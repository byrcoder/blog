package toolbox.cassandra.client;

import com.datastax.driver.core.KeyspaceMetadata;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.TableMetadata;
import org.apache.log4j.Logger;
import toolbox.cassandra.client.annotation.ColumnKey;
import toolbox.cassandra.client.annotation.RowKey;
import toolbox.cassandra.client.protocol.Keyspace;
import toolbox.cassandra.client.protocol.Table;
import toolbox.cassandra.client.protocol.Entity;

import java.util.*;

/**
 * @author yangzhe
 * @version created on 14-4-11.
 */
class KeyspaceClient implements Keyspace {
    private static Logger logger = Logger.getLogger(KeyspaceClient.class);

    private Session session;

    private KeyspaceMetadata meta;

    private Map<String, String> typeMap;

    public KeyspaceClient(KeyspaceMetadata km, Session session) {
        this.meta = km;
        this.session = session;
        typeMap = new Hashtable<String, String>();
        typeMap.put("byte", "blob");
        typeMap.put("boolean", "boolean");
        typeMap.put("short", "short");
        typeMap.put("integer", "int");
        typeMap.put("long", "bigint");
        typeMap.put("float", "float");
        typeMap.put("double", "double");
        typeMap.put("string", "text");
        typeMap.put("vint", "varint");
        typeMap.put("text", "text");
        typeMap.put("vintstring", "text");
        typeMap.put("vintbytearray", "blob");
        typeMap.put("blob", "blob");
        typeMap.put("textarray", "list<text>");
        typeMap.put("bytearray", "blob");
    }

    @Override
    public KeyspaceMetadata getMata() {
        return meta;
    }

    @Override
    public Table createTable(Entity defObj) {
        if (defObj == null || defObj.getTableName().isEmpty()) {
            logger.info("create table fail, input invalid!");
            return null;
        }
        StringBuffer sb = new StringBuffer();
        sb.append("create table ").append(meta.getName() + ".").append(defObj.getTableName()).append(" (");
        List<EntityHelper.FieldPair> rowKeys = new ArrayList<EntityHelper.FieldPair>();
        List<EntityHelper.FieldPair> colKeys = new ArrayList<EntityHelper.FieldPair>();
        for (EntityHelper.FieldPair f : EntityHelper.getFieldsWithType(defObj.getClass())) {
            if (f.annotation.annotationType() == RowKey.class) {
                rowKeys.add(f);
            } else if (f.annotation.annotationType() == ColumnKey.class) {
                colKeys.add(f);
            }
            sb.append(f.columnName + " " + f.type.name() + " , ");
        }
        if (rowKeys.size() == 0) {
            logger.info("create table fail, no row key!");
            return null;
        }
        sb.append("primary key ( ");
        if (rowKeys.size() > 1) {
            sb.append("(");
        }
        for (int i = 0; i < rowKeys.size(); i++) {
            sb.append(rowKeys.get(i).columnName + " ");
            if (i < rowKeys.size() - 1) {
                sb.append(", ");
            }
        }
        if (rowKeys.size() > 1) {
            sb.append(")");
        }
        for (EntityHelper.FieldPair f : colKeys) {
            sb.append(", " + f.columnName);
        }
        sb.append(") )");
        logger.info(sb.toString());
        session.execute(sb.toString());
        int n=session.getCluster().getMetadata().getAllHosts().size()+1;
        try {
            Thread.sleep(n*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        n=n*10;
        while(n-->0){
            try {
                //如果没有这个可能导致openTable返回空
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Table t=openTable(defObj.getTableName());
            if(t!=null){
                return t;
            }
        }
        return null;

    }

    @Override
    public Table createTable(String tableName, String[] columnNames, String[] types) {
        if (tableName.isEmpty()) {
            return null;
        }
        StringBuffer sb = new StringBuffer();
        sb.append("create table ").append(meta.getName() + "." + tableName + " ( ");
        if (columnNames.length != types.length || columnNames.length == 0) {
            return null;
        }
        for (int i = 0; i < columnNames.length; i++) {
            sb.append(columnNames[i] + " " + typeMap.get(types[i].toLowerCase()) + " , ");
        }
        sb.append("primary key ( " + columnNames[0] + " ) )");

        logger.info(sb.toString());
        session.execute(sb.toString());
        //如果没有这个可能导致openTable返回空
        int n=session.getCluster().getMetadata().getAllHosts().size()+1;
        try {
            Thread.sleep(n*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        n=n*10;
        while(n-->0){
            try {
                //如果没有这个可能导致openTable返回空
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Table t=openTable(tableName);
            if(t!=null){
                return t;
            }
        }
        return null;
    }

    @Override
    public Collection<TableMetadata> listTables() {
        return meta.getTables();
    }

    @Override
    public TableMetadata findTable(String tableName) {
        return meta.getTable(tableName);
    }

    @Override
    public void deleteTable(String tableName) {
        session.execute("drop table if exists " + meta.getName() + "." + tableName);
    }

    @Override
    public Table openTable(String tableName) {
        TableMetadata tm = meta.getTable(tableName);
        logger.info("opening table "+tableName+"... "+tm);
        if (tm == null) {
            return null;
        }
        return new TableClient(tm, session);
    }

    @Override
    public Session getGlobalSession() {
        return session;
    }
}
