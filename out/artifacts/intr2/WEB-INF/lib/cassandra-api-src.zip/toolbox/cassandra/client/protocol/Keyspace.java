package toolbox.cassandra.client.protocol;

import com.datastax.driver.core.KeyspaceMetadata;
import com.datastax.driver.core.TableMetadata;

import java.util.Collection;

/**
 * 操作特定keyspace的句柄
 *
 * @author yangzhe
 * @version created on 14-4-9.
 */
public interface Keyspace extends HasSession {

    /**
     * 获取该Keyspace的定义信息
     *
     * @return
     */
    public KeyspaceMetadata getMata();

    /**
     * 创建新表，如果已经存在同名的表不看定义是否相同直接返回该表
     * 创建失败（如格式非法等）会返回null
     * 需要注意，为了保证create table后，集群所有节点都能得到这个信息，会阻塞sleep 节点个数+1 秒才返回
     *
     * @param defObj 传入一个Entity对象来描述定义
     * @return
     */
    public Table createTable(Entity defObj);

    /**
     * Omap风格的建表，如果已经存在同名的表不看定义是否相同直接返回该表
     * 支持Omap的格式声明会把第一个字段当成RowKey，无ColumnKey
     * omap和cassandra的类型对应关系如下：不支持FIXEDLENGTHBYTEARRAY和TPKEY
     * 不支持ARRAY，支持泛型后的TEXTARRAY
     * 想使用cassandra的set、map、其他泛型list等类型请直接自己写sql语句用session建表……
     * 创建失败（如格式非法等）会返回null
     * 需要注意，为了保证create table后，集群所有节点都能得到这个信息，会阻塞sleep 节点个数+1 秒才返回
     *
     * <table>
     * <tr><th>OMAP类型</th><th>Cassandra类型</th><th>Java类型</th></tr>
     * <tr><td>BYTE</td><td>blob</td><td>java.nio.ByteBuffer</td></tr>
     * <tr><td>BOOLEAN</td><td>boolean</td><td>boolean</td></tr>
     * <tr><td>SHORT</td><td>int</td><td>int</td></tr>
     * <tr><td>INTEGER</td><td>int</td><td>int</td></tr>
     * <tr><td>LONG</td><td>bigint</td><td>long</td></tr>
     * <tr><td>FLOAT</td><td>float</td><td>float</td></tr>
     * <tr><td>DOUBLE</td><td>double</td><td>double</td></tr>
     * <tr><td>STRING</td><td>text</td><td>java.lang.String</td></tr>
     * <tr><td>VINT</td><td>varint</td><td>java.math.BigInteger</td></tr>
     * <tr><td>TEXT</td><td>text</td><td>java.lang.String</td></tr>
     * <tr><td>VINTSTRING</td><td>text</td><td>java.lang.String</td></tr>
     * <tr><td>VINTBYTEARRAY</td><td>blob</td><td>blob</td></tr>
     * <tr><td>BLOB</td><td>blob</td><td>blob</td></tr>
     * <tr><td>TEXTARRAY</td><td>list(text)</td><td>java.util.List<String></td></tr>
     * <tr><td>BYTEARRAY</td><td>blob</td><td>blob</td></tr>
     * </table>
     *
     * @param tableName
     * @param columnNames
     * @param types
     * @return
     */
    public Table createTable(String tableName, String[] columnNames, String[] types);

    /**
     * 返回该keyspace已存在的表
     *
     * @return
     */
    public Collection<TableMetadata> listTables();

    /**
     * 根据表名查找表
     *
     * @param tableName
     * @return 返回该表的定义信息，如不存在返回null
     */
    public TableMetadata findTable(String tableName);

    /**
     * 删除一个表
     *
     * @param tableName
     */
    public void deleteTable(String tableName);

    /**
     * 根据表名返回操作该表的句柄，如不存在返回null
     * 每次调用会创建新的Table实例，但内部的Session是全局单例
     *
     * @param tableName
     * @return
     */
    public Table openTable(String tableName);
}
