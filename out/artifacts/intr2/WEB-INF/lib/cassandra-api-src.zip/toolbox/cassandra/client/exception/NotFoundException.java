package toolbox.cassandra.client.exception;

/**
 * @author yangzhe
 * @version created on 14-4-9.
 */
public class NotFoundException extends Exception {
    public NotFoundException(String what) {
        super(what + " not found!");
    }
}
