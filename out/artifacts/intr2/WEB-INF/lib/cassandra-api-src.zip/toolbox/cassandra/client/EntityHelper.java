package toolbox.cassandra.client;

import com.datastax.driver.core.DataType;
import com.datastax.driver.core.Row;
import toolbox.cassandra.client.annotation.Column;
import toolbox.cassandra.client.annotation.ColumnKey;
import toolbox.cassandra.client.annotation.RowKey;
import toolbox.cassandra.client.protocol.Entity;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * @author yangzhe
 * @version created on 14-4-11.
 */
class EntityHelper {

    static List<FieldPair> getFieldsWithType(Class<? extends Entity> c) {
        List<FieldPair> result = new ArrayList<FieldPair>();
        for (Field f : c.getDeclaredFields()) {
            f.setAccessible(true);
            if (f.getAnnotation(RowKey.class) == null
                    && f.getAnnotation(ColumnKey.class) == null
                    && f.getAnnotation(Column.class) == null) {
                continue;
            }
            for (DataType.Name n : DataType.Name.values()) {
                if (n == DataType.Name.ASCII) {
                    //字符串一律当做TEXT
                    continue;
                }
                if (n.asJavaClass().equals(f.getType())) {
                    Annotation a;
                    if (f.getAnnotation(RowKey.class) != null) {
                        a = f.getAnnotation(RowKey.class);
                    } else if (f.getAnnotation(ColumnKey.class) != null) {
                        a = f.getAnnotation(ColumnKey.class);
                    } else {
                        a = f.getAnnotation(Column.class);
                    }
                    result.add(new FieldPair(n, f.getName(), a));
                    break;
                }
            }
        }
        return result;
    }

    static<Q> Q newEntityInstance(Class<? extends Entity> c) {
        try {
            return (Q)c.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    static List<String> getFields(Class<? extends Entity> c, Class<? extends Annotation> annotation) {
        List<String> result = new ArrayList<String>();
        for (Field f : c.getDeclaredFields()) {
            f.setAccessible(true);
            if (f.getAnnotation(annotation) == null) {
                continue;
            }
            result.add(f.getName());
        }
        return result;
    }

    static void setFieldValue(Object obj, String name, Object value) {
        Field f;
        try {
            f = obj.getClass().getDeclaredField(name);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
            return;
        }
        f.setAccessible(true);
        try {
            f.set(obj, value);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    static Object getFieldValueObject(Object obj, String name) {
        Field f;
        try {
            f = obj.getClass().getDeclaredField(name);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
            return null;
        }
        f.setAccessible(true);
        try {
            return f.get(obj);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    static Type[] getGenericTypes(Object obj, String name) {
        Field f = null;
        try {
            f = obj.getClass().getDeclaredField(name);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
            return null;
        }
        f.setAccessible(true);
        ParameterizedType pt = (ParameterizedType) f.getGenericType();
        return pt.getActualTypeArguments();
    }

    static void rowToEntity(Row r,Entity n,List<EntityHelper.FieldPair> types){

        //TODO 需要确认switch枚举类型是否是效率最高的办法
        for (EntityHelper.FieldPair fp : types) {
            try {
                switch (fp.type) {
                    case TEXT:
                    case VARCHAR:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getString(fp.columnName));
                        break;
                    case INT:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getInt(fp.columnName));
                        break;
                    case BIGINT:
                    case COUNTER:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getLong(fp.columnName));
                        break;
                    case TIMESTAMP:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getDate(fp.columnName));
                        break;
                    case BLOB:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getBytes(fp.columnName));
                        break;
                    case BOOLEAN:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getBool(fp.columnName));
                        break;
                    case VARINT:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getVarint(fp.columnName));
                        break;
                    case DECIMAL:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getDecimal(fp.columnName));
                        break;
                    case DOUBLE:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getDouble(fp.columnName));
                        break;
                    case FLOAT:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getFloat(fp.columnName));
                        break;
                    case UUID:
                    case TIMEUUID:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getUUID(fp.columnName));
                        break;
                    case INET:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getInet(fp.columnName));
                        break;
                    case LIST:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getList(fp.columnName,
                                (Class) EntityHelper.getGenericTypes(n, fp.columnName)[0]));
                        break;
                    case SET:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getSet(fp.columnName,
                                (Class) EntityHelper.getGenericTypes(n, fp.columnName)[0].getClass()));
                        break;
                    case MAP:
                        EntityHelper.setFieldValue(n, fp.columnName, r.getMap(fp.columnName,
                                (Class) EntityHelper.getGenericTypes(n, fp.columnName)[0].getClass(), (Class) EntityHelper.getGenericTypes(n, fp.columnName)[1].getClass()));
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    static class FieldPair {
        public DataType.Name type;
        public String columnName;
        public Annotation annotation;

        public FieldPair(DataType.Name type, String name, Annotation a) {
            this.type = type;
            this.columnName = name;
            this.annotation = a;
        }
    }



}

