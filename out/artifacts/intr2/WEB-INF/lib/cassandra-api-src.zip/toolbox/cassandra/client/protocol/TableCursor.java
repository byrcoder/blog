package toolbox.cassandra.client.protocol;

import toolbox.cassandra.client.exception.CassandraRuntimeException;

/**
 * @author yangzhe
 * @version created on 14-4-16.
 */
public interface TableCursor<T extends Entity> {
    /**
     * 如果存在对应的key，则下次调用next返回colKeys对应的行
     * 否则下次调用next会返回大于colKeys的第一行
     * colKeys按照顺序进行优先级排序
     * 参数的长度可以小于column key的个数
     * 为null相当于跳到该rowKey下的第一行
     *
     * @param colKeys
     */
    public void moveTo(Object... colKeys) throws CassandraRuntimeException;

    /**
     * 读下一行数据
     *
     * @param
     * @return 存在数据则返回，否则返回null
     */
    public T next() throws CassandraRuntimeException;

}
