package toolbox.cassandra.client.annotation;

import java.lang.annotation.*;

/**
 * 注解一个属性为该类型的ColumnKey
 *
 * @author yangzhe
 * @version created on 14-4-10.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface ColumnKey {

}
