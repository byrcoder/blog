package toolbox.cassandra.client;

import com.datastax.driver.core.*;
import com.datastax.driver.core.exceptions.NoHostAvailableException;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.fluent.Content;
import org.apache.http.client.fluent.Request;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import toolbox.cassandra.client.exception.CassandraRuntimeException;
import toolbox.cassandra.client.exception.NotFoundException;
import toolbox.cassandra.client.protocol.HasSession;
import toolbox.cassandra.client.protocol.Keyspace;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

/**
 * @author yangzhe
 * @version created on 14-4-9.
 */
public class CassandraClient implements HasSession {

    private static Logger logger = Logger.getLogger(CassandraClient.class);

    private static CassandraClient instance = new CassandraClient();

    private Cluster cluster;

    private Session globalSession;

    private boolean isInit = false;

    private final String nodesListUrl = "http://config.corp.yodao.com/svn/yodaoconfig/cassandra/seedlist";

    private final String nodesListUrlTest = "http://config.corp.yodao.com/svn/yodaoconfig/cassandra/seedlist_test";

    private final String log4jConfigUrl = "http://config.corp.yodao.com/svn/yodaoconfig/cassandra/log4j.properties";

    private CassandraClient() {
    }

    private static String httpGet(String url) throws IOException {
        Content content = Request.Get(url)
                .connectTimeout(3000)
                .socketTimeout(3000)
                .execute().returnContent();
        return IOUtils.toString(content.asStream(), "UTF-8");
    }

    /**
     * 获取线上Cassandra集群的实例，与测试共用单例，哪个先调用连哪个
     * 采用默认配置，如一致性为ONE
     *
     * @return
     * @throws CassandraRuntimeException
     */
    public static synchronized CassandraClient getInstance() throws CassandraRuntimeException {
        return getInstance(new QueryOptions());
    }

    /**
     * 新建带查询配置的线上集群实例
     *
     * @param qo 见{QueryOptions}
     * @return
     * @throws CassandraRuntimeException
     */
    public static synchronized CassandraClient getInstance(QueryOptions qo) throws CassandraRuntimeException {
        try {
            if (!instance.isInit) {
                instance.init(qo);
            }
        } catch (NoHostAvailableException e) {
            for (Map.Entry<InetSocketAddress, Throwable> entry : e.getErrors().entrySet()) {
                entry.getValue().printStackTrace();
            }
            throw new CassandraRuntimeException(e);
        } catch (RuntimeException e) {
            throw new CassandraRuntimeException(e);
        }
        return instance;
    }

    /**
     * 获取测试服Cassandra集群的实例，与线上共用单例，哪个先调用连哪个
     * 采用默认配置，如一致性为ONE
     * @return
     * @throws CassandraRuntimeException
     */
    public static synchronized CassandraClient getInstanceForTest() throws CassandraRuntimeException {
        return getInstanceForTest(new QueryOptions());
    }

    /**
     * 新建带查询配置的测试集群实例
     *
     * @param qo 见{QueryOptions}
     * @return
     * @throws CassandraRuntimeException
     */
    public static synchronized CassandraClient getInstanceForTest(QueryOptions qo) throws CassandraRuntimeException {
        try {
            if (!instance.isInit) {
                instance.initForTest(qo);
            }
        } catch (NoHostAvailableException e) {
            for (Map.Entry<InetSocketAddress, Throwable> entry : e.getErrors().entrySet()) {
                entry.getValue().printStackTrace();
            }
            throw new CassandraRuntimeException(e);
        } catch (RuntimeException e) {
            throw new CassandraRuntimeException(e);
        }
        return instance;
    }

    private void init(QueryOptions qo) {
        try {
            PropertyConfigurator.configure(new URL(log4jConfigUrl));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        String[] nodes = null;
        try {
            nodes = httpGet(nodesListUrl).split("\\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
        connect(qo, nodes);
        isInit = true;
    }

    private void initForTest(QueryOptions qo) {
        try {
            PropertyConfigurator.configure(new URL(log4jConfigUrl));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        String[] nodes = null;
        try {
            nodes = httpGet(nodesListUrlTest).split("\\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
        connect(qo, nodes);
        isInit = true;
    }

    private void connect(QueryOptions qo, String[] nodes) {
        Cluster.Builder builder = Cluster.builder();
        for (String node : nodes) {
            builder.addContactPoint(node);
        }
        cluster = builder.withQueryOptions(qo).build();
        Metadata metadata = cluster.getMetadata();
        logger.info("Connected to cluster: " + metadata.getClusterName());
        for (Host host : metadata.getAllHosts()) {
            logger.info("Datacenter: " + host.getDatacenter() + "; Host: "
                    + host.getAddress() + "; Rack: " + host.getRack());
        }
        globalSession = cluster.connect();
    }

    /**
     * 获取一个操作keyspace的实例
     * 每次调用会创建新的实例，但内部的Session是全局单例
     *
     * @param name
     * @return
     * @throws NotFoundException
     */
    public Keyspace getKeyspace(String name) throws NotFoundException {
        KeyspaceMetadata km = cluster.getMetadata().getKeyspace(name);
        if (km == null) {
            throw new NotFoundException("Keyspace not found");
        }
        return new KeyspaceClient(km, globalSession);
    }


    @Override
    public Session getGlobalSession() {
        return globalSession;
    }

    public void close() {
        globalSession.close();
        cluster.close();
    }
}
