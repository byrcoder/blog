package toolbox.cassandra.client;


import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.*;
import toolbox.cassandra.client.annotation.Column;
import toolbox.cassandra.client.annotation.ColumnKey;
import toolbox.cassandra.client.annotation.RowKey;
import toolbox.cassandra.client.exception.CassandraRuntimeException;
import toolbox.cassandra.client.protocol.Table;
import toolbox.cassandra.client.protocol.Entity;
import toolbox.cassandra.client.protocol.TableCursor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author yangzhe
 * @version created on 14-4-11.
 */
class TableClient<T extends Entity> implements Table<T> {
    private Session session;

    private TableMetadata meta;

    public TableClient(TableMetadata tm, Session session) {
        this.meta = tm;
        this.session = session;
    }

    @Override
    public TableMetadata getMata() {
        return meta;
    }

    @Override
    public void update(T obj) throws CassandraRuntimeException{
        try {
            Update.Where where = updateBuilder().where();
            for (String col : EntityHelper.getFields(obj.getClass(), RowKey.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.and(QueryBuilder.eq(col, v));
                } else {
                    return;
                }
            }
            for (String col : EntityHelper.getFields(obj.getClass(), ColumnKey.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.and(QueryBuilder.eq(col, v));
                }
            }
            for (String col : EntityHelper.getFields(obj.getClass(), Column.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.with(QueryBuilder.set(col, v));
                }
            }
            if (obj.getTTL() > 0) {
                where.using(QueryBuilder.ttl(obj.getTTL()));
            }

            session.execute(where.setConsistencyLevel(obj.getWriteConsistencyLevel()));
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }

    }

    @Override
    public void update(String[] column, Object[] value, Object... keys) throws CassandraRuntimeException {
        try {
            if (column.length != value.length || column.length == 0) {
                return;
            }
            Update u = updateBuilder();
            for (int i = 0; i < column.length; i++) {
                u.with(QueryBuilder.set(column[i], value[i]));
            }
            for (int i = 0; i < keys.length; i++) {
                u.where(QueryBuilder.eq(meta.getPrimaryKey().get(i).getName(), keys[i]));
            }
            session.execute(u.setConsistencyLevel(ConsistencyLevel.QUORUM));
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }
    }

    @Override
    public void delete(T obj) throws CassandraRuntimeException {
        try{
            Delete.Where where = deleteBuilder().where();
            for (String col : EntityHelper.getFields(obj.getClass(), RowKey.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.and(QueryBuilder.eq(col, v));
                } else {
                    return;
                }
            }
            for (String col : EntityHelper.getFields(obj.getClass(), ColumnKey.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.and(QueryBuilder.eq(col, v));
                }
            }
            session.execute(where.setConsistencyLevel(obj.getWriteConsistencyLevel()));
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }
    }

    @Override
    public void delete(Object... keys) throws CassandraRuntimeException {
        try{
            Delete.Where where = deleteBuilder().where();
            for (int i = 0; i < keys.length; i++) {
                String keyname = meta.getPrimaryKey().get(i).getName();
                where.and(QueryBuilder.eq(keyname, keys[i]));
            }
            session.execute(where.setConsistencyLevel(ConsistencyLevel.QUORUM));
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }
    }

    @Override
    public List<T> get(T obj) throws CassandraRuntimeException {
        try{
            Select.Where where = selectBuilder().where();
            for (String col : EntityHelper.getFields(obj.getClass(), RowKey.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.and(QueryBuilder.eq(col, v));
                } else {
                    return null;
                }
            }
            for (String col : EntityHelper.getFields(obj.getClass(), ColumnKey.class)) {
                Object v = EntityHelper.getFieldValueObject(obj, col);
                if (v != null) {
                    where.and(QueryBuilder.eq(col, v));
                }
            }
            ResultSet rows = session.execute(where.setConsistencyLevel(obj.getReadConsistencyLevel()));
            return resultSetToEntityList(rows,obj);
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }

    }

    @Override
    public ResultSet get(Object... keys) throws CassandraRuntimeException {
        try {
            Select.Where where = selectBuilder().where();
            for (int i = 0; i < keys.length; i++) {
                String keyname = meta.getPrimaryKey().get(i).getName();
                where.and(QueryBuilder.eq(keyname, keys[i]));
            }
            return session.execute(where.setConsistencyLevel(ConsistencyLevel.QUORUM));
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }
    }

    @Override
    public Update updateBuilder() {
        return QueryBuilder.update(meta.getKeyspace().getName(), meta.getName());
    }

    @Override
    public Insert insertBuilder() {
        return QueryBuilder.insertInto(meta.getKeyspace().getName(), meta.getName());
    }

    @Override
    public Select selectBuilder() {
        return QueryBuilder.select().from(meta.getKeyspace().getName(), meta.getName());
    }

    @Override
    public Delete deleteBuilder() {
        return QueryBuilder.delete().from(meta.getKeyspace().getName(), meta.getName());
    }

    @Override
    public TableCursor<T> getCursor(Class<T> c, Object... rowKeys) throws CassandraRuntimeException {
        try{
            return new TableCursorClient(this, c, rowKeys);
        }catch(Exception e){
            throw new CassandraRuntimeException(e);
        }
    }
    public List<T> resultSetToEntityList(ResultSet rows,T obj){
        List<T> result=new ArrayList<T>();
        List<EntityHelper.FieldPair> types=EntityHelper.getFieldsWithType(obj.getClass());
        for (Row r : rows.all()) {
            T n = EntityHelper.newEntityInstance(obj.getClass());
            EntityHelper.rowToEntity(r,n,types);
            result.add(n);
        }
        return result;
    }
    @Override
    public Session getGlobalSession() {
        return session;
    }
}
