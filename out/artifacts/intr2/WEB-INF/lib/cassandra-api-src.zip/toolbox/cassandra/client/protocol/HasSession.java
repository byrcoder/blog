package toolbox.cassandra.client.protocol;

import com.datastax.driver.core.Session;

/**
 * 实现该接口的类都需要保存Cassandra driver提供的全局Session
 * Session是并发安全且提供了连接池，所以只有一个实例
 *
 * @author yangzhe
 * @version created on 14-4-9.
 */
public interface HasSession {

    /**
     * 获取全局共用的session实例
     * Session是并发安全且提供了连接池，所以只有一个实例
     *
     * @return
     */
    public Session getGlobalSession();
}
