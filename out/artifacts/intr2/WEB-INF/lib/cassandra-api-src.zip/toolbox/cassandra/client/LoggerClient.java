package toolbox.cassandra.client;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * @author yangzhe
 * @version created on 14-4-21.
 */
public class LoggerClient {
    public static Logger getLogger(Class clazz) {
        Logger logger = Logger.getLogger(clazz);
        logger.setLevel(Level.INFO);
        return logger;
    }
}
