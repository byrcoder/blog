package toolbox.cassandra.client.protocol;

import com.datastax.driver.core.ConsistencyLevel;

/**
 * 直接将类型映射为数据库表的需要实现该接口
 * 给每个字段（可以为private）标记@RowKey、@ColumnKey或@Column注解来声明这个表的结构：
        * 需要成为无序的分区用RowKey请用@RowKey注解标记，只能有一个
        * 需要成为有序可比较大小的ColumnKey请用@ColumnKey注解标记，可以有多个，有顺序
        * 其他字段标记为@Column
* 所有字段不要使用标准类型而是封装的类，如要用Integer类而非int
        * byte[]需要用ByteBuffer
 * 其子类一定要public否则会导致一些方法报错
        *
        * @author yangzhe
        * @version created on 14-4-10.
        */
public interface Entity {

    /**
     * 表名
     *
     * @return
     */
    public String getTableName();

    /**
     * update时，若另此函数返回大于0的数，则会设置对应的TTL，单位是秒，到期删除
     *
     * @return
     */
    public int getTTL();

    /**
     * 读取时需要的一致性，不可为null
     * @return
     */
    public ConsistencyLevel getReadConsistencyLevel();

    /**
     * 写入时需要的一致性，不可为null
     * @return
     */
    public ConsistencyLevel getWriteConsistencyLevel();
}
