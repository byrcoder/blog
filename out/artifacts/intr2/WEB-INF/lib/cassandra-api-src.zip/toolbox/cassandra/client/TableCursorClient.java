package toolbox.cassandra.client;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import toolbox.cassandra.client.protocol.Entity;
import toolbox.cassandra.client.protocol.Table;
import toolbox.cassandra.client.protocol.TableCursor;

import java.util.List;

/**
 * @author yangzhe
 * @version created on 14-4-16.
 */

class TableCursorClient<T extends Entity> implements TableCursor<T> {

    private Table<T> table;

    private Object[] rowKeys;

    private ResultSet bufferdResutlSet;

    private Row next;

    List<EntityHelper.FieldPair> types;

    Class<T> clazz;


    TableCursorClient(Table<T> t, Class<T> c, Object... rowKeys) {
        table = t;
        this.rowKeys = rowKeys;
        clazz=c;//吐槽下JAVA的伪泛型，只能传参数来在runtime时判断class信息
        types=EntityHelper.getFieldsWithType(c);
        moveTo(null);

    }

    @Override
    public void moveTo(Object... colKeys) {
        getNewResults(true, colKeys);
    }

    @Override
    public T next() {
        if (next == null) {
            return null;
        }
        Row row = next;
        next = bufferdResutlSet.one();
        if (next == null) {
            getNewResults(row);
        }
        T n = EntityHelper.newEntityInstance(clazz);
        EntityHelper.rowToEntity(row,n,types);
        return n;
    }

    /**
     * 获取后续若干个新结果
     * @param r
     * @return
     */
    private boolean getNewResults(Row r) {
        Object[] cols = new Object[table.getMata().getClusteringColumns().size()];
        for (int i = 0; i < cols.length; i++) {
            ColumnMetadata col = table.getMata().getClusteringColumns().get(i);
            DataType.Name name = col.getType().getName();
            switch (name) {
                case TEXT:
                case VARCHAR:
                    cols[i] = r.getString(col.getName());
                    break;
                case INT:
                    cols[i] = r.getInt(col.getName());
                    break;
                case BIGINT:
                case COUNTER:
                    cols[i] = r.getLong(col.getName());
                    break;
                case TIMESTAMP:
                    cols[i] = r.getDate(col.getName());
                    break;
                case BLOB:
                    cols[i] = r.getBytes(col.getName());
                    break;
                case BOOLEAN:
                    cols[i] = r.getBool(col.getName());
                    break;
                case VARINT:
                    cols[i] = r.getVarint(col.getName());
                    break;
                case DECIMAL:
                    cols[i] = r.getDecimal(col.getName());
                    break;
                case DOUBLE:
                    cols[i] = r.getDouble(col.getName());
                    break;
                case FLOAT:
                    cols[i] = r.getFloat(col.getName());
                    break;
                case UUID:
                case TIMEUUID:
                    cols[i] = r.getUUID(col.getName());
                    break;
                case INET:
                    cols[i] = r.getInet(col.getName());
                    break;
            }
        }
        Object[] tmp = cols;
        while (!getNewResults(false, tmp)) {
            if (tmp.length == 1) {
                return false;
            }
            tmp = new Object[tmp.length - 1];
            System.arraycopy(cols, 0, tmp, 0, tmp.length);
        }
        return true;

    }

    /**
     * @param isGte   true最后一个colKey大于等于，其他的等于;false最后一个colKey大于，其他的等于
     * @param colKeys
     * @return
     */
    private boolean getNewResults(boolean isGte, Object... colKeys) {
        Select.Where where = table.selectBuilder().where();
        for (int i = 0; i < rowKeys.length; i++) {
            String keyname = table.getMata().getPartitionKey().get(i).getName();
            where.and(QueryBuilder.eq(keyname, rowKeys[i]));
        }
        if (colKeys != null) {
            for (int i = 0; i < colKeys.length; i++) {
                String keyname = table.getMata().getClusteringColumns().get(i).getName();
                if (i < colKeys.length - 1) {
                    where.and(QueryBuilder.eq(keyname, colKeys[i]));
                } else if (isGte) {
                    where.and(QueryBuilder.gte(keyname, colKeys[i]));
                } else {
                    where.and(QueryBuilder.gt(keyname, colKeys[i]));
                }
            }
        }
        bufferdResutlSet = table.getGlobalSession().execute(where.setConsistencyLevel(ConsistencyLevel.QUORUM));
        next = bufferdResutlSet.one();
        return next != null;
    }
}
