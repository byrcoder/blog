package toolbox.cassandra.client.exception;

/**
 * @author yangzhe
 * @version created on 14-4-15.
 */
public class InitFailException extends Exception {
    public InitFailException() {
        super("init cassandra cluster fail!");
    }
}
