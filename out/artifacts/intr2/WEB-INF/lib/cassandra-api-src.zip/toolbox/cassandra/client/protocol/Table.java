package toolbox.cassandra.client.protocol;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.TableMetadata;
import com.datastax.driver.core.querybuilder.Delete;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.Select;
import com.datastax.driver.core.querybuilder.Update;
import toolbox.cassandra.client.exception.CassandraRuntimeException;

import java.util.List;

/**
 * 操作特定table的句柄
 *
 * @author yangzhe
 * @version created on 14-4-9.
 */
public interface Table<T extends Entity> extends HasSession {
    /**
     * 获取该表metadata
     *
     * @return
     */
    public TableMetadata getMata();

    /**
     * 插入或更新一条数据，此时要求所有RowKey和ColumnKey都不能为null
     * 将特定字段设为null可以跳过覆盖此列
     *
     * @param obj
     */
    public void update(T obj) throws CassandraRuntimeException;

    /**
     * 针对只有一个key的时候做update，至少需要指定全部RowKey
     * 一致性使用QUORUM模式
     *
     * @param keys   参数顺序需要和定义的主键(RowKey+ColumnKey)顺序保持一致
     * @param column
     * @param value
     */
    public void update(String[] column, Object[] value, Object... keys) throws CassandraRuntimeException;

    /**
     * 根据RowKey（均不能为null）和ColumnKey（可为null）删除数据
     *
     * @param obj
     */
    public void delete(T obj) throws CassandraRuntimeException;

    /**
     * 按key删除数据，参数顺序需要和定义的主键(RowKey+ColumnKey)顺序保持一致
     * 至少需要指定全部RowKey
     *
     * @param keys
     */
    public void delete(Object... keys) throws CassandraRuntimeException;

    /**
     * 查询数据，@RowKey和@ColumnKey的字段需要设好，所有RowKey不能为null
     * 会覆盖当前@Column上的值，查询时不会这些字段的进行过滤，尽管如果该列建了index是可以进行条件查询的
     * 如果有高级查询需求如对列用了index、针对Column判断大小、返回多个结果等，请使用QueryBuilder构建
     * QueryBuilder样例在https://gist.github.com/yangzhe1991/10349122
     *
     * @param obj
     * @return 查询非法会返回null，否则永远不会为null
     */
    public List<T> get(T obj) throws CassandraRuntimeException;

    /**
     * 根据各个主键读0-n行数据
     * 参数顺序需要和定义的主键(RowKey+ColumnKey)顺序保持一致
     * 如果参数多于主键数或类型不匹配等原因抛异常需自行处理
     * 一致性使用QUORUM模式
     *
     * @param keys
     * @return driver原生的ResultSet类型
     */
    public ResultSet get(Object... keys) throws CassandraRuntimeException;

    /**
     * 创建一个针对此表的update QueryBuilder
     * 请注意如果试图修改主键，实际上会insert一条新数据，旧的还在
     * 一致性需要自己设，否则默认只是ONE模式
     *
     * @return
     */
    public Update updateBuilder();

    /**
     * 创建一个针对此表的insert QueryBuilder
     * 一致性需要自己设，否则默认只是ONE模式
     *
     * @return
     */
    public Insert insertBuilder();

    /**
     * 创建一个针对此表的select QueryBuilder
     * 一致性需要自己设，否则默认只是ONE模式
     *
     * @return
     */
    public Select selectBuilder();

    /**
     * 创建一个针对此表的delete QueryBuilder
     * 一致性需要自己设，否则默认只是ONE模式
     *
     * @return
     */
    public Delete deleteBuilder();

    /**
     *
     * 获取一个cursor用来扫描，因为Cassandra与omap/hbase结构不同，只能在特定的rowKey下扫描
     *
     * @param c 为了让返回的类型为T，请传入具体的类
     * @param rowKeys
     * @return 如果参数和实际表结构中的RowKey对应不上返回null
     */
    public TableCursor<T> getCursor(Class<T> c,Object... rowKeys) throws CassandraRuntimeException;

    /**
     * 将ResultSet填充成Entity，方便通过driver原生api复杂查询时的类型获取。
     * @param resultSet
     * @param obj
     * @return
     */
    public List<T> resultSetToEntityList(ResultSet resultSet,T obj);
}
