package toolbox.cassandra.client.exception;

/**
 * @author yangzhe
 * @version created on 14-4-30.
 */
public class CassandraRuntimeException extends Exception{
    public CassandraRuntimeException(Exception e){
        super(e);
    }
}
