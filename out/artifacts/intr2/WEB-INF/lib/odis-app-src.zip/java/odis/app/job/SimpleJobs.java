package odis.app.job;

import java.io.IOException;
import java.util.Arrays;

import odis.app.view.DataUtils;
import odis.app.view.DataUtils.PathProp;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.io.IFileSystem;
import odis.io.LockStateException;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapMergeConf;
import odis.mapred.lib.IdentityMapper;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.ReuseWalker;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;

/**
 * Some static methods for executing some simple jobs
 * 
 * @author david
 *
 */
public class SimpleJobs {
    @SuppressWarnings("unchecked")
    public static boolean sortData(ToolContext context, IFileSystem fs, 
            Path input, Path output, int outPart, 
            Class<? extends BasicPartitioner> partitioner, int nWorker) 
            throws IOException, LockStateException {
        PathProp pp = DataUtils.checkPathProp(fs, input);
        if (pp == null)
            throw new IOException(input + "@" + fs + " is not a valid path!");
        return sortSeqData(context, fs, input, output, outPart, 
                pp.getKeyClass(), pp.getValClass(), partitioner, nWorker, 
                nWorker * 3);
    }
    public static boolean sortSeqData(ToolContext context, IFileSystem fs, 
            Path input, Path output, int outPart, 
            Class<? extends IWritableComparable> keyClass, 
            Class<? extends IWritable> valClass, 
            Class<? extends BasicPartitioner> partitioner, int nWorker, 
            int nMapper) throws IOException, LockStateException {
        MapReduceJobDef job = AppCreationUtils.createMapReduceJob(context, 
                "sort.data", nWorker, 
                IdentityMapper.class, nMapper, 
                IdentityReducer.class, outPart, 
                keyClass, valClass, partitioner);
        
        MapReduceHelper helper = new MapReduceHelper(job, fs, 
                context.tempPath(""), context.path(""));
        
        helper.addReadInputDir(input, null);
        helper.addUpdateOutputDir(0, output, keyClass, valClass, null);
        
        JobResult res = helper.runJob(context.getCoWork());
        if (!res.isSuccess())
            return false;
        
        return true;
    }
    
    /**
     * The merge-mapper for mergeLookup
     * 
     * @author David
     *
     */
    public static class SimpleLookupMerger implements IMergeMapper {
        public static String KEY_COUNT = "key.count";
        // boolean: output multiple values for the same key if more than one exists in the values file 
        public static String MULTI_VALUES = "multi.values"; 
        int keyCount = 1;
        boolean multiValues;
        public void configure(JobDef conf, TaskRunnable task) {
            keyCount = conf.getConfig().getInt(KEY_COUNT);
            multiValues = conf.getConfig().getBoolean(MULTI_VALUES, false);
        }
        public void mapBegin() {}

        long countInput = 0;
        long countOutput = 0;
        
        public void map(Object key, IWritablePairWalker[] mergeValues, 
                ICollector collector) {
            countInput ++;
            int keyIndex = -1;
            for (int i = 0; i < keyCount; i ++)
                if (mergeValues[i] != null && mergeValues[i].moreValue()) {
                    keyIndex = i;  break;
                } // if, for i
            if (keyIndex == -1)
                return;
            
            for (int i = keyCount; i < mergeValues.length; i ++) {
                if (mergeValues[i] == null)
                    continue;
                if (multiValues)
                    while (mergeValues[i].moreValue()) {
                        countOutput++;
                        collector.collect(mergeValues[keyIndex].getValue(), 
                                mergeValues[i].getValue());
                    }
                else if (mergeValues[i].moreValue()) {
                    countOutput ++;
                    collector.collect(mergeValues[keyIndex].getValue(), 
                            mergeValues[i].getValue());
                    return; // we need at most one pair
                } // if, for i
            }
        }
        
        public void mapEnd(ICollector collector) {
            collector.collectDoneMsg(countInput + " " + countOutput);
        }
    }
    
    private static void checkSeqFolder(Path a, PathProp pa) throws IOException {
        if (pa.getPathType() != PathProp.TYPE_FOLDER_SEQ_FILE)
            throw new IOException("The data in " + a + " should be a folder of " 
                    + "sequence files!");
    }
    private static void checkCount(Path a, PathProp pa, Path b, PathProp pb) 
            throws IOException {
        if (pa.getCount() != pb.getCount())
            throw new IOException("The number of files in " + a + " (" 
                    + pa.getCount() + ") is NOT equal to the number of files " 
                    + "in " + b + "(" + pb.getCount() + "), cannot merge!");
    }
    private static void checkKeyClass(Path a, PathProp pa, Path b, 
            PathProp pb) throws IOException {
        if (!pa.getKeyClass().equals(pb.getKeyClass()))
            throw new IOException("The key class of " + a + ", " + 
                    pa.getKeyClass() + ", is  different from the key class " 
                    + "of " + b + ", " + pb.getKeyClass() + ", cannot merge!");
    }
    private static void checkValClass(Path a, PathProp pa, Path b, 
            PathProp pb) throws IOException {
        if (!pa.getValClass().equals(pb.getValClass()))
            throw new IOException("The value class of " + a + ", " + 
                    pa.getKeyClass() + ", is  different from the value class " 
                    + "of " + b + ", " + pb.getKeyClass() + ", cannot merge!");
    }

    @SuppressWarnings("unchecked")
    public static boolean mergeLookup(ToolContext context, IFileSystem fs, 
            Path[] keyIn, Path[] valIn, Path output, int nOutParts,
            Class<? extends BasicPartitioner> partitioner, int nWorker, 
            IJobConfigurer<MapReduceJobDef> jobConfigurer) 
        throws IOException, LockStateException {
        /*
         * Get and check the classes and numbers of keyIn and valIn
         */
        PathProp keyInProp = DataUtils.checkPathProp(fs, keyIn[0]);
        checkSeqFolder(keyIn[0], keyInProp);
        if (!IWritableComparable.class.isAssignableFrom(
                keyInProp.getValClass()))
            throw new IOException("The value class of " + keyIn[0] + " " + 
                    keyInProp.getValClass() + " does not implement " +
                    "IWritableComparable!");
        PathProp valInProp = DataUtils.checkPathProp(fs, valIn[0]);
        checkSeqFolder(valIn[0], valInProp);
        
        checkKeyClass(keyIn[0], keyInProp, valIn[0], valInProp);
        checkCount(keyIn[0], keyInProp, valIn[0], valInProp);
        
        for (int i = 1; i < keyIn.length; i ++) {
            PathProp prop = DataUtils.checkPathProp(fs, keyIn[i]);
            checkSeqFolder(keyIn[i], prop);
            checkKeyClass(keyIn[i], prop, keyIn[0], keyInProp);
            checkValClass(keyIn[i], prop, keyIn[0], keyInProp);
            checkCount(keyIn[i], prop, keyIn[0], keyInProp);
        } // for i
        for (int i = 1; i < valIn.length; i ++) {
            PathProp prop = DataUtils.checkPathProp(fs, valIn[i]);
            checkSeqFolder(valIn[i], prop);
            checkKeyClass(valIn[i], prop, valIn[0], valInProp);
            checkValClass(valIn[i], prop, valIn[0], valInProp);
            checkCount(valIn[i], prop, valIn[0], valInProp);
        } // for i
        
        return mergeLookup(context, fs, keyIn, valIn, keyInProp.getCount(), 
                output, nOutParts, keyInProp.getKeyClass(), 
                keyInProp.getValClass(), valInProp.getValClass(), partitioner, 
                nWorker, jobConfigurer);
    }
    /**
     * Calls the mergeLookup with specified key-value classes. Using this 
     * method, the types are automatically determined.
     * 
     * @param context  the ToolContext instance
     * @param fs  the file-system instance
     * @param keyIn  the path to the input key-file
     * @param valIn  the path to the input val-file
     * @param output  the path to the output file
     * @param nOutParts  the number of parts of the output file
     * @param partitioner  the partitioner for outputing
     * @param nWorker  the number workers to be resolved
     * @param jobConfigurer  the configurer for the caller to add additional 
     *                       parameters to the job-def. Set this to null if no 
     *                       more configure info available.
     * @return  true if succeed; false otherwise.
     * @throws IOException  if an I/O error occurs
     * @throws LockStateException  if an lock-state error occurs
     */
    public static boolean mergeLookup(ToolContext context, IFileSystem fs, 
            Path keyIn, Path valIn, Path output, int nOutParts,
            Class<? extends BasicPartitioner> partitioner, int nWorker, 
            IJobConfigurer<MapReduceJobDef> jobConfigurer) 
        throws IOException, LockStateException {
        return mergeLookup(context, fs, new Path[]{keyIn}, new Path[]{valIn},
                output, nOutParts, partitioner, nWorker, jobConfigurer); 
    }

    /**
     * Look-up (replace) the keys of a sequence file by merging.
     * The input are two sequence files: keyIn and valIn. They share the same 
     * key-type: inKeyClass (and the same number of partitions and the same 
     * partitioner), and their values' types are: outKeyClass and outValClass 
     * respectively. The output is a sequence file newly partitionered, whose 
     * key and value's types are: outKeyClass and outValClass.
     * 
     *            ,--------------------------、
     *      <inKeyClass, outKeyClass>   <inKeyClass, outValClass>
     *                         \                        /
     *                          V                      V
     *                         <outKeyClass, outValClass>
     * 
     * @param context  the ToolContext instance
     * @param fs  the file-system instance
     * @param keyIn  the path to the input key-file
     * @param valIn  the path to the input val-file
     * @param nInParts  the number of parts of input files
     * @param output  the path to the output file
     * @param nOutParts  the number of parts of the output file
     * @param inKeyClass  the class of the key of the input files
     * @param outKeyClass  the class of the key of the output file
     * @param outValClass  the class of the value of the output file
     * @param partitioner  the partitioner for outputing
     * @param nWorker  the number workers to be resolved
     * @param jobConfigurer  the configurer for the caller to add additional 
     *                       parameters to the job-def. Set this to null if no 
     *                       more configure info available.
     * @return  true if succeed; false otherwise.
     * @throws IOException  if an I/O error occurs
     * @throws LockStateException  if an lock-state error occurs
     */
    public static boolean mergeLookup(ToolContext context, IFileSystem fs, 
            Path keyIn, Path valIn, int nInParts, Path output, int nOutParts,
            Class<? extends IWritableComparable> inKeyClass, 
            Class<? extends IWritableComparable> outKeyClass, 
            Class<? extends IWritable> outValClass,
            Class<? extends BasicPartitioner> partitioner, int nWorker, 
            IJobConfigurer<MapReduceJobDef> jobConfigurer) 
            throws IOException, LockStateException {
        return mergeLookup(context, fs, new Path[]{keyIn}, new Path[]{valIn},
                nInParts,
                output, nOutParts, inKeyClass, outKeyClass, outValClass,
                partitioner, nWorker, jobConfigurer); 
    }
    
    /**
     * Look-up (replace) the keys of a sequence file by merging.
     * The input are two sequence files: keyIn and valIn. They share the same 
     * key-type: inKeyClass (and same number-of-partitions and partitioner), and 
     * their values' types are: outKeyClass and outValClass. The output is a 
     * sequence file newly partitionered, whose key and value's types are: 
     * outKeyClass and outValClass.
     * 
     *            ,--------------------------、
     *      <inKeyClass, outKeyClass>   <inKeyClass, outValClass>
     *                         \                        /
     *                          V                      V
     *                         <outKeyClass, outValClass>
     * 
     * @param context  the ToolContext instance
     * @param fs  the file-system instance
     * @param keyIn  the paths to the input key-files. When more than one file
     *               are specified, the previous one suppress the letter one
     *               when same key exists in more than one files.
     * @param valIn  the paths to the input val-files. When more than one file
     *               are specified, the previous one suppress the letter one
     *               when same key exists in more than one files.
     * @param nInParts  the number of partitions of input files
     * @param output  the path to the output file
     * @param nOutParts  the number of parts of the output file
     * @param inKeyClass  the class of the key of the input files
     * @param outKeyClass  the class of the key of the output file
     * @param outValClass  the class of the value of the output file
     * @param partitioner  the partitioner for outputing
     * @param nWorker  the number workers to be resolved
     * @param jobConfigurer  the configurer for the caller to add additional 
     *                       parameters to the job-def. Set this to null if no 
     *                       more configuring are necessary.
     * @return  true if succeed; false otherwise.
     * @throws IOException  if an I/O error occurs
     * @throws LockStateException  if an lock-state error occurs
     */
    public static boolean mergeLookup(ToolContext context, IFileSystem fs, 
            Path[] keyIn, Path[] valIn, int nInParts, Path output, 
            int nOutParts, Class<? extends IWritableComparable> inKeyClass, 
            Class<? extends IWritableComparable> outKeyClass, 
            Class<? extends IWritable> outValClass,
            Class<? extends BasicPartitioner> partitioner, int nWorker, 
            IJobConfigurer<MapReduceJobDef> jobConfigurer) 
                throws IOException, LockStateException {
        System.out.println("Merging data " + Arrays.toString(keyIn) + " and " + 
                Arrays.toString(valIn) + " @ " + fs.getName() + " ...");
        MapReduceJobDef job = context.createMapReduceJob("merge.lookup", 
                nWorker);
        MapReduceHelper helper = new MapReduceHelper(job, fs, 
                context.tempPath(), context.path()); 
        // map (merge-map)
        MapMergeConf merge = AppCreationUtils.createMapMergeConf(
                SimpleLookupMerger.class,
                keyIn, ReuseWalker.class,
                valIn, ReuseWalker.class);
        
        job.plugin(merge);
        job.setMapNumber(nInParts);
        // reduce
        job.setMergeKeyValClass(outKeyClass, outValClass);
        job.setPartitionerClass(partitioner);
        job.setReducer(IdentityReducer.class);
        job.setReduceNumber(nOutParts);
        // config
        job.getConfig().setProperty(SimpleLookupMerger.KEY_COUNT, keyIn.length);
        
        helper.addUpdateOutputDir(0, output, outKeyClass, outValClass, null);
        
        if (jobConfigurer != null)
            jobConfigurer.configure(job);
        
        JobResult res = helper.runJob(context.getCoWork());
        if (!res.isSuccess())
            return false;
        
        System.out.println("Summary:");
        CounterUtils.showSumCounters(res.getMsg()[0], " ", "    ", 
                "Input ", CounterUtils.TP_COUNT_4,
                "Output", CounterUtils.TP_COUNT_4);
        
        System.out.println("Merged results are stored at " + output);
        
        return true;
    }
}
