package odis.app.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Logger;

import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import toolbox.misc.LogFormatter;
import toolbox.misc.channel.IObjectOutput;

/**
 * 对应于一个具体的数据目录。一个目录中包含了多个Parition。Database类中定义有这个目录的Partition方法，
 * 即：BasicPartitioner类型的成员变量。
 * 
 * @author 吴迎晖（river@rd.netease.com）
 * 
 * 修改历史：
 *   2007/6/2（庄莉）：添加javadoc说明和注释
 */
public class Database<K extends IWritableComparable, V extends IWritable> 
        implements Searchable<K, V> {
    
    private static final Logger LOG = LogFormatter.getLogger(Database.class);
    
    private IFileSystem fs;

    private Path file;

    private BasicPartitioner partitioner;

    private Partition<K, V>[] partitions = null;
    
    public Database(IFileSystem nfs, Path file) throws IOException {
        this(nfs, file, null);
    }

    public Database(IFileSystem nfs, Path file, BasicPartitioner partitioner)
            throws IOException {
        this.fs = nfs;
        this.file = file;
        if (partitioner == null) {
            this.partitioner = new SeqFileHashPartitioner();
        } else {
            this.partitioner = partitioner;
        }
    }

    /**
     * 设置这个目录的partition的办法对应的partitioner
     * @param partitioner 该目录使用的partitioner
     */
    public void setPartitioner(BasicPartitioner partitioner) {
        this.partitioner = partitioner;
    }

    /**
     * 给定key寻找对应的value
     * @param key 被寻找的key
     * @return 对应的value
     * @throws IOException
     */
    public V search(K key) throws IOException {
        synchronized (this) {
            if (partitions == null) {
                try {
                    load();
                } catch (IOException e) {
                    return null;
                }
            }
        }

        int partIndex = partitioner.getPartition(key, null, partitions.length);
        return partitions[partIndex].search(key);
    }
    
    /**
     * Search the values for a specified key
     * @param key  the target key to search
     * @param output  the IObjectOutput instance for outputting
     * @return  the number of found values
     * @throws IOException  if an I/O error occurs
     */
    public int search(K key, IObjectOutput output) throws IOException {
        synchronized (this) {
            if (partitions == null) {
                load();
            } // if
        }

        int partIndex = partitioner.getPartition(key, null, partitions.length);
        return partitions[partIndex].search(key, output);
    }

    /** 
     * @return 目录下的partition个数
     */
    public int getPartitionNumber() {
        return partitions.length;
    }

    /** 
     * @return 目录的路径
     */
    public Path getPath() {
        return file;
    }

    /**
     * 读入一个目录下各个partition的信息
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    private void load() throws IOException {
        LOG.info("Loading database " + file + " with partitioner " + partitioner.getClass().getName());

        ArrayList<String> partNames = new ArrayList<String>();
        for (FileInfo info : fs.listFiles(file)) {
            partNames.add(info.getPath().getName());
        }
        Collections.sort(partNames);
        partitions = new Partition[partNames.size()];
        for (int i = 0; i < partitions.length; i++) {
            partitions[i] = new Partition<K, V>(fs, file.cat(partNames.get(i)));
        }
    }

}
