/**
 * @(#)RandomSampleTool.java, 2008-2-4. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.IOException;
import java.rmi.server.UID;
import java.util.Random;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IndexedFileInputFormat;
import odis.mapred.lib.IndexedFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.IWritable;
import odis.serialize.lib.BytesWritable;
import odis.serialize.lib.LongWritable;
import odis.tools.MapReduceHelper;
import odis.util.ProcessUtils;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

/**
 * 这个工具能够在输入数据中随机抽取1/n的数据，并且输出抽取的结果.
 * 例如，我们要在"/home/test/data_a"数据中随机抽取1/100的数据到"/home/test/data_a_sampled"中，可以使用
 * 如下的命令:
 * <code>
 *   odis.sh dbsample -i /home/test/data_a -o /home/test/data_a_sampled -n 100
 * </code>
 * 输出的数据具有如下的特点：
 * <ul>
 *   <li>默认情况下，输出数据的part数目和输入数据相同; 也可以在参数上指定输出的partition数目.</li>
 *   <li>输出数据的key, value以及压缩属性都和输入数据一致. </li>
 *   <li>输出数据的排序被随机打乱，partition也被随机打乱</li>
 * </ul>
 * 
 * 实际进行随机抽取的方法是:
 * <ul>
 *   <li>在map过程中，使用一个随机数从顺序的输入数据中随机抽取1/n数据输出到reduce. 或者，我们可以描述输出
 *       条件为<code>rand.nextInt(n) == 0</code>. </li> map输出的时候，输出的数据以一个随机数作为
 *       key.
 *   <li>在reduce的时候，直接输出reduce得到的数据，由于map输出的时候以随机数作为key，所以reduce输出的
 *       数据的排序和partition都是随机的。
 *   </li>
 * </ul>
 *   
 * @author river
 *
 */
public class RandomSampleTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(RandomSampleTool.class);
    
    @Override
    public String comment() {
        return "Random sample on database";
    }

    @Override
    protected void prepareOptions(toolbox.misc.cli.Options options) {
        options.withOption("i", "dir", "path of database to be sampled");
        options.withOption("o", "output", "path of output");
        options.withOption("n", "number", "1/n data sampled");
        options.withOption("p", "partition", "set the output partition number, " +
        		"same as the input as default").hasDefault();
    }

    protected String inputName;
    protected String outputName;
    protected int rn;
    protected int percent;
    
    @Override
    public boolean processOptions(toolbox.misc.cli.Options options) {
        inputName = options.getStringOpt("i");
        outputName = options.getStringOpt("o");
        percent = options.getIntOpt("n");
        rn = options.getIntOpt("p", -1);
        return true;
    }

    @Override
    public boolean exec(int worker) throws Exception {
        FileSystem fs = context.getFileSystem();
        Path inputPath = context.path(inputName);
        if (!fs.exists(inputPath)) {
            throw new IOException("cannot find input dir : " + inputPath);
        }
        
        FileInfo [] childs = fs.listFiles(inputPath);
        boolean isIndexedFile = (fs.isDirectory(childs[0].getPath()));
        Class keyClass, valClass;
        int compressBlockSize = 0;
        SequenceFile.Reader reader;
        if (isIndexedFile)
            reader = new SequenceFile.Reader(fs, childs[0].getPath().cat(IndexedFile.DATA_FILE_NAME));
        else
            reader = new SequenceFile.Reader(fs, childs[0].getPath());
        try {
            compressBlockSize = reader.getCompressBlockSize();
            keyClass = reader.getKeyClass();
            valClass = reader.getValueClass();
        } finally {
            reader.close();
        }
        
        MapReduceJobDef job = context.createMapReduceJob(this.getToolName(), worker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        job.addInputDir(helper.getReadInput(inputPath), 
                isIndexedFile ? IndexedFileInputFormat.class : SeqFileInputFormat.class);
        job.setMapper(RandomOutputMapper.class);
        job.setMapNumber(worker * mParallel);
        job.setMergeKeyValClass(LongWritable.class, BytesWritable.class);
        job.useDefaultHashPartitioner();
        
        job.setReducer(Reducer.class);
        if (rn < 0) {
            job.setReduceNumber(MapReduceHelper.getContinuousPartCount(fs, inputPath));
        } else {
            job.setReduceNumber(rn);
        }
        job.setWalkerClass(ReuseWalker.class);
        
        Path dstPath = context.path(outputName);
        job.addOutputDir(0, helper.getUpdateOutput(dstPath), keyClass, valClass, 
                isIndexedFile ? IndexedFileOutputFormat.class : SeqFileOutputFormat.class);
        if (compressBlockSize > 0) {
            GenericFileOutputFormat.setCompress(job, 0, compressBlockSize);
        }
        job.getConfig().setProperty(Reducer.NAME_KEY_CLASS, keyClass.getName());
        job.getConfig().setProperty(Reducer.NAME_VAL_CLASS, valClass.getName());
        job.getConfig().setInt(RandomOutputMapper.NAME_PERCENT, percent);
        
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printCounters(out, result.getCounters());
        
        return true;
    }

    /**
     * Mapper
     * @author river
     *
     */
    public static class RandomOutputMapper extends AbstractMapper<IWritable, IWritable> {
        public static final String NAME_PERCENT = RandomOutputMapper.class.getName() + ".percent";
        private Random rand;
        private DataOutputBuffer buffer = new DataOutputBuffer();
        private BytesWritable blob = new BytesWritable();
        
        private final LongWritable randomKey = new LongWritable();

        private int n;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            rand = new Random(System.currentTimeMillis() + 
                    ProcessUtils.getPid() + new UID().hashCode() );
            n = job.getConfig().getInt(NAME_PERCENT, -1);
            if (n <= 0) {
                throw new TaskFatalException("cannot find percent config");
            }
        }

        public void map(IWritable key, IWritable value, ICollector collector) {
            if (rand.nextInt(n) != 0) {
                return;
            }
            
            randomKey.set(rand.nextLong());
            try {
                buffer.reset();
                key.writeFields(buffer);
                value.writeFields(buffer);
            } catch (IOException e) {
                throw new TaskFatalException("cannot write data to buffer", e);
            }
            blob.setBuffer(buffer.getData(), buffer.size());
            collector.collect(randomKey, blob);
        }
    }
    
    /**
     * reducer
     * @author river
     *
     */
    public static class Reducer extends AbstractReducer<LongWritable, BytesWritable> {
        public static final String NAME_KEY_CLASS = Reducer.class.getName() + ".key-class";
        public static final String NAME_VAL_CLASS = Reducer.class.getName() + ".val-class";
        
        private IWritable k;
        private IWritable v;
        private DataInputBuffer buffer = new DataInputBuffer();
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            String keyClassname = job.getConfig().getString(NAME_KEY_CLASS);
            String valClassname = job.getConfig().getString(NAME_VAL_CLASS);
            if (keyClassname == null || valClassname == null) {
                throw new TaskFatalException("cannot find key class or val class in config");
            }
            try {
                k = (IWritable) ClassUtils.newInstance(Class.forName(keyClassname));
                v = (IWritable) ClassUtils.newInstance(Class.forName(valClassname));
            } catch (Exception e) {
                throw new TaskFatalException("initialize key or value failed", e);
            }
        }

        public void reduce(LongWritable key,
                IWritablePairWalker<LongWritable, BytesWritable> values,
                ICollector collector) {
            
            while (values.moreValue()) {
                try {
                    BytesWritable bytes = values.getValue();
                    buffer.reset(bytes.getBytes(), bytes.getByteLength());
                    k.readFields(buffer);
                    v.readFields(buffer);
                } catch(IOException e) {
                    throw new TaskFatalException("cannot read data from buffer", e);
                }
                collector.collectToChannel(0, k, v);
            }
        }
        
    }
    
}
