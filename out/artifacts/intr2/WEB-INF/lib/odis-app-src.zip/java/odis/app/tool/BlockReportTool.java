/**
 * @(#)BlockReportTool.java, 2008-11-3. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import odis.tools.AbstractLocalTool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.text.util.HexString;

/**
 * This tool calculate the block checksum on datanode and print the 
 * report to stdout.
 * 
 * This tool is called by {@link FileBlockCheckTool} through gexec.
 *  
 * @author river
 *
 */
public class BlockReportTool extends AbstractLocalTool {
    private static final String ODFS_PATH = "/odfs/datanode";
    
    private Options opts;
    
    public BlockReportTool() {
        opts = new Options();
        opts.withOption("b", "block", "the name of block").setType(Options.TYPE_NUMBER);
        opts.withOption("d", "datanode", "the name of datanode").hasDefault();
    }
    
    public String comment() {
        return "Calc block-checkum and report";
    }

    public void usage(PrintWriter out) {
        opts.printHelpInfo(out, "blockreport");
    }

    /**
     * Calc the checksum for one file if exist, or return null if not.
     * @param file
     * @return
     * @throws IOException
     */
    private BlockReport probeFile(File file) throws IOException {
        // check if the file exist
        if (!file.exists()) return null;
        
        long size = file.length();
        
        // read the file and calc the checksum
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
        } catch(NoSuchAlgorithmException e) {
            throw new IOException("no md5 algorithm found in jvm");
        }
        FileInputStream fis = new FileInputStream(file);
        try {
            byte [] buf = new byte[4096];
            int len;
            while ((len = fis.read(buf)) > 0) {
                digest.update(buf, 0, len);
            }
        } finally {
            fis.close();
        }
        byte [] d = digest.digest();
        String md5 = HexString.bytesToHexNoSpace(d);
        
        return new BlockReport(size, md5);
    }
    
    public boolean exec(String[] args) throws Exception {
        try {
            opts.parse(args);
        } catch(OptionParseException e) {
            out.println("error: " + e.getMessage());
            usage(out);
            return false;
        }
        
        long blockId = opts.getLongOpt("b");

        boolean found = false;
        String filePath = ODFS_PATH + "/" + getBlockPrefix(blockId) + "/" + getBlockFileName(blockId);
        int diskSeq = 1;
        while (true) {
            File disk = new File("/disk" + diskSeq );
            if (!disk.exists()) break;
            BlockReport report = probeFile(new File(disk, filePath));
            if (report != null) {
                out.println(report);
                found = true;
                break;
            }
            diskSeq ++;
        }
        
        if (!found) {
            out.println("[" + opts.getStringOpt("d") + 
                    "] error: cannot find given block at " + diskSeq + 
                    " disks : filepath=" + filePath);
        }
        return found;
    }

    /**
     * Return the prefix(dir) of given block.
     * (Copy from odfs code)
     * @param id
     * @return
     */
    public static String getBlockPrefix(long id) {
        String r = "0"+Long.toHexString((id >> 56) & 0xffL);
        return r.substring(r.length()-2);
    }

    /**
     * Return the filename of given block.
     * (Copy from odfs code)
     * @param blkid
     * @return
     */
    public static String getBlockFileName(long blkid) {
        String r = "000000000000000" + Long.toHexString(blkid);
        return r.substring(r.length() - 16) + ".blk";
    }
    
    /**
     * Data structure to hold block size and md5 checksum.
     * @author river
     */
    public static class BlockReport {
        private long blockSize;
        private String md5;
        
        public BlockReport(long blockSize, String md5) {
            this.blockSize = blockSize;
            this.md5 = md5;
        }
        
        @Override
        public boolean equals(Object o) {
            if (o == null || !(o instanceof BlockReport)) return false;
            BlockReport that = (BlockReport) o;
            return this.blockSize == that.blockSize && this.md5.equals(that.md5);
        }
        
        @Override
        public String toString() {
            return "size:" + blockSize + ",md5:" + md5;  
        }
        
        private static Pattern PATTERN = Pattern.compile("size:([\\-\\d]+),md5:([\\w\\d]+)");
        public static BlockReport parse(String line) {
            Matcher matcher = PATTERN.matcher(line);
            if (!matcher.find()) return null;
            
            return new BlockReport(Long.parseLong(matcher.group(1)), matcher.group(2));
        }
        
    }
    
}
