package odis.app.data;

import java.io.DataInput;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.LongBinaryComparator;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.MD5Writable;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * SiteID a long that represents id of each host (url)
 * 
 * Change Log:
 *   - 1/25/2007 (Li Zhuang) Cleanup API and add Javadoc
 * 
 * @author river
 */

public class SiteID extends LongWritable {
    private static final Logger LOG = LogFormatter.getLogger(SiteID.class);
    public static final int BYTES = Long.SIZE / Byte.SIZE;
    static {
        WritableRegistry.register(SiteID.class, "SiteID", BYTES, 
                LongBinaryComparator.class);
    }

    public static final SiteID NULL_SITEID = new SiteID(0);

    /**
     * Default constructor
     */
    public SiteID() { this.value = Long.MAX_VALUE; }

    /**
     * Create SiteID from long
     * @param id  The long format of the id
     */
    public SiteID(long id) { super(id); }

    /**
     * Create SiteID from another SiteID
     * @param sid  Another SiteID
     */
    public SiteID(SiteID sid) { set(sid); }

    /**
     * Create SiteID from host name
     * @param host  The host name
     */
    public SiteID(String host) { set(host); }

    /**
     * Create SiteID from URL -- will extract host from URL first
     * @param url  The URL
     */
    public SiteID(URL url) {
        this.value = MD5Writable.digest(url.getHost()).halfDigest();
    }
    
    /**
     * Set value of this SiteID given the host name (thread-safe)
     * @param host  The host name
     */
    public void set(String host) {
        this.value = MD5Writable.digest(host).halfDigest();
    }
    
    /**
     * Set value of this SiteID from another SiteId (thread-safe)
     * @param siteId
     */
    public void set(SiteID siteId) {
        this.value = siteId.value;
    }
    
    public boolean isZero() { return this.value==0L; }

    public String toString() {
        return HexString.longToPaddedHex(this.value).toUpperCase();
    }

    /**
     * Set value of this SiteID from hex string
     * @param hexString  The hex string
     */
    public void parse(String hexString) throws ParseException {
        try {
            this.value = HexString.paddedHexToLong(hexString);
        } catch (NumberFormatException e) {
            LOG.log(Level.WARNING, "Not a padded hex string", e);
            throw new ParseException(SiteID.class, hexString);
        }
    }

    /**
     * Skip length of a SiteID from data input
     * @param in  The DataInput
     * @throws IOException
     */
    public static void skip(DataInput in) throws IOException {
        in.skipBytes(BYTES);
    }

    /**
     * Directly create a siteid. 
     * @param host hostname of url. It MUST be normalized.
     * @return A new instance of SiteID
     */
    public static SiteID getSiteID(String host) {
        return new SiteID(host);
    }

    /**
     * Parse and create a SiteID from hex String
     * @param hexString  The hex string
     * @return A new instance of SiteID
     * @throws ParseException
     */
    public static SiteID parseSiteID(String hexString) throws ParseException {
        SiteID id = new SiteID();
        id.parse(hexString);
        return id;
    }

    public static void main(String args[]) throws Exception {
        if (args.length == 0) {
            System.out.println("params: hostname");
            return;
        }
        SiteID id = new SiteID(args[0]);
        System.out.println(id);
    }

}
