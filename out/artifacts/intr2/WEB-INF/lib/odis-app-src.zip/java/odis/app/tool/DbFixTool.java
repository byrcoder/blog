/**
 * @(#)DbFixTool.java, 2008-11-25. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.IOException;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.app.tool.SeqFileFixTool.Fixer;
import odis.app.tool.SeqFileFixTool.ProgressAndCursorListener;
import odis.cowork.CoWorkUtils;
import odis.cowork.CounterMap.Counter;
import odis.cowork.GenericJobDef;
import odis.cowork.JobClient;
import odis.cowork.JobConfig;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.dfs.common.DFSClientConfig;
import odis.io.FileSystem;
import odis.io.Path;
import odis.tools.MapReduceHelper;
import odis.tools.ToDelete;
import odis.tools.misc.SeqFileFixTool;
import toolbox.misc.cli.Options;

/**
 * Fix all the partitions in one db by invoking {@link SeqFileFixTool} in odis.
 * 
 * @author river
 */
public class DbFixTool extends AbstractCoWorkToolWithArg {

    @Override
    public String comment() {
        return "Fix all the partitions of db";
    }

    @Override
    protected void prepareOptions(Options options) {
        super.prepareOptions(options);

        options.withOption("i", "input", "set the db path to be repaired");
        options.withOption("o", "output", "set the output path");
        options.withOption("fs", "filesystem",
                "set the input/output filesystem").hasDefault();

        options.withOption("s", "whether to sync always, default to false");
        options.withOption("d", "search_distance(M)", "set the search distance").setDefault(
                5).setType(Options.TYPE_NUMBER);
        options.withOption("r", "block_retries", "block finding retries").setType(
                Options.TYPE_NUMBER).setDefault(
                DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME_DEFAULT_VALUE);
    }

    @Override
    public boolean exec(int worker) throws Exception {
        String fsName = options.getStringOpt("fs");
        FileSystem fs = context.getFileSystem();
        if (fsName != null) {
            fs = FileSystem.getNamed(fsName);
        }

        Path inputDb = context.path(options.getStringOpt("i"));
        int inputDbPartition = fs.listFiles(inputDb).length;
        if (inputDbPartition == 0) {
            return false;
        }

        Path outputDb = context.path(options.getStringOpt("o"));
        Path outputTempDb = new Path(outputDb.getAbsolutePath() + ".fixing");
        if (fs.exists(outputTempDb)) {
            fs.delete(outputTempDb);
        }
        ToDelete.toDelete(fs, outputTempDb);

        GenericJobDef job = context.createGenericJob(this.getToolName(), worker);
        job.setTaskClass(FixTask.class);
        job.setTaskNumber(inputDbPartition);
        job.setMaxBackupNum(0);

        job.getConfig().setProperty(FixTask.NAME_FS, fs.getName());
        job.getConfig().setProperty(FixTask.NAME_INPUT,
                inputDb.getAbsolutePath());
        job.getConfig().setProperty(FixTask.NAME_OUTPUT,
                outputTempDb.getAbsolutePath());
        job.getConfig().setProperty(FixTask.NAME_SEARCH_DISTANCE,
                options.getLongOpt("d"));
        job.getConfig().setProperty(FixTask.NAME_SYNC_ALWAYS,
                options.isOptSet("s"));
        job.getConfig().setProperty(FixTask.NAME_BLOCK_FINDING_RETRIES,
                options.getIntOpt("r"));

        JobResult result = JobClient.runJob(context.getCoWork(), job);
        if (!result.isSuccess())
            return false;

        MapReduceHelper.printMessages(out, this.getToolName(), result.getMsg());
        MapReduceHelper.printCounters(out, this.getToolName(),
                result.getCounters());

        MapReduceHelper.replace(fs, outputDb, outputTempDb);

        return true;
    }

    public static class FixTask extends TaskRunnable implements
            ProgressAndCursorListener {
        private static final String PREFIX = FixTask.class.getName();

        public static final String NAME_FS = PREFIX + ".fs";

        public static final String NAME_INPUT = PREFIX + ".input";

        public static final String NAME_OUTPUT = PREFIX + ".output";

        public static final String NAME_SYNC_ALWAYS = PREFIX + ".sync_always";

        public static final String NAME_SEARCH_DISTANCE = PREFIX
                + ".search_distance";

        public static final String NAME_BLOCK_FINDING_RETRIES = PREFIX
                + ".block_finding_retries";

        private long c;

        private Counter savedObjectsCounter;

        private Counter ignoredObjectsCounter;

        private Counter blockSkipCounter;

        @Override
        protected long cursor() {
            return c;
        }

        public void setCursor(long c) {
            this.c = c;
        }

        public void setProgress(double p) {
            this.progress = (float) p;
            savedObjectsCounter.set(fixer.getCount());
            ignoredObjectsCounter.set(fixer.getBadObjectIgnored());
            blockSkipCounter.set(fixer.getBlockSkips());
        }

        private Fixer fixer;

        @Override
        public void configure(JobDef job, TaskWorker runner) {

            JobConfig conf = job.getConfig();
            String fsName = conf.getString(NAME_FS);
            FileSystem fs;
            try {
                fs = FileSystem.getNamed(fsName);
            } catch (IOException e) {
                throw new TaskFatalException(
                        "cannot open filesystem " + fsName, e);
            }

            int partId = this.getPartIdx();
            Path inputDb = new Path(conf.getString(NAME_INPUT));
            Path outputDb = new Path(conf.getString(NAME_OUTPUT));
            fixer = new Fixer(fs, inputDb.cat(CoWorkUtils.getPartID(partId)),
                    outputDb.cat(CoWorkUtils.getPartID(partId)));
            fixer.setSyncAlways(conf.getBoolean(NAME_SYNC_ALWAYS));
            fixer.setSearchDistance(conf.getLong(NAME_SEARCH_DISTANCE));
            fixer.setBlockFindingRetries(conf.getInt(NAME_BLOCK_FINDING_RETRIES));

            savedObjectsCounter = this.getCounter("savedObjects");
            ignoredObjectsCounter = this.getCounter("ignoredObjects");
            blockSkipCounter = this.getCounter("blockSkips");

            fixer.setProgressAndCursorListener(this);
        }

        @Override
        public void run() {
            try {
                fixer.fix();
            } catch (IOException e) {
                throw new TaskFatalException("fix partition "
                        + this.getPartIdx() + " failed", e);
            }

            setProgress(1);
            this.doneMsg = "part " + CoWorkUtils.getPartID(this.getPartIdx())
                    + " " + (fixer.isErrorFound() ? "FIXED" : "PASSED");
        }

    }

}
