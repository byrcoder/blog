package odis.app.job.demo;

import java.util.Arrays;

import odis.app.job.CoWorkTool;

import org.apache.commons.cli.Options;

public class DemoCoworkTool extends CoWorkTool {
    public static final String TOOL_NAME = "cli-demo";

    @Override
    protected void appendOptions(Options opts) {
        addOption("i", 1, "The input file");
        addOption("o", 1, "The output file. The description of this " +
                        "option could be very long.");
        addRequiredOption("r", 1, "A required option.");
    }

    @Override
    protected boolean exec() throws Exception {
        if (args.hasOption("i")) {
            out.println("-i parameter is specified: " 
                    + args.getOptionValue("i"));
        } // if
        if (args.hasOption("o")) {
            out.println("-o parameter is specified: " 
                    + args.getOptionValue("o"));
        } // if
        
        out.println("All options: " + Arrays.toString(args.getOptions()));
        out.println("Left args: " + Arrays.toString(args.getArgs()));
        return true;
    }

    @Override
    public String comment() {
        return "A demo showing the use of cli";
    }

}
