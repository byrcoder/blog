package odis.app.view;

import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

/**
 * 定义一个可用于search（如：二分查找）的数据对象（即：(key,value)的存储）
 *  
 * 修改历史：
 *   2007/6/2（庄莉）：添加javadoc说明和注释
 */
public interface Searchable<K extends IWritableComparable, V extends IWritable> {

    /**
     * 根据给定的key返回对应的value
     * @param key 用于查找的key
     * @return 对应的value
     * @throws IOException
     */
    public V search(K key) throws IOException;
}
