package odis.app.tool;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.app.job.AbstractLocalToolWithArg;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.DFSClientConfig;
import odis.file.IRecordWriter;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.BadObjectException;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.toolkit.LazyWritable;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.misc.cli.Options;

/**
 * Fix the sequence file when block lost.
 * <ul>
 * <li>If the record is broken(cannot be uncompressed, for example), then the
 * record is simply ignored.
 * <li>If the data is broken, so the record cannot be read out, then we skip to
 * the next sync.
 * </ul>
 * 
 * @author river
 */
public class SeqFileFixTool extends AbstractLocalToolWithArg {
    private static final Logger LOG = LogFormatter.getLogger(SeqFileFixTool.class);

    public static interface ProgressAndCursorListener {
        public void setProgress(double p);

        public void setCursor(long c);
    }

    public static class Fixer {
        public static final long DEFAULT_SEARCH_DISTANCE = 5 * 1024 * 1024;

        private IFileSystem fs;

        private Path file;

        private Path fixedFile;

        private boolean isIndexedFile;

        private boolean syncAlways;

        private long searchDistance = DEFAULT_SEARCH_DISTANCE;

        private boolean errorFound = false;

        private long count = 0;

        private double progress = 0;

        private long badObjectIgnored = 0;

        private long blockSkips = 0;

        private ArrayList<Long> skipOffsets = new ArrayList<Long>();

        private long nextSkipOffset = -1;

        private ProgressAndCursorListener listener = null;

        public Fixer(IFileSystem fs, Path file, Path output) {
            this.fs = fs;
            this.file = file;
            this.fixedFile = output;
            if (fs instanceof DistributedFileSystem) {
                ((DistributedFileSystem) fs).getConf().setProperty(
                        DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME, 4);
            }
            syncAlways = false;
        }

        public void setSyncAlways(boolean value) {
            syncAlways = value;
        }

        public void setSearchDistance(long value) {
            this.searchDistance = value;
        }

        public void setBlockFindingRetries(int retries) {
            if (fs instanceof DistributedFileSystem) {
                ((DistributedFileSystem) fs).getConf().setProperty(
                        DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME, retries);
            }
        }

        public void addSkipOffsets(long offset) {
            skipOffsets.add(offset);
            Collections.sort(skipOffsets);
            if (nextSkipOffset < 0) {
                nextSkipOffset = skipOffsets.remove(0);
            }
        }

        public void setProgressAndCursorListener(
                ProgressAndCursorListener listener) {
            this.listener = listener;
        }

        private boolean skipBadBlock(SequenceFile.Reader reader, long fromPos,
                long length) {
            long pos = fromPos;
            if (pos >= length) {
                LOG.log(Level.INFO, "remove the last part of data.");
                return false;
            }

            while (pos < length) {
                try {
                    reader.sync(pos);
                    LOG.log(Level.INFO, "recovered at pos " + reader.getPos());
                    blockSkips++;
                    return true;
                } catch (Throwable ex) {}
                pos += searchDistance;
            }
            return false;
        }

        /**
         * Return if any error found in the input file.
         * 
         * @return
         */
        public boolean isErrorFound() {
            return errorFound;
        }

        /**
         * Progress of file-fix.
         * 
         * @return
         */
        public double getProgress() {
            return progress;
        }

        /**
         * The count of objects currently saved.
         * 
         * @return
         */
        public long getCount() {
            return count;
        }

        /**
         * Return the count of bad objects ignored.
         * 
         * @return
         */
        public long getBadObjectIgnored() {
            return badObjectIgnored;
        }

        /**
         * Return the count of block skip calls, not the count of blocks
         * skipped.
         * 
         * @return
         */
        public long getBlockSkips() {
            return blockSkips;
        }

        @SuppressWarnings("unchecked")
        public void fix() throws IOException {
            if (fixedFile.equals(file)) {
                throw new IOException(
                        "source file and fixed file should not be the same");
            }
            isIndexedFile = fs.isDirectory(file);
            if (isIndexedFile)
                LOG.info("source file is indexed file");
            Path dataFile = isIndexedFile ? file.cat("data") : file;

            SequenceFile.Reader reader = new SequenceFile.Reader(fs, dataFile);
            long length = fs.getLength(dataFile);
            int compressBlockSize = reader.getCompressBlockSize();
            IRecordWriter writer;
            if (isIndexedFile) {
                if (compressBlockSize > 0) {
                    writer = new IndexedFile.CompressedWriter(fs, fixedFile,
                            reader.getKeyClass(), reader.getValueClass(), true,
                            compressBlockSize);
                } else {
                    writer = new IndexedFile.Writer(fs, fixedFile,
                            reader.getKeyClass(), reader.getValueClass());
                }
            } else {
                if (compressBlockSize > 0) {
                    writer = new SequenceFile.CompressedWriter(fs, fixedFile,
                            reader.getKeyClass(), reader.getValueClass(), true,
                            compressBlockSize, false);
                } else {
                    writer = new SequenceFile.Writer(fs, fixedFile,
                            reader.getKeyClass(), reader.getValueClass());
                }
            }

            try {
                Object key = ClassUtils.newInstance(reader.getKeyClass());
                Object value = ClassUtils.newInstance(reader.getValueClass());

                while (true) {
                    long lastPos = reader.getPos();
                    double percent = (lastPos * 1000 / length) / 1000.0;
                    if (percent > progress) {
                        System.out.println(new Date() + " " + (percent * 100)
                                + "% [" + lastPos + "/" + length + "]");
                        progress = percent;
                        if (this.listener != null) {
                            listener.setProgress(progress);
                        }
                    }

                    try {
                        if (nextSkipOffset >= 0 && lastPos >= nextSkipOffset) {
                            nextSkipOffset = -1;
                            if (!skipOffsets.isEmpty())
                                nextSkipOffset = skipOffsets.remove(0);
                            LOG.log(Level.WARNING, "force skip at offset "
                                    + lastPos + " with distance "
                                    + searchDistance + ".");
                            if (!skipBadBlock(reader, lastPos + searchDistance,
                                    length)) {
                                LOG.log(Level.SEVERE, "skip failed.");
                                break;
                            }
                        }

                        if (!reader.next(key, value))
                            break;
                        try {
                            if (value instanceof LazyWritable) {
                                // make sure the compressed data is ok
                                ((LazyWritable) value).decode();
                            }
                        } catch (Exception e) {
                            throw new BadObjectException(
                                    "decode object failed", e);
                        }

                        writer.write(key, value);
                        count++;
                        if (this.listener != null) {
                            listener.setCursor(count);
                        }
                    } catch (BadObjectException e) {
                        errorFound = true;
                        LOG.log(Level.WARNING, "bad object found at pos "
                                + lastPos + ", skip.", e);
                        if (reader.getPos() > lastPos && !syncAlways) {
                            badObjectIgnored++;
                            continue;
                        } else {
                            if (!skipBadBlock(reader, lastPos, length)) {
                                break;
                            }
                        }
                    } catch (Throwable e) {
                        errorFound = true;
                        LOG.log(Level.WARNING, "read failed at pos " + lastPos
                                + ", try to recover.", e);
                        if (reader.getPos() > lastPos) {
                            try {
                                LOG.log(Level.INFO, "try sync first");
                                reader.sync(reader.getPos());
                            } catch (Throwable ex) {
                                LOG.log(Level.INFO,
                                        "sync failed, try to skip the bad block");
                                if (!skipBadBlock(reader, lastPos, length)) {
                                    break;
                                }
                            }
                        } else {
                            if (!skipBadBlock(reader, lastPos, length)) {
                                break;
                            }
                        }
                    }
                }
                reader.close();
            } finally {
                writer.close();
            }
        }

    }

    public String comment() {
        return "Fix sequence file at the time of ODFS block lost";
    }

    @Override
    protected void prepareOptions(Options options) {
        super.prepareOptions(options);
        options.withOption("fs", "filesystem", "set the filesystem of db").hasDefault();
        options.withOption("f", "file", "set file to fix");
        options.withOption("o", "output", "set output file path");
        options.withOption("s", "whether to sync always, default to false");
        options.withOption("d", "search_distance(M)", "set the search distance").setDefault(
                5).setType(Options.TYPE_NUMBER);
        options.withOption("r", "block_retries", "block finding retries").setType(
                Options.TYPE_NUMBER).setDefault(
                DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME_DEFAULT_VALUE);
        options.withOption("skip", "skip_offset", "force skip at offset").setType(
                Options.TYPE_NUMBER).hasDefault();
    }

    @Override
    public boolean exec() throws Exception {
        String fsName = options.getStringOpt("fs");
        FileSystem fs = context.getFileSystem();
        if (fsName != null) {
            fs = FileSystem.getNamed(fsName);
        }

        String filename = options.getStringOpt("f");
        String fixedName = options.getStringOpt("o");
        if (filename.equals(fixedName)) {
            out.println("error: the output should not be the same as input");
            return false;
        }
        boolean syncAlways = options.isOptSet("s");

        Fixer fixer = new Fixer(fs, new Path(filename), new Path(fixedName));
        fixer.setSyncAlways(syncAlways);
        fixer.setSearchDistance(options.getIntOpt("d") * UnitUtils.M);
        fixer.setBlockFindingRetries(options.getIntOpt("r"));

        if (options.isOptSet("skip")) {
            for (String s: options.getOpt("skip")) {
                fixer.addSkipOffsets(Long.parseLong(s));
            }
        }

        out.println(new Date() + " Start to fix ...");
        try {
            fixer.fix();
        } catch (IOException e) {
            out.println(new Date() + " Failed to fix.");
            e.printStackTrace(out);
            return false;
        }
        out.println(new Date() + " Fixed.");
        return true;
    }
}
