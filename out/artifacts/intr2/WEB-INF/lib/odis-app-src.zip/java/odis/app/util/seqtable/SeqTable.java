package odis.app.util.seqtable;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import odis.file.SequenceFile;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.tools.LocalToolContext;
import odis.tools.MapReduceHelper;

/**
 * 该类用于将一个SequenceFile当成一个table来操作。
 * 
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Apr 16, 2007
 */
public class SeqTable<K extends IWritableComparable, V extends IWritable> 
        implements ITable<K, V> {

    private LocalToolContext env;
    
    private Path path;
    
    private List<Pair<K,V>> records = new ArrayList<Pair<K,V>>();

    private Class<?> kClass;

    private Class<?> vClass;

    /**
     * 读入一个路径为Path的SequenceFile
     * 
     * @param env  the tool context
     * @param path  the path of sequence file
     * @throws Exception
     */
    public SeqTable(LocalToolContext env, Path path) throws Exception {
        this.env = env;
        this.path = path;
        load(Long.MAX_VALUE);
    }
    
    /**
     * 读入一个路径为Path的SequenceFile，并且最多读limit个。
     * 
     * @param env  the tool context
     * @param path  the path of sequence file
     * @param limit  record number limit
     * @throws Exception
     */
    public SeqTable(LocalToolContext env, Path path, long limit) throws Exception {
        this.env = env;
        this.path = path;
        load(limit);
    }
    
    /**
     * 返回KEY为key的所有的VALUE，包括重复的。
     */
    public List<V> selectValues(K key) {
        List<V> list = new ArrayList<V>();
        for(Pair<K,V> p : records) {
            if(p.getKey().equals(key))
                list.add(p.getValue());
        }
        return list;
    }
    
    /**
     * 返回第一个KEY为key的VALUE。
     */
    public V selectValue(K key) {
        for(Pair<K,V> p : records) {
            if(p.getKey().equals(key))
                return p.getValue();
        }
        return null;
    }
    
    /**
     * 将KEY为key的所有的VALUE的都赋值为value。
     */
    public void updateValue(K key, V value) {
        updateValue(key, value, 0, Integer.MAX_VALUE);
    }
    
    /**
     * 从第start个开始（包括），到第end个结束（不包括），将KEY为key的所有的VALUE的都赋值为value。
     */
    public void updateValue(K key, V value, int start, int end) {
        if(start >= end)
            return;
        int i = 0;
        for(Pair<K,V> p : records) {
            if(p.getKey().equals(key)) {
                if(i<start)
                    continue;
                if(i>=end)
                    return;
                p.getValue().copyFields(value);
                i++;
            }
        }
    }
    
    
    public void insert(K key, V value, int idx) {
        Pair<K,V> pair = new Pair<K,V>();
        pair.setKey(key);
        pair.setValue(value);
        records.add(idx, pair);
    }
    
    public List<V>  delete(K key) {
        List<V> list = new ArrayList<V>();
        Iterator<Pair<K,V>> itor = records.iterator();
        while(itor.hasNext()) {
            Pair<K,V> p = itor.next();
            if(p.getKey().equals(key)) {
                list.add(p.getValue());
                itor.remove();
            }
        }
        return list;
    }
    
    public void commit() throws IOException {
        commit(kClass, vClass);
    }
    
    public void commit(Class<?> kClass, Class<?> vClass) throws IOException {
        Path swp = env.tempPath(".swp" + System.currentTimeMillis());
        SequenceFile.Writer w = new SequenceFile.Writer(env.getFileSystem(),
                swp, kClass, vClass);
        for(Pair<K,V> pair : records) {
            w.write(pair.getKey(), pair.getValue());
        }
        w.close();
        
        MapReduceHelper.replace(env.getFileSystem(), path, swp);
        
        env.getFileSystem().delete(swp);
    }
    
    public int size() {
        return records.size();
    }

    public void updateValue(K key, V value, int idx) {
        updateValue(key, value, idx, idx+1);
    }
    
    public boolean isKeyUnique() {
        Set<K> set = new HashSet<K>();
        for(Pair<K,V> p : records) {
            if(set.contains(p.getKey()))
                return false;
            set.add(p.getKey());
        }
        return true;
    }
    
    public Pair<K,V> getPair(int idx) {
        if(idx >= records.size())
            return null;
        return records.get(idx);
    }
    
    Set<K> getKeySet() {
        Set<K> set = new HashSet<K>();
        for(Pair<K,V> p : records) {
            set.add(p.getKey());
        }
        return set;
    }

    @SuppressWarnings("unchecked")
    protected void load(long limit) throws Exception {
        try {
            SequenceFile.Reader r = 
                new SequenceFile.Reader(env.getFileSystem(), path);
            
            kClass = r.getKeyClass();
            vClass = r.getValueClass();
            K k = (K)kClass.newInstance();
            V v = (V)vClass.newInstance();
            
            records.clear();
            while(r.next(k, v)) {
                Pair<K, V> pair = new Pair<K,V>();
                pair.setKey(k);
                pair.setValue(v);
                records.add(pair);
                limit--;
                if(limit <= 0)
                    break;
                
                k = (K)r.getKeyClass().newInstance();
                v = (V)r.getValueClass().newInstance();
            }
            r.close();
        } catch (FileNotFoundException e) {
            
        }
    }
    

}
