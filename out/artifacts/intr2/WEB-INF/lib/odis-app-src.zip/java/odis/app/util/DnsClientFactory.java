package odis.app.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.tools.ToolContext;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;

import toolbox.misc.LogFormatter;
import toolbox.misc.net.DnsClient;

/**
 * 利用如下的配置数据构造 {@link DnsClient} 的实例:
 * <ul>
 * <li>commons.dns.servers : 服务器列表，可以是","隔开的字符串</li>
 * <li>commons.dns.initial_timeout : dns请求的初始timeout</li>
 * <li>commons.dns.retries : dns请求的重试次数</li>
 * </ul>
 * 
 * @see DnsClient
 * 
 * @author 吴迎晖 (river@rd.netease.com)
 */

public class DnsClientFactory {
    public static final Logger LOG = LogFormatter.getLogger(DnsClientFactory.class);
    
    private static final String NAME_DNS_SERVERS = "commons.dns.servers";
    private static final String NAME_DNS_RETRIES = "commons.dns.retries";
//    private static final String NAME_DNS_INITIAL_TIMEOUT = "commons.dns.initial_timeout";
    private static final String NAME_DNS_INITIAL_TIMEOUT = "commons.dns.initial_timeout";
  
    private static DnsClient defaultClient = null;
    private static ConfigurationException defaultClientError = null;
    static {
        try {
            defaultClient = createDnsClient(ToolContext.getConfig(), true);
        } catch(ConfigurationException e) {
            defaultClientError = e;
        }
    }

    /**
     * 根据给定的配置创建 {@link DnsClient}的实例. 如果配置中没有指定 "commons.dns.servers"，
     * 那么，会使用操作系统配置的dns 服务器列表.
     * 
     * @param config
     * @param allowSystemConfig 是否允许在配置中没有dns服务器的情况下使用操作系统的配置
     * @return
     */
    public static DnsClient createDnsClient(Configuration config, 
            boolean allowSystemConfig) throws ConfigurationException {
        // 从配置中读取DNS Server地址列表
        List<String> serverList = new ArrayList<String>();
        String [] servers = config.getStringArray(NAME_DNS_SERVERS);
        for (String s : servers) {
            s = s.trim();
            if (s.length() > 0) {
                serverList.add(s);
            }
        }
        
        // 读取配置中的Client连接参数：timeout时间长度和retry次数
        long initialTimeout = config.getLong(NAME_DNS_INITIAL_TIMEOUT, -1);
        int retries = config.getInt(NAME_DNS_RETRIES, -1);
        // 配置中找不到DNS Server地址列表时，使用操作系统配置的默认列表
        if (serverList.size() == 0 && allowSystemConfig) {
            LOG.warning("cannot find dns setting in outfox conf, use system setting instead");
            DnsClient.loadSystemSetting(serverList);
        }
        if (serverList.size() == 0) {
            throw new ConfigurationException("no dns servers setting found in config and system");
        }
        String [] serverArray = serverList.toArray(new String[serverList.size()]);
        // 打印DNS Server的信息和Client连接参数
        if (LOG.isLoggable(Level.INFO)) {
            LOG.info("DNS servers at " + Arrays.toString(serverArray));
            LOG.info("DNS init timeout is [" + initialTimeout + "]");
            LOG.info("DNS retries is [" + retries + "]");
        }
        // 初始化DnsClient
        defaultClient = new DnsClient(serverArray);
        if (initialTimeout > 0) defaultClient.setInitialTimeout(initialTimeout);
        if (retries > 0) defaultClient.setRetries(retries);
        
        return defaultClient;
    }
    
    /**
     * 取得系统默认的 {@link DnsClient} 实例，这个实例依赖的配置数据是 {@link ToolContext}.
     * 这个实例是jvm全局唯一的.
     * 
     * 如果要根据指定的配置创建新的 {@link DnsClient}实例，调用 
     * {@link #createDnsClient(Configuration, boolean)}
     * 方法.
     * 
     * @return JVM全局唯一的DnsClient的实例
     */
    public static DnsClient getDnsClient() {
        if (defaultClient == null) {
            throw new RuntimeException("Load default dns client config failed", defaultClientError);
        }
        return defaultClient;
    }    
    
}
