package odis.app.tool;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobClient;
import odis.cowork.JobResult;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityMapper;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.IndexedFileInputFormat;
import odis.mapred.lib.IndexedFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.comparator.BinaryComparator;
import odis.tools.MapReduceHelper;
import odis.tools.ToDelete;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

/**
 * {@link RepartitionTool} 提供了对于输入数据进行重新分块排序的功能.
 * 不同参数的意义如下:
 * <ul>
 *   <li>-m : 指定程序执行时候的mapper数目，这个参数不对最终结果产生影响，一般不需要指定.
 *   <li>-d : 指定需要重新分块排序的数据. 如果没有使用"-s"参数指定输入数据，那么"-d"指定的数据同时是输入
 *            数据，也是输出数据的位置；否则，"-d"仅仅指定输出数据的位置.
 *   <li>-s : 指定输入数据的位置，如果没有"-s"参数，那么输入数据就是"-d"参数指定的数据. 这里可以指定多个
 *            不同的输入数据，但是这些输入数据的key, value必须是一样的.
 *   <li>-c : 指定新的partition的工具类(partitioner), 例如"odis.mapred.lib.UrlMd5Partitioner"
 *   <li>-p : 指定输出数据的part个数.
 *   <li>-k : 指定数据重新排序时候使用的key comparator，默认情况使用key的类型对应的comparator.
 *   <li>-v : 指定数据重新排序时候使用的value comparator，默认不按照value排序.
 *   <li>-name : 指定任务执行时候的名字，这个参数并没有实际意义，仅仅保证可以在odis web monitor上可以
 *            区别不同的repartition任务.
 * </ul>
 * 例如，如果我们需要把"/home/test/a1", "/home/test/a2"数据合并到一起，重新排序得到一个有256 part的输出
 * 数据，并且数据是按照url排序的，那么，可以用如下的命令行
 * <code>
 *     odis.sh -wn 128 repartition -s /home/test/a1 -s /home/test/a2 -d /home/test/a -p 256 -c odis.mapred.lib.UrlMd5Partitioner
 * </code>
 * 
 * 对于压缩的输入数据，这个工具保证输出的数据的压缩属性和输入数据一致；另外，如果输入数据是index file，输出数据也是index file.
 * 
 * @author river
 * 
 */
public class RepartitionTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(RepartitionTool.class);

    public String comment() {
        return "Repatition data";
    }
    
    @Override
    public String getToolName() {
        return "repartition";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("m", "mapnumber", "set the map number, " +
        		"use the worker number as default").setDefault("");
        options.withOption("d", "db", "if source db is not set, this option set " +
        		"database to be repartitioned and output path; otherwise, " +
        		"this option set the output path");
        options.withOption("s", "db", "set the database to be repartitioned, " +
        		"multiple db could be used").hasDefault();
        options.withOption("p", "new_partition_number", "set the new partition number");
        options.withOption("c", "classname", "set the partitioner class");
        options.withOption("k", "classname", "set the key comparator class").hasDefault();
        options.withOption("v", "classname", "set the value comparator class").hasDefault();
        options.withOption("name", "jobname", "set the name of job").hasDefault();
    }

    @SuppressWarnings("unchecked")
    public boolean exec(int nWorker) throws Exception {
        int mapNumber = options.getIntOpt("m", -1);
        if (mapNumber < 0) {
            mapNumber = nWorker;
        }

        int partitionNumber = options.getIntOpt("p");
        String partitionClassname = options.getStringOpt("c");
        String keyCompClassname = options.getStringOpt("k", null);
        String valCompClassname = options.getStringOpt("v", null);
        String dstPath = options.getStringOpt("d");
        String toolName = options.getStringOpt("name", null);

        String [] sourcePaths;
        if (options.isOptSet("s")) {
            sourcePaths = options.getOpt("s");
        } else {
            sourcePaths = new String[] { dstPath };
        }

        Class<? extends BasicPartitioner> partitionClass = (Class<? extends BasicPartitioner>) ClassUtils
                .getClass(partitionClassname, BasicPartitioner.class);
        Class<? extends BinaryComparator> keyCompClass = (keyCompClassname == null) ? null
                : (Class<? extends BinaryComparator>) ClassUtils.getClass(
                        keyCompClassname, BinaryComparator.class);
        Class<? extends BinaryComparator> valCompClass = (valCompClassname == null) ? null
                : (Class<? extends BinaryComparator>) ClassUtils.getClass(
                        valCompClassname, BinaryComparator.class);

        FileSystem fs = context.getFileSystem();

        Path inputDir = context.path(sourcePaths[0]);
        if (!fs.exists(inputDir)) {
            throw new IOException("cannot find input dir " + inputDir);
        }
        FileInfo[] files = fs.listFiles(inputDir);
        if (files.length == 0) {
            throw new IOException("input dir is empty");
        }

        boolean isIndexedFile = files[0].isDir();
        SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                isIndexedFile ? files[0].getPath().cat("data") : files[0].getPath());
        Class keyClass;
        Class valClass;
        int compressBlockSize = 0;
        try {
            keyClass = reader.getKeyClass();
            valClass = reader.getValueClass();
            compressBlockSize = reader.getCompressBlockSize();
        } finally {
            reader.close();
            reader = null;
        }

        String tempName = dstPath.replace('/', '_').replace('\\', '_');
        Path outputDir = context.tempPath(tempName);
        if (fs.exists(outputDir) && !fs.delete(outputDir)) {
            throw new IOException("cannot clean tmp directory " + outputDir);
        }
        ToDelete.toDelete(fs, outputDir);

        MapReduceJobDef job = context.createMapReduceJob(
                "repartition" + (toolName == null ? "" : "_" + toolName), 
                nWorker);

        for (String srcPath : sourcePaths) {
            job.addInputDir(context.path(srcPath), 
                    isIndexedFile ? IndexedFileInputFormat.class : SeqFileInputFormat.class);
        }

        job.setMapper(IdentityMapper.class);
        job.setPartitionerClass(partitionClass);
        job.setMapNumber(mapNumber);

        job.setMergeKeyValClass(keyClass, valClass);
        if (keyCompClass != null)
            job.setMergeKeyComparator(keyCompClass);
        if (valCompClass != null)
            job.setMergeValComparator(valCompClass);

        job.setWalkerClass(ReuseWalker.class);

        job.setReducer(IdentityReducer.class);
        job.setReduceNumber(partitionNumber);

        job.addOutputDir(0, outputDir, keyClass, valClass,
                isIndexedFile ? IndexedFileOutputFormat.class
                        : SeqFileOutputFormat.class);
        
        if (compressBlockSize > 0) {
            GenericFileOutputFormat.setCompress(job, 0, compressBlockSize);
            BasicPartitioner.setCompress(job);
        }

        JobResult result = JobClient.runJob(context.getCoWork(), job);
        if (!result.isSuccess()) {
            return false;
        }
        MapReduceHelper.printCounters(out, "Repartition job counters", result.getCounters());

        if (MapReduceHelper.getContinuousPartCount(fs, outputDir) != job
                .getReduceNumber()) {
            throw new IOException("bad output data in " + outputDir);
        }

        LOG.info("start to replace old data");
        File dstFile = context.file(dstPath);
        MapReduceHelper.replace(fs, new Path(dstFile), outputDir);
        LOG.info("old data replaced.");

        return true;
    }

}
