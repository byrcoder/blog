/**
 * @(#)TopCollectTool.java, 2007-7-16. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.IOException;
import java.io.PrintWriter;

import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MrStarJobDef;
import odis.mapred.lib.RandomPartitioner;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.BytesWritable;
import odis.serialize.lib.DoubleWritable;
import odis.tools.AbstractCoWorkTool;
import odis.tools.MapReduceHelper;
import toolbox.misc.ClassUtils;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * 在全部数据中选取score(key,value)最大的n个数据. 子类需要实现
 * {@link #getExtracter()} 方法来提供实际的排序分值以及输出数据.
 * 返回的是一个{@link Extracter}的实现.
 * 
 * @author river
 */
public abstract class AbstractTopCollectTool extends AbstractCoWorkTool {
    public static final String TOOL_NAME = "TopCollectTool";
    
    private String input;
    private String output;
    private int reserveNumber;
    private Options options;
    
    public AbstractTopCollectTool() {
        options = new Options();
        options.withOption("in", "input", "set input database");
        options.withOption("out", "output", "set output dir");
        options.withOption("n", "reserve_number", "set the count of entries to reserve");
    }
    
    @Override
    public String comment() {
        return "Select top n pair from data";
    }

    @Override
    public void usage(PrintWriter out) {
        options.printHelpInfo(out, TOOL_NAME);
    }
    
    @Override
    protected boolean processArgs(String[] args) throws Exception {
        try {
            options.parse(args);
        } catch(OptionParseException e) {
            out.println("error:" + e.getMessage());
            usage(out);
            return false;
        }
        
        input = options.getStringOpt("in");
        output = options.getStringOpt("out");
        reserveNumber = options.getIntOpt("n");
        return true;
    }

    /**
     * 子类必须实现这个方法，返回一个Extracter的实现.
     * @return
     */
    public abstract Extracter getExtracter();

    @Override
    public boolean exec(int nWorker) throws Exception {
        MrStarJobDef job = context.createMrStarJob(2, TOOL_NAME, nWorker);

        MapReduceHelper helper = new MapReduceHelper(context, job);
        Extracter extracter = getExtracter();
        
        // input
        job.addInputDir(helper.getReadInput(context.path(input)));
        
        // phrase 0
        job.setMapper(0, ExtractMapper.class);
        job.setMergeKeyValClass(0, DoubleWritable.class, BytesWritable.class);
        job.setPartitionerClass(0, RandomPartitioner.class);
        job.setMapNumber(nWorker);
        job.getConfig().setProperty(ExtractMapper.NAME_EXTRACTER_CLASS, 
                extracter.getClass().getName());
        job.setReducer(0, FirstSelectReducer.class);
        job.setWalkerClass(0, ReuseWalker.class);
        
        job.setMrNumber(1, nWorker);
        job.setMergeKeyValClass(1, DoubleWritable.class, BytesWritable.class);
        job.setPartitionerClass(1, SeqFileHashPartitioner.class);
        job.getConfig().setProperty(FirstSelectReducer.NAME_RESERVE_NUMBER, reserveNumber * 2 / nWorker);
        
        // reducer
        job.setReducer(SecondSelectReducer.class);
        job.setReduceNumber(1);
        job.setWalkerClass(ReuseWalker.class);
        job.getConfig().setProperty(SecondSelectReducer.NAME_RESERVE_NUMBER, reserveNumber);
        
        // output
        job.addOutputDir(0, helper.getUpdateOutput(context.path(output)), extracter.getKeyClass(), extracter.getValClass());
        
        // execute
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printCounters(out, result.getCounters());

        return true;
    }

    /**
     * 从(key,value)中提取出新的key, value以及打分的接口.
     * @author river
     */
    public static interface Extracter<K1, V1, K2, V2> {

        /**
         * 返回提取出来的key的类型.
         * @return
         */
        public Class getKeyClass();
        
        /**
         * 返回提取出来的val的类型.
         * @return
         */
        public Class getValClass();
        
        /**
         * 提取新的数据，如果返回false，就忽略这一条数据.
         * @param key
         * @param val
         * @param newKey
         * @param newVal
         */
        public boolean extractData(K1 key, V1 val, K2 newKey, V2 newVal);
        
        /**
         * 返回一个用于排序的分数. 最终选择分最高的n个.
         * @param key
         * @param val
         * @return
         */
        public double getScore(K1 key, V1 val);
        
    }
    
    /**
     * 从原始数据中提前输出数据，并且输出打分的值.
     * @author river
     *
     */
    public static class ExtractMapper extends AbstractMapper {
        public static final String NAME_EXTRACTER_CLASS = 
            ExtractMapper.class.getName() + ".extracter_class";
        
        private IWritable newKey;
        private IWritable newValue;
        private Extracter extracter;
        
        private final DoubleWritable scoreObject = new DoubleWritable();
        private final BytesWritable wrapper = new BytesWritable();
        private DataOutputBuffer obuf = new DataOutputBuffer();
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            super.configure(job, task);
            Class extracterClass = job.getConfig().getPropClass(NAME_EXTRACTER_CLASS, Extracter.class, null);
            extracter = (Extracter)ClassUtils.newInstance(extracterClass);
            newKey = (IWritable)ClassUtils.newInstance(extracter.getKeyClass());
            newValue = (IWritable)ClassUtils.newInstance(extracter.getValClass());
        }

        @SuppressWarnings("unchecked")
        public void map(Object key, Object value, ICollector collector) {
            if (extracter.extractData(key, value, newKey, newValue)) {
                scoreObject.set((-1) * extracter.getScore(key, value));
                wrapper.clear();
                obuf.reset();
                try {
                    newKey.writeFields(obuf);
                    newValue.writeFields(obuf);
                    wrapper.setBuffer(obuf.getData(), obuf.size());
                } catch(IOException e) {
                    throw new TaskFatalException("cannot persistent new key and value", e);
                }
                collector.collect(scoreObject, wrapper);
            }
        }
    }
    
    public static class FirstSelectReducer extends AbstractReducer<DoubleWritable, BytesWritable> {
        public static final String NAME_RESERVE_NUMBER = 
            FirstSelectReducer.class.getName() + ".reserve_number";
        
        private int reserveNumber;
        private TaskRunnable task;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            this.task = task;
            reserveNumber = job.getConfig().getInt(NAME_RESERVE_NUMBER, -1);
            if (reserveNumber < 0) {
                throw new TaskFatalException("cannot find reserve number setting");
            }
        }

        public void reduce(DoubleWritable key, 
                IWritablePairWalker<DoubleWritable, BytesWritable> values, ICollector collector) {
            while (reserveNumber > 0 && values.moreValue()) {
                collector.collect(key, values.getValue());
                reserveNumber --;
            }
            if (reserveNumber == 0) task.endTask();
        }
    }
    
    public static class SecondSelectReducer extends AbstractReducer<DoubleWritable, BytesWritable> {
        public static final String NAME_RESERVE_NUMBER = 
            SecondSelectReducer.class.getName() + ".reserve_number";
        
        private int reserveNumber;
        private TaskRunnable task;
        private Extracter extracter;
        private IWritable newKey;
        private IWritable newValue;
        private DataInputBuffer ibuf = new DataInputBuffer();
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            this.task = task;
            reserveNumber = job.getConfig().getInt(NAME_RESERVE_NUMBER, -1);
            if (reserveNumber < 0) {
                throw new TaskFatalException("cannot find reserve number setting");
            }
            Class extracterClass = job.getConfig().getPropClass(
                    ExtractMapper.NAME_EXTRACTER_CLASS, Extracter.class, null);
            extracter = (Extracter)ClassUtils.newInstance(extracterClass);
            newKey = (IWritable)ClassUtils.newInstance(extracter.getKeyClass());
            newValue = (IWritable)ClassUtils.newInstance(extracter.getValClass());
        }

        public void reduce(DoubleWritable key, 
                IWritablePairWalker<DoubleWritable, BytesWritable> values, ICollector collector) {
            while (reserveNumber > 0 && values.moreValue()) {
                BytesWritable wrapper = values.getValue();
                ibuf.reset(wrapper.data(), wrapper.size());
                try {
                    newKey.readFields(ibuf);
                    newValue.readFields(ibuf);
                } catch(IOException e) {
                    throw new TaskFatalException("unmarshal key and value failed", e);
                }
                collector.collect(newKey, newValue);
                reserveNumber --;
            }
            if (reserveNumber == 0) task.endTask();
        }
    }

}
