package odis.app.job;

import java.io.IOException;

import odis.cowork.JobResult;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.IMapper;
import odis.mapred.IReducer;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.LongHashPartitioner;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.Url;
import odis.tools.MapReduceHelper;

import toolbox.misc.cli.Options;

/**
 * 利用反射机制实现的更为简单的cowork tool的父类。 
 * 
 * 注意: 一个Tool里面只能有一个类继承自{@link IMapper}，也只能有一个类继承自{@link IReducer}，
 * 否则反射机制会搞不清该用哪个Mapper和Reducer。 
 * 
 * 相关wiki页面见：
 * https://dev.corp.youdao.com/outfoxwiki/ODIS/CoWork/Docs/EasyCoworkTool 
 * 
 * XXX: 1 仅支持MapOnlyJob和MapReduceJob，希望将来能够增加对MergeMapper和MergeReducer的支持 
 *      2 默认情况仅支持单目录输入、单目录输出的情况
 * 
 * @author hujie
 */
public abstract class AbstractEasyCoworkTool extends AbstractCoWorkToolWithArg {
    /**
     * Mapper.class Reducer.class
     */
    @SuppressWarnings("unchecked")
    protected Class<? extends IMapper> mapperClaz;

    @SuppressWarnings("unchecked")
    protected Class<? extends IReducer> reducerClaz;

    protected int nMapper, nReducer;

    protected Class<? extends BasicPartitioner> partitioner;

    protected Path inputPath, outputPath;

    protected int worker;

    private OutputKeyValueClass outputKeyValueClass;

    private void printInfo() {
        System.out.println("Mapper = " + mapperClaz.getCanonicalName());
        if (reducerClaz != null) {
            System.out.println("Reducer = " + reducerClaz.getCanonicalName());
        } else {
            System.out.println("no reducer found, must be map only job");
        }
        System.out.println("worker = " + worker);
        System.out.println("nMapper = " + nMapper + ", nReducer = " + nReducer);
        System.out.println("partitioner = " + partitioner.getCanonicalName());
        System.out.println("inputPath = " + inputPath.getAbsolutePath());
        System.out.println("outputPath = " + outputPath.getAbsolutePath());
    }

    protected void prepareOptions(Options opt) {
        opt.withOption("in", "input dir", "input path").hasDefault();
        opt.withOption("out", "output dir", "output path").hasDefault();
    }

    public boolean processOptions(Options opt) {
        inputPath = context.path(opt.getStringOpt("in"));
        outputPath = context.path(opt.getStringOpt("out"));
        return true;
    }

    protected boolean runJob(MapReduceHelper helper) throws Exception {
        JobResult res = helper.runJob(context.getCoWork());
        if (!res.isSuccess())
            return false;
        helper.printCounters(out, res.getCounters());
        return true;
    }

    /**
     * @param worker
     * @param outputKeyValueClass
     *            mapper和reducer输出数据的类型
     * @return
     * @throws Exception
     */
    public boolean mapReduceJobExec(int worker,
            OutputKeyValueClass outputKeyValueClass) throws Exception {

        this.worker = worker;

        this.outputKeyValueClass = outputKeyValueClass;

        setMapperReducer();

        setNMapperNReducer();

        setPartitioner();

        MapReduceJobDef job = AppCreationUtils.createMapReduceJob(context,
                getToolName(), worker, mapperClaz, nMapper, reducerClaz,
                nReducer, outputKeyValueClass.mapOutputKeyClass,
                outputKeyValueClass.mapOutValueClass, partitioner);

        MapReduceHelper helper = new MapReduceHelper(context, job);

        setInputPath(helper);

        setOutputPath(helper);

        setCompress(job);

        setJobConf(job);

        printInfo();

        if (!runJob(helper))
            return false;

        doAfterRunJob();

        return true;
    }

    /**
     * @param worker
     * @param outputKeyValueClass
     * @return
     * @throws Exception
     */
    public boolean mapOnlyJobExec(int worker,
            OutputKeyValueClass outputKeyValueClass) throws Exception {
        this.worker = worker;

        this.outputKeyValueClass = outputKeyValueClass;

        setMapperReducer();

        setNMapperNReducer();

        setPartitioner();

        MapOnlyJobDef job = AppCreationUtils.createMapOnlyJob(context,
                getToolName(), worker, mapperClaz, nMapper);

        MapReduceHelper helper = new MapReduceHelper(context, job);

        setInputPath(helper);

        setOutputPath(helper);

        setCompress(job);

        setJobConf(job);

        printInfo();

        if (!runJob(helper))
            return false;

        doAfterRunJob();

        return true;
    }

    /**
     * 当主要的job完成之后，可以plugin一些事情。
     */
    protected void doAfterRunJob() {

    }

    /**
     * 可以重载此方法来设置任何的partitioner
     */
    protected void setPartitioner() {
        if (outputKeyValueClass.mapOutputKeyClass != null) {
                if (outputKeyValueClass.mapOutputKeyClass.equals(Url.class)) {
                    partitioner = UrlMd5Partitioner.class;
                    return;
                } else if (LongWritable.class.isAssignableFrom(
                        outputKeyValueClass.mapOutputKeyClass)){
                    // support LongWritable & DocID
                    partitioner = LongHashPartitioner.class;
                    return;
                }
        }
        partitioner = SeqFileHashPartitioner.class;
    }

    /**
     * 可以重载此方法，增加多路的输入，默认只有一路输入。
     * 
     * @param helper
     * @throws IOException
     */
    protected void setInputPath(MapReduceHelper helper) throws IOException {
        helper.addReadInputDir(inputPath, null);
    }

    /**
     * 可以重载此方法，达到输出多路数据的目的，默认只有一路输出。
     * 
     * @param helper
     * @throws IOException
     */
    protected void setOutputPath(MapReduceHelper helper) throws IOException {
        helper.addUpdateOutputDir(0, outputPath,
                outputKeyValueClass.reduceOutputKeyClaz,
                outputKeyValueClass.reduceOutputValueClaz, null);
    }

    /**
     * 配置文件中指定的part数目
     */
    protected int defaultPartNum;

    protected boolean internalInitTool() throws Exception {
        if (!super.internalInitTool())
            return false;
        int partNumber = context.getAppInt("database.partition_number", -1);
        if (partNumber <= 0) {
            throw new RuntimeException("bad part number : " + partNumber);
        }
        this.defaultPartNum = partNumber;
        return true;
    }

    /**
     * 重载此方法可以往config里面写数据。
     * 
     * @param job
     */
    protected void setJobConf(MapOnlyJobDef job) {

    }

    /**
     * 重载方法可以对多路输出进行压缩，一般配合setOutputPath使用。
     * 
     * @param job
     */
    protected void setCompress(MapOnlyJobDef job) {
        GenericFileOutputFormat.setCompress(job, 0, 0);
    }

    /**
     * 默认是通过reflection找到Mapper和Reducer，重载此方法可以自定义mapper和reducer
     */
    @SuppressWarnings("unchecked")
    protected void setMapperReducer() {
        Class<?>[] clazs = this.getClass().getDeclaredClasses();
        for (Class<?> claz: clazs) {
            if (IMapper.class.isAssignableFrom(claz)) {
                if (mapperClaz != null) {
                    throw new RuntimeException(""
                            + "There are too many classes implement IMapper.");
                }
                mapperClaz = (Class<? extends IMapper>) claz;
            }

            if (IReducer.class.isAssignableFrom(claz)) {
                if (reducerClaz != null) {
                    throw new RuntimeException(""
                            + "There are too many classes implement IReducer.");
                }
                reducerClaz = (Class<? extends IReducer>) claz;
            }
        }
    }

    /**
     * 可以通过重载此方法，重新设置nMapper和nReducer.
     */
    protected void setNMapperNReducer() {
        nMapper = worker;
        nReducer = defaultPartNum;
    }

    /**
     * 中间数据和最终输出数据的key,value的类型
     * 
     * @author hujie
     */
    public static class OutputKeyValueClass {

        private Class<?> mapOutputKeyClass, mapOutValueClass;

        private Class<? extends IWritableComparable> reduceOutputKeyClaz;

        private Class<? extends IWritable> reduceOutputValueClaz;

        /**
         * 定义mapper和reducer的输出的key value的类型
         * 
         * @param mapOutputKeyClass
         *            Mapper output key's class
         * @param mapOutValueClass
         *            Mapper output values's class
         * @param reduceOutputKeyClaz
         *            Reducer output key's class
         * @param reduceOutputValueClaz
         *            Reducer output valus's class
         */
        public OutputKeyValueClass(Class<?> mapOutputKeyClass,
                Class<?> mapOutValueClass,
                Class<? extends IWritableComparable> reduceOutputKeyClaz,
                Class<? extends IWritable> reduceOutputValueClaz) {
            this.mapOutputKeyClass = mapOutputKeyClass;
            this.mapOutValueClass = mapOutValueClass;
            this.reduceOutputKeyClaz = reduceOutputKeyClaz;
            this.reduceOutputValueClaz = reduceOutputValueClaz;
        }

        /**
         * 这个构造函数在以下两种场景中使用 1 MapOnlyJob 时 2 MapReduceJob
         * 的mapper的输出与reducer的输出的key、value的类型一样时
         * 
         * @param outputKeyClass
         * @param outputValueClass
         */
        public OutputKeyValueClass(
                Class<? extends IWritableComparable> outputKeyClass,
                Class<? extends IWritable> outputValueClass) {
            this(outputKeyClass, outputValueClass, outputKeyClass,
                    outputValueClass);
        }

    }
}
