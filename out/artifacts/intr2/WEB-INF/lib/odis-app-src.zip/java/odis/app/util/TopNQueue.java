/**
 * 
 */
package odis.app.util;

import java.util.Comparator;

import odis.serialize.IWritable;
import toolbox.misc.IObjectGenerator;

/**
 * A class exntending PriorityQueue which remains the Top-N largest objects.
 * This class extends toolbox.misc.TopNQueue and add an addValue methods. When E
 * extends from IMutable, you can use addValue to add value to the queue. The
 * object passed in can be reused after calling.
 * 
 * @author David
 */
@SuppressWarnings("serial")
public class TopNQueue<E> extends toolbox.collections.TopNQueue<E> {
    IObjectGenerator<E> generator;

    /**
     * The constructor.
     * 
     * @param topN
     *            The number of objects remained.
     */
    public TopNQueue(int topN) {
        super(topN);
    }

    /**
     * The constructor.
     * 
     * @param topN
     *            The number of objects remained.
     * @param comparator
     *            The comparator for the minimum-heap.
     */
    public TopNQueue(int topN, Comparator<E> comparator) {
        super(topN, comparator);
    }

    /**
     * The constructor.
     * 
     * @param topN
     *            The number of objects remained.
     * @param generator
     *            The object generator.
     */
    public TopNQueue(int topN, IObjectGenerator<E> generator) {
        super(topN);
        this.generator = generator;
    }

    /**
     * The constructor.
     * 
     * @param topN
     *            The number of objects remained.
     * @param generator
     *            The object generator.
     * @param comparator
     *            The comparator for the minimum-heap.
     */
    public TopNQueue(int topN, IObjectGenerator<E> generator,
            Comparator<E> comparator) {
        super(topN, comparator);
        this.generator = generator;
    }

    /**
     * Add the value of an element. Only value of the object is copied, i.e the
     * object can be reused again after returning. The element must implement
     * IMutable interface. A new instance will be generated using the object
     * generator. NOTE: You must specify (in constructor) the object generator.
     * 
     * @param o
     *            the element to be added
     * @return true if this element replaces one of the element in the queue or
     *         was insterted into the queue. false otherwise.
     */
    public boolean addValue(E o) {
        if (this.size() < topN || objCompareTo(this.peek(), o) < 0) {
            E p;
            if (this.size() >= topN)
                p = poll();
            else
                p = generator.newInstance();
            ((IWritable) p).copyFields((IWritable) o);
            super.offer(p);
            return true;
        } // if
        return false;
    }
}
