package odis.app.job;

import java.io.PrintWriter;

import odis.tools.AbstractCoWorkTool;
import odis.tools.ToolContext;
import toolbox.collections.ArrayUtils;

/**
 * The abstract class for creating a set (sub-folder) of tools.
 * 
 * @author xxx, david
 *
 */
public abstract class CoWorkToolExecSet extends CoWorkToolGroup {
    
    protected AbstractCoWorkTool tool;
    
    public boolean exec(int nWorker) throws Exception {
        return tool.exec(nWorker);
    }
    
    public boolean setEnv(ToolContext env, String[] args, PrintWriter out) 
            throws Exception {
        if (args.length >= 1) {
            String name = args[0];
            if ("help".equals(name)) {
                if (args.length >= 2) {
                    name = args[1];
                    
                    if (getTools().containsKey(name)) {
                        tool = getTools().get(name).newInstance();
                        tool.usage(out);
                        return false;
                    } // if
                    
                    out.println("Unknown tool " + name);
                } // if
            } else {
                if (getTools().containsKey(name)) {
                    tool = getTools().get(name).newInstance();
                    String [] newArgs = ArrayUtils.shift(args);
                    return tool.setEnv(env, newArgs, out);
                } // if
                
                out.println("Unknown tool " + name);
            } // else
        } // if
        usage(out);
        return false;
    }
}
