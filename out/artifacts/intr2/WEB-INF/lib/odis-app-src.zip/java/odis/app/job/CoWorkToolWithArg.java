package odis.app.job;

import java.io.PrintWriter;

import odis.tools.AbstractCoWorkTool;
import toolbox.misc.cli.ArgumentProcessor;

/**
 * A cowork tool super-class with argument processing supporting.
 * @deprecated Use {@link AbstractCoWorkToolWithArg} instead.
 * 
 * @author david
 */
public abstract class CoWorkToolWithArg extends AbstractCoWorkTool {
    public int nWorker;
    public ArgumentProcessor args;
    
    public CoWorkToolWithArg() {
        args = getArgumentProcessor();
        if (this.args == null)
            this.args = new ArgumentProcessor();
        
        this.args.addArguments("help", "COMMENT:Print this help info.", 
                "SHARED:");
        internalAddArgumentsTool(this.args);
    }

    /**
     * Return an ArgumentProcessor object for argument processing.
     * See document of ArgumentProcessor for more details.
     * 
     * @return Created object.
     */
    protected ArgumentProcessor getArgumentProcessor() {
        return null;
    }

    /**
     * Interal adding of arguments. This is called before arguments are 
     * processed.
     * 
     * @param args  the ArgumentProcessor instance
     */
    protected void internalAddArgumentsTool(ArgumentProcessor args) {
    }
    
    @Override
    public boolean processArgs(String[] args) {
        try {
            if (!internalInitTool()) {
                out.println("Initialization failed.");
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } // if
        
        String msg = this.args.process(args, 0);
        if (msg != null) {
            out.println(msg);
            return false;
        } // if
        
        if (this.args.isOptSet("help")) {
            this.usage(out);
            return false;
        } // if
        
        if (getMinNumOfArgs() >= 0 && this.args.size() < getMinNumOfArgs()) {
            out.println("Expected at least " + getMinNumOfArgs() 
                    + " arguments, but only " + this.args.size() + 
                    " is set!\n" + "Please read the usage message for more " +
                    "details!");
            usage(out);
            return false;
        } // if
        
        return true;
    }
    
    /**
     * The internal initialization. This is called before the augument processor is created.
     *  
     * @return  true if succeed; false if any error happens.
     * @throws Exception if an error occurs
     */
    protected boolean internalInitTool() throws Exception {
        return true;
    }
    
    protected abstract boolean exec() throws Exception;
    public boolean exec(int nWorker) throws Exception {
        this.nWorker = nWorker;
        System.out.println("=== Executing " + this.getClass().getSimpleName() + ".exec() ===");
        return exec();
    }
    
    /**
     * Return the minimum number of arguments. If this method returns -1, the framework
     * will not check the number of args.
     *
     * @return The minimum number of arguments.
     */
    protected int getMinNumOfArgs() {
        return 0;
    }

    /**
     * Returns the name of the tool for printing usage information.
     */
    public abstract String getToolName();
    
    @Override
    public void usage(PrintWriter out) {
        out.println(this.comment());
        args.printHelpInfo(out, getToolName(), 100);
    }
}
