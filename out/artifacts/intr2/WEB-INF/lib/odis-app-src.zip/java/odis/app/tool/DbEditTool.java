/**
 * @(#)UpdateSiteRankTool.java, 2007-6-1. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.app.view.SeqFileUtils;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobClient;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IndexedFileInputFormat;
import odis.mapred.lib.IndexedFileOutputFormat;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.IParsable;
import odis.tools.MapReduceHelper;

import org.apache.commons.configuration.Configuration;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

/**
 * 通过读取一个固定格式的修正文件（xml文件格式)修改db中指定的数据.
 * 修正文件的格式为:
 * <code>
 * <!-- 修正文件例子 -->
 * <?xml version="1.0" encoding="utf-8"?>
 * <edits>
 *   <key-class>odis.serialize.lib.Url</key-class>
 *   <val-class>outfox.data.SiteAttr</val-class>
 *   <!-- If there's "add" command, partitioner-class must be set -->
 *   <partitioner-class>odis.mapred.lib.UrlMd5Partitioner</partitioner-class>
 *   
 *   <!-- create and add new object -->
 *   <add key="www.google.com">
 *      <set field="capacity" value="5" />
 *      <set field="priority" value="3" />
 *      <set field="siteRank" value="10000" />
 *   </add>
 *   
 *   <!-- type may be "regex" which means match by regex, or "string" which means
 *        match exactly; "*" or ".*" match all -->
 *   <mod key="*" type="regex">
 *      <set field="capability">5</set>
 *   </mod>
 *   
 *   <!-- exact matches -->
 *   <mod key="help.163.com">
 *      <set field="fetchPriority" value="8" />
 *   </mod>
 *   <mod key="post.baidu.com">
 *      <set field="updatePriority" value="8" />
 *   </mod>
 *   
 *   <!-- regex match -->
 *   <mod key=".*\.blog\.163\.com" type="regex">
 *      <set field="updatePriority" value="5" />
 *   </mod>
 *   
 *   <!-- suffix match -->
 *   <del key=".bad.com" type="suffix" />
 *   
 *   <!-- prefix match -->
 *   <mod key="comments." type="prefix">
 *      <set field="fetchPriority" value="3" />
 *      <set field="updatePriority" value="4" />
 *   </mod>
 *   
 * </edits> 
 * 
 * </code>
 * 
 * @author guojun, river
 *
 */
public class DbEditTool extends AbstractCoWorkToolWithArg {
    
    public static final Logger LOG = LogFormatter.getLogger(DbEditTool.class);
    private static final String NAME_CONFIG_FILE = DbEditTool.class + ".config-file";
    private static final String NAME_PARTITIONER_CLASS = DbEditTool.class + ".partitioner-class";
    private static final String NAME_PARTITION_NUMBER = DbEditTool.class + ".partition-number";
    
    private String localXmlFilename;
    private String partitionerClassname;
    private String dbName;
    
    @Override
    public String comment() {
        return "Edit db by xml description";
    }
    
    @Override
    public String getToolName() {
        return "dbedit";
    }
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("d", "database", "set the database to be edited");
        options.withOption("f", "xml_file_name", "set the xml rule file");
        options.withOption("pa", "partitioner_class", "set the partitioner " +
        		"to be used when adding instances during editing").hasDefault();
    }

    @Override
    public boolean processOptions(Options options) {
        localXmlFilename = options.getStringOpt("f");
        partitionerClassname = options.getStringOpt("pa", null);
        dbName = options.getStringOpt("d");
        return true;
    }

    private void validateXmlFile(Class keyClass, Class valClass) throws Exception {
        FileInputStream fis = new FileInputStream(localXmlFilename);
        try {
            DocumentBuilder builder = 
                DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(fis);
            NodeList nodes = doc.getChildNodes().item(0).getChildNodes();
            for (int i=0; i<nodes.getLength(); i++) {
                Node node = nodes.item(i);
                if (node.getNodeName().equals("partitioner-class")) {
                    partitionerClassname = node.getChildNodes().item(0).getTextContent();
                } else if (node.getNodeName().equals("add")) {
                    if (partitionerClassname == null) {
                        throw new RuntimeException("partitioner-class should be set when there's <add> commands");
                    }
                }
            }
            
            // test to parse the xml locally
            Modifier.Editor editor = Modifier.parse(doc);
            if (editor.getKeyClass() != keyClass || editor.getValClass() != valClass) {
                throw new RuntimeException("key/val class mismatch in config file and db");
            }
        } finally {
            fis.close();
        }
    }
    
    private void createNewData(FileSystem fs, Path tempPath) throws Exception {
        FileInputStream fis = new FileInputStream(localXmlFilename);
        try {
            
            HashMap<Object, Object> dataMap = new HashMap<Object, Object>();
            Modifier.Editor editor = Modifier.parse(fis);
            for (Modifier.EditorPair<Object, Modifier.ObjectModifier> entry : editor.getCreateList()) {
                Object value = ClassUtils.newInstance(editor.getValClass());
                entry.getValue().apply(value);
                dataMap.put(entry.getKey(), value);
            }
            
            Path output = tempPath.cat("output1");
            SeqFileUtils.saveMapToFile(fs, output.cat(CoWorkUtils.getPartID(0)), dataMap);
            MapReduceHelper.replace(fs, context.path(dbName), output);
        } finally {
            fis.close();
        }
    }
    
    @Override
    public boolean exec(int nWorker) throws Exception {
        FileSystem fs = context.getFileSystem();
        
        Path db = context.path(dbName);
        Path tempPath = MapReduceHelper.createTempDir(fs, new Path(context.getAppTemp()), "dbedit");
        
        Path remoteXmlFile = tempPath.cat("edit-file-xml");
        fs.copyFromLocalFile(new File(localXmlFilename), remoteXmlFile);
        
        MapOnlyJobDef job = context.createMapOnlyJob("DbEdit", nWorker);
        
        // input
        Path inputLink = tempPath.cat("input");
        if (!fs.exists(db)) {
            createNewData(fs, tempPath);
            return true;
        }
        
        int partitionNumber = MapReduceHelper.linkContinuousParts(fs, db, inputLink);
        Path partFile = fs.listFiles(inputLink)[0].getPath();
        boolean isIndexFile = fs.isDirectory(partFile);
        Class keyClass, valClass;
        int compressedBlockSize = 0;
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, 
                isIndexFile ? new Path(partFile, IndexedFile.DATA_FILE_NAME) : partFile);
        try {
            keyClass = reader.getKeyClass();
            valClass = reader.getValueClass();
            compressedBlockSize = reader.getCompressBlockSize();
        } finally {
            reader.close();
        }
        job.addInputDir(inputLink, 
                isIndexFile ? IndexedFileInputFormat.class : SeqFileInputFormat.class);

        // validation
        validateXmlFile(keyClass, valClass);
        if (partitionerClassname != null && 
                !BasicPartitioner.class.isAssignableFrom(Class.forName(partitionerClassname))) {
            throw new RuntimeException("bad partitioner classname : " + partitionerClassname);
        }
        
        // map settings
        job.setMapper(Mapper.class);
        job.setMapNumber(partitionNumber);
        job.setPerUnitSplit(true);
        
        // output
        Path output = tempPath.cat("output");
        job.addOutputDir(0, output, keyClass, valClass, 
                isIndexFile ? IndexedFileOutputFormat.class : SeqFileOutputFormat.class);
        if (compressedBlockSize > 0) {
            GenericFileOutputFormat.setCompress(job, 0, compressedBlockSize);
        }
        
        // config
        job.getConfig().setProperty(NAME_CONFIG_FILE, remoteXmlFile.asFile().getAbsolutePath());
        if (partitionerClassname != null) {
            job.getConfig().setProperty(NAME_PARTITIONER_CLASS, partitionerClassname);
        }
        job.getConfig().setProperty(NAME_PARTITION_NUMBER, partitionNumber);
        
        // execute
        JobResult result = JobClient.runJob(context.getCoWork(), job);
        if (!result.isSuccess()) return false;
        
        //replace the sitedb
        fs.getLock(db, FileSystem.UPDATE_LOCK);
        try {
            fs.promoteLock(db);
            MapReduceHelper.replace(fs, db, output);
        } finally{
            fs.releaseLock(db);
        }

        // print the job messages
        MapReduceHelper.printMessages(out, "Job messages:", result.getMsg());
        MapReduceHelper.printCounters(out, "Job counters", result.getCounters());     

        return true;
    }
    
    public static class Mapper extends AbstractMapper<Object, Object>{
        private Modifier.Editor editor;
        private BasicPartitioner partitioner;
        
        private Object [] keys;
        private Object [] vals;
        private int keyIndex;
        private Counter updateCounter;
        private Counter delCounter;
        private Counter addCounter;
        
        public void configure(JobDef job, TaskRunnable task) {
            Configuration conf = job.getConfig();
            try {
                FileSystem fs = FileSystem.getNamed(((BasicInOutJobDef)job).getDefaultFsName());
                String configFilename = conf.getString(NAME_CONFIG_FILE);
                InputStream is = fs.open(new Path(configFilename));
                try {
                    editor = Modifier.parse(is); 
                } finally {
                    is.close();
                }
                String partitionerClassname = conf.getString(NAME_PARTITIONER_CLASS);
                partitioner = partitionerClassname == null ? null : 
                    (BasicPartitioner)Class.forName(partitionerClassname).newInstance();
            } catch (Exception e) {
                throw new TaskFatalException("initialize failed", e);
            }
            int partIdx = task.getPartIdx();
            int partitionNumber = conf.getInt(NAME_PARTITION_NUMBER);
            
            List<Modifier.EditorPair<Object, Modifier.ObjectModifier>> creaters = editor.getCreateList();
            ArrayList<Modifier.EditorPair<Object, Modifier.ObjectModifier>> localCreaters = 
                new ArrayList<Modifier.EditorPair<Object, Modifier.ObjectModifier>>(creaters.size());
            for (Modifier.EditorPair<Object, Modifier.ObjectModifier> entry : creaters) {
                int p = partitioner.getPartition(entry.getKey(), null, partitionNumber);
                if (p == partIdx) {
                    localCreaters.add(entry);
                }
            }
            Collections.sort(localCreaters, new Comparator<Modifier.EditorPair<Object, Modifier.ObjectModifier>>() {

                @SuppressWarnings("unchecked")
                public int compare(odis.app.tool.DbEditTool.Modifier.EditorPair<Object, odis.app.tool.DbEditTool.Modifier.ObjectModifier> o1, 
                        odis.app.tool.DbEditTool.Modifier.EditorPair<Object, odis.app.tool.DbEditTool.Modifier.ObjectModifier> o2) {
                    return ((Comparable) o1.getKey()).compareTo(o2.getKey());
                }
            });
            
            keys = new Object[localCreaters.size()];
            vals = new Object[localCreaters.size()];
            int index = 0;
            for (Modifier.EditorPair<Object, Modifier.ObjectModifier> entry : localCreaters) {
                keys[index] = entry.getKey();
                Object value = ClassUtils.newInstance(editor.getValClass());
                try {
                    entry.getValue().apply(value);
                } catch(Exception e) {
                    throw new TaskFatalException("bad setting for new value of " + entry.getKey(), e);
                }
                vals[index] = value;
                index ++;
            }
            keyIndex = 0;
            
            updateCounter = task.getCounter("updateCounter");
            delCounter = task.getCounter("delCounter");
            addCounter = task.getCounter("addCounter");
        }
        
        @SuppressWarnings("unchecked")
        public void map(Object key, Object value, ICollector collector) {
            while (keyIndex < keys.length 
                    && ((Comparable<Object>) key).compareTo(keys[keyIndex]) > 0) {
                collector.collect(keys[keyIndex], vals[keyIndex]);
                addCounter.inc();
                keyIndex ++;
            }
            
            if (key.toString().equals("help.163.com")) {
                System.out.println("haha");
            }
            if (editor.shouldDelete(key)) {
                delCounter.inc();
                return;
            } else {
                try {
                    if (editor.applyModification(key, value)) {
                        updateCounter.inc();
                    }
                } catch(InvocationTargetException e) {
                    LOG.log(Level.SEVERE, "set value to " + key + " failed", e);
                    throw new TaskFatalException("set value to " + key + " failed", e);
                }
                collector.collect(key, value);
            }
        }

        @Override
        public void mapEnd(ICollector collector) {
            while (keyIndex < keys.length) {
                collector.collect(keys[keyIndex], vals[keyIndex]);
                keyIndex ++;
                addCounter.inc();
            }
        }
        
    }

    public static class Modifier {

        public static class FieldCache {
            
            private HashMap<Class, HashMap<String, Method> > cache = new HashMap<Class, HashMap<String, Method>>();
            private static FieldCache instance = new FieldCache(); 
            
            private FieldCache() {}
            
            public synchronized Method getMethod(Class clazz, String name) {
                HashMap<String, Method> methodMap = cache.get(clazz);
                if (methodMap == null) {
                    methodMap = new HashMap<String, Method>();
                    cache.put(clazz, methodMap);
                }
                Method method = methodMap.get(name);
                if (method == null) {
                    Method [] methods = clazz.getDeclaredMethods();
                    String setName = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
                    for (Method m : methods) {
                        if (m.getName().equals(setName) && m.getParameterTypes().length==1) {
                            method = m;
                            break;
                        }
                    }
                    if (method != null) {
                        methodMap.put(name, method);
                    }
                }
                return method;
            }
            
            public static FieldCache getInstance() {
                return instance;
            }
        }
        
        public static class BadModifyDeclarationException extends Exception {
            private static final long serialVersionUID = -4446428633714186968L;

            public BadModifyDeclarationException(String message) {
                super(message);
            }
            
            public BadModifyDeclarationException(String message, Throwable cause) {
                super(message, cause);
            }
        }
        
        public static class FieldModifier {
            private Method method;
            private Object value;

            private FieldModifier(Method method, Object value) {
                this.method = method;
                this.value = value;
            }
            
            public void apply(Object o) throws InvocationTargetException {
                try {
                    method.invoke(o, new Object[]{value});
                } catch (IllegalAccessException e) {
                    throw new RuntimeException("illegal access to method " + method + " of class " + o.getClass(), e);
                }
            }
            
            public static Object convertValue(Class paramType, String value) throws BadModifyDeclarationException {
                Object valueObject;
                if (paramType == String.class) {
                    valueObject = value;
                } else if (paramType == Integer.class || paramType == Integer.TYPE) {
                    valueObject = new Integer(value);
                } else if (paramType == Short.class || paramType == Short.TYPE) {
                    valueObject = new Short(value);
                } else if (paramType == Byte.class || paramType == Byte.TYPE) {
                    valueObject = new Byte(value);
                } else if (paramType == Long.class || paramType == Long.TYPE) {
                    valueObject = new Long(value);
                } else if (paramType == Float.class || paramType == Float.TYPE) {
                    valueObject = new Float(value);
                } else if (paramType == Double.class || paramType == Double.TYPE) {
                    valueObject = new Double(value);
                } else if (paramType == Character.class || paramType == Character.TYPE) {
                    valueObject = value.charAt(0);
                } else if (paramType == Boolean.class || paramType == Boolean.TYPE) {
                    valueObject = new Boolean(value);
                } else if (IParsable.class.isAssignableFrom(paramType)) {
                    try {
                        IParsable parsable = (IParsable)paramType.newInstance();
                        parsable.parse(value);
                        valueObject = parsable;
                    } catch(Exception e) {
                        throw new BadModifyDeclarationException("cannot parse the value \"" + value + "\" for type " + paramType, e);
                    }
                } else {
                    throw new BadModifyDeclarationException("param type " + paramType + " do not support set from string");
                }
                return valueObject;
            }
            
            public static FieldModifier create(Class clazz, String fieldName, String value) throws BadModifyDeclarationException {
                Method m = FieldCache.getInstance().getMethod(clazz, fieldName);
                if (m == null) {
                    return null;
                }
                
                Class paramType = m.getParameterTypes()[0];
                Object valueObject = convertValue(paramType, value);
                return new FieldModifier(m, valueObject);
            }
            
        }
        
        public static class ObjectModifier {
            private List<FieldModifier> fields = new LinkedList<FieldModifier>();

            public void addFieldModifier(FieldModifier modifier) {
                fields.add(modifier);
            }
            
            public void apply(Object o) throws InvocationTargetException {
                for (FieldModifier field : fields) {
                    field.apply(o);
                }
            }
        }
        
        public static class EditorPair<K, V> {
            private K key;
            private V value;
            public EditorPair(K k, V v) {
                this.key = k;
                this.value = v;
            }
            
            public K getKey() { return key; }
            
            public V getValue() { return value; }
        }
        
        public static class Editor {
            public static final String TYPE_REGEX = "regex";
            public static final String TYPE_STRING = "string";
            public static final String TYPE_PREFIX = "prefix";
            public static final String TYPE_SUFFIX = "suffix";
            
            private Class keyClass;
            private Class valClass;
            
            private List<ObjectModifier> forAll = new LinkedList<ObjectModifier>();
            private List<EditorPair<Pattern, ObjectModifier> > patterns = new LinkedList<EditorPair<Pattern, ObjectModifier>>();
            private Map<Object, ObjectModifier> modMap = new HashMap<Object, ObjectModifier>();
            private List<EditorPair<String, ObjectModifier> > prefixes = new LinkedList<EditorPair<String, ObjectModifier>>();
            private List<EditorPair<String, ObjectModifier> > suffixes = new LinkedList<EditorPair<String, ObjectModifier>>();
            
            private List<EditorPair<Object, ObjectModifier> > createList = new LinkedList<EditorPair<Object, ObjectModifier>>();
            
            private List<Pattern> delPatterns = new LinkedList<Pattern>();
            private Set<Object> delSet = new HashSet<Object>();
            private List<String> prefixDels = new LinkedList<String>();
            private List<String> suffixDels = new LinkedList<String>();
            
            public Editor(Class keyClass, Class valClass) {
                this.keyClass = keyClass;
                this.valClass = valClass;
            }
            
            public Class getKeyClass() {
                return keyClass;
            }
            
            public Class getValClass() {
                return valClass;
            }
            
            public void addModifier(String matchString, String matchType, ObjectModifier modifier) 
            throws BadModifyDeclarationException {
                if (matchType.equals(TYPE_REGEX)) {
                    if (matchString.equals(".*") || matchString.equals("*")) {
                        forAll.add(modifier);
                    } else {
                        Pattern pattern = Pattern.compile(matchString);
                        patterns.add(new EditorPair<Pattern, ObjectModifier>(pattern, modifier));
                    }
                } else if (matchType.equals(TYPE_PREFIX)) {
                    if (matchString.length() ==0) {
                        throw new BadModifyDeclarationException("empty prefix is not allowed");
                    }
                    prefixes.add(new EditorPair<String, ObjectModifier>(matchString, modifier));
                } else if (matchType.equals(TYPE_SUFFIX)) {
                    if (matchString.length() ==0) {
                        throw new BadModifyDeclarationException("empty suffix is not allowed");
                    }
                    suffixes.add(new EditorPair<String, ObjectModifier>(matchString, modifier));
                } else {
                    Object keyObject = FieldModifier.convertValue(keyClass, matchString);
                    modMap.put(keyObject, modifier);
                }
            }
            
            public void addCreater(String keyString, ObjectModifier modifier) 
            throws BadModifyDeclarationException {
                Object keyObject = FieldModifier.convertValue(keyClass, keyString);
                createList.add(new EditorPair<Object, ObjectModifier>(keyObject, modifier));
            }
            
            public void addDeleter(String matchString, String matchType) 
            throws BadModifyDeclarationException {
                if (matchType.equals("regex")) {
                    if (matchString.equals(".*") || matchString.equals("*")) {
                        throw new BadModifyDeclarationException("cannot delete " + matchString);
                    }
                    Pattern pattern = Pattern.compile(matchString);
                    delPatterns.add(pattern);
                } else if (matchType.equals(TYPE_PREFIX)) {
                    if (matchString.length() ==0) {
                        throw new BadModifyDeclarationException("empty prefix is not allowed");
                    }
                    prefixDels.add(matchString);
                } else if (matchType.equals(TYPE_SUFFIX)) {
                    if (matchString.length() ==0) {
                        throw new BadModifyDeclarationException("empty suffix is not allowed");
                    }
                    suffixDels.add(matchString);                    
                } else {
                    Object keyObject = FieldModifier.convertValue(keyClass, matchString);
                    delSet.add((Comparable)keyObject);
                }
            }
            
            public boolean applyModification(Object key, Object value) throws InvocationTargetException {
                if (!modMap.isEmpty()) {
                    ObjectModifier modifier = modMap.get(key);
                    if (modifier != null) {
                        modifier.apply(value);
                        return true;
                    }
                }

                String str = null;
                if (!patterns.isEmpty() || !prefixes.isEmpty() || !suffixes.isEmpty()) {
                    str = key.toString();
                }
                
                if (!prefixes.isEmpty()) {
                    for (EditorPair<String, ObjectModifier> entry : prefixes) {
                        if (str.startsWith(entry.getKey())) {
                            entry.getValue().apply(value);
                            return true;
                        }
                    }
                }
                
                if (!suffixes.isEmpty()) {
                    for (EditorPair<String, ObjectModifier> entry : suffixes) {
                        if (str.endsWith(entry.getKey())) {
                            entry.getValue().apply(value);
                            return true;
                        }
                    }
                }
                
                if (!patterns.isEmpty()) {
                    for (EditorPair<Pattern, ObjectModifier> entry : patterns) {
                        if (entry.getKey().matcher(str).matches()) {
                            entry.getValue().apply(value);
                            return true;
                        }
                    }
                }
                
                if (!forAll.isEmpty()) {
                    for (ObjectModifier modifier : forAll) {
                        modifier.apply(value);
                    }
                    return true;
                }
                
                return false;
            }
            
            public List<EditorPair<Object, ObjectModifier>> getCreateList() {
                return createList;
            }
            
            public boolean shouldDelete(Object key) {
                if (!delSet.isEmpty() && delSet.contains(key)) 
                    return true;
                
                String str = null;
                if (!prefixDels.isEmpty() || !suffixDels.isEmpty() || !delPatterns.isEmpty()) {
                    str = key.toString();
                }
                
                if (!prefixDels.isEmpty()) {
                    for (String prefix : prefixDels) {
                        if (str.startsWith(prefix)) {
                            return true;
                        }
                    }
                }
                
                if (!suffixDels.isEmpty()) {
                    for (String suffix : suffixDels) {
                        if (str.endsWith(suffix)) {
                            return true;
                        }
                    }
                }
                
                if (!delPatterns.isEmpty()) {
                    for (Pattern pattern : delPatterns) {
                        if (pattern.matcher(str).matches()) {
                            return true;
                        }
                    }
                }
         
                return false;
            }
        }
        
        public static Editor parse(InputStream s) throws BadModifyDeclarationException {
            Document doc;
            try {
                DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                doc = builder.parse(s);
            } catch(Exception e) {
                throw new BadModifyDeclarationException(" parse xml source failed", e);
            }
            return parse(doc);
        }
        
        private static ObjectModifier parseModifier(Class keyClass, Node node) throws BadModifyDeclarationException {
            ObjectModifier mod = new ObjectModifier();
            
            NodeList childs = node.getChildNodes();
            int count = childs.getLength();
            for (int i=0; i<count; i++) {
                Node child = childs.item(i);
                if (child.getNodeName().equals("set")) {
                    String fieldName = child.getAttributes().getNamedItem("field").getTextContent();
                    String value;
                    Node attr = child.getAttributes().getNamedItem("value");
                    if (attr == null) {
                        NodeList valueList = child.getChildNodes();
                        if (valueList.getLength() == 0) {
                            value = "";
                        } else {
                            value = valueList.item(0).getTextContent();
                        }
                    } else {
                        value = attr.getTextContent();
                    }
                    FieldModifier modifier = FieldModifier.create(keyClass, fieldName, value);
                    mod.addFieldModifier(modifier);
                }
            }
            return mod;
        }
        
        public static Editor parse(Document doc) throws BadModifyDeclarationException {
            Editor editor = null;
            String keyClass = null;
            String valClass = null;
            
            Set<String> commandSet = new HashSet<String>();
            commandSet.add("add");
            commandSet.add("mod");
            commandSet.add("del");
            
            NodeList nodes = doc.getChildNodes().item(0).getChildNodes();
            for (int i=0; i<nodes.getLength(); i++) {
                Node node = nodes.item(i);
                if (node.getNodeName().equals("key-class")) {
                    keyClass = node.getChildNodes().item(0).getTextContent();
                } else if (node.getNodeName().equals("val-class")) {
                    valClass = node.getChildNodes().item(0).getTextContent();
                } else if (commandSet.contains(node.getNodeName())) {
                    if (editor == null) {
                        try {
                            editor = new Editor(Class.forName(keyClass), Class.forName(valClass));
                        } catch(Exception e) {
                            throw new BadModifyDeclarationException("initialize editor failed", e);
                        }
                    }
                    
                    if (node.getNodeName().equals("mod")) {
                        ObjectModifier modifier = parseModifier(editor.getValClass(), node);
                        String matchString = node.getAttributes().getNamedItem("key").getTextContent();
                        Node attrNode = node.getAttributes().getNamedItem("type");
                        String matchType = attrNode == null ? "string" : attrNode.getTextContent();
                        editor.addModifier(matchString, matchType, modifier);
                    } else if (node.getNodeName().equals("add")) {
                        ObjectModifier modifier = parseModifier(editor.getValClass(), node);
                        String matchString = node.getAttributes().getNamedItem("key").getTextContent();
                        editor.addCreater(matchString, modifier);
                    } else if (node.getNodeName().equals("del")) {
                        String matchString = node.getAttributes().getNamedItem("key").getTextContent();
                        Node attrNode = node.getAttributes().getNamedItem("type");
                        String matchType = attrNode == null ? "string" : attrNode.getTextContent();
                        editor.addDeleter(matchString, matchType);
                    }
                }
            }
            
            return editor;
        }
        
    }
    

}
