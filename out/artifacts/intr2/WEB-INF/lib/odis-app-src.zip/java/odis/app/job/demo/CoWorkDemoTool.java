package odis.app.job.demo;

import java.io.PrintWriter;

import odis.tools.AbstractCoWorkTool;

public class CoWorkDemoTool extends AbstractCoWorkTool {
    public static String TOOL_NAME = "coworkdemo";

    @Override
    public String comment() {
        return "Demo for a cowork tool";
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        System.out.println("  exec: nWorker = " + nWorker);
        return true;
    }

    @Override
    public void usage(PrintWriter out) {
        out.println("  coworkdemo");
    }
}
