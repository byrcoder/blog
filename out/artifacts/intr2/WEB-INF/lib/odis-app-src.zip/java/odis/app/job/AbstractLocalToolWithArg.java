/**
 * @(#)AbstractLocalToolWithArg.java, 2008-4-16. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.job;

import java.io.PrintWriter;
import java.lang.reflect.Field;

import odis.tools.AbstractLocalTool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Abstract local tool supports argument processing.
 * 
 * ChangeLog:
 *   1) David: add optPrepared so that prepareOptions is not called in 
 *      construtor. If calling in construtor, the members of sub-class are not
 *      initialized.
 *      
 * @author river, David
 */
public abstract class AbstractLocalToolWithArg extends AbstractLocalTool {
    protected Options options;
    private boolean optPrepared = false;
    
    public AbstractLocalToolWithArg() {
        options = new Options();
        options.withSharedOption("help", "Print this help information");
    }
    
    private void assureOptions() {
        if (!optPrepared) {
            prepareOptions(options);
            optPrepared = true;
        } // if
    }
    
    /**
     * Subclass can override this method to add application's options.
     * This method is called in constructor of tool, so don't access any
     * field which is not initialized at this time.
     *  
     * @param options the options instance to be used in {@link 
     *        #usage(PrintWriter)} and {@link #processArgs(String[])}.
     */
    protected void prepareOptions(Options options) {
    }
    
    /**
     * Get the options which hold the parsed value after {@link 
     * #processArgs(String[])} is called.
     * @return the {@link Options} instance.
     */
    public Options getOptions() {
        assureOptions();        
        return options;
    }
    
    /**
     * Read the parsed value from options.
     * @param options
     * @return
     */
    public boolean processOptions(Options options) {
        return true;
    }
    
    /**
     * This method is overrided to use the options prepared in {@link #prepareOptions(Options)}
     * to parse arguments.
     */
    public boolean processArgs(String[] args) {
        assureOptions();
        try {
            options.parse(args, 0, false);
        } catch(OptionParseException e) {
            out.println("option error : " + e.getMessage());
            return false;
        }
        if (options.isOptSet("help")) {
            this.usage(out);
            return false;
        }
        try {
            options.validate();
        } catch(OptionParseException e) {
            out.println("option validation failed : " + e.getMessage());
            return false;
        }

        if (!this.processOptions(options)) {
            this.usage(out);
            return false;
        }
        
        return true;
    }
    
    /**
     * Returns the name of the tool for printing usage information.
     * Override this method to supply your tool name, and the default
     * implementation returns the simple name of this class.
     */
    public String getToolName() {
        try {
            Field field = this.getClass().getField("TOOL_NAME");
            return field.get(null).toString();
        } catch (Throwable t) {
            // ignored
        }
        try {
            Field field = this.getClass().getField("TOOLNAME");
            return field.get(null).toString();
        } catch (Throwable t) {
            // ignored
        }
        return this.getClass().getSimpleName();
    }

    /**
     * Doing execution and return if the execution is succeeded.
     * @return
     * @throws Exception
     */
    public abstract boolean exec() throws Exception;
    
    public final boolean exec(String[] args) throws Exception {
        if (!processArgs(args)) {
            return false;
        }
        return exec();
    }

    /**
     * This method is overrided to use options prepared in {@link #prepareOptions(Options)}
     * to print help info.
     */
    public void usage(PrintWriter out) {
        out.println(this.comment());
        assureOptions();
        options.printHelpInfo(out, getToolName());
    }
}
