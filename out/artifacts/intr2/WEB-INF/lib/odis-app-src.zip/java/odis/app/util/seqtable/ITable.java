package odis.app.util.seqtable;

import java.io.IOException;
import java.util.List;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

/**
 * 和数据库概念类似的一个table。
 * 
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Apr 16, 2007
 */
public interface ITable <K extends IWritableComparable, V extends IWritable> {

    /**
     * key value pair
     * @author Feng Jiang (Feng.a.Jiang@gmail.com)
     */
    public static class Pair<K, V> {

        private K key;

        private V value;

        public K getKey() {
            return key;
        }

        public void setKey(K key) {
            this.key = key;
        }

        public V getValue() {
            return value;
        }

        public void setValue(V value) {
            this.value = value;
        }

    }

    /**
     * 返回第一个KEY为key的Value。
     * @param key
     * @return
     */
    public V selectValue(K key);

    /**
     * 返回所有KEY为key的value list。
     * @param key
     * @return
     */
    public List<V> selectValues(K key);

    /**
     * 得到索引位置为idx(从0开始)的Pair<K,V)。
     * <p>
     * 注意：对该pair中的key或value的修改都将在commit的时候对seqfile文件生效。
     * 
     * @param idx 索引的位置
     * @param key 存放结果key
     * @param value 存放结果value
     * @return
     */
    public Pair<K,V> getPair(int idx);

    /**
     * 将KEY为key的所有value全部更新为value。
     * 
     * @param key
     * @param value
     */
    public void updateValue(K key, V value);

    /**
     * 将KEY为key的、第idx个value更新为value。
     * 
     * @param key
     * @param value
     * @param idx
     */
    public void updateValue(K key, V value, int idx);

    /**
     * 将KEY为key的所有value中，从第start到第end（不包括end）都更新为value。
     * 
     * @param key
     * @param value
     * @param start
     * @param end
     */
    public void updateValue(K key, V value, int start, int end);

    /**
     * 插入一个K-V对。
     * 
     * @param key
     * @param value
     * @param idx
     */
    public void insert(K key, V value, int idx);

    /**
     * 删除KEY为key的记录，并这些记录返回。
     * 
     * @param key
     * @return
     */
    public List<V> delete(K key);

    /**
     * 记录的个数。
     * 
     * @return
     */
    public int size();

    /**
     * 该文件的记录列表的key是否是UNIQUE的。
     * 
     * @return 如果没有重复的key，返回true。
     */
    public boolean isKeyUnique();

    /**
     * 提交对该文件的修改。该操作的实质是删除原有文件，并写入新的文件。
     * 
     * @throws IOException
     */
    public void commit() throws IOException;

    /**
     * 提交对文件的修改，并用指定的key value的类进行输出到sequence file。
     * @param kClass
     * @param vClass
     * @throws IOException
     */
    public void commit(Class<?> kClass, Class<?> vClass) throws IOException;

}
