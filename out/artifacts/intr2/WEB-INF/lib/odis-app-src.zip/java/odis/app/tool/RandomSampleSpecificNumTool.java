/**
 * @(#)RandomSampleSpecificNumTool.java, 2009-1-7. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.file.SequenceFile;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.IMapper;
import odis.mapred.IReducer;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapOnlyTaskRunnable;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MapTaskRunnable;
import odis.mapred.ReduceTaskRunnable;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.LongHashPartitioner;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.Url;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

/**
 * 这个工具能够在输入数据中随机抽取n个数据，并且输出抽取的结果.
 * 注意由于运行时需要知道具体的IWritable类型，因此使用时需要确定当前运行目录下有相应的
 * IWritable类型存在，并且有正确实现了copyFields方法。
 * 例如，我们要在"/home/test/data_a"数据中随机抽取100个数据到"/home/test/data_a_sampled"中，可以使用
 * 如下的命令: <code>
 *   bin/odis.sh -wn workerNum odis.app.tool.RandomSampleSpecificNumTool -i /home/test/data_a -o /home/test/data_a_sampled -n 100
 * </code>
 * <p>
 * 输入的sampleNum太大或者数据本身的object太大时，可能将内存撑爆。
 * <p>
 * 输入参数
 * <ul>
 * <li>i: 输入数据的路径，除普通的数据目录外，该参数支持指定路径是一个part文件， 如/home/test/data_a/part-00000；</li>
 * <li>o: sample结果输出的路径；</li>
 * <li>n: sample的记录数目；</li>
 * <li>m: task上分配的内存大小；</li>
 * <li>filter: 如果只sample数据中符合某种条件的记录，则需要实现
 * odis.app.tool.RandomSampleFilter接口中的filter(IWritable key, IWritable
 * value)方法，对满足sample条件的记录该方法返回false，不满足需要filter的
 * 记录返回true，用该参数指定实现类的全名（完整包名+类名）。</li>
 * </ul>
 * <p>
 * 输出的数据具有如下的特点：
 * <ul>
 * <li>输出数据的part数目为1.</li>
 * <li>输出数据的key, value以及压缩属性都和输入数据一致.</li>
 * <li>输出数据的排序被随机打乱，key是url，则按UrlMd5Partitioner进行partition，
 * key是LongWritable，则按LongHashPartitioner进行partition，其它情况则按
 * SeqFileHashPartitioner进行partition</li>
 * </ul>
 * <p>
 * sample算法描述：
 * <p>
 * 假设从n条记录中随机sample出k条记录，k已知，而n事先并不知道，算法在一遍扫描过后完成sample。
 * <p>
 * 算法先将扫描的前k条记录放入sample数组中，继续向后扫描，对扫到的大于k的任意一条记录j，产生 一个[0, j-1]的随机整数r，如果r <
 * k，则sample数组r的位置替换为记录j，否则不做任何改动。
 * <p>
 * 证明：对任意的第i条记录，将扫描到第j条记录时i在sample数组中的这个事件记为s(j)， (j >=
 * i)，则根据上述算法，在扫第(j-1)条记录时i留在sample数组中的条件下，扫第j条i仍然留下的 概率：
 * <p>
 * 1 (j<=k) P(s(j)|s(j-1)) = { (j-1)/j (j>k) 只要随机数不是i在sample数组中的位置，i就可以继续留下。
 * 而扫第i条记录i被sample到数组中的概率：
 * <p>
 * 1 (i<=k) P(s(i)) = { k/i (i>k)
 * <p>
 * 则根据乘法公式，在n条记录全部扫描完成后，i被sample出的概率为从i开始一直到n，每一次扫描i都留 在sample数组中的概率的乘积，于是有：
 * <p>
 * 当i<k时：P(s(i))P(s(i+1)|s(i))P(s(i+2)|s(i+1))...P(s(n)|P(s(n-1)) =
 * P(s(i))P(s(i+1)|s(i))...P(s(k)|s(k-1))P(s(k+1)|s(k)...P(s(n)|P(s(n-1)) = 1 *
 * P(s(k+1)|s(k)P(s(k+2)|P(s(k+1)...P(s(n)|P(s(n-1)) = k/(k+1) * (k+1)/(k+2) *
 * ... * (n-1)/n = k/n
 * <p>
 * 当i>k时：P(s(i))P(s(i+1)|s(i))P(s(i+2)|s(i+1))...P(s(n)|P(s(n-1)) = k/i *
 * i/(i+1) * (i+1)/(i+2) * ... * (n-1)/n = k/n
 * <p>
 * 因此，对于任意一条记录i，在扫描完所有的n条记录后，i被sample出的概率是k/n，算法是等概率sample的。
 * 
 * @author yixun
 * @since 1.5
 * @version 1.0
 */
public class RandomSampleSpecificNumTool extends AbstractCoWorkToolWithArg {

    private static final Logger LOG = LogFormatter.getLogger(RandomSampleSpecificNumTool.class);

    public static final String TOOL_NAME = "RandomSampleSpecificNumTool";

    public static final String NAME_MAP_SAMPLENUM = TOOL_NAME + ".mapSampleNum";

    public static final String NAME_REDUCE_SAMPLENUM = TOOL_NAME
            + ".reduceSampleNum";

    public static final String NAME_KEYCLASS = TOOL_NAME + ".keyClass";

    public static final String NAME_VALUECLASS = TOOL_NAME + ".valueClass";

    public static final String NAME_RANDOM_SAMPLE_FILTER = TOOL_NAME
            + ".ramdomSampleFilter";

    private String input;

    private String output;

    private int sampleNum;

    private int taskHeapMemory;

    private String filterClassName;

    public String comment() {
        return "This tool samples specific number records from input.";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("o", "output", "set output path.");
        options.withOption("i", "input", "set input path.");
        options.withOption("n", "sampleNum", "set number of sample record.");
        options.withOption("m", "taskHeapMemory", "set heap memory of task.").setDefault(
                -1);
        options.withOption(
                "filter",
                "filter",
                "set filter class name, "
                        + "should inherit from odis.app.tool.RandomSampleFilter.").hasDefault();
    }

    @Override
    public boolean processOptions(Options options) throws Exception {
        input = options.getStringOpt("i");
        output = options.getStringOpt("o");
        sampleNum = options.getIntOpt("n");
        taskHeapMemory = options.getIntOpt("m");
        filterClassName = options.getStringOpt("filter");
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(input);
        Path outputPath = context.path(output);
        String fileName = inputPath.getName();
        LOG.info("input file name: " + fileName);
        Path tempInputPath = null;
        if (fileName.startsWith("part-")) {
            tempInputPath = MapReduceHelper.createTempDir(fs,
                    context.tempPath(TOOL_NAME), inputPath.getParent());
            Path part = tempInputPath.cat(CoWorkUtils.getPartID(0));
            fs.link(inputPath, part);
            LOG.info("link input " + inputPath.getAbsolutePath() + " to "
                    + tempInputPath.getAbsolutePath());
            inputPath = tempInputPath;
        }
        int partNum = MapReduceHelper.getContinuousPartCount(fs, inputPath);
        LOG.info("partNum = " + partNum);
        if (partNum < 1) {
            LOG.info("part number for src error.");
            return false;
        }
        SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                inputPath.cat(CoWorkUtils.getPartID(0)));
        Class<? extends IWritableComparable> keyClass = reader.getKeyClass().asSubclass(
                IWritableComparable.class);
        Class<? extends IWritable> valueClass = reader.getValueClass();
        String keyClassName = keyClass.getName();
        String valueClassName = valueClass.getName();
        LOG.info("keyClassName = " + keyClassName);
        LOG.info("valueClassName = " + valueClassName);

        MapOnlyJobDef job;
        if (partNum == 1) {
            job = context.createMapOnlyJob(TOOL_NAME, nWorker);
        } else {
            job = context.createMapReduceJob(TOOL_NAME, nWorker);
            MapReduceJobDef mapReduceJob = (MapReduceJobDef) job;
            Class<? extends BasicPartitioner> partitionerClass;
            if (keyClass.equals(Url.class)) {
                partitionerClass = UrlMd5Partitioner.class;
            } else if (keyClass.equals(LongWritable.class)) {
                partitionerClass = LongHashPartitioner.class;
            } else {
                partitionerClass = SeqFileHashPartitioner.class;
            }
            LOG.info("using partitioner: " + partitionerClass.getName());
            mapReduceJob.setReducer(SampleMR.class);
            mapReduceJob.setReduceNumber(1);
            mapReduceJob.setMergeKeyValClass(keyClass, valueClass);
            mapReduceJob.setPartitionerClass(partitionerClass);
            mapReduceJob.setWalkerClass(ReuseWalker.class);
        }
        MapReduceHelper helper = new MapReduceHelper(context, job);
        LOG.info("input is " + inputPath.getAbsolutePath());
        helper.addReadInputDir(inputPath, null);
        job.setMapper(SampleMR.class);
        job.setMapNumber(partNum);
        job.setPerUnitSplit(true);
        // output channels
        helper.addUpdateOutputDir(0, outputPath, keyClass, valueClass, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        //set parameters.
        int mapSampleNum = (int) Math.ceil((double) sampleNum / partNum);
        job.getConfig().setInt(NAME_MAP_SAMPLENUM, mapSampleNum);
        job.getConfig().setInt(NAME_REDUCE_SAMPLENUM, sampleNum);
        job.getConfig().setProperty(NAME_KEYCLASS, keyClassName);
        job.getConfig().setProperty(NAME_VALUECLASS, valueClassName);
        job.getConfig().setProperty(NAME_RANDOM_SAMPLE_FILTER, filterClassName);
        if (taskHeapMemory != -1) {
            job.setTaskHeapSize(taskHeapMemory);
        }
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess())
            return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());

        if (tempInputPath != null && fs.exists(tempInputPath)) {
            LOG.info("delete temp input: " + tempInputPath.getAbsolutePath());
            fs.delete(tempInputPath);
        }
        return true;
    }

    public static class SampleMR implements IMapper<IWritable, IWritable>,
            IReducer<IWritable, IWritable> {

        private Object[][] sampleRecords;

        private int sampleNum;

        private Class<?> keyClass;

        private Class<?> valueClass;

        private Method keyCopyFieldsMethod;

        private Method valueCopyFieldsMethod;

        private int sampleIdx = 0;

        private Random random = new Random();

        private Counter realSampleCounter;

        private Counter filterCounter;

        private Counter reflectionErrorCounter;

        private RandomSampleFilter filter;

        public void configure(JobDef job, TaskRunnable task) {

            if (task instanceof MapOnlyTaskRunnable
                    || task instanceof MapTaskRunnable) {
                String filterClassName = job.getConfig().getString(
                        NAME_RANDOM_SAMPLE_FILTER);
                if (filterClassName != null && !filterClassName.equals("")) {
                    try {
                        filter = (RandomSampleFilter) Class.forName(
                                filterClassName).newInstance();
                    } catch (InstantiationException e) {
                        throw new TaskFatalException(e);
                    } catch (IllegalAccessException e) {
                        throw new TaskFatalException(e);
                    } catch (ClassNotFoundException e) {
                        throw new TaskFatalException(e);
                    }
                }
                sampleNum = job.getConfig().getInt(NAME_MAP_SAMPLENUM);
            } else if (task instanceof ReduceTaskRunnable) {
                sampleNum = job.getConfig().getInt(NAME_REDUCE_SAMPLENUM);
            } else {
                throw new TaskFatalException("task error.");
            }

            sampleRecords = new Object[sampleNum][2];
            String keyClassName = job.getConfig().getString(NAME_KEYCLASS);
            String valueClassName = job.getConfig().getString(NAME_VALUECLASS);

            try {
                keyClass = Class.forName(keyClassName);
                valueClass = Class.forName(valueClassName);
                keyCopyFieldsMethod = keyClass.getMethod("copyFields",
                        IWritable.class);
                valueCopyFieldsMethod = valueClass.getMethod("copyFields",
                        IWritable.class);
            } catch (Exception e) {
                throw new TaskFatalException(e);
            }
            reflectionErrorCounter = task.getCounter("reflectionErrorCounter");
            realSampleCounter = task.getCounter("realSampleCounter");
            filterCounter = task.getCounter("filterCounter");
        }

        public void mapEnd(ICollector collector) {
            doCollect(collector);
        }

        /**
         * @param collector
         */
        private void doCollect(ICollector collector) {
            int realSampleNum = 0;
            for (int i = 0; i < sampleRecords.length; ++i) {
                if (sampleRecords[i][0] != null && sampleRecords[i][1] != null) {
                    realSampleNum++;
                    collector.collect(sampleRecords[i][0], sampleRecords[i][1]);
                }
            }
            realSampleCounter.inc(realSampleNum);
        }

        public void map(IWritable key, IWritable value, ICollector collector) {
            if (filter != null && filter.filter(key, value)) {
                filterCounter.inc();
                return;
            }
            try {
                doSample(key, value);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "reflection error.", e);
                reflectionErrorCounter.inc();
            }
        }

        public void mapBegin() {

        }

        public void reduce(IWritable key,
                IWritablePairWalker<IWritable, IWritable> values,
                ICollector collector) {
            try {
                while (values.moreValue()) {
                    doSample(key, values.getValue());
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING, "reflection error.", e);
                reflectionErrorCounter.inc();
            }

        }

        /**
         * sample记录。 算法描述： 假设要sample出的数目sampleNum = 5，顺序扫描每一条record，把前5个先放入
         * sample url的数组中，当扫描序号大于等于5时，产生一个0到扫描序号的随机数，
         * 如果这个随机数小于5，则置换掉随机数所在位置的record，否则不做任何操作。
         * 这个算法能保证从实现未知数目的record中等概率的sample出确定数目的record。
         * 
         * @param key
         *            key of record
         * @param value
         *            value of record
         * @throws InstantiationException
         * @throws IllegalAccessException
         * @throws InvocationTargetException
         */
        private void doSample(IWritable key, IWritable value)
                throws InstantiationException, IllegalAccessException,
                InvocationTargetException {
            if (sampleIdx < sampleNum) {
                if (sampleRecords[sampleIdx][0] == null) {
                    sampleRecords[sampleIdx][0] = keyClass.newInstance();
                }
                if (sampleRecords[sampleIdx][1] == null) {
                    sampleRecords[sampleIdx][1] = valueClass.newInstance();
                }
                keyCopyFieldsMethod.invoke(sampleRecords[sampleIdx][0], key);
                valueCopyFieldsMethod.invoke(sampleRecords[sampleIdx][1], value);
            } else {
                int ran = random.nextInt(sampleIdx);
                if (ran < sampleNum) {
                    keyCopyFieldsMethod.invoke(sampleRecords[ran][0], key);
                    valueCopyFieldsMethod.invoke(sampleRecords[ran][1], value);
                }
            }
            sampleIdx++;
        }

        public void reduceBegin() {

        }

        public void reduceEnd(ICollector collector) {
            doCollect(collector);
        }

    }

}
