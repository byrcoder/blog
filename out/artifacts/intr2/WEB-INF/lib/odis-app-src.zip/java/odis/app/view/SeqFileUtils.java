/**
 * @(#)SeqFileUtils.java, 2007-5-21. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.view;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import odis.cowork.CoWorkUtils;
import odis.file.CompressUtils.CompressAlgo;
import odis.file.IRecordWriter;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import toolbox.collections.ArrayUtils;
import toolbox.misc.ClassUtils;

/**
 * Utilities to read or write small data to sequence file.
 * 
 * @author river
 */
public class SeqFileUtils {

    private static boolean isDataFileName(String filename) {
        return filename.equals(IndexedFile.DATA_FILE_NAME)
                || filename.equals(IndexedFile.COMPRESSED_DATA_FILE_NAME);
    }

    private static boolean isIndexFileName(String filename) {
        return filename.equals(IndexedFile.INDEX_FILE_NAME);
    }

    /**
     * Load keys and values into map from file or database.
     * 
     * @param fs
     * @param file
     * @return
     * @throws IOException
     */
    public static Map<Object, Object> loadToMap(IFileSystem fs, Path file)
            throws IOException {
        Map<Object, Object> map = new HashMap<Object, Object>();
        List<Path> inputs = new LinkedList<Path>();
        if (fs.isFile(file)) {
            inputs.add(file);
        } else {
            FileInfo[] infos = fs.listFiles(file);
            if (infos.length == 2) {
                String name1 = infos[0].getPath().getName();
                String name2 = infos[1].getPath().getName();
                if (isDataFileName(name1) && isIndexFileName(name2))
                    inputs.add(file.cat(name1));
                else if (isDataFileName(name2) && isIndexFileName(name1))
                    inputs.add(file.cat(name2));
                if (inputs.size() == 0) {
                    // just normal file with 2 part
                    inputs.add(infos[0].getPath());
                    inputs.add(infos[1].getPath());
                }
            } else {
                for (FileInfo info: fs.listFiles(file)) {
                    if (info.isDir()) {
                        Path dataPath = info.getPath().cat(
                                IndexedFile.DATA_FILE_NAME);
                        if (fs.exists(dataPath) && fs.isFile(dataPath)) {
                            inputs.add(dataPath);
                        }
                        dataPath = info.getPath().cat(
                                IndexedFile.COMPRESSED_DATA_FILE_NAME);
                        if (fs.exists(dataPath) && fs.isFile(dataPath)) {
                            inputs.add(dataPath);
                        }
                    } else {
                        inputs.add(info.getPath());
                    }
                }
            }
        }

        for (Path input: inputs) {
            SequenceFile.Reader reader = new SequenceFile.Reader(fs, input);
            try {
                Object key = ClassUtils.newInstance(reader.getKeyClass());
                Object value = ClassUtils.newInstance(reader.getValueClass());
                while (reader.next(key, value)) {
                    map.put(key, value);
                    key = ClassUtils.newInstance(reader.getKeyClass());
                    value = ClassUtils.newInstance(reader.getValueClass());
                }
            } finally {
                reader.close();
            }
        }

        return map;
    }

    /**
     * Save map[key--value] to sequence file.
     * 
     * @param fs
     * @param file
     * @param map
     * @throws IOException
     */
    public static void saveMapToFile(IFileSystem fs, Path file, Map map)
            throws IOException {
        saveMapToFile(fs, file, map, false);
    }

    /**
     * Save map[key--value] to sequence file or indexed file.
     * 
     * @param fs
     * @param file
     * @param map
     * @param indexed
     * @throws IOException
     */
    public static void saveMapToFile(IFileSystem fs, Path file, Map map,
            boolean indexed) throws IOException {
        saveMapToFile(fs, file, map, indexed, -1, false, CompressAlgo.LZO);
    }

    /**
     * Save map[key--value] to one single file ordered by key.
     * 
     * @param fs
     * @param file
     * @param map
     *            , should not be empty
     * @param indexed
     * @param compressBlockSize
     * @param objectCompressed
     * @param compressAlgo
     * @throws IOException
     */
    public static void saveMapToFile(IFileSystem fs, Path file, Map map,
            boolean indexed, int compressBlockSize, boolean objectCompressed,
            CompressAlgo compressAlgo) throws IOException {
        if (map.isEmpty()) {
            throw new IOException(
                    "cannot determine key/valclass because map is empty");
        }
        Map.Entry entry = (Map.Entry) map.entrySet().iterator().next();

        Class keyClass = entry.getKey().getClass();
        Class valClass = entry.getValue().getClass();

        saveMapToFile(fs, file, map, indexed, compressBlockSize,
                objectCompressed, compressAlgo, keyClass, valClass);
    }

    /**
     * Save map[key--value] to one single file ordered by key.
     * 
     * @param fs
     * @param file
     * @param map
     * @param indexed
     *            if the output should be one IndexedFile
     * @param compressBlockSize
     * @param objectCompressed
     * @param compressAlgo
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public static void saveMapToFile(IFileSystem fs, Path file, Map map,
            boolean indexed, int compressBlockSize, boolean objectCompressed,
            CompressAlgo compressAlgo, Class keyClass, Class valClass)
            throws IOException {
        Object[] keys = new Object[map.size()];
        Object[] values = new Object[map.size()];
        int index = 0;
        for (Iterator it = map.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            keys[index] = entry.getKey();
            values[index] = entry.getValue();
            index++;
        }
        ArrayUtils.sortArrays(keys, values);

        IRecordWriter<Object, Object> writer;
        if (indexed) {
            if (compressBlockSize > 0) {
                writer = new IndexedFile.CompressedWriter(fs, file, keyClass,
                        valClass, true, compressBlockSize);
            } else if (compressBlockSize == 0) {
                writer = new IndexedFile.CompressedWriter(fs, file, keyClass,
                        valClass, true,
                        SequenceFile.CompressedWriter.DEFAULT_BLOCK_SIZE);
            } else {
                writer = new IndexedFile.Writer(fs, file, keyClass, valClass);
            }
        } else {
            if (compressBlockSize > 0) {
                writer = new SequenceFile.CompressedWriter(fs, file, keyClass,
                        valClass, true, compressBlockSize, objectCompressed,
                        compressAlgo);
            } else if (compressBlockSize == 0) {
                writer = new SequenceFile.CompressedWriter(fs, file, keyClass,
                        valClass, true,
                        SequenceFile.CompressedWriter.DEFAULT_BLOCK_SIZE,
                        objectCompressed, compressAlgo);
            } else if (objectCompressed) {
                writer = new SequenceFile.ObjectCompressWriter(fs, file,
                        keyClass, valClass, true, compressAlgo);
            } else {
                writer = new SequenceFile.Writer(fs, file, keyClass, valClass,
                        true);
            }
        }

        try {
            for (int i = 0; i < keys.length; i++) {
                writer.write(keys[i], values[i]);
            }
        } finally {
            writer.close();
        }
    }

    public static void saveMapToDatabase(FileSystem fs, Path dbPath,
            int partitionNumber, BasicPartitioner partitioner, Map map)
            throws IOException {
        saveMapToDatabase(fs, dbPath, partitionNumber, partitioner, map, false);
    }

    public static void saveMapToDatabase(FileSystem fs, Path dbPath,
            int partitionNumber, BasicPartitioner partitioner, Map map,
            boolean indexed) throws IOException {
        saveMapToDatabase(fs, dbPath, partitionNumber, partitioner, map,
                indexed, -1, false, CompressAlgo.LZO);
    }

    /**
     * Save the map as one database with specified partitioner and partition
     * number.
     * 
     * @param fs
     * @param dbPath
     * @param partitionNumber
     * @param partitioner
     * @param map
     * @param indexed
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public static void saveMapToDatabase(FileSystem fs, Path dbPath,
            int partitionNumber, BasicPartitioner partitioner, Map map,
            boolean indexed, int compressBlockSize, boolean objectCompressed,
            CompressAlgo compressAlgo) throws IOException {
        if (map.isEmpty())
            throw new IOException("map is empty");

        Map[] parts = new HashMap[partitionNumber];
        for (int i = 0; i < parts.length; i++)
            parts[i] = new HashMap<Object, Object>();

        Class keyClass = null;
        Class valClass = null;

        for (Iterator it = map.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            int partition = partitioner.getPartition(entry.getKey(),
                    entry.getValue(), partitionNumber);
            parts[partition].put(entry.getKey(), entry.getValue());
            keyClass = entry.getKey().getClass();
            valClass = entry.getValue().getClass();
        }

        for (int i = 0; i < partitionNumber; i++) {
            saveMapToFile(fs, dbPath.cat(CoWorkUtils.getPartID(i)), parts[i],
                    indexed, compressBlockSize, objectCompressed, compressAlgo,
                    keyClass, valClass);
        }
    }

}
