/**
 * 
 */
package odis.app.serialize;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Stack;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * TreeWritable存储了一棵left-child, right-sibling方式表示的树。
 * 其中的方法全部采用迭代的方式以提高效率。
 * 这是一个抽象类，继承出自己的类来使用：
 * 
 * MyTree extends TreeWritable<MyTreeNodeValue, MyTree> {
 *  ...
 * }
 * 
 * @author why
 * 
 * @param <NodeValueType> 树的节点中存储的值类型
 * @param <TreeNodeType> 子类本身
 */
public abstract class TreeWritable<NodeValueType extends IWritable, 
                                    TreeNodeType extends TreeWritable<NodeValueType, TreeNodeType>> 
                                implements IWritable {

    protected NodeValueType nodeValue = newNodeValue();
    protected TreeNodeType parent = null;
    protected TreeNodeType firstChild = null;
    protected TreeNodeType nextSibling = null;
    
    /**
     * create a new instance of <NodeValueType> 
     * @return new instance of <NodeValueType> class
     */
    abstract protected NodeValueType newNodeValue();
    
    /**
     * create a new instance of TreeWritable
     * @return new instance of this class
     */
    abstract protected TreeNodeType newTreeNode();
    
    /**
     * clear the NodeValue 
     */
    abstract protected void clearNodeValue();

    /**
     * 构造一个空节点
     */
    public TreeWritable() {
    }
    
    /**
     * 构造一个空节点，同时使得它成为指定节点的子节点
     */
    @SuppressWarnings("unchecked")
    public TreeWritable(TreeNodeType parent) {
        if (parent!=null) parent.addChild((TreeNodeType)this);
    }
    
    /**
     * 将以本节点为根的子树分离出来。
     * 如果本节点是一棵树中的内节点，执行后的效果是以它为根的子树成为了独立的一棵树。
     */
    public void detach() {
        if (parent==null) return; // 本节点已经是树的根节点
        
        TreeNodeType pc = parent.firstChild;
        if (this==pc) {
            // 本节点是父节点的第一个孩子
            parent.firstChild = nextSibling;
        } else {
            TreeNodeType prev = pc;
            TreeNodeType next = prev.nextSibling;
            while(next!=null && next!=this) {
                prev = next;
                next = prev.nextSibling;
            }
            if (next==null) 
                throw new IllegalStateException("cannot find me in the parent's children");
            prev.nextSibling = nextSibling;
        }
        parent = null;
        nextSibling = null;
    }
    
    /**
     * 清空本树所有数据
     */
    @SuppressWarnings("unchecked")
    public void clear() {
        detach();
        TreeNodeType p = null;
        
        LinkedList<TreeNodeType> children = 
            new LinkedList<TreeNodeType>();
        children.add((TreeNodeType)this);
        
        while((p = children.poll())!=null) {
            p.clearNodeValue();
            p.parent = null;
            
            TreeNodeType child = p.firstChild;
            while(child!=null) {
                children.add(child);
                child = child.nextSibling;
            }
            
            p.firstChild = null;
            p.nextSibling = null;
        }
    }
    
    /**
     * @return child number of this node
     */
    public int getChildNumber() {
        int childNum = 0;
        TreeNodeType child = firstChild;
        while(child!=null) {
            ++ childNum;
            child = child.nextSibling;
        }
        return childNum;
    }
    
    /**
     * @return first child of this node
     */
    public TreeNodeType firstChild() {
        return firstChild;
    }
    
    /**
     * @return next sibling of this node
     */
    public TreeNodeType nextSibling() {
        return nextSibling;
    }
    
    /**
     * @return parent of this node
     */
    public TreeNodeType parent() {
        return parent;
    }

    /**
     * @return node value stored in this node
     */
    public NodeValueType getNodeValue() {
        return nodeValue;
    }
    
    /**
     * add a child to this node
     * @param child
     */
    @SuppressWarnings("unchecked")
    public void addChild(TreeNodeType child) {
        child.detach();
        
        if (firstChild==null) {
            firstChild = child;
        } else {
            TreeNodeType prev = firstChild;
            TreeNodeType next = prev.nextSibling;
            while(next!=null) {
                prev = next;
                next = prev.nextSibling;
            }
            prev.nextSibling = child;
        }
        child.parent = (TreeNodeType)this;
    }
    
    /**
     * remove a child from the children of this node
     * @param child
     */
    public boolean removeChild(TreeNodeType child) {
        assert child!=null;
        
        if (firstChild==null) {
            // no child
            return false;
        } else if (firstChild==child) {
            // first child
            child.parent = null;
            firstChild = child.nextSibling;
            child.nextSibling = null;
            return true;
        } else {
            TreeNodeType prev = firstChild;
            TreeNodeType next = prev.nextSibling;
            while(next!=null && next!=child) {
                prev = next;
                next = prev.nextSibling;
            }
            if (next!=null) {
                child.parent = null;
                prev.nextSibling = child.nextSibling;
                child.nextSibling = null;
                return true;
            }
            return false;
        }
    }
    
    /**
     * @return a copy of this tree
     */
    public TreeNodeType copy() {
        TreeNodeType t = newTreeNode();
        t.copyFields(this);
        return t;
    }

    /**
     * 从DataInput中读取数据，构造出以本节点为根的一棵树
     */
    @SuppressWarnings("unchecked")
    public void readFields(DataInput in) throws IOException {
        clear();
        
        TreeNodeType p = (TreeNodeType)this;
        Stack<Integer> childNums = new Stack<Integer>();
        childNums.push(1); // root's parent, null node
        do {
            p.nodeValue.readFields(in);
            
            int childNum = CDataInputStream.readVInt(in);
            if (childNum>0) {
                childNums.push(childNum);
                TreeNodeType child = newTreeNode();
                p.addChild(child);
                p = child;
            } else {
                int leftSiblingNum = 0;
                while (p!=null && (leftSiblingNum = childNums.pop()-1)==0) {
                    p = p.parent;
                }
                if (p!=null) {
                    childNums.push(leftSiblingNum);
                    TreeNodeType child = newTreeNode();
                    p.nextSibling = child;
                    child.parent = p.parent;
                    p = child;
                }
            }
            
        } while (p!=null);
    }

    /**
     * 将以本节点为根的树的数据写入到DataOutput中
     */
    @SuppressWarnings("unchecked")
    public void writeFields(DataOutput out) throws IOException {
        TreeNodeType p = (TreeNodeType) this;
        do {
            p.nodeValue.writeFields(out);
            
            int childNum = p.getChildNumber();
            CDataOutputStream.writeVInt(childNum, out);
            
            if (childNum>0) {
                // has children
                p = p.firstChild;
            } else {
                while(p!=null && p.nextSibling==null) p = p.parent;
                if (p!=null) p = p.nextSibling;
            }
            
        } while(p!=null);
    }
    
    /**
     * 拷贝另外一棵树
     */
    @SuppressWarnings("unchecked")
    public IWritable copyFields(IWritable value) {
        if (this==value) return this;
        TreeNodeType o = (TreeNodeType) value;
        
        clear();
        
        TreeNodeType p = (TreeNodeType) this;
        
        do {
            p.nodeValue.copyFields(o.nodeValue);
            
            if (o.firstChild!=null) {
                TreeNodeType child = newTreeNode();
                p.addChild(child);
                p = child;
                o = o.firstChild;
            } else {
                while(o!=null && o.nextSibling==null) {
                    o = o.parent;
                    p = p.parent;
                }
                if (o!=null) {
                    TreeNodeType child = newTreeNode();
                    child.parent = p.parent;
                    p.nextSibling = child;
                    p = child;
                    o = o.nextSibling;
                }
            }
        } while(o!=null);
        
        return this;
    }

    /**
     * 判断是否相同的树
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object obj) {
        if (this==obj) return true;
        if (!(obj instanceof TreeWritable) || obj==null) return false;
        
        TreeNodeType o = (TreeNodeType) obj;
        TreeNodeType p = (TreeNodeType) this;
        
        do {
            if (!o.nodeValue.equals(p.nodeValue)) return false;
            
            if (o.firstChild!=null && p.firstChild!=null) {
                o = o.firstChild;
                p = p.firstChild;
            } else if (o.firstChild==null && p.firstChild==null) {
                while(o!=null && o.nextSibling==null && p!=null && p.nextSibling==null) {
                    o = o.parent;
                    p = p.parent;
                }
                if (o!=null && p!=null) {
                    o = o.nextSibling;
                    p = p.nextSibling;
                }
            } else return false;
        } while(o!=null && p!=null);
     
        return p==o; // all null is true, one null is false
    }

    @SuppressWarnings("unchecked")
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        TreeNodeType p = (TreeNodeType) this;
        
        do {
            sb.append("(" + p.nodeValue + ")");
            
            if (p.firstChild!=null) {
                sb.append("{");
                p = p.firstChild;
            } else {
                while(p!=null && p.nextSibling==null) {
                    p = p.parent;
                    if (p!=null) sb.append("}");
                }
                if (p!=null) {
                    p = p.nextSibling;
                }
            }
        } while(p!=null);
        
        return sb.toString();
    }
    

}
