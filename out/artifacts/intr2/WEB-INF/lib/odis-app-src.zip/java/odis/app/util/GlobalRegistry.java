/**
 * @(#)GlobalRegistry.java, 2007-6-29. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.XMLConfiguration;

import toolbox.misc.LogFormatter;

/**
 * Interface for registry based on odfs. We can save and load
 * persistent data in transactional manner.
 * 
 * The sample code to update the registry in transactional manner:
 * <code>
 *     GlobalRegistry registry = ...;
 *     registry.lock();
 *     try {
 *         XMLConfiguration data = registry.get();
 *         ... // read the properties out and change the properties in data
 *         registry.save();
 *     } finally {
 *         registry.release();
 *     }
 * </code> 
 * @author river
 *
 */
public class GlobalRegistry {
    public static final Logger LOG = LogFormatter.getLogger(GlobalRegistry.class);
    
    private IFileSystem fs;
    private Path path;
    private boolean locked = false;
    private XMLConfiguration configData = null;
    
    /**
     * Create the registry interface.
     * @param fs
     * @param path
     */
    public GlobalRegistry(IFileSystem fs, Path path) {
        this.fs = fs;
        this.path = path;
    }
    
    /**
     * Lock the registry and deny and read/write by others.
     * @throws IOException
     */
    public synchronized void lock() throws IOException {
        if (locked) {
            throw new IOException("double lock checked");
        }
        fs.getLock(path, FileSystem.EXCLUSIVE_LOCK);
        configData = null;
        locked = true;
    }

    /**
     * Save the modified data, it is the same as save(get()).
     * @see #save(XMLConfiguration)
     * @throws IOException
     */
    public synchronized void save() throws IOException {
        // check lock
        if (!locked) {
            throw new IOException("registry is not locked");
        }
        save(get());
    }
    
    /**
     * Save the configurations, this method can only be called after {@link #lock()}.
     * @param data
     * @throws IOException
     */
    public synchronized void save(XMLConfiguration data) throws IOException {
        // check lock
        if (!locked) {
            throw new IOException("registry is not locked");
        }
        
        // save configuration to buffer
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            data.save(bos);
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "write configuration to buffer failed", e);
            throw new IOException("write configuration to buffer failed");
        }
        bos.close();
        
        // save config buffer to temp file first
        Path tmpPath = new Path(path.getAbsolutePath() + "~");
        OutputStream os = fs.create(tmpPath, true);
        try {
            os.write(bos.toByteArray());
        } finally {
            os.close();
        }

        // replace target file with temp file
        fs.delete(path);
        fs.rename(tmpPath, path);
        
        // replace in-memory copy if not the same
        if (configData != data) {
            configData = data;
        }
        
    }
    
    /**
     * Get the data of registry. This method can be called with/without
     * lock. If the registry is not locked, we cannot guarantee that 
     * the registry data should not be modified by others.
     * If there's no data/file for this registry, one empty configuration
     * is returned.
     * 
     * @return
     * @throws IOException
     */
    public synchronized XMLConfiguration get() throws IOException {
        if (configData == null) {
            XMLConfiguration newConfig = new XMLConfiguration();
            newConfig.setRootElementName("registry");
            if (fs.exists(path)) {
                if (!locked) {
                    fs.getLock(path, FileSystem.SHARED_LOCK);
                }
                try {
                    byte [] buf = new byte[(int)fs.getLength(path)];
                    InputStream is = fs.open(path);
                    try {
                        is.read(buf);
                    } finally {
                        is.close();
                    }
                    try {
                        newConfig.load(new ByteArrayInputStream(buf));
                    } catch (ConfigurationException e) {
                        throw new IOException("configuration parse failed");
                    }
                } finally {
                    if (!locked) {
                        fs.releaseLock(path);
                    }
                }
            }
            configData = newConfig;
        }
        
        return configData;
    }
    
    /**
     * Release the lock. Please put this call in finally block and make
     * sure it is called when {@link #lock()} is called.
     * @throws IOException
     */
    public void release() throws IOException {
        fs.releaseLock(path);
        locked = false;
    }
    
    /**
     * This method is a short way to set value for one key. It is the
     * same as "lock(); get() and modify and data; save(); release()". 
     * @param key
     * @param value
     * @throws IOException
     */
    public void setProperty(String key, Object value) throws IOException {
        lock();
        try {
            XMLConfiguration config = get();
            config.setProperty(key, value);
            save(config);
        } finally {
            release();
        }
    }
    
    /**
     * Remove subtree start with given key.
     * @param key
     * @throws IOException
     */
    public void clearSubTree(String key) throws IOException {
        lock();
        try {
            XMLConfiguration config = get();
            config.clearTree(key);
            save(config);
        } finally {
            release();
        }
    }
    
    /**
     * This method is a short way to get value for one key. It is the 
     * same as "get().getProperty(key)".
     *  
     * @param key
     * @return
     * @throws IOException
     */
    public Object getProperty(String key) throws IOException {
        return get().getProperty(key);
    }
    
    /**
     * @see #getProperty(String).
     * @param key
     * @param def
     * @return
     * @throws IOException
     */
    public int getInt(String key, int def) throws IOException {
        return get().getInt(key, def);
    }
    
    /**
     * @see #getProperty(String)
     * @param key
     * @param def
     * @return
     * @throws IOException
     */
    public long getLong(String key, long def) throws IOException {
        return get().getLong(key, def);
    }
    
    /**
     * @see #getProperty(String)
     * @param key
     * @param def
     * @return
     * @throws IOException
     */
    public String getString(String key, String def) throws IOException {
        return get().getString(key, def);
    }
    
    private String xmlToString(HierarchicalConfiguration config) throws IOException {
        // save configuration to buffer
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            XMLConfiguration xmlConfig;
            if (config instanceof XMLConfiguration) {
                xmlConfig = (XMLConfiguration) config;
            } else {
                xmlConfig = new XMLConfiguration();
                for (Iterator it = config.getKeys(); it.hasNext(); ) {
                    String key = (String) it.next();
                    xmlConfig.setProperty(key, config.getProperty(key));
                }
                xmlConfig.setRootElementName("registry");
            }
            xmlConfig.save(bos, "UTF-8");
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "write configuration to buffer failed", e);
            throw new IOException("write configuration to buffer failed");
        }
        bos.close();

        return new String(bos.toByteArray(), "UTF-8");
    }
    
    /**
     * Save the whole registry as string.
     * @return
     * @throws IOException
     */
    public String format() throws IOException {
        return xmlToString(get());
    }
    
    /**
     * Save subtree of the whole registry as string.
     * @param subTree
     * @return
     * @throws IOException
     */
    public String format(String subTree) throws IOException {
        return xmlToString(get().configurationAt(subTree));
    }
}
