/**
 * @(#)AbstractFilterTool.java, 2008-2-4. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import odis.cowork.CoWorkUtils;
import odis.cowork.JobConfig;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.IndexedFileInputFormat;
import odis.mapred.lib.IndexedFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.IWritable;
import odis.tools.AbstractCoWorkTool;
import odis.tools.MapReduceHelper;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Abstract tool to filter data.
 * @author river
 */
public class DbFilterTool extends AbstractCoWorkTool {
    public static final Logger LOG = LogFormatter.getLogger(DbFilterTool.class);
    
    private Options options;
    public DbFilterTool() {
        options = new Options();
        options.withOption("filter", "filter class", "set the filter class");
        options.withOption("in", "input", "Set the input database to filter. This option can " +
        		"be used a lot of times to add more than one inputs");
        options.withOption("out", "output", "set the output directory");
        options.withOption("rn", "reduce number", "set the reduce number, when this value is not " +
        		"set and there is only one input, map only is used").hasDefault();
        options.withOption("p", "partition_class", "set the partitioner " +
        		"class to be used for reduce").hasDefault();
        
        // because we should use options for filter, we must accept unknown options
        options.ignoreUnknownOption();
    }
    
    @Override
    public String comment() {
        return "Data filter";
    }

    @Override
    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "dbfilter");
    }

    protected String [] args;
    protected String filterClass;
    protected String [] inputNames;
    protected String outputName;
    protected int reduceNumber;
    private boolean mapOnly = true;
    private String partitionerClass;
    
    @Override
    protected boolean processArgs(String[] args) throws Exception {
        try {
            options.parse(args);
        } catch(OptionParseException e) {
            out.println("error : " + e.getMessage());
            usage(out);
            return false;
        }
        
        inputNames = options.getOpt("in");
        outputName = options.getStringOpt("out");
        partitionerClass = options.getStringOpt("p", null);
        reduceNumber = options.getIntOpt("rn", -1);
        filterClass = options.getStringOpt("filter");
        
        mapOnly = inputNames.length == 1 && reduceNumber <= 0;
        if (!mapOnly && reduceNumber <= 0) {
            usage(out);
            return false;
        }
        this.args = args;
        
        return true;
    }

    private static HashMap<String, String> predefinedFilters = new HashMap<String, String>();
    static {
        predefinedFilters.put("regexp", RegexpFilter.class.getName());
    }
    
    /**
     * The subclass can override this method to specify the filter.
     * Default implementation of this method returns the filter class specified
     * in command line.
     * @return
     */
    public static Filter getFilter(String name) throws ClassNotFoundException {
        if (name != null) {
            String predefined = predefinedFilters.get(name);
            if (predefined == null) 
                predefined = name;
            return (Filter)ClassUtils.newInstance(Class.forName(predefined));
        } else {
            throw new RuntimeException("no filter class specified");
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int worker) throws Exception {
        FileSystem fs = context.getFileSystem();

        MapOnlyJobDef job;
        if (mapOnly) {
            job = context.createMapOnlyJob("dbfilter", worker);
            job.setPerUnitSplit(true);
            job.setMapNumber(MapReduceHelper.getContinuousPartCount(fs, 
                    context.path(inputNames[0])));
        } else {
            job = context.createMapReduceJob("dbfilter", worker);
            job.setMapNumber(worker * mParallel);
        }
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        boolean isIndexedFile = false;
        Class keyClass = null, valClass = null;
        int compressBlockSize = 0;
        
        int idx = 0;
        for (String s : inputNames) {
            Path inputDir = context.path(s);
            if (!fs.exists(inputDir)) {
                throw new IOException("cannot find input dir : " + inputDir);
            } else {
                Path input;
                if (fs.isFile(inputDir)) {
                    // single file
                    input = helper.getTempOutput("input");
                    fs.mkdirs(input);
                    fs.link(inputDir, input.cat(CoWorkUtils.getPartID(0)));
                } else {
                    input = helper.getReadInput(inputDir);
                }
                
                FileInfo [] childs = fs.listFiles(input);
                boolean indexed = (fs.isDirectory(childs[0].getPath()));
                
                if (idx == 0) {
                    // extract first input information
                    isIndexedFile = indexed;
                    SequenceFile.Reader reader;
                    if (isIndexedFile)
                        reader = new SequenceFile.Reader(fs, childs[0].getPath().cat(IndexedFile.DATA_FILE_NAME));
                    else
                        reader = new SequenceFile.Reader(fs, childs[0].getPath());
                    try {
                        compressBlockSize = reader.getCompressBlockSize();
                        keyClass = reader.getKeyClass();
                        valClass = reader.getValueClass();
                    } finally {
                        reader.close();
                    }
                }
                job.addInputDir(input, indexed ? IndexedFileInputFormat.class : SeqFileInputFormat.class);
            }
            idx ++;
        }
        
        Filter filter = getFilter(filterClass);
        if (!filter.processArgs(args)) {
            LOG.log(Level.SEVERE, "process args in filter failed");
            return false;
        }
        
        if (filter.getOutputKeyClass() != null) {
            keyClass = filter.getOutputKeyClass();
            valClass = filter.getOutputValClass();
        }
        
        job.setMapper(Mapper.class);
        
        if (!mapOnly) {
            MapReduceJobDef mrJob = (MapReduceJobDef) job;
            mrJob.setMergeKeyValClass(keyClass, valClass);
            if (partitionerClass == null)
                mrJob.useDefaultHashPartitioner();
            else
                mrJob.setPartitionerClass((Class<? extends BasicPartitioner>)
                        Class.forName(partitionerClass));
            mrJob.setWalkerClass(ReuseWalker.class);
            mrJob.setReducer(IdentityReducer.class);
            mrJob.setReduceNumber(reduceNumber);
        }
        
        Path dstPath = context.path(outputName);
        job.addOutputDir(0, helper.getUpdateOutput(dstPath), keyClass, valClass, 
                isIndexedFile ? IndexedFileOutputFormat.class : SeqFileOutputFormat.class);
        if (compressBlockSize > 0) {
            GenericFileOutputFormat.setCompress(job, 0, compressBlockSize);
        }
        
        job.getConfig().setProperty(Mapper.NAME_FILTER_CLASS, filter.getClass().getName());
        job.getConfig().setProperty(Mapper.NAME_KEY_CLASS, keyClass.getName());
        job.getConfig().setProperty(Mapper.NAME_VAL_CLASS, valClass.getName());
        
        filter.prepareConfig(job.getConfig());
        
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printCounters(out, result.getCounters());
        
        return true;
    }

    /**
     * The filter interface.
     *
     * @author river
     *
     */
    public static interface Filter<K_SRC extends IWritable, V_SRC extends IWritable, 
    K_DST extends IWritable, V_DST extends IWritable> {
        
        /**
         * Process the arguments from command line.
         * @param args
         */
        public boolean processArgs(String [] args);
        
        /**
         * This method is called before job submitted.
         * @param config
         */
        public void prepareConfig(JobConfig config);
        
        /**
         * This method is called before task executed.
         * @param config
         * @param task
         */
        public void init(JobConfig config, TaskRunnable task);
        
        /**
         * The key class of output.
         * @return
         */
        public Class<? extends IWritable> getOutputKeyClass();
        
        /**
         * The value class of output.
         * @return
         */
        public Class<? extends IWritable> getOutputValClass();
        
        /**
         * Determine if the key value pair should be accepted,
         * and generate the output data in keyOut and valueOut if
         * return true.
         * @param key
         * @param value
         * @return
         */
        public boolean accept(K_SRC key, V_SRC value, K_DST keyOut, V_DST valueOut);
    }
    
    /**
     * Filter which output the source key and value if accept returns true.
     *
     * @author river
     *
     * @param <K_SRC>
     * @param <V_SRC>
     */
    public static abstract class AbstractDirectFilter<K_SRC extends IWritable, V_SRC extends IWritable> 
    implements Filter<K_SRC, V_SRC, K_SRC, V_SRC> {

        public abstract boolean accept(K_SRC key, V_SRC value);
        
        public boolean processArgs(String [] args) { return true; }
        
        public void prepareConfig(JobConfig config) {}
        
        public void init(JobConfig config, TaskRunnable task) {}
        
        public final boolean accept(K_SRC key, V_SRC value, K_SRC keyOut,
                V_SRC valueOut) {
            if (accept(key, value)) {
                return true;
            } else {
                return false;
            }
        }

        public Class<? extends IWritable> getOutputKeyClass() {
            return null;
        }

        public Class<? extends IWritable> getOutputValClass() {
            return null;
        }
        
    }
    
    public static class Mapper extends AbstractMapper {
        public static final String NAME_FILTER_CLASS = Mapper.class.getName() + ".filter_class";
        public static final String NAME_KEY_CLASS = Mapper.class.getName() + ".key_class";
        public static final String NAME_VAL_CLASS = Mapper.class.getName() + ".val_class";
        
        private Filter filter;
        private IWritable outputKey;
        private IWritable outputValue;
        private boolean directOutput = false;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            String classname = job.getConfig().getString(NAME_FILTER_CLASS);
            try {
                filter = getFilter(classname);
            } catch(Exception e) {
                throw new TaskFatalException("initialize filter as " + classname + " failed", e);
            }
            filter.init(job.getConfig(), task);
            directOutput = filter instanceof AbstractDirectFilter;
            
            String keyClassname = job.getConfig().getString(NAME_KEY_CLASS);
            String valClassname = job.getConfig().getString(NAME_VAL_CLASS);
            try {
                outputKey = (IWritable)ClassUtils.newInstance(Class.forName(keyClassname));
                outputValue = (IWritable)ClassUtils.newInstance(Class.forName(valClassname));
            } catch(Exception e) {
                throw new TaskFatalException("initialize output key/value failed", e);
            }
        }

        @SuppressWarnings("unchecked")
        public void map(Object key, Object value, ICollector collector) {
            if (filter.accept((IWritable)key, (IWritable)value, outputKey, outputValue)) {
                if (directOutput) {
                    collector.collect(key, value);
                } else {
                    collector.collect(outputKey, outputValue);
                }
            }
        }
    }
    
    public static class RegexpFilter<K_SRC extends IWritable, V_SRC extends IWritable> extends AbstractDirectFilter<K_SRC, V_SRC> {
        private static final String NAME_KEY_PATTERN = "key_pattern";
        private static final String NAME_VAL_PATTERN = "val_pattern";
        
        private String keyPatternString;
        private String valPatternString;
        
        private Pattern keyPattern;
        private Pattern valPattern;
        
        
        @Override
        public boolean processArgs(String[] args) {
            Options options = new Options();
            options.withOption("kreg", "regexp", "set regular expression for key").hasDefault();
            options.withOption("vreg", "regexp", "set regular expression for value").hasDefault();
            options.ignoreUnknownOption();
            try {
                options.parse(args);
            } catch(OptionParseException e) {
                LOG.log(Level.SEVERE, "parse options for regexp filter error", e);
                return false;
            }
            keyPatternString = options.getStringOpt("kreg", null);
            valPatternString = options.getStringOpt("vreg", null);
            if (keyPatternString == null && valPatternString == null) {
                return false;
            }
            return true;
        }

        @Override
        public void prepareConfig(JobConfig config) {
            config.setProperty(NAME_KEY_PATTERN, keyPatternString);
            config.setProperty(NAME_VAL_PATTERN, valPatternString);
        }

        @Override
        public void init(JobConfig config, TaskRunnable task) {
            String keyTemp = config.getString(NAME_KEY_PATTERN);
            if (keyTemp != null) {
                keyPattern = Pattern.compile(keyTemp);
            }
            String valTemp = config.getString(NAME_VAL_PATTERN);
            if (valTemp != null) {
                valPattern = Pattern.compile(valTemp);
            }
        }

        @Override
        public boolean accept(K_SRC key, V_SRC value) {
            boolean keyMatches;
            boolean valMatches;
            
            if (keyPattern != null) {
                keyMatches = keyPattern.matcher(key.toString()).matches();
            } else {
                keyMatches = true;
            }
            
            if (valPattern != null) {
                valMatches = valPattern.matcher(value.toString()).matches();
            } else {
                valMatches = true;
            }
            
            return keyMatches && valMatches;
        }
        
    }
    
}
