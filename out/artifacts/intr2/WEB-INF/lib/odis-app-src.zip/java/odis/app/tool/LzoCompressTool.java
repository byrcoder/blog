/**
 * @(#)LzoCompressTool.java, 2007-8-20. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import odis.app.job.AbstractLocalToolWithArg;
import odis.io.FileSystem;
import odis.io.LzoInputStream;
import odis.io.LzoOutputStream;
import odis.io.Path;
import toolbox.misc.UnitUtils;
import toolbox.misc.cli.Options;

/**
 * Lzo compression/uncompression.
 * @author river
 *
 */
public class LzoCompressTool extends AbstractLocalToolWithArg {

    public String comment() {
        return "Lzo compression or uncompression";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("x", "uncompress");
        options.withOption("in", "input", "set input file to be processed");
        options.withOption("out", "output", "set output file name");
        options.withOption("c", "chunksize", "set the chunk size in K used in compression").setDefault(64);
        options.withOption("fs", "fs_name", "set the filesystem, default is file system of context").setDefault("");
    }

    public boolean exec() throws Exception {
        boolean uncompression = options.isOptSet("x");
        String input = options.getStringOpt("in");
        String output = options.getStringOpt("out");
        int chunkSize = (int)(options.getIntOpt("c") * UnitUtils.K);
        String fsName = options.getStringOpt("fs", null);
        FileSystem fs = (fsName == null) ? context.getFileSystem() : FileSystem.getNamed(fsName);
        if (uncompression) {
            uncompress(fs, new Path(input), new Path(output));
        } else {
            compress(fs, new Path(input), new Path(output), chunkSize);
        }
        return true;
    }
    
    private void compress(FileSystem fs, Path input, Path output, int chunkSize) throws IOException {
        InputStream is = fs.open(input);
        try {
            LzoOutputStream os = new LzoOutputStream(fs.create(output, false), chunkSize);
            try {
                byte [] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) >=0) {
                    os.write(buf, 0, len);
                }
            } finally {
                os.close();
            }
        } finally {
            is.close();
        }
    }
    
    private void uncompress(FileSystem fs, Path input, Path output) throws IOException {
        LzoInputStream is = new LzoInputStream(fs.open(input));
        try {
            OutputStream os = fs.create(output, false);
            try {
                byte [] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) >=0) {
                    os.write(buf, 0, len);
                }
            } finally {
                os.close();
            }
        } finally {
            is.close();
        }
    }

}
