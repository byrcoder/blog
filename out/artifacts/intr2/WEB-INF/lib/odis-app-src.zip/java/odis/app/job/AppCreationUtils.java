package odis.app.job;

import java.lang.reflect.Array;

import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.IMapper;
import odis.mapred.IReducer;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapMergeConf;
import odis.tools.ToolContext;

/**
 * Some utitilies for creation of cowork applications.
 * 
 * Using the following createXxxxJob to create your JobDef increases the 
 * realability of the code.
 * 
 * @author david
 *
 */
public class AppCreationUtils {
    /**
     * Creates a MapOnlyJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param mapper The mapper.
     * @param nMapper The number of the mappers.
     * @return The created object.
     */
    public static MapOnlyJobDef createMapOnlyJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            Class<? extends IMapper> mapper, int nMapper
        ) {
        MapOnlyJobDef job = env.createMapOnlyJob(jobName, nWorker);
        job.setMapper(mapper);  job.setMapNumber(nMapper);
        return job;
    }
    
    /**
     * Creates a MapReduceJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param mapper The mapper.
     * @param nMapper The number of the mappers.
     * @param reducer The reducer.
     * @param nReducer The number of reducers.
     * @param mergeKeyClass The key class of the  merger.
     * @param mergeValClass The value class of the merger.
     * @return The created object.
     * @deprecated use the one with partitioner.
     */
    @Deprecated
    public static MapReduceJobDef createMapReduceJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            Class<? extends IMapper> mapper, int nMapper,
            // reducer
            Class<? extends IReducer> reducer, int nReducer,
            Class mergeKeyClass, Class mergeValClass
        ) {
        return createMapReduceJob(env, jobName, nWorker, 
                mapper, nMapper, 
                reducer, nReducer, mergeKeyClass, mergeValClass,
                null);
    }
    /**
     * Creates a MapReduceJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param mapper The mapper.
     * @param nMapper The number of the mappers.
     * @param reducer The reducer.
     * @param nReducer The number of reducers.
     * @param mergeKeyClass The key class of the  merger.
     * @param mergeValClass The value class of the merger.
     * @param partitioner  the partitioner class
     * @return The created object.
     */
    public static MapReduceJobDef createMapReduceJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            Class<? extends IMapper> mapper, int nMapper,
            // reducer
            Class<? extends IReducer> reducer, int nReducer,
            Class mergeKeyClass, Class mergeValClass,
            Class<? extends BasicPartitioner> partitioner
        ) {
        MapReduceJobDef job = env.createMapReduceJob(jobName, nWorker);
        job.setMapper(mapper);  job.setMapNumber(nMapper);
        job.setReducer(reducer);  job.setReduceNumber(nReducer);
        job.setMergeKeyValClass(mergeKeyClass, mergeValClass);
        if (partitioner != null)
            job.setPartitionerClass(partitioner);

        return job;
    }
    
    /**
     * Creates a MapReduceJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param mapper The mapper.
     * @param nMapper The number of the mappers.
     * @param mergeKeyClass The key class of the  merger.
     * @param mergeValClass The value class of the merger.
     * @param partitioner  the partitioner class
     * @return The created object.
     */
    public static MapReduceJobDef createMapMergeReduceJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            Class<? extends IMapper> mapper, int nMapper,
            // reducer
            Class mergeKeyClass, Class mergeValClass,
            Class<? extends BasicPartitioner> partitioner
        ) {
        MapReduceJobDef job = env.createMapReduceJob(jobName, nWorker);
        job.setMapper(mapper);  job.setMapNumber(nMapper);
        job.setMergeKeyValClass(mergeKeyClass, mergeValClass);
        if (partitioner != null)
            job.setPartitionerClass(partitioner);

        return job;
    }
    
    /**
     * Creates a MapReduceJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param nMapper The number of the mappers.
     * @param reducer The reducer.
     * @param nReducer The number of reducers.
     * @param mergeKeyClass The key class of the  merger.
     * @param mergeValClass The value class of the merger.
     * @param partitioner  the partitioner class
     * @return The created object.
     */
    public static MapReduceJobDef createMergeMapReduceJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            int nMapper,
            // reducer
            Class<? extends IReducer> reducer, int nReducer,
            Class mergeKeyClass, Class mergeValClass,
            Class<? extends BasicPartitioner> partitioner
        ) {
        MapReduceJobDef job = env.createMapReduceJob(jobName, nWorker);
        job.setMapNumber(nMapper);
        job.setReducer(reducer);  job.setReduceNumber(nReducer);
        job.setMergeKeyValClass(mergeKeyClass, mergeValClass);
        if (partitioner != null)
            job.setPartitionerClass(partitioner);

        return job;
    }
    
    /**
     * Creates a MrStarJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param mapper The (1st) mapper.
     * @param nMapper The number of the (1st) mappers.
     * @param reducer_0 The 1st reducer.
     * @param nReducer_0 The number of 1st reducers.
     * @param mergeKeyClass_0 The key class of the 1st merger.
     * @param mergeValClass_0 The value class of the 1st merger.
     * @param reducers The rest reducers. Each 4 parameters forms a io-phase:
     *                 (<reducer_i> <nReducer_i> <mergeKeyClass_0> <mergeValueClass_0>)*
     * @return The created object.
     * @deprecated use the one with partitioner setting instead.
     */
    @SuppressWarnings("unchecked")
    @Deprecated
    public static MrStarJobDef createMrStarJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            Class<? extends IMapper> mapper, int nMapper,
            // reducer 0
            Class<? extends IReducer> reducer_0, int nReducer_0,
            Class mergeKeyClass_0, Class mergeValClass_0,
            // reducer 1, 2, ...
            Object... reducers
        ) {
        if (reducers.length % 4 != 0) {
            throw new RuntimeException("Wrong number of paramters.");
        } // if
        int cnt = 1 + reducers.length/4;
        MrStarJobDef job = env.createMrStarJob(cnt, jobName, nWorker);
        job.setMapper(mapper);  job.setMapNumber(nMapper);
        
        job.setReducer(0, reducer_0);  job.setMrNumber(1, nReducer_0);
        job.setMergeKeyValClass(0, mergeKeyClass_0, mergeValClass_0);
        
        for (int i = 1; i < cnt; i ++) {
            job.setReducer(i, (Class<? extends IReducer>) reducers[(i - 1)*4 + 0]);
            if (i < cnt - 1)
                job.setMrNumber(i + 1, (Integer) reducers[(i - 1)*4 + 1]);
            else
                job.setReduceNumber((Integer) reducers[(i - 1)*4 + 1]);
            job.setMergeKeyValClass(i, (Class) reducers[(i - 1)*4 + 2], (Class) reducers[(i - 1)*4 + 3]);
        } // for i
        return job;
    }
    
    /**
     * Creates a MrStarJobDef object.
     * 
     * @param context  The OutfoxEnv object.
     * @param jobName The name of the job.
     * @param nWorker The number of workers
     * @param mapper The (1st) mapper.
     * @param nMapper The number of the (1st) mappers.
     * 
     * @param reducer_0 The 1st reducer.
     * @param nReducer_0 The number of 1st reducers.
     * @param mergeKeyClass_0 The key class of the 1st merger.
     * @param mergeValClass_0 The value class of the 1st merger.
     * @param partitioner_0  the partitioner for the first reducer
     * 
     * @param reducers The rest reducers. Each 4 parameters forms a io-phase:
*                 (<reducer_i>  <nReducer_i> 
*                  <mergeKeyClass_i> <mergeValueClass_i> <partitioner_i>),*
     * @return The created object.
     */
    @SuppressWarnings("unchecked")
    public static MrStarJobDef createMrStarJob(
            ToolContext env, String jobName, int nWorker,
            // mapper
            Class<? extends IMapper> mapper, int nMapper,
            // reducer 0
            Class<? extends IReducer> reducer_0, int nReducer_0,
            Class mergeKeyClass_0, Class mergeValClass_0,
            Class<? extends BasicPartitioner> partitioner_0,
            // reducer 1, 2, ...
            Object... reducers
        ) {
        if (reducers.length % 5 != 0) {
            throw new RuntimeException("Wrong number of paramters.");
        } // if
        int cnt = 1 + reducers.length/5;
        MrStarJobDef job = env.createMrStarJob(cnt, jobName, nWorker);
        job.setMapper(mapper);  job.setMapNumber(nMapper);
        
        job.setReducer(0, reducer_0);  job.setMrNumber(1, nReducer_0);
        job.setMergeKeyValClass(0, mergeKeyClass_0, mergeValClass_0);
        if (partitioner_0 != null)
            job.setPartitionerClass(0, partitioner_0);
        
        for (int i = 1; i < cnt; i ++) {
            job.setReducer(i, (Class<? extends IReducer>) reducers[(i - 1)*5 + 0]);
            if (i < cnt - 1)
                job.setMrNumber(i + 1, (Integer) reducers[(i - 1)*5 + 1]);
            else
                job.setReduceNumber((Integer) reducers[(i - 1)*5 + 1]);
            job.setMergeKeyValClass(i, (Class) reducers[(i - 1)*5 + 2], (Class) reducers[(i - 1)*5 + 3]);
            if (reducers[(i - 1)*5 + 4] != null)
                job.setPartitionerClass(i, (Class<? extends BasicPartitioner>) reducers[(i - 1)*5 + 4]);
        } // for i
        return job;
    }
    
    /**
     * Creates MapMergeConf object.
     * 
     * @param mapper The mapper class.
     * @param input The input directories:  
     *              (<<File|Path|String>|<File|Path|String>[]>  <Class walkerclass>)+
     *              e.g. new Path(..), new Path[]{...}               
     * @return The created object.
     */
    public static MapMergeConf createMapMergeConf(
            Class<? extends IMergeMapper> mapper,
            Object... input) {
        if (input.length % 2 != 0)
            throw new RuntimeException("Input must be pared: <dir> <walker>");
        
        MapMergeConf conf = new MapMergeConf();
        conf.setMergeMapper(mapper);
        if (input.length > 0) {
            int nMerge = 0;
            for (int i = 0; i < input.length; i += 2)
                if (input[i].getClass().isArray())
                    nMerge += Array.getLength(input[i]);
                else
                    nMerge ++;
            conf.setMergeCount(nMerge);
            int idx = 0;
            for (int i = 0; i < input.length; i += 2) {
                if (input[i].getClass().isArray()) {
                    for (int j = 0; j < Array.getLength(input[i]); j ++) {
                        conf.setMergeDir(idx ++, new Path(Array.get(input[i], j).toString()), 
                                (Class) input[i + 1]);
                    } // for j
                } else
                    conf.setMergeDir(idx ++, new Path(input[i].toString()), (Class) input[i + 1]);
            } // for i
        } // if
        return conf;
    }
}
