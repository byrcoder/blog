package odis.app.job;

import java.io.PrintStream;
import java.util.ArrayList;

import toolbox.text.util.StringUtils;

public class CounterUtils {
    public static final String DEF_COUNTER_SEP = "[^0-9\\-]+"; 
    
   /**
    * Sum up the counters in nums.
    * 
    * Usage:
    *   nums = {"1 2 3", "4 5 6"};
    *   sep = null or " ";
    *   sumCounters(nums, sep) returns:
    *     {5, 7, 9}
    *     
    * @param nums
    * @param sep The separator regular expresion. You can set this to null to use the default
    *            separator: "[^0-9\\-]+" (DEF_COUNTER_SEP).
    * @return
    */
   public static long[] sumCounters(String[] nums, String sep) {
       ArrayList<Long> cnts = new ArrayList<Long>();
       if (sep == null || sep.length() == 0)
           sep = DEF_COUNTER_SEP;

       for (String num: nums) {
           if (num == null)
               continue;
           String[] strs = num.split(sep);
           for (int i = 0; i < strs.length; i ++)
               try {
                   if (i < cnts.size())
                       cnts.set(i, Long.parseLong(strs[i]) + cnts.get(i));
                   else
                       cnts.add(new Long(strs[i]));
               } catch (NumberFormatException e) {
                   // ignore this.
               }
       } // for num

       long[] res = new long[cnts.size()];
       for (int i = 0; i < cnts.size(); i ++)
           res[i] = cnts.get(i);
       return res;
   }

   /**
    * shown as it is, default
    */
   public static final int TP_PLAIN            = 0;
   /**
    * this field is hidden
    */
   public static final int TP_HIDDEN           = 1;
   /**
    * the abbreviation form of the size in bytes
    */
   public static final int TP_BYTES_ABBR       = 2;
   /**
    * the abbreviation form of the intervals in milli-seconds
    */
   public static final int TP_INTERVAL_MS_ABBR = 3;
   /**
    * the number separarted every 4 digits
    */
   public static final int TP_COUNT_3          = 4;
   /**
    * the number separarted every 4 digits
    */
   public static final int TP_COUNT_4          = 5;

   public static void showCounters(PrintStream out, long[] counts, String indent, Object... names) {
       int idx = 0;
       for (int i = 0; i < counts.length; i ++) {
           String name = null;
           if  (names != null && idx < names.length)
               name = "" + names[idx ++];
           int type = TP_PLAIN;
           if (names != null && idx < names.length && names[idx] instanceof Integer)
               type = (Integer) names[idx ++];
           if (type== TP_HIDDEN)
               continue;

           String count;
           switch (type) {
               case TP_BYTES_ABBR:
                   count = StringUtils.bytesAbbr(counts[i]);
                   break;
               case TP_INTERVAL_MS_ABBR:
                   count = StringUtils.intervalToString(counts[i]);
                   break;
               case TP_COUNT_3:
                   count = StringUtils.countSep(counts[i], ",", 3);
                   break;
               case TP_COUNT_4:
                   count = StringUtils.countSep(counts[i], ",", 4);
                   break;
               default:
                   count = "" + counts[i];
           }

           if (name != null)
               out.println(indent + name + ": " + count);
           else if (names == null || names.length == 0)
               out.println(indent + "count_" + i + ": " + count);
           else
               out.println(indent + String.format("%" + names[0].toString().length() + "s", "count_" + i) + ": " + count);
       } // for i
   }

   /**
    * Sum up the counters in nums and show them out using showCounters.
    * 
    * Usage:
    *   nums = {"1 2 3", "4 5 6"};
    *   sumCounters(nums, null, "    ", 
    *           "apple ", 
    *           "banana", 
    *           "cat   ") displays
    *       apple  5
    *       banana 7
    *       cat    9
    *
    * @param nums
    * @param sep The separator regular expresion. You can set this to null to use the default
    *            separator: "[^0-9\\-]+" (DEF_COUNTER_SEP).
    * @param indent
    * @param names The names and options of the counter. See javadoc of sumCounters for more information.
    */
   public static void showSumCounters(String[] nums, String sep, String indent, Object... names) {
       long[] counts = sumCounters(nums, sep);
       showCounters(System.out, counts, indent, names);
   }

   public static long[] maxCounters(String[] nums, String sep) {
       ArrayList<Long> cnts = new ArrayList<Long>();
       if (sep == null || sep.length() == 0)
           sep = "[^0-9\\-]+";

       for (String num: nums) {
           if (num == null)
               continue;
           String[] strs = num.split(sep);
           for (int i = 0; i < strs.length; i ++)
               try {
                   if (i < cnts.size())
                       cnts.set(i, Math.max(Long.parseLong(strs[i]), cnts.get(i)));
                   else
                       cnts.add(new Long(strs[i]));
               } catch (NumberFormatException e) {
                   // ignore this.
               }
       } // for num

       long[] res = new long[cnts.size()];
       for (int i = 0; i < cnts.size(); i ++)
           res[i] = cnts.get(i);
       return res;
   }

   public static long[] minCounters(String[] nums, String sep) {
       ArrayList<Long> cnts = new ArrayList<Long>();
       if (sep == null || sep.length() == 0)
           sep = "[^0-9\\-]+";

       for (String num: nums) {
           if (num == null)
               continue;
           String[] strs = num.split(sep);
           for (int i = 0; i < strs.length; i ++)
               try {
                   if (i < cnts.size())
                       cnts.set(i, Math.max(Long.parseLong(strs[i]), cnts.get(i)));
                   else
                       cnts.add(new Long(strs[i]));
               } catch (NumberFormatException e) {
                   // ignore this.
               }
       } // for num

       long[] res = new long[cnts.size()];
       for (int i = 0; i < cnts.size(); i ++)
           res[i] = cnts.get(i);
       return res;
   }

   public static void showMaxCounters(String[] nums, String sep, String indent, Object... names) {
       long[] counts = maxCounters(nums, sep);
       showCounters(System.out, counts, indent, names);
   }

   public static void showMinCounters(String[] nums, String sep, String indent, Object... names) {
       long[] counts = minCounters(nums, sep);
       showCounters(System.out, counts, indent, names);
   }
}
