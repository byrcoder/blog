package odis.app.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.Thread.State;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import odis.rpc.RPC;
import odis.rpc.RpcException;
import odis.rpc.RpcServer;

/**
 * This class is a designed for conviniently calling a method which is 
 * implemented in another separated process. 
 * Meanwhile, the class will monitor the status of
 * the separated process and re-start the service transparently 
 * even the process crashes.
 * 
 * <p>
 * <strong>Notice:</strong> 
 * <li>Although it is multi-thread safe to call the interface method of 
 * the proxy, but it is not really concurrency supported. There is only 
 * one thread can actually send rpc request to the separated process .</li>
 * <li>The implementation MUST NOT throw a RpcException or its sub-instance.</li>
 * <li>When the service process crashs, a RpcExcetion is thrown.</li>
 * </p>
 * 
 * @author Feng Jiang (feng.a.jiang@gmail.com)
 */
public class InterProcessService<T> {
    
    private boolean isStart = false;
    private boolean isShutdown = false;
    
    private ChildMonitor monitor = null;
    private volatile T rpcProxy = null;
    /** control the proxy is avaliable to use*/
    private Semaphore proxyPermit = new Semaphore(0);
    
    private Class<T> intf;
    private Class<? extends T> impl;
    
    public InterProcessService(Class<T> intf, Class<? extends T> impl){
        this.intf = intf;
        this.impl = impl;
    }
    
    @SuppressWarnings("unchecked")
    public T getProxy(){
        return (T)Proxy.newProxyInstance(intf.getClassLoader(), new Class[]{intf}, 
            new InvocationHandler(){
                private final Object lock = new Object();
                public Object invoke(Object proxy, Method method,
                        Object[] args) throws Throwable {
                    synchronized(lock){
                        if(monitor.getState() == State.TERMINATED)
                            throw new IllegalStateException("the service has been shutdown.");
                        try {
                            return method.invoke(rpcProxy, args);
                        }catch(InvocationTargetException e){
                            // user should get the caues exception
                            // because s/he has no idea about the proxy mechanism,
                            // but user may get rpc-like exception.
                            Throwable t = e.getTargetException();
                            if(t instanceof RpcException)
                                proxyPermit.acquireUninterruptibly();
                            throw t;
                        }
                    }
                }
            }
        );
    }
    
    /**
     * Start the service. <p>
     * It will be blocked until the service is ready.
     * It MUST be called before any method of proxy instance is invoked.
     * 
     * @throws InterruptedException when an interrupt occurs
     */
    public synchronized void start() throws InterruptedException {
        if(isStart)
            return;
        monitor = new ChildMonitor();
        monitor.start();
        try {
            proxyPermit.acquire();
        } catch (InterruptedException e) {
            monitor.interrupt();
            throw e; // notify the caller.
        }//wait until proxy is avaliable
        isStart = true;
    }
    
    /**
     * Shutdown the serice.<p>
     * It SHOULD be called when the proxy instance will not be used any more.
     * If the program exits without calling this method, the zombie process
     * will be brought out.<p>
     * ATTENTION: even this method is called, zombie process will be brought
     * out as well.
     */
    public synchronized void shutdown() {
        if(isShutdown)
            return;
        monitor.interrupt();
        isShutdown = true;
    }
    
    interface IHeartbeat {
        void hello(int port) throws RpcException;
    }
    
    public class ChildMonitor extends Thread implements IHeartbeat {
        
        private int listenPort = 12345;
        private volatile int childPort = -1;
        private Semaphore childPermit = new Semaphore(0);
        
        public void hello(int port) throws RpcException {
            childPort = port;
            childPermit.release();// wakeup childMonitor if possible
        }
        
        public ChildMonitor() {
            this.setName(this.getClass().getSimpleName());
            this.setDaemon(true);
        }
        
        @SuppressWarnings("unchecked")
        public void run() {
            RedirectDaemon stdoutDaemon = new RedirectDaemon(true);
            stdoutDaemon.setName("StdoutRedirectDaemon");
            stdoutDaemon.start();
            
            RedirectDaemon stderrDaemon = new RedirectDaemon(false);
            stderrDaemon.setName("StderrRedirectDaemon");
            stderrDaemon.start();
            
             // the port of heartbeat server listen on
            RpcServer rpcServer = null;
            for(;;) {
                try {
                    rpcServer = RPC.getServer(this, listenPort);
                    rpcServer.start();
                    System.out.println("the heartbeat service is started at port: "
                            +  listenPort);
                    break;
                } catch (IOException e) {
                    listenPort++;
                    if(listenPort >= 65535)
                        listenPort = 1025;
                }
            }
            
            String cmdline = "";
            try {
                cmdline = makeCmdline();
            } catch (IOException e1) {
                throw new RuntimeException(e1);
            }
            Process p = null;
            for (; !Thread.interrupted();) {
                try {
                    p = Runtime.getRuntime().exec(cmdline);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                
                stdoutDaemon.add(p.getInputStream());
                stderrDaemon.add(p.getErrorStream());
                
                try {
                    //if the jvm is started but java program fails,
                    //not exception is thrown. so a timeout is need 
                    //in case that the java program fails, such as
                    //the binary byte code is modified when Child process
                    //is being started.
                    if(!childPermit.tryAcquire(100, TimeUnit.SECONDS)) {// wait until childPort is obtained
                        p.destroy();
                        int exitcode = p.waitFor();
                        System.out.println("The child process has died too early: " + exitcode);
                        continue;
                    }
                    rpcProxy = (T)RPC.getProxy(intf, new InetSocketAddress(childPort));
                    proxyPermit.release(); // wakeup the proxy awaitig thread
                    
                    // a potential bug here:
                    // if the program exit without calling the shutdown() method,
                    // or though called the shutdown() method but dies too quickly
                    // so that ChildMonitor thread has no chance to kill the child 
                    // process, the child process will become Zombie.
                    
                    int exitcode = p.waitFor();// if the child is killed by
                    // hand, it is not big problem, and just one more rpc call
                    // may be missed.
                    childPermit.drainPermits(); // make getProxy wait unitl hello msg.
                    System.out.println("The child process has died: " + exitcode);
                
                }catch (InterruptedException e) {
                    // interrupt is for quit, so just destory the process.
                    if(p!=null)
                        p.destroy();
                    Thread.currentThread().interrupt();
                }
            }
            rpcServer.stop();
        }
        
        class RedirectDaemon extends Thread {
            
//            public static final int REDIRECT_STDOUT = 1;
//            public static final int REDIRECT_STDERR = 2;
            
            private PrintStream stream = null;
            
            private LinkedBlockingQueue<InputStream> q = new LinkedBlockingQueue<InputStream>();
            
            public RedirectDaemon(boolean isStdout){
                this.setDaemon(true);
                if(isStdout)
                    stream = System.out;
                else
                    stream = System.err;
            }
            public void add(InputStream is) {
                q.offer(is);
            }
            
            public void run() {
                char[] cbuf = new char[4*1024]; 
                for(; !Thread.interrupted() ;){
                    BufferedReader read = null;
                    try {
                        read = new BufferedReader(
                                new InputStreamReader(q.take()));
                        for(int len = 0; (len=read.read(cbuf))>0;)
                            for(int i=0; i<len; i++)
                                stream.print(cbuf[i]);
                    } catch (Exception e) {
                        continue;
                    } finally {
                        try {
                            read.close();
                        } catch (IOException e) {}
                    }
                }
            }
        }

        private String makeCmdline() throws IOException {
            //for java path
            StringBuilder sb = new StringBuilder();
            sb.append(new File(new File(System.getProperty("java.home"), "bin"), "java").getAbsolutePath());
            
            // for class path
            sb.append(" -cp " + System.getProperty("java.class.path"));
            
            //for main class
            sb.append(" " + Child.class.getName());
            
            //for parameters
            sb.append(" " + impl.getName());
            sb.append(" " + listenPort);
            return sb.toString();
        }
    }
    
    public static class Child {
        
        public static void main(String[] args) {
            Object impl = null;
            try {
                impl = Class.forName(args[0]).newInstance();
            } catch (Exception e1) {
                System.exit(1);
            } 
            int childPort = 21345;
            for(;;) {
                RpcServer server = RPC.getServer(impl, childPort);
                try {
                    server.start();
                    System.out.println("CHILD: the child rpc server is " +
                                "started at port: " + childPort);
                    break;
                } catch (IOException e) {
                    childPort++;
                    if(childPort >= 65535)
                        childPort = 1025;
                }
            }
            
            int parentPort = Integer.parseInt(args[1]);
            IHeartbeat parent = (IHeartbeat)RPC.getProxy(IHeartbeat.class, 
                    new InetSocketAddress(parentPort));
            
            for(;;){
                try {
                    parent.hello(childPort);
                    Thread.sleep(1000);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
