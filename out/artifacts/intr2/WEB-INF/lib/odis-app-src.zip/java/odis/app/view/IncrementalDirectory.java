package odis.app.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.IWritablePairWalker;
import odis.mapred.ext.MapMergeConf;
import odis.mapred.ext.ReduceMergeConf;
import odis.mapred.lib.PairWalkerBase;
import odis.serialize.IWritable;
import odis.serialize.toolkit.AbstractOpObject;
import odis.tools.MapReduceHelper;

/**
 * Directory structure for incremental data, such as "summary" and "snapshot". 这样的目录
 * 版本号通常包括一个主要部分（major）和一个增量部分（minor）：major.minor
 * 
 * 加入一个版本号为i.j，那么其目录结构为：
 *   i.j/major     e.g.   12.3/major
 *      /minor/1              /minor/1
 *            /2                    /2
 *            /3                    /3
 *           ...
 *            /j
 * 如果是刚开始的一个主版本，那么目录结构为：
 *  i.0/major
 *     /minor （目录内为空）
 *     
 * 关于第一个版本：
 *  - 如果在没有当前version的情况下创建minor版本，会创建0.1版本作为第一个版本
 *  - 如果在没有当前version的情况下建major版本，会创建1.0版本作为第一个版本
 * 
 * 下面的例子说明几个基本的操作流程:<BR>
 * <strong>主版本更新</strong>
 * <code>
 *   Path output = ...; // output中保存着最新的全数据，例如由merge过程生成的数据
 *   
 *   IncrementalDirectory incDir = new IncrementalDirectory(...);
 *   incDir.createMajorVersion(output, true); // 创建新的版本，并且删除旧的版本
 *   
 * </code>
 * 
 * <strong>小版本更新</strong>
 * <code>
 *   Path output = ...; // output中保存着最新的增量数据
 *   IncrementalDirectory incDir = new IncrementalDirectory(...);
 *   incDir.createMinorVersion(output, true); // 创建新的版本，并且删除旧的版本
 * </code>
 * 
 * <strong>获得当前最新数据</strong>
 * <code>
 *   IncrementalDirectory incDir = new IncrementalDirectory(...);
 *   // 获得major目录
 *   Path majorPath = incDir.getMajorDirectory(incDir.latestVersion());
 *   // 获得minor的目录列表
 *   Path [] minorPaths = incDir.getMinorDirectories(incDir.latestVersion());
 * </code>
 *  
 * @author 吴迎晖（river）
 * 
 * 修改历史：
 *   2007/6/2（庄莉）：添加javadoc说明和注释
 *   2007-8-7 ( river) : 从outback中迁移到odis-app中
 */
public class IncrementalDirectory {

    public static final String MAJOR = "major";
    public static final String MINOR = "minor";
    
    private IFileSystem fs;

    private Path dir;

    /**
     * 一个增量目录的版本号包括major号和minor号 
     */
    public static class Version implements Comparable<Version> {
        private int major;
        private int minor;

        public Version(int major, int minor) {
            this.major = major;
            this.minor = minor;
        }

        public int getMajor() {
            return major;
        }

        public int getMinor() {
            return minor;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || !(o instanceof Version)) return false;
            Version that = (Version)o;
            return this.major == that.major && this.minor == that.minor;
        }
        
        public int compareTo(Version other) {
            return (this.major < other.major) ? -1
                    : (this.major > other.major ? 1
                            : (this.minor < other.minor ? -1
                                    : (this.minor > other.minor ? 1 : 0)));
        }

        @Override
        public String toString() {
            return major + "." + minor;
        }
    }

    /**
     * 找出一系列版本中最新的。先比major号，再比minor号
     * @param versions 一系列版本号
     * @return 最新的一个版本号
     */
    public static Version latest(Version[] versions) {
        if (versions.length == 0)
            return null;

        Version latestVersion = versions[0];
        for (int index = 1; index < versions.length; index++) {
            Version version = versions[index];
            if (version.major > latestVersion.major
                    || (version.major == latestVersion.major 
                            && version.minor > latestVersion.minor)) {
                latestVersion = version;
            }
        }

        return latestVersion;
    }

    public IncrementalDirectory(IFileSystem fs, Path dir) {
        this.fs = fs;
        this.dir = dir;
    }

    /**
     * 得到这个目录下所有的版本号（major.minor），返回的列表是增序的.
     * @return 这个目录下所有的版本
     * @throws IOException
     */
    public Version[] getVersions() throws IOException {
        FileInfo[] dirs = fs.listFiles(dir);
        if (dirs == null) {
            return new Version[0];
        }

        Pattern pattern = Pattern.compile("(\\d+)\\.(\\d+)");
        List<Version> versions = new ArrayList<Version>();

        for (FileInfo dir : dirs) {
            if (!dir.isDir())
                continue;

            String name = dir.getPath().getName();
            Matcher matcher = pattern.matcher(name);
            if (matcher.matches()) {
                int major = Integer.parseInt(matcher.group(1));
                int minor = Integer.parseInt(matcher.group(2));
                versions.add(new Version(major, minor));
            }
        }
        
        Collections.sort(versions);
        return versions.toArray(new Version[versions.size()]);
    }

    /**
     * @deprecated use getLatestVersion() instead
     */
    @Deprecated
    public Version latestVersion() throws IOException {
        Version[] versions = getVersions();
        if (versions.length == 0) {
            return null;
        }
        return latest(versions);
    }
    
    /**
     * 找出这个目录下最新的一个版本. 
     * @return 如果当前目录下没有版本，返回null
     */
    public Version getLatestVersion() throws IOException {
        Version[] versions = getVersions();
        if (versions.length == 0) {
            return null;
        }
        return latest(versions);
    }

    /**
     * @deprecated use getLatestPartitionNumber() instead 
     */
    @Deprecated
    public int latestPartitionNumber() throws IOException {
        Version version = latestVersion();
        if (version == null) return -1;
        if (version.major != 0) {
            return MapReduceHelper.getContinuousPartCount(fs, 
                    getMajorDirectory(version));
        } else {
            return MapReduceHelper.getContinuousPartCount(fs, 
                    getMinorDirectories(version)[0]);
        }
    }
    /**
     * @return 最新版本的partition number 
     * @throws IOException
     */
    public int getLatestPartitionNumber() throws IOException {
        Version version = getLatestVersion();
        if (version == null) return -1;
        if (version.major != 0) {
            return MapReduceHelper.getContinuousPartCount(fs, 
                    getMajorDirectory(version));
        } else {
            return MapReduceHelper.getContinuousPartCount(fs, 
                    getMinorDirectories(version)[0]);
        }
    }

    /**
     * 获得version的根目录.
     * @param version
     * @return
     */
    public Path getVersionDirectory(Version version) {
        return dir.cat(version.toString());
    }
    
    /**
     * 得到一个版本对应的所有目录，将目录按照名字排序后返回. 
     * 如果major和所有minor的part number出现任何不一致，那么一定是之前发生了错误。
     * 这种情况下返回null。
     */
    public Path [] getDirectories(Version version) throws IOException {
        List<Path> dirList = new ArrayList<Path>();
        Path majorDir = getMajorDirectory(version);
        int partNum = -1;
        if (majorDir != null) {
            dirList.add(majorDir);
            partNum = MapReduceHelper.getContinuousPartCount(fs, majorDir);
        }
        for (Path p : getMinorDirectories(version)) {
            int pn = MapReduceHelper.getContinuousPartCount(fs, p);
            if (partNum < 0) partNum = pn;
            else if (pn != partNum) {
                throw new IOException("part number in version mismatch");
            }
            dirList.add(p);
        }
        return dirList.toArray(new Path[dirList.size()]);
    }

    /**
     * 得到一个版本的major目录：major#.minor#/major
     * @param version 版本号
     * @return major目录：major#.minor#/major
     */
    public Path getMajorDirectory(Version version) {
        if (version.major == 0) {
            return null;
        } else {
            return dir.cat(version.toString()).cat(MAJOR);
        }
    }

    /**
     * 得到一个版本的所有minor目录：major#.minor#/minor/(1 ... minor#)
     * @param version version 版本号
     * @return 所有minor目录：major#.minor#/minor/(1 ... minor#)
     * @throws IOException
     */
    public Path[] getMinorDirectories(Version version) throws IOException {        
        if (version.minor == 0) {
            return new Path[0];
        }
        
        Path minorDir = dir.cat(version.toString()).cat(MINOR);
        HashMap<String, Path> childMap = new HashMap<String, Path>();
        for (FileInfo child : fs.listFiles(minorDir)) {
            childMap.put(child.getPath().getName(), child.getPath());
        }

        List<Path> childs = new ArrayList<Path>(childMap.size());
        for (int i = 1; i <= version.minor; i++) {
            Path child = childMap.get(String.valueOf(i));
            if (child != null) {
                childs.add(child);
            } else {
                throw new IOException("directory missed for minor version " + i);
            }
        }

        return childs.toArray(new Path[childs.size()]);
    }

    /**
     * 创建下一个小版本号。创建下一个版本号的操作包括：将上一个小版本数据link到新的目录下，然后将增量目录
     * link到新的目录下。这个操作是原子的。
     * @param deltaDir 增量目录（增量部分数据）
     * @param removeOld 是否在创建新的版本之后删除当前版本
     * @return 新版本号
     * @throws IOException
     */
    public Version createMinorVersion(Path deltaDir, boolean removeOld) throws IOException {
        Version latest = getLatestVersion();
        return createMinorVersion(latest, deltaDir, removeOld);
    }
    
    /**
     * 创建指定版本之后的一个小版本号。这个操作是原子的，即：如果操作失败了会删除临时的垃圾。创建下一个版本
     * 号的操作包括：将上一个小版本数据link到新的目录下，然后将增量目录link到新的目录下。
     * @param currentVersion 指定版本号
     * @param deltaDir 增量目录（增量部分数据）
     * @param removeOld 是否在创建新的版本之后删除当前版本
     * @return 新版本号
     * @throws IOException
     */
    private Version createMinorVersion(Version currentVersion, Path deltaDir, boolean removeOld)
            throws IOException {
        
        Version newVersion;
        Path newVersionDir = null;
        boolean success = false;
        
        try {
            // link当前小版本的数据
            if (currentVersion == null) {
            	// 如果在没有当前version的情况下创建minor版本，会创建0.1版本作为第一个版本
                newVersion = new Version(0, 1);
                newVersionDir = dir.cat(newVersion.toString());
                fs.mkdirs(newVersionDir.cat(MINOR));
            } else {
                newVersion = new Version(currentVersion.major,
                        currentVersion.minor + 1);
                newVersionDir = dir.cat(newVersion.toString());
                Path oldVersionDir = dir.cat(currentVersion.toString());
                if (!fs.link(oldVersionDir, newVersionDir)) {
                    throw new IOException("cannot link old version to new version");
                }
            }
            // link增量数据
            Path minorVersionDir = newVersionDir.cat(MINOR).cat(newVersion.minor+"");
            if (!fs.link(deltaDir, minorVersionDir)) {
                throw new IOException("cannot link data to minor version directory");
            }
            success = true;
            
            // 新版本创建已经完成，是否删除当前版本目录
            if (removeOld && currentVersion != null) {
                fs.delete(dir.cat(currentVersion.toString()));
            }
            return newVersion;
        } finally {
            if (!success && newVersionDir != null) {
                fs.delete(newVersionDir);
            }
        }
    }

    /**
     * 创建下一个大版本号
     * @param dataDir 主数据目录
     * @param removeOld 是否在创建新的版本之后删除当前版本
     * @return 新版本号
     * @throws IOException
     */
    public Version createMajorVersion(Path dataDir, boolean removeOld) throws IOException {
        return createMajorVersion(getLatestVersion(), dataDir, removeOld);
    }
    
    /**
     * 创建指定版本之后的一个大版本号。这个操作是原子的，即：如果操作失败了会删除临时的垃圾。创建下一个版本
     * 号的操作包括：将主数据目录link到大版本号下。
     * @param currentVersion 指定版本号
     * @param dataDir 主数据目录
     * @param removeOld 是否在创建新的版本之后删除当前版本
     * @return 新版本号
     * @throws IOException
     */
    private Version createMajorVersion(Version currentVersion, Path dataDir, boolean removeOld)
            throws IOException {
    	// 如果在没有当前version的情况下建major版本，会创建1.0版本作为第一个版本
        Version newVersion = new Version(currentVersion == null ? 1
                : (currentVersion.major + 1), 0);
        Path path = dir.cat(newVersion.toString());
        fs.mkdirs(path);
        if (!fs.link(dataDir, path.cat(MAJOR))) {
            throw new IOException(
                    "cannot link data dir to major directory under " + path);
        }
        fs.mkdirs(path.cat(MINOR));
        if (removeOld && currentVersion != null) {
            fs.delete(dir.cat(currentVersion.toString()));
        }
        
        return newVersion;
    }
    
    /**
     * 删除当前目录下某个指定的版本
     * @param version 需要删除的版本
     * @throws IOException
     */
    public void removeVersion(Version version) throws IOException {
        Path path = dir.cat(version.toString());
        if (!fs.delete(path)) {
            throw new IOException("cannot remove version " + version);
        }
    }

    /**
     * Sets merge-dirs in a map-merge-conf.
     * @param conf  the MapMergeConf instance
     * @param ver  the ver instance
     * @param startIdx  the starting index
     * @param walker  the walker for each directory
     * @return  the ending index (exclusive)
     * @throws IOException  if an I/O error occurs
     */
    public int setMergeDirs(MapMergeConf conf, Version ver, int startIdx, 
            Class<? extends PairWalkerBase> walker) throws IOException {
        Path[] minors = getMinorDirectories(ver);
        conf.setMergeDir(startIdx ++, getMajorDirectory(ver), walker);
        for (Path minor: minors)
            conf.setMergeDir(startIdx ++, minor, walker);
        
        return startIdx;
    }
    /**
     * Sets merge-dirs in a reduce-merge-conf.
     * @param conf  the ReduceMergeConf instance
     * @param ver  the ver instance
     * @param startIdx  the starting index
     * @param walker  the walker for each directory
     * @return  the ending index (exclusive)
     * @throws IOException  if an I/O error occurs
     */
    public int setMergeDirs(ReduceMergeConf conf, Version ver, int startIdx, 
            Class<? extends PairWalkerBase> walker) throws IOException {
        Path[] minors = getMinorDirectories(ver);
        conf.setMergeDir(startIdx ++, getMajorDirectory(ver), walker);
        for (Path minor: minors)
            conf.setMergeDir(startIdx ++, minor, walker);
        
        return startIdx;
    }
    
    /**
     * Chooses the latest value from a list of values corresponding the same 
     * key. 
     * NOTE: The class of minor values should be a subclass of AbstractOpObject
     *       and the content in it should be of type V.
     * @param <K>  the type of the key
     * @param <V>  the type of the major value.
     * @param values  the array of the value-walkers
     * @param startIdx  the starting index in values
     * @param endIdx  the ending index (clusive)
     * @return  the chosen value. Null if no available value found (i.e. it was
     *          marked as OP_DELETED latestly.
     */
    @SuppressWarnings("unchecked")
    public static <K, V extends IWritable> V choose(
            IWritablePairWalker<K, ? extends IWritable>[] values, int startIdx, 
            int endIdx) {
        // select the latest minor
        AbstractOpObject minor =  null;
        for (int i = startIdx + 1; i < endIdx; i ++) {
            if (values[i] != null && values[i].moreValue()) {
                AbstractOpObject v = (AbstractOpObject) values[i].getValue();
                if (minor == null || v.getTimestamp() > minor.getTimestamp())
                    minor = v;
            } // if
        } // for i
        
        if (minor != null) {
            /*
             * if minor found, return it
             */
            if (minor.getOperator() == AbstractOpObject.OP_DELETED)
                return null;
            return  (V) minor.get();
        } // if
        /*
         * If minor not found, fetch and returns major
         */
        V major = null;
        if (values[startIdx] != null && values[startIdx].moreValue()) {
            major = (V) values[startIdx].getValue();
        } // if
        
        return major;
    }
}
