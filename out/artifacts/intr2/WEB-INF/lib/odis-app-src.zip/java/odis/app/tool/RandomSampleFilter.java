/**
 * @(#)RandomSampleFilter.java, 2009-1-21. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import odis.serialize.IWritable;

/**
 * random sample 工具的filter接口。
 * @author yixun
 * @since 1.5
 * @version 1.0
 */
public interface RandomSampleFilter {

    /**
     * sample时用到的filter，如果不想sample需要filter掉的记录返回true，否则返回false.
     * 
     * @param key
     * @param value
     * @return
     */
    public boolean filter(IWritable key, IWritable value);
}
