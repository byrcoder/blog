package odis.app.job;

import odis.cowork.JobDef;

/**
 * The interface for configuring a job
 * 
 * @author david
 *
 * @param <T>  the type of the job
 */
public interface IJobConfigurer<T extends JobDef> {
    /**
     * Configure the job, i.e. setting properties of job.
     * 
     * @param job  the job to be configured
     */
    public void configure(T job);
}
