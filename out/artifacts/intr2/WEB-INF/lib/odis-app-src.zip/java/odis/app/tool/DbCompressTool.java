/**
 * @(#)DbCompressTool.java, 2007-11-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.PrintWriter;
import java.util.logging.Logger;

import odis.app.view.DataUtils;
import odis.app.view.DataUtils.PathProp;
import odis.cowork.JobResult;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityMapper;
import odis.tools.AbstractCoWorkTool;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Compress one database by block compression.
 * @author river
 *
 */
public class DbCompressTool extends AbstractCoWorkTool {
    public static final Logger LOG = LogFormatter.getLogger(DbCompressTool.class);
    private static final String TOOL_NAME = "DbCompressTool";

    private Options options;
    
    public DbCompressTool() {
        options = new Options();
        options.withOption("s", "src", "set source data to be compressed");
        options.withOption("d", "dst", "set output dir, and use src dir " +
        		"as default if not supplied").hasDefault();
        options.withOption("b", "block_size", "set compress block size, " +
        		"0 means default block size").setDefault(0);
    }
    @Override
    public String comment() {
        return "Compress database";
    }

    @Override
    public void usage(PrintWriter out) {
        options.printHelpInfo(out, TOOL_NAME);
    }

    private String src;
    private String dst;
    private int blockSize;
    
    @Override
    protected boolean processArgs(String[] args) throws Exception {
        try {
            options.parse(args);
        } catch(OptionParseException e) {
            out.println("error: " + e.getMessage());
            usage(out);
            return false;
        }
        
        src = options.getStringOpt("s");
        dst = options.getStringOpt("d", src);
        blockSize = options.getIntOpt("b");
        return true;
    }

    @Override
    public boolean exec(int worker) throws Exception {
        IFileSystem fs = context.getFileSystem();
        
        Path srcPath = context.path(src);
        
        PathProp pathProp = DataUtils.checkPathProp(fs, srcPath);
        if (pathProp == null) {
            LOG.severe("cannot find src path " + srcPath);
            return false;
        }
        if (pathProp.getPathType() != PathProp.TYPE_FOLDER_SEQ_FILE) {
            LOG.severe("database is not standard seq format");
            return false;
        }
        
        MapOnlyJobDef job = context.createMapOnlyJob(TOOL_NAME, worker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        job.addInputDir(helper.getReadInput(srcPath));
        
        job.setPerUnitSplit(true);
        job.setMapper(IdentityMapper.class);
        job.setMapNumber(MapReduceHelper.getContinuousPartCount(fs, srcPath));
        
        job.addOutputDir(0, helper.getUpdateOutput(context.path(dst)), 
                pathProp.getKeyClass(), pathProp.getValClass());
        GenericFileOutputFormat.setCompress(job, 0, blockSize);
        
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) {
            return false;
        }
        helper.printCounters(out, result.getCounters());
        
        return true;
    }

}
