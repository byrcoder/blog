/**
 * 
 */
package odis.app.job;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import odis.tools.AbstractCoWorkTool;
import odis.tools.ToolContext;
import toolbox.text.util.StringUtils;

/**
 * @author phx
 */
public abstract class CoWorkToolGroup extends AbstractCoWorkTool {
    private static Map<String, Map<String, Class<? extends AbstractCoWorkTool>>> 
        toolGroups = new HashMap<String, Map<String, Class<? extends AbstractCoWorkTool>>>();    

    protected static void addTool(String groupName, String toolName,
            Class<? extends AbstractCoWorkTool> toolClass) {
        if (!toolGroups.containsKey(groupName)) {
            toolGroups.put(groupName,
                    new LinkedHashMap<String, Class<? extends AbstractCoWorkTool>>());
        }
        toolGroups.get(groupName).put(toolName, toolClass);
    }
    
    public static Map<String, Class<? extends AbstractCoWorkTool>> getTools(String name) {
        return toolGroups.get(name);
    }
    
    protected PrintWriter out;

    public boolean exec(int nWorker) throws Exception {
        usage(out); return true;
    }

    public boolean setEnv(ToolContext env, String[] args, PrintWriter out)
            throws Exception {
        this.out = out; return true;
    }

    public void usage(PrintWriter out) {
        out.println("Group (" + getName() + ") of Tools");
        out.println("Description: " + comment());
        Set<String> keys = getTools().keySet();
        int len = 0;
        for (String key: keys)
          if (key.length() > len)
            len = key.length();
        if (len > 15)
          len = 15;
        for (String key: keys) {
          String comment = key + " tool.";
          try {
            comment = ((AbstractCoWorkTool)getTools().get(key).newInstance()).comment();
          } catch (Exception e) { } // catch
          int len_comment = 80 - Math.max(len, key.length()) - 7; // 7 spaces
          ArrayList<String> lines = StringUtils.layout(comment, len_comment, "ends");
          out.format("     %-" + len + "s  %s\n", key, (lines.size() > 0 ? lines.get(0) : ""));
          for (int i = 1; i < lines.size(); i ++)
              out.format("     %-" + Math.max(len, key.length()) + "s  %s\n", "", lines.get(i));
        } // for key
    }

    protected Map<String, Class<? extends AbstractCoWorkTool>> getTools() {
        return toolGroups.get(getName());
    }

    abstract protected String getName();
    
    @Override
    public String comment() {
        return "Sub-commands: " + getTools().keySet();
    }
}
