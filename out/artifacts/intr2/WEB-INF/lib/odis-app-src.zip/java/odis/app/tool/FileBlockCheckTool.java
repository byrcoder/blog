/**
 * @(#)FileBlockCheckTool.java, 2008-11-3. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import odis.app.job.AbstractLocalToolWithArg;
import odis.app.tool.BlockReportTool.BlockReport;
import odis.conf.OdisLibConfig;
import odis.dfs.client.DFSClient;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSFileStatus;
import odis.util.BlockingExecutor;
import toolbox.misc.cli.Options;
import toolbox.misc.net.InetAddressUtils;

/**
 * Check if the blocks of one file are consistent. One file should be reported
 * as non-consistent if :
 * <ul>
 * <li>Any block missed in appointed datanode, or no datanode found for one
 * block</li>
 * <li>Checksum of replications of one block are not the same</li>
 * </ul>
 * The checksum of block is calculated by remote process created on datanode.
 * Parallel calc processes could be created according to the <code>"-c"</code>
 * param. Because we use "ssh" to create process on remote datanode, set up
 * "ssh-agent" and add key by "ssh-add" before invoking this tool.
 * 
 * @author river
 */
public class FileBlockCheckTool extends AbstractLocalToolWithArg {

    public String comment() {
        return "Check if blocks of file consistent";
    }

    private DFSClient client; // dfs client used to contact namenode

    private ExecutorService fileTaskQueue; // thread pool for file tasks

    private ExecutorService blockTaskQueue; // thread pool for block check tasks

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("f", "file", "set filename");
        options.withOption("fs", "filesystem", "set filesystem").hasDefault();
        options.withOption("c", "concurrency",
                "set the block check concurrency").setDefault(128).setType(
                Options.TYPE_NUMBER);
    }

    @Override
    public boolean exec() throws Exception {
        // check if ssh-agent set up
        String sshAgentPid = System.getenv("SSH_AGENT_PID");
        if (sshAgentPid == null) {
            out.println("error: please set up ssh-agent before invoking this tool");
            return false;
        }

        // initialize odfs client
        String fsAddress = options.getStringOpt("fs", context.getAppFs());
        client = new DFSClient(InetAddressUtils.createSocketAddr(fsAddress));

        // initialize thread queues
        int concurrency = options.getIntOpt("c");
        fileTaskQueue = BlockingExecutor.createExecutor(concurrency + 5,
                new LinkedBlockingQueue<Runnable>());
        blockTaskQueue = BlockingExecutor.createExecutor(concurrency,
                new LinkedBlockingQueue<Runnable>());

        // iterate the files and submit file check task
        Stack<String> fileStack = new Stack<String>();
        for (String s: options.getOpt("f")) {
            fileStack.push(s);
        }
        while (!fileStack.isEmpty()) {
            String filename = fileStack.pop();
            if (client.isDirectory(filename)) {
                for (DFSFileStatus info: client.listFiles(filename)) {
                    fileStack.push(info.getPath());
                }
            } else {
                fileTaskQueue.submit(new FileTask(
                        new FileCheckRequest(filename)));
            }
        }

        // waiting for all the tasks done
        fileTaskQueue.shutdown();
        fileTaskQueue.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);

        blockTaskQueue.shutdown();
        blockTaskQueue.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);

        return true;
    }

    /**
     * Data structure to record one bad block.
     * 
     * @author river
     */
    public class BadBlockRecord {
        private BlockSizeLocationWithDataPath block; // the location of block

        private BlockReport[] reports; // the checksum data on each datanode

        public BadBlockRecord(BlockSizeLocationWithDataPath block,
                BlockReport[] reports) {
            this.block = block;
            this.reports = reports;
        }
    }

    /**
     * Data structure to hold all data for one file.
     * 
     * @author river
     */
    public class FileCheckRequest {
        private String filename; // filename

        private BlockSizeLocationWithDataPath[] blocks; // all the blocks of this file

        private ArrayList<BadBlockRecord> badBlocks; // the bad blocks of this file

        private int remainedBlockTaskCount; // count of blocks under checking

        public FileCheckRequest(String filename) {
            this.filename = filename;
            this.blocks = null;
            this.badBlocks = null;
        }

        /**
         * Set the blocks list of this file, the count of block check tasks is
         * also initialized to the count of blocks, and the count is decreased
         * every time {@link #finishTask()} called.
         * 
         * @param blocks
         */
        public void initBlocks(BlockSizeLocationWithDataPath[] blocks) {
            this.blocks = blocks;
            this.remainedBlockTaskCount = blocks.length;
        }

        /**
         * Add one bad block record.
         * 
         * @param record
         */
        public void recordBadBlock(BadBlockRecord record) {
            synchronized (badBlocks) {
                badBlocks.add(record);
            }
        }

        /**
         * Set one block check task finished, and return true if all the tasks
         * are finished.
         * 
         * @return
         */
        public synchronized boolean finishTask() {
            remainedBlockTaskCount--;
            return (remainedBlockTaskCount == 0);
        }

    }

    private int fileCount = 0; // count of processed files

    /**
     * Report the check result of one file.
     * 
     * @param request
     * @param e
     */
    private synchronized void report(FileCheckRequest request, Exception e) {

        out.print(fileCount + " [" + request.filename + "]");
        fileCount++;
        if (request.badBlocks == null || request.badBlocks.size() > 0) {
            out.println(" error");
            if (e != null) {
                out.println(e.getMessage());
                e.printStackTrace(out);
            }
            if (request.badBlocks == null) {
                out.println("cannot find blocks for file");
                return;
            }

            for (BadBlockRecord record: request.badBlocks) {
                out.println(BlockReportTool.getBlockFileName(record.block.getBlock())
                        + " inconsistent");
                if (record.reports == null) {
                    out.println("\t no available datanodes");
                } else {
                    for (int i = 0; i < record.reports.length; i++) {
                        out.println("\t" + record.block.getLocations()[i] + " "
                                + record.reports[i]);
                    }
                }
            }
        } else {
            out.println(" ok");
        }
    }

    /**
     * This task get blocks list from namenode, and create and submit all the
     * blocks as {@link BlockTask} to block check thread pool.
     * 
     * @author river
     */
    public class FileTask implements Runnable {
        private FileCheckRequest request;

        public FileTask(FileCheckRequest request) {
            this.request = request;
        }

        public void run() {

            // get block list from namenode
            try {
                BlockSizeLocationWithDataPath[] blocks = client.getBlocksNodes(request.filename);
                if (blocks == null || blocks.length == 0) {
                    report(request, null);
                    return;
                }
                request.initBlocks(blocks);
            } catch (Exception e) {
                report(request, e);
                return;
            }

            // init the badblocks container and submit all the block check tasks
            request.badBlocks = new ArrayList<BadBlockRecord>();
            for (int i = 0; i < request.blocks.length; i++) {
                BlockTask task = new BlockTask(request, i);
                blockTaskQueue.submit(task);
            }
        }

    }

    /**
     * This task get checksum data for one block from all the replica datanodes.
     * We use "ssh" to execute checksum data calc remotely.
     * 
     * @author river
     */
    public class BlockTask implements Runnable {
        private FileCheckRequest request;

        private int idx;

        public BlockTask(FileCheckRequest request, int idx) {
            this.request = request;
            this.idx = idx;
        }

        public void run() {
            BlockSizeLocationWithDataPath block = request.blocks[idx];
            long blockId = block.getBlock();

            if (block.getLocations() == null
                    || block.getLocations().length == 0) {
                request.recordBadBlock(new BadBlockRecord(block, null));
                if (request.finishTask()) {
                    report(request, null);
                }
                return;
            }

            BlockReportTool.BlockReport[] reports = new BlockReportTool.BlockReport[block.getLocations().length];
            int idx = 0;
            for (String loc: block.getLocations()) {
                String hostname = loc.substring(0, loc.indexOf(':'));
                String cmd = "ssh " + hostname + " "
                        + OdisLibConfig.getHomeDir()
                        + "/bin/odis.sh -heap 128M "
                        + BlockReportTool.class.getName() + " -b " + blockId
                        + " -d " + loc;
                String stdout;
                int exitValue;
                try {
                    ProcessBuilder builder = new ProcessBuilder(cmd.split(" "));
                    builder.redirectErrorStream(true);
                    Process process = builder.start();
                    InputStream is = process.getInputStream();
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = is.read(buf)) >= 0) {
                        bos.write(buf, 0, len);
                    }
                    stdout = new String(bos.toByteArray(), "utf-8");
                    try {
                        exitValue = process.waitFor();
                    } catch (InterruptedException e) {
                        exitValue = -1;
                    }

                } catch (IOException e) {
                    e.printStackTrace(out);
                    reports[idx++] = null;
                    continue;
                }

                if (exitValue == 0) {
                    BlockReportTool.BlockReport report = BlockReportTool.BlockReport.parse(stdout);
                    if (report == null) {
                        out.println("error: [cmd : " + cmd
                                + "] bad returned value : " + stdout);
                    }
                    reports[idx++] = report;
                } else {
                    out.println("error: [cmd : " + cmd + "] bad return code "
                            + exitValue + " : " + stdout);
                    reports[idx++] = null;
                }
            }

            boolean error = false;
            for (int i = 0; i < reports.length; i++) {
                if (reports[i] == null) {
                    error = true;
                    break;
                }
                if (i > 0 && !reports[i].equals(reports[i - 1])) {
                    error = true;
                    break;
                }
            }

            if (error) {
                request.recordBadBlock(new BadBlockRecord(block, reports));
            }

            if (request.finishTask()) {
                report(request, null);
            }

        }

    }

}
