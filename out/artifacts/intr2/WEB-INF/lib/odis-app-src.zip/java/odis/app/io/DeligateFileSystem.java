/**
 * @(#)ThrottledFileSystem.java, 2008-4-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.io;

import java.io.File;
import java.io.IOException;

import odis.io.FSInputStream;
import odis.io.FSOutputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.LockStateException;
import odis.io.NamedPermitException;
import odis.io.Path;

/**
 * {@link DeligateFileSystem} contains another real file system instance, and
 * simply overrides every methods by passing requests to the contained file
 * system. Subclass of {@link DeligateFileSystem} may further override some of
 * the methods or add more methods.
 * 
 * @author river
 */
public class DeligateFileSystem extends FileSystem {

    /**
     * The real file system instance used in every method.
     */
    protected IFileSystem real;

    /**
     * Create a {@link DeligateFileSystem} by assigning the argument
     * <code>fs</code> to the field <code>this.real</code>.
     * 
     * @param fs
     */
    protected DeligateFileSystem(IFileSystem fs) {
        this.real = fs;
    }

    /**
     * Return the real name of file system.
     */
    @Override
    public String getName() {
        return real.getName();
    }

    public void completeLocalInput(File localFile) throws IOException {
        this.real.completeLocalInput(localFile);
    }

    public void completeLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        this.real.completeLocalOutput(fsOutputFile, tmpLocalFile);
    }

    public void copyFromLocalFile(File src, Path dst) throws IOException {
        this.real.copyFromLocalFile(src, dst);
    }

    public void copyToLocalFile(Path src, File dst) throws IOException {
        this.copyToLocalFile(src, dst);
    }

    public FSOutputStream createRaw(Path f, boolean overwrite)
            throws IOException {
        return real.createRaw(f, overwrite);
    }

    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent) throws IOException {
        return real.createRaw(f, overwrite, persistent);
    }

    public boolean delete(Path f) throws IOException {
        return real.delete(f);
    }

    @Override
    public boolean delete(Path f, boolean recursive) throws IOException {
        return real.delete(f, recursive);
    }

    public boolean deprive(Path f) throws IOException {
        return deprive(f);
    }

    public boolean exists(Path f) throws IOException {
        return exists(f);
    }

    public long getBlockSize() {
        return real.getBlockSize();
    }

    public long getLength(Path f) throws IOException {
        return real.getLength(f);
    }

    public void getLock(Path file, int type) throws IOException {
        real.getLock(file, type);
    }

    public String getLockState(Path file) throws IOException {
        return real.getLockState(file);
    }

    public boolean isDirectory(Path f) throws IOException {
        return real.isDirectory(f);
    }

    public long lastModified(Path f) throws IOException {
        return real.lastModified(f);
    }

    public boolean link(Path src, Path dst) throws IOException {
        return real.link(src, dst);
    }

    public FileInfo[] listFiles(Path f) throws IOException {
        return real.listFiles(f);
    }

    public void mkdirs(Path f) throws IOException {
        real.mkdirs(f);
    }

    public void moveFromLocalFile(File src, Path dst) throws IOException {
        real.moveFromLocalFile(src, dst);
    }

    public FSInputStream openRaw(Path f) throws IOException {
        return real.openRaw(f);
    }

    public void promoteLock(Path file) throws LockStateException, IOException {
        real.promoteLock(file);
    }

    public void releaseLock(Path file) throws IOException {
        real.releaseLock(file);
    }

    public boolean rename(Path src, Path dst) throws IOException {
        return real.rename(src, dst);
    }

    public File startLocalInput(Path fsInputFile, File tmpLocalFile)
            throws IOException {
        return real.startLocalInput(fsInputFile, tmpLocalFile);
    }

    public File startLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        return real.startLocalOutput(fsOutputFile, tmpLocalFile);
    }

    public long getLengthRecursive(Path f) throws IOException {
        throw new RuntimeException("Not implemented yet!");
        //        return real.getLengthRecursive(f);
    }

    public boolean acquirePermit(String name, int request)
            throws NamedPermitException {
        // TODO Auto-generated method stub
        return false;
    }

    public void createPermit(String name, int p, boolean detached)
            throws NamedPermitException {
        real.createPermit(name, p, detached);
    }

    public void releasePermit(String name, int p) {
        real.releasePermit(name, p);
    }

    public void releasePermit(String name) {
        real.releasePermit(name);
    }

    public void removePermit(String name) throws NamedPermitException {
        real.removePermit(name);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent, int flags) throws IOException {
        return real.createRaw(f, overwrite, persistent, flags);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent, int flags, int blockSize) throws IOException {
        return real.createRaw(f, overwrite, persistent, flags, blockSize);
    }

    /**
     * Close the contained file system.
     */
    @Override
    protected void closeInternal() throws IOException {
        this.real.close();
    }

}
