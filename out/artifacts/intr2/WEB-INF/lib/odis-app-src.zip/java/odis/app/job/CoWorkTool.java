package odis.app.job;

import java.io.IOException;
import java.io.PrintWriter;

import odis.io.IFileSystem;
import odis.io.Path;
import odis.tools.AbstractCoWorkTool;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

/**
 * An abstract cowork-tool.
 * 
 * Usage:
 *   
    public class DemoCoworkTool extends CoWorkTool {
        public static final String TOOL_NAME = "cli-demo";
    
        @Override
        protected void appendOptions(Options opts) {
            addOption("i", 1, "The input file");
            addOption("o", 1, "The output file. The description of this " +
                            "option could be very long.");
            addRequiredOption("r", 1, "A required option.");
        }
    
        @Override
        protected boolean exec() throws Exception {
            if (args.hasOption("i")) {
                out.println("-i parameter is specified: " 
                        + args.getOptionValue("i"));
            } // if
            if (args.hasOption("o")) {
                out.println("-o parameter is specified: " 
                        + args.getOptionValue("o"));
            } // if
            
            out.println("All options: " + Arrays.toString(args.getOptions()));
            out.println("Left args: " + Arrays.toString(args.getArgs()));
            return true;
        }
    
        @Override
        public String comment() {
            return "A demo showing the use of cli";
        }
    
    }
 * @author david
 *
 */
public abstract class CoWorkTool extends AbstractCoWorkTool {
    /**
     * The number of workers for cowork job
     */
    public int nWorker;
    /**
     * The file-system
     */
    public IFileSystem fs;
    /**
     * The path to the root folder
     */
    public Path rootPath;
    /**
     * The path to the temporary folder
     */
    public Path tempPath;
    /**
     * The arguments as a CommandLine instance
     */
    public CommandLine args;

    protected Options opts;
    abstract protected void appendOptions(Options opts);
    
    public CoWorkTool() {
        opts = new Options();
        appendOptions(opts);
        opts.addOption(new Option("h", "help", false, 
                "Print this help information."));
    }

    /** 
     * Add an option that only contains a short-name without arguments.
     *
     * @param opt Short single-character name of the option.
     * @param desc  Self-documenting description
     */
    public void addOption(String opt, String desc) {
        opts.addOption(opt, false, desc);
    }
    /** 
     * Add an option that only contains a short-name.
     * It may be specified as requiring an argument.
     *
     * @param opt Short single-character name of the option.
     * @param argNum  the number of required arguments. if 0, no require for 
     *                arguments.
     * @param desc  Self-documenting description
     */
    public void addOption(String opt, int argNum, String desc) {
        Option o = new Option(opt, argNum > 0, desc);
        o.setArgs(argNum);
        opts.addOption(o);
    }
    /**
     * Add a requried option that only contains a short-name.
     * It may be specified as requiring an argument.
     * @param opt Short single-character name of the option.
     * @param argNum  the number of required arguments. if 0, no require for 
     *                arguments.
     * @param desc  Self-documenting description
     */
    public void addRequiredOption(String opt, int argNum, String desc) {
        Option o = new Option(opt, argNum > 0, desc);
        o.setArgs(argNum);
        o.setRequired(true);
        opts.addOption(o);
    }
    
    @Override
    public boolean processArgs(String[] args) {
        try {
            this.fs = context.getFileSystem();
            this.rootPath = context.path("");
            this.tempPath = context.tempPath("");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        for (String arg: args) {
            if (arg.startsWith("-"))
                if (opts.getOption(arg) == null) {
                    out.println("Unknown optioin: " + arg);
                    usage(out);
                    return false;
                } // if
        } // for arg
        
        try {
            this.args = new PosixParser().parse(opts, args);
        } catch (ParseException e) {
            out.println(e.getMessage());
            usage(out);
            return false;
        }

        if (this.args.hasOption("help")) {
            usage(out);
            return false;
        } // if
        
        return true;
    }
    
    /**
     * Execute the tool.
     * @return  true if success, false if failed
     * @throws Exception  if an error occurs
     */
    protected abstract boolean exec() throws Exception;
    
    public boolean exec(int nWorker) throws Exception {
        this.nWorker = nWorker;
        System.out.println("=== Executing " + this.getClass().getSimpleName() 
                + ".exec() ===");
        return exec();
    }
    
    @Override
    public void usage(PrintWriter out) {
        out.println(comment());
        String toolName = "cmd";
        try {
            toolName = this.getClass().getField("TOOL_NAME").get(
                    this).toString();
        } catch (Exception e) {
            try {
                toolName = this.getClass().getField("TOOLNAME").get(
                        this).toString();
            } catch (Exception e1) {
            }
        }
        new HelpFormatter().printHelp(out, HelpFormatter.DEFAULT_WIDTH, 
                toolName, null, opts,
                HelpFormatter.DEFAULT_LEFT_PAD, HelpFormatter.DEFAULT_DESC_PAD, 
                null, true);
    }

}
