/**
 * @(#)AutoPersistent.java, 2008-3-24. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.serialize.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标志指定的类型的所有域在没有用{@link Persistent}标识的时候的持久化状态是true还是false，
 * 当一个类型没有指定这个annotation的时候，这个值默认是true.
 * 
 * @author river
 *
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface AutoPersistent {
    boolean value();
}
