package odis.app.job.demo;

import odis.app.job.AbstractEasyCoworkTool;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.serialize.IWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.Url;

/**
 * Easy Cowork Demo Tool.
 * @author hujie
 *
 */
public class EasyCoworkDemoTool extends AbstractEasyCoworkTool {

	@Override
	public String comment() {
		return "easy cowork demo tool";
	}

	@Override
	public boolean exec(int worker) throws Exception {
		return mapReduceJobExec(worker, new OutputKeyValueClass(
				// mapper output key/value class
				Url.class, IntWritable.class,
				// reducer output key/value class
				Url.class, LongWritable.class));
	}

	public static class Mapper extends AbstractMapper<IWritable, IWritable> {

		@Override
		public void map(IWritable key, IWritable value, ICollector collector) {
			// do map task
		}
		
	}
	
	public static class Reducer extends AbstractReducer<IWritable, IWritable> {

		@Override
		public void reduce(IWritable key,
				IWritablePairWalker<IWritable, IWritable> values,
				ICollector collector) {
			// do reduce task
		}
		
	}
	
}
