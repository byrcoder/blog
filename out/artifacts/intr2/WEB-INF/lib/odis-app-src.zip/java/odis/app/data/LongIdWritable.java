/**
 * @(#)LongIdWritable.java, 2007-7-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.data;

import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.LongBinaryComparator;
import odis.serialize.lib.BytesAccessable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.MD5Writable;
import toolbox.text.util.HexString;

/**
 * Id of long(8bytes). We suggest use this class instead of DocID/SiteID.
 * @author river
 *
 */
public class LongIdWritable extends LongWritable {

    public static final int BYTES = Long.SIZE / Byte.SIZE;
    static {
        WritableRegistry.register(LongIdWritable.class, "LongId_0", BYTES, 
                LongBinaryComparator.class);
    }
    
    /**
     * Create instance with default value of Long.MAX_VALUE.
     */
    public LongIdWritable() { this.value = Long.MAX_VALUE; }

    /**
     * Create DocID from long.
     * @param id  the long format of the id
     */
    public LongIdWritable(long id) { super(id); }

    /**
     * Copy-constructor.
     * @param id
     */
    public LongIdWritable(LongIdWritable id) {  super(id.get()); }

    /**
     * Set value of this LongWritable from hex String.
     * @param hexString  The hex string
     */
    @Override
    public void parse(String hexString) throws ParseException {
        try {
            this.value = HexString.paddedHexToLong(hexString);
        } catch (NumberFormatException e) {
            throw new ParseException(DocID.class, hexString);
        }
    }

    /**
     * Set the value to low 8 bytes of md5(s).
     * @param url  The normalized url
     */
    public void setMd5Value(String s) {
        this.value = MD5Writable.halfDigest(s);
    }
    
    /**
     * Set the value to low 8 bytes of md5(s).
     * @param s
     */
    public void setMd5Value(BytesAccessable s) {
        this.value = MD5Writable.halfDigest(s);
    }

    /**
     * Check if the value is zero.
     * @return
     */
    public boolean isZero() { return this.value == 0; }

    /**
     * Return string in hex format.
     */
    @Override
    public String toString() {
        return HexString.longToPaddedHex(this.value).toUpperCase();
    }

    /**
     * Create a new instance with value of low 8bytes of md5(s).
     * @param s
     * @return
     */
    public static LongIdWritable md5(String s) {
        LongIdWritable value = new LongIdWritable();
        value.setMd5Value(s);
        return value;
    }

    /**
     * Create a new instance with value of low 8bytes of md5(s).
     * @param s
     * @return
     */
    public static LongIdWritable md5(BytesAccessable s) {
        LongIdWritable value = new LongIdWritable();
        value.set(MD5Writable.halfDigest(s));
        return value;
    }
    
    /**
     * Command line support.
     * @param args
     * @throws Exception
     */
    public static void main(String args[]) throws Exception {
        if (args.length == 0) {
            System.out.println("params: string");
            return;
        }
        LongIdWritable value = md5(args[0]);
        System.out.println(value);
    }

    
}
