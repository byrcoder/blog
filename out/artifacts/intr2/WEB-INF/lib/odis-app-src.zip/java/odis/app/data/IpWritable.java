/**
 * @(#)IpWritable.java, 2007-12-29. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.data;

import odis.serialize.IParsable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.IntBinaryComparator;
import odis.serialize.lib.IntWritable;
import toolbox.misc.net.IpUtils;

/**
 * Writable for ipv4.
 * @author river
 */
public class IpWritable extends IntWritable implements IParsable {
    static {
        WritableRegistry.registerAlias(IpWritable.class, "ip");
        WritableRegistry.register(IpWritable.class, 4, IntBinaryComparator.class);
    }
    
    public IpWritable() { super(); }
    
    public IpWritable(int ip) { super(ip); }
    
    @Override
    public String toString() {
        return IpUtils.formatIp(this.get());
    }
    
    @Override
    public void parse(String str) {
        try {
            this.set(IpUtils.parseIp(str));
        } catch(Exception e) {
            this.set(-1);
        }
    }
}
