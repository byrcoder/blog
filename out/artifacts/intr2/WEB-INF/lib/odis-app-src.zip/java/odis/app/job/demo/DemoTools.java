package odis.app.job.demo;

import odis.app.job.CoWorkToolExecSet;

public class DemoTools extends CoWorkToolExecSet {
    public static String NAME = "odisclidemos";
    
    static {
        addTool(NAME, CoWorkDemoTool.TOOL_NAME, CoWorkDemoTool.class);
        addTool(NAME, DemoCoworkTool.TOOL_NAME, DemoCoworkTool.class);
    }

    @Override
    protected String getName() {
        return "odisclidemos";
    }

    @Override
    public String comment() {
        return "Demo tools.\n" + super.comment();
    }
}
