package odis.app.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.Url;
import odis.tools.MapReduceHelper;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

/**
 * 抽取给定的站点列表的页面。利用二分查找定位site在文件中的位置，在输入比较大的时候，比直接遍历
 * 整个输入会快很多。使用:
 * <ul>
 * <li>SitesDumpTool -i input_path -o output_path -f sites_file [-n sample]</li>
 * <li>输入要求key是{@link Url}, 并且是排好序的，partitioner任意</li>
 * <li>输出和输入的partition是一样的，并且也是排好序的</li>
 * <li>输入的site列表文件是每行一个站点的文本文件</li>
 * </ul>
 * <p>
 * 支持对每个站点，在每个partition上sample一定数量。使用-n指定。默认不sample, 输出所有的
 * <p>
 * 支持子站点模式(以*.开头)。如
 *   163.com 会匹配 163.com, 但不会匹配 a.163.com
 *   *.163.com 会匹配 a.163.com,  b.a.163.com, 但不会匹配 163.com
 * <p>
 * 支持路径前缀。如 news.163.com/special/ 或者 *.163.com/11/
 * <p>
 * 站点列表文件示例:
 *   www.tsinghua.edu.cn
 *   *.pku.edu.cn
 *   *.163.com/11/
 *   news.163.com/special/
 *   www.youku.com/show_page/
 *   www.youku.com/v_olist/
 *
 * @author zhanglh
 *
 */
public class SitesDumpTool extends AbstractCoWorkToolWithArg {
    public static Logger LOG = LogFormatter.getLogger(SitesDumpTool.class);
    
    @Override
    public String comment() {
        return "dump site urls using binary search";
    }
    
    private String inputStr, outputStr, siteListFile;
    
    private int sampleNumber;
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input", "input path");
        options.withOption("o", "output", "output path");
        options.withOption("f", "sitelistfile", "sitelist path in local");
        options.withOption("n", "number", "sample url number per site per part"
                ).setDefault(0);
    }
    
    @Override
    public boolean processOptions(Options options) throws Exception {
        inputStr = options.getStringOpt("i");
        outputStr = options.getStringOpt("o");
        siteListFile = options.getStringOpt("f");
        sampleNumber = options.getIntOpt("n");
        if (sampleNumber < 0) {
            out.println("sample number should not be negative");
            return false;
        }
        if ((new File(siteListFile)).exists() == false) {
            out.println(siteListFile + " do not exist!");
            return false;
        }
        return true;
    }
   
    @Override
    public boolean exec(int nWorker) throws Exception {
        MapOnlyJobDef job = context.createMapOnlyJob(getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        // no real input here
        Path input = helper.getReadInput(context.path(inputStr));
        int partNum = MapReduceHelper.getContinuousPartCount(fs, input);
        job.setMapper(Mapper.class);
        job.setMapNumber(partNum);
        job.setCheckMapProgress(false);
        
        job.getConfig().setProperty(Mapper.NAME_FS, fs.getName());
        job.getConfig().setProperty(Mapper.NAME_INPUT, input.getAbsolutePath());
        job.getConfig().setProperty(Mapper.NAME_FILE, 
                new File(siteListFile).getAbsolutePath());
        job.getConfig().setProperty(Mapper.NAME_SAMPLENUM, sampleNumber);
        
        SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                input.cat(CoWorkUtils.getPartID(0)));
        
        helper.addUpdateOutputDir(0, context.path(outputStr), Url.class, 
                (Class<? extends IWritable>)reader.getValueClass(), null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        reader.close();
        
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    /**
     * pattern to dump
     *
     * @author zhanglh
     *
     */
    private static class Pattern implements Comparable<Pattern> {
        public Url url = new Url();
        public Url site = new Url();
        public String path;
        public boolean dumpSubSite;
        
        /**
         * constructor
         * 
         * @param urlStr
         */
        public Pattern(String urlStr) {
            url.set(urlStr);
            url.getSite(site);
            path = url.getPath();
            dumpSubSite = (site.get().charAt(0) == '.');
        }
        
        /**
         * 检查当前的url和目标的匹配程度
         * 
         * @param siteToCheck
         * @param pathToCheck
         * @return 匹配上，返回0。
         *         没有匹配上，并且已经比目标大，返回 1
         *         没有匹配上，但后面还有可能匹配上，返回 -1
         */
        public int checkMatch(Url siteToCheck, String pathToCheck) {
            // 检查site, 这里必须用Url的比较，不能用string的
            int comp = siteToCheck.compareTo(site);
            if (comp < 0)
                return -1;
            if (dumpSubSite)
                comp = siteToCheck.get().endsWith(site.get())? 0 : 1;
            if (comp > 0)
                return 1;
            
            // 检查path
            if (path.length() == 0)
                return 0;
            // 子站点如果path不匹配后面可能还有，非子站点就没有机会了
            comp = pathToCheck.compareTo(path);
            if (comp < 0)
                return -1;
            if (comp > 0)
                comp = pathToCheck.startsWith(path) ? 0 : 1;
            if (comp == 0)
                return 0;
            if (dumpSubSite) {
                return -1; 
            } else { 
                return 1;
            }
        }
        
        @Override
        public int compareTo(Pattern that) {
            return this.url.compareTo(that.url);
        }
        
        @Override
        public String toString() {
            return url.toString();
        }
    }
    
    /**
     * mapper, 没有进行真正的map, 实际的工作都是在 mapEnd 里完成的
     *
     * @author zhanglh
     *
     */
    public static class Mapper extends AbstractMapper<Url, IWritable> {
        public static String PREFIX = Mapper.class.getName();
        public static String NAME_FS = PREFIX + ".fs";
        public static String NAME_INPUT = PREFIX + ".input";
        public static String NAME_FILE = PREFIX + ".sitelistfile";
        public static String NAME_SAMPLENUM = PREFIX + ".samplenum";
        
        private Pattern [] patternList;
        
        private FileSystem fs;
        private SequenceFile.Reader reader;
        
        private int sampleNum;
        
        private TaskRunnable task;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            this.task = task;
            // init reader and writer
            try {                
                String fsName = job.getConfig().getString(NAME_FS);   
                fs = FileSystem.getNamed(fsName);
                
                String input = job.getConfig().getString(NAME_INPUT);
                String partId = CoWorkUtils.getPartID(task.getPartIdx());
                reader = new SequenceFile.Reader(fs, new Path(input, partId));
            } catch (IOException e) {
                closeReader();
                throw new TaskFatalException("init fs or reader failed ", e);
            }
            
            // read site list
            String siteListFile = job.getConfig().getString(NAME_FILE);
            BufferedReader fileReader = null;
            try {
                String line = null;
                List<Pattern> patterns = new ArrayList<Pattern> ();
                fileReader = new BufferedReader(new InputStreamReader(
                        new FileInputStream(new File(siteListFile)), "utf-8"));
                while((line = fileReader.readLine()) != null) {
                    line = line.trim();
                    if (line.length() == 0 || line.startsWith("#"))
                        continue;
                    if (line.startsWith("*."))
                        line = line.substring(1);
                    
                    Pattern pattern = new Pattern(line);
                    patterns.add(pattern);
                    LOG.info("add pattern " + pattern);
                }
                patternList = patterns.toArray(new Pattern[0]);
                Arrays.sort(patternList);
            } catch (IOException e) {
                closeReader();
                throw new TaskFatalException("read site list failed " + e);
            } finally {
                try {
                    fileReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            // sample url
            sampleNum = job.getConfig().getInt(NAME_SAMPLENUM);
        }
           
        private void closeReader() {
            try {
                if (reader != null)
                    reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        private void dumpUrl(ICollector collector) throws IOException {
            // prepare
            Class valClass = reader.getValueClass();
            
            Url tmpUrl = new Url();
            IWritable tmpValue = (IWritable)ClassUtils.newInstance(valClass);
            
            reader.sync(0);
            long startPos = reader.getPosition();
            
            int patternIdx = 0;
            while (patternIdx < patternList.length) {        
                Pattern currentPattern = patternList[patternIdx];
                Url patternUrl = currentPattern.url;
                patternIdx ++;
                
                LOG.info("start to process " + patternUrl);
                List<Pattern> currentPatterns = new ArrayList<Pattern> ();
                Map<Pattern, RecordSampler> samplerMap = 
                    new HashMap<Pattern, RecordSampler>();
                currentPatterns.add(currentPattern);
                samplerMap.put(currentPattern, new RecordSampler(
                        sampleNum, Url.class, valClass));
                
                // 处理pattern中存在重叠的情况，如 *.163.com/11/ 和 news.163.com
                if (currentPattern.dumpSubSite) {
                    for (; patternIdx < patternList.length; patternIdx ++) {
                        Pattern pattern = patternList[patternIdx];
                        if (!pattern.site.get().endsWith(
                                currentPattern.site.get()))
                            break;
                        currentPatterns.add(pattern);
                        samplerMap.put(pattern, new RecordSampler(
                                sampleNum, Url.class, valClass));
                        LOG.info("add related pattern: " + pattern);
                    }
                }
                
                long from = binarySearchKey(fs, reader, startPos, patternUrl);
                if (from < 0) {
                    LOG.info("search " + patternUrl + " failed");
                    continue;
                }
                reader.seek(from);
                LOG.info("search site from position: " + from);
                // 找到不小于patternUrl的第一个key value
                if (reader.next(patternUrl, tmpUrl, tmpValue) == false)
                    return;  // reach end
                int count = 0;
                do {
                    if (count % 10000 == 0) {
                        LOG.info("processed " + count + 
                                " urls, current url: " + tmpUrl);
                    }
                    count ++;
                    
                    Pattern matchedPattern = findMatch(currentPatterns, tmpUrl);
                    
                    if (currentPatterns.size() == 0) {
                        LOG.info("End dump " + patternUrl + ", url= " + tmpUrl);
                        break;
                    }
                    startPos = reader.getPos(); // 放在上面的if里可能会跳过一个记录
                    if (matchedPattern == null) {
                        continue;
                    }
                    
                    if (sampleNum > 0) {
                        RecordSampler sampler = samplerMap.get(matchedPattern);
                        sampler.add(tmpUrl, tmpValue);
                    } else {
                        collector.collect(tmpUrl, tmpValue);
                    }
                    task.getCounter("matched-" + matchedPattern).inc();
                } while (reader.next(tmpUrl, tmpValue));
                
                if (sampleNum > 0) {
                    finishSample(samplerMap.values(), collector);
                }
            }
        }
        
        private static void finishSample(Collection<RecordSampler> samplers,
                ICollector collector) {
            List<KeyValWrapper> resultList = new ArrayList<KeyValWrapper> ();
            for (RecordSampler sampler : samplers) {
                KeyValWrapper []resultBuffer = sampler.getResultBuffer();
                for (int i = 0; i < sampler.getResultCount(); i ++) {
                    resultList.add(resultBuffer[i]);
                }
            }
            Collections.sort(resultList);
            for (KeyValWrapper result : resultList)
                collector.collect(result.getKey(), result.getValue());
        }
        
        /**
         * 检查当前的url和目标的匹配程度, 并删除不可能再命中的pattern
         * 
         * @param patterns
         * @param url
         * @return 返回匹配上的pattern, 如果没有匹配上返回null
         */
        private static Pattern findMatch(List<Pattern> patterns, Url url) {
            Url site = url.getSite();
            String path = url.getPath();
            int i = patterns.size() - 1;
            for (; i >= 0; i --) {
                Pattern pattern = patterns.get(i);
                int res = pattern.checkMatch(site, path);
                if (res == 0)
                    return pattern;
                if (res > 0) {
                    patterns.remove(i);
                    LOG.info("remove pattern " + pattern + " url=" + url);
                }
            }
            return null;
        }
        
        @Override
        public void map(Url key, IWritable value, ICollector collector) {
            // 没有输入， map不会被执行到
        }
        
        @Override
        public void mapEnd(ICollector collector) {
            try {
                dumpUrl(collector);
            } catch(IOException e) {
                // 不使用 TaskFatalException, 允许重试
                throw new RuntimeException("dump url error", e);
            } finally {
                closeReader();
            }
        }
    }
    
    private static final int MAX_BINARY_SEARCH_DISTANCE = 1024 * 1024 * 10;
    
    /**
     * 使用二分查找在SequenceFile中寻找key的大概位置
     * 返回的位置会是比key的位置稍小或者等于的位置, 但如果起始位置就比key大，会返回起始位置  
     * 如果已经到了文件结尾返回 -1
     * 
     * @param fs
     * @param reader
     * @param startPos, 
     * @param target
     * @return
     * @throws IOException
     */
    public static long binarySearchKey (FileSystem fs, 
            SequenceFile.Reader reader, long startPos, 
            IWritable target) throws IOException {
        long lowPos = startPos;
        long hiPos = reader.getEnd();
        long midPos;
        
        IWritableComparable lowKey, hiKey, midKey;
        IWritable lowValue, hiValue, midValue;
        
        try {
            lowKey = (IWritableComparable) reader.getKeyClass().newInstance();
            midKey = (IWritableComparable) reader.getKeyClass().newInstance();
            hiKey = (IWritableComparable) reader.getKeyClass().newInstance();

            lowValue = (IWritable) reader.getValueClass().newInstance();
            midValue = (IWritable) reader.getValueClass().newInstance();
            hiValue = (IWritable) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new IOException("cannot initialize object");
        }

        reader.seek(lowPos);
        reader.next(lowKey, lowValue);

        int comp = lowKey.compareTo(target);
        if (comp >= 0) {
            return lowPos;
        }

        if(lowPos > hiPos)
            return -1;
            
        while (hiPos - lowPos > MAX_BINARY_SEARCH_DISTANCE) {
            midPos = (lowPos + hiPos) / 2;
            reader.sync(midPos);
            midPos = reader.getPosition();
            reader.next(midKey, midValue);
            comp = midKey.compareTo(target);

            if (comp >= 0) {
                IWritableComparable tmpKey = hiKey;
                hiKey = midKey;
                midKey = tmpKey;
                
                IWritable tmpValue = hiValue;
                hiValue = midValue;
                midValue = tmpValue;
                hiPos = midPos;                
            } else if (comp < 0) {                
                IWritableComparable tmpKey = lowKey;
                lowKey = midKey;
                midKey = tmpKey;

                IWritable tmpValue = lowValue;
                lowValue = midValue;
                midValue = tmpValue;
                lowPos = midPos;               
            }
        }

        return lowPos;
    }
    
    /**
     * IWritable key value wrapper
     *
     * @author zhanglh
     *
     */
    public static class KeyValWrapper implements Comparable<KeyValWrapper> {
        private IWritableComparable key;
        private IWritable value;
        
        /**
         * constructor
         * @param key
         * @param value
         */
        public KeyValWrapper(IWritableComparable key, IWritable value) {
            this.key = key;
            this.value = value;
        }
        
        /**
         * set by copyFields
         * @param key
         * @param value
         */
        public void copyFields(IWritableComparable key, IWritable value) {
            this.key.copyFields(key);
            this.value.copyFields(value);
        }
        
        /**
         * get key
         * @return key
         */
        public IWritableComparable getKey() {
            return key;
        }
        
        /**
         * get value
         * @return value
         */
        public IWritable getValue() {
            return value;
        }
        
        @Override
        public int compareTo(KeyValWrapper that) {
            return this.key.compareTo(that.key);
        }
    }
    
    /**
     * sample given count records
     *
     * @author zhanglh
     *
     */
    public static class RecordSampler {
        private int sampleNum;
        
        private KeyValWrapper []keyValues;
        
        private int totalCount;
        
        private Random random = new Random();
        
        /**
         * constructor
         * 
         * @param sampleNum
         * @param keyClass
         * @param valClass
         */
        public RecordSampler(int sampleNum, Class keyClass, Class valClass) {
            this.sampleNum = sampleNum;
            keyValues = new KeyValWrapper[sampleNum];
            for (int i = 0; i < sampleNum; i ++) {
                keyValues[i] = new KeyValWrapper(
                        (IWritableComparable)ClassUtils.newInstance(keyClass),
                        (IWritable)ClassUtils.newInstance(valClass));
            }
        }
        
        /**
         * 添加key, value。
         * 
         * @param key
         * @param value
         */
        public void add(IWritableComparable key, IWritable value) {
            if (totalCount < sampleNum) {
                keyValues[totalCount].copyFields(key, value);
            } else {
                int r = random.nextInt(totalCount + 1);
                if (r < sampleNum) {
                    keyValues[r].copyFields(key, value);
                }
            }
            totalCount ++;
        }
        
        /**
         * get saved result count
         * @return
         */
        public int getResultCount() {
            return Math.min(totalCount, sampleNum);
        }
        
        /**
         * get result buffer
         * @return
         */
        public KeyValWrapper []getResultBuffer() {
            return keyValues;
        }
    }
}
