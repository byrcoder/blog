package odis.app.data;

import java.io.DataInput;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.LongBinaryComparator;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.MD5Writable;
import odis.serialize.lib.UTF8Writable;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * DocID a long that represents id of each document (url)
 * 
 * Change Log:
 *   - 1/25/2007 (Li Zhuang) Cleanup API and add Javadoc
 * 
 * @author river
 */

public class DocID extends LongWritable {
    
    private static final Logger LOG = LogFormatter.getLogger(DocID.class);
    public static final int BYTES = Long.SIZE / Byte.SIZE;
    static {
        WritableRegistry.register(DocID.class, "DocID", BYTES, 
                LongBinaryComparator.class);
    }
  
    public final static DocID NULL_DOCID = new DocID(0L);

    public DocID() { this.value = Long.MAX_VALUE; }

    /**
     * Create DocID from long
     * @param id  the long format of the id
     */
    public DocID(long id) { super(id); }

    /**
     * Create DocID from another DocID
     * @param docId  Another DocID
     */
    public DocID(DocID docId) {  set(docId); }
    /**
     * Create DocID from a URL instance
     * @param docId  the URL instance
     */
    public DocID(URL url) { set(url.toString()); }

    /**
     * Create DocID from url.  The url is normalized.
     * @param url  The normalized url
     */
    public DocID(String url) { set(url); }

    /**
     * Set value of this DocID from hex String
     * @param hexString  The hex string
     */
    public void parse(String hexString) throws ParseException {
        try {
            this.value = HexString.paddedHexToLong(hexString);
        } catch (NumberFormatException e) {
            LOG.log(Level.WARNING, "Not a padded hex string", e);
            throw new ParseException(DocID.class, hexString);
        }
    }

    /**
     * Set value of this DocID according to the normalized url (thread-safe)
     * @param url  The normalized url
     */
    public void set(String url) {
        this.value = MD5Writable.digest(url).halfDigest();
    }
    
    /**
     * Set value of this DocID from another instance of DocID (thread-safe)
     * @param docId anther docID
     */
    public void set(DocID docId) {
        this.value = docId.get();
    }    

    public boolean isZero() { return this.value==0; }

    public String toString() {
        return HexString.longToPaddedHex(this.value).toUpperCase();
    }

    /**
     * Skip a length of DocID in data input
     * @param in  The DataInput
     * @throws IOException
     */
    public static void skip(DataInput in) throws IOException {
        in.skipBytes(BYTES);
    }

    /**
     * Create docId with normalized url, no more normalization needed.
     * @param url  The normalized url
     * @return  A new DocID instance given that url
     */
    public static DocID getDocID(String url) {
        return new DocID(url);
    }

    /**
     * Create docId with normalized url in UTF8Writable format, no more 
     * normalization needed.
     * @param url  The normalized url
     * @return  A new DocID instance given that url
     */
    public static DocID getDocID(UTF8Writable url) {
        return new DocID(url.toString());
    }

    /**
     * Read DocID from DataInput
     * @param in  The DataInput object to be read from
     * @return  A new DocID instance
     * @throws IOException
     */
    public static DocID getDocID(DataInput in) throws IOException {
        DocID id = new DocID();
        id.readFields(in);
        return id;
    }

    /**
     * Parse and create a DocID from hex string
     * @param hexString  The hex string
     * @return  A new instance of DocID 
     * @throws ParseException
     */
    public static DocID parseDocID(String hexString) throws ParseException {
        DocID id = new DocID();
        id.parse(hexString);
        return id;
    }

    public static void main(String args[]) throws Exception {
        if (args.length == 0) {
            System.out.println("params: url");
            return;
        } // if
        DocID id = new DocID(args[0]);
        System.out.println(id);
    }

}
