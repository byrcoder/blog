package odis.app.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;
import java.util.TreeSet;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.tools.MapReduceHelper;
import odis.tools.misc.SeqFileFixTool.Fixer;
import toolbox.misc.channel.IObjectOutput;
import toolbox.misc.channel.MultiOutputPipe;
import toolbox.misc.channel.NoOutputPipeException;

public class CheckDataUtils {
    /**
     * A fixer class that can fix fragile files and bad files. The fixer fix bad
     * files using odis.tools.misc.SeqFileFixTool.Fixer, and fix fragile files
     * by copying file. Usage: FileFixer fixer = new FileFixer(200, 20, fs,
     * tmpDir, 3); fixer.addBadFile(...); fixer.addFragileFile(...); ...
     * fixer.stop();
     * 
     * @author David
     */
    public static class FileFixer extends MultiOutputPipe {
        public void addBadFile(Path path) throws InterruptedException {
            try {
                put("bad", path);
            } catch (NoOutputPipeException e) {
                throw new RuntimeException("All threads failed!");
            }
        }

        public void addFragileFile(Path path) throws InterruptedException {
            try {
                put("fragile", path);
            } catch (NoOutputPipeException e) {
                throw new RuntimeException("All threads failed!");
            }
        }

        static Random rand = new Random();

        public FileFixer(int bufLen, int nThread, final IFileSystem fs,
                final Path tmpDir, final int repl) throws IOException {
            super(new IObjectOutput() {
                DFSClient client;

                Path fixPipeTmpDir;
                {
                    DistributedFileSystem dfs = (DistributedFileSystem) fs;
                    client = dfs.getClient();

                    fixPipeTmpDir = tmpDir.cat("fix-pipe");

                    client.mkdirs(fixPipeTmpDir.toString(), (byte) repl);
                }

                /*
                 * Arguments:
                 *   cmd   String  "bad"/"fragile"
                 *   path  Path    the path
                 */
                public void output(Object... objects) throws Exception {
                    String cmd = objects[0].toString();
                    Path path = (Path) objects[1];
                    Path tmpFolder;
                    synchronized (this) {
                        String name = rand.nextLong() + "";
                        while (fs.exists(fixPipeTmpDir.cat(name)))
                            name = rand.nextLong() + "";
                        tmpFolder = fixPipeTmpDir.cat(name);
                        fs.mkdirs(tmpFolder);
                    }
                    try {
                        Path tmpFile = tmpFolder.cat("tmp");

                        if (cmd.equals("bad")) {
                            /*
                             * Fix a bad file
                             */
                            Fixer fixer = new Fixer(
                                    FileSystem.getNamed(fs.getName()), path,
                                    tmpFile, null);
                            try {
                                fixer.fix();
                                MapReduceHelper.replace(fs, path, tmpFile);
                                System.out.println("Bad file " + path
                                        + " is successfuly fixed!");
                            } catch (IOException e) {
                                System.err.println("Failed to fix bad file "
                                        + path + "!");
                                e.printStackTrace();
                            }
                        } else if (cmd.equals("fragile")) {
                            /*
                             * Fix a fragile file
                             */
                            try {
                                FileSystem.copyContents(
                                        FileSystem.getNamed(fs.getName()),
                                        path, tmpFile, false);
                                MapReduceHelper.replace(fs, path, tmpFile);
                                System.out.println("Fragile file " + path
                                        + " is successfuly fixed!");
                            } catch (IOException e) {
                                System.err.println("Failed to fix fragile file "
                                        + path + "!");
                                e.printStackTrace();
                            }
                        } // else
                    } finally {
                        fs.delete(tmpFolder);
                    }
                }
            }, bufLen, nThread, false);
        }
    }

    /**
     * The data-structure for checking results. Fields: fragileFiles
     * TreeSet<String> the set of fragile files. A fragile file is a file at
     * least one of the blocks contains less copies (than <copy>) badFiles
     * TreeSet<String> the set of bad files. A bad file is a file at least one
     * of the blocks no matter exists on any datanode.
     * 
     * @author David
     */
    public static class CheckResult {
        public TreeSet<String> fragileFiles = new TreeSet<String>();

        public TreeSet<String> badFiles = new TreeSet<String>();

        /**
         * Whether this file is bad.
         * 
         * @return true if this file is bad, i.e. contains bad files, or false
         *         otherwise
         */
        public boolean isBad() {
            return badFiles.size() > 0;
        }
    }

    /**
     * Check a sequence-file (with many parts) to see if it contains fragile and
     * bad files.
     * 
     * @param fs
     *            the file-system instance
     * @param path
     *            the path to the file to be checked
     * @param copy
     *            the number of copies for each block. The file with less than
     *            <copy> number of blocks are considered as a bad/fragile file.
     * @return the checking result as a CheckResult instance
     * @throws Exception
     *             if an error occurs. If the <path> does not exist or is not a
     *             directory, a FileNotFoundException will be thrown.
     */
    public static CheckResult checkSeqDB(IFileSystem fs, Path path, int copy)
            throws Exception {
        if (!fs.exists(path)) {
            throw new FileNotFoundException(path + " does not exist!");
        } // if

        if (!fs.isDirectory(path)) {
            throw new FileNotFoundException(path + " should be a directory!");
        } // if

        if (!(fs instanceof DistributedFileSystem)) {
            return new CheckResult();
        } // if

        DistributedFileSystem dfs = (DistributedFileSystem) fs;
        DFSClient client = dfs.getClient();

        FileInfo[] files = fs.listFiles(path);
        CheckResult res = new CheckResult();
        TreeSet<String> badFiles = res.badFiles;
        TreeSet<String> fragileFiles = res.fragileFiles;
        for (FileInfo file: files) {
            BlockSizeLocationWithDataPath[] blks = client.getBlocksNodes(file.getPath().toString());
            boolean isBad = false;
            boolean isFragile = false;
            for (BlockSizeLocationWithDataPath blk: blks) {
                int cnt = blk.getLocations().length;
                if (cnt == 0) {
                    isBad = true;
                    break;
                } // if
                if (cnt < copy) {
                    isFragile = true;
                } // if
            } // for blk
            if (isBad)
                badFiles.add(file.getPath().getName());
            else if (isFragile)
                fragileFiles.add(file.getPath().getName());
        } // for file

        return res;
    }
}
