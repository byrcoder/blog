package odis.app.view;

import java.io.IOException;
import java.util.logging.Logger;

import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import toolbox.misc.LogFormatter;

/**
 * 一个增量数据库的表示（对应实体为一个增量数据目录）
 * 
 * @author 吴迎晖（river@rd.netease.com）
 * 
 * 修改历史：
 *   2007/6/3（庄莉）：添加javadoc说明和注释
 */
@SuppressWarnings("unchecked")
public class IncrementalDatabase implements Searchable {
    public static final Logger LOG = LogFormatter.getLogger(IncrementalDatabase.class);
    
    private IFileSystem fs;  // incremental db所在的文件系统
    private Path file;      // incremental db的文件路径，这个路径下按照IncrementalDirectory存储

    private Database [] databases = null;  // 主数据目录和增量数据目录
    private IncrementalDirectory.Version current = null; // 当前版本号
    private BasicPartitioner partitioner = null; // 数据目录的partition办法
    
    /** 
     * @param fs incremental db所在的文件系统
     * @param file incremental db的文件路径，这个路径下按照IncrementalDirectory存储
     */
    public IncrementalDatabase(IFileSystem fs, Path file) {
        this(fs, file, null);
    }
    
    /**
     * @param fs incremental db所在的文件系统
     * @param file incremental db的文件路径，这个路径下按照IncrementalDirectory存储
     * @param partitioner 数据目录的partition办法
     */
    public IncrementalDatabase(IFileSystem fs, Path file, BasicPartitioner partitioner) {
        this.fs = fs;
        this.file = file;
        this.partitioner = partitioner;
    }
    
    /**
     * 在这个database中寻找指定的key对应的value
     */
    public synchronized IWritable search(IWritableComparable key) throws IOException {
        checkUpdate();
        for (int i=databases.length-1; i>=0; i--) {
            IWritable value = databases[i].search(key);
            if (value != null) return value;
        }
        return null;
    }
    
    /**
     * 检查db所在的incremental目录是否出现了新版本号
     * @throws IOException
     */
    private void checkUpdate() throws IOException {
        IncrementalDirectory incDir = new IncrementalDirectory(fs, file);
        IncrementalDirectory.Version [] versions = incDir.getVersions();
        IncrementalDirectory.Version latest = IncrementalDirectory.latest(versions);
        if (current == null || !latest.equals(current)) {
            load(incDir, latest);
            current = latest;
        }
    }
    
    /**
     * 读入一个incremental directory下面的指定版本。当主版本号为0时，没有major部分，只有
     * 若干minors部分。
     * @param incDir incremental directory所在的目录
     * @param version 指定版本号
     * @throws IOException
     */
    private void load(IncrementalDirectory incDir, IncrementalDirectory.Version version) 
            throws IOException {
        LOG.info("Reload incremental database " + file + " at version " + version);
        if (version.getMajor()<0 || version.getMinor()<0)
        	throw new IOException("Cannot have negative number in version: " + version);
        Path [] minors = incDir.getMinorDirectories(version);
        databases = new Database[(version.getMajor() > 0 ? 1 : 0) + minors.length];
        // 读入major的目录
        int stdIdx = 0;
        if (version.getMajor() > 0) {
            databases[0] = new Database(fs, incDir.getMajorDirectory(version), partitioner);
            stdIdx = 1;
        }
        // 读入minor的各个目录
        for (int i=0; i<minors.length; i++) {
            databases[i+stdIdx] = new Database(fs, minors[i], partitioner);
        }
    }

}
