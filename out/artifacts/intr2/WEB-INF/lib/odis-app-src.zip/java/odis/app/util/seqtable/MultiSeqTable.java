package odis.app.util.seqtable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import odis.io.FileInfo;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.tools.LocalToolContext;

/**
 * 将一个"传统意义上的SequenceFile"作为一个table进行操作。
 * 所谓"传统意义上的SequenceFile"是指一个目录，下面的每一个part都是一个真正的SequenceFile.
 * 
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Apr 16, 2007
 */
public class MultiSeqTable<K extends IWritableComparable, V extends IWritable> 
        implements ITable<K, V> {
    
    private SeqTable<K,V>[] tables;

    /**
     * constructor
     * @param env  the tool context
     * @param path  the path of sequence file
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public MultiSeqTable(LocalToolContext env, Path path) throws Exception {
        FileInfo[] files = env.getFileSystem().listFiles(path);
        tables = new SeqTable[files.length];
        for(int i=0; i<tables.length; i++) {
            tables[i] = new SeqTable<K,V>(env, files[i].getPath());
        }
    }

    public void commit() throws IOException {
        for(SeqTable<K, V> t : tables) {
            t.commit();
        }
    }

    public void commit(Class<?> kClass, Class<?> vClass) throws IOException {
        for(SeqTable<K, V> t : tables) {
            t.commit(kClass, vClass);
        }
    }

    public List<V> delete(K key) {
        List<V> list = new ArrayList<V>();
        for(SeqTable<K,V> t : tables) {
            list.addAll(t.delete(key));
        }
        return list;
    }

    public V selectValue(K key) {
        for(SeqTable<K,V> t : tables) {
            V v = t.selectValue(key);
            if(v != null)
                return v;
        }
        return  null;
    }

    public List<V> selectValues(K key) {
        List<V> list = new ArrayList<V>();
        for(SeqTable<K,V> t : tables) {
            list.addAll(t.selectValues(key));
        }
        return list;
    }

    public void updateValue(K key, V value) {
        for(SeqTable<K,V> t : tables) {
            t.updateValue(key, value);
        }
    }

    public void updateValue(K key, V value, int start, int end) {
        for(SeqTable<K,V> t : tables) {
            t.updateValue(key, value, start, end);
        }
    }

    public void updateValue(K key, V value, int idx) {
        for(SeqTable<K,V> t : tables) {
            t.updateValue(key, value, idx);
        }
    }

    public int size() {
        int size = 0;
        for(SeqTable<K,V> t : tables) {
            size += t.size();
        }
        return size;
    }

    public boolean isKeyUnique() {
        Set<K> set = null;
        for(SeqTable<K,V> t : tables) {
            if(!t.isKeyUnique())
                return false;
            Set<K> newSet = t.getKeySet();
            if(set == null)
                set = newSet;
            else {
                if(set.removeAll(newSet))
                    return false;
                else
                    set.addAll(newSet);
            }
        }
        return true;
    }

    public Pair<K,V> getPair(int idx) {
        for(int i=0; i<tables.length; i++) {
            if(idx >= tables[i].size()) {
                idx -= tables[i].size();
                continue;
            }
            return tables[i].getPair(idx);
        }
        return null;
    }
    
    public SeqTable<K,V>[] getSeqTables() {
        return this.tables;
    }

    public void insert(K key, V value, int idx) {
        for(int i=0; i<tables.length; i++) {
            if(idx > tables[i].size()) {
                idx -= tables[i].size();
                continue;
            }
            tables[i].insert(key, value, idx);
            return;
        }
    }

}
