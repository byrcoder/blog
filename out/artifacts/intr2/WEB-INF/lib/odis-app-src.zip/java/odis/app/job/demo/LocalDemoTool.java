package odis.app.job.demo;

import java.io.PrintWriter;
import java.util.Arrays;

import odis.tools.AbstractLocalTool;

public class LocalDemoTool extends AbstractLocalTool {
    public static String TOOL_NAME = "localdemo";
    
    public String comment() {
        return "Local demo tool.";
    }

    public boolean exec(String[] arg0) throws Exception {
        System.out.println("  exec: arg0 = " + Arrays.toString(arg0));
        return true;
    }

    public void usage(PrintWriter arg0) {
        out.println("  coworkdemo");
    }

}
