/**
 * @(#)DbConvertTool.java, 2007-6-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IndexedFileInputFormat;
import odis.mapred.lib.IndexedFileOutputFormat;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.tools.AbstractCoWorkTool;
import odis.tools.MapReduceHelper;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Convert db from one type to another type.
 * @author river
 *
 */
public class DbConvertTool extends AbstractCoWorkTool {
    public static final Logger LOG = LogFormatter.getLogger(DbConvertTool.class);

    private static final String NAME_CONVERTER = "DbConvertTool.converter_name";
    
    /**
     * Converter interface.
     *
     * @author river
     *
     * @param <K1> source key
     * @param <V1> source value
     * @param <K2> target key
     * @param <V2> target value
     */
    public static interface IConverter<K1,V1,V2> {
        public Class getKeyClass();
        public Class getSrcValClass();
        public Class getDstValClass();
        
        /**
         * Convert the key and value (k1, v1) and store
         * converted data into (k2, v2). If the (k1, v1)
         * should be removed, return false, else return true.
         * @param k1
         * @param v1
         * @param k2
         * @param v2
         * @return
         */
        public boolean convert(K1 k1, V1 v1, V2 v2);
    }

    private Options options;
    
    public DbConvertTool() {
        options = new Options();
        options.withOption("d", "database", "set database to be converted");
        options.withOption("converter", "converter_class", "set the converter class");
    }
    
    @Override
    public String comment() {
        return "Converter";
    }

    @Override
    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "dbconver");
    }
    
    private String converterClassname;
    private String dbName;
    
    @Override
    protected boolean processArgs(String[] args) throws Exception {
        if (!super.processArgs(args)) return false;
        try {
            options.parse(args);
        } catch(OptionParseException e) {
            out.println("error: " + e.getMessage());
            usage(out);
            return false;
        }
        converterClassname = options.getStringOpt("converter");
        dbName = options.getStringOpt("d");
        return true;
    }

    @Override
    public boolean exec(int nWorker) throws Exception {

        IConverter converter;
        // validate the converter
        try {
            Class converterClass = Class.forName(converterClassname);
            if (!IConverter.class.isAssignableFrom(converterClass)) {
                LOG.severe("converter should be subclass of IConverter");
                return false;
            }
            converter = (IConverter)ClassUtils.newInstance(converterClass);
        } catch(Exception e) {
            LOG.log(Level.SEVERE, "initialize converter class " + converterClassname, e);
            return false;
        }
        
        FileSystem fs = context.getFileSystem();
        
        // check the database
        Path dbPath = context.path(dbName);
        if (!fs.exists(dbPath)) {
            LOG.log(Level.SEVERE, "cannot find db at " + dbName);
            return false;
        }
        FileInfo [] childs = fs.listFiles(dbPath);
        if (childs == null || childs.length==0) {
            LOG.log(Level.SEVERE, "no data in db");
            return false;
        }
        int partitionNumber = childs.length;
        Path partPath = childs[0].getPath();
        boolean isIndexedFile = fs.isDirectory(partPath);
        
        Class keyClass;
        Class valClass;
        int compressBlockSize;
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, 
                isIndexedFile ? partPath.cat(IndexedFile.DATA_FILE_NAME) : partPath);
        try {
            keyClass = reader.getKeyClass();
            valClass = reader.getValueClass();
            if (keyClass != converter.getKeyClass() || valClass != converter.getSrcValClass()) {
                LOG.log(Level.SEVERE, "key/val class mismatch");
                return false;
            }
            compressBlockSize = reader.getCompressBlockSize();
        } finally {
            reader.close();
        }
        
        MapOnlyJobDef job = context.createMapOnlyJob("DbConvertTool", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        // input and mapper
        job.addInputDir(helper.getUpdateInput(dbPath), 
                isIndexedFile ? IndexedFileInputFormat.class : SeqFileInputFormat.class);
        job.setMapper(ConvertMapper.class);
        job.setMapNumber(partitionNumber);
        job.setPerUnitSplit(true);
        
        // output
        job.addOutputDir(0, helper.getUpdateOutput(dbPath), 
                converter.getKeyClass(), 
                converter.getDstValClass(),
                isIndexedFile ? IndexedFileOutputFormat.class : SeqFileOutputFormat.class);
        if (compressBlockSize > 0) {
            GenericFileOutputFormat.setCompress(job, 0, compressBlockSize);
        }
        
        // config
        job.getConfig().setProperty(NAME_CONVERTER, converterClassname);
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) {
            return false;
        }
        helper.printCounters(out, result.getCounters());
        
        return true;
    }

    public static class ConvertMapper extends AbstractMapper {
        private IConverter converter;
        private Object dstValue;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            try {
                converter = (IConverter)ClassUtils.newInstance(
                        Class.forName(job.getConfig().getString(NAME_CONVERTER)));
                dstValue = ClassUtils.newInstance(converter.getDstValClass());
            } catch(Exception e) {
                throw new TaskFatalException("initialize converter failed", e);
            }
        }

        @SuppressWarnings("unchecked")
        public void map(Object key, Object value, ICollector collector) {
            if (converter.convert(key, value, dstValue)) {
                collector.collect(key, dstValue);
            }
        }
        
    }
}
