/**
 * @(#)RandomSampleSiteUrlTool.java, 2009-1-8. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.file.SequenceFile;
import odis.io.Path;
import odis.mapred.ICollector;
import odis.mapred.IMapper;
import odis.mapred.IReducer;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapOnlyTaskRunnable;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MapTaskRunnable;
import odis.mapred.ext.IMergeReducer;
import odis.mapred.ext.ReduceMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.UrlSiteMd5Partitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.Url;
import odis.serialize.toolkit.WritableArrayList;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

/**
 * <p>这个工具能够在以Url为key的输入数据中为每个指定的site随机抽取n个数据，并且输出抽取的结果。
 * 指定site的方式可以是一个site，一个文件中的多个site或者一个sequence file中的海量site，具体
 * 设置请参见后面的输入参数详解。
 * <p>注意由于运行时需要知道具体的IWritable类型，因此使用时需要确定当前运行目录下有相应的
 * IWritable类型存在，并且有正确实现了copyFields方法。
 * <p>例如，我们要在"/home/test/data_a"数据中为每一个site随机抽取100个数据到"/home/test/data_a_sampled"中，可以使用
 * 如下的命令:
 * <code>
 *   bin/odis.sh -wn workerNum odis.app.tool.RandomSampleSiteUrlTool -i /home/test/data_a -o /home/test/data_a_sampled -n 100
 * </code>
 * 
 * <p>输入参数
 * <ul>
 *     <li>i: 输入数据的路径，除普通的数据目录外，该参数支持指定路径是一个part文件，
 *     如/home/test/data_a/part-00000，另外应保证输入数据是以Url为key的；</li>
 *     <li>o: sample结果输出的路径；</li>
 *     <li>n: 每个site sample的记录数目；</li>
 *     <li>p: 输出结果的part数，当输入只有1个part时输出也一定是1个part，此时该参数无效；</li>
 *     <li>s: 需要sample的site；<li>
 *     <li>f: 当需要sample多个site时，将这些site放入一个文件中，该参数指定sample site
 *     的文件，该文件放在运行目录的根路径下即可。</li>
 *     <li>merge: 当需要sample的site非常多而不能在内存放下时，该参数可指定一个sitedb的路径，
 *     工具会和sitedb做merge，sample出所有sitedb中的site。注意sitedb应该事先以
 *     UrlSiteMd5Partitioner partition好，此时参数p指定的输出part数无效，输出结果的part
 *     数将和sitedb的part数相等。如果-s，-f，-merge三个参数都未设置，则会对输入数据的每一个
 *     site都sample出n条记录；</li>
 *     <li>urlSiteMd5: 输入数据是否按UrlSiteMd5Partitioner，当urlSiteMd5设定，输出
 *     part数和输入part数又相等时，只做MapOnlyJob。</li>
 *     <li>filter: 如果只sample数据中符合某种条件的记录，则需要实现
 *     odis.app.tool.RandomSampleFilter接口中的filter(IWritable key, 
 *     IWritable value)方法，对满足sample条件的记录该方法返回false，不满足需要filter的
 *     记录返回true，用该参数指定实现类的全名（完整包名+类名）。</li>
 * </ul>
 * 
 * <p>注意：输入的sampleNum太大或者数据本身的object太大时，可能将内存撑爆。
 * <p>输出的数据具有如下的特点：
 * <ul>
 *   <li>输出数据的part数目默认与输入数据的part数一致，也可以通过-p参数设置；</li>
 *   <li>输出数据的key, value以及压缩属性都和输入数据一致.；</li>
 *   <li>输出数据的key是url，按UrlMd5Partitioner进行partition。</li>
 * </ul>
 * 
 * <p>sample算法描述：
 * <p>假设从n条记录中随机sample出k条记录，k已知，而n事先并不知道，算法在一遍扫描过后完成sample。
 * <p>算法先将扫描的前k条记录放入sample数组中，继续向后扫描，对扫到的大于k的任意一条记录j，产生
 * 一个[0, j-1]的随机整数r，如果r < k，则sample数组r的位置替换为记录j，否则不做任何改动。
 * <p>证明：对任意的第i条记录，将扫描到第j条记录时i在sample数组中的这个事件记为s(j)，
 * (j >= i)，则根据上述算法，在扫第(j-1)条记录时i留在sample数组中的条件下，扫第j条i仍然留下的
 * 概率：
 * <p>               1       (j<=k)  
 * P(s(j)|s(j-1)) = {
 *                   (j-1)/j (j>k) 只要随机数不是i在sample数组中的位置，i就可以继续留下。
 * 而扫第i条记录i被sample到数组中的概率：
 * <p>         1 (i<=k)
 * P(s(i)) = { 
 *             k/i (i>k)
 * <p>则根据乘法公式，在n条记录全部扫描完成后，i被sample出的概率为从i开始一直到n，每一次扫描i都留
 * 在sample数组中的概率的乘积，于是有：
 * <p>当i<k时：P(s(i))P(s(i+1)|s(i))P(s(i+2)|s(i+1))...P(s(n)|P(s(n-1)) = 
 * P(s(i))P(s(i+1)|s(i))...P(s(k)|s(k-1))P(s(k+1)|s(k)...P(s(n)|P(s(n-1)) =
 * 1 * P(s(k+1)|s(k)P(s(k+2)|P(s(k+1)...P(s(n)|P(s(n-1)) = 
 * k/(k+1) * (k+1)/(k+2) * ... * (n-1)/n = k/n
 * <p>当i>k时：P(s(i))P(s(i+1)|s(i))P(s(i+2)|s(i+1))...P(s(n)|P(s(n-1)) = 
 * k/i * i/(i+1) * (i+1)/(i+2) * ... * (n-1)/n = k/n
 * <p>因此，对于任意一条记录i，在扫描完所有的n条记录后，i被sample出的概率是k/n，算法是等概率sample的。
 * 
 * @author yixun
 * @since 1.5
 * @version 1.0
 */
public class RandomSampleSiteUrlTool extends AbstractCoWorkToolWithArg {

    private static final Logger LOG = LogFormatter.getLogger(RandomSampleSiteUrlTool.class);
    public static final String TOOL_NAME = "RandomSampleSiteUrlTool";
    public static final String NAME_SAMPLENUM = TOOL_NAME + ".sampleNum";
    public static final String NAME_VALUECLASS = TOOL_NAME + ".valueClass";
    public static final String NAME_SAMPLESITE = TOOL_NAME + ".sampleSite";
    public static final String NAME_SAMPLESITEFILE = TOOL_NAME + ".sampleSiteFile";
    public static final String NAME_NEEDMERGE = TOOL_NAME + ".needMerge";
    public static final String NAME_RANDOM_SAMPLE_FILTER = 
        TOOL_NAME + ".ramdomSampleFilter";
    
    private String input;
    private String output;
    private int sampleNum;
    private String sampleSite;
    private String sampleSiteFileName;
    private String mergeSitePath;
    private boolean isUrlSiteMd5;
    private int reducePartNum;
    private String filterClassName;

    public String comment() {
        return "This tool samples specific number records for specific site from input.";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("o", "output", "set output path.");
        options.withOption("i", "input", "set input path.");
        options.withOption("n", "sampleNum", "set number of sample record.");
        options.withOption("p", "reducePartNum", 
                "set part number for reduce.").setDefault(-1);
        options.withOption("s", "site", 
                "set site need to be sampled.").hasDefault();
        options.withOption("f", "siteFile", 
                "set a file for sites need to be sampled.").hasDefault();  
        options.withOption("merge", "mergedSiteDb", 
                "set merged site db.").hasDefault();
        options.withOption("urlSiteMd5", "is UrlSiteMd5Partitioner");
        options.withOption("filter", "filter", 
                "set filter class name, "
                + "should inherit from odis.app.tool.RandomSampleFilter.").hasDefault();
    }
    
    @Override
    public boolean processOptions(Options options) throws Exception {
        reducePartNum = options.getIntOpt("p");
        if (reducePartNum != -1 && reducePartNum <= 0) {
            LOG.info("reducePartNum should be positive "
                    + "or -1 as default (in defaut case, "
                    + "reducePartNum will set as input part number later)");
            return false;
        }
        input = options.getStringOpt("i");
        output = options.getStringOpt("o");
        sampleNum = options.getIntOpt("n");
        sampleSite = options.getStringOpt("s");
        sampleSiteFileName = options.getStringOpt("f");
        mergeSitePath = options.getStringOpt("merge");
        isUrlSiteMd5 = options.isOptSet("urlSiteMd5");
        filterClassName = options.getStringOpt("filter");
        return true;
    } 

    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(input);
        Path outputPath = context.path(output);
        String fileName = inputPath.getName();
        LOG.info("input file name: " + fileName);
        Path tempInputPath = null;
        if (fileName.startsWith("part-")) {
            tempInputPath = MapReduceHelper.createTempDir(fs, 
                    context.tempPath(TOOL_NAME), inputPath.getParent());
            Path part = tempInputPath.cat(CoWorkUtils.getPartID(0));
            fs.link(inputPath, part);
            LOG.info("link input " + inputPath.getAbsolutePath() + " to "
                    + tempInputPath.getAbsolutePath());
            inputPath = tempInputPath;
        } 
        int inputPartNum = MapReduceHelper.getContinuousPartCount(fs, inputPath);
        LOG.info("partNum = " + inputPartNum);
        if (inputPartNum < 1) {
            LOG.info("part number for src error.");
            return false;
        }
        if (reducePartNum == -1) {
            reducePartNum = inputPartNum;
        }
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, 
                inputPath.cat(CoWorkUtils.getPartID(0)));
        Class<? extends IWritable> valueClass = reader.getValueClass();        
        String valueClassName = valueClass.getName();
        LOG.info("valueClassName = " + valueClassName);
        MapOnlyJobDef job;
        MapReduceHelper helper = null;        
        //如果不需merge site db
        if (mergeSitePath == null) {
            //输入只有一个part或者输入是UrlSiteMd5Partitioner的并且reducePartNum和输入
            //的partNum相等，则只需做MapOnly即可。
            if (inputPartNum == 1 || (isUrlSiteMd5 && reducePartNum == inputPartNum)) {
                job = context.createMapOnlyJob(TOOL_NAME, nWorker);      
            } else {
                job = context.createMapReduceJob(TOOL_NAME, nWorker);
                MapReduceJobDef mapReduceJob = (MapReduceJobDef)job;
                mapReduceJob.setReducer(SampleMR.class);
                mapReduceJob.setReduceNumber(reducePartNum);
                mapReduceJob.setMergeKeyValClass(Url.class, valueClass);
                UrlSiteMd5Partitioner.setCompress(mapReduceJob);
                mapReduceJob.setPartitionerClass(UrlSiteMd5Partitioner.class);
                mapReduceJob.setWalkerClass(ReuseWalker.class);
            }
        } else { //需要和给定site db 做merge
            job = context.createMapReduceJob(TOOL_NAME, nWorker);
            helper = new MapReduceHelper(context, job);
            MapReduceJobDef mapReduceJob = (MapReduceJobDef)job;            
            mapReduceJob.setMergeKeyValClass(Url.class, UrlValueWrapperList.class);
            UrlSiteMd5Partitioner.setCompress(mapReduceJob);
            mapReduceJob.setPartitionerClass(UrlSiteMd5Partitioner.class);
            mapReduceJob.setWalkerClass(ReuseWalker.class);
            ReduceMergeConf rmconf = new ReduceMergeConf();
            rmconf.setMergeCount(1);
            Path mergeSiteDb = context.path(mergeSitePath);
            rmconf.setMergeDir(0, helper.getReadInput(mergeSiteDb), 
                    ReuseWalker.class);
            rmconf.setMergeReducer(MergeReducer.class);
            mapReduceJob.plugin(rmconf);
            reducePartNum = MapReduceHelper.getContinuousPartCount(fs, 
                    mergeSiteDb);
            mapReduceJob.setReduceNumber(reducePartNum);
            mapReduceJob.getConfig().setBoolean(NAME_NEEDMERGE, true); 
        }
        if (helper == null) {
            helper = new MapReduceHelper(context, job);
        }
        LOG.info("input is " + inputPath.getAbsolutePath());
        helper.addReadInputDir(inputPath, null);
        job.setMapper(SampleMR.class);
        job.setMapNumber(inputPartNum);
        job.setPerUnitSplit(true);
        // output channels
        helper.addUpdateOutputDir(0, outputPath, Url.class, valueClass, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        //set parameters.
        job.getConfig().setInt(NAME_SAMPLENUM, sampleNum); 
        job.getConfig().setProperty(NAME_RANDOM_SAMPLE_FILTER, filterClassName);  
        if (sampleSite != null) {
            job.getConfig().setProperty(NAME_SAMPLESITE, sampleSite); 
        }
        if (sampleSiteFileName != null) {
            File sampleSiteFile = new File(sampleSiteFileName); 
            LOG.info("sampleSiteFile = " + sampleSiteFile.getAbsolutePath());
            BufferedReader sampleSiteFileReader = null;
            try {
                sampleSiteFileReader = 
                    new BufferedReader(new InputStreamReader(
                            new FileInputStream(sampleSiteFile)));
            } catch (FileNotFoundException e) {
                LOG.log(Level.WARNING, "Not found sampleSiteFile: " 
                        + sampleSiteFile.getAbsolutePath(), e);
                return false;
            } finally {
                sampleSiteFileReader.close();
            }
            job.getConfig().setProperty(NAME_SAMPLESITEFILE, 
                    sampleSiteFile.getAbsolutePath()); 
        }
        
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        
        if (tempInputPath != null && fs.exists(tempInputPath)) {
            LOG.info("delete temp input: " + tempInputPath.getAbsolutePath());
            fs.delete(tempInputPath);
        }
        return true;
    }
    
    /**
     * 不merge sitedb时的sample站点url的map和reduce.
     * 做merge时也用该类先做map. 
     * 
     * @author yixun
     * @since 1.5
     * @version 1.0
     */
    public static class SampleMR implements IMapper<Url, IWritable>, IReducer<Url, IWritable> {        

        private static final String[] FILE_URL_SUFFIX = new String[] {
            ".doc", ".xls", ".ppt", ".pdf", ".mp3"
        };
        private Url prevSite = new Url();
        private int sampleNum;
        private UrlValueWrapper[] sampleRecords;
        private boolean[] sampleFlags;
        private int sampleSiteUrlIdx = 0;
        private Set<String> sampleSiteSet = new HashSet<String>();
        private UrlValueWrapperList sampleUrlValueWrapperList = new UrlValueWrapperList();
        private Random random = new Random();
        private RandomSampleFilter filter;
        private boolean needMerge;
        private Counter fileUrlCounter;
        private Counter siteCounter;    
        private Counter urlLackSiteCounter;
        private Counter filterCounter; 
        
        public void configure(JobDef job, TaskRunnable task) {
            if (task instanceof MapOnlyTaskRunnable
                    || task instanceof MapTaskRunnable) {
                String filterClassName = job.getConfig().getString(NAME_RANDOM_SAMPLE_FILTER);
                if (filterClassName != null && !filterClassName.equals("")) {
                    try {
                        filter = (RandomSampleFilter) Class.forName(filterClassName).newInstance();
                    } catch (InstantiationException e) {
                        throw new TaskFatalException(e);
                    } catch (IllegalAccessException e) {
                        throw new TaskFatalException(e);
                    } catch (ClassNotFoundException e) {
                        throw new TaskFatalException(e);
                    }
                }
                needMerge = job.getConfig().getBoolean(NAME_NEEDMERGE, false);
                String sampleSite = job.getConfig().getString(NAME_SAMPLESITE);
                if (sampleSite != null) sampleSiteSet.add(sampleSite);
                //读取文件中指定的多个sample site
                String sampleSiteFileName = 
                    job.getConfig().getString(NAME_SAMPLESITEFILE);
                if (sampleSiteFileName != null) {
                    BufferedReader sampleSiteFileReader = null;
                    try {
                        File sampleSiteFile = new File(sampleSiteFileName); 
                        LOG.info("sampleSiteFile = " + sampleSiteFile.getAbsolutePath());
                        sampleSiteFileReader = 
                            new BufferedReader(new InputStreamReader(
                                    new FileInputStream(sampleSiteFile)));
                        String line = null;
                        while ((line = sampleSiteFileReader.readLine()) != null) {
                            if (!line.startsWith("#")) {
                                sampleSiteSet.add(line.trim());
                            }
                        }            
                    } catch (IOException e) {
                        throw new TaskFatalException("read sample site file failed.", e);
                    } finally {
                        if (sampleSiteFileReader != null) {
                            try {
                                sampleSiteFileReader.close();
                            } catch (IOException e) {
                                throw new TaskFatalException("close sample site file failed.", e);
                            }
                        }
                    }
                }
            }

            sampleNum = job.getConfig().getInt(NAME_SAMPLENUM);
            sampleRecords = new UrlValueWrapper[sampleNum];
            sampleFlags = new boolean[sampleNum];
            for (int i = 0; i < sampleNum; ++i) {
                sampleFlags[i] = false;
            }
            fileUrlCounter = task.getCounter("fileUrlCounter");
            siteCounter = task.getCounter("siteCounter");
            urlLackSiteCounter = task.getCounter("urlLackSiteCounter");
            filterCounter = task.getCounter("filterCounter");
        }
        
        /**
         * map阶段的collect，对pageattr中的每一个site进行sample，输出site->urlList对
         * reduce阶段与cloaking site库进行merge，选出一定数量的site，sample出url
         * @param urls
         * @param collector
         */
        private void doCollect(ICollector collector) {
            if (null == prevSite || prevSite.get().equals("")) return;
            siteCounter.inc();
            int realSampleNum = 0;
            sampleUrlValueWrapperList.clear();
            for (int i = 0; i < sampleNum; ++i) {
                if (sampleFlags[i]) {
                    if (needMerge) {
                        sampleUrlValueWrapperList.add(sampleRecords[i]);
                    } else {
                        collector.collect(sampleRecords[i].getUrl(), sampleRecords[i].getValue());
                    }
                    sampleFlags[i] = false;
                    realSampleNum++;
                }
            }
            if (needMerge) {
                collector.collect(prevSite, sampleUrlValueWrapperList);
            }
            if (realSampleNum < sampleNum) {
                urlLackSiteCounter.inc();
            }
        }
        
        public void map(Url key, IWritable value, ICollector collector) {
            if (filter != null && filter.filter(key, value)) {
                filterCounter.inc();
                return;
            }
            String host = key.getHostname();
            if (sampleSiteSet.size() == 0 || sampleSiteSet.contains(host)) {
                String urlStr = key.get();            
                //如果是word, pdf等文件类型的url，则舍去。
                for (String suffix: FILE_URL_SUFFIX) {
                    if (urlStr.endsWith(suffix)) {
                        fileUrlCounter.inc();
                        return;
                    }
                }
                doSample(key, value, collector); 
            }
        }

        /**
         * 从site下未知总量的url中sample出确定数目的url
         * 算法描述：
         * 假设要sample出的数目sampleNum = 5，顺序扫描每一个url，把前5个先放入
         * sample url的数组中，当扫描序号大于等于5时，产生一个0到扫描序号的随机数，
         * 如果这个随机数小于5，则置换掉随机数所在位置的url，否则不做任何操作。
         * 这个算法能保证从实现未知数目的url中等概率的sample出确定数目的url。
         * @param key
         * @param value
         * @param collector
         */
        private void doSample(Url key, IWritable value, ICollector collector) {
            Url site = key.getSite();
            if (!site.equals(prevSite)) {
                doCollect(collector);
                prevSite.copyFields(site);
                sampleSiteUrlIdx = 0;                    
                if (sampleRecords[sampleSiteUrlIdx] == null) {                            
                    sampleRecords[sampleSiteUrlIdx] = new UrlValueWrapper();        
                }
                sampleRecords[sampleSiteUrlIdx].copyFields(key, value);
                sampleFlags[sampleSiteUrlIdx] = true;
            } else {
                sampleSiteUrlIdx++;
                if (sampleSiteUrlIdx < sampleNum) {
                    if (sampleRecords[sampleSiteUrlIdx] == null) {                            
                        sampleRecords[sampleSiteUrlIdx] = new UrlValueWrapper();    
                    }
                    sampleRecords[sampleSiteUrlIdx].copyFields(key, value); 
                    sampleFlags[sampleSiteUrlIdx] = true;
                } else {
                    int idx = random.nextInt(sampleSiteUrlIdx);
                    if (idx < sampleNum) {
                        sampleRecords[idx].copyFields(key, value);  
                    }
                }
            }
        }
        
        public void mapEnd(ICollector collector) {
            doCollect(collector);
        }

        
        public void mapBegin() {
            
        }
        
        public void reduce(Url key, IWritablePairWalker<Url, IWritable> values,
                ICollector collector) {
            while (values.moreValue()) {
                doSample(key, values.getValue(), collector);   
            }
                     
        }
        
        public void reduceBegin() {
            
        }
        
        public void reduceEnd(ICollector collector) {
            doCollect(collector);            
        }
    }
    
    /**
     * 与sitedb做merge的reduce.
     *
     * @author yixun
     * @since 1.5
     * @version 1.0
     */
    public static class MergeReducer implements IMergeReducer<Url, UrlValueWrapperList, IWritable> {

        private int sampleNum;
        private UrlValueWrapper[] sampleRecords;
        private boolean[] sampleFlags;
        private Random random = new Random();
        private Counter sampleSiteCounter;
        private Counter urlLackSiteCounter;
        private Counter noUrlSiteCounter;
        
        public void configure(JobDef job, TaskRunnable task) {
            sampleNum = job.getConfig().getInt(NAME_SAMPLENUM);
            sampleNum = job.getConfig().getInt(NAME_SAMPLENUM);
            sampleRecords = new UrlValueWrapper[sampleNum];
            sampleFlags = new boolean[sampleNum];
            for (int i = 0; i < sampleNum; ++i) {
                sampleFlags[i] = false;
            }
            sampleSiteCounter = task.getCounter("sampleSiteCounter");
            urlLackSiteCounter = task.getCounter("urlLackSiteCounter");
            noUrlSiteCounter = task.getCounter("noUrlSiteCounter");
        }

        /**
         * @param key
         * @param values
         * @param mergeValues
         * @param collector
         */
        
        public void reduce(Url key,
                IWritablePairWalker<Url, UrlValueWrapperList> values,
                IWritablePairWalker<Url, IWritable>[] mergeValues,
                ICollector collector) {
            //select site库中有数据
            if(mergeValues[0] != null 
                    && mergeValues[0].moreValue()) {
                //url sample有数据
                if (values != null) {
                    doSample(values);
                    doCollect(collector);
                    sampleSiteCounter.inc();
                } else {
                    noUrlSiteCounter.inc();
                }
            }            
        }
        
        /**
         * 从site下未知总量的url中sample出确定数目的url
         * 算法描述：
         * 假设要sample出的数目sampleNum = 5，顺序扫描每一个url，把前5个先放入
         * sample url的数组中，当扫描序号大于等于5时，产生一个0到扫描序号的随机数，
         * 如果这个随机数小于5，则置换掉随机数所在位置的url，否则不做任何操作。
         * 这个算法能保证从实现未知数目的url中等概率的sample出确定数目的url。
         * @param values
         */
        private void doSample(IWritablePairWalker<Url, UrlValueWrapperList> values) {            
            if (values != null) {                
                int sampleCnt = 0;
                while (values.moreValue()) {
                    UrlValueWrapperList urlValueWrapperList = values.getValue();
                    for (UrlValueWrapper wrapper: urlValueWrapperList) {
                        if (sampleCnt < sampleNum) {
                            if (sampleRecords[sampleCnt] == null) {
                                sampleRecords[sampleCnt] = new UrlValueWrapper();
                            }
                            sampleRecords[sampleCnt].copyFields(wrapper.getUrl(), wrapper.getValue());
                            sampleFlags[sampleCnt] = true;
                        } else {
                            int ranInt = random.nextInt(sampleCnt);
                            if (ranInt < sampleNum) {
                                sampleRecords[ranInt].copyFields(wrapper.getUrl(), wrapper.getValue());
                            }
                        }
                        sampleCnt++;
                    }
                }
            }
        }
        
        /**
         * map阶段的collect，对pageattr中的每一个site进行sample，输出site->urlList对
         * reduce阶段与cloaking site库进行merge，选出一定数量的site，sample出url
         * @param urls
         * @param collector
         */
        private void doCollect(ICollector collector) {
            int realSampleNum = 0;
            for (int i = 0; i < sampleNum; ++i) {
                if (sampleFlags[i]) {
                    collector.collectToChannel(0, sampleRecords[i].getUrl(), 
                            sampleRecords[i].getValue());
                    sampleFlags[i] = false;
                    realSampleNum++;
                }
            }
            if (realSampleNum < sampleNum) {
                urlLackSiteCounter.inc();
            }
        }
        
        public void reduceBegin() {
            
        }
        
        public void reduceEnd(ICollector collector) {
            
        }
        
    }
    
    public static class UrlValueWrapper implements IWritable {
        private Url url = new Url();
        private StringWritable className = new StringWritable();
        private IWritable value = null;
        
        public Url getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url.set(url);
        }        

        public StringWritable getClassName() {
            return className;
        }

        public IWritable getValue() {
            return value;
        }

        public void setValue(IWritable value) {
            className.set(value.getClass().getName());
            newValueInstance();
            this.value.copyFields(value);
        }

        /**
         * @param in
         * @throws IOException
         */
        
        public void readFields(DataInput in) throws IOException {
            url.readFields(in);
            className.readFields(in);
            newValueInstance();
            value.readFields(in);
        }
        /**
         * 根据className实例化一个value.
         */
        private void newValueInstance() {
            if (value == null) {
                try {
                    value = (IWritable) Class.forName(className.get()).newInstance();
                } catch (InstantiationException e) {
                    throw new TaskFatalException(e);
                } catch (IllegalAccessException e) {
                    throw new TaskFatalException(e);
                } catch (ClassNotFoundException e) {
                    throw new TaskFatalException(e);
                }
            }
        }
        /**
         * @param out
         * @throws IOException
         */
        
        public void writeFields(DataOutput out) throws IOException {
            url.writeFields(out);
            className.writeFields(out);
            value.writeFields(out);          
        }
        /**
         * @param value
         * @return
         */
        
        public IWritable copyFields(IWritable o) {
            if (o == null || !(o instanceof UrlValueWrapper)) {
                throw new RuntimeException("bad value : " + o);
            }
            if (o == this)
                return this;
            
            UrlValueWrapper that = (UrlValueWrapper) o;
            this.url.copyFields(that.url);
            this.className.copyFields(that.className);
            newValueInstance();
            this.value.copyFields(that.value);
            return this;
        }
        
        public void copyFields(Url url, IWritable value) {
            this.url.copyFields(url);
            this.className.set(value.getClass().getName());
            newValueInstance();
            this.value.copyFields(value);
        }
    }
    
    @SuppressWarnings("serial")
    public static class UrlValueWrapperList extends WritableArrayList<UrlValueWrapper> {

        @Override
        protected UrlValueWrapper newElementInstance() {
            return new UrlValueWrapper();
        }
        
    }

}
