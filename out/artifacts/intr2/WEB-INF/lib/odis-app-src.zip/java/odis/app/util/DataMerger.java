package odis.app.util;

import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.util.AsyncRecordReader;

/**
 * modified from image DataMerger
 *
 * @author david, linfeng, why
 */
public class DataMerger<K extends IWritableComparable, V extends IWritable> {
    AsyncRecordReader<K, V> srcs[];
    IWritableComparable[] keys;
    IWritable[] values;
    PriorityQueue<Integer> q;

    public DataMerger(AsyncRecordReader<K, V>[] srcs, 
            Comparator<K> keyComp, final Comparator<V> valComp, 
            Class<K> keyClass, Class<V> valueClass)
            throws Exception {
        this.srcs = srcs;
        if (keyComp == null) {
            keyComp = new Comparator<K>() {
                @SuppressWarnings("unchecked")
                public int compare(K o1, K o2) {
                    return o1.compareTo(o2);
                }

            };
        }
        final Comparator<K> keyCmp = keyComp;
        q = new PriorityQueue<Integer>(srcs.length, new Comparator<Integer>() {
            @SuppressWarnings("unchecked")
            public int compare(Integer arg0, Integer arg1) {
                int cmp = 0;
                if (keyCmp != null) {
                    cmp = keyCmp.compare((K)keys[arg0], (K)keys[arg1]);
                    if (cmp != 0)
                        return cmp;
                } // if

                if (valComp != null)
                    cmp = valComp.compare((V) values[arg0], (V) values[arg1]);
                return cmp;
            }
        });
        keys = new IWritableComparable[srcs.length];
        values = new IWritable[srcs.length];

        for (int i = 0; i < srcs.length; i++) {
            keys[i] = keyClass.newInstance();
            values[i] = valueClass.newInstance();

            if (srcs[i].next()) {
                keys[i] = srcs[i].getKey();
                values[i] = srcs[i].getValue();
                q.add(i);
            }
        } // for i
        current = -1;
    }

    public boolean started = false;

    public void close() throws IOException {
        for (int i = 0; i < srcs.length; i++)
            srcs[i].close();
    }

    int current;

    public boolean moveToNext() throws IOException {
        if (current == -2)
            return false;
        if (current != -1) {
            if (srcs[current].next()) {
                keys[current] = (K)srcs[current].getKey();
                values[current] = (IWritable) srcs[current].getValue();
                q.add(current);
            }
        } // if
        if (q.isEmpty()) {
            current = -2;
            return false;
        } // if

        current = q.poll();
        return true;
    }

    public Object getCurrentKey() {
        return current < 0 ? null : keys[current];
    }

    public Object getCurrentVal() {
        return current < 0 ? null : values[current];
    }

    @SuppressWarnings("unchecked")
    public boolean next(Object key, Object val) throws IOException {
        if (!moveToNext())
            return false;

        ((IWritableComparable) key).copyFields(keys[current]);
        ((IWritable) val).copyFields(values[current]);

        return true;
    }
}
