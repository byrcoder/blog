/**
 * @(#)AbstractBeanWritable.java, 2008-2-13. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.serialize;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.app.serialize.annotation.Persistent;
import odis.serialize.IWritable;

/**
 * BeanWritable supports auto mashal/unmashal of data by invoking getter/setter
 * in bean interface.
 * 
 * @author river
 *
 */
public class AbstractBeanWritable implements IWritable {
    private BeanWritableHelper helper = 
        BeanWritableHelper.getHelperForClass(this.getClass());
    
    public void readFields(DataInput in) throws IOException {
        helper.unmarshal(this, in);
    }

    public void writeFields(DataOutput out) throws IOException {
        helper.marshal(this, out);
    }

    public IWritable copyFields(IWritable value) {
        if (value == null || value.getClass() != this.getClass()) {
            throw new RuntimeException("bad value : " + value);
        }
        if (value == this) return this;
        try {
            helper.copyFields(value, this);
        } catch(IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    @Override
    public String toString() {
        return helper.toString(this);
    }

    /**
     * Clear all the known fields :
     * <ul>All numeric primitive fields, such as "int", "char", are set to zero.
     * <li>Boolean fields are set to false.
     * <li>clear() method of all writable fields are called.
     * </ul>
     */
    public void clear() {
        helper.clear(this);
    }
    
    /**
     * Return name of properties.
     * @return
     */
    @Persistent(false)
    public String [] getPropertyNames() {
        return helper.getPropertyNames();
    }
    
    /**
     * Return the type of property.
     * @param path
     * @return
     */
    @Persistent(false)
    public Class<?> getPropertyType(String path) {
        return helper.getPropertyType(this, path);
    }

    /**
     * Return property by path, such as "a.b".
     * @param path
     * @return
     */
    @Persistent(false)
    public Object getProperty(String path) {
        return helper.getProperty(this, path);
    }
    
    /**
     * Set the property by path.
     * @param path
     * @param value
     */
    @Persistent(false)
    public void setProperty(String path, Object value) {
        helper.setProperty(this, path, value);
    }
    
}
