package odis.app.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import odis.file.SequenceFile;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import toolbox.misc.channel.IObjectOutput;

/**
 * 用于描述一个Partition。一个Partition通常是一个SequenceFile或者一个IndexFile，文件名通常是
 * part-xxxxx这样的形式。
 * 
 * @author 吴迎晖（river@rd.netease.com）
 * 
 * 修改历史：
 *   2007/6/2（庄莉）：添加javadoc说明和注释
 */
public class Partition<K extends IWritableComparable, V extends IWritable> {
    public static final long MAX_BINARY_SEARCH_DISTANCE = 30 * 1024 * 1024;

    private IFileSystem fs;

    private Path file;

    private long fileLength;

    /**
     * 书签：记录一些key所在的位置，方便查找.
     * For consequent pairs with the same key, this offset points to the first
     * one.
     */
    private static class Mark implements Comparable<Mark> {
        private IWritableComparable key;

        private long offset;

        public Mark(IWritableComparable key, long offset) {
            this.key = key;
            this.offset = offset;
        }

        public int compareTo(Mark o) {
            return key.compareTo(o.key);
        }

        public int hashCode() {
            return key.hashCode();
        }

        public boolean equals(Object o) {
            return key.compareTo(((Mark) o).key) == 0;
        }
    }

    private List<Mark> marks = new ArrayList<Mark>(32);

    private HashSet<Mark> markSet = new HashSet<Mark>();

    /**
     * 一个partition是文件系统上的一个文件
     * @param nfs 文件系统
     * @param file 文件路径
     * @throws IOException
     */
    public Partition(IFileSystem nfs, Path file) throws IOException {
        this.fs = nfs;
        this.file = file;
        if (!this.fs.exists(this.file)) {
            throw new IOException("cannot find file : " + file);
        }
        fileLength = this.fs.getLength(getRealFile());
    }

    /**
     * IndexFile等文件的路径是一个目录，找到实际的数据的文件
     * @return 实际的数据的文件
     * @throws IOException
     */
    private Path getRealFile() throws IOException {
        if (fs.isDirectory(file)) {
            return file.cat("data");
        } else {
            return file;
        }
    }

    /**
     * 顺序查找SequenceFile.
     * 
     * @param reader sequance file reader
     * @param from 查找的起始位置
     * @param to 查找的结束位置
     * @param target 寻找的key
     * @return key对应的value的值，null如果没有找到
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    private V searchSequential(SequenceFile.Reader reader, long from,
            long to, K target) throws IOException {

        K key;
        V value;

        try {
            key = (K) reader.getKeyClass().newInstance();
            value = (V) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new IOException("cannot initialize object");
        }

        reader.seek(from);
        while (reader.getPosition() <= to && reader.next(key, value)) {
            int comp = key.compareTo(target);
            if (comp == 0)
                return value;
            else if (comp > 0)
                return null;
        }
        return null;
    }

    /**
     * Searches linear from a speicified position in the reader for a target
     * key and output all values equal to that key.
     * 
     * @param reader  the reader of the sequence file
     * @param from  the start position. NOTE: this position should be 
     *              synchronized.
     * @param target  the target key to be searched
     * @param output  the IObjectOutput instance for outputting
     * @return  the number of found values
     * @throws IOException  if an I/O error occurs
     */
    @SuppressWarnings("unchecked")
    private int linearSearch(SequenceFile.Reader reader, long from, 
            K target, IObjectOutput output) throws IOException {
        K k;  V v;
        /*
         * Allocate key/value instances
         */
        try {
            k = (K) reader.getKeyClass().newInstance();
            v = (V) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new IOException("cannot initialize object");
        }
        /*
         * Seek to from position
         */
        reader.seek(from);
        /*
         * Skipping the leading smaller values
         */
        while (true) {
            if (!reader.next(k, v))
                return 0;
            int comp = k.compareTo(target);
            if (comp > 0)
                return 0;
            if (comp == 0)
                break;
        } // while
        /*
         * Scan and output entries until larger keys found or no more entries
         * in the reader.
         */
        int cnt = 1;
        try {
            output.output(v);
        } catch (Exception e) {
            throw new RuntimeException();
        }
        
        while (reader.next(k, v)) {
            if (k.compareTo(target) > 0)
                /*
                 * A larger key found
                 */
                break;
            try {
                output.output(v);
            } catch (Exception e) {
                throw new RuntimeException();
            }
            
            cnt ++;
        } // while
        
        return cnt;
    }

    /**
     * mark某个key所在的位置
     * @param key key
     * @param pos 所在的位置
     */
    private void addMark(K key, long pos) {
        Mark mark = new Mark(key, pos);
        if (markSet.contains(mark))
            return;
        markSet.add(mark);
        marks.add(mark);
        Collections.sort(marks);
    }

    /**
     * 二分查找.
     * 
     * @param reader sequance file reader
     * @param from 查找的起始位置
     * @param to 查找的结束位置
     * @param target 寻找的key
     * @return key对应的value的值，null如果没有找到
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    private V searchInSortedSequenceFile(SequenceFile.Reader reader,
            long from, long to, K target) throws IOException {

        long lowPos = from;
        long hiPos = to;
        long midPos;

        K key;
        V value;
        try {
            key = (K) reader.getKeyClass().newInstance();
            value = (V) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new IOException("cannot initialize object");
        }

        reader.seek(lowPos);
        lowPos = reader.getPosition();
        reader.next(key, value);
        addMark(key, lowPos);

        int comp = key.compareTo(target);
        if (comp == 0)
            return value;
        else if (comp > 0)
            return null;

        while (hiPos - lowPos > MAX_BINARY_SEARCH_DISTANCE) {
            midPos = (lowPos + hiPos) / 2;
            reader.sync(midPos);
            midPos = reader.getPosition();
            try {
                key = (K) reader.getKeyClass().newInstance();
            } catch (Exception e) {
                throw new IOException("cannot initialize object");
            }
            reader.next(key, value);
            addMark(key, midPos);

            comp = key.compareTo(target);
            if (comp == 0)
                return value;
            else if (comp < 0) {
                lowPos = midPos;
            } else {
                hiPos = midPos;
            }
        }
        return searchSequential(reader, lowPos, hiPos, target);
    }

    /**
     * Makes a binary search in a specified range, [from , to), for a specified
     * key, and output all values with this key to output.
     * @param reader  the reader of the sequence file
     * @param from  the start position in the reader. NOTE: this position should
     *              have been synchronized. e.g. calling reader.sync()
     * @param to  the end position in the reader. This position could NOT be
     *            synchronized.
     * @param target  the target key to be searched
     * @param output  the IObjectOutput instance for outputting
     * @return  the number of found values
     * @throws IOException  if an I/O error occurs
     */
    @SuppressWarnings("unchecked")
    private int binarySearch(SequenceFile.Reader reader,
            long from, long to, K target, IObjectOutput output) 
            throws IOException {

        /*
         * Allocate key/value pairs
         */
        K k;  V v;
        try {
            k = (K) reader.getKeyClass().newInstance();
            v = (V) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        /*
         * Read the first entry
         */
        reader.seek(from);
        reader.next(k, v);

        int comp = k.compareTo(target);
        if (comp == 0)
            /*
             * Since first key is target, simple linear-searching from it
             */
            return linearSearch(reader, from, target, output);
        else if (comp > 0)
            /*
             * The smallest key is larger than target, no keys could be found
             */
            return 0;
        /*
         * Binary search
         */
        while (to-from > MAX_BINARY_SEARCH_DISTANCE) {
            /*
             * Move (and sync) to mid-position
             */
            long midPos = (from + to) / 2;
            reader.sync(midPos);
            midPos = reader.getPosition();
            /*
             * Read the next entry
             */
            reader.next(k, v);

            /*
             * Update from/to
             */
            comp = k.compareTo(target);
            if (comp < 0) {
                from = midPos;
            } else {
                if (to == midPos)
                    /*
                     * In case the gap is smaller than sync gap
                     */
                    break;
                else
                    to = midPos;
            } // else
        } // while
        /*
         * Linear search in a block
         */
        return linearSearch(reader, from, target, output);
    }
    
    /**
     * 给定key寻找对应的value
     * @param key 被寻找的key
     * @return 对应的value
     * @throws IOException
     */
    public synchronized V search(K key)
            throws IOException {
        long from = SequenceFile.HEADER_SIZE;
        long to = fileLength;

        if (!marks.isEmpty()) {
            /*
             * Find in marks to shrink the range of from-to
             */
          int index = Collections.binarySearch(marks, new Mark(key, 0));
            if (index >= 0) {
                from = marks.get(index).offset;
            } else {
                index = (-1) * index - 1;
                if (index > 0) {
                    from = marks.get(index - 1).offset;
                } // if
                if (index < marks.size()) {
                    to = marks.get(index).offset;
                } // if
            } // else
        } // if

        if (to <= from)
            return null;

        SequenceFile.Reader reader = new SequenceFile.Reader(fs, getRealFile());
        try {
            return searchInSortedSequenceFile(reader, from, to, key);
        } finally {
            reader.close();
        }        
    }

    /**
     * Searches for values for a specified key.
     * 
     * @param target  the target key to be searched
     * @param output  and IObjectOutput instance for output found values
     * @return  the number of values found
     * @throws IOException  if an I/O error occurs
     */
    public synchronized int search(K target, IObjectOutput output) 
            throws IOException {
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, getRealFile());
        try {
            return binarySearch(reader, SequenceFile.HEADER_SIZE, fileLength, 
                    target, output);
        } finally {
            reader.close();
        }        
    }
}
