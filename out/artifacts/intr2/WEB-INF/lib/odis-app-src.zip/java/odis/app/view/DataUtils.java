package odis.app.view;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;

/**
 * Some utilities for processing data.
 * 
 * @author david
 *
 */
public class DataUtils {
    /**
     * The data-structure representing the properites of a path.
     * 
     * Fields:
     *   singleFile  boolean  whether the specified path is a single sequence or indexed-file
     *   keyClass    Class    the class of the key
     *   valClass    Class    the class of the value
     *   count       int      the number of files.
     *                        if isSingleFile() returns true, count equals 1, 
     *                        otherwise count is the number files in the folder
     *   pathType    int      the type of the path. One of the four values:
     *                          TYPE_SINGLE_SEQ_FILE      a single sequence-file
     *                          TYPE_SINGLE_INDEXED_FILE  a single indexed-file
     *                          TYPE_FOLDER_SEQ_FILE      a folder with
     *                                                    sequence-files
     *                          TYPE_FOLDER_INDEXED_FILE  a folder with
     *                                                    indexed-files
     * 
     * @author david
     *
     */
    public static class PathProp {
        public static final int TYPE_SINGLE_SEQ_FILE = 0;
        public static final int TYPE_SINGLE_INDEXED_FILE = 1;
        public static final int TYPE_FOLDER_SEQ_FILE = 2;
        public static final int TYPE_FOLDER_INDEXED_FILE = 3;
        
        public PathProp(int type, Class keyClass, Class valClass) {
            this.pathType = type;
            this.keyClass = keyClass;  this.valClass = valClass;
        }
        public PathProp(int type, Class keyClass, Class valClass, int count) {
            this.pathType = type;
            this.keyClass = keyClass;  this.valClass = valClass;
            this.count = count;
        }
        
        private Class keyClass;
        private Class valClass;
        
        private int pathType;
        private int count = 1;
        
        public boolean isSingleFile() {
            return pathType == TYPE_SINGLE_SEQ_FILE || pathType == TYPE_SINGLE_INDEXED_FILE;
        }
        public int getPathType() {
            return pathType;
        }
        public Class getKeyClass() {
            return keyClass;
        }
        public Class getValClass() {
            return valClass;
        }
        
        void setCount(int count) {
            this.count = count;
        }
        public int getCount() {
            return count;
        }
    }
    
    /**
     * @deprecated use the one with IFileSystem.
     */
    @Deprecated
    public static PathProp checkPathProp(FileSystem fs, Path path) throws IOException {
        return checkPathProp((IFileSystem) fs, path);
    }
    /**
     * Retrieve the properties of a sequence/indexed file/folder.
     * 
     * @param fs  the file-system
     * @param path  the path to the file/folder
     * @return  the properties as a PathProp instance
     * @throws IOException  if an I/O error occurs
     */
    public static PathProp checkPathProp(IFileSystem fs, Path path) throws IOException {
        if (!fs.exists(path))
            return null;
        
        if (fs.isFile(path)) {
            /*
             * For a file
             */
            SequenceFile.Reader rd = new SequenceFile.Reader(fs, path);
            try {
                return new PathProp(PathProp.TYPE_SINGLE_SEQ_FILE, rd.getKeyClass(), 
                        rd.getValueClass());
            } finally {
                rd.close();
            }
        } else {
            /*
             * For a folder.
             * Could be an indexed-file or a folder of sequence file or a folder of indexed file
             */
            FileInfo[] files = fs.listFiles(path);
            if (files.length == 0)
                return null;
            
            Arrays.sort(files, new Comparator<FileInfo>() {
                public int compare(FileInfo o1, FileInfo o2) {
                    return o1.getPath().compareTo(o2.getPath());                }
            });
            
            if (files.length == 2 && !files[0].isDir() && !files[1].isDir()) {
                /*
                 * 2 files, could be an indexed-file
                 */
                String[] fs0 = {files[0].getPath().getName(), files[1].getPath().getName()};
                String[] fs1 = {IndexedFile.DATA_FILE_NAME, IndexedFile.INDEX_FILE_NAME};
                
                Arrays.sort(fs0);  Arrays.sort(fs1);
                if (Arrays.equals(fs0, fs1)) {
                    IndexedFile.Reader rd = new IndexedFile.Reader(fs, path);
                    try {
                        return new PathProp(PathProp.TYPE_SINGLE_INDEXED_FILE, rd.getKeyClass(), 
                                rd.getValueClass());
                    } finally {
                        rd.close();
                    }
                } // if
            } // if
            
            if (!files[0].isDir()) {
                SequenceFile.Reader rd = new SequenceFile.Reader(fs, files[0].getPath());
                try {
                    return new PathProp(PathProp.TYPE_FOLDER_SEQ_FILE, rd.getKeyClass(), 
                            rd.getValueClass(), files.length);
                } finally {
                    rd.close();
                }
            } else {
                IndexedFile.Reader rd = new IndexedFile.Reader(fs, files[0].getPath());
                try {
                    return new PathProp(PathProp.TYPE_FOLDER_INDEXED_FILE, rd.getKeyClass(), 
                            rd.getValueClass(), files.length);
                } finally {
                    rd.close();
                }
            } // else
        } // else
    }
}
