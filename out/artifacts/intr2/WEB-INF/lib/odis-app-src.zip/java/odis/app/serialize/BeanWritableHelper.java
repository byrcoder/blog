/**
 * @(#)BeanWritableHelper.java, 2008-2-13. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.serialize;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import odis.app.serialize.annotation.AutoPersistent;
import odis.app.serialize.annotation.Persistent;
import odis.app.serialize.annotation.PersistentOrder;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * Helper to marshal/unmarshal bean data.
 * @author river
 */
public class BeanWritableHelper {
    private static final Object [] EMPTY_ARGS = new Object[0]; 
    
    private Class clazz;
    private FieldMeta [] fields;
    private HashMap<String, FieldMeta> fieldsMap = new HashMap<String, FieldMeta>();
    
    private Method readIntMethod, writeIntMethod;
    private Method readByteMethod, writeByteMethod;
    private Method readShortMethod, writeShortMethod;
    private Method readCharMethod, writeCharMethod;
    private Method readLongMethod, writeLongMethod;
    private Method readBooleanMethod, writeBooleanMethod;
    private Method readDoubleMethod, writeDoubleMethod;
    private Method readFloatMethod, writeFloatMethod;
    private Method readStringMethod, writeStringMethod;
    private Method readWritableMethod, writeWritableMethod;

    private static ConcurrentHashMap<Class, BeanWritableHelper> helperMap = 
        new ConcurrentHashMap<Class, BeanWritableHelper>();
    
    /**
     * Get a helper for given class. The helper for same class is cached and reused,
     * so there is only one helper for one class.
     * 
     * @param clazz
     * @return
     */
    public static BeanWritableHelper getHelperForClass(Class clazz) {
        BeanWritableHelper helper = helperMap.get(clazz);
        if (helper == null) {
            helper = new BeanWritableHelper(clazz);
            helperMap.put(clazz, helper);
        }
        return helper;
    }
    
    /**
     * Marchal the given instance into output.
     * @param instance
     * @param output
     * @throws IOException
     */
    public void marshal(Object instance, DataOutput output) throws IOException {
        for (FieldMeta field : fields) {
            try {
                Object value = field.field == null ? field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance);
                field.writer.invoke(this, output, value);
            } catch(Exception e) {
                throw new IOException("marshal error on field " + field.name + " : " + e.toString());
            }
        }
    }
    
    /**
     * Unmarshal instance from input.
     * @param instance
     * @param input
     * @throws IOException
     */
    public void unmarshal(Object instance, DataInput input) throws IOException {
        for (FieldMeta field : fields) {
            try {
                if (field.primitive) {
                    Object value = field.reader.invoke(this, input);
                    if (field.field == null) { 
                        field.setter.invoke(instance, value);
                    } else {
                        field.field.set(instance, value);
                    }
                } else {
                    Object f = field.field == null ? field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance);
                    if (f == null) {
                        throw new NullPointerException("writable field " + field.name + " should not be null");
                    }
                    field.reader.invoke(this, input, f);
                }
            } catch(Exception e) {
                throw new IOException("unmarshal error on field " + field.name + " : " + e.toString());
            }
        }
    }
    
    /**
     * Get the names of fields in this helper.
     * @return
     */
    public String [] getPropertyNames() {
        String [] names = new String[fields.length];
        for (int i=0; i<fields.length; i++) {
            names[i] = fields[i].name;
        }
        return names;
    }
    
    /**
     * Access the property of bean by path, such as "aField.bField".
     * @param path
     * @return
     */
    public Object getProperty(Object instance, String path) {
        int pos = path.indexOf('.');
        String part = pos >=0 ? path.substring(0, pos) : path;
        FieldMeta field = fieldsMap.get(part);
        if (field == null) {
            throw new IllegalAccessError("no such field : " + part + " for class " + clazz);
        }
        try {
            Object value = 
                field.field == null ? 
                        field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance);
            if (pos < 0) return value;
            else {
                BeanWritableHelper helper = BeanWritableHelper.getHelperForClass(value.getClass());
                return helper.getProperty(value, path.substring(pos+1));
            }
        } catch(InvocationTargetException e) {
            throw new IllegalAccessError("access field at " + part + 
                    "failed for class " + clazz + ":" + e.getTargetException());
        } catch(IllegalAccessException e) {
            throw new IllegalAccessError("access field at " + part + 
                    "failed for class " + clazz);
        }
    }
    
    /**
     * Access the type of property of bean by path.
     * @param instance
     * @param path
     * @return
     */
    public Class getPropertyType(Object instance, String path) {
        int pos = path.indexOf('.');
        String part = pos >=0 ? path.substring(0, pos) : path;
        FieldMeta field = fieldsMap.get(part);
        if (field == null) {
            throw new IllegalAccessError("no such field : " + part + " for class " + clazz);
        }
        if (pos < 0) {
            return field.type;
        }
        try {
            Object value = 
                field.field == null ? 
                        field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance);
            BeanWritableHelper helper = BeanWritableHelper.getHelperForClass(value.getClass());
            return helper.getPropertyType(value, path.substring(pos+1));
        } catch(InvocationTargetException e) {
            throw new IllegalAccessError("access field at " + part + 
                    "failed for class " + clazz + ":" + e.getTargetException());
        } catch(IllegalAccessException e) {
            throw new IllegalAccessError("access field at " + part + 
                    "failed for class " + clazz);
        }
    }
    
    /**
     * Set property by path.
     * @param instance
     * @param path
     * @param value
     */
    public void setProperty(Object instance, String path, Object value) {
        int pos = path.indexOf('.');
        String part = pos >=0 ? path.substring(0, pos) : path;
        FieldMeta field = fieldsMap.get(part);
        if (field == null) {
            throw new IllegalAccessError("no such field : " + part + " for class " + clazz);
        }
        
        try {
            if (pos < 0) {
                if (field.primitive) {
                    if (field.field == null) {
                        field.setter.invoke(instance, value);
                    } else {
                        field.field.set(instance, value);
                    }
                } else {
                    Object f = field.field == null ? field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance);
                    if (value.getClass() == f.getClass()) {
                        ((IWritable)f).copyFields((IWritable)value);
                    } else {
                        try {
                            Method m = f.getClass().getMethod("set", value.getClass());
                            m.invoke(f, value);
                        } catch (NoSuchMethodException e) {
                            throw new IllegalAccessError("cannot set field " + part + 
                                    " of class " + clazz + " with value " + value);
                        }
                    }
                }
            } else {
                    Object tmp = field.field == null ? field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance);
                    BeanWritableHelper helper = BeanWritableHelper.getHelperForClass(tmp.getClass());
                    helper.setProperty(tmp, path.substring(pos+1), value);
            }
        } catch(InvocationTargetException e) {
            throw new IllegalAccessError("access field at " + part + 
                    "failed for class " + clazz + ":" + e.getTargetException());
        } catch(IllegalAccessException e) {
            throw new IllegalAccessError("access field at " + part + 
                    "failed for class " + clazz);
        }
    }
    
    /**
     * Copy data in src to dst.
     * @param src
     * @param dst
     */
    public void copyFields(Object src, Object dst) throws IOException {
        for (FieldMeta field : fields) {
            try {
                if (field.primitive) {
                    if (field.field == null) {
                        Object value =  field.getter.invoke(src, EMPTY_ARGS);
                        field.setter.invoke(dst, value);
                    } else {
                        field.field.set(dst, field.field.get(src));
                    }
                } else {
                    IWritable f, value;
                    if (field.field == null) {
                        f = (IWritable) field.getter.invoke(dst, EMPTY_ARGS);
                        value = (IWritable) field.getter.invoke(src, EMPTY_ARGS);
                    } else {
                        f = (IWritable) field.field.get(dst);
                        value = (IWritable) field.field.get(src);
                    }
                    if (f == null || value == null) {
                        throw new NullPointerException("writable field should be final and should not be null");
                    }
                    f.copyFields(value);
                }
            } catch(InvocationTargetException e) {
                throw new IOException("unmarshal error on field " + field.name + " : " + e.toString());
            } catch(Exception e) {
                throw new IOException("unmarshal error on field " + field.name + " : " + e.toString());
            }
        }
    }

    /**
     * Copy the samed named fields from src to dst, even if their classes is different.
     * This method is useful when converting types to add only several fields.
     * @param src
     * @param dst
     * @throws IOException
     */
    public static void copyFieldsByName(Object src, Object dst) throws IOException {
        BeanWritableHelper srcHelper = BeanWritableHelper.getHelperForClass(src.getClass());
        BeanWritableHelper dstHelper = BeanWritableHelper.getHelperForClass(dst.getClass());
        for (FieldMeta srcField : srcHelper.fields) {
            FieldMeta dstField = dstHelper.fieldsMap.get(srcField.name);
            if (dstField == null) continue;
            if (srcField.type != dstField.type) {
                throw new IOException("field " + srcField.name + " has different types in src and dst");
            }
            try {
                Object value = srcField.field == null ? srcField.getter.invoke(src, EMPTY_ARGS) : srcField.field.get(src);

                if (dstField.primitive) {
                    if (dstField.field == null) {
                        dstField.setter.invoke(dst, value);
                    } else {
                        dstField.field.set(dst, value);
                    }
                } else {
                    IWritable v;
                    if (dstField.field == null) {
                        v = (IWritable) dstField.getter.invoke(dst, EMPTY_ARGS);
                    } else {
                        v = (IWritable) dstField.field.get(dst);
                    }
                    if (v == null ) {
                        throw new NullPointerException("writable field " + srcField.name + 
                                " should be final and should not be null");
                    }
                    v.copyFields((IWritable)value);
                }
            } catch(InvocationTargetException e) {
                throw new IOException("copy field " + srcField.name + " failed : " + e.getMessage());
            } catch(Exception e) {
                throw new IOException("copy field " + srcField.name + " failed : " + e.getMessage());
            }
        }
    }
    
    public String toString(Object instance) {
        StringBuilder buf = new StringBuilder();
        for (FieldMeta field : fields) {
            try {
                buf.append(field.name).append("=");
                if (!field.primitive) {
                    buf.append("{");
                    buf.append(field.field == null ? field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance));
                    buf.append("}");
                } else {
                    buf.append(field.field == null ? field.getter.invoke(instance, EMPTY_ARGS) : field.field.get(instance));
                }
                buf.append(',');
            } catch(Exception e) {
                throw new RuntimeException("get field " + field.name + " failed");
            }
        }
        if (buf.length() > 0) buf.setLength(buf.length()-1);
        return buf.toString();
    }
    
    public void clear(Object instance) {
        try {
            for (FieldMeta field : fields) {
                if (field.primitive) {
                    if (field.field != null) {
                        field.field.set(instance, field.zero);
                    } else {
                        field.setter.invoke(instance, field.zero);
                    }
                } else {
                    if (field.clearer == null) {
                        throw new RuntimeException("no auto clean supported for field " + field.name);
                    }
                    if (field.field != null) {
                        field.clearer.invoke(field.field.get(instance), EMPTY_ARGS);
                    } else {
                        field.clearer.invoke(field.getter.invoke(instance, EMPTY_ARGS), EMPTY_ARGS);
                    }
                }
            }
        } catch(Exception e) {
            throw new RuntimeException("clear object failed", e);
        }
        
    }
    
    private BeanWritableHelper(Class clazz) {
        this.clazz = clazz;
        initPredifinedMethods();
        getFields(clazz);
    }

    private void initPredifinedMethods() {
        HashMap<String, Method> methods = new HashMap<String, Method>();
        for (Method m : this.getClass().getDeclaredMethods()) {
            methods.put(m.getName(), m);
        }
        
        readIntMethod = methods.get("readInt");
        writeIntMethod = methods.get("writeInt");
        
        readByteMethod = methods.get("readByte");
        writeByteMethod = methods.get("writeByte");
        
        readShortMethod = methods.get("readShort");
        writeShortMethod = methods.get("writeShort");
        
        readCharMethod = methods.get("readChar");
        writeCharMethod = methods.get("writeChar");
        
        readLongMethod = methods.get("readLong");
        writeLongMethod = methods.get("writeLong");
        
        readBooleanMethod = methods.get("readBoolean");
        writeBooleanMethod = methods.get("writeBoolean");
        
        readFloatMethod = methods.get("readFloat");
        writeFloatMethod = methods.get("writeFloat");
        
        readDoubleMethod = methods.get("readDouble");
        writeDoubleMethod = methods.get("writeDouble");
        
        readStringMethod = methods.get("readString");
        writeStringMethod = methods.get("writeString");
        
        readWritableMethod = methods.get("readWritable");
        writeWritableMethod = methods.get("writeWritable");
    }
    
    @SuppressWarnings("unchecked")
    private void getFields(Class clazz) {
        boolean auto = true;
        AutoPersistent ap = (AutoPersistent)clazz.getAnnotation(AutoPersistent.class);
        if (ap != null) {
            auto = ap.value();
        }
        
        HashMap<String, Method> methodMap = new HashMap<String, Method>();
        HashMap<String, Object> fieldNames = new HashMap<String, Object>();
        for (Method m : clazz.getMethods()) {
            if (Modifier.isStatic(m.getModifiers())) {
                continue;
            }
            
            Persistent persistentA = m.getAnnotation(Persistent.class);
            if (persistentA != null) {
                if (!persistentA.value()) continue;
            } else {
                if (!auto) continue;
            }
            
            String name = m.getName();
            methodMap.put(name, m);
            if (name.startsWith("get")) {
                String fieldName = name.substring(3);
                if (fieldName.length() == 0) continue;
                fieldName = Character.toLowerCase(fieldName.charAt(0)) + fieldName.substring(1);
                if (fieldNames.containsKey(fieldName)) {
                    throw new RuntimeException("conflict def on field " + fieldName);
                }
                fieldNames.put(fieldName, m);
            }
        }
        
        for (Field f : clazz.getFields()) {
            if (Modifier.isStatic(f.getModifiers()))
                continue;
            
            Persistent persistentA = f.getAnnotation(Persistent.class);
            if (persistentA != null) {
                if (!persistentA.value()) continue;
            } else {
                if (!auto) continue;
            }
            
            if (Modifier.isPublic(f.getModifiers())) {
                String fieldName = f.getName();
                if (fieldNames.containsKey(fieldName)) {
                    throw new RuntimeException("conflict def on field " + fieldName);
                }
                fieldNames.put(fieldName, f);
            }
        }
        
        ArrayList<FieldMeta> metas = new ArrayList<FieldMeta>();
        for (String fieldName : fieldNames.keySet()) {
            Object o = fieldNames.get(fieldName);
            
            Field field = null;
            Class<?> returnType;
            Method getter = null;
            Method setter = null;
            int order = 65535; // default order
            if (o instanceof Field) {
                field = (Field) o;
                returnType = field.getType();
                PersistentOrder pa = field.getAnnotation(PersistentOrder.class);
                if (pa != null) {
                    order = pa.value();
                }
            } else {
                String capitalized = Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1);
                getter = methodMap.get("get" + capitalized);
                setter = methodMap.get("set" + capitalized);
                returnType = getter.getReturnType();
                if (getter.getParameterTypes().length != 0) {
                    continue;
                }
                PersistentOrder pa = getter.getAnnotation(PersistentOrder.class);
                if (pa != null) {
                    order = pa.value();
                }
            }
            
            Object zero = null;
            Method clearer = null;
            
            Method reader = null, writer = null;
            boolean primitive = false;
            if (returnType == Integer.TYPE) {
                reader = readIntMethod;
                writer = writeIntMethod;
                primitive = true;
                zero = (int)0;
            } else if (returnType == Short.TYPE) {
                reader = readShortMethod;
                writer = writeShortMethod;
                primitive = true;
                zero = (short)0;
            } else if (returnType == Byte.TYPE) {
                reader = readByteMethod;
                writer = writeByteMethod;
                primitive = true;
                zero = (byte)0;
            } else if (returnType == Character.TYPE) {
                reader = readCharMethod;
                writer = writeCharMethod;
                primitive = true;
                zero = (char)0;
            } else if (returnType == Long.TYPE) {
                reader = readLongMethod;
                writer = writeLongMethod;
                primitive = true;
                zero = (long)0;
            } else if (returnType == Boolean.TYPE) {
                reader = readBooleanMethod;
                writer = writeBooleanMethod;
                primitive = true;
                zero = (boolean)false;
            } else if (returnType == Float.TYPE) {
                reader = readFloatMethod;
                writer = writeFloatMethod;
                primitive = true;
                zero = (float)0;
            } else if (returnType == Double.TYPE) {
                reader = readDoubleMethod;
                writer = writeDoubleMethod;
                primitive = true;
                zero = (double)0;
            } else if (returnType == String.class) {
                reader = readStringMethod;
                writer = writeStringMethod;
                primitive = true;
                zero = "";
            } else if (IWritable.class.isAssignableFrom(returnType)) {
                reader = readWritableMethod;
                writer = writeWritableMethod;
                primitive = false;
                try {
                    clearer = returnType.getMethod("clear", new Class[0]);
                } catch(Exception e) {
                    clearer = null;
                }
            } else if (setter == null && field == null) {
                continue;
            } else {
                throw new RuntimeException("unsupported type " + returnType + " for field " + fieldName);
            }
            if (primitive) {
                if (field == null) {
                    if (setter == null || setter.getParameterTypes().length != 1 
                            || setter.getParameterTypes()[0] != returnType) {
                        continue;
                    }
                } 
            }
            metas.add(new FieldMeta(fieldName, getter, setter, clearer, field, 
                    reader, writer, returnType, primitive, zero, order));
        }
        
        Collections.sort(metas);
        fields = metas.toArray(new FieldMeta[metas.size()]);
        
        for (FieldMeta field : fields) {
            fieldsMap.put(field.name, field);
        }
        
    }
    

    final int readInt(DataInput in) throws IOException { return in.readInt(); }
    final void writeInt(DataOutput out, int value) throws IOException { out.writeInt(value); }
    final byte readByte(DataInput in) throws IOException { return in.readByte(); }
    final void writeByte(DataOutput out, byte value) throws IOException { out.writeByte(value); }
    final short readShort(DataInput in) throws IOException { return in.readShort(); }
    final void writeShort(DataOutput out, short value) throws IOException { out.writeShort(value); }
    final char readChar(DataInput in) throws IOException { return in.readChar(); }
    final void writeChar(DataOutput out, char value) throws IOException { out.writeChar(value); }
    final long readLong(DataInput in) throws IOException { return in.readLong(); }
    final void writeLong(DataOutput out, long value) throws IOException { out.writeLong(value); }
    final boolean readBoolean(DataInput in) throws IOException { return in.readBoolean(); }
    final void writeBoolean(DataOutput out, boolean value) throws IOException { out.writeBoolean(value); }
    final double readDouble(DataInput in) throws IOException { return in.readDouble(); }
    final void writeDouble(DataOutput out, double value) throws IOException { out.writeDouble(value); }
    final float readFloat(DataInput in) throws IOException { return in.readFloat(); }
    final void writeFloat(DataOutput out, float value) throws IOException { out.writeFloat(value); }
    final String readString(DataInput in) throws IOException { return StringWritable.readString(in); }
    final void writeString(DataOutput out, String value) throws IOException { StringWritable.writeString(out, value); }
    final void readWritable(DataInput in, IWritable instance) throws IOException { instance.readFields(in); }
    final void writeWritable(DataOutput out, IWritable instance) throws IOException { instance.writeFields(out); }
    
    private static class FieldMeta implements Comparable<FieldMeta> {
        private int order;
        
        private String name;
        
        private Method getter;
        private Method setter;
        private Method clearer;
        private Field field;
        private Object zero;
        
        private Method writer;
        private Method reader;
        
        private Class type;
        private boolean primitive;
        
        public FieldMeta(String name, Method getter, Method setter, Method clearer, 
                Field field, Method reader, Method writer, Class type, 
                boolean primitive, Object zero, int order) {
            this.name = name;
            this.getter = getter;
            this.setter = setter;
            this.clearer = clearer;
            this.field = field;
            this.reader = reader;
            this.writer = writer;
            this.type = type;
            this.primitive = primitive;
            this.zero = zero;
            this.order = order;
        }

        public int compareTo(FieldMeta o) {
            if (this.order == o.order) {
                return this.name.compareTo(o.name);
            } else if (this.order < o.order) {
                return -1;
            } else {
                return 1;
            }
        }
        
        public String toString() {
            return name;
        }
    }
    
}
