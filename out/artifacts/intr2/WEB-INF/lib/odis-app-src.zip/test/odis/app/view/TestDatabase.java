package odis.app.view;

import java.util.ArrayList;
import java.util.Random;

import odis.cowork.CoWorkUtils;
import odis.file.SequenceFile;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.TestCaseOdis;
import toolbox.misc.channel.IObjectOutput;


public class TestDatabase extends TestCaseOdis {
    public void testMultiValues() throws Exception {
        final int N = 1000;
        final int PART = 3;
        Random rand = new Random(10);
        
        /*
         * Make input data
         */
        SequenceFile.Writer[] writers = new SequenceFile.Writer[PART];
        SeqFileHashPartitioner partitioner = new SeqFileHashPartitioner();
        
        for (int i = 0; i < PART; i ++) {
            writers[i] = new SequenceFile.Writer(fs, 
                    inputPath.cat(CoWorkUtils.getPartID(i)), 
                    IntWritable.class, StringWritable.class); 
        } // for i
        
        int[] counts = new int[N];
        for (int i = 0; i < N; i ++) {
            int cnt = rand.nextInt(5) + 1;
            counts[i] = cnt;
            for (int j = 0; j < cnt; j ++) {
                IntWritable key = new IntWritable(i);
                StringWritable val = new StringWritable(i + "-" + j);
                
                int part = partitioner.getPartition(key, val, PART);
                writers[part].write(key, val);
            } // for j
        } // for i
        
        for (int i = 0; i < PART; i ++) {
            writers[i].close(); 
        } // for i
        
        Database<IntWritable, StringWritable> db =
            new Database<IntWritable, StringWritable>(fs, 
                    this.inputPath);
        
        /*
         * Read and check
         */
        for (int i = 0; i < 10; i ++) {
            int k = rand.nextInt(N);
            IntWritable key = new IntWritable(k); 
            final ArrayList<String> vals = new ArrayList<String>();
            int cnt = db.search(key, new IObjectOutput() {
                public void output(Object... objects) throws Exception {
                    vals.add(objects[0].toString());
                }
            });
            
            assertEquals("The number of records for " +  k, counts[k], cnt);
            assertEquals("The number of output times", cnt, vals.size());
            for (int j = 0; j < cnt; j ++) {
                assertEquals("The " + j + "-th value for key " + k, k + "-" + j,
                        vals.get(j));
            } // for j
        } // for i
    }
}
