/**
 * @(#)TestSitesDumpTool.java, Mar 24, 2011. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import odis.app.view.SeqFileUtils;
import odis.io.Path;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.Url;
import odis.tools.ToolTest;

/**
 *
 * @author zhanglh
 *
 */
public class TestSitesDumpTool extends ToolTest {
    
    private static final String [] URLS = {
        "http://1.com/",
        "http://1.com/a?b=c",
        "http://www.1.com/",
        "http://2.com/",
        "http://2.com/a",
        "http://2.com/test1",
        "http://2.com/test/a",
        "http://2-2.com/",
        "http://www.2.com/b",
        "http://3.com/test/",
        "http://www.3.com/b",
        "http://www.3.com/test/",
        "http://4.com/a/",
        "http://4.com/b/",
        "http://4.com/c/",
        "http://5.com/",
    };
    
    private static final String []PATTERNS = {
        "1.com",
        "*.2.com",
        "2.com/test/",
        "*.3.com/test/",
        "33.com", // not exist pattern between
        "4.com/a/",
        "4.com/c/",
        "noexist.com",
    };
    
    private static final String []RESULTS = {
        "http://1.com/",
        "http://1.com/a?b=c",
        "http://2.com/test/a",
        "http://www.2.com/b",
        "http://www.3.com/test/",
        "http://4.com/a/",
        "http://4.com/c/",
    };

    @Override
    public void createInput() throws Exception {
        HashMap<Url, IntWritable> map = new HashMap<Url, IntWritable>();
        Random rand = new Random();
        for (String url : URLS) {
            map.put(new Url(url), new IntWritable(rand.nextInt()));
        }
        SeqFileUtils.saveMapToDatabase(ctx.fs(), 
                ctx.context().path("input"), 1, 
                new SeqFileHashPartitioner(), map, false);
        
        BufferedWriter writer = new BufferedWriter(
                new FileWriter(ctx.context().path("pattern").asFile()));
        for (String pattern : PATTERNS) {
            writer.write(pattern + "\n");
        }
        writer.close();
    }

    @Override
    public void execute() throws Exception {
        runTool(SitesDumpTool.class, "-i input -o output -f " 
                + ctx.context().path("pattern").getAbsolutePath());
    }

    @Override
    public void checkOutput() throws Exception {
        Path output = ctx.context().path("output");
        Map<Object, Object> map = SeqFileUtils.loadToMap(ctx.fs(), output);
        assertTrue("no enough output data", map.size() == RESULTS.length);
        for (String result : RESULTS)
            assertTrue(result + " not int result", 
                    map.containsKey(new Url(result)));
    }
}
