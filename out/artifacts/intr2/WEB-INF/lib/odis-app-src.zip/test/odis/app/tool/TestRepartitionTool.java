package odis.app.tool;

import java.io.File;
import java.util.Random;

import odis.cowork.CoWorkUtils;
import odis.file.SequenceFile;
import odis.io.Path;
import odis.serialize.lib.IntWritable;
import odis.tools.TestCaseOdis;
import odis.tools.ToolContext;

public class TestRepartitionTool extends TestCaseOdis {

    public void createInput() throws Exception {
        File dir = new File(context.getAppRoot(), "test");

        Random rand = new Random();
        for (int i = 0; i < 7; i++) {
            SequenceFile.Writer writer = new SequenceFile.Writer(fs, new Path(
                    dir, CoWorkUtils.getPartID(i)), IntWritable.class,
                    IntWritable.class);
            try {
                for (int j = 0; j < 100; j++) {
                    writer.write(new IntWritable(rand.nextInt()),
                            new IntWritable(rand.nextInt()));
                }
            } finally {
                writer.close();
            }
        }
    }

    public void execute() throws Exception {
        RepartitionTool tool = new RepartitionTool();

        tool.setEnv(context,
                "-d test -p 12 -c odis.mapred.lib.SeqFileHashPartitioner -name test"
                        .split("\\s+"), out);
        tool.exec(1);
    }

    public void checkOutput() throws Exception {
        File dir = new File(context.getAppRoot(), "test");

        int count = 0;
        for (int i = 0; i < 12; i++) {
            SequenceFile.Reader reader = new SequenceFile.Reader(fs, new Path(
                    dir, CoWorkUtils.getPartID(i)));
            try {
                IntWritable key = new IntWritable();
                IntWritable value = new IntWritable();
                while (reader.next(key, value)) {
                    count++;
                    assertTrue((key.get() & Integer.MAX_VALUE) % 12 == i);
                }
            } finally {
                reader.close();
            }
        }

        assertTrue(count == 7 * 100);
    }

    public void test() throws Exception {
        ToolContext.getConfig().setProperty("file.seqfile.sort.memory-mb", 1);
        createInput();
        execute();
        checkOutput();
    }

}
