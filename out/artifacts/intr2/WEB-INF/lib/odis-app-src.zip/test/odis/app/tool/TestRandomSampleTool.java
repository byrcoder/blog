/**
 * @(#)TestRandomSampleTool.java, 2008-9-13. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import odis.app.view.SeqFileUtils;
import odis.io.Path;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.lib.IntWritable;
import odis.tools.ToolTest;

/**
 *
 * @author river
 *
 */
public class TestRandomSampleTool extends ToolTest {

    @Override
    public void createInput() throws Exception {
        HashMap<IntWritable, IntWritable> map = new HashMap<IntWritable, IntWritable>();
        Random rand = new Random(1000);
        for (int i=0; i<1000; i++) {
            map.put(new IntWritable(i), new IntWritable(rand.nextInt()));
        }
        SeqFileUtils.saveMapToDatabase(ctx.fs(), 
                ctx.context().path("input"), 5, 
                new SeqFileHashPartitioner(), map, false);
    }

    @Override
    public void execute() throws Exception {
        runTool(RandomSampleTool.class, "-i input -o output -n 15 -p 2");
    }

    @Override
    public void checkOutput() throws Exception {
        Path output = ctx.context().path("output");
        assertEquals("output partition number error", 2, ctx.fs().listFiles(output).length);
        
        Map<Object, Object> map = SeqFileUtils.loadToMap(ctx.fs(), output);
        assertTrue("no enough output data", map.size() > 0);
    }
    
}
