/**
 * @(#)TestAbstractFilterTool.java, 2008-3-2. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import odis.app.tool.DbFilterTool.AbstractDirectFilter;
import odis.app.view.SeqFileUtils;
import odis.cowork.JobConfig;
import odis.cowork.TaskRunnable;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.Url;
import odis.tools.TestCaseOdis;

/**
 *
 * @author river
 *
 */
public class TestDbFilterTool extends TestCaseOdis {
    
    private String [][] data = {
            {"http://www.tom.com/", "Tom site" },
            {"http://www.163.com/", "163 site" },
    };
    
    private void createInput() throws Exception {
        HashMap<Url, StringWritable> map = new HashMap<Url, StringWritable>();
        for (String [] rec : data) {
            Url url = new Url(rec[0]);
            StringWritable s = new StringWritable(rec[1]);
            map.put(url, s);
        }
        SeqFileUtils.saveMapToDatabase(fs, context.path("input"), 2, 
                new UrlMd5Partitioner(), map, false);
    }
    
    public static final class Filter1 extends AbstractDirectFilter<Url, StringWritable> {

        private HashSet<Url> targetSet = new HashSet<Url>();
        
        @Override
        public void init(JobConfig config, TaskRunnable task) {
            String [] targets = config.getStringArray("targets");
            for (String target : targets) {
                targetSet.add(new Url(target));
            }
        }

        @Override
        public void prepareConfig(JobConfig config) {
            config.setProperty("targets", "http://www.163.com/, http://www.sohu.com/");
        }


        @Override
        public boolean accept(Url key, StringWritable value) {
            return targetSet.contains(key);
        }
        
    }
    
    /**
     * direct filter output.
     * @throws Exception
     */
    public void test1() throws Exception {
        createInput();
        
        this.runTool(DbFilterTool.class, 
                ("-in input -out output -filter " + Filter1.class.getName()).split("\\s+"));
        
        Map<Object, Object> resultMap = SeqFileUtils.loadToMap(fs, context.path("output"));
        assertEquals(1, resultMap.size());
        assertEquals(data[1][1], resultMap.get(new Url("http://www.163.com/")).toString());
        
        this.runTool(DbFilterTool.class, ("-in input -out output1 -filter regexp -vreg \\d+\\s+site -rn 1").split("\\s+"));
        resultMap = SeqFileUtils.loadToMap(fs, context.path("output1"));
        assertEquals(1, resultMap.size());
        assertEquals(data[1][1], resultMap.get(new Url("http://www.163.com/")).toString());
        
    }
    
}
