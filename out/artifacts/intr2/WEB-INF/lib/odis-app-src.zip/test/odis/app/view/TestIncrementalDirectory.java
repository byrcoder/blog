/**
 * @(#)TestIncrementalDirectory.java, 2007-8-7. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.view;

import odis.cowork.CoWorkUtils;
import odis.io.Path;
import odis.tools.TestCaseOdis;

/**
 *
 * @author river
 *
 */
public class TestIncrementalDirectory extends TestCaseOdis {

    private void createDb(Path db, int partNumber) throws Exception {
        if (fs.exists(db)) {
            fs.delete(db);
        }
        fs.mkdirs(db);
        for (int i=0; i<partNumber; i++) {
            Path part = db.cat(CoWorkUtils.getPartID(i));
            fs.create(part).close();
        }
    }
    
    public void test() throws Exception {
        IncrementalDirectory incDir  = new IncrementalDirectory(fs, 
                this.context.path("test"));
        assertEquals("latestVersion()", null, incDir.getLatestVersion());
        Path dbPath = context.path("db");
        createDb(dbPath, 4);
        IncrementalDirectory.Version version = incDir.createMajorVersion(dbPath, true);
        assertEquals("version.major", 1, version.getMajor());
        assertEquals("version.minor", 0, version.getMinor());
        assertEquals("latestVersion()", version, incDir.getLatestVersion());
    }
    
}
