/**
 * @(#)TestTopCollectTool.java, 2007-7-16. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.util.HashMap;

import odis.app.tool.AbstractTopCollectTool.Extracter;
import odis.app.view.SeqFileUtils;
import odis.cowork.CoWorkUtils;
import odis.file.SequenceFile;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.tools.ToolTest;

/**
 * @author river
 *
 */
public class TestAbstractTopCollectTool extends ToolTest {
    
    public static class MyCollectTool extends AbstractTopCollectTool implements Extracter {

        @Override
        public Extracter getExtracter() {
            return this;
        }

        public boolean extractData(Object key, Object val, Object newKey, Object newVal) {
            ((LongWritable)newKey).copyFields((LongWritable)val);
            ((IntWritable)newVal).copyFields((IntWritable)key);
            return true;
        }

        public Class getKeyClass() {
            return LongWritable.class;
        }

        public double getScore(Object key, Object val) {
            return ((IntWritable)key).get();
        }

        public Class getValClass() {
            return IntWritable.class;
        }
        
    }
    
    @Override
    public void createInput() throws Exception {
        HashMap<IntWritable, LongWritable> map = new HashMap<IntWritable, LongWritable>();
        for (int i=0; i<100; i++) {
            map.put(new IntWritable(i), new LongWritable(1));
        }
        SeqFileUtils.saveMapToFile(ctx.fs(), ctx.context().path("input", CoWorkUtils.getPartID(0)), map);
    }

    @Override
    public void execute() throws Exception {
        runTool(MyCollectTool.class, "-in input -out output -n 50".split("\\s+"));
    }

    @Override
    public void checkOutput() throws Exception {
        SequenceFile.Reader reader = new SequenceFile.Reader(ctx.fs(), 
                ctx.context().path("output", CoWorkUtils.getPartID(0)));
        LongWritable key = new LongWritable();
        IntWritable val = new IntWritable();
        
        for (int i=99; i>=50; i--) {
            assertTrue(reader.next(key, val));
            assertEquals(1, key.get());
            assertEquals(i, val.get());
        }
        assertFalse(reader.next(key, val));
    }

}
