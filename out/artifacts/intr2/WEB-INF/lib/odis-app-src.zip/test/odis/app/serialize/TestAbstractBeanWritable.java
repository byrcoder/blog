/**
 * @(#)TestAbstractBeanWritable.java, 2008-2-13. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.serialize;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.app.serialize.annotation.AutoPersistent;
import odis.app.serialize.annotation.Persistent;
import odis.app.serialize.annotation.PersistentOrder;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;

import org.junit.Test;

/**
 * @author river
 */
public class TestAbstractBeanWritable {

    public static class A extends AbstractBeanWritable {
        // static fields should not be marshalled/unmarshalled
        public static final int C = 0;

        private int i1;

        private int i2;

        private final StringWritable s = new StringWritable();

        public final UTF8Writable u = new UTF8Writable();

        /**
         * 用来测试BeanWritableHelper的一个bug getFields()以前对 if
         * (getter.getParameterTypes().length != 0) 的处理有错 应该忽略，但是以前错误的return了
         * 
         * @param someParam
         * @return
         */
        public int getForTestReturnBug(String someParam) {
            return 0;
        }

        /**
         * @return the i1
         */
        public int getI1() {
            return i1;
        }

        /**
         * @param i1
         *            the i1 to set
         */
        public void setI1(int i1) {
            this.i1 = i1;
        }

        /**
         * @return the i2
         */
        @PersistentOrder(0)
        public int getI2() {
            return i2;
        }

        /**
         * @param i2
         *            the i2 to set
         */
        public void setI2(int i2) {
            this.i2 = i2;
        }

        public StringWritable getS() {
            return s;
        }

    }

    @AutoPersistent(false)
    public static class B extends AbstractBeanWritable {
        public int i1 = 0;

        @Persistent(true)
        public int i2 = 0;
    }

    public static class AW implements IWritable {
        private int i1;

        private int i2;

        private final StringWritable s = new StringWritable();

        private final UTF8Writable u = new UTF8Writable();

        public void readFields(DataInput in) throws IOException {
            i1 = in.readInt();
            i2 = in.readInt();
            s.readFields(in);
            u.readFields(in);
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeInt(i1);
            out.writeInt(i2);
            s.writeFields(out);
            u.writeFields(out);
        }

        public IWritable copyFields(IWritable value) {
            if (value == null || !(value instanceof AW)) {
                throw new RuntimeException("bad value : " + value);
            }
            if (value == this)
                return this;
            AW that = (AW) value;
            this.i1 = that.i1;
            this.i2 = that.i2;
            this.s.copyFields(that.s);
            this.u.copyFields(that.u);
            return this;
        }
    }

    @Test
    public void testCorrectness() throws Exception {
        A a = new A();
        a.i1 = 1;
        a.i2 = 2;
        a.s.set("this is a test");
        a.u.set("utf8");

        DataOutputBuffer obuf = new DataOutputBuffer();
        DataInputBuffer ibuf = new DataInputBuffer();

        // write and read
        a.writeFields(obuf);
        ibuf.reset(obuf.getData(), 0, obuf.size());
        A a1 = new A();
        a1.readFields(ibuf);

        assertEquals(a.i1, a1.i1);
        assertEquals(a.i2, a1.i2);
        assertEquals(a.s, a1.s);
        assertEquals(a.u, a1.u);

        // copy fields
        A a2 = new A();
        a2.copyFields(a);
        assertEquals(a.i1, a2.i1);
        assertEquals(a.i2, a2.i2);
        assertEquals(a.s, a2.s);
        assertEquals(a.u, a2.u);

        // clear
        a1.clear();
        assertEquals(0, a1.i1);
        assertEquals(0, a1.i2);
        assertEquals("", a1.s.get());
        assertEquals("", a1.u.get());

        // check order
        ibuf.reset(obuf);
        assertEquals(a.i2, ibuf.readInt());

        // no auto persistent
        B b1 = new B();
        b1.i1 = Integer.MAX_VALUE - 2;
        b1.i2 = Integer.MAX_VALUE - 3;
        obuf.reset();
        b1.writeFields(obuf);
        B b2 = new B();
        ibuf.reset(obuf);
        b2.readFields(ibuf);
        assertEquals(b1.i2, b2.i2);
        assertEquals(0, b2.i1);

    }

    @Test
    public void testPropertyAccess() throws Exception {
        A a = new A();
        assertTrue(Arrays.deepEquals(a.getPropertyNames(), new String[] {
            "i2", "i1", "s", "u"
        }));

        a.setProperty("i1", 1);
        a.setProperty("i2", 2);
        a.setProperty("s", "this is a test");
        a.setProperty("u", "utf8");
        assertEquals(1, a.getProperty("i1"));
        assertEquals(2, a.getProperty("i2"));
        assertEquals("this is a test", a.getProperty("s").toString());
        assertEquals("utf8", a.getProperty("u").toString());
    }

    public static class StringBeanWritable extends AbstractBeanWritable {
        private String strA;

        private String strB;

        public String getStrA() {
            return strA;
        }

        public void setStrA(String strA) {
            this.strA = strA;
        }

        public String getStrB() {
            return strB;
        }

        public void setStrB(String strB) {
            this.strB = strB;
        }

    }

    @Test
    public void testString() throws IOException {
        StringBeanWritable w = new StringBeanWritable();
        w.clear();
        assertEquals("", w.getStrA());
        assertEquals("", w.getStrB());
        w.setStrA("strB");
        w.setStrB("strA");
        DataOutputBuffer out = new DataOutputBuffer();
        w.writeFields(out);
        DataInputBuffer in = new DataInputBuffer(out);
        StringBeanWritable w1 = new StringBeanWritable();
        w1.readFields(in);
        assertEquals("strB", w1.getStrA());
        assertEquals("strA", w1.getStrB());
    }

    @Test
    public void testPerformance() throws Exception {
        DataOutputBuffer obuf = new DataOutputBuffer();
        DataInputBuffer ibuf = new DataInputBuffer();

        int r1 = 10000, r2 = 100;
        long start = System.currentTimeMillis();
        for (int c = 0; c < r1; c++) {
            AW a = new AW();
            obuf.reset();
            for (int i = 0; i < r2; i++) {
                a.i1 = c + i;
                a.i2 = c * i;
                a.s.set("a" + c + i);
                a.writeFields(obuf);
            }
            ibuf.reset(obuf.getData(), 0, obuf.size());
            for (int i = 0; i < r2; i++) {
                a.readFields(ibuf);
            }
        }
        long end = System.currentTimeMillis();
        System.out.println("first time : " + (end - start) + " ms.");

        start = System.currentTimeMillis();
        for (int c = 0; c < r1; c++) {
            A a = new A();
            obuf.reset();
            for (int i = 0; i < r2; i++) {
                a.i1 = c + i;
                a.i2 = c * i;
                a.s.set("a" + c + i);
                a.writeFields(obuf);
            }
            ibuf.reset(obuf.getData(), 0, obuf.size());
            for (int i = 0; i < r2; i++) {
                a.readFields(ibuf);
            }
        }
        end = System.currentTimeMillis();
        System.out.println("second time : " + (end - start) + " ms.");

    }

}
