package odis.app.job;

import junit.framework.JUnit4TestAdapter;
import odis.app.job.SimpleJobs;
import odis.app.job.SimpleJobs.SimpleLookupMerger;
import odis.io.Path;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.Url;
import odis.tools.TestCaseOdis;

import org.junit.Assert;
import org.junit.Test;

import toolbox.tchelper.kvadapter.SortedSeqFileAdapter;

public class TestSimpleJobs extends TestCaseOdis {
    // for Ant compatibility
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(TestSimpleJobs.class);
    }

    @Test
    public void testMergeLookupTest() throws Exception {
        int PART_NUM = 3;
        /* 
         * Key 1
         */
        int[] key1Key = {
            1, 3, 5, 7
        };
        String[] key1Val = {
            "1_one", "3_three", "5_five", "7_seven"
        };
        /*
         * Key 2
         */
        int[] key2Key = {
            3, 4, 5, 7, 9
        };
        String[] key2Val = {
            "3_THREE", "4_FOUR", "5_FIVE", "7_SEVEN", "9_NINE"
        };
        /*
         * Value 1
         */
        int[] val1Key = {
            1, 2, 3, 4, 4, 5
        };
        String[] val1Val = {
            "www.1.com", "www.2.com", "www.3.com", "www.4.com", "www.4.org",
            "www.5.com"
        };
        /*
         * Value 1
         */
        int[] val2Key = {
            1, 4, 5, 6, 7, 8, 9, 10
        };
        String[] val2Val = {
            "www.1.cn", "www.4.cn", "www.5.cn", "www.6.cn", "www.7.cn",
            "www.8.cn", "www.9.cn", "www.10.cn"
        };
        /*
         * Result
         */
        String[] resKey = {
            "1_one", "3_three", "4_FOUR", "5_five", "7_seven", "9_NINE"
        };
        String[] resVal = {
            "www.1.com", "www.3.com", "www.4.com", "www.5.com", "www.7.cn",
            "www.9.cn",
        };

        // zf: results for MULTI_VALUES=true
        String[] resKeyMulti = {
            "1_one", "1_one", "3_three", "4_FOUR", "4_FOUR", "4_FOUR",
            "5_five", "5_five", "7_seven", "7_seven", "9_NINE"
        };
        String[] resValMulti = {
            "www.1.com", "www.1.cn", "www.3.com", "www.4.com", "www.4.org",
            "www.4.cn", "www.5.com", "www.5.cn", "www.7.cn", "www.7.cn",
            "www.9.cn",
        };

        SeqFileHashPartitioner partitioner = new SeqFileHashPartitioner();
        SortedSeqFileAdapter<IntWritable, StringWritable> key1 = new SortedSeqFileAdapter<IntWritable, StringWritable>(
                IntWritable.class, StringWritable.class, PART_NUM, partitioner,
                "key1", null, null);
        for (int i = 0; i < key1Key.length; i++)
            key1.add(new IntWritable(key1Key[i]),
                    new StringWritable(key1Val[i]));
        SortedSeqFileAdapter<IntWritable, StringWritable> key2 = new SortedSeqFileAdapter<IntWritable, StringWritable>(
                IntWritable.class, StringWritable.class, PART_NUM, partitioner,
                "key2", null, null);
        for (int i = 0; i < key2Key.length; i++)
            key2.add(new IntWritable(key2Key[i]),
                    new StringWritable(key2Val[i]));
        SortedSeqFileAdapter<IntWritable, Url> val1 = new SortedSeqFileAdapter<IntWritable, Url>(
                IntWritable.class, Url.class, PART_NUM, partitioner, "val1",
                null, null);
        for (int i = 0; i < val1Key.length; i++)
            val1.add(new IntWritable(val1Key[i]), new Url(val1Val[i]));
        SortedSeqFileAdapter<IntWritable, Url> val2 = new SortedSeqFileAdapter<IntWritable, Url>(
                IntWritable.class, Url.class, PART_NUM, partitioner, "val2",
                null, null);
        for (int i = 0; i < val2Key.length; i++)
            val2.add(new IntWritable(val2Key[i]), new Url(val2Val[i]));

        key1.setAvailable(true);
        key2.setAvailable(true);
        val1.setAvailable(true);
        val2.setAvailable(true);

        Path key1Path = inputPath.cat(key1.getRelPath());
        Path key2Path = inputPath.cat(key2.getRelPath());
        Path val1Path = inputPath.cat(val1.getRelPath());
        Path val2Path = inputPath.cat(val2.getRelPath());

        key1.save(fs, inputPath);
        key2.save(fs, inputPath);
        val1.save(fs, inputPath);
        val2.save(fs, inputPath);

        SortedSeqFileAdapter<StringWritable, Url> res = new SortedSeqFileAdapter<StringWritable, Url>(
                StringWritable.class, Url.class, PART_NUM, partitioner,
                "result", null, null);
        res.setAllowDuplicated(false);
        Path resPath = outputPath.cat(res.getRelPath());

        /*
         * Run the job.
         */
        //        Assert.assertTrue("Job failed!",
        //                SimpleJobs.mergeLookup(context, fs, 
        //                        new Path[]{key1Path, key2Path}, new Path[]{val1Path, val2Path},
        //                        PART_NUM, resPath, PART_NUM, 
        //                        IntWritable.class, StringWritable.class, Url.class, 
        //                        SeqFileHashPartitioner.class, PART_NUM, null)
        //            );
        Assert.assertTrue("Job failed!", SimpleJobs.mergeLookup(context, fs,
                new Path[] {
                    key1Path, key2Path
                }, new Path[] {
                    val1Path, val2Path
                }, resPath, PART_NUM, SeqFileHashPartitioner.class, PART_NUM,
                null));

        /*
         * Load anc check
         */
        res.checkData(fs, outputPath);
        res.load(fs, outputPath);

        SortedSeqFileAdapter<StringWritable, Url> resGnd = new SortedSeqFileAdapter<StringWritable, Url>(
                StringWritable.class, Url.class, PART_NUM, partitioner,
                "result", null, null);
        for (int i = 0; i < resKey.length; i++) {
            resGnd.add(new StringWritable(resKey[i]), new Url(resVal[i]));
        } // for i
        resGnd.setAvailable(true);

        res.check(resGnd);

        // zf: check when MULTI_VALUES=true
        SortedSeqFileAdapter<StringWritable, Url> resMulti = new SortedSeqFileAdapter<StringWritable, Url>(
                StringWritable.class, Url.class, PART_NUM, partitioner,
                "resultMulti", null, null);
        res.setAllowDuplicated(true);
        Path resMultiPath = outputPath.cat(resMulti.getRelPath());

        /*
         * Run the job.
         */
        Assert.assertTrue("Job failed!", SimpleJobs.mergeLookup(context, fs,
                new Path[] {
                    key1Path, key2Path
                }, new Path[] {
                    val1Path, val2Path
                }, resMultiPath, PART_NUM, SeqFileHashPartitioner.class,
                PART_NUM, new IJobConfigurer<MapReduceJobDef>() {
                    public void configure(MapReduceJobDef job) {
                        job.getConfig().setBoolean(
                                SimpleLookupMerger.MULTI_VALUES, true);
                    }
                }));

        /*
         * Load and check
         */
        resMulti.checkData(fs, outputPath);
        resMulti.load(fs, outputPath);

        SortedSeqFileAdapter<StringWritable, Url> resMultiGnd = new SortedSeqFileAdapter<StringWritable, Url>(
                StringWritable.class, Url.class, PART_NUM, partitioner,
                "result", null, null);
        for (int i = 0; i < resKeyMulti.length; i++) {
            resMultiGnd.add(new StringWritable(resKeyMulti[i]), new Url(
                    resValMulti[i]));
        } // for i
        resMultiGnd.setAvailable(true);

        resMulti.check(resMultiGnd);

    }
}
