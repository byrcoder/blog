/**
 * @(#)TestDbCompressTool.java, 2007-11-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.util.HashMap;
import java.util.Map;

import odis.app.view.SeqFileUtils;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.ToolTest;

/**
 *
 * @author river
 *
 */
public class TestDbCompressTool extends ToolTest {

    @Override
    public void createInput() throws Exception {
        Map<IntWritable, StringWritable> data = new HashMap<IntWritable, StringWritable>();
        for (int i=0; i<100; i++) {
            data.put(new IntWritable(i), new StringWritable("test-" + i));
        }
        SeqFileUtils.saveMapToDatabase(ctx.fs(), ctx.context().path("input"), 
                2, new SeqFileHashPartitioner(), data, false);
    }

    @Override
    public void execute() throws Exception {
        runTool(DbCompressTool.class, 
                ("-s " + ctx.context().path("input").getAbsolutePath()).split("\\s+"));
    }
    
    @Override
    public void checkOutput() throws Exception {
        Map map = SeqFileUtils.loadToMap(ctx.fs(), ctx.context().path("input"));
        assertEquals("bad data size", 100, map.size());
        for (int i=0; i<100; i++) {
            IntWritable key = new IntWritable(i);
            StringWritable value = (StringWritable) map.get(key);
            assertTrue("bad data", value != null);
            assertEquals("bad data", "test-" + i, value.get());
        }
    }

}
