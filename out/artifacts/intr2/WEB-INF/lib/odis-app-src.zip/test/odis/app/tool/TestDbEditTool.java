/**
 * @(#)TestDbEditTool.java, 2007-6-6. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import odis.app.tool.DbEditTool.Modifier;
import odis.app.tool.DbEditTool.Modifier.Editor;
import odis.app.view.SeqFileUtils;
import odis.cowork.CoWorkUtils;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.Url;
import odis.tools.ToolTest;

/**
 * @author river
 *
 */
public class TestDbEditTool extends ToolTest {

    public static class SiteAttr implements IWritable {
        private int capability;
        private float siteRank;
        private int updatePriority;
        private int fetchPriority;
        
        public int getCapability() {
            return capability;
        }

        public void setCapability(int capability) {
            this.capability = capability;
        }

        public int getFetchPriority() {
            return fetchPriority;
        }

        public void setFetchPriority(int fetchPriority) {
            this.fetchPriority = fetchPriority;
        }

        public float getSiteRank() {
            return siteRank;
        }

        public void setSiteRank(float siteRank) {
            this.siteRank = siteRank;
        }

        public int getUpdatePriority() {
            return updatePriority;
        }

        public void setUpdatePriority(int updatePriority) {
            this.updatePriority = updatePriority;
        }

        public void readFields(DataInput in) throws IOException {
            capability = CDataInputStream.readVInt(in);
            updatePriority = CDataInputStream.readVInt(in);
            fetchPriority = CDataInputStream.readVInt(in);
            siteRank = in.readFloat();
        }

        public void writeFields(DataOutput out) throws IOException {
            CDataOutputStream.writeVInt(capability, out);
            CDataOutputStream.writeVInt(updatePriority, out);
            CDataOutputStream.writeVInt(fetchPriority, out);
            out.writeFloat(siteRank);
        }

        public IWritable copyFields(IWritable value) {
            if (value == null || !(value instanceof SiteAttr))
                throw new RuntimeException("bad value : " + value);
            if (value == this) return this;
            SiteAttr that = (SiteAttr) value;
            this.capability = that.capability;
            this.updatePriority = that.updatePriority;
            this.fetchPriority = that.fetchPriority;
            this.siteRank = that.siteRank;
            return this;
        }
    }
    
    public void testEditor() throws Exception {
        
        Editor editor = Modifier.parse(getClass().getResourceAsStream("dbedit_sample.xml"));
        
        List<Modifier.EditorPair<Object, Modifier.ObjectModifier>> creaters = editor.getCreateList();
        assertEquals("bad creator number", 1, creaters.size());
        assertEquals("bad key", new Url("www.google.com"), creaters.get(0).getKey());

        SiteAttr attr = new SiteAttr();
        creaters.get(0).getValue().apply(attr);
        
        assertEquals("bad value", 5, attr.getCapability());
        assertEquals("bad value", 10000.0f, attr.getSiteRank());
        
        attr = new SiteAttr();
        assertFalse("bad init value", attr.getUpdatePriority() == 8);
        editor.applyModification(new Url("help.163.com"), attr);
        assertEquals("bad value", 8, attr.getUpdatePriority());
        
    }

    private String [] sites = {
            "help.163.com",
            "www.baidu.com",
            "post.baidu.com",
            "www.bad.com",
            "wuyinghui97.blog.163.com",
            "comment.news.sohu.com",
    };
    
    private String [] resultList = {
            "www.google.com",
            "help.163.com",
            "www.baidu.com",
            "post.baidu.com",
            "wuyinghui97.blog.163.com",
            "comment.news.sohu.com",
    };
    
    
    @SuppressWarnings("unchecked")
    @Override
    public void createInput() throws Exception {
        Map[] partitions = new Map[2];
        for (int i=0; i<partitions.length; i++) {
            partitions[i] = new HashMap<String, SiteAttr>(); 
        }
        
        for (String s : sites) {
            Url url = new Url(s);
            partitions[UrlMd5Partitioner.getPartition(url, 2)].put(url, new SiteAttr());
        }
        
        for (int i=0; i<partitions.length; i++) {
            SeqFileUtils.saveMapToFile(ctx.fs(), 
                    ctx.context().path("siteattr", CoWorkUtils.getPartID(i)), 
                    partitions[i]);
        }
    }
    
    @Override
    public void execute() throws Exception {
        runTool(DbEditTool.class, ("-d " + 
                ctx.context().file("siteattr").getAbsolutePath() 
                + " -f " 
                + getClass().getResource("dbedit_sample.xml").getFile()
                ).split("\\s+"));
    }
    
    @Override
    public void checkOutput() throws Exception {
        Set<String> resultSet = new HashSet<String>();
        for (String s : resultList) { resultSet.add(s); }
        
        for (int i=0; i<2; i++) {
            Map<Object, Object> map = SeqFileUtils.loadToMap(ctx.fs(), 
                    ctx.context().path("siteattr", CoWorkUtils.getPartID(i)));
            for (Map.Entry<Object, Object> entry : map.entrySet()) {
                assertTrue("found bad entry : " + entry.getKey(), resultSet.remove(entry.getKey().toString()));
                if (entry.getKey().toString().equals("help.163.com")) {
                    assertEquals("bad value", 8, ((SiteAttr)(entry.getValue())).getUpdatePriority());
                } else if (entry.getKey().toString().equals("wuyinghui97.blog.163.com")) {
                    assertEquals("bad value", 5, ((SiteAttr)(entry.getValue())).getFetchPriority());
                } else if (entry.getKey().toString().equals("www.baidu.com")) {
                    assertEquals("bad value", 8, ((SiteAttr)(entry.getValue())).getFetchPriority());
                } else if (entry.getKey().toString().equals("post.baidu.com")) {
                    assertEquals("bad value", 8, ((SiteAttr)(entry.getValue())).getFetchPriority());
                } else if (entry.getKey().toString().equals("comment.news.sohu.com")) {
                    assertEquals("bad value", 1, ((SiteAttr)(entry.getValue())).getUpdatePriority());
                }
            }
        }
        
        assertTrue("value lost", resultSet.isEmpty());
    }


    
}
