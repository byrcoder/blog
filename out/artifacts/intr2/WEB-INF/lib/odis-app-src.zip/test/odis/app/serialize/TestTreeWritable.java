/**
 * 
 */
package odis.app.serialize;

import java.io.IOException;

import junit.framework.Assert;
import junit.framework.JUnit4TestAdapter;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.lib.StringWritable;

import org.junit.Test;


/**
 * @author why
 *
 */
public class TestTreeWritable {
    
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(TestTreeWritable.class);
    }
    
    class TestTree extends TreeWritable<StringWritable, TestTree> {
        
        public TestTree(String name) {
            nodeValue.set(name);
        }
        
        public TestTree(String name, TestTree parent) {
            super(parent);
            nodeValue.set(name);
        }

        @Override
        protected void clearNodeValue() {
            nodeValue.clear();
        }

        @Override
        protected StringWritable newNodeValue() {
            return new StringWritable();
        }

        @Override
        protected TestTree newTreeNode() {
            return new TestTree("");
        }
        
    }
    
    private TestTree createTree() {
        TestTree root = new TestTree("root");
        new TestTree("child1", root);
        TestTree child2 = new TestTree("child2", root);
        new TestTree("child3", root);
        new TestTree("child2child", child2);
        
        return root;
    }
    
    private TestTree createAnotherTree() {
        TestTree root = new TestTree("root");
        new TestTree("child1", root);
        new TestTree("child2", root);
        new TestTree("child3", root);
        
        return root;
    }
    
    private TestTree create3rdTree() {
        TestTree root = new TestTree("root");
        new TestTree("child1", root);
        TestTree child2 = new TestTree("child2", root);
        new TestTree("child3", root);
        new TestTree("child2child_different", child2);
        
        return root;
    }
    
    private TestTree create4thTree() {
        TestTree root = new TestTree("root");
        TestTree child1 = new TestTree("child1", root);
        new TestTree("child2", root);
        new TestTree("child1child", child1);
        return root;
    }
    
    @Test
    public void test() throws IOException {
        // test 0 : toString
        TestTree root = createTree();
        
        System.out.println("=================== test 0 : toString ====================");
        System.out.println(root);
        Assert.assertEquals(3, root.getChildNumber());
        Assert.assertEquals("(root){(child1)(child2){(child2child)}(child3)}", root.toString());
        
        // test 1 : equals
        System.out.println("\n=================== test 1 : equals ====================");
        TestTree rootRepeat = createTree();
        System.out.println(rootRepeat);
        Assert.assertEquals(3, rootRepeat.getChildNumber());
        Assert.assertTrue(root.equals(rootRepeat));
        
        TestTree anotherRoot = createAnotherTree();
        System.out.println(anotherRoot);
        Assert.assertEquals(3, anotherRoot.getChildNumber());
        Assert.assertFalse(root.equals(anotherRoot));
        
        TestTree the3rdRoot = create3rdTree();
        System.out.println(the3rdRoot);
        Assert.assertEquals(3, the3rdRoot.getChildNumber());
        Assert.assertFalse(root.equals(the3rdRoot));
        
        TestTree the4thRoot = create4thTree();
        System.out.println(the4thRoot);
        Assert.assertEquals(2, the4thRoot.getChildNumber());
        Assert.assertFalse(root.equals(the4thRoot));
        
        // test 2 : copy
        System.out.println("\n=================== test 2 : copy ====================");
        TestTree rootCopy = (TestTree)root.copy();
        System.out.println(root);
        Assert.assertEquals(3, rootCopy.getChildNumber());
        Assert.assertTrue(rootCopy.equals(rootRepeat));

        // test 3 : copyFields
        System.out.println("\n=================== test 3 : copyFields ====================");
        TestTree rootCopyFields = new TestTree("");
        rootCopyFields.copyFields(root);
        System.out.println(rootCopyFields);
        Assert.assertTrue(rootCopyFields.equals(root));
        
        // test 4 : writeFields and readFields
        System.out.println("\n=================== test 4 : writeFields/readFields ====================");
        DataOutputBuffer output = new DataOutputBuffer();
        root.writeFields(output);
        
        DataInputBuffer input = new DataInputBuffer(output);
        TestTree rootReadFields = new TestTree("");
        rootReadFields.readFields(input);
        System.out.println(rootReadFields);
        Assert.assertTrue(rootReadFields.equals(root));
        
        // test 5 : detach
        System.out.println("\n=================== test 5 : detach ====================");
        TestTree child1 = (TestTree)root.firstChild();
        child1.detach();
        System.out.println(root);
        System.out.println(child1);
        Assert.assertEquals(2, root.getChildNumber());
        Assert.assertEquals(0, child1.getChildNumber());
        Assert.assertEquals(null, child1.parent());
        Assert.assertEquals("child1", child1.getNodeValue().get());
        
        // test 6 : clear
        System.out.println("\n=================== test 6 : clear ====================");
        TestTree child2 = (TestTree)root.firstChild();
        child2.clear();
        System.out.println(root);
        System.out.println(child2);
        Assert.assertEquals(1, root.getChildNumber());
        Assert.assertEquals(0, child2.getChildNumber());
        Assert.assertEquals(null, child2.parent());
        Assert.assertEquals("", child2.getNodeValue().get());
        
        // test 7 : addChild
        System.out.println("\n=================== test 7 : addChild ====================");
        TestTree child4Added = new TestTree("child4Added");
        anotherRoot.addChild(child4Added);
        System.out.println(anotherRoot);
        Assert.assertEquals(4, anotherRoot.getChildNumber());
        
        child1 = (TestTree)anotherRoot.firstChild();
        child2 = (TestTree)child1.nextSibling();
        TestTree child2child = new TestTree("child2childAdded");
        child2.addChild(child2child);
        System.out.println(anotherRoot);
        Assert.assertEquals(4, anotherRoot.getChildNumber());
        Assert.assertEquals(1, child2.getChildNumber());
        
        // test 7 : removeChild
        System.out.println("\n=================== test 8 : removeChild ====================");
        TestTree child3 = (TestTree)child2.nextSibling();
        boolean succ = anotherRoot.removeChild(child3);
        System.out.println(anotherRoot);
        Assert.assertTrue(succ);
        Assert.assertEquals(3, anotherRoot.getChildNumber());
        Assert.assertEquals(null, child3.parent());
        Assert.assertEquals(null, child3.nextSibling());
        
        succ = anotherRoot.removeChild(child1);
        System.out.println(anotherRoot);
        Assert.assertTrue(succ);
        Assert.assertEquals(2, anotherRoot.getChildNumber());
        Assert.assertEquals(null, child1.parent());
        Assert.assertEquals(null, child1.nextSibling());
        
        succ = anotherRoot.removeChild(child4Added);
        System.out.println(anotherRoot);
        Assert.assertTrue(succ);
        Assert.assertEquals(1, anotherRoot.getChildNumber());
        Assert.assertEquals(null, child4Added.parent());
        Assert.assertEquals(null, child4Added.nextSibling());
        
        succ = anotherRoot.removeChild(child4Added);
        System.out.println(anotherRoot);
        Assert.assertFalse(succ);
        Assert.assertEquals(1, anotherRoot.getChildNumber());

        succ = anotherRoot.removeChild(child2);
        System.out.println(anotherRoot);
        Assert.assertTrue(succ);
        Assert.assertEquals(0, anotherRoot.getChildNumber());
        Assert.assertEquals(null, child2.parent());
        Assert.assertEquals(null, child2.nextSibling());
    }

}
