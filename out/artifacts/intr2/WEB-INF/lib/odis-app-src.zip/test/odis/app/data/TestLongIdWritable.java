/**
 * @(#)TestLongIdWritable.java, 2007-8-8. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.data;

import junit.framework.TestCase;
import odis.serialize.lib.UTF8Writable;

/**
 *
 * @author river
 *
 */
public class TestLongIdWritable extends TestCase {

    public void test() throws Exception {
        LongIdWritable id = new LongIdWritable();
        id.setMd5Value("http://www.tsinghua.edu.cn/");
        assertEquals("md5()", id, LongIdWritable.md5(new UTF8Writable("http://www.tsinghua.edu.cn/")));
    }
    
}
