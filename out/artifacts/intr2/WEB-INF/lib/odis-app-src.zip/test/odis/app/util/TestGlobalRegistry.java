/**
 * @(#)TestGlobalRegistry.java, 2007-6-29. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.util;

import odis.io.Path;
import odis.tools.TestCaseOdis;

import org.apache.commons.configuration.HierarchicalConfiguration;

/**
 * @author river
 *
 */
public class TestGlobalRegistry extends TestCaseOdis {
    private Path registryPath;
    
    public void basic() throws Exception {
        GlobalRegistry registry = new GlobalRegistry(fs, registryPath);
        registry.setProperty("test", "testvalue");
        registry = new GlobalRegistry(fs, registryPath);
        assertEquals("basic set/get failed", "testvalue", registry.getString("test", null));
        
    }
    
    public void round(int r) throws Exception {
        GlobalRegistry registry = new GlobalRegistry(fs, registryPath);
        registry.lock();
        try {
            for (int i=0; i<10; i++) {
                registry.get().setProperty("rounds.r" + r + ".value_" + i+".v1", i);
                registry.get().setProperty("rounds.r" + r + ".value_" + i+".v2", i*2);
            }
            registry.save();
        } finally {
            registry.release();
        }
        
        registry.setProperty("rounds.current", r);
    }
    
    public void checkRound(int r) throws Exception {
        GlobalRegistry registry = new GlobalRegistry(fs, registryPath);
        assertEquals("rounds.current", r, registry.getInt("rounds.current", -1));
        HierarchicalConfiguration config = registry.get().configurationAt("rounds.r" + r);
        for (int i=0; i<10; i++) {
            assertEquals("" + i, i, config.getInt("value_" + i + ".v1", -1));
        }
    }
    
    public void deleteRound(int r) throws Exception {
        GlobalRegistry registry = new GlobalRegistry(fs, registryPath);
        registry.clearSubTree("rounds.r" + r);
    }
    
    public void test() throws Exception {
        registryPath = this.context.path("test");
        
        basic();
        
        round(0);
        checkRound(0);
        
        round(1);
        checkRound(1);
        
        deleteRound(0);
        GlobalRegistry registry = new GlobalRegistry(fs, registryPath);
        assertEquals("delete failed", -1, registry.getInt("rounds.r0.value_0.v1", -1));
        
        System.out.println("=== Whole registry ===");
        System.out.println(registry.format());
        
        System.out.println("=== Subtree ===");
        System.out.println(registry.format("rounds.r1"));
        
    }
    
}
