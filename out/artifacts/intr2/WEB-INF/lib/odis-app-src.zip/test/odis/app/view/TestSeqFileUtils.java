/**
 * @(#)TestSeqFileUtils.java, 2007-8-8. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.view;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import odis.file.CompressUtils.CompressAlgo;
import odis.io.Path;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.tools.TestCaseOdis;

/**
 *
 * @author river
 *
 */
public class TestSeqFileUtils extends TestCaseOdis {

    private void mapEquals(Map map1, Map map2) throws Exception {
        assertEquals("size not equal", map1.size(), map2.size());
        for (Object key : map1.keySet()) {
            Object value1 = map1.get(key);
            Object value2 = map2.get(key);
            assertEquals("value of the key " + key, value1, value2);
        }
    }
    
    private void fillMap(Map<IntWritable, LongWritable> map, Random rand) {
        fillMap(map, rand, rand.nextInt(5000));
    }
    
    private void fillMap(Map<IntWritable, LongWritable> map, Random rand,
            int size) {
        map.clear();
        for (int i=0; i < size; i++) {
            int k = rand.nextInt();
            map.put(new IntWritable(k), new LongWritable(k*2));
        }
    }
    
    public void test() throws Exception {
        Map<IntWritable, LongWritable> map = 
            new HashMap<IntWritable, LongWritable>();     
        Random rand = new Random();
        
        // single seq file test
        fillMap(map, rand);
        Path singleFile = context.path("single_seq");
        SeqFileUtils.saveMapToFile(fs, singleFile, map);
        Map map1 = SeqFileUtils.loadToMap(fs, singleFile);
        mapEquals(map, map1);
        
        // single indexed file test
        fillMap(map, rand);
        Path indexedFile = context.path("single_indexed");
        SeqFileUtils.saveMapToFile(fs, indexedFile, map, true);
        map1 = SeqFileUtils.loadToMap(fs, indexedFile);
        mapEquals(map, map1);
        
        // seq db test
        fillMap(map, rand);
        Path seqDbFile = context.path("db_seq");
        SeqFileUtils.saveMapToDatabase(fs, seqDbFile, 3, 
                new SeqFileHashPartitioner(), map, false);
        map1 = SeqFileUtils.loadToMap(fs, seqDbFile);
        mapEquals(map, map1);

        // indexed db test
        // XXX should check output is IndexedFile format
        fillMap(map, rand);
        Path indexedDbFile = context.path("db_indexed");
        SeqFileUtils.saveMapToDatabase(fs, indexedDbFile, 3, 
                new SeqFileHashPartitioner(), map, true);
        map1 = SeqFileUtils.loadToMap(fs, indexedDbFile);
        mapEquals(map, map1);
        
        // compressed sequence file
        fillMap(map, rand);
        Path seqCompressDbFile = context.path("db_seq_compress");
        SeqFileUtils.saveMapToDatabase(fs, seqCompressDbFile, 3, 
                new SeqFileHashPartitioner(), map, false, 
                10*1024*1024, false, CompressAlgo.LZO);
        map1 = SeqFileUtils.loadToMap(fs, seqCompressDbFile);
        mapEquals(map, map1);
        
        // indexed compressed sequence file
        fillMap(map, rand);
        Path seqIndexedCompressDbFile = context.path("db_seq_indexed_compress");
        SeqFileUtils.saveMapToDatabase(fs, seqIndexedCompressDbFile, 3, 
                new SeqFileHashPartitioner(), map, true, 
                10*1024*1024, false, CompressAlgo.LZO);
        map1 = SeqFileUtils.loadToMap(fs, seqIndexedCompressDbFile);
        mapEquals(map, map1);
        
        // normal file with 1 record, but multi part
        fillMap(map, rand, 1);
        Path db_small = context.path("db_small");
        SeqFileUtils.saveMapToDatabase(fs, db_small, 2, 
                new SeqFileHashPartitioner(), map);
        map1 = SeqFileUtils.loadToMap(fs, db_small);
        mapEquals(map, map1);
    }
    
}
