/**
 * @(#)TestBeanWritableHelper.java, 2008-2-13. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.serialize;

import java.util.Arrays;

import junit.framework.TestCase;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;

/**
 *
 * @author river
 *
 */
public class TestBeanWritableHelper extends TestCase {
    
    public static class A {
        private int i1, i2;
        
        public int getI1() { return i1; }
        public void setI1(int value) { i1 = value; }
        public int getI2() { return i2; }
        public void setI2(int value) { i2 = value; }
        
        private boolean b1;
        public boolean getB1() { return b1; }
        public void setB1(boolean value) { b1 = value; }
        
        private char c1;
        public char getC1() { return c1; }
        public void setC1(char value) { c1 = value; }
        
        private short s1;
        public short getS1() { return s1; }
        public void setS1(short value) { s1 = value; }
        
        private long l1;
        public long getL1() { return l1; }
        public void setL1(long value) { l1 = value; }

        private double d1;
        public double getD1() { return d1; }
        public void setD1(double value) { d1 = value; }
        
        private float f1;
        public float getF1() { return f1; }
        public void setF1(float value) { f1 = value; }
        
        private final UTF8Writable utf8 = new UTF8Writable();
        public UTF8Writable getUtf8() { return utf8; }
        public void setUtf8(String s) { utf8.set(s); }
        
        public int i3;
        public final StringWritable str1 = new StringWritable();
    }
    
    private static class W extends AbstractBeanWritable {
        public int i;
        public int j;
    }
    
    private static class B {
        public final W a = new W();
    }
    
    private void checkEquals(A a1, A a2) {
        assertEquals(a1.i1, a2.i1);
        assertEquals(a1.i2, a2.i2);
        
        assertEquals(a1.b1, a2.b1);
        
        assertEquals(a1.c1, a2.c1);
        
        assertEquals(a1.s1, a2.s1);
        
        assertEquals(a1.l1, a2.l1);
        
        assertEquals(a1.d1, a2.d1);
        
        assertEquals(a1.f1, a2.f1);
        
        assertEquals(a1.utf8, a2.utf8);
        
        assertEquals(a1.i3, a2.i3);
        
        assertEquals(a1.str1, a2.str1);
    }
    
    public void test() throws Exception {
        BeanWritableHelper helper = BeanWritableHelper.getHelperForClass(A.class);
        
        A a1 = new A();
        a1.setI1(1); a1.setI2(2);
        a1.setB1(true);
        a1.setC1('a');
        a1.setS1((short)1023);
        a1.setL1(Long.MAX_VALUE-3);
        a1.setD1(Double.MAX_VALUE-1024);
        a1.setF1(Float.MAX_VALUE-1024);
        a1.setUtf8("this is a test");
        a1.i3 = Integer.MAX_VALUE-1;
        a1.str1.set("test again");
        
        A a2 = new A();
        DataOutputBuffer obuf = new DataOutputBuffer();
        helper.marshal(a1, obuf);
        
        DataInputBuffer ibuf = new DataInputBuffer(obuf);
        helper.unmarshal(a2, ibuf);
        
        checkEquals(a1, a2);
        
        A a3 = new A();
        helper.copyFields(a1, a3);
        checkEquals(a1, a3);
    }
    
    public void testPropertyAccess() throws Exception {
        
        BeanWritableHelper aHelper = BeanWritableHelper.getHelperForClass(A.class);
        BeanWritableHelper bHelper = BeanWritableHelper.getHelperForClass(B.class);
        
        String [] aFields = aHelper.getPropertyNames();
        assertTrue(Arrays.deepEquals(aFields, 
                new String[]{"b1", "c1", "d1", "f1", "i1", "i2", "i3", "l1", "s1", "str1", "utf8"}));
        A a = new A();
        aHelper.setProperty(a, "i2", 245);
        assertEquals(245, a.i2);
        aHelper.setProperty(a, "utf8", "string");
        assertEquals("string", a.utf8.toString());
        
        B b = new B();
        assertTrue(Arrays.deepEquals(bHelper.getPropertyNames(), new String[]{"a"}));
        bHelper.setProperty(b, "a.i", 3);
        bHelper.setProperty(b, "a.j", 4);
        assertEquals(3, b.a.i);
        assertEquals(3, bHelper.getProperty(b, "a.i"));
        assertEquals(4, b.a.j);
        assertEquals(4, bHelper.getProperty(b, "a.j"));
    }
    
    public static class T1 {
        public int i;
        private float f;
        private final StringWritable s = new StringWritable();
        
        public float getF() { return f; }
        public void setF(float v) { f = v; }
        public StringWritable getS() { return s; }
    }

    public static class T2 {
        private int i;
        private float f;
        public final StringWritable s = new StringWritable();
        public final StringWritable s1 = new StringWritable();
        
        public int getI() { return i; }
        public void setI(int v) { i = v; }
        public float getF() { return f; }
        public void setF(float v) { f = v; }
    }
    public void testCopyFieldsByName() throws Exception {
        T1 t1 = new T1();
        t1.i = 1023;
        t1.f = 0.4f;
        t1.s.set("test");
        
        T2 t2 = new T2();
        BeanWritableHelper.copyFieldsByName(t1, t2);
        
        assertEquals(t1.i, t2.i);
        assertEquals(t1.f, t2.f);
        assertEquals(t1.s, t2.s);
    }
    
}
