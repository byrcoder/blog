package odis.app.util;

import junit.framework.JUnit4TestAdapter;
import odis.app.util.TopNQueue;
import odis.serialize.lib.IntWritable;

import org.junit.Assert;
import org.junit.Test;

import toolbox.misc.IObjectGenerator;

public class TestTopNQueue {
    // for Ant compatibility
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(TestTopNQueue.class);
    }

    @Test
    public void basic() throws Throwable {
        int[] inputs = {1, 2, 3, 4, 5, 7, 0, 4, 4};
        
        TopNQueue<IntWritable> topN = new TopNQueue<IntWritable>(2, new IObjectGenerator<IntWritable>() {
            public IntWritable newInstance() {
                return new IntWritable();
            }
        });
        IntWritable iw = new IntWritable();
        for (int i: inputs) {
            iw.set(i);
            topN.addValue(iw);
        } // for i
        
        Assert.assertEquals(2, topN.size());
        IntWritable[] a = topN.toReverseArray(new IntWritable[0]);
        Assert.assertEquals(2, a.length);
        Assert.assertEquals(7, a[0].get());
        Assert.assertEquals(5, a[1].get());
    }
}
