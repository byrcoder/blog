/**
 * @(#)TestSegments.java, 2007-7-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.view;

import odis.io.Path;
import odis.tools.TestCaseOdis;

/**
 * The testcase for odis.app.viewSegments.
 *  
 * @author river, David (david@rd.netease.com)
 *
 */
public class TestSegments extends TestCaseOdis {

    public static final String TAG_A = "tag_a";
    public static final String TAG_B = "tag_b";
    
    public void test() throws Exception {
        Path segmentPath = context.path("segments");
        Segments segments = new Segments(fs, segmentPath);
        
        // test empty
        assertTrue("exists?", !segments.exists());
        assertTrue("getLastSegment()", segments.getLastSegment() == -1);
        
        // test create/delete
        segments.createNewSegment();
        segments.createNewSegment();
        segments.createNewSegment();
        segments.createNewSegment();
        int [] segs = segments.getSegments();
        assertEquals("segments.length", 4, segs.length);
        for (int i=0; i<4; i++) {
            assertEquals("seg", i, segs[i]);
        }
        segments.deleteSegment(2);
        segs = segments.getSegments();
        assertEquals("segments.length", 3, segs.length);
        assertEquals("segs[0]", 0, segs[0]);
        assertEquals("segs[1]", 1, segs[1]);
        assertEquals("segs[2]", 3, segs[2]);
        assertEquals("getLastSegment()", 3, segments.getLastSegment());
        
        // test mark
        segments.mark(0, new String[]{TAG_A, TAG_B});
        segments.mark(1, new String[]{TAG_A});
        segments.mark(3, new String[]{TAG_B});
        assertTrue("tas_in_0", segments.match(0, new String[]{TAG_A, TAG_B}, 
                new String[0]));
        assertTrue("tas_in_0", segments.match(0, new String[]{TAG_A, TAG_B}, 
                null));
        assertTrue("tas_in_1", !segments.match(1, new String[]{TAG_A, TAG_B}, 
                new String[0]));
        assertTrue("tas_in_1", !segments.match(1, new String[]{TAG_A, TAG_B}, 
                null));
        assertTrue("tas_in_3", segments.match(3, new String[]{TAG_B}, 
                new String[]{TAG_A}));
        
        segments.unmark(3, new String[]{TAG_A, TAG_B});
        assertTrue("tas_in_3", !segments.match(3, new String[]{TAG_B}, 
                new String[]{TAG_A}));
        
        segs = segments.findSegments(new String[]{TAG_A}, new String[]{TAG_B});
        assertEquals("find_tags", 1, segs.length);
        assertEquals("find_tags", 1, segs[0]);
    }
    
}
