package odis.app.data;

import junit.framework.TestCase;
import odis.io.DataOutputBuffer;
import odis.serialize.comparator.WritableComparator;

public class TestDocID extends TestCase {

    public void checkGreater(DocID id1, DocID id2) throws Exception {
        WritableComparator comparator = WritableComparator.get(DocID.class);
        
        DataOutputBuffer out1 = new DataOutputBuffer();
        id1.writeFields(out1);
        
        DataOutputBuffer out2 = new DataOutputBuffer();
        id2.writeFields(out2);
        
        assertTrue(id1.compareTo(id2) > 0);
        assertTrue(comparator.compare(out1.getData(), 0, out1.size(), out2.getData(), 0, out2.size()) > 0);
    }
    
    public void testCompare() throws Exception {
        DocID id1 = DocID.parseDocID("7FFFFD4C3750A4AA");
        DocID id2 = DocID.parseDocID("80001BAD437975AA");
        
        checkGreater(id1, id2);
        
        System.out.println("id1=" + id1.get() + ", id2=" + id2.get());
        
        checkGreater(DocID.parseDocID("800006D72C885F00"), DocID.parseDocID("8000016D9E632300"));
    }
    
}
