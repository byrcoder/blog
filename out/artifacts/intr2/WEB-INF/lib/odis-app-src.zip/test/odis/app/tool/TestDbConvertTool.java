/**
 * @(#)TestDbConvertTool.java, 2007-6-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.tool;

import java.util.HashMap;
import java.util.Map;

import odis.app.tool.DbConvertTool.IConverter;
import odis.app.view.SeqFileUtils;
import odis.cowork.CoWorkUtils;
import odis.io.Path;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.tools.ToolTest;

/**
 *
 * @author river
 *
 */
public class TestDbConvertTool extends ToolTest {

    public static class Converter implements IConverter<IntWritable, IntWritable, LongWritable> {

        public boolean convert(IntWritable k1, IntWritable v1, LongWritable v2) {
            if ((k1.get() % 5) == 0) {
                return false;
            }
            v2.set(v1.get() * 3);
            return true;
        }

        public Class getDstValClass() {
            return LongWritable.class;
        }

        public Class getKeyClass() {
            return IntWritable.class;
        }

        public Class getSrcValClass() {
            return IntWritable.class;
        }
        
    }
    
    private Path testPath;
    Map<IntWritable, IntWritable> sourceMap = new HashMap<IntWritable, IntWritable>();
    
    @Override
    public void createInput() throws Exception {
        
        for (int i=0; i<100; i++) {
            sourceMap.put(new IntWritable(i), new IntWritable(i * 2));
        }
    
        testPath = ctx.context().path("test");
        SeqFileUtils.saveMapToFile(ctx.fs(), testPath.cat(CoWorkUtils.getPartID(0)), 
                sourceMap);
    }

    @Override
    public void execute() throws Exception {
        runTool(DbConvertTool.class, 
                ("-converter " + Converter.class.getName() 
                        + " -d " + testPath.getAbsolutePath()).split("\\s+"));
    }

    @Override
    public void checkOutput() throws Exception {
        Map map = SeqFileUtils.loadToMap(ctx.fs(), 
                testPath.cat(CoWorkUtils.getPartID(0)));
        for (int i=0; i<100; i++) {
            if (i % 5 != 0) {
                IntWritable key = new IntWritable(i);
                LongWritable value = new LongWritable(i * 6);
                LongWritable v = (LongWritable)map.remove(key);
                assertTrue("data lost", v != null);
                assertEquals("bad value", value, v);
            }
        }
        assertTrue("redudant data", map.isEmpty());
    }

    
}
