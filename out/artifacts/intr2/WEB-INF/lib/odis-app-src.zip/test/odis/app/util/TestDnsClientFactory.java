/**
 * @(#)TestDnsClientFactory.java, 2008-11-12. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.app.util;

import java.io.StringReader;
import java.net.InetAddress;
import java.util.ArrayList;

import odis.tools.TestCaseOdis;

import org.apache.commons.configuration.XMLConfiguration;

import toolbox.misc.net.DnsClient;
import toolbox.text.util.StringUtils;

/**
 *
 * @author river
 *
 */
public class TestDnsClientFactory extends TestCaseOdis {

    public void test() throws Exception {
        
        DnsClient defaultClient = DnsClientFactory.getDnsClient();
        InetAddress [] addrs = defaultClient.query("www.163.com");
        assertTrue(addrs.length > 0);

        ArrayList<String> servers = new ArrayList<String>(); 
        DnsClient.loadSystemSetting(servers);
        String serverString = StringUtils.arrayToString(
                servers.toArray(new String[servers.size()]), ",");
        
        String configString = "<conf>" + 
        "\t<commons>\n" +
        "\t<dns>\n" + 
        "\t\t<servers>" + serverString + "</servers>\n"+
        "\t\t<initial_timeout>8</initial_timeout>\n" +
        "\t\t<retries>2</retries>\n" +
        "\t</dns>\n" +
        "\t</commons>\n" +
        "</conf>";
        
        XMLConfiguration conf = new XMLConfiguration();
        conf.load(new StringReader(configString));
        
        DnsClient client = DnsClientFactory.createDnsClient(conf, false);
        addrs = client.query("www.163.com");
        assertTrue(addrs.length > 0);
        
    }
    
}
