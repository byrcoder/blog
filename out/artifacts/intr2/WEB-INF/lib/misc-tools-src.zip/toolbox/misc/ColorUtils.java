package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Utilities to meter the difference between two colors.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class ColorUtils {

    public static int toRGBInt(int r, int g, int b) {
        return ((r & 0x0ff) << 16) | ((g & 0x0ff) << 8) | (b & 0x0ff);
    }

    /**
     * Normalize rgb.
     * 
     * @see http://www.easyrgb.com/math.php?MATH=M2#text2
     * @param value
     * @param rgb
     */
    private static void rgb(int value, double[] rgb) {
        rgb[0] = ((value >> 16) & 0x0ff) / 255.0;
        rgb[1] = ((value >> 8) & 0x0ff) / 255.0;
        rgb[2] = (value & 0x0ff) / 255.0;
        for (int i = 0; i < 3; i++) {
            if (rgb[i] > 0.04045)
                rgb[i] = Math.pow((rgb[i] + 0.055) / 1.055, 2.4);
            else
                rgb[i] = rgb[i] / 12.92;
            rgb[i] *= 100;
        }

    }

    public static void xyz(double[] rgb, double[] xyz) {
        xyz[0] = rgb[0] * 0.4124 + rgb[1] * 0.3576 + rgb[2] * 0.1805;
        xyz[1] = rgb[0] * 0.2125 + rgb[1] * 0.7152 + rgb[2] * 0.0722;
        xyz[2] = rgb[0] * 0.0193 + rgb[1] * 0.1192 + rgb[2] * 0.9505;
    }

    /**
     * @see http://www.easyrgb.com/math.php?MATH=M7#text7
     * @param xyz
     * @param lab
     */
    private static void cielab(double[] xyz, double[] lab) {
        xyz[0] = xyz[0] / 95.047;
        xyz[1] = xyz[1] / 100;
        xyz[2] = xyz[2] / 108.883;

        for (int i = 0; i < 3; i++) {
            if (xyz[i] > 0.008856)
                xyz[i] = Math.pow(xyz[i], 1.0 / 3);
            else
                xyz[i] = (7.787 * xyz[i]) + 16.0 / 116;
        }

        lab[0] = 116 * xyz[1] - 16;
        lab[1] = 500 * (xyz[0] - xyz[1]);
        lab[2] = 200 * (xyz[1] - xyz[2]);
    }

    public static void cielab(int c, double[] lab) {
        rgb(c, lab);
        double[] xyz = new double[3];
        xyz(lab, xyz);
        cielab(xyz, lab);
    }

    /**
     * get E-distance in CIELAB color space.
     * 
     * @param v1
     * @param v2
     * @return E-distance in CIELAB color space.
     */
    public static double cielabDistance(int v1, int v2) {
        if (v1 == v2)
            return 0;

        double[] rgb1 = new double[3];
        double[] rgb2 = new double[3];
        double[] xyz1 = new double[3];
        double[] xyz2 = new double[3];
        double[] lab1 = new double[3];
        double[] lab2 = new double[3];

        rgb(v1, rgb1);
        xyz(rgb1, xyz1);
        cielab(xyz1, lab1);

        rgb(v2, rgb2);
        xyz(rgb2, xyz2);
        cielab(xyz2, lab2);

        return (Math.sqrt(Math.pow(lab1[0] - lab2[0], 2)
                + Math.pow(lab1[1] - lab2[1], 2)
                + Math.pow(lab1[2] - lab2[2], 2)));
    }

    public static void main(String[] args) throws Exception {
        // int v1 = 0x1d76ec;
        // int v2 = 0xFFCC00;

        System.out.println(cielabDistance(0xEFEBEF, 0x0));
        System.out.println(cielabDistance(0xffffff, 0x0));
        System.out.println(cielabDistance(0x0F0CBF, 0xFFFFFF));
        System.out.println(cielabDistance(0xFF0000, 0xffffff));
    }

}
