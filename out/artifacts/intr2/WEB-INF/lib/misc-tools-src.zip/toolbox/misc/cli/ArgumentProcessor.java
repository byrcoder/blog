package toolbox.misc.cli;

import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A class that processes arguments. Usage: <code>
 *   ArgumentProcessor ap = new ArgumentProcessor(...);
 *   ap.addOption(...);
 *   
 *   String res = ap.process(args);
 *   if (res != null) {
 *       ap.printHelpInfo(System.out, "cmd", 100);
 *       throw new RuntimeException(res);
 *   } // if 
 * 
 *   if (ap.isOptSet(...))
 *      vl = ap.getStringOpt(...);
 *      
 *   int intVl = ap.getIntOpt(...);
 *   </code>
 * 
 * @author David
 */
@SuppressWarnings("serial")
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class ArgumentProcessor extends ArrayList<String> {
    private TreeMap<String, Integer> optNames = new TreeMap<String, Integer>();
    private HashMap<String, String[]> opts = new HashMap<String, String[]>();
    private HashMap<String, String> defaults = new HashMap<String, String>();
    private HashMap<String, String> optComments = 
        new HashMap<String, String>();
    private HashMap<String, String> optArgs = 
        new HashMap<String, String>();
    private HashMap<String, String> optProps = 
        new HashMap<String, String>();
    private ArrayList<String> params = new ArrayList<String>();
    private ArrayList<String> paramComments = new ArrayList<String>();

    /**
     * Creates an argment processor with specified options.
     * 
     * @param optNames The options. 
     *   The order is: 
     *       <opt1> [num-of-values] [DEF:<default-value>|{"vl1", "vl2"}] 
     *              [ARG:name-of-the-sub-args] [COMMMENT:<the-comments>]
     *              [SHARED:]
     *       <opt2> ...
     *       [PARAM:param-0] [COMMMENT:<the-comments>] 
     *   If num-of-values is not specified, it is set to 0. 
     *   If num-of-values equals 1, you can use DEF:<default-value>, e.g. DEF:0, 
     *   to set its default value. if num-of-values is non-zero, you can use a 
     *   string[] value to set the default value of this option. Default value 
     *   can be omitted.
     *   "ARG:" is used to set the name of the sub-arguments for the current 
     *          option. It will change the default sub-arguments (e.g. <arg-0>,
     *          <arg-1>, et.) Use ";" as the separator when more than one values
     *          are used.
     *   "PARAM:" is used to give help info for remaining argument. If the last
     *            PARAM is ..., it is handled in a special way.
     *   "SHARED:" If this is specified, this option will not be listed in the
     *             usage info. All comments of shared options will be listed 
     *             at the last and seprated from normal options.
     *   Some examples: 
     *      new ArgumentProcessor("p"); 
     *      new ArgumentProcessor("p", 1, "DEF:3", "ARG:num", 
     *                  "COMMENT:the printer number"); 
     *      new ArgumentProcessor("pair", 2, new String[] {"left", "right"});
     *      new ArgumentProcessor("p", 1, "t", 3, "PARAM:param);
     */
    public ArgumentProcessor(Object... optNames) {
        addArguments(optNames);
    }

    /**
     * Appends new arguments.
     * 
     * @param optNames The options. 
     *   The order is: 
     *       <opt1> [num-of-values] [DEF:<default-value>|{"vl1", "vl2"}] 
     *              [ARG:name-of-the-sub-args] [COMMMENT:<the-comments>]
     *       <opt2> ...
     *       [PARAM:param-0] [COMMMENT:<the-comments>] 
     *   If num-of-values is not specified, it is set to 0. 
     *   If num-of-values equals 1, you can use DEF:<default-value>, e.g. DEF:0, 
     *   to set its default value. if num-of-values is non-zero, you can use a 
     *   string[] value to set the default value of this option. Default value 
     *   can be omitted.
     *   "ARG:" is used to set the name of the sub-arguments for the current 
     *          option. It will change the default sub-arguments (e.g. <arg-0>,
     *          <arg-1>, et.) Use ";" as the separator when more than one values
     *          are used.
     *   "PARAM:" is used to give help info for remaining argument. If the last
     *            PARAM is ..., it is handled in a special way.
     *   Some examples: 
     *      new ArgumentProcessor("p"); 
     *      new ArgumentProcessor("p", 1, "DEF:3", "ARG:num", 
     *                  "COMMENT:the printer number"); 
     *      new ArgumentProcessor("pair", 2, new String[] {"left", "right"});
     *      new ArgumentProcessor("p", 1, "t", 3, "PARAM:param);
     */
    public ArgumentProcessor addArguments(Object... optNames) {
        int idx = 0;
        while (idx < optNames.length) {
            // opt-name
            String opt = optNames[idx ++].toString();
            if (opt.startsWith("PARAM:")) {
                params.add(opt.substring("PARAM:".length()));
                String cmm = "";
                if (idx < optNames.length) {
                    if (optNames[idx].toString().startsWith("COMMENT:")) {
                        cmm = optNames[idx ++].toString().substring(
                                "COMMENT:".length());
                    } // if
                } // if
                paramComments.add(cmm);
                continue;
            } // if
            int num = 0;
            if (idx < optNames.length && optNames[idx].toString().matches(
                    "[0-9]+"))
                // number of arguments
                num = Integer.valueOf(optNames[idx ++].toString());
            this.optNames.put(opt, num);
            if (idx < optNames.length) {
                if (num == 1 && optNames[idx].toString().startsWith("DEF:")) {
                    String def = optNames[idx ++].toString().substring(
                            "DEF:".length());
                    if (def.length() > 0)
                        opts.put(opt, new String[] {def});
                    else
                        opts.put(opt, new String[0]);
                    defaults.put(opt, def);
                } else if (num > 0 && optNames[idx] instanceof String[]) {
                    String[] def = (String[]) optNames[idx ++];
                    opts.put(opt, def);
                    String s = "";
                    for (String item: def) {
                        if (s.length() > 0)
                            s = s + " ";
                        s = s + item;
                    } // for item
                    defaults.put(opt, s);
                } // else if
            } // if 
            if (idx < optNames.length 
                    && optNames[idx].toString().startsWith("ARG:")) {
                // sub-argument names
                optArgs.put(opt, 
                        optNames[idx].toString().substring("ARG:".length()));
                idx ++;
            } // if
            optComments.put(opt, "");
            if (idx < optNames.length) {
                if (optNames[idx].toString().startsWith("COMMENT:")) {
                    optComments.put(opt, optNames[idx ++].toString().substring(
                            "COMMENT:".length()));
                } // if
            } // if
            
            if (idx < optNames.length && optNames[idx].toString().equals(
                    "SHARED:")) {
                idx ++;
                optProps.put(opt, "shared:");
            } // if
        } // for i
        
        return this;
    }
    /**
     * Adds an option.
     * 
     * @param opt  the name of the option
     * @param comment  the comment to this option
     */
    public void addOption(String opt, String comment) {
        addOption(opt, 0, comment);
    }
    /**
     * Adds an option.
     * 
     * @param opt  the name of the option
     * @param subArg  the number of sub-arguments for this option
     * @param comment  the comment to this option
     */
    public void addOption(String opt, int subArg, String comment) {
        optNames.put(opt, subArg);
        optComments.put(opt, comment); 
    }
    /**
     * Adds an option.
     * 
     * @param opt  the name of the option
     * @param subArg  the number of sub-arguments for this option
     * @param comment  the comment to this option
     * @param def  the default value for this options.
     */
    public void addOption(String opt, int subArg, String comment, Object... def) {
        addOption(opt, subArg, comment);

        if (def.length != subArg) {
            throw new RuntimeException("We need " + subArg + " default values"
                    + ", but " + def.length + " values set!");

        } // if
        if (subArg > 0) {
            String[] defStr = new String[subArg];
            String s = "";
            for (int i = 0; i < defStr.length; i++) {
                defStr[i] = def[i].toString();
                if (s.length() > 0)
                    s = s + " ";
                s = s + defStr[i];
            } // for i
            opts.put(opt, defStr);
            defaults.put(opt, s);
        } // if
    }
    /**
     * Adds the comment of a parameter. Parameters are those strings following
     * the options.
     * 
     * @param name  the name the parameter
     * @param comment  the comments to this parameter
     */
    public void addParam(String name, String comment) {
        params.add(name);
        paramComments.add(comment);
    }
    /**
     * Gets the options set.
     * @param name  the name of the options to be extracted
     * @return  the options as a string list
     */
    public String[] getOpt(String name) {
        return opts.get(name);
    }
    /**
     * Gets the options set.
     * NOTE: using default value in this way may affluent the help-info, so 
     *       call this method when you have to 
     * 
     * @param name  the name of the options to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the options as a string list
     */
    public String[] getOpt(String name, String[] def) {
        return isOptSet(name) ? opts.get(name) : def;
    }
    /**
     * Gets the single string option.
     * @param name  the name of the option to be extracted
     * @return  the extracted option value as a string
     */
    public String getStringOpt(String name) {
        return getOpt(name)[0];
    }
    /**
     * Gets the single string option.
     * @param name  the name of the option to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the extracted option value as a string
     */
    public String getStringOpt(String name, String def) {
        return isOptSet(name) ? getOpt(name)[0] : def;
    }
    /**
     * Gets the single File option.
     * @param name  the name of the option to be extracted
     * @return  the extracted option value as a File
     */
    public File getFileOpt(String name) {
        return new File(getOpt(name)[0]);
    }
    /**
     * Gets the single File option.
     * NOTE: using default value in this way may affluent the help-info, so 
     *       call this method when you have to 
     * @param name  the name of the option to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the extracted option value as a File
     */
    public File getFileOpt(String name, File def) {
        return isOptSet(name) ? new File(getOpt(name)[0]) : def;
    }
    /**
     * Gets the single integer option.
     * @param name  the name of the option to be extracted
     * @return  the extracted option value as an integer
     */
    public int getIntOpt(String name) {
        return Integer.parseInt(getOpt(name)[0]);
    }
    /**
     * Gets the single integer option.
     * NOTE: using default value in this way may affluent the help-info, so 
     *       call this method when you have to 
     * @param name  the name of the option to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the extracted option value as an integer
     */
    public int getIntOpt(String name, int def) {
        return isOptSet(name) ? Integer.parseInt(getOpt(name)[0]) : def;
    }
    /**
     * Gets the single long option
     * @param name  the name of the option to be extracted
     * @return  the extracted option value as a long
     */
    public long getLongOpt(String name) {
        return Long.parseLong(getOpt(name)[0]);
    }
    /**
     * Gets the single long option
     * NOTE: using default value in this way may affluent the help-info, so 
     *       call this method when you have to 
     * @param name  the name of the option to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the extracted option value as a long
     */
    public long getLongOpt(String name, long def) {
        return isOptSet(name) ? Long.parseLong(getOpt(name)[0]) : def;
    }
    /**
     * Gets the single float option
     * @param name  the name of the option to be extracted
     * @return  the extracted option value as a long
     */
    public float getFloatOpt(String name) {
        return Float.parseFloat(getOpt(name)[0]);
    }
    /**
     * Gets the single float option
     * NOTE: using default value in this way may affluent the help-info, so 
     *       call this method when you have to 
     * @param name  the name of the option to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the extracted option value as a long
     */
    public float getFloatOpt(String name, long def) {
        return isOptSet(name) ? Float.parseFloat(getOpt(name)[0]) : def;
    }
    /**
     * Gets the single double option
     * @param name  the name of the option to be extracted
     * @return  the extracted option value as a long
     */
    public double getDoubleOpt(String name) {
        return Double.parseDouble(getOpt(name)[0]);
    }
    /**
     * Gets the single double option
     * NOTE: using default value in this way may affluent the help-info, so 
     *       call this method when you have to 
     * @param name  the name of the option to be extracted
     * @param def  the default value, returned when this option is not set
     * @return  the extracted option value as a long
     */
    public double getDoubleOpt(String name, double def) {
        return isOptSet(name) ? Double.parseDouble(getOpt(name)[0]) 
                : def;
    }
    /**
     * Check whether an option is set.
     * @param name  the name of the option to be checed
     * @return  true, if the specified option is set; false, otherwise
     */
    public boolean isOptSet(String name) {
        return opts.containsKey(name) && 
            (optNames.get(name) == 0 || opts.get(name).length > 0);
    }
    
    public boolean isOptSet(String... names) {
        for (String name: names) {
            if (!isOptSet(name))
                return false;
        } // for name
        
        return true;
    }

    /**
     * Process the arguments from the beginning of args.
     * @param args
     * @return
     */
    public String process(String [] args) {
        return process(args, 0);
    }
    
    /**
     * Process the arguments, and the remained params is stored in this container.
     * 
     * @param args  argument strings
     * @param from  the index of first argument to process
     * @return  null, if no error happens; An error string is returned if some 
     *          error found.
     */
    public String process(String[] args, int from) {
        int idx = from;
        while (idx < args.length && args[idx].startsWith("-")) {
            String opt = args[idx++].substring(1);
            Integer num = optNames.get(opt);
            if (num == null)
                return "Unknown option " + opt;

            if (num + idx > args.length)
                return num + " parameters needed for option " + opt;

            String[] vls = new String[num];
            System.arraycopy(args, idx, vls, 0, num);

            opts.put(opt, vls);

            idx += num;
        } // while
        clear();
        while (idx < args.length)
            this.add(args[idx++]);

        return null;
    }
    /**
     * Layout a string given the size on each line and wrap methods
     * 
     * @param text  the string to layout
     * @param size  the wrap size of each line
     * @param wrap  one of "left", "right", or "ends"
     * @return  a list of string in each line
     */
    public static ArrayList<String> layout(String text, int size, String wrap) {
        ArrayList<String> res = new ArrayList<String>();
        if (text == null)
            text = "";
        String[] lines = text.split("\n");
        for (String srcLine : lines) {
            String[] words = srcLine.split(" +");
            int idx = 0;
            while (idx < words.length) {
                int len = words[idx].length();
                int idx_1 = idx + 1;
                while (idx_1 < words.length
                        && len + words[idx_1].length() + 1 <= size) {
                    len += words[idx_1].length() + 1;
                    idx_1++;
                } // while

                int remLen = size - len;
                if (remLen < 0)
                    remLen = 0;
                String line;
                if ("right".equals(wrap)) {
                    line = words[idx];
                    for (int i = idx + 1; i < idx_1; i++)
                        line += " " + words[i];
                    if (remLen > 0)
                        line = String.format("%" + remLen + "s", "") + line;
                } else if ("ends".equals(wrap) && idx_1 < words.length) {
                    line = words[idx];
                    int num_words = idx_1 - idx;
                    for (int i = idx + 1; i < idx_1; i++) {
                        int blank = 1 + remLen/(num_words - 1) + ((i - idx - 1) 
                                < (remLen % (num_words - 1)) ? 1 : 0);
                        line += String.format("%" + blank + "s", "")
                                + words[i];
                    } // for i
                } else {
                    // default is left
                    line = words[idx];
                    for (int i = idx + 1; i < idx_1; i++)
                        line += " " + words[i];
                    if (remLen > 0)
                        line += String.format("%" + remLen + "s", "");
                } // else
                res.add(line);

                idx = idx_1;
            } // while
        } // for srcLine
        return res;
    }

    /**
     * Print the help infomation. 
     * e.g. for arguments:
     *   "a", "COMMENT:comment for a", "b", 1, "COMMENT:comment for b",
     *   "PARAM:input-file", "COMMENT:The input file" 
     *   
     *   Usage:
     *      cmd  [-a] -b <arg0> <input-file>
     *   Options:
     *      -a   comment for a
     *      -b   comment for b
     *   Parameters:
     *      input-file   The input file.  
     *      
     * @param out  the output PrintStream
     * @param cmd  the name of the command
     * @param maxWidth  the maximum width
     */
    public void printHelpInfo(PrintStream out, String cmd, int maxWidth) {
        PrintWriter pw = new PrintWriter(out, true);
        printHelpInfo(pw, cmd, maxWidth);
        pw.flush();
    }
    
    private void printNameInfos(PrintWriter out, String[] names, String[] infos, 
            int maxWidth, String indent, int gap, int optLen) {
        for (int i = 0; i < infos.length; i ++) {
            ArrayList<String> lines = layout(infos[i], 
                    maxWidth - indent.length() - optLen - gap, "left");
            for (int j = 0; j < lines.size(); j ++) {
                out.print(indent);
                if (j == 0) {
                    if (names[i].length() <= optLen) {
                        out.format("%-" + optLen + "s", names[i]);
                    } else {
                        out.println(names[i]);
                        out.format("%s%" + optLen + "s", indent, "");
                    } // else
                } else {
                    out.format("%" + optLen + "s", "");
                } // else
                out.format("%" + gap + "s", "");
                out.println(lines.get(j));
            } // for j
        } // for i
    }
    /**
     * Prints the help infomation. 
     * e.g. for arguments:
     *   "a", "COMMENT:comment for a", "b", 1, "COMMENT:comment for b",
     *   "PARAM:input-file", "COMMENT:The input file" 
     *   
     *   Usage:
     *      cmd  [-a] -b <arg0> <input-file>
     *   Options:
     *      -a   comment for a
     *      -b   comment for b
     *   Parameters:
     *      input-file   The input file.  
     *      
     * @param out  the output PrintWriter
     * @param cmd  the name of the command
     * @param maxWidth  the maximum width
     */
    public void printHelpInfo(PrintWriter out, String cmd, int maxWidth) {
        /*
         * Print usage infomation.
         */
        out.println("Usage: ");
        out.print("   " + cmd + " ");
        int leading = ("   " + cmd + " ").length();
        
        int cntOpts = 0;
        int pos = leading;
        String line;
        int sharedOpts = 0;
        for (String opt: optNames.keySet()) {
            if (optProps.containsKey(opt) 
                    && optProps.get(opt).contains("shared:")) {
                sharedOpts ++;
                continue;
            } // if
            cntOpts ++;
            int cnt = optNames.get(opt);
            line = "";
            boolean hasDefault = cnt == 0 || defaults.containsKey(opt);
            if (hasDefault)
                line = line + "[";
            
            line = line + "-" + opt;
            
            String subArgsStr = optArgs.get(opt);
            String[] subArgs = subArgsStr == null ? null : 
                subArgsStr.split(";"); 
            for (int i = 0; i < cnt; i ++) {
                if (subArgs != null && i < subArgs.length)
                    line = line + " <" + subArgs[i] + ">";
                else
                    line = line + " <arg" + i + ">";
            } // for i
            
            if (hasDefault)
                line = line + "]";
            
            if (pos == leading) {
                out.print(line);
                pos += line.length();
            } else if (pos + 1 + line.length() > maxWidth) {
                out.println();
                out.format("%" + leading + "s", "");
                out.print(line);
                pos = line.length();
            } else {
                out.print(" " + line);
                pos += 1 + line.length();
            } // else
        } // for opt
        
        for (int i = 0; i < params.size(); i ++) {
            if (i == params.size() - 1 && "...".equals(params.get(i)))
                line = "...";
            else
                line = "<" + params.get(i) + ">";
            if (pos == leading) {
                out.print(line);
                pos += line.length();
            } else if (pos + 1 + line.length() > maxWidth) {
                out.println();
                out.format("%" + leading + "s", "");
                out.print(line);
                pos = line.length();
            } else {
                out.print(" " + line);
                pos += 1 + line.length();
            } // else
        } // for i
        
        out.println();
        out.println("Options:");
        /*
         * Print comments for each option.
         */
        String[] names = new String[cntOpts];
        String[] infos = new String[cntOpts];
        int idx = 0;
        int optLen = 0;
        for (String opt: optNames.keySet()) {
            if (optProps.containsKey(opt) 
                    && optProps.get(opt).contains("shared:"))
                continue;
            names[idx] = "-" + opt;
            infos[idx] = "";
            if (optComments.containsKey(opt)) {
                infos[idx] = optComments.get(opt).trim();
                if (infos[idx].length() > 0) {
                    if (infos[idx].charAt(0) >= 'a' 
                        && infos[idx].charAt(0) <= 'z')
                        infos[idx] = Character.toUpperCase(infos[idx].charAt(0))
                                + infos[idx].substring(1); 
                } // if
                if (infos[idx].length() > 0 && !infos[idx].endsWith("."))
                    infos[idx] = infos[idx] + ".";
            } // if
            if (optNames.get(opt) > 0) {
                if (infos[idx].length() > 0)
                    infos[idx] = infos[idx] + " ";
                infos[idx] = infos[idx] + optNames.get(opt) + " " + 
                    (optNames.get(opt) == 1 ? "argument" : "arguments") + ".";
            } // if
            if (defaults.containsKey(opt)) {
                if (infos[idx].length() > 0)
                    infos[idx] = infos[idx] + " ";
                String defVal = defaults.get(opt);
                if (defVal.length() == 0)
                    infos[idx] = infos[idx] + "OPTIONAL";
                else
                    infos[idx] = infos[idx] + "DEFAULT: " + defVal;
            } // if
            
            if (names[idx].length() > optLen)
                optLen = names[idx].length();
            
            idx ++;
        } // for opt
        
        if (optLen > 20)
            optLen = 20;
        
        if (maxWidth < optLen + 10)
            maxWidth = optLen + 10;
        
        String indent = "   ";
        int gap = 3;
        printNameInfos(out, names, infos, maxWidth, indent, gap, optLen);
        /*
         * Print remaining parameters (if any).
         */
        if (params.size() > 0) {
            out.println("Parameters:");
            cntOpts = params.size();
            if ("...".equals(params.get(params.size() - 1)))
                cntOpts --;
            names = new String[cntOpts];
            infos = new String[cntOpts];
            idx = 0;
            optLen = 0;
            for (int i = 0; i < cntOpts; i ++) {
                names[idx] = params.get(i);
                if (names[idx].length() > optLen)
                    optLen = names[idx].length();
                infos[idx] = paramComments.get(i);
                
                if (infos[idx].length() > 0) {
                    if (infos[idx].charAt(0) >= 'a' 
                        && infos[idx].charAt(0) <= 'z')
                        infos[idx] = Character.toUpperCase(infos[idx].charAt(0))
                                + infos[idx].substring(1); 
                } // if
                if (infos[idx].length() > 0 && !infos[idx].endsWith("."))
                    infos[idx] = infos[idx] + ".";
                
                idx ++;
            } // for opt
            printNameInfos(out, names, infos, maxWidth, indent, gap, optLen);
        } // if
        /*
         * Print shared options
         */
        if (sharedOpts > 0) {
            out.println("Shared options:");
            names = new String[sharedOpts];
            infos = new String[sharedOpts];
            idx = 0;
            optLen = 0;
            for (String opt: optNames.keySet()) {
                if (!optProps.containsKey(opt) 
                        || !optProps.get(opt).contains("shared:"))
                    continue;
                names[idx] = "-" + opt;
                infos[idx] = "";
                if (optComments.containsKey(opt)) {
                    infos[idx] = optComments.get(opt).trim();
                    if (infos[idx].length() > 0) {
                        if (infos[idx].charAt(0) >= 'a' 
                            && infos[idx].charAt(0) <= 'z')
                            infos[idx] = Character.toUpperCase(infos[idx].charAt(0))
                                    + infos[idx].substring(1); 
                    } // if
                    if (infos[idx].length() > 0 && !infos[idx].endsWith("."))
                        infos[idx] = infos[idx] + ".";
                } // if
                if (optNames.get(opt) > 0) {
                    if (infos[idx].length() > 0)
                        infos[idx] = infos[idx] + " ";
                    infos[idx] = infos[idx] + optNames.get(opt) + " " + 
                        (optNames.get(opt) == 1 ? "argument" : "arguments") + ".";
                } // if
                if (defaults.containsKey(opt)) {
                    if (infos[idx].length() > 0)
                        infos[idx] = infos[idx] + " ";
                    String defVal = defaults.get(opt);
                    if (defVal.length() == 0)
                        infos[idx] = infos[idx] + "OPTIONAL";
                    else
                        infos[idx] = infos[idx] + "DEFAULT: " + defVal;
                } // if
                
                if (names[idx].length() > optLen)
                    optLen = names[idx].length();
                
                idx ++;
            } // for opt
            if (maxWidth < optLen + 10)
                maxWidth = optLen + 10;
            
            if (optLen > 20)
                optLen = 20;
            
            printNameInfos(out, names, infos, maxWidth, indent, gap, optLen);
        } // if
    }
}
