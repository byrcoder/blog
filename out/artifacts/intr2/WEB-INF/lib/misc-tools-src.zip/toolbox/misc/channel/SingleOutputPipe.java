package toolbox.misc.channel;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A collectPipe with single thread. Data are collected to a blocking-queue and
 * then a single thread will write them to the collector.
 * 
 * @author David
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class SingleOutputPipe extends OutputPipe {
    ArrayQueue<Object[]> q;

    PipeThread pipeThread;

    boolean running;

    class PipeThread extends Thread {
        IObjectOutput out;

        public PipeThread(IObjectOutput out, int index, boolean isDaemon) {
            super("pipe-thread " + index);
            this.out = out;
            this.setDaemon(isDaemon);
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Object[] objects;
                    synchronized (q) {
                        while (!stopNow && q.isEmpty() && !stopping) {
                            q.wait();
                        } // while
                        if (stopNow || q.isEmpty())
                            break;

                        objects = q.poll();
                        q.notifyAll();
                    } // synchronized

                    out.output(objects);
                } // while
            } catch (InterruptedException e) {
                // simply quit
            } catch (Exception e) {
                exception = e;
                if (onException != null)
                    onException.notify(SingleOutputPipe.this);
                else
                    e.printStackTrace();
            }

            synchronized (q) {
                running = false;
                q.notifyAll();
            }
        }
    }

    public SingleOutputPipe(IObjectOutput out, int bufLen, boolean isDaemon) {
        q = new ArrayQueue<Object[]>(bufLen);
        running = true;
        pipeThread = new PipeThread(out, 0, isDaemon);
        pipeThread.start();

    }

    @Override
    public void join() throws InterruptedException {
        pipeThread.join();
    }

    @Override
    public void stop() throws InterruptedException {
        synchronized (q) {
            this.stopping = true;
            q.notifyAll();
        }
        join();
    }

    @Override
    public void stopNow() throws InterruptedException {
        synchronized (q) {
            this.stopping = true;
            this.stopNow = true;
            q.notifyAll();
        }
        join();
    }

    @Override
    protected void put(Object... objects) throws InterruptedException,
            NoOutputPipeException {
        synchronized (q) {
            while (running && q.isFull()) {
                q.wait();
            } // while

            if (!running)
                throw new NoOutputPipeException();

            q.add(objects);
            q.notifyAll();
        } // synchronized
    }
}
