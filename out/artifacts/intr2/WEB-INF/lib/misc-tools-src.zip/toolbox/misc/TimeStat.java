package toolbox.misc;

import java.util.Date;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Util to calc the time elapse.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class TimeStat {

    private long start;

    public TimeStat() {
        start = System.currentTimeMillis();
    }

    public void reset() {
        start = System.currentTimeMillis();
    }

    public long elapse() {
        return System.currentTimeMillis() - start;
    }

    public long getStartTime() {
        return start;
    }

    public String toString() {
        return "TimeStat: start at " + new Date() + " and " + elapse()
                + "ms elapsed.";
    }

}
