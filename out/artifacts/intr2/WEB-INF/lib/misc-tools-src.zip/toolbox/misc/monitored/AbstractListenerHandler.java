package toolbox.misc.monitored;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 监听者处理器的抽象类，通知所有的监听者有事件发生。
 * 使用WeakReference保存指向Listener的实例引用，因此客户调用addListener()的时候，
 * 传入的值必须在其它地方有强引用，否则就会被GC掉。也就是说，客户不能够如下调用：
 *    handler.addListener(new XxxListener())
 * 
 * @author why
 *
 * @param <L> Listener Interface Type
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public abstract class AbstractListenerHandler<L> {

    protected List<WeakReference<L>> listeners = new LinkedList<WeakReference<L>>();

    /**
     * add a event listener
     * 
     * @param listener
     */
    public synchronized void addListener(L listener) {
        boolean found = false;
        for (Iterator<WeakReference<L>> it = listeners.iterator(); it.hasNext();) {
            WeakReference<L> ref = it.next();
            if (listener == ref.get()) {
                found = true;
                break;
            }
        }

        if (!found) {
            listeners.add(new WeakReference<L>(listener));
        }
    }

    /**
     * remove a listener
     * 
     * @param listener
     */
    public synchronized void removeListener(L listener) {
        for (Iterator<WeakReference<L>> it = listeners.iterator(); it.hasNext();) {
            WeakReference<L> ref = it.next();
            if (listener == ref.get()) {
                it.remove();
                break;
            }
        }
    }

    /**
     * clear all listeners
     */
    public synchronized void clear() {
        listeners.clear();
    }

    /**
     * @return registered listener number
     */
    public synchronized int getListenerCount() {
        return listeners.size();
    }

    /**
     * how to notify one listener some event occurs
     * 
     * @param listener
     * @param args
     */
    protected void notifyListener(L listener, Object... args) {}

    /**
     * notify all listeners some event occurs in a synchronized way
     * 
     * @param args
     */
    protected synchronized final void notifyAllListeners(Object... args) {
        for (Iterator<WeakReference<L>> it = listeners.iterator(); it.hasNext();) {
            WeakReference<L> ref = it.next();
            L listener = ref.get();
            if (listener != null) {
                notifyListener(listener, args);
            } else {
                it.remove();
            }
        }
    }
}
