package toolbox.misc.channel;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A round-robin queue.
 * <p>
 * NOTE: this queue is not thread-safe.
 * 
 * @author david
 * @param <E>
 *            the type of elements
 */
class ArrayQueue<E> extends AbstractQueue<E> {
    private int size = 0;

    private int head;

    private int tail;

    Object[] q;

    /**
     * The constructor.
     * 
     * @param capacity
     *            the maximum number of elements that can be put in this queue
     */
    public ArrayQueue(int capacity) {
        q = new Object[capacity];
        head = 0;
        tail = 0;
    }

    @Override
    public Iterator<E> iterator() {
        if (isEmpty()) {
            return new Iterator<E>() {

                public boolean hasNext() {
                    return false;
                }

                public E next() {
                    throw new NoSuchElementException();
                }

                public void remove() {
                    throw new UnsupportedOperationException();

                }
            };
        } else {
            return new Iterator<E>() {
                int cur = tail;

                public boolean hasNext() {
                    return cur >= 0;
                }

                @SuppressWarnings("unchecked")
                public E next() {
                    if (cur < 0)
                        throw new NoSuchElementException();

                    E res = (E) q[cur];
                    cur++;
                    if (cur == q.length)
                        cur = 0;

                    if (cur == head)
                        cur = -1;

                    return res;
                }

                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        }
    }

    @Override
    public int size() {
        return size;
    }

    public boolean offer(E o) {
        if (size >= q.length)
            return false;

        q[head] = o;
        head++;
        if (head == q.length)
            head = 0;
        size++;

        return true;
    }

    @SuppressWarnings("unchecked")
    public E peek() {
        if (size == 0)
            return null;
        else
            return (E) q[tail];
    }

    @SuppressWarnings("unchecked")
    public E poll() {
        if (size == 0)
            return null;
        E res = (E) q[tail];
        tail++;
        if (tail == q.length)
            tail = 0;
        size--;
        return res;
    }

    /**
     * Returns true if this queue cannot put more elements.
     * 
     * @return true if this queue cannot put more elements.
     */
    public boolean isFull() {
        return size == q.length;
    }
}
