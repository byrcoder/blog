package toolbox.misc;

import java.util.HashMap;
import java.util.HashSet;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Some utilities related to numbers.
 * 
 * @author xxx, david
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class NumberUtils {

    /**
     * convert byte array to an integer
     * 
     * @param bs
     *            the byte array
     * @return the integer
     */
    public static int bytesToInt(byte[] bs) {
        return (((int) bs[0] & 0xFF) << 24) | (((int) bs[1] & 0xFF) << 16)
                | (((int) bs[2] & 0xFF) << 8) | ((int) bs[3] & 0xFF);
    }

    /**
     * convert byte array to a long
     * 
     * @param bs
     *            the byte array
     * @return the long
     */
    public static long byteToLong(byte[] bs) {
        //bs.length > 8?
        long result = 0;
        int len = bs.length;
        if (len > 8) {
            len = 8;
        }
        for (int i = 0; i < len; i++) {
            result |= (bs[i] & 0xffL) << (8 * (7 - i));
        }
        return result;
    }

    /**
     * convert long to byte array
     * 
     * @param var
     * @see #byteToLong(byte[])
     * @return
     */
    public static byte[] longToBytes(long var) {
        byte[] ret = new byte[8];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = (byte) (var >> (8 * (7 - i)));
        }
        return ret;
    }

    /**
     * 判断一个字符串是否是数字.
     * 
     * @param s
     *            the string
     * @return whether it is a digital number
     */
    public static boolean isDecimal(String s) {
        int digitNumber = 0;
        int len = s.length();
        for (int i = 0; i < len; i++) {
            if (Character.isDigit(s.charAt(i)))
                digitNumber++;
        }
        return (digitNumber > 0 && digitNumber == s.length());
    }

    private static final HashMap<String, String> specialPluralMap = new HashMap<String, String>();
    static {
        specialPluralMap.put("child", "children");
        specialPluralMap.put("roof", "roofs");
    };

    /**
     * The set of consonants
     */
    public static final HashSet<Character> consonants = new HashSet<Character>();
    static {
        String str = "bcdfghjklmnpqrstvwxy";
        for (char ch: str.toCharArray())
            consonants.add(ch);
    }

    /**
     * Returns the plural form of a noun
     * 
     * @param noun
     *            the noun
     * @return the plural form
     */
    public static String toPlural(String noun) {
        // TODO more rules
        String plural = specialPluralMap.get(noun);
        if (plural != null)
            return plural;
        if (noun.endsWith("s") || noun.endsWith("x"))
            return noun + "es";
        if (noun.endsWith("y")) {
            if (noun.length() == 1)
                return "y's";
            char ch = noun.charAt(noun.length() - 2);
            if (consonants.contains(ch))
                return noun.substring(0, noun.length() - 1) + "ies";
        } // if
        return noun + "s";
    }

    /**
     * Returns the English for the phrase of a noun with numbers.
     * 
     * @param noun
     *            the name of the object
     * @param num
     *            the number of the objects
     * @return the English for the phrase of a noun with numbers
     */
    public static String numberObject(int num, String noun) {
        if (num == 0)
            return "no " + toPlural(noun);
        if (num <= 1)
            return num + " " + noun;
        return num + " " + toPlural(noun);
    }
}
