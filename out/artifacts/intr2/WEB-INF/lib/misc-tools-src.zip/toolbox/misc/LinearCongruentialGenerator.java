/**
 * @(#)LinearCongruentialGenerator.java, 2012-10-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A liner congruential generator with 2^64 period.
 * <p>
 * The multiplier and increment is copied from Knuth's MMIX random number
 * generator.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class LinearCongruentialGenerator {
    private static final long A = 6364136223846793005L;

    private static final long C = 1442695040888963407L;

    /**
     * generate next value using A * current + C
     * 
     * @param current
     * @return
     */
    public static long nextLong(long current) {
        return A * current + C;
    }
}
