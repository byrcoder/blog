/**
 * @(#)NativeLibLoader.java, 2007-10-23. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.sys;

import java.io.File;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Tool to load native lib for jni. This tool can locate the lib according to
 * the arch of os.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class NativeLibLoader {
    private static final String[] DEFAULT_PROBE_PATHS = {
        "lib", "native", "nativelib"
    };

    private static final String OS = System.getProperty("os.name", "linux");

    private String probeHome;

    private String[] probePaths;

    private static NativeLibLoader DEFAULT_LOADER = new NativeLibLoader();

    /**
     * Return default instance of loader. The probe home of default instance is
     * System.getProperty("native.home"), and probe paths are "lib", "native"
     * and "nativelib".
     * 
     * @return
     */
    public static NativeLibLoader getDefaultLoader() {
        return DEFAULT_LOADER;
    }

    private NativeLibLoader() {
        probeHome = System.getProperty("native.home", ".");
        probePaths = DEFAULT_PROBE_PATHS;
    }

    public NativeLibLoader(String home) {
        probeHome = home;
        probePaths = DEFAULT_PROBE_PATHS;
    }

    public NativeLibLoader(String home, String[] paths) {
        probeHome = home;
        probePaths = paths;
    }

    /**
     * Return the home path where to locate the lib in probe paths.
     * 
     * @return
     */
    public String getProbeHome() {
        return probeHome;
    }

    /**
     * Return the probe paths.
     * 
     * @return
     */
    public String[] getProbePaths() {
        return probePaths;
    }

    /**
     * Load the native lib.
     * 
     * @param name
     */
    public void loadNativeLib(String name) {
        String libName;
        File libFile = null;

        if (OS.toLowerCase().contains("win")) {
            libName = "lib" + name + ".dll";
        } else {
            String arch = System.getProperty("os.arch", "i386");
            libName = "lib" + name + "." + arch + ".so";
        }

        for (String prefix: probePaths) {
            File tmp = new File(probeHome, prefix + "/" + libName);
            if (tmp.exists()) {
                libFile = tmp;
                break;
            }
        }

        if (libFile == null) {
            throw new RuntimeException("cannot find native lib");
        } else {
            try {
                System.load(libFile.getCanonicalPath());
            } catch (Exception e) {
                throw new RuntimeException("cannot load native lib "
                        + libFile.getAbsolutePath());
            }
        }

    }

}
