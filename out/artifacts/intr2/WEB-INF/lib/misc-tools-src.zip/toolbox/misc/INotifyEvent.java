package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * The interface for a notify event.
 * 
 * @author David
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface INotifyEvent<T> {
    /**
     * Notifies the listener the event happens
     * 
     * @param obj
     *            some related object
     */
    public void notify(T obj);
}
