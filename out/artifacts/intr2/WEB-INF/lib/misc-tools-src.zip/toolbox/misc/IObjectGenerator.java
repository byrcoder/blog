package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * The interface for an object generator.
 * 
 * @author David
 * @param <E>
 *            The type of the object generated.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface IObjectGenerator<E> {
    /**
     * Returns a new instance of the object E
     * 
     * @return a new instance of the object E
     */
    public E newInstance();
}
