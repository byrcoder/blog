package toolbox.misc;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A class that reads configuration from an xml file, and write configuration to
 * an xml file.
 * 
 * @author rcai, David (david@rd.netease.com)
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class SimpleConf {
    private String resourceNames;

    private Properties properties;

    private ClassLoader classLoader = SimpleConf.class.getClassLoader();

    /**
     * Constructor.
     * 
     * @param resourceName
     *            The name of the resource containing the configuration.
     */
    public SimpleConf(String resourceName) {
        this.resourceNames = resourceName;
    }

    /**
     * Returns the value of the <code>name</code> property, or null if no such
     * property exists.
     * 
     * @param name
     *            The name of the property.
     * @return The value of the property.
     */
    public String get(String name) {
        return getProps().getProperty(name);
    }

    /**
     * Returns the value of the <code>name</code> property. If no such property
     * exists, then <code>defaultValue</code> is returned.
     * 
     * @param name
     *            The name of the property.
     * @param defaultValue
     *            The default vaule.
     * @return The value of the property.
     */
    public String get(String name, String defaultValue) {
        return getProps().getProperty(name, defaultValue);
    }

    /**
     * Returns the value of the <code>name</code> property as an integer. If no
     * such property is specified, or if the specified value is not a valid
     * integer, then <code>defaultValue</code> is returned.
     * 
     * @param name
     * @param defaultValue
     * @return int value of this property name
     */
    public int getInt(String name, int defaultValue) {
        String valueString = get(name);
        if (valueString == null)
            return defaultValue;
        try {
            return Integer.parseInt(valueString);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Returns the value of the <code>name</code> property as a long. If no such
     * property is specified, or if the specified value is not a valid long,
     * then <code>defaultValue</code> is returned.
     * 
     * @param name
     * @param defaultValue
     * @return long value of this property name
     */
    public long getLong(String name, long defaultValue) {
        String valueString = get(name);
        if (valueString == null)
            return defaultValue;
        try {
            return Long.parseLong(valueString);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Returns the value of the <code>name</code> property as a float. If no
     * such property is specified, or if the specified value is not a valid
     * float, then <code>defaultValue</code> is returned.
     * 
     * @param name
     * @param defaultValue
     * @return float value of this property name
     */
    public float getFloat(String name, float defaultValue) {
        String valueString = get(name);
        if (valueString == null)
            return defaultValue;
        try {
            return Float.parseFloat(valueString);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Returns the value of the <code>name</code> property as an boolean. If no
     * such property is specified, or if the specified value is not a valid
     * boolean, then <code>defaultValue</code> is returned. Valid boolean values
     * are "true" and "false".
     * 
     * @param name
     * @param defaultValue
     * @return boolean value of this property name
     */
    public boolean getBoolean(String name, boolean defaultValue) {
        String valueString = get(name);
        if ("true".equals(valueString))
            return true;
        else if ("false".equals(valueString))
            return false;
        else
            return defaultValue;
    }

    /**
     * Returns the value of the <code>name</code> property as an array of
     * strings. If no such property is specified, then <code>null</code> is
     * returned. Values are whitespace or comma delimted.
     * 
     * @param name
     * @return string values given this property name
     */
    public String[] getStrings(String name, String[] defaultValue) {
        String valueString = get(name);
        if (valueString == null)
            return defaultValue;
        StringTokenizer tokenizer = new StringTokenizer(valueString,
                ", \t\n\r\f");
        ArrayList<String> values = new ArrayList<String>();
        while (tokenizer.hasMoreTokens()) {
            values.add(tokenizer.nextToken());
        }
        return (String[]) values.toArray(new String[values.size()]);
    }

    /**
     * Returns the value of the <code>name</code> property as an array of int.
     * If no such property is specified, then <code>null</code> is returned.
     * Values are whitespace or comma delimted.
     * 
     * @param name
     * @return int values given this property name
     */
    public int[] getInts(String name, int[] defaultValue) {
        String valueString = get(name);
        if (valueString == null)
            return defaultValue;
        StringTokenizer tokenizer = new StringTokenizer(valueString,
                ", \t\n\r\f");
        ArrayList<String> values = new ArrayList<String>();
        while (tokenizer.hasMoreTokens()) {
            values.add(tokenizer.nextToken());
        }
        String[] list = (String[]) values.toArray(new String[values.size()]);
        int[] res = new int[list.length];
        for (int i = 0; i < list.length; i++)
            res[i] = Integer.parseInt(list[i]);
        return res;
    }

    /**
     * Returns the value of the <code>name</code> property as a Class. If no
     * such property is specified, then <code>defaultValue</code> is returned.
     * 
     * @param name
     * @param defaultValue
     * @return class value given this property name
     */
    public Class getClass(String name, Class defaultValue) {
        String valueString = get(name);
        if (valueString == null)
            return defaultValue;
        try {
            return Class.forName(valueString);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Returns the URL for the named resource.
     * 
     * @param name
     * @return url value given this property name
     */
    public URL getResource(String name) {
        return this.classLoader.getResource(name);
    }

    /**
     * @return all properties
     */
    private synchronized Properties getProps() {
        if (this.properties == null) {
            this.properties = new Properties();
            loadResource(this.properties, this.resourceNames);
        } // if
        return this.properties;
    }

    /**
     * @param properties
     * @param name
     * @param quietFail
     */
    private void loadResource(Properties properties, Object name) {
        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = null;

            if (name instanceof String) { // a CLASSPATH resource
                URL url = getResource((String) name);
                if (url != null) {
                    doc = builder.parse(url.toString());
                } // if
            } else if (name instanceof File) { // a file resource
                File file = (File) name;
                if (file.exists()) {
                    doc = builder.parse(file);
                } // if
            } // else if

            if (doc == null) {
                throw new RuntimeException(name + " not found");
            } // if

            Element root = doc.getDocumentElement();
            NodeList props = root.getChildNodes();
            for (int i = 0; i < props.getLength(); i++) {
                Node propNode = props.item(i);
                if (!(propNode instanceof Element))
                    continue;
                Element prop = (Element) propNode;
                NodeList fields = prop.getChildNodes();
                String attr = null;
                String value = null;
                for (int j = 0; j < fields.getLength(); j++) {
                    Node fieldNode = fields.item(j);
                    if (!(fieldNode instanceof Element))
                        continue;
                    Element field = (Element) fieldNode;
                    if ("name".equals(field.getTagName()))
                        attr = ((Text) field.getFirstChild()).getData();
                    if ("value".equals(field.getTagName())
                            && field.hasChildNodes())
                        value = ((Text) field.getFirstChild()).getData();
                } // for i
                if (attr != null && value != null)
                    properties.setProperty(attr, value);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

    }

}
