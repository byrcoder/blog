package toolbox.misc.cli;

import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.TreeMap;
import java.util.TreeSet;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A general tool framework with multi commands supported.
 *
 * Usage:
 *      Inherite this class, and implements necessary abstract
 *      methods. Then add doXxxx methods with "String[] args"
 *      as the only argument. Return value counld be either a
 *      boolean indicating whether success, or void. Throw an
 *      exception when error in the latter situation. 
 *      
 *      An example:
 *      
 *      public class MyAppTool extends AppTool {
 *          public usage(PrintWriter out, String cmd) {
 *              if ("foo".equal(cmd)) {
 *                  out.println("foo help info");
 *              } // if
 *          }
 *          public String getName() {
 *              return "demo";
 *          }
 *          
 *          public doFoo(String[] args) {
 *              ...
 *          }
 *      }
 *
 * @author david
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class AppTool implements ITool {
    /**
     * Output the usage info of a specified comand.
     * 
     * @param out
     *            the PrintWriter where usage info will be printed to
     * @param cmd
     *            the name of the command
     */
    abstract public void usage(PrintWriter out, String cmd);

    /**
     * The name of this tool.
     * 
     * @return the name of this tool
     */
    abstract public String getName();

    protected TreeMap<String, AppTool> mapCmdClass = new TreeMap<String, AppTool>();

    /**
     * Register the sub-tool into this tool.
     * 
     * @param tool
     *            the sub-tool to be registered
     */
    protected void registerTool(Class<? extends AppTool> tool) {
        try {
            AppTool app = tool.newInstance();
            mapCmdClass.put(app.getName().toLowerCase(), app);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public void usage(PrintWriter out) {
        TreeSet<String> commands = new TreeSet<String>();
        Method[] methods = this.getClass().getMethods();
        for (Method m: methods) {
            String name = m.getName();
            if (name.length() > 2 && name.startsWith("do")
                    && name.charAt(2) >= 'A' && name.charAt(2) <= 'Z') {
                if (name.substring(3).equals(name.substring(3).toLowerCase())) {
                    // the method's name is in the form of doXxxxxx();
                    try {
                        this.getClass().getMethod(name, String[].class);
                    } catch (SecurityException e) {
                        // parameter wrong, ignored
                        continue;
                    } catch (NoSuchMethodException e) {
                        // parameter wrong, ignored
                        continue;
                    }
                    name = name.substring(2).toLowerCase();
                    commands.add(name);
                } // if
            }
        } // for m

        commands.addAll(mapCmdClass.keySet());

        System.out.println("  " + getName() + " <command>");
        System.out.println("    Implmeneted commands: " + commands.toString());
        for (String cmd: commands) {
            AppTool app = mapCmdClass.get(cmd);
            if (app == null)
                usage(out, cmd);
            else
                System.out.println("    [" + cmd + "]  " + app.comment());
            System.out.println();
        } // for cmd
    }

    public boolean exec(String[] args) {
        if (args.length < 1) {
            usage(new PrintWriter(System.err, true));
            return false;
        } // if

        String cmd = args[0];
        String[] args_new = new String[args.length - 1];
        System.arraycopy(args, 1, args_new, 0, args_new.length);
        // find in maps
        AppTool app = mapCmdClass.get(cmd.toLowerCase());
        if (app != null)
            return app.exec(args_new);
        // find in methods
        cmd = cmd.substring(0, 1).toUpperCase()
                + cmd.substring(1).toLowerCase();

        try {
            Method m = this.getClass().getMethod("do" + cmd, String[].class);
            try {
                if (m.getReturnType().equals(boolean.class))
                    return (Boolean) m.invoke(this, new Object[] {
                        (Object[]) args_new
                    });
                else {
                    m.invoke(this, new Object[] {
                        (Object[]) args_new
                    });
                    return true;
                } // else
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        } catch (SecurityException e) {
            System.out.println("Unknown command " + cmd);
            usage(new PrintWriter(System.err, true));
            return false;
        } catch (NoSuchMethodException e) {
            System.out.println("Unknown command " + cmd);
            usage(new PrintWriter(System.err, true));
            return false;
        }
    }
}
