package toolbox.misc;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Properties;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Use one string to store properties. we encode the data in BASE64.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class StringProperties {

    /**
     * Decode properties from string.
     * 
     * @param s
     * @return the decoded properties from the String
     */
    public static Properties decode(String s) {
        s = s.replace('_', '\n').replace('@', '\r');
        BASE64Decoder decoder = new BASE64Decoder();
        Properties result = new Properties();
        try {
            byte[] bytes = decoder.decodeBuffer(s);
            ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
            result.load(bis);
        } catch (IOException e) {}
        return result;
    }

    /**
     * Encode properties into string.
     * 
     * @param properties
     * @return the encoded String from properties
     */
    public static String encode(Properties properties) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            properties.store(bos, null);
        } catch (IOException e) {}
        BASE64Encoder encoder = new BASE64Encoder();
        String s = encoder.encode(bos.toByteArray());
        return s.replace('\n', '_').replace('\r', '@');
    }

}
