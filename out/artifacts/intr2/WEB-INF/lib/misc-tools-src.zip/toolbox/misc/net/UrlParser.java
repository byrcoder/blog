/**
 * @(#)UrlParser.java, 2007-7-19. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.net;

import java.net.MalformedURLException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 基于回调的url解析工具，目前仅仅用于处理经过normalizer处理过的url，也就是格式标准的url.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class UrlParser {

    /**
     * Url解析过程中的回调接口.
     * 
     * @author river
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static interface UrlParseHandler {

        /**
         * 解析url中的protocol部分，返回值决定是否继续后续的解析.
         * 
         * @param protocol
         * @return
         */
        public boolean onProtocol(String url, int start, int end);

        /**
         * 解析url中的host.
         * 
         * @param host
         * @return
         */
        public boolean onHost(String url, int start, int end);

        /**
         * 解析url中的port. 返回值决定是否继续后续的解析. 这个方法只有在url 中指定了port的时候才会被调用.
         * 
         * @param port
         * @return
         */
        public boolean onPort(String url, int start, int end);

        /**
         * 路径的开始，代表第一个"/".
         * 
         * @return
         */
        public boolean onRootPath();

        /**
         * 遇到一个路径，url中的"/xxx/"中的"xxx"会被解析为一个路径，第一个"/"被解析 为一个空的路径，实际上是根.
         * 
         * @param dir
         * @return
         */
        public boolean onPathDir(String url, int start, int end);

        /**
         * 遇到一个文件，url中的"/xxx"中的"xxx"会被解析成为一个文件名.
         * 
         * @param file
         * @return
         */
        public boolean onPathFile(String url, int start, int end);

        /**
         * 遇到一个参数.
         * 
         * @param name
         * @param value
         * @return
         */
        public boolean onParam(String url, int nameStart, int nameEnd,
                int valStart, int valEnd);
    }

    /**
     * 空的UrlParseHandler的实现，便于子类继承以后实现需要的函数.
     * 
     * @author river
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class DefaultUrlParseHandler implements UrlParseHandler {
        public boolean onHost(String url, int start, int end) {
            return true;
        }

        public boolean onParam(String url, int nameStart, int nameEnd,
                int valStart, int valEnd) {
            return true;
        }

        public boolean onPathDir(String url, int start, int end) {
            return true;
        }

        public boolean onPathFile(String url, int start, int end) {
            return true;
        }

        public boolean onPort(String url, int start, int end) {
            return true;
        }

        public boolean onProtocol(String url, int start, int end) {
            return true;
        }

        public boolean onRootPath() {
            return true;
        }
    }

    /**
     * 解析url，并且回调handler中对应的函数.
     * 
     * @param url
     * @param handler
     * @throws MalformedURLException
     */
    public static void parse(String url, UrlParseHandler handler)
            throws MalformedURLException {
        int len = url.length();
        int pos = url.indexOf(':');
        if (pos < 0)
            throw new MalformedURLException("cannot find hostname in url "
                    + url);
        if (!handler.onProtocol(url, 0, pos))
            return;

        int slash = url.indexOf('/', pos + 3);
        int comma = url.indexOf(':', pos + 3);
        if (comma > 0 && comma < slash) {
            if (!handler.onHost(url, pos + 3, comma))
                return;
            if (!handler.onPort(url, comma + 1, slash))
                return;
        } else {
            if (!handler.onHost(url, pos + 3, slash))
                return;
        }
        if (!handler.onRootPath())
            return;

        int paramStart = url.indexOf('?', slash);
        int pathEnd = (paramStart > 0) ? paramStart : len;
        slash++;
        int slash1;
        while (slash < len && (slash1 = url.indexOf('/', slash)) > 0
                && slash1 < pathEnd) {
            if (!handler.onPathDir(url, slash, slash1))
                return;
            slash = slash1 + 1;
        }
        if (slash < pathEnd) {
            if (!handler.onPathFile(url, slash, pathEnd))
                return;
        }

        if (paramStart > 0 && (++paramStart) < len) {
            int idx = paramStart;
            int nameStart = idx;
            int nameEnd = idx;
            int valStart = -1;
            while (idx < len) {
                char ch = url.charAt(idx);
                if (ch == '&') {
                    if (valStart < 0) {
                        if (nameStart < idx)
                            if (!handler.onParam(url, nameStart, idx, idx, idx))
                                return;
                    } else {
                        if (!handler.onParam(url, nameStart, nameEnd, valStart,
                                idx))
                            return;
                    }
                    nameStart = idx + 1;
                    valStart = -1;
                } else if (ch == '=') {
                    nameEnd = idx;
                    valStart = idx + 1;
                }
                idx++;
            }
            if (idx == len) {
                if (valStart < 0) {
                    if (nameStart < idx)
                        if (!handler.onParam(url, nameStart, idx, idx, idx))
                            return;
                } else {
                    if (!handler.onParam(url, nameStart, nameEnd, valStart, idx))
                        return;
                }
            }
        }
    }

}
