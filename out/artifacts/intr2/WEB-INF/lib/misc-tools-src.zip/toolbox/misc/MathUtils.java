package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 这个工具类放一些和数学公式有关的东西。
 * 
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Aug 16, 2006
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class MathUtils {

    /**
     * Whether two floats equal
     */
    public static boolean floatEqual(float x, float y) {
        return Math.abs(x - y) < 1.0E-5;
    }

    /**
     * Whether two doubles equal
     */
    public static boolean doubleEqual(double x, double y) {
        return Math.abs(x - y) < 1.0E-5;
    }

    /**
     * 标准差计算
     * <p>
     * 一般来说计算一个数列的标准差的时候需要知道这个数列的每个数。但是这样会 占用很多内存。这个工具的作用在于不需要记录每个数，而是计算一些特征值，
     * 在插入新的数据的时候可以得到新的标准差值。同时顺便可以得到新的平均值。
     * <p>
     * XXX David: Incrementally calculating standard-deviation has faster ways.<br>
     * s = E(X^2) - E^2(X)<br>
     * so incrementally sum up X and X^2, count n, you can finally get s.
     * 
     * @author Feng Jiang (Feng.a.Jiang@gmail.com)
     * @since Aug 16, 2006
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class StandardDeviation {

        protected int n = 0; //number

        protected float s; //标准差

        protected float v; //平均值

        public void add(float x) {
            if (n == 0) { //第一个数
                s = 0;
                v = x;
                n++;
                return;
            }

            float var = n * s * s + n * (x - v) * (x - v) / (n + 1);
            s = (float) Math.sqrt(var / (n + 1));

            float v1 = (n * v + x) / (n + 1);//新的v
            v = v1;
            n++;
        }

        /**
         * @return 数列中数据的个数
         */
        public int getNumberOfData() {
            return n;
        }

        /**
         * @return 这个数列的标准差
         */
        public float getStandardDeviation() {
            return s;
        }

        /**
         * @return 整个数列的平均数
         */
        public float getAverage() {
            return v;
        }

        public int hashCode() {
            return HashUtils.hashCode(n, s, v);
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof StandardDeviation)) {
                return false;
            }
            StandardDeviation that = (StandardDeviation) obj;
            if (this.n == that.n && Math.abs(this.s - that.s) < 1e-5
                    && Math.abs(this.v - that.v) < 1e-5) {
                return true;
            }
            return false;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("count=" + n);
            sb.append(",avg=" + v);
            sb.append(",standard=" + s);
            return sb.toString();

        }

        public void clear() {
            n = 0;
            v = 0;
            s = 0;
        }
    }

}
