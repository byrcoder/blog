/**
 * @(#)ToolExecMain.java, 2008-6-23. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.cli;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Invoker for {@link ITool}. Use the tool name and tool args as arguments to
 * invoke {@link #main(String[])} int this class. The tool name could the full
 * classname or the simple(short) class name.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ToolExecMain {
    private static final Logger LOG = LogFormatter.getLogger(ToolExecMain.class);

    public static void usage() {
        System.out.println("param : tool_name [tool_args]");
    }

    /**
     * Find the tool class by name. Variable <code>name</code> could be the full
     * class name or simple class name.
     * 
     * @param name
     * @return
     * @throws IOException
     */
    private static Class<?> findToolClass(String name) throws IOException {
        Class<?> cls = null;
        try {
            cls = Class.forName(name);
            if (!ITool.class.isAssignableFrom(cls)) {
                System.err.println("error: " + name + " is not ITool");
                return null;
            }
            return cls;
        } catch (Exception e) {}

        String pattern = name;
        List<String> includeList = new ArrayList<String>(1);
        includeList.add(pattern);
        String[] classnames = ClassUtils.findClassesInPackage(".*",
                includeList, new ArrayList<String>(0));

        HashSet<String> nameSet = new HashSet<String>();
        LinkedList<Class<?>> classes = new LinkedList<Class<?>>();
        for (String s: classnames) {
            if (nameSet.contains(s))
                continue;
            nameSet.add(s);

            try {
                Class<?> tmpClass = Class.forName(s);
                if (ITool.class.isAssignableFrom(tmpClass)) {
                    classes.add(tmpClass);
                }
            } catch (Exception e) {}
        }

        if (classes.size() > 1) {
            StringBuilder buf = new StringBuilder();
            for (Class<?> c: classes)
                buf.append(c.getName()).append(",");
            buf.setLength(buf.length() - 1);

            System.err.println("error: please specify the exact class name, "
                    + "it could be one of (" + buf.toString() + ")");
            return null;
        } else if (classes.size() == 0) {
            System.err.println("error: cannot find tool for name " + name + ".");
            return null;
        } else {
            return classes.iterator().next();
        }
    }

    /**
     * Split the args with space and call {@link #invoke(Class, String[])}.
     * 
     * @param toolClass
     * @param args
     * @return
     * @throws Exception
     */
    public static boolean invoke(Class<? extends ITool> toolClass, String args)
            throws Exception {
        return invoke(toolClass, args.split("\\s+"), false);
    }

    /**
     * Invoke the tool with arguments and print the start/end information and
     * time information.
     * 
     * @param toolClass
     * @param args
     * @return
     * @throws Exception
     */
    public static boolean invoke(Class<? extends ITool> toolClass, String[] args)
            throws Exception {
        return invoke(toolClass, args, false);
    }

    /**
     * Invoke the tool with arguments. If <code>silent</code> is false, print
     * the start/end information and time information.
     * 
     * @param toolClass
     * @param args
     * @param silent
     * @return
     * @throws Exception
     */
    public static boolean invoke(Class<? extends ITool> toolClass,
            String[] args, boolean silent) throws Exception {
        ITool tool = (ITool) ClassUtils.newInstance(toolClass);
        if (!silent)
            System.out.println("Execute tool " + toolClass.getCanonicalName()
                    + " with arguments " + Arrays.toString(args));
        long timeStart = System.currentTimeMillis();
        boolean result = tool.exec(args);
        long timeEnd = System.currentTimeMillis();
        if (!result && !silent) {
            System.out.println("Failed: tool " + toolClass.getCanonicalName()
                    + " .");
        }
        if (!silent) {
            System.out.println("Total elapsed time: " + (timeEnd - timeStart)
                    + " ms (" + ((int) (timeEnd - timeStart) / 1000 / 60)
                    + " minutes " + (((timeEnd - timeStart) / 1000) % 60)
                    + " seconds).");
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            usage();
            return;
        }

        String toolName = args[0];
        Class<? extends ITool> toolClass = (Class<? extends ITool>)findToolClass(toolName);
        if (toolClass == null) {
            return;
        }

        args = Arrays.copyOfRange(args, 1, args.length);
        try {
            boolean result = invoke(toolClass, args);
            if (!result) {
                System.exit(2);
            }
        } catch (Throwable e) {
            LOG.log(Level.WARNING,
                    "Error during execute tool " + toolClass.getCanonicalName()
                            + " with arguments " + Arrays.toString(args), e);
            System.exit(3);
        }
    }

}
