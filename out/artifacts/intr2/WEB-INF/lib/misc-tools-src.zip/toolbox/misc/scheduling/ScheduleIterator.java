/**
 * @(#)ScheduleIterator.java, 2007-10-8. Copyright 2007 Yodao, Inc. All rights
 *                            reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                            subject to license terms.
 */
package toolbox.misc.scheduling;

import java.util.Date;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public interface ScheduleIterator {
    Date next();
}
