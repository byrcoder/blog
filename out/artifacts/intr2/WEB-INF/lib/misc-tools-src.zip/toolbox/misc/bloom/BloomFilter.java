/**
 * @(#)WritableBloomFilter.java, 2009-4-20. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.bloom;

import java.util.BitSet;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class BloomFilter {

    protected int nbHash;

    protected int hashType;

    protected int bitSetSize;

    protected HashFunction hash;

    protected BitSet bitSet;

    public BloomFilter() {}

    public BloomFilter(long expectedElements, float errorRate, int hashType) {
        if (expectedElements < 1) {
            throw new IllegalArgumentException("expectedElements="
                    + expectedElements);
        }
        if (errorRate <= 0.0f || errorRate >= 1.0f) {
            throw new IllegalArgumentException();
        }
        int nbHash = (int) Math.round(Math.log(errorRate) / Math.log(0.5d));
        if (nbHash < 1) {
            nbHash = 1;
        }
        this.nbHash = nbHash;
        int bitSetSize = (int) Math.ceil(-nbHash * expectedElements
                / Math.log(1 - Math.pow(errorRate, 1.0d / nbHash)));
        if (bitSetSize < 2) {
            bitSetSize = 2;
        }
        this.bitSetSize = bitSetSize;
        this.hashType = hashType;
        this.hash = new HashFunction(bitSetSize, nbHash, hashType);
        this.bitSet = new BitSet(bitSetSize);
    }

    public BloomFilter(int bitSetSize, int nbHash, int hashType) {
        if (nbHash < 1) {
            throw new IllegalArgumentException();
        }
        if (bitSetSize < 2) {
            throw new IllegalArgumentException();
        }
        this.nbHash = nbHash;
        this.hashType = hashType;
        this.bitSetSize = bitSetSize;
        this.hash = new HashFunction(bitSetSize, nbHash, hashType);
        this.bitSet = new BitSet(bitSetSize);
    }

    public static int expectedBitSetBytes(long expectedElements, float errorRate) {
        int nbHash = (int) Math.round(Math.log(errorRate) / Math.log(0.5d));
        if (nbHash < 1) {
            nbHash = 1;
        }
        int bitSetSize = (int) Math.ceil(-nbHash * expectedElements
                / Math.log(1 - Math.pow(errorRate, 1.0d / nbHash)));
        if (bitSetSize < 2) {
            bitSetSize = 2;
        }
        return (bitSetSize + 7) / 8;
    }

    public static double expectedFalsePositiveProbability(
            long expectedElements, int nbHash, int bitSetSize) {
        return Math.pow(
                (1 - Math.exp(-nbHash * (double) expectedElements
                        / (double) bitSetSize)), nbHash);
    }

    public void add(byte[] b) {
        add(b, b.length);
    }

    public void add(byte[] b, int length) {
        add(b, 0, length);
    }

    public void add(byte[] b, int offset, int length) {
        int[] hashes = hash.hash(b, offset, length);
        for (int h: hashes) {
            bitSet.set(h);
        }
    }

    public boolean contains(byte[] b) {
        return contains(b, b.length);
    }

    public boolean contains(byte[] b, int length) {
        return contains(b, 0, length);
    }

    public boolean contains(byte[] b, int offset, int length) {
        int[] hashs = hash.hash(b, offset, length);
        for (int h: hashs) {
            if (!bitSet.get(h)) {
                return false;
            }
        }
        return true;
    }

    public int getNBytes() {
        return (bitSetSize + 7) / 8;
    }
}
