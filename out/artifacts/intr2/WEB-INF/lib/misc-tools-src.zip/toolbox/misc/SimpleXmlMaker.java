package toolbox.misc;

import java.util.ArrayList;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A helper class that makes xml tree.
 * <p>
 * Usage: <code>
 *   SimpleXmlMaker maker = new SimpleXmlMaker(
 *       new XmlNode("html",
 *           new XmlNode("body",
 *               new XmlNode("a",
 *                   new XmlAttr("src", "http://www.youdao.com/"),
 *                   new TextXmlNode("text", "Something fun!")
 *               )
 *           )
 *       ) 
 *   );
 * </code>
 * 
 * @author david
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class SimpleXmlMaker {
    /**
     * The data-structure for a xml attribute.
     * 
     * @author david
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class XmlAttr {
        ArrayList<String> names = new ArrayList<String>();

        ArrayList<String> vals = new ArrayList<String>();

        /**
         * The constructor.
         * 
         * @param nameValues
         */
        public XmlAttr(Object... nameValues) {
            addValues(nameValues);
        }

        /**
         * Adds values.
         * 
         * @param nameValues
         *            name, value, name, value, ...
         */
        public void addValues(Object... nameValues) {
            for (int i = 0; i < nameValues.length / 2; i++) {
                names.add(nameValues[i * 2].toString());
                vals.add(nameValues[i * 2 + 1].toString());
            } // for i
        }
    }

    /**
     * A node.
     * 
     * @author david
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class XmlNode {
        String name;

        ArrayList<XmlAttr> attrs = new ArrayList<XmlAttr>();

        ArrayList<XmlNode> children = new ArrayList<XmlNode>();

        /**
         * The constructor.
         * 
         * @param name
         *            the name of this node
         * @param attrChildren
         *            the attributes and children of this node
         */
        public XmlNode(String name, Object... attrChildren) {
            this.name = name;
            addChildren(attrChildren);
        }

        /**
         * Adds children
         * 
         * @param attrChildren
         *            the list of attributes (XmlAttr) or children XmlNode.
         */
        public void addChildren(Object... attrChildren) {
            int i = 0;
            while (i < attrChildren.length) {
                if (attrChildren[i] instanceof XmlAttr) {
                    attrs.add((XmlAttr) attrChildren[i]);
                } else if (attrChildren[i] instanceof XmlNode) {
                    children.add((XmlNode) attrChildren[i]);
                } else {
                    String nm = attrChildren[i].toString();
                    String vl = "";
                    if (i < attrChildren.length - 1) {
                        vl = attrChildren[++i].toString();
                    } // if
                    children.add(new TextXmlNode(nm, vl));
                } // else if
                i++;
            } // while
        }

        public String toString() {
            return toString("");
        }

        /**
         * Returns a string representation of the object with specified indent.
         * 
         * @param indent
         *            the indent string
         * @return a string representation
         */
        public String toString(String indent) {
            StringBuilder str = new StringBuilder();
            str.append(indent).append("<").append(name);
            for (XmlAttr attr: attrs) {
                for (int i = 0; i < attr.names.size(); i++) {
                    str.append(attr.names.get(i)).append("=").append(
                            attr.vals.get(i));
                } // for i
            } // for attr
            str.append(">\n");
            for (XmlNode child: children) {
                str.append(child.toString(indent + "  ")).append("\n");
            } // for child
            str.append(indent).append("</").append(name).append(">");
            return str.toString();
        }
    }

    /**
     * The data-structure for a text xml-node.
     * 
     * @author david
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class TextXmlNode extends XmlNode {
        public String text;

        /**
         * Constructor.
         * 
         * @param name
         *            the name of the node
         * @param text
         *            the text content of the node
         */
        public TextXmlNode(String name, String text) {
            super(name);
            this.text = text;
        }

        public String toString(String indent) {
            return indent + "<" + name + ">" + text + "</" + name + ">";
        }
    }

    private XmlNode root;

    /**
     * Constructor.
     * 
     * @param root
     *            the root node
     */
    public SimpleXmlMaker(XmlNode root) {
        this.root = root;
    }

    public String toString() {
        return root.toString();
    }

    /**
     * Converts the xml tree to xml file.
     * 
     * @param encoding
     *            the encoding of the xml file
     * @return the content of the converted xml file
     */
    public String toXml(String encoding) {
        StringBuilder str = new StringBuilder();
        str.append("<?xml version=\"1.0\"");
        if (encoding != null)
            str.append(" encoding=\"" + encoding + "\"");
        str.append("?>\n\n");
        str.append(toString());
        return str.toString();
    }
}
