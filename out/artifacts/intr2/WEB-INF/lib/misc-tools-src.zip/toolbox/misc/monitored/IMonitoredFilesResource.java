/**
 * 
 */
package toolbox.misc.monitored;

import java.io.File;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 受监控的多文件资源提供者
 * 
 * @author why
 * @since 2008-10-14
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface IMonitoredFilesResource {
    /**
     * 注册监听者
     */
    void registerListener(IFileListener listener);

    /**
     * 得到所监控的文件列表
     */
    File[] getFiles();
}
