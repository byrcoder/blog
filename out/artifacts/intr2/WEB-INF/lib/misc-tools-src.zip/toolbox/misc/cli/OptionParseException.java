/**
 * @(#)OptionParseException.java, 2008-4-14. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.cli;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Exception thrown when parse options failed.
 * @author river
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class OptionParseException extends Exception {

    private static final long serialVersionUID = -3194154057059094233L;

    public OptionParseException(String message) {
        super(message);
    }
    
    public OptionParseException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public OptionParseException(Throwable cause) {
        super(cause);
    }
    
}
