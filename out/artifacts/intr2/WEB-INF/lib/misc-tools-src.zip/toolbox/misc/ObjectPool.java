/**
 * @(#)Pool.java, 2007-7-20. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc;

import java.util.ArrayList;
import java.util.Arrays;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A pool for allocating and reusing of objects.
 * <p>
 * ObjectPool is only an interface class. 3 predefined classes can be used:
 * <ul>
 * <li>FixedLengthObjectPool</li>
 * <li>FlexibleObjectPool</li>
 * <li>FlexibleObjectPoolWithFlush</li>
 * </ul>
 * 
 * @author david
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public abstract class ObjectPool<T> {
    /**
     * Allocate an object instance.
     * 
     * @return allocated object instance.
     */
    abstract public T alloc();

    /**
     * Put the object back to the pool for reused in the future.
     * 
     * @param t
     *            the object to be freed.
     * @return whether the object is catched.
     */
    abstract public boolean free(T t);

    /**
     * Release all cached objects.
     */
    abstract public void clear();

    private Class<T> objectClass = null;

    protected T newInstance() {
        if (objectClass != null) {
            // use objectClass to generate new instance if it is not null
            try {
                return objectClass.newInstance();
            } catch (InstantiationException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }

        // newInstance needs to be overriden if objectClass is not assigned.
        throw new RuntimeException(
                "Override WritablePool.newInstance for creation of new instance.");
    }

    protected ObjectPool() {}

    protected ObjectPool(Class<T> cls) {
        objectClass = cls;
    }

    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class FixedLengthObjectPool<T> extends ObjectPool<T> {
        private T[] objects;

        private int rear = 0;

        public FixedLengthObjectPool(int length) {
            this(length, null);
        }

        @SuppressWarnings("unchecked")
        public FixedLengthObjectPool(int length, Class<T> cls) {
            super(cls);
            objects = (T[]) new Object[length];
        }

        @Override
        public T alloc() {
            if (rear > 0) {
                synchronized (objects) {
                    T obj = objects[--rear];
                    objects[rear] = null;
                    return obj;
                } // synchronized objects
            } else
                return newInstance();
        }

        @Override
        public boolean free(T t) {
            synchronized (objects) {
                if (rear < objects.length - 1) {
                    objects[rear++] = t;
                    return true;
                } else
                    return false;
            } // synchronized objects
        }

        @Override
        public void clear() {
            synchronized (objects) {
                rear = 0;
                Arrays.fill(objects, null);
            } // synchronized objects
        }
    }

    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class FlexibleObjectPool<T> extends ObjectPool<T> {
        private ArrayList<T> objects = new ArrayList<T>();

        public FlexibleObjectPool() {}

        public FlexibleObjectPool(Class<T> cls) {
            super(cls);
        }

        @Override
        public T alloc() {
            synchronized (objects) {
                if (objects.size() > 0) {
                    T obj = objects.get(objects.size() - 1);
                    objects.set(objects.size() - 1, null);
                    objects.remove(objects.size() - 1);
                    return obj;
                } else {
                    return newInstance();
                }
            } // synchronized objects
        }

        @Override
        public boolean free(T t) {
            objects.add(t);
            return true;
        }

        @Override
        public void clear() {
            objects.clear();
            objects.trimToSize();
        }

        public int size() {
            return objects.size();
        }
    }

    /**
     * The object pool that can allocate a lot of objects and then reuse them
     * (by flushing) together.
     * <p>
     * Usage: <code>
     *     FlexibleObjectPoolWithFlush pool = new FlexibleObjectPoolWithFlush();
     *     
     *     pool.alloc();
     *     ...
     *     pool.alloc();
     *     
     *     pool.flush;
     *     // objects allocated are now about to be reused
     *     
     *     pool.alloc();
     *     ...
     * </code>
     * 
     * @author david
     * @param <T>
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class FlexibleObjectPoolWithFlush<T> extends ObjectPool<T> {
        private ArrayList<T> objects = new ArrayList<T>();

        private int numAllocated = 0;

        public FlexibleObjectPoolWithFlush() {}

        public FlexibleObjectPoolWithFlush(Class<T> cls) {
            super(cls);
        }

        @Override
        public T alloc() {
            synchronized (objects) {
                if (numAllocated < objects.size())
                    return objects.get(numAllocated++);
                else {
                    T obj = newInstance();
                    objects.add(obj);
                    numAllocated++;
                    return obj;
                } // else
            } // synchronized objects
        }

        @Override
        public boolean free(T t) {
            return false;
        }

        @Override
        public void clear() {
            synchronized (objects) {
                objects.clear();
                objects.trimToSize();
                numAllocated = 0;
            }
        }

        /**
         * Make all allocated objects reusable.
         */
        public void flush() {
            numAllocated = 0;
        }
    }
}
