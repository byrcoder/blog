/**
 * @(#)CookieNames.java, 2007-10-18. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.netease.urs;

/**
 *
 * @author river
 *
 */
public class CookieNames {
    /**
     * Name of in memory cookie.
     */
    public static final String NTES_SESS = "NTES_SESS";
    
    /**
     * Name of persistent cookie.
     */
    public static final String NTES_PASSPORT = "NTES_PASSPORT";
    
}
