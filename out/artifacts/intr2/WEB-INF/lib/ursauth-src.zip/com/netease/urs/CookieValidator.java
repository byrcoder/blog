/**
 * @(#)CookieValidator.java, 2007-10-18. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.netease.urs;

/**
 * Validator for urs cookies.
 * @author river
 */
public class CookieValidator {
    /** 登录用户的Email */
    protected String email = "";      // user email
    protected String cookie = "";    // cookie?
    /** 用户登录时的IP */
    protected String ip = "";        // ip user used to login
    /** 与用户Email"关联"的手机号码， 为""或者具体的手机号码 */
    protected String mobile = "";    // mobile of user
    /** 是否可以自动登录 */
    protected boolean autoLogin = false;
    /** 帐号创建时间(单位为: s) */
    protected long createTime = 0;
    
    protected ntescode validator = new ntescode();

    /**
     * Convert values extracted from cookie from bytes to string.
     */
    protected void extractProperties() {
        // 1. 提取Email
        String id = new String(validator.ssn);
        if (!id.contains("@")) {
            email = id + "@163.com";
        } else {
            email = id;
        }
        
        // 2. 提取Cookie
        if(validator.cookie != null ) {
            cookie =  new String(validator.cookie);
        }
        
        // 3. 提取Ip
        ip = new String(validator.p_uid);
        
        // 4. mobile号码, 如果Email和手机关联，则会有mobile号码; 在163邮箱内的"设置"-"修改密码"处可以关联手机号码和邮箱
        // 通过手机号码登录，并不意味着手机号码和Email是关联的
        if (validator.mobile.length==1 && validator.mobile[0]==(byte)'N') { 
            mobile = "";
        } else { 
            mobile = new String(validator.mobile);
        }
        
        // 5. 自动登录(目前一般为0)
        if (validator.autologin != null && validator.autologin.length > 0) {
            autoLogin = (validator.autologin[0] == 1);
        }
        
        createTime = validator.createTime;
    }
    
    /**
     * Validate the value of in memory cookie.
     * @param cookieValue
     * @param timeval 单位: 秒, 而不是ms
     * @param returnNewCookie
     *     如果为true, 则{@link ntescode#cookie}为一个新的Cookie, 
     *     并且在{@link #extractProperties()}中以{@link CookieValidator#cookie}形式返回; 
     *     新的Cookie和原有Cookie相比较新，过期时间较晚
     * @return
     */
    public boolean validateInMemoryCookie(String cookieValue, long timeval, boolean returnNewCookie) {
        
        int r = validator.validate_cookie(cookieValue.getBytes(), 
                ntescode.NEED_IP_VALIDATE, 
                timeval, 
                returnNewCookie);
        
        if (r < 0) {
            return false;
        } else {
            // 提取属性
            extractProperties();
            return true;
        }
    }
    
    /**
     * Validate the value of persistent cookie.
     * @param cookieValue
     * @param timeval 单位: 秒, 而不是ms
     * @param returnNewCookie
     *     如果为true, 则{@link ntescode#cookie}为一个新的Cookie, 
     *     并且在{@link #extractProperties()}中以{@link CookieValidator#cookie}形式返回; 
     *     新的Cookie和原有Cookie相比较新，过期时间较晚
     * @return
     */
    public boolean validatePersistentCookie(String cookieValue, long timeval, 
            boolean returnNewCookie) {
        
        int r = validator.validate_persistent_cookie(cookieValue.getBytes(), 
                ntescode.NEED_IP_VALIDATE, 
                timeval, returnNewCookie);
        if (r < 0) {
            return false;
        } else {
            extractProperties();
            return true;
        }
    }
    
    /**
     * email
     * @return
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * ?
     * @return
     */
    public String getNewCookie() {
        return cookie;
    }
    
    /**
     * Ip address user used to login.
     * @return
     */
    public String getIp() {
        return ip;
    }
    
    /**
     * Return the mobile of user, if set; or empty string if no mobile for user.
     * @return
     */
    public String getMobile() {
        return mobile;
    }

    public boolean isAutoLogin() {
        return autoLogin;
    }

    public void setAutoLogin(boolean autoLogin) {
        this.autoLogin = autoLogin;
    }

    /** 获取帐号创建时间, 时间单位为 ms */
    public long getCreateTime() {
        return createTime * 1000;
    }    
    
}
