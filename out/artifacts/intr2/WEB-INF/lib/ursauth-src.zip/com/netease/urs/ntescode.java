/**
 * @(#)ntescode.java, 2007-10-17. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.netease.urs;

/**
 * This code is created by urs team.
 * The native lib should be located under the subdir "lib", "native" and "nativelib" 
 * under home of System.getProperty("native.home"). 
 * @author urs team
 * 
 * -History:
 *  -Code Changed at 2010-01-22 to support long email address
 *  -Code Changed at 2010-12-23 to support misc field
 */
public class ntescode {
   static {
        NativeLibLoader.getDefaultLoader().loadNativeLib("com_netease_urs_ntescode");
   }
   /**
    * 见URS Cookie使用说明, 文档为doc/URS Cookie使用说明.doc
    */
   public static final int NEED_IP_VALIDATE = 8;
   
   public byte[] cookie;
   public byte[] ssn;
   public byte[] p_uid;
   public byte[] mobile;
   public byte[] autologin;
   public long createTime = 0L;
   public long cookieCreateTime = 0L;
   public byte[] alias;
   
   // 
   public byte[] misc;


   /** 
    * @param buf NTES_SESS的Cookie对应的byte[], 目前与编码无关(因为全英文)
    * @param p_id 如果为{@link ntescode#NEED_IP_VALIDATE} 表示需要IP校验
    * @param timeval Cookie的有效期，单位为: second
    * @param flag true表示生成新的Cookie, 从而延长了Cookie的有效时间, 新生成的Cookie因该是{@link ntescode#cookie}
    * @return
    */
   public native int validate_cookie(byte[] buf,int p_id,long timeval,boolean flag);
   
   /**
    * 对NTES_PASSPORT的Cookie进行校验
    * @param buf
    *        NTES_PASSPORT的Cookie对应的byte[], 目前与编码无关(因为全英文)
    * @param p_id 
    *        如果为{@link ntescode#NEED_IP_VALIDATE} 表示需要IP校验
    * @param timeval 
    *        Cookie的有效期，单位为: second
    * @param flag 
    *        true表示生成新的Cookie, 从而延长了Cookie的有效时间; 新生成的Cookie因该是{@link ntescode#cookie}
    * @return
    */
   public native int validate_persistent_cookie(byte[] buf,int p_id,long timeval,boolean flag);
   
   @Override
   public String toString(){
       String ret = "[cookie = " + new String(cookie) + "]" 
                    + "[ssn = " + new String(ssn) + "]"
                    + "[ip = " + new String(p_uid) + "]"
                    + "[mobile = " + new String(mobile) + "]" 
                    + "[createTime = " + String.valueOf(createTime) +"]"
                    + "[cookieCreateTime = " + String.valueOf(cookieCreateTime) +"]";
       
       if(autologin != null) {
            ret += "[autologin = " + new String(autologin) + "]"  ;
       }
       if(alias != null) {
            ret += "[alias = " + new String(alias) + "]"  ;
       }
       if ( misc != null ) {
           ret += "[misc = " + new String(misc) + "]"  ;
       }
       return ret;
   }   
}