/**
 * @(#)BenchCookieValidator.java, Nov 29, 2007. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.netease.urs;


/**
 *
 * @author phx
 *
 */
public class BenchCookieValidator {
    private int threadNum;
    private int time;
    private int count;
    private boolean persitent;
    
    public BenchCookieValidator(int threadNum, int time, boolean persitent) {
        this.threadNum = threadNum;
        this.time = time;
        this.persitent = persitent;
    }

    private void run() throws InterruptedException {
        for (int i = 0; i < threadNum; i++) {
            Thread t = new Thread(new BenchRunnable(time, persitent));
            t.start();
            System.out.println("start thread " + i);
        }    
        try {
            Thread.sleep(time+1000);
        } 
        finally {
        }
        System.out.println("run " + count + " times in " + time + " ms");
        System.out.println((count*1000/time) + " per second");
    }

    public class BenchRunnable implements Runnable {
        String cookie;
        private int time;
        private boolean persitent;

        public BenchRunnable(int time, boolean persitent) {
            this.time = time;
            this.persitent = persitent;
            if(this.persitent) {
                cookie = "NNg.OIn8sgBFycqxxWabv9GdAWGSGCuf_2MWmpa4dF88FNEUgF1EKWevA369c9lbp7wE_Otb.dOK_uUiQ.WhHmKVF";    
            }
            
            else {
                cookie = ".RTfJkMCLOElzZohVQQyEAPi8lDj_pCRIIbiXjHUTmMMm8ak6mnaFiDk8L44qwMfs21C5YWy35UHoo.8k5KTZbNVfPw2R8j38";
            }
        }

        public void run() {
            long start = System.currentTimeMillis();
            while (System.currentTimeMillis() - start < time) {
                CookieValidator validator = new CookieValidator();
                if (persitent) {
                    if (!validator.validatePersistentCookie(cookie, 65536*1000, true)) {
                        throw new RuntimeException("validator failed!");
                    }
                } else {
                    if (!validator.validateInMemoryCookie(cookie,
                            Integer.MAX_VALUE, true)) {
                        throw new RuntimeException("validator failed!");
                    }
                }

                cookie = validator.getNewCookie();
                count++;
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        int threadNum = 20;
        int time = 30000;
        BenchCookieValidator bcv = new BenchCookieValidator(threadNum, time, false);
        bcv.run();
    }

}
