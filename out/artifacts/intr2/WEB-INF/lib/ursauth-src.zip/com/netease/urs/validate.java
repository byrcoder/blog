package com.netease.urs;

public class validate {
   public static void main(String[] args) {
      if(args.length < 3){
         System.out.println("Usage: java validate <cookie's value> <0 memory cookie or 1 persistent cookie> <timeout>");
         return;
      }
      byte[] a   = args[0].getBytes();
      int type = Integer.parseInt(args[1]);
      long timeout = Long.parseLong(args[2]);
      com.netease.urs.ntescode n = new com.netease.urs.ntescode();
      
      int ret =-1;
      if ( type == 0 )
      	ret   = n.validate_cookie(a,8,timeout,true);
      else if ( type == 1 )
      	ret   = n.validate_persistent_cookie(a,8,timeout,true);
      if(ret < 0){
         System.out.println("This cookie is invalidated!");
         return;
      }
      System.out.println("ret = "+ret);
      System.out.println("result = " + n );
   }
}