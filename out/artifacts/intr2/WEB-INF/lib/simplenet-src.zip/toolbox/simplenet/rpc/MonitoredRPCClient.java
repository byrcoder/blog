/**
 * @(#)RPCClientMonitor.java, 2008-7-10. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.simplenet.client.CallFuture;
import toolbox.simplenet.client.ICallFutureFactory;
import toolbox.simplenet.commons.IFuture;

/**
 * {@link MonitoredRPCClient} 是 {@link RPCClient}的子类，在 {@link RPCClient}的基础上
 * 增加了对于服务器异常的检测以及自动重连的功能.
 * 
 * 用法基本等同于 {@link RPCClient}，例如如下代码:
 * 
 * <code>
 *         ScheduledExecutorService retryThreadPool = Executors.newScheduledThreadPool(5, 
 *               new NamedThreadFactory("retryThread", true));
 *       
 *       MonitoredRPCClient client = new MonitoredRPCClient(
 *               new InetSocketAddress(InetAddress.getLocalHost(), 6678), 
 *               1, 1000, 1000, 100, retryThreadPool, 1000);
 *       client.open();
 *       client.getProxy(DemoInterface.class).call();
 *       client.close();
 * </code>
 * 
 * 服务器异常检测和重连的控制通过 {@link IRetryPolicy} 接口进行，这个接口接受操作的异常回调，如果其中的
 * {@link IRetryPolicy#onException(Throwable)} 或者 {@link IRetryPolicy#onRpcException(Throwable)}
 * 返回true，当前的连接就会被断开，并且每隔一定的时间间隔对服务进行一次连接检测。服务器连接检测的步骤为:
 * <ul>
 * <li>尝试建立到服务器的网络连接，如果连接失败，检测失败.
 * <li>尝试访问服务器的 {@link IPing} 接口，如果请求抛出exception，检测失败.
 * <li>以上都正常，检测成功，允许发送后续的请求.
 * </ul>
 * 
 * 默认的 {@link IRetryPolicy} 实现会在每次出现timeout或者其他网络错误的时候都断开连接. 我们可以通过
 * 从 {@link #setRetryPolicy(toolbox.simplenet.rpc.MonitoredRPCClient.IRetryPolicy)}接口
 * 传入自己的实现来控制重连的策略，下面给出一个例子实现，在例子实现中，只有当连续出现5次 {@link RPCException}
 * 才会断开连接，开始重连测试.
 * 
 * <code>
 *       client.setRetryPolicy(new IRetryPolicy() {
 *           
 *           private AtomicInteger count = new AtomicInteger(0);
 *           
 *           public boolean onException(Throwable t) {
 *               return false;
 *           }
 *
 *           public boolean onRpcException(Throwable t) {
 *               return count.incrementAndGet() >= 5;
 *           }
 *
 *           public void onSuccess() {
 *               count.set(0);
 *           }
 *
 *           public void reset() {
 *               count.set(0);
 *           }
 *           
 *       });
 *
 * </code>
 * 
 * @see RPCClient
 * @author river
 *
 */
public class MonitoredRPCClient extends RPCClient {
    public static final Logger LOG = LogFormatter.getLogger(MonitoredRPCClient.class);
    
    private static final long DEFAULT_PING_TIMEOUT = 50;
    
    private static final int ST_NOT_OPENED = 0;
    private static final int ST_VALID = 1;
    private static final int ST_INVALID = 2;
    private static final int ST_CLOSED = 0;

    private static Method PING_METHOD;
    static {
        try {
            PING_METHOD = IPing.class.getMethod("monitorPing", new Class[0]);
        } catch(Exception e) {
            throw new RuntimeException("cannot find monitorPing method", e);
        }
    }
    
    private long checkInterval;
    private AtomicInteger state;

    private IRetryPolicy retryPolicy = new DefaultRetryPolicy();
    private ScheduledExecutorService retryThreadPool;

    /**
     * 创建一个 {@link MonitoredRPCClient}的实例，和 {@link RPCClient}的构造函数不同，这里
     * 增加了<code>retryThreadPool</code>和<code>checkInterval</code>参数，前者是提交重连
     * 任务的线程池，而后者是重连的时间间隔.
     * 
     * @param addr
     * @param connectionCount
     * @param connectTimeout
     * @param writeTimeout
     * @param callTimeout
     * @param retryThreadPool
     * @param checkInterval
     */
    public MonitoredRPCClient(InetSocketAddress addr, int connectionCount, 
            long connectTimeout, long writeTimeout, long callTimeout,  
            ScheduledExecutorService retryThreadPool, long checkInterval) {
        super(addr, connectionCount, connectTimeout, writeTimeout, callTimeout);
        this.client.setCallFutureFactory(new ICallFutureFactory() {
            public CallFuture create() {
                return new MonitoredRpcInvokeFuture();
            }
        });
        
        this.retryThreadPool = retryThreadPool;
        this.checkInterval = checkInterval;
        
        // init the state to ST_NOT_OPENED
        state = new AtomicInteger(ST_NOT_OPENED);
        
    }

    /**
     * 设置retry policy.
     * @see IRetryPolicy
     * @param policy
     */
    public void setRetryPolicy(IRetryPolicy policy) {
        this.retryPolicy = policy;
    }
    
    /**
     * 和父类的open方法不同，这里的open()首先尝试打开连接，而当连接失败的时候，并不是直接
     * 抛出exception，而是记录连接的状态为不可用，并且schedule一个定时的重新连接的任务.
     */
    @Override
    public void open() throws RPCException {
        
        // try to open the connection
        if (this.state.get() != ST_NOT_OPENED) {
            throw new RPCException("rpc connection is opened previously");
        }
        
        this.state.set(ST_INVALID);
        try {
            super.open();
            this.state.set(ST_VALID);
            retryPolicy.reset();
        } catch(Throwable e) {
            LOG.log(Level.WARNING, "open the connection failed for " + client.getServerAddress()
                    + ", retry later", e);
            // schedule check task
            retryThreadPool.schedule(new RetryTask(), 
                    checkInterval, TimeUnit.MILLISECONDS);
        }
    }

    /**
     * 关闭连接. 如果这个时候连接不可用，已经schedule了重新连接的任务，我们也尝试终止这个重连的任务，
     * 至少保证这个重连的任务不会在关闭以后重新打开连接.
     */
    public void close() {
        synchronized(state) {
            client.close();
            this.state.set(ST_CLOSED);
        }
    }

    /**
     * 应用程序调用这个方法标记当前的连接不可用，这个方法会依次做如下的操作:
     * <ul>
     * <li>关闭连接
     * <li>标记连接状态为不可用，后续的请求会立即失败
     * <li>schedule一个重连的任务
     * </ul>
     */
    public void invalidateConnection() {
        if (this.state.get() == ST_VALID) {
            synchronized(state) {
                if (this.state.get() == ST_VALID) {
                    this.client.close();
                    state.set(ST_INVALID);
                    
                    // schedule check task
                    retryThreadPool.schedule(new RetryTask(), 
                            checkInterval, TimeUnit.MILLISECONDS);
                }
            }
        }
    }
    
    /**
     * 这个方法在父类的方法的基础上增加了对于连接状态的判断.
     * <strong>如果连接当前不可用，会直接返回null.</strong>
     */
    @Override
    public IFuture invoke(Method method, Object ... args) {
        
        // check the state
        if (this.state.get() != ST_VALID) {
            return null;
        }
        
        return super.invoke(method, args);
    }

    /**
     * 尝试重新建立到服务器的连接，并且判断连接是否可用.
     * 检测服务器是否可用的办法是:
     * <ul>
     * <li>建立到服务器的连接，如果连接建立失败，就立即返回false.
     * <li>向服务器发送一个ping的请求，这要求服务器实现了 {@link IPing#monitorPing()}
     * 方法.
     * </ul>
     */
    protected boolean retryConnection() {
        // try to connect to server
        try {
            client.open();
        } catch(Throwable e) {
            LOG.log(Level.WARNING, "retry connection failed for " + this.client.getServerAddress(), e);
            return false;
        }

        // do ping
        boolean pingSuccess = false;
        try {
            IFuture future = super.invoke(PING_METHOD, new Object[0]);
            try {
                future.get(DEFAULT_PING_TIMEOUT, TimeUnit.MILLISECONDS);
                pingSuccess = true;
            } catch(Throwable t) {
                LOG.log(Level.WARNING, "ping failed for " + this.client.getServerAddress(), t);
            }
        } finally {
            if (!pingSuccess) {
                client.close();
            } else {
                this.state.set(ST_VALID);
                retryPolicy.reset();
            }
        }
        return pingSuccess;
    }

    /**
     * 这是在 {@link RPCInvokeFuture} 基础上包装的 {@link IRPCInvokeFuture}
     * 接口实现，主要用于截获 {@link #join()} 调用，报告请求的状态到 retry policy.
     *
     * @author river
     *
     */
    private class MonitoredRpcInvokeFuture extends RPCInvokeFuture {
        
        public Object get() throws InterruptedException, ExecutionException {
            try {
                Object result = super.get();
                retryPolicy.onSuccess();
                return result;
            } catch(ExecutionException e) {
                Throwable t = e.getCause();
                if ((t instanceof RPCException) && !(t instanceof RPCInvalidStateException)) {
                    if (retryPolicy.onRpcException((RPCException)t)) {
                        invalidateConnection();
                    }
                } else {
                    if (retryPolicy.onException(t)) {
                        invalidateConnection();
                    }
                }
                throw e;
            }
        }

        public Object get(long timeout, TimeUnit unit)
                throws InterruptedException, ExecutionException,
                TimeoutException {
            try {
                Object result = super.get(timeout, unit);
                retryPolicy.onSuccess();
                return result;
            } catch(ExecutionException e) {
                Throwable t = e.getCause();
                if ((t instanceof RPCException) && !(t instanceof RPCInvalidStateException)) {
                    if (retryPolicy.onRpcException((RPCException)t)) {
                        invalidateConnection();
                    }
                } else {
                    if (retryPolicy.onException(t)) {
                        invalidateConnection();
                    }
                }
                throw e;
            } catch(TimeoutException e) {
                if (retryPolicy.onRpcException(new RPCTimeoutException(e))) {
                    invalidateConnection();
                }
                throw e;
            }
        }

    }
    
    /**
     * 重新建立连接的任务.
     *
     * @author river
     *
     */
    private class RetryTask implements Runnable {

        public void run() {
            synchronized(state) {
                
                //check current state, exit if state error
                if (state.get() != ST_INVALID) {
                    return;
                }
                
                try {
                    if (retryConnection()) {
                        return;
                    }
                } catch(Throwable e) {
                    LOG.log(Level.WARNING, "retry failed for " + client.getServerAddress(), e);
                }
                
                // reschedule the retry task if failed
                retryThreadPool.schedule(this, checkInterval, TimeUnit.MILLISECONDS);
            }
        }
        
    }
    
    /**
     * 在请求不被正常执行的时候的retry策略.
     * @author river
     */
    public static interface IRetryPolicy {
       
        /**
         * 重置policy的状态.
         */
        public void reset();
        
        /**
         * 当任意一个请求正常返回的时候，会回调这个方法.
         */
        public void onSuccess();
        
        /**
         * 当任意一个请求抛出了一个属于 {@link RPCException}的exception的时候，这个方法会被回调.
         * 如果这个请求的返回值为true，表示我们必须要断开当前的连接，定时重新尝试建立连接。
         * 对于超时的请求，会被这个方法处理，Exception 为 {@link RPCTimeoutException}。
         * 
         * @param t
         * @return
         */
        public boolean onRpcException(RPCException t);
        
        /**
         * 当任意一个请求抛出非RPCException的exception的时候，会调用这个方法.
         * 如果这个请求的返回值为true，表示我们必须要断开当前的连接，定时重新尝试建立连接.
         * @param t
         * @return
         */
        public boolean onException(Throwable t);
    }

    /**
     * {@link IRetryPolicy} 的默认实现，规则如下:
     * <ul>
     * <li>当发生任意的RPCException的时候，断开连接.</li>
     * <li>忽视其他的所有的exception.</li>
     * </ul>
     * @author river
     *
     */
    public static class DefaultRetryPolicy implements IRetryPolicy {

        public boolean onException(Throwable t) {
            return false;
        }

        public boolean onRpcException(RPCException t) {
            return true;
        }

        public void onSuccess() {
        }

        public void reset() {
        }
        
    }
    
    /**
     * 支持连接状态检测和重连的服务器必须实现这个ping接口.
     * @author river
     *
     */
    public static interface IPing {
        /**
         * 当服务器正常的时候，这个方法应该正常返回；抛出任意的exception都会被认为是服务器异常.
         * @throws RPCException
         */
        public void monitorPing() throws RPCException;
        
    }
    
}
