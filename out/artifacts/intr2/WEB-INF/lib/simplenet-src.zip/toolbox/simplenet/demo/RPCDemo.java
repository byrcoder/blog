/**
 * @(#)RPCDemo.java, 2008-4-6. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo;

import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import toolbox.simplenet.rpc.RPCException;
import toolbox.simplenet.rpc.RPCThreadState;
import toolbox.simplenet.server.Context;
import toolbox.simplenet.server.IContextListener;
import toolbox.simplenet.server.SessionFatalException;

/**
 * RPC例子，其中的方法主要用于测试.
 * @author river
 *
 */
public class RPCDemo {

    public static interface IDemo {
        public int incAndGet(int v) throws RPCException;
        
        public String echo(String s) throws RPCException;
        
        public StringWritable hello(StringWritable name) throws RPCException;

        public StringWritable hello() throws RPCException;
        
        public void timeout() throws RPCException;
        
        public void fatal() throws RPCException;
        
        public IntWritable nil() throws RPCException;

        public void exception() throws RPCException;
    }
    
    public static class DemoImpl implements IDemo, IContextListener {
        public static final int ECHO_IDLE = 200;
        
        private int count = 0;
        private int echoIdle = ECHO_IDLE;

        public void setEchoIdle(int value) {
            this.echoIdle = value;
        }
        
        /**
         * 直接返回参数，但是会等待200ms. 用于基本的测试.
         */
        public String echo(String s) {
            try {
                Thread.sleep(echoIdle);
            } catch(InterruptedException e) {}
            return s;
        }

        /**
         * 这个接口返回"Hello ${name}"，并且记录name在context中，
         * 便于对于context的测试.
         */
        public StringWritable hello(StringWritable name) {
            Context context = RPCThreadState.getContext();
            context.put("name", name.get());
            return new StringWritable("Hello " + name);
        }
     
        /**
         * 从context中读出name并且返回"Hello ${name}".
         */
        public StringWritable hello() {
            Context context = RPCThreadState.getContext();
            String name = (String) context.get("name");
            return new StringWritable("Hello " + name);
        }
        
        /**
         * 计数器，用于基本的测试.
         */
        public int incAndGet(int v) {
            count += v;
            return count;
        }
        
        /**
         * 这个方法调用会导致调用者超时.
         */
        public void timeout() {
            try {
                Thread.sleep(100000);
            } catch(InterruptedException e) {}
        }

        /**
         * 这个方法会导致连接被断开，用于测试客户端是否能够正确处理连接被断开的情况.
         */
        public void fatal() {
            throw new SessionFatalException("fatal error on session");
        }
        
        /**
         * 这个方法会返回一个null的数据，用于判断null的返回值是否被正常处理.
         */
        public IntWritable nil() {
            return null;
        }
        
        public void onContextCreate(Context context) {
        }

        /**
         * 在context释放的时候，会打印"$name is gone"的信息，用于测试
         * context是否是否正常.
         */
        public void onContextDestroy(Context context) {
            String name = (String) context.get("name");
            if (name != null) {
                System.out.println(name + " is gone.");
            }
        }

        /**
         * 在服务器一端抛出exception.
         */
        public void exception() throws RPCException {
            throw new NullPointerException("null exception raised in server side");
        }
        
    }
    
}
