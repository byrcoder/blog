/**
 * @(#)ConnectionGroup.java, 2007-10-15. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.client;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.simplenet.commons.CallException;
import toolbox.simplenet.commons.ConnectionClosedException;
import toolbox.simplenet.commons.IFuture;
import toolbox.simplenet.commons.WritableCache;
import toolbox.simplenet.commons.WritableIdDef;

/**
 * 客户端实现.
 * 一个Client对应于服务器端的一个Context，但可以同时拥有多条连接. 请求按照roundrobin
 * 的方式分配到每个连接上.
 * 
 * 连接本身是复用的，可以在一个连接上同时发出多个请求，一个请求并不需要等待上一个请求返回才能发送.
 * 请求发送的接口是异步的，通过返回一个{@link CallFuture}对象来读取请求的状态和返回值.
 * 
 * @author river
 *
 */
public class Client {
    public static final Logger LOG = LogFormatter.getLogger(Client.class);
    private static final IWritable [] EMPTY_ARGS = new IWritable[0];
    
    public static final long DEFAULT_WRITE_TIMEOUT = 10 * UnitUtils.SECOND;
    public static final long DEFAULT_CONNECT_TIMEOUT = 10 * UnitUtils.SECOND;
    
    private static final long DEFAULT_BIND_TIMEOUT = 5 * UnitUtils.SECOND;
    
    private WritableCache writableCache = new WritableCache();
    private WritableIdDef idDef = new WritableIdDef();
    
    private ArrayList<Connection> connections = new ArrayList<Connection>();
    private int next = 0;

    private InetSocketAddress addr;
    private int connectionCount;
    private long connectTimeout;
    private long writeTimeout;
    
    private AtomicBoolean opened = new AtomicBoolean(false);
    private String ctxKey = null;
    
    private ICallFutureFactory callFutureFactory = CallFuture.DefaultCallFutureFactory.getInstance();

    /**
     * 创建一个到服务器的单连接的客户端. 由于连接是复用的，所以大部分情况下一个
     * 连接就足够满足并发度的要求了.
     * 这里timeout的设置都采用默认值.
     * @see #DEFAULT_WRITE_TIMEOUT
     * @see #DEFAULT_CONNECT_TIMEOUT
     * @param addr
     */
    public Client(InetSocketAddress addr) {
        this(addr, 1, DEFAULT_CONNECT_TIMEOUT, DEFAULT_WRITE_TIMEOUT);
    }
    
    /**
     * 创建一个到服务器的拥有指定连接数的客户端. timeout的设置采用默认值.
     * @see #DEFAULT_WRITE_TIMEOUT
     * @see #DEFAULT_CONNECT_TIMEOUT
     * @param addr
     * @param connectionCount
     */
    public Client(InetSocketAddress addr, int connectionCount) {
        this(addr, connectionCount, DEFAULT_CONNECT_TIMEOUT, DEFAULT_WRITE_TIMEOUT);
    }

    /**
     * 得到这个客户端所连的服务器地址
     * @return
     */
    public InetSocketAddress getServerAddress() {
        return addr;
    }
    /**
     * 创建客户端，并且指定各种timeout设置.
     * @param addr
     * @param connectionCount
     * @param connectTimeout
     * @param writeTimeout
     */
    public Client(InetSocketAddress addr, int connectionCount, 
            long connectTimeout, long writeTimeout) {
        this.addr = addr;
        this.connectionCount = connectionCount;
        this.connectTimeout = connectTimeout;
        this.writeTimeout = writeTimeout;
    }
    
    /**
     * 设置客户端在read/write过程中使用的writable cache.
     * 这个设置只有在{@link #open()}调用以前做才生效.
     * @param cache
     */
    public void setWritableCache(WritableCache cache) {
        this.writableCache = cache;
    }
    
    /**
     * 设置服务器传输过程中使用的id def.
     * 这个设置只有在{@link #open()}调用以前做才生效.
     * @param idDef
     */
    public void setWritableIdDef(WritableIdDef idDef) {
        this.idDef = idDef;
    }
    
    /**
     * 创建指定数目的到服务器的连接，并且将所有这些连接都bind在
     * 一个context上.
     * 
     * @throws CallException
     */
    public void open() throws CallException {
        synchronized(this) {
            if (opened.get()) {
                throw new CallException("client to " + this.addr + " is opened previously");
            }
            
            boolean success = false;
            try {
                synchronized(connections) {
                    for (int i=0; i<connectionCount; i++) {
                        Connection conn = 
                            new Connection(this,
                                    addr, connectTimeout, 
                                    writeTimeout);
                        connections.add(conn);

                        // 对于只有一个连接的情况，不需要进行bind，使用连接上的默认context
                        if (connectionCount > 1) {
                            bindConnection(conn);
                        }
                    }
                }
                success = true;
            } finally {
                if (!success) {
                    for (Connection conn : connections) {
                        conn.close();
                    }
                    connections.clear();
                }
            }
            
            opened.set(true);
        }
    }
    
    /**
     * 返回连接是否已经被打开.
     * @return
     */
    public boolean isOpened() {
        return opened.get();
    }
    
    /**
     * 提交一个请求，请求部是立即完成的，请使用返回的 {@link Future}
     * 对象来获取请求的状态. 
     * @see #submit(ICallFinishListener, IWritable...)
     * 
     * @param objs
     * @return
     */
    public IFuture submit(IWritable ... objs) {
        return submit(null, objs);
    }
    
    /**
     * 提交一个请求，请求并不是立即完成的，请使用返回的{@link CallFuture}
     * 来得到call当前的状态. 
     * 
     * @param listener 请求完成回调的接口，可以为空
     * @param objs
     * @return
     */
    public IFuture submit(ICallFinishListener listener, IWritable ... objs) {
        if (!opened.get()) {
            CallFuture errorFuture = callFutureFactory.create();
            errorFuture.setCallFinishListener(listener);
            errorFuture.setDone(
                    new ConnectionClosedException("connection is not opened yet"), null);
            return errorFuture;
        }
        
        Connection conn;
        synchronized(connections) {
            if (next >= connections.size()) {
                next = connections.size()-1;
            }
            conn = connections.get(next);
            next = (next +1) % (connections.size());
        }
        
        return conn.submit(listener, objs);
    }
    
    /**
     * 执行一个空的请求，并且指定了timeout.
     * @see #execute(IWritable...)
     * @return
     * @throws Throwable
     */
    public IWritable execute() throws Throwable {
        return execute(EMPTY_ARGS);
    }
    
    /**
     * 执行一个请求，实际上相当于调用了{@link #submit(IWritable...)}后又调用了
     * {@link CallFuture#get()}，参数是callTimeout.
     * 
     * @param objs
     * @return
     * @throws Throwable
     */
    public IWritable execute(IWritable ... objs) throws Throwable {
        IFuture future = submit(objs);
        return (IWritable)future.get();
    }

    /**
     * 关闭所有的连接，所有没有完成或者返回的请求都会失败.
     */
    public void close() {
        synchronized(this) {
            if (!opened.get()) {
                return;
            }
            opened.set(false);
            synchronized(connections) {
                for (Connection conn : connections) {
                    conn.close();
                }
                connections.clear();
            }
        }            
    }
    
    /**
     * 设置客户端在异步调用中使用的future对象的工厂类. 这个方法一般用于在client基础上的上层协议的开发，
     * 最终用户一般不需要调用这个方法.
     * 
     * @param factory
     */
    public void setCallFutureFactory(ICallFutureFactory factory) {
        this.callFutureFactory = factory;
    }
    
    /**
     * 当Client中的任意一个connection遇到异常exception的时候，会回调这个方法，让client
     * 统一处理异常. client对于异常的处理办法是断开所有的到服务器的连接，并且把client状态
     * 置于closed的状态. 上层应用自己需要处理这个异常状况.
     * 
     * @param conn
     * @param e
     */
    void onConnectionException(Connection conn, Throwable e) {
        LOG.log(Level.SEVERE, 
                "connection to " + this.addr + " encountered exception, " +
                		"the client should be force closed", e);
        close();
    }
    
    /**
     * 返回client中使用的callFutureFactory实例，这个方法被 {@link Connection} 调用，
     * 以创建新的call future实例.
     * 
     * @return
     */
    ICallFutureFactory getCallFutureFactory() {
        return callFutureFactory;
    }
    
    /**
     * 返回group使用的writable cache.
     * @return
     */
    WritableCache getWritableCache() {
        return writableCache;
    }
    
    WritableIdDef getWritableIdDef() {
        return idDef;
    }
    
    /**
     * 将连接和context关联，保证这些连接的请求在服务器端都拥有同一个context.
     * 
     * <ul>
     * <li>如果是第一个连接，使用空的context_key，服务器会返回一个唯一的context_key.
     * <li>其他连接使用服务器返回的唯一的context_key.
     * </ul>
     * 
     * @param conn
     * @throws CallException
     */
    private void bindConnection(Connection conn) throws CallException {
        if (ctxKey == null) {
            // first connection, request for auto generated key
            StringWritable emptyString = new StringWritable();
            IFuture future = conn.internalSubmit(-1, null, emptyString);
            StringWritable result;
            try {
                result = (StringWritable)future.get(DEFAULT_BIND_TIMEOUT, TimeUnit.MILLISECONDS);
            } catch(ExecutionException e) {
                Throwable t = e.getCause();
                if (t instanceof CallException) {
                    throw (CallException)t;
                } else {
                    throw new CallException("bind call failed", t);
                }
            } catch(Throwable e) {
                throw new CallException("bind call failed", e);
            }
            ctxKey = result.get();
            if (ctxKey.length() == 0) {
                throw new CallException("bind connection to context failed : empty returned key");
            }
        } else {
            // bind it to the context key
            StringWritable keyObj = new StringWritable(ctxKey);
            IFuture future = conn.internalSubmit(-1, null, keyObj);
            StringWritable result;
            try {
                result = (StringWritable)future.get(DEFAULT_BIND_TIMEOUT, TimeUnit.MILLISECONDS);
            } catch(ExecutionException e) {
                Throwable t = e.getCause();
                if (t instanceof CallException) {
                    throw (CallException)t;
                } else {
                    throw new CallException("bind call failed", t);
                }
            } catch(Throwable e) {
                throw new CallException("bind call failed", e);
            }
            if (!result.get().equals(ctxKey)) {
                throw new CallException("bind connection to context failed : bad returned key");
            }
        }
    }
    
}
