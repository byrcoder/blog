/**
 * @(#)MultipleCallLutch.java, 2008-8-23. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import toolbox.simplenet.client.ICallFinishListener;
import toolbox.simplenet.commons.IFuture;

/**
 * 用于等待多个异步请求返回的latch. 这个类型实现了 {@link ICallFinishListener}，可以
 * 监听异步任务返回.
 * 例子代码:
 * <code>
 *    MultipleCallLatch latch = new MultipleCallLatch(count);
 *    IFuture [] futures = new IFuture[count];
 *    for (int i=0; i<count; i++) {
 *        futures[i] = clients[i].invoke(method, latch, ...);
 *    }
 *           
 *    listener.await(timeout, timeunit);
 *    
 *    for (IFuture future : futures) {
 *        if (future.isDone()) {
 *            ... // process result
 *        }
 *    }
 *    
 * </code>
 * 
 * @author river
 *
 */
public class MultipleCallLatch implements ICallFinishListener {

    protected CountDownLatch latch;

    /**
     * 构造一个统计指定请求个数的lutch.
     * @param count
     */
    public MultipleCallLatch(int count) {
        latch = new CountDownLatch(count);
    }
    
    /**
     * 等待请求返回.
     * @throws InterruptedException
     */
    public void await() throws InterruptedException {
        latch.await();
    }
    
    /**
     * 等待请求返回，如果在指定的timeout时间内请求没有返回，返回false，否则返回true.
     * @param timeout
     * @param unit
     * @return
     * @throws InterruptedException
     */
    public boolean await(long timeout, TimeUnit unit) throws InterruptedException {
        return latch.await(timeout, unit);
    }
    
    /**
     * 任务完成回调.
     */
    public void onFinish(IFuture call) {
        latch.countDown();
    }
    
    
}
