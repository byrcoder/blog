/**
 * @(#)RPCConnectionClosedException.java, 2008-7-31. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import toolbox.simplenet.commons.ConnectionClosedException;

/**
 * 当下层的连接处于关闭状态下请求失败抛出的exception，对应于 {@link ConnectionClosedException}.
 * 
 * @author river
 *
 */
public class RPCConnectionClosedException extends RPCException {

    private static final long serialVersionUID = 2457819751120059881L;

    public RPCConnectionClosedException(String message) {
        super(message);
    }
    
    public RPCConnectionClosedException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public RPCConnectionClosedException(Throwable cause) {
        super(cause);
    }
    
}
