/**
 * @(#)RPCInvalidStateException.java, 2008-7-18. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

/**
 * 这个Exception标明RPC连接状态异常.
 * 
 * @author river
 *
 */
public class RPCInvalidStateException extends RPCException {

    private static final long serialVersionUID = -4259000049786632780L;

    public RPCInvalidStateException(String message) {
        super(message);
    }
    
}
