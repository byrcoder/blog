/**
 * @(#)ServerHandler.java, 2008-3-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

import java.util.concurrent.Executor;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;

import toolbox.misc.LogFormatter;
import toolbox.simplenet.commons.DataPack;
import toolbox.simplenet.commons.ExceptionWritable;
import toolbox.simplenet.commons.WritableCache;
import toolbox.simplenet.commons.WritableCodecFactory;

/**
 * 服务器请求的handler，主要用于调用应用实现的{@link IRequestHandler} 接口，并且完成Context的
 * 管理.
 * @author river
 *
 */
public class ServerHandler extends IoHandlerAdapter {
    private static final Logger LOG = LogFormatter.getLogger(ServerHandler.class);
    
    private ContextManager ctxManager;
    private WritableCache writableCache;
    private IRequestHandler requestHandler;
    private Executor executor;
    private boolean noCtx = false;
    
    public ServerHandler(IRequestHandler requestHandler, Executor executor, 
            ContextManager ctxManager, WritableCache writableCache) {
        this.requestHandler = requestHandler;
        this.executor = executor;
        this.ctxManager = ctxManager;
        this.writableCache = writableCache;
    }
    
    public void setNoContext(boolean v) {
        noCtx = v;
    }
    
    @Override
    public void exceptionCaught(IoSession session, Throwable cause)
            throws Exception {
        LOG.log(Level.SEVERE, "exception caught on connection " + 
                session.getRemoteAddress(), cause);
        session.close();
    }

    @Override
    public void messageReceived(IoSession session, Object message)
            throws Exception {
        DataPack pack = (DataPack) message;
        if (noCtx) {
            executor.execute(new RequestTask(session, pack, null));
        } else {
            long reqSeq = pack.getSequenceNumber();
            if (reqSeq == -1) {
                // bind the session with context
                StringWritable keyObject = (StringWritable) pack.first();
                String key = keyObject.get();
                Context context;
                if (key.length() == 0) {
                    // auto generate key
                    context = ctxManager.attachSession(null, session);
                } else {
                    context = ctxManager.attachSession(key, session);
                }
                key = context.getName();
                
                // generate output pack
                DataPack respPack = new DataPack();
                respPack.setSequenceNumber(pack.getSequenceNumber());
                StringWritable stringObject = 
                    (StringWritable)writableCache.acquire(StringWritable.class);
                stringObject.set(key);
                respPack.add(stringObject);

                // register the request pack to be released in encoder
                session.setAttribute(WritableCodecFactory.REQUEST_PACK_KEY, pack);
                
                session.write(respPack);
                
            } else {
                Context ctx = ctxManager.getContext(session);
                executor.execute(new RequestTask(session, pack, ctx));
            }
        }
    }

    /**
     * Remove the context when session closed.
     */
    @Override
    public void sessionClosed(IoSession session) throws Exception {
        ctxManager.detachSession(session);
    }
    
    private class RequestTask implements Runnable {
        private IoSession session;
        private DataPack pack;
        private Context ctx;
        private long createTime;
        private long startTime;
        
        public RequestTask(IoSession session, DataPack pack, Context ctx) {
            this.session = session;
            this.pack = pack;
            this.ctx = ctx;
            this.createTime = System.currentTimeMillis();
        }

        private void setName(Thread t, String name) {
            try {
                t.setName(name);
            } catch(Exception e) {
                // probably security exception, ignore it
            }
        }
        
        public void run() {
            Thread currentThread = Thread.currentThread();
            String threadName = currentThread.getName();
            this.startTime = System.currentTimeMillis();
            
            // include session address in thread name
            String newName = threadName + "-" + session.getRemoteAddress() + 
            "-" + createTime + "-" + startTime;
            setName(currentThread, newName);

            try {
                // execute the request and get result
                IWritable result;
                try {
                    result = requestHandler.process(pack.getWritableList(), ctx, writableCache, session);
                } catch(SessionFatalException e) {
                    // terminate the connection on this exception
                    LOG.log(Level.SEVERE, "process request from " + session.getRemoteAddress() + " failed", e);
                    session.close();
                    return;
                } catch(Throwable t) {
                    ExceptionWritable ew = (ExceptionWritable)writableCache.acquire(ExceptionWritable.class);
                    ew.set(t);
                    result = ew;
                }

                // output the response
                DataPack respPack = new DataPack();
                respPack.setSequenceNumber(pack.getSequenceNumber());
                respPack.add(result);

                // register the request pack to be released in encoder
                session.setAttribute(WritableCodecFactory.REQUEST_PACK_KEY, pack);

                session.write(respPack);
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.log(Level.FINE, System.currentTimeMillis() + " [" +
                            session.getLocalAddress() + "-" + 
                            session.getRemoteAddress() + "] Request " + pack.getSequenceNumber() + 
                            ": inBufTime=" + (startTime - createTime) + "ms, executeTime=" + 
                            (System.currentTimeMillis()-startTime) + "ms.");
                }
            } finally {
                // restore thread name
                setName(currentThread, threadName);
            }
        }
        
    }
    
}
