/**
 * @(#)Context.java, 2007-10-12. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

import java.net.InetSocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

import org.apache.mina.common.IoSession;

import toolbox.misc.LogFormatter;


/**
 * context管理器，管理context和session之间的关联关系，并且提供接口便于session被释放的时候
 * 关闭无关联的context.
 * 
 * @author river
 *
 */
public class ContextManager {
    private static final Logger LOG = LogFormatter.getLogger(ContextManager.class);
    
    private static final String CACHED_CONTEXT_NAME = "__context_";
    
    private IContextListener listener = null;
    
    private AtomicLong contextIdGenerator = new AtomicLong(0);
    
    private ConcurrentHashMap<String, Context> contexts = 
        new ConcurrentHashMap<String, Context>();
    
    private boolean verbose = false;
    
    public void setContextListener(IContextListener listener) {
        this.listener = listener;
    }
    
    public void setVerbose(boolean v) {
        this.verbose = v;
    }
    
    public int getContextCount() {
        return contexts.size();
    }
    
    private String createContextKey(IoSession session) {
        InetSocketAddress addr = (InetSocketAddress) session.getRemoteAddress();
        return addr.toString() + " - " + contextIdGenerator.addAndGet(1);
    }
    
    /**
     * 将一个session关联到key对应的context. 如果key是null，表示需要自动给这个context生成一个
     * key.
     * 
     * @param key
     * @param session
     * @return
     */
    Context attachSession(String key, IoSession session) {
        // detach old context if exists
        Context oldContext = (Context) session.getAttribute(CACHED_CONTEXT_NAME);
        if (oldContext != null) {
            detachSession(session);
        }
    
        Context context = null;
        synchronized(contexts) {
            if (key == null) {
                key = createContextKey(session);
            } else {
                context = contexts.get(key);
            }
            
            if (context == null) {
                context = new Context(key);
                // register context
                contexts.put(context.getName(), context);
                if (verbose) {
                    LOG.info("Context " + key + " created.");
                }
            }

            // add session to context
            if (verbose) {
                LOG.info("Bind session " + session.getRemoteAddress() + 
                        " to context " + context.getName());
            }
            context.addSession(session);
            session.setAttribute(CACHED_CONTEXT_NAME, context);
        }
        
        if (listener != null) {
            listener.onContextCreate(context);
        }
        
        return context;
    }
    
    /**
     * 取消session和对应context的关联，这个方法在session关闭的时候被调用.
     * 如果一个context所有关联的session都已经关闭，context也会被释放.
     * 
     * @param session
     */
    void detachSession(IoSession session) {
        Context context = (Context) session.getAttribute(CACHED_CONTEXT_NAME);
        if (context != null) {
            boolean removed = false;
            synchronized(contexts) {
                if (verbose) {
                    LOG.info("Detach session " + session.getRemoteAddress() + " from context " + context.getName());
                }
                context.removeSession(session);
                session.removeAttribute(CACHED_CONTEXT_NAME);

                if (context.getSessionCount() == 0) {
                    if (verbose) {
                        LOG.info("Remove empty context " + context.getName());
                    }
                    contexts.remove(context.getName());
                    removed = true;
                }
            }
            if (removed && listener != null) {
                listener.onContextDestroy(context);
            }
        }
    }
    
    /**
     * 获得session对应的context.
     * @param session
     * @return
     */
    Context getContext(IoSession session) {
        Context context = (Context)session.getAttribute(CACHED_CONTEXT_NAME);
        if (context == null) {
            // first called
            return attachSession(null, session);
        } else {
            return context;
        }
    }
    
}
