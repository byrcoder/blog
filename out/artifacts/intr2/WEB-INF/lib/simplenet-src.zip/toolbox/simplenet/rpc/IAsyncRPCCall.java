/**
 * @(#)IAsyncRPCCall.java, 2008-8-21. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.lang.reflect.Method;

import toolbox.simplenet.client.ICallFinishListener;
import toolbox.simplenet.commons.IFuture;

/**
 * 异步rpc方法调用的接口.
 * @author river
 *
 */
public interface IAsyncRPCCall {

    /**
     * 异步调用指定的方法，并且返回调用的future对象. 等待请求返回以及取得返回值都通过调用 
     * {@link IRPCInvokeFuture}的对应方法完成.
     * @see IRPCInvokeFuture#join()
     * @see IRPCInvokeFuture#getResult()
     * @see IRPCInvokeFuture#getException()
     * 
     * @param method
     * @param args
     * @return
     */
    public IFuture invoke(Method method, Object ... args);
    
    /**
     * 异步调用指定的方法，并且返回调用的future对象. 等待请求返回以及取得返回值都通过调用 
     * {@link IRPCInvokeFuture}的对应方法完成.
     * @see IRPCInvokeFuture#join()
     * @see IRPCInvokeFuture#getResult()
     * @see IRPCInvokeFuture#getException()
     * 
     * @param method
     * @param listener
     * @param args
     * @return
     */
    public IFuture invoke(Method method, ICallFinishListener listener, Object ... args);
    
}
