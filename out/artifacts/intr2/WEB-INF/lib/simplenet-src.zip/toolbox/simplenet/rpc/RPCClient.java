/**
 * @(#)RPCClient.java, 2008-4-6. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import odis.serialize.IWritable;
import odis.serialize.lib.ObjectWritable;
import odis.serialize.lib.StringWritable;
import toolbox.simplenet.client.CallFuture;
import toolbox.simplenet.client.Client;
import toolbox.simplenet.client.ICallFinishListener;
import toolbox.simplenet.client.ICallFutureFactory;
import toolbox.simplenet.commons.CallException;
import toolbox.simplenet.commons.ConnectionClosedException;
import toolbox.simplenet.commons.IFuture;

/**
 * RPC客户端，在{@link Client} 基础上实现了rpc调用的接口.
 * 
 * rpc客户端的使用方式有两种，一种是同步的rpc调用，例如如下的代码：
 * <code>
 *   ...
 *   RPCClient client = new RPCClient(addr);
 *   client.open();
 *   IProto proto = client.getProxy(IProto.class);
 *   proto.rpcMethod(...);
 *   ...
 * </code>
 * 
 * 另外一种办法是异步调用，使用{@link #invoke(Method, Object[])}
 * 方法，例如如下代码：
 * <code>
 *   ...
 *   RPCClient client = new RPCClient(addr);
 *   client.open();
 *   Method method = IProto.class.getMethod(methodName, argTypes);
 *   IFuture future = client.invoke(method, args);
 *   ...
 *   try {
 *       Object result = future.get(timeout, timeoutUnit);
 *       // process result
 *       ...
 *   } catch(ExecutionException e) {
 *       Throwable t = e.getCause();
 *       // process exception
 *       ...
 *   } catch(TimeoutException e) {
 *       // process timeout
 *       ...
 *   }
 * </code>
 * 
 * 另外一个需要注意的地方，就是RPCClient需要调用{@link #open()}打开连接，而不是默认打开.
 * 
 * @author river
 *
 */
public class RPCClient implements IAsyncRPCCall {
    protected Client client;
    
    protected long callTimeout = 0;
    protected TimeUnit callTimeunit; 
    
    public RPCClient(InetSocketAddress addr) {
        this(addr, 1, Client.DEFAULT_CONNECT_TIMEOUT, Client.DEFAULT_WRITE_TIMEOUT);
    }
    
    /**
     * 创建client实例，默认请求没有timeout，可以通过 {@link #setCallTimeout(long, TimeUnit)}
     * 来指定timeout的时间.
     * 
     * @param addr
     * @param connectionCount
     * @param connectTimeout
     * @param writeTimeout
     */
    public RPCClient(InetSocketAddress addr, int connectionCount, 
            long connectTimeout, long writeTimeout) {
        this(addr, connectionCount, connectTimeout, writeTimeout, 0);
    }
    
    /**
     * 创建client实例，并且指定请求的timeout.
     * @see #setCallTimeout(long, TimeUnit)
     * 
     * @param addr
     * @param connectionCount
     * @param connectTimeout
     * @param writeTimeout
     * @param callTimeout
     */
    public RPCClient(InetSocketAddress addr, int connectionCount, 
            long connectTimeout, long writeTimeout, long callTimeout) {
        client = new Client(addr, connectionCount, connectTimeout, writeTimeout);
        client.setCallFutureFactory(RPCInvokeFuture.Factory.getInstance());
        this.setCallTimeout(callTimeout, TimeUnit.MILLISECONDS);
    }
    
    /**
     * 设置请求的timeout，这个设置仅仅在通过 proxy同步调用远程方法的时候生效，对于异步调用
     * 没有作用.
     * 
     * @param callTimeout
     * @param unit
     */
    public void setCallTimeout(long callTimeout, TimeUnit unit) {
        this.callTimeout = callTimeout;
        this.callTimeunit = unit;
    }
    
    /**
     * Return the real client under rpc client.
     * @return
     */
    public Client getClient() {
        return client;
    }
    
    /**
     * 打开连接，新创建的RPCClient实例连接是默认关闭的，必须调用这个方法打开连接.
     * @throws RPCException
     */
    public void open() throws RPCException {
        try {
            client.open();
        } catch(CallException e) {
            throw new RPCException("open rpc client failed", e);
        }
    }

    /**
     * 返回连接是否已经被打开.
     * @return
     */
    public boolean isOpened() {
        return client.isOpened();
    }
    
    /**
     * 关闭连接.
     */
    public void close() {
        client.close();
    }
    
    /**
     * 得到一个连接上的proxy对象.我们会检查传入的接口是否是正确的rpc接口（rpc接口的方法必须声明抛出
     * {@link RPCException}).
     * @param <V> 接口类型
     * @param protocol 接口的类定义
     * @return 一个接口的实例
     */
    @SuppressWarnings("unchecked")
    public <V> V getProxy(Class<V> protocol) {
        RPC.validateRPCInterface(protocol);
        return (V)Proxy.newProxyInstance(protocol.getClassLoader(), 
                new Class<?>[]{protocol, IRPCClientCommon.class}, new Invoker());
    }

    /**
     * 把请求发送到rpc服务器，返回future对象. 调用者通过这个future对象检查请求的状态，并且
     * 在请求完成的时候得到返回值.
     */
    public IFuture invoke(Method method, Object ... args) {
        return invoke(method, null, args);
    }
    
    /**
     * 把请求发送到rpc服务器，返回future对象. 调用者通过这个future对象检查请求的状态，并且
     * 在请求完成的时候得到返回值.
     * 
     * 通过<code>listener</code>参数，可以为请求设置一个完成回调接口.
     * 
     * @param method
     * @param listener
     * @param args
     * @return
     */
    public IFuture invoke(Method method, ICallFinishListener listener, Object ... args) {
        StringWritable methodNameObj = new StringWritable(method.getName());
        int argCount = args == null ? 0 : args.length;
        IWritable [] params = new IWritable[argCount +1];
        params[0] = methodNameObj;
        Class<?> [] argTypes = method.getParameterTypes();
        
        for (int i=0; i<argCount; i++) {
            params[i+1] = new ObjectWritable(argTypes[i], args[i]);
        }
        return client.submit(listener, params);
    }
    
    protected void fillStackTrace(Throwable t, Exception tmp) {
        StackTraceElement [] clientStackTrace = tmp.getStackTrace();
        StackTraceElement [] remoteStackTrace = t.getStackTrace();
        assert remoteStackTrace != null;
        StackTraceElement [] stackTrace = new StackTraceElement[
                                                                clientStackTrace.length + remoteStackTrace.length + 1 ];
        System.arraycopy(remoteStackTrace, 0, stackTrace, 0, remoteStackTrace.length);
        stackTrace[remoteStackTrace.length] = new StackTraceElement(
                "--- rpc call ---", "...", "...", -1);
        System.arraycopy(clientStackTrace, 0, stackTrace, 
                remoteStackTrace.length +1 , clientStackTrace.length);
        t.setStackTrace(stackTrace);
    }
    
    /**
     * 对于proxy对象的方法调用.
     * @param proxy
     * @param method
     * @param args
     * @return
     * @throws Throwable
     */
    protected Object invokeProxyMethod(Object proxy, Method method, Object[] args) throws Throwable {

        // check and process internal methods
        String methodName = method.getName();
        if (methodName.startsWith("__")) {
            // internal methods, process it in client
            if (methodName.equals(IRPCClientCommon.CLOSE_METHOD_NAME)) {
                close();
                return null;
            } else {
                throw new RuntimeException("bad internal method : " + methodName);
            }
        }

        // send request to server and wait for result
        IFuture future = invoke(method, args);
        if (future == null) {
            // cannot submit the request now
            throw new RPCInvalidStateException("client connection state is invalid");
        }
        
        try {
            if (callTimeout > 0) {
                return future.get(callTimeout, callTimeunit);
            } else {
                return future.get();
            }
        } catch(ExecutionException e) {
            Throwable t = e.getCause();
            fillStackTrace(t, new Exception());
            throw t;
        } catch(InterruptedException e) {
            Throwable t = new RPCException("call interrupted for method \"" + 
                    method.getName() + " \" with args: " + Arrays.deepToString(args), e);
            throw t;
        } catch(TimeoutException e) {
            Throwable t = new RPCTimeoutException("call timeout for method \"" + 
                    method.getName() + "\" with args : " + 
                    Arrays.deepToString(args));
            throw t;
        }
    }
    
    private class Invoker implements InvocationHandler {
        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            return invokeProxyMethod(proxy, method, args);
        }
    }
    
    /**
     * RPC异步调用返回的future对象，在将实际的请求传递给 {@link CallFuture} 以外，从返回值
     * 的ObjectWritable中提取出实际的返回值，并且当异常类型是 {@link CallException}的时候，
     * 转换成为 {@link RPCException}. 
     *
     * @author river
     *
     */
    protected static class RPCInvokeFuture extends CallFuture {
        
        @Override
        public Object get() throws InterruptedException, ExecutionException {
            try {
                Object o = super.get();
                if (o == null) return null;
                else if (o instanceof ObjectWritable) {
                    return ((ObjectWritable) o).getObject();
                } else return o;
            } catch(ExecutionException e) {
                Throwable t = e.getCause();
                if (t instanceof ConnectionClosedException) {
                    throw new ExecutionException(new RPCException("underlined connection is closed", t));
                } else if (t instanceof CallException) {
                    throw new ExecutionException("call failed", new RPCException(t));
                } else {
                    throw e;
                }
            }
        }

        @Override
        public Object get(long timeout, TimeUnit unit)
                throws InterruptedException, ExecutionException,
                TimeoutException {
            try {
                Object o = super.get(timeout, unit);
                if (o == null) return null;
                else if (o instanceof ObjectWritable) {
                    return ((ObjectWritable) o).getObject();
                } else return o;
            } catch(ExecutionException e) {
                Throwable t = e.getCause();
                if (t instanceof ConnectionClosedException) {
                    throw new ExecutionException(new RPCConnectionClosedException("underlined connection is closed", t));
                } else if (t instanceof CallException) {
                    throw new ExecutionException("call failed", new RPCException(t));
                } else {
                    throw e;
                }
            }
        }
        
        static class Factory implements ICallFutureFactory {
            
            private static ICallFutureFactory instance = new Factory();
            public static ICallFutureFactory getInstance() {
                return instance;
            }
            
            private Factory() {}
            
            public CallFuture create() {
                return new RPCInvokeFuture();
            }
            
        }
        

    }
    
    /**
     * 为了能够通过rpc proxy对象释放底层的连接，在实现的时候，每个rpc proxy对象实际
     * 还实现了{@link IRPCClientCommon}的接口.
     *
     * @author river
     *
     */
    static interface IRPCClientCommon {
        public static final String CLOSE_METHOD_NAME = "__close";
        public void __close();
    }
    
}
