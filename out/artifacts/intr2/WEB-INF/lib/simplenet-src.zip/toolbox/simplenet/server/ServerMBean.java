/**
 * @(#)IServerMBean.java, 2008-4-12. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

/**
 * 服务器对象的jmx接口.
 * @author river
 */
public interface ServerMBean {
    
    /**
     * 返回服务器的端口号.
     * @return
     */
    public int getPort();
    
    /**
     * 返回服务器请求队列中的请求数.
     * @return
     */
    public int getRequestQueueSize();
    
    /**
     * 返回当前context的数目.
     * @return
     */
    public int getContextCount();
 
}
