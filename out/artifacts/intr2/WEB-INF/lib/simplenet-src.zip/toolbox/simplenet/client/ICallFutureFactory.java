/**
 * @(#)ICallFutureFactory.java, 2008-8-23. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.client;

import java.util.concurrent.Future;

/**
 * 创建Future对象的factory接口. 在simplenet的实现中，支持基本的数据传输支持，rpc访问接口支持，并且
 * 所有这些接口都支持异步访问，所以，我们用一个factory来维持这些访问层次中的一致的 {@link Future}
 * 类型.
 * 
 * @author river
 *
 */
public interface ICallFutureFactory {

    /**
     * 创建一个CallFuture的实例.
     * @return
     */
    CallFuture create();
    
}
