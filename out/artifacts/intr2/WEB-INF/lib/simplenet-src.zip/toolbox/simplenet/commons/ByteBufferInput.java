/**
 * @(#)ByteBufferInput.java, 2008-4-1. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.IOException;

import org.apache.mina.common.ByteBuffer;

/**
 * 在apache mina的ByteBuffer基础上实现的DataInput接口，主要用于兼容IWritable的输入.
 * 需要注意的是，如下方法没有实现: {@link #readUTF()}, {@link #readLine()}.
 * 
 * 在基本接口上，还增加了{@link #readAsciiString()}方法用于加速对于ascii字符串的读取.
 * 
 * @author river
 *
 */
public class ByteBufferInput implements DataInput {

    private ByteBuffer buf;

    public ByteBufferInput(ByteBuffer buf) {
        this.buf = buf;
    }
    
    public boolean readBoolean() throws IOException {
        return buf.get() > 0;
    }

    public byte readByte() throws IOException {
        return buf.get();
    }

    public char readChar() throws IOException {
        return buf.getChar();
    }

    public double readDouble() throws IOException {
        return buf.getDouble();
    }

    public float readFloat() throws IOException {
        return buf.getFloat();
    }

    public void readFully(byte[] b) throws IOException {
        buf.get(b);
    }

    public void readFully(byte[] b, int off, int len) throws IOException {
        buf.get(b, off, len);
    }

    public int readInt() throws IOException {
        return buf.getInt();
    }

    /**
     * @deprecated
     */
    public String readLine() throws IOException {
        throw new AbstractMethodError("not implemented");
    }

    public long readLong() throws IOException {
        return buf.getLong();
    }

    public short readShort() throws IOException {
        return buf.getShort();
    }

    @Deprecated
    public String readUTF() throws IOException {
        return DataInputStream.readUTF(this);
    }

    public int readUnsignedByte() throws IOException {
        byte b = buf.get();
        return b & 0xff;
    }

    public int readUnsignedShort() throws IOException {
        short s = buf.getShort();
        return s & 0xffff;
    }

    public int skipBytes(int n) throws IOException {
        int pos = buf.position();
        int newPos = buf.position() + n;
        if (newPos > buf.limit()) newPos = buf.limit();
        buf.position(newPos);
        return newPos - pos;
    }
    
    /**
     * 读入一个完全由ascii字符组成的字符串，例如类名，这里避免了字符集的转换，并且
     * 也减少了临时缓存的创建.
     * @return
     * @throws IOException
     */
    public String readAsciiString() throws IOException {
        int len = readUnsignedShort();
        char [] arr = new char[len];
        for (int i=0; i<len; i++) {
            arr[i] = (char) readByte();
        }
        return new String(arr);
    }
    
}
