/**
 * @(#)IFuture.java, 2008-8-23. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.concurrent.Future;

/**
 * Future接口声明. 这里的Future接口就是jdk的 {@link Future}.
 * 
 * @author river
 *
 */
public interface IFuture extends java.util.concurrent.Future<Object> {
}
