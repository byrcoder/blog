/**
 * @(#)HelloImpl.java, 2008-4-12. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo.hello;

import toolbox.simplenet.rpc.RPCException;
import toolbox.simplenet.rpc.RPCThreadState;
import toolbox.simplenet.server.Context;
import toolbox.simplenet.server.IContextListener;


/**
 *
 * @author river
 *
 */
public class HelloImpl implements IHello, IContextListener {
    
    public String hello(String name) {
        Context ctx = RPCThreadState.getContext();
        ctx.put("name", name);
        return "Hello " + name + "!";
    }

    public String hello() throws RPCException {
        Context ctx = RPCThreadState.getContext();
        String name = (String) ctx.get("name");
        if (name == null) {
            return "Hello, may I known your name?";
        } else {
            return "Hello " + name + "!";
        }
    }

    public void onContextCreate(Context context) {
        context.put("__start", System.currentTimeMillis());
    }

    public void onContextDestroy(Context context) {
        long start = (Long) context.get("__start");
        long end = System.currentTimeMillis();
        String name = (String) context.get("name");
        if (name == null) {
            System.out.println("unknown user stayed here for " + (end-start) + "ms.");
        } else {
            System.out.println(name + " stayed here for " + (end-start) + "ms.");
        }
    }
    
}
