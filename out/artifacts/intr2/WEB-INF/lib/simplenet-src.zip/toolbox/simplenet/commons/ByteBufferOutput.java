/**
 * @(#)ByteBufferOutput.java, 2008-4-1. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.io.DataOutput;
import java.io.IOException;

import org.apache.mina.common.ByteBuffer;

/**
 * 在apache mina的ByteBuffer基础上实现的DataOutput接口，用于IWritable对象的输出.
 * 需要注意的是，如下方法没有实现: {@link #writeUTF(String)}, {@link #writeChars(String)},
 * {@link #writeBytes(String)}.
 * 
 * 在基本接口以外，还增加了{@link #writeAsciiString(String)}方法加速对于”类名“这样的ascii
 * 字符串的输出.
 * 
 * @author river
 *
 */
public class ByteBufferOutput implements DataOutput {
    private ByteBuffer buf;
    
    public ByteBufferOutput(ByteBuffer buf) {
        this.buf = buf;
    }
    
    public void write(int b) throws IOException {
        buf.put((byte)b);
    }

    public void write(byte[] b) throws IOException {
        buf.put(b);
    }

    public void write(byte[] b, int off, int len) throws IOException {
        buf.put(b, off, len);
    }

    public void writeBoolean(boolean v) throws IOException {
        buf.put(v ? (byte)1 : (byte)0);
    }

    public void writeByte(int v) throws IOException {
        buf.put((byte)v);
    }

    @Deprecated
    public void writeBytes(String s) throws IOException {
        throw new AbstractMethodError("not implemented");
    }

    public void writeChar(int v) throws IOException {
        buf.putChar((char)v);
    }

    @Deprecated
    public void writeChars(String s) throws IOException {
        throw new AbstractMethodError("not implemented");
    }

    public void writeDouble(double v) throws IOException {
        buf.putDouble(v);
    }

    public void writeFloat(float v) throws IOException {
        buf.putFloat(v);
    }

    public void writeInt(int v) throws IOException {
        buf.putInt(v);
    }

    public void writeLong(long v) throws IOException {
        buf.putLong(v);
    }

    public void writeShort(int v) throws IOException {
        buf.putShort((short)v);
    }

    @Deprecated
    public void writeUTF(String str) throws IOException {
        throw new AbstractMethodError("not implemented");
    }

    /**
     * 输出一个完全由ascii字符组成的字符串，例如类名，这里不会创建新的临时缓存.
     * @param s
     * @throws IOException
     */
    public void writeAsciiString(String s) throws IOException {
        int len = s.length();
        writeShort(len);
        for (int i=0; i<len; i++) {
            writeByte(s.charAt(i));
        }
    }
    
}
