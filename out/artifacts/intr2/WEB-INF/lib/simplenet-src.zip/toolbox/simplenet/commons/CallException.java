/**
 * @(#)RemoteCallException.java, 2008-3-30. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

/**
 * 请求过程中可能抛出的exception.
 * @author river
 *
 */
public class CallException extends Exception {

    private static final long serialVersionUID = -7036269999956272621L;

    public CallException(String message) { super(message); }
    
    public CallException(String message, Throwable cause) { super(message, cause); }
    
    public CallException(Throwable cause) { super(cause); }
    
}
