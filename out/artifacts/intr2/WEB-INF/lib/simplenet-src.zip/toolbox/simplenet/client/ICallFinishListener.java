/**
 * @(#)ICallFinishListener.java, 2008-8-22. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.client;

import toolbox.simplenet.commons.IFuture;

/**
 * Callback interface for call.
 * 
 * @author river
 *
 */
public interface ICallFinishListener {

    /**
     * This method should in invoked whenever the call is done(exception included), 
     * or cancelled.
     * 
     * @param call
     */
    public void onFinish(IFuture call);
    
}
