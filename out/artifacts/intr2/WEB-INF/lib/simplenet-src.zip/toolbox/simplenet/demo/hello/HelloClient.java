/**
 * @(#)HelloClient.java, 2008-4-12. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo.hello;

import java.net.InetSocketAddress;

import toolbox.simplenet.rpc.RPC;

/**
 *
 * @author river
 *
 */
public class HelloClient {

    public static void main(String [] args) throws Exception {
        if (args.length < 3) {
            System.out.println("args: hostname port name");
            return;
        }
        InetSocketAddress addr = new InetSocketAddress(args[0], Integer.parseInt(args[1]));
        
        IHello hello = RPC.getProxy(addr, IHello.class);
        System.out.println(hello.hello(args[2]));
        
        RPC.closeProxy(hello);
        
    }
    
}
