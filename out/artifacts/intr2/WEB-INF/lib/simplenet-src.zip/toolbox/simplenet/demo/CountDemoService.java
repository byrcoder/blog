/**
 * @(#)CountDemoService.java, 2008-4-1. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo;

import java.util.List;

import odis.serialize.IWritable;
import odis.serialize.lib.IntWritable;

import org.apache.mina.common.IoSession;

import toolbox.simplenet.commons.WritableCache;
import toolbox.simplenet.server.Context;
import toolbox.simplenet.server.IRequestHandler;

/**
 *
 * @author river
 *
 */
public class CountDemoService implements IRequestHandler {
    
    public IWritable process(List<IWritable> input, Context ctx, WritableCache writableCache, IoSession session)
            throws Throwable {
        IntWritable count = (IntWritable)ctx.get("__count_");
        if (count == null) {
            count = new IntWritable(1);
            ctx.put("__count_", new IntWritable(1));
        } else {
            count.incAndGet(1);
        }
        return count;
    }

}
