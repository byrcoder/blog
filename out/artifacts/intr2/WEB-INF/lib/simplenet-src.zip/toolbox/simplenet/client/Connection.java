/**
 * @(#)Connection.java, 2007-10-15. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.client;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.IWritable;

import org.apache.mina.common.ConnectFuture;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.SocketConnector;
import org.apache.mina.transport.socket.nio.SocketConnectorConfig;

import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.simplenet.commons.CallException;
import toolbox.simplenet.commons.ConnectionClosedException;
import toolbox.simplenet.commons.DataPack;
import toolbox.simplenet.commons.ExceptionWritable;
import toolbox.simplenet.commons.IFuture;
import toolbox.simplenet.commons.WritableCodecFactory;

/**
 * 可以复用的连接的实现.
 * 
 * @author river
 *
 */
public class Connection extends IoHandlerAdapter {
    
    public static final Logger LOG = LogFormatter.getLogger(Connection.class);

    private boolean callMapClosed = false;
    private Map<Long, CallFuture> callMap = new ConcurrentHashMap<Long, CallFuture>();
    private IoSession session;
    private AtomicLong reqId = new AtomicLong(0);
    
    private Client group;
    private boolean closed;

    /**
     * 创建一个到服务器的物理连接，并且加入到给定的group(client)中.
     * @param group 连接所属的group
     * @param addr 服务器地址
     * @param connectTimeout 建立连接的timeout
     * @param writeTimeout 输出数据的timeout
     * @param callTimeout 请求执行的timeout
     */
    Connection(Client group,
            InetSocketAddress addr, 
            long connectTimeout, 
            long writeTimeout) {

        this.group = group;
        
        SocketConnector connector = new SocketConnector(1, new Executor() {
            public void execute(Runnable command) {
                Thread t = new Thread(command);
                t.setDaemon(true);
                t.start();
            }
        });
        
        SocketConnectorConfig cfg  = new SocketConnectorConfig();
        cfg.getSessionConfig().setTcpNoDelay(true);
        
        int realConnectTimeout = (int)(connectTimeout / UnitUtils.SECOND);
        if (realConnectTimeout <= 0) {
            LOG.log(Level.WARNING, "minimal connect timeout is 1 second");
            realConnectTimeout = 1;
        }
        cfg.setConnectTimeout(realConnectTimeout);
        
        WritableCodecFactory codecFactory = new WritableCodecFactory(
                group.getWritableCache(), 
                group.getWritableIdDef(), false);
        
        cfg.getFilterChain().addLast("codec", new ProtocolCodecFilter(codecFactory));
        
        cfg.setThreadModel(ThreadModel.MANUAL);
        
        ConnectFuture connFuture = connector.connect(addr, this, cfg);
        connFuture.join();
        session = connFuture.getSession();
        
        session.setWriteTimeout((int)(writeTimeout/UnitUtils.SECOND));
        
        this.closed = false;
    }
    
    /**
     * 物理连接关闭，这里会关闭请求队列，并且将队列中的所有请求失败.
     */
    @Override
    public void sessionClosed(IoSession session) throws Exception {
        
        LOG.log(Level.INFO, "clear all the pending calls because connection is closed");
        int count = 0;
        synchronized(callMap) {
            callMapClosed = true;
            ArrayList<Long> idList = new ArrayList<Long>(callMap.size());
            idList.addAll(callMap.keySet());
            for (Long id : idList) {
                CallFuture call = callMap.remove(id);
                if (call != null) {
                    count ++;
                    call.setDone(new ConnectionClosedException("connection to " + 
                            session.getRemoteAddress() + " closed"), null);
                }
            }
        }
        
        LOG.log(Level.INFO, count + " pending calls failed for closed connection");
        
        if (!closed) {
            group.onConnectionException(this, 
                    new IOException("Connection to " + session.getRemoteAddress() + " reset by peer"));
        }
        
    }

    @Override
    public void exceptionCaught(IoSession session, Throwable cause)
            throws Exception {
        LOG.log(Level.SEVERE, "exception caught on connection " + 
                session.getRemoteAddress(), cause);
        
        // tell group to handle the exception
        group.onConnectionException(this, cause);
    }

    @Override
    public void messageReceived(IoSession session, Object message)
            throws Exception {
        DataPack pack = (DataPack) message;
        CallFuture call = callMap.remove(pack.getSequenceNumber()); 
        if (call == null) {
            LOG.log(Level.WARNING, "cannot find request for response with id " + 
                    pack.getSequenceNumber());
            return;
        }
        
        IWritable obj = pack.first();
        if (obj instanceof ExceptionWritable) {
            call.setDone(((ExceptionWritable)obj).get(), null);
        } else {
            call.setDone(null, obj);
        }
    }

    /**
     * 提交一个异步请求，并且得到future对象. 
     * @param timeout
     * @param objs
     * @return
     */
    public IFuture submit(IWritable ... objs) {
        long id = reqId.getAndAdd(1);
        return internalSubmit(id, null, objs);
    }
    
    /**
     * 提交一个异步请求，并且为这个异步请求注册一个完成回调的接口.
     * @param listener
     * @param objs
     * @return
     */
    public IFuture submit(ICallFinishListener listener, IWritable ... objs) {
        long id = reqId.getAndAdd(1);
        return internalSubmit(id, listener, objs);
    }
    
    IFuture internalSubmit(long id, ICallFinishListener listener, IWritable ... objs) {
        // initialize call future object
        CallFuture call = this.group.getCallFutureFactory().create();
        call.setCallFinishListener(listener);

        synchronized(callMap) {
            if (callMapClosed) {
                call.setDone(new CallException("connection closed in previous call"), null);
                return call;
            } else {
                callMap.put(id, call);
            }
        }
        
        // Send request
        DataPack pack = new DataPack();
        pack.setSequenceNumber(id);
        for (IWritable obj : objs) {
            pack.add(obj);
        }

        try {
            session.write(pack);
            if (LOG.isLoggable(Level.FINE)) {
                LOG.log(Level.FINE, System.currentTimeMillis() + " [" + session.getLocalAddress() + 
                        "-" + session.getRemoteAddress() +
                        "] request " + pack.getSequenceNumber() + " submited: createTime=" + 
                        call.getCreateTime()); 
            }
        } catch(Throwable e){
            call.setDone(new CallException(
                    "request not submitted for unexpected exception", e), null);
        }
        
        return call;
    }
    
    /**
     * 执行一个请求，并且返回返回值. 如果请求过程中出现任意exception，都会被抛出.
     * 
     * @param timeout
     * @param objs
     * @return
     * @throws Throwable
     */
    public IWritable execute(IWritable ... objs) throws Throwable {
        // Submit
        IFuture future = submit(objs);
        return (IWritable)future.get();
    }
    
    /**
     * 关闭连接，所有连接上的请求都会失败.
     */
    public void close() {
        this.closed = true;
        LOG.log(Level.INFO, "Connection to " + session.getRemoteAddress() + " is closed.");
        session.close();
        // sessionClosed() method would be called by mina
    }

}
