/**
 * @(#)RPCServer.java, 2008-4-6. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.ObjectWritable;
import odis.serialize.lib.StringWritable;

import org.apache.mina.common.IoSession;

import toolbox.misc.LogFormatter;
import toolbox.simplenet.commons.WritableCache;
import toolbox.simplenet.server.Context;
import toolbox.simplenet.server.IContextListener;
import toolbox.simplenet.server.IRequestHandler;
import toolbox.simplenet.server.Server;

/**
 * 在{@link Server}基础上实现的RPC服务器.
 * 创建一个rpc服务器可以使用如下的代码:
 * <code>
 *   RPCServer server = new RPCServer(instance, port);
 *   server.start();
 *   ...
 * </code>
 * 其中instance实现了定义好的rpc接口.
 * 如果需要设置一些服务器的参数，可以通过{@link #getServer()}方法获得底层的server对象
 * 并且调用{@link Server}的接口.
 * 
 * 如果传入的instance还实现了{@link IContextListener}的接口，那么对应的事件也会被
 * 监听到.
 * 
 * @see IContextListener
 * 
 * @author river
 *
 */
public class RPCServer {
    public static final Logger LOG = LogFormatter.getLogger(RPCServer.class);
    
    private Object instance;
    private Server server;
    private IContextListener listener;
    
    /**
     * 创建只有一个处理线程的rpc服务器.
     * @param instance
     * @param port
     */
    public RPCServer(Object instance, int port) {
        this(instance, port, 1, 1);
    }
    
    /**
     * 创建指定应答连接线程数以及处理线程数的rpc服务器.
     * @param instance
     * @param port
     * @param ioWorkerNumber
     * @param processorNumber
     */
    public RPCServer(Object instance, int port, int ioWorkerNumber, int processorNumber) {
        this.instance = instance;
        if (instance instanceof IContextListener) {
            listener = ((IContextListener)instance);
        }
        
        this.server = new Server(port, ioWorkerNumber, processorNumber, new RPCObjectRequestHandler());
    }
    
    /**
     * 返回rpc服务器下层实际使用的服务器对象.
     * @return
     */
    public Server getServer() {
        return server;
    }
    
    /**
     * 启动rpc服务器.
     * @throws IOException
     */
    public void start() throws IOException {
        server.start();
    }
    
    /**
     * 停止rpc服务器.
     */
    public void stop() {
        server.stop();
    }
    
    /**
     * 等待服务器退出.
     * @throws InterruptedException
     */
    public void join() throws InterruptedException {
        server.join();
    }
    
    public class RPCObjectRequestHandler implements IRequestHandler, IContextListener {
        
        /**
         * 处理rpc请求.
         */
        public IWritable process(List<IWritable> input, Context ctx, WritableCache writableCache, IoSession session)
                throws Throwable {
            
            Iterator<IWritable> it = input.iterator();
            StringWritable methodNameObj = (StringWritable)it.next();
            String methodName = methodNameObj.get();

            if (server.getVerbose()) {
                LOG.info("process method \"" + methodName + "\" from client " + session.getRemoteAddress());
            }
            
            Object [] params = new Object[input.size()-1];
            Class<?> [] paramTypes = new Class<?> [input.size()-1];
            
            for (int i=0; i<params.length; i++) {
                IWritable o = it.next();
                if (o instanceof ObjectWritable) {
                    params[i] = ((ObjectWritable)o).getObject();
                    paramTypes[i] = ((ObjectWritable)o).getDeclaredClass();
                } else {
                    params[i] = o;
                    paramTypes[i] = o.getClass();
                }
            }
            
            try {
                Method m = instance.getClass().getMethod(methodName, paramTypes);
                RPCThreadState.setState(ctx, session);
                Object result;
                try {
                    result = m.invoke(instance, params);
                } finally {
                    RPCThreadState.removeState();
                }
                if (result != null && result instanceof IWritable) {
                    return (IWritable)result;
                } else {
                    return new ObjectWritable(m.getReturnType(), result);
                }
            } catch(InvocationTargetException e) {
                LOG.log(Level.WARNING, "invoke method \"" + methodName + 
                        "\" failed with args : " + input, e.getTargetException());
                throw e.getTargetException();
            } catch(Throwable e) {
                LOG.log(Level.WARNING, "invoke method \"" + methodName + 
                        "\" failed with args : " + input, e);
                throw e;
            }
        }

        public void onContextCreate(Context context) {
            if (listener != null) {
                listener.onContextCreate(context);
            }
        }

        public void onContextDestroy(Context context) {
            if (listener != null) {
                listener.onContextDestroy(context);
            }
        }
        
    }
    
}
