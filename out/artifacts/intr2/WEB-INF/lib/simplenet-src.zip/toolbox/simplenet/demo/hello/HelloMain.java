/**
 * @(#)HelloMain.java, 2008-4-12. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo.hello;

import toolbox.simplenet.rpc.RPC;
import toolbox.simplenet.rpc.RPCServer;

/**
 *
 * @author river
 *
 */
public class HelloMain {
    
    public static void main(String [] args) throws Exception {
        if (args.length < 1) {
            System.out.println("args: port");
            return;
        }
        
        int port = Integer.parseInt(args[0]);
        HelloImpl impl = new HelloImpl();
        RPCServer server = RPC.createServer(impl, port);
        server.start();
        server.join();
    }
    
}
