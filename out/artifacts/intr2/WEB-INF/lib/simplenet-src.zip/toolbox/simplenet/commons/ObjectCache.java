/**
 * @(#)PackCache.java, 2008-3-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 请求数据缓存，用于减少请求读写中的中间数据量.
 * 
 * @author river
 *
 */
public abstract class ObjectCache<V> {
    
    // 由于缓存并没有检查进入缓存的对象是否重复，如果放入了重复的对象，会引起无法预知的错误，
    // 因此，设置了这个开关，可以在测试过程中打开这个开关，对于每个放入的对象进行检查
    private static final boolean DUP_CHECK = false;
    
    private ConcurrentLinkedQueue<V> freeList = new ConcurrentLinkedQueue<V>();
    private int maxSize = Integer.MAX_VALUE;
    
    
    public ObjectCache() {}
    
    public ObjectCache(int maxSize) { this.maxSize = maxSize; }
    
    /**
     * 创建一个新的数据实例.
     * @return
     */
    abstract public V createInstance();

    /**
     * Clear the instance before cached.
     * @param v
     */
    public void clearInstance(V v) {
        
    }
    
    /**
     * 从缓存中取出一个缓存对象，或者当缓存为空的时候创建一个新的缓存对象.
     * @return
     */
    public V acquire() {
        V obj = freeList.poll();
        if (obj == null) {
            obj = createInstance();
        }
        return obj;
    }
    
    /**
     * 释放一个对象到缓存.
     * @param obj
     */
    public void release(V obj) {
        
        if (DUP_CHECK) {
            for (V o : freeList) {
                if (o == obj) {
                    throw new RuntimeException("duplicate release of object : " + 
                            obj.hashCode() + " : " + obj);
                }
            }
        }
        
        if (freeList.size() < maxSize) {
            clearInstance(obj);
            freeList.add(obj);
        }
    }

}
