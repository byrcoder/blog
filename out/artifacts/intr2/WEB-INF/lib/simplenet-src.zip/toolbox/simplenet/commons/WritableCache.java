/**
 * @(#)WritableCacheMap.java, 2008-3-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.HashMap;

import odis.serialize.IWritable;
import toolbox.misc.ClassUtils;

/**
 * Writable对象的缓存.
 * @author river
 *
 */
public class WritableCache {
    private HashMap<Class<? extends IWritable>, ObjectCache<IWritable>> map = 
        new HashMap<Class<? extends IWritable>, ObjectCache<IWritable>>();
    
    /**
     * 注册一个需要cache的writable类型，以及cache的大小（对象个数）.这个方法
     * 需要在初始化的时候调用，在运行过程中调用可能会导致不可预期的错误，因为考虑到性能
     * 的要求，这里没有考虑多线程访问的情况.
     * 
     * @param clazz
     * @param cacheSize
     */
    public void registerCache(Class<? extends IWritable> clazz, int cacheSize) {
        map.put(clazz, new WritableObjCache(clazz, cacheSize));
    }
    
    /**
     * 直接注册一个实例化的writable的cache.
     * @param clazz
     * @param cache
     */
    public void registerCache(Class<? extends IWritable> clazz, ObjectCache<IWritable> cache) {
        map.put(clazz, cache);
    }
    
    /**
     * 返回一个对象类型的实例，如果注册了这个类型的cache并且cache中有数据，会
     * 返回cache中的对象，否则，返回一个新的实例.
     * @param clazz
     * @return
     */
    public IWritable acquire(Class<? extends IWritable> clazz) {
        ObjectCache<IWritable> cache = map.get(clazz);
        if (cache == null) {
            return (IWritable)ClassUtils.newInstance(clazz);
        } else {
            return cache.acquire();
        }
    }

    /**
     * 释放一个对象到cache中，如果对应的cache没有注册，什么也不做.
     * @param v
     */
    public void release(IWritable v) {
        ObjectCache<IWritable> cache = map.get(v.getClass());
        if (cache != null) {
            cache.release(v);
        }
    }
    
    /**
     * 实际的基于{@link ObjectCache}的writable cache实现.
     * @author river
     */
    private static class WritableObjCache extends ObjectCache<IWritable> {
        private Class<? extends IWritable> clazz;
        
        public WritableObjCache(Class<? extends IWritable> clazz, int maxSize) {
            super(maxSize);
            this.clazz = clazz;
        }

        @Override
        public IWritable createInstance() {
            try {
                return clazz.newInstance();
            } catch(Exception e) {
                throw new RuntimeException("cannot create instance of " + clazz, e);
            }
        }
    }
    
}
