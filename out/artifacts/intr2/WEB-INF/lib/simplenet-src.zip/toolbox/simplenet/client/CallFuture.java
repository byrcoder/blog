/**
 * @(#)CallFuture.java, 2008-3-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.client;

import toolbox.simplenet.commons.BasicFuture;

/**
 * 请求状态的future类型.
 * 
 * @author river
 *
 */
public class CallFuture extends BasicFuture {
    
    protected long createTime = System.currentTimeMillis();
    
    public long getCreateTime() {
        return createTime;
    }
    
    public static class DefaultCallFutureFactory implements ICallFutureFactory {
        
        private static ICallFutureFactory instance = new DefaultCallFutureFactory();
        public static ICallFutureFactory getInstance() {
            return instance;
        }
        
        private DefaultCallFutureFactory() {}
        
        public CallFuture create() {
            return new CallFuture();
        }
        
    }
}
