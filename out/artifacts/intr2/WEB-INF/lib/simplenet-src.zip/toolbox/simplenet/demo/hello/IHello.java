/**
 * @(#)IHello.java, 2008-4-12. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo.hello;

import toolbox.simplenet.rpc.RPCException;

/**
 * Hello服务的接口.
 * @author river
 *
 */
public interface IHello {
    
    /**
     * 返回"Hello ${name}!".
     * @param name
     * @return
     * @throws RPCException
     */
    public String hello(String name) throws RPCException;
    
    /**
     * 不带名字的hello接口，应该返回"Hello ${name}!"，其中name是上次hello的时候记住的.
     * @return
     * @throws RPCException
     */
    public String hello() throws RPCException;
    
}
