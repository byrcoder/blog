/**
 * @(#)RPCTimeException.java, 2008-4-6. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;


/**
 * 当RPC调用timeout的时候抛出这个exception，对应于{@link CallTimeoutException}.
 * 
 * @author river
 *
 */
public class RPCTimeoutException extends RPCException {

    private static final long serialVersionUID = 98245582986561422L;

    public RPCTimeoutException(String message) {
        super(message);
    }
    
    public RPCTimeoutException(Throwable cause) {
        super(cause);
    }
    
    public RPCTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
