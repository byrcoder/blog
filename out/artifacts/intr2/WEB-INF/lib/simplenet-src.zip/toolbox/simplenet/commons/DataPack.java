/**
 * @(#)DataPack.java, 2008-3-31. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.LinkedList;
import java.util.List;

import odis.serialize.IWritable;

/**
 * 中间数据传输中使用的数据结构，保存了请求的sequence number以及实际传输的writable对象列表.
 * @author river
 *
 */
public class DataPack {

    private long seq = -1;
    
    // pay load length is used during message decode
    private int payLoadLength = -1;
    
    private LinkedList<IWritable> list = new LinkedList<IWritable>();

    /**
     * 清空writable对象列表.
     */
    public void clear() {
        seq = -1;
        payLoadLength = -1;
        list.clear();
    }
    
    public int getPayloadLength() {
        return payLoadLength;
    }
    
    public void setPayloadLength(int v) {
        this.payLoadLength = v;
    }
    
    /**
     * 返回sequence number.
     * @return
     */
    public long getSequenceNumber() {
        return seq;
    }
    
    /**
     * 设置sequence number.
     * @param v
     */
    public void setSequenceNumber(long v) {
        this.seq = v;
    }
    
    /**
     * 加入一个writable对象到列表.
     * @param obj
     */
    public void add(IWritable obj) {
        list.add(obj);
    }
    
    /**
     * 返回writable对象列表.
     * @return
     */
    public List<IWritable> getWritableList() {
        return list;
    }
    
    /**
     * 返回数据列表中的第一个数据.
     * @return
     */
    public IWritable first() {
        return list.getFirst();
    }
    
    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        buf.append("[").append(seq).append("]").append(list);
        return buf.toString();
    }
    
}
