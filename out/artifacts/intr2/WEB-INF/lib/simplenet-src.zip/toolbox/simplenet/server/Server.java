/**
 * @(#)Server.java, 2008-3-27. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.filter.LoggingFilter;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;

import toolbox.misc.LogFormatter;
import toolbox.simplenet.commons.NamedThreadFactory;
import toolbox.simplenet.commons.WritableCache;
import toolbox.simplenet.commons.WritableCodecFactory;
import toolbox.simplenet.commons.WritableIdDef;

/**
 * 基于mina的服务器框架，可以通过非常简单的方法实现一个支持异步访问的服务器.服务器
 * 的主要逻辑通过{@link IRequestHandler}来实现，在已经实现了一个RequestHandler
 * 的情况下，通过如下代码就可以创建一个服务器实例:
 * <code>
 *   RequestHandler handler = ...;
 *   ...
 *   int concurrent = 5; // 处理请求的线程池大小为5
 *   Server server = new Server(port, concurrent, handler);
 *   server.start();
 * </code>  
 * 需要注意的是，服务器的所有线程都是daemon线程，所以在没有其他线程的情况下，虚拟机会
 * 终止，可以通过如下代码一直运行服务器:
 * <code>
 *   server.join();
 * </code>
 * 
 * @author river
 *
 */
public class Server implements ServerMBean {
    private static final Logger LOG = LogFormatter.getLogger(Server.class);
    
    private int port;
    private int processorNumber;
    private int ioWorkerNumber;
    private IoAcceptor acceptor;
    private boolean terminated;
    private IRequestHandler handler;
    private WritableIdDef idDef = new WritableIdDef();
    
    private boolean verbose = true;
    private boolean noContext = false;
    
    private WritableCache writableCache = new WritableCache();
    private ContextManager contextManager = new ContextManager();
    
    private LinkedBlockingQueue<Runnable> requestQueue;
    private ThreadPoolExecutor processThreadPool;
    
    /**
     * Create server at given port, and the process number and instance. 
     * @param port
     * @param processorNumber
     * @param instance
     */
    public Server(int port, int processorNumber, IRequestHandler handler) {
        this(port, 1, processorNumber, handler);
    }
    
    public Server(int port, int ioWorkerNumber, int processorNumber, IRequestHandler handler) {
        this.port = port;
        this.ioWorkerNumber = ioWorkerNumber;
        this.processorNumber = processorNumber;
        this.handler = handler;
    }

    /**
     * 设置在传输过程中使用的writable类型的byte表示映射，在这里存在映射的类型可以避免传输类名，从而
     * 减少传输的数据量.
     * 这个方法不被调用的情况下，使用默认的实现，能够支持odis.serialize.lib下的基本数据类型.
     * 这个设置只有在{@link #start()}调用以前做才生效.
     * @param idDef
     */
    public void setWritableIdDef(WritableIdDef idDef) {
        this.idDef = idDef;
    }
    
    /**
     * 设置是否记录连接的日志，默认情况下日志是打开的.
     * 这个设置只有在{@link #start()}调用以前才生效.
     * @param v
     */
    public void setVerbose(boolean v) {
        verbose = v;
    }
    
    /**
     * 得到是否记录详细连接信息的开关.
     * @return
     */
    public boolean getVerbose() {
        return verbose;
    }

    /**
     * 设置是否在处理请求过程中不需要context，也就是服务器一定是一个无状态的服务器.
     * Context的创建和释放会引入一些开销，无状态的服务器可以通过设置no context为
     * true来避免这个开销，默认为false.
     * @param v
     */
    public void setNoContext(boolean v) {
        this.noContext = v;
    }
    
    /**
     * 设置传输过程中使用的writable对象的cache，如果不设置，就不
     * 这个设置只有在{@link #start()}调用以前做才生效.
     * cache任何对象.
     * @param cache
     */
    public void setWritableCache(WritableCache cache) {
        this.writableCache = cache;
    }
    
    /**
     * 启动服务器，开始监听指定的端口.
     * @throws IOException
     */
    public synchronized void start() throws IOException {
        // Create acceptor
        acceptor = new SocketAcceptor(ioWorkerNumber, new AcceptorExecutor());

        // Prepare the configuration
        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
        cfg.setReuseAddress(true);
        cfg.getSessionConfig().setTcpNoDelay(true);
        
        if (verbose)
            cfg.getFilterChain().addLast("logger", new LoggingFilter());
        
        WritableCodecFactory codecFactory = 
            new WritableCodecFactory(writableCache, 
                    idDef, true);
        
        cfg.getFilterChain().addLast(
                "codec",
                new ProtocolCodecFilter(codecFactory));

        // use our own thread pool
        cfg.setThreadModel(ThreadModel.MANUAL);
        
        requestQueue = new LinkedBlockingQueue<Runnable>();
        processThreadPool = new ThreadPoolExecutor(processorNumber, processorNumber,
                0L, TimeUnit.MILLISECONDS,
                requestQueue,
                new NamedThreadFactory("processThread", true));

        // register context listener if available
        if (handler instanceof IContextListener) {
            contextManager.setContextListener((IContextListener)handler);
        }
        contextManager.setVerbose(verbose);
        
        // Bind
        ServerHandler serverHandler = new ServerHandler(
                handler,
                processThreadPool,
                contextManager, 
                writableCache);
        serverHandler.setNoContext(noContext);
        
        acceptor.bind(new InetSocketAddress(port), serverHandler, cfg);
        
        this.terminated = false;
        
        // register to jmx
        try {
            MBeanServer mbeanServer = ManagementFactory.getPlatformMBeanServer();
            mbeanServer.registerMBean(this, 
                    new ObjectName("toolbox.simplenet.server:type=Server,id=server-" + port));
        } catch(Exception e) {
            LOG.log(Level.WARNING, "register server mbean failed, no jmx support for this server", e);
        }
        
    }
    
    /**
     * Stop the executor of server, which call the shutdown() method.
     */
    public synchronized void stop() {
        acceptor.unbindAll();
        terminated = true;
        
        try {
            MBeanServer mbeanServer = ManagementFactory.getPlatformMBeanServer();
            mbeanServer.unregisterMBean(
                    new ObjectName("toolbox.simplenet.server:type=Server,id=server-" + port));
        } catch(Exception e) {
            LOG.log(Level.WARNING, "unregister server mbean failed", e);
        }
        
        this.notifyAll();
    }
    
    /**
     * Waiting for the server to stop.
     */
    public synchronized void join() throws InterruptedException {
        while (!terminated) {
            this.wait();
        }
    }
    
    public ContextManager getContextManager() {
        return contextManager;
    }
    
    /**
     * 这个executor为每个不同的acceptor提供了一个独立的名字.
     * @author river
     *
     */
    private static class AcceptorExecutor implements Executor {
        private AtomicInteger id = new AtomicInteger(0);
        
        public void execute(Runnable command) {
            Thread t = new Thread(command, "ioworker-" + id.getAndAdd(1));
            t.setDaemon(true);
            t.start();
        }
    }
    
    /**************************************************/
    /** MBean interface                              **/
    /**************************************************/

    public int getContextCount() {
        return contextManager.getContextCount();
    }

    public int getPort() {
        return port;
    }

    public int getRequestQueueSize() {
        return requestQueue.size();
    }

}
