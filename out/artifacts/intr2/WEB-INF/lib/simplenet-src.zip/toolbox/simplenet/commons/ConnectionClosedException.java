/**
 * @(#)ConnectionClosedException.java, 2008-7-31. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

/**
 * 下层连接被关闭导致请求失败的exception.
 * @author river
 *
 */
public class ConnectionClosedException extends CallException {

    private static final long serialVersionUID = -1866657865542914447L;

    public ConnectionClosedException(String message) {
        super(message);
    }
    
    public ConnectionClosedException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public ConnectionClosedException(Throwable cause) {
        super(cause);
    }
}
