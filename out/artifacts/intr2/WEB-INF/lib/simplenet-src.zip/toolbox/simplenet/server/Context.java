/**
 * @(#)Context.java, 2007-10-15. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

import java.util.HashMap;
import java.util.HashSet;

import org.apache.mina.common.IoSession;

import toolbox.simplenet.client.Client;


/**
 * 连接上下文，每个context对应于一个{@link Client}. context
 * 本身是一个hash表，可以用于保存连接状态数据.
 * 
 * @author river
 *
 */
public class Context extends HashMap<Object, Object> {

    private static final long serialVersionUID = -3215504911435654902L;
    
    private String name;
    private Object sessions;
    
    /**
     * 创建一个指定名字的context.
     * @param name
     */
    Context(String name) {
        this.name = name;
    }
    
    /**
     * 返回context的名字.
     * @return
     */
    public String getName() {
        return name;
    }
    
    /**
     * 返回context中当前的连接个数.
     * @return
     */
    public synchronized int getSessionCount() {
        if (sessions == null) return 0;
        if (sessions instanceof HashSet) {
            return ((HashSet)sessions).size();
        } else {
            return 1;
        }
    }
    
    /**
     * 返回context中的一个连接. 我们并不保证这个连接一定是第一个创建的连接.
     * @return
     */
    @SuppressWarnings("unchecked")
    public synchronized IoSession getSession() {
        if (sessions == null) return null;
        
        if (sessions instanceof IoSession) {
            return (IoSession)sessions;
        } else {
            return ((HashSet<IoSession>) sessions).iterator().next();
        }
    }

    /**
     * 返回context中所有的连接.
     * @return
     */
    @SuppressWarnings("unchecked")
    public synchronized IoSession [] getSessions() {
        if (sessions == null) return new IoSession[0];
        
        if (sessions instanceof IoSession) {
            return new IoSession[]{(IoSession)sessions};
        } else {
            HashSet<IoSession> set = (HashSet<IoSession>) sessions; 
            return set.toArray(new IoSession[set.size()]);
        }
    }

    @SuppressWarnings("unchecked")
    synchronized void addSession(IoSession session) {
        if (sessions == null) {
            sessions = session;
        } else if (sessions instanceof IoSession) {
            HashSet<IoSession> set = new HashSet<IoSession>();
            set.add((IoSession)sessions);
            sessions = set;
        } else {
            ((HashSet<IoSession>)sessions).add(session);
        }
    }
    
    @SuppressWarnings("unchecked")
    synchronized void removeSession(IoSession session) {
        if (sessions != null) {
            if (sessions == session) sessions = null;
            else if (sessions instanceof HashSet) {
                ((HashSet<IoSession>)sessions).remove(session);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    synchronized boolean containsSession(IoSession session) {
        if (sessions != null) {
            if (sessions == session) return true;
            if (sessions instanceof HashSet) {
                return ((HashSet<IoSession>)sessions).contains(session);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
 
}
