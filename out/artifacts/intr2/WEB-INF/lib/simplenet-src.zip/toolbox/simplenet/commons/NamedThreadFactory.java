/**
 * @(#)DaemonThreadFactory.java, 2007-10-10. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ThreadFactory implementation which set the thread name
 * and daemon option.
 * 
 * @author river
 *
 */
public class NamedThreadFactory implements ThreadFactory {
    private AtomicInteger id = new AtomicInteger(0);
    private String namePrefix;
    private boolean daemon;
    
    /**
     * Create a thread factory which create thread with name like <code>{namePrefix}-0</code>.
     * The daemon state of new created thread is set by argument <code>daemon</code>.  
     * @param namePrefix
     * @param daemon
     */
    public NamedThreadFactory(String namePrefix, boolean daemon) {
        this.namePrefix = namePrefix;
        this.daemon = daemon;
    }
    
    /**
     * Create a thread for given runnable instance.
     */
    public Thread newThread(Runnable r) {
        int currentId = id.getAndAdd(1);
        String name = namePrefix + "-" + currentId;
        Thread thread = new Thread(r, name);
        thread.setDaemon(daemon);
        return thread;
    }

}
