/**
 * @(#)LocalInvoker.java, 2008-8-21. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import toolbox.simplenet.client.ICallFinishListener;
import toolbox.simplenet.commons.BasicFuture;
import toolbox.simplenet.commons.IFuture;
import toolbox.simplenet.commons.NamedThreadFactory;

/**
 * 虚拟机内部的异步调用工具，由于 {@link LocalInvoker}和RPCClient一样实现了 {@link IAsyncRPCCall}
 * 的接口，可以允许上层应用不区分下层是本地接口还是远程接口.
 * 
 * @author river
 *
 */
public class LocalInvoker implements IAsyncRPCCall {
    private Object instance;
    private ExecutorService threadPool;
    
    /**
     * 创建一个指定对象的异步调用工具类，参数<code>concurrency</code>决定
     * 了异步调用的并发度.
     * 
     * @param instance
     * @param concurrency
     */
    public LocalInvoker(Object instance, int concurrency) {
        this.instance = instance;
        this.threadPool = Executors.newFixedThreadPool(concurrency, 
                new NamedThreadFactory("localinvoker-" + 
                        instance.getClass().getSimpleName(), true));
    }
    
    /**
     * 异步调用指定的方法. 需要注意的是，这里的调用实际上就是在另外的函数中调用这个方法，
     * 所以，需要考虑参数的多线程访问特性.
     */
    public IFuture invoke(Method method, Object... args) {
        return invoke(method, null, args);
    }
    
    /**
     * 异步调用指定的方法. 需要注意的是，这里的调用实际上就是在另外的函数中调用这个方法，
     * 所以，需要考虑参数的多线程访问特性.
     */
    public IFuture invoke(Method method, ICallFinishListener listener, Object... args) {
        BasicFuture future = new BasicFuture();
        Call call = new Call(method, args, future);
        threadPool.submit(call);
        return future;
    }

    private class Call implements Runnable {
        private Method method;
        private Object [] params;
        private BasicFuture future;
        
        public Call(Method method, Object [] params, BasicFuture future) {
            this.method = method;
            this.params = params;
            this.future = future;
        }
        
        public void run() {
            try {
                Object result = method.invoke(instance, params);
                future.setDone(null, result);
            } catch(InvocationTargetException e) {
                future.setDone(e.getTargetException(), null);
            } catch(Throwable e) {
                future.setDone(e, null);
            }
        }
    }
    
}
