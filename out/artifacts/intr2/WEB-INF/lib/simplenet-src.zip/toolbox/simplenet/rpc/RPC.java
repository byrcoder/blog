/**
 * @(#)RPC.java, 2008-4-7. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.lang.reflect.Method;
import java.net.InetSocketAddress;

import toolbox.simplenet.client.Client;

/**
 * RPC Utilities.
 * @author river
 *
 */
public class RPC {

    /**
     * 创建一个只有一个i/o线程，一个处理线程的rpc服务器.
     * @param instance
     * @param port
     * @return
     */
    public static RPCServer createServer(Object instance, int port) {
        return new RPCServer(instance, port);
    }
    
    /**
     * 创建一个rpc服务器，并且指定处理线程的个数，以及是否输出详细的日志信息. 这里采用的i/o(select)的线程数
     * 是1，也就是说，所有的连接用一个selector进行select.
     * 一般情况下，当连接数不是很多的时候，一个selector应该是够用的.
     * 
     * @param instance
     * @param port
     * @param processorNumber
     * @param verbose
     * @return
     */
    public static RPCServer createServer(Object instance, int port, int processorNumber, boolean verbose) {
        return createServer(instance, port, 1, processorNumber, verbose);
    }
    
    /**
     * 创建一个rpc服务器，指定用于i/o(select)的线程数(也就是selector的数目)，处理请求的句柄(线程)个数，
     * 以及是否打印详细的连接日志.
     * 
     * @param instance
     * @param port
     * @param ioWorkerNumber
     * @param processorNumber
     * @param verbose
     * @return
     */
    public static RPCServer createServer(Object instance, int port, int ioWorkerNumber, int processorNumber, boolean verbose) {
        RPCServer server = new RPCServer(instance, port, ioWorkerNumber, processorNumber);
        server.getServer().setVerbose(verbose);
        return server;
    }
    
    /**
     * 打开一个rpc client连接，并且返回对应的接口实现. 
     * rpc调用的默认超时时间是Long.MAX_VALUE，也就是永远不会超时.
     * 
     * @param <T>
     * @param addr
     * @param protocol
     * @return
     * @throws RPCException
     */
    public static <T> T getProxy(InetSocketAddress addr, Class<T> protocol) throws RPCException {
        return getProxy(addr, protocol, 1, Long.MAX_VALUE);
    }
    
    /**
     * 打开一个rpc client连接，指定rpc调用的超时时间，并且返回对应的接口实现.
     * 需要注意的是，每次调用这个方法都会创建新的客户端，即使使用同一个地址.
     * @param <T>
     * @param addr
     * @param protocol
     * @param connectionCount
     * @param callTimeout
     * @return
     * @throws RPCException
     */
    public static <T> T getProxy(InetSocketAddress addr, Class<T> protocol, 
            int connectionCount, long callTimeout) throws RPCException {
        RPCClient client = new RPCClient(addr, connectionCount, 
                Client.DEFAULT_CONNECT_TIMEOUT, Client.DEFAULT_WRITE_TIMEOUT, callTimeout);
        client.open();
        return client.getProxy(protocol);
    }
    
    /**
     * 释放一个proxy对象，关闭下层的连接.
     * @param proxyInstance
     */
    public static void closeProxy(Object proxyInstance) {
        if (!(proxyInstance instanceof RPCClient.IRPCClientCommon)) {
            throw new RuntimeException("invalid proxy instance : " + proxyInstance);
        }
        ((RPCClient.IRPCClientCommon)proxyInstance).__close();
    }
    
    /**
     * 检查rpc接口的方法是否都抛出了{@link RPCException}.
     * @param cls
     * @return
     */
    public static void validateRPCInterface(Class<?> protocol) throws ClassCastException {
        Method[] ms = protocol.getMethods();
        
        for (int i = 0; i < ms.length; i++) {
            Method m = ms[i];
            Class<?>[] ex = m.getExceptionTypes();
            boolean valid = false;
            for (int j = 0; j < ex.length; j++) {
                if (ex[j].isAssignableFrom(RPCException.class)) {
                    valid = true;
                    break;
                }
            }
            
            if (!valid) {
                StringBuilder exBuf = new StringBuilder();
                exBuf.append("<");
                for (Class<?> c : ex) {
                    exBuf.append(c.getName()).append(",");
                }
                exBuf.append(">");
                throw new ClassCastException("Method " + m.getName()
                        +"(...) of RPC interface "+ protocol +
                        " is not declared as throwing " +
                        "RPCException( available exception is " + 
                        exBuf.toString() + "). Please fix that.");
            }
        }
    }
    
}
