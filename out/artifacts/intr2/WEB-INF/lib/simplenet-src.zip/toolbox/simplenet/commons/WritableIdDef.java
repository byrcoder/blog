/**
 * @(#)WritableIdDef.java, 2008-3-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.lib.BlobWritable;
import odis.serialize.lib.BooleanWritable;
import odis.serialize.lib.ByteWritable;
import odis.serialize.lib.BytesWritable;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.FloatWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.IntsWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.LongsWritable;
import odis.serialize.lib.NullWritable;
import odis.serialize.lib.ObjectWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.StringsWritable;
import odis.serialize.lib.UTF16Writable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.lib.Url;

/**
 * 用于将writable的类型映射成为id，从而避免在数据传输中传输类名，以期减少流量.
 * 
 * @author river
 *
 */
public class WritableIdDef {
    private Map<Class<? extends IWritable>, Byte> idMap = 
        new HashMap<Class<? extends IWritable>, Byte>();
    
    private Map<Byte, Class<? extends IWritable>> byteToClassMap = 
        new HashMap<Byte, Class<? extends IWritable>>();
    
    private byte lastId = 1;
    
    public WritableIdDef() {
        def(IntWritable.class);
        def(ByteWritable.class);
        def(LongWritable.class);
        def(NullWritable.class);
        def(StringWritable.class);
        def(UTF8Writable.class);
        def(UTF16Writable.class);
        def(Url.class);
        def(IntsWritable.class);
        def(BooleanWritable.class);
        def(FloatWritable.class);
        def(DoubleWritable.class);
        def(StringsWritable.class);
        def(LongsWritable.class);
        def(BytesWritable.class);
        def(BlobWritable.class);
        def(ObjectWritable.class);
    }
    
    public WritableIdDef def(Class<? extends IWritable> cls) {
        if (!idMap.containsKey(cls)) {
            byte id = lastId++;
            idMap.put(cls, id);
            byteToClassMap.put(id, cls);
        }
        return this;
    }

    public Class<? extends IWritable> getClass(int id) {
        return byteToClassMap.get((byte)id);
    }
    
    public byte getId(Class<? extends IWritable> cls) {
        Byte obj = idMap.get(cls);
        if (obj == null) return -1;
        else return obj;
    }
    
}
