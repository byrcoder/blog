/**
 * @(#)IContextListener.java, 2008-4-7. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;


/**
 * 监听context创建和释放事件的接口.
 * 
 * @author river
 *
 */
public interface IContextListener {

    /**
     * context被创建的事件.
     * @param context
     */
    public void onContextCreate(Context context);
    
    /**
     * Context被释放的事件.
     * @param context
     */
    public void onContextDestroy(Context context);
    
}
