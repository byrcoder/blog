/**
 * @(#)EchoService.java, 2008-4-1. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.demo;

import java.util.List;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

import org.apache.mina.common.IoSession;

import toolbox.simplenet.commons.WritableCache;
import toolbox.simplenet.server.Context;
import toolbox.simplenet.server.IRequestHandler;

/**
 * 将所有的输入的对象串联起来并且返回的测试服务器.
 * 
 * @author river
 *
 */
public class EchoService implements IRequestHandler {

    public IWritable process(List<IWritable> input, Context ctx, WritableCache writableCache, IoSession session)
            throws Throwable {
        StringBuilder buf = new StringBuilder();
        for (IWritable o : input) {
            buf.append(o);
        }
        StringWritable str = (StringWritable)writableCache.acquire(StringWritable.class);
        str.set(buf.toString());
        return str;
    }
    
}
