/**
 * @(#)WritableCodecFactory.java, 2008-3-29. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.commons;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.IWritable;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoSession;
import org.apache.mina.filter.codec.CumulativeProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;

import toolbox.misc.LogFormatter;
import toolbox.simplenet.server.Server;

/**
 * 按照数据传输协议进行数据的encode和decode.
 * 
 * <strong>传输协议</strong>
 * 客户端和服务器之间的数据传输协议如下:
 * REQUEST = REQ_SEQ(long) REQ_LEN(int) REQ_DATA
 * (RESPONSE = REQ_SEQ(long) RES_LEN(int) RES_DATA)
 * REQ_DATA = OBJ_COUNT(int) OBJ*
 * 
 * 其中各个域定义如下:
 * <ul>
 * <li>REQ_SEQ : 请求的序列号，一个用于区分不同的请求的long(64bits). 所有的序列号都是大于等于0的，除了
 * 一个特殊用途的-1. 序列号为-1标记了这个请求是一个conection-bind请求，也就是说将这个请求bind到某个context
 * 上. 关于Context参考{@link Server} 的说明.
 * <li>REQ_LEN : 请求的数据长度，也就是REQ_DATA的byte数，是一个int(32bits).
 * <li>REQ_DATA : 请求的数据，是一个writable对象的列表.
 * </ul>
 * 
 * <strong>字节序</strong><p>
 * 在对象序列化过程中，虽然直接使用了IWritable，但是由于性能问题，这里采用的传输的字节序目前是java默认的字节序(
 * 高位在前)，这个和odis里面DataInputBuffer/DataOutputBuffer使用的字节序是不同的.
 * 
 * 
 * @author river
 *
 */
public class WritableCodecFactory implements ProtocolCodecFactory {
    public static final Logger LOG = LogFormatter.getLogger(WritableCodecFactory.class);
    private static final int LONG_BYTES = Long.SIZE/Byte.SIZE;
    private static final int INT_BYTES = Integer.SIZE/Byte.SIZE;
    
    private static final int HEADER_LEN = LONG_BYTES + INT_BYTES;
    
    public static final String REQUEST_PACK_KEY = "__request_pack_";
    
    private WritableCache writableCache;
    
    private WritableIdDef idDef;
    private boolean cacheWritable;
    
    /**
     * 构造一个codec factory，并且初始化所有的cache. 需要注意的是cacheWritable开关，在server
     * 中，这个开关应该是true，以便自动release所有的中间对象到cache中；而在client中，由于writable
     * 对象的产生和使用都不在框架中，所以这个开关应该是false.
     * 
     * @param writableCache
     * @param packCache
     * @param idDef
     * @param cacheWritable
     */
    public WritableCodecFactory(WritableCache writableCache, WritableIdDef idDef, 
            boolean cacheWritable) {
        this.writableCache = writableCache;
        this.idDef = idDef;
        this.cacheWritable = cacheWritable;
    }
    
    public ProtocolDecoder getDecoder() throws Exception {
        return new WritableProtocolDecoder();
    }

    public ProtocolEncoder getEncoder() throws Exception {
        return new WritableProtocolEncoder();
    }

    public class WritableProtocolDecoder extends CumulativeProtocolDecoder {
        
        @SuppressWarnings("unchecked")
        @Override
        protected boolean doDecode(IoSession session, ByteBuffer in,
                ProtocolDecoderOutput out) throws Exception {
            DataPack decodeState = (DataPack)session.getAttachment();
            if (decodeState == null) {
                decodeState = new DataPack();
                session.setAttachment(decodeState);
            }

            ByteBufferInput ibuf = new ByteBufferInput(in);
            // read header
            if (decodeState.getPayloadLength() < 0) {
                if (in.remaining() < HEADER_LEN) {
                    return false;
                } else {
                    decodeState.setSequenceNumber(ibuf.readLong());
                    decodeState.setPayloadLength(ibuf.readInt());
                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.log(Level.FINE, System.currentTimeMillis() + " [" +
                                session.getLocalAddress() + "-" +
                                session.getRemoteAddress() + "] received pack " + 
                                decodeState.getSequenceNumber());
                    }
                }
            }

            if (decodeState.getPayloadLength() >= 0) {
                if (in.remaining() < decodeState.getPayloadLength()) {
                    return false;
                }
            }

            int objCount = ibuf.readInt();
            for (int i=0; i<objCount; i++) {
                byte clsId = ibuf.readByte();
                Class<? extends IWritable> cls;
                if (clsId == -1) {
                    String classname = ibuf.readAsciiString();
                    try {
                        cls = (Class<? extends IWritable>)Class.forName(classname);
                    } catch(Exception e) {
                        throw new RuntimeException("load class " + classname + " failed", e);
                    }
                } else {
                    cls = idDef.getClass(clsId);
                }

                IWritable instance = writableCache.acquire(cls);
                instance.readFields(ibuf);
                decodeState.add(instance);
            }

            // output the request and record pack for cache release during output
            session.setAttachment(null);
            out.write(decodeState);

            return true;
            
        }

    }
    
    public class WritableProtocolEncoder implements ProtocolEncoder {
        
        public void encode(IoSession session, Object message,
                ProtocolEncoderOutput out) throws Exception {

            // encode the response pack to buffer
            DataPack pack = (DataPack) message;
            ByteBuffer buf = ByteBuffer.allocate(1024).setAutoExpand(true);
            ByteBufferOutput obuf = new ByteBufferOutput(buf);
            // write sequence
            obuf.writeLong(pack.getSequenceNumber());

            // lead space for payload length
            int lenPos = buf.position();
            obuf.writeInt(0);
                
            // write the payload
            List<IWritable> list = pack.getWritableList();
            obuf.writeInt(list.size());
            for (IWritable obj : list) {
                byte clsId = idDef.getId(obj.getClass());
                obuf.writeByte(clsId);
                if (clsId == -1) {
                    obuf.writeAsciiString(obj.getClass().getName());
                }
                obj.writeFields(obuf);
            }
            
            // fill the payload length
            int lastPos = buf.position();
            buf.position(lenPos);
            obuf.writeInt(lastPos - HEADER_LEN);
            buf.position(lastPos);

            buf.flip();
            out.write(buf);
            
            if (LOG.isLoggable(Level.FINE)) {
                LOG.log(Level.FINE, System.currentTimeMillis() + " [" + 
                        session.getLocalAddress() + "-" + session.getRemoteAddress() + 
                        "] sent pack " + pack.getSequenceNumber());
            }
            
            // release output objects into object cache
            if (cacheWritable) {
                for (IWritable obj : pack.getWritableList()) {
                    writableCache.release(obj);
                }
            }
            
            // release the request data
            DataPack requestPack = (DataPack) session.removeAttribute(REQUEST_PACK_KEY);
            if (requestPack != null) {
                if (cacheWritable) {
                    for (IWritable obj : requestPack.getWritableList()) {
                        writableCache.release(obj);
                    }
                }
            }
            
        }
        
        public void dispose(IoSession session) throws Exception {
        }

    }
    
}
