/**
 * @(#)RequestHandler.java, 2008-3-27. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

import java.util.List;

import org.apache.mina.common.IoSession;

import odis.serialize.IWritable;
import toolbox.simplenet.commons.WritableCache;

/**
 * 任务处理的接口，处理输入的数据（IWritable对象），得到输出的数据（IWritable对象）.
 * @author river
 *
 */
public interface IRequestHandler {

    /**
     * 处理输入的请求数据，并且产生输出的数据. 这个方法是会被多个线程同时调用的，所以
     * 实现代码必须保证线程安全. 如果我们需要在连接上保存一些数据，可以保存在context中，
     * 一个实际的例子就是缓存输出使用的IWritable.
     * 
     * 如果处理过程中发现比较严重的错误，需要中断当前的连接，抛出{@link SessionFatalException}，
     * 这个exception不会被返回给客户端，而是直接中断当前的连接.
     * 
     * @param request
     * @param ctx 一个保存连接上状态的hash表，当服务器无状态的时候，这个值为null
     * @param writableCache writable的对象池
     * @param session 当前的连接
     * @return
     * @throws SessionFatalException
     */
    public IWritable process(List<IWritable> input, Context ctx, WritableCache writableCache, IoSession session) throws Throwable;

}
