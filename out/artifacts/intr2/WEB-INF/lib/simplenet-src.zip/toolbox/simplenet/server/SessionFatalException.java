/**
 * @(#)RequestProcessException.java, 2008-3-27. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.server;

/**
 * 在任务处理过程中可能抛出的exception，该exception会中断当前的网络连接，而不是被
 * 返回给客户端.
 * 
 * @author river
 *
 */
@SuppressWarnings("serial")
public class SessionFatalException extends RuntimeException {

    public SessionFatalException() {}
    
    public SessionFatalException(String message) {
        super(message);
    }
    
    public SessionFatalException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
