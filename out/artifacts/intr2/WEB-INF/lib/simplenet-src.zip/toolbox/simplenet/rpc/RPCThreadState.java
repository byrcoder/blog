/**
 * @(#)ThreadState.java, 2008-4-7. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.simplenet.rpc;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.mina.common.IoSession;

import toolbox.simplenet.server.Context;

/**
 * 线程状态，用于设置和访问当前线程相关的数据，目前可以访问的数据包括context和session.
 * 这个类便于在rpc方法中得到一些没有办法通过接口传入的数据，例如，我们可以在rpc方法中
 * 通过如下方法得到当前的context:
 * <code>
 *   ...
 *   Context context = RPCThreadState.getContext();
 *   ...
 * </code>
 * 实际的实现办法是将状态以当前线程为key保存在一个状态表(hash表)中便于访问.
 * 
 * 需要注意的是：只有在rpc方法调用中才能通过{@link RPCThreadState}得到context这些对象，在其他
 * 地方调用{@link RPCThreadState}的接口是无意义的，因为状态的设置和取消发生在进入/退出rpc方法
 * 调用的时候.
 * 
 * @author river
 *
 */
public class RPCThreadState {

    private static class State {
        private Context context;
        private IoSession session;
        
        public State(Context context, IoSession session) {
            this.context = context;
            this.session = session;
        }
        
    }
    
    private static ConcurrentHashMap<Thread, State> currentStates = 
        new ConcurrentHashMap<Thread, State>();
    
    /**
     * 设置当前线程的context和session.
     * @param context
     * @param session
     */
    public static void setState(Context context, IoSession session) {
        currentStates.put(Thread.currentThread(), new State(context, session));
    }
    
    /**
     * 获得当前线程使用的context.
     * @return
     */
    public static Context getContext() {
        State st = currentStates.get(Thread.currentThread());
        return st == null ? null : st.context;
    }
    
    /**
     * 获取当前线程上的请求对应的连接.
     * @return
     */
    public static IoSession getIoSession() {
        State st = currentStates.get(Thread.currentThread());
        return st == null ? null : st.session;
    }
    
    /**
     * 释放当前线程的状态信息.
     */
    public static void removeState() {
        currentStates.remove(Thread.currentThread());
    }
    
}
