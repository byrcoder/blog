package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

public class Cluster implements IWritable {
        private int index;
        private long size;
        private double cohesion; // 凝聚度
        private Vector centroid;

        public Cluster() {
                index = 0;
                size = 0;
                cohesion = 0;
                centroid = new Vector();
        }
        
        public Cluster(int index, long size, double cohesion, Vector centroid) {
                set(index, size, cohesion, centroid);
        }
        
        /**
         * @param index
         * @param size
         * @param cohesion
         * @param centroid null使得centroid被清0
         */
        public void set(int index, long size, double cohesion, Vector centroid) {
                this.index = index;
                this.size = size;
                this.cohesion = cohesion;
                if(centroid == null) {
                    this.centroid.clear();
                } else {
                    this.centroid.copyFields(centroid);
                }
        }
        
        public boolean merge(Cluster that) {
                if(centroid.size() != that.centroid.size()) return false;
                // 对凝聚度采用了一种粗略的合并算法, 对同Cluster的增量数据合并是准确的.
                if(that.size() == 0) return true;
                cohesion = (cohesion*size() + that.cohesion*that.size())/(size() + that.size());
                for(int i = 0; i < centroid.size(); i ++) {
                        centroid.setValue(i, (centroid.getValue(i)*size() + that.centroid.getValue(i)*that.size())/(size() + that.size()));
                }
                size += that.size;
                return true;
        }
        
        public int getIndex() {
                return index;
        }
        
        public long size() {
                return size;
        }
        
        public double getCohesion() {
                return cohesion;
        }
        
        public Vector getCentroid() {
                return centroid;
        }
        
        @Override
        public void readFields(DataInput in) throws IOException {
        index = in.readInt();
        size = in.readLong();
        cohesion = in.readDouble();
        centroid.readFields(in);
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
                out.writeInt(index);
                out.writeLong(size);
                out.writeDouble(cohesion);
                centroid.writeFields(out);              
        }

        @Override
        public IWritable copyFields(IWritable value) {
                if(this == value) return this;
                Cluster that = (Cluster) value;
                this.index = that.index;
                this.size = that.size;
                this.cohesion = that.cohesion;
                this.centroid.copyFields(that.centroid);
                return this;
        }
        
        @Override
        public String toString() {
                return "(" + index + ", " + size + ", " + cohesion + ", " + centroid.toString() + ")";
        }
}
