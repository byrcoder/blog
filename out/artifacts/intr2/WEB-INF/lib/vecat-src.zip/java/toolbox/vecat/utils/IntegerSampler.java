package toolbox.vecat.utils;

import java.util.HashMap;
import java.util.Random;

/**
 * 不放回地在指定的整数范围内[from, to)中随机抽取整数序列(通过迭代调用{@link #sample()})
 * @author caofx
 *
 */
public class IntegerSampler {
    private HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
    private Random random;
    private int from;
    private int to;
    private int i;

    /**
     * @param seed 随机数种子
     * @param from
     * @param to
     */
    public IntegerSampler(long seed, int from, int to) {
    	random = new Random(seed);
    	reset(from, to);
    }
 
    /**
     * @param from
     * @param to
     */
    public IntegerSampler(int from, int to) {
    	random = new Random();
    	reset(from, to);
    }

    /**
     * 清除已抽取记录, 以重新开始抽取
     */
    public void clear() {
    	map.clear();
    	i = 0;
    }
    
    /**
     * 重新指定范围, 并清除已抽取记录
     * @param from
     * @param to
     */
    public void reset(int from, int to) {
    	assert(to > from);
    	this.from = from;
    	this.to = to;
    	clear();
    }
    
    /**
     * 随机抽取一个整数, 如果无数可取返回{@link Integer#MIN_VALUE}
     * @return
     */
    public int sample() {
    	int length = to - from;
    	if(i >= length) return Integer.MIN_VALUE;
    	
    	int index = map.containsKey(i)? map.get(i): i;
    	int j = i + random.nextInt(length - i);
    	if(j != i) {
    		int t = map.containsKey(j)? map.get(j): j;
    		map.put(j, index);
    		index = t;
    	}
    	i ++;
    	return index + from;
    }
    
}
