package toolbox.vecat.utils;

import java.util.Random;

import toolbox.vecat.data.SparseVector;

/**
 * 生成随机向量
 * @author caofx
 *
 */
public class RandomVectorGenerator {
    private static final double SQRT3 = Math.sqrt(3);
    private static enum MethodType {
        GAUSS,
        ACHLIOPTAS1,
        ACHLIOPTAS2
    }

    private MethodType method;
    private Random random;
    private int seedSize;
    private SparseVector vector;
    private IntegerSampler sampler;
    
    public RandomVectorGenerator(String method, long randomSeed, int dimSize, int seedSize) {
    	assert(dimSize >= seedSize);
        this.method = MethodType.valueOf(method.toUpperCase());
        random = new Random();
        sampler = new IntegerSampler(randomSeed, 0, dimSize);
        this.seedSize = seedSize;
        vector = new SparseVector(seedSize);
    }
    
    public SparseVector generateVector() {
        vector.resize(seedSize);
        
        // 1. 选取种子
        sampler.clear();
        for(int i = 0; i < seedSize; i ++) {
            vector.setIndex(i, sampler.sample());
        }

        // 2. 使用不同方法为种子元素赋值
        if(method == MethodType.GAUSS) {
            for(int i = 0; i < seedSize; i ++) {
                vector.setValue(i, random.nextGaussian());
            }
        } else if(method == MethodType.ACHLIOPTAS1) {
            for(int i = 0; i < seedSize; i ++) {
                vector.setValue(i, random.nextInt(2)*2 -1);
            }
        } else if(method == MethodType.ACHLIOPTAS2) {
            for(int i = 0; i < seedSize; i ++) {
                vector.setValue(i, (random.nextInt(2)*2 -1) * SQRT3);
            }
        } else {
            throw new UnsupportedOperationException(method.toString());
        }
        
        return vector;
    }

}
