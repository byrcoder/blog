package toolbox.vecat;
import odis.app.job.AbstractCoWorkToolWithArg;
import odis.io.Path;
import toolbox.misc.cli.Options;
import toolbox.vecat.base.BucketUtils;


public class VectorClusterFinder extends AbstractCoWorkToolWithArg {
    public static final String RESULT_PATH = "result";
    private static final String CLUSTER_STAGE_PREFIX = "cluster_";
    private static final String MERGE_STAGE_PREFIX = "merge_";
    private static final int MAX_BUFFER_SIZE = 100000;
    private static final double MIN_CATCH_PROB = 0.3;
    private static final int MIN_SCPE = 45;

    @Override
    public String comment() {
        return "Find clusters in vector data";
    }

    @Override
    protected void prepareOptions(Options opt) {
        opt.withOption("i", "input", "input path");
        opt.withOption("o", "output", "output path");
        opt.withOption("l", "sig_length", "signiture vector length");
        opt.withOption("gc", "group", "signiture group count").setDefault(-1);
        opt.withOption("sc", "shingle_count ", "group count for shingles").setDefault(-1);
        opt.withOption("bs", "buffer_size", "buffer size").setDefault(MAX_BUFFER_SIZE);
        opt.withOption("rbs", "regular_bucket_size", "regular bucket size for computing bucket params").setDefault(-1);
        opt.withOption("s", "sim_threshold", "similarity threshold");
        opt.withOption("c", "catch_prob", "catch probability threshold, real cath probability under this will cause keeping isolate elements").setDefault(0);
        opt.withOption("size", "data_size", "data size, for param auto-setup & need not be accurate").setDefault(-1);
        opt.withOption("iter", "iter_num", "iteration num");
        opt.withOption("mc", "do compression in map");
        opt.withOption("run", "run the job");
        opt.withOption("con", "continue the job, take effect only when \"-run\" set");
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(options.getOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        
        int sigLength = options.getIntOpt("l");
        int groupCount = options.getIntOpt("gc");
        int shingleCount = options.getIntOpt("sc");
        int bufferSize = options.getIntOpt("bs");
        double regularBucketSize = options.getDoubleOpt("rbs");
        if(regularBucketSize < 0) regularBucketSize = bufferSize;
        double simThreshold = options.getDoubleOpt("s");
        double catchProb = options.getDoubleOpt("c");
        long size = options.getLongOpt("size");
        int iter = options.getIntOpt("iter");
        boolean mapCompress = options.isOptSet("mc");
        boolean run = options.isOptSet("run");
        boolean con = options.isOptSet("con");
        
        // 检查输入参数冲突
        if(!run) con = false;
        
        // Clustering iteration
        for(int i = 0; i < iter; i ++) {
            // 设置IO路径
            Path input;
            if(i == 0) {
                input = inputPath;
            } else {
                input = getClusterIterPath(outputPath, i-1).cat(VectorClusterTool.CLUSTER_PATH);
            }
            Path output = getClusterIterPath(outputPath, i);
            // 检查是否需要执行这个stage
            if(con) {
                if(fs.exists(output.cat(VectorClusterTool.RESULT_PATH))) {
                    continue;
                } else {
                    out.println("Continue clustering job at cluster stage " + i);
                    con = false;
                }
            }
            if(size >= 0 && size < 2) {
                iter = i;
                out.println("less than 2 cluster found, cluster iteration finished");
                break;
            }
            // execute
            out.println("Clustering stage: " + i);
            // 设置签名分组参数
            int len = sigLength;
            int gc = groupCount;
            int sc = shingleCount;
            if(gc < 0 || sc < 0) {
                if(size < 0) {
                    out.println("you must provide \"-size\" argument when \"-gc\" or \"-sc\" omit");
                    return false;
                }
                if(size <= bufferSize) {
                    gc = 1;
                    sc = 0;
                } else {
                    double ebc = Math.ceil(BucketUtils.getProperBucketNumber(size, regularBucketSize, simThreshold));
                    double sl = Math.log(ebc)/Math.log(2);
                    // 1. 优先保证catchProb
                    int [] params = BucketUtils.computeGroupParams(sl, sigLength, simThreshold, catchProb, MIN_SCPE);
                        
                    // 2. 如果不能保证catchProb, 则在保证MIN_CATCH_PROB的条件下优先保证较小的SHINGLE_PER_ELEMENT
                    if(params == null) {
                        params = BucketUtils.computeGroupParams(sl, sigLength, simThreshold, MIN_CATCH_PROB, MIN_SCPE);
                        if(params == null) {
                            out.println("hard to get a proper signiture group config, please adjust job parameters: \"-s\", \"-c\".");
                            return false;
                        }
                    }
                    len = params[0];
                    gc = params[1];
                    sc = params[2];
                }
            }
            size = VectorClusterTool.exec(getToolName(), context, out, nWorker, input, output,
                    len, gc, sc, simThreshold, catchProb, bufferSize, false, mapCompress, run);
            if(size < 0) return false;
            if(!run) return true;
        }
        
        // Merging iteration
        for(int i = 0; i < iter; i ++) {
            // 设置IO路径
            Path parent;
            if(i == 0) {
                parent = getClusterIterPath(outputPath, iter-1-i).cat(VectorClusterTool.INDEX_PATH);
            } else {
                parent = getMergeIterPath(outputPath, i-1);
            }
            // 合并已经完成, 把parent链接到输出目录
            if(i == iter-1) {
                Path output = outputPath.cat(RESULT_PATH);
                if(fs.exists(output)) fs.delete(output);
                fs.link(parent, output);
                break;
            }
            // 合并未完成
            Path input = getClusterIterPath(outputPath, iter-2-i).cat(VectorClusterTool.RESULT_PATH);
            Path output = getMergeIterPath(outputPath, i);
            // 检查是否需要执行这个stage
            if(con) {
                if(fs.exists(output)) {
                    continue;
                } else {
                    out.println("Continue clustering job at cluster stage " + i);
                    con = false;
                }
            }
            // execute
            out.println("Merging stage: " + i);
            boolean ret = MergeClusterTool.exec(getToolName(), context, out, nWorker, input, parent, output, 0);
            if(!ret) return false;
        }
        
        out.println("The clustering job has finished");
        return true;
    }
    
    private static Path getClusterIterPath(Path outputPath, int iter) {
        return outputPath.cat(CLUSTER_STAGE_PREFIX + iter);
    }

    private static Path getMergeIterPath(Path outputPath, int iter) {
        return outputPath.cat(MERGE_STAGE_PREFIX + iter);
    }
    
    public static void main(String[] args) {
        long n = (long) 3e6;
        double a = BucketUtils.getProperBucketNumber(n, 10000, 0.99);
        System.out.println(a);
        System.out.println(n/a);
        System.out.println(a);
        System.out.println(n/a);
    }
}
