/**
 * @(#)QuerySigExtractTool.java, Sep 4, 2009. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.vecat;

import java.util.Random;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.LongsWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.base.IVectorConverter;
import toolbox.vecat.base.SignitureGenerator;
import toolbox.vecat.base.SimpleVectorConverter;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.StringDim;
import toolbox.vecat.data.Vector;

/**
 * Make signitures for vectors
 * 
 * @author caofx
 *
 */

public class VectorSignitureTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(VectorSignitureTool.class);
    public static final String LSH_PATH = "lsh";
    public static final String SIGNITURE_PATH = "signiture";
    
    private static enum CounterName {
        SIGNITURE_COUNT,
    }
    
    private static final String CFG_FS = "CFG_FS";
    private static final String CFG_WORK_PATH = "CFG_WORK_PATH";
    private static final String CFG_HASH_FUNC = "CFG_HASH_FUNC";
    private static final String CFG_SIG_LEN = "CFG_SIG_LEN";
    private static final String CFG_CONVERTER_CLASS = "CFG_CONVERTER_CLASS";
    
    private static enum HashFunc {
        MIN,
        WEIGHTED,
        COS,
        MCOS,
        BCOS,
    }

    private Path inputPath;
    private Path outputPath;
    private int sigLen;
    private HashFunc hashFunc;
    private Class<? extends IVectorConverter> converterClass;

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path");
        options.withOption("l", "sig_len", "set signiture length").hasDefault();
        options.withOption("h", "hash_func", "set hash func: min, weighted, mcos, bcos, cos").setDefault(HashFunc.MIN.name());
        options.withOption("c", "record_converter", "set record converter").setDefault(SimpleVectorConverter.class.getName());
    }

    @Override
    public String comment() {
        return "Make signitures for vectors";
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        // 环境设置, 初始化
        inputPath = context.path(options.getStringOpt("i"));
        outputPath = context.path(options.getStringOpt("o"));
        hashFunc = HashFunc.valueOf(options.getStringOpt("h").toUpperCase());
        converterClass = (Class<? extends IVectorConverter>) Class.forName(options.getStringOpt("c"));
        
        if(hashFunc == HashFunc.COS) {
            sigLen = options.getIntOpt("l");
            return buildCosSigs(nWorker);
        } else {
            sigLen = options.getIntOpt("l", 0);
            return buildMinSigs(nWorker);
        }
    }
    
    private boolean buildMinSigs(int nWorker) throws Exception {
        if(sigLen > 0) {
            // 生成 lsh 数据
            LOG.info("Generate lsh params ...");
            SignitureGenerator generator = new SignitureGenerator();
            generator.generateParams(sigLen);
            generator.write(fs, outputPath.cat(LSH_PATH));
        } else {
            // 检查是否存在 lsh 数据
            if(!fs.exists(outputPath.cat(LSH_PATH))) {
                LOG.severe("No lsh data exists, \"-l\" param must be provided");
                return false;
            }
        }
        
        // MR settings
        MapReduceJobDef job = context.createMapReduceJob(this.getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        job.setMapper(MinMapper.class);
        helper.addReadInputDir(inputPath, null);
        
        job.setReducer(IdentityReducer.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        if(hashFunc == HashFunc.MCOS) {
            job.setMergeKeyValClass(StringWritable.class, Vector.class);
            helper.addUpdateOutputDir(0, outputPath.cat(SIGNITURE_PATH), StringWritable.class, Vector.class, null);
        } else if(hashFunc == HashFunc.BCOS) {
            job.setMergeKeyValClass(StringWritable.class, BitArray.class);
            helper.addUpdateOutputDir(0, outputPath.cat(SIGNITURE_PATH), StringWritable.class, BitArray.class, null);
        } else {
            job.setMergeKeyValClass(StringWritable.class, LongsWritable.class);
            helper.addUpdateOutputDir(0, outputPath.cat(SIGNITURE_PATH), StringWritable.class, LongsWritable.class, null);
        }
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        job.setMapNumber(nWorker*4);
        job.setReduceNumber(nWorker);
        
        job.setCheckReduceProgress(false);
        job.getConfig().setProperty(CFG_FS, fs.getName());
        job.getConfig().setProperty(CFG_WORK_PATH, outputPath.getAbsolutePath());
        job.getConfig().setProperty(CFG_HASH_FUNC, hashFunc.name());
        job.getConfig().setInt(CFG_SIG_LEN, sigLen);
        job.getConfig().setProperty(CFG_CONVERTER_CLASS, converterClass.getName());

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    private boolean buildCosSigs(int nWorker) throws Exception {
        if(sigLen <= 0) {
            LOG.severe("\"-l\" param must be provided");
            return false;
        }
        
        // MR settings
        MrStarJobDef job = context.createMrStarJob(2, this.getToolName()+ ".cos", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        job.setMapper(CosMapper.class);
        helper.addReadInputDir(0, inputPath, null);
        job.setReducer(0, FeatureReducer.class);
        job.setMergeKeyValClass(0, StringWritable.class, StringDim.class);
        job.setPartitionerClass(0, SeqFileHashPartitioner.class);
        job.setWalkerClass(0, ReuseWalker.class);

        job.setReducer(1, CosReducer.class);
        job.setMergeKeyValClass(1, StringWritable.class, Vector.class);
        job.setPartitionerClass(1, SeqFileHashPartitioner.class);
        job.setWalkerClass(1, ReuseWalker.class);
        helper.addUpdateOutputDir(1, 0, outputPath.cat(SIGNITURE_PATH), StringWritable.class, Vector.class, null);
        GenericFileOutputFormat.setCompress(job, 1, 0, 0);
        GenericFileOutputFormat.setCompress(job, 1, 1, 0);
        BasicPartitioner.setCompress(job, 1, 0, false);

        job.setMapNumber(nWorker);
        job.setMrNumber(1, nWorker);
        job.setReduceNumber(nWorker);

        job.setCheckMrProgress(1, false);
        job.setCheckReduceProgress(false);
        job.getConfig().setProperty(CFG_FS, fs.getName());
        job.getConfig().setProperty(CFG_WORK_PATH, outputPath.getAbsolutePath());
        job.getConfig().setProperty(CFG_HASH_FUNC, hashFunc.name());
        job.getConfig().setInt(CFG_SIG_LEN, sigLen);
        job.getConfig().setProperty(CFG_CONVERTER_CLASS, converterClass.getName());

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class MinMapper extends AbstractMapper<IWritable, IWritable> {
        private SignitureGenerator generator = new SignitureGenerator();
        private StringWritable elementName = new StringWritable();
        private HashFunc hashFunc;
        private IVectorConverter converter;
        private Counter sigCounter;

        public void configure(JobDef job, TaskRunnable task) {
            try {
                IFileSystem fs = FileSystem.getNamed(job.getConfig().getString(CFG_FS));
                Path path = new Path(job.getConfig().getString(CFG_WORK_PATH));
                generator.read(fs, path.cat(LSH_PATH));
                converter = (IVectorConverter) Class.forName(job.getConfig().getString(CFG_CONVERTER_CLASS)).newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            hashFunc = HashFunc.valueOf(job.getConfig().getString(CFG_HASH_FUNC));
            sigCounter = task.getCounter(CounterName.SIGNITURE_COUNT.name());
        }

        public void map(IWritable key, IWritable value, ICollector collector) {
            AbstractVector vector = converter.convert(key, value);
            if(vector == null || vector.size() == 0) return;
            
            IWritable sig;
            if(hashFunc == HashFunc.MCOS) {
                sig = generator.getCosHashProduct(vector);
            } else if(hashFunc == HashFunc.BCOS) {
                sig = generator.getCosHashSig(vector);
            } else if(hashFunc == HashFunc.WEIGHTED) {
                sig = generator.getWeightedMinHashSig(vector);
            } else /* HashFunc.MIN */{
                sig = generator.getMinHashSig(vector);
            }
            if(sig == null) return;
            elementName.set(key.toString());
            collector.collect(elementName, sig);
            sigCounter.inc();
        }
    }

    public static class CosMapper extends AbstractMapper<IWritable, IWritable> {
        private StringWritable featureName = new StringWritable();
        private StringDim pair = new StringDim();
        private IVectorConverter converter;

        @Override
        public void configure(JobDef job, TaskRunnable task) {
            try {
                converter = (IVectorConverter) Class.forName(job.getConfig().getString(CFG_CONVERTER_CLASS)).newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        
        public void map(IWritable key, IWritable value, ICollector collector) {
            AbstractVector vector = converter.convert(key, value);
            if(vector == null) return;
            double modulus = vector.modulus();
            if(modulus <= 0) return;
            pair.setIndex(key.toString());
            for(int i = 0; i < vector.size(); i ++) {
                if(vector.getValue(i) == 0) continue;
                featureName.set(vector.getIndexName(i));
                pair.setValue(vector.getValue(i)/modulus); // 原向量归一化为单位向量
                collector.collect(featureName, pair);
            }
        }
    }
    
    public static class FeatureReducer extends AbstractReducer<StringWritable, StringDim> {
        private int sigLen;
        private Random random;
        private Vector refVector;
        private Vector tempVector;
        private StringWritable elementName = new StringWritable();

        public void configure(JobDef job, TaskRunnable task) {
            sigLen = job.getConfig().getInt(CFG_SIG_LEN);
            random = new Random(task.getPartIdx());
            refVector = new Vector(sigLen);
            tempVector = new Vector(sigLen);
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringDim> values,
                ICollector collector) {
            // 生成参考向量
            for(int i = 0; i < sigLen; i ++) {
                refVector.setValue(i, random.nextGaussian());
            }
            // 计算内积各分量值
            while(values.moreValue()) {
                StringDim pair = values.getValue();
                elementName.set(pair.getIndex());
                for(int i = 0; i < sigLen; i ++) {
                    tempVector.setValue(i, pair.getValue() * refVector.getValue(i));
                }
                collector.collect(elementName, tempVector);
            }
        }
    }
    
    public static class CosReducer extends AbstractReducer<IWritable, Vector> {
        private int sigLen;
        private Vector tempVector;
        private Counter sigCounter;

        public void configure(JobDef job, TaskRunnable task) {
            sigLen = job.getConfig().getInt(CFG_SIG_LEN);
            tempVector = new Vector(sigLen);
            sigCounter = task.getCounter(CounterName.SIGNITURE_COUNT.name());
        }

        @Override
        public void reduce(IWritable key,
                IWritablePairWalker<IWritable, Vector> values,
                ICollector collector) {
            // 对内积各分量值求和
            tempVector.clear();
            while(values.moreValue()) {
                Vector vector = values.getValue();
                for(int i = 0; i < sigLen; i ++) {
                    tempVector.setValue(i, tempVector.getValue(i) + vector.getValue(i));
                }
            }
            
            collector.collectToChannel(0, key, tempVector);
            sigCounter.inc();
        }
    }
    
}
