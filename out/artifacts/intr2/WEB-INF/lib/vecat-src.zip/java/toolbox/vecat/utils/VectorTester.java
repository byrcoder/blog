package toolbox.vecat.utils;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import odis.app.job.AbstractLocalToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.IParsable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongsWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.Url;
import odis.tools.MapReduceHelper;
import odis.tools.misc.DumpTool;
import toolbox.cluster.Instance;
import toolbox.misc.cli.Options;
import toolbox.vecat.base.CosHashUtils;
import toolbox.vecat.base.IVectorConverter;
import toolbox.vecat.base.SimpleVectorConverter;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.StringDim;
import toolbox.vecat.data.Vector;

/**
 * 以指定的key从指定的文件中取得两个vector并计算它们的相似度, 距离等
 * @author caofx
 *
 */
public class VectorTester extends AbstractLocalToolWithArg {

    private BasicPartitioner partioner;

    @Override
    public String comment() {
        return "Compute similarity, distance and etc for two sepcified vectors";
    }
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("v", "set verbose mode.");
        options.withOption("fs", "filesystem", "set file system.").setDefault("");
        options.withOption("p1", "path1", "set path for vector1.");
        options.withOption("p2", "path2", "set path for vector2.").setDefault("");
        options.withOption("k1", "key1", "set key for vector1.");
        options.withOption("k2", "key2", "set key for vector2.");
        options.withOption("kc", "keyclass", "set key class.").setDefault("");
        options.withOption("pc", "partitioner", "set partitioner class.").setDefault("");
        options.withOption("l", "length", "set truncate length.").setDefault(-1);
        options.withOption("c", "record_converter", "set record converter").setDefault(SimpleVectorConverter.class.getName());
    }

    @Override
    public boolean exec() throws Exception {
        // 处理输入
        boolean verbose = options.isOptSet("v");
        String fsName = options.getStringOpt("fs");
        FileSystem fs = context.getFileSystem(); 
        if(fsName.length() > 0) fs = FileSystem.getNamed(fsName);
        String path1 = options.getStringOpt("p1");
        String path2 = options.getStringOpt("p2");
        if(path2.length() == 0) path2 = path1;
        String key1 = options.getStringOpt("k1");
        String key2 = options.getStringOpt("k2");
        String keyClassName = options.getStringOpt("kc");
        int length = options.getIntOpt("l"); 
        IVectorConverter converter = (IVectorConverter) Class.forName(options.getStringOpt("c")).newInstance();
        Instance.ID id = new Instance.ID();
        Utils.setInstanceID(id, key1);
        System.out.println(key1 + ": " + id);
        Utils.setInstanceID(id, key2);
        System.out.println(key2 + ": " + id);
        IWritableComparable key1Writable;
        IWritableComparable key2Writable;
        if(keyClassName.length() == 0) {
            partioner = new SeqFileHashPartitioner();
            key1Writable = new StringWritable(key1);
            key2Writable = new StringWritable(key2);
        } else if(keyClassName.equals("url")) {
            partioner = new UrlMd5Partitioner();
            key1Writable = new Url(key1);
            key2Writable = new Url(key2);
        } else {
            partioner = new SeqFileHashPartitioner();
            key1Writable = (IWritableComparable) Class.forName(keyClassName).newInstance();
            ((IParsable)key1Writable).parse(key1);
            key2Writable = (IWritableComparable) Class.forName(keyClassName).newInstance();
            ((IParsable)key1Writable).parse(key2);
        }
        
        if(options.getStringOpt("pc").length() > 0) {
            partioner = (BasicPartitioner) Class.forName(options.getStringOpt("pc")).newInstance();
        }
        
        IWritable value1 = getRecordValue(fs, path1, key1Writable);
        IWritable value2 = getRecordValue(fs, path2, key2Writable);
        if(value1 instanceof Vector) {
            Vector vector1 = (Vector) value1;
            Vector vector2 = (Vector) value2;
            if(length > 0) {
                vector1.truncate(length);
                vector2.truncate(length);
            }
            if(verbose) {
                System.out.println(key1 + ": " + vector1);
                System.out.println(key2 + ": " + vector2);
            }
            int diff = Vector.getDiff(vector1, vector2);
            double cos = CosHashUtils.diff2Sim(diff, vector1.size());
            System.out.println("Diff Distance(" + vector1.size() + ", " + vector2.size() + "): " + diff);
            System.out.println("Equivalent COS Similarity: " + cos);
        } else if(value1 instanceof BitArray) {
            BitArray vector1 = (BitArray) value1;
            BitArray vector2 = (BitArray) value2;
            if(length > 0) {
                vector1.truncate(length);
                vector2.truncate(length);
            }
            if(verbose) {
                System.out.println(key1 + ": " + vector1);
                System.out.println(key2 + ": " + vector2);
            }
            int diff = vector1.diff(vector2);
            double cos = CosHashUtils.diff2Sim(diff, vector1.size());
            System.out.println("Diff Distance(" + vector1.size() + ", " + vector2.size() + "): " + diff);
            System.out.println("Equivalent COS Similarity: " + cos);
        } else if(value1 instanceof LongsWritable){
            long[] vector1 = Arrays.copyOf(((LongsWritable) value1).getBuffer(), ((LongsWritable) value1).size());
            long[] vector2 = Arrays.copyOf(((LongsWritable) value2).getBuffer(), ((LongsWritable) value2).size());
            if(length > 0 && length < vector1.length) {
                vector1 = Arrays.copyOf(vector1, length);
                vector2 = Arrays.copyOf(vector2, length);
            }
            if(verbose) {
                System.out.println(key1 + ": " + vector1);
                System.out.println(key2 + ": " + vector2);
            }
            System.out.println("Diff Distance(" + vector1.length + ", " + vector2.length + "): " + DiffTools.diffUnit(vector1, vector2));
        } else {
            AbstractVector vector1 = converter.convert(key1Writable, value1).clone();
            AbstractVector vector2 = converter.convert(key2Writable, value2).clone();
            if(length > 0) {
                vector1.truncate(length);
                vector2.truncate(length);
            }
            Comparator<StringDim> comparator = new Comparator<StringDim>() {
                @Override
                public int compare(StringDim o1, StringDim o2) {
                    return Double.compare(o2.getValue(), o1.getValue());
                }
            };
            if(verbose) {
                StringDim[] array1 = vector1.toArray();
                StringDim[] array2 = vector2.toArray();
                Arrays.sort(array1, comparator);
                Arrays.sort(array2, comparator);
                System.out.println(key1 + ": " + Arrays.toString(array1));
                System.out.println(key2 + ": " + Arrays.toString(array2));
            }
            System.out.println("Distance(" + vector1.modulus() + ", " + vector2.modulus() + "): " + vector1.distance(vector2));
            double cos = vector1.innerProduct(vector2)/(vector1.modulus()*vector2.modulus());
            System.out.println("COS Similarity: " + cos);
            System.out.println("(1 - theta/pi): " + (1 - Math.acos(cos)/Math.PI));
            
            // Jaccard similarity 相关
            AbstractVector jv1;
            AbstractVector jv2;
            jv1 = vector1.clone();
            jv2 = vector2.clone();
            for(int i = 0; i < jv1.size(); i ++) {
                jv1.setValue(i, 1);
            }
            for(int i = 0; i < jv2.size(); i ++) {
                jv2.setValue(i, 1);
            }
            if(verbose) {
                StringDim[] array1 = jv1.toArray();
                StringDim[] array2 = jv2.toArray();
                Arrays.sort(array1, comparator);
                Arrays.sort(array2, comparator);
                System.out.println(key1 + "(j): " + Arrays.toString(array1));
                System.out.println(key2 + "(j): " + Arrays.toString(array2));
            }
            System.out.println("JACCARD similarity: " + jv1.intersect(jv2));
            List<StringDim> list = jv1.commonDims(jv2);
            System.out.println("Common Dims(" + jv1.size() + ", " + jv2.size() + "): " + list.size() + "(" + (double)list.size()/(jv1.size() + jv2.size() - list.size()) + ")");
            Collections.sort(list, comparator);
            System.out.println(list);
        }
        return true;
    }
    
    private IWritable getRecordValue(FileSystem fs, String pathName, IWritableComparable key) throws IOException {
        Path path = new Path(pathName);
        int partCount = MapReduceHelper.getContinuousPartCount(fs, path);
        int partNum = partioner.getPartition(key, null, partCount);
        IWritable[] records = DumpTool.searchInSortedSequenceFile(fs, path.cat(CoWorkUtils.getPartID(partNum)).getAbsolutePath(), key);
        return records[0];
    }
    
}
