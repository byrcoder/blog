package toolbox.vecat.data;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.toolkit.WritablePair;

/**
 * @author caofx
 *
 */
public class LongDoublePair extends WritablePair<LongWritable, DoubleWritable> {

    @Override
    protected LongWritable newFirstInstance() {
        return new LongWritable();
    }

    @Override
    protected DoubleWritable newSecondInstance() {
        return new DoubleWritable();
    }

    public void set(long first, double second) {
        this.first.set(first);
        this.second.set(second);
    }
}

