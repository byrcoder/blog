package toolbox.vecat.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.TreeSet;

import odis.app.job.AbstractLocalToolWithArg;
import odis.file.SequenceFile.Reader;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import toolbox.cluster.Instance;
import toolbox.cluster.Instance.ID;
import toolbox.misc.cli.Options;
import toolbox.vecat.utils.Utils.ReadOperator;

public class PathFinder extends AbstractLocalToolWithArg {
    Graph graph = new Graph();
    
    @Override
    public String comment() {
        return "Find path between two nodes";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("fs", "filesystem", "set file system.").setDefault("");
        options.withOption("path", "path", "set file path.");
        options.withOption("s", "src", "src key.");
        options.withOption("d", "dest", "dest key(s).");
    }

    @Override
    public boolean exec() throws Exception {
        String fsName = options.getStringOpt("fs");
        FileSystem fs = context.getFileSystem(); 
        if(fsName.length() > 0) fs = FileSystem.getNamed(fsName);
        Path path = context.path(options.getStringOpt("path"));
        Instance.ID src = new Instance.ID();
        src.parse(options.getStringOpt("s"));
        String[] dests = options.getOpt("d");

        System.out.println("Loading data ...");
        graph.load(fs, path);
        
        Instance.ID dest = new Instance.ID();
        for(String c: dests) {
            dest.parse(c);
            System.out.println("Find path from " + src + " to " + dest + ": ");
            graph.find(src, dest);
        }
        return true;
    }
    
    private static class Node implements Comparable<Node> {
        TreeSet<Node> edges = new TreeSet<Node>();
        final ID id;
        byte color = 0;
        Node parent = null;
        
        Node(ID id) {
            this.id = new ID(id);
        }
        
        void add(Node b) {
            edges.add(b);
        }

        @Override
        public int compareTo(Node o) {
            return id.compareTo(o.id);
        }
        
    }
    
    private static class Graph {
        HashMap<ID, Node> map = new HashMap<ID, Node>();
        
        void add(ID a, ID b) {
            Node nodeA = map.get(a);
            if(nodeA == null) {
                nodeA = new Node(a);
                map.put(nodeA.id, nodeA);
            }

            Node nodeB = map.get(b);
            if(nodeB == null) {
                nodeB = new Node(b);
                map.put(nodeB.id, nodeB);
            }
            nodeA.add(nodeB);
            nodeB.add(nodeA);
        }
        
        void find(ID src, ID dest) {
            Node n = findPath(src, dest);
            if(n == null) {
                System.out.println("No path found!");
                return;
            }
            
            while(n != null) {
                System.out.println(n.id);
                n = n.parent;
            }
        }
        
        Node findPath(ID src, ID dest) {
            Node srcNode = map.get(src);
            Node destNode = map.get(dest);
            if(srcNode == null) {
                System.out.println(src + "not exist");
                return null;
            }
            if(destNode == null) {
                System.out.println(dest + "not exist");
                return null;
            }
            
            for(Node n: map.values()) {
                n.color = 0;
            }
            srcNode.color = 1;
            Queue<Node> queue = new LinkedList<Node>();
            queue.offer(srcNode);
            while(!queue.isEmpty()) {
                Node n = queue.remove();
                if(n == destNode) {
                    return n;
                }
                for(Node o: n.edges) {
                    if(o.color == 0) {
                        o.color = 1;
                        o.parent = n;
                        queue.add(o);
                    }
                }
                n.color = 2;
            }
            return null;
        }
        
        void load(IFileSystem fs, Path path) throws IOException {
            // 建立读取文件列表
            List<Path> inputs = new ArrayList<Path>();
            if (fs.isFile(path)) {
                inputs.add(path);
            } else {
                for (FileInfo info : fs.listFiles(path)) {
                    inputs.add(info.getPath());
                }
            }

            // 读取并合并数据
            for (Path input : inputs) {
                System.out.println("src = " + input.getAbsolutePath());
                Utils.readFromSeqFile(fs, input, this, new ReadOperator<Graph> () {
                    @Override
                    public void operate(Reader reader, Graph graph) throws IOException {
                        Instance.ID key = new Instance.ID();
                        Instance.ID value = new Instance.ID();
                        while (reader.next(key, value)) {
                            int c = key.compareTo(value);
                            if(c == 0) {
                                continue;
                            }
                            graph.add(key, value);
                        } 
                    }
                });
            }
        }
        
    }
    
    

}
