package toolbox.vecat.base;

import java.util.ArrayList;
import java.util.Collection;

public abstract class ObjectPool <T> {
    private ArrayList<T> buffer = new ArrayList<T>();
    
    /**
     * 创建新对象的接口
     * @return
     */
    protected abstract T newInstance();
    
    /**
     * 从对象池中取得一个对象
     * @return
     */
    public T pop() {
        int size = buffer.size();
        if(size > 0) {
            return buffer.remove(size-1);
        }
        return newInstance();
    }
    
    /**
     * 将对象还回对象池, 继续使用该对象的引用将出现不可知结果
     * @param object
     */
    public void push(T object) {
        buffer.add(object);
    }
    
    /**
     * 将collection中的对象还回对象池, 并将collection清空
     * @param collection
     */
    public void push(Collection<T> collection) {
        buffer.addAll(collection);
        collection.clear();
    }
}
