package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.serialize.IWritable;

/**
 * 以 int 为 index 类型的 SparseVector
 * @author caofx
 *
 */
public class SparseVector extends AbstractIntegerVector {
    private static class Dim implements Comparable<Dim> {
        public int index = 0;
        public double value = 0;
        
        @Override
        public int compareTo(Dim o) {
            return (index == o.index)? 0: ((index < o.index)? -1: 1);
        }
        
    }
    
    private int size;
    private Dim [] dims;
    private double modulus = -1;
    
    public SparseVector() {
        this(0);
    }
    
    public SparseVector(int size) {
        resize(size);
    }
    
    public void resize(int size) {
        this.size = size;
        if(dims == null || dims.length < size) {
            dims = new Dim [size];
            for(int i = 0; i < size; i ++) dims[i] = new Dim();
        }
        modulus = -1;
    }
    
    public int size() {
        return size;
    }
    
    public int getIndex(int i) {
        rangeCheck(i);
        return dims[i].index;
    }
 
    public double getValue(int i) {
        rangeCheck(i);
        return dims[i].value;
    }

    public void setIndex(int i, int index) {
        rangeCheck(i);
        dims[i].index = index;
    }
 
    public void setValue(int i, double value) {
        rangeCheck(i);
        dims[i].value = value;
        modulus = -1;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int size = in.readInt();
        resize(size);
        for(int i = 0; i < size; i ++) {
            dims[i].index = in.readInt();
        }
        for(int i = 0; i < size; i ++) {
            dims[i].value = in.readDouble();
        }
        modulus = -1;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        int size = size();
        out.writeInt(size);
        for(int i = 0; i < size; i ++) {
            out.writeInt(dims[i].index);
        }
        for(int i = 0; i < size; i ++) {
            out.writeDouble(dims[i].value);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if(this == value) return this;
        SparseVector that = (SparseVector) value;
        int size = that.size();
        resize(size);
        for(int i = 0; i < size; i ++) {
            dims[i].index = that.dims[i].index;
            dims[i].value = that.dims[i].value;
        }
        modulus = -1;
        return this;
    }
    
    public void sort() {
        Arrays.sort(dims, 0, size);
    }
    
    @Override
    public double modulus() {
    	if(modulus < 0) modulus = super.modulus();
    	return modulus;
    }

}
