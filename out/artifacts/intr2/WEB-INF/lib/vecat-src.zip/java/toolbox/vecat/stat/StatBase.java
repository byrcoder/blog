/**
 * @(#)StatBase.java, 2009-6-2. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.vecat.stat;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.FloatWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import toolbox.lang.ChnConstant;


/**
 * 数据统计的逻辑代码和数据结构
 * @author caofx
 *
 */
public class StatBase {

    /**
     * 描述一个统计结果的基类
     * @author caofx
     *
     */
    public static abstract class AbstractStatResult implements IWritable {
        /**
         * 合并统计结果
         * @param o
         */
        public abstract boolean merge(AbstractStatResult o);

        /**
         * 统计一个新值
         * @param v
         */
        public abstract void record(double v);
        
        /**
         * 返回记录数
         * @return
         */
        public abstract long getSize();
        
        /**
         * 判断给定浮点数是否NaN/Infinity
         * @param v
         */
        protected boolean isBad(double v) {
            return Double.isInfinite(v) || Double.isNaN(v);
        }
    }
    
    /**
     * 描述一个简单的统计结果, 包括最值, 和.
     * @author caofx
     *
     */
    public static class SimpleStatResult extends AbstractStatResult {
        private long size = 0;
        private double max = -Double.MAX_VALUE;
        private double min = Double.MAX_VALUE;
        private double sum = 0;
        
        public SimpleStatResult() {
            
        }
        
        public long getSize() {
            return size;
        }
        
        public double getMax() {
            return max;
        }
        
        public double getMin() {
            return min;
        }
        
        public double getSum() {
            return sum;
        }
        
        public void record(double v) {
            if(isBad(v)) return;
            size ++;
            if(max < v) max = v;
            if(min > v) min = v;
            sum += v;
        }
        
        public String toString() {
            // Write results to summary string
            StringBuilder summary = new StringBuilder();
            summary.append("Size = ").append(size);
            summary.append("\nMax = ").append(max);
            summary.append("\nMin = ").append(min);
            summary.append("\nMean = ").append(sum/size);
            summary.append("\n");
            return summary.toString();
        }
        
        public boolean merge(AbstractStatResult value) {
            SimpleStatResult o = (SimpleStatResult) value;
            size += o.size;
            if(max < o.max) max = o.max;
            if(min > o.min) min = o.min;
            sum += o.sum;
            return true;
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            size = in.readLong();
            max = in.readDouble();
            min = in.readDouble();
            sum = in.readDouble();
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(size);
            out.writeDouble(max);
            out.writeDouble(min);
            out.writeDouble(sum);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            SimpleStatResult o = (SimpleStatResult) value;
            size = o.size;
            max = o.max;
            min = o.min;
            sum = o.sum;
            return this;
        }

    }
    
    /**
     * 描述一个统计结果, 包括零值数, 最值, 和, 平方和, 直方图等统计信息
     * @author caofx
     *
     */
    public static class StatResult extends AbstractStatResult {
        private double max;
        private double min;
        private double mean;
        private boolean logarithmic;
        private long size = 0;
        private long zeroCount = 0;
        private long badCount = 0;
        private double varSum = 0;
        private double [] histBounds;
        private long [] hists;
        
        public StatResult() {
            this(0, 0, 0, 0, false);
        }
        
        /**
         * 使用预设参数初始化
         * @param max
         * @param min
         * @param mean
         * @param histLevel
         * @param logarithmic
         */
        public StatResult(double max, double min, double mean, int histLevel, boolean logarithmic) {
            this.max = max;
            this.min = min;
            this.mean = mean;
            this.logarithmic = logarithmic;
            histBounds = new double[histLevel];
            hists = new long[histLevel];
            for(int i = 0; i < histLevel; i++) {
                if(logarithmic) {
                    histBounds[i] = min -1 + Math.pow(max-min+1, ((double)i)/(histLevel-1));
                } else {
                    histBounds[i] = min + (max-min)*i/(histLevel-1);
                }
                hists[i] = 0;
            }
        }
        
        public long getSize() {
            return size;
        }

        public void record(double v) {
            if(isBad(v)) {
                badCount ++;
                return;
            }
            size ++;
            if(v == 0.0) zeroCount ++;
            varSum += Math.pow(mean - v, 2);
            int histLevel = histBounds.length;
            for(int i = histLevel - 1; i >= 0; i--) {
                if(v > histBounds[i]) break;
                hists[i] ++;
            }
        }
        
        public String toString() {
            // Write results to summary string
            StringBuilder summary = new StringBuilder();
            summary.append("Size = ").append(size);
            summary.append("\nZeroCount = ").append(zeroCount);
            summary.append("\nBadCount = ").append(badCount);
            summary.append("\nMax = ").append(max);
            summary.append("\nMin = ").append(min);
            summary.append("\nMean = ").append(mean);
            summary.append("\nSigma = ").append(Math.sqrt(varSum/size));
            summary.append("\nHistogram\n");
            int histLevel = histBounds.length;
            for(int i = 0; i < histLevel; i++) {
                summary.append("[" + i + "]\t<=\t" + histBounds[i] + "\t " + hists[i] + "\t" + (double)hists[i]/size + "\n");
            }
            return summary.toString();
        }
        
        /**
         * 合并统计结果, 如果本结果记录数为0, 则直接用value赋值,
         * 如果使用同样的预设参数(见 {@link #StatBase(double, double, double, int, boolean)}), 则合并,
         * 否则保持原内容.
         * @param value
         */
        public boolean merge(AbstractStatResult value) {
            if(size == 0) {
                this.copyFields(value);
                return true;
            }
            
            StatResult o = (StatResult) value;
            if(max != o.max || min != o.min || mean != o.mean || logarithmic != o.logarithmic) return false;
            size += o.size;
            zeroCount += o.zeroCount;
            badCount += o.badCount;
            varSum += o.varSum;
            int histLevel = histBounds.length;
            for(int i = 0; i < histLevel; i++) {
                hists[i] += o.hists[i];
            }
            return true;
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            max = in.readDouble();
            min = in.readDouble();
            mean = in.readDouble();
            logarithmic = in.readBoolean();
            size = in.readLong();
            zeroCount = in.readLong();
            badCount = in.readLong();
            varSum = in.readDouble();
            int histLevel = in.readInt();
            if(histBounds.length != histLevel) {
                histBounds = new double[histLevel];
                hists = new long[histLevel];
            }
            for(int i = 0; i < histLevel; i ++) {
                histBounds[i] = in.readDouble();
                hists[i] = in.readLong();
            }
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeDouble(max);
            out.writeDouble(min);
            out.writeDouble(mean);
            out.writeBoolean(logarithmic);
            out.writeLong(size);
            out.writeLong(zeroCount);
            out.writeLong(badCount);
            out.writeDouble(varSum);
            int histLevel = histBounds.length;
            out.writeInt(histLevel);
            for(int i = 0; i < histLevel; i ++) {
                out.writeDouble(histBounds[i]);
                out.writeLong(hists[i]);
            }
        }

        @Override
        public IWritable copyFields(IWritable value) {
            StatResult o = (StatResult) value;
            max = o.max;
            min = o.min;
            mean = o.mean;
            logarithmic = o.logarithmic;
            size = o.size;
            zeroCount = o.zeroCount;
            badCount = o.badCount;
            varSum = o.varSum;
            int histLevel = o.histBounds.length;
            if(histBounds.length != histLevel) {
                histBounds = new double[histLevel];
                hists = new long[histLevel];
            }
            for(int i = 0; i < histLevel; i ++) {
                histBounds[i] = o.histBounds[i];
                hists[i] = o.hists[i];
            }
            return this;
        }
    }
    
    /**
     * 将一个字符串转换成合法的java标识符, 用"_"替换不合法的字符, 如果首字符是数字, 则在前面添加"_"<br>
     * 使用 {@link DataGrepTool} 的 BeanShell 表达式时可能用到 
     * @param name
     * @return 转换后的字符串
     */
    public static String formatVarName(String name) {
        if(name == null || name.length() <= 0) return null;
        char[] array = name.toCharArray();
        for(int i = 0; i < array.length; i++) {
            if(!Character.isJavaIdentifierPart(array[i])) {
                array[i] = '_';
            }
        }
        if(Character.isJavaIdentifierStart(array[0])) {
            return String.valueOf(array);
        }
        return "_" + String.valueOf(array);
    }
    
    /**
     * 描述一个统计变量
     * @author caofx
     *
     */
    public static class StatVariable {
        public String name;
        public double value;

        public StatVariable(String name, double value) {
            this.name = name;
            this.value = value;
        }
    }
    
    /**
     * 从一条记录(Key->Value对)中解析出要统计的变量及其值
     * @author caofx
     *
     */
    public static interface DataParser {
        static final StatVariable[] EMPTY_VARIABLES = new StatVariable[0];
        /**
         * 由给定数据返回统计变量的数组
         * @param key
         * @param value
         * @return 解析出的 StatVariable 数组. 如果解析失败, 数组长度为零
         */
        public StatVariable [] getVariables(IWritable key, IWritable value);
    }
    
    /**
     * 用于"IWritable->数值"类型记录的解析器
     * @see DataParser
     * @author caofx
     *
     */
    public static class NumericParser implements DataParser {
        
        @Override
        public StatVariable[] getVariables(IWritable key, IWritable value) {
            double v = 0;
            boolean isNumeric = true;
            if(value instanceof IntWritable) {
                v = ((IntWritable)value).get();
            } else if(value instanceof LongWritable) {
                v = ((LongWritable)value).get();
            } else if(value instanceof FloatWritable) {
                v = ((FloatWritable)value).get();
            } else if(value instanceof DoubleWritable) {
                v = ((DoubleWritable)value).get();
            } else {
                isNumeric = false;
            }

            if(isNumeric) {
                StatVariable[] ret = {new StatVariable("number", v)};
                return ret;
            }
            return EMPTY_VARIABLES;
        }
    }
    
    /** 
     * 计算指定字符串的有效长度 = 汉字数 + 英文单词(英文数字连续字符串)数,
     * 中英文标点符号均不计算在内
     * @param str
     * @return
     */
    public static int getEffectiveLength(String str) {
        int len = 0;
        boolean isLastEnglish = false;
        for(int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if(ChnConstant.isEnglishAlphabet(c) || Character.isDigit(c)) {
                isLastEnglish = true;
            } else {
                if(isLastEnglish) len ++;
                isLastEnglish = false;
                if(ChnConstant.isChineseChar(c)) len ++;
            }
        }
        if(isLastEnglish) len ++;
        return len;
    }

}
