package toolbox.vecat.base;


public interface IClusterFilter {
    
    /**
     * 初始化filter
     * @param fileName
     * @return
     * @throws Exception 
     */
    public void init(Object param) throws Exception;

    /**
     * 重置状态, 以开始一轮新的扫描
     */
    public void reset();
    
    /**
     * 扫描一个element, 并返回本次扫描结果
     * @param element
     * @return
     */
    public boolean scan(String element);
    
    
    /**
     * 返回本轮扫描后的判断结果: 是否需要过滤
     * @return
     */
    public boolean judge();
}
