package toolbox.vecat.base;

import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.Vector;

public class CosHashUtils {
    private static BitArray bitArray = new BitArray();

    /**
     * 根据签名算法计算两个vector的cos similarity
     * @param v1
     * @param v2
     * @return
     */
    public static double getSimilarity(Vector v1, Vector v2) {
        return diff2Sim(Vector.getDiff(v1, v2), v1.size());
    }
    
    /**
     * 根据签名算法计算两个BitArray所代表的vector的cos similarity
     * @param v1
     * @param v2
     * @return
     */
    public static double getSimilarity(BitArray v1, BitArray v2) {
        return diff2Sim(v1.diff(v2), v1.size());
    }
    
    public static double diff2Sim(int diff, int size) {
        return Math.cos(((double)diff/size)*Math.PI);
    }
    
    public static int sim2Diff(double sim, int size) {
        return (int) Math.round(Math.acos(sim)/Math.PI*size);
    }
    
    /**
     * 从签名向量中取得某一位的签名, 这是一个二进制值0/1
     * @param v
     * @param index
     * @return
     */
    public static byte getSig(Vector v, int index) {
        return (byte) ((v.getValue(index) < 0)? 0: 1);
    }
    
    /**
     * 由签名向量生成16进制表示的签名字符串
     * @param v
     * @return
     */
    public static String getSigString(Vector v) {
        v.toBitArray(bitArray);
        return bitArray.hexString();
    }

    public static void main(String[] args) {
        Vector v1 = new Vector(128);
        Vector v2 = new Vector(128);
        int n = 1000;
        int m = n*n;
        System.out.println(m);
        long begin = System.currentTimeMillis();
        for(int j = 0; j < m; j ++) {
            getSimilarity(v1, v2);
        }
        long end = System.currentTimeMillis();
        System.out.println((end-begin)/1000.0);
        
    }
}
