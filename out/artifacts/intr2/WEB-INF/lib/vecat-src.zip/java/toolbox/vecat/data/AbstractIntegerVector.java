package toolbox.vecat.data;


/**
 * 以 int 为 index 类型的 Vector基类, 此类型及其子类之间支持distance/innerProduct运算
 * @author caofx
 *
 */
public abstract class AbstractIntegerVector extends AbstractVector {
    public abstract int getIndex(int i);
 
    public String toString() {
        StringBuilder buffer = new StringBuilder("[");
        for(int i = 0; i < size(); i ++) {
            buffer.append("(").append(getIndex(i)).append(", ").append(getValue(i)).append(")");
            if(i < size()-1) buffer.append(", ");
        }
        return buffer.append("]#").append(size()).toString();
    }

    protected void sort() {
    }
    
    public String getIndexName(int i) {
        return String.valueOf(getIndex(i));
    }

    @Override
    protected int compareIndex(int i, AbstractVector that, int j) {
        int i1 = this.getIndex(i);
        int i2 = ((AbstractIntegerVector)that).getIndex(j);
        return (i1 == i2)? 0: ((i1 < i2)? -1: 1);
    }
}
