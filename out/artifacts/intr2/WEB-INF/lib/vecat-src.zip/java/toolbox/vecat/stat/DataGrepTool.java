package toolbox.vecat.stat;

import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.stat.StatBase.DataParser;
import toolbox.vecat.stat.StatBase.NumericParser;
import toolbox.vecat.stat.StatBase.StatVariable;
import bsh.EvalError;
import bsh.Interpreter;

/**
 * 基于CoWork的数据筛选工具, 使用BeanShell表达式表示条件<br>
 * 如果表达式为空则输出所有记录<br>
 * 注意: 表达式最后应返回一个boolean值, 如果表达式有错误将被认为返回false<br>
 * 语法: http://www.beanshell.org/manual/contents.html<br>
 * <br>
 * 和{@link DataStatTool}使用同样的解析器来定义变量.
 *  
 * @author caofx
 *
 */
public class DataGrepTool extends AbstractCoWorkToolWithArg {
    private static final Logger LOG = LogFormatter.getLogger(DataGrepTool.class);
    private static final String CFG_PARSERNAME = DataGrepTool.class.getName() + "CFG_PARSERNAME";
    private static final String CFG_GREPCOND = DataGrepTool.class.getName() + "CFG_GREPCOND";

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("p", "parser_name", "set parser name.").setDefault(NumericParser.class.getName());
        options.withOption("g", "grep_cond", "set grep condition.");
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
    }

    @Override
    public String comment() {
        return "Do data grep on CoWork";
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        // Environment configuration & initialization
        Class<? extends DataParser> parserClass = (Class<? extends DataParser>) Class.forName(options.getStringOpt("p"));
        String grepCond = "";
        if(options.isOptSet("g")) grepCond = options.getStringOpt("g");
        Path inputPath = context.path(options.getStringOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        LOG.info("Input path: " + inputPath.getAbsolutePath());
        
        // MR settings
        MapOnlyJobDef job = context.createMapOnlyJob(getToolName(), nWorker);
        job.setMapper(Mapper.class);
        job.setMapNumber(nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(inputPath, null);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);

        // 自定义 job 设置
        job.getConfig().setProperty(CFG_PARSERNAME, parserClass.getName());
        job.getConfig().setProperty(CFG_GREPCOND, grepCond);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if(!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    /**
     * 输入: 指定的 Sequence File库, BeanShell 脚本, 指定的 DataParser
     * 输出: 符合条件的记录, 及其统计量的值
     * @author caofx
     *
     */
    public static class Mapper extends AbstractMapper<IWritable, IWritable> {
        private StringWritable newKey = new StringWritable();
        private StringWritable record = new StringWritable();
        private DataParser parser;
        private Interpreter interpreter = new Interpreter();
        private String grepCond;
        private Counter parsedCounter;
        private Counter hitCounter;
        private StringBuilder scriptBuffer = new StringBuilder();

        public void configure(JobDef job, TaskRunnable task) {
            try {
                parser = (DataParser) Class.forName(job.getConfig().getString(CFG_PARSERNAME)).newInstance();
            } catch (Exception e) {
                throw new TaskFatalException("Error initializing parser", e);
            }
            grepCond = job.getConfig().getString(CFG_GREPCOND);
            parsedCounter = task.getCounter("ParsedCounter");
            hitCounter = task.getCounter("HitCounter");
        }

        public void map(IWritable key, IWritable value, ICollector collector) {
            StatVariable[] vars = parser.getVariables(key, value);
            if(vars.length <= 0) return;
            parsedCounter.inc();
            boolean ret = true;
            // 构造将统计变量传入脚本的代码
            scriptBuffer.setLength(0);
            for(StatVariable var: vars) {
                scriptBuffer.append(var.name).append("=").append(var.value).append(";");
            }
            String logs = scriptBuffer.toString();
            
            // 如果条件表达式不为空, 则执行脚本
            if(grepCond.length() > 0) {
                // 过滤条件的代码
                scriptBuffer.append(grepCond);
                // 执行脚本
                try {
                    ret = (Boolean) interpreter.eval(scriptBuffer.toString());
                } catch (EvalError e) {
                    ret = false;
                    LOG.warning(e.toString());
                }
            }
            
            // 输出结果
            if(ret) {
                hitCounter.inc();
                newKey.set(key.toString());
                record.set(logs + value.toString());
                collector.collectToChannel(0, newKey, record);
            }
        }
   
    }
    
}
