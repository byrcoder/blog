package toolbox.vecat.base;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * 分桶相关的策略及辅助方法
 * @author caofx
 *
 */
public class BucketUtils {
    public static final int MAX_SHINGLE_PER_ELEMENT = 100;
    public static final double MAX_CATCH_PROB = 0.99;

    /**
     * 返回组合数的第一个结果
     * @param total
     * @param select
     * @return
     */
    public static int[] getFirstCombination(int total, int select) {
        int[] s = new int[select];
        for(int i=0; i<select; i++) s[i] = i;
        return s;
    }
    
    /**
     * 返回当前组合数的下一个组合数
     * @param total
     * @param select
     * @param last
     * @return
     */
    public static int[] nextCombination(int total, int select, int[] last) {
        if (last == null) {
            return getFirstCombination(total, select);
        } else {
            inc(total, select, last, select - 1);
            return last;
        }
    }

    private static void inc(int total, int select, int[] last, int pos) {
        if (pos<0) {
            for(int i=0; i<select; i++) last[i] = -1;
            return;
        }
        
        if (last[pos] < total - select + pos) {
            last[pos]++;
            for (int i = pos + 1; i < select; i++) {
                last[i] = last[i - 1] + 1;
            }
        } else {
            inc(total, select, last, pos-1);
        }
    }

    public static int[] naiveSplitPolicy(int sigLen, int bucketCount) {
        int[] bucketSize = new int[bucketCount];

        int r = sigLen % bucketCount;
        int size = sigLen / bucketCount;

        for (int i = 0; i < bucketCount; i++) {
            if (i < r)
                bucketSize[i] = size + 1;
            else
                bucketSize[i] = size;
        }

        return bucketSize;
    }

    /**
     * 根据bucketCovering和r的设置生成最终的分桶位置方案。<br>
     * 如果r=1，就直接返回bucketCovering的内容，只不过转成int[][]。<br>
     * 在实际使用中，基本都用的r=1
     * 
     * @param bucketCovering
     * @param bucketCount
     * @param bucket_r
     * @return
     */
    @SuppressWarnings("unchecked")
    public static int[][] getBucketPos(ArrayList[] bucketCovering,
            int bucketCount, int bucket_r) {

        if (bucket_r == 1) {
            int[][] newPos = new int[bucketCount][];
            for (int i = 0; i < bucketCount; i++) {
                newPos[i] = new int[bucketCovering[i].size()];
                for (int j = 0; j < bucketCovering[i].size(); j++) {
                    newPos[i][j] = (Integer) bucketCovering[i].get(j);
                }
            }
            return newPos;
        }

        ArrayList[] newPosArray;

        int count = 0;
        int[] selectedBucket = null;
        while (true) {
            selectedBucket = nextCombination(bucketCount, bucket_r,
                    selectedBucket);
            if (selectedBucket[0] < 0)
                break;
            count++;
        }

        newPosArray = new ArrayList[count];

        for (int i = 0; i < newPosArray.length; i++) {
            newPosArray[i] = new ArrayList<Integer>();
        }

        count = 0;
        selectedBucket = null;
        while (true) {
            selectedBucket = nextCombination(bucketCount, bucket_r,
                    selectedBucket);
            if (selectedBucket[0] < 0)
                break;
            for (int bucketIdx: selectedBucket) {
                for (int j = 0; j < bucketCovering[bucketIdx].size(); j++) {
                    int idx = (Integer) bucketCovering[bucketIdx].get(j);
                    newPosArray[count].add(idx);
                }
            }
            count++;
        }

        int[][] newPos = new int[newPosArray.length][];
        for (int i = 0; i < newPos.length; i++) {
            ArrayList<Integer> list = newPosArray[i];
            int asize = list.size();
            newPos[i] = new int[asize];
            for (int j = 0; j < asize; j++) {
                newPos[i][j] = list.get(j);
            }
            Arrays.sort(newPos[i]);
        }

        return newPos;
    }

    /**
     * 在指定的shingle分组策略下计算对指定相似度Pair的捕获概率
     * @param length
     * @param group
     * @param shingleCount
     * @param similarity
     * @return
     */
    public static double shingleCatchProb(int length, int group, int shingleCount, double similarity) {
        double p = 1.0 - Math.acos(similarity)/Math.PI;
        double k = (double)length/group;
        double S = Math.pow(p, k);
        double G = factorial(group);
        double ret = 1;
        for(shingleCount -= 1; shingleCount >= 0; shingleCount --) {
            ret -= G/(factorial(group-shingleCount)*factorial(shingleCount))
            *Math.pow(S, shingleCount)*Math.pow(1-S, group-shingleCount);
        }
        return ret;
    }

    /**
     * 计算指定shingle分组策略下每个元素生成的shingle个数
     * @param group
     * @param shingleCount
     * @return
     */
    public static double shingleCountPerElement(int group, int shingleCount) {
        return factorial(group)/(factorial(group-shingleCount)*factorial(shingleCount));
    }
    
    /**
     * 计算指定shingle分组策略下理论上生成的桶的总数
     * @param length
     * @param group
     * @param shingleCount
     * @return
     */
    public static double totalBucketCount(int length, int group, int shingleCount) {
        double k = (double)length/group;
        return shingleCountPerElement(group, shingleCount)*Math.pow(2, k*shingleCount);
    }

    /**
     * 阶乘函数
     * @param n
     * @return
     */
    public static double factorial(int n) {
        double ret = 1;
        for(; n > 0; n --) ret *= n;
        return ret;
    }

    /**
     * 估计合适的签名分组(shingle)参数
     * @param shingleLenth shingle长度, 由桶的总数可以估算见 {@link #getProperBucketNumber(long, double, double)}
     * @param sigLength 签名总长度
     * @param simThreshold 相似度阈值
     * @param catchProb 对于相似度为simThreshold的pair的捕获概率的阈值
     * @param minSCPE 单个元素最少应该输出的shingle个数, 在实际捕获概率低于{@link #MAX_CATCH_PROB}的情况下. 目的是让捕获概率尽可能地高
     * @return
     */
    public static int[] computeGroupParams(double shingleLenth, int sigLength, double simThreshold, double catchProb, int minSCPE) {
        int shingleCount = 0;
        int groupCount = 0;
        int len = 0;
        boolean success = false;
        for(shingleCount = 1; shingleCount <= shingleLenth ; shingleCount ++) {
            for(groupCount = shingleCount; ; groupCount ++) {
                len = (int) Math.ceil(shingleLenth*groupCount/shingleCount);
                double scpe = shingleCountPerElement(groupCount, shingleCount);
                if(len > sigLength || scpe > MAX_SHINGLE_PER_ELEMENT) {
                    break;
                }
                double cp = shingleCatchProb(len, groupCount, shingleCount, simThreshold);
                if(cp >= catchProb && (cp >= MAX_CATCH_PROB || scpe >= minSCPE)) {
                    success = true;
                    break;
                }
            }
            if(success) break;
        }

        if(success) {
            return new int []{len, groupCount, shingleCount};
        }
        return null;
    }
    
    /**
     * 估计合适的桶的总数
     * @param size 数据大小
     * @param bucketSize 平均单桶大小
     * @param simThreshold 相似度阈值
     * @return
     */
    public static double getProperBucketNumber(long size, double bucketSize, double simThreshold) {
        if(size <= bucketSize) return 1;
        return (double)size/bucketSize;
    }

    public static void main(String [] args) {
        int[] c = null;
        int n = 17;
        int m = 2;
        int i = 0;
        while(true) {
            c = BucketUtils.nextCombination(n, m, c);
            if(c[0] < 0) break;
            System.out.println(String.valueOf(i++) + " " + Arrays.toString(c));
        }
    }
}
