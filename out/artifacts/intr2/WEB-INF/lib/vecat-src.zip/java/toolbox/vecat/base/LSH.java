package toolbox.vecat.base;


/**
 * 使用大整数取模实现的LSH函数 
 * @author caofx
 */
public class LSH {
    private static final String DELIMITER = "\t";
    
    private long a;
    private long b;
    private long r;

    /**
     * @param str
     * @see #parse(String)
     */
    public LSH(String str) {
        parse(str);
    }

    /**
     * @param a
     * @param b
     * @param r
     * @see #set(long, long, long)
     */
    public LSH(long a, long b, long r) {
        set(a, b, r);
    }

    /**
     * 设置LSH参数, 各参数的意义见下式:
     *  h(x) = (a * x + b) % r
     * @param a
     * @param b
     * @param r
     */
    public void set(long a, long b, long r) {
        this.a = a;
        this.b = b;
        this.r = r;
    }
    
    /**
     * 计算无权重的散列值
     * @param d
     * @return
     */
    public long hash(long d) {
        return (a * d + b) % r;
    }

    /**
     * 计算有权重的散列值
     * @param d
     * @param w
     * @return
     */
    public double hash(long d, double w) {
        long t = (a * d + b) % r;
        if (t < 0) t += r;
        return Math.log(((double)r)/(r-t))/w;
    }

    /**
     * 对一个集合计算无权重的MinHash值
     * @param digest
     * @return
     */
    public long getMinHash(long[] digest) {
        long minvalue = -1;
        long minhash = Long.MAX_VALUE;

        for (int i = 0; i < digest.length; i++) {
            long current = hash(digest[i]);
            if (current < minhash) {
                minhash = current;
                minvalue = digest[i];
            }
        }
        return minvalue;
    }

    /**
     * 对一个集合计算Weighted-MinHash值
     * @param digest
     * @param len
     * @return
     */
    public long getMinHash(long[] digest, double[] weights) {
        assert digest.length == weights.length;        
        long minvalue = -1;
        double minhash = Double.MAX_VALUE;

        for (int i = 0; i < digest.length; i++) {
            double current = hash(digest[i], weights[i]);
            if (current < minhash) {
                minhash = current;
                minvalue = digest[i];
            }
        }
        return minvalue;
    }

    /**
     * 解析字符串读入LSH参数
     * @see #toString()
     */
    public void parse(String str) {
        String[] s = str.split(DELIMITER, 3);
        a = Long.parseLong(s[0]);
        b = Long.parseLong(s[1]);
        r = Long.parseLong(s[2]);
    }
    
    @Override
    public String toString() {
        return a + DELIMITER + b + DELIMITER + r;
    }

}
