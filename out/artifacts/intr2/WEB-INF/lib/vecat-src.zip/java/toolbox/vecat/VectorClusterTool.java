/**
 * @(#)QueryBucketTool.java, Sep 4, 2009. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.vecat;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.PerKeyBufferedWalker;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.toolkit.WritablePair;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;
import toolbox.cluster.Instance;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.base.BucketKeyPosEncoderDecoder;
import toolbox.vecat.base.BucketUtils;
import toolbox.vecat.base.CosHashUtils;
import toolbox.vecat.base.ObjectPool;
import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.BucketInfo;
import toolbox.vecat.data.StringDim;
import toolbox.vecat.data.Vector;
import toolbox.vecat.utils.Utils;

/**
 * 对Vector进行聚类
 * @author caofx
 *
 */
public class VectorClusterTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(VectorClusterTool.class);

    public static final String INDEX_PATH = "index";
    public static final String RESULT_PATH = "result";
    public static final String CLUSTER_PATH = "cluster";
    public static final String BUCKET_PATH = "bucket";
    
    // 只在 pair-output 模式下使用
    public static final String LARGE_PATH = "large";
    public static final String PAIR_PATH = "graph/input/edge/pair";

    private static final String CFG_SIG_LENGTH = "CFG_SIG_LENGTH";
    private static final String CFG_GROUP_COUNT = "CFG_GROUP_COUNT";
    private static final String CFG_SHINGLE_COUNT = "CFG_SHINGLE_COUNT";
    private static final String CFG_BUFFER_SIZE = "CFG_BUFFER_SIZE";
    private static final String CFG_SIM_THRESHOLD = "CFG_SIM_THRESHOLD";
    private static final String CFG_KEEP_ISOLATE = "CFG_KEEP_ISOLATE";
    private static final String CFG_PAIR_MODE = "CFG_PAIR_MODE";

    private static enum CounterName {
        BUCKET_COUNT,
        LARGE_BUCKET_COUNT,
        LARGE_BUCKET_ELEMENT_COUNT,
        PAIR_COUNT,
        ISOLATED_COUNT,
        CLUSTER_COUNT,
        PROCESS_COUNT,
        ELEMENT_COUNT,
    }

    @Override
    public String comment() {
        return "Do vector clustering";
    }

    @Override
    protected void prepareOptions(Options opt) {
        opt.withOption("i", "input", "input path");
        opt.withOption("o", "output", "output path");
        opt.withOption("l", "sig_length", "signiture vector length");
        opt.withOption("gc", "group", "signiture group count");
        opt.withOption("sc", "shingle_count ", "group count for shingles");
        opt.withOption("bs", "buffer_size", "buffer size");
        opt.withOption("s", "sim_threshold", "similarity threshold");
        opt.withOption("c", "catch_prob", "catch probability threshold, real cath probability under this will cause keeping isolate elements").setDefault(0);
        opt.withOption("pair", "pair-output mode");
        opt.withOption("mc", "do compression in map");
        opt.withOption("run", "run the job");
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(options.getOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        
        int sigLength = options.getIntOpt("l");
        int groupCount = options.getIntOpt("gc");
        int shingleCount = options.getIntOpt("sc");
        int bufferSize = options.getIntOpt("bs");
        double simThreshold = options.getDoubleOpt("s");
        double catchProb = options.getDoubleOpt("c");
        boolean pairMode = options.isOptSet("pair");
        boolean mapCompress = options.isOptSet("mc");
        boolean run = options.isOptSet("run");
        
        return exec(getToolName(), context, out, nWorker, inputPath, outputPath,
                sigLength, groupCount, shingleCount, simThreshold, catchProb, 
                bufferSize, pairMode, mapCompress, run) >= 0;
    }
    
    /**
     * @param jobName
     * @param context
     * @param out
     * @param nWorker
     * @param inputPath
     * @param outputPath
     * @param sigLength
     * @param groupCount
     * @param shingleCount
     * @param simThreshold
     * @param catchProb
     * @param bufferSize
     * @param pairMode
     * @param mapCompress
     * @param run
     * @return <0 失败; == 0 成功; > 0 成功, 返回数值为得到的Cluster数目
     * @throws Exception
     */
    public static long exec(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path inputPath, Path outputPath, int sigLength, int groupCount, int shingleCount, double simThreshold, double catchProb, 
            int bufferSize, boolean pairMode, boolean mapCompress, boolean run) throws Exception {
        out.println("Start running tool with following settings:");
        out.println("sig length: " + sigLength);
        out.println("group count: " + groupCount);
        out.println("shingle count: " + shingleCount);
        out.println("buffer size: " + bufferSize);
        out.println("similarity threshold: " + simThreshold);
        
        double cp = BucketUtils.shingleCatchProb(sigLength, groupCount, shingleCount, simThreshold);
        boolean keepIsolate = cp < catchProb;
        out.println("catch probability threshold: " + catchProb);
        out.println("probability for catching similar pair with threshold: " + cp);
        out.println("keep isolated elements: " + keepIsolate + ", because " + cp + (keepIsolate?" < ":" >= ") + catchProb);
        
        out.println("converted diff threshold for specified sig length: " + CosHashUtils.sim2Diff(simThreshold, sigLength));
        out.println("shingle length: " + (double)shingleCount*sigLength/groupCount);
        out.println("shingle count per element: " + BucketUtils.shingleCountPerElement(groupCount, shingleCount));
        out.println("estimated total bucket count for infinite element count: " +BucketUtils.totalBucketCount(sigLength, groupCount, shingleCount));
        out.println("equivalent disjoint bucket count: " + BucketUtils.totalBucketCount(sigLength, groupCount, shingleCount)/BucketUtils.shingleCountPerElement(groupCount, shingleCount));
        out.println("pair output mode: " + pairMode);
        out.println("run the job: " + run);
        if(!run) {
            out.println("use \"-run\" option to run the job.");
            return 0;
        }
        
        if(!doCluster(jobName + ".cluster", context, out, nWorker, inputPath, outputPath,
                sigLength, groupCount, shingleCount, simThreshold, bufferSize, keepIsolate, pairMode, mapCompress)) {
            return -1;
        }
        if(pairMode) return 0;
        
        return buildCentroid(jobName + ".centroid", context, out, nWorker, inputPath, outputPath.cat(INDEX_PATH), outputPath);
    }
    
    public static boolean doCluster(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path inputPath, Path outputPath, int sigLength, int groupCount, int shingleCount, double simThreshold,
            int bufferSize, boolean keepIsolate, boolean pairMode, boolean mapCompress) throws Exception {
        MrStarJobDef job = context.createMrStarJob(2, jobName, nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        job.setMapper(0, Mapper.class);
        job.setReducer(0, ClusterReducer.class);
        helper.addReadInputDir(0, inputPath, null);
        helper.addUpdateOutputDir(0, ClusterReducer.CON_BUCKET, outputPath.cat(BUCKET_PATH), StringWritable.class, BucketInfo.class, null);
        GenericFileOutputFormat.setCompress(job, 0, ClusterReducer.CON_BUCKET, 0);
        if(pairMode) {
            helper.addUpdateOutputDir(0, ClusterReducer.CON_LARGE, outputPath.cat(LARGE_PATH), StringWritable.class, Vector.class, null);
            GenericFileOutputFormat.setCompress(job, 0, ClusterReducer.CON_LARGE, 0);
        }
        job.setMergeKeyValClass(0, StringWritable.class, StrVectorPair.class);
        job.setPartitionerClass(0, SeqFileHashPartitioner.class);
        job.setWalkerClass(0, PerKeyBufferedWalker.class);
        
        job.setReducer(1, MergeReducer.class);
        if(pairMode) {
            helper.addUpdateOutputDir(1, MergeReducer.CON_INDEX, outputPath.cat(PAIR_PATH), Instance.ID.class, Instance.ID.class, null);
            GenericFileOutputFormat.setCompress(job, 1, MergeReducer.CON_INDEX, 0);
        } else {
            helper.addUpdateOutputDir(1, MergeReducer.CON_INDEX, outputPath.cat(INDEX_PATH), StringWritable.class, StringWritable.class, null);
            GenericFileOutputFormat.setCompress(job, 1, MergeReducer.CON_INDEX, 0);
        }
        job.setMergeKeyValClass(1, StringWritable.class, StringDim.class);
        job.setPartitionerClass(1, SeqFileHashPartitioner.class);
        job.setWalkerClass(1, ReuseWalker.class);
        
        job.setMapNumber(nWorker);
        job.setMrNumber(1, nWorker*4);
        job.setReduceNumber(MapReduceHelper.getContinuousPartCount(context.getFileSystem(), inputPath));
        
        if (mapCompress) {
            BasicPartitioner.setCompress(job, 0, 0, false);
        }
        job.setCheckMapProgress(false);
        job.setCheckMrProgress(1, false);
        job.setCheckReduceProgress(false);
        
        job.getConfig().setInt(CFG_SIG_LENGTH, sigLength);
        job.getConfig().setInt(CFG_GROUP_COUNT, groupCount);
        job.getConfig().setInt(CFG_SHINGLE_COUNT, shingleCount);
        job.getConfig().setInt(CFG_BUFFER_SIZE, bufferSize);
        job.getConfig().setDouble(CFG_SIM_THRESHOLD, simThreshold);
        job.getConfig().setBoolean(CFG_KEEP_ISOLATE, keepIsolate);
        job.getConfig().setBoolean(CFG_PAIR_MODE, pairMode);
        
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static long buildCentroid(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path sigPath, Path indexPath, Path outputPath) throws Exception {
        MapReduceJobDef job = context.createMapReduceJob(jobName, nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        MapMergeConf mmc = new MapMergeConf();
        mmc.setMergeMapper(CentroidMapper.class);
        mmc.setMergeCount(CentroidMapper.CIN_NUM);
        mmc.setMergeDir(CentroidMapper.CIN_INDEX, indexPath, ReuseWalker.class);
        mmc.setMergeDir(CentroidMapper.CIN_SIGNITURE, sigPath, ReuseWalker.class);
        job.plugin(mmc);
        
        job.setReducer(CentroidReducer.class);
        job.setMergeKeyValClass(StringWritable.class, StrVectorPair.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(CentroidReducer.CON_CLUSTER, outputPath.cat(CLUSTER_PATH), StringWritable.class, Vector.class, null);
        GenericFileOutputFormat.setCompress(job, CentroidReducer.CON_CLUSTER, 0);
        helper.addUpdateOutputDir(CentroidReducer.CON_RESULT, outputPath.cat(RESULT_PATH), StringWritable.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, CentroidReducer.CON_RESULT, 0);
        
        int partCount = MapReduceHelper.getContinuousPartCount(context.getFileSystem(), sigPath);
        job.setMapNumber(partCount);
        job.setReduceNumber(partCount);

        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return -1;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return result.getCounters()[1].get(CounterName.CLUSTER_COUNT.name()).get();
    }
    
    private static int compareCluster(String firstCluster, double firstValue, String secondCluster, double secondValue) {
        int ret = Double.compare(secondValue, firstValue);
        if(ret != 0) return ret;
        return firstCluster.compareTo(secondCluster);
    }

    public static class StrVectorPair extends WritablePair<StringWritable, Vector> {

        @Override
        protected StringWritable newFirstInstance() {
            return new StringWritable();
        }

        @Override
        protected Vector newSecondInstance() {
            return new Vector();
        }
        
        /**
         * 深拷贝
         * @param s
         * @param v
         */
        public void set(String s, Vector v) {
            first.set(s);
            second.copyFields(v);
        }
    }
    
    /**
     * 描述内存中的一个 Cluster
     * @author caofx
     *
     */
    private static class Cluster {
        private String id = null;
        private int size = 0;
        private Vector centroid = new Vector();
        private ArrayList<StrVectorPair> elements = new ArrayList<StrVectorPair>();
        
        /**
         * @param dim
         */
        public void init(int dim) {
            id = null;
            size = 0;
            centroid.resize(dim);
            centroid.clear();
            elements.clear();
        }
        
        /**
         * 更新cluster size计数及centroid
         * @param element
         */
        public void update(StrVectorPair element, boolean save) {
            size ++;
            for(int i = 0; i < centroid.size(); i ++) {
                centroid.setValue(i, centroid.getValue(i) + element.getSecond().getValue(i));
            }
            if(save) elements.add(element);
        }
        
        public void merge(Cluster o) {
            size += o.size;
            for(int i = 0; i < centroid.size(); i ++) {
                centroid.setValue(i, centroid.getValue(i) + o.centroid.getValue(i));
            }
            elements.addAll(o.elements);
        }
        
        public void setID(String id) {
            this.id = id;
        }
        
        public String getId() {
            return id;
        }

        public int getSize() {
            return size;
        }

        public Vector getCentroid() {
            return centroid;
        }
        
        public ArrayList<StrVectorPair> getElements() {
            return elements;
        }
        
    }
    
    public static class Mapper extends AbstractMapper<StringWritable, Vector> {
        private int sigLength;
        private int groupCount;
        private int shingleCount;
        private int[][] groupCovering;
        private StringWritable bucketKey = new StringWritable();
        private StringWritable defaultBucketKey = new StringWritable("");
        private BitArray bitArray = new BitArray();
        private ArrayList<Integer> newpos = new ArrayList<Integer>();
        private StrVectorPair pair = new StrVectorPair();


        @Override
        public void configure(JobDef job, TaskRunnable task) {
            sigLength = job.getConfig().getInt(CFG_SIG_LENGTH);
            groupCount = job.getConfig().getInt(CFG_GROUP_COUNT);
            shingleCount = job.getConfig().getInt(CFG_SHINGLE_COUNT);

            int[] groupSize = BucketUtils.naiveSplitPolicy(sigLength, groupCount);
            groupCovering = new int[groupCount][];

            int begin = 0;
            for (int i = 0; i < groupCount; i++) {
                int size = groupSize[i];
                groupCovering[i] = new int[size];
                for (int j = 0; j < size; j++) {
                    groupCovering[i][j] = begin + j;
                }
                begin += size;
                Arrays.sort(groupCovering[i]);
            }

        }

        public void setBucketKey(Vector v, int[] pos, StringWritable bucketKey) {
            String posStr = BucketKeyPosEncoderDecoder.compactPosArrayEncoder(pos);
            bitArray.resize(pos.length);
            for(int i = 0; i < pos.length; i ++) {
                bitArray.setValue(i,CosHashUtils.getSig(v, pos[i]));
            }
            bucketKey.set(posStr + "," + bitArray.hexString());
        }

        @Override
        public void map(StringWritable key, Vector value, ICollector collector) {
            pair.set(key.toString(), value);
            
            if(shingleCount == 0) {
                // 不分桶
                collector.collect(defaultBucketKey, pair);
                return;
            }
            
            // 分组签名并输出
            int[] selectedBucket = null;
            while (true) {
                selectedBucket = BucketUtils.nextCombination(groupCount, shingleCount, selectedBucket);
                if (selectedBucket[0] < 0) break;

                newpos.clear();
                for (int bucketIdx: selectedBucket) {
                    for (int j = 0; j < groupCovering[bucketIdx].length; j++) {
                        newpos.add(groupCovering[bucketIdx][j]);
                    }
                }

                Collections.sort(newpos);
                int[] newposa = new int[newpos.size()];
                for (int i = 0; i < newpos.size(); i++) {
                    newposa[i] = newpos.get(i);
                }
                setBucketKey(pair.getSecond(), newposa, bucketKey);
                collector.collect(bucketKey, pair);
            }
        }
    }

    /**
     * 在桶内进行clustering, 并生成局部从属关系
     * @author caofx
     *
     */
    public static class ClusterReducer extends AbstractReducer<StringWritable, StrVectorPair> {
        private static final int CON_BUCKET = 0;
        private static final int CON_LARGE = 1; // 只在pair-output模式下使用
        
        private int bufferSize;
        private double simThreshold;
        private boolean keepIsolate;
        private boolean pairMode;
        private LinkedList<Cluster> clusterList = new LinkedList<Cluster>();
        private ObjectPool<Cluster> clusterPool = new ObjectPool<Cluster>() {
            @Override
            protected Cluster newInstance() {
                return new Cluster();
            }
        }; // cluster对象池, 复用小对象
        private StringDim clusterSimPair = new StringDim();
        private BucketInfo bucketInfo = new BucketInfo();
        private StringWritable elementID = new StringWritable();
        private Counter bucketCounter;
        private Counter largeBucketCounter;
        private Counter largeBucketElementCounter;
        private Counter pairCounter;
        private Counter isolatedCounter;
        private Counter clusterCounter;
        private Counter processCounter;

        public void configure(JobDef job, TaskRunnable task) {
            // 读取参数
            bufferSize = job.getConfig().getInt(CFG_BUFFER_SIZE);
            simThreshold = job.getConfig().getDouble(CFG_SIM_THRESHOLD);
            keepIsolate = job.getConfig().getBoolean(CFG_KEEP_ISOLATE);
            pairMode = job.getConfig().getBoolean(CFG_PAIR_MODE);
            // 初始化计数器
            bucketCounter = task.getCounter(CounterName.BUCKET_COUNT.name());
            largeBucketCounter = task.getCounter(CounterName.LARGE_BUCKET_COUNT.name());
            largeBucketElementCounter = task.getCounter(CounterName.LARGE_BUCKET_ELEMENT_COUNT.name());
            pairCounter = task.getCounter(CounterName.PAIR_COUNT.name());
            isolatedCounter = task.getCounter(CounterName.ISOLATED_COUNT.name());
            clusterCounter = task.getCounter(CounterName.CLUSTER_COUNT.name());
            processCounter = task.getCounter(CounterName.PROCESS_COUNT.name());
        }

        private String getSigniture(Vector v) {
            return CosHashUtils.getSigString(v);
        }

        private void collectElement(String cluster, String element, double size, ICollector collector) {
            clusterSimPair.setIndex(cluster);
            clusterSimPair.setValue(size);
            elementID.set(element);
            collector.collect(elementID, clusterSimPair);
            pairCounter.inc();
        }

        public void reduce(StringWritable key, IWritablePairWalker<StringWritable, StrVectorPair> values,
                ICollector collector) {
            bucketCounter.inc();
            clusterPool.push(clusterList);
            long count = 0;
            long largeBucketElementCount = 0;
            while (values.moreValue()) {
                StrVectorPair currentValue = values.getValue();
                Cluster currentCluster = null;
                double currentSim = 0;
                count ++;
                boolean save = (count <= bufferSize); // 该元素是否超限
                processCounter.inc();
                
                /// 1. 与每个cluster比较
                int clusterSize = clusterList.size();
                for(int i = 0; i < clusterSize; i ++) {
                    // 从clusterList头部取出一个cluster, 并将其插入末尾
                    Cluster cluster = clusterList.removeFirst();
                    clusterList.addLast(cluster);
                    
                    double sim = CosHashUtils.getSimilarity(currentValue.getSecond(), cluster.getCentroid());
                    if(sim >= simThreshold) {
                        // 1.1 相似度高于阈值
                        if(currentCluster == null) {
                            currentCluster = cluster;
                        } else {
                            if(CosHashUtils.getSimilarity(currentCluster.getCentroid(), cluster.getCentroid()) >= simThreshold) {
                                // 满足条件则合并两个Cluster
                                currentCluster.merge(cluster);
                                currentSim = CosHashUtils.getSimilarity(currentValue.getSecond(), currentCluster.getCentroid());
                                // 删除被合并的cluster
                                clusterPool.push(clusterList.removeLast());
                            } else {
                                // 不能合并则选取最相似的cluster作为candidate
                                if(sim > currentSim) {
                                    currentCluster = cluster;
                                    currentSim = sim;
                                }
                            }
                        }
                    }
                }
                
                /// 2. 如果当前元素加入某个Cluster, 则更新该Cluster, 否则根据容量限制创建新的cluster
                if(currentCluster == null && save) {
                    // 如果未超限 
                    currentCluster = clusterPool.pop(); 
                    currentCluster.init(currentValue.getSecond().size());
                    clusterList.addLast(currentCluster);
                    clusterCounter.inc();
                }
                
                if(currentCluster != null) {
                    currentCluster.update(currentValue, save);
                }
                
                /// 3. 超限时将元素输出以备后续流程处理, 不管是否超限, 前面都要走一遍比较质心的流程, 但不增加新的质心.
                /// 其目的是为了后面能尽可能地判断出孤立元素并剔除之
                if(!save) {
                    // size 设置为 1, 以期望在后续处理中该元素能被指派给size > 1的cluster
                    // pair-output 模式下直接输出到LARGE_PATH
                    if(pairMode) {
                        collector.collectToChannel(CON_LARGE, currentValue.getFirst(), currentValue.getSecond());
                    } else {
                        collectElement(getSigniture(currentValue.getSecond()), currentValue.getFirst().get(), 1, collector);
                    }
                    largeBucketElementCount ++;
                    largeBucketElementCounter.inc();
                    continue;
                }
            }
            
            /// 4. 将缓存的每个元素及其从属的cluster输出
            int clusterCount = 0;
            for(Cluster cluster: clusterList) {
                // 不输出该桶中的离群点(即singleton cluster)when !keepIsolate
                if(cluster.getSize() < 2 && !keepIsolate) {
                    continue;
                }
                
                clusterCount ++;
                ArrayList<StrVectorPair> elements = cluster.getElements();
                
                // 设置Cluster id
                int start = 0;
                if(pairMode) {
                    // pair-output模式下将clusterID设置为第一个elementID
                    cluster.setID(elements.get(0).getFirst().get());
                    start = 1;
                } else {
                    cluster.setID(getSigniture(cluster.getCentroid()));
                }
                
                // 输出元素归属
                for(int i = start; i < elements.size(); i ++) {
                    collectElement(cluster.getId(), elements.get(i).getFirst().get(), cluster.getSize(), collector);
                }

            }

            /// 5. 输出当前桶的信息
            int isolatedCount = clusterList.size() - clusterCount;
            isolatedCounter.inc(isolatedCount);
            bucketInfo.set(count, isolatedCount, clusterCount);
            collector.collectToChannel(CON_BUCKET, key, bucketInfo);
            if(largeBucketElementCount > 0) {
                largeBucketCounter.inc();
            }
        }

    }

    /**
     * 为每个元素选取合适的cluster并输出从属关系
     * @author caofx
     *
     */
    public static class MergeReducer extends AbstractReducer<StringWritable, StringDim> {
        private static final int CON_INDEX = 0;
        private boolean pairMode;
        private StringWritable clusterID = new StringWritable();
        private Instance.ID keyID = new Instance.ID();
        private Instance.ID valueID = new Instance.ID();
        private Counter elementCounter;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            pairMode = job.getConfig().getBoolean(CFG_PAIR_MODE);
            elementCounter = task.getCounter(CounterName.ELEMENT_COUNT.name());
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringDim> values,
                ICollector collector) {
            elementCounter.inc();
            // pair-output 模式, 直接输出pair
            if(pairMode) {
                while(values.moreValue()) {
                    StringDim value = values.getValue();
                    String c = value.getIndex();
                    if(!c.equals(key.get())) {
                        Utils.setInstanceID(keyID, key.get());
                        Utils.setInstanceID(valueID, c);
                        collector.collectToChannel(0, keyID, valueID);
                    }
                }
                return;
            }
            
            // 正常模式
            double maxValue = -Double.MAX_VALUE;
            String nearCluster = null;
            while(values.moreValue()) {
                StringDim value = values.getValue();
                if(compareCluster(value.getIndex(), value.getValue(), nearCluster, maxValue) < 0) {
                    nearCluster = value.getIndex();
                    maxValue = value.getValue();
                }
            }
            assert(nearCluster != null);
            clusterID.set(nearCluster);
            collector.collectToChannel(CON_INDEX, key, clusterID);
        }
        
    }

    public static class CentroidMapper implements IMergeMapper<StringWritable, IWritable> {
        private static final int CIN_INDEX = 0;
        private static final int CIN_SIGNITURE = 1;
        private static final int CIN_NUM = 2;
        private static StrVectorPair pair = new StrVectorPair();

        @Override
        public void configure(JobDef conf, TaskRunnable task) {
        }

        @Override
        public void map(StringWritable key,
                IWritablePairWalker<StringWritable, IWritable>[] mergeValues,
                ICollector collector) {
            if(mergeValues[CIN_SIGNITURE] == null || !mergeValues[CIN_SIGNITURE].moreValue()) {
                throw new RuntimeException("Data corruption");
            }
            Vector sig = (Vector)mergeValues[CIN_SIGNITURE].getValue();
            
            pair.set(key.get(), sig);
            while(mergeValues[CIN_INDEX] != null && mergeValues[CIN_INDEX].moreValue()) {
                collector.collect(mergeValues[CIN_INDEX].getValue(), pair);
            }
        }

        @Override
        public void mapBegin() {
        }

        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }
    
    public static class CentroidReducer extends AbstractReducer<IWritable, StrVectorPair> {
        private static final int CON_CLUSTER = 0;
        private static final int CON_RESULT = 1;
        private Vector tempVector = null;
        private Counter clusterCounter;

        public void configure(JobDef job, TaskRunnable task) {
            clusterCounter = task.getCounter(CounterName.CLUSTER_COUNT.name());
        }

        @Override
        public void reduce(IWritable key,
                IWritablePairWalker<IWritable, StrVectorPair> values,
                ICollector collector) {
            // 对内积各分量值求和
            if(tempVector != null){
                tempVector.clear();
            }
            while(values.moreValue()) {
                StrVectorPair value = values.getValue();
                Vector vector = value.getSecond();
                if(tempVector == null) {
                    tempVector = new Vector(vector.size());
                    tempVector.copyFields(vector);
                } else {
                    for(int i = 0; i < vector.size(); i ++) {
                        tempVector.setValue(i, tempVector.getValue(i) + vector.getValue(i));
                    }
                }
                collector.collectToChannel(CON_RESULT, key, value.getFirst());
            }
            
            collector.collectToChannel(CON_CLUSTER, key, tempVector);
            clusterCounter.inc();
        }
    }
    
}
