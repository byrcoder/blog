package toolbox.vecat;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.ClusterCollectTool.StrLongPair;
import toolbox.vecat.ClusterCollectTool.StrLongPairList;

/**
 * 合并Cluster的数据
 * @author caofx
 *
 */
public class MergeClusterTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(MergeClusterTool.class);
   
    private static enum CounterName {
        CLUSTER_COUNT,
        INVALID_COUNT,
        ELEMENT_COUNT,
    }
    
    @Override
    public String comment() {
        return "Merge clusters.";
    }
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("p", "output_part", "set output part num. 0 means using input part num").setDefault(0);
        options.withOption("s", "super_path", "set super cluster path.");
        options.withOption("o", "output_path", "set output path.");
    }
    
    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(options.getStringOpt("i"));
        Path superPath = context.path(options.getStringOpt("s"));
        Path outputPath = context.path(options.getStringOpt("o"));
        int part = options.getIntOpt("p");
        return exec(getToolName(), context, out, nWorker, inputPath, superPath, outputPath, part);
    }
    
    public static boolean exec(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path inputPath, Path superPath, Path outputPath, int part) throws Exception {
        // MR settings
        MapReduceJobDef job = context.createMapReduceJob(jobName + ".merge", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        MapMergeConf mmc = new MapMergeConf();
        mmc.setMergeMapper(Mapper.class);
        mmc.setMergeCount(Mapper.CIN_NUM);
        mmc.setMergeDir(Mapper.CIN_DATA, inputPath, ReuseWalker.class);
        mmc.setMergeDir(Mapper.CIN_SUPER, superPath, ReuseWalker.class);
        job.plugin(mmc);
        
        job.setReducer(Reducer.class);
        job.setMergeKeyValClass(StringWritable.class, StringWritable.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);

        int partCount = MapReduceHelper.getContinuousPartCount(context.getFileSystem(), superPath);
        if(part == 0) part = partCount;
        job.setMapNumber(partCount);
        job.setReduceNumber(part);
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);
        
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    /**
     * 合并两轮cluster result
     * @author caofx
     *
     */
    public static class Mapper implements IMergeMapper<StringWritable, IWritable> {
        private static final int CIN_DATA = 0;
        private static final int CIN_SUPER = 1;
        private static final int CIN_NUM = 2;
        private ArrayList<StringWritable> clusters = new ArrayList<StringWritable>();
        private Counter clusterCounter;
        private Counter invalidCounter;
        
        @Override
        public void configure(JobDef conf, TaskRunnable task) {
            clusterCounter = task.getCounter(CounterName.CLUSTER_COUNT.name());
            invalidCounter = task.getCounter(CounterName.INVALID_COUNT.name());
        }

        @Override
        public void map(
                StringWritable key,
                IWritablePairWalker<StringWritable, IWritable>[] mergeValues,
                ICollector collector) {
            clusters.clear();
            while(mergeValues[CIN_SUPER] != null && mergeValues[CIN_SUPER].moreValue()) {
                IWritable supers = mergeValues[CIN_SUPER].getValue();
                if(supers instanceof StrLongPairList) {
                    for(StrLongPair s: (StrLongPairList)supers) {
                        clusters.add(new StringWritable(s.getFirst()));
                    }
                } else {
                    clusters.add(new StringWritable((StringWritable)supers));
                }
            }
            
            if(mergeValues[CIN_DATA] == null) {
                invalidCounter.inc();
                if(clusters.size() > 0) {
                    throw new RuntimeException(key.toString() + ", " + clusters.toString());
                }
                return;
            }
            
            if(clusters.size() == 0) clusters.add(key);

            while(mergeValues[CIN_DATA].moreValue()) {
                for(StringWritable cluster: clusters) {
                    collector.collect(mergeValues[CIN_DATA].getValue(), cluster);
                }
            }
            clusterCounter.inc(clusters.size());
        }

        @Override
        public void mapBegin() {
        }

        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }
    
    /**
     * 生成新的index
     * @author caofx
     *
     */
    public static class Reducer extends AbstractReducer<StringWritable, StringWritable> {
        private Counter elementCounter;
        
        @Override
        public void configure(JobDef conf, TaskRunnable task) {
            elementCounter = task.getCounter(CounterName.ELEMENT_COUNT.name());
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringWritable> values,
                ICollector collector) {
            elementCounter.inc();
            while(values.moreValue()) {
                collector.collectToChannel(0, key, values.getValue());
            }
        }
        
    }
    
}
