package toolbox.vecat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Map.Entry;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.data.SparseVector;
import toolbox.vecat.data.StringDim;
import toolbox.vecat.data.StringSparseVector;
import toolbox.vecat.utils.RandomVectorGenerator;

public class RandomIndexTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(RandomIndexTool.class);
    private static final String MAIN_DATA_PATH = "main";
    private static final String TRANSPOSE_PATH = "transpose";
    private static final String PROJECTION_PATH = "projection";
    private static final String COMPLEMENT_PROJECTION_PATH = "complement";
    private static final int DEFAULT_QUEUE_INITIAL_CAPACITY = 10000;

    private static final String CFG_RANDOM_METHOD = RandomIndexTool.class.getName() + "CFG_RANDOM_METHOD";
    private static final String CFG_DIM_SIZE = RandomIndexTool.class.getName() + "CFG_DIM_SIZE";
    private static final String CFG_SEED_SIZE = RandomIndexTool.class.getName() + "CFG_SEED_SIZE";
    private static final String CFG_ROW_TRUNCATE_SIZE = RandomIndexTool.class.getName() + "CFG_ROW_TRUNCATE_SIZE";
    private static final String CFG_COLUMN_TRUNCATE_SIZE = RandomIndexTool.class.getName() + "CFG_COLUMN_TRUNCATE_SIZE";

    private static enum CounterName {
        INVALID_ELEMENT_COUNT,
        EMPTY_ELEMENT_COUNT,
        ROW_TRUNCATED_COUNT,
        COLUMN_TRUNCATED_COUNT
    }

    private Path inputPath;
    private Path outputPath;
    private String randomMethod;
    private boolean reverse;
    private int dimSize;
    private int seedSize;
    private int rowTruncateSize;
    private int columnTruncateSize;

    @Override
    public String comment() {
        return "Random indexing for dimension reduction";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("r", "do reverse indexing.");
        options.withOption("m", "random_method", "set random method: gauss, achlioptas1, achlioptas2.");
        options.withOption("d", "dim_size", "set dimsize.");
        options.withOption("s", "seed_size", "set seed size");
        options.withOption("tr", "truncate_size1", "set truncate size for rows.").setDefault(Integer.MAX_VALUE);
        options.withOption("tc", "truncate_size2", "set truncate size for columns.").setDefault(Integer.MAX_VALUE);
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        // 环境设置, 初始化
        inputPath = context.path(options.getStringOpt("i"));
        outputPath = context.path(options.getStringOpt("o"));
        randomMethod = options.getStringOpt("m");
        reverse = options.isOptSet("r");
        dimSize = options.getIntOpt("d");
        seedSize = options.getIntOpt("s");
        rowTruncateSize = options.getIntOpt("tr");
        columnTruncateSize = options.getIntOpt("tc");
        LOG.info("inputPath = " + inputPath.getAbsolutePath());
        
        IFileSystem fs = context.getFileSystem();
        if(!fs.exists(outputPath)) {
            fs.mkdirs(outputPath);
        }
        
        boolean ret;
        // 转换数据格式
        if(!fs.exists(outputPath.cat(MAIN_DATA_PATH)) || !fs.exists(outputPath.cat(TRANSPOSE_PATH))) {
            LOG.info("Convert data ...");
            ret = convert(nWorker);
            if(!ret) return ret;
        }
        
        if(!reverse) {
            // 正向Indexing
            LOG.info("Do indexing ...");
            ret = index(outputPath.cat(TRANSPOSE_PATH), outputPath.cat(COMPLEMENT_PROJECTION_PATH), outputPath.cat(PROJECTION_PATH), nWorker);
        } else {
            // 逆向Indexing
            LOG.info("Do reverse indexing ...");
            ret = index(outputPath.cat(MAIN_DATA_PATH), outputPath.cat(PROJECTION_PATH), outputPath.cat(COMPLEMENT_PROJECTION_PATH), nWorker);
        }
        return ret;
    }

    /**
     * 将原始数据转换为StringSparseVector及其转置
     * @param nWorker
     * @return
     * @throws Exception
     */
    private boolean convert(int nWorker) throws Exception {
        // MR settings
        MrStarJobDef job = context.createMrStarJob(2, getToolName() + ".convert", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(0, inputPath, null);
        job.setMapper(0, ConvertMapper.class);
        job.setReducer(0, TransposeReducer.class);
        job.setMergeKeyValClass(0, StringWritable.class, StringDim.class);
        job.setPartitionerClass(0, SeqFileHashPartitioner.class);
        job.setWalkerClass(0, ReuseWalker.class);
        helper.addUpdateOutputDir(0, 0, outputPath.cat(TRANSPOSE_PATH), StringWritable.class, StringSparseVector.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0, 0);
        
        job.setReducer(1, RestoreReducer.class);
        job.setMergeKeyValClass(1, StringWritable.class, StringDim.class);
        job.setPartitionerClass(1, SeqFileHashPartitioner.class);
        job.setWalkerClass(1, ReuseWalker.class);
        helper.addUpdateOutputDir(1, 0, outputPath.cat(MAIN_DATA_PATH), StringWritable.class, StringSparseVector.class, null);
        GenericFileOutputFormat.setCompress(job, 1, 0, 0);

        job.setMapNumber(nWorker);
        job.setMrNumber(1, nWorker);
        job.setReduceNumber(nWorker);
        
        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckMrProgress(1, false);
        job.setCheckReduceProgress(false);
        job.getConfig().setInt(CFG_ROW_TRUNCATE_SIZE, rowTruncateSize);
        job.getConfig().setInt(CFG_COLUMN_TRUNCATE_SIZE, columnTruncateSize);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    /**
     * @param mainPath
     * @param projectionPath 如不存在, 则使用随机投影向量
     * @param nWorker
     * @return
     * @throws Exception
     */
    private boolean index(Path mainPath, Path projectionPath, Path outputPath, int nWorker) throws Exception {
        // MR settings
        IFileSystem fs = context.getFileSystem();

        MapReduceJobDef job = context.createMapReduceJob(getToolName() + ".index", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        MapMergeConf mmc = new MapMergeConf();
        mmc.setMergeMapper(ProductMapper.class);
        mmc.setMergeCount(ProductMapper.CIN_NUM);
        mmc.setMergeDir(ProductMapper.CIN_MAIN_DATA, mainPath, ReuseWalker.class);
        if(fs.exists(projectionPath)) {
            mmc.setMergeDir(ProductMapper.CIN_PROJECTION_DATA, projectionPath, ReuseWalker.class);
        }
        job.plugin(mmc);
        
        job.setReducer(SumReducer.class);
        job.setMergeKeyValClass(StringWritable.class, SparseVector.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, SparseVector.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        int partNum = MapReduceHelper.getContinuousPartCount(context.getFileSystem(), mainPath);
        job.setMapNumber(partNum);
        job.setReduceNumber(partNum);
        
        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);
        job.getConfig().setProperty(CFG_RANDOM_METHOD, randomMethod);
        job.getConfig().setInt(CFG_DIM_SIZE, dimSize);
        job.getConfig().setInt(CFG_SEED_SIZE, seedSize);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    public static class ConvertMapper extends AbstractMapper<IWritable, StringSparseVector> {
        private StringWritable id = new StringWritable();
        private StringDim dim = new StringDim();
        private int rowTruncateSize;
        private Counter rowTruncatedCounter;
        private Comparator<StringDim> comparator = new Comparator<StringDim>() {
            @Override
            public int compare(StringDim o1, StringDim o2) {
                return Double.compare(o2.getValue(), o1.getValue());
            }
        };

        public void configure(JobDef job, TaskRunnable task) {
            rowTruncateSize = job.getConfig().getInt(CFG_ROW_TRUNCATE_SIZE);
            rowTruncatedCounter = task.getCounter(CounterName.ROW_TRUNCATED_COUNT.name());
        }
        
        @Override
        public void map(IWritable key, StringSparseVector value, ICollector collector) {
            // 转换并截断数据
            if(value.size() > rowTruncateSize) {
                value.truncate(rowTruncateSize, comparator );
                rowTruncatedCounter.inc();
            }
            
            // 分发转置(列)数据
            dim.setIndex(key.toString());
            for(int i  = 0; i < value.size(); i ++) {
                id.set(value.getIndexName(i));
                dim.setValue(value.getValue(i));
                collector.collect(id, dim);
            }
        }
    }
    
    public static class TransposeReducer extends AbstractReducer<StringWritable, StringDim> {
        private StringWritable id = new StringWritable();
        private StringDim dim = new StringDim();
        private PriorityQueue<StringDim> dims;
        private StringSparseVector vector = new StringSparseVector();
        private int columnTruncateSize;
        private Counter columnTruncatedCounter;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            columnTruncateSize = job.getConfig().getInt(CFG_COLUMN_TRUNCATE_SIZE);
            dims = new PriorityQueue<StringDim>(columnTruncateSize < DEFAULT_QUEUE_INITIAL_CAPACITY? columnTruncateSize: DEFAULT_QUEUE_INITIAL_CAPACITY, new Comparator<StringDim>() {
                @Override
                public int compare(StringDim o1, StringDim o2) {
                    return Double.compare(o1.getValue(), o2.getValue());
                }
            });
            columnTruncatedCounter = task.getCounter(CounterName.COLUMN_TRUNCATED_COUNT.name());
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringDim> values,
                ICollector collector) {
            // 构造并输出转置(列)数据
            dims.clear();
            boolean truncated = false;
            while(values.moreValue()) {
                StringDim v = values.getValue();
                if(dims.size() < columnTruncateSize) {
                    dims.add(new StringDim(v));
                } else if(dims.peek().getValue() < v.getValue()) {
                    dims.poll();
                    dims.add(new StringDim(v));
                    truncated = true;
                }
            }
            
            if(truncated) columnTruncatedCounter.inc();
            assert(dims.size() > 0);
            vector.set(dims);
            collector.collectToChannel(0, key, vector);
            
            // 分发原(行)数据
            dim.setIndex(key.toString());
            for(int i  = 0; i < vector.size(); i ++) {
                id.set(vector.getIndexName(i));
                dim.setValue(vector.getValue(i));
                collector.collect(id, dim);
            }
        }
        
    }
    
    public static class RestoreReducer extends AbstractReducer<StringWritable, StringDim> {
        private ArrayList<StringDim> dims = new ArrayList<StringDim>();
        private StringSparseVector vector = new StringSparseVector();

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringDim> values,
                ICollector collector) {
            // 收集输出原(行)数据
            dims.clear();
            while(values.moreValue()) {
                StringDim v = values.getValue();
                dims.add(new StringDim(v));
            }
            assert(dims.size() > 0);
            vector.set(dims);
            collector.collectToChannel(0, key, vector);
        }
        
    }

    public static class ProductMapper implements IMergeMapper<StringWritable, AbstractVector> {
        private static final int CIN_MAIN_DATA = 0;
        private static final int CIN_PROJECTION_DATA = 1;
        private static final int CIN_NUM = 2;
        private RandomVectorGenerator rvGenerator;
        private StringWritable id = new StringWritable();
        private SparseVector tempVector = new SparseVector();
        private Counter invalidElementCount;
        private Counter emptyElementCount;

        @Override
        public void configure(JobDef job, TaskRunnable task) {
            String randomMethod = job.getConfig().getString(CFG_RANDOM_METHOD);
            int dimSize = job.getConfig().getInt(CFG_DIM_SIZE);
            int seedSize = job.getConfig().getInt(CFG_SEED_SIZE);
            rvGenerator = new RandomVectorGenerator(randomMethod, task.getPartIdx(), dimSize, seedSize);
            invalidElementCount = task.getCounter(CounterName.INVALID_ELEMENT_COUNT.name());
            emptyElementCount = task.getCounter(CounterName.EMPTY_ELEMENT_COUNT.name());
        }

        @Override
        public void map(
                StringWritable key,
                IWritablePairWalker<StringWritable, AbstractVector>[] mergeValues,
                ICollector collector) {

            // 1. 获取当前元素的代表向量
            if(mergeValues[CIN_MAIN_DATA] == null || !mergeValues[CIN_MAIN_DATA].moreValue()) {
                invalidElementCount.inc();
                return;
            }
            AbstractVector mainVector = mergeValues[CIN_MAIN_DATA].getValue();
            LOG.info("Current Element: " + key.toString());
            if(mainVector.size() == 0) {
                emptyElementCount.inc();
                return;
            }
            
            // 2. 获取投影向量
            SparseVector projection = null;
            if(mergeValues[CIN_PROJECTION_DATA] == null || !mergeValues[CIN_PROJECTION_DATA].moreValue()) {
                // 投影向量数据不存在, 生成随机投影向量
                projection = rvGenerator.generateVector();
            } else {
                // 
                projection = (SparseVector) mergeValues[CIN_PROJECTION_DATA].getValue();
            }
            
            // 3. 对与当前元素相关的所有Element分发加权的投影向量
            tempVector.copyFields(projection); // for resize并拷贝projection的index
            for(int j = 0; j < mainVector.size(); j ++) {
                String index = mainVector.getIndexName(j);
                double weight = mainVector.getValue(j);
                // 投影向量数乘权重
                for(int i = 0; i < projection.size(); i ++) {
                    tempVector.setValue(i, weight * projection.getValue(i));
                }
                id.set(index);
                collector.collect(id, tempVector);
            }
        }

        @Override
        public void mapBegin() {
        }

        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }
    
    public static class SumReducer extends AbstractReducer<StringWritable, SparseVector> {
        private HashMap<Integer, Double> dimMap = new HashMap<Integer, Double>();  
        private SparseVector tempVector;
        
        public void configure(JobDef job, TaskRunnable task) {
            tempVector = new SparseVector();
        }       
        
        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, SparseVector> values,
                ICollector collector) {
            LOG.info("Current Element: " + key);
            // 1. 对加权向量加和
            dimMap.clear();
            while(values.moreValue()) {
                SparseVector vector = values.getValue();
                for(int i = 0; i < vector.size(); i ++) {
                    Double v = dimMap.get(vector.getIndex(i));
                    if(v == null) v = 0.0;
                    dimMap.put(vector.getIndex(i), v + vector.getValue(i));
                }
                
            }
            LOG.info("Current dims: " + dimMap);

            // 2. 输出结果
            tempVector.resize(dimMap.size());
            int i = 0;
            for(Entry<Integer, Double> entry: dimMap.entrySet()) {
                tempVector.setIndex(i, entry.getKey());
                // 非负值化
                tempVector.setValue(i, Math.abs(entry.getValue()));
                i ++;
            }
            tempVector.sort();
            collector.collectToChannel(0, key, tempVector);
        }
        
    }
    
    public static void main(String [] args) {
    	Object [] s = {"a", "b"};
    	System.out.println(Arrays.toString(s));
    	String [] ss = (String[]) s;
    	System.out.println(Arrays.toString(ss));
        RandomVectorGenerator rvGenerator = new RandomVectorGenerator("achlioptas1", 0, 1000, 10);
        for(int i = 0; i < 10; i ++) {
            System.out.println(rvGenerator.generateVector());
        }
        
        HashMap<Integer, Double> dimMap = new HashMap<Integer, Double>();
        double a = dimMap.get(1);
        System.out.println(a);
    }
}
