package toolbox.vecat.base;

import odis.serialize.IWritable;
import toolbox.vecat.data.AbstractVector;

/**
 * 将数据转换为 {@link AbstractVector}类型的接口
 * @author caofx
 *
 */
public interface IVectorConverter {
    /**
     * 将指定的IWritable记录转换为 {@link AbstractVector}的子类型, 返回null表明输入数据无效
     * @param key
     * @param value
     * @return
     */
    AbstractVector convert(IWritable key, IWritable value);
    
}
