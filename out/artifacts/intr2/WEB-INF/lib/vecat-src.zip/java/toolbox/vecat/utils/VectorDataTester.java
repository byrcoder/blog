package toolbox.vecat.utils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.app.view.SeqFileUtils;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.ext.IMergeReducer;
import odis.mapred.ext.ReduceMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.data.SparseVector;
import toolbox.vecat.data.StringSparseVector;

public class VectorDataTester extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(VectorDataTester.class);
    private static final String CFG_SAMPLE_NUM = VectorDataTester.class.getName() + "CFG_SAMPLE_NUM";
    private static final String CFG_SAMPLE_INTERVAL = VectorDataTester.class.getName() + "CFG_SAMPLE_INTERVAL";

    @Override
    public String comment() {
        return "Compute errors between original data and dimension-reduced ones";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("n", "sample_number", "set sample number.");
        options.withOption("t", "sample_interval", "set sample interval.");
        options.withOption("r", "raw_input_path", "set raw input path.");
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        // 环境设置, 初始化
        Path rawPath = context.path(options.getStringOpt("r"));
        Path inputPath = context.path(options.getStringOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        int sampleNum = options.getIntOpt("n");
        int sampleInterval = options.getIntOpt("t");

        LOG.info("rawPath = " + rawPath.getAbsolutePath());
        LOG.info("inputPath = " + inputPath.getAbsolutePath());

        // MR settings
        MapReduceJobDef job = context.createMapReduceJob(getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(rawPath, null);
        job.setMergeKeyValClass(StringWritable.class, StringSparseVector.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        job.setMapper(Mapper.class);

        ReduceMergeConf rmc = new ReduceMergeConf();
        rmc.setMergeCount(1);
        rmc.setMergeDir(0, helper.getReadInput(inputPath), ReuseWalker.class);
        rmc.setMergeReducer(Reducer.class);
        job.plugin(rmc);

        helper.addUpdateOutputDir(0, outputPath.cat("result"), StringWritable.class, Record.class, null);
        helper.addUpdateOutputDir(1, outputPath.cat("bad"), StringWritable.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        GenericFileOutputFormat.setCompress(job, 1, 0);
        job.setMapNumber(nWorker);
        int partNum = MapReduceHelper.getContinuousPartCount(context.getFileSystem(), inputPath);
        job.setReduceNumber(partNum);

        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);
        job.getConfig().setInt(CFG_SAMPLE_NUM, sampleNum);
        job.getConfig().setInt(CFG_SAMPLE_INTERVAL, sampleInterval);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        statResult(outputPath.cat("result"));
        return true;
    }

    public static int countInversionPair(Record [] records) {
        int count = 0;
        for(int i = 0; i < records.length; i ++) {
            for(int j = i+1; j < records.length; j ++) {
                if(records[i].index > records[j].index) count ++;
            }
        }
        return count;
    }

    public static double computeOrderSimilarity(Record [] records) {
        double similarity = 0;
        double m = 0;
        for(int i = 0; i < records.length; i ++) {
            similarity += (i+1)*(records[i].index+1);
            m += (i+1)*(i+1);
        }
        return similarity/m;
    }

    public void statResult(Path path) throws IOException {
        Map<Object, Object> map = SeqFileUtils.loadToMap(context.getFileSystem(), path);
        Record[] records = new Record[map.size()];
        int j = 0;
        for(Object record: map.values()) {
            records[j++] = (Record) record;
        }
        StringBuilder buffer = new StringBuilder("Results: \nRecord Count: " + records.length);
        // 统计误差
        double distanceError = 0;
        double similarityError = 0;
        Record meanRecord = new Record();
        for(Record record: records) {
            distanceError += Math.pow(record.distance1 - record.distance2, 2);
            similarityError += Math.pow(record.similarity1 - record.similarity2, 2);
            meanRecord.distance1 += record.distance1;
            meanRecord.distance2 += record.distance2;
            meanRecord.similarity1 += record.similarity1;
            meanRecord.similarity2 += record.similarity2;
        }
        distanceError = Math.sqrt(distanceError/records.length);
        similarityError = Math.sqrt(similarityError/records.length);
        meanRecord.distance1 /= records.length;
        meanRecord.distance2 /= records.length;
        meanRecord.similarity1 /= records.length;
        meanRecord.similarity2 /= records.length;
        buffer.append("\nDistance error: " + distanceError);
        buffer.append("\nMean Distance1: " + meanRecord.distance1);
        buffer.append("\nMean Distance2: " + meanRecord.distance2);
        buffer.append("\nSimilarity error: " + similarityError);
        buffer.append("\nMean Similarity1: " + meanRecord.similarity1);
        buffer.append("\nMean Similarity2: " + meanRecord.similarity2);

        // 统计distance()的逆序对数和OrderSimilarity
        Arrays.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                // TODO Auto-generated method stub
                return Double.compare(o1.distance1, o2.distance1);
            }
        });
        for(int i = 0; i < records.length; i ++) {
            records[i].index = i;
        }
        Arrays.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                // TODO Auto-generated method stub
                return Double.compare(o1.distance2, o2.distance2);
            }
        });
        int inversionPairCount = countInversionPair(records);
        buffer.append("\n(REF)InversionPair Count of reversed order: " + records.length*(records.length-1)/2);
        buffer.append("\nInversionPair Count in distance: " + inversionPairCount);
        double orderSimilarity = computeOrderSimilarity(records);
        buffer.append("\nOrder Similarity in distance: " + orderSimilarity);

        // 统计similarity()的逆序对数和OrderSimilarity
        Arrays.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                // TODO Auto-generated method stub
                return Double.compare(o1.similarity1, o2.similarity1);
            }
        });
        for(int i = 0; i < records.length; i ++) {
            records[i].index = i;
        }
        Arrays.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                // TODO Auto-generated method stub
                return Double.compare(o1.similarity2, o2.similarity2);
            }
        });
        inversionPairCount = countInversionPair(records);
        buffer.append("\nInversionPair Count in similarity: " + inversionPairCount);
        orderSimilarity = computeOrderSimilarity(records);
        buffer.append("\nOrder Similarity in similarity: " + orderSimilarity);

        LOG.info(buffer.toString());
    }

    public static class Record implements IWritable {
        int index = 0;
        double distance1 = 0;
        double distance2 = 0;
        double similarity1 = 0;
        double similarity2 = 0;

        @Override
        public void readFields(DataInput in) throws IOException {
            distance1 = in.readDouble();
            distance2 = in.readDouble();
            similarity1 = in.readDouble();
            similarity2 = in.readDouble();
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeDouble(distance1);
            out.writeDouble(distance2);
            out.writeDouble(similarity1);
            out.writeDouble(similarity2);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            if(this == value) return this;
            Record that = (Record) value;
            distance1 = that.distance1;
            distance2 = that.distance2;
            similarity1 = that.similarity1;
            similarity2 = that.similarity2;
            return this;
        }

        public String toString() {
            return distance1 + ", " + distance2 + ", " + similarity1 + ", " + similarity2;
        }

    }

    public static class Mapper extends AbstractMapper<IWritable, StringSparseVector> {
        private StringWritable elementID = new StringWritable();

        @Override
        public void map(IWritable key, StringSparseVector value, ICollector collector) {
            elementID.set(key.toString());
            collector.collect(elementID, value);
        }

    }

    public static class Reducer implements IMergeReducer<StringWritable, StringSparseVector, SparseVector> {
        private Random random;
        private int sampleNum;
        private int sampleInterval;
        private TaskRunnable task;
        private String lastKey = null;
        private StringSparseVector lovector = new StringSparseVector();
        private SparseVector lnvector = new SparseVector();
        private Record record = new Record();
        private StringWritable badData = new StringWritable();
        private int count = 0;
        private Counter sampleCounter;
        private Counter badCounter;

        public void configure(JobDef job, TaskRunnable task) {
            sampleNum = job.getConfig().getInt(CFG_SAMPLE_NUM)/job.getTaskNumber(task.getStageIdx());
            sampleInterval = job.getConfig().getInt(CFG_SAMPLE_INTERVAL);
            random = new Random(task.getPartIdx());
            this.task = task;
            sampleCounter = task.getCounter("SampleCounter");
            badCounter = task.getCounter("BadCounter");
        }       

        @Override
        public void reduce(
                StringWritable key,
                IWritablePairWalker<StringWritable, StringSparseVector> values,
                IWritablePairWalker<StringWritable, SparseVector>[] mergeValues,
                ICollector collector) {

            if(count > sampleNum) {
                task.endTask();
                return;
            }

            if(values == null || !values.moreValue() || mergeValues[0] == null || !mergeValues[0].moreValue()) return;
            if(random.nextInt(sampleInterval) != 0) return;

            StringSparseVector ovector = values.getValue();
            SparseVector nvector = mergeValues[0].getValue();
            if(ovector.modulus() == 0.0 || nvector.modulus() == 0.0) {
                badCounter.inc();
                badData.set(ovector.toString() + ", " + nvector.toString());
                collector.collectToChannel(1, key, badData);
                return;
            }

            if(lastKey == null) {
                lastKey = key.toString();
                lovector.copyFields(ovector);
                lnvector.copyFields(nvector);
                return;
            }

            record.distance1 = ovector.distance(lovector);
            record.distance2 = nvector.distance(lnvector);
            record.similarity1 = ovector.innerProduct(lovector)/(ovector.modulus()*lovector.modulus());
            record.similarity2 = nvector.innerProduct(lnvector)/(nvector.modulus()*lnvector.modulus());
            collector.collectToChannel(0, key, record);

            lastKey = null;
            sampleCounter.inc();
            count ++;
        }

        @Override
        public void reduceBegin() {
        }

        @Override
        public void reduceEnd(ICollector collector) {
        }

    }

}

