package toolbox.vecat.base;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.LongsWritable;
import odis.tools.ToolContext;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.Vector;
import toolbox.vecat.utils.Utils;

/**
 * LSH签名生成器, 支持MinHash, Weighted-MinHash, CosHash
 * @author caofx
 *
 */
public class SignitureGenerator {
    private LSH[] funcs;
    private LongsWritable tempLongs = new LongsWritable();
    private Vector tempVector = new Vector();
    private BitArray tempBitArray = new BitArray();

    /**
     * 至少分辨出MIN_R个不同的hash值，避免出现平凡解
     */
    private static final int MIN_R = 1024*1024; 

    /**
     * 随机创建指定个数的LSH函数
     * @param n
     */
    public void generateParams(int n) {
        funcs = new LSH[n];
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            long a, b, r; // (a * x + b) % r
            do { 
                a = rand.nextLong();
                b = rand.nextLong();
                r = rand.nextLong();
            } while (a == 0 || r < MIN_R);
            funcs[i] = new LSH(a, b, r);
        }
        tempVector.resize(getSigLen());
    }

    /**
     * 从文件中读入参数
     * @param fs
     * @param path
     * @throws IOException
     */
    public void read(IFileSystem fs, Path path) throws IOException {
        ArrayList<LSH> funcs = new ArrayList<LSH>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(fs.open(path)));
        try {
            while(true) {
                String line = reader.readLine();
                if(line == null) break;
                line = line.trim();
                if(line.length() == 0) continue;
                funcs.add(new LSH(line));
            }
        } finally {
            reader.close();
        }
        
        this.funcs = funcs.toArray(new LSH[funcs.size()]);
        tempVector.resize(getSigLen());
    }
    
    /**
     * 将参数保存到文件
     * @param fs
     * @param path
     * @throws IOException
     */
    public void write(IFileSystem fs, Path path) throws IOException {
        PrintWriter writer = new PrintWriter(fs.create(path));
        try {
            for(int i = 0; i < funcs.length; i ++) {
                writer.println(funcs[i].toString());
            }
        } finally {
            writer.close();
        }
    }
    
    /**
     * 返回签名长度
     * @return
     */
    public int getSigLen() {
        return funcs.length;
    }
    
    /**
     * 计算向量的MinHash签名
     * @param vector
     * @return
     */
    public LongsWritable getMinHashSig(AbstractVector vector) {
        int size = vector.size();
        tempLongs.clear();
        long [] digests = new long [size];
        for(int i = 0; i < size; i ++) {
            digests[i] = Utils.getDigest(vector.getIndexName(i));
        }
        for(int i = 0; i < funcs.length; i ++) {
            tempLongs.addLong(funcs[i].getMinHash(digests));
        }
        return tempLongs;
    }

    /**
     * 计算向量的Weighted-MinHash签名
     * @param vector
     * @return
     */
    public LongsWritable getWeightedMinHashSig(AbstractVector vector) {
        int size = vector.size();
        tempLongs.clear();
        long [] digests = new long [size];
        double [] weights = new double [size];
        for(int i = 0; i < size; i ++) {
            digests[i] = Utils.getDigest(vector.getIndexName(i));
            weights[i] = vector.getValue(i);
        }
        for(int i = 0; i < funcs.length; i ++) {
            tempLongs.addLong(funcs[i].getMinHash(digests, weights));
        }
        return tempLongs;
    }

    /**
     * 计算向量归一化后的CosHash签名, 是{@link #getCosHashProduct(AbstractVector)}的二进制化,
     * 如果向量模为0返回null
     * @param vector
     * @return
     */
    public BitArray getCosHashSig(AbstractVector vector) {
        double modulus = vector.modulus();
        if(vector.modulus() <= 0) return null; // 丢弃0长度向量
        int size = vector.size();
        tempVector.clear();
        // 这里为性能优化, 直接操作内部Buffer
        double[] buffer = tempVector.getBuffer();
        for(int j = 0; j < size; j ++) {
            long s = Utils.getDigest(vector.getIndexName(j));
            double w = vector.getValue(j)/modulus;
            for(int i = 0; i < funcs.length; i ++) {
                buffer[i] += w * funcs[i].hash(s);
            }
        }
        tempVector.toBitArray(tempBitArray);
        return tempBitArray;
    }

    /**
     * 计算向量归一化后的CosHash Product, 如果向量模为0返回null
     * @param vector
     * @return
     */
    public Vector getCosHashProduct(AbstractVector vector) {
        double modulus = vector.modulus();
        if(vector.modulus() <= 0) return null; // 丢弃0长度向量
        int size = vector.size();
        tempVector.clear();
        // 这里为性能优化, 直接操作内部Buffer
        double[] buffer = tempVector.getBuffer();
        for(int j = 0; j < size; j ++) {
            long s = Utils.getDigest(vector.getIndexName(j));
            double w = vector.getValue(j)/modulus;
            for(int i = 0; i < funcs.length; i ++) {
                buffer[i] += w * funcs[i].hash(s);
            }
        }
        return tempVector;
    }

    public static void main(String[] args) throws IOException {
        int sigLen = 128;
        IFileSystem fs = FileSystem.getNamed(FileSystem.LOCAL);
        Path path = new Path(ToolContext.getAppConfFile("spam/domexpand/lsh").getAbsolutePath());

        SignitureGenerator generator1 = new SignitureGenerator();
        generator1.generateParams(sigLen);
        generator1.write(fs, path);
        
        SignitureGenerator generator2 = new SignitureGenerator();
        generator2.read(fs, path);

        int dlen = 200;
        long[] digest = new long[dlen];
        for (int i = 0; i < digest.length; i++)
            digest[i] = i;

        long[] minhash = new long[sigLen];
        for (int i = 0; i < sigLen; i++) {
            minhash[i] = generator2.funcs[i].getMinHash(digest);
        }

        System.out.println("digests:");
        System.out.println(Arrays.toString(digest));

        Arrays.sort(minhash);
        System.out.println("minhashes:");
        System.out.println(Arrays.toString(minhash));
    }
}
