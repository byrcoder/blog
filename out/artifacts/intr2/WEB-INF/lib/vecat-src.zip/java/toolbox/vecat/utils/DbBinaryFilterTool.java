package toolbox.vecat.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobConfig;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.LzoCompression;
import odis.io.Path;
import odis.io.LzoCompression.LzoContext;
import odis.mapred.AbstractMapper;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.LongHashPartitioner;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.IParsable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.Url;
import odis.tools.MapReduceHelper;
import odis.tools.misc.DumpTool;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

/**
 * 使用多线程+二分查找的方法dump数据
 * 
 * 输入为要dump的数据目录和要dump的key目录或者文件
 * key的格式是{@link SequenceFile}或者每行一个key的文本格式。默认是SequenceFile, 可以用
 *   -format指定是seq还是text
 * 由于key可能会被读取多遍, 对SequenceFile, 可以先用{link KeysTool}转成一个part的
 *   SequenceFile，方便读取
 * 
 * -t 指定使用的线程数。线程数主要取决于要dump的数据是否使用了块压缩，以及块压缩的大小
 * 如果没有使用块压缩，可以使用比较多的线程数，比如60
 * 如果使用了块压缩，当块大小是10M时，线程数不能超过8, 否则容易OOM
 *
 * @author zhanglh
 *
 */
public class DbBinaryFilterTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(
            DbBinaryFilterTool.class);
    
    @Override
    public String comment() {
        return "filter db with given key files using binary search";
    }
    
    private String inputStr, keysStr, outputStr;
    private String keyFormat;
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input", "input path");
        options.withOption("k", "keys", "keys path");
        options.withOption("o", "output", "output path");
        options.withOption("p", "class", "partitioner class").hasDefault();
        options.withOption("t", "thread number", 
                "thread number, if use 10M block compress, " +
                "thread number must less than 8").setDefault(60);
        options.withOption("n", "number", 
                "output part number, default same as input").hasDefault();
        options.withOption("format", "keyformat", "key file format, " +
                        "seq or text, default sequence file").setDefault("seq");
        options.withOption("name", "toolname", "toolname").hasDefault();
    }
    
    @Override
    public boolean processOptions(Options options) throws Exception {
        inputStr = options.getStringOpt("i");
        keysStr = options.getStringOpt("k");
        outputStr = options.getStringOpt("o");
        keyFormat = options.getStringOpt("format");
        return true;
    }
    
    @SuppressWarnings("unchecked")
    public boolean exec(int nWorker) throws Exception {
        MapReduceJobDef job = context.createMapReduceJob(
                options.getStringOpt("name", getToolName()), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context,job);
        
        int partNum = helper.getPartNumber(context.path(inputStr));
        helper.addReadInputDir(context.path(inputStr), null);
        job.setMapper(Mapper.class);
        
        job.setMapNumber(partNum);
        job.setCheckMapProgress(false);
        
        job.getConfig().setProperty(Mapper.NAME_FS, fs.getName());
        job.getConfig().setProperty(Mapper.NAME_INPUT, 
                context.path(inputStr).getAbsolutePath());
        job.getConfig().setProperty(Mapper.NAME_KEYS, 
                context.path(keysStr).getAbsolutePath());
        
        String partClass = options.getStringOpt("p", null);
        if (partClass != null)
            job.getConfig().setProperty(Mapper.PART_CLASS, partClass);      
        job.getConfig().setProperty(Mapper.PART_NUMBER, partNum);
        
        job.getConfig().setProperty(Mapper.NUMBER_THREAD, 
                options.getIntOpt("t"));
        
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, 
                context.path(inputStr, CoWorkUtils.getPartID(0)));
        job.setMergeKeyValClass(reader.getKeyClass(), reader.getValueClass());
        
        Class partitioner = SeqFileHashPartitioner.class;
        String cls = options.getStringOpt("p", null);
        if (cls != null) 
            partitioner = Class.forName(cls);
        else if (LongWritable.class.isAssignableFrom(reader.getKeyClass()))
            partitioner = LongHashPartitioner.class;
        else if (Url.class.isAssignableFrom(reader.getKeyClass()))
            partitioner = UrlMd5Partitioner.class;
        job.setPartitionerClass(partitioner);
        
        job.getConfig().setProperty(Mapper.PART_CLASS, partitioner.getName());
        
        job.getConfig().setProperty(Mapper.KEY_FORMAT, keyFormat);
        job.getConfig().setProperty(Mapper.KEY_CLASS, 
                reader.getKeyClass().getName());
        
        job.setReducer(IdentityReducer.class);
        job.setReduceNumber(options.getIntOpt("n", partNum));
        
        helper.addUpdateOutputDir(0, context.path(outputStr), 
                reader.getKeyClass(), reader.getValueClass(), null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        reader.close();
        
        JobResult res = helper.runJob(context.getCoWork());       
        if(!res.isSuccess())
            return false;    
        helper.printCounters(out, res.getCounters());
        return true;
    }
    
    /**
     * 使用二分的方法dump数据
     *
     * @author zhanglh
     *
     */
    public static class Mapper extends AbstractMapper<IWritable, IWritable> {
        private static final String PREFIX = Mapper.class.getName() + ".";
        public static final String NAME_INPUT = PREFIX + "input";
        public static final String NAME_KEYS = PREFIX + "keys";
        public static final String NAME_FS = PREFIX + "fs";
        public static final String PART_CLASS = PREFIX + "partclass";
        public static final String PART_NUMBER = PREFIX + "partnumber";
        public static final String NUMBER_THREAD = PREFIX + "threadnumber";
        public static final String KEY_FORMAT = PREFIX + "keyformat";
        public static final String KEY_CLASS = PREFIX + "keyclass";
        
        private TaskRunnable task;       
        private IWritableComparable[]keys;

        private FileSystem fs;
        private Path targetPath;
        private Path keysPath;
        
        private BasicPartitioner partitioner;
        private int partNum;
        private int threadNum;
        
        private String keyFormat;
        private Class<? extends IWritableComparable> keyClass;
        
        @SuppressWarnings("unchecked")
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            this.task = task;
            JobConfig config = job.getConfig();
            String partId = CoWorkUtils.getPartID(task.getPartIdx());
            try {
                fs = FileSystem.getNamed(config.getString(NAME_FS));
                targetPath = new Path(config.getString(NAME_INPUT), partId);
                keysPath = new Path(config.getString(NAME_KEYS));
                Class clazz = job.getConfig().getPropClass(PART_CLASS, 
                        BasicPartitioner.class, SeqFileHashPartitioner.class);
                partitioner = (BasicPartitioner)ClassUtils.newInstance(clazz);
                partNum = job.getConfig().getInt(PART_NUMBER);
                threadNum = job.getConfig().getInt(NUMBER_THREAD);
                keyFormat = job.getConfig().getString(KEY_FORMAT);
                keyClass = (Class<? extends IWritableComparable>)
                        job.getConfig().getPropClass(KEY_CLASS, 
                                IWritableComparable.class, Url.class);
            } catch (IOException e) {
                throw new TaskFatalException("init reader failed ", e);
            }
        }
        
        private void loadKeys(FileSystem fs, Path keyPath) throws Exception {
            Set<IWritableComparable>result = new TreeSet<IWritableComparable>();            
            if (fs.isDirectory(keyPath)) {
                for (FileInfo info : fs.listFiles(keyPath)) {
                    loadKeys(fs, info.getPath(), result);
                }
            } else {
                loadKeys(fs, keyPath, result);
            }
            keys = new IWritableComparable[result.size()];
            int idx = 0;
            // sort keys
            for (IWritableComparable key : result)
                keys[idx ++] = key;
        }
        
        private void loadKeys(FileSystem fs, Path keyPath, 
                Set<IWritableComparable> keySet)
                throws Exception {
            if (keyFormat.equals("text")) {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(fs.open(keyPath)));
                try {                   
                    String line;
                    while ((line = reader.readLine()) != null) {
                        IWritableComparable key = (IWritableComparable)
                                ClassUtils.newInstance(keyClass);
                        ((IParsable)key).parse(line);
                        if (partitioner != null) {
                            if (partitioner.getPartition(key, null, partNum) 
                                    != this.task.getPartIdx())
                                continue;
                        }
                        keySet.add(key);
                    }
                } finally {
                    reader.close();
                }
                return;
            }
            // else sequence file
            SequenceFile.Reader reader = new SequenceFile.Reader(fs, keyPath);
            try {
                IWritableComparable key = (IWritableComparable)
                        ClassUtils.newInstance(reader.getKeyClass());
                IWritable value = (IWritable)ClassUtils.newInstance(
                        reader.getValueClass());
                while (reader.next(key, value)) {
                    if (partitioner != null) {
                        int p = partitioner.getPartition(key, value, partNum);
                        if (p != this.task.getPartIdx())
                            continue;
                    }
                    
                    IWritableComparable tmp = (IWritableComparable)
                        ClassUtils.newInstance(reader.getKeyClass());
                    tmp.copyFields(key);
                    keySet.add(tmp);
                }
            } finally {
                reader.close();
            }
        }
        
        /**
         * 只是用到了collector, 并不是实际的进行map
         */
        @Override
        public void map(IWritable key, IWritable value, ICollector collector) {
            try {
                loadKeys(fs, keysPath);
                if (keys.length == 0) {
                    LOG.info("no keys to dump");
                    task.endTask();
                    return;
                }
                LOG.info("load keys finish, keys size=" + keys.length);
                
                // split keys to threadNum parts
                int interval = keys.length / threadNum;
                int residual = keys.length % threadNum;
                int start = 0, end = 0;
                Thread[] ts = new Thread[threadNum];
                BinaryKeySearcher[]searchers = new BinaryKeySearcher[threadNum];
                for (int i = 0 ; i < threadNum; i++) {
                    start = end;
                    if (i < residual) {
                        end = start + interval + 1;
                    } else {
                        end = start + interval;
                    }
                    
                    searchers[i] = new BinaryKeySearcher(
                            keys, start, end, collector, fs, targetPath);
                    ts[i] = new Thread(searchers[i]);
                    ts[i].start();
                }
                
                // 等待全部线程结束，如果线程异常，则抛出异常
                for(int i = 0; i < threadNum; i ++) {
                    ts[i].join();
                    Throwable throwable = searchers[i].getThrowable();
                    if(throwable != null) {
                        throw new TaskFatalException("do filter error in " + ts[i].getName(), throwable);
                    }
                }
            } catch (Exception e) {
                throw new TaskFatalException("do filter error", e);
            }
            
            task.endTask();
        }
    }
    
    /**
     * 使用二分的方法dump数据
     *
     * @author zhanglh
     *
     */
    private static class BinaryKeySearcher implements Runnable {
        private IWritableComparable []keys;
        private int start; // start of keys, include
        private int end;   // end of keys, exclude
        private ICollector collector;
        
        private SequenceFile.Reader reader = null;
        
        private Throwable ex = null;
        
        /**
         * constructor
         * 
         * @param keys  keys to dump
         * @param start  start pos of keys, include
         * @param end    end pos of keys, exclude
         * @param collector   data collector
         * @param fs  file system of data
         * @param path  path of data
         * @throws IOException
         */
        public BinaryKeySearcher(IWritableComparable []keys, int start, 
                int end, ICollector collector, IFileSystem fs, Path path) 
                    throws IOException
        {
            this.keys = keys;
            this.start = start;
            this.end = end;
            this.collector = collector;
            reader = new SequenceFile.Reader(fs, path);
        }
        
        /**
         * 得到线程的异常
         * 
         * @return  返回异常，如果没有异常返回null
         */
        public Throwable getThrowable() {
            return ex;
        }
        
        /**
         * add cost log for sync
         */
        private static void readerSync(SequenceFile.Reader reader, long pos) 
                throws IOException {
            long start = System.currentTimeMillis();
            // for a bug of sync: 
            // it do not clear bufferedRecord when pos <= HEAD_SIZE
            if (pos > SequenceFile.HEADER_SIZE)
                reader.sync(pos);
            else
                reader.seek(SequenceFile.HEADER_SIZE);
            LOG.info(Thread.currentThread().getName() + " sync to " + pos + 
                    " cost " + (System.currentTimeMillis() - start));
        }
        
        @Override
        public void run() {
            // use thread local lzo context, needed?
            LzoContext lzoContext = LzoCompression.createContext();
            try {
                LzoCompression.setThreadLocalContext(lzoContext);
                doBinaryFilter(start, end, 0, reader.getEnd());
            } catch (Throwable e) {
                e.printStackTrace();
                ex = e;
                LOG.info(Thread.currentThread().getName() + 
                        " get exception in binary search" + e);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                    }
                }
                LzoCompression.removeThreadLocalContext();
                LzoCompression.releaseContext(lzoContext);
            }
        }
        
        /**
         * do binary search to dump data
         * 
         * @param keyLowPos   low pos in keys array, include
         * @param keyHiPos    high pos in keys array, exclude
         * @param inputLowPos  low pos in seq file, include
         * @param inputHiPos   high pos in seq file, exclude
         * @throws Exception
         */
        private void doBinaryFilter(int keyLowPos, int keyHiPos, 
                long inputLowPos, long inputHiPos) throws Exception {
            if (keyLowPos >= keyHiPos)
                return;
            String threadName = Thread.currentThread().getName();
            LOG.info(threadName + "\tsearch: " + keyLowPos + "->" + keyHiPos + 
                    ", " + inputLowPos + "->" + inputHiPos);
            
            IWritableComparable key = (IWritableComparable)
                    reader.getKeyClass().newInstance();
            IWritable value = (IWritable)reader.getValueClass().newInstance();
            int keyPos = keyLowPos;
            
            // 如果距离比较小，顺序找
            if (inputHiPos - inputLowPos < DumpTool.MAX_BINARY_SEARCH_DISTANCE){
                readerSync(reader, inputLowPos);
                int collected = 0;
                while (keyPos < keyHiPos && reader.next(key, value)) {
                    // 结束的位置可能超过inputHiPos
                    // if (reader.getPosition() >= inputHiPos)
                    //    return;
                    int comp;
                    do {                       
                        comp = key.compareTo(keys[keyPos]);
                        if (comp == 0) {
                            synchronized (collector) {
                                collector.collect(key, value);
                            }
                            collected ++;
                        } else if (comp > 0) {
                            LOG.info(threadName + "\t" + "key="+key+ ", keys[" +
                                    keyPos + "]=" + keys[keyPos]);
                            keyPos ++;                           
                        }
                    } while (keyPos < keyHiPos && comp > 0);                   
                }
                LOG.info(threadName + "\tsearch: " + keyLowPos + "->" + 
                        keyHiPos + "(" + (keyHiPos - keyLowPos) + 
                        "), " + inputLowPos + "->" + inputHiPos +
                        ", collect " + collected + " records");
                return;
            }
            
            long midPos = (inputLowPos + inputHiPos) / 2;
            long start = System.currentTimeMillis();
            reader.sync(midPos);
            // get position must before next
            // midPos = reader.getPosition();
            reader.next(key, value);
            LOG.info(threadName + " syncnext to " + midPos + " cost " + 
                    (System.currentTimeMillis() - start));
            
            int comp = 0;
            while (keyPos < keyHiPos) {                 
                comp = key.compareTo(keys[keyPos]);
                if (comp < 0)
                    break;
                keyPos ++;
            }
            
            LOG.info(threadName + "\tmidpos="+midPos + ",midKey="+key.toString()
                    + ", keyPos=" + keyPos + ", "
                    + (keyPos < keyHiPos ? keys[keyPos]:null));
            
            if (keyPos > keyLowPos) {
                doBinaryFilter(keyLowPos, keyPos, inputLowPos, midPos);
            }
            if (keyPos < keyHiPos) {
                doBinaryFilter(keyPos, keyHiPos, midPos, inputHiPos);
            }
        }
    }
}
