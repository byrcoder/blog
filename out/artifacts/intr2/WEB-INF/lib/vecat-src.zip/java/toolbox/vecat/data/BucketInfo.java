package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

public class BucketInfo implements IWritable {
    private long count = 0;
    private long isolatedCount = 0;
    private int processedClusterCount = 0;

    public boolean needProcess() {
        return isolatedCount > 0 || processedClusterCount > 1;
    }
    
    public void set(long count, long isolatedCount, int processedClusterCount) {
        this.count = count;
        this.isolatedCount = isolatedCount;
        this.processedClusterCount = processedClusterCount;
    }
    
    public long getCount() {
        return count;
    }

    public long getIsolatedCount() {
        return isolatedCount;
    }

    public long getProcessedClusterCount() {
        return processedClusterCount;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        count = in.readLong();
        isolatedCount = in.readLong();
        processedClusterCount = in.readInt();
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(count);
        out.writeLong(isolatedCount);
        out.writeInt(processedClusterCount);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if(value == this) return this;
        BucketInfo that = (BucketInfo) value;
        count = that.count;
        isolatedCount = that.isolatedCount;
        processedClusterCount = that.processedClusterCount;
        return this;
    }
    
    @Override
    public String toString() {
        return "(" + count + ", " + isolatedCount + ", " + processedClusterCount + ")";
    }

}
