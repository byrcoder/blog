package toolbox.vecat.utils;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;

import odis.cowork.CoWorkUtils;
import odis.file.SequenceFile;
import odis.file.SequenceFile.Reader;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.io.IFileSystem.PathFilter;
import odis.serialize.IWritable;
import odis.serialize.lib.MD5Writable;
import toolbox.cluster.Instance;

public class Utils {
    
    /**
     * 快速清空容器
     * @param <T>
     * @param object
     * @param threshold
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T extends Collection<?>> T fastClear(T object, int threshold) {
        if(object.size() > threshold) {
            try {
                return (T) object.getClass().newInstance();
            } catch(Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            object.clear();
            return object;
        }
    }

    /**
     * 快速清空容器
     * @param <T>
     * @param object
     * @param threshold
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T extends Map<?, ?>> T fastClear(T object, int threshold) {
        if(object.size() > threshold) {
            try {
                return (T) object.getClass().newInstance();
            } catch(Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            object.clear();
            return object;
        }
    }

    /**
     * 将数据以指定的操作方式写入指定SeqFile
     * @param <T>
     * @param fs
     * @param path
     * @param data
     * @param keyClass
     * @param valueClass
     * @param override
     * @param operator
     * @return
     * @throws IOException
     */
    public static <T> void writeToSeqFile(IFileSystem fs, Path path, T data,
            Class<? extends IWritable> keyClass, Class<? extends IWritable> valueClass,
            boolean override, WriteOperator<T> operator) throws IOException {
        SequenceFile.Writer writer = new SequenceFile.Writer(fs, path, keyClass, valueClass, override);
        try {
            operator.operate(writer, data);
        } finally {
            writer.close();
        }
    }
    
    /**
     * 以指定的操作方式从指定SeqFile读入数据
     * @param <T>
     * @param fs
     * @param path
     * @param data
     * @param keyClass
     * @param valueClass
     * @param override
     * @param operator
     * @return
     * @throws IOException
     */
    public static <T> void readFromSeqFile(IFileSystem fs, Path path, T data,
            ReadOperator<T> operator) throws IOException {
        Reader reader = new SequenceFile.Reader(fs, path);
        try {
            operator.operate(reader, data);
        } finally {
            reader.close();
        }
    }
    
    
    /**
     * 描述写SeqFile的操作, 参见 {@link Utils#writeToSeqFile(IFileSystem, Path, Object, Class, Class, boolean, WriteOperator)}
     * @author caofx
     *
     * @param <T>
     */
    public interface WriteOperator<T> {
        public void operate(SequenceFile.Writer writer, T data) throws IOException;
    }

    /**
     * 描述读SeqFile的操作, 参见{@link Utils#readFromSeqFile(IFileSystem, Path, Object, ReadOperator)}
     * @author caofx
     *
     * @param <T>
     */
    public interface ReadOperator<T> {
        public void operate(SequenceFile.Reader reader, T data) throws IOException;
    }
    
    /**
     * 获取单个SeqFile或partitioned SeqFiles(目录)的keyClass, valueClass
     * @param fs
     * @param path
     * @return
     * @throws IOException 
     */
    @SuppressWarnings("unchecked")
    public static Class<? extends IWritable >[] getKeyValueClass(IFileSystem fs, Path path) throws IOException {
        if(fs.isDirectory(path)) {
            path = path.cat(CoWorkUtils.getPartID(0));
        }
        Reader reader = new SequenceFile.Reader(fs, path);
        Class<?>[] ret = {reader.getKeyClass(), reader.getValueClass()};
        reader.close();
        return (Class<? extends IWritable>[]) ret;
    }
    
    /**
     * 在指定的FileSystem中, 把指定的输入目录按文件分割为指定个数的合法的MapReduce输入目录
     * @param fs
     * @param srcPath 源路径
     * @param splitPath 分割后的输入目录路径
     * @param group 分割的数目, > 1 会进行分割, 否则直接返回源路径
     * @return 路径数组, size == group, 其中的元素有可能为 null, 使用时需要检查
     * @throws IOException 
     */
    public static Path[] splitInput(IFileSystem fs, Path srcPath, Path splitPath, int group) throws IOException {
        if(group <= 1) {
            return new Path[]{srcPath};
        }
        
        try {
            fs.getLock(srcPath, IFileSystem.SHARED_LOCK);
            FileInfo[] files = fs.listFiles(srcPath);
            if (files == null) {
                throw new IOException(srcPath.getAbsolutePath() + " does not exist or denote a directory");
            }
            Path [] paths = new Path[group];
            for(int i = 0; i < files.length; i ++) {
                int g = i%group;
                int p = i/group;
                if(paths[g] == null) {
                    paths[g] = splitPath.cat("group_" + g);
                    fs.delete(paths[g]); 
                    fs.mkdirs(paths[g]);
                }
                fs.link(files[i].getPath(), paths[g].cat(CoWorkUtils.getPartID(p)));
            }
            return paths;
        } finally {
            fs.releaseLock(srcPath);
        }
    }
    
    /**
     * 在指定的FileSystem中, 在指定的路径中寻找已分割的输入路径
     * @param fs
     * @param splitPath
     * @return 路径数组
     * @throws IOException
     */
    public static Path[] getSplitInput(IFileSystem fs, Path splitPath) throws IOException {
        FileInfo[] files = fs.listFiles(splitPath, new PathFilter() {
            @Override
            public boolean accept(Path path) {
                return path.getName().startsWith("group_");
            }
        });
        if(files == null) return new Path[0];
        
        Path[] paths = new Path[files.length];
        for(int i = 0; i < files.length; i ++) {
            paths[i] = files[i].getPath();
        }
        
        return paths;
    }

    /**
     * 将 String 转换为 Instance.ID
     * @param id
     * @param s
     */
    public static void setInstanceID(Instance.ID id, String s) {
        id.set(getDigest(s));
    }
    
    public static long getDigest(String s) {
        return MD5Writable.digest(s).halfDigest();
    }
}
