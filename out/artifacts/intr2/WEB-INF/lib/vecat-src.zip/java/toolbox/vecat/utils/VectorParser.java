package toolbox.vecat.utils;

import odis.serialize.IWritable;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.stat.StatBase.DataParser;
import toolbox.vecat.stat.StatBase.StatVariable;

/**
 * {@link AbstractVector}及其子类的统计用解析器, 实现自 {@link outfox.tools.StatBase.DataParser}<br>
 * 定义关心的SiteAttr库统计变量, 以便使用{@link outfox.tools.StatBase.DataStatTool}进行统计,
 * 或使用{@link outfox.tools.StatBase.DataGrepTool}过滤关心的数据
 * 
 * @author caofx
 *
 */public class VectorParser implements DataParser {

    @Override
    public StatVariable[] getVariables(IWritable key, IWritable value) {
        if(!(value instanceof AbstractVector)) return EMPTY_VARIABLES;
        AbstractVector vector = (AbstractVector)value;
        int size = vector.size();
        double modulus = vector.modulus();
        StatVariable[] ret = {
                new StatVariable("size", size),
                new StatVariable("modulus", modulus),
        };
        return ret;
    }

}
