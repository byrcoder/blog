package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.serialize.IClearable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.comparator.BinaryComparator;
import toolbox.text.util.HexString;

public class BitArray implements IWritableComparable, IClearable {
    private int size;
    private byte [] values;
    private static final int BASE = 8;

    public BitArray() {
        this(0);
    }

    public BitArray(int size) {
        resize(size);
    }
    
    private void rangeCheck(int i) {
        if (i >= size()) throw new IndexOutOfBoundsException("Order: " + i + ", Size: " + size());
    }
    
    public static byte getBit(byte b, int r) {
        return (byte) ((b >> r) & 0x1);
    }

    public static byte setBit(byte b, int r, int v) {
        return (byte) ((b & ~(0x1 << r)) | ((v & 0x1) << r));
    }

    public static byte clearBit(byte b, int r) {
        return (byte) (b & ~(0x1 << r));
    }

    public static int diffBits(byte l1, byte l2, int bitLen) {
        int c = l1 ^ l2;
        int d = 0;
        for(int i = 0; i < bitLen; i ++) {
            d += (c >> i) & 0x1;
        }
        return d;
    }
    
    /**
     * 计算两个byte不同的位数, 比 {@link #diffBits(byte, byte, int)}快
     * @param l1
     * @param l2
     * @return
     */
    public static int diffBits(byte l1, byte l2) {
        int c = l1 ^ l2;
        c = (c & 0x55) + ((c >> 1) & 0x55);
        c = (c & 0x33) + ((c >> 2) & 0x33);
        c = (c & 0x0f) + ((c >> 4) & 0x0f);
        return c;
    }

    public byte getValue(int i) {
        rangeCheck(i);
        return getBit(values[i/BASE], i%BASE);
    }

    /**
     * @param i
     * @param value 仅使用最低位
     */
    public void setValue(int i, int value) {
        rangeCheck(i);
        int q = i/BASE;
        values[q] = setBit(values[q], i%BASE, value);
    }

    /**
     * 重新指定BitArray的大小, 如果指定size比{@link #size()}大则扩展后的数据是不确定的
     * 对于没有用满的byte, 其没有用到的位都为0, 以保证{@link #compareTo(IWritable)}和
     * {@link #diff(BitArray)}能正常工作
     * @param size
     */
    public void resize(int size) {
        if(this.size == size) return;
        this.size = size;
        int bufferSize = bufferSize();
        if(values == null || values.length < bufferSize) {
            values = new byte [bufferSize];
        }
        int r = this.size%BASE;
        if(r > 0) {
            int q = this.size/BASE;
            for(int i = r-1; i < BASE; i ++) {
                values[q] = clearBit(values[q], i);
            }
        }
    }

    /**
     * 截断AbstractVector到指定的大小, 如果指定size比{@link #size()}大则无变化
     * @param size
     */
    public void truncate(int size) {
        if(size < size()) resize(size);
    }

    public int size() {
        return size;
    }

    public int bufferSize() {
        return (size + BASE -1)/BASE;
    }
    
    /**
     * 计算两个 BitArray的diff, 需要保证两者具有相同的size()
     * 为性能优化
     * 
     * @param that
     * @return
     */
    public int diff(BitArray that) {
        int n = (size + BASE -1)/BASE;
        int diff = 0;
        for(int i = 0; i < n; i ++) {
            int c = values[i] ^ that.values[i];
            c = (c & 0x55) + ((c >> 1) & 0x55);
            c = (c & 0x33) + ((c >> 2) & 0x33);
            c = (c & 0x0f) + ((c >> 4) & 0x0f);
            diff += c;
        }
        return diff;
    }
    
    @Override
    public void readFields(DataInput in) throws IOException {
        resize(in.readInt());
        int bufferSize = bufferSize();
        for(int i = 0; i < bufferSize; i ++) {
            values[i] = in.readByte();
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(size());
        int bufferSize = bufferSize();
        for(int i = 0; i < bufferSize; i ++) {
            out.writeByte(values[i]);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if(this == value) return this;
        BitArray that = (BitArray) value;
        resize(that.size());
        int bufferSize = bufferSize();
        for(int i = 0; i < bufferSize; i ++) {
            values[i] = that.values[i];
        }
        return this;
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < size; i ++) {
            builder.append(getValue(i));
        }
        builder.append("#").append(size());
        return builder.toString();
    }
    
    @Override
    public void clear() {
        int bufferSize = bufferSize();
        for(int i = 0; i < bufferSize; i ++) {
            values[i] = 0;
        }
    }
    
    @Override
    public int compareTo(IWritable o) {
        BitArray that = (BitArray) o;
        return BinaryComparator.compareBytes(values, 0, bufferSize(), that.values, 0, that.bufferSize());
    }
    
    public byte[] toArray() {
        return Arrays.copyOf(values, bufferSize());
    }
    
    public String hexString() {
        return HexString.bytesToHexNoSpace(values, 0, bufferSize());
    }

    /**
     * 采集BitArray中指定位置的值, 并依次保存到新的BitArray中
     * @param pos
     * @param s 目标 BitArray
     */
    public void sample(int [] pos, BitArray s) {
        s.resize(pos.length);
        for(int i = 0; i < pos.length; i ++) {
            s.setValue(i, getValue(pos[i]));
        }
    }
    
    public static void main(String[] args) {
        for(int i = 0; i < 100; i ++) {
            int q = i/BASE;
            q = (i%BASE == 0? q: q+1);
            int r = (i-1 + BASE)/BASE;
            if(q != r) {
                System.out.println("false " + i + ", " + q + ", " + r);
                break;
            }
        }
        
        byte b1 = 20;
        byte b2 = 35;
        System.out.println(diffBits(b1, b2));
        System.out.println(diffBits(b1, b2, 8));

        int n = 1000;
        int m = n*n;
        System.out.println(m);
        long begin = System.currentTimeMillis();
        for(int j = 0; j < m; j ++) {
            int c = b1 ^ b2;
            int d = 0;
            for(int i = 0; i < 8; i ++) {
                d += (c >> i) & 0x1;
            }
        }
        long end = System.currentTimeMillis();
        System.out.println((end-begin)/1000.0);
        
        BitArray a = new BitArray(16);
        System.out.println(a);
        a.setValue(15, 1);
        a.setValue(13, 1);
        a.setValue(10, 1);
        System.out.println(a);
        System.out.println(Arrays.toString(a.values));
        a.resize(12);
        System.out.println(a);
        System.out.println(Arrays.toString(a.values));
        System.out.println(4|(0x1 << 3));
        System.out.println(BitArray.setBit((byte) 4, 3, 1));
    }

}
