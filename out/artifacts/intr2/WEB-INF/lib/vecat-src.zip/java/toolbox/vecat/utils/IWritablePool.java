/**
 * @(#)IWritablePool.java, 2008-7-17. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.vecat.utils;

import java.io.IOException;
import java.util.LinkedList;

import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.LocalFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.lib.NullWritable;

import toolbox.misc.ClassUtils;

/**
 * {@link IWritable} 的一个pool， 可以用来缓存数据到内存，
 * 如果内存不够的话，还可以存到本地磁盘中去。
 * 
 * 这个类适合的应用场景是 ：需要将记录一一记录，然后再一一处理。
 * 不支持随机访存，不支持边写边读。
 * 
 * 这里，读写的顺序是保证一致的。
 * 
 * <br><b>需要注意的是：</b> 类型 T 一定要实现 copyFields()的方法
 *
 * @author jiangfy
 * modified by caofx 2010-07-23 16:32:16
 *
 * @param <T>
 */
public class IWritablePool <T extends IWritable> {
    
    private LinkedList<T> memPool = new LinkedList<T>();
    private LinkedList<T> buffer = new LinkedList<T>();
    private Class<T> objClass = null;
    private Path localTmp;
    private int bufCount; 
    private int maxBufCount;
    private boolean compress;
    private SequenceFile.Writer writer = null;
    private SequenceFile.Reader reader = null;
    private FileSystem localFs;
    private T object = null;
    
    /**
     * 带参数构造函数
     * @param localTmp 内存中放不下时存放数据的本地磁盘路径
     * @param maxCount 内存中最多存放的对象个数
     * @param compress 存放到本地磁盘时是否压缩
     * @throws IOException
     */
    public IWritablePool(Path localTmp, int maxCount, 
            boolean compress) throws IOException {
        this.localTmp = localTmp;
        maxBufCount = maxCount;
        this.compress = compress;
        localFs = new LocalFileSystem();
    }
    
    /**
     * 清空， 初始化
     * @throws IOException
     */
    public void clear() throws IOException {
        if (memPool.size() < maxBufCount / 2) {
            for (T t : memPool) 
                buffer.add(t);
            if (memPool.size() < 50)
                memPool.clear();
            else
                memPool = new LinkedList<T>();
        } else {
            for (T t : buffer)
                memPool.add(t);
            LinkedList<T> tmp = buffer;
            buffer = memPool;
            if (tmp.size() < 50) {
                tmp.clear();
                memPool = tmp;
            } else
                memPool = new LinkedList<T>();
        }
        
        bufCount = 0;
        
        if (writer != null) {
            writer.close();
            writer = null;
        }
        
        if (reader != null) {
            reader.close();
            reader = null;
        }
        
        if (localFs.exists(localTmp))
            localFs.delete(localTmp);
    }
    
    /**
     * 缓存一个对象
     * @param obj 需要被缓存的对象
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public void save(T obj) throws IOException {
        Class<T> clazz = (Class<T>) obj.getClass();
        if(objClass == null) {
            objClass = clazz;
        } else if(clazz != objClass) {
            throw new IOException("Wrong object class: " + obj + " is " + clazz + ", not " + objClass);
        }
        if (bufCount < maxBufCount) {
            T t = buffer.poll();
            if (t == null)
                t = (T)ClassUtils.newInstance(objClass);
            t.copyFields(obj);
            memPool.add(t);
        } else {
            // write to local disk
            if (writer == null) {
                if (compress)
                    writer = new SequenceFile.CompressedWriter(localFs, localTmp, 
                            objClass, NullWritable.class, true);
                else
                    writer = new SequenceFile.Writer(localFs, localTmp, 
                            objClass, NullWritable.class, null, true);
            }
            writer.write(obj, NullWritable.get());
        }
        bufCount ++;
    }
    
    /**
     * 缓存结束。
     * @throws IOException
     */
    public void finishSave() throws IOException {
        if (writer != null) {
            writer.close(); 
            writer = null;
        }
    }
    
    /**
     * 获得当前缓存的数目
     * @return
     */
    public int getNumInPool() {
        return bufCount;
    }
    
    /**
     * 获取下一个缓存的对象
     * @param obj
     * @return
     * @throws IOException
     */
    public boolean next(T obj) throws IOException {
        if (bufCount <= 0) {
            if (reader != null) {
                reader.close();
                reader = null;
            }
            return false;
        }
        if (memPool.size() > 0) {
            T t = memPool.poll();
            obj.copyFields(t);
            buffer.add(t);
            bufCount --;
            return true;
        } else {
            if (reader == null) 
                reader = new SequenceFile.Reader(localFs, localTmp);
            if (!reader.next(obj, NullWritable.get())) {
                reader.close();
                return false;
            }
            bufCount --;
            return true;
        }
    }
    
    /**
     * 获取下一个缓存的对象, 该对象被复用故不能直接留作后用
     * @return
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public T next() throws IOException {
        if(object == null) object = (T)ClassUtils.newInstance(objClass);

        if (bufCount <= 0) {
            if (reader != null) {
                reader.close();
                reader = null;
            }
            return null;
        }
        if (memPool.size() > 0) {
            T t = memPool.poll();
            object.copyFields(t);
            buffer.add(t);
            bufCount --;
            return object;
        } else {
            if (reader == null) 
                reader = new SequenceFile.Reader(localFs, localTmp);
            if (!reader.next(object, NullWritable.get())) {
                reader.close();
                return null;
            }
            bufCount --;
            return object;
        }
    }

}
