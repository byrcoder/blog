package toolbox.vecat;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.ext.IMergeReducer;
import odis.mapred.ext.ReduceMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityMapper;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.PerKeyBufferedWalker;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.toolkit.WritablePair;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.base.BucketKeyPosEncoderDecoder;
import toolbox.vecat.base.BucketUtils;
import toolbox.vecat.base.CosHashUtils;
import toolbox.vecat.base.JobQueue;
import toolbox.vecat.base.JobQueue.Job;
import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.StringDim;
import toolbox.vecat.data.Vector;
import toolbox.vecat.utils.Utils;

/**
 * 在样本集合中寻找跟种子集合中元素相似的元素, 输出这些Pair及其相似度 
 * @author caofx
 *
 */
public class VectorNeighborFinder extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(VectorNeighborFinder.class);

    public static final String SEED_PATH = "seed";
    public static final String SPLIT_INPUT_PATH = "split_input";
    public static final String SPLIT_RESULT_PATH = "split_result";
    public static final String RESULT_PATH = "result";

    private static final String CFG_SIG_LENGTH = "CFG_SIG_LENGTH";
    private static final String CFG_GROUP_COUNT = "CFG_GROUP_COUNT";
    private static final String CFG_SHINGLE_COUNT = "CFG_SHINGLE_COUNT";
    private static final String CFG_SIM_THRESHOLD = "CFG_SIM_THRESHOLD";
    
    private static enum CounterName {
        VALID_BUCKET_COUNT,
    }
    
    @Override
    public String comment() {
        return "Find neighbors in vector data";
    }

    @Override
    protected void prepareOptions(Options opt) {
        opt.withOption("sa", "sample", "input sample path");
        opt.withOption("se", "seed", "input seed path").setDefault("");
        opt.withOption("o", "output", "output path");
        opt.withOption("l", "sig_length", "signiture vector length");
        opt.withOption("gc", "group", "signiture group count").setDefault(-1);
        opt.withOption("sc", "shingle_count ", "group count for shingles").setDefault(-1);
        opt.withOption("sl", "shingle_length", "shingle length").setDefault(-1);
        opt.withOption("s", "sim_threshold", "similarity threshold");
        opt.withOption("c", "catch_prob", "catch probability threshold, real cath probability under this will cause keeping isolate elements").setDefault(0);
        opt.withOption("split", "sample_split", "split input sample and do neighbor finding separately").setDefault(1);
        opt.withOption("cc", "concurrency", "set concurrency for processing split inputs").setDefault(8);
        opt.withOption("index", "build index for sample data");
        opt.withOption("mc", "do compression in map");
        opt.withOption("run", "run the job");
        opt.withOption("con", "continue the job, take effect only when \"-run\" set");
    }

    /* (non-Javadoc)
     * @see odis.tools.AbstractCoWorkTool#exec(int)
     */
    @Override
    public boolean exec(int nWorker) throws Exception {
        Path samplePath = context.path(options.getStringOpt("sa"));
        String seedPathStr = options.getStringOpt("se");
        Path outputPath = context.path(options.getStringOpt("o"));

        int sigLength = options.getIntOpt("l");
        int groupCount = options.getIntOpt("gc");
        int shingleCount = options.getIntOpt("sc");
        int shingleLength = options.getIntOpt("sl");
        double simThreshold = options.getDoubleOpt("s");
        double catchProb = options.getDoubleOpt("c");
        int split = options.getIntOpt("split");
        int concurrency = options.getIntOpt("cc");
        boolean index = options.isOptSet("index");
        boolean mapCompress = options.isOptSet("mc");
        boolean run = options.isOptSet("run");
        boolean con = options.isOptSet("con");

        // 估计分组参数 
        if(groupCount < 0 || shingleCount < 0) {
            if(shingleLength < 0) {
                out.println("you must provide \"-sl\" argument when \"-gc\" or \"-sc\" omit");
                return false;
            }
            int [] params = BucketUtils.computeGroupParams(shingleLength, sigLength, simThreshold, catchProb, 0);
            if(params == null) {
                out.println("hard to get a proper signiture group config, please adjust job parameters: \"-s\", \"-c\".");
                return false;
            }
            sigLength = params[0];
            groupCount = params[1];
            shingleCount = params[2];
        }

        out.println("Start running tool with following settings:");
        out.println("sig length: " + sigLength);
        out.println("group count: " + groupCount);
        out.println("shingle count: " + shingleCount);
        out.println("similarity threshold: " + simThreshold);
        
        double cp = BucketUtils.shingleCatchProb(sigLength, groupCount, shingleCount, simThreshold);
        out.println("catch probability threshold: " + catchProb);
        out.println("probability for catching similar pair with threshold: " + cp);
        out.println("converted diff threshold for specified sig length: " + CosHashUtils.sim2Diff(simThreshold, sigLength));
        out.println("shingle length: " + (double)shingleCount*sigLength/groupCount);
        out.println("shingle count per element: " + BucketUtils.shingleCountPerElement(groupCount, shingleCount));
        out.println("estimated total bucket count for infinite element count: " +BucketUtils.totalBucketCount(sigLength, groupCount, shingleCount));
        out.println("equivalent disjoint bucket count: " + BucketUtils.totalBucketCount(sigLength, groupCount, shingleCount)/BucketUtils.shingleCountPerElement(groupCount, shingleCount));
        out.println("split input sample: " + (split > 1));
        out.println("concurrency: " + concurrency);
        out.println("run the job: " + run);
        if(!run) {
            out.println("use \"-run\" option to run the job.");
            return true;
        }

        // 仅为样本数据创建倒排索引
        if(index) {
            LOG.info("Build index for sample data ...");
            return invert(getToolName() + ".invert", context, out, nWorker,
                    samplePath, outputPath, sigLength, groupCount, shingleCount);
        }
        
        // 为种子创建倒排
        if(!fs.exists(outputPath.cat(SEED_PATH)) || !con) {
            if(seedPathStr.length() == 0) {
                LOG.severe("Seed index not exists, you must provide \"-se\" argument to build the index.");
                return false;
            }
            LOG.info("Build seed index ...");
            if(!invert(getToolName() + ".invert", context, out, nWorker,
                    context.path(seedPathStr), outputPath.cat(SEED_PATH), sigLength, groupCount, shingleCount))
                return false;
        }

        // Neighbor finding
        Path mergePath = MapReduceHelper.createTempDir(fs, tempPath, "merge");
        if(split <= 1) {
            // 不需要分割输入
            out.println("Process input: " + samplePath.getAbsolutePath());
            if(!merge(getToolName() + ".merge", context, out, nWorker,
                    samplePath, outputPath.cat(SEED_PATH), mergePath, sigLength, groupCount, shingleCount,
                    simThreshold, mapCompress)) {
                return false;
            }
            if(!collect(getToolName() + ".collect", context, out, nWorker, mergePath, outputPath.cat(RESULT_PATH))) {
                return false;
            }
        } else {
            // 分割输入, 分别做neighbor finding
            split = Math.min(split, MapReduceHelper.getContinuousPartCount(fs, samplePath));
            Path splitPath = outputPath.cat(SPLIT_INPUT_PATH);
            Path[] inputs = null;
            if(fs.exists(splitPath)) {
                inputs = Utils.getSplitInput(fs, splitPath);
            }
            
            if(inputs == null || inputs.length != split) {
                fs.delete(splitPath);
                inputs = Utils.splitInput(fs, samplePath, splitPath, split);
                con = false;
            }

            // 同时提交多个job来处理多个输入
            JobQueue jobs = new JobQueue();
            for(int i = 0; i < inputs.length; i ++) {
                if(inputs[i] == null) continue;
                String jobName = inputs[i].getName();
                Path output = outputPath.cat(SPLIT_RESULT_PATH).cat(jobName);
                // 检查是否需要处理这个split
                if(con) {
                    if(fs.exists(output)) {
                        continue;
                    } else {
                        out.println("We will continue neighbor-finding job: " + jobName);
                    }
                }

                MyJob job = new MyJob(jobName, getToolName(), context, out, nWorker, inputs[i], outputPath.cat(SEED_PATH),
                        mergePath.cat(jobName), output, sigLength, groupCount, shingleCount, simThreshold, mapCompress);
                jobs.addJob(job);
            }
            
            // 并发执行Job队列
            jobs.run(concurrency);
            
            // 等待所有job返回, 并检查结果
            try {
                jobs.waitForDone();
            } catch (InterruptedException e) {
            }
            out.print("Failed jobs(total " + jobs.size() + " submitted):");
            int failed = 0;
            for(Job job: jobs) {
                boolean ret = (Boolean)job.getFuture();
                if(!ret) {
                    out.print(" " + job.getName());
                    failed ++;
                }
            }
            out.println("#" + failed);
            if(failed > 0) return false;
        }
        
        LOG.info("The neighbor-finding job has finished");
        return true;
    }

    public static boolean invert(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path inputPath, Path outputPath, int sigLength, int groupCount, int shingleCount) throws Exception {
        MapReduceJobDef job = context.createMapReduceJob(jobName, nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        job.setMapper(InvertMapper.class);
        helper.addReadInputDir(inputPath, null);
        job.setReducer(IdentityReducer.class);
        job.setMergeKeyValClass(StringWritable.class, StrBitsPair.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, StrBitsPair.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        job.setMapNumber(nWorker);
        job.setReduceNumber(nWorker*4);

        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);
        
        job.getConfig().setInt(CFG_SIG_LENGTH, sigLength);
        job.getConfig().setInt(CFG_GROUP_COUNT, groupCount);
        job.getConfig().setInt(CFG_SHINGLE_COUNT, shingleCount);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    public static boolean merge(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path inputPath, Path seedIndexPath, Path outputPath, int sigLength, int groupCount, int shingleCount,
            double simThreshold, boolean mapCompress) throws Exception {
        MapReduceJobDef job = context.createMapReduceJob(jobName, nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        job.setMapper(InvertMapper.class);
        helper.addReadInputDir(inputPath, null);

        ReduceMergeConf rmc = new ReduceMergeConf();
        rmc.setMergeReducer(MergeReducer.class);
        rmc.setMergeCount(MergeReducer.CIN_NUM);
        rmc.setMergeDir(MergeReducer.CIN_SEED, seedIndexPath, PerKeyBufferedWalker.class);
        job.plugin(rmc);
        
        job.setMergeKeyValClass(StringWritable.class, StrBitsPair.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, StringDim.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        int partCount = MapReduceHelper.getContinuousPartCount(context.getFileSystem(), seedIndexPath);
        job.setMapNumber(nWorker);
        job.setReduceNumber(partCount);

        // 自定义job设置
        if (mapCompress) {
            BasicPartitioner.setCompress(job, 0, 0, false);
        }
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);
        
        job.getConfig().setInt(CFG_SIG_LENGTH, sigLength);
        job.getConfig().setInt(CFG_GROUP_COUNT, groupCount);
        job.getConfig().setInt(CFG_SHINGLE_COUNT, shingleCount);
        job.getConfig().setDouble(CFG_SIM_THRESHOLD, simThreshold);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (result == null || !result.isSuccess()) return false;
        synchronized (out) {
            helper.printMessages(out, result.getMsg());
            helper.printCounters(out, result.getCounters());
        }
        return true;
    }
    
    public static boolean collect(String jobName, ToolContext context, PrintWriter out, int nWorker,
            Path inputPath, Path outputPath) throws Exception {
        MapReduceJobDef job = context.createMapReduceJob(jobName, nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        job.setMapper(IdentityMapper.class);
        helper.addReadInputDir(inputPath, null);
        job.setReducer(CollectReducer.class);
        job.setMergeKeyValClass(StringWritable.class, StringDim.class);
        job.setPartitionerClass(MyPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, StringDim.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        job.setMapNumber(nWorker);
        job.setReduceNumber(nWorker);

        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);
        
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (result == null || !result.isSuccess()) return false;
        synchronized (out) {
            helper.printMessages(out, result.getMsg());
            helper.printCounters(out, result.getCounters());
        }
        return true;
    }

    /**
     * 以指定并发度运行多个job
     * @author caofx
     *
     */
    private static class MyJob extends Job {
        private String toolName;
        private ToolContext context;
        private PrintWriter out;
        private int nWorker;
        private Path inputPath;
        private Path seedIndexPath;
        private Path mergePath;
        private Path outputPath;
        private int sigLength;
        private int groupCount;
        private int shingleCount;
        private double simThreshold;
        private boolean mapCompress;

        public MyJob(String jobName, String toolName, ToolContext context, PrintWriter out, int nWorker,
                Path inputPath, Path seedIndexPath, Path mergePath, Path outputPath, int sigLength, int groupCount, int shingleCount,
                double simThreshold, boolean mapCompress) {
            super(jobName);
            this.toolName = toolName;
            this.context = context;
            this.out = out;
            this.nWorker = nWorker;
            this.inputPath = inputPath;
            this.seedIndexPath = seedIndexPath;
            this.mergePath = mergePath;
            this.outputPath = outputPath;
            this.sigLength = sigLength;
            this.groupCount = groupCount;
            this.shingleCount = shingleCount;
            this.simThreshold = simThreshold;
            this.mapCompress = mapCompress;
            setFuture(Boolean.FALSE);
        }
        
        @Override
        public void run() {
            try {
                out.println("Running job: " + getName());
                if(!merge(toolName + ".merge." + getName(), context, out, nWorker,
                        inputPath, seedIndexPath, mergePath, sigLength, groupCount, shingleCount,
                        simThreshold, mapCompress)) {
                    return;
                }
                if(!collect(toolName + ".collect." + getName(), context, out, nWorker, mergePath, outputPath)) {
                    return;
                }
                setFuture(Boolean.TRUE);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                }
            }
        }
        
    }
    
    /**
     * 在对输入分组时, 各组的key是依原来的Partitioner聚集的, 这会导致在最后的collect阶段
     * 中各Reducer的数据分布不均, 因此需要使用另一个Partition规则
     * @author caofx
     *
     */
    public static class MyPartitioner extends SeqFileHashPartitioner {
        @Override
        public int getPartition(Object key, Object value, int numPartitions) {
            int hash = key.hashCode();
            hash = (hash >> 16) ^ hash;
            return (int) ((hash & Long.MAX_VALUE) % numPartitions);
        }
    }
    
    public static class StrBitsPair extends WritablePair<StringWritable, BitArray> {

        @Override
        protected StringWritable newFirstInstance() {
            return new StringWritable();
        }

        @Override
        protected BitArray newSecondInstance() {
            return new BitArray();
        }
        
        /**
         * 深拷贝
         * @param s
         * @param v
         */
        public void set(String s, BitArray v) {
            first.set(s);
            second.copyFields(v);
        }

        /**
         * @param s
         * @param v
         */
        public void set(String s, Vector v) {
            first.set(s);
            v.toBitArray(second);
        }

    }

    /**
     * 对签名进行分组(shingle), 并按shingle生成倒排
     * @author caofx
     *
     */
    public static class InvertMapper extends AbstractMapper<StringWritable, IWritable> {
        private int sigLength;
        private int groupCount;
        private int shingleCount;
        private int[][] groupCovering;
        private StringWritable bucketKey = new StringWritable();
        private StringWritable defaultBucketKey = new StringWritable("");
        private BitArray bitArray = new BitArray();
        private ArrayList<Integer> newpos = new ArrayList<Integer>();
        private StrBitsPair pair = new StrBitsPair();

        @Override
        public void configure(JobDef job, TaskRunnable task) {
            sigLength = job.getConfig().getInt(CFG_SIG_LENGTH);
            groupCount = job.getConfig().getInt(CFG_GROUP_COUNT);
            shingleCount = job.getConfig().getInt(CFG_SHINGLE_COUNT);

            int[] groupSize = BucketUtils.naiveSplitPolicy(sigLength, groupCount);
            groupCovering = new int[groupCount][];

            int begin = 0;
            for (int i = 0; i < groupCount; i++) {
                int size = groupSize[i];
                groupCovering[i] = new int[size];
                for (int j = 0; j < size; j++) {
                    groupCovering[i][j] = begin + j;
                }
                begin += size;
                Arrays.sort(groupCovering[i]);
            }

        }

        public void setBucketKey(BitArray v, int[] pos, StringWritable bucketKey) {
            String posStr = BucketKeyPosEncoderDecoder.compactPosArrayEncoder(pos);
            v.sample(pos, bitArray);
            bucketKey.set(posStr + "," + bitArray.hexString());
        }

        @Override
        public void map(StringWritable key, IWritable value, ICollector collector) {
            if(value instanceof BitArray) {
                // 签名是 CosHash
                pair.set(key.toString(), (BitArray) value);
            } else /* Vector */ {
                // 签名是 CosHashProduct
                pair.set(key.toString(), (Vector)value);
            }
            
            if(shingleCount == 0) {
                // 不分桶
                collector.collect(defaultBucketKey, pair);
                return;
            }
            
            // 分组签名并输出
            int[] selectedBucket = null;
            while (true) {
                selectedBucket = BucketUtils.nextCombination(groupCount, shingleCount, selectedBucket);
                if (selectedBucket[0] < 0) break;

                newpos.clear();
                for (int bucketIdx: selectedBucket) {
                    for (int j = 0; j < groupCovering[bucketIdx].length; j++) {
                        newpos.add(groupCovering[bucketIdx][j]);
                    }
                }

                Collections.sort(newpos);
                int[] newposa = new int[newpos.size()];
                for (int i = 0; i < newpos.size(); i++) {
                    newposa[i] = newpos.get(i);
                }
                setBucketKey(pair.getSecond(), newposa, bucketKey);
                collector.collect(bucketKey, pair);
            }
        }
    }
    
    /**
     * 对两路倒排做Merge, 计算Pairwise Similarity
     * 对于 MergeValues, 需要保证使用 {@link PerKeyBufferedWalker}
     * @author caofx
     *
     */
    public static class MergeReducer implements IMergeReducer<StringWritable, StrBitsPair, StrBitsPair> {
        private static final int CIN_SEED = 0;
        private static final int CIN_NUM = 1;
        private double simThreshold;
        private ArrayList<StrBitsPair> seeds = new ArrayList<StrBitsPair>(); 
        private StringDim simPair = new StringDim();
        private Counter validBucketCounter;

        @Override
        public void configure(JobDef job, TaskRunnable task) {
            simThreshold = job.getConfig().getDouble(CFG_SIM_THRESHOLD);
            validBucketCounter = task.getCounter(CounterName.VALID_BUCKET_COUNT.name());
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StrBitsPair> values,
                IWritablePairWalker<StringWritable, StrBitsPair>[] mergeValues,
                ICollector collector) {
            if(values == null || mergeValues[CIN_SEED] == null) return;
            seeds = Utils.fastClear(seeds, 100);
            while(mergeValues[CIN_SEED].moreValue()) {
                // 这里需要保证使用了PerKeyBufferedWalker
                seeds.add(mergeValues[CIN_SEED].getValue());
            }
            if(seeds.size() == 0) return;

            validBucketCounter.inc();
            while(values.moreValue()) {
                StrBitsPair value = values.getValue();
                BitArray sig = value.getSecond();
                double maxSim = -1;
                StrBitsPair maxSeed = null;
                for(StrBitsPair seed: seeds) {
                    double sim = CosHashUtils.getSimilarity(sig, seed.getSecond());
                    if(sim >= simThreshold && sim > maxSim) {
                        maxSim = sim;
                        maxSeed = seed;
                    }
                }
                if(maxSeed != null) {
                    simPair.setIndex(maxSeed.getFirst().get());
                    simPair.setValue(maxSim);
                    collector.collect(value.getFirst(), simPair);
                }
            }
            
        }

        @Override
        public void reduceBegin() {
        }

        @Override
        public void reduceEnd(ICollector collector) {
        }
        
    }
    
    public static class CollectReducer extends AbstractReducer<IWritable, StringDim> {
        private StringDim info = new StringDim();

        @Override
        public void reduce(IWritable key,
                IWritablePairWalker<IWritable, StringDim> values,
                ICollector collector) {
            info.setValue(-1);
            while(values.moreValue()) {
                StringDim value = values.getValue();
                if(value.getValue() > info.getValue()) {
                    info.copyFields(value);
                }
            }
            assert(info.getValue() >= 0);
            collector.collect(key, info);
        }
        
    }
    
}
