package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * 
 * @author caofx
 *
 */
public class StringDim implements IWritable, Comparable<StringDim> {
    private StringWritable index;
    private double value;
    
    public StringDim() {
        index = new StringWritable();
        value = 0;
    }
    
    public StringDim(StringDim that) {
        index = new StringWritable(that.index);
        value = that.value;
    }
    
    /**
     * @param index
     * @param value
     */
    public StringDim(String index, double value) {
        this.index = new StringWritable(index);
        this.value = value;
    }
    
    public void setIndex(String index) {
        this.index.set(index);
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getIndex() {
        return index.get();
    }

    public double getValue() {
        return value;
    }
    
    @Override
    public int compareTo(StringDim o) {
        return index.toString().compareTo(o.index.toString());
    }
    
    public String toString() {
        return "(" + index + ", " + value + ")";
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        index.readFields(in);
        value = in.readDouble();
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        index.writeFields(out);
        out.writeDouble(value);            
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if(this == value) return this;
        StringDim that = (StringDim) value;
        this.index.copyFields(that.index);
        this.value = that.value;
        return this;
    }
}
