package toolbox.vecat.base;

import java.util.HashSet;

/**
 * 如果bucketKey用string来记录，则可以使用这里的工具来对pos信息进行编码和解码。<br>
 * 这里提供两套编码解码方式，一种是简单模式，一种是紧缩模式。对于分桶算法来说，多数时候pos信息<br>
 * 都是连续的数字，所以建议使用紧缩模式。<br>
 * 不管使用哪种模式，解码和编码必须配套使用，不能混用:<br>
 * naivePosArrayEncoder 和 naivePosArrayDecoder 必须一起使用；<br>
 * compactPosArrayEncoder 和 compactPosArrayDecoder 必须一起使用；<br>
 * 
 * @author kick
 */
public class BucketKeyPosEncoderDecoder {

    /**
     * 以简单模式对pos信息进行编码。编码的方式是，直接把所有的pos写到字符串里，以逗号分隔。<br>
     * e.g. pos={1,2,4,5}, 它的编码就是"1,2,4,5".<br>
     * 
     * @param pos
     * @return
     */
    public static String naivePosArrayEncoder(int[] pos) {
        String posStr = "";
        for (int i = 0; i < pos.length; i++) {
            if (i != pos.length - 1) {
                posStr = posStr + pos[i] + ",";
            } else {
                posStr = posStr + pos[i];
            }
        }
        return posStr;
    }

    /**
     * 对以紧缩模式编码的pos信息进行解码。<br>
     * 
     * @param posStr
     * @param hs
     */
    public static void naivePosArrayDecoder(String posStr, HashSet<Integer> hs) {
        hs.clear();
        String[] s = posStr.split(",");
        for (int i = 0; i < s.length; i++) {
            try {
                hs.add(Integer.parseInt(s[i]));
            } catch (Exception e) {}
        }
    }

    /**
     * 以紧缩模式对pos信息进行编码。<br>
     * 和compactPosArrayDecoder配套使用。<br>
     * 编码方法是，对于连续的几个数字，只记录第一个数字和连续的个数，从而减少存储。<br>
     * 由于分桶算法中多数时候pos都是由连续数字组成，所以这个方法很管用。<br>
     * 要求输入的pos是按递增排序的。<br>
     * <br>
     * e.g. 如果 pos={5,6,7,8,10,11}, 它的编码就是"5,4,1,2"。<br>
     * 
     * @param pos
     * @return
     */
    public static String compactPosArrayEncoder(int[] pos) {
        boolean begin = true;
        int count = 0;
        int start = 0;
        String posStr = "";
        for (int i = 0; i < pos.length; i++) {
            if (begin) {
                begin = false;
                start = pos[i];
                count = 1;
                continue;
            }

            if (pos[i] == pos[i - 1] + 1) {
                count++;
            } else {
                posStr = posStr + start + "," + count + ",";
                start = pos[i];
                count = 1;
            }
        }
        posStr = posStr + start + "," + count;
        return posStr;
    }

    /**
     * 对以紧缩模式编码的pos信息进行解码。<br>
     * 和compactPosArrayEncoder配套使用, 解码原理见compactPosArrayEncoder的介绍。<br>
     * e.g. posStr="1,4,6,2"，对它解码之后得到的pos就是{1,2,3,4,6,7}.<br>
     * 
     * @param posStr
     * @param hs
     */
    public static void compactPosArrayDecoder(String posStr, HashSet<Integer> hs) {
        hs.clear();
        String[] s = posStr.split(",");
        for (int i = 0; i < s.length / 2; i++) {
            int begin = Integer.parseInt(s[i * 2]);
            int length = Integer.parseInt(s[i * 2 + 1]);
            for (int j = 0; j < length; j++) {
                hs.add(begin + j);
            }
        }
    }

    public static void main(String[] args) {
        int[] pos = new int[] {
            1, 2, 3, 4, 6, 7, 8, 9, 10, 100, 101, 102, 105, 109, 120
        };

        System.out.println("pos information: ");
        for (int i = 0; i < pos.length; i++) {
            System.out.print(pos[i] + " ");
        }
        System.out.println();
        System.out.println();

        System.out.println("naive encode: ");
        String naive = naivePosArrayEncoder(pos);
        System.out.println(naive);
        System.out.println();

        System.out.println("compact encode: ");
        String compact = compactPosArrayEncoder(pos);
        System.out.println(compact);
        System.out.println();
    }

}
