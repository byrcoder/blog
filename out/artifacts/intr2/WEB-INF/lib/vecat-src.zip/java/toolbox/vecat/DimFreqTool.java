package toolbox.vecat;

import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.data.LongDoublePair;

public class DimFreqTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(DimFreqTool.class);

    private static enum CounterName {
        COUNT,
        SUM,
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path");
    }

    @Override
    public String comment() {
        return "Count dim frequency in vector data.";
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        // 环境设置, 初始化
        Path inputPath = context.path(options.getStringOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        
        // MR settings
        MapReduceJobDef job = context.createMapReduceJob(this.getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        helper.addReadInputDir(inputPath, null);
        job.setMapper(Mapper.class);
        job.setReducer(Reducer.class);
        job.setMergeKeyValClass(StringWritable.class, DoubleWritable.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, LongDoublePair.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        job.setMapNumber(nWorker);
        job.setReduceNumber(nWorker);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class Mapper extends AbstractMapper<IWritable, AbstractVector> {
        private StringWritable dimName = new StringWritable();
        private DoubleWritable dimValue = new DoubleWritable();
        
        public void map(IWritable key, AbstractVector value, ICollector collector) {
            for(int i = 0; i < value.size(); i ++) {
                dimName.set(value.getIndexName(i));
                dimValue.set(value.getValue(i));
                collector.collect(dimName, dimValue);
            }
        }
    }
    
    public static class Reducer extends AbstractReducer<StringWritable, DoubleWritable> {
        private LongDoublePair result = new LongDoublePair();
        private Counter countCounter;
        private Counter sumCounter;
        
        @Override
        public void configure(JobDef job, TaskRunnable task) {
            countCounter = task.getCounter(CounterName.COUNT.name());
            sumCounter = task.getCounter(CounterName.SUM.name());
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, DoubleWritable> values,
                ICollector collector) {
            long count = 0;
            double sum = 0;
            while(values.moreValue()) {
                count ++;
                sum += values.getValue().get();
            }
            countCounter.inc(count);
            sumCounter.inc((long) sum);
            result.set(count, sum);
            collector.collectToChannel(0, key, result);
        }
        
    }
}
