package toolbox.vecat.base;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * 支持并发执行的任务队列
 * @author caofx
 *
 */
public class JobQueue implements Iterable<JobQueue.Job> {
    private ArrayList<Job> jobs = new ArrayList<Job>();
    private int current = 0;
    private int done = 0;

    /**
     * 向队列中添加一个{@link Job}
     * @param job
     */
    public synchronized void addJob(Job job) {
        jobs.add(job);
    }

    /**
     * 从队列中获取下一个{@link Job}, 如果没有返回null
     * @return
     */
    public synchronized Job nextJob() {
        if(current == jobs.size()) return null;
        return jobs.get(current ++);
    }

    /**
     * @return 队列中的{@link Job}数目
     */
    public synchronized int size() {
        return jobs.size();
    }

    /**
     * @return 队列中未执行的{@link Job}数目
     */
    public synchronized int unexecuted() {
        return jobs.size() - current;
    }

    /**
     * @return 队列中已完成的{@link Job}数目
     */
    public synchronized int done() {
        return done;
    }

    /**
     * 清空队列
     */
    public synchronized void clear() {
        jobs.clear();
        current = 0;
        done = 0;
    }

    /**
     * 以指定的并发度(线程数)运行队列中所有未执行的{@link Job}
     * @param concurrency
     */
    public void run(int concurrency) {
        concurrency = Math.min(concurrency, unexecuted());
        for(int i = 0; i < concurrency; i ++) {
            JobRunner runner = new JobRunner(this);
            runner.start();
        }
    }

    /**
     * 等待队列中所有{@link Job}完成
     * @throws InterruptedException 
     */
    public synchronized void waitForDone() throws InterruptedException {
        while(done != jobs.size()) {
            wait();
        }
    }

    /** 
     * 注意: 这个方法是未同步的 
     * @see java.lang.Iterable#iterator()
     */
    @Override
    public Iterator<JobQueue.Job> iterator() {
        return jobs.iterator();
    }

    private synchronized void finishAJob() {
        if((++ done) == jobs.size()) {
            notifyAll();
        }
    }

    /**
     * 描述一个任务
     * @author caofx
     *
     */
    public static abstract class Job implements Runnable {
        private String name;
        private Object future = null;

        /**
         * @param name Job名称
         */
        public Job(String name) {
            this.name = name;
        }

        /**
         * @return Job名称
         */
        public String getName() {
            return name;
        }

        /**
         * 设置future, 在任务结束后调用者通过{@link #getFuture()}获取任务的完成状况
         * @param future
         */
        protected void setFuture(Object future) {
            this.future = future;
        }

        /**
         * 获取任务的完成状况
         * @return
         */
        public Object getFuture() {
            return future;
        }

    }

    /**
     * 描述执行任务的线程
     * @author caofx
     *
     */
    public static class JobRunner extends Thread {
        private JobQueue jobs;

        /**
         * @param jobs Job队列
         */
        public JobRunner(JobQueue jobs) {
            super();
            this.jobs = jobs;
        }

        /**
         * @param name 线程名称
         * @param jobs Job队列
         */
        public JobRunner(String name, JobQueue jobs) {
            super(name);
            this.jobs = jobs;
        }

        /**
         * 从队列中获取一个job并执行, 如果{@link JobQueue#unexecuted()} == 0则线程退出
         * @see java.lang.Thread#run()
         */
        @Override
        public final void run() {
            while(true) {
                Job job = null;
                // 从队列中获取一个job
                job = jobs.nextJob();
                if(job == null) return;
                job.run();
                jobs.finishAJob();
            }
        }
    }
}
