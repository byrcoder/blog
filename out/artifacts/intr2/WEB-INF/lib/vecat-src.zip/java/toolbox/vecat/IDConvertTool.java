package toolbox.vecat;

import java.io.IOException;
import java.util.logging.Logger;

import odis.app.data.DocID;
import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobResult;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.serialize.IWritable;
import odis.tools.MapReduceHelper;
import toolbox.cluster.Instance;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;

public class IDConvertTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(IDConvertTool.class);
    private static final String RESULT_PATH = "result";
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path");
    }

    @Override
    public String comment() {
        return "Convert similarity data format for ClusterFinder";
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        // 环境设置, 初始化
        String [] inputs = options.getOpt("i");
        Path outputPath = context.path(options.getStringOpt("o"));
        
        // MR settings
        MapOnlyJobDef job = context.createMapOnlyJob(this.getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        //Process input
        Path inputPath = null;
        if(inputs.length == 1) {
            inputPath = context.path(inputs[0]);
        } else {
            inputPath = helper.getTempOutput("input");
            int i = 0;
            for(String input: inputs) {
                Path path = context.path(input);
                LOG.info("src = " + path.getAbsolutePath());
                try {
                    fs.getLock(path, IFileSystem.SHARED_LOCK);
                    FileInfo[] files = fs.listFiles(path);
                    if (files == null) {
                        throw new IOException(path.getAbsolutePath() + " does not exist or denote a directory");
                    }
                    for (FileInfo file: files) {
                        fs.link(file.getPath(), inputPath.cat(CoWorkUtils.getPartID(i++)));
                    }
                } finally {
                    fs.releaseLock(path);
                }
            }
        }

        helper.addReadInputDir(inputPath, null);
        helper.addUpdateOutputDir(0, outputPath.cat(RESULT_PATH), Instance.ID.class, Instance.ID.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        job.setMapper(Mapper.class);
        job.setMapNumber(nWorker);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class Mapper extends AbstractMapper<IWritable, IWritable> {
        private Instance.ID keyID = new Instance.ID();
        private Instance.ID valueID = new Instance.ID();

        public void map(IWritable key, IWritable value, ICollector collector) {
            if(key.equals(value)) return;
            keyID.set(DocID.getDocID(key.toString()).get());
            valueID.set(DocID.getDocID(value.toString()).get());
            collector.collectToChannel(0, keyID, valueID);
        }
    }
}
