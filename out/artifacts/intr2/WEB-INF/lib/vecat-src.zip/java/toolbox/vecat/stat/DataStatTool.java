package toolbox.vecat.stat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.app.view.SeqFileUtils;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.stat.StatBase.AbstractStatResult;
import toolbox.vecat.stat.StatBase.DataParser;
import toolbox.vecat.stat.StatBase.NumericParser;
import toolbox.vecat.stat.StatBase.SimpleStatResult;
import toolbox.vecat.stat.StatBase.StatResult;
import toolbox.vecat.stat.StatBase.StatVariable;

/**
 * 基于CoWork的 Sequence File 数据统计工具, 通过实现{@link StatBase.DataParser}解析器来定义统计变量,
 * 给出均值, 最值, 方差, 直方图等统计结果. 默认使用{@link StatBase.NumericParser}, 可以直接统计
 * Key => Numeric 的 Sequence File
 * @author caofx
 *
 */
public class DataStatTool extends AbstractCoWorkToolWithArg {
    private static final Logger LOG = LogFormatter.getLogger(DataStatTool.class);
    private static final String CFG_PARSERNAME = DataStatTool.class.getName() + "CFG_PARSERNAME";
    private static final String CFG_FS = DataStatTool.class.getName() + "CFG_FS";
    private static final String CFG_WORKDIR = DataStatTool.class.getName() + "CFG_WORKDIR";
    private static final String CFG_HISTLEVEL = DataStatTool.class.getName() + "CFG_HISTLEVEL";
    private static final String CFG_LOGARITHMIC = DataStatTool.class.getName() + "CFG_LOGARITHMIC";
    private static final String STEP1_RESULT_NAME = "step1_result";

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("p", "parser_name", "set parser name.").setDefault(NumericParser.class.getName());
        options.withOption("h", "hist_level", "set histogram level.").setDefault(6);
        options.withOption("l", "use logarithmic axes");
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
    }

    @Override
    public String comment() {
        return "Do data statistics on CoWork";
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        // Environment configuration & initialization
        Class<? extends DataParser> parserClass = (Class<? extends DataParser>) Class.forName(options.getStringOpt("p"));
        int histLevel = options.getIntOpt("h");
        boolean logarithmic = options.isOptSet("l");
        Path inputPath = context.path(options.getStringOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        LOG.info("Input path: " + inputPath.getAbsolutePath());
        
        Path workDir = context.tempPath(getToolName());
        if (fs.exists(workDir)) fs.delete(workDir); 
        fs.mkdirs(workDir);
        Path linkedInputPath = MapReduceHelper.linkInput(fs, inputPath, workDir.cat("input"));

        // Job1 settings
        Path outputPath1 = workDir.cat("output1");
        MapOnlyJobDef job1 = context.createMapOnlyJob(getToolName() + ".step1", nWorker);
        job1.setMapper(SimpleStatMapper.class);
        job1.setMapNumber(nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job1);
        job1.addInputDir(linkedInputPath);
        helper.addUpdateOutputDir(0, outputPath1, StringWritable.class, SimpleStatResult.class, null);
        GenericFileOutputFormat.setCompress(job1, 0, 0);

        // 自定义 job 设置
        job1.getConfig().setProperty(CFG_PARSERNAME, parserClass.getName());

        // Run job
        JobResult result1 = helper.runJob(context.getCoWork());
        if(!result1.isSuccess()) return false;
        
        // 汇总第一轮统计结果
        Map<StringWritable, AbstractStatResult> map1 = mergeResult(fs, outputPath1);
        SeqFileUtils.saveMapToFile(fs, workDir.cat(STEP1_RESULT_NAME), map1);
        helper.printMessages(out, result1.getMsg());
        helper.printCounters(out, result1.getCounters());
        
        // Job2 settings
        Path outputPath2 = workDir.cat("output2");
        MapOnlyJobDef job2 = context.createMapOnlyJob(getToolName() + ".step2", nWorker);
        job2.setMapper(StatMapper.class);
        job2.setMapNumber(nWorker);
        helper = new MapReduceHelper(context, job2);
        job2.addInputDir(linkedInputPath);
        helper.addUpdateOutputDir(0, outputPath2, StringWritable.class, StatResult.class, null);
        GenericFileOutputFormat.setCompress(job2, 0, 0);

        // 自定义 job 设置
        job2.getConfig().setProperty(CFG_FS, fs.getName());
        job2.getConfig().setProperty(CFG_WORKDIR, workDir.getAbsolutePath());
        job2.getConfig().setProperty(CFG_PARSERNAME, parserClass.getName());
        job2.getConfig().setInt(CFG_HISTLEVEL, histLevel);
        job2.getConfig().setBoolean(CFG_LOGARITHMIC, logarithmic);

        // Run job
        JobResult result2 = helper.runJob(context.getCoWork());
        if(!result2.isSuccess()) return false;
        
        // 汇总第二轮统计结果, 并输出
        Map<StringWritable, AbstractStatResult> map2 = mergeResult(fs, outputPath2);
        if (fs.exists(outputPath)) fs.delete(outputPath); 
        SeqFileUtils.saveMapToFile(fs, outputPath, map2);
        helper.printMessages(out, result2.getMsg());
        helper.printCounters(out, result2.getCounters());
        fs.delete(workDir);
        return true;
    }
    
    /**
     * 汇总指定fs, path下储存的统计结果
     * @param fs
     * @param path
     * @return 汇总结果
     * @throws IOException 
     */
    public static Map<StringWritable, AbstractStatResult> mergeResult(IFileSystem fs, Path path) throws IOException {
        Map<StringWritable, AbstractStatResult> map = new HashMap<StringWritable, AbstractStatResult>();
        List<Path> inputs = new ArrayList<Path>();
        if (fs.isFile(path)) {
            inputs.add(path);
        } else {
            for (FileInfo info : fs.listFiles(path)) {
                inputs.add(info.getPath());
            }
        }
        
        for (Path input : inputs) {
            SequenceFile.Reader reader = new SequenceFile.Reader(fs, input);
            try {
                StringWritable key = new StringWritable();
                Object value = ClassUtils.newInstance(reader.getValueClass());
                while (reader.next(key, value)) {
                    AbstractStatResult current = map.get(key);
                    if(current == null) {
                        current = (AbstractStatResult) ClassUtils.newInstance(reader.getValueClass());
                        map.put(new StringWritable(key), current);
                    }
                    current.merge((AbstractStatResult) value);
                }
            } finally {
                reader.close();
            }
        }
        
        return map;
    }
    
    /**
     * 输入: 指定的 Sequence File库, 指定的 DataParser
     * 输出: varName => {@link SimpleStatResult}
     * @author caofx
     *
     */
    public static class SimpleStatMapper extends AbstractMapper<IWritable, IWritable> {
        StringWritable varName = new StringWritable();
        private HashMap<String, SimpleStatResult> map = new HashMap<String, SimpleStatResult>();
        private DataParser parser;
        private Counter parsedCounter;

        public void configure(JobDef job, TaskRunnable task) {
            try {
                parser = (DataParser) Class.forName(job.getConfig().getString(CFG_PARSERNAME)).newInstance();
            } catch (Exception e) {
                throw new TaskFatalException("Error initializing parser", e);
            }
            parsedCounter = task.getCounter("ParsedCounter");
        }

        public void map(IWritable key, IWritable value, ICollector collector) {
            StatVariable[] vars = parser.getVariables(key, value);
            if(vars.length <= 0) return;
            parsedCounter.inc();
            for(StatVariable var: vars) {
                SimpleStatResult item = map.get(var.name);
                if(item == null) {
                    item = new SimpleStatResult();
                    map.put(var.name, item);
                }
                item.record(var.value);
            }
        }

        public void mapEnd(ICollector collector) {
            for(Entry<String, SimpleStatResult> entry: map.entrySet()) {
                varName.set(entry.getKey());
                collector.collect(varName, entry.getValue());
            }
        }

    }
    
    /**
     * 输入: 指定的 Sequence File库, 指定的 DataParser
     * 输出: varName => {@link StatResult}
     * @author caofx
     *
     */
    public static class StatMapper extends AbstractMapper<IWritable, IWritable> {
        StringWritable varName = new StringWritable();
        private HashMap<String, StatResult> map = new HashMap<String, StatResult>();
        private IFileSystem fs;
        private Path workDir;
        private DataParser parser;
        private int histLevel;
        private boolean logarithmic;
        private Counter parsedCounter;
        private Counter errorCounter;

        public void configure(JobDef job, TaskRunnable task) {
            try {
                parser = (DataParser) Class.forName(job.getConfig().getString(CFG_PARSERNAME)).newInstance();
                fs = FileSystem.getNamed(job.getConfig().getString(CFG_FS));
            } catch (IOException e) {
                throw new TaskFatalException("Error getting fs", e);
            } catch (Exception e) {
                throw new TaskFatalException("Error initializing parser", e);
            }
            workDir = new Path(job.getConfig().getString(CFG_WORKDIR));
            histLevel = job.getConfig().getInt(CFG_HISTLEVEL);
            logarithmic = job.getConfig().getBoolean(CFG_LOGARITHMIC);
            
            // 读取第一轮汇总结果, 作为本轮统计的参数
            try {
                Map<Object, Object> step1Map = SeqFileUtils.loadToMap(fs, workDir.cat(STEP1_RESULT_NAME));
                for(Entry<Object, Object> entry: step1Map.entrySet()) {
                    String key = ((StringWritable)entry.getKey()).get();
                    SimpleStatResult value = (SimpleStatResult)entry.getValue();
                    map.put(key, new StatResult(value.getMax(), value.getMin(),
                            value.getSum()/value.getSize(), histLevel, logarithmic));
                }
            } catch(IOException e) {
                throw new TaskFatalException("Error loading step1 result", e);
            }
            
            parsedCounter = task.getCounter("ParsedCounter");
            errorCounter = task.getCounter("ErrorCounter");
        }

        public void map(IWritable key, IWritable value, ICollector collector) {
            StatVariable[] vars = parser.getVariables(key, value);
            if(vars.length <= 0) return;
            parsedCounter.inc();
            for(StatVariable var: vars) {
                StatResult item = map.get(var.name);
                if(item == null) {
                    errorCounter.inc();
                    continue;
                }
                item.record(var.value);
            }
        }

        public void mapEnd(ICollector collector) {
            for(Entry<String, StatResult> entry: map.entrySet()) {
                varName.set(entry.getKey());
                collector.collect(varName, entry.getValue());
            }
        }
    }
    
}