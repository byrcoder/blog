package toolbox.vecat.base;

import odis.serialize.IWritable;
import toolbox.vecat.data.AbstractVector;

/**
 * 将输入的 {@link AbstractVector}数据原样返回
 * @author caofx
 *
 */
public class SimpleVectorConverter implements IVectorConverter {

    @Override
    public AbstractVector convert(IWritable key, IWritable value) {
        return (AbstractVector) value;
    }

}
