package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * 以 int 为 index 类型的 (Dense)Vector
 * @author caofx
 *
 */
public class Vector extends AbstractIntegerVector {
    private int size;
    private double [] values;
    private double modulus = -1;

    public Vector() {
        this(0);
    }

    public Vector(int size) {
        resize(size);
    }

    @Override
    public int getIndex(int i) {
        return i;
    }

    @Override
    public double getValue(int i) {
        rangeCheck(i);
        return values[i];
    }

    @Override
    public void resize(int size) {
        this.size = size;
        if(values == null || values.length < size) {
            values = new double [size];
        }
        modulus = -1;
    }

    /**
     * 为性能优化 
     * 
     * @see toolbox.vecat.data.AbstractVector#clear()
     */
    @Override
    public void clear() {
        for(int i = 0; i < size; i ++) {
            values[i] = 0;
        }
    }
    
    @Override
    public void setValue(int i, double value) {
        rangeCheck(i);
        values[i] = value;
        modulus = -1;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int size = in.readInt();
        resize(size);
        for(int i = 0; i < size; i ++) {
            values[i] = in.readDouble();
        }
        modulus = -1;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        int size = size();
        out.writeInt(size);
        for(int i = 0; i < size; i ++) {
            out.writeDouble(values[i]);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if(this == value) return this;
        Vector that = (Vector) value;
        int size = that.size();
        resize(size);
        for(int i = 0; i < size; i ++) {
            values[i] = that.values[i];
        }
        modulus = -1;
        return this;
    }

    @Override
    public double modulus() {
        if(modulus < 0) {
            modulus = 0;
            for(int i = 0; i < size; i ++) {
                double v = values[i];
                modulus += v*v;
            }
            modulus = Math.sqrt(modulus);
        }
        return modulus;
    }

    @Override
    public double distance(AbstractVector o) {
        if(o instanceof Vector) {
            double distance = 0;
            Vector that = (Vector) o;
            int size = Math.min(this.size, that.size);
            int i = 0;
            for(; i < size; i ++) {
                double v = values[i] - that.values[i];
                distance += v*v;
            }
            for(int j = i; j < this.size; j ++) {
                double v = values[j];
                distance += v*v;
            }
            for(int j = i; j < that.size; j ++) {
                double v = that.values[j];
                distance += v*v;
            }
            return Math.sqrt(distance);
        }
        return super.distance(o);
    }

    @Override
    public double innerProduct(AbstractVector o) {
        if(o instanceof Vector) {
            double product = 0;
            Vector that = (Vector) o;
            int size = Math.min(this.size, that.size);
            for(int i = 0; i < size; i ++) {
                product += values[i]*that.values[i];
            }
            return product;
        }
        return super.innerProduct(o);
    }
    
    /**
     * 计算两个签名向量的diff, 为性能优化, 需要保证v1, v2的size相同
     * @param v1
     * @param v2
     * @return
     */
    public static int getDiff(Vector v1, Vector v2) {
        int diff = 0;
        int size = v1.size;
        double[] values1 = v1.values;
        double[] values2 = v2.values;
        for(int i = 0; i < size; i ++) {
            if(values1[i] * values2[i] < 0) {
                diff ++;
            }
        }
        return diff;
    }
    
    /**
     * 返回内部缓冲区, 有效数据长度由{@link #size()}确定
     * @return
     */
    public double[] getBuffer() {
        return values;
    }
    
    /**
     * 生成BitArray, 其第i位取值为 v[i]<0? 0: 1
     * @param b
     */
    public void toBitArray(BitArray b) {
        b.resize(size);
        for(int i = 0; i < size; i ++) {
            b.setValue(i, values[i] < 0? 0: 1);
        }
    }

    @Override
    public String toString() {
        StringBuilder buffer = new StringBuilder("[");
        for(int i = 0; i < size(); i ++) {
            buffer.append(getValue(i));
            if(i < size()-1) buffer.append(", ");
        }
        return buffer.append("]#").append(size()).toString();
    }

}
