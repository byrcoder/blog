package toolbox.vecat.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;

import odis.serialize.IWritable;

/**
 * 以 String 为 index 类型的 SparseVector
 * @author caofx
 *
 */
public class StringSparseVector extends AbstractVector {
    private int size;
    private StringDim [] dims;
    private static final Comparator<StringDim> INDEX_COMPARATOR = new Comparator<StringDim>() {
        @Override
        public int compare(StringDim o1, StringDim o2) {
            return o1.getIndex().compareTo(o2.getIndex());
        }
    };
    
    public StringSparseVector() {
        this(0);
    }
    
    public StringSparseVector(int size) {
        resize(size);
    }
    
    public void resize(int size) {
        this.size = size;
        if(dims == null || dims.length < size) {
            dims = new StringDim [size];
            for(int i = 0; i < size; i ++) dims[i] = new StringDim();
        }
    }
    
    /**
     * 对Collection中的元素作深拷贝
     * @param dims
     */
    public void set(Collection<StringDim> dims) {
        resize(dims.size());
        int i = 0;
        for(StringDim dim: dims) {
            this.dims[i ++].copyFields(dim);
        }
        sort();
    }
    
    /**
     * 以指定的顺序, 指定的个数将vector截断
     * @param count
     * @param comparator
     */
    public void truncate(int count, Comparator<StringDim> comparator) {
        if(size <= count) return;
        Arrays.sort(dims, 0, size, comparator);
        size = count;
        sort();
    }
    
    public int size() {
        return size;
    }
    
    public String getIndex(int i) {
        rangeCheck(i);
        return dims[i].getIndex();
    }
 
    public String getIndexName(int i) {
        return getIndex(i);
    }

    public double getValue(int i) {
        rangeCheck(i);
        return dims[i].getValue();
    }

    public void setIndex(int i, String index) {
        rangeCheck(i);
        dims[i].setIndex(index);
    }
 
    public void setValue(int i, double value) {
        rangeCheck(i);
        dims[i].setValue(value);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int size = in.readInt();
        resize(size);
        for(int i = 0; i < size; i ++) {
            dims[i].readFields(in);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        int size = size();
        out.writeInt(size);
        for(int i = 0; i < size; i ++) {
            dims[i].writeFields(out);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if(this == value) return this;
        StringSparseVector that = (StringSparseVector) value;
        int size = that.size();
        resize(size);
        for(int i = 0; i < size; i ++) {
            dims[i].copyFields(that.dims[i]);
        }
        return this;
    }
    
    public String toString() {
        StringBuilder buffer = new StringBuilder("[");
        for(int i = 0; i < size(); i ++) {
            buffer.append(dims[i]);
            if(i < size()-1) buffer.append(", ");
        }
        return buffer.append("]#").append(size()).toString();
    }

    public void sort() {
        Arrays.sort(dims, 0, size, INDEX_COMPARATOR);
    }
    
    @Override
    protected int compareIndex(int i, AbstractVector that, int j) {
        String i1 = this.getIndex(i);
        String i2 = ((StringSparseVector)that).getIndex(j);
        return i1.compareTo(i2);
    }

}
