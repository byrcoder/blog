package toolbox.vecat.utils;

/**
 * 对基本数据进行按位或者按个比较不同.<br> 
 * diffBit是按位比较，diffUnit是按个比较。<br>
 * 这里假设参与比较的两个数组的长度相同。<br>
 * 
 * @author kick
 *
 */
public class DiffTools {

    private static final int LONG_BIT_LEN = 64;

    private static final int INT_BIT_LEN = 32;

    private static final int SHORT_BIT_LEN = 16;

    private static final int BYTE_BIT_LEN = 8;

    public static int diffBit(byte[] b1, byte[] b2) {
        int len = b1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            d += diffBit(b1[i], b2[i]);
        }
        return d;
    }

    public static int diffBit(short[] b1, short[] b2) {
        int len = b1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            d += diffBit(b1[i], b2[i]);
        }
        return d;
    }

    public static int diffBit(int[] b1, int[] b2) {
        int len = b1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            d += diffBit(b1[i], b2[i]);
        }
        return d;
    }

    public static int diffBit(long[] l1, long[] l2) {
        int len = l1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            d += diffBit(l1[i], l2[i]);
        }
        return d;
    }

    public static int diffUnit(byte[] b1, byte[] b2) {
        int len = b1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            if (b1[i] != b2[i])
                d++;
        }
        return d;
    }

    public static int diffUnit(short[] b1, short[] b2) {
        int len = b1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            if (b1[i] != b2[i])
                d++;
        }
        return d;
    }

    public static int diffUnit(int[] b1, int[] b2) {
        int len = b1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            if (b1[i] != b2[i])
                d++;
        }
        return d;
    }

    public static int diffUnit(long[] l1, long[] l2) {
        int len = l1.length;
        int d = 0;
        for (int i = 0; i < len; i++) {
            if (l1[i] != l2[i])
                d++;
        }
        return d;
    }

    public static int diffBit(long l1, long l2, int bitLen) {
        long c = l1 ^ l2;
        int d = 0;
        for (int i = 0; i < bitLen; i++) {
            d += (c >> i) & 0x1;
        }
        return d;
    }

    public static int diffBit(long b1, long b2) {
        return diffBit(b1, b2, LONG_BIT_LEN);
    }

    public static int diffBit(int i1, int i2) {
        return diffBit(i1, i2, INT_BIT_LEN);
    }

    public static int diffBit(short s1, short s2) {
        return diffBit(s1, s2, SHORT_BIT_LEN);
    }

    public static int diffBit(byte b1, byte b2) {
        return diffBit(b1, b2, BYTE_BIT_LEN);
    }

}
