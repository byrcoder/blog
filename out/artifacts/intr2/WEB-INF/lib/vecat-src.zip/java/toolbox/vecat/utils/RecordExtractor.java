package toolbox.vecat.utils;

import java.io.IOException;

import odis.app.job.AbstractLocalToolWithArg;
import odis.cowork.CoWorkUtils;
import odis.file.SequenceFile.Writer;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.UrlMd5Partitioner;
import odis.serialize.IParsable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.lib.Url;
import odis.tools.MapReduceHelper;
import odis.tools.misc.DumpTool;
import toolbox.misc.cli.Options;

/**
 * 以指定的key从指定的文件中抽取指定的记录并保存为新的SequenceFile
 * @author caofx
 *
 */
public class RecordExtractor extends AbstractLocalToolWithArg {


    @Override
    public String comment() {
        return "Extract records from sequence files";
    }
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
        options.withOption("k", "key", "set key(s) for record.");
    }

    @Override
    public boolean exec() throws Exception {
        // 处理输入
        final Path inputPath = context.path(options.getStringOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        String[] keys = options.getOpt("k");
        
        final FileSystem fs = context.getFileSystem();
        final Class<? extends IWritable>[] kvClass = Utils.getKeyValueClass(fs, inputPath.cat(CoWorkUtils.getPartID(0)));
        assert(IParsable.class.isAssignableFrom(kvClass[0]));

        fs.mkdirs(outputPath);
        Utils.writeToSeqFile(fs, outputPath.cat(CoWorkUtils.getPartID(0)), keys, kvClass[0], kvClass[1], true, new Utils.WriteOperator<String[]>() {
            @Override
            public void operate(Writer writer, String[] keys) throws IOException {
                IWritableComparable keyWritable;
                try {
                    keyWritable = (IWritableComparable) kvClass[0].newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
                for(String key: keys) {
                    try {
                        ((IParsable)keyWritable).parse(key);
                    } catch (ParseException e) {
                        continue;
                    }
                    IWritable[] values = getRecordValue(fs, inputPath, keyWritable, getPartitioner(kvClass[0]));
                    if(values == null) continue;
                    for(IWritable value: values) {
                        writer.write(keyWritable, value);
                    }
                }
            }
            
        });
        return true;
    }
    
    private static BasicPartitioner getPartitioner(Class<?> keyClass) {
        if(keyClass == Url.class) {
            return new UrlMd5Partitioner();
        } else {
            return new SeqFileHashPartitioner();
        }
    }
    
    public static IWritable[] getRecordValue(FileSystem fs, Path path, IWritableComparable key, BasicPartitioner partioner) throws IOException {
        int partCount = MapReduceHelper.getContinuousPartCount(fs, path);
        int partNum = partioner.getPartition(key, null, partCount);
        IWritable[] records = DumpTool.searchInSortedSequenceFile(fs, path.cat(CoWorkUtils.getPartID(partNum)).getAbsolutePath(), key);
        return records;
    }
    
}
