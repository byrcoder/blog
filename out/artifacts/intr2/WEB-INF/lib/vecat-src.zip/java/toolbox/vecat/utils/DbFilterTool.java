package toolbox.vecat.utils;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapOnlyMergeConf;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.ReuseWalker;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.tools.MapReduceHelper;
import toolbox.misc.cli.Options;

public class DbFilterTool extends AbstractCoWorkToolWithArg {

    private static enum CounterName {
        KEY_COUNT,
        LOST_COUNT,
    }

    @Override
    public String comment() {
        return "Filter db with given key db";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("k", "key_path", "set input key path");
        options.withOption("o", "output_path", "set output path.");
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(options.getStringOpt("i"));
        Path keyPath = context.path(options.getStringOpt("k"));
        Path outputPath = context.path(options.getStringOpt("o"));
        
        // MR settings
        MapOnlyJobDef job = context.createMapOnlyJob(getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        
        MapOnlyMergeConf mmc = new MapOnlyMergeConf();
        mmc.setMergeMapper(Mapper.class);
        mmc.setMergeCount(Mapper.CIN_NUM);
        mmc.setMergeDir(Mapper.CIN_INPUT, helper.getReadInput(inputPath), ReuseWalker.class);
        mmc.setMergeDir(Mapper.CIN_KEY, helper.getReadInput(keyPath), ReuseWalker.class);
        job.plugin(mmc);

        Class<? extends IWritable>[] kvClass = Utils.getKeyValueClass(fs, inputPath);
        helper.addUpdateOutputDir(0, outputPath, (Class<? extends IWritableComparable>) kvClass[0], kvClass[1], null);
        GenericFileOutputFormat.setCompress(job, 0, 0);

        int partCount = MapReduceHelper.getContinuousPartCount(context.getFileSystem(), inputPath);
        job.setMapNumber(partCount);
        
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class Mapper implements IMergeMapper<IWritable, IWritable> {
        private static final int CIN_INPUT = 0;
        private static final int CIN_KEY = 1;
        private static final int CIN_NUM = 2;
        private Counter keyCounter;
        private Counter lostCounter;

        @Override
        public void configure(JobDef conf, TaskRunnable task) {
            keyCounter = task.getCounter(CounterName.KEY_COUNT.name());
            lostCounter = task.getCounter(CounterName.LOST_COUNT.name());
        }

        @Override
        public void map(IWritable key,
                IWritablePairWalker<IWritable, IWritable>[] mergeValues,
                ICollector collector) {
            if(mergeValues[CIN_KEY] == null || !mergeValues[CIN_KEY].moreValue()) {
                return;
            }
            keyCounter.inc();
            boolean lost = true;
            while(mergeValues[CIN_INPUT] != null && mergeValues[CIN_INPUT].moreValue()) {
                collector.collect(key, mergeValues[CIN_INPUT].getValue());
                lost = false;
            }
            if(lost) lostCounter.inc();
        }

        @Override
        public void mapBegin() {
        }

        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }
}
