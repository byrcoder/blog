package toolbox.vecat.data;

import java.util.ArrayList;
import java.util.List;

import odis.serialize.IWritable;

/**
 * Vector基类
 * @author caofx
 *
 */
public abstract class AbstractVector implements IWritable, Cloneable {
    /**
     * 重新指定AbstractVector的大小, 如果指定size比{@link #size()}大则扩展后的vector数据是不确定的
     * @param size
     */
    public abstract void resize(int size);
    
    /**
     * 截断AbstractVector到指定的大小, 如果指定size比{@link #size()}大则无变化
     * @param size
     */
    public void truncate(int size) {
        if(size < size()) resize(size);
    }
    
    /**
     * 返回向量大小
     * @return
     */
    public abstract int size();
    
    /**
     * 返回向量第i维的Feature名称
     * @param i
     * @return
     */
    public abstract String getIndexName(int i);
    
    /**
     * 返回向量第i维的值
     * @param i
     * @return
     */
    public abstract double getValue(int i);

    /**
     * 设置向量第i维的值
     * @param i
     * @param value
     */
    public abstract void setValue(int i, double value);
    
    /**
     * 比较this[i].index和that[j].index的大小
     * @param i
     * @param that
     * @param j
     * @return
     */
    protected abstract int compareIndex(int i, AbstractVector that, int j);

    protected void rangeCheck(int i) {
        if (i >= size()) throw new IndexOutOfBoundsException("Order: "+i+", Size: "+size());
    }

    /**
     * 将所有维度的值清0
     */
    public void clear() {
        for(int i = 0; i < size(); i ++) {
            setValue(i, 0);
        }
    }
    
    /**
     * 将AbstractVector按index排序
     */
    protected abstract void sort();
    
    /**
     * 输出为数组
     * @return
     */
    public StringDim [] toArray() {
        int size = size();
        StringDim [] array = new StringDim[size];
        for(int i = 0; i < size; i ++) {
            array[i] = new StringDim(getIndexName(i), getValue(i));
        }
        return array;
    }
    
    /**
     * 调用前需保证参与计算的Vector是按index排序的, 参见{@link #sort()}
     * @param that
     * @return
     */
    public double distance(AbstractVector that) {
        double distance = 0;
        int i = 0;
        int j = 0;
        while(i < this.size() || j < that.size()) {
            if(!(j < that.size())) {
                distance += Math.pow(this.getValue(i), 2);
                i ++;
                continue;
            }
            if(!(i < this.size())) {
                distance += Math.pow(that.getValue(j), 2);
                j ++;
                continue;
            }
            double v1 = this.getValue(i);
            double v2 = that.getValue(j);
            int c = compareIndex(i, that, j);
            if(c == 0) {
                distance += Math.pow(v1 - v2, 2);
                i ++;
                j ++;
            } else if (c < 0) {
                distance += Math.pow(v1, 2);
                i ++;
            } else {
                distance += Math.pow(v2, 2);
                j ++;
            }
        }
        return Math.sqrt(distance);
    }
    
    /**
     * 调用前需保证参与计算的Vector是排序的, 参见{@link #sort()}
     * @param that
     * @return
     */
    public double innerProduct(AbstractVector that) {
        double product = 0;
        int i = 0;
        int j = 0;
        while(i < this.size() && j < that.size()) {
            int c = compareIndex(i, that, j);
            if(c == 0) {
                product += this.getValue(i)*that.getValue(j);
                i ++;
                j ++;
            } else if (c < 0) {
                i ++;
            } else {
                j ++;
            }
        }
        return product;
    }
    
    public double sum() {
        double sum = 0;
        for(int i = 0; i < size(); i ++) {
            sum += getValue(i);
        }
        return sum;
    }
    
    /**
     * 调用前需保证参与计算的Vector是排序的, 参见{@link #sort()}
     * @param that
     * @return
     */
    public double intersect(AbstractVector that) {
        double intersect = 0;
        int i = 0;
        int j = 0;
        while(i < this.size() && j < that.size()) {
            int c = compareIndex(i, that, j);
            if(c == 0) {
                intersect += Math.min(getValue(i), that.getValue(j));
                i ++;
                j ++;
            } else if (c < 0) {
                i ++;
            } else {
                j ++;
            }
        }
        return intersect/(sum() + that.sum() - intersect);
    }

    /**
     * 得到与指定向量共有的维度
     * @param that
     * @return
     */
    public List<StringDim> commonDims(AbstractVector that) {
        List<StringDim> list = new ArrayList<StringDim>();
        int i = 0;
        int j = 0;
        while(i < this.size() && j < that.size()) {
            int c = compareIndex(i, that, j);
            if(c == 0) {
                list.add(new StringDim(getIndexName(i), Math.min(getValue(i), that.getValue(j))));
                i ++;
                j ++;
            } else if (c < 0) {
                i ++;
            } else {
                j ++;
            }
        }
        return list;
    }
    
    /**
     * 计算向量的模
     * @return
     */
    public double modulus() {
        double modulus = 0;
        for(int i = 0; i < size(); i ++) {
            modulus += Math.pow(getValue(i), 2);
        }
        return Math.sqrt(modulus);
    }
    
    @Override
    public AbstractVector clone() {
        try {
            AbstractVector newObj = getClass().newInstance();
            newObj.copyFields(this);
            return newObj;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
