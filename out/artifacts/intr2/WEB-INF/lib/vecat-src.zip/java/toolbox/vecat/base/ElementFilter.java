package toolbox.vecat.base;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;

public class ElementFilter implements IClusterFilter {
    private HashSet<String> set = new HashSet<String>();
    protected boolean filtered = false;
    
    @Override
    public void init(Object param) throws Exception {
        set.clear();
        String fileName = (String) param;
        if(fileName.length() == 0) return;
        BufferedReader reader = new BufferedReader(new FileReader((String) fileName ));
        String line;
        try {
            while((line = reader.readLine()) != null) {
                set.add(line.trim());
            }
        } finally { 
            reader.close();
        }
    }
    
    @Override
    public void reset() {
        filtered = false;
    }

    @Override
    public boolean scan(String element) {
        boolean ret = set.contains(element);
        if(ret) filtered = true;
        return ret;
    }
    
    @Override
    public boolean judge() {
        return filtered;
    }

}
