package toolbox.vecat;

import java.util.Collections;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;
import odis.mapred.ext.IMergeMapper;
import odis.mapred.ext.MapMergeConf;
import odis.mapred.lib.FirstValueReducer;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.comparator.BytesBinaryComparator;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.toolkit.WritableArrayList;
import odis.serialize.toolkit.WritablePair;
import odis.tools.MapReduceHelper;
import toolbox.cluster.Instance;
import toolbox.cluster.Instance.IDPartitioner;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.base.ElementFilter;
import toolbox.vecat.base.IClusterFilter;
import toolbox.vecat.utils.Utils;

/**
 * 整理ClusterFinder的结果数据
 * @author caofx
 *
 */
public class ClusterCollectTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(ClusterCollectTool.class);
   
    public static final String INDEX_PATH = "index";
    public static final String RESULT_PATH = "result";
    public static final String CLUSTER_PATH = "cluster";
    private static final String CFG_MIN_SIZE = "CFG_MIN_SIZE";
    private static final String CFG_INVERSE_INPUT = "CFG_INVERSE_INPUT";
    private static final String CFG_FILTER_CLASS = "CFG_FILTER_CLASS";
    private static final String CFG_FILTER_PARAM = "CFG_FILTER_PARAM";

    private static enum CounterName {
        INVALID_ID_COUNT,
        ELEMENT_COUNT,
        CLUSTER_COUNT,
        DISCARD_COUNT,
        SMALL_COUNT,
        FILTERED_COUNT,
    }
    
    private Path inputPath;
    private Path mapPath = null;
    private Path namePath = null;
    private Path outputPath;
    private int inputPartNum;
    private long minSize;
    private boolean inverse;
    private Class<? extends IClusterFilter> filterClass;
    private String filterParam;
    private int outputPartNum;
    
    @Override
    public String comment() {
        return "Collect cluster data.";
    }
    
    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("n", "name_path", "set name path.").setDefault("");
        options.withOption("m", "map_path", "set map path.").setDefault("");
        options.withOption("o", "output_path", "set output path.");
        options.withOption("s", "min_size", "set min cluster size.").setDefault(1);
        options.withOption("v", "set inverse input mode, take effect only without \"-m\".");
        options.withOption("f", "filter_class", "set filter class").setDefault(ElementFilter.class.getName());
        options.withOption("p", "filter_param", "set input filter param.").setDefault("");
        options.withOption("op", "output_part", "set output part num. 0 means using nWorker.").setDefault(0);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public boolean exec(int nWorker) throws Exception {
        inputPath = context.path(options.getStringOpt("i"));
        if(options.getStringOpt("n").length() > 0) {
            namePath = context.path(options.getStringOpt("n"));
        }
        if(options.getStringOpt("m").length() > 0) {
            mapPath = context.path(options.getStringOpt("m"));
        }
        outputPath = context.path(options.getStringOpt("o"));
        inputPartNum = MapReduceHelper.getContinuousPartCount(fs, inputPath);
        minSize = options.getLongOpt("s");
        inverse = options.isOptSet("v");
        filterClass = (Class<? extends IClusterFilter>) Class.forName(options.getStringOpt("f"));
        filterParam = options.getStringOpt("p");
        outputPartNum = options.getIntOpt("op");
        if(outputPartNum == 0) outputPartNum = nWorker;
        
        if(namePath != null && mapPath != null) {
            LOG.info("Build ID map ...");
            if(!buildIDMap(nWorker)) return false;
        }
        
        LOG.info("Collect clusters ...");
        if(!collect(nWorker)) return false;
        
        LOG.info("Make indexes ...");
        return index(nWorker);
    }
    
    private boolean buildIDMap(int nWorker) throws Exception {
        // MR settings
        if(!fs.exists(namePath)) {
            LOG.severe(namePath + " not exists");
            return false;
        }
        MapReduceJobDef job = context.createMapReduceJob(getToolName() + ".build", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(namePath, null);
        job.setMapper(BuildMapper.class);
        job.setReducer(FirstValueReducer.class);
        job.setMergeKeyValClass(Instance.ID.class, StringWritable.class);
        job.setPartitionerClass(IDPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, mapPath, Instance.ID.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        
        job.setMapNumber(nWorker);
        job.setReduceNumber(inputPartNum);
        
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    private boolean collect(int nWorker) throws Exception {
        LOG.info("Input filter: " + filterClass.getName());
        LOG.info("Input filter param: " + filterParam);

        // MR settings
        MrStarJobDef job = context.createMrStarJob(2, getToolName() + ".collect", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        if(mapPath != null) {
            MapMergeConf mmc = new MapMergeConf();
            mmc.setMergeMapper(CollectMapper.class);
            mmc.setMergeCount(CollectMapper.CIN_NUM);
            mmc.setMergeDir(CollectMapper.CIN_DATA, inputPath, ReuseWalker.class);
            mmc.setMergeDir(CollectMapper.CIN_MAP, mapPath, ReuseWalker.class);
            job.plugin(mmc);
        } else {
            job.setMapper(0, SimpleCollectMapper.class);
            helper.addReadInputDir(0, inputPath, null);
        }

        job.setReducer(0, DedupReducer.class);
        job.setMergeKeyValClass(0, StringWritable.class, StringWritable.class);
        job.setMergeValComparator(0, BytesBinaryComparator.class);
        job.setPartitionerClass(0, SeqFileHashPartitioner.class);
        job.setWalkerClass(0, ReuseWalker.class);
        
        job.setReducer(1, CollectReducer.class);
        job.setMergeKeyValClass(1, StringWritable.class, StringWritable.class);
        job.setPartitionerClass(1, SeqFileHashPartitioner.class);
        job.setWalkerClass(1, ReuseWalker.class);
        helper.addUpdateOutputDir(1, 0, outputPath.cat(RESULT_PATH), StringWritable.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 1, 0, 0);
        helper.addUpdateOutputDir(1, 1, outputPath.cat(CLUSTER_PATH), StringWritable.class, LongWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 1, 1, 0);
        
        job.setMapNumber(inputPartNum);
        job.setMrNumber(1, outputPartNum);
        job.setReduceNumber(outputPartNum);
        job.getConfig().setLong(CFG_MIN_SIZE, minSize);
        job.getConfig().setBoolean(CFG_INVERSE_INPUT, inverse);
        job.getConfig().setProperty(CFG_FILTER_CLASS, filterClass.getName());
        job.getConfig().setProperty(CFG_FILTER_PARAM, filterParam);
       
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }
    
    public boolean index(int nWorker) throws Exception {
        // MR settings
        MrStarJobDef job = context.createMrStarJob(2, getToolName() + ".index", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        MapMergeConf mmc = new MapMergeConf();
        mmc.setMergeMapper(IndexMapper.class);
        mmc.setMergeCount(IndexMapper.CIN_NUM);
        mmc.setMergeDir(IndexMapper.CIN_CLUSTER, outputPath.cat(CLUSTER_PATH), ReuseWalker.class);
        mmc.setMergeDir(IndexMapper.CIN_RESULT, helper.getUpdateInput(outputPath.cat(RESULT_PATH)), ReuseWalker.class);
        job.plugin(mmc);
        
        job.setReducer(0, IndexReducer.class);
        job.setMergeKeyValClass(0, StringWritable.class, StrLongPair.class);
        job.setPartitionerClass(0, SeqFileHashPartitioner.class);
        job.setWalkerClass(0, ReuseWalker.class);
        helper.addUpdateOutputDir(0, 0, outputPath.cat(INDEX_PATH), StringWritable.class, StrLongPairList.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0, 0);
        
        job.setReducer(1, IdentityReducer.class);
        job.setMergeKeyValClass(1, StringWritable.class, StringWritable.class);
        job.setPartitionerClass(1, SeqFileHashPartitioner.class);
        job.setWalkerClass(1, ReuseWalker.class);
        helper.addUpdateOutputDir(1, 0, outputPath.cat(RESULT_PATH), StringWritable.class, StringWritable.class, null);
        GenericFileOutputFormat.setCompress(job, 1, 0, 0);
        
        job.setMapNumber(MapReduceHelper.getContinuousPartCount(context.getFileSystem(), outputPath.cat(CLUSTER_PATH)));
        job.setMrNumber(1, outputPartNum);
        job.setReduceNumber(outputPartNum);
        
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class StrLongPair extends WritablePair<StringWritable, LongWritable> implements IWritableComparable {

        public StrLongPair() {
            super();
        }

        public StrLongPair(StrLongPair that) {
            super();
            copyFields(that);
        }

        @Override
        protected StringWritable newFirstInstance() {
            return new StringWritable();
        }

        @Override
        protected LongWritable newSecondInstance() {
            return new LongWritable();
        }

        @Override
        public int compareTo(IWritable o) {
            StrLongPair that = (StrLongPair) o;
            return this.getFirst().compareTo(that.getFirst());
        }
        
        public void setFirst(String f) {
            first.set(f);
        }
        
        public void setSecond(long s) {
            second.set(s);
        }
        
        @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
        
    }
    
    @SuppressWarnings("serial")
    public static class StrLongPairList extends WritableArrayList<StrLongPair> {

        @Override
        protected StrLongPair newElementInstance() {
            return new StrLongPair();
        }
        
    }
    
    public static class BuildMapper extends AbstractMapper<IWritable, IWritable> {
        private StringWritable name = new StringWritable();
        private Instance.ID id = new Instance.ID();
        
        @Override
        public void map(IWritable key, IWritable value, ICollector collector) {
            String s = key.toString();
            name.set(s);
            Utils.setInstanceID(id, s);
            collector.collect(id, name);
        }
    }
    
    public static class SimpleCollectMapper extends AbstractMapper<IWritable, IWritable> {
        private StringWritable clusterID = new StringWritable();
        private StringWritable name = new StringWritable();
        private boolean inverse;

        @Override
        public void configure(JobDef job, TaskRunnable task) {
            inverse = job.getConfig().getBoolean(CFG_INVERSE_INPUT);
        }
        
        @Override
        public void map(IWritable key, IWritable value, ICollector collector) {
            if(inverse) {
                name.set(value.toString());
                clusterID.set(key.toString());
            } else {
                name.set(key.toString());
                clusterID.set(value.toString());
            }
            collector.collect(name, clusterID);
        }
        
    }
    
    public static class CollectMapper implements IMergeMapper<IWritable, IWritable> {
        private static final int CIN_DATA = 0;
        private static final int CIN_MAP = 1;
        private static final int CIN_NUM = 2;
        private StringWritable clusterID = new StringWritable();
        private StringWritable name = new StringWritable();
        private Counter invalidIDCounter;
        
        @Override
        public void configure(JobDef conf, TaskRunnable task) {
            invalidIDCounter = task.getCounter(CounterName.INVALID_ID_COUNT.name());
        }
        
        @Override
        public void map(IWritable key,
                IWritablePairWalker<IWritable, IWritable>[] mergeValues,
                ICollector collector) {
            if(mergeValues[CIN_DATA] == null) {
                return;
            }
            if(mergeValues[CIN_MAP] == null || !mergeValues[CIN_MAP].moreValue()) {
                // 此ID在表中无记录
                invalidIDCounter.inc();
                return;
            }
            
            name = (StringWritable) mergeValues[CIN_MAP].getValue();
            while(mergeValues[CIN_DATA].moreValue()) {
                clusterID.set(mergeValues[CIN_DATA].getValue().toString());
                collector.collect(name, clusterID);
            }
        }
        
        @Override
        public void mapBegin() {
        }
        
        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }
    
    /**
     * 输入: elementID => clusterID
     * 输出: 去重后的clusterID => elementID
     * @author caofx
     *
     */
    public static class DedupReducer extends AbstractReducer<StringWritable, StringWritable> {

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringWritable> values,
                ICollector collector) {
            // 对value进行了排序以滤重
            String last = null;
            while(values.moreValue()) {
                StringWritable current = values.getValue();
                if(current.get().equals(last)) continue;
                last = current.get();
                collector.collect(current, key);
            }            
        }
        
    }
    
    /**
     * 输入: clusterID => elementID
     * 输出0: clusterID => 未被过滤的elementID
     * 输出1: 过滤后的clusterID => clusterID
     * @author caofx
     *
     */
    public static class CollectReducer extends AbstractReducer<StringWritable, StringWritable> {
        private LongWritable clusterSize = new LongWritable();
        private long minSize;
        private StringWritable[] pool;
        private IClusterFilter filter;
        private Counter filteredCounter;
        private Counter smallCounter;

        @Override
        public void configure(JobDef job, TaskRunnable task) {
            try {
                filter = (IClusterFilter) Class.forName(job.getConfig().getString(CFG_FILTER_CLASS)).newInstance();
                filter.init(job.getConfig().getString(CFG_FILTER_PARAM));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            minSize = job.getConfig().getLong(CFG_MIN_SIZE);
            pool = new StringWritable[(int) (minSize-1)];
            for(int i = 0; i < pool.length; i ++) {
                pool[i] = new StringWritable();
            }
            filteredCounter = task.getCounter(CounterName.FILTERED_COUNT.name());
            smallCounter = task.getCounter(CounterName.SMALL_COUNT.name());
        }
        
        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StringWritable> values,
                ICollector collector) {
            long count = 0;
            filter.reset();
            while(values.moreValue()) {
                StringWritable current = values.getValue();
                count ++; 
                filter.scan(current.get());
                if(count < minSize) {
                    pool[(int) (count-1)].copyFields(current);
                    continue;
                }
                if(count == minSize) {
                    for(StringWritable e: pool) {
                        collector.collectToChannel(0, key, e);
                    }
                }
                collector.collectToChannel(0, key, current);
            }
            // 被filter的cluster在result库中仍然存在, 在下一步中会去除
            if(count < minSize) {
                smallCounter.inc();
                return;
            }
            if(filter.judge()) {
                filteredCounter.inc();
                return;
            }
            clusterSize.set(count);
            collector.collectToChannel(1, key, clusterSize);
        }
        
    }
    
    public static class IndexMapper implements IMergeMapper<StringWritable, IWritable> {
        private static final int CIN_CLUSTER = 0;
        private static final int CIN_RESULT = 1;
        private static final int CIN_NUM = 2;
        private StrLongPair cluster = new StrLongPair();
        private Counter clusterCounter;
        private Counter discardCounter;

        @Override
        public void configure(JobDef conf, TaskRunnable task) {
            clusterCounter = task.getCounter(CounterName.CLUSTER_COUNT.name());
            discardCounter = task.getCounter(CounterName.DISCARD_COUNT.name());
        }

        @Override
        public void map(StringWritable key,
                IWritablePairWalker<StringWritable, IWritable>[] mergeValues,
                ICollector collector) {
            if(mergeValues[CIN_CLUSTER] == null || !mergeValues[CIN_CLUSTER].moreValue()) {
                discardCounter.inc();
                return;
            }
            assert(mergeValues[CIN_RESULT] != null);
            LongWritable clusterSize = (LongWritable) mergeValues[CIN_CLUSTER].getValue();
            clusterCounter.inc();
            cluster.setFirst(key.get());
            cluster.setSecond(clusterSize.get());
            while(mergeValues[CIN_RESULT].moreValue()) {
                StringWritable name = (StringWritable) mergeValues[CIN_RESULT].getValue();
                collector.collect(name, cluster);
            }
            
        }

        @Override
        public void mapBegin() {
        }

        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }

    public static class IndexReducer extends AbstractReducer<StringWritable, StrLongPair> {
        private StrLongPairList clusters = new StrLongPairList();
        private Counter elementCounter;
        
        @Override
        public void configure(JobDef conf, TaskRunnable task) {
            elementCounter = task.getCounter(CounterName.ELEMENT_COUNT.name());
        }

        @Override
        public void reduce(StringWritable key,
                IWritablePairWalker<StringWritable, StrLongPair> values,
                ICollector collector) {
            clusters.clear();
            while(values.moreValue()) {
                StrLongPair cluster = values.getValue();
                collector.collect(cluster.getFirst(), key);
                clusters.add(new StrLongPair(cluster));
            }
            Collections.sort(clusters);
            
            elementCounter.inc();
            collector.collectToChannel(0, key, clusters);
        }
        
    }

}
