package toolbox.vecat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Map.Entry;
import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.CounterMap.Counter;
import odis.file.SequenceFile.Reader;
import odis.file.SequenceFile.Writer;
import odis.io.DataInputBuffer;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.data.AbstractIntegerVector;
import toolbox.vecat.data.AbstractVector;
import toolbox.vecat.data.Cluster;
import toolbox.vecat.data.SparseVector;
import toolbox.vecat.data.StringDim;
import toolbox.vecat.data.Vector;
import toolbox.vecat.utils.IntegerSampler;
import toolbox.vecat.utils.Utils;
import toolbox.vecat.utils.Utils.ReadOperator;
import toolbox.vecat.utils.Utils.WriteOperator;

public class KClusterTool extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(KClusterTool.class);
    private static final String LAST_CLUSTERS_PATH = "last_clusters";
    private static final String CLUSTERS_PATH = "clusters";
    private static final String INIT_CLUSTERS_PATH = "init_clusters";
    private static final String UPDATE_CLUSTERS_PATH = "update_clusters";
    private static final String ERROR_PATH = "errors";
    private static final String CLUSTER_SIMILARITES_PATH = "similarities";
    private static final String RESULTS_PATH = "results";
    private static final String INDEX_PATH = "index";

    private static enum Status {
        CLUSTER,
        OUTPUT_CLUSTER
    }
    
    private static enum CounterName {
        ELEMENT_COUNT,
        STRAY_ELEMENT_COUNT
    }

    private static final String CFG_CLUSTER_NUM = KClusterTool.class.getName() + "CFG_CLUSTER_NUM";
    private static final String CFG_MIN_WEIGHT = KClusterTool.class.getName() + "CFG_MIN_WEIGHT";
    private static final String CFG_MAX_CLUSTER_PER_ELEMENT = KClusterTool.class.getName() + "CFG_MAX_CLUSTER_PER_ELEMENT";
    private static final String CFG_FS = KClusterTool.class.getName() + "CFG_FS";
    private static final String CFG_WORK_PATH = KClusterTool.class.getName() + "CFG_WORK_PATH";
    private static final String CFG_STATUS = KClusterTool.class.getName() + "CFG_STATUS";;

    private Path inputPath;
    private Path outputPath;
    private int clusterNum;
    private boolean needOutput;
    private double minWeight;
    private int dimSize;
    private int maxCluterPerElement;

    private long elementCount;
    private long strayElementCount;

    @Override
    public String comment() {
        return "K-Means Cluster tool";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("n", "cluster_num", "set cluster num.");
        options.withOption("r", "whether output results.");
        options.withOption("w", "min_weight", "set min weight threshold.");
        options.withOption("d", "dim_size", "set dimsize.");
        options.withOption("m", "max_cluster_per_element", "set max cluster number per element");
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
    }

    @Override
    public boolean exec(int nWorker) throws Exception {
        // 环境设置, 初始化
        inputPath = context.path(options.getStringOpt("i"));
        outputPath = context.path(options.getStringOpt("o"));
        clusterNum = options.getIntOpt("n");
        needOutput = options.isOptSet("r");
        minWeight = options.getDoubleOpt("w");
        dimSize = options.getIntOpt("d");
        maxCluterPerElement = options.getIntOpt("m");

        LOG.info("inputPath = " + inputPath.getAbsolutePath());
        if(!context.getFileSystem().exists(outputPath)) {
            fs.mkdirs(outputPath);
        }
        fs.delete(outputPath.cat(UPDATE_CLUSTERS_PATH));

        /// 首次迭代, 构造初始Cluster
        if(!context.getFileSystem().exists(outputPath.cat(CLUSTERS_PATH))) {
            LOG.info("Generate initial clusters ...");
            generateInitClusters();
        }

        boolean ret;
        if(needOutput) {
            LOG.info("Do clustering and output results ...");
        } else {
            LOG.info("Do clustering ...");
        }
        
        /// 迭代
        ret = cluster(nWorker, needOutput);
        if(!ret) return ret;
        
        // 输出结果
        if(needOutput) {
            ret = output(nWorker);
        }
        
        if(ret) {
            // 更新质心及误差数据
            LOG.info("Merge and update parameters ...");
            int nonemptyCount = mergeUpdateClusters();
            fs.delete(outputPath.cat(ERROR_PATH));
            double[] errors = getErrors();
            double[] cohesions = getCohesions();
            
            // 打印结果参数
            StringBuilder buffer = new StringBuilder("Result parameters: ");
            buffer.append("\nNonempty Cluster Count: ").append(nonemptyCount);
            buffer.append("\nElement Count: ").append(elementCount);
            buffer.append("\nStray Element Count: ").append(strayElementCount);
            buffer.append("\nMean Cohesion: ").append(cohesions == null? 0: cohesions[clusterNum]);
            buffer.append("\nMean Centroid Error(versus last cluster): ").append(errors == null? Double.POSITIVE_INFINITY: errors[clusterNum]);
            LOG.info(buffer.toString());
        }
        return ret;
    }

    private boolean cluster(int nWorker, boolean needOutput) throws Exception {
        // MR settings
        MapOnlyJobDef job = context.createMapOnlyJob(getToolName() + ".cluster", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(inputPath, null);
        job.setMapper(ClusterMapper.class);
        job.setMapNumber(nWorker);
        helper.addUpdateOutputDir(0, outputPath.cat(UPDATE_CLUSTERS_PATH), IntWritable.class, Cluster.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        if(needOutput) {
            helper.addUpdateOutputDir(1, outputPath.cat(INDEX_PATH), StringWritable.class, SparseVector.class, null);
            GenericFileOutputFormat.setCompress(job, 1, 0);
        }
        
        // 自定义job设置
        job.setCheckMapProgress(false);
        job.getConfig().setInt(CFG_CLUSTER_NUM, clusterNum);
        job.getConfig().setDouble(CFG_MIN_WEIGHT, minWeight);
        job.getConfig().setInt(CFG_MAX_CLUSTER_PER_ELEMENT, maxCluterPerElement);
        if(needOutput) {
        	job.getConfig().setProperty(CFG_STATUS, Status.OUTPUT_CLUSTER.name());
        } else {
            job.getConfig().setProperty(CFG_STATUS, Status.CLUSTER.name());
        }
        job.getConfig().setProperty(CFG_FS, context.getFileSystem().getName());
        job.getConfig().setProperty(CFG_WORK_PATH, outputPath.getAbsolutePath());

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        elementCount = result.getCounters()[0].get(CounterName.ELEMENT_COUNT.name()).get();
        strayElementCount = result.getCounters()[0].get(CounterName.STRAY_ELEMENT_COUNT.name()).get();
        return true;
    }


    private boolean output(int nWorker) throws Exception {
        // MR settings
        MapReduceJobDef job = context.createMapReduceJob(getToolName() + ".output", nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(outputPath.cat(INDEX_PATH), null);
        job.setMapper(ResultMapper.class);
        job.setReducer(IdentityReducer.class);
        job.setMergeKeyValClass(IntWritable.class, StringDim.class);
        job.setMergeValComparator(WeightComparator.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setWalkerClass(ReuseWalker.class);
        helper.addUpdateOutputDir(0, outputPath.cat(RESULTS_PATH), IntWritable.class, StringDim.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);
        job.setMapNumber(nWorker);
        job.setReduceNumber(clusterNum);

        // 自定义job设置
        job.setCheckMapProgress(false);
        job.setCheckReduceProgress(false);

        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class WeightComparator extends BinaryComparator {
        private StringDim d1 = new StringDim();
        private StringDim d2 = new StringDim();
        private DataInputBuffer buffer = new DataInputBuffer();

        @Override
        public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
            try {
                buffer.reset(b1, s1, l1);
                d1.readFields(buffer);
                buffer.reset(b2, s2, l2);
                d2.readFields(buffer);
            } catch (IOException e) {
                throw new RuntimeException();
            }
            return Double.compare(d2.getValue(), d1.getValue());
        }
        
    }
    
    /**
     * 用于在cluster过程中记录cluster的临时状态
     * @author caofx
     *
     */
    private static class ClusterUnit implements Comparable<ClusterUnit> {
        Cluster cluster; // 当前Cluster
        Vector centroidSum; // 记录所属元素对该cluster质心的贡献量
        long updateSize; // 记录所属元素个数
        double cohesionSum; // 记录所属元素对该cluster凝聚度的贡献量
        double ratioSum; // 记录所属元素到该cluster的分配权重之和
        double weight; // 临时变量, 记录当前element与该cluster的相似度

        public ClusterUnit(Cluster cluster) {
            this.cluster = cluster;
            centroidSum = new Vector(cluster.getCentroid().size());
            updateSize = 0;
            cohesionSum = 0;
            ratioSum = 0;
            weight = 0;
        }

        /**
         * 累计元素对cluster质心及cohesion的更新量
         * @param vector
         * @param d 
         */
        public void update(AbstractIntegerVector vector, double ratio) {
            assert(ratio > 0 && ratio <= 1);
            double modulus = vector.modulus();
            for(int j = 0; j < vector.size(); j ++) {
                int i = vector.getIndex(j);
                double v = vector.getValue(j);
                // 可以证明, 对基于余弦相似度的加权cohesion, 使其最大化的质心满足:
                // 质心与该cluster中归一化的元素加权和成比例
                centroidSum.setValue(i, centroidSum.getValue(i) + v * ratio/modulus);
            }
            cohesionSum += weight * ratio;
            ratioSum += ratio;
            updateSize ++;
        }

        @Override
        public int compareTo(ClusterUnit o) {
            return Double.compare(weight, o.weight);
        }


    }

    /**
     * 生成一组初始Cluster, 此centroid并非质心, 而是初始Cluster的筛选向量(通过 {@link ClusterMapper#weight(AbstractVector, Cluster)}>0判别)
     * @return
     * @throws IOException 
     */
    private void generateInitClusters() throws IOException {
        assert(dimSize > clusterNum);
        IntegerSampler sampler = new IntegerSampler(0, dimSize);
        Utils.writeToSeqFile(fs, outputPath.cat(INIT_CLUSTERS_PATH), sampler, IntWritable.class, Cluster.class, true, new WriteOperator<IntegerSampler>() {
            @Override
            public void operate(Writer writer, IntegerSampler data) throws IOException {
                IntWritable key = new IntWritable();
                Cluster value = new Cluster();
                int n = dimSize/clusterNum;
                for(int i = 0; i < clusterNum; i ++) {
                    // 构造筛选向量
                    Vector centroid = new Vector(dimSize);
                    for(int j = 0; j < n; j ++) {
                        centroid.setValue(data.sample(), 1);
                    }

                    // 存储
                    key.set(i);
                    value.set(i, 1, 0, centroid); // 设置size > 0以避免在cluster阶段该cluster被忽略
                    writer.write(key, value);
                }
            }
        });
    }

    /**
     * 合并更新Cluster数据并备份上次Cluster数据, 返回非空cluster数
     * @return
     * @throws IOException
     */
    private int mergeUpdateClusters() throws IOException {
        IFileSystem fs = context.getFileSystem();
        Path lastPath = outputPath.cat(LAST_CLUSTERS_PATH);
        Path currentPath = outputPath.cat(CLUSTERS_PATH);
        Path updatePath = outputPath.cat(UPDATE_CLUSTERS_PATH);
        
        // 备份上次Cluster划分
        if(fs.exists(currentPath)) {
            fs.delete(lastPath);
            fs.rename(currentPath, lastPath);
        }

        // 合并更新Cluster
        Map<Integer, Cluster> updateClusters = loadClusters(fs, updatePath, clusterNum);
        Utils.writeToSeqFile(fs, currentPath, updateClusters, IntWritable.class, Cluster.class, true, new WriteOperator<Map<Integer, Cluster>>() {
            @Override
            public void operate(Writer writer, Map<Integer, Cluster> data) throws IOException {
                IntWritable key = new IntWritable();
                for(Cluster cluster: data.values()) {
                    key.set(cluster.getIndex());
                    writer.write(key, cluster);
                }
            }
        });

        // 计算并返回合并后的cohesion
        int nonemptyCount = 0;
        for(Cluster cluster: updateClusters.values()) {
            if(cluster.size() > 0) {
                nonemptyCount ++;
            }
        }
        
        // 计算各个cluster之间的相似度
        Cluster[] clusters = new Cluster[updateClusters.size()];
        computeClusterSimilarity(updateClusters.values().toArray(clusters));
        return nonemptyCount;
    }

    private static class ClusterSimilarity {
        private final int index;
        private final int size;
        private double sum = 0;
        private double max = 0;
        private double min = Double.MAX_VALUE;
        private int maxIndex;
        private int minIndex;
        
        public ClusterSimilarity(int index, int size) {
            this.index = index;
            this.size = size;
        }

        public void update(int i, double sim) {
            sum += sim;
            if(sim > max) {
                max = sim;
                maxIndex = i;
            }
            if(sim < min) {
                min = sim;
                minIndex = i;
            }
        }
        
        @Override
        public String toString() {
            StringBuilder buffer = new StringBuilder().append(index).append(", ");
            buffer.append(max).append(": ").append(maxIndex).append(", ");
            buffer.append(min).append(": ").append(minIndex).append(", ");
            buffer.append(sum/size);
            return buffer.toString();
        }
    }
    
    /**
     * 统计各个Cluster之间的相似度信息
     * @param clusters
     * @throws IOException
     */
    private void computeClusterSimilarity(Cluster [] clusters) throws IOException {
        int size = clusters.length;
        ClusterSimilarity [] clusterSims = new ClusterSimilarity[size];
        for(int i = 0; i < size; i ++) {
            clusterSims[i] = new ClusterSimilarity(clusters[i].getIndex(), size);
        }
        
        for(int i = 0; i < size; i ++) {
            Vector c1 = clusters[i].getCentroid();
            for(int j = i+1; j < size; j ++) {
                Vector c2 = clusters[j].getCentroid();
                double sim = c1.innerProduct(c2)/(c1.modulus()*c2.modulus());
                clusterSims[i].update(clusters[j].getIndex(), sim);
                clusterSims[j].update(clusters[i].getIndex(), sim);
            }
        }
        
        Utils.writeToSeqFile(fs, outputPath.cat(CLUSTER_SIMILARITES_PATH), clusterSims, IntWritable.class, StringWritable.class, true, new WriteOperator<ClusterSimilarity []>() {
            @Override
            public void operate(Writer writer, ClusterSimilarity [] data) throws IOException {
                IntWritable key = new IntWritable();
                StringWritable value = new StringWritable();
                for(ClusterSimilarity sim: data) {
                    key.set(sim.index);
                    value.set(sim.toString());
                    writer.write(key, value);
                }
            }
        });
    }
    
    /**
     * 读取(且合并)Cluster数据
     * @param fs
     * @param path
     * @param clusterNum
     * @return
     * @throws IOException
     */
    private static Map<Integer, Cluster> loadClusters(IFileSystem fs, Path path, int clusterNum) throws IOException {
        // 建立读取文件列表
        List<Path> inputs = new ArrayList<Path>();
        if (fs.isFile(path)) {
            inputs.add(path);
        } else {
            for (FileInfo info : fs.listFiles(path)) {
                inputs.add(info.getPath());
            }
        }

        // 读取并合并数据
        Map<Integer, Cluster> map = new HashMap<Integer, Cluster>(clusterNum);
        for (Path input : inputs) {
            Utils.readFromSeqFile(fs, input, map, new ReadOperator<Map<Integer, Cluster>> () {
                @Override
                public void operate(Reader reader, Map<Integer, Cluster> data) throws IOException {
                    IntWritable key = new IntWritable();
                    Cluster value = new Cluster();
                    while (reader.next(key, value)) {
                        assert(key.get() == value.getIndex());
                        Cluster current = data.get(key.get());
                        if(current == null) {
                            current = new Cluster();
                            current.copyFields(value);
                            data.put(key.get(), current);
                            continue;
                        }
                        assert(current.getIndex() == value.getIndex());
                        assert(current.merge(value));
                    } 
                }
            });
        }
        assert(map.size() == clusterNum);
        return map;
    }

    /**
     * 计算前后两次迭代的质心变化误差, 最后一个元素为总平均error
     * 如果没有前两次迭代的结果则返回 null
     * @return
     * @throws IOException
     */
    private double [] computeError() throws IOException {
        IFileSystem fs = context.getFileSystem();
        if(!fs.exists(outputPath.cat(CLUSTERS_PATH)) || !fs.exists(outputPath.cat(LAST_CLUSTERS_PATH))) {
            return null;
        }

        double [] errors = new double[clusterNum+1];
        Map<Integer, Cluster> oldClusters = loadClusters(fs, outputPath.cat(LAST_CLUSTERS_PATH), clusterNum);
        Map<Integer, Cluster> newClusters = loadClusters(fs, outputPath.cat(CLUSTERS_PATH), clusterNum);
        for(Entry<Integer, Cluster> entry: oldClusters.entrySet()) {
            int index = entry.getValue().getIndex();
            Vector oldCentroid = entry.getValue().getCentroid();
            Vector newCentroid = newClusters.get(index).getCentroid();
            errors[index] = oldCentroid.distance(newCentroid);
            errors[clusterNum] += errors[index];
        }
        errors[clusterNum] /= clusterNum;
        return errors;
    }

    /**
     * 返回cohesion数据, 如果没有数据返回null
     * @return
     * @throws IOException 
     */
    private double [] getCohesions() throws IOException {
        // 计算并返回合并后的cohesion
        IFileSystem fs = context.getFileSystem();
        Path path = outputPath.cat(CLUSTERS_PATH);
        if(!fs.exists(path)) return null;
        
        double [] cohesions = new double[clusterNum+1];
        Map<Integer, Cluster> clusters = loadClusters(fs, path, clusterNum);
        long size = 0;
        for(Cluster cluster: clusters.values()) {
            int index = cluster.getIndex();
            if(cluster.size() > 0) {
                cohesions[index] = cluster.getCohesion();
                cohesions[clusterNum] += cluster.getCohesion() * cluster.size();
                size += cluster.size();
            }
        }
        cohesions[clusterNum] /= size;
        return cohesions;
    }
    
    /**
     * 读取前两次迭代的质心变化误差, 如果没有前两次迭代的结果则返回 null
     * @return
     * @throws IOException
     */
    private double [] getErrors() throws IOException {
        double [] errors;
        IFileSystem fs = context.getFileSystem();
        Path errorPath = outputPath.cat(ERROR_PATH);

        // 不存在error文件, 重新计算 
        if(!fs.exists(errorPath)) {
            errors = computeError();
            if(errors == null) return null;
            Utils.writeToSeqFile(fs, errorPath, errors, IntWritable.class, DoubleWritable.class, true, new WriteOperator<double []>() {
                @Override
                public void operate(Writer writer, double [] data) throws IOException {
                    IntWritable key = new IntWritable();
                    DoubleWritable value = new DoubleWritable();
                    for(int i = 0; i < clusterNum+1; i ++) {
                        key.set(i);
                        value.set(data[i]);
                        writer.write(key, value);
                    }
                }
            });

            return errors;
        }

        // 存在error文件, 直接读取
        errors = new double[clusterNum+1];
        Utils.readFromSeqFile(fs, errorPath, errors, new ReadOperator<double []>() {
            @Override
            public void operate(Reader reader, double[] data) throws IOException {
                IntWritable key = new IntWritable();
                DoubleWritable value = new DoubleWritable();
                for(int i = 0; i < clusterNum+1; i ++) {
                    reader.next(key, value);
                    data[key.get()] = value.get();
                }
            }
        });
        
        return errors;
    }

    public static class ClusterMapper extends AbstractMapper<StringWritable, SparseVector> {
        private int clusterNum;
        private double minWeight;
        private int maxCluterPerElement;
        private Status status;
        private IFileSystem fs;
        private Path workPath;
        private boolean firstCluster;
        private ClusterUnit [] clusterUnits;
        private PriorityQueue<ClusterUnit> queue;
        private ClusterUnit [] tempUnits; 
        private IntWritable clusterIndex = new IntWritable();
        private SparseVector clusterList;
        private Counter elementCounter;
        private Counter strayElementCounter;

        public void configure(JobDef job, TaskRunnable task) {
            clusterNum = job.getConfig().getInt(CFG_CLUSTER_NUM);
            minWeight = job.getConfig().getDouble(CFG_MIN_WEIGHT);
            maxCluterPerElement = job.getConfig().getInt(CFG_MAX_CLUSTER_PER_ELEMENT);
            status = Status.valueOf(job.getConfig().getString(CFG_STATUS));
            workPath = new Path(job.getConfig().getString(CFG_WORK_PATH));
            try {
                fs = FileSystem.getNamed(job.getConfig().getString(CFG_FS));
                firstCluster = !fs.exists(workPath.cat(CLUSTERS_PATH));
                Path clustersPath;
                if(firstCluster) {
                    clustersPath = workPath.cat(INIT_CLUSTERS_PATH);
                } else {
                    clustersPath = workPath.cat(CLUSTERS_PATH);
                }
                Map<Integer, Cluster> clusters = loadClusters(fs, clustersPath, clusterNum);
                assert(clusters.size() == clusterNum);
                clusterUnits = new ClusterUnit [clusterNum];
                for(Cluster cluster: clusters.values()) {
                    clusterUnits[cluster.getIndex()] = new ClusterUnit(cluster);
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            queue = new PriorityQueue<ClusterUnit>(maxCluterPerElement);
            tempUnits = new ClusterUnit[maxCluterPerElement];
            clusterList = new SparseVector(maxCluterPerElement);
            elementCounter = task.getCounter(CounterName.ELEMENT_COUNT.name());
            strayElementCounter = task.getCounter(CounterName.STRAY_ELEMENT_COUNT.name());
        }

        /**
         * 计算vector对于cluster的权重(相关度)
         * @param vector
         * @param cluster
         * @return
         */
        public static double weight(AbstractVector vector, Cluster cluster) {
            return vector.innerProduct(cluster.getCentroid())/(vector.modulus()*cluster.getCentroid().modulus());
        }

        public void cluster(SparseVector vector, Status status, StringWritable key, ICollector collector) {
            // 计算当前元素与所有Cluster的距离, 并通过优先级队列记录最大的maxCluterPerElement个
            queue.clear();
            for(int c = 0; c < clusterNum; c ++) {
                ClusterUnit clusterUnit = clusterUnits[c];
                if(clusterUnit.cluster.size() == 0) continue; // 对空cluster不做处理
                clusterUnit.weight = weight(vector, clusterUnit.cluster);
                assert(clusterUnit.weight >= 0 && clusterUnit.weight <= 1);
                if(queue.size() < maxCluterPerElement) {
                    queue.add(clusterUnit);
                } else if(queue.peek().compareTo(clusterUnit) < 0) {
                    queue.poll();
                    queue.add(clusterUnit);
                }
            }

            // 选取当前元素的归属cluster并计算分配比重(即根据weight估计分配到每个cluster的概率, 采用: weight[c]/sum(weight[]))
            int count = 0;
            double weightSum = 0;
            while(queue.size() > 0) {
                ClusterUnit clusterUnit = queue.poll();
                if(clusterUnit.weight > minWeight || (firstCluster && clusterUnit.weight > 0)) {
                    tempUnits[count ++] = clusterUnit;
                    weightSum += clusterUnit.weight;
                }
            }
            
            // 计数
            elementCounter.inc();
            if(count == 0) {
                strayElementCounter.inc();
                return;
            }
            
            // 根据当前元素的归属累计对各个Cluster的质心的更新量
            clusterList.resize(count);
            for(int c = 0; c < count; c ++) {
                ClusterUnit clusterUnit = tempUnits[c];
                clusterUnit.update(vector, clusterUnit.weight/weightSum);
                if(status == Status.OUTPUT_CLUSTER) {
                    clusterList.setIndex(c, clusterUnit.cluster.getIndex());
                    clusterList.setValue(c, clusterUnit.weight);
                }
            }
            if(status == Status.OUTPUT_CLUSTER) {
                collector.collectToChannel(1, key, clusterList);
            }
        }

        @Override
        public void map(StringWritable key, SparseVector value, ICollector collector) {
            cluster(value, status, key, collector);
        }

        public void mapEnd(ICollector collector) {
            /// 将各个Cluster的质心的更新量输出
            // 将质心更新量和cohesion归一化
            for(ClusterUnit clusterUnit: clusterUnits) {
                if(clusterUnit.updateSize == 0) {
                    // 空cluster
                    clusterUnit.cluster.set(clusterUnit.cluster.getIndex(),
                            0,
                            0,
                            null); // 质心赋予空向量.
                } else {
                    // 正常cluster
                    Vector updateCentroid = clusterUnit.cluster.getCentroid();
                    for(int i = 0; i < updateCentroid.size(); i ++) {
                        updateCentroid.setValue(i, clusterUnit.centroidSum.getValue(i)/clusterUnit.ratioSum);
                    }
                    clusterUnit.cluster.set(clusterUnit.cluster.getIndex(),
                            clusterUnit.updateSize,
                            clusterUnit.cohesionSum/clusterUnit.ratioSum,
                            updateCentroid);
                }
            }

            // 输出
            for(ClusterUnit clusterUnit: clusterUnits) {
                clusterIndex.set(clusterUnit.cluster.getIndex());
                collector.collectToChannel(0, clusterIndex, clusterUnit.cluster);
            }
        }
    }

    public static class ResultMapper extends AbstractMapper<StringWritable, SparseVector> {
        private IntWritable clusterIndex = new IntWritable();
        private StringDim elementInfo = new StringDim();

		@Override
		public void map(StringWritable key, SparseVector value,	ICollector collector) {
			elementInfo.setIndex(key.toString());
			for(int i = 0; i < value.size(); i ++) {
				clusterIndex.set(value.getIndex(i));
				elementInfo.setValue(value.getValue(i));
				collector.collect(clusterIndex, elementInfo);
			}
		}
    	
    }

}
