package toolbox.vecat.utils;

import java.util.logging.Logger;

import odis.app.job.AbstractCoWorkToolWithArg;
import odis.cowork.JobResult;
import odis.io.Path;
import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.GenericFileOutputFormat;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.tools.MapReduceHelper;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.Options;
import toolbox.vecat.data.BitArray;
import toolbox.vecat.data.Vector;

public class BitsSigConverter extends AbstractCoWorkToolWithArg {
    public static final Logger LOG = LogFormatter.getLogger(BitsSigConverter.class);

    @Override
    public String comment() {
        return "Convert cos signiture into bit array";
    }

    @Override
    protected void prepareOptions(Options options) {
        options.withOption("i", "input_path", "set input path.");
        options.withOption("o", "output_path", "set output path.");
    }
    
    @Override
    public boolean exec(int nWorker) throws Exception {
        Path inputPath = context.path(options.getStringOpt("i"));
        Path outputPath = context.path(options.getStringOpt("o"));
        
        // MR settings
        MapOnlyJobDef job = context.createMapOnlyJob(getToolName(), nWorker);
        MapReduceHelper helper = new MapReduceHelper(context, job);
        helper.addReadInputDir(inputPath, null);
        job.setMapper(Mapper.class);
        job.setMapNumber(MapReduceHelper.getContinuousPartCount(fs, inputPath));
        helper.addUpdateOutputDir(0, outputPath, StringWritable.class, BitArray.class, null);
        GenericFileOutputFormat.setCompress(job, 0, 0);

        // 自定义job设置
        job.setPerUnitSplit(true);
        
        // Run job
        JobResult result = helper.runJob(context.getCoWork());
        if (!result.isSuccess()) return false;
        helper.printMessages(out, result.getMsg());
        helper.printCounters(out, result.getCounters());
        return true;
    }

    public static class Mapper extends AbstractMapper<IWritable, Vector> {
        private BitArray bitArray = new BitArray();

        @Override
        public void map(IWritable key, Vector value, ICollector collector) {
            value.toBitArray(bitArray);
            collector.collect(key, bitArray);
        }
        
    }
}
