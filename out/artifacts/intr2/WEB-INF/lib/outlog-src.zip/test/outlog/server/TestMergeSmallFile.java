/**
 * @(#)TestMergeSmallFile.java, 2013-4-15. Copyright 2013 Yodao, Inc. All rights
 *                              reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                              subject to license terms.
 */
package outlog.server;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Test;

/**
 * @author jasonliu
 */
public class TestMergeSmallFile {

    @Test
    public void testIsSameTimeFile() {
        MergeSmallFile smallFile = new MergeSmallFile();

        boolean result = smallFile.IsSameTimeFile("name.2012121203",
                "name.2012121203", -1);
        assertEquals(true, result);
        result = smallFile.IsSameTimeFile("name.2012121204", "name.2012121203",
                -1);
        assertEquals(false, result);

        result = smallFile.IsSameTimeFile("name.2012121203", "name.2012121203",
                0);
        assertEquals(true, result);
        result = smallFile.IsSameTimeFile("name.2012121204", "name.2012121603",
                0);
        assertEquals(false, result);

        result = smallFile.IsSameTimeFile("name.2012121203", "2012121303", 1);
        assertEquals(true, result);
        result = smallFile.IsSameTimeFile("name.2011121204", "2012111203", 1);
        assertEquals(false, result);
    }

    public static void main(String[] args) throws IOException {
        String dfsPath = null;
        String dfsName = null;
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-dfsPath")) {
                dfsPath = args[++i];
            } else if (args[i].equals("-dfsName")) {
                dfsName = args[++i];
            }
        }
        if (dfsPath == null || dfsName == null)
            return;

        MergeSmallFile smallFile = new MergeSmallFile(dfsPath, dfsName, 10);
        smallFile.setDaemon(true);
        smallFile.start();
        return;
    }

}
