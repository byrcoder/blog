/**
 * @(#)TestLogSink.java, 2007-11-12. Copyright 2007 Yodao, Inc. All rights
 *                       reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                       subject to license terms.
 */
package outlog.server;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outlog.logging.RemoteLogger;
import outlog.toolbox.Clock;
import toolbox.misc.FileUtils;
import toolbox.misc.UnitUtils;

/**
 * @author river
 */
public class TestLogSink {

    public static class ClockImpl implements Clock.ClockIface {
        private long time = System.currentTimeMillis();

        public long currentTimeMillis() {
            long t = time;
            time += UnitUtils.SECOND;
            return t;
        }

        public void advance(long a) {
            time += a;
        }
    }

    ClockImpl clock = new ClockImpl();

    private File testDir;

    private File localDir;

    private File dfsDir;

    @Before
    public void setUp() throws Exception {
        Clock.setClock(clock);
        testDir = new File(".", TestLogSink.class.getSimpleName());
        if (testDir.exists()) {
            FileUtils.fullyDelete(testDir);
        }
        testDir.mkdir();

        localDir = new File(testDir, "local");
        localDir.mkdir();
        dfsDir = new File(testDir, "dfs");
        dfsDir.mkdir();
    }

    @Test
    public void test() throws Exception {
        String product = "test";
        File productDir = new File(localDir, product);
        SimpleDateFormat dateFormatD1 = new java.text.SimpleDateFormat(
                "yyyyMMdd");
        String filename = productDir.getAbsolutePath() + "/" + product + "."
                + dateFormatD1.format(new Date());
        if (!productDir.exists())
            productDir.mkdir();
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(new File(filename), true), "UTF-8"));
        writer.append("20090612\tok!!");
        writer.close();

        LogSink logSink = new LogSink();
//        logSink.exec(new String[] {
//            localDir.getAbsolutePath()
//        }, dfsDir.getAbsolutePath(), "local", 9180, 1, 1000, LogSink.INTERVAL_DAY,
//                3, "unknown");

        RemoteLogger logger = new RemoteLogger("test", "localhost:2020");
        System.out.println("start ok!!");
        logger.log("1");
        logger.log("2");

        Thread.sleep(UnitUtils.SECOND);
        clock.advance(UnitUtils.DAY + 1);
        logger.log("3");
        logger.log("4");

        Thread.sleep(2 * UnitUtils.SECOND);

        // there should be two log files
        File[] logs = productDir.listFiles();
        assertEquals("no enough logs", 2, logs.length);
        System.out.println("logs : " + Arrays.toString(logs));

        clock.advance(UnitUtils.DAY + 1);
        long time = System.currentTimeMillis() + 36000;
        logger.log(time + "\t5");
        logger.log("6");
        Thread.sleep(2 * UnitUtils.SECOND);

        // there should be two log files
        logs = productDir.listFiles();
        System.out.println("logs : " + Arrays.toString(logs));

        for (int i = 0; i < logs.length; i++) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(logs[i])));
            System.out.println(" doing i " + i);
            while (true) {
                String line = reader.readLine();
                if (line == null)
                    break;
                System.out.println(line);
                if (line.endsWith("5")) {
                    String[] splits = line.split("\t");
                    assertEquals(
                            Long.parseLong(splits[0]) > System.currentTimeMillis(),
                            true);

                }
            }
        }
        assertEquals("no enough logs", 2, logs.length);

    }

    @After
    public void tearDown() throws Exception {
        FileUtils.fullyDelete(testDir);
    }

}
