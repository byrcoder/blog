/**
 * @(#)TestMergeSmallHourFile.java, 2013-4-15. Copyright 2013 Yodao, Inc. All
 *                                  rights reserved. YODAO
 *                                  PROPRIETARY/CONFIDENTIAL. Use is subject to
 *                                  license terms.
 */
package outlog.server;

import java.io.IOException;

/**
 * @author Administrator
 */
public class TestMergeSmallHourFile {

    public static void main(String[] args) throws IOException {
        String dfsPath = null;
        String dfsName = null;
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-dfsPath")) {
                dfsPath = args[++i];
            } else if (args[i].equals("-dfsName")) {
                dfsName = args[++i];
            }
        }
        if (dfsPath == null || dfsName == null)
            return;

        MergeSmallHourFile smallFile = new MergeSmallHourFile(dfsPath, dfsName);
        smallFile.setDaemon(true);
        smallFile.start();
        return;
    }

}
