package outlog.logging;

import org.junit.Test;

public class TestLogger extends Thread {

    private Logger logger;

    public TestLogger(String productId) {
        logger = LogFactory.getLogger(productId);
    }

    public void run() {
        while (true) {
            logger.log("Test message generated at "
                    + System.currentTimeMillis());
            try {
                sleep(500);
            } catch (InterruptedException e) {

            }
        }
    }

    public static void main(String[] args) {
        System.out.println(System.currentTimeMillis());
        TestLogger testLogger = new TestLogger(args[0]);
        testLogger.start();
    }
    
    @Test
    public void test() {
        return;
    }
}
