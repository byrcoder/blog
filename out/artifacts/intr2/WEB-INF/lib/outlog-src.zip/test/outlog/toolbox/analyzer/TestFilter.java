package outlog.toolbox.analyzer;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import outlog.http.RequestLogParser;

public class TestFilter {
    @Test
    public void test() throws Exception {
        RequestLogParser parser = new RequestLogParser();
        parser.parse("API\tkeyfrom=toolbar.94"
                + "\tp=http://www.tedahr.com/recruit/index.asp?field=006&keyword=&kwdtype=pos&period=30&disprec=20&ordertype=pub_time&Page=20"
                + "\treq=rank"
                + "\t[ip=125.36.195.128]"
                + "\t[userid=-1136209709@125.36.191.91]"
                + "\t[useragent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)]"
                + "\t[referer=\\[NULL\\]]");
        assertEquals("bad category", "API", parser.getCategory());
        assertEquals(
                false,
                Filter.isSpider(parser.getProperties().getProperty("useragent")));
        assertEquals(false,
                Filter.isCompanyIp(parser.getProperties().getProperty("ip")));

    }
}
