/**
 * @(#)TestRemoteLogger.java, 2007-11-12. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outlog.logging;

import java.util.Date;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * @author river
 */
public class TestRemoteLogger extends TestCase {

    public void testReplaceLrln() throws Exception {
        assertEquals("a  ", RemoteLogger.replaceLrln("a\r\n"));
        assertEquals("", RemoteLogger.replaceLrln(""));
        assertEquals(" ", RemoteLogger.replaceLrln("\r"));
        assertEquals("  ab", RemoteLogger.replaceLrln("\r\nab"));
        assertEquals("a  b", RemoteLogger.replaceLrln("a\r\nb"));
    }

    static int iii = 0;

    public static void main(String[] args) {
        // out 测试
        String sink = "sb052x.corp.youdao.com:2020"; //在自己的配置文件中取得outlog的sinkaddr
        if (sink != null) {
            LogFactory.registerLogger("test", sink); //建立关联到该sinkaddr的Logger
        }

        for (; iii < 500; ++iii) {
            new Thread(new Runnable() {
                int num = 0;

                public void run() {
                    num = iii;
                    Logger logger = LogFactory.getLogger("test");
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        //break;
                    }

                    long count = 0;
                    while (true) {
                        String outlogtmp = "test : " + new Date().toString();
                        logger.log(outlogtmp);
                        if (++count % 10 == 0) {
                            System.out.println("thread[" + num + "] : " + count);
                        }
                        //                      System.out.println(outlogtmp);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                            //break;
                        }
                    }
                }
            }).start();

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                //break;
            }
        }

    }

    @Test
    public void test() {

    }
}
