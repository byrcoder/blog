/**
 * @(#)TestUdpBroadcaster.java, 2013-4-15. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outlog.server;

import static org.junit.Assert.assertEquals;

import odis.rpc2.RpcException;

import org.junit.Test;

/**
 *
 * @author jasonliu
 *
 */
public class TestUdpBroadcaster {
    
    @Test
    public void testAdd() throws RpcException
    {
        UdpBroadcaster udp=new UdpBroadcaster();
        boolean result=udp.add("realTime@test1", "127.0.0.1", 2321);
        assertEquals(true, result);

        udp.add("test2", "127.0.0.1", 2321);
        assertEquals(true, result);

    }
    
    public static void main(String[] args) throws RpcException {
        UdpBroadcaster udp=UdpBroadcaster.getInstance();
        udp.add("realTime@test1", "127.0.0.1", 2321);
        udp.add("test2", "127.0.0.1", 2321);
        
        String message="API\tkeyfrom=toolbar.94"
            + "\tp=http://www.tedahr.com/recruit/index.asp?field=006&keyword=&kwdtype=pos&period=30&disprec=20&ordertype=pub_time&Page=20"
            + "\treq=rank"
            + "\t[ip=125.36.195.128]"
            + "\t[userid=-1136209709@125.36.191.91]"
            + "\t[useragent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)]"
            + "\t[referer=\\[NULL\\]]";
        Log log=new Log("test1",message);
        log.setTimestamp(System.currentTimeMillis());
        udp.add(log);
        
        return;
    }
}
