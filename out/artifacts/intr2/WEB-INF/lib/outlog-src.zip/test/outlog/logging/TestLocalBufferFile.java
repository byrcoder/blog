/**
 * @(#)TestLocalBufferFile.java, 2013-4-15. Copyright 2013 Yodao, Inc. All
 *                               rights reserved. YODAO
 *                               PROPRIETARY/CONFIDENTIAL. Use is subject to
 *                               license terms.
 */
package outlog.logging;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.ArrayBlockingQueue;

import org.junit.Test;

/**
 * @author jasonliu
 */
public class TestLocalBufferFile {

    @Test
    public void testEqualitySamplerPool() throws Exception {
        LocalBufferFile local = new LocalBufferFile(null);

        int poolNum = 1;
        for (poolNum = 1; poolNum < 10; poolNum++) {
            String[] pool = {
                "a", "b", "c"
            };
            String message = "d";
            local.equalitySamplerPool(pool, poolNum, message);
            for (int i = 0; i < pool.length; i++) {
                System.out.println(pool[i]);
            }
            System.out.println("\n");
        }
    }

    @Test
    public void testConvertToTimeFormatPath() {
        LocalBufferFile local = new LocalBufferFile(null);
        String result = local.convertToTimeFormatPath("20121212");
        assertEquals("./requestlogbuffer/20121220", result);
    }

    public static void main(String[] args) {
        ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(2000);
        LocalBufferFile sender = new LocalBufferFile(queue);
        return;
    }
}
