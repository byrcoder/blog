package outlog.server;

import org.apache.mina.protocol.ProtocolCodecFactory;
import org.apache.mina.protocol.ProtocolDecoder;
import org.apache.mina.protocol.ProtocolEncoder;
import org.apache.mina.protocol.ProtocolHandler;
import org.apache.mina.protocol.ProtocolProvider;

/**
 * ProtocolProvider of mina.
 * 
 * @author yaming
 */
public class LogSinkProtocolProvider implements ProtocolProvider {

    private static ProtocolCodecFactory CODEC_FACTORY = new ProtocolCodecFactory() {
        public ProtocolEncoder newEncoder() {
            return null;
        }

        public ProtocolDecoder newDecoder() {
            return new LogProtocolDecoder();
        }
    };

    private ProtocolHandler handler;

    public LogSinkProtocolProvider(ProtocolHandler handler) {
        this.handler = handler;
    }

    public ProtocolCodecFactory getCodecFactory() {
        return CODEC_FACTORY;
    }

    public ProtocolHandler getHandler() {
        return handler;
    }

}
