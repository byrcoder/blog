package outlog.toolbox.analyzer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

import outlog.toolbox.GetConfig;

/*
 * ps: 这是一个最简单的，回头改成在线读配置。
 * Filter to recognize company ip and 
 */
public class Filter {
    private static String[] companyIpConf = new String[]{
        "61.135.255.83", "127.0.0.1", "192.168.", "10.",
        "202.108.7.", "61.135.216.", "61.135.217.", 
        "61.135.218.", "61.135.219.", "61.135.220.", 
        "61.135.221.", "60.191.80.", "60.191.82.",
        "61.135.255.86", /*火炬办公室*/
        "61.135.248."/*qt的外网*/, "61.135.249."/*nd的外网*/, "220.181.76."/*兆维外网*/, 
        "121.195.178.201", "121.195.178.202"/*教育网*/, "203.86.46.138"/*vpn*/, 
        "203.86.63.107"/*电信服务器*/, 
        "123.58.182"/*ynote外网*/
    };

    /* https://dev.corp.youdao.com/outfoxwiki/ServerList 
     * 参照该wiki 维护
     */
    private static String[] youdaoIpConf = new String[]{
        "127.0.0.1", "192.168.", "10.168.", "10.169.", /*内网*/
        "61.135.216.", "61.135.217.", "61.135.218.", 
        "61.135.219.", "61.135.220.", "61.135.221.", 
        "61.135.248."/*qt的外网*/, "61.135.249."/*nd的外网*/, "220.181.76."/*兆维外网*/, 
        "121.195.178.201", "121.195.178.202"/*教育网*/, 
        "203.86.46.138"/*vpn*/, "203.86.63.107"/*电信服务器*/, "61.135.255.83"/*youdao办公室*/, 
        "123.58.182"/*ynote外网*/, "10.120.182"/*ynote内网*/
    };

    private static String[] spiderConf = new String[]{
        "Baiduspider",  "Googlebot", "Yahoo!", "msnbot", "QihooBot", 
        "sogou", "heritrix", "Commons-HttpClient", "Indy Library",
        "YodaoBot", "YoudaoBot", "Sosospider",
        "baiduspider-mobile-gate", "iaskspider"
    };


    
    public static boolean isCompanyIp(String ip){
        return isInList(ip, companyIpConf, true);
    }
    
    /*
     * function: judge if the request comes from company ip.  
     * @parameter: HttpServletRequest request
     */
    public static boolean isCompanyIp(HttpServletRequest request){
        String ip = request.getRemoteAddr() ;
        return isInList(ip, companyIpConf, true);
    }

    public static boolean isYoudaoIp(String ip){
        return isInList(ip, youdaoIpConf, true);
    }
    public static boolean isYoudaoIp(HttpServletRequest request){
        String ip = request.getRemoteAddr() ;
        return isInList(ip, youdaoIpConf, true);
    }

    public static boolean isSpider(String useragent){
        return isInList(useragent, spiderConf, false);
    }
    public static boolean isSpider(HttpServletRequest request){
        String useragent = request.getHeader("User-Agent");
        return isInList(useragent, spiderConf, false);
    }
    
    public static boolean isRefererNull(HttpServletRequest request){
        String referer = request.getHeader("Referer");
        return referer== null ? true: false;
    }
    
    private static boolean isInList(String value,String[] conf, boolean isFirstMatch){
        update();
        
        if(value == null){
            value = "null";
        }
        for(int i = 0;conf!=null &&i < conf.length; i++){
            int pos = value.indexOf(conf[i]);
            if( !isFirstMatch && pos >= 0){
                return true;
            }else if (isFirstMatch && pos == 0)
                return true;
        }
        return false;
    }
    
    /*
     * 异步更新
     */
    private static String URL = 
        "http://config.corp.youdao.com/svn/yodaoconfig/iplocation/company_ip.conf";
    private static long checkConfInterval = 10 * 60 * 1000L;
    private static long lastUpTime = -1L;
    private static byte[] updateLock = new byte[0];
    private static void update() {
        synchronized (updateLock) {
            if (System.currentTimeMillis() - lastUpTime >= checkConfInterval) {
                new Thread(new Runnable() {
                    private int timeout = 5000;
                    public void run() {
                        HttpClient client = new HttpClient();
                        client.getParams().setParameter("http.socket.timeout", 
                                new Integer(timeout));
                        GetMethod method = new GetMethod(URL);
                        method.addRequestHeader("Connection", "close");
                        
                        try {
                            int code = client.executeMethod(method);
                            if (code == 200) {
                                BufferedReader fread = new BufferedReader(
                                        new InputStreamReader(
                                                method.getResponseBodyAsStream(),
                                                "UTF-8"));
                                String line = null;
                                while ((line = fread.readLine()) != null) {
                                    String[] ips;
                                    if (line.startsWith("companyIp=")) {
                                        ips = getIpConfig(line.substring("companyIp=".length()));
                                        if (null != ips) {
                                            companyIpConf = ips;
                                        }
                                    } else if (line.startsWith("youdaoIp=")) {
                                        ips = getIpConfig(line.substring("youdaoIp=".length()));
                                        if (null != ips) {
                                            youdaoIpConf = ips;
                                        }
                                    } else if (line.startsWith("spider=")) {
                                        ips = getIpConfig(line.substring("spider=".length()), ";");
                                        if (null != ips) {
                                            spiderConf = ips;
                                        }
                                    }
                                }
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    
                    private String[] getIpConfig(String str) {
                        return getIpConfig(str, " ");
                    }
                    private String[] getIpConfig(String str, String split) {
                        ArrayList<String> ips = new ArrayList<String>();
                        for (String i : GetConfig.vsplit(str, split)) {
                            int pos = i.indexOf("/*");
                            if (pos > 0) {
                                i = i.substring(0, pos);
                            }
                            i = i.trim();
                            if (i.length() >= 2) {
                                ips.add(i);
                            }
                        }
                        if (ips.size() > 5) {
                            return ips.toArray(new String[0]);
                        }
                        return null;
                    }
                }).start();
                lastUpTime = System.currentTimeMillis();
            }
        }
    }
}
