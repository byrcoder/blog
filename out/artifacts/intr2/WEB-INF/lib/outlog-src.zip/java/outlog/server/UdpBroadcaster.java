/**
 * @(#)UdpBroadcaster.java, 2012-6-5. Copyright 2012 Yodao, Inc. All rights
 *                          reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                          subject to license terms.
 */
package outlog.server;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.PortUnreachableException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;

import outlog.toolbox.Clock;
import toolbox.collections.Pair;
import toolbox.maintain.alarm.SmsSender;
import toolbox.misc.LogFormatter;

/**
 * @author pumpkin
 * @author jasonliu
 */
public class UdpBroadcaster implements Runnable, ITailLogProtocol {
    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(UdpBroadcaster.class.getName());

    private String HEARTBEAT = "heartbeat";

    private HashMap<String, List> req = new HashMap<String, List>();

    private AbstractRpcServer reqServer = null;

    private Thread cleanReqTh = null;

    private static Long REQ_LIFE = 6 * 1000L;

    private int udpMTU = 1200;

    private ArrayBlockingQueue<Log> udpLogBufferQueue = new ArrayBlockingQueue<Log>(
            10000);

    // static instance
    private static UdpBroadcaster ubc = null;

    public static UdpBroadcaster getInstance() {
        if (ubc == null) {
            ubc = new UdpBroadcaster();
            Thread udpThread = new Thread(ubc);
            udpThread.setDaemon(true);
            udpThread.start();
        }
        return ubc;
    }

    private void closeTh() {
        if (null != cleanReqTh) {
            cleanReqTh.interrupt();
            cleanReqTh = null;
        }
    }

    public UdpBroadcaster() {
        closeTh();
        cleanReqTh = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    long now = Clock.currentTimeMillis();
                    synchronized (req) {
                        Iterator iter = req.keySet().iterator();
                        while (iter.hasNext()) {
                            String productId = (String) iter.next();
                            ArrayList<Pair<DatagramSocket, Long>> list = (ArrayList<Pair<DatagramSocket, Long>>) req
                                    .get(productId);

                            for (int i = 0; i < list.size(); ++i) {
                                Pair<DatagramSocket, Long> p = list.get(i);
                                if (now - p.getSecond() >= REQ_LIFE) {
                                    p.getFirst().close();
                                    list.remove(i);
                                    --i;
                                }
                            }

                            if (list.size() <= 0) {
                                iter.remove();
                            }
                        }
                    }

                    try {
                        Thread.sleep(REQ_LIFE);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        });
        cleanReqTh.setDaemon(true);
        cleanReqTh.start();

        int handleCount = 32;
        // ----
        reqServer = RPC.getServer(ITailLogProtocol.class, this, 2327,
                handleCount, handleCount * 10, 1, 0);
        try {
            reqServer.start();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            reqServer.stop();
        }
    }

    public boolean send(Log log) {
        String product = log.getProductId();
        synchronized (req) {
            ArrayList<Pair<DatagramSocket, Long>> list = (ArrayList<Pair<DatagramSocket, Long>>) req
                    .get(log.getProductId());
            if (null == list) {
                return true;
            }

            if (log.getMessage().length() > udpMTU) {
                int beg = 0;
                int end = 0;
                List<String> udpsubpackage = new ArrayList<String>();
                while (beg < log.getMessage().length()) {
                    if (beg + udpMTU >= log.getMessage().length())
                        end = log.getMessage().length();
                    else {
                        end = log.getMessage().substring(beg, beg + udpMTU)
                                .lastIndexOf("\t");
                        if (end <= 0)
                            end = log.getMessage().indexOf("\t", beg);
                        else
                            end += beg;
                    }
                    if (end <= 0)
                        end = log.getMessage().length();
                    String packet_bits = new String();
                    if (0 == beg)
                        packet_bits = log.getTimestamp() + "\t";
                    if (end - beg > udpMTU)
                        packet_bits += log.getMessage().substring(beg,
                                beg + udpMTU);
                    else
                        packet_bits += log.getMessage().substring(beg, end);
                    beg = end + 1;
                    udpsubpackage.add(packet_bits);
                }

                // send log
                long hashcode = (log.getTimestamp() + log.getMessage())
                        .hashCode();
                for (int i = 0; i < udpsubpackage.size(); i++) {
                    String packet_bits = "#" + hashcode + "#"
                            + udpsubpackage.size() + "_" + i + "#"
                            + udpsubpackage.get(i);
                    DatagramPacket packet = new DatagramPacket(packet_bits
                            .getBytes(), packet_bits.length());
                    for (Pair<DatagramSocket, Long> pair: list) {
                        try {
                            packet.setAddress(null);
                            pair.getFirst().send(packet);
                        } catch (IOException e1) {
                            // TODO Auto-generated catch block
                            e1.printStackTrace();
                        }
                    }
                }
            } else {
                byte[] packet_bits = (log.getTimestamp() + "\t" + log
                        .getMessage()).getBytes();
                DatagramPacket packet = new DatagramPacket(packet_bits,
                        packet_bits.length);
                for (Pair<DatagramSocket, Long> pair: list) {
                    try {
                        packet.setAddress(null);
                        pair.getFirst().send(packet);
                    } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                }
            }// end of else
            return true;
        }
    }

    @Override
    public boolean add(String productId, String ip, int port)
            throws RpcException {
        if (productId.startsWith(HEARTBEAT))
            productId = productId.substring(HEARTBEAT.length());
        else
            LOG.info("client request:" + productId + " come from " + ip + ":"
                    + port);

        synchronized (req) {
            ArrayList<Pair<DatagramSocket, Long>> list = (ArrayList<Pair<DatagramSocket, Long>>) req
                    .get(productId);
            if (null == list) {
                list = new ArrayList<Pair<DatagramSocket, Long>>();
                req.put(productId, list);
            }

            InetSocketAddress addr = new InetSocketAddress(ip, port);
            // 定位插入位置
            int pos = 0;
            for (; pos < list.size(); ++pos) {
                int comp = compare(addr, list.get(pos).getFirst());
                if (0 == comp) {
                    list.get(pos).setSecond(Clock.currentTimeMillis());
                    return true;
                } else if (comp < 0) {
                    break;
                }
            }

            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.connect(addr);
            } catch (SocketException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return false;
            }

            list.add(pos, new Pair<DatagramSocket, Long>(socket, Clock
                    .currentTimeMillis()));

            return true;
        }
    }

    private int compare(InetSocketAddress o1, DatagramSocket o2) {
        int ret = o1.getAddress().hashCode() - o2.getInetAddress().hashCode();
        if (0 == ret) {
            ret = o1.getPort() - o2.getPort();
        }
        return ret;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {

        // TODO Auto-generated method stub
        while (true) {
            Log log = udpLogBufferQueue.poll();
            if (null == log) {
                try { // odfs error
                    Thread.sleep(5);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
                continue;
            }

            try {
                send(log);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }// end of while
    }// end of run thread

    long logNum = 1;

    long time = System.currentTimeMillis();

    public void add(Log next) {
        if (!udpLogBufferQueue.offer(next)) {
            if ((logNum > 1000)
                    && (System.currentTimeMillis() - time) > 1000 * 60 * 30) {
                logNum = 1;
                time = System.currentTimeMillis();
                LOG.info("udpLogBufferQueue over flow");
                SmsSender.send(new String[] {
                    "liujg"
                }, "LogSink udpLogBufferQueue over flow!");
            }
            logNum++;
        }
    }
}
