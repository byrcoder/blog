package outlog.logging;

/**
 * Interface of Logger.
 * 
 * @author yaming
 */
public interface Logger {

    /**
     * Log a message. Message will be delivered to log sink, or send to
     * System.out (if this is a LocalLogger).
     * 
     * @param message
     */
    public void log(String message);
    
    /**
     * flush writer manually.
     *
     */
    public void flush();
}
