package outlog.server;

/**
 * The body of a Log. Contains a productId and a message.
 * 
 * @author yaming
 */
public class Log {

    private String productId;

    private String message;
    
    private long timestamp;

    public Log(String productId, String message) {
        this.productId = productId;
        this.message = message;
    }

    public String getProductId() {
        return productId;
    }

    public String getMessage() {
        return message;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setMessage(long time, String message) {
        this.timestamp = time;
        this.message = message;
    }

    /**
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
