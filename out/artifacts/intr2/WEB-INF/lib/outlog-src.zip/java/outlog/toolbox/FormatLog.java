/**
 * @(#)FormatLog.java, 2008-2-27. Copyright 2008 Yodao, Inc. All rights
 *                     reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is subject
 *                     to license terms.
 */
package outlog.toolbox;

import java.util.logging.Level;

import toolbox.misc.LogFormatter;

/**
 * @author Administrator
 */
public class FormatLog {
    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(FormatLog.class.getName());
    static boolean isDebug = false;
    
    public static void warn(String log){
        LOG.log(Level.WARNING, log);
    }
    public static void debug(String log){
        if(isDebug){
            LOG.log(Level.INFO, log);
        }
    }
    
    public static void info(String log){
        LOG.log(Level.INFO, log);
    }
    
    public static void setIsDebug(boolean debug){
        isDebug = debug;
    }

}
