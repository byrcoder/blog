package outlog.logging;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Level;
import java.util.regex.Pattern;

import odis.conf.OdisLibConfig;
import toolbox.misc.LogFormatter;

/**
 * The log-factory class. To get a logger: Logger logger =
 * LogFactory.getLogger("product-id");
 * 
 * @author yaming
 */
public class LogFactory {

    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(LogFactory.class.getName());

    private static final Pattern pattern = Pattern.compile("[\\w\\-\\.\\_]+");

    private static String CONFIG_FILE_NAME = "outlog.properties";

    private static String defaultAddress = null;

    private static HashMap<String, Logger> loggerMap = new HashMap<String, Logger>();

    private static String home;

    // Find configurations in Config dirs and load properties.
    static {
        File configFile = null;
        /**
         * Try OdisLibConfig.getConfigDir()
         */
        if (configFile == null) {
            home = System.getProperty("odis.home");
            if (home != null) {
                configFile = new File(OdisLibConfig.getConfigDir(),
                        CONFIG_FILE_NAME);
                if (!configFile.exists()) {
                    configFile = null;
                } // if
            } // if
        } // if
        if (configFile == null) {
            home = System.getProperty("odis.home");
            if (home != null) {
                configFile = new File(home, CONFIG_FILE_NAME);
                if (!configFile.exists()) {
                    configFile = null;
                }
            }
        }
        if (configFile == null) {
            home = System.getProperty("outlog.home");
            if (home != null) {
                configFile = new File(home, CONFIG_FILE_NAME);
                if (!configFile.exists()) {
                    configFile = null;
                }
            }
        }
        if (configFile == null) {
            home = System.getenv("OUTLOG_HOME");
            if (home != null) {
                configFile = new File(home, CONFIG_FILE_NAME);
                if (!configFile.exists()) {
                    configFile = null;
                }
            }
        }
        if (configFile == null) {
            home = ".";
            if (home != null) {
                configFile = new File(home, CONFIG_FILE_NAME);
                if (!configFile.exists()) {
                    configFile = null;
                }
            }
        }

        if (configFile != null) {
            try {
                FileInputStream istream = new FileInputStream(configFile);
                Properties props = new Properties();
                props.load(istream);
                defaultAddress = props.getProperty("sinkaddr");
                LOG.info("outlog.properties loaded, default sink address is "
                        + defaultAddress);
                if (defaultAddress == null) {
                    LOG.info("LocalLogger will returned by getLogger method "
                            + "defaultly.");
                }
            } catch (FileNotFoundException e) {
                LOG.log(Level.WARNING, "Outlog configuration file "
                        + "(outlog.properties) not found. LocalLogger "
                        + "will returned by getLogger method defaultly.");
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Caught IOException when load "
                        + "outlog.properties. LocalLogger will "
                        + "returned by getLogger method defaultly.");
            }
        } else {
            LOG.log(Level.WARNING, "Outlog configuration file "
                    + "(outlog.properties) not found. LocalLogger will "
                    + "returned by getLogger method defaultly.");

        }
    }

    /**
     * Register a logger to the sink address
     * 
     * @param productId
     * @param address
     */
    public synchronized static void registerLogger(String productId,
            String address) {
        if (address == null || "".equals(address.trim())) {
            // for empty address, put a LocalLogger
            loggerMap.put(productId, new LocalLogger());
            return;
        } // if
        Logger logger = loggerMap.get(productId);
        if ((logger == null) || (logger instanceof LocalLogger)) {
            logger = new RemoteLogger(productId, address);
            loggerMap.put(productId, logger);
        } else if (logger instanceof RemoteLogger) {
            LOG.warning("duplicate registration for product id " + productId);
        } else {
            LOG.warning("register logger: " + productId + " to " + address
                    + " failed.");
        }
    }

    /**
     * Get a logger, productId is also the id of this logger. If you has a sink
     * address set in the file outlog.properties, or registerd a logger with
     * this productId to a sink address using registerLogger method, a
     * RemoteLogger will be returned, log message will be delivered to log sink.
     * If no sink address can be found, a LocalLogger will be returned, log
     * message will be printed to stdout.
     * 
     * @param productId
     * @return
     */
    public synchronized static Logger getLogger(String productId) {
        Logger logger = loggerMap.get(productId);
        if (logger == null) {
            if (!pattern.matcher(productId).matches()) {
                LOG.warning("ProductId: " + productId
                        + " is not valid, LocalLogger will be returned.");
                logger = new LocalLogger();
            } else if (defaultAddress != null) {
                logger = new RemoteLogger(productId, defaultAddress);
            } else {
                logger = new LocalLogger();
            }
            loggerMap.put(productId, logger);
        }
        return logger;
    }
}
