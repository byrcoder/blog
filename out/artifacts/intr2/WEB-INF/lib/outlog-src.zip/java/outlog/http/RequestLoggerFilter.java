/**
 * @(#)RequestLogFilter.java, 2007-12-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outlog.http;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import toolbox.misc.LogFormatter;
/**
 * A filter which provides an alternative way of using RequestLogger. 
 * @author zhangkun
 *
 */
public class RequestLoggerFilter implements Filter {
    private static final Logger LOG = LogFormatter.getLogger(RequestLoggerFilter.class.getName());
    private RequestLogger logger;
    /**
     * If category is set to null, the requested URI will be used as category, otherwise,
     * the designated category will be used and the requested URI will be displayed as an attribute
     * "requestedURI". 
     */
    private String category = null;
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse res,
        FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httprequest = (HttpServletRequest)req;
        HttpServletResponse httpresponse = (HttpServletResponse)res;
        String path = httprequest.getRequestURI();
        if(category == null) {
            logger.log(path, httprequest, httpresponse);
        } else {
            httprequest.setAttribute("requestedURI", path);
            logger.log(category, httprequest, httpresponse);
        }
        chain.doFilter(req, res);
    }

    public void init(FilterConfig conf) throws ServletException {
        String productName = conf.getInitParameter("productName");
        if(productName == null) {
            throw new ServletException("productName is null");
        }
        LOG.info("productName=" + productName);
        String sinkAddr = conf.getInitParameter("sinkAddr");
        if(sinkAddr == null) {
            throw new ServletException("sinkAddr is null");
        }
        LOG.info("sinkAddr=" + sinkAddr);
        logger = new RequestLogger();
        logger.setProductName(productName);
        logger.setSinkAddr(sinkAddr);
        String userNameAttributeName = conf.getInitParameter("userNameAttributeName");
        if(userNameAttributeName != null) {
            logger.setUserNameAttributeName(userNameAttributeName);
            LOG.info("userNameAttributeName=" + userNameAttributeName);
        }
        String cookieName = conf.getInitParameter("cookieName");
        if(cookieName != null) {
            logger.setCookieName(cookieName);
            LOG.info("cookieName=" + cookieName);
        }
        String cookieDomain = conf.getInitParameter("cookieDomain");
        if(cookieDomain != null) {
            logger.setCookieDomain(cookieDomain);
            LOG.info("cookieDomain=" + cookieDomain);
        }
        String sendQueueMaxSize = conf.getInitParameter("sendQueueMaxSize");
        if(sendQueueMaxSize != null) {
            logger.setSendQueueMaxSize(Integer.parseInt(sendQueueMaxSize));
            LOG.info("sendQueueMaxSize=" + sendQueueMaxSize);
        }
        category = conf.getInitParameter("category");
        if(category != null) {
            // FIXME this filter doesn't provides interface of setting visible attributes right now,
            // so I simply overwrite the default empty visible attribut list.
            logger.setVisibleAttributes(Arrays.asList(new String[]{"requestedURI"}));
            LOG.info("category=" + category); 
        }
        logger.init();
    }
}
