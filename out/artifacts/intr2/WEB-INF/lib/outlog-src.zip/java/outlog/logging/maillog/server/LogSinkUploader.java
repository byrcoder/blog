package outlog.logging.maillog.server;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;

import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.TimeWritable;
import odis.serialize.lib.UTF8Writable;
import outlog.toolbox.Clock;
import outlog.toolbox.Helper;
import toolbox.maintain.alarm.SmsSender;
import toolbox.misc.LogFormatter;

public class LogSinkUploader {
    private static final Logger LOG = LogFormatter.getLogger(
            LogSinkUploader.class.getName());
    
    public static final String INTERVAL_DAY = "day";
    public static final String INTERVAL_HOUR = "hour";

    private final static String GZ_SUFFIX = ".gz";
    
    private String host;

    private String localPath;
    
    private String dfsPath;
    
    private IFileSystem dfs;
    
    private int uploadThread;
    
    private int localCopyCount = 20;
    
    private int odfsFullRetry = 0;
    
    private int maxOdfsFullRetry = 300;

    private String interval = INTERVAL_DAY;
    
    private LinkedList<String> dfsUploadQueue = new LinkedList<String>();

    private ArrayList<DfsUploader> dfsUploader = new ArrayList<DfsUploader>();
    
    private SimpleDateFormat dateFormatD2 = new java.text.SimpleDateFormat(
    "yyyyMMdd");

    private SimpleDateFormat dateFormatH2 = new java.text.SimpleDateFormat(
    "yyyyMMddHH");

    private SimpleDateFormat timeFormat2 = new java.text.SimpleDateFormat(
    "yyyyMMddHHmmss");
    
    private static final String[] SMS_GROUP = {
        "liujg"
    };
    
    public LogSinkUploader(IFileSystem dfs, String localPath, String dfsPath,
            int uploadThread) {
        this(dfs, localPath, dfsPath, uploadThread, "unknown");
    }
    public LogSinkUploader(IFileSystem dfs, String localPath, String dfsPath,
            int uploadThread, String host) {
        this.dfs = dfs;
        this.localPath = localPath;
        this.dfsPath = dfsPath;
        this.uploadThread = uploadThread;
        this.host = host;
    }
    
    public void upload(){
        checkOldLogFiles();
        for(int i = 0; i < uploadThread; i++){
            DfsUploader up = new DfsUploader();
            dfsUploader.add(up);
            up.run();
        }
    }
    /**
     * Collect all old log files to dfsUploadQueue.
     */
    private void checkOldLogFiles() {
        Calendar ccal = Calendar.getInstance();
        String todayName;
        if (interval.equals(INTERVAL_HOUR)) {
            todayName = dateFormatH2.format(ccal.getTime());
        } else {
            todayName = dateFormatD2.format(ccal.getTime());
        }
        File localDir = new File(localPath);
        for (File dir: localDir.listFiles()) {
            if (dir.isDirectory()) {
                for (File file: dir.listFiles()) {
                    String filename = file.getName();
                    // ignore archived copied
                    if (filename.endsWith(".a"))
                        continue;

                    if (!filename.endsWith("." + todayName)) {
                        synchronized (dfsUploadQueue) {
                            dfsUploadQueue.add(dir.getName() + "/"
                                    + filename);
                            dfsUploadQueue.notify();
                        }
                        LOG.info("Found old file " + dir.getName() + "/"
                                + file.getName()
                                + ", put it to dfsUploadedQueue.");
                    }else{
                        String productId = filename.replace("."+todayName, "");
                        
                        LOG.info("find product id : " + productId 
                                + " path : " + file.getPath() + " need not upload.");
                    }
                }
            }
        }
    }
    
    public static void main(String[] args) throws IOException {
        FileInputStream istream = new FileInputStream("conf/logsink.cfg");
        Properties props = new Properties();
        props.load(istream);
        istream.close();
        String dfsName = props.getProperty("dfsname");
        FileSystem dfs;
        try {
            dfs = FileSystem.getNamed(dfsName);
            LOG.info("Get FileSystem " + dfsName + " success.");
        } catch (IOException e) {
            LOG.log(Level.SEVERE, "Caught IOException when get FileSystem: "
                    + dfsName + "!.", e);
            throw e;
        }
        
        String host = props.getProperty("host", "unknown");
        String localPath = props.getProperty("localpath");
        String dfsPath = props.getProperty("dfspath");

        int uploadThread = Integer.parseInt(props.getProperty("uploadThread", "1"));

        if (dfsName == null || localPath == null || dfsPath == null) {
            return;
        }
        
        LogSinkUploader uploader = new LogSinkUploader(dfs, localPath,
                dfsPath, uploadThread, host);
        uploader.upload();

    }
    /**
     * Uploader thread, putting all log files to odfs.
     * 
     * @author yaming
     */
    private class DfsUploader extends Thread {
        private static final int MAX_BLOCK = 8 << 20;
        
        public void run() {
            while (true) {
                String next;
                synchronized (dfsUploadQueue) {
                    if (dfsUploadQueue.isEmpty()) {
                        LOG.log(Level.INFO, "upload to odfs finished!!");
                        break;
                    }
                    next = dfsUploadQueue.poll();
                }
                if (next != null) {
                    File localFile = new File(localPath, next);
                    String dfsNext = next.endsWith(GZ_SUFFIX) ? 
                            next.substring(0, next.length() - GZ_SUFFIX.length()) : 
                                next;
                    Path dfsFile = new Path(dfsPath, dfsNext);
                    Path dfsParentDir = dfsFile.getParentFile();
                    Path tmpFile = new Path("/tmp/outlogtmp", 
                            next + "." + Clock.currentTimeMillis());
                    if (localFile.exists()) {
                        try {
                            while (dfs.exists(tmpFile)) {
                                tmpFile = new Path("/tmp/outlogtmp", 
                                        next + "." + Clock.currentTimeMillis());
                            }

                            LOG.info("Uploading " + next + " to "
                                    + dfs.getName() + ".....");
                            if (!transferToDfsSeqFile(localFile, tmpFile)) {
                                // local IOException
                                continue ;
                            }
                            
                            if (!dfs.exists(dfsParentDir)) {
                                dfs.mkdirs(dfsParentDir);
                            }
                            int i = 1;
                            while (dfs.exists(dfsFile)) {
                                dfsFile = new Path(dfsPath, dfsNext + "." + i);
                                i++;
                            }
                            dfs.rename(tmpFile, dfsFile);
                            if (localCopyCount <= 0) {
                                localFile.delete();
                            } else {
                                localFile.renameTo(new File(localFile
                                        .getAbsolutePath()
                                        + ".a"));
                            }
                            LOG.info("Uploaded " + next + " to "
                                    + dfs.getName()
                                    + " path : " + dfsFile.getAbsolutePath());
                            odfsFullRetry = odfsFullRetry > 0 ? odfsFullRetry-1 : 0;
                        } catch (IOException e) {
                            // only dfs IOException
                            LOG.log(Level.WARNING,
                                    "Caught IOException when upload file "
                                            + localFile + " to dfs.", e);
                            
                            odfsFullRetry++;
                            try { //odfs error
                                Thread.sleep(20000);
                            } catch (InterruptedException e1) {
                                e1.printStackTrace();
                            }
                            if (odfsFullRetry >= maxOdfsFullRetry) {
                                //重试多次也不能成功，就失败退出，重启了
                                SmsSender.send(SMS_GROUP, 
                                        new StringBuilder("dfsUploader error ... ")
                                        .append(host).append(" ")
                                        .append(e.getMessage()).toString());
                                System.exit(1000);
                            }
                            
                            LOG.info("Put back to dfsUploadQueue.");
                            synchronized (dfsUploadQueue) {
                                dfsUploadQueue.add(next);
                            }
                        }
                    } else {
                        LOG.log(Level.WARNING,
                                "DfsUploader can not found local file: "
                                        + localFile.getAbsolutePath());
                    }
                }
            }
        }

        /**
         * Transfer a local text formatted log file to a compressed sequence
         * file on odfs, using TimeWritable -> UTF8Writable.
         * 
         * @param srcFile
         * @param dstFile
         * @throws dfs IOException
         */
        public boolean transferToDfsSeqFile(File srcFile, Path dstFile) 
                throws IOException {
            BufferedReader reader = null;
            try {
                if (srcFile.getName().endsWith(GZ_SUFFIX)) {
                    reader = 
                        new BufferedReader(
                                new InputStreamReader(
                                        new GZIPInputStream(
                                                new FileInputStream(srcFile)), 
                                                "UTF-8"));
                } else {
                    reader = 
                        new BufferedReader(
                                new InputStreamReader(
                                        new BufferedInputStream(
                                                new FileInputStream(srcFile), 
                                                MAX_BLOCK), "UTF-8"));
                }
            } catch (EOFException e) {
                // TODO Auto-generated catch block
                // empty file
                e.printStackTrace();
                return false;
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                // never mind
                e.printStackTrace();
                return false;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                // alarm and continue;
                e.printStackTrace();
                SmsSender.send(SMS_GROUP, 
                        new StringBuilder("dfsUploader open file error ... ")
                        .append(host).append(":/")
                        .append(srcFile.getAbsolutePath()).toString());
                return false;
            }
            
            SequenceFile.Writer writer;
            try {
                writer = new SequenceFile.CompressedWriter(dfs,
                        dstFile, TimeWritable.class, UTF8Writable.class);
            } catch (IOException e2) {
                // TODO Auto-generated catch block
                e2.printStackTrace();
                try {
                    reader.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                throw e2;
            }
            
            String record = null;
            TimeWritable t = new TimeWritable();
            UTF8Writable c = new UTF8Writable();
            while (true) {
                try {
                    record = reader.readLine();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                    SmsSender.send(SMS_GROUP, 
                            new StringBuilder("dfsUploader upload file error ... ")
                            .append(host).append(":/")
                            .append(srcFile.getAbsolutePath()).toString());
                    record = null;
                }
                if (null == record) break ;
                
                String[] splits = Helper.vsplit(record, "\t", 3);
                if (splits.length < 3) continue ;
                
                splits[1] = splits[1].replaceAll(":|@", "-");
                try {
                    t.set(timeFormat2.parse(splits[0]).getTime());
                } catch (ParseException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                    continue ;
                }
                c.set(new StringBuilder(splits[1]).append("\t")
                        .append(splits[2]).toString());
                
                int max_try_close = 3;
                while (true) {
                    try {
                        writer.write(t, c);
                        break;
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        if (max_try_close <= 0) {
                            try {
                                writer.close();
                                dfs.delete(dstFile);
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                            throw ex;
                        }
                    }
                    --max_try_close;
                }
            }
            try {
                reader.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            // 有时odfs close 会出错
            int max_try_close = 3;
            while (true) {
                try {
                    writer.close();
                    break;
                } catch (IOException ex) {
                    if (max_try_close <= 0) throw ex;
                }
                --max_try_close;
            }
            
            return true;
        }
    }

}
