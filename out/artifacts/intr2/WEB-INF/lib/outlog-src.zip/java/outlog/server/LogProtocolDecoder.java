package outlog.server;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Pattern;

import odis.io.DataOutputBuffer;
import odis.serialize.lib.StringWritable;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.protocol.ProtocolDecoder;
import org.apache.mina.protocol.ProtocolDecoderOutput;
import org.apache.mina.protocol.ProtocolSession;
import org.apache.mina.protocol.ProtocolViolationException;

import toolbox.misc.LogFormatter;

/**
 * Decoder in mina, process data from client.
 * 
 * @author yaming
 */
public class LogProtocolDecoder implements ProtocolDecoder {
    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(LogProtocolDecoder.class.getName());

    private static final Pattern pattern = Pattern.compile("[\\w\\-\\.\\_]+");

    public static Boolean runFlag = true;    
  
    DataOutputBuffer obuf = new DataOutputBuffer();

    /**
     * Collect input datas until a complete log is got, and then send the log to
     * the output, the log will be processed by the LogSinkHandler.
     */
    public void decode(ProtocolSession session, ByteBuffer buf,
            ProtocolDecoderOutput output) throws ProtocolViolationException {
        if (!runFlag) {
            // 手动释放连接
            session.close();
            return;
        }

        while (buf.hasRemaining()) {
            byte b = buf.get();

            if (b == '\n') {
                String s = StringWritable
                        .decode(obuf.getData(), 0, obuf.size());

                if (session.getAttribute("productId") == null) {
                    if (pattern.matcher(s).matches()) {
                        session.setAttribute("productId", s);
                    } else {
                        LOG.warning("ProductId : " + s
                                + " containes invalid chars.");
                        session.close();
                    }
                } else {
                    output.write(new Log((String) session
                            .getAttribute("productId"), s));
                }
                obuf.reset();
            } else if (b != '\r') {
                obuf.write(b);
            }
        }
    }

    // 手动修改配置runFlag值，确定是否需要退出程序
    public static void readConfigThread() {
        
        Thread th = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    try {
                        FileInputStream istream = new FileInputStream(
                                "logsink.cfg");
                        Properties props = new Properties();
                        props.load(istream);
                        istream.close();
                        synchronized (runFlag) {
                            runFlag = Boolean.valueOf(props.getProperty(
                                    "runFlag", "true"));
                        }
                        if (!runFlag)
                            LOG
                                    .info("operator begins to close the outlog server!");
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    try {
                        Thread.sleep(30000);
                    } catch (InterruptedException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
        th.setDaemon(true);
        th.start();
        
    }
}
