package outlog.logging;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import outlog.http.RequestLogger;
import outlog.toolbox.Clock;

import toolbox.misc.LogFormatter;

/**
 * Logger sending logs to remote outlog server.
 * 
 * @author yaming
 */
public class RemoteLogger implements Logger {

    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(RemoteLogger.class.getName());

    private String productId;

    private InetSocketAddress[] sinkAddrs;

    private long maxFlushInterval = 100;

    private long defaultFullTimes = 100;

    private ArrayBlockingQueue<String> sendQueue;

    private Sender sender;

    private class Sender extends Thread {
        Socket socket = null;

        BufferedWriter writer = null;

        public Sender() {
            super("outlog-sender");
            this.setDaemon(true);
        }

        private int sinkIndex = 0;

        private void doShutDownWork() {
            Runtime.getRuntime().addShutdownHook(new Thread() {
                public void run() {
                    flush();
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            });
        }

        public void run() {
            doShutDownWork();

            while (true) {
                try {
                    socket = new Socket();
                    InetSocketAddress sinkAddr = sinkAddrs[sinkIndex];
                    socket.connect(sinkAddr);
                    LOG.log(Level.INFO, "[outlog] Connected to server "
                            + sinkIndex + "/" + sinkAddrs.length + ": "
                            + sinkAddr);

                    writer = new BufferedWriter(new OutputStreamWriter(socket
                            .getOutputStream(), "UTF-8"), 16392);

                    // send the product id first for a new connection
                    writer.write(productId);
                    writer.newLine();
                    writer.flush();
                    
                    // 为了避免重连接阶段因为log 打满queue 而造成继续重连接现象
                    boolean newConn = true;

                    long lastFlush = Clock.currentTimeMillis();
                    boolean empty = true;
                    while (true) {
                        String message = sendQueue.poll(500l,
                                TimeUnit.MILLISECONDS);
                        if (message != null) {
                            writer.write(message);
                            writer.newLine();
                            empty = false;
                        }
                        
                        // 最长刷新时间
                        if (!empty
                                && (Clock.currentTimeMillis() - lastFlush) >= maxFlushInterval) {
                            writer.flush();
                            lastFlush = Clock.currentTimeMillis();
                            empty = true;
                        }
                        
                        if (fullTimes > defaultFullTimes) {
                            if (sinkAddrs.length > 1 && !newConn) {
                                LOG.log(Level.WARNING,
                                        "failed upload too many "
                                                + "times, change server."
                                                + fullTimes);
                                fullTimes = 0;
                                break;
                            }
                            fullTimes = 0;
                            newConn = false;
                        }
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Exception during sending log to "
                            + sinkAddrs[sinkIndex] + ", will reconnect later.",
                            e);
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException ex) {}

                } finally {
                    if (writer != null) {
                        try {
                            writer.flush();
                            writer.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    LOG.info("Closing socket.");
                    try {
                        if (socket != null)
                            socket.close();
                    } catch (Exception e) {}
                }
                sinkIndex = (sinkIndex + 1) % sinkAddrs.length;
                updateHostPort();
            }
        }
    }

    private int fullTimes = 0;

    private LocalBufferFile localBuffer = null;

    private void enqueue(String message) {
        if (!sendQueue.offer(message)) {
            if (fullTimes % 100000 == 0)
                LOG.log(Level.INFO, "Unable to enqueue log: " + message
                        + ", send queue is full,num " + fullTimes);
            fullTimes++;
            if (localBuffer == null)
                localBuffer = new LocalBufferFile(sendQueue);
            try {
                synchronized (localBuffer) {
                    localBuffer.write(message);
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else {
            fullTimes = fullTimes > 0 ? fullTimes - 1 : 0;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        RemoteLogger rl = new RemoteLogger("test", "localhost:2020");
        while (true) {
            Thread.sleep(100);
            rl.log("hello,test!");
        }
    }

    /**
     * @param productId
     * @param addressString
     *            The address(es) of logging sink. Supports multiple addresses,
     *            like "host1:2323,host2:2323,host3:4848". When more than one
     *            sinks are given, the logs will be sent to the first server
     *            initially. If the current server fails, will select next
     *            server in a round-robin manner.
     */
    public RemoteLogger(String productId, String addressString) {
        this(productId, addressString, RequestLogger.DEFAULT_QUEUE_SIZE);
    }

    /**
     * @param productId
     * @param addressString
     *            The address(es) of logging sink. Supports multiple addresses,
     *            like "host1:2323,host2:2323,host3:4848". When more than one
     *            sinks are given, the logs will be sent to the first server
     *            initially. If the current server fails, will select next
     *            server in a round-robin manner.
     * @param maxSendQueueSize
     * @param batchSize
     */
    private String[][] hostPortArray = null;

    public RemoteLogger(String productId, String addressString,
            int maxSendQueueSize) {
        this.productId = productId;
        String[] addrStrings = vsplit(addressString, ",");
        sinkAddrs = new InetSocketAddress[addrStrings.length];
        hostPortArray = new String[addrStrings.length][];
        for (int i = 0; i < addrStrings.length; i++) {
            hostPortArray[i] = new String[2];
        }
        for (int i = 0; i < sinkAddrs.length; i++) {
            String[] split = vsplit(addrStrings[i].trim(), ":");
            sinkAddrs[i] = new InetSocketAddress(split[0], Integer
                    .parseInt(split[1]));
            hostPortArray[i][0] = split[0];
            hostPortArray[i][1] = split[1];
        }
        sendQueue = new ArrayBlockingQueue<String>(maxSendQueueSize);
        init();
    }

    /* 更新主机解析 */
    private void updateHostPort() {
        if (hostPortArray == null)
            return;
        if (sinkAddrs == null || sinkAddrs.length < hostPortArray.length)
            sinkAddrs = new InetSocketAddress[hostPortArray.length];
        for (int i = 0; i < hostPortArray.length; i++) {
            sinkAddrs[i] = new InetSocketAddress(hostPortArray[i][0], Integer
                    .valueOf(hostPortArray[i][1]));
        }
        return;
    }

    private void init() {
        sender = new Sender();
        sender.start();
    }

    public void flush() {
        if (sender.writer != null) {
            try {
                sender.writer.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Replace the '\r', '\n' with space.
     * 
     * @param s
     * @return
     */
    public static String replaceLrln(String s) {
        int len = s.length();
        StringBuilder buf = null;
        int start = 0;
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c == '\r' || c == '\n') {
                if (buf == null)
                    buf = new StringBuilder();
                if (i > start) {
                    buf.append(s.substring(start, i));
                }
                buf.append(' ');
                start = i + 1;
            }
        }

        if (buf == null) {
            return s;
        } else {
            if (start < len) {
                buf.append(s.substring(start));
            }
            return buf.toString();
        }
    }

    public void log(String message) {
        message = replaceLrln(message);
        enqueue(message);
    }

    public String[] vsplit(String str, String split, int count) {
        Vector<String> vector = new Vector<String>();
        int index = -1;
        int offset = 0;
        int cnt = 1;
        while (cnt < count && (index = str.indexOf(split, index + 1)) != -1) {
            vector.addElement(str.substring(offset, index));
            offset = index + 1;
            ++cnt;
        }
        vector.addElement(str.substring(offset));
        return vector.toArray(new String[0]);
    }

    public String[] vsplit(String str, String split) {
        return vsplit(str, split, Integer.MAX_VALUE);
    }
}
