package outlog.toolbox;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.CoWorkUtils;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;
import toolbox.misc.LogFormatter;

public class GetInputFileList {
    private static final Logger LOG = LogFormatter.getLogger(GetInputFileList.class.getName());
    private MatchPathFilter pathFilter = new MatchPathFilter(); //默认pathfilter是正则表达式匹配的。
    public GetInputFileList() {}
    public GetInputFileList(Class<? extends MatchPathFilter> matchClass)
            throws InstantiationException, IllegalAccessException{
        pathFilter = matchClass.newInstance();
    }
    public GetInputFileList(Class<? extends MatchPathFilter> matchClass, String rule) 
            throws InstantiationException, IllegalAccessException{
        pathFilter = matchClass.newInstance();
        pathFilter.setRule(rule);
    }
    
    public Path prepareInput(String inpath, String rule, ToolContext context) throws IOException{
        String TOOL_NAME= GetInputFileList.class.getSimpleName();
        pathFilter.setRule(rule);
        
        FileSystem fs = context.getFileSystem();
        Path inputPath = 
            MapReduceHelper.createTempDir(fs, context.tempPath(TOOL_NAME), "temp");
        
        fs.mkdirs(inputPath);
        FileInfo[] files = fs.listFiles(context.path(inpath), pathFilter);
        if(files != null){
            int idx = 0;
            LOG.log(Level.INFO, "length : " + files.length);
            for(FileInfo f : files){
                if(fs.isDirectory(f.getPath())) {continue;} //跳过目录。
                Path part = inputPath.cat(CoWorkUtils.getPartID(idx));
                idx++;
                fs.link(f.getPath(), part);
                LOG.log(Level.INFO,f.getPath().getAbsolutePath()
                        + " link to " + part.getAbsolutePath());
            }
        }else{
            LOG.log(Level.WARNING, "can not find any file at " + inpath + " on condition : " + rule);
        }
        return inputPath;
    }
    
    public static void main(String[] args){
        GetInputFileList inputTool = new GetInputFileList();
        try {
            inputTool.prepareInput(".", ".*l.*", new ToolContext("local"));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
