package outlog.logging;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Logger printing logs to local
 * 
 * @author yaming
 */
public class LocalLogger implements Logger {

    private SimpleDateFormat timeFormat = new java.text.SimpleDateFormat(
            "yyyyMMddHHmmss");

    public void log(String message) {
        message = message.replaceAll("\r", "");
        message = message.replaceAll("\n", "");
        Calendar cal = Calendar.getInstance();
        System.out.println(timeFormat.format(cal.getTime()) + "\t" + message);
    }

    public void flush() {
        
    }

}
