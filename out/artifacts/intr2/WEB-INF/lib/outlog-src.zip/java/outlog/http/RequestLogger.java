/**
 * @(#)RequestLogger.java, 2007-11-12. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outlog.http;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import outlog.logging.LocalLogger;
import outlog.logging.RemoteLogger;
import outlog.toolbox.Clock;
import outlog.toolbox.analyzer.Filter;
import toolbox.misc.LogFormatter;
import toolbox.text.util.StringUtils;

/**
 * RequestLogger based on outlog logger. Code migrated from request-logger project.
 * @author zhangkun
 *
 */
public class RequestLogger {
    private static final Logger LOG = LogFormatter.getLogger(RequestLogger.class.getName());
    private String userIdCookieName = "OUTFOX_SEARCH_USER_ID";
    private String userIdAttrName = "outlog.http.userid";
    private final Random rand = new Random();
    private static final int thirtyYears = 3600 * 24 * 365 * 30;
    private String productName = "NONAME";
    private String userNameAttributeName = "__email__";
    private String domain = null;
    private String path = null;
    private String sinkAddrs;
    private final Set<String> visibleAttributes = new HashSet<String>();
    private final Set<String> unloggedParameters = new HashSet<String>();
    /*private SimpleDateFormat timeFormat1 = new java.text.SimpleDateFormat(
            "yyyyMMddHHmmss");*/
    
    public static int DEFAULT_QUEUE_SIZE = 8 << 10;
    private int sendQueueMaxSize = DEFAULT_QUEUE_SIZE;
    public void setUserNameAttributeName(String name) {
        this.userNameAttributeName = name;
    }
    public void setCookieName(String name) {
        this.userIdCookieName = name;
    }
    public String getCookieName() {
        return this.userIdCookieName;
    }
    public void setUserIdAttrName(String userIdAttrName) {
        this.userIdAttrName = userIdAttrName;
    }
    /**
     * Get the userid cookie from the request. Return null if not exist.
     * @param req
     * @return
     */
    public Cookie getUserIdCookie(HttpServletRequest req) {
        Cookie[] cookies = req.getCookies();
        Cookie cookie = null;
        if(cookies != null) {
            for(Cookie c : cookies) {
                if(userIdCookieName.equals(c.getName())) {
                    cookie = c;
                    break;
                }
            }
        }
        if (cookie == null) {
            Object userIdCookie = req.getAttribute(userIdAttrName);
            if (userIdCookie != null) 
                return (Cookie) userIdCookie;
        }
        return cookie;
    }
    /**
     * Generate a userid cookie. 
     * that needs to be written in the response.
     * @param req
     * @return
     */
    public Cookie generateUserIdCookie(HttpServletRequest req) {
        Cookie cookie = new Cookie(this.userIdCookieName, rand.nextInt() + "@" + req.getRemoteAddr());
        cookie.setMaxAge(thirtyYears);
        if(domain != null) {
            cookie.setDomain(domain);
            if (path != null && !"".equals(path))
                cookie.setPath(path);
        }
        req.setAttribute(userIdAttrName, cookie);
        return cookie;
    }
    public void setCookieDomain(String domain) {
        this.domain = domain;
    }
    public void setPath(String path){
        this.path = path;
    }
    
    public void setSendQueueMaxSize(int size) {
        sendQueueMaxSize = size;
    }
    
    public void init() {
        if (StringUtils.isEmptyString(sinkAddrs.trim())) {
            logger = new LocalLogger();
            LOG.log(Level.INFO, "[requestLogger] localLogger initialized. productName : " 
                    + productName);
        } else {
            logger = new RemoteLogger(productName, sinkAddrs, sendQueueMaxSize);
            LOG.log(Level.INFO, "[requestLogger] requestLogger initialized. productName : " 
                    + productName + " sinkAddr : " + sinkAddrs);
        }
    }
    
    public void setProductName(String name) {
        this.productName = name;
    }
    /**
     * Set the list of request attributes that can be displayed.
     * Default is no attribute is displayed.
     * @param attrs
     */
    public void setVisibleAttributes(List<String> attrs) {
        visibleAttributes.clear();
        visibleAttributes.addAll(attrs);
    }
    /**
     * Set the list of request parameters that need not to be logged.
     * Default is all parameters are logged.
     * @param params
     */
    public void setUnloggedParameters(List<String> params) {
        unloggedParameters.clear();
        unloggedParameters.addAll(params);
    }
    private outlog.logging.Logger logger = null;
    /**
     * Set the address of logging sink. Supports multiple addresses, like "host1:2323,host2:2323,host3:4848".
     * When more than one sinks are given, the logs will be sent to the first server initially. 
     * If the current server fails, will select next server in a round-robin manner.
     * @param addr
     */
    public synchronized void setSinkAddr(String addrString) {
        this.sinkAddrs = addrString;
    }
    
    private static void append(StringBuilder buffer, String key, String value) {
        buffer.append("\t");
        buffer.append(key);
        buffer.append("=");
        buffer.append(value);
    }
    
    private void enqueue(String log) {
        if (logger != null) {
            logger.log(log);
        } else {
            LOG.warning("RequestLogger is not initialized");
        }
    }
    
    public void log(String category, HttpServletRequest req, HttpServletResponse res) {
        log(category, null, null, req, res, null);
    }
   
    /**
     * Log an HTTP request "AS IS".
     * @param category
     * @param req
     * @param res
     * @see RequestLogger#log(String, String, String, HttpServletRequest, HttpServletResponse, String)
     */
    public void log(String category, HttpServletRequest req, HttpServletResponse res, String message) {
        log(category, null, null, req, res, message);
    }

    public void log(String category, String serverURLEncoding, String urlEncoding, HttpServletRequest req, HttpServletResponse res) {
        log(category, serverURLEncoding, urlEncoding, req, res, null);
    }
    private static String escape(String text) {
        if(text == null) {
            return "NULL";
        }
        int length = text.length();
        StringBuilder buffer = new StringBuilder(length);
        for(int i = 0; i < length; i++) {
            char ch = text.charAt(i);
            switch(ch) {
                case '\t': buffer.append("\\t"); break;
                case '\n': buffer.append("\\n"); break;
                case '\r': buffer.append("\\r"); break;
                case '[': buffer.append("\\["); break;
                case ']': buffer.append("\\]"); break;
                case '\\': buffer.append("\\\\"); break;
                default: buffer.append(ch);
            }
        }
        return buffer.toString();
    }
    /**
     * Log an HTTP request, recording the user_id in cookie, user's IP and the request's all parameters.
     * Use this method if the parameters in the request is not corrected decoded and needs a transcode.
     * This method will get the parameters by translate them from <b>serverURLEncoding</b> to <b>urlEncoding</b>.
     * @param category
     * @param serverURLEncoding the default URL encoding of the web server
     * @param urlEncoding the URL encoding of this request
     * @param req the HttpServletRequest
     * @param res the HttpServletResponse
     * @param message any additional messages you want to log. It can be null, which means no message
     */
    public void log(String category, String serverURLEncoding, String urlEncoding, HttpServletRequest req, HttpServletResponse res, String message) {
        StringBuilder buffer = new StringBuilder();
        buffer.append(Clock.currentTimeMillis());
        buffer.append("\t");
        
        buffer.append(category);
        for( Enumeration attrNames = req.getParameterNames(); attrNames.hasMoreElements(); ) {
            String attrName = (String) attrNames.nextElement();
            if(!unloggedParameters.contains(attrName)) {
                String value = req.getParameter(attrName);
                try {
                    if(serverURLEncoding != null && urlEncoding != null) {
                        value = new String(value.getBytes(serverURLEncoding), urlEncoding);
                    }
                    append(buffer, escape(attrName), escape(value));
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Exception", e);
                }
            }
        }
        for( Enumeration attrNames = req.getAttributeNames(); attrNames.hasMoreElements(); ) {
            String attrName = (String) attrNames.nextElement();
            if(visibleAttributes.contains(attrName)) {
                buffer.append("\t[@" + escape(attrName) + "=" + escape(req.getAttribute(attrName).toString()) + "]");
            }
        }
        
        String ip = getRequestIP(req);
        buffer.append("\t[ip=" + ip + "]");
        Cookie cookie = getUserIdCookie(req);
        if(cookie == null) {
            cookie = generateUserIdCookie(req);
            res.addCookie(cookie);
        }
        buffer.append("\t[basePath=" + req.getServletPath() + "]");
        buffer.append("\t[userid="+escape(cookie.getValue())+"]");
        
        Object userName = req.getAttribute(userNameAttributeName);
        buffer.append("\t[username=" + escape(userName == null ? null : userName.toString()) + "]");
        buffer.append("\t[useragent="+ escape(req.getHeader("User-Agent"))+"]");
        buffer.append("\t[referer=" + escape(req.getHeader("Referer")) + "]");
        if(message != null) {
            buffer.append("\t[["+escape(message)+"]]");
        }
        enqueue(buffer.toString());
    }

    protected String getRequestIP(HttpServletRequest request) {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String ip = httpRequest.getRemoteAddr();
        if(Filter.isCompanyIp(ip)){
            ip = httpRequest.getHeader("x-forwarded-for");
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = httpRequest.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = httpRequest.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = httpRequest.getRemoteAddr();
            }
        }
        return ip;
    }    
}
