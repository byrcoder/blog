package outlog.server;

import java.io.File;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.util.Properties;
import java.util.logging.Level;

import org.apache.mina.common.TransportType;
import org.apache.mina.registry.Service;
import org.apache.mina.registry.ServiceRegistry;
import org.apache.mina.registry.SimpleServiceRegistry;
import org.joda.time.DateTime;

import outlog.toolbox.Clock;
import outlog.toolbox.Helper;

import toolbox.misc.LogFormatter;

/**
 * Construct the server end of outlog.
 * 
 * @author yaming
 */
public class LogSink {
    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(LogSink.class.getName());

    private LogSinkHandler handler;
    
    public void exec(String[] localPath, int port, int udpPort, int bufHour,
            int queueSize, int upload, String dfsName, String dfsPath,
            String host, boolean mergeSmallFile, int writeInterval,
            String smsGroup) throws Exception {
        
        for (int i = 0; i < localPath.length; ++i) {
            File localDir = new File(localPath[i]);
            localPath[i] = localDir.getAbsolutePath();
            if (!localDir.exists()) {
                localDir.mkdirs();
            }
            if (!localDir.isDirectory()) {
                LOG.log(Level.SEVERE, "Local path " + localPath
                        + " is not a direstory!");
                throw new Exception("Local path " + localPath
                        + " is not a direstory!");
            }
        }
        handler = new LogSinkHandler(localPath, bufHour, queueSize, upload,
                dfsName, dfsPath, host, mergeSmallFile, writeInterval, smsGroup);      
        
        ServiceRegistry registry = new SimpleServiceRegistry();

        Service service = new Service("logsink", TransportType.SOCKET, port);
        registry.bind(service, new LogSinkProtocolProvider(handler));
        LOG.info("Mina tcp service registered at " + port);

        if (udpPort > 0) {
            Service udp = new Service("logsink", TransportType.DATAGRAM,
                    udpPort);
            registry.bind(udp, new LogSinkProtocolProvider(handler));
            LOG.info("Mina udp service registered at " + udpPort);
        }
    }

    public static void usage() {
        System.out.println("some paramaters not be set in logsink.cfg.");
    }

    /**
     * Main method, collect properties in logsink.cfg and execute a log sink.
     * 
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        FileInputStream istream = new FileInputStream("logsink.cfg");
        Properties props = new Properties();
        props.load(istream);
        istream.close();

        String[] localPath = props.getProperty("localpath").split(" ");
        int port = Integer.parseInt(props.getProperty("port", "2020"));
        int udpPort = Integer.parseInt(props.getProperty("udpPort", "-1"));
        int bufHour = Integer.parseInt(props.getProperty("localcopy", "48"));
        int queueSize = Integer.parseInt(props.getProperty("maxqueuesize",
                "100000"));
        int writeInterval = Integer.parseInt(props.getProperty("writeInterval",
                "10"));
        int upload = Integer.parseInt(props.getProperty("uploadThread", "0"));
        boolean mergeSmallFile = Boolean.valueOf(props.getProperty(
                "mergeSmallFile", "false"));

        String dfsName = props.getProperty("dfsname");
        String dfsPath = props.getProperty("dfspath");

        String host = InetAddress.getLocalHost().getHostName() + ":" + port;
        String smsGroup = props.getProperty("smsGroup", "liujg");

        if (null == localPath || localPath.length <= 0
                || (upload > 0 && (null == dfsName || null == dfsPath))) {
            usage();
            return;
        }

        LOG.info("Executing LogSink....");
        try {
            new LogSink().exec(localPath, port, udpPort, bufHour, queueSize,
                    upload, dfsName, dfsPath, host, mergeSmallFile,
                    writeInterval, smsGroup);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
        // 读取操作配置
        LogProtocolDecoder.readConfigThread();
    }

}
