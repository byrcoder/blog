package outlog.server;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.TimeWritable;
import odis.serialize.lib.UTF8Writable;

import org.joda.time.DateTime;

import outlog.toolbox.Clock;
import outlog.toolbox.Helper;
import toolbox.misc.LogFormatter;

/**
 * ProtocolHanderAdapter of mina, main body of outlog server.
 * 
 * @author yaming
 */
public class LocalWriter extends Thread {

    private static final java.util.logging.Logger LOG = LogFormatter
            .getLogger(LocalWriter.class.getName());

    private LinkedList<String> dfsUploadQueue = new LinkedList<String>();

    // local buffer path
    private String[] localPath = null;

    private int bufHour = 24;

    private int maxQueueSize = 100000;

    // sms paras
    private String smsGroup = null;

    private String host = null;

    private ArrayBlockingQueue<Log> logQueue = null;

    private HashMap<String, SequenceFile.Writer> writers = new HashMap<String, SequenceFile.Writer>();

    private IFileSystem localFs = null;

    private int writeInterval = 10 * 60 * 1000;

    public static void main(String[] args) {
        LocalWriter lw = null;
        try {
            lw = new LocalWriter(null, 1, 2, " ", 10, " ");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        lw.clearExpiredLocalCopy();
        DateTime now = new DateTime(Clock.currentTimeMillis());
        System.out.println(Helper.yyyyMMddHHmmss.print(now));
        return;
    }

    public LinkedList<String> getUploadQueue() {
        return dfsUploadQueue;
    }

    public void run() {
        this.setUncaughtExceptionHandler(new ExitExceptionHandler());

        TimeWritable t = new TimeWritable();
        UTF8Writable c = new UTF8Writable();

        DateTime prevDate = new DateTime(Clock.currentTimeMillis());
        clearExpiredLocalCopy(prevDate, true);
        // main loop
        while (true) {
            DateTime now = new DateTime(Clock.currentTimeMillis());

            // check date to see if a new circle should be started
            if (now.getMillis() - prevDate.getMillis() + prevDate.getMillis()
                    % writeInterval >= writeInterval) {
                LOG.info("A new round file: " + now.toString());

                // close all writers, so that new log files will be open
                synchronized (writers) {
                    for (String p: writers.keySet()) {
                        try {
                            writers.get(p).close();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        synchronized (dfsUploadQueue) {
                            dfsUploadQueue.add(p);
                            dfsUploadQueue.notify();
                        }
                    }
                    writers.clear();
                }
                clearExpiredLocalCopy();

                prevDate = now;
            }

            // Start to process logs, poll from the logQueue and write it.
            Log next = null;
            try {
                next = logQueue.poll(500L, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {}
            if (null == next) {
                // 手动释放状态下，关闭序列化文件
                if (!LogProtocolDecoder.runFlag) {
                    synchronized (writers) {
                        for (String p: writers.keySet()) {
                            try {
                                writers.get(p).close();
                            } catch (IOException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        writers.clear();
                    }
                    LOG.info("operator closes the outlog server successly!");
                    System.exit(0);
                }
                continue;
            }
            String productId = next.getProductId();
            synchronized (writers) {
                SequenceFile.Writer writer = writers.get(productId);
                if (null == writer) {
                    // open log file
                    String logFileRelativePath = productId + "/" + productId
                            + "." + Helper.yyyyMMddHHmmss.print(now);

                    int pathPos = (productId.hashCode() & Integer.MAX_VALUE)
                            % localPath.length;
                    File localPathDir = new File(localPath[pathPos], productId);
                    if (!localPathDir.exists()) {
                        localPathDir.mkdirs();
                    }

                    File localLogFile = new File(localPath[pathPos],
                            logFileRelativePath);
                    if (localLogFile.exists())
                        localLogFile.delete();

                    try {
                        writer = new SequenceFile.CompressedWriter(localFs,
                                new Path(localLogFile), TimeWritable.class,
                                UTF8Writable.class, false);
                        writers.put(productId, writer);
                        LOG.info("===Start logging to " + logFileRelativePath);
                    } catch (Throwable e) {
                        LOG.log(Level.SEVERE,
                                "Cannot open a writer for the log file "
                                        + localLogFile.getAbsolutePath(), e);
                        Helper.SmsSend(smsGroup, new StringBuilder(
                                "Cannot open a writer for the log file ")
                                .append(localLogFile.getAbsolutePath()).append(
                                        " at ").append(host).append(" ")
                                .append(e.getMessage()));
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e1) {
                            // TODO Auto-generated catch block
                            e1.printStackTrace();
                        }
                    }
                }
                t.set(next.getTimestamp());
                c.set(next.getMessage());
                synchronized (writer) {
                    try {
                        writer.write(t, c);
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            UdpBroadcaster.getInstance().add(next);
        }
    }

    /**
     * Clear all expired local copy.
     */
    private void clearExpiredLocalCopy() {
        clearExpiredLocalCopy(new DateTime(Clock.currentTimeMillis()), false);
    }

    private void clearExpiredLocalCopy(DateTime now, boolean start) {
        String expirePoint = Helper.yyyyMMddHH.print(now);
        expirePoint = MergeSmallFile.getDate(expirePoint, 3);
        String expirePointStart = Helper.yyyyMMddHHmmss.print(now);

        for (String iterLP: localPath) {
            File localDir = new File(iterLP);
            for (File dir: localDir.listFiles()) {
                if (!dir.isDirectory()) {
                    continue;
                }

                Pattern p = Pattern.compile(dir.getName() + ".(\\d{14}).a");
                Pattern addP = Pattern.compile(dir.getName() + ".(\\d{14})");

                for (File file: dir.listFiles()) {
                    Matcher m = p.matcher(file.getName());
                    if (m.matches()
                            && m.group(0).compareTo(
                                    dir.getName() + "." + expirePoint) < 0)
                        file.delete();

                    // 启动时处理之前未上传完的文件
                    if (start) {
                        m = addP.matcher(file.getName());
                        if (m.matches()
                                && m.group(0).compareTo(
                                        dir.getName() + "." + expirePointStart) < 0) {
                            LOG.info("add exists file " + file.getName()
                                    + " to upLoadQueue!");
                            synchronized (dfsUploadQueue) {
                                dfsUploadQueue.add(dir.getName());
                                dfsUploadQueue.notify();
                            }
                        }
                    }// end of start

                }// end of matcher
            }// end of file
        }// end of path
    }

    /**
     * Put a Log to logQueue, the log is pushed by the LogProtocolDecoder.
     * 
     * @param log
     */
    private long drop = 0L;

    public void enqueue(Log log) {
        if (!logQueue.offer(log)) {
            if (++drop % maxQueueSize == 0) {
                LOG.warning("Max queue size reached, drop log..." + drop);
            }
        } else {
            // ---- Todo local buf
        }
    }

    public LocalWriter(String[] localPath, int bufHour, int maxQueueSize,
            String host, int writeInterval, String smsGroup) throws Exception {
        this.localPath = localPath;
        this.bufHour = bufHour;
        this.maxQueueSize = maxQueueSize;
        this.host = host;
        this.smsGroup = smsGroup;
        this.writeInterval = writeInterval * 60 * 1000;

        localFs = FileSystem.getNamed(FileSystem.LOCAL);
        logQueue = new ArrayBlockingQueue<Log>(maxQueueSize);

        UdpBroadcaster.getInstance();
    }

    public class ExitExceptionHandler implements
            Thread.UncaughtExceptionHandler {
        public void uncaughtException(Thread t, Throwable e) {
            System.exit(1);
        }
    }

}
