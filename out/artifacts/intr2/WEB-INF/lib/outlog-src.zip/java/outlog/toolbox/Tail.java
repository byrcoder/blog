/**
 * @(#)Tail.java, 2012-6-11. Copyright 2012 Yodao, Inc. All rights reserved.
 *                YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license
 *                terms.
 */
package outlog.toolbox;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import outlog.server.ITailLogProtocol;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import toolbox.misc.UnitUtils;

/**
 * @author pumpkin\jasonliu
 */
public class Tail {

    private static Long HEATBEAT_LIFE = 2 * 1000L;

    private String HEARTBEAT = "heartbeat";

    private boolean IsConnected = true;

    private String product;

    private String srcServer;

    private int tryPort;

    private String dstServer;

    public Tail(String product, String srcServer, String dstServer) {
        this.product = product;
        this.srcServer = srcServer;
        this.dstServer = dstServer;
    }

    public DatagramSocket connect(int localport) {
        DatagramSocket socket = null;

        tryPort = localport;
        for (; tryPort <= localport + 100; ++tryPort) {
            System.out.println("try to use port " + tryPort);
            try {
                socket = new DatagramSocket(tryPort);
                // 设置超时控制
                try {
                    socket.setSoTimeout(5 * 1000);
                } catch (SocketException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                break;
            } catch (SocketException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }

        // 连接服务器
        HeartBeatThread heartThread = new HeartBeatThread();
        if (!IsConnected) {
            socket.close();
            return null;
        }

        // 服务器正常，启动心跳包线程
        Thread t = new Thread(heartThread);
        t.setDaemon(true);
        t.start();

        return socket;
    }

    public void receiveTailData(DatagramSocket socket) {
        if (null == socket)
            return;
        while (true) {
            if (!IsConnected) {
                System.out.println("check YES connet to the server succussly!");
                break;
            }

            try {
                System.out.println(receive(socket));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                // e.printStackTrace();
            }
        }
    }

    public String receive(DatagramSocket socket) throws IOException {

        byte[] receiveData = new byte[4092];
        DatagramPacket receivePacket = new DatagramPacket(receiveData,
                receiveData.length);
        socket.receive(receivePacket);

        String sentence = new String(receivePacket.getData(), 0, receivePacket
                .getLength());
        return sentence;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

        // TODO Auto-generated method stub
        if (args.length <= 0) {
            System.out.println("usage : outlog.toolbox.Tail list");
            System.out
                    .println("      / outlog.toolbox.Tail -pro XX -server XX");
        }

        String product = "analyzer";
        String srcServer = "localhost";
        String dstServer = "localhost";
        int localport = 2025;

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-pro")) {
                product = args[i + 1];
                i++;
            } else if (args[i].equals("-srcServer")) {
                srcServer = args[i + 1];
                i++;
            } else if (args[i].equals("-dstServer")) {
                dstServer = args[i + 1];
                i++;
            }
        }

        InetAddress inet = null;
        try {
            inet = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        srcServer = inet.getHostAddress();

        Tail t = new Tail(product, srcServer, dstServer);
        t.receiveTailData(t.connect(localport));
    }

    private class HeartBeatThread implements Runnable {

        public ITailLogProtocol[] svrArray = null;

        public String[] dstServers = null;

        public HeartBeatThread() {
            dstServers = dstServer.split(",");
            svrArray = new ITailLogProtocol[dstServers.length];

            int flag = 0;
            for (int i = 0; i < dstServers.length; i++) {
                try {
                    svrArray[i] = (ITailLogProtocol) RPC
                            .getProxy(ITailLogProtocol.class,
                                    new InetSocketAddress(dstServers[i], 2327),
                                    10 * UnitUtils.SECOND);
                    svrArray[i].add(product, srcServer, tryPort);
                } catch (RpcException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    flag++;
                }
            }
            if (dstServers.length == flag)
                IsConnected = false;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Runnable#run()
         */
        @Override
        public void run() {
            // TODO Auto-generated method stub
            while (true) {
                int flag = 0;
                for (int i = 0; i < dstServers.length; i++) {
                    try {
                        svrArray[i]
                                .add(HEARTBEAT + product, srcServer, tryPort);
                    } catch (RpcException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        flag++;
                    }
                }

                // 服务器未启动
                if (dstServers.length == flag) {
                    IsConnected = false;
                    sleep(30 * HEATBEAT_LIFE);
                } else {
                    IsConnected = true;
                    sleep(HEATBEAT_LIFE);
                }
            }
        }
    }// end of HeartBeatThread

    public boolean getIsConnected() {
        return IsConnected;
    }

    public static void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
