/**
 * @(#)DealProperties.java, 2012-8-15. Copyright 2012 Yodao, Inc. All rights
 *                          reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                          subject to license terms.
 */
package outlog.toolbox;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import odis.io.IFileSystem;
import toolbox.maintain.alarm.SmsSender;

/**
 * @ read and save all properties operation
 * 
 * @author jasonliu
 */
public class FileFlagProperties {

    public static Properties loadProperties(String product) {
        try {
            if (!product.contains("\\"))
                product = "./flag" + product;

            File f = new File(product + ".cfg");
            File p = new File(f.getParent());
            if (!p.exists())
                p.mkdirs();
            if (!f.exists())
                f.createNewFile();
            FileInputStream istream = new FileInputStream(f);
            Properties props = new Properties();
            props.load(istream);
            istream.close();
            return props;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void saveProperties(Properties p, String product) {
        try {
            if (!product.contains("\\"))
                product = "./flag" + product;
            File f = new File(product + ".cfg");
            File pa = new File(f.getParent());
            if (!pa.exists())
                pa.mkdirs();
            if (!f.exists())
                f.createNewFile();
            FileOutputStream file = new FileOutputStream(product + ".cfg");
            p.save(file, "update property!");
            file.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            SmsSender.send(new String[] {
                "liujg"
            }, "writer local cfg error");
        }
        return;
    }

    public static boolean hadReadedFile(Properties p, String file) {
        boolean flag = Boolean.valueOf(p.getProperty(file, "false"));
        return flag;
    }
}
