/**
 * @(#)Clock.java, 2007-11-12. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outlog.toolbox;

/**
 * Use this class instead of {@link System#currentTimeMillis()} to support 
 * @author river
 *
 */
public class Clock {

    public static interface ClockIface {
        public long currentTimeMillis();
    }
    
    public static class StandardClock implements ClockIface {
        public long currentTimeMillis() {
            return System.currentTimeMillis();
        }
    }

    private static ClockIface clock = new StandardClock();
    
    public static void setClock(ClockIface impl) { clock = impl; }
    
    public static long currentTimeMillis() {
        return clock.currentTimeMillis();
    }
    
}
