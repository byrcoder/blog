/**
 * @(#)LocalFile.java, 2012-7-24. Copyright 2012 Yodao, Inc. All rights
 *                     reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is subject
 *                     to license terms.
 */
package outlog.logging;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.net.InetSocketAddress;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import toolbox.misc.LogFormatter;

/**
 * Logger printing logs to local buffer to send remote outlog server.
 * 
 * @author jasonliu
 */
public class LocalBufferFile {
    private static final Logger LOG = LogFormatter
            .getLogger(LocalBufferFile.class.getName());

    static private int MAXBUFFERNUM = 2000;

    static private int MINBUFFERNUM = 100;

    public String[] pool = new String[MAXBUFFERNUM];

    private int poolNum = 0;

    static private int CrontabTime = 10;

    static private int lineSeparatorLength = 1;

    private String path = null;

    private ArrayBlockingQueue<String> sendQueue;

    private ArrayBlockingQueue<String> writerBufferQueue;

    private BufferedWriter writer = null;

    private LocalBufferSender sender;

    private LocalBufferWriter writerBuffer;

    static SimpleDateFormat fullFormat = new SimpleDateFormat("yyyyMMddHHmm");

    static SimpleDateFormat full = new SimpleDateFormat("yyyyMMddHHmmss");

    /**
     * @param sendQueue
     */
    public LocalBufferFile(ArrayBlockingQueue<String> sendQueue) {
        // TODO Auto-generated constructor stub
        this.sendQueue = sendQueue;
        this.writerBufferQueue = new ArrayBlockingQueue<String>(MINBUFFERNUM);
        File f = new File("./requestlogbuffer");
        if (!f.exists())
            f.mkdir();
        writerBuffer = new LocalBufferWriter();
        writerBuffer.setDaemon(true);
        writerBuffer.start();

        sender = new LocalBufferSender();
        sender.setDaemon(true);
        sender.start();
    }

    public static String convertToTimeFormatPath(String date) {
        String path = "./requestlogbuffer/";
        try {
            path += Long.valueOf(date) / 100;
            path += (Long.valueOf(date) % 10) * 10;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return path;
    }

    /**
     * 写入缓存
     * 
     * @throws IOException
     */
    public void write(String message) throws IOException {
        // TODO Auto-generated method stub
        writerBufferQueue.offer(message);
    }

    /*
     * @蓄水池均匀采样函数 以 poolNum+1分之pool.length的概率决定是否要替换
     * @以pool.length/1的概率替换池中的数
     */
    private static Random r = new Random();

    public void equalitySamplerPool(String[] pool, int poolNum, String message) {
        if (null == pool || null == message)
            return;
        if (poolNum < pool.length)
            pool[poolNum] = message;
        else {
            int p = r.nextInt(poolNum);
            if (p < pool.length) {
                p = r.nextInt(pool.length);
                pool[p] = message;
            }
        }
    }

    private class LocalBufferWriter extends Thread {
        public void run() {
            while (true) {
                String message = writerBufferQueue.poll();
                if (message == null) {
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    continue;
                }

                String nowPath = convertToTimeFormatPath(fullFormat
                        .format(new Date()));
                if (path == null)
                    path = nowPath;

                if (path.equals(nowPath)) {
                    equalitySamplerPool(pool, poolNum, message);
                    poolNum++;
                } else {
                    File f = new File(path);
                    if (!f.exists())
                        try {
                            f.createNewFile();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }

                    try {
                        writer = new BufferedWriter(new FileWriter(path));

                        int min = pool.length > poolNum ? poolNum : pool.length;
                        for (int i = 0; i < min; i++) {
                            writer.write(pool[i]);
                            writer.newLine();
                        }
                        writer.flush();
                        poolNum = 0;
                        equalitySamplerPool(pool, poolNum, message);
                        path = nowPath;
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private class LocalBufferSender extends Thread {

        private File outPath = null;

        private RandomAccessFile fread = null;

        private long readStart = 0;

        public LocalBufferSender() {
            outPath = new File("./requestlogbuffer");
        }

        public void run() {

            while (true) {
                String[] fList = outPath.list();
                Arrays.sort(fList);
                try {
                    if (fList.length == 0) {
                        Thread.sleep(60 * 1000);
                        continue;
                    }

                    if (fList.length > 100) {
                        for (int i = 0; i < fList.length - 100; i++) {
                            File tmpFile = new File("./requestlogbuffer/"
                                    + fList[i]);
                            tmpFile.delete();
                            LOG.log(Level.INFO,
                                    "delete unnecessary requestlogbuffer file:"
                                            + tmpFile.getAbsolutePath());

                        }
                    }

                    int beg = fList.length > 100 ? fList.length - 100 : 0;

                    for (int i = beg; i < fList.length;) {
                        if (fList[i].equals(path)) {
                            i++;
                            continue;
                        } else {
                            boolean flag = sendLogBufferFile(outPath, fList[i]);
                            // 缓存日志发送完毕后本地删除
                            if (flag) {
                                File tmpFile = new File("./requestlogbuffer/"
                                        + fList[i]);
                                tmpFile.delete();
                                LOG.log(Level.INFO,
                                        "delete dealed requestlogbuffer file:"
                                                + tmpFile.getAbsolutePath());
                                readStart = 0;
                                i++;
                            } else {
                                Thread.sleep(5000);
                            }
                        }
                    }
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        private boolean sendLogBufferFile(File outPath, String file) {
            try {
                fread = new RandomAccessFile(outPath + "/" + file, "r");
                fread.seek(readStart);
                String message;
                while ((message = fread.readLine()) != null) {

                    if (message.length() < 1) {
                        readStart += lineSeparatorLength;
                        lineSeparatorLength++;
                        continue;
                    }
                    if (!sendQueue.offer(message)) {
                        fread.close();
                        return false;
                    }
                    readStart += message.length() + lineSeparatorLength;
                    fread.seek(readStart);
                    Thread.sleep(10);
                }
                readStart = 0;
                fread.close();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return true;
        }
    }

    public static void main(String[] args) {
        ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(
                MAXBUFFERNUM);
        LocalBufferFile sender = new LocalBufferFile(queue);
        return;
    }
}
