package outlog.http;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 记录用户信息的filter
 * 
 * 1. 记录用户来源
 * 根据request里面的keyfrom|Referer判断用户来源，并记录到内存cookie(user-from)中，便于其它产品进行统计
 * 同时，将用户来源的信息塞入request的attribute中（SessionUserFrom)，便于打AnalyzerLog
 * 2. 生成用户userid
 *
 * @author guanbin, hehb
 *
 */
public class UserInfoFilter implements Filter {
    private String domain = ".youdao.com";

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp,
            FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;

        traceSessionUserFrom(request, response);
        traceFirstComeFrom(request, response);
        traceSessionFromPage(request, response);
        traceUserId(request, response);
        chain.doFilter(request, response);
    }
    
    /*
     * 检查cookie是否包含 cookieName的cookie，如果有,将其值添加到request的属性attributeName
     */
    private boolean checkCookie(HttpServletRequest request, String cookieName,
            String attributeName) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie: cookies) {
                if (cookieName.equals(cookie.getName())) {
                    String value = cookie.getValue();
                    if (value == null)
                        break;
                    value = value.trim();
                    if (value.length() == 0)
                        break;
                    request.setAttribute(attributeName, value); // 塞入attribute，
                                                                // 便于后台统计
                    return true;
                }
            }
        }
        return false;
    }
    
    public static String FCF_COOKIE_NAME = "fcf";
    public static String FCF_LOG_NAME = "firstComeFrom"; // 在analyzer中的log名称
    /**
     * 记录用户第一次从哪里来。将cookie中的fcf塞入request，便于requestLogger统计。
     * @param request
     * @param response
     */
    private void traceFirstComeFrom(HttpServletRequest request, HttpServletResponse response) {
        checkCookie(request, FCF_COOKIE_NAME, FCF_LOG_NAME);
    }
    
    public static String SUF_COOKIE_NAME = "user-from";
    public static String SUF_LOG_NAME = "SessionUserFrom"; // 在analyzer中的log名称
    private static int MAX_LENGTH = 100; // 对cookie value进行截断
    /**
     * 根据keyfrom|Referer统计本次会话的用户来源，并放入内存cookie中。
     * @param request
     * @param response
     */
    private void traceSessionUserFrom(HttpServletRequest request, HttpServletResponse response) {
        // 如果已经存在该cookie，则不做替换
        if (checkCookie(request, SUF_COOKIE_NAME, SUF_LOG_NAME))
            return;

        String userfrom = null;
        String keyfrom = request.getParameter("keyfrom");
        String refered = request.getHeader("Referer");
        if(keyfrom != null) {
            userfrom = keyfrom;
        } else {
            userfrom = refered;
        }
        if(userfrom != null) {
            userfrom = userfrom.trim().replaceAll("[\r\n]", "");
            if(userfrom.length() == 0) return;
            if(userfrom.length() > MAX_LENGTH) userfrom = userfrom.substring(0, MAX_LENGTH);
            Cookie cookie = new Cookie(SUF_COOKIE_NAME, userfrom);
            cookie.setDomain(domain);
            cookie.setMaxAge(-1); // 内存cookie
            cookie.setPath("/");
            response.addCookie(cookie);
            
            request.setAttribute(SUF_LOG_NAME, userfrom); // 塞入attribute，便于后台统计
        }
    }
    
    public static String FP_COOKIE_NAME = "from-page";
    public static String FP_LOG_NAME = "SessionFromPage"; // 在analyzer中的log名称
    /**
     * 根据Referer统计本次Session来源页面。对Referer不做截断，后台统计根据需要进行后期处理。
     * @param request
     * @param response
     */
    private void traceSessionFromPage(HttpServletRequest request, HttpServletResponse response) {
        // 如果已经存在该cookie，则不做替换
        if (checkCookie(request, FP_COOKIE_NAME, FP_LOG_NAME))
            return;

        String fromPage = request.getHeader("Referer");
        if(fromPage != null) {
            fromPage = fromPage.trim().replaceAll("[\r\n]", "");
            if(fromPage.length() == 0) return;
            Cookie cookie = new Cookie(FP_COOKIE_NAME, fromPage);
            cookie.setDomain(domain);
            cookie.setMaxAge(-1); // 内存cookie
            cookie.setPath("/");
            response.addCookie(cookie);
            
            request.setAttribute(FP_LOG_NAME, fromPage); // 塞入attribute，便于后台统计
        }
    }
    
    /**
     * 生成userId cookie。
     * 
     * @param request
     * @param response
     */
    private void traceUserId(HttpServletRequest req, HttpServletResponse res) {
        RequestLogger logger = new RequestLogger();
        logger.setCookieDomain(domain);
        Cookie cookie = logger.getUserIdCookie(req);
        if (cookie == null) {
            cookie = logger.generateUserIdCookie(req);
            res.addCookie(cookie);
        }
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }
    
    @Override
    public void destroy() {}

    @Override
    public void init(FilterConfig arg0) throws ServletException {}

}
