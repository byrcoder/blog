package outlog.toolbox;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * 
 * @author Administrator
 *
 */
public class GetConfig {
    private static String confDir = "./conf/";
    {
        System.out.println(new File(confDir).getAbsolutePath());
    }

    static final private String defaultSplit = " ";

    static final private String defaultMapSplit = ":";


    private static String split = defaultSplit;

    private static String mapSplit = defaultMapSplit;

    public static void  setConfDir(String configDir){
        confDir=configDir;
    }
    
    public static String getConfDir(){
        return confDir;
    }
//    public static boolean setSplitSymbol(String splitSymbol,
//            String mapSplitSymbol) {
//        if (splitSymbol == null || splitSymbol.length() == 0) {
//            FormatLog.warn("splitSymbol empty!!!");
//            return false;
//        }
//        split = splitSymbol;
//        if (mapSplitSymbol == null || mapSplitSymbol.length() == 0) {
//            return false;
//        }
//        setMapSplitSymbol(mapSplitSymbol);
//        FormatLog
//                .debug("split symbol : " + split + "\t mapSplit : " + mapSplit);
//        return true;
//    }
//
//    public static boolean setMapSplitSymbol(String mapSplitSymbol) {
//        if (mapSplitSymbol == null || mapSplitSymbol.length() == 0) {
//            FormatLog.warn("MapSplitSymbol empty!!!");
//            return false;
//        }
//        mapSplit = mapSplitSymbol;
//        return true;
//    }

    public static void setDefaultSplitSymbol() {
        split = defaultSplit;
        mapSplit = defaultMapSplit;
    }

    public static int getIntConfig(String confFile, String confKey, int defaultNum){
        try{
            return Integer.parseInt(GetConfig
                .getStringConfig(confFile, confKey));
        }catch (Exception e) {
            return defaultNum;
        }
    }
    public static String getStringConfig(String confFile, String confKey) {
        if (confKey == null || confKey.length() < 1) {
            FormatLog.info("confKey is empty!!!");
            return null;
        }
        if (confFile == null || confFile.length() < 1) {
            FormatLog.info("confFile is empty!!!");
            return null;
        }

        URL confUrl = GetConfig.class.getClassLoader().getResource(confFile);
        if(confUrl != null){
            confFile = confUrl.getPath();
        }else{
            confFile = confDir + confFile;
        }

        File file = new File(confFile);
        if (!file.exists()) {
            throw new RuntimeException(confFile + " not exist!!!" + file.getAbsolutePath());
        }
        String value = getConfig(confFile, confKey);
        if (value == null) {
            FormatLog.info(confFile + " : " + confKey + " not exist!!!");
            return null;
        }

        value = value.trim();
        FormatLog.debug("GetConfig : confFile " + confFile + " confKey "
                + confKey + " result : " + value);

        return value;
    }

    public static String getStringConfig(String firstConfFile,
            String secondConfFile, String confKey) {
        String value = getStringConfig(firstConfFile, confKey);
        if (value != null) {
            return value;
        }
        value = getStringConfig(secondConfFile, confKey);
        if(value == null)            
            FormatLog.info(firstConfFile + " and " + secondConfFile
                    + " : " + confKey + " not exist!!!");
        return value;
    }

    public static String[] getArrayConfig(String confFile, String confKey){
        return getArrayConfigWithSplit(confFile, confKey, split);
    }
    public static String[] getArrayConfigWithSplit(String confFile, String confKey, String split) {
        String value = getStringConfig(confFile, confKey);
        if (value == null) {
            return null;
        }
        FormatLog.debug("split : " + split);
        String[] valueSplit = value.split(split);
        return valueSplit;
    }

    public static String[] getArrayConfigWithSplit(String firstConfFile,
            String secondConfFile, String confKey, String split){
        String[] value = getArrayConfigWithSplit(firstConfFile, confKey,split);
        if (value != null) {
            if (value[0].length() > 0) {
                return value;
            } else {
                // 存在配置，但为空
                return new String[0];
            }
        }
        value = getArrayConfigWithSplit(secondConfFile, confKey, split);
        if(value == null)            
            FormatLog.info(firstConfFile + " and " + secondConfFile
                    + " : " + confKey + " not exist!!!");
        return value;
    }
    public static String[] getArrayConfig(String firstConfFile,
            String secondConfFile, String confKey) {
        return getArrayConfigWithSplit(firstConfFile, secondConfFile, confKey, split);
    }

    public static int[] getIntArrayConfig(String firstConfFile, 
            String secondConfFile, String confKey){
        int[] value = getIntArrayConfig(firstConfFile, confKey);
        if(value != null ){
            return value;
        }
        value = getIntArrayConfig(secondConfFile, confKey);
        if(value == null)            
            FormatLog.info(firstConfFile + " and " + secondConfFile
                    + " : " + confKey + " not exist!!!");
        return value;
    }
        
    public static int[] getIntArrayConfig(String conFile, String confKey) {
        String[] value = getArrayConfig(conFile, confKey);
        if (value == null) {
            return null;
        }
        int[] result = new int[value.length];
        for (int i = 0; i < value.length; i++) {
            result[i] = Integer.parseInt(value[i]);
        }
        return result;
    }

    public synchronized static HashSet<String> getHashSetConfig(String confFile,
            String confKey) {
        String[] arrayConf = getArrayConfig(confFile, confKey);
        if (arrayConf == null) {
            return null;
        }
        HashSet<String> hashSetConf = new HashSet<String>();

        for (int i = 0; i < arrayConf.length; i++) {
            hashSetConf.add(arrayConf[i]);
        }
        return hashSetConf;
    }
    
    public static String[][] gettwoConditionArrayConfig(String confFile,
            String confKey){
        return gettwoConditionArrayConfigWithSplit(confFile, confKey,
                split, mapSplit);
    }

    public static String[][] gettwoConditionArrayConfigWithSplit(String confFile,
            String confKey, String split, String mapSplit) {
        String[] arrayConf = getArrayConfigWithSplit(confFile, confKey, split);
        if (arrayConf == null) {
            return null;
        }

        String[][] twoConditionConf = new String[arrayConf.length][];
        for (int i = 0; i < arrayConf.length; i++) {
            String[] slice = arrayConf[i].split(mapSplit, -1);
            if (slice.length < 2) {
                FormatLog.debug(confFile + " : " + confKey + "\t"
                        + arrayConf[i] + " format error!!" + " mapSplit : "
                        + mapSplit + slice.length);
            } else {
                twoConditionConf[i] = slice;
            }
        }
        return twoConditionConf;
    }
    public static String[][] gettwoConditionArrayConfig(String firstConfFile,
            String secondConfFile, String confKey) {
        return gettwoConditionArrayConfigWithSplit(firstConfFile, secondConfFile,
                confKey, split, mapSplit);
    }
    public static String[][] gettwoConditionArrayConfigWithSplit(String firstConfFile,
            String secondConfFile, String confKey, String split, String mapSplit) {
        String[][] twoConditionConf = gettwoConditionArrayConfigWithSplit(firstConfFile,
                confKey, split, mapSplit);
        if (twoConditionConf != null && twoConditionConf.length >= 1) {
            return twoConditionConf;
        }
        twoConditionConf = gettwoConditionArrayConfigWithSplit(secondConfFile, confKey, 
                split, mapSplit);
        if(twoConditionConf == null)            
            FormatLog.info(firstConfFile + " and " + secondConfFile
                    + " : " + confKey + " not exist!!!");
        return twoConditionConf;
    }

    public static String getConfig(String filename, String confKey) {
        ArrayList<String> confContent = loadConfFile(filename);
        if (confContent == null) {
            return null;
        }

        for (int i = 0; i < confContent.size(); i++) {
            String line = confContent.get(i);
            if (line.startsWith(confKey + "=")) {
                return line.substring(line.indexOf('=') + 1);
            }
        }
        return null;
    }

    public static ArrayList<String> loadConfFile(String filename) {
            try {
                BufferedReader fread = new BufferedReader(
                        new InputStreamReader(new FileInputStream(filename),
                                "UTF-8"));
                ArrayList<String> confContent = new ArrayList<String>();

                String line;
                while ((line = fread.readLine()) != null) {
                    confContent.add(line);
                }
                return confContent;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return null;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                return null;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
//        }
    }

    public static String[] vsplit(String str, String split, int count) {
        if (str == null) return new String[0];
        Vector<String> vector = new Vector<String>();  
        int index = -1;
        int offset = 0;
        int cnt = 1;
        while ((index = str.indexOf(split, offset)) != -1) {
            if (cnt >= count) break;
            vector.addElement(str.substring(offset, index));
            offset = index + split.length();
            ++cnt;
        }
        vector.addElement(str.substring(offset));
        return vector.toArray(new String[0]);  
    }
    public static String[] vsplit(String str, String split) {
        return vsplit(str, split, Integer.MAX_VALUE);
    }
    public static String[] tsplit(String str, String split) {
        if (str == null) return new String[0];
        StringTokenizer token = new StringTokenizer(str, split, false);
        int cnt = token.countTokens();
        /*cnt = cnt >= 1 ? cnt : 1;*/
        String[] array = new String[cnt];  
        int i = 0;
        while (i < cnt) {  
            array[i++] = token.nextToken();  
        }
              
        return array;  
    }

    public static void main(String[] vars) {
        // GetConfig getConfig=new GetConfig();
        String[] config = GetConfig.getArrayConfig("blog.conf",
                "search.instructSmallProduct");
        for (int i = 0; i < config.length; i++) {
            System.out.println(config[i]);
        }

        String[][] twoconfig = GetConfig.gettwoConditionArrayConfig(
                "default.conf", "default.Segment.noKey");
        for (int i = 0; i < twoconfig.length; i++) {
            for (int j = 0; j < twoconfig[i].length; j++) {
                System.out.println(twoconfig[i][j]);
            }
        }

    }
}
