package outlog.server;

import java.net.InetSocketAddress;
import java.util.List;

import odis.rpc2.RpcException;

public interface ITailLogProtocol {

    /*public List getServers() throws RpcException;*/

    public boolean add(String productId, String ip, int port) throws RpcException;

}
