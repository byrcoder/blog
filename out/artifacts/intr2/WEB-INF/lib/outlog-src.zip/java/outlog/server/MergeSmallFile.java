/**
 * @(#)MergeSmallFile.java, 2012-8-1. Copyright 2012 Yodao, Inc. All rights
 *                          reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                          subject to license terms.
 */
package outlog.server;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.joda.time.DateTime;

import outlog.toolbox.Clock;
import outlog.toolbox.FileFlagProperties;
import outlog.toolbox.Helper;

import odis.file.SequenceFile;
import odis.file.SequenceFile.Reader;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.TimeWritable;
import odis.serialize.lib.UTF8Writable;
import toolbox.misc.LogFormatter;

/**
 * @将/tmp/下分钟的文件合并成小时文件
 * @author jasonliu
 */

public class MergeSmallFile extends Thread {
    private static final Logger LOG = LogFormatter
            .getLogger(MergeSmallFile.class.getName());

    protected String dfsPath;

    private String dfsName = null;

    protected IFileSystem dfs = null;

    protected String TMPDSTPATH;

    protected String SMALLDSTPATH;

    public static final long MERGEBLOCKSIZE = 64 << 20;

    public static final long MAXMERGEBLOCKSIZE = 1 << 30;

    protected static final int CLEANBUFFERFILEHOURS = 7 * 24;

    protected int writeInterval = 10;

    public MergeSmallFile(String dfsPath, String dfsName, int writeInterval) {
        this.writeInterval = writeInterval;
        this.dfsPath = dfsPath;
        try {
            this.dfs = FileSystem.getNamed(dfsName);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        TMPDSTPATH = dfsPath + "/tmp/";
        SMALLDSTPATH = dfsPath + "/small/";
    }

    /**
     * 
     */
    public MergeSmallFile() {
    // TODO Auto-generated constructor stub
    }

    /**
     * 根据文件名判断是否属于同一时间段的文件
     * 
     * @flag=-1表示同一小时
     * @flag=0 表示同一天
     * @flag=1 表示同一周期为7天
     * @其他
     */
    public boolean IsSameTimeFile(String file1, String file2, int flag) {
        if (flag == -1) {
            int beg = file1.indexOf(".");
            file1 = file1.substring(0, beg + 11);
            beg = file2.indexOf(".");
            file2 = file2.substring(0, beg + 11);
            return file1.equals(file2);
        }

        if (flag == 0) {
            int beg = file1.indexOf(".");
            file1 = file1.substring(0, beg + 9);
            beg = file2.indexOf(".");
            file2 = file2.substring(0, beg + 9);
            return file1.equals(file2);
        }

        if (flag == 1) {
            int beg = file1.indexOf(".");
            if (beg < 0)
                return false;
            file1 = file1.substring(beg + 1, beg + 9);
            file2 = getDate(file2, CLEANBUFFERFILEHOURS);
            return file1.compareTo(file2) > 0 ? true : false;
        }

        if (file1.length() == file2.length()) {
            String[] tmp = file1.split("\\.");
            String[] tmp2 = file2.split("\\.");
            if (tmp != null && tmp2 != null && tmp.length >= 3) {
                return tmp[1].equals(tmp2[1]);
            }
            if (tmp != null && tmp.length < 3)
                return false;
        } else if (file1.length() > file2.length()) {
            return file1.contains(file2);
        } else {
            return file2.contains(file1);
        }

        return false;
    }

    public boolean updateProperty(Properties p, String now) {
        boolean flag = false;
        Set<String> s = p.stringPropertyNames();
        String[] key = s.toArray(new String[s.size()]);
        for (int i = 0; i < key.length; i++) {
            if (!IsSameTimeFile(key[i], now, 1)) {
                p.remove(key[i]);
                flag = true;
            }
        }
        return flag;
    }

    // 返回合并后文件的长度
    public long MergeSmallFileFunction(Path[] srcFiles, Path dstFile) {
        // 对输入文件名按顺序排序
        Arrays.sort(srcFiles, new FileNameCompare());

        SequenceFile.Writer writer = null;
        try {
            writer = new SequenceFile.CompressedWriter(dfs, dstFile,
                    TimeWritable.class, UTF8Writable.class, true);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            LOG.warning(dstFile + " write error,check please!");
            return -1;
        }

        // 多路归并及顺序追加
        for (int i = 0; i < srcFiles.length; i++) {
            int j = i;
            String nowFile = srcFiles[j].getName();
            while (j < srcFiles.length - 1) {
                String nextFile = srcFiles[j + 1].getName();
                if (IsSameTimeFile(nextFile, nowFile, 100))
                    j++;
                else
                    break;
            }
            try {
                if (j != i) {
                    // 多路归并
                    TreeMap<ComparePair, UTF8Writable> tMap = new TreeMap<ComparePair, UTF8Writable>();
                    for (int k = i; k <= j; k++) {
                        ComparePair keyPair = new ComparePair();
                        SequenceFile.Reader reader = new SequenceFile.Reader(
                                dfs, srcFiles[k]);
                        TimeWritable time = new TimeWritable();
                        UTF8Writable value = new UTF8Writable();
                        reader.next(time, value);
                        keyPair.setFirst(time);
                        keyPair.setSecond(reader);
                        keyPair.setPath(srcFiles[k]);
                        tMap.put(keyPair, value);
                    }

                    while (tMap.size() != 0) {
                        Entry<ComparePair, UTF8Writable> litter = tMap
                                .firstEntry();
                        writer.write(litter.getKey().getFirst(), litter
                                .getValue());
                        SequenceFile.Reader reader = litter.getKey()
                                .getSecond();
                        TimeWritable key = new TimeWritable();
                        UTF8Writable value = new UTF8Writable();
                        UTF8Writable uw = tMap.remove(litter.getKey());
                        if (reader.next(key, value)) {
                            litter.getKey().setFirst(key);
                            litter.getValue().set(value);
                            tMap.put(litter.getKey(), litter.getValue());
                        } else {
                            litter.getKey().getSecond().close();
                        }
                    }
                } else {
                    // 顺序追加
                    SequenceFile.Reader reader = new SequenceFile.Reader(dfs,
                            srcFiles[i]);
                    TimeWritable key = new TimeWritable();
                    UTF8Writable value = new UTF8Writable();
                    while (reader.next(key, value)) {
                        writer.write(key, value);
                    }
                    reader.close();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                LOG.info("read " + srcFiles[i].getAbsolutePath() + " error!");
                return -1;
            }
            i = j;
        }

        try {
            writer.close();
            SequenceFile.Reader reader = new SequenceFile.Reader(dfs, dstFile);
            long size = reader.getSize();
            reader.close();
            return size;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            LOG.info("read " + dstFile.getAbsolutePath() + " error!");
            return -1;
        }
    }

    private class ComparePair implements Comparable {
        TimeWritable time;

        SequenceFile.Reader reader;

        Path file;

        public ComparePair() {

        }

        public ComparePair(TimeWritable time, SequenceFile.Reader reader,
                Path file) {
            this.time = time;
            this.reader = reader;
            this.file = file;
        }

        public TimeWritable getFirst() {
            // TODO Auto-generated method stub
            return time;
        }

        public SequenceFile.Reader getSecond() {
            // TODO Auto-generated method stub
            return reader;
        }

        public Path getPath() {
            return file;
        }

        public void setFirst(TimeWritable v) {
            // TODO Auto-generated method stub
            this.time = v;
        }

        public void setSecond(SequenceFile.Reader v) {
            // TODO Auto-generated method stub
            this.reader = v;
        }

        public void setPath(Path file) {
            this.file = file;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Comparable#compareTo(java.lang.Object)
         */
        @Override
        public int compareTo(Object arg0) {
            // TODO Auto-generated method stub
            TimeWritable t1 = this.getFirst();
            TimeWritable t2 = ((ComparePair) arg0).getFirst();
            int v = t1.compareTo(t2);
            if (v != 0)
                return v;
            else {
                Path p1 = this.getPath();
                Path p2 = ((ComparePair) arg0).getPath();
                return p1.compareTo(p2);
            }
        }
    }

    public void sleepMoment(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public class FileNameCompare implements Comparator {
        /*
         * (non-Javadoc)
         * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
         */
        @Override
        public int compare(Object arg0, Object arg1) {
            // TODO Auto-generated method stub
            if (arg0.getClass().equals(FileInfo.class)) {
                Path p0 = ((FileInfo) arg0).getPath();
                Path p1 = ((FileInfo) arg1).getPath();
                return p0.getName().compareTo(p1.getName());
            } else if (arg0.getClass().equals(Path.class)) {
                Path p0 = (Path) arg0;
                Path p1 = (Path) arg1;
                return p0.getName().compareTo(p1.getName());
            }
            return 0;
        }
    }

    // 向前推n个小时
    public static String getDate(String date, int forwordHours) {
        long t = Helper.yyyyMMddHH.parseMillis(String.valueOf(date));
        t -= forwordHours * 3600 * 1000;
        return Helper.yyyyMMddHH.print(t);
    }

    public Path createUniqueneFile(String p, IFileSystem dfs) {
        Path dfsFile = new Path(p);
        Path tmpFile = new Path(p);

        try {
            for (int i = 1; dfs.exists(dfsFile); ++i) {
                dfsFile = new Path(tmpFile.getAbsolutePath() + "." + i);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return dfsFile;
    }

    public void run() {
        List<String> srcFiles = new ArrayList<String>();
        while (true) {
            try {
                Path[] productList;
                productList = dfs.listPaths(new Path(TMPDSTPATH));
                if (productList == null) {
                    sleepMoment(writeInterval * 30 * 1000);
                    continue;
                }
                for (int i = 0; i < productList.length; i++) {
                    if (productList[i].asFile().isFile())
                        continue;
                    if (srcFiles.contains(productList[i].getName()))
                        continue;
                    else
                        srcFiles.add(productList[i].getName());

                    Thread t = new Thread(new MergeSmallFileThread(
                            productList[i]));
                    t.setDaemon(true);
                    t.start();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            sleepMoment(writeInterval * 60 * 1000);
        }// end of while
    }

    private class MergeSmallFileThread implements Runnable {
        private Path product;

        MergeSmallFileThread(Path p) {
            this.product = p;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Runnable#run()
         */
        @Override
        public void run() {
            // TODO Auto-generated method stub
            while (true) {
                try {
                    Path[] fileList = dfs.listPaths(product);
                    if (fileList == null)
                        continue;
                    Arrays.sort(fileList, new FileNameCompare());

                    List<Path> srcFiles = new ArrayList<Path>();

                    // 读取属性配置
                    Properties property = FileFlagProperties
                            .loadProperties(product.getAbsolutePath());

                    srcFiles.clear();

                    // 当前小时起十分钟后开始处理上一小时的数据文件
                    DateTime dt = new DateTime(Clock.currentTimeMillis());
                    int minute = dt.getMinuteOfHour();
                    if (minute < writeInterval) {
                        sleepMoment(writeInterval * 100);
                        continue;
                    }

                    // 判断是否需要合并，确定合并的文件集合
                    String now = Helper.yyyyMMddHH.print(Clock
                            .currentTimeMillis());
                    now = getDate(now, 1);

                    for (int i = 0; i < fileList.length; i++) {
                        Path file = fileList[i];
                        if (!dfs.exists(file)) {
                            LOG.log(Level.SEVERE, file.getAbsolutePath()
                                    + " not exits");
                            continue;
                        }

                        // 处理上一小时的数据文件
                        boolean flag = file.getName().contains(
                                product.getName() + "." + now);
                        if (!flag) {
                            if (file.getName().compareTo(
                                    product.getName() + "." + now) > 0)
                                continue;
                        }

                        // 清除一周之前的数据
                        if (!IsSameTimeFile(file.getName(), now, 1)) {
                            dfs.delete(file);
                            LOG.info("delete file:" + file.getAbsolutePath());
                            continue;
                        }

                        if (!FileFlagProperties.hadReadedFile(property, file
                                .getName())) {
                            srcFiles.add(new Path(file.getAbsolutePath()));
                            property.put(file.getName(), "true");
                            if (i < fileList.length - 1) {
                                if (!IsSameTimeFile(file.getName(),
                                        fileList[i + 1].getName(), -1))
                                    break;
                            }
                        }
                    }// end of for

                    if (srcFiles.size() > 0) {
                        String dstPath = srcFiles.get(srcFiles.size() - 1)
                                .getName();
                        int beg = dstPath.indexOf(".");
                        dstPath = dstPath.substring(0, beg + 11);

                        Path dst = new Path("/tmp/outlogtmp", dstPath + "."
                                + Clock.currentTimeMillis());
                        long size = MergeSmallFileFunction(srcFiles
                                .toArray(new Path[srcFiles.size()]), dst);
                        if (size < 0) {
                            sleepMoment(writeInterval * 60 * 100);
                            continue;
                        } else if (size > MERGEBLOCKSIZE
                                || dstPath.endsWith("23")) {
                            Path renameDst = createUniqueneFile(dfsPath + "/"
                                    + product.getName() + "/" + dstPath, dfs);
                            dfs.mkdirs(renameDst.getParentFile());
                            dfs.rename(dst, renameDst);
                            LOG.info(product.getName()
                                    + " merge one hour file to "
                                    + renameDst.getAbsolutePath()
                                    + " successly!");
                        } else {
                            Path renameDst = createUniqueneFile(SMALLDSTPATH
                                    + "/" + product.getName() + "/" + dstPath,
                                    dfs);
                            dfs.mkdirs(renameDst.getParentFile());
                            dfs.rename(dst, renameDst);
                            LOG.info(product.getName()
                                    + " merge one hour file to "
                                    + renameDst.getAbsolutePath()
                                    + " successly!");
                        }
                        // 更新配置
                        now = getDate(now, CLEANBUFFERFILEHOURS);
                        updateProperty(property, now);
                        FileFlagProperties.saveProperties(property, product
                                .getAbsolutePath());
                    } else {
                        // 更新配置
                        now = getDate(now, CLEANBUFFERFILEHOURS);
                        boolean flag = updateProperty(property, now);
                        if (flag)
                            FileFlagProperties.saveProperties(property, product
                                    .getAbsolutePath());
                    }
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    LOG.info(System.currentTimeMillis() + e1.getMessage());
                } finally {
                    sleepMoment(writeInterval * 60 * 100);
                }
            }// end of while
        }// end of run
    }// end of MergeSmallFileThread

    public static void main(String[] args) throws IOException {
        MergeSmallFile smallFile = new MergeSmallFile("/outlog/tmp",
                "tiger:6080", 10);
        smallFile.setDaemon(true);
        smallFile.start();
        return;
    }
}
