package outlog.toolbox;

import java.util.StringTokenizer;
import java.util.Vector;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.maintain.alarm.SmsSender;

public class Helper {

    public static String[] vsplit(String str, String split, int count) {
        if (str == null) return new String[0];
        Vector<String> vector = new Vector<String>();  
        int index = -1;
        int offset = 0;
        int cnt = 1;
        while ((index = str.indexOf(split, offset)) != -1) {
            if (cnt >= count) break;
            vector.addElement(str.substring(offset, index));
            offset = index + split.length();
            ++cnt;
        }
        vector.addElement(str.substring(offset));
        return vector.toArray(new String[0]);  
    }
    public static String[] vsplit(String str, String split) {
        return vsplit(str, split, Integer.MAX_VALUE);
    }
    
    public static String[] tsplit(String str, String split) {
        if (str == null) return new String[0];
        StringTokenizer token = new StringTokenizer(str, split, false);
        int cnt = token.countTokens();
        /*cnt = cnt >= 1 ? cnt : 1;*/
        String[] array = new String[cnt];  
        int i = 0;
        while (i < cnt) {  
            array[i++] = token.nextToken();  
        }
              
        return array;  
    }

    /*
     * 短信报警
     */
    private static final int MESSAGE_LEN = 60;
    public static void SmsSend(String group, StringBuilder message) {
        SmsSend(group, message, MESSAGE_LEN);
    }
    public static void SmsSend(String group, StringBuilder message, 
            int messageLen) {
        if (message.length() > messageLen) {
            SmsSender.send(new String[] {
                group
            }, message.substring(0, messageLen - 4) + " ...");
        } else {
            SmsSender.send(new String[] {
                group
            }, message.toString());
        }
    }
    
    public static DateTimeFormatter yyyyMMdd = DateTimeFormat.forPattern(
            "yyyyMMdd");
    public static  DateTimeFormatter yyyyMMddHH = DateTimeFormat.forPattern(
            "yyyyMMddHH");
    public static  DateTimeFormatter yyyyMMddHHmm = DateTimeFormat.forPattern(
            "yyyyMMddHHmm");
    public static  DateTimeFormatter yyyyMMddHHmmss = DateTimeFormat.forPattern(
            "yyyyMMddHHmmss");

}
