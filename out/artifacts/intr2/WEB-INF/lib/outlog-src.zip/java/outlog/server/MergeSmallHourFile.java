/**
 * @(#)MergeSmallHourFile.java, 2012-8-7. Copyright 2012 Yodao, Inc. All rights
 *                              reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                              subject to license terms.
 */
package outlog.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.joda.time.DateTime;

import outlog.server.MergeSmallFile.FileNameCompare;
import outlog.toolbox.Clock;
import outlog.toolbox.FileFlagProperties;
import outlog.toolbox.Helper;
import odis.io.FileInfo;
import odis.io.Path;
import toolbox.misc.LogFormatter;

/**
 * @将odfs上单小时小log文件合并生成大文件,减少文件数
 * @author jasonliu
 */
public class MergeSmallHourFile extends MergeSmallFile {
    private static final Logger LOG = LogFormatter
            .getLogger(MergeSmallHourFile.class.getName());

    /**
     * @param dfsPath
     * @param dfsName
     */
    public MergeSmallHourFile(String dfsPath, String dfsName) {
        super(dfsPath, dfsName, 10);
        // TODO Auto-generated constructor stub
    }

    public void run() {
        List<String> srcFiles = new ArrayList<String>();
        while (true) {
            try {
                Path[] productList = dfs.listPaths(new Path(SMALLDSTPATH));

                if (productList == null) {
                    sleepMoment(5 * 60 * 1000);
                    continue;
                }
                for (int i = 0; i < productList.length; i++) {
                    if (productList[i].asFile().isFile())
                        continue;
                    if (srcFiles.contains(productList[i].getName()))
                        continue;
                    else
                        srcFiles.add(productList[i].getName());
                    Thread t = new Thread(new MergeSmallHourFileThread(
                            productList[i]));
                    t.setDaemon(true);
                    t.start();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            sleepMoment(10 * 60 * 1000);
        }// end of while
    }// end of run

    private class MergeSmallHourFileThread implements Runnable {
        private Path product;

        MergeSmallHourFileThread(Path p) {
            this.product = p;
        }

        /*
         * (non-Javadoc)
         * @see java.lang.Runnable#run()
         */
        @Override
        public void run() {
            while (true) {
                DateTime dt = new DateTime(Clock.currentTimeMillis());

                // 23:20后才开始执行，将0-23小时之间的小文件合并
                int hour = dt.getHourOfDay();
                if (hour > 22) {
                    int minute = dt.getMinuteOfHour();
                    if (minute < 20)
                        sleepMoment((20 - minute) * 60 * 1000);
                    else
                        sleepMoment(5 * 1000);
                }// end of else

                List<Path> srcFiles = new ArrayList<Path>();

                // TODO Auto-generated method stub
                try {
                    Path[] fileList = dfs.listPaths(product);
                    if (fileList == null)
                        continue;
                    // 对输入文件名按顺序排序
                    Arrays.sort(fileList, new FileNameCompare());

                    srcFiles.clear();

                    String now = Helper.yyyyMMdd.print(Clock
                            .currentTimeMillis());
                    now = now + "00";
                    if (hour <= 22) {
                        for (int i = 0; i < fileList.length; i++) {
                            if (fileList[i].getName().compareTo(
                                    product.getName() + "." + now) >= 0) {
                                fileList = Arrays.copyOf(fileList, i);
                                break;
                            }
                        }
                    }

                    // 读取属性配置
                    Properties property = FileFlagProperties
                            .loadProperties(product.getAbsolutePath());

                    for (int i = 0; i < fileList.length; i++) {
                        Path file = fileList[i];
                        if (!dfs.exists(file)) {
                            LOG.log(Level.SEVERE, file.getAbsolutePath()
                                    + " not exits");
                            continue;
                        }

                        // 清除一周之前的数据
                        if (!IsSameTimeFile(file.getName(), now, 1)) {
                            dfs.delete(file);
                            LOG.info("delete file:" + file.getAbsolutePath());
                            continue;
                        }

                        if (!FileFlagProperties.hadReadedFile(property, file
                                .getName())) {
                            LOG.info(file.getAbsolutePath());
                            srcFiles.add(new Path(file.getAbsolutePath()));
                            property.put(file.getName(), "true");
                            if (i < fileList.length - 1) {
                                if (!IsSameTimeFile(file.getName(),
                                        fileList[i + 1].getName(), 0))
                                    break;
                            }
                            // if (srcFiles.size() > 8)
                            // break;
                        }
                    }

                    if (srcFiles.size() > 0) {
                        fileList = srcFiles.toArray(new Path[srcFiles.size()]);
                        String childFile = fileList[fileList.length - 1]
                                .getName();
                        int beg = childFile.indexOf(".");
                        childFile = childFile.substring(0, beg + 9);
                        Path dst = new Path("/tmp/outlogtmp", product.getName()
                                + ".multiplehour." + Clock.currentTimeMillis());
                        long size = MergeSmallFileFunction(fileList, dst);
                        if (size < 0)
                            continue;

                        Path dstFile = new Path(dfsPath + "/"
                                + product.getName(), childFile);
                        dstFile = createUniqueneFile(dstFile.getAbsolutePath(),
                                dfs);
                        dfs.mkdirs(dstFile.getParentFile());
                        dfs.rename(dst, dstFile);
                        LOG.info(product.getName()
                                + " merge mutiple litter hourfiles to "
                                + dstFile.getAbsolutePath() + " successly!");

                        // 更新配置
                        now = getDate(now, CLEANBUFFERFILEHOURS);
                        updateProperty(property, now);
                        FileFlagProperties.saveProperties(property, product
                                .getAbsolutePath());
                    } else if (hour <= 22 && srcFiles.size() == 0) {
                        // 更新配置
                        now = getDate(now, CLEANBUFFERFILEHOURS);
                        boolean flag = updateProperty(property, now);
                        if (flag)
                            FileFlagProperties.saveProperties(property, product
                                    .getAbsolutePath());
                        sleepMoment(5 * 60 * 1000);
                    }
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } finally {
                    sleepMoment(60 * 1000);
                }
            }// end of while
        }// end of run
    }// end of MergeSmallHourFileThread

    public static void main(String[] args) {
        String dfsPath = "/outlog/tmp";
        String dfsName = "tiger:7080";
        MergeSmallHourFile msf = new MergeSmallHourFile(dfsPath, dfsName);
        msf.run();
        return;
    }
}
