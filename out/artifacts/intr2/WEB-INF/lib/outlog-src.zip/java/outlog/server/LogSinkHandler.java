package outlog.server;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import odis.dfs.client.DistributedFileSystem;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.io.permission.FsPermission;
import odis.tools.MapReduceHelper;

import org.apache.mina.protocol.ProtocolHandlerAdapter;
import org.apache.mina.protocol.ProtocolSession;
import org.joda.time.DateTime;
import org.joda.time.IllegalFieldValueException;

import outlog.server.LogSinkHandler.DfsUploader.ResetExceptionHandler;
import outlog.toolbox.Clock;
import outlog.toolbox.Helper;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

/**
 * ProtocolHanderAdapter of mina, main body of outlog server.
 * 
 * @author yaming
 */
public class LogSinkHandler extends ProtocolHandlerAdapter {

    private static final Logger LOG = LogFormatter
            .getLogger(LogSinkHandler.class.getName());

    private LocalWriter worker = null;

    private ArrayList<DfsUploader> dfsUploader = new ArrayList<DfsUploader>();

    private LinkedList<String> dfsUploadQueue = null;

    private int writeInterval = 10;

    public LogSinkHandler(String[] localPath, int bufferHour, int maxQueueSize,
            int upload, String dfsName, String dfsPath, String host,
            boolean mergeSmallFile, int write_Interval, String smsGroup)
            throws Exception {
        writeInterval = write_Interval;
        worker = new LocalWriter(localPath, bufferHour, maxQueueSize, host,
                writeInterval, smsGroup);
        dfsUploadQueue = worker.getUploadQueue();
        worker.start();
        LOG.info("LogSinkHandler.work started.");

        if (upload > 0) {
            for (int i = 0; i < upload; i++) {
                DfsUploader uploader = new DfsUploader(localPath, dfsName,
                        dfsPath, host, smsGroup);
                uploader.setDaemon(true);
                uploader.start();
                dfsUploader.add(uploader);
            }
            LOG.info("LogSinkHandler.dfsUploader started.");
        }

        if (mergeSmallFile) {
            MergeSmallFile smallFile = new MergeSmallFile(dfsPath, dfsName,
                    writeInterval);
            smallFile.setDaemon(true);
            smallFile.start();
            LOG.info("MergeSmallFile started.");

            MergeSmallHourFile smallHourFile = new MergeSmallHourFile(dfsPath,
                    dfsName);
            smallHourFile.setDaemon(true);
            smallHourFile.start();
            LOG.info("MergeSmallHourFile started.");
        }
    }

    public void exceptionCaught(ProtocolSession session, Throwable cause) {
        cause.printStackTrace();
        session.close();
    }

    public void messageReceived(ProtocolSession session, Object log)
            throws IOException {
        Log next = (Log) log;
        String message = next.getMessage();

        if (null == message) {
            return;
        }
        long nowTime = Clock.currentTimeMillis();
        long lastTime = -1L;
        // 判断第一列是不是时间
        String[] split = Helper.vsplit(message, "\t", 2);
        if (split.length == 2) {
            if (split[0].length() == 14) {
                try {
                    lastTime = Helper.yyyyMMddHHmmss.parseMillis(split[0]);
                } catch (IllegalFieldValueException e) {} catch (IllegalArgumentException e) {}
            } else if (split[0].length() == 13) {
                try {
                    lastTime = Long.parseLong(split[0]);
                } catch (Exception e) {}
            }
            if (lastTime > 0) {
                if (Math.abs(nowTime - lastTime) <= 360000) {
                    next.setMessage(lastTime, split[1]);
                } else {
                    next.setMessage(nowTime, split[1]);
                }
                worker.enqueue(next);
                return;
            }
        }

        // 没有时间，服务端补上时间。
        next.setTimestamp(nowTime);
        worker.enqueue(next);
    }

    /**
     * Uploader thread, putting all log files to odfs.
     */
    public class DfsUploader extends Thread {
        private static final long SLEEP = 10 * 1000L;

        // 10*120,20 分钟的报警间隔
        private int maxOdfsFullRetry = 120;

        private int odfsFullRetry = 0;

        private String[] localPath = null;

        private String dfsName = null;

        private IFileSystem dfs = null;

        private String dfsPath = null;

        private String host = null;

        private String smsGroup = "liujg";

        public DfsUploader(String[] localPath, String dfsName, String dfsPath,
                String host, String smsGroup) {
            this.localPath = localPath;
            this.dfsName = dfsName;
            this.dfsPath = dfsPath;
            this.host = host;
            this.smsGroup = smsGroup;
        }

        private void touchDfs() {
            dfs = null;
            while (null == dfs) {
                try {
                    dfs = FileSystem.getNamed(dfsName);
                    LOG.info("Get FileSystem " + dfsName + " success.");
                    odfsFullRetry = 0;
                } catch (IOException e) {
                    LOG.log(Level.SEVERE,
                            "Caught IOException when get FileSystem: "
                                    + dfsName + "!.", e);
                    dfs = null;
                    try { // odfs error
                        Thread.sleep(SLEEP);
                    } catch (InterruptedException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }

        public String getMinus(DateTime date) {
            long t = date.getMillis();
            t = (t / (writeInterval * 60 * 1000)) * (writeInterval * 60 * 1000);
            return Helper.yyyyMMddHHmm.print(t);
        }

        public class ResetExceptionHandler implements
                Thread.UncaughtExceptionHandler {
            public void uncaughtException(Thread t, Throwable e) {
                for (DfsUploader i: dfsUploader) {
                    if (i.getId() == t.getId()) {
                        dfsUploader.remove(i);
                        i = new DfsUploader(localPath, dfsName, dfsPath, host,
                                smsGroup);;
                        dfsUploader.add(i);
                        i.start();
                    }
                }
            }
        }

        public String convertToWRITE_INTERVAL(String file) {
            int beg = file.indexOf(".");
            if (beg < 0)
                return file;
            String timeString = file.substring(beg + 1, file.length());
            int interval = writeInterval * 100;
            long timeInteger = (Long.valueOf(timeString) / interval)
                    * writeInterval;
            return file.substring(0, beg + 1) + String.valueOf(timeInteger);
        }

        public void run() {

            this.setUncaughtExceptionHandler(new ResetExceptionHandler());

            touchDfs();

            DateTime now = null;
            while (true) {
                
                String product = null;
                synchronized (dfsUploadQueue) {
                    while (dfsUploadQueue.isEmpty()) {
                        try {
                            dfsUploadQueue.wait(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    product = dfsUploadQueue.poll();
                }

                now = new DateTime(Clock.currentTimeMillis());
                String expirePoint = getMinus(now);
                int pathPos = (product.hashCode() & Integer.MAX_VALUE)
                        % localPath.length;
                File localDir = new File(localPath[pathPos], product);

                for (File file: localDir.listFiles()) {
                    if (file.isDirectory()) {
                        continue;
                    }

                    Pattern p = Pattern.compile(product + ".(\\d{14})");
                    Matcher m = p.matcher(file.getName());
                    if (!m.matches()) {
                        continue;
                    } else if (m.group(1).compareTo(expirePoint) >= 0) {
                        continue;
                    }

                    String childPath = "tmp/" + product;
                    // 大于block默认大小则直接上传到日志的根目录
                    if (file.length() > MergeSmallFile.MERGEBLOCKSIZE)
                        childPath = product;
                    Path dfsParentDir = new Path(dfsPath, childPath);
                    String dstName = convertToWRITE_INTERVAL(file.getName());

                    Path dfsFile = new Path(dfsParentDir, dstName);
                    try {
                        if (!dfs.exists(dfsParentDir)) {
                            dfs.mkdirs(dfsParentDir);
                        }
                        Path tmpFile = new Path("/tmp/outlogtmp", file
                                .getName()
                                + "." + Clock.currentTimeMillis());

                        dfs.copyFromLocalFile(file, tmpFile);                        
                        for (int i = 1; dfs.exists(dfsFile); ++i) {
                            dfsFile = new Path(dfsParentDir, dstName + "." + i);
                        }
                        dfs.rename(tmpFile, dfsFile);
                        LOG.info("Uploaded " + file.getName() + " to "
                                + dfs.getName() + " path : "
                                + dfsFile.getAbsolutePath());

                        file.renameTo(new File(file.getAbsolutePath() + ".a"));

                        odfsFullRetry = odfsFullRetry > 0 ? odfsFullRetry - 1
                                : 0;
                    } catch (IOException e) {
                        // only dfs IOException
                        LOG.log(Level.WARNING,
                                "Caught IOException when upload file "
                                        + file.getName() + " to dfs.", e);
                        exceptionAlarm(e);
                    }
                }

                try {
                    Thread.sleep(SLEEP);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        private void exceptionAlarm(Exception e) {
            ++odfsFullRetry;

            if (odfsFullRetry >= maxOdfsFullRetry) {
                Helper.SmsSend(smsGroup, new StringBuilder(
                        "dfsUploader error ... ").append(host).append(" ")
                        .append(e.getMessage()));
                odfsFullRetry = 0;
            }
            try { // odfs error
                Thread.sleep(SLEEP);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
        }

    }

}
