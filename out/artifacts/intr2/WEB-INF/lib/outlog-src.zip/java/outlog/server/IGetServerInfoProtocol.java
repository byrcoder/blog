package outlog.server;

import java.util.List;

import odis.rpc2.RpcException;

public interface IGetServerInfoProtocol {

    public List getServers() throws RpcException;

}
