package outlog.toolbox;

import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.Path;
import odis.io.IFileSystem.PathFilter;
import toolbox.misc.LogFormatter;

/**
 * 
 *
 * @author Administrator
 *
 */
public class MatchPathFilter implements PathFilter{
    private static final Logger LOG = LogFormatter.getLogger(MatchPathFilter.class.getName());

    private String matchrule = null;
    
    public MatchPathFilter(){};
    public MatchPathFilter(String matchrule){
        this.matchrule = matchrule;
    }
    
    public void setRule(String rule){
        matchrule = rule;
    }

    public boolean accept(Path path) {
        LOG.log(Level.INFO, "path : " + path.getPath());
        if(path.getPath().matches(matchrule)){
            LOG.log(Level.INFO, "path : " + path.getPath() + " match the filter : " 
                    + matchrule);
            return true;
        }
        return false;
    }

}
