import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

import toolbox.webfront.support.spring.coverter.MappingFastJsonHttpMessageConverter;

public class testMessageConverter {

	public static final Charset UTF8 = Charset.forName("UTF-8");
	private Charset charset = UTF8;
	
	@Test
	public void givenConsumingJson_whenReadingTheFoo_thenCorrect() {
		String URI = "http://qt002x.corp.youdao.com:28086/course/promotionact/senddrawcode.jsonp?mobile=13827223896&lesson=751";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setMessageConverters(getMessageConverters());
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<JSONObject> response = restTemplate.exchange(URI,
				HttpMethod.GET, entity, JSONObject.class, "1");

		JSONObject resource = response.getBody();
		System.out.println(resource);
	}

	private List<HttpMessageConverter<?>> getMessageConverters() {
		MappingFastJsonHttpMessageConverter m = new MappingFastJsonHttpMessageConverter();
		List<MediaType> list = new ArrayList<MediaType>();
		list.add(new MediaType("*", "*", UTF8));
		
		m.setSupportedMediaTypes(list);
		
		List<HttpMessageConverter<?>> converters = new ArrayList<HttpMessageConverter<?>>();
		
		converters.add(m);
		return converters;
	}

}
