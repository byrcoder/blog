package toolbox.webfront.support.spring.coverter;

import java.io.IOException;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageNotWritableException;

import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;


/**
 * 基于fastjson的spring支持类
 * @author luzhujun
 *
 */
public class MappingFastJsonHttpMessageConverter extends FastJsonHttpMessageConverter {
 
     
    @Override 
    protected void writeInternal(Object o, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
    	outputMessage.getHeaders().setContentType(new MediaType("text", "plain"));
        super.writeInternal(o , outputMessage);
    }  
}