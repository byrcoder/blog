package toolbox.webfront.support.spring.interceptor;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import toolbox.webfront.support.spring.annotation.JSONP;

import com.alibaba.fastjson.JSON;



/**
 * 
 * 前端支持,根据注解自动支持jsonp
 * @author luzhujun
 */
public class JsonpInterceptor  implements HandlerInterceptor {

	
	private static ThreadLocal<String> isJSONP = new ThreadLocal<String>();
	
	private static final String SUCCESS = "1";
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
		String ret = isJSONP.get();
		isJSONP.remove();
		if(SUCCESS.equals(ret)){
			response.getOutputStream().write(")".getBytes());
		}
		
		
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		
		if(! (handler instanceof HandlerMethod) ){
			return true;
		}
		
		HandlerMethod m = (HandlerMethod) handler;
		Method method = m.getMethod();
		
		
		//是否需要支持jsonp
		if(!method.isAnnotationPresent(JSONP.class)){
			return true;
		}
		
		Class<?> returnType = method.getReturnType();
		//是否支持序列化类型
		if(!
			(
				JSON.class.isAssignableFrom(returnType)
				|| Map.class.isAssignableFrom(returnType)
				|| Collection.class.isAssignableFrom(returnType)
			)
		){
			return true;
		}
		
		String callback = request.getParameter("callback");
		if(StringUtils.isEmpty(callback)){
			return true;
		}
		
		response.getOutputStream().write( (callback + "(").getBytes() );
		
		isJSONP.set(SUCCESS);
		
		
		return true;
	}

}
