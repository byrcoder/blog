package toolbox.webfront.support.spring.interceptor;

import java.util.*;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


/**
 * 
 * 前端支持,自动将request的参数放入model中
 * @author luzhujun
 */
public class RequestInterceptor  implements HandlerInterceptor{

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		if(modelAndView == null)return;
		
		Map<String, String[]> map = request.getParameterMap(); 
		
		Map retMap = new HashMap(map.size());
        Set<Entry<String, String[]>> set = map.entrySet();  
        Iterator<Entry<String, String[]>> it = set.iterator();  
        while (it.hasNext()) {  
            Entry<String, String[]> entry = it.next();  
            String[] vals = entry.getValue();
            if(vals != null && vals.length == 1){
            	retMap.put(entry.getKey(), entry.getValue()[0]);
            }else{
            	retMap.put(entry.getKey(), vals);
            }
          
        }  
        Map model = modelAndView.getModel();
        if(model != null){
        	model.put("params", retMap);
        }
		
		
		
		
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		return true;
	}

	
	
	
}
