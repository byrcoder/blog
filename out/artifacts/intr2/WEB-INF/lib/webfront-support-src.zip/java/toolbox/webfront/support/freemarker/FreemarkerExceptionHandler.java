package toolbox.webfront.support.freemarker;

import java.io.Writer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import freemarker.core.Environment;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

/**
 * 自定义Freemarker错误处理类(用于屏蔽报错时候,网页输出报错信息)
 * 
 * @author luzhujun
 *
 */
public class FreemarkerExceptionHandler  implements TemplateExceptionHandler{

	private static Log log = LogFactory.getLog(FreemarkerExceptionHandler.class);
	
	@Override
	public void handleTemplateException(
			TemplateException te,
			Environment env, Writer out)
			throws TemplateException {
		log.error(env.getTemplate().getName(), te);
		
		
	}
}
