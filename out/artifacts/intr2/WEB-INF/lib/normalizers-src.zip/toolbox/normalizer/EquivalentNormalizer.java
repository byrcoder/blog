package toolbox.normalizer;



public abstract class EquivalentNormalizer<T, E extends Exception> implements Normalizer<T, E> {
        
    /**
     * Initialize the equivlent map
     */
    protected abstract void init();
    protected abstract boolean isInit();
    
    protected abstract T getEquivalent(T target) throws E;
    
    public T normalize(T target) throws E {
        if (!isInit()) init();
        T other = getEquivalent(target);
        if (other==null) return target;
        else return other;
    }
    
}
