package toolbox.normalizer.url;

import java.net.MalformedURLException;
import java.util.HashMap;

import toolbox.normalizer.EquivalentNormalizer;

public class UrlReplaceNormalizer extends EquivalentNormalizer<String, MalformedURLException> {
    
    protected HashMap<String, String> siteMap; // mirror --> original
    protected HashMap<String, String> urlMap;  // mirror --> original
    
    protected void addSitePair(String mirror, String original) {
        mirror = mirror.toLowerCase(); original = original.toLowerCase();
        String realOriginal = siteMap.get(original);
        if (realOriginal==null) siteMap.put(mirror, original);
        else siteMap.put(mirror, realOriginal);
    }
    
    protected void init() { 
        siteMap = new HashMap<String, String>();
        urlMap = new HashMap<String, String>();
    }

    protected boolean isInit() { return siteMap!=null&&urlMap!=null; }
    
    protected void addUrlPair(String mirror, String original) 
            throws MalformedURLException {
        BasicUrlNormalizer bun = BasicUrlNormalizer.get();
        urlMap.put(bun.normalize(mirror), bun.normalize(original));
    }
    
    protected String getEquivalent(String url) throws MalformedURLException {
        url = BasicUrlNormalizer.get().normalize(url);
        String url1 = getEquivSite(url);
        if (url1==null) url1 = url;
        String url2 = urlMap.get(url1);
        if (url2==null) return url1;
        else return url2;
    }
    
    protected String getEquivSite(String urlString) {
        int startPos = urlString.indexOf(':');
        if (startPos <= 0) return urlString;
        startPos += 3;
        int endPos = urlString.indexOf('/', startPos);
        if (endPos < 0) endPos = urlString.indexOf('?', startPos);
        if (endPos < 0) endPos = urlString.length();
        String site = urlString.substring(startPos, endPos).toLowerCase();
        String mirror = siteMap.get(site);
        if (mirror == null) return null;   
        return urlString.substring(0, startPos) + mirror
            + (endPos < urlString.length() ? urlString.substring(endPos) : "");
    }

}
