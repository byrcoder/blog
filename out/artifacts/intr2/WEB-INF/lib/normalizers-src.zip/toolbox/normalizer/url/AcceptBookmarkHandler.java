/**
 * @(#)AcceptBookmarkHandler.java, 2009-9-6. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.normalizer.url;

/**
 * 稍加改造的参数处理工具，会完成如下的参数处理工作:
 * <ul>
 * <li>删除无效参数，包括phpsession这样的.</li>
 * <li>接受URI里头#之后的东西（按照目前的代码的名称是叫做bookmark,官方名称实际应为fragment）</li>
 * </ul>
 * @author sunly
 */
public class AcceptBookmarkHandler extends DefaultParamHandler {

    /**
     * 接受所有的bookmark.
     */
    public boolean acceptBookmark(String bookmark) {
        return true;
    }

}
