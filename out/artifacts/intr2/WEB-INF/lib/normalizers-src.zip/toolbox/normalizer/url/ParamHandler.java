/**
 * @(#)ParamHandler.java, 2007-6-23. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.normalizer.url;

/**
 * 被UrlNormalizer调用，用于控制normalizer的一些规则，包括参数保留和修改.
 * @author river
 */
public interface ParamHandler {
    
    /**
     * 是否接受某个schema，目前schema可能包括"http", "https", "ftp".
     * @param schema
     * @return
     */
    public boolean acceptSchema(String schema);
    
    /**
     * 是否接受带有username和password的url.
     * @param username
     * @param password
     * @return
     */
    public boolean acceptUserAndPassword(String username, String password);
    
    /**
     * 处理参数，param[0]是参数的名字, param[1]是参数的值. 返回值决定是否保留这个参数.
     * 如果需要修改参数的值，可以直接将新的参数名字或者值设置到param数组中.
     * 
     * @param param
     * @return
     */
    public boolean acceptParam(String [] param);
    
    /**
     * 是否保留某个bookmark.
     * @param bookmark
     * @return
     */
    public boolean acceptBookmark(String bookmark);
    
}
