package toolbox.normalizer.url;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.normalizer.Normalizer;

/**
 * Url正则化工具，同时提供一定的url处理的能力，例如去处一些无效的参数.
 * 
 * <p>
 * 请注意：normalizer本身不对url的每个部分的语法进行任何检查。即，它不会告诉调用者这个host是否合法，
 * 或者path中含有非法字符。因此调用者需要自己决定什么样的url是需要的。该normalizer就像IE浏览器一样，
 * 只是把一个url转化成另一个形式发送出去。
 * 
 * <p>
 * 如下特征被判为非法url：
 * <ol>
 * <li>url长度不能长于1024字节。</li>
 * <li>如果protocol不是http or https。</li>
 * <li>如果端口中包含有非数字字符，或者端口数字不在[0,65535]之间。</li>
 * <li>hostname中包含非法字符（非"0-9a-zA-Z-_.")，包括空格</li>
 * <li>路径中包含"/.../"这样的情况会被认为是非法的</li>
 * </ol>
 * 
 * <p>
 * 对url做了一些处理：
 * <ol>
 * <li>如果url没有指定protocol，默认使用http协议。</li>
 * <li>如果url中包含了username和password，会被丢弃。</li>
 * <li>如果url中的path为空，会加上"/"。</li>
 * <li>如果url中有ISOControl字符，则ignore它。</li>
 * <li>如果url中有' '，则escape它。</li>
 * <li>path中所有的back-slash都将变成slash（query除外）。</li>
 * <li>除去了"."这样的当前路径。</li>
 * <li>除去了".."这样的当前路径，这个会退到上层目录。</li>
 * <li>对于http:www.yodao.com 或者 http:/www.yodao.com 都将变成http://www.yodao.com/。</li>
 * <li>如果在hostname里出现“#”或“?”，那么认为这个hostname在这里已经结束了。例如：
 *     http://www.yodao.com:8080?1/index.html 将变成http://www.yodao.com:8080/?1/index.html。</li>
 * <li>除去了frag，即#以后的部分。</li>
 * <li>protocol, host, query部分一律变成小写。</li>
 * <li>对参数进行排序。</li>
 * </ol>
 * 
 * <p>
 * 对特殊参数的处理：
 * <ol>
 * <li>如果param name中含有"sesion"，那么删除这个param的value。</li>
 * <li>如果param name中含有"phpsess"，那么删除这个param的value。</li>
 * <li>如果param name是"ntime"，那么删除这个param的value。</li>
 * <li>如果param name是"sid"，那么删除这个param的value。</li>
 * <li>删除中path中含有"session"，则删除'='之后的部分。</li>
 * <li>删除中path中含有"phpsess"，则删除'='之后的部分。</li>
 * </ol>
 * 
 * <p>
 * 对于链接中bookmark的处理：
 * <ol>
 * <li>默认情况下bookmark一律被丢弃
 * </ol>
 * 
 * 上面描述的都是默认实现，我们还可以通过传入具体的ParamHandler实现来修改一些规则，具体可以被修改的规则是：
 * <ol>
 * <li>决定是否允许ftp协议
 * <li>决定是否保留username, password
 * <li>决定是否保留或者修改每个参数
 * <li>决定是否保留bookmark
 * </ol>
 * 具体的说明参考{@link ParamHandler}.
 * 
 * <p>
 * 目前已知和IE不一致的地方：
 * <ol>
 * <li>http:/ /www.yodao.com/在IE中变成http:///www.yodao.com/，而这里变成了http://%20/www.yodao.com/ </li>
 * </ol>
 * @author Feng Jiang, river
 * @see ParamHandler
 * 
 * Mar 16, 2007
 */
public class UrlNormalizer implements Normalizer<String, MalformedURLException> {
    public static final String PROTO_HTTP = "http";
    public static final String PROTO_HTTPS = "https";
    public static final String PROTO_FTP = "ftp";
    
    public static final int PORT_HTTP = 80;
    public static final int PORT_HTTPS = 443;
    public static final int PORT_FTP = 21;
    
    /**
     * The hostname check level.
     * <ul>
     * <li>1 : allow all the one label host, such as "http://netease/"
     * <li>2 : deny all the one label host, except "localhost"
     * <li>3 : deny all the one label host
     * </ul>
     */
    public static final int STRICT_HOSTNAME_LEVEL = 2;
    
    public static final int MAX_URL_LENGTH = 2048;

    private ParamHandler paramHandler = new DefaultParamHandler();

    private static UrlNormalizer DEFAULT_INSTANCE = new UrlNormalizer();
    
    /**
     * Normalize one url in default way.
     * @param target
     * @return
     * @throws MalformedURLException
     */
    public static String normalizeUrl(String target) throws MalformedURLException {
        return DEFAULT_INSTANCE.normalize(target);
    }
    
    public class QueryParam implements Comparable<QueryParam>{
        String key;
        String value;
        
        public QueryParam(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public int compareTo(QueryParam o) {
            return this.key.compareTo(o.key);
        }
    }

    protected boolean bufferEquals(StringBuilder builder, int offset, int len, String s) {
        if (len != s.length()) {
            return false;
        }
        
        for (int i=0; i<len; i++) {
            if (builder.charAt(i + offset) != s.charAt(i)) {
                return false;
            }
        }
        
        return true;
    }
    
    public void setParamHandler(ParamHandler handler) {
        this.paramHandler = handler;
    }
    
    public String normalize(String target) throws MalformedURLException {
        if(target.length() > MAX_URL_LENGTH)
            throw new MalformedURLException("Length of the url is greater than 256 bytes.");

        int offset = 0;
        int targetLength = target.length();
        // remove leading space and control char
        while (offset < targetLength) {
            char ch = target.charAt(offset);
            if (ch != ' ' && !Character.isISOControl(ch)) {
                break;
            }
            offset ++;
        }
        // remove trailing space and control char
        while (targetLength > offset) {
            char ch = target.charAt(targetLength-1);
            if (ch != ' ' && !Character.isISOControl(ch)) {
                break;
            }
            targetLength --;
        }
        
        // create the buffer for normalized url
        StringBuilder sb = new StringBuilder(targetLength + 16);

        // process the protocol
        // we only accept "http", "https" and "ftp" protocol here
        // and we check the illegal character in host
        int defPort = 0;
        int commaIdx = -1;
        String protoString = null;
        for (int i = offset; i<targetLength; i ++) {
            char c = target.charAt(i); 
            if(c == ':') {
                commaIdx = i;
                protoString = target.substring(offset, commaIdx);
                if (protoString.equalsIgnoreCase(PROTO_HTTP)) {
                    protoString = PROTO_HTTP;
                    defPort = PORT_HTTP;
                    sb.append(PROTO_HTTP);
                } else if (protoString.equalsIgnoreCase(PROTO_HTTPS)) {
                    protoString = PROTO_HTTPS;
                    defPort = PORT_HTTPS;
                    sb.append(PROTO_HTTPS);
                } else if (protoString.equalsIgnoreCase(PROTO_FTP)) {
                    protoString = PROTO_FTP;
                    defPort = PORT_FTP;
                    sb.append(PROTO_FTP);
                } else {
                    throw new MalformedURLException("Unsupported protocol for: " + target);
                }
                break;
            } else if (!Character.isLetter(c)) {//c may be / or \ or SPACE or other
                break;
            }
        }
        
        // set default proto if not found
        if (commaIdx < 0) {
            protoString = PROTO_HTTP;
            sb.append(PROTO_HTTP);
            defPort = 80;
        }
        if (!paramHandler.acceptSchema(protoString)) {
            throw new MalformedURLException("Unsupported protocol for : " + target);
        }
        
        sb.append("://");

        // skip '/', '\\' and find the start pos of hostname
        int hostIdx = commaIdx + 1;
        while (hostIdx < targetLength) {
            char ch = target.charAt(hostIdx);
            if(ch != '/' && ch != '\\')
                break;
            hostIdx ++;
        }
        
        // throw exception if we cannot find hostname
        if(hostIdx == targetLength)
            throw new MalformedURLException("No host in the url: " + target);

        // process the hostname and port
        // we check the label count in hostname, there should be 
        // at least 2 labels if STRICT_HOSTNAME_CHECK is true
        boolean portFound = false;
        int labelCount = 0; // hostname label count
        int lastLabelLength = 0;
        int hostnameStartOffset = sb.length();
        int portStartOffset = -1;
        boolean userFound = false;
        String hostName = null;
        int hostStart = hostIdx;
        
        while (hostIdx < targetLength) {
            char c = target.charAt(hostIdx);
            if (Character.isISOControl(c)) {
                // ignore control char
                hostIdx ++;
                hostStart ++;
                continue;
            }
            if (c == '@') {
                if (userFound) {
                    throw new MalformedURLException("dup @ in hostname part for url " + target);
                }
                userFound = true;
                
                String username, password;
                if (portStartOffset >= 0) {
                    username = sb.substring(hostnameStartOffset, portStartOffset);
                    password = sb.substring(portStartOffset+1);
                } else {
                    username = sb.substring(hostnameStartOffset);
                    password = "";
                }
                if (paramHandler.acceptUserAndPassword(username, password)) {
                    sb.append('@');
                    hostnameStartOffset = sb.length();
                } else {
                    sb.setLength(hostnameStartOffset);
                }
                
                // restart host finding
                portFound = false;
                portStartOffset = -1;
                labelCount = 0;
                lastLabelLength = 0;
                hostIdx ++;
                continue;
            }
            
            if(c =='?' || c == '#' || c=='/' || c=='\\') {
                // stop char of hostname
                break;
            }
            if (!portFound) {
                if (c == ':') {
                    portFound = true;
                    portStartOffset = sb.length();
                    sb.append(c);
                } else if (c == '.') {
                    if (lastLabelLength == 0) {
                        throw new MalformedURLException("bad hostname for url " + target);
                    }
                    sb.append(c);
                    labelCount ++;
                    lastLabelLength = 0;
                } else {
                    sb.append(c);
                    lastLabelLength++;
                }
            } else {
                // append port for future
                sb.append(c);
            }
            hostIdx ++;
        }

        hostName = target.substring(hostStart, hostIdx);
        
        // validate the hostname and change to lowercase
        int hostnameEndOffset = portStartOffset < 0 ? sb.length() : portStartOffset;
        for (int i=hostnameStartOffset; i<hostnameEndOffset; i++) {
            char ch = sb.charAt(i);
            ch = Character.toLowerCase(ch);
            if (!(ch=='-' || ch=='_' || (ch>='0' && ch<='9') || (ch>='a' && ch<='z') || ch == '.')) {
                throw new MalformedURLException("bad character \"" + ch + "\" found in hostname for url " + target);
            }
            sb.setCharAt(i, ch);
        }
        
        // validate and remove port string from buffer
        int port = defPort;
        if (portStartOffset >= 0) {
            port = 0;
            for (int i=portStartOffset +1; i<sb.length(); i++) {
                char ch = sb.charAt(i);
                if (ch >='0' && ch <='9') {
                    port = port * 10 + (sb.charAt(i) - '0' );
                } else {
                    throw new MalformedURLException("bad character \"" + ch + "\" found in port for url " + target);
                }
            }
            sb.setLength(portStartOffset);
        }
        
        // check the label count
        if (lastLabelLength > 0) {
            labelCount ++;
        }
        boolean isValidHostname;
        if (STRICT_HOSTNAME_LEVEL == 1) {
            isValidHostname = labelCount > 0;
        } else if (STRICT_HOSTNAME_LEVEL == 2) {
            isValidHostname = (labelCount > 1) || (labelCount==1 && bufferEquals(sb, hostnameStartOffset, sb.length()-hostnameStartOffset, "localhost"));
        } else {
            isValidHostname = labelCount > 1;
        }
        if (!isValidHostname) {
            throw new MalformedURLException("bad hostname for url " + target);
        }
        
        // remove the last dot in hostname
        if (sb.charAt(sb.length()-1)== '.') {
            sb.setLength(sb.length()-1);
        }
        
        // append the port if it is non-default port
        if (port != defPort) {
            if (port <= 0 || port > 65535) {
                throw new MalformedURLException("bad port in url " + target);
            }
            sb.append(':').append(port);
        }

        // add the splitter('/') between hostname and path, and skip the first '/' in path
        int pathIdx = hostIdx;
        sb.append('/');
        if (pathIdx < targetLength && target.charAt(pathIdx) == '/') {
            pathIdx ++;
        }
        
        // process path, ignore "." and do ".." removal
        int queryIdx = pathIdx;
        int paramIdx = -1;
        int bookmarkIdx = -1;
        int pathLevel = 0;
        int [] levelIdx = new int[6];
        levelIdx[0] = sb.length();
        
        int dot = 0;
        while (queryIdx < targetLength) {
            char ch = target.charAt(queryIdx);
            if (Character.isISOControl(ch)) {
                // ignore control char
                queryIdx ++;
                continue;
            }
            
            if (ch == '?') {
                break;
            } else if (paramIdx < 0 && bookmarkIdx < 0) {
                if (ch == ';') {
                    paramIdx = queryIdx;
                } else if (ch == '#') {
                    bookmarkIdx = queryIdx;
                } else {
                    if (ch == '/' || ch == '\\') {
                        if (dot == 0 || dot ==1) {
                            // "/./", "//", "/.../" are simply ignored
                        } else if (dot == 2) {
                            if (pathLevel > 0) {
                                // pop the last level
                                pathLevel --;
                                sb.setLength(levelIdx[pathLevel]);
                            }
                        } else if (dot > 2) {
                            // we do not allow "..." as one label
                            throw new MalformedURLException("bad path element in url " + target);
                        } else {
                            // dot < 0, append the slash
                            sb.append('/');
                            pathLevel ++;
                            if (levelIdx.length == pathLevel) {
                                int [] tmp = new int[pathLevel + 2];
                                System.arraycopy(levelIdx, 0, tmp, 0, levelIdx.length);
                                levelIdx = tmp;
                            }
                            levelIdx[pathLevel] = sb.length();
                        }
                        dot = 0;
                    } else if (dot >= 0) {
                        if (ch == '.') {
                            dot ++;
                        } else {
                            for (int d=0; d<dot; d++) {
                                sb.append('.');
                            }
                            dot = -1;
                            sb.append(ch);
                        }
                    } else {
                        sb.append(ch);
                    }
                }
            }
            queryIdx ++;
        }
        
        // remove the last ".."
        if (dot == 2 && pathLevel > 0) {
            pathLevel --;
            sb.setLength(levelIdx[pathLevel]);
        } else if (dot > 2) {
            throw new MalformedURLException("bad path element in url " + target);
        }
        
        // deal with params in path
        if (paramIdx > 0) {
            // we simply ignore param in path
        }

        // deal with query params
        queryIdx ++;
        if (queryIdx < targetLength & bookmarkIdx < 0) {
            ArrayList<QueryParam> params = new ArrayList<QueryParam>(4);
            String name=null;
            String [] paramPair = new String[2];
            int start = queryIdx;
            StringBuilder paramSb = new StringBuilder(20);
            while (queryIdx < targetLength) {
                char ch = target.charAt(queryIdx);
                if (Character.isISOControl(ch)) {
                    // ignore iso control char
                    queryIdx ++;
                    continue;
                }
                
                if (ch == '#') {
                    // stop and check the bookmark later
                    bookmarkIdx = queryIdx;
                    break;
                } else if (ch == '&') {
                    // put current name & value into list
                    if (name == null) {
                        // name without value found
                        if (queryIdx > start) {
                            paramPair[0] = paramSb.toString();
                            paramPair[1] = "";
                            if (paramHandler.acceptParam(paramPair)) {
                                params.add(new QueryParam(paramPair[0], paramPair[1]));
                            }
                        }
                    } else {
                        // name and value found
                        paramPair[0] = name;
                        paramPair[1] = paramSb.toString();
                        if (paramHandler.acceptParam(paramPair)) {
                            params.add(new QueryParam(paramPair[0], paramPair[1]));
                        }
                    }
                    start = queryIdx + 1;
                    name = null;
                    paramSb.delete(0, paramSb.length());
                } else if (ch == '=') {
                    // end of name, start of value
                    name = paramSb.toString();
                    start = queryIdx + 1;
                    paramSb.delete(0, paramSb.length());
                } else {
                    paramSb.append(ch);
                }
                queryIdx ++;              
            }
            
            // last name & value
            if (start < queryIdx) {
                if (name == null) {
                    paramPair[0] = paramSb.toString();
                    paramPair[1] = "";
                    if (paramHandler.acceptParam(paramPair))
                        params.add(new QueryParam(paramPair[0], paramPair[1]));
                } else {
                    paramPair[0] = name;
                    paramPair[1] = paramSb.toString();
                    if (paramHandler.acceptParam(paramPair))
                        params.add(new QueryParam(paramPair[0], paramPair[1]));
                }
            }
            
            if (params.size() > 0) {
                Collections.sort(params);
                sb.append('?');
                QueryParam param = params.get(0);
                if (param.value.length() > 0) {
                    sb.append(param.key).append('=').append(param.value);
                } else {
                    sb.append(param.key);
                }
                for (int i=1; i<params.size(); i++) {
                    param = params.get(i);
                    if (param.value.length() > 0) {
                        sb.append('&').append(param.key).append('=').append(param.value);
                    } else {
                        sb.append('&').append(param.key);
                    }
                }
            }
            
            
        }

        // check if we accept the bookmark, and we only accept one bookmark if multi bookmark found
        if (bookmarkIdx > 0) {
            String bookmark = target.substring(bookmarkIdx + 1);
            if (paramHandler.acceptBookmark(bookmark)) {
                sb.append('#').append(bookmark);
            }
        }
        
        // 增加对一些专门站点的处理方法 add by huangbo
        if (hostName.equals("zhidao.baidu.com")) {
            String url = sb.toString();
            // /question目录下，只保留至数字.html，之后的全部normalize到.html 
            Pattern pp = Pattern.compile("http\\:\\/\\/zhidao\\.baidu\\.com\\/question\\/\\d*\\.html");
            Matcher matcher = pp.matcher(url);
            if (matcher.find()) {
                return matcher.group();
            }
            // /browse/数字 目录下，只保留lm和word和pn选项，排序按照lm,pn,word次序 
            // lm=null等价于lm=0
            pp = Pattern.compile("http\\:\\/\\/zhidao\\.baidu\\.com\\/browse\\/\\d*");
            matcher = pp.matcher(url);
            if (matcher.find()) {
                String res = matcher.group();
                String lm = null;
                String pn = null;
                String word = null;
                String[] parameters = url.split("\\?|\\&");
                for (String tmp : parameters) {
                    if (tmp.contains("lm=")) {
                        int pos = tmp.indexOf("lm=");
                        lm = tmp.substring(pos);
                        if (lm.equals("lm=2")) {
                            lm = null;
                        } else if (lm.equals("lm=null")) {
                            lm = "lm=0";
                        }
                    }
                    if (tmp.contains("pn=")) {
                        int pos = tmp.indexOf("pn=");
                        pn = tmp.substring(pos);
                        if (pn.equals("pn=0")) {
                            pn = null;
                        }
                    }
                    if (tmp.contains("word=")) {
                        int pos = tmp.indexOf("word=");
                        word = tmp.substring(pos);
                    }
                }
                if (lm==null && pn==null && word==null) {
                    return res;
                } else {
                    if (lm!=null) {
                        res = res + "&" + lm;
                    }
                    if (pn!=null) {
                        res = res + "&" + pn;
                    }
                    if (word!=null) {
                        res = res + "&" + word;
                    }
                    res = res.replaceFirst("\\&", "?");
                }
                return res;
            }
        }
        return sb.toString();
    }
    
}