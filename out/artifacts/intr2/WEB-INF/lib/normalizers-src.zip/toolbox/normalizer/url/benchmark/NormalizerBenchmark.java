package toolbox.normalizer.url.benchmark;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.util.HashSet;
import java.util.Set;

import toolbox.normalizer.Normalizer;
import toolbox.normalizer.url.BasicUrlNormalizer;
import toolbox.normalizer.url.UrlNormalizer;

/**
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Mar 26, 2007
 */
public class NormalizerBenchmark {

    public static void main(String[] args) throws Exception {
        
        Set<String> set = new HashSet<String>();
        Normalizer<String, MalformedURLException> normalizer = null;
        long start = 0, end = 0;
        
        BufferedReader r = new BufferedReader(new FileReader("./url.list"));
        String line = null;
        int total = 100000;
        int count = 0;
        while( (line = r.readLine()) != null ) {
            line = line.trim();
            set.add(line);
            count++;
            if(count>=total)
                break;
        }
        r.close();
        
        normalizer = new UrlNormalizer(); 
        start = System.currentTimeMillis();
        for(String url : set) {
            try{
//                System.out.println(url);
                normalizer.normalize(url);
            }catch(MalformedURLException e){
                
            }catch(Exception e){
                System.err.println(url);
                throw new RuntimeException(e);
            }
        }
        end = System.currentTimeMillis();
        System.out.println(total + " urls cost: " + (end-start) + " millisec for IEStyledUrlNormalizer.");
        
        normalizer = new BasicUrlNormalizer();
        start = System.currentTimeMillis();
        for(String url : set) {
            try{
                normalizer.normalize(url);
            }catch(MalformedURLException e){
                
            }catch(Exception e){
//                System.err.println(url);
//                throw new RuntimeException(e);
            }
        }
        end = System.currentTimeMillis();
        System.out.println(total + " urls cost: " + (end-start) + " millisec for BasicUrlNormalizer.");
        
        normalizer = new UrlNormalizer(); 
        start = System.currentTimeMillis();
        for(String url : set) {
            try{
//                System.out.println(url);
                normalizer.normalize(url);
            }catch(MalformedURLException e){
                
            }catch(Exception e){
                System.err.println(url);
                throw new RuntimeException(e);
            }
        }
        end = System.currentTimeMillis();
        System.out.println(total + " urls cost: " + (end-start) + " millisec for IEStyledUrlNormalizer.");
        
    }
    
}
