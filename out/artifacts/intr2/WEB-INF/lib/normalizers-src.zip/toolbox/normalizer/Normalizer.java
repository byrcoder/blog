package toolbox.normalizer;


public interface Normalizer<T, E extends Exception> {
    
    public abstract T normalize(T target) throws E;

}
