package toolbox.normalizer.url;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;
import java.util.TreeMap;
import java.util.Map.Entry;

import toolbox.normalizer.Normalizer;

/**
 * TODO reseved chars should be translated into %xxx
 * @deprecated please use IEStyledUrlNormalizer instead.
 */
public class BasicUrlNormalizer implements Normalizer<String, MalformedURLException> {
    
    private static final BasicUrlNormalizer instance = new BasicUrlNormalizer();
    private static final String DEFAULT_PROTOCOL = "http://";
    
    public static BasicUrlNormalizer get() { return instance; }

    public String normalize(String url) throws MalformedURLException {
        return normalize(url, DEFAULT_PROTOCOL);
    }
    public String normalize(String url, String defaultProtocol) throws MalformedURLException {
        String u = removeReservedChars(url);
        URLRecord ou = new URLRecord(u, defaultProtocol);

        normalizeCase(ou);
        removeDefaultPort(ou);
        removeBookmark(ou);

        detectUnsupportPort(ou);
        detectUnsupportHost(ou);

        removeRelativePath(ou);
        removeSessionID(ou);

        return ou.toString();
    }
    
    private String removeReservedChars(String url) throws MalformedURLException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < url.length(); i++){
            if ( !Character.isISOControl(url.charAt(i)) )
                sb.append(url.charAt(i));
        }
        return sb.toString();
    }

    private static HashMap<String, Integer> DefaultPort = null;
    static {
        // add default port here
        DefaultPort = new HashMap<String, Integer>();
        DefaultPort.put("http", 80);
        DefaultPort.put("https", 443);
        DefaultPort.put("ftp", 21);
    }

    private void normalizeCase(URLRecord url) throws MalformedURLException {
        url.protocol = url.protocol.toLowerCase();
        url.host = url.host.toLowerCase();
    }  

    private void removeBookmark(URLRecord url) throws MalformedURLException {
        url.bookmark = "";
    }

    private void removeDefaultPort(URLRecord url) throws MalformedURLException {
        Integer r = DefaultPort.get(url.protocol);
        if (r==null) r=-1;
        if (url.port == r) url.port = 0;
    }

    private void detectUnsupportPort(URLRecord url) throws MalformedURLException {
        if (url.port < 0 || url.port > 65535)
            throw new MalformedURLException("Unsupport Port Number");
    }

    /**
     * Detect unsupport hostname
     * @param url  the url record
     * @throws MalformedURLException  when unsupport chars occur in url
     */
    private void detectUnsupportHost(URLRecord url) throws MalformedURLException {

        // From RFC1738 http://www.faqs.org/rfcs/rfc1738.html
        //    host           = hostname | hostnumber
        //    hostname       = *[ domainlabel "." ] toplabel
        //    domainlabel    = alphadigit | alphadigit *[ alphadigit | "-" ] alphadigit
        //    toplabel       = alpha | alpha *[ alphadigit | "-" ] alphadigit
        //    alphadigit     = alpha | digit
        //    hostnumber     = digits "." digits "." digits "." digits
        // current : do not differ hostname and hostnumber    

        String now = url.host;
        int nLabels = 0;
        int index = -1;
        while (true) {
            index = now.indexOf(".");
            if (index == -1 && now.length() == 0)
                break;
            nLabels ++;
            String name = null;
            if (index == -1) {
                name = now;
                now = "";
            } else {
                name = now.substring(0, index);
                now = now.substring(index + ".".length());
            }
            if (name.length() == 0)
                throw new MalformedURLException("Empty Part in Host");
            for (int i = 0; i < name.length(); i++) {
                char ch = name.charAt(i);
                if (!(ch == '-' || ch == '_' || ch >= '0' && ch <= '9' || ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z'))
                    throw new MalformedURLException("Unsupported Char in Host");
            }
        }
        if ( nLabels < 2)
            throw new MalformedURLException("the domain name only have 1 label");
        // remove the last period
        if(url.host.length() >0 && url.host.charAt(url.host.length()-1) == '.')
            url.host = url.host.substring(0, url.host.length()-1);
    }

    private void removeRelativePath(URLRecord url) throws MalformedURLException {
        // process relative path in file
        if (url.path.size() == 0)
            return;
        Stack<String> stack = new Stack<String>();
        for (int i = 0; i < url.path.size(); i++) {
            String name = url.path.get(i);
            if (name.equals("."))
                continue;
            if (name.equals("..")) {
                if (stack.size() > 0)
                    stack.pop();
                continue;
            }
            stack.push(name);
        }
        url.path = new ArrayList<String>(stack);
    }

    private void removeSessionID(URLRecord url) throws MalformedURLException {
        // process possible session id
        // current : remove parameter name = PHPSESSID and value = [a-zA-Z0-9]{32}
        String value = url.params.get("PHPSESSID");
        if (value != null && value.length() == 32+1) {
            boolean flag = true;
            for (int i = 1; i < value.length(); i++) {
                char ch = value.charAt(i);
                if ( !(ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z' 
                    || ch >= '0' && ch <= '9')) {
                    flag = false;
                    break;
                }
            }
            if (flag)
                url.params.remove("PHPSESSID");
        }
        value = url.params.get("jsessionid");
        if (value != null && value.length() == 32+1) {
            boolean flag = true;
            for (int i = 1; i < value.length(); i++) {
                char ch = value.charAt(i);
                if ( !(ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z' 
                    || ch >= '0' && ch <= '9')) {
                    flag = false;
                    break;
                }
            }
            if (flag)
                url.params.remove("jsessionid");
        }
        value = url.params.get("sid");
        if (value != null && value.length() == 32+1) {
            boolean flag = true;
            for (int i = 1; i < value.length(); i++) {
                char ch = value.charAt(i);
                if (! (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z' 
                    || ch >= '0' && ch <= '9')) {
                    flag = false;
                    break;
                }
            }
            if (flag)
                url.params.remove("sid");
        }

    }

    public static void main(String[] args) throws Exception {
        URL url = new URL("httP://wwW. tsinghua.edu.cn/index.html?a=1");
        System.out.println("Protocol : " + url.getProtocol());
        System.out.println("Host : " + url.getHost());
        System.out.println("File : " + url.getFile());
        System.out.println("Default Port : " + url.getDefaultPort());
        System.out.println(URLEncoder.encode("清华大学", "UTF-8"));
        System.out.println(URLEncoder.encode("清华大学", "UTF-16"));
        System.out.println(URLEncoder.encode("清华大学", "GB2312"));
        System.out.println(URLEncoder.encode("清华大学", "GBK"));
        System.out.println();
        System.out.println(URLEncoder.encode(" ", "UTF-8"));
        System.out.println(URLEncoder.encode(" ", "UTF-16"));
        System.out.println(URLEncoder.encode(" ", "GB2312"));
        System.out.println(URLEncoder.encode(" ", "GBK"));

        BasicUrlNormalizer normalizer = new BasicUrlNormalizer();
        System.out.println(normalizer.normalize("http://test.com/./aa//./../a.html"));
        System.out.println(normalizer.normalize("http://test.com/../aa/bb/../../cc/../foo.html"));
        System.out.println(normalizer.normalize("http://test.com/aa/bb/../../cc/../foo.html"));
        System.out.println(normalizer.normalize("http://test.com/foo.html"));
        System.out.println(normalizer.normalize("http://test.com/../foo.html"));
        System.out.println(normalizer.normalize("http://ww.test.com/../foo.html"));
        System.out.println(normalizer.normalize("http://ww.test.com/../foo.html"));
        System.out.println(normalizer.normalize("http:/ww.test.com/../foo.html"));
        System.out.println(normalizer.normalize("http://a.a./foo.html"));
        System.out.println(normalizer.normalize("http://showbook.asp?bl_id=5647http:///showbook.asp?Bl_id=5647"));
        System.out.println(normalizer.normalize("http://v6188.com/"));
        System.out.println(normalizer.normalize("www.sina.com.cn"));
    }
}

/**
 * @author refactored by Alan
 */
class URLRecord {
    // each element in a url
    protected String protocol;
    protected String host;
    protected int port;               // port == 0 means default port
    protected ArrayList<String> path; // each path element
    protected String file;            // file
    protected String bookmark;
    protected TreeMap<String, String> params;

    private static final String HOST_SPLIT = "://";
    private static final String HOST_SPLIT_1 = ":/";
    private static final String PORT_SPLIT = ":";
    private static final String PATH_SPLIT = "/";
    private static final String PARAM_SPLIT = ";";
    private static final String FRAGMENT_SPLIT = "#";
    private static final String QUERY_SPLIT = "?";
    private static final String QUERY_INTER_SPLIT = "&";
    private static final String QUERY_INNER_SPLIT = "=";

    public URLRecord(String url, String defaultProtocol) throws MalformedURLException {
        path = new ArrayList<String>();
        params = new TreeMap<String, String>();
        parseURL(url, defaultProtocol);
    }

    private boolean checkProtocol(String protocol) {
        for(int i=0; i<protocol.length(); i++){
            char c = protocol.charAt(i);
            if ( c>='a'&&c<='z' || c>='A'&&c<='Z' || c>='0'&&c<='9' ) continue;
            else return false;
        }
        return true;
    }

    /**
     * Parse raw string of whole url string to structed URL Record
     * @param url
     */
    private void parseURL(String url, String defaultProtocol)  throws MalformedURLException {
        String now = url.trim();
      
        // protocol
        int index = now.indexOf(HOST_SPLIT);
        if (index == -1){
            index = now.indexOf(HOST_SPLIT_1);
            if (index == -1) {
                now = defaultProtocol + now;
                index = defaultProtocol.length()  - HOST_SPLIT.length();
                protocol = now.substring(0, index);
                now = now.substring(index + HOST_SPLIT.length());
                }
            else {
                protocol = now.substring(0, index);
                now = now.substring(index + HOST_SPLIT_1.length());    
            }
            
        } else {
            // do not make protocol string to lowercases 
            protocol = now.substring(0, index);
            now = now.substring(index + HOST_SPLIT.length());
        }
        if (!checkProtocol(protocol))
            throw new MalformedURLException("Illigal Protocol in url "  + url);

        // bookmark: deal with the fragment and remove it
        int indexFragment = now.indexOf(FRAGMENT_SPLIT);
        if ( indexFragment>0 ) {
            bookmark = now.substring(indexFragment+1);
            now = now.substring(0,indexFragment);
        }
        // from now on, "now" do not conains fragment
        
        // now the string now is xxx:xx/xxx?xxx#???
        int indexPort = now.indexOf(PORT_SPLIT);
        int indexPath = now.indexOf(PATH_SPLIT);
        int indexParam = now.indexOf(PARAM_SPLIT);
        int indexQuery = now.indexOf(QUERY_SPLIT);


        
        // Part means the part after scheme and "//", now exactly as RFC 2396
        int indexPart = Integer.MAX_VALUE;
        if ( indexPath >= 0 && indexPart > indexPath )
            indexPart = indexPath;
        if ( indexParam >= 0 && indexPart > indexParam )
            indexPart = indexParam;
        if ( indexQuery >= 0 && indexPart > indexQuery )
            indexPart = indexQuery;

        // deal with  authority -- host:port
        int endOfHostPort=indexPart;
        if ( endOfHostPort == Integer.MAX_VALUE ){
            endOfHostPort = now.length();
        }
        if (indexPort > 0 && indexPort < endOfHostPort ) {
            // there is no path, file & param
            host = now.substring(0, indexPort);
            try {
                if (indexPart < 0)
                    port = Integer.parseInt(now.substring(indexPort + PORT_SPLIT.length()));
                else
                    port = Integer.parseInt(now.substring(indexPort + PORT_SPLIT.length(),endOfHostPort));
            } catch (NumberFormatException ex) {
                throw new MalformedURLException(
                        "Invalid Port Number with url = " + url);
            }
        } else{
            host = now.substring(0,endOfHostPort);
        }

        // deal with the path/query/fragment
        // if the path is null, use "/"
        // FIXME param things as http://xxx;hehe/hehe?hehe what is it?
        int lastPathSplit = 0;
        if ( indexPart != indexPath || indexPath == -1 ){
            // donot need to add path : path.add("") X
            lastPathSplit = indexPart;
        } else{
            // there is path, then split path
            int lastIndex = now.indexOf(PATH_SPLIT,indexPart)+1;
            lastPathSplit = lastIndex;
            while (true) {
                index = now.indexOf(PATH_SPLIT,lastIndex);
                if (index == -1)
                    break;
                else if (indexQuery > 0 && index > indexQuery) 
                    break;
                String name = now.substring(lastIndex, index);
                if (name.length() != 0)
                    path.add(name);
                lastIndex=index+1;
                lastPathSplit = lastIndex;
            }
        }
        
        //deal with the file
        if (indexQuery < 0){
            if (indexPath < 0)
                file = "";
            else{
                if (indexParam < 0)
                    file = now.substring(lastPathSplit);
                else 
                    file = now.substring(lastPathSplit,indexParam);
                if (file.equals("..") || file.equals(".")) {
                    path.add(file);
                    file = "";
                }
            }
            return;
        } else {         // deal with query 
            if (indexParam < indexQuery && indexParam >= lastPathSplit)
                file = now.substring(lastPathSplit,indexParam);
            else
                file = now.substring(lastPathSplit,indexQuery);
            int lastSplit = indexQuery;
            while (true) {
                int begin = lastSplit + 1;
                int end=begin;                
                index = now.indexOf(QUERY_INTER_SPLIT,begin);
                if (index == -1 )
                    break;
                end=index;
                if ( begin == end ){
                    lastSplit = end;                    
                    break;
                }
                index = now.indexOf(QUERY_INNER_SPLIT,begin);
                if (index >= 0 && index < end  ) {
                    String name = now.substring(begin, index);
                    if (name.length() != 0)
                        params.put(name, now.substring(index ,end));
                } else {
                    if ( begin < end )
                        params.put(now.substring(begin,end), "");
                    lastSplit = end;
                    break;
                }
                lastSplit = end;                
            }
            // deal with the remains query
            if (lastSplit<now.length()) {
                int begin = lastSplit + 1;                
                int end = now.length();              
                index = now.indexOf(QUERY_INNER_SPLIT,begin);
                if (index >= 0 && index < end  ) {
                    String name = now.substring(begin, index);
                    if (name.length() != 0)
                        params.put(name, now.substring(index ,end));
                } else {
                    if ( begin < end )
                        params.put(now.substring(begin,end), "");
                    lastSplit = end;
                }
            }
        } 
        
        if ( file!=null && ( file.equals("..") || file.equals(".")) ) {
            path.add(file);
            file = "";
        }
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(protocol);
        sb.append(HOST_SPLIT);
        sb.append(host);
        sb.append(port == 0 ? "" : PORT_SPLIT + port);

        for (int i = 0; i < path.size(); i++)
            sb.append(PATH_SPLIT + path.get(i));
        sb.append(PATH_SPLIT + file);
        if(bookmark.length() > 0)
            sb.append(FRAGMENT_SPLIT + bookmark);
        if (!params.isEmpty()) {
            sb.append("?");
            int index = 0;
            for (Entry<String, String> entry : params.entrySet()) {
                sb.append((index == 0 ? "" : "&") + entry.getKey() + entry.getValue());
                index++;
            }
        }
        return sb.toString();
    }
}