package toolbox.normalizer.url;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.normalizer.EquivalentNormalizer;

public abstract class UrlTemplateNormalizer extends EquivalentNormalizer<String, MalformedURLException> {
     
    protected ArrayList<Template> urlTemplates;  // url pattern --> target pattern
    
    protected boolean isInit = false;
    
    synchronized protected void init() {
        if(isInit)
            return;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(getConfFile()));
            try {
                urlTemplates = new ArrayList<Template>();
                String ln;
                while ((ln = reader.readLine()) != null)
                    urlTemplates.add(new Template(ln));
                isInit = true;
            } finally {
                reader.close();
            }
        } catch (IOException e) {
            urlTemplates = null; throw new RuntimeException(e);
        }
    }
    
    protected boolean isInit() {
        return isInit;
    }
    
    UrlNormalizer urlNormalizer = new UrlNormalizer();
    protected String getEquivalent(String url) throws MalformedURLException {
        url = urlNormalizer.normalize(url);
        for (Template list: urlTemplates) {
            String u = list.wrap(url);
            if (u != null) return u;
        }
        return null;
    }
    
    protected abstract File getConfFile();
    
    @SuppressWarnings("serial")
    public static class MalformedRuleException extends IOException {
        public MalformedRuleException(String msg) { super(msg); }
    }
    
    public static class Template {
        private Pattern pattern;
        private String target;

        public Template(String line) throws MalformedRuleException {
            String[] strs = line.split("::");
            if (strs.length != 2) 
                throw new MalformedRuleException("Wrong substitution rule: " + line);
            pattern = Pattern.compile(strs[0]);
            target = strs[1];
        }

        public String wrap(String source) {
            if (pattern == null) return null;
            String dest = target;
            Matcher m = pattern.matcher(source);
            if (m.matches() && m.groupCount() > 0) {
                for (int i = 1; i <= m.groupCount(); i++)
                    dest = dest.replace("{$" + i + "}", m.group(i));
                return dest;
            } else  return null;
        }
    }

}
