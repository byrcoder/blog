/**
 * @(#)DefaultParamHandler.java, 2007-6-23. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.normalizer.url;

/**
 * 默认的参数处理工具，会完成如下的参数处理工作:
 * <ul>
 * <li>删除无效参数，包括phpsession这样的.
 * </ul>
 * @author river
 */
public class DefaultParamHandler implements ParamHandler {

    public static final String [] SESSION_NAMES = {
        "phpsess", "session", "PHPSESS", "SESSION"};
    
    protected boolean removeSessionKey(String [] param) {
        for (String s : SESSION_NAMES) {
            if (param[0].contains(s)) {
                return false;
            }
        }
        return true;
    }
    
    public static final String [] RANDOM_PARAMS = {
        "sid", 
        "ntime"};
    public static final int MIN_RANDOM_PARAM_LENGTH = 6;
    
    protected boolean removeRandomParam(String [] param) {
        if (param[1].length() >= MIN_RANDOM_PARAM_LENGTH) {
            for (String s : RANDOM_PARAMS) {
                if (param[0].equalsIgnoreCase(s)) return false;
            }
        }
        return true;
    }
    
    public boolean acceptParam(String[] param) {
        if (!removeSessionKey(param)) return false;
        if (!removeRandomParam(param)) return false;
        
        return true;
    }

    /**
     * 忽略所有的bookmark.
     */
    public boolean acceptBookmark(String bookmark) {
        
        return false;
    }

    /**
     * 接受ftp以外的其他protocol, 也就是"http"和"https".
     */
    public boolean acceptSchema(String schema) {
        return !schema.equals(UrlNormalizer.PROTO_FTP);
    }

    /**
     * 忽略所有的username和password.
     */
    public boolean acceptUserAndPassword(String username, String password) {
        return false;
    }

}
