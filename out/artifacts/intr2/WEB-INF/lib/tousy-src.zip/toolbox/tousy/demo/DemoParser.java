package toolbox.tousy.demo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Properties;

import toolbox.tousy.html.HTMLElements;
import toolbox.tousy.html.HTMLHandler;
import toolbox.tousy.html.HTMLScanner;

/**
 * 解析一个目录下的所有文件，并且将解析的结果输出到文件.
 * @author river
 *
 */
public class DemoParser {
	private static final boolean HTML_ONLY = true;
	
	private File input;
	private File output;
	private long size;
	private int pages;
	
	public DemoParser(File input, File output) {
		this.input = input;
		this.output = output;
	}
	
	/**
	 * @param file
	 * @param files
	 */
	private void explore(File file, ArrayList<File> files) {
		if (file.isDirectory()) {
			File [] arr = file.listFiles();
			for (int i=0; i<arr.length; i++)
				explore(arr[i], files);
		} else {
			files.add(file);
		}
	}
	

	/**
	 * @throws Exception
	 */
	public void parse() throws Exception {
		ArrayList<File> files = new ArrayList<File>();
		explore(input, files);
		HTMLScanner scanner = new HTMLScanner();
		scanner.setAutoParse(HTMLElements.A, true);
		scanner.setAutoParse(HTMLElements.AREA, true);
		scanner.setAutoParse(HTMLElements.FORM, true);
		scanner.setAutoParse(HTMLElements.FRAME, true);
		scanner.setAutoParse(HTMLElements.IFRAME, true);
		scanner.setAutoParse(HTMLElements.IMG, true);
		scanner.setAutoParse(HTMLElements.LINK, true);
		scanner.setAutoParse(HTMLElements.META, true);
		
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(output)), true);
		try {
			ParserHandler handler = new ParserHandler(writer);
			scanner.registerHtmlHandler(handler);
			
			for (File file : files) {
				if (HTML_ONLY) {
					String name = file.getName().toLowerCase();
					if (!name.endsWith(".html") && !name.endsWith(".htm"))
						continue;
				}
				
				size += file.length();
				pages ++;
				handler.startFile(file.getName());
				FileReader reader = new FileReader(file);
				try {
					scanner.clear();
					scanner.scan(reader);
				} finally {
					handler.endFile(file.getName());
					reader.close();
				}
			}
		} finally {
			writer.close();
		}
	}
	
	public static void usage() {
		System.out.println("param: input output");
	}
	
	public static void main(String [] args) throws Exception {
        if (args.length < 2) {
			usage();
			return;
		}

		DemoParser parser = new DemoParser(new File(args[0]), new File(args[1]));
		
		long start = System.currentTimeMillis();
		parser.parse();
		long end = System.currentTimeMillis();
		
		System.out.println(parser.size + " bytes in " + parser.pages + " pages parsed, elapse time is " + (end-start) + "ms.");
	}
    
    public static class ParserHandler implements HTMLHandler {

        private boolean inTitle;
        private boolean inSpecial;

        private StringBuffer title;
        private StringBuffer text;
        private PrintWriter writer;
        private ArrayList<String> links;

        public ParserHandler(PrintWriter writer) {
            title = new StringBuffer(128);
            text = new StringBuffer(4096);
            links = new ArrayList<String>();
            this.writer = writer;
        }

        public void startFile(String filename) {
            writer.println("[BEGIN:" + filename + ">]");
        }

        public void endFile(String filename) {
            writer.println("[END:" + filename + "]");
            writer.println();
        }

        /**
         * 开始一个html对象.
         * 
         * @throws ParseException
         */
        public void startDocument() {
            title.setLength(0);
            text.setLength(0);
            links.clear();
            inTitle = false;
            inSpecial = false;
        }

        /**
         * 结束一个html对象.
         * 
         * @throws ParseException
         */
        public void endDocument() {

            writer.println("<TITLE>");
            writer.println(title.toString());
            writer.println("</TITLE>");

            writer.println("<TEXT>");
            writer.println(text.toString());
            writer.println("</TEXT>");
        }

        /**
         * 开始一个html 的tag.
         * 
         * @param name
         * @param code
         *            tag element 的数字标识，例如HTMLElements.UNKOWN
         * @param attributes
         *            如果没有处理，这个可以是null
         * @param attrValue
         */
        public void startElement(String name, int code, Properties attributes,
                char[] attrBuffer, int offset, int count) {

            if (code == HTMLElements.TITLE) {
                inTitle = true;
                return;
            }

            if (HTMLElements.findElement(code).isSpecial()) {
                inSpecial = true;
                return;
            }

            String link;
            if (code == HTMLElements.A || code == HTMLElements.AREA
                    || code == HTMLElements.LINK) {
                link = (attributes == null) ? null : attributes.getProperty("HREF");
                if (link != null)
                    links.add(link);
                return;
            }

            if (code == HTMLElements.FRAME || code == HTMLElements.IFRAME
                    || code == HTMLElements.IMG) {
                link = (attributes == null) ? null : attributes.getProperty("SRC");
                if (link != null)
                    links.add(link);
            }

        }

        /*
         * (non-Javadoc)
         * 
         * @see tousy.html.HTMLHandler#emptyElement(java.lang.String, int,
         *      java.util.Properties, char[], int, int)
         */
        public void emptyElement(String name, int code, Properties attributes,
                char[] attrBuffer, int offset, int count) {
            startElement(name, code, attributes, attrBuffer, offset, count);
            endElement(name, code);
        }

        /**
         * 结束一个html的tag.
         * 
         * @param name
         * @param code
         */
        public void endElement(String name, int code) {
            if (code == HTMLElements.TITLE)
                inTitle = false;

            if (HTMLElements.findElement(code).isSpecial())
                inSpecial = false;
        }

        /**
         * 处理html的文本.对应的文本已经将"&amp;..."这样字符解析出来了.
         * 
         * @param buf
         */
        public void characters(char[] buf, int offset, int count) {
            if (inSpecial)
                return;

            if (inTitle) {
                if (title.length() > 512)
                    inTitle = false;
                else {
                    title.append(buf, offset, count);
                    return;
                }
            }

            text.append(buf, offset, count);
        }

        /**
         * 处理注释，对应的文本没有经过任何处理.
         * 
         * @param buf
         */
        public void comment(char[] buf, int offset, int count) {

        }

        /**
         * 处理DOCTYPE的声明.
         * 
         * @param root
         * @param pubid
         * @param sysid
         * @throws ParseException
         */
        public void declDoctype(String root, String pubid, String sysid) {

        }

    }

}
