package toolbox.tousy.html;

import java.util.Properties;

/**
 * Dispatch callback to registered handlers.
 * @author river
 *
 */
public class CompositeHTMLHandler implements HTMLHandler {
	private static HTMLHandler [] EMPTY_HANDLERS = new HTMLHandler[0];
	
	private HTMLHandler [] handlers = EMPTY_HANDLERS;

	public void registerHandler(HTMLHandler handler) {
		HTMLHandler [] newHandlers = new HTMLHandler[handlers.length+1];
		if (handlers.length>0) {
			System.arraycopy(handlers, 0, newHandlers, 0, handlers.length);
		}
		handlers = newHandlers;
		handlers[handlers.length-1] = handler;
	}
	
	public void characters(char[] buf, int offset, int count) {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].characters(buf, offset, count);
		}
	}

	public void comment(char[] buf, int offset, int count) {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].comment(buf, offset, count);
		}
	}

	public void declDoctype(String root, String pubid, String sysid) {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].declDoctype(root, pubid, sysid);
		}
	}

	public void emptyElement(String name, int code, Properties attributes, char[] attrBuffer, int offset, int count) {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].emptyElement(name, code, attributes, attrBuffer, offset, count);
		}
	}

	public void endDocument() {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].endDocument();
		}
	}

	public void endElement(String name, int code) {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].endElement(name, code);
		}
	}

	public void startDocument() {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].startDocument();
		}
	}

	public void startElement(String name, int code, Properties attributes, char[] attrBuffer, int offset, int count) {
		for (int i=0; i<handlers.length; i++) {
			handlers[i].startElement(name, code, attributes, attrBuffer, offset, count);
		}
	}
	
	
}
