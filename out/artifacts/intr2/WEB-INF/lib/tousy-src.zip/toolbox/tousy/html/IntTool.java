package toolbox.tousy.html;

import java.util.Arrays;

class IntTool {
    public static int[] HEX_VALUES = new int[128];
    static {
        Arrays.fill(HEX_VALUES, -1);
        HEX_VALUES['0'] = 0;
        HEX_VALUES['1'] = 1;
        HEX_VALUES['2'] = 2;
        HEX_VALUES['3'] = 3;
        HEX_VALUES['4'] = 4;
        HEX_VALUES['5'] = 5;
        HEX_VALUES['6'] = 6;
        HEX_VALUES['7'] = 7;
        HEX_VALUES['8'] = 8;
        HEX_VALUES['9'] = 9;
        HEX_VALUES['a'] = 10;
        HEX_VALUES['A'] = 10;
        HEX_VALUES['B'] = 11;
        HEX_VALUES['b'] = 11;
        HEX_VALUES['c'] = 12;
        HEX_VALUES['C'] = 12;
        HEX_VALUES['d'] = 13;
        HEX_VALUES['D'] = 13;
        HEX_VALUES['e'] = 14;
        HEX_VALUES['E'] = 14;
        HEX_VALUES['f'] = 15;
        HEX_VALUES['F'] = 15;
    }

    /**
     * 将字符串转换成为数字，考虑到文本扫描的时候已经进行了检查，这里不再检查合法性.
     * 
     * @param buf
     * @param offset
     * @param count
     * @return
     */
    public static final int parseHexInt(char[] buf, int offset, int count) {
        int value = 0;

        for (int i = offset; i < offset + count; i++) {
            value = value * 16 + HEX_VALUES[buf[i]];
        }
        return value;
    }

    public static final int parseInt(char[] buf, int offset, int count) {
        int value = 0;
        for (int i = offset; i < offset + count; i++) {
            value = value * 10 + buf[i] - '0';
        }
        return value;
    }

}
