package toolbox.tousy.css;

import org.apache.batik.css.parser.DefaultDocumentHandler;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.SACMediaList;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SelectorList;

/**
 * 包含分析css文档得到的结果。
 *
 * @author river
 * @author liruohao
 */
public class CssDocumentHandler extends DefaultDocumentHandler {
    /**
     * css分析结果
     */
    private CssParseInfo parseInfo = new CssParseInfo();
    
    /**
     * 当前归并到的declarations
     */
    private Declarations currentDeclarations = null;
    
    /**
     * 如果media类型不是all或screen，我们不关心为该媒体类型指定的规则集
     */
    boolean isNeglectableMedia;
    
    /**
     * 返回css分析结果
     * @return css分析结果
     */
    public CssParseInfo getParseInfo() {
        return parseInfo;
    }
    
    public void importStyle(String uri, SACMediaList media, String defaultNamespaceURI) {
        if (uri != null && uri.length() > 0) {
            parseInfo.addImport(uri);
        }
    }
    
    public void startMedia(SACMediaList media) throws CSSException {
        boolean isScreen = false;
        for (int i = 0; i < media.getLength(); ++i) {
            String mediaType = media.item(i);
            if (mediaType.equalsIgnoreCase("ALL") || mediaType.equalsIgnoreCase("SCREEN")) {
                isScreen = true;
                break;
            }
        }
        
        isNeglectableMedia = !isScreen;
    }
    
    public void endMedia(SACMediaList media) throws CSSException {
        isNeglectableMedia = false;
    }
    
    public void startSelector(SelectorList selectors) throws CSSException {
        currentDeclarations = new Declarations();
    }

    public void endSelector(SelectorList selectors) throws CSSException {
        if (!isNeglectableMedia) {
            for (int i = 0; i < selectors.getLength(); ++i) {
                Selector selector = selectors.item(i);
                short selectorType = selector.getSelectorType();
                // 我们不处理下列情况：
                // 1. E > F
                // 2. E F
                // 3. E + F
                if (selectorType == Selector.SAC_CHILD_SELECTOR
                        || selectorType == Selector.SAC_DESCENDANT_SELECTOR
                        || selectorType == Selector.SAC_DIRECT_ADJACENT_SELECTOR) {
                    continue;
                }
                
                parseInfo.addRuleSet(selector, currentDeclarations);
            }
        }
    }

    public void property(String name, LexicalUnit value, boolean important) throws CSSException {
        currentDeclarations.put(name, value);
    }
    
    public void endDocument(InputSource source) throws CSSException {
        parseInfo.buildIndex4Ws();
    }
    
    /**
     * 清空对象的内部状态
     *
     */
    public void clear() {
        parseInfo.clear();
        currentDeclarations = null;
        isNeglectableMedia = false;
    }
    
    /**
     * 返回对象的字符串表示
     */
    public String toString() {
        return parseInfo.toString();
    }
}
