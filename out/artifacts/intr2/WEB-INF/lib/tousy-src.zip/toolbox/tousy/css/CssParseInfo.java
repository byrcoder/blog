/**
 * @(#)CssParseInfo.java, 2007-8-17. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tousy.css;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.w3c.css.sac.Selector;

/**
 * css分析结果
 * 
 * @author liruohao
 */
public class CssParseInfo {
    /**
     * 所有规则集
     */
    private List<RuleSet> ruleSets = new ArrayList<RuleSet>();
    
    /**
     * web search优化parser效率所需的一些索引
     */
    private List<RuleSet> backgroundSet = new ArrayList<RuleSet>();
    private List<RuleSet> fontSet = new ArrayList<RuleSet>();
    private List<RuleSet> colorSet = new ArrayList<RuleSet>();
    private List<RuleSet> fontSizeSet = new ArrayList<RuleSet>();
    private List<RuleSet> fontWeightSet = new ArrayList<RuleSet>();
    private List<RuleSet> backgroundImageSet = new ArrayList<RuleSet>();
    private List<RuleSet> backgroundColorSet = new ArrayList<RuleSet>();
    private List<RuleSet> displaySet = new ArrayList<RuleSet>();
    private List<RuleSet> visibilitySet = new ArrayList<RuleSet>();
    
    /**
     * CSS规范中规定，可以通过@import引入其他格式页（style sheets）。
     * 现在我们虽然不处理这种引入，但是仍然维护引入的格式页的地址列表
     */
    private List<String> imports = new ArrayList<String>();
    
    /**
     * web search优化parser效率所需的一些数据结构
     */
    private boolean hasTagAll = false;
    private Set<Short> tagSet = new HashSet<Short>();
    private Set<String> idSet = new HashSet<String>();
    private Set<String> classSet = new HashSet<String>();
    
    
    /**
     * 加入一个规则集
     * @param selector 选择器
     * @param declarations property/value对
     */
    public void addRuleSet(Selector selector, Declarations declarations) {
        RuleSet ruleSet = new RuleSet(selector.toString(), declarations);
        // 二分查找插入的位置
        int low = 0, high = ruleSets.size() - 1, mid = 0;
        int specificity = ruleSet.getSpecificity();
        while (low <= high) {
            mid = (low + high) / 2;
            int curSpecificity = ruleSets.get(mid).getSpecificity();
            if (specificity < curSpecificity) {
                low = mid + 1;
            } else if (specificity > curSpecificity) {
                high = mid - 1;
            } else {
                break;
            }
        }
        if (low > high) {
            mid = low;
        } else {
            while (mid >= 0 && specificity == ruleSets.get(mid).getSpecificity()) {
                --mid;
            }
            ++mid;
        }
        ruleSets.add(mid, ruleSet);
        
        
        SimpleSelector simpleSelector = ruleSet.getSelector();
        
        Short tagCode = simpleSelector.getTagCode();
        if((tagCode == SimpleSelector.TAG_ALL) && 
                ((simpleSelector.getId() == null) || (simpleSelector.getId().length() <= 0)) && 
                ((simpleSelector.getClazzes() == null) || (simpleSelector.getClazzes().size() <= 0))) {
            hasTagAll = true;
        }
        tagSet.add(tagCode);
        
        String id = simpleSelector.getId();
        if((id != null) && (id.length() > 0)) {
            idSet.add(id.toLowerCase());
        }
        
        Set<String> clazzes = simpleSelector.getClazzes();
        if((clazzes != null) && (clazzes.size() > 0)) {
            classSet.addAll(clazzes);
        }
        
        
    }
    
    
    /**
     * web serach优化parser效率建立一些索引
     */
    public void buildIndex4Ws() {
        backgroundSet.clear();
        fontSet.clear();
        colorSet.clear();
        fontSizeSet.clear();
        fontWeightSet.clear();
        backgroundImageSet.clear();
        backgroundColorSet.clear();
        displaySet.clear();
        visibilitySet.clear();
        
        for (RuleSet ruleSet : ruleSets) {
            
            if(ruleSet.getDeclarations().has(CssProperties.BACKGROUND)) {
                backgroundSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.FONT)) {
                fontSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.COLOR)) {
                colorSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.FONT_SIZE)) {
                fontSizeSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.FONT_WEIGHT)) {
                fontWeightSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.BACKGROUND_IMAGE)) {
                backgroundImageSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.BACKGROUND_COLOR)) {
                backgroundColorSet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.DISPLAY)) {
                displaySet.add(ruleSet);
            }
            if(ruleSet.getDeclarations().has(CssProperties.VISIBILITY)) {
                visibilitySet.add(ruleSet);
            }
        }
    }
    
    /**
     * 加入一个css引入
     * @param uri css引入地址
     */
    public void addImport(String uri) {
        imports.add(uri);
    }
    
    /**
     * 返回符合特定需求的declarations
     * @param propertyCode 所需的css属性
     * @param tagCode html元素名称
     * @param id html元素id
     * @param clazzes html元素所属的class（可以有多个）
     * @param inlineDeclarations inline declarations
     * @return 符合特定需求的declarations
     */
    public Declarations getDeclarations(short propertyCode, short tagCode, String id,
            Set<String> clazzes, Declarations inlineDeclarations) {
        if (inlineDeclarations != null && inlineDeclarations.has(propertyCode)) {
            return inlineDeclarations;
        }
        
        return getDeclarations(propertyCode, tagCode, id, clazzes);
    }
    
    /**
     * 返回符合特定需求的declarations
     * @param propertyCode 所需的css属性
     * @param tagCode html元素名称
     * @param id html元素id
     * @param clazzes html元素所属的class（可以有多个）
     * @return 符合特定需求的declarations
     */
    public Declarations getDeclarations(short propertyCode, short tagCode, String id, Set<String> clazzes) {
        // RuleSet.match要求比较的字符串都是大写的
        id = (id == null ? null : id.toLowerCase());
        Set<String> upperClazzes = new HashSet<String>(2);
        for (String clazz : clazzes) {
            upperClazzes.add(clazz.toLowerCase());
        }
        
        for (RuleSet ruleSet : ruleSets) {
            if (ruleSet.match(propertyCode, tagCode, id, upperClazzes)) {
                return ruleSet.getDeclarations();
            }
        }
        
        return null;
    }
    
    /**
     * 返回符合特定需求的declarations, for web search parser效率优化
     * @param propertyCode 所需的css属性
     * @param tagCode html元素名称
     * @param id html元素id
     * @param clazzes html元素所属的class（可以有多个）
     * @param inlineDeclarations inline declarations
     * @return 符合特定需求的declarations
     */
    public Declarations getDeclarations4Ws(short propertyCode, short tagCode, String id,
            Set<String> clazzes, Declarations inlineDeclarations) {
        if (inlineDeclarations != null && inlineDeclarations.has(propertyCode)) {
            return inlineDeclarations;
        }
        
        return getDeclarations(propertyCode, tagCode, id, clazzes);
    }
    
    
    /**
     * 返回符合特定需求的declarations,  for web search parser效率优化
     * @param propertyCode 所需的css属性
     * @param tagCode html元素名称
     * @param id html元素id
     * @param clazzes html元素所属的class（可以有多个）
     * @return 符合特定需求的declarations
     */
    public Declarations getDeclarations4Ws(short propertyCode, short tagCode, String id, Set<String> clazzes) {
        // RuleSet.match要求比较的字符串都是大写的
        id = (id == null ? null : id.toLowerCase());
        Set<String> upperClazzes = new HashSet<String>(2);
        for (String clazz : clazzes) {
            upperClazzes.add(clazz.toLowerCase());
        }
        
        List<RuleSet> customRuleSet;
        switch (propertyCode) {
            case CssProperties.BACKGROUND:
                customRuleSet = backgroundSet;
                break;
            case CssProperties.FONT:
                customRuleSet = fontSet;
                break;
            case CssProperties.COLOR:
                customRuleSet = colorSet;
                break;
            case CssProperties.FONT_SIZE:
                customRuleSet = fontSizeSet;
                break;
            case CssProperties.FONT_WEIGHT:
                customRuleSet = fontWeightSet;
                break;
            case CssProperties.BACKGROUND_IMAGE:
                customRuleSet = backgroundImageSet;
                break;
            case CssProperties.BACKGROUND_COLOR:
                customRuleSet = backgroundColorSet;
                break;
            case CssProperties.DISPLAY:
                customRuleSet = displaySet;
                break;
            case CssProperties.VISIBILITY:
                customRuleSet = visibilitySet;
                break;
            default:
                customRuleSet = ruleSets;
                break;
        }
        
        for (RuleSet ruleSet : customRuleSet) {
            if (ruleSet.match(propertyCode, tagCode, id, upperClazzes)) {
                return ruleSet.getDeclarations();
            }
        }
        
        return null;
    }
    
    public List<RuleSet> getRuleSets() {
        return ruleSets;
    }
    
    public boolean getHasTagAll() {
        return hasTagAll;
    }
    
    public Set<Short> getTagSet() {
        return tagSet;
    }
    
    public Set<String> getIdSet() {
        return idSet;
    }
    
    public Set<String> getClassSet() {
        return classSet;
    }
    
    public boolean hasTag(short tag) {
        return (hasTagAll || tagSet.contains(tag));
    }
    
    public boolean hasId(String id) {
        return idSet.contains(id.toLowerCase());
    }
    
    public boolean hasClass(String clazz) {
        return classSet.contains(clazz);
    }
    
    /**
     * 清空对象的内部状态
     *
     */
    public void clear() {
        ruleSets.clear();
        imports.clear();
        tagSet.clear();
        idSet.clear();
        classSet.clear();
        hasTagAll = false;
        
        backgroundSet.clear();
        fontSet.clear();
        colorSet.clear();
        fontSizeSet.clear();
        fontWeightSet.clear();
        backgroundImageSet.clear();
        backgroundColorSet.clear();
        displaySet.clear();
        visibilitySet.clear();
    }
    
    /**
     * 返回对象的字符串表示
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("RULE_SETS: ").append(ruleSets).append("\n");
        
        return sb.toString();
    }
}
