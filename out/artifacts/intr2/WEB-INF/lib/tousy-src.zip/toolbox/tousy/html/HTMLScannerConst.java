package toolbox.tousy.html;

public interface HTMLScannerConst {
	public static final int STATE_CONTENT = 0;
	public static final int STATE_MARKUP_BRACKET = 1;
	public static final int STATE_START_DOCUMENT = 2;
	public static final int STATE_END_DOCUMENT = 3;
	
}
