package toolbox.tousy.html;

import java.util.Properties;

public class AttributesHelper {

	public static Properties parse(char [] buf, int offset, int count) {
		Properties properties = new Properties();
		HTMLScanner scanner = new HTMLScanner(buf, offset, offset + count);
		try {
			scanner.scanAttribute(properties);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return properties;
	}
	
	public static void main(String [] args) throws Exception {
		String s = "<a href=\"http://www.google.com\" onclick=\"javascript:this()\" >";
		char [] buf = s.toCharArray();
//		Properties properties = new Properties();
		Attributes properties = new Attributes();
		
		long start = System.currentTimeMillis();
		for (int i=0; i<1000000; i++) {
			properties.clear();
			HTMLScanner scanner = new HTMLScanner(buf, 2, buf.length);
			scanner.scanAttribute(properties);
			properties.getProperty("HREF");
			properties.getProperty("ONCLICK");
		}
		long end = System.currentTimeMillis();
		
		System.out.println("Elapse time : " + (end-start)+ " ms.");
		
	}
}
