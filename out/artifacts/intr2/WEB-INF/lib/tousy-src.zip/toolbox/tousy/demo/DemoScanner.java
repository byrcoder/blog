package toolbox.tousy.demo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import toolbox.tousy.html.HTMLElements;
import toolbox.tousy.html.HTMLScanner;

public class DemoScanner {

	public void explore(File dir, HashMap<String, byte [] > found) throws Exception {
		if (dir.isDirectory()) {
			File [] files = dir.listFiles();
			for (int i=0; i<files.length; i++) {
				explore(files[i], found);
			}
		} else {
			if (dir.getName().endsWith(".html")) {
				FileInputStream fis = new FileInputStream(dir);
				try {
					byte [] buf = new byte[fis.available()];
					fis.read(buf);
					found.put(dir.getAbsolutePath(), buf);
				} finally {
					fis.close();
				}
			}
		}
	}

	public void scan(File file) throws Exception {
		long size = 0;
		HTMLScanner scanner = new HTMLScanner();
		
		scanner.setAutoParse(HTMLElements.A, true);
		scanner.setAutoParse(HTMLElements.IMG, true);
		scanner.setAutoParse(HTMLElements.META, true);
		
		long start = System.currentTimeMillis();
		HashMap<String, byte []> found = new HashMap<String, byte []>();
		explore(file, found);
		for (Map.Entry<String, byte []> entry : found.entrySet()) {
			System.out.println("parse : " + entry.getKey());
			size += entry.getValue().length;
			InputStreamReader reader = new InputStreamReader(new ByteArrayInputStream(entry.getValue()));
			scanner.clear();
			scanner.scan(reader);
		}
		long end = System.currentTimeMillis();
		
		System.out.println("Size = " + size + ", elapse time is " + (end-start) + "ms");
	}
	
	public static void usage() {
		System.out.println("params: filename | dir");
	}
	
	public static void main(String [] args) throws Exception {
		if (args.length<1) {
			usage();
			return;
		}
		new DemoScanner().scan(new File(args[0]));
	}
}
