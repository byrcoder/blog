package toolbox.tousy.html;

public class HTMLEscape {

	public static String encode(String s) {
		if (s == null) return null;
		if (s.length() == 0) return "";
		
		int len = s.length();
		StringBuilder builder = new StringBuilder(len);
		char [] arr = s.toCharArray();
		for (int i=0; i<len; i++) {
			char c = arr[i];
			String name = HTMLEntities.getName(c); 
			if ( name != null) {
				builder.append('&').append(name).append(';');
			} else {
				builder.append(c);
			}
		}
		return builder.toString();
	}
	
}
