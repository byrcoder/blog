/**
 * @(#)RawHTMLScanner.java, 2009-5-31. Copyright 2009 Youdao, Inc. All rights
 *                          reserved. YOUDAO PROPRIETARY/CONFIDENTIAL. Use is
 *                          subject to license terms.
 */
package toolbox.tousy.html;

import java.io.EOFException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

/**
 * @author sunly
 */
public class RawHTMLScanner implements HTMLScannerConst {

    private static final Properties EMPTY_PROPERTIES = new Properties();

    private static final boolean DUMP_ON_EXCEPTION = false;

    private static final String ERROR_DUMP_PATH;
    static {
        ERROR_DUMP_PATH = System.getProperty("tousy.HtmlScanner.ErrorDumpPath",
                "/tmp/html_scanner_error");
    }

    private static final int DEFAULT_BUFFER_SIZE = 64 * 1024;

    private static final char[] SPACE = {
        ' '
    };

    protected HTMLTagBalancer handler;

    private char[] defaultBuffer;

    protected char[] buffer;

    protected int offset = 0;

    protected int length = 0;

    private int state;

    private CharBuffer nameBuffer;

    private CharBuffer attributeBuffer;

    private StringBuilder valueBuffer = new StringBuilder(128);

    private CharBuffer markupContentBuffer;

    private CharBuffer refBuffer;

    private Properties attributes;

    private boolean[] autoParsedElements;

    // private boolean lastIsSpace;
    private boolean textBlockStarted;

    private boolean lastSpaceReserved;

    private boolean remainWhiteSpace;

    public RawHTMLScanner() {
        defaultBuffer = new char[DEFAULT_BUFFER_SIZE];
        buffer = defaultBuffer;
        nameBuffer = new CharBuffer(buffer, 0, 0);
        markupContentBuffer = new CharBuffer(buffer, 0, 0);
        attributeBuffer = new CharBuffer(buffer, 0, 0);

        refBuffer = new CharBuffer(64);
        attributes = new Properties();
        autoParsedElements = new boolean[HTMLElements.UNKNOWN];
        Arrays.fill(autoParsedElements, false);

        handler = new HTMLTagBalancer();
    }

    /**
     * 用于内部使用，主要是为了解析attribute列表.
     * 
     * @param buf
     * @param offset
     * @param length
     */
    RawHTMLScanner(char[] buf, int offset, int length) {
        buffer = buf;
        this.offset = offset;
        this.length = length;
        nameBuffer = new CharBuffer(buffer, 0, 0);
        markupContentBuffer = new CharBuffer(buffer, 0, 0);
        attributeBuffer = new CharBuffer(buffer, 0, 0);
    }

    /**
     * 设置对某个tag的自动解析.
     * 
     * @param code
     * @param value
     */
    public void setAutoParse(int code, boolean value) {
        if (code < 0 || code >= HTMLElements.UNKNOWN)
            return;

        autoParsedElements[code] = value;
    }

    public void clear() {
        buffer = defaultBuffer;
        refBuffer.clear();
        offset = 0;
        length = 0;
        // lastIsSpace = true;
        textBlockStarted = false;
        lastSpaceReserved = false;

        remainWhiteSpace = false;
    }

    /**
     * Set the callback handler.
     * 
     * @param handler
     */
    public void registerHtmlHandler(HTMLHandler handler) {
        this.handler.registerHTMLHandler(handler);
    }

    /**
     * Read all content into memory.
     * 
     * @param reader
     * @throws IOException
     */
    private void load(Reader reader) throws IOException {
        while (true) {
            int capacity = buffer.length - length - 1;
            int size = reader.read(buffer, length, capacity);

            if (size < 0)
                break;

            length += size;
            if (size < capacity) {
                break;
            }

            char[] newBuffer = new char[buffer.length << 1];
            System.arraycopy(buffer, 0, newBuffer, 0, length);
            buffer = newBuffer;
        }
        nameBuffer.data = buffer;
        markupContentBuffer.data = buffer;
        attributeBuffer.data = buffer;
    }

    private void dumpError(Throwable t) {
        long sequence = System.currentTimeMillis();
        try {
            while (true) {
                File dir = new File(ERROR_DUMP_PATH);
                if (!dir.exists())
                    dir.mkdirs();

                File file = new File(ERROR_DUMP_PATH, String.valueOf(sequence));
                if (file.createNewFile()) {
                    FileWriter contentWriter = new FileWriter(file);
                    try {
                        contentWriter.write(buffer, 0, length);
                    } finally {
                        contentWriter.close();
                    }
                    PrintWriter writer = new PrintWriter(new FileWriter(
                            new File(file.getAbsolutePath() + ".exception")));
                    try {
                        t.printStackTrace(writer);
                    } finally {
                        writer.close();
                    }
                    break;
                }
                sequence++;
            }
        } catch (Throwable ignored) {}

    }

    /**
     * Scan the content in reader.
     * 
     * @param reader
     * @throws IOException
     */
    public void scan(Reader reader) throws IOException {
        clear();
        load(reader);
        handler.startDocument();
        this.state = STATE_CONTENT;
        try {
            scan();
        } catch (Throwable e) {
            System.err
                    .println("Exception occur during html scanning, data length is "
                            + length
                            + " and current offset is "
                            + offset
                            + ", " + e.getClass().getName());
            if (e instanceof Error || e instanceof RuntimeException)
                e.printStackTrace();

            if (DUMP_ON_EXCEPTION)
                dumpError(e);
        } finally {
            handler.endDocument();
        }
    }

    /**
     * Insert content at current offset.
     * 
     * @param buf
     * @param offset
     * @param length
     */
    public void insert(char[] buf, int off, int len) {
        if (len == 0) {
            return;
        }

        char[] newBuf = new char[this.length + len];
        System.arraycopy(buffer, 0, newBuf, 0, this.offset);
        System.arraycopy(newBuf, this.offset, buf, off, len);
        System.arraycopy(buffer, this.offset, newBuf, this.offset + len,
                this.length - this.offset);
        buffer = newBuf;
        this.length = this.length + len;

        nameBuffer.data = buffer;
        markupContentBuffer.data = buffer;
        attributeBuffer.data = buffer;
    }

    /**
     * Return the decode buffer.
     * 
     * @return
     */
    public char[] getBuffer() {
        return buffer;
    }

    /**
     * Return the length of decode buffer.
     * 
     * @return
     */
    public int getBufferLength() {
        return length;
    }

    /**
     * Returns true if the specified text is present and is skipped.
     * 
     * @param s
     * @param caseSensitive
     * @return
     * @throws IOException
     */
    private boolean skip(String s, boolean caseSensitive) throws IOException {

        int sLen = s != null ? s.length() : 0;
        if (length - offset < sLen)
            return false;

        int oldOffset = offset;
        char c0, c1;
        for (int i = 0; i < sLen; i++) {
            c0 = s.charAt(i);
            c1 = buffer[offset++];
            if (!caseSensitive) {
                c0 = Character.toLowerCase(c0);
                c1 = Character.toLowerCase(c1);
            }
            if (c0 != c1) {
                offset = oldOffset;
                return false;
            }
        }
        return true;
    }

    /**
     * Skips markup and return if the markup is closed.
     * 
     * @throws IOException
     */
    private boolean skipMarkup() throws IOException {
        return skipMarkupDirectly();
    }

/**
     * Skips markup and return if the markup is closed or seen '<'
     * 
     * @throws IOException
     */
    private boolean skipMarkupDirectly() throws IOException {
        while (offset < length) {
            char c = buffer[offset++];
            if (c == '<') {
                offset--;
                return false;
            } else if (c == '>') {
                return false;
            } else if (c == '/') {
                if (offset < length) {
                    c = buffer[offset++];
                    if (c == '>')
                        return true;
                }
            }
        }
        return false;
    }

    /*
     * skip <% content %> return when seen %>,if '%>' doesn't exist,return when
     * reach the end this rule is according to IE
     */
    private void skipClosePercent() {
        char c;
        while (offset < length) {
            c = buffer[offset++];
            if (c == '%') {
                if (offset < length) {
                    c = buffer[offset++];
                    if (c == '>')
                        return;
                }
            }
        }
    }

    /**
     * Returns the new lines skipped.
     * 
     * @param maxlines
     * @return
     * @throws IOException
     */
    private int skipNewlines() throws IOException {

        if (offset == length) {
            return 0;
        }

        char c = buffer[offset];
        int newlines = 0;

        if (c == '\n' || c == '\r') {
            do {
                c = buffer[offset++];
                if (c == '\r') {
                    newlines++;
                    if (offset == length) {
                        break;
                    }

                    if (buffer[offset] == '\n') {
                        offset++;
                    }
                } else if (c == '\n') {
                    newlines++;
                    if (offset == length) {
                        break;
                    }
                } else {
                    offset--;
                    break;
                }
            } while (true);
        }

        return newlines;
    }

    /**
     * Scan text in tag into markupContentBuffer and return true if EOF
     * encountered.
     * 
     * @param cend
     * @return
     * @throws IOException
     */
    private void scanMarkupContent(char cend) throws IOException {

        markupContentBuffer.offset = offset;
        markupContentBuffer.limit = offset;
        int firstBracket = -1;

        char c;
        while (offset < length) {
            c = buffer[offset++];
            if (c == cend) {
                int count = 1;
                while (offset < length && (c = buffer[offset++]) == cend) {
                    count++;
                }
                if (offset < length && count >= 2 && c == '>') {
                    markupContentBuffer.limit = offset - 3;
                    return;
                }
            } else if (c == '>') {
                if (firstBracket == -1) {
                    firstBracket = offset;
                }
            }

        }
        if (offset == length && firstBracket != -1) {
            markupContentBuffer.limit = firstBracket - 1;
            offset = firstBracket;
        } else {
            markupContentBuffer.limit = length;
        }
    }

    /**
     * scan <comment> this is comment </comment> note that we start at
     * "this is comment",not start at"<comment>"
     * 
     * @throws IOException
     */
    private void scanCloseComment() throws IOException {
        int thisState = STATE_CONTENT;
        char c;
        int oldOffset = offset;
        int endOffset;

        while (offset < length) {
            switch (thisState) {
                case STATE_CONTENT:
                    c = buffer[offset++];
                    if (c == '<') {
                        thisState = STATE_MARKUP_BRACKET;
                        continue;
                    }
                    break;
                case STATE_MARKUP_BRACKET:
                    endOffset = offset - 1;

                    c = buffer[offset++];
                    if (c != '/') {
                        thisState = STATE_CONTENT;
                        offset--;// it may be ...<</comment>
                        continue;
                    }
                    scanName();
                    HTMLElements.ElementEntry entry = HTMLElements
                            .findElementByName(nameBuffer);
                    if (entry.code == HTMLElements.COMMENT) {
                        if (buffer[offset] == '\\') {
                            continue;
                        }
                        skipMarkup();// here we should skip mark up
                        handler.comment(buffer, oldOffset, endOffset
                                - oldOffset);
                        return;
                    }
                    thisState = STATE_CONTENT;
            }
        }
    }

    /**
     * scan <!--comment-->,note that we start at "comment",not "<!"
     * 
     * @throws IOException
     */
    private void scanComment() throws IOException {
        scanMarkupContent('-');
        handler.comment(markupContentBuffer.data, markupContentBuffer.offset,
                markupContentBuffer.limit - markupContentBuffer.offset);
    }

    private void scanCDATA() throws IOException {
        scanMarkupContent(']');
    }

    private boolean skipSpaces() throws IOException {
        boolean spaces = false;

        while (offset < length) {
            char c = buffer[offset];
            if (!Character.isWhitespace(c)) {
                break;
            }
            offset++;
            spaces = true;
        }

        return spaces;
    }

    protected boolean isLetterOrDigit(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
                || (c >= '0' && c <= '9');
    }

    protected boolean isWhitespace(char c) {
        return (c >= 9 && c <= 13) || (c >= 28 && c <= 32);
    }

    /**
     * Scan name entry and store it into nameBuffer.
     * 
     * @return
     * @throws IOException
     */
    protected void scanName() throws IOException {

        nameBuffer.offset = offset;
        nameBuffer.limit = offset;

        if (offset == length) {
            return;
        }

        while (offset < length) {
            char c = buffer[offset];

            if (!isLetterOrDigit(c)
                    && !(c == '-' || c == '.' || c == ':' || c == '_')) {
                break;
            }
            offset++;
        }

        nameBuffer.limit = offset;
        return;
    }

    /**
     * Scan a quoted literal.
     * 
     * @return
     * @throws IOException
     */
    protected String scanLiteral() throws IOException {
        if (offset == length) {
            return null;
        }

        int quote = buffer[offset++];

        if (quote == '\'' || quote == '"') {
            StringBuilder str = new StringBuilder();
            int c;

            while (true) {
                if (offset == length)
                    throw new EOFException();

                c = buffer[offset++];

                if (c == quote) {
                    break;
                }

                if (c == '\r' || c == '\n') {
                    offset--;
                    skipNewlines();
                    str.append(' ');
                } else if (c == '<') {
                    offset--;
                    break;
                } else {
                    str.append((char) c);
                }
            }
            return str.toString();
        } else {
            offset--;
        }
        return null;
    }

    private void scanDoctype() throws IOException {

        String root = null;
        String pubid = null;
        String sysid = null;

        if (skipSpaces()) {
            scanName();
            root = nameBuffer.toString();

            if (skipSpaces()) {
                if (skip("PUBLIC", false)) {
                    skipSpaces();
                    pubid = scanLiteral();
                    if (skipSpaces()) {
                        sysid = scanLiteral();
                    }
                } else if (skip("SYSTEM", false)) {
                    skipSpaces();
                    sysid = scanLiteral();
                }
            }
            handler.declDoctype(root, pubid, sysid);
        }

        int c;
        while (offset < length) {

            c = buffer[offset++];

            if (c == '<') {
                offset--;
                break;
            }
            if (c == '>') {
                break;
            }
            if (c == '[') {
                skipMarkup();
                break;
            }
        }
    }

    private void scanPI() throws IOException {
        skipMarkup();
    }

    boolean scanAttributeFast() throws IOException {
        char c = 0;
        boolean slashFound = false;

        attributeBuffer.offset = offset;

        while (offset < length) {
            slashFound = false;

            while (offset < length) { // search for the fist name_char
                c = buffer[offset++];
                if (c == '/')
                    slashFound = true;
                else if (c == '>') {
                    attributeBuffer.offset = offset - (slashFound ? 2 : 1);
                    return slashFound;
                } else if (c < CharCategory.TAG_NAME_FLAG_LENGTH
                        && CharCategory.TAG_NAME_FLAG[c]) {
                    break;
                } else
                    slashFound = false;
            }

            while (offset < length) { // scan name
                c = buffer[offset++];
                if (c >= CharCategory.TAG_NAME_FLAG_LENGTH
                        || !CharCategory.TAG_NAME_FLAG[c])
                    break;
            }

            // scan white space
            while (offset < length && c < CharCategory.WHITE_SPACE_FLAG_LENGTH
                    && CharCategory.WHITE_SPACE_FLAG[c])
                c = buffer[offset++];

            if (offset == length) {
                throw new EOFException();
            }

            if (c == '=' && offset < length) {
                // scan value
                c = buffer[offset++];

                while (offset < length
                        && c < CharCategory.WHITE_SPACE_FLAG_LENGTH
                        && CharCategory.WHITE_SPACE_FLAG[c])
                    c = buffer[offset++];

                if (c == '\'' || c == '\"') {
                    char quote = c;
                    while (offset < length && buffer[offset++] != quote);
                } else {
                    while (offset < length) {
                        c = buffer[offset++];
                        if (c == '>') {
                            offset--;
                            break;
                        } else if (c < CharCategory.WHITE_SPACE_FLAG_LENGTH
                                && CharCategory.WHITE_SPACE_FLAG[c]) {
                            break;
                        }
                    }
                }
            } else {
                offset--;
            }
        }

        throw new EOFException();
    }

    boolean scanAttribute(Attributes attributes) throws IOException {
        if (offset == length)
            throw new EOFException();

        attributeBuffer.offset = offset;
        char c;
        boolean slashFound = false;

        while (true) {

            slashFound = false;
            while (offset < length) {
                c = buffer[offset++];
                if (c == '/') {
                    slashFound = true;
                } else if (c == '>') {
                    attributeBuffer.limit = offset - (slashFound ? 2 : 1);
                    return slashFound;
                } else if (!Character.isWhitespace(c)) {
                    offset--;
                    break;
                }
            }

            scanName();
            String name = HTMLElements.findAttributeName(nameBuffer);
            if (name == null)
                name = nameBuffer.toString().toLowerCase();

            if (name == null || name.length() == 0) {
                boolean closed = skipMarkup();
                attributeBuffer.limit = offset - (closed ? 2 : 1);
                return closed;
            }

            skipSpaces();

            if (offset == length)
                throw new EOFException();

            c = buffer[offset++];

            if (c == '/') {
                offset--;
                boolean closed = skipMarkup();
                if (closed) {
                    attributeBuffer.limit = offset - 2;
                } else {
                    attributeBuffer.limit = offset - 1;
                }
                return closed;
            } else if (c == '>') {
                attributeBuffer.limit = offset - 1;
                return false;
            }

            if (c == '=') {
                skipSpaces();
                if (offset == length)
                    throw new EOFException();
                c = buffer[offset++];
                if (c == '>') {
                    attributeBuffer.limit = offset - 1;
                    return false;
                }

                if (c != '\'' && c != '\"') {
                    offset--;
                    boolean useStringBuffer = false;
                    int startOffset = offset;

                    while (offset < length) {
                        c = buffer[offset++];
                        if (isWhitespace(c) || c == '>') {
                            offset--;
                            break;
                        }
                        if (c == '&') {
                            if (!useStringBuffer) {
                                useStringBuffer = true;
                                valueBuffer.setLength(0);
                                valueBuffer.append(buffer, startOffset,
                                        offset - 1);
                            }

                            int ref = scanEntityRef(true);
                            if (ref < 0) {
                                valueBuffer.append('&');
                            } else {
                                valueBuffer.append((char) ref);
                            }
                        } else {
                            if (useStringBuffer)
                                valueBuffer.append(c);
                        }
                    }
                    if (useStringBuffer)
                        attributes.setProperty(name, valueBuffer.toString());
                    else
                        attributes.setProperty(name, buffer, startOffset,
                                offset);

                } else {
                    char quote = c;
                    boolean useStringBuffer = false;
                    int startOffset = offset;

                    while (true) {
                        if (offset == length)
                            throw new EOFException();
                        c = buffer[offset++];
                        if (c == '&') {
                            if (!useStringBuffer) {
                                useStringBuffer = true;
                                valueBuffer.setLength(0);
                                valueBuffer.append(buffer, startOffset,
                                        offset - 1);
                            }

                            int ref = scanEntityRef(true);
                            if (ref < 0) {
                                valueBuffer.append('&');
                            } else {
                                valueBuffer.append((char) ref);
                            }
                        } else if (c == '\t' || c == '\r' || c == '\n') {
                            if (!useStringBuffer) {
                                useStringBuffer = true;
                                valueBuffer.setLength(0);
                                valueBuffer.append(buffer, startOffset,
                                        offset - 1);
                            }

                            valueBuffer.append(' ');
                        } else if (c == quote) {
                            break;
                        } else {
                            if (useStringBuffer)
                                valueBuffer.append(c);
                        }
                    }

                    if (useStringBuffer)
                        attributes.setProperty(name, valueBuffer.toString());
                    else
                        attributes.setProperty(name, buffer, startOffset,
                                offset - 1);
                }
            } else {
                offset--;
            }
        }
    }

    boolean scanAttribute(Properties attributes) throws IOException {
        if (offset == length)
            throw new EOFException();

        attributeBuffer.offset = offset;
        char c;
        boolean slashFound = false;

        while (true) {

            slashFound = false;
            while (offset < length) {
                c = buffer[offset++];
                if (c == '/') {
                    slashFound = true;
                } else if (c == '>') {
                    attributeBuffer.limit = offset - (slashFound ? 2 : 1);
                    return slashFound;
                } else if (!isWhitespace(c)) {
                    offset--;
                    break;
                }
            }

            scanName();
            String name = HTMLElements.findAttributeName(nameBuffer);
            if (name == null)
                name = nameBuffer.toString();

            if (name == null || name.length() == 0) {
                boolean closed = skipMarkup();
                attributeBuffer.limit = offset - (closed ? 2 : 1);
                return closed;
            }

            skipSpaces();

            if (offset == length)
                throw new EOFException();

            c = buffer[offset++];

            if (c == '/') {
                offset--;
                boolean closed = skipMarkup();
                if (closed) {
                    attributeBuffer.limit = offset - 2;
                } else {
                    attributeBuffer.limit = offset - 1;
                }
                return closed;
            } else if (c == '>') {
                attributeBuffer.limit = offset - 1;
                return false;
            }

            if (c == '=') {
                skipSpaces();
                if (offset == length)
                    throw new EOFException();
                c = buffer[offset++];
                if (c == '>') {
                    attributeBuffer.limit = offset - 1;
                    return false;
                }

                if (c != '\'' && c != '\"') {
                    offset--;
                    valueBuffer.setLength(0);
                    while (offset < length) {
                        c = buffer[offset++];
                        if (isWhitespace(c) || c == '>') {
                            offset--;
                            break;
                        }
                        if (c == '&') {
                            int ref = scanEntityRef(true);
                            if (ref < 0) {
                                valueBuffer.append('&');
                            } else {
                                valueBuffer.append((char) ref);
                            }
                        } else {
                            valueBuffer.append(c);
                        }
                    }
                    attributes.setProperty(name.toLowerCase(), valueBuffer
                            .toString());
                } else {
                    char quote = c;
                    valueBuffer.setLength(0);
                    while (true) {
                        if (offset == length)
                            throw new EOFException();
                        c = buffer[offset++];
                        if (c == '&') {
                            int ref = scanEntityRef(true);
                            if (ref < 0) {
                                valueBuffer.append('&');
                            } else {
                                valueBuffer.append((char) ref);
                            }
                        } else if (c == '\t' || c == '\r' || c == '\n') {
                            valueBuffer.append(' ');
                        } else if (c == quote) {
                            break;
                        } else {
                            valueBuffer.append(c);
                        }
                    }
                    attributes.setProperty(name.toLowerCase(), valueBuffer
                            .toString());
                }
            } else {
                offset--;
            }
        }
    }

    /**
     * Scan the attribute table of tag and return if the tag is closed. Values
     * are not records in order for acceleration.
     * 
     * @throws ParseException
     * @throws IOException
     */
    private boolean scanAttribute() throws IOException {

        if (offset == length)
            throw new EOFException();

        attributeBuffer.offset = offset;

        while (true) {
            skipSpaces();
            char c = buffer[offset];
            if (c == '>') {
                attributeBuffer.limit = offset;
                offset++;
                return false;
            }

            scanName();
            if (nameBuffer.limit <= nameBuffer.offset) {
                boolean closed = skipMarkup();
                attributeBuffer.limit = offset - (closed ? 2 : 1);
                return closed;
            }

            skipSpaces();
            if (offset == length)
                throw new EOFException();

            c = buffer[offset++];

            if (c == '/') {
                offset--;
                boolean closed = skipMarkup();
                attributeBuffer.limit = (closed) ? offset - 2 : offset - 1;
                return closed;
            } else if (c == '>') {
                attributeBuffer.limit = offset - 1;
                return false;
            }

            if (c == '=') {
                skipSpaces();
                if (offset == length)
                    throw new EOFException();
                c = buffer[offset++];
                if (c == '>') {
                    attributeBuffer.limit = offset - 1;
                    return false;
                }

                if (c != '\'' && c != '\"') {
                    offset--;
                    while (offset < length) {
                        c = buffer[offset++];
                        if (isWhitespace(c) || c == '>') {
                            offset--;
                            break;
                        }
                    }
                } else {
                    char quote = c;
                    while (offset < length && buffer[offset++] != quote);
                }
            } else {
                offset--;
            }
        }
    }

    private void scanStartElement() throws IOException {
        int oldOffset = offset;

        scanName();
        if (nameBuffer.limit == nameBuffer.offset) {
            handler.characters(buffer, oldOffset - 1, 1);
            return;
        }

        String elementName;
        int elementCode = HTMLElements.UNKNOWN;

        HTMLElements.ElementEntry elementEntry = HTMLElements
                .findElementByName(nameBuffer);

        if (elementEntry.code == HTMLElements.UNKNOWN) {
            elementName = nameBuffer.toString().toLowerCase();
        } else {
            elementName = elementEntry.name;
            elementCode = elementEntry.code;
        }

        int nameLength = elementName != null ? elementName.length() : 0;
        int c = (nameLength > 0) ? elementName.charAt(0) : -1;

        if (nameLength == 0
                || !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
            handler.characters(buffer, oldOffset - 1, 1);
            offset = oldOffset;
            return;
        }

        boolean closed;

        // we simply parse all known tags here
        if (elementCode != HTMLElements.UNKNOWN) {
            if (elementCode == HTMLElements.PRE) {
                // reserve space for "<PRE>"
                remainWhiteSpace = true;
            }
            attributes.clear();
            closed = scanAttribute(attributes);
            if (elementCode == HTMLElements.COMMENT) {
                // scan for close of comment
                scanCloseComment();
            } else {
                if (elementEntry.isBlock() || elementCode == HTMLElements.P) {
                    // restart the text block for block elements, such as "<p>"
                    textBlockStarted = false;
                    lastSpaceReserved = false;
                }
                handler.startElement(elementName, elementCode, attributes,
                        attributeBuffer.data, attributeBuffer.offset,
                        attributeBuffer.limit - attributeBuffer.offset);
            }
        } else {
            closed = scanAttribute();
            handler.startElement(elementName, elementCode, EMPTY_PROPERTIES,
                    attributeBuffer.data, attributeBuffer.offset,
                    attributeBuffer.limit - attributeBuffer.offset);

        }

        if (elementCode != HTMLElements.COMMENT) {
            if (closed
                    && (elementEntry.isEmpty() || elementCode == HTMLElements.UNKNOWN)) {
                /*
                 * we end closed element while this element's property is empty
                 * or it is unknown html element
                 */
                handler.endElement(elementName, elementCode);
            } else {
                if (elementEntry.isSpecial()) {
                    scanSpecialElement(elementName, elementCode);
                }
            }
        }
    }

    private void scanEndElement() throws IOException {
        scanName();
        String elementName;
        int elementCode;
        HTMLElements.ElementEntry entry = HTMLElements
                .findElementByName(nameBuffer);

        elementName = (entry.code == HTMLElements.UNKNOWN) ? nameBuffer
                .toString() : entry.name;
        elementCode = entry.code;

        if (elementCode == HTMLElements.PRE) {
            remainWhiteSpace = false;
        } else if (entry.isBlock() || elementCode == HTMLElements.P) {
            // restart the text block for block elements, such as "<p>"
            textBlockStarted = false;
            lastSpaceReserved = false;
        }

        skipMarkup();
        handler.endElement(elementName, elementCode);
    }

    /**
     * Scan special element such as "TEXTAREA", "SCRIPT", "STYLE", all content
     * between start and end is regarded as characters.
     * 
     * @throws IOException
     */
    private void scanSpecialElement(String name, int code) throws IOException {
        int thisState = STATE_CONTENT;
        char c;
        int oldOffset = offset;
        int endOffset;

        boolean escapeEntity = false;

        if (code == HTMLElements.TEXTAREA) {
            // if the tag is TEXTAREA,we should escape entity
            escapeEntity = true;
        }

        while (offset < length) {
            switch (thisState) {
                case STATE_CONTENT:
                    c = buffer[offset++];
                    if (c == '<') {
                        thisState = STATE_MARKUP_BRACKET;
                        continue;
                    }
                    if (escapeEntity && c == '&') {
                        endOffset = offset - 1;
                        int ref = scanEntityRef(false);
                        if (ref >= 0) {
                            handler.characters(buffer, oldOffset, endOffset
                                    - oldOffset);
                            char[] tmp = {
                                (char) ref
                            };
                            handler.characters(tmp, 0, 1);
                            oldOffset = offset;
                        }
                    }
                    break;
                case STATE_MARKUP_BRACKET:
                    endOffset = offset - 1;

                    c = buffer[offset++];
                    if (c != '/') {
                        thisState = STATE_CONTENT;
                        offset--;// it may be ...<&nbsp;</TAG> or ...<</TAG>
                        continue;
                    }
                    scanName();
                    HTMLElements.ElementEntry entry = HTMLElements
                            .findElementByName(nameBuffer);
                    if (entry.code == code) {
                        if (buffer[offset] == '\\') {
                            // "</tag\...>" are characters, not end tag
                            continue;
                        }
                        skipMarkup();// here we should skip mark up
                        handler.characters(buffer, oldOffset, endOffset
                                - oldOffset);
                        handler.endElement(name, code);
                        return;
                    }
                    thisState = STATE_CONTENT;
            }
        }
        if (offset > oldOffset) {
            handler.characters(buffer, oldOffset, offset - oldOffset);
        }
    }

    protected int fixWindowsCharacter(int origChar) {
        switch (origChar) {
            case 130:
                return 8218;
            case 131:
                return 402;
            case 132:
                return 8222;
            case 133:
                return 8230;
            case 134:
                return 8224;
            case 135:
                return 8225;
            case 136:
                return 710;
            case 137:
                return 8240;
            case 138:
                return 352;
            case 139:
                return 8249;
            case 140:
                return 338;
            case 145:
                return 8216;
            case 146:
                return 8217;
            case 147:
                return 8220;
            case 148:
                return 8221;
            case 149:
                return 8226;
            case 150:
                return 8211;
            case 151:
                return 8212;
            case 152:
                return 732;
            case 153:
                return 8482;
            case 154:
                return 353;
            case 155:
                return 8250;
            case 156:
                return 339;
            case 159:
                return 376;
        }
        return origChar;
    }

    /**
     * 扫描普通文本，在遇到下一个"<"以前或者"&"符号的时候停止. 在输出过程中， 回车换行被转成空格，多个连续空格被转成单个空格.
     * 
     * @throws IOException
     */
    private void scanCharacters() throws IOException {
        char c;
        int oldOffset = offset;

        while (offset < length) {
            c = buffer[offset++];
            if (c == '<' || c == '&') {
                offset--;
                break;
            }

            if (remainWhiteSpace == false && isWhitespace(c)) {

                if (offset - 1 > oldOffset) {
                    // some non-whitespace chars in buffer
                    if (lastSpaceReserved) {
                        // output the last space reserved
                        handler.characters(SPACE, 0, 1);
                        lastSpaceReserved = false;
                    }
                    // output the non-whitespace chars
                    handler.characters(buffer, oldOffset, offset - oldOffset
                            - 1);
                    textBlockStarted = true;
                }

                if (textBlockStarted) {
                    // reserve one space char
                    lastSpaceReserved = true;
                }

                // ignore all the continued chars
                while (offset < length) {
                    c = buffer[offset];
                    if (!isWhitespace(c))
                        break;
                    offset++;
                }
                oldOffset = offset;
            }
        }

        if (offset > oldOffset) {
            if (lastSpaceReserved) {
                handler.characters(SPACE, 0, 1);
                lastSpaceReserved = false;
            }
            handler.characters(buffer, oldOffset, offset - oldOffset);
            textBlockStarted = true;
        }
    }

    /*
     * debug the specified string in html file.
     */
    @SuppressWarnings("unused")
    private void justForDebug(String debugStr) {
        CharBuffer debugbuf = new CharBuffer(buffer, offset, offset);
        debugbuf.offset = offset;
        if (offset + 50 < length) {
            debugbuf.limit = offset + 50;
        } else {
            debugbuf.limit = length;
        }
        String bufStr = debugbuf.toString();
        if (bufStr.startsWith(debugStr)) {
            /* here debug */
            bufStr.length();
        }
    }

    private void scan() throws IOException {
        char c;

        do {
            // justForDebug("<tr><td>a</td><td>");
            switch (state) {
                case STATE_CONTENT: {
                    if (offset >= length)
                        return;

                    c = buffer[offset];
                    if (c == '<') {
                        ++offset;
                        state = STATE_MARKUP_BRACKET;
                    } else if (c == '&') {
                        ++offset;
                        int refStart = refBuffer.limit;
                        while (true) {
                            int ref = scanEntityRef(false);
                            if (ref < 0) {
                                if (lastSpaceReserved) {
                                    handler.characters(SPACE, 0, 1);
                                    lastSpaceReserved = false;
                                }
                                if (refBuffer.limit - refStart > 0) {
                                    handler.characters(refBuffer.data,
                                            refStart, refBuffer.limit
                                                    - refStart);
                                    // refBuffer.limit = 0;
                                }
                                handler.characters(buffer, offset - 1, 1);
                                textBlockStarted = true;
                                break;
                            } else {
                                refBuffer.append((char) ref);
                            }
                            if (offset < length && buffer[offset] == '&') {
                                offset++;
                            } else {
                                break;
                            }
                        }
                        if (refBuffer.limit - refStart > 0) {
                            if (lastSpaceReserved) {
                                handler.characters(SPACE, 0, 1);
                                lastSpaceReserved = false;
                            }
                            handler.characters(refBuffer.data, refStart,
                                    refBuffer.limit - refStart);
                            textBlockStarted = true;
                        }
                    } else {
                        scanCharacters();
                    }
                }
                    break;

                case STATE_MARKUP_BRACKET: {
                    if (offset >= length) {
                        throw new EOFException();
                    }

                    c = buffer[offset++];
                    if (c == '!') {
                        if (skip("--", false)) {
                            scanComment();
                        } else if (skip("[CDATA[", false)) {
                            scanCDATA();
                        } else if (skip("DOCTYPE", false)) {
                            scanDoctype();
                        } else {
                            skipMarkup();
                        }
                    } else if (c == '?') {
                        scanPI();
                    } else if (c == '/') {
                        scanEndElement();
                    } else if (c == '%') {
                        skipClosePercent();
                    } else {
                        offset--;
                        scanStartElement();
                    }
                    state = STATE_CONTENT;
                }
                    break;

                case STATE_START_DOCUMENT: {

                }
                    break;

                case STATE_END_DOCUMENT: {

                }
                    break;

            }
        } while (true);
    }

    public String dump() {
        StringBuilder tmp = new StringBuilder();
        tmp.append(" defaultBuffer:" + this.defaultBuffer.length);
        tmp.append(" buffer:" + this.buffer.length);
        tmp.append(" nameBuffer:" + nameBuffer.data.length);
        tmp.append(" attributeBuffer:" + attributeBuffer.data.length);
        tmp.append(" valueBuffer:" + valueBuffer.length());
        tmp.append(" markupBuffer:" + markupContentBuffer.data.length);
        tmp.append(" refBuffer:" + refBuffer.data.length);
        tmp.append(" attributes:" + attributes.size());
        return tmp.toString();
    }

    private int scanEntityRef(boolean inAttribute) {
        
        return -1;/*

        int oldOffset = offset;
        int entitySize = 0;
        
        while (true) {

            if (offset == length) {
                offset = oldOffset;
                return -1;
            }

            char c = buffer[offset++];

            if (c == ';') {
                if (offset - oldOffset < 2) {
                    offset = oldOffset;
                    return -1;
                }
                entitySize = offset - oldOffset - 1;
                break;
            }

            if (!isLetterOrDigit((char) c) && c != '#') {
                entitySize = offset - oldOffset - 1;
                offset--;
                break;
            }
        }

        if (buffer[oldOffset] == '#') {
            int value = -1;
            try {
                if (buffer[oldOffset + 1] == 'x') {
                    entitySize = 0;
                    for (int i = oldOffset + 2; i < length
                            && ((buffer[i] >= '0' && buffer[i] <= '9')
                                    || (buffer[i] >= 'A' && buffer[i] <= 'F') || (buffer[i] >= 'a' && buffer[i] <= 'f')); i++) {
                        entitySize++;
                    }
                    offset = oldOffset + entitySize + 2;
                    if (buffer[offset] == ';') {
                        offset++;
                    }
                    value = IntTool.parseHexInt(buffer, oldOffset + 2,
                            entitySize);
                } else {
                    entitySize = 0;
                    for (int i = oldOffset + 1; i < length && buffer[i] >= '0'
                            && buffer[i] <= '9'; i++) {
                        entitySize++;
                    }
                    offset = oldOffset + entitySize + 1;
                    if (buffer[offset] == ';') {
                        offset++;
                    }
                    value = IntTool.parseInt(buffer, oldOffset + 1, entitySize);
                }
                value = fixWindowsCharacter(value);
            } catch (Exception e) {
                offset = oldOffset;
                return -1;
            }
            return value;
        }

        int c = HTMLEntities.get(new String(buffer, oldOffset, entitySize));

        if (c == -1) {
            if (inAttribute == false) {
                int matchLen = (entitySize < 8) ? entitySize : 8;
                for (; matchLen > 0; matchLen--) {
                    int ctmp = HTMLEntities
                            .getNoRelySemicolonEntity(new String(buffer,
                                    oldOffset, matchLen));
                    if (ctmp != -1) {
                        offset = oldOffset + matchLen;
                        return ctmp;
                    }
                }
            }

            offset = oldOffset;
            return -1;
        }
        // the entity who does not contain ';', if it is in
        // norelySemicolonEntity,it is valid;or else invalid
        if (offset >= 1 && buffer[offset - 1] != ';') {
            int ctmp = HTMLEntities.getNoRelySemicolonEntity(new String(buffer,
                    oldOffset, entitySize));
            if (ctmp == -1) {
                offset = oldOffset;
                return -1;
            }
        }

        System.out.println("in scanEntityRef, result is : "+(char)c);
        
        return c;*/
    }

    public static void main(String args[]) {
//        String content = "<div>test</DIV>  &lt; &#160; ";
//        RawHTMLScanner scanner = new RawHTMLScanner();
//        RebuildHtmlHandler handler = new RebuildHtmlHandler(0);
//        scanner.registerHtmlHandler(handler);
//        try {
//            scanner.scan(new StringReader(content));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        System.out.println(handler.toHtmlString());
    }
}
