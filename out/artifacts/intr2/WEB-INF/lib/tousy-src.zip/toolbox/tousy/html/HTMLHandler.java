package toolbox.tousy.html;

import java.util.Properties;

/**
 * html扫描的回调接口. 根据对应的HtmlScanner的不同，在解析的时候可能回调 不同的接口.
 * 
 * @author river
 */
public interface HTMLHandler {

    /**
     * 开始一个html对象.
     * 
     * @throws ParseException
     */
    public void startDocument();

    /**
     * 结束一个html对象.
     * 
     * @throws ParseException
     */
    public void endDocument();

    /**
     * 开始一个html 的tag. 每个startElement()都会有一个对应的endElement()操作.
     * 
     * @see #endElement(String, int)
     * @see #emptyElement(String, int, Properties, char[], int, int)
     * @param name
     * @param code
     *            tag element 的数字标识，例如HTMLElements.UNKOWN
     * @param attributes
     *            如果没有处理，这个是null
     * @param attrBuffer
     *            attribute 字符串对应的buffer，对应值可能是null，在处理过程中需要进行检查
     * @param offset
     *            attrBuffer的偏移
     * @param count
     *            attribute字符串的长度ַ�ĳ���
     */
    public void startElement(String name, int code, Properties attributes,
            char[] attrBuffer, int offset, int count);

    /**
     * 结束一个html的tag.
     * 
     * @param name
     * @param code
     */
    public void endElement(String name, int code);

    /**
     * 处理一个不包含子节点的element. 这个接口相当于顺序调用了一次startElement()和endElement().
     * 
     * @see #startElement(String, int, Properties, char[], int, int)
     * @see #endElement(String, int)
     * @param name
     * @param code
     * @param attributes
     * @param attrBuffer
     * @param offset
     * @param count
     */
    public void emptyElement(String name, int code, Properties attributes,
            char[] attrBuffer, int offset, int count);

    /**
     * 处理html的文本.对应的文本已经将"&amp;..."这样字符解析出来了.
     * 
     * @param buf
     */
    public void characters(char[] buf, int offset, int count);

    /**
     * 处理注释，对应的文本没有经过任何处理.
     * 
     * @param buf
     */
    public void comment(char[] buf, int offset, int count);

    /**
     * 处理DOCTYPE的声明.
     * 
     * @param root
     * @param pubid
     * @param sysid
     * @throws ParseException
     */
    public void declDoctype(String root, String pubid, String sysid);

}
