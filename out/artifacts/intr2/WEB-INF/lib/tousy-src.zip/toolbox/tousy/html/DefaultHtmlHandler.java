package toolbox.tousy.html;

import java.util.Properties;

public class DefaultHtmlHandler implements HTMLHandler {
	private static final boolean DEBUG = false;

	/**
	 * 开始一个html对象.
	 * @throws ParseException
	 */
	public void startDocument() {
		
	}
	
	/**
	 * 结束一个html对象.
	 * @throws ParseException
	 */
	public void endDocument() {
		
	}
	
	/**
	 * 开始一个html 的tag.
	 * @param name
	 * @param code
	 * @param attributes
	 * @param attrValue
	 */
	public void startElement(String name, int code, Properties attributes, char [] attrValue, int offset, int count) {
		if (DEBUG) {
//			System.out.println("<" + name + ">");
//			if (attributes != null) {
//				attributes.list(System.out);
//			}
		}
	}
	
	public void emptyElement(String name, int code, Properties attributes, char [] attrValue, int offset, int count) {
		if (DEBUG) {
			System.out.println("<" + name + "/>");
		}
	}
	
	/**
	 * 结束一个html的tag.
	 * @param name
	 */
	public void endElement(String name, int code) {
		if (DEBUG) {
			System.out.println("</" + name + ">");
		}
	}
	
	/**
	 * 处理html的文本.对应的文本已经将"&amp;..."这样字符解析出来了.
	 * @see #charactersRaw(CharBuffer)
	 * @param buf
	 */
	public void characters(char [] buf, int offset, int count) {
		if (DEBUG) {
			String str = new String(buf, offset, count);
			System.out.println(": " + str);
		}
	}
	
	/**
	 * 处理注释，对应的文本没有经过任何处理.
	 * @param buf
	 */
	public void comment(char [] buf, int offset, int count) {
		
	}

	public void declDoctype(String root, String pubid, String sysid) {
		if (DEBUG){
			System.out.println("DOCTYPE : root = " + root + ", pubid = " + pubid + ", sysid = " + sysid);
		}
	}
}
