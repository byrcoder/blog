package toolbox.tousy.html;

import java.util.Properties;

/**
 * Balance the tags.
 * @author river
 *
 */
public class HTMLTagBalancer {
    private static final Properties EMPTY_PROPERTIES = new Properties();
    
    private static final HTMLHandler DUMMY_HANDLER = new DefaultHtmlHandler();

    private HTMLHandler handler = DUMMY_HANDLER;

    private boolean seenRootElement;
    private boolean seenHeadElement;
    private boolean seenBodyElement;
    private boolean seenRootElementEnd;

    private boolean ignoreOutsideContent;

    private HTMLTagStack elementStack = new HTMLTagStack();

    public HTMLTagBalancer() {
    }
	
    public void registerHTMLHandler(HTMLHandler handler) {
        if (handler == null) return;

        if (this.handler == DUMMY_HANDLER) {
            this.handler = handler;
        } else {
            if (this.handler instanceof CompositeHTMLHandler) {
                ((CompositeHTMLHandler)this.handler).registerHandler(handler);
            } else {
                CompositeHTMLHandler composite = new CompositeHTMLHandler();
                composite.registerHandler(this.handler);
                composite.registerHandler(handler);
                this.handler = composite;
            }
        }
    }

    public void startDocument() {
        seenRootElement = false;
        seenHeadElement = false;
        seenBodyElement = false;
        seenRootElementEnd = false;
        elementStack.top = 0;

        handler.startDocument();
    }
	
    public void endDocument() {
        if (!seenRootElement) {
            HTMLElements.ElementEntry entry = HTMLElements.findElement(HTMLElements.HTML);
            handler.startElement(entry.name, entry.code, EMPTY_PROPERTIES, null, 0, 0);
            handler.endElement(entry.name, entry.code);
        } else {
            int length = elementStack.top;
            for (int i=0; i<length; i++) {
                HTMLTagStackEntry entry = elementStack.pop();
                handler.endElement(entry.name, entry.element.code);
            }
        }

        handler.endDocument();
    }

    public int getParentDepth(short [] parentCodes, short bounds) {
        if (parentCodes != null) {
            for (int i=elementStack.top-1; i>=0; i--) {
                HTMLTagStackEntry tag = elementStack.entries[i];
                if (tag.element.code == bounds)
                    break;
                for (int j=0; j<parentCodes.length; j++) {
                    if (tag.element.code == parentCodes[j]) 
                        return elementStack.top - i;
                }
            }
        }
        return -1;
    }

    public void startElement(String name, int code, Properties attributes, char [] attrBuffer, int offset, int count) {
        HTMLElements.ElementEntry element = HTMLElements.findElement(code);

        //ignore multiple html, head, body elements
        if (element.code == HTMLElements.HTML) {
            if (seenRootElement)
                return;
        } else if (element.code == HTMLElements.HEAD) {
            if (seenHeadElement) 
                return;
            seenHeadElement = true;
        } else if (element.code == HTMLElements.BODY) {
            if (seenBodyElement) {
                return;
            }
            seenBodyElement = true;
        }

        if (element.parentCodes != null) {
            if (!seenRootElement) {
                HTMLElements.ElementEntry parent = HTMLElements.findElement(element.parentCodes[0]);
                startElement(parent.name, parent.code, EMPTY_PROPERTIES, null, 0, 0);
            } else {
                HTMLElements.ElementEntry parent = HTMLElements.findElement(element.parentCodes[0]);
                if (!seenBodyElement || (parent.code != HTMLElements.HEAD && parent.code != HTMLElements.BODY)) {
                    if (getParentDepth(element.parentCodes, element.bounds) == -1) {
                        startElement(parent.name, parent.code, EMPTY_PROPERTIES, null, 0, 0);
                    }
                }
            }
        }

        int depth = 0;
        HTMLTagStack inlineElementStack = null;
        if (element.flags == 0) {
            inlineElementStack = new HTMLTagStack();
            inlineElementStack.top = 0;
            for (int i=elementStack.top-1; i>=0; i--) {
                HTMLTagStackEntry entry = elementStack.entries[i];
                if (!entry.element.isInline()) {
                    break;
                }
                inlineElementStack.push(entry);
                endElement(entry.name, entry.element.code);
            }
            depth = inlineElementStack.top;
        }

        if (element.closes != null) {
            int length = elementStack.top;
            for (int i=length-1; i>=0; i--) {
                HTMLTagStackEntry entry = elementStack.entries[i];
                if (element.closes(entry.element.code)) {
                    for (int j=length-1; j>=i; j--) {
                        HTMLTagStackEntry tmp = elementStack.pop();
                        handler.endElement(tmp.name, tmp.element.code);
                    }
                    length = i;
                    continue;
                }

                boolean container = entry.element.isContainer();
                boolean parent = false;
                if (!container) {
                    for (int j=0; !parent && j<element.parentCodes.length; j++) {
                        parent = parent || entry.element.code == element.parentCodes[j];
                    }
                }
                if (container || parent) break;
            }
        }

        seenRootElement = true;
        if (element.isEmpty()) {
            handler.emptyElement(name, code, attributes, attrBuffer, offset, count);
        } else {
            elementStack.push(new HTMLTagStackEntry(name, element));
            handler.startElement(name, code, attributes, attrBuffer, offset, count);
        }

        //reopen inline elements
        for (int i=0; i<depth; i++) {
            HTMLTagStackEntry entry = inlineElementStack.pop();
            startElement(entry.name, entry.element.code, EMPTY_PROPERTIES, null, 0, 0);
        }
    }

    public int getElementDepth(String name, HTMLElements.ElementEntry element) {
        boolean container = element.isContainer();
        int code = element.code;

        int depth = -1;
        if (code != HTMLElements.UNKNOWN) {
            for (int i=elementStack.top-1; i>=0; i--) {
                HTMLTagStackEntry entry = elementStack.entries[i]; 
                if (entry.element.code == code) {
                    depth = elementStack.top-i;
                    break;
                }
                if (!container && entry.element.isBlock()) 
                    break;
            }
        } else {
            for (int i=elementStack.top-1; i>=0; i--) {
                HTMLTagStackEntry entry = elementStack.entries[i]; 
                if (entry.name.equals(name)) {
                    depth = elementStack.top-i;
                    break;
                }
                if (!container && entry.element.isBlock())
                    break;
            }
        }
        return depth;
    }

    public void endElement(String name, int code) {
        if (seenRootElementEnd) {
            return;
        }

        HTMLElements.ElementEntry element = HTMLElements.findElement(code);
        if (!ignoreOutsideContent && (element.code == HTMLElements.BODY || 
                element.code == HTMLElements.HTML)) {
            return;
        }

        if (element.code == HTMLElements.HTML) {
            seenRootElementEnd = true;
        }

        int depth = getElementDepth(name, element);

        if (depth == -1 && element.code == HTMLElements.P) {
            startElement(element.name, element.code, EMPTY_PROPERTIES, null, 0, 0);
            endElement(element.name, element.code);
        }

        HTMLTagStack inlineElementStack = null;
        if (depth > 1 && element.isInline()) {
            inlineElementStack = new HTMLTagStack();
            int size = elementStack.top;
            inlineElementStack.top = 0;
            for (int i=0; i<depth-1; i++) {
                HTMLTagStackEntry entry = elementStack.entries[size-i-1];
                if (entry.element.isInline()) {
                    inlineElementStack.push(entry);
                }
            }
        }

        for (int i=0; i<depth; i++) {
            HTMLTagStackEntry entry = elementStack.pop();
            handler.endElement(entry.name, entry.element.code);
        }

        if (depth > 1) {
            if(inlineElementStack == null){
                inlineElementStack = new HTMLTagStack();
            }
            int size = inlineElementStack.top;
            for (int i=0; i<size; i++) {
                HTMLTagStackEntry entry = inlineElementStack.pop();
                startElement(entry.name, entry.element.code, EMPTY_PROPERTIES, null, 0, 0);
            }
        }

    }

    public void characters(char []  buf, int offset, int count) {
        handler.characters(buf, offset, count);
    }

    public void comment(char [] buf, int offset, int count) {
        handler.comment(buf, offset, count);
    }

    public void declDoctype(String root, String pubid, String sysid) {
        handler.declDoctype(root, pubid, sysid);
    }


    public static class HTMLTagStackEntry {
        private String name;

        private HTMLElements.ElementEntry element;

        public HTMLTagStackEntry(String name, HTMLElements.ElementEntry element) {
            this.name = name;
            this.element = element;
        }
    }

    public static class HTMLTagStack {
        public int top = 0;
        public HTMLTagStackEntry [] entries = new HTMLTagStackEntry[20];

        public void push(HTMLTagStackEntry entry) {
            if (top == entries.length) {
                HTMLTagStackEntry [] newBuffer = new HTMLTagStackEntry[entries.length + 20];
                System.arraycopy(entries, 0, newBuffer, 0, entries.length);
                entries = newBuffer;
            }
            entries[top++] = entry;
        }

        public HTMLTagStackEntry peek() {
            return entries[top-1];
        }

        public HTMLTagStackEntry pop() {
            return entries[--top];
        }

        public void clear() {
            top = 0;
        }
    }
}
