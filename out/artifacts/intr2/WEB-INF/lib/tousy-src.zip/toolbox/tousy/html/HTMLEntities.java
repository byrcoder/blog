package toolbox.tousy.html;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

public class HTMLEntities {
	private static HashMap<String, Character> ENTITIES = new HashMap<String, Character>();
	private static HashMap<Character, String> NAMES = new HashMap<Character, String>();
	private static HashMap<String, Character> NO_RELY_SEMICOLON_ENTITIES = new HashMap<String, Character>();
    
	static {
		load("HTMLlat1.properties");
		load("HTMLspecial.properties");
		load("HTMLsymbol.properties");
		load("XMLbuiltin.properties");
        loadNoRelySemicolon("NoRelySemicolon.properties");
	}
	
	public static int get(String name) {
		Character character = ENTITIES.get(name.toLowerCase());
		return character == null ? -1 : character.charValue();
	}
    
	public static int getNoRelySemicolonEntity(String name) {
        Character character = NO_RELY_SEMICOLON_ENTITIES.get(name.toLowerCase());
        return character == null ? -1 : character.charValue();
    }
    
	public static String getName(char c) {
		return NAMES.get(c);
	}
	
	private static void load(String filename) {
		try {
			Properties prop = new Properties();
			InputStream is = HTMLEntities.class.getResourceAsStream(filename);
			try {
				prop.load(is);
			} finally {
				is.close();
			}
			
			for (Object o : prop.keySet()) {
				String value = prop.getProperty((String)o);
				ENTITIES.put((String)o, value.charAt(0));
				NAMES.put(value.charAt(0), (String)o);
			}
			
		} catch(Exception e) {
			System.err.println("load resource error : " + filename);
			e.printStackTrace(System.err);
		}
	}
    private static void loadNoRelySemicolon(String filename){
        try {
            Properties prop = new Properties();
            InputStream is = HTMLEntities.class.getResourceAsStream(filename);
            try {
                prop.load(is);
            } finally {
                is.close();
            }
            NO_RELY_SEMICOLON_ENTITIES.clear();
            for (Object o : prop.keySet()) {
                String value = prop.getProperty((String)o);
                NO_RELY_SEMICOLON_ENTITIES.put((String)o, value.charAt(0));
            }
            
        } catch(Exception e) {
            System.err.println("load resource error : " + filename);
            e.printStackTrace(System.err);
        }
    }
	
}
