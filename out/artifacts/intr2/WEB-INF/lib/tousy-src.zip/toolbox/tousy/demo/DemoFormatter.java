package toolbox.tousy.demo;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.text.ParseException;
import java.util.Properties;

import toolbox.tousy.html.HTMLElements;
import toolbox.tousy.html.HTMLHandler;
import toolbox.tousy.html.HTMLScanner;

public class DemoFormatter implements HTMLHandler {
    private PrintWriter writer;

    private int indent = 0;

    public DemoFormatter(PrintWriter writer) {
        this.writer = writer;
    }

    /**
     * 开始一个html对象.
     * 
     * @throws ParseException
     */
    public void startDocument() {
        indent = 0;
    }

    /**
     * 结束一个html对象.
     * 
     * @throws ParseException
     */
    public void endDocument() {}

    private void indent() {
        for (int i = 0; i < indent; i++)
            writer.print("  ");
    }

    private void printElement(String name, int code, char[] attrBuffer,
            int offset, int count, boolean closed) {
        writer.println();
        indent();
        writer.print("<" + name);
        if (attrBuffer != null && count > 0) {
            writer.write(' ');
            writer.write(attrBuffer, offset, count);
        }
        if (closed) {
            HTMLElements.ElementEntry element = HTMLElements.findElement(code);
            if (element.isInline()) {
                writer.write('>');
            } else {
                writer.print("/>");
            }
        } else {
            writer.write('>');
        }
        writer.flush();
    }

    /**
     * 开始一个html 的tag.
     * 
     * @param name
     * @param code
     *            tag element 的数字标识，例如HTMLElements.UNKOWN
     * @param attributes
     *            如果没有处理，这个可以是null
     * @param attrValue
     */
    public void startElement(String name, int code, Properties attributes,
            char[] attrBuffer, int offset, int count) {
        printElement(name, code, attrBuffer, offset, count, false);
        indent++;
    }

    public void emptyElement(String name, int code, Properties attributes,
            char[] attrBuffer, int offset, int count) {
        printElement(name, code, attrBuffer, offset, count, true);
    }

    /**
     * 结束一个html的tag.
     * 
     * @param name
     * @param code
     */
    public void endElement(String name, int code) {
        writer.println();
        indent--;
        indent();
        writer.print("</" + name + ">");
    }

    /**
     * 处理html的文本.对应的文本已经将"&amp;..."这样字符解析出来了.
     * 
     * @param buf
     */
    public void characters(char[] buf, int offset, int count) {
        writer.write(buf, offset, count);
        writer.flush();
    }

    /**
     * 处理注释，对应的文本没有经过任何处理.
     * 
     * @param buf
     */
    public void comment(char[] buf, int offset, int count) {

    }

    /**
     * 处理DOCTYPE的声明.
     * 
     * @param root
     * @param pubid
     * @param sysid
     * @throws ParseException
     */
    public void declDoctype(String root, String pubid, String sysid) {

    }

    public static void main(String[] args) throws Exception {
        Reader input;
        PrintWriter output;

        if (args.length > 0) {
            input = new InputStreamReader(new FileInputStream(args[0]));
        } else {
            input = new InputStreamReader(System.in);
        }

        if (args.length > 1) {
            output = new PrintWriter(new FileWriter(args[1]), true);
        } else {
            output = new PrintWriter(System.out);
        }

        HTMLScanner scanner = new HTMLScanner();
        DemoFormatter formatter = new DemoFormatter(output);
        scanner.registerHtmlHandler(formatter);
        scanner.scan(input);
        output.flush();
    }

}
