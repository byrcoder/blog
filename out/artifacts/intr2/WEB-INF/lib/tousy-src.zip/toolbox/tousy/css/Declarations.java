package toolbox.tousy.css;

import java.util.HashMap;
import java.util.Map;

import org.apache.batik.css.parser.DefaultDocumentHandler;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.LexicalUnit;

import toolbox.tousy.html.HTMLColor;
import toolbox.tousy.html.HTMLFont;

/**
 * 包含了css文档中某个selector规定的property/value对儿
 *
 * @author river
 * @author liruohao
 */
public class Declarations extends DefaultDocumentHandler {
    /**
     * 代表颜色值没有被缓存
     */
    public static final int NO_CACHED_COLOR = -2;
    
    /**
     * 代表properties中没有指定相应的属性值
     */
    public static final int NOT_SPECIFIED = -1;
    
    /**
     * property/value对儿
     */
    private Map<Short, LexicalUnit> properties = new HashMap<Short, LexicalUnit>();

    /**
     * 缓存的背景颜色
     */
    private int cachedBackgroundColor = NO_CACHED_COLOR;
    
    /**
     * 缓存的文本颜色
     */
    private int cachedColor = NO_CACHED_COLOR;
    
    public void property(String name, LexicalUnit value, boolean important) throws CSSException {
        put(name, value);
    }
    
    /**
     * 返回css property对应的语法单元
     * @param propertyCode css property
     * @return 语法单元
     */
    public LexicalUnit get(short propertyCode) {
        return propertyCode == CssProperties.UNKNOWN_PROPERTY ? null : properties.get(propertyCode);
    }
    
    /**
     * 加入一个property/value对儿
     * @param name 属性名
     * @param unit 属性值
     */
    public void put(String name, LexicalUnit unit) {
        short s = CssProperties.getPropertyCode(name);
        if (s != CssProperties.UNKNOWN_PROPERTY) {
            properties.put(s, unit);
        }
    }
    
    /**
     * 返回是否含有给定名称的属性
     * @param propertyCode 属性名
     * @return 是否含有给定名称的属性
     */
    public boolean has(short propertyCode) {
        return properties.containsKey(propertyCode);
    }
    
    /**
     * 返回<code>BACKGROUND-COLOR</code>或<code>BACKGROUND</code>指定的颜色值
     * @return <code>BACKGROUND-COLOR</code>或<code>BACKGROUND</code>指定的颜色值
     */
    public int getBackgroundColor() {
        if (cachedBackgroundColor == NO_CACHED_COLOR) {
            LexicalUnit unit = properties.get(CssProperties.BACKGROUND_COLOR);
            if (unit == null) {
                unit = properties.get(CssProperties.BACKGROUND);
            }
            
            cachedBackgroundColor = (unit == null ? NOT_SPECIFIED : getColor(unit));
        }
        
        return cachedBackgroundColor;
    }
    
    /**
     * 返回<code>BACKGROUND-IMAGE</code>或<code>BACKGROUND</code>指定的背景图片路径
     * @return <code>BACKGROUND-IMAGE</code>或<code>BACKGROUND</code>指定的背景图片路径
     */
    public String getBackgroundImage() {
        LexicalUnit unit = properties.get(CssProperties.BACKGROUND_IMAGE);
        if (unit == null) {
            unit = properties.get(CssProperties.BACKGROUND);
        }
        
        return unit == null ? null: getBackgroundImage(unit);
    }
    
    /**
     * 返回<code>COLOR<code>指定的颜色值
     * @return <code>COLOR<code>指定的颜色值
     */
    public int getColor() {
        if (cachedColor == NO_CACHED_COLOR) {
            LexicalUnit unit = properties.get(CssProperties.COLOR);
            cachedColor = (unit == null ? NOT_SPECIFIED : getColor(unit));
        }
        
        return cachedColor;
    }
    
    /**
     * 返回字号
     * @param parentFontSize 父元素的字号（<code>FONT-SIZE</code>属性为一百分数时需要使用）
     * @return 字号
     */
    public int getFontSize(int parentFontSize) {
        LexicalUnit unit = properties.get(CssProperties.FONT_SIZE);
        if (unit == null) {
            unit = properties.get(CssProperties.FONT);
        }
        
        return unit == null ? NOT_SPECIFIED : getFontSize(unit, parentFontSize);
    }
    
    /**
     * 返回字体粗细信息
     * @return 字体粗细信息
     */
    public int getFontWeight() {
        LexicalUnit unit = properties.get(CssProperties.FONT_WEIGHT);
        if (unit == null) {
            unit = properties.get(CssProperties.FONT);
        }
        
        return unit == null ? NOT_SPECIFIED : getFontWeight(unit);
    }
    
    /**
     * 返回css property对应的属性值的字符串表示
     * @param propertyCode css property
     * @return css property对应的属性值的字符串表示
     */
    public String getStringValue(short propertyCode) {
        LexicalUnit unit = properties.get(propertyCode);
        return unit == null ? null : LexicalUnitUtils.toString(unit);
    }
    
    /**
     * 返回背景图片信息
     * @param unit 语法单元
     * @return 背景图片信息
     */
    public static String getBackgroundImage(LexicalUnit unit) {
        while (unit != null) {
            switch(unit.getLexicalUnitType()) {
                case LexicalUnit.SAC_URI:
                    return unit.getStringValue();
            }
            
            unit = unit.getNextLexicalUnit();
        }
        
        return null;
    }
    
    /**
     * 返回颜色值
     * @param unit 颜色属性值
     * @return 颜色值
     */
    public static int getColor(LexicalUnit unit) {
        while (unit != null) {
            switch (unit.getLexicalUnitType()) {
                // color name or transparent
                case LexicalUnit.SAC_IDENT:
                    String s = unit.getStringValue().toLowerCase();
                    // 注意这里TRANSPARENT关键字会返回NOT_SPECIFIED
                    Integer i = HTMLColor.COLOR_MAP.get(s);
                    if (i != null) {
                        return i;
                    }
                    break;
                    
                // the hex number has been converted into rgb color by batik
                    
                // a rgb value, e.g. rgb(0,255,255)
                case LexicalUnit.SAC_RGBCOLOR:
                    LexicalUnit param = unit.getParameters();
                    int color = 0;
                    int count = 0;
                    Outer:
                    while (param != null && count < 3) {
                        switch (param.getLexicalUnitType()) {
                            case LexicalUnit.SAC_INTEGER:
                                color = (color << 8) | param.getIntegerValue();
                                break;
                                
                            case LexicalUnit.SAC_PERCENTAGE:
                                color = (color << 8) | (param.getIntegerValue() * 255 / 100);
                                break;
                                
                            default:
                                break Outer;
                        }
                        
                        ++count;
                        
                        param = param.getNextLexicalUnit();
                        if (param != null) {
                            // 跳过逗号
                            param = param.getNextLexicalUnit();
                        }
                    }
                    
                    if (count >= 3) {
                        return color;
                    }
                    
                    break;
            }
            
            unit = unit.getNextLexicalUnit();
        }
        
        return NOT_SPECIFIED;
    }
    
    public static int getFontSize(LexicalUnit unit, int parentFontSize) {
        while (unit != null) {
            switch (unit.getLexicalUnitType()) {
                case LexicalUnit.SAC_CENTIMETER:
                    return (int) (unit.getFloatValue() * HTMLFont.CM);
                
                case LexicalUnit.SAC_EM:
                    return (int) (unit.getFloatValue() * HTMLFont.EM);
                
                case LexicalUnit.SAC_EX:
                    return (int) (unit.getFloatValue() * HTMLFont.EX);
                
                case LexicalUnit.SAC_IDENT:
                    String s = unit.getStringValue().toLowerCase();
                    Integer i = HTMLFont.NAMED_CSS_FONT_SIZE.get(s);
                    if (i != null) {
                        return i;
                    }
                    break;
                    
                case LexicalUnit.SAC_INCH:
                    return (int) (unit.getFloatValue() * HTMLFont.IN);
                
                case LexicalUnit.SAC_INTEGER:
                    // 因为font-weight也会指定一个整数值
                    if (unit.getIntegerValue() < 100) {
                        return unit.getIntegerValue();
                    }
                    break;
                    
                case LexicalUnit.SAC_MILLIMETER:
                    return (int) (unit.getFloatValue() * HTMLFont.MM);
                    
                case LexicalUnit.SAC_OPERATOR_SLASH:
                    // 如果遇到'/'，就说明font-size已经出现过了，那么以后也不会再出现了
                    return NOT_SPECIFIED;
                    
                case LexicalUnit.SAC_PERCENTAGE:
                    return (int) (unit.getFloatValue() * parentFontSize / 100);
                
                case LexicalUnit.SAC_PICA:
                    return (int) (unit.getFloatValue() * HTMLFont.PC);
                    
                case LexicalUnit.SAC_PIXEL:
                    return (int) unit.getFloatValue();
                    
                case LexicalUnit.SAC_POINT:
                    return (int) (unit.getFloatValue() * HTMLFont.PT);
            }
            
            unit = unit.getNextLexicalUnit();
        }
        
        return NOT_SPECIFIED;
    }
    
    public static int getFontWeight(LexicalUnit unit) {
        while (unit != null) {
            switch (unit.getLexicalUnitType()) {
                case LexicalUnit.SAC_IDENT:
                    String s = unit.getStringValue().toLowerCase();
                    if (s.equals("BOLD") || s.equals("BOLDER")) {
                        return HTMLFont.BOLD;
                    }
                    break;
                    
                case LexicalUnit.SAC_INTEGER:
                    int i = unit.getIntegerValue();
                    if (i == 600 || i == 700 || i == 800 || i == 900) {
                        return HTMLFont.BOLD;
                    }
                    break;
            }
            
            unit = unit.getNextLexicalUnit();
        }
        
        return NOT_SPECIFIED;
    }
    
    /**
     * 返回对象的字符串表示
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        for (Map.Entry<Short, LexicalUnit> entry : properties.entrySet()) {
            sb.append(CssProperties.getPropertyName(entry.getKey()) + ": " + LexicalUnitUtils.toString(entry.getValue()) + "\n");
        }
        
        return sb.toString();
    }
}
