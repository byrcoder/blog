package toolbox.tousy.html;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class HTMLElements {

    public static final short A = 0;

    public static final short ABBR = A + 1;

    public static final short ACRONYM = ABBR + 1;

    public static final short ADDRESS = ACRONYM + 1;

    public static final short APPLET = ADDRESS + 1;

    public static final short AREA = APPLET + 1;

    public static final short B = AREA + 1;

    public static final short BASE = B + 1;

    public static final short BASEFONT = BASE + 1;

    public static final short BDO = BASEFONT + 1;

    public static final short BGSOUND = BDO + 1;

    public static final short BIG = BGSOUND + 1;

    public static final short BLINK = BIG + 1;

    public static final short BLOCKQUOTE = BLINK + 1;

    public static final short BODY = BLOCKQUOTE + 1;

    public static final short BR = BODY + 1;

    public static final short BUTTON = BR + 1;

    public static final short CAPTION = BUTTON + 1;

    public static final short CENTER = CAPTION + 1;

    public static final short CITE = CENTER + 1;

    public static final short CODE = CITE + 1;

    public static final short COL = CODE + 1;

    public static final short COLGROUP = COL + 1;

    public static final short COMMENT = COLGROUP + 1;

    public static final short DEL = COMMENT + 1;

    public static final short DFN = DEL + 1;

    public static final short DIR = DFN + 1;

    public static final short DIV = DIR + 1;

    public static final short DD = DIV + 1;

    public static final short DL = DD + 1;

    public static final short DT = DL + 1;

    public static final short EM = DT + 1;

    public static final short EMBED = EM + 1;

    public static final short FIELDSET = EMBED + 1;

    public static final short FONT = FIELDSET + 1;

    public static final short FORM = FONT + 1;

    public static final short FRAME = FORM + 1;

    public static final short FRAMESET = FRAME + 1;

    public static final short H1 = FRAMESET + 1;

    public static final short H2 = H1 + 1;

    public static final short H3 = H2 + 1;

    public static final short H4 = H3 + 1;

    public static final short H5 = H4 + 1;

    public static final short H6 = H5 + 1;

    public static final short HEAD = H6 + 1;

    public static final short HR = HEAD + 1;

    public static final short HTML = HR + 1;

    public static final short I = HTML + 1;

    public static final short IFRAME = I + 1;

    public static final short ILAYER = IFRAME + 1;

    public static final short IMG = ILAYER + 1;

    public static final short INPUT = IMG + 1;

    public static final short INS = INPUT + 1;

    public static final short ISINDEX = INS + 1;

    public static final short KBD = ISINDEX + 1;

    public static final short KEYGEN = KBD + 1;

    public static final short LABEL = KEYGEN + 1;

    public static final short LAYER = LABEL + 1;

    public static final short LEGEND = LAYER + 1;

    public static final short LI = LEGEND + 1;

    public static final short LINK = LI + 1;

    public static final short LISTING = LINK + 1;

    public static final short MAP = LISTING + 1;

    public static final short MARQUEE = MAP + 1;

    public static final short MENU = MARQUEE + 1;

    public static final short META = MENU + 1;

    public static final short MULTICOL = META + 1;

    public static final short NEXTID = MULTICOL + 1;

    public static final short NOBR = NEXTID + 1;

    public static final short NOEMBED = NOBR + 1;

    public static final short NOFRAMES = NOEMBED + 1;

    public static final short NOLAYER = NOFRAMES + 1;

    public static final short NOSCRIPT = NOLAYER + 1;

    public static final short OBJECT = NOSCRIPT + 1;

    public static final short OL = OBJECT + 1;

    public static final short OPTION = OL + 1;

    public static final short OPTGROUP = OPTION + 1;

    public static final short P = OPTGROUP + 1;

    public static final short PARAM = P + 1;

    public static final short PLAINTEXT = PARAM + 1;

    public static final short PRE = PLAINTEXT + 1;

    public static final short Q = PRE + 1;

    public static final short RB = Q + 1;

    public static final short RBC = RB + 1;

    public static final short RP = RBC + 1;

    public static final short RT = RP + 1;

    public static final short RTC = RT + 1;

    public static final short RUBY = RTC + 1;

    public static final short S = RUBY + 1;

    public static final short SAMP = S + 1;

    public static final short SCRIPT = SAMP + 1;

    public static final short SELECT = SCRIPT + 1;

    public static final short SMALL = SELECT + 1;

    public static final short SOUND = SMALL + 1;

    public static final short SPACER = SOUND + 1;

    public static final short SPAN = SPACER + 1;

    public static final short STRIKE = SPAN + 1;

    public static final short STRONG = STRIKE + 1;

    public static final short STYLE = STRONG + 1;

    public static final short SUB = STYLE + 1;

    public static final short SUP = SUB + 1;

    public static final short TABLE = SUP + 1;

    public static final short TBODY = TABLE + 1;

    public static final short TD = TBODY + 1;

    public static final short TEXTAREA = TD + 1;

    public static final short TFOOT = TEXTAREA + 1;

    public static final short TH = TFOOT + 1;

    public static final short THEAD = TH + 1;

    public static final short TITLE = THEAD + 1;

    public static final short TR = TITLE + 1;

    public static final short TT = TR + 1;

    public static final short U = TT + 1;

    public static final short UL = U + 1;

    public static final short VAR = UL + 1;

    public static final short WBR = VAR + 1;

    public static final short XML = WBR + 1;

    public static final short XMP = XML + 1;

    public static final short UNKNOWN = XMP + 1;

    public static final short MAX_ELEMENTS = UNKNOWN + 1;

    /*
     * ELEMENTS_INDEX's Size should be 2^n
     */
    private static ElementEntry[][] ELEMENTS_INDEX = new ElementEntry[8192][];

    private static ElementEntry[] ELEMENTS_ARRAY = new ElementEntry[UNKNOWN + 1];

    public static Set<String> TAGSET = new HashSet<String>();

    private static ElementEntry UNKNOWN_ENTRY = new ElementEntry(UNKNOWN, "UNKNOWN", 0, new short[] {
        HEAD, BODY
    }, null);

    static {
        ELEMENTS_ARRAY[UNKNOWN] = UNKNOWN_ENTRY;

        indexElement(new ElementEntry(A, "a", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(ABBR, "abbr", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(ACRONYM, "acronym", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(ADDRESS, "address", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(APPLET, "applet", 0, BODY, null));
        indexElement(new ElementEntry(AREA, "area", ElementEntry.EMPTY, MAP, null));

        indexElement(new ElementEntry(B, "b", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(BASE, "base", ElementEntry.EMPTY, HEAD, null));
        indexElement(new ElementEntry(BASEFONT, "basefont", 0, HEAD, null));
        indexElement(new ElementEntry(BDO, "bdo", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(BGSOUND, "bgsound", ElementEntry.EMPTY, HEAD, null));
        indexElement(new ElementEntry(BIG, "big", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(BLINK, "blink", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(BLOCKQUOTE, "blockquote", ElementEntry.BLOCK, BODY, new short[] {
            P
        }));
        indexElement(new ElementEntry(BODY, "body", 0, HTML, new short[] {
            HEAD
        }));
        indexElement(new ElementEntry(BR, "br", ElementEntry.EMPTY, BODY, null));
        indexElement(new ElementEntry(BUTTON, "button", 0, BODY, null));

        indexElement(new ElementEntry(CAPTION, "caption", ElementEntry.INLINE, TABLE, null));
        indexElement(new ElementEntry(CENTER, "center", 0, BODY, null));
        indexElement(new ElementEntry(CITE, "cite", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(CODE, "code", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(COL, "col", ElementEntry.EMPTY, TABLE, null));
        indexElement(new ElementEntry(COLGROUP, "colgroup", 0, TABLE, new short[] {
            COL, COLGROUP
        }));
        indexElement(new ElementEntry(COMMENT, "comment", ElementEntry.SPECIAL, HTML, null));

        indexElement(new ElementEntry(DEL, "del", 0, BODY, null));
        indexElement(new ElementEntry(DFN, "dfn", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(DIR, "dir", 0, BODY, null));
        indexElement(new ElementEntry(DIV, "div", ElementEntry.BLOCK | ElementEntry.CONTAINER, BODY, null));
        indexElement(new ElementEntry(DD, "dd", 0, DL, new short[] {
            DT, DD
        }));
        indexElement(new ElementEntry(DL, "dl", ElementEntry.BLOCK, BODY, null));
        indexElement(new ElementEntry(DT, "dt", 0, DL, new short[] {
            DT, DD
        }));

        indexElement(new ElementEntry(EM, "em", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(EMBED, "embed", 0, BODY, null));

        indexElement(new ElementEntry(FIELDSET, "fieldset", 0, BODY, null));
        indexElement(new ElementEntry(FONT, "font", ElementEntry.CONTAINER, BODY, null));
        indexElement(new ElementEntry(FORM, "form", ElementEntry.CONTAINER, new short[] {
            BODY, TD, P, DIV
        }, new short[] {
            FORM, BUTTON
        }));
        indexElement(new ElementEntry(FRAME, "frame", ElementEntry.EMPTY, FRAMESET, null));
        indexElement(new ElementEntry(FRAMESET, "frameset", 0, HTML, null));

        indexElement(new ElementEntry(H1, "h1", ElementEntry.BLOCK, new short[] {
            BODY, A
        }, new short[] {
            H1, H2, H3, H4, H5, H6, P
        }));
        indexElement(new ElementEntry(H2, "h2", ElementEntry.BLOCK, new short[] {
            BODY, A
        }, new short[] {
            H1, H2, H3, H4, H5, H6, P
        }));
        indexElement(new ElementEntry(H3, "h3", ElementEntry.BLOCK, new short[] {
            BODY, A
        }, new short[] {
            H1, H2, H3, H4, H5, H6, P
        }));
        indexElement(new ElementEntry(H4, "h4", ElementEntry.BLOCK, new short[] {
            BODY, A
        }, new short[] {
            H1, H2, H3, H4, H5, H6, P
        }));
        indexElement(new ElementEntry(H5, "h5", ElementEntry.BLOCK, new short[] {
            BODY, A
        }, new short[] {
            H1, H2, H3, H4, H5, H6, P
        }));
        indexElement(new ElementEntry(H6, "h6", ElementEntry.BLOCK, new short[] {
            BODY, A
        }, new short[] {
            H1, H2, H3, H4, H5, H6, P
        }));
        indexElement(new ElementEntry(HEAD, "head", 0, HTML, null));
        indexElement(new ElementEntry(HR, "hr", ElementEntry.EMPTY, BODY, new short[] {
            P
        }));
        indexElement(new ElementEntry(HTML, "html", 0, null, null));

        indexElement(new ElementEntry(I, "i", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(IFRAME, "iframe", ElementEntry.BLOCK, null/* BODY */, null));
        indexElement(new ElementEntry(ILAYER, "ilayer", ElementEntry.BLOCK, BODY, null));
        indexElement(new ElementEntry(IMG, "img", ElementEntry.EMPTY, HTML, null));
        indexElement(new ElementEntry(INPUT, "input", ElementEntry.EMPTY, BODY, null));
        indexElement(new ElementEntry(INS, "ins", 0, BODY, null));
        indexElement(new ElementEntry(ISINDEX, "isindex", 0, HEAD, null));

        indexElement(new ElementEntry(KBD, "kbd", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(KEYGEN, "keygen", 0, BODY, null));

        indexElement(new ElementEntry(LABEL, "label", 0, BODY, null));
        indexElement(new ElementEntry(LAYER, "layer", ElementEntry.BLOCK, BODY, null));
        indexElement(new ElementEntry(LEGEND, "legend", ElementEntry.INLINE, FIELDSET, null));
        indexElement(new ElementEntry(LI, "li", 0, new short[] {
            BODY, UL, OL
        }, new short[] {
            LI
        }));
        indexElement(new ElementEntry(LINK, "link", ElementEntry.EMPTY, HEAD, null));
        indexElement(new ElementEntry(LISTING, "listing", 0, BODY, null));

        indexElement(new ElementEntry(MAP, "map", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(MARQUEE, "marquee", 0, BODY, null));
        indexElement(new ElementEntry(MENU, "menu", 0, BODY, null));
        indexElement(new ElementEntry(META, "meta", ElementEntry.EMPTY, HEAD, new short[] {
            STYLE, TITLE
        }));
        indexElement(new ElementEntry(MULTICOL, "multicol", 0, BODY, null));

        indexElement(new ElementEntry(NEXTID, "nextid", ElementEntry.EMPTY, BODY, null));
        indexElement(new ElementEntry(NOBR, "nobr", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(NOEMBED, "noembed", 0, BODY, null));
        indexElement(new ElementEntry(NOFRAMES, "noframes", 0, FRAMESET, null));
        indexElement(new ElementEntry(NOLAYER, "nolayer", 0, BODY, null));
        indexElement(new ElementEntry(NOSCRIPT, "noscript", 0, new short[] {
            HEAD, BODY
        }, null));

        indexElement(new ElementEntry(OBJECT, "object", 0, BODY, null));
        indexElement(new ElementEntry(OL, "ol", ElementEntry.BLOCK, BODY, null));
        indexElement(new ElementEntry(OPTION, "option", 0, SELECT, new short[] {
            OPTION
        }));
        indexElement(new ElementEntry(OPTGROUP, "optgroup", 0, SELECT, new short[] {
            OPTION
        }));

        indexElement(new ElementEntry(P, "p", 0, BODY, new short[] {
            P
        }));
        indexElement(new ElementEntry(PARAM, "param", ElementEntry.EMPTY, new short[] {
            OBJECT, APPLET
        }, null));
        indexElement(new ElementEntry(PLAINTEXT, "plaintext", ElementEntry.SPECIAL, BODY, null));
        indexElement(new ElementEntry(PRE, "pre", 0, BODY, null));

        indexElement(new ElementEntry(Q, "q", ElementEntry.INLINE, BODY, null));

        indexElement(new ElementEntry(RB, "rb", ElementEntry.INLINE, RUBY, new short[] {
            RB
        }));
        indexElement(new ElementEntry(RBC, "rbc", 0, RUBY, null));
        indexElement(new ElementEntry(RP, "rp", ElementEntry.INLINE, RUBY, new short[] {
            RB
        }));
        indexElement(new ElementEntry(RT, "rt", ElementEntry.INLINE, RUBY, new short[] {
            RB, RP
        }));
        indexElement(new ElementEntry(RTC, "rtc", 0, RUBY, new short[] {
            RBC
        }));
        indexElement(new ElementEntry(RUBY, "ruby", 0, BODY, new short[] {
            RUBY
        }));

        indexElement(new ElementEntry(S, "s", 0, BODY, null));
        indexElement(new ElementEntry(SAMP, "samp", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(SCRIPT, "script", ElementEntry.SPECIAL, new short[] {
            HEAD, BODY
        }, null));
        indexElement(new ElementEntry(SELECT, "select", 0, BODY, new short[] {
            SELECT
        }));
        indexElement(new ElementEntry(SMALL, "small", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(SOUND, "sound", ElementEntry.EMPTY, HEAD, null));
        indexElement(new ElementEntry(SPACER, "spacer", ElementEntry.EMPTY, BODY, null));
        indexElement(new ElementEntry(SPAN, "span", ElementEntry.CONTAINER, BODY, null));
        indexElement(new ElementEntry(STRIKE, "strike", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(STRONG, "strong", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(STYLE, "style", ElementEntry.SPECIAL, new short[] {
            HEAD, BODY
        }, new short[] {
            STYLE, TITLE, META
        }));
        indexElement(new ElementEntry(SUB, "sub", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(SUP, "sup", ElementEntry.INLINE, BODY, null));

        indexElement(new ElementEntry(TABLE, "table", ElementEntry.BLOCK | ElementEntry.CONTAINER, BODY, null));
        indexElement(new ElementEntry(TBODY, "tbody", 0, TABLE, new short[] {
            THEAD, TD, TH, TR, COLGROUP
        }));
        indexElement(new ElementEntry(TD, "td", 0, TR, TABLE, new short[] {
            TD, TH
        }));
        indexElement(new ElementEntry(TEXTAREA, "textarea", ElementEntry.SPECIAL, BODY, null));
        indexElement(new ElementEntry(TFOOT, "tfoot", 0, TABLE, new short[] {
            THEAD, TBODY, TD, TH, TR
        }));
        indexElement(new ElementEntry(TH, "th", 0, TR, TABLE, new short[] {
            TD, TH
        }));
        indexElement(new ElementEntry(THEAD, "thead", 0, TABLE, new short[] {
            COLGROUP
        }));
        indexElement(new ElementEntry(TITLE, "title", 0, new short[] {
            HEAD, BODY
        }, null));
        indexElement(new ElementEntry(TR, "tr", ElementEntry.BLOCK, TABLE, new short[] {
            TD, TH, TR, COLGROUP
        }));
        indexElement(new ElementEntry(TT, "tt", ElementEntry.INLINE, BODY, null));

        indexElement(new ElementEntry(U, "u", ElementEntry.INLINE, BODY, null));
        indexElement(new ElementEntry(UL, "ul", ElementEntry.BLOCK, BODY, null));

        indexElement(new ElementEntry(VAR, "var", ElementEntry.INLINE, BODY, null));

        indexElement(new ElementEntry(WBR, "wbr", ElementEntry.EMPTY, BODY, null));

        indexElement(new ElementEntry(XML, "xml", 0, BODY, null));
        indexElement(new ElementEntry(XMP, "xmp", ElementEntry.SPECIAL, BODY, null));
    }

    public static class ElementEntry {
        public static final int INLINE = 0x01;

        public static final int BLOCK = 0x02;

        public static final int EMPTY = 0x04;

        public static final int CONTAINER = 0x08;

        public static final int SPECIAL = 0x10;

        public int index;

        public short code;

        public String name;

        public int flags;

        public short[] parentCodes;

        public short bounds;

        public short[] closes;

        public ElementEntry(short code, String name, int flags, short parent, short[] closes) {
            this(code, name.toLowerCase(), flags, parent, (short) -1, closes);
        }

        public ElementEntry(short code, String name, int flags, short parent, short bounds, short[] closes) {
            this(code, name.toLowerCase(), flags, new short[] {
                parent
            }, bounds, closes);
        }

        public ElementEntry(short code, String name, int flags, short[] parents, short[] closes) {
            this(code, name.toLowerCase(), flags, parents, (short) -1, closes);
        }

        public ElementEntry(short code, String name, int flags, short[] parents, short bounds, short[] closes) {
            this.code = code;
            this.name = name.toLowerCase();
            this.flags = flags;
            this.parentCodes = parents;
            this.bounds = bounds;
            this.closes = closes;
            this.index = getNameIndex(name.toCharArray(), 0, name.length());
        }

        public static int getNameIndex(char[] buf, int offset, int length) {
            int index = 0;
            // if (length -offset > 5) length = offset +4;
            for (int i = offset; i < length; i++)
                index = index * 31 + (((int) buf[i]) | (0x01 << 5));
            return index;
        }

        public static int getNameIndex(String name) {
            int index = 0;
            int len = name.length();

            for (int i = 0; i < len; i++) {
                index = index * 31 + (((int) name.charAt(i)) | (0x01 << 5));
            }
            return index;
        }

        public int getIndex() {
            return index;
        }

        public boolean isInline() {
            return (flags & INLINE) != 0;
        }

        public boolean isContainer() {
            return (flags & CONTAINER) != 0;
        }

        public boolean isEmpty() {
            return (flags & EMPTY) != 0;
        }

        public boolean isBlock() {
            return (flags & BLOCK) != 0;
        }

        public boolean isSpecial() {
            return (flags & SPECIAL) != 0;
        }

        public boolean closes(int code) {
            if (closes != null) {
                for (int i = 0; i < closes.length; i++) {
                    if (closes[i] == code)
                        return true;
                }
            }
            return false;
        }

        public String toString() {
            return name;
        }
    }

    private static void indexElement(ElementEntry entry) {

        int index = entry.getIndex() & (ELEMENTS_INDEX.length - 1);

        if (ELEMENTS_INDEX[index] == null) {
            ELEMENTS_INDEX[index] = new ElementEntry[1];
            ELEMENTS_INDEX[index][0] = entry;
        } else {
            ElementEntry[] arr = new ElementEntry[ELEMENTS_INDEX[index].length + 1];
            System.arraycopy(ELEMENTS_INDEX[index], 0, arr, 0, ELEMENTS_INDEX[index].length);
            ELEMENTS_INDEX[index] = arr;
            ELEMENTS_INDEX[index][ELEMENTS_INDEX[index].length - 1] = entry;
        }
        TAGSET.add(entry.name);
        ELEMENTS_ARRAY[entry.code] = entry;

    }

    public static ElementEntry findElement(int code) {
        if (code < 0 || code >= ELEMENTS_ARRAY.length)
            return null;
        else
            return ELEMENTS_ARRAY[code];
    }

    public static ElementEntry findElementByName(CharBuffer buffer) {
        int entryIndex = ElementEntry.getNameIndex(buffer.data, buffer.offset, buffer.limit);
        int index = entryIndex & (ELEMENTS_INDEX.length - 1);

        ElementEntry[] arr = ELEMENTS_INDEX[index];
        if (arr != null) {
            for (int i = 0; i < arr.length; i++) {
                if (arr[i].index == entryIndex)
                    return arr[i];
                if (buffer.equalsIgnoreCase(arr[i].name)) {
                    return arr[i];
                }
            }
        }
        return UNKNOWN_ENTRY;
    }

    public static ElementEntry findElementByName(String name) {
        int entryIndex = ElementEntry.getNameIndex(name);
        int index = entryIndex & (ELEMENTS_INDEX.length - 1);

        ElementEntry[] arr = ELEMENTS_INDEX[index];
        if (arr != null) {
            for (int i = 0; i < arr.length; i++) {
                if (arr[i].index == entryIndex)
                    return arr[i];
                if (name.equalsIgnoreCase(arr[i].name)) {
                    return arr[i];
                }
            }
        }
        return UNKNOWN_ENTRY;

    }

    public static void main(String[] args) throws Exception {
        int dupCount = 0;
        for (int i = 0; i < ELEMENTS_INDEX.length; i++) {
            ElementEntry[] arr = ELEMENTS_INDEX[i];
            if (arr != null) {
                System.out.print(arr.length + " ");
                if (arr.length > 1) {
                    dupCount++;
                    System.out.println();
                    for (int j = 0; j < arr.length; j++) {
                        System.out.println(":" + arr[j].name + ":" + arr[j].index);
                    }

                }
            }
        }
        System.out.println("DUP COUNT : " + dupCount);
    }

    private static StringPool TAG_ATTRIBUTES = new StringPool(true, 8192);
    static {
        try {
            InputStream is = HTMLElements.class.getResourceAsStream("TagAttributes.properties");
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line;

                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.length() > 0) {
                        TAG_ATTRIBUTES.add(line);
                    }
                }
            } finally {
                is.close();
            }
        } catch (IOException e) {
            System.err.println("cannot load TagAttributes.properties");
            e.printStackTrace();
        }
    }

    public static String findAttributeName(CharBuffer buffer) {
        return TAG_ATTRIBUTES.findString(buffer.data, buffer.offset, buffer.limit - buffer.offset);
    }

}
