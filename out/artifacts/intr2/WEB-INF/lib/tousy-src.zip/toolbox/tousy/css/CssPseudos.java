/**
 * @(#)CssPseudos.java, 2008-3-21. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tousy.css;

import java.util.HashMap;
import java.util.Map;

/**
 * css pseudo classes and pseudo elements
 * 
 * @author liruohao
 */
public class CssPseudos {
    public static final short UNKNOWN_PSEUDO_CLASS = -1;
    
    public static final short FIRST_CHILD = UNKNOWN_PSEUDO_CLASS + 1;
    public static final short LINK = FIRST_CHILD + 1;
    public static final short VISITED = LINK + 1;
    public static final short HOVER = VISITED + 1;
    public static final short ACTIVE = HOVER + 1;
    public static final short FOCUS = ACTIVE + 1;
    public static final short LANG = FOCUS + 1;
    
    private static final Map<String, Short> CLASS_MAP = new HashMap<String, Short>(16);
    
    static {
        CLASS_MAP.put("first-child", FIRST_CHILD);
        CLASS_MAP.put("link", LINK);
        CLASS_MAP.put("visited", VISITED);
        CLASS_MAP.put("hover", HOVER);
        CLASS_MAP.put("active", ACTIVE);
        CLASS_MAP.put("focus", FOCUS);
        CLASS_MAP.put("lang", LANG);
    }
    
    private static final Map<Short, String> INVERSE_CLASS_MAP = new HashMap<Short, String>(16);
    
    static {
        INVERSE_CLASS_MAP.put(FIRST_CHILD, "first-child");
        INVERSE_CLASS_MAP.put(LINK, "link");
        INVERSE_CLASS_MAP.put(VISITED, "visited");
        INVERSE_CLASS_MAP.put(HOVER, "hover");
        INVERSE_CLASS_MAP.put(ACTIVE, "active");
        INVERSE_CLASS_MAP.put(FOCUS, "focus");
        INVERSE_CLASS_MAP.put(LANG, "lang");
    }
    
    public static final short UNKNOWN_PSEUDO_ELEMENT = -1;
    
    public static final short FIRST_LINE = UNKNOWN_PSEUDO_ELEMENT + 1;
    public static final short FIRST_LETTER = FIRST_LINE + 1;
    public static final short BEFORE = FIRST_LETTER + 1;
    public static final short AFTER = BEFORE + 1;
    
    private static Map<String, Short> ELEMENT_MAP = new HashMap<String, Short>(8);
    
    static {
        ELEMENT_MAP.put("first-line", FIRST_LINE);
        ELEMENT_MAP.put("first-letter", FIRST_LETTER);
        ELEMENT_MAP.put("before", BEFORE);
        ELEMENT_MAP.put("after", AFTER);
    }
    
    private static Map<Short, String> INVERSE_ELEMENT_MAP = new HashMap<Short, String>(8);
    
    static {
        INVERSE_ELEMENT_MAP.put(FIRST_LINE, "first-line");
        INVERSE_ELEMENT_MAP.put(FIRST_LETTER, "first-letter");
        INVERSE_ELEMENT_MAP.put(BEFORE, "before");
        INVERSE_ELEMENT_MAP.put(AFTER, "after");
    }
    
    public static short getPseudoClassCode(String pseudoClass) {
        Short s = CLASS_MAP.get(pseudoClass.toLowerCase());
        return s == null ? UNKNOWN_PSEUDO_CLASS : s;
    }
    
    public static String getPseudoClassName(short code) {
        return INVERSE_CLASS_MAP.get(code);
    }
    
    public static short getPseudoElementCode(String pseudoElement) {
        Short s = ELEMENT_MAP.get(pseudoElement.toLowerCase());
        return s == null ? UNKNOWN_PSEUDO_ELEMENT : s;
    }
    
    public static String getPseudoElementName(short code) {
        return INVERSE_ELEMENT_MAP.get(code);
    }
}
