package toolbox.tousy.html;

/**
 * 
 * @author river
 *
 */
public class CharBuffer {

	char [] data;
	int offset;
	int limit;

	CharBuffer next = null; //for link 
	
	CharBuffer() {
		
	}
	
	/**
	 * 创建一个reference已有数据缓冲的CharBuffer.
	 * @param data
	 * @param offset
	 * @param length
	 */
	CharBuffer(char [] data, int offset, int limit) {
		this.data = data;
		this.offset = offset;
		this.limit = limit;
	}
	
	/**
	 * 创建一个standalone的CharBuffer.
	 * @param capacity
	 */
	public CharBuffer(int capacity) {
		offset = 0;
		limit = 0;
		data = new char[capacity];
	}
	
	void append(char ch) {
		if (limit == data.length) {
			ensureCapacity(data.length * 2);
		}
		data[limit++] = ch;
	}
	
	void ensureCapacity(int capacity) {
		if (data.length >= capacity) 
			return;
		
		char [] newBuffer = new char[capacity];
		System.arraycopy(data, offset, newBuffer, 0, limit-offset);
		limit -= offset;
		offset = 0;
		data = newBuffer;
	}
	
	void clear() {
		offset = 0;
		limit = 0;
	}
	
	public static final boolean equalsIgnoreCase(char [] buf, int offset, int count, String valueInUpperCase) {
		if (count != valueInUpperCase.length()) return false;
		int len = valueInUpperCase.length();
		
		for (int i=0; i<len; i++) {
			char ch = valueInUpperCase.charAt(i);
			if (buf[offset+i] != ch && Character.toLowerCase(buf[offset+i])!=ch) 
				break;
		}
		return true;
	}
	
	public boolean equalsIgnoreCase(String valueInUpperCase) {
		if (limit-offset != valueInUpperCase.length()) return false;
		int len = valueInUpperCase.length();
		for (int i=0; i<len; i++) {
			char ch = valueInUpperCase.charAt(i);
			if (data[offset+i] == ch) continue;
			if (Character.toLowerCase(data[offset+i]) == ch) continue;
			return false;
		}
		return true;
	}
	
	public String toString() {
		if (limit - offset <= 0) {
			return "";
		}
		return new String(data, offset, limit - offset);
	}
	
}
