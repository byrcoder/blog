package toolbox.tousy.html;

import java.util.HashMap;
import java.util.Map;

/**
 * Utilities for handling html color.
 * @author river
 *
 */
public class HTMLColor {
	public static final int DEFAULT_BG_COLOR = 0x00ffffff;
	public static final int DEFAULT_FONT_COLOR = 0x000000;
	
	public static final int AQUA = 0x00FFFF;
	public static final int BLACK = 0x000000;
	public static final int BLUE = 0x0000FF;
	public static final int FUCHSIA = 0xFF00FF;
	public static final int GRAY = 0x808080;
	public static final int GREEN = 0x008000;
	public static final int LIME = 0x00FF00;
	public static final int MAROON = 0x800000;
        public static final int NAVY = 0x000080;
        public static final int OLIVE =0x808000;
        public static final int PURPLE = 0x800080;
        public static final int RED = 0xFF0000;
        public static final int SILVER = 0xC0C0C0;
        public static final int TEAL = 0x008080;
        public static final int WHITE = 0xFFFFFF;
        public static final int YELLOW = 0xFFFF00;
        
	public static final int CYAN = 0x00ffff;
	
	public static final Map<String, Integer> COLOR_MAP = new HashMap<String, Integer>();
	static {
		//aqua, black, blue, fuchsia, gray, green, lime, 
		//maroon, navy, olive, purple, red, silver, teal, 
		//white, and yellow
		COLOR_MAP.put("aqua", 0x00FFFF);
		COLOR_MAP.put("blue", 0x0000FF);
		COLOR_MAP.put("black", 0x000000);
		COLOR_MAP.put("cyan", 0x00FFFF);
		COLOR_MAP.put("fuchsia", 0xFF00FF);
		COLOR_MAP.put("gray", 0x808080);
		COLOR_MAP.put("green", 0x008000);
		COLOR_MAP.put("lime", 0x00FF00);
		COLOR_MAP.put("maroon", 0x800000);
		COLOR_MAP.put("navy", 0x000080);
		COLOR_MAP.put("olive", 0x808000);
		COLOR_MAP.put("purple", 0x800080);
		COLOR_MAP.put("red", 0xFF0000);
		COLOR_MAP.put("silver", 0xC0C0C0);
		COLOR_MAP.put("teal", 0x008080);
		COLOR_MAP.put("white", 0xFFFFFF);
		COLOR_MAP.put("yellow", 0xFFFF00);
	}
	
	/**
	 * accept named color(such as "red") or rgb color (such as "#00cc00")
	 * and return rgb color as int.
	 * @param s
	 * @return
	 */
	public static int parseColor(String s) {
		int len;
		
		if (s == null || (len =s.length())==0)
			return -1;
		
		char firstChar = s.charAt(0);
		if (firstChar == '#') {
			//rgb color
			if (len != 7) return -1;
			try {
				return Integer.parseInt(s.substring(1), 16);
			} catch(Exception e) {
				return -1;
			}
		} else {
			s = s.trim().toLowerCase();
			if (s.startsWith("rgb(")) {
				int i = 4;
				int l = s.length();
				int c = 0;
				int cc = 0;
				
				while (i < l) {
					char ch = s.charAt(i);
					while (Character.isWhitespace(ch)) {
						++i;
						if (i < l) 
							ch = s.charAt(i);
						else 
							break;
					}
					
                    if (ch >= '0' && ch <= '9') {
                      int c1 = ch - '0';
                      while (++i < l) {
                        ch = s.charAt(i);
                        if (ch >='0' && ch<='9')
                          c1 = c1 * 10 + (ch-'0');
                        else break;
                      }
                      if (c1 < 0 || c1>=256) 
                        break;
                      
                      if (cc < 3) {
                    	  c = (c << 8) | c1;
                          cc ++;
                      }
                    }
                    
					
					while (Character.isWhitespace(ch)) {
						++i;
						if (i < l) 
							ch = s.charAt(i);
						else 
							break;
					}
					
					if (ch == ')') {
						return c;
					} 
					
					if (ch != ',')
						break;
					++i;
				}
				return -1;
			} else {
				Integer o = COLOR_MAP.get(s);
				if (o == null) {
					try {
						return Integer.parseInt(s, 16);
					} catch(Exception e) {
						return -1;
					}
				} else {
					return o.intValue();
				}
			}
		}
	}
	
}
