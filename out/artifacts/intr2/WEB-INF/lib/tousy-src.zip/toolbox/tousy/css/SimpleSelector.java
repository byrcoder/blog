/**
 * @(#)SimpleSelector.java, 2008-3-24. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tousy.css;

import java.util.HashSet;
import java.util.Set;

import toolbox.tousy.html.HTMLElements;

/**
 * 一个简单的selector
 * 
 * @author liruohao
 */
public class SimpleSelector {
    /**
     * 如果selector的tag是'*'，那么它的tag code是TAG_ALL
     */
    public static final short TAG_ALL = -2;
    
    /**
     * selector适用的html元素名称
     */
    private short tagCode;
    
    /**
     * id的名称（大写）
     */
    private String id;
    
    /**
     * class的名称，可以有多个（大写）
     */
    private Set<String> clazzes = new HashSet<String>(2);
    
    /**
     * pseudo class的名称
     */
    private short pseudoClassCode = CssPseudos.UNKNOWN_PSEUDO_CLASS;
    
    /**
     * pseudo element的名称
     */
    private short pseudoElementCode = CssPseudos.UNKNOWN_PSEUDO_ELEMENT;
    
    /**
     * selector的得分
     */
    private int specificity;
    
    public SimpleSelector(String selector) {
        selector = selector.toLowerCase();
        StringBuilder sb = new StringBuilder();
        int i = 0;
        
        while (i < selector.length()) {
            char c = selector.charAt(i);
            if (c != '#' && c != '.' && c != ':') {
                sb.append(c);
            } else {
                break;
            }
            ++i;
        }
        String tagName = sb.toString();
        tagCode = (tagName.equals("*") ? TAG_ALL : HTMLElements.findElementByName(tagName).code);
        
        while (i < selector.length()) {
            char c = selector.charAt(i);
            if (c == '#') {
                ++i;
                sb.setLength(0);
                while (i < selector.length()) {
                    c = selector.charAt(i);
                    if (c != '.' && c != ':') {
                        sb.append(c);
                    } else {
                        break;
                    }
                    ++i;
                }
                id = sb.toString();
            } else if (c == '.') {
                ++i;
                sb.setLength(0);
                while (i < selector.length()) {
                    c = selector.charAt(i);
                    if (c != '#' && c != '.' && c!= ':') {
                        sb.append(c);
                    } else {
                        break;
                    }
                    ++i;
                }
                clazzes.add(sb.toString());
            } else if (c == ':') {
                ++i;
                sb.setLength(0);
                while (i < selector.length()) {
                    c = selector.charAt(i);
                    if (c != '#' && c != '.' && c!= ':') {
                        sb.append(c);
                    } else {
                        break;
                    }
                    ++i;
                }
                String pseudo = sb.toString();
                pseudoClassCode = CssPseudos.getPseudoClassCode(pseudo);
                if (pseudoClassCode == CssPseudos.UNKNOWN_PSEUDO_CLASS) {
                    pseudoElementCode = CssPseudos.getPseudoElementCode(pseudo);
                }
            }
        }
        
        int a = 0;
        int b = (id == null ? 0 : 1);
        int c = clazzes.size() + (pseudoClassCode == CssPseudos.UNKNOWN_PSEUDO_CLASS ? 0 : 1);
        int d = (tagCode == TAG_ALL ? 0 : 1) + (pseudoElementCode == CssPseudos.UNKNOWN_PSEUDO_ELEMENT ? 0 : 1);
        specificity = a * 8000 + b * 400 + c * 20 + d;
    }
    
    public int getSpecificity() {
        return specificity;
    }
    
    /**
     * 比较selector与元素的attributes
     * @param tagCode html元素名称
     * @param id id名称（大写）
     * @param clazzes class名称（大写）
     * @return
     */
    public boolean match(short tagCode, String id, Set<String> clazzes) {
        boolean b = (this.tagCode == TAG_ALL || this.tagCode == tagCode)
            && (this.id == null || (id != null && this.id.equals(id)))
            && clazzes.containsAll(this.clazzes);
        if (tagCode == HTMLElements.A) {
            b = b && (pseudoClassCode == CssPseudos.UNKNOWN_PSEUDO_CLASS || pseudoClassCode == CssPseudos.LINK);
        }
        return b;
    }
    
    /**
     * 比较selector与html元素具有的css属性是否相符
     * @param attrs html元素具有的css属性
     * @return
     */
    public boolean match(CssAttributes attrs) {
        return match(attrs.getTagCode(), attrs.getId(), attrs.getClazzes());
    }
    
    /**
     * 返回tagCode
     * @return
     */
    public short getTagCode() {
        return tagCode;
    }
    
    /**
     * 返回id
     * @return
     */
    public String getId() {
        return id;
    }
    
    /**
     * 返回clazzes
     * @return
     */
    public Set<String> getClazzes() {
        return clazzes;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append(tagCode == TAG_ALL ? "*" : HTMLElements.findElement(tagCode).name);
        if (id != null) {
            sb.append("#" + id);
        }
        for (String clazz : clazzes) {
            sb.append("." + clazz);
        }
        if (pseudoClassCode != CssPseudos.UNKNOWN_PSEUDO_CLASS) {
            sb.append(":" + CssPseudos.getPseudoClassName(pseudoClassCode));
        } else if (pseudoElementCode != CssPseudos.UNKNOWN_PSEUDO_ELEMENT) {
            sb.append(":" + CssPseudos.getPseudoElementName(pseudoElementCode));
        }
        sb.append(" (").append(specificity).append(")");
        
        return sb.toString();
    }
}
