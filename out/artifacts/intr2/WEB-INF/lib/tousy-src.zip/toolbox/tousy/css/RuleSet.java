/**
 * @(#)RuleSet.java, 2007-8-10. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tousy.css;

import java.util.Set;

/**
 * 表示css中的一个规则集。
 * 每个规则集包含selector和declarations两部分。
 * 我们只关注html元素名称、id、class以及pseudo class作为selector的情况
 *
 * @author liruohao
 */
public class RuleSet {
    /**
     * selector
     */
    private SimpleSelector selector;
    
    /**
     * declarations（包含若干property/value对儿）
     */
    private Declarations declarations;
    
    /**
     * 规则集的得分
     */
    private int specificity;
    
    /**
     * 构造函数
     * @param selector 选择器
     * @param declarations declarations
     */
    public RuleSet(String selector, Declarations declarations) {
        this.selector = new SimpleSelector(selector);
        this.declarations = declarations;
        specificity = this.selector.getSpecificity();
    }
    
    /**
     * 返回selector
     * @return selector
     */
    public SimpleSelector getSelector() {
        return selector;
    }
    
    /**
     * 返回declarations
     * @return declarations
     */
    public Declarations getDeclarations() {
        return declarations;
    }
    
    /**
     * 返回specificity
     * @return specificity
     */
    public int getSpecificity() {
        return specificity;
    }
    
    /**
     * 返回此规则集是否包含相应的规则
     * @param propertyCode 所需的css属性
     * @param tagCode html元素名称
     * @param id html元素id（必须大写）
     * @param clazz html元素class（必须大写）
     * @return 此规则集是否包含相应的规则
     */
    public boolean match(short propertyCode, short tagCode, String id, Set<String> clazzes) {
        return declarations.has(propertyCode) && selector.match(tagCode, id, clazzes);
    }
    
    /**
     * 返回对象的字符串表示
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("SELECTOR: ").append(selector).append("\n");
        sb.append("DECLARATIONS:\n" + declarations).append("\n");
        sb.append("SPECIFICITY: ").append(specificity).append("\n");
        
        return sb.toString();
    }
}
