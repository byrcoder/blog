package toolbox.tousy.html;

public class CharCategory {

	public static final boolean [] WHITE_SPACE_FLAG = new boolean[12289];
	public static final int WHITE_SPACE_FLAG_LENGTH = WHITE_SPACE_FLAG.length;
	
	static {
		for (int i=0; i<WHITE_SPACE_FLAG.length; i++) {
			WHITE_SPACE_FLAG[i] = Character.isWhitespace(i);
		}
	}
	
	public static final boolean [] TAG_NAME_FLAG = new boolean[128];
	public static final int TAG_NAME_FLAG_LENGTH = TAG_NAME_FLAG.length;
	
	static {
		for (int i=0; i<TAG_NAME_FLAG.length; i++) {
			TAG_NAME_FLAG[i] = Character.isLetterOrDigit(i) 
			|| i == '-' || i == '.' || i == ':' || i == '_';
		}
	}

}
