package toolbox.tousy.css;

import java.io.CharArrayReader;
import java.io.IOException;
import java.io.Reader;

import org.apache.batik.css.parser.Parser;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;

/**
 * 对css文档进行分析
 *
 * @author river
 * @author liruohao
 */
public class CssParser {
    /**
     * css文档分析器
     */
    private Parser parser = new Parser();
    
    /**
     * 分析处于字符串缓冲区中的css文档
     * @param buf 字符缓冲区
     * @param begin 起点
     * @param count 长度
     * @param cssHandler css文档处理器
     * @throws IOException
     */
    public void parse(char[] buf, int begin, int count, CssDocumentHandler cssHandler) throws IOException {
        Reader reader = new CharArrayReader(buf, begin, count);
        try {
            parse(reader, cssHandler);
        } finally {
            reader.close();
        }
    }
    
    /**
     * 分析处于<code>Reader</code>中的css文档
     * @param reader <code>Reader</code>对象
     * @param cssHandler css文档处理器
     * @throws IOException
     */
    public void parse(Reader reader, CssDocumentHandler cssHandler) throws IOException {
        parser.setDocumentHandler(cssHandler);
        parser.parseStyleSheet(new InputSource(reader));
    }
    
    /**
     * 分析处于URI上的css文档
     * @param uri css文档地址
     * @param cssHandler css文档处理器
     * @throws IOException
     */
    public void parse(String uri, CssDocumentHandler cssHandler) throws IOException {
        parser.setDocumentHandler(cssHandler);
        parser.parseStyleSheet(uri);
    }
    
    /**
     * 分析处于字符串中的规则
     * @param source 字符串（注意：此字符串中只列出每条规则，不包含selector的内容）
     * @return 字符串中的规则
     * @throws CSSException
     * @throws IOException
     */
    public Declarations parseRule(String source) throws CSSException, IOException {
        Declarations declarations = new Declarations();
        parser.setDocumentHandler(declarations);
        parser.parseRule("{" + source + "}");
        return declarations;
    }
    
    
    public static void main(String[] args){
        CssParser cssParser = new CssParser();
        CssDocumentHandler handler = new CssDocumentHandler();
        String st = 
            "a{ font-size:9pt;text-decoration: none;}\n" +
            "a:hover {  font-size:9pt;text-decoration: underline;}\n" +
            "a.behavior{ font-size:10pt;color : #FFFFFF; text-decoration: none;}\n" +
            "a:hover.behavior{  font-size:10pt;text-decoration: underline; color : #FFFFFF; }\n";
        try {
            cssParser.parse(st.toCharArray(), 0, st.length(), handler);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(handler.getParseInfo());
    }
}
