/**
 * @(#)CssAttributes.java, 2008-3-25. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tousy.css;

import java.util.HashSet;
import java.util.Set;

/**
 * 一个html元素具有的和css相关的属性
 * 
 * @author liruohao
 */
public class CssAttributes {
    private short tagCode;
    /**
     * id和clazzes中的字符串是全大写的
     */
    private String id;
    private Set<String> clazzes = new HashSet<String>(2);
    
    public CssAttributes() {
        
    }
    
    public CssAttributes(short tagCode, String id, Set<String> clazzes) {
        this.tagCode = tagCode;
        this.id = id.toLowerCase();
        for (String clazz : clazzes) {
            clazzes.add(clazz.toLowerCase());
        }
    }
    
    public short getTagCode() {
        return tagCode;
    }
    
    public void setTagCode(short tagCode) {
        this.tagCode = tagCode;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id.toLowerCase();
    }
    
    public Set<String> getClazzes() {
        return clazzes;
    }
    
    public void setClazzes(Set<String> clazzes) {
        if (this.clazzes == clazzes) {
            return;
        }
        
        this.clazzes.clear();
        for (String clazz : clazzes) {
            this.clazzes.add(clazz.toLowerCase());
        }
    }
}
