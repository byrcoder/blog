package toolbox.tousy.html;

import java.util.HashMap;
import java.util.Map;

/**
 * Utility for translating font settings into comparable value.
 * 
 * 1 in = 96
 * 1 px = 1
 * 1 pt = 4/3
 * 1 pc = 16
 * 1 mm = 3.7795, 1 in = 25.4 mm
 * 1 cm = 37.795
 * 1 em = 8
 * 
 * xx-small = 10
 * x-small = 14
 * small = 16
 * medium = 18
 * large = 24
 * x-large = 32
 * xx-large = 48
 * 
 * For setting with "&lt;FONT&gt;":
 * 1 = 10
 * 2 = 14
 * 3 = 16
 * 4 = 18
 * 5 = 24
 * 6 = 32
 * 7 = 48
 * 
 * default = 16
 * 
 * @author river
 *
 */
public class HTMLFont {

	public static final int NORMAL = 0;
	public static final int BOLD = 1;
	public static final int DEFAULT_FONT_WEIGHT = NORMAL;

	public static final double IN = 96.0;
	public static final double PX = 1.0;
	public static final double PT = 1.3333;
	public static final double PC = 16.0;
	public static final double MM = 3.7795;
	public static final double CM = 37.795;
	public static final double EM = 8.0;
	public static final double EX = 7.0;
	
	public static final double [] H = {32, 24, 18, 16, 14, 10};
	
	public static final Map<String, Double> UNITS = new HashMap<String, Double>();
	static {
		UNITS.put("IN", IN);
		UNITS.put("PX", PX);
		UNITS.put("PT", PT);
		UNITS.put("PC", PC);
		UNITS.put("MM", MM);
		UNITS.put("CM", CM);
	}
	
	public static final Map<String, Integer> NAMED_CSS_FONT_SIZE = new HashMap<String, Integer>();
	static {
		NAMED_CSS_FONT_SIZE.put("XX-SMALL", 10);
		NAMED_CSS_FONT_SIZE.put("X-SMALL", 14);
		NAMED_CSS_FONT_SIZE.put("SMALL", 16);
		NAMED_CSS_FONT_SIZE.put("MEDIUM", 18);
		NAMED_CSS_FONT_SIZE.put("LARGE", 24);
		NAMED_CSS_FONT_SIZE.put("X-LARGE", 32);
		NAMED_CSS_FONT_SIZE.put("XX-LARGE", 48);
	}
	
	public static final int [] FONT_LEVELS = {10, 14, 16, 18, 24, 32, 48};
	public static final int DEFAULT_FONT_LEVEL = 3;
	
	/**
	 * Default font size.
	 */
	public static final int DEFAULT_FONT_SIZE = 16;
	
	private int px;
	private boolean isPercent = false;
	
	public HTMLFont(int px, boolean isPercent) {
		this.px = px;
		this.isPercent = isPercent;
	}
	
	/**
	 * Parse "font-size" setting in css, such as "px", "pt", "pc", percentage, etc.
	 * @param value
	 * @return -1 indicates parse error
	 */
	public static HTMLFont parseCSSFont(String value) {
		if (value == null || value.length()==0)
			return null;
		
		int len = value.length();
		if (Character.isDigit(value.charAt(0))) {
			int d = 0;
			int i;
			char ch = 0;
			for (i=0; i<len; i++) {
				ch = value.charAt(i);
				if (ch >='0' && ch<='9') {
					d = d * 10 + (ch - '0');
				} else {
					break;
				}
			}
			
			while (i < len && ch == ' ') {
				ch = value.charAt(++i);
			}
			
			if (i >= len) {//default unit is "px"
				return new HTMLFont(d, false);
			}
			
			String unit = value.substring(i).toLowerCase();
			if (unit.equals("%")) {
				return new HTMLFont(d, true);
			} 
			
			Double o = UNITS.get(unit);
			if (o != null)
				return new HTMLFont(d, false);
			else
				return null;
		} else {
			value = value.toLowerCase();
			Integer o = NAMED_CSS_FONT_SIZE.get(value);
			if (o == null)
				return null;
			else
				return new HTMLFont(o.intValue(), false);
		}
	}
	
	public int getFont(int base) {
		if (isPercent) {
			return base * px / 100;
		} else {
			return px;
		}
	}
	
	public static int parseCSSFontSize(String value, int base) {
		HTMLFont font = parseCSSFont(value);
		if (font == null)
			return -1;
		else 
			return font.getFont(base);
	}
	
	/**
	 * Parse "size" setting in font tag.
	 * @param value
	 * @param base
	 * @return -1 if parse error
	 */
	public static int parseFontSize(String value) {
		if (value == null || value.length() == 0) {
			return -1;
		}
		
		char ch = value.charAt(0);
		int d;
		int level;
		if (ch == '+' || ch=='-') {
			try {
				d = Integer.parseInt(value.substring(1));
			} catch(Exception e) {
				return -1;
			}
			if (ch == '+') {
				level = DEFAULT_FONT_LEVEL + d;
			} else {
				level = DEFAULT_FONT_LEVEL - d;
			}
		} else {
			try {
				level = Integer.parseInt(value);
				if (level == 0) { //level 0 is error
					return -1;
				}
			} catch(Exception e) {
				return -1;
			}
		}
		
		if (level > 7)
			level = 7;
		else if (level < 1)
			level = 1;
		
		return FONT_LEVELS[level-1];
	}
	
	public static void main(String [] args) throws Exception {
		System.out.println(parseCSSFontSize("3  inch", 102));
	}
}
