package toolbox.tousy.html;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * 可以使用CharBuffer的属性表实现，确保在大部分的情况下只有在实际读取
 * 对应的属性的时候才创建String对象.
 * 
 * @author river
 *
 */
public class Attributes extends Properties {
	/**
     * auto generate a serialVersionUID
     */
    private static final long serialVersionUID = 7980650191523212266L;

    private Map <String, Object> map = new HashMap<String, Object>();
	
	private CharBuffer freeBuffers = null;
	private CharBuffer usedBuffers = null;
	
	public Attributes() {
		
	}
	
	public void clear() {
		map.clear();
		while (usedBuffers != null) {
			CharBuffer toRelease = usedBuffers;
			usedBuffers = usedBuffers.next;
			toRelease.next = freeBuffers;
			freeBuffers = toRelease;
            toRelease.data = null;
            toRelease.clear();
		}
	}
	
	void setProperty(String name, char [] buf, int offset, int limit) {
		CharBuffer newBuffer;
		if (freeBuffers == null) {
			newBuffer = new CharBuffer();
		} else {
			newBuffer = freeBuffers;
			freeBuffers = freeBuffers.next;
		}
//		CharBuffer newBuffer = new CharBuffer();
		newBuffer.next = usedBuffers;
		usedBuffers = newBuffer;
		newBuffer.data = buf;
		newBuffer.offset = offset;
		newBuffer.limit = limit;
		map.put(name, newBuffer);
	}
	
	void setProperty(String name, CharBuffer buf) {
		setProperty(name, buf.data, buf.offset, buf.limit);
	}
	
	public Object setProperty(String name, String value) {
		map.put(name, value);
		return null;
	}
	
	public String getProperty(String name, String defValue) {
		Object o = map.get(name);
		if (o == null)
			return defValue;
		if (o instanceof String)
			return (String)o;
		else
			return o.toString();
	}
	
	public String getProperty(String name) {
		Object o = map.get(name);
		if (o == null) {
			return null;
		} else {
			if (o instanceof String) 
				return (String)o;
			else
				return o.toString();
		}
	}
}
