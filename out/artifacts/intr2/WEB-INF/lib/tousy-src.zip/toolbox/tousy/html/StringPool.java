package toolbox.tousy.html;

/**
 * 字符串池，给出字符数组的情况下可以从字符串池中获得已有的字符串的大写形式. 在html 扫描过程中，大量使用重复的字符串，通过使用字符串池可以减少过程
 * 中的中间对象. {@link HTMLElements} 实际也是一个字符串池，里面保存了所有的html element对应的 字符串.
 * 
 * @see HTMLElements#findElementByName(CharBuffer)
 * @author river
 * @author river
 */
public class StringPool {

    private static class StringEntry {
        private String value;

        private int hash;

        public StringEntry(String value) {
            this.value = value.toLowerCase();
            char[] arr = this.value.toCharArray();
            this.hash = hash(arr, 0, arr.length);
        }

    }

    private boolean optimistic;

    private StringEntry[][] entries;

    /**
     * 创建一个字符串池. optimistic为true的情况下，在池中检索的时候， 当字符串的{@link #hash(char[], int)}相等的情况下，就会认为字符串
     * 是一样的，这样避免了字符串比较.
     * 
     * @param optimistic
     *            是否采用乐观的字符串比较方式
     * @param hashSize
     *            hash表的大小，通过调整这个值，我们可以获得比较小的 碰撞率.
     */
    public StringPool(boolean optimistic, int hashSize) {
        this.optimistic = optimistic;
        int size = 1;
        while (size < hashSize)
            size = size << 1;

        entries = new StringEntry[size][];
    }

    /**
     * 将一个字符串放入pool中.
     * 
     * @param value
     */
    public void add(String value) {
        char[] charArray = value.toCharArray();
        int hash = hash(charArray, 0, charArray.length);
        int index = hash & (entries.length - 1);
        StringEntry[] bucket = entries[index];
        StringEntry[] newBucket;
        if (bucket == null) {
            newBucket = new StringEntry[1];
        } else {
            newBucket = new StringEntry[bucket.length + 1];
            System.arraycopy(bucket, 0, newBucket, 0, bucket.length);
        }
        newBucket[newBucket.length - 1] = new StringEntry(value);
        entries[index] = newBucket;
    }

    /**
     * 大小写无关的字符串hash，在{@link String#hashCode()}的基础上修改得到.
     * 
     * @param buf
     * @param offset
     * @param count
     * @return
     */
    public static final int hash(char[] buf, int offset, int count) {
        int hash = 0;
        for (int i = 0; i < count; i++)
            hash = hash * 31 + (((int) buf[offset + i]) | (0x01 << 5));
        return hash;
    }

    public final String findString(char[] buf, int offset, int count) {
        int hash = hash(buf, offset, count);
        int index = hash & (entries.length - 1);
        StringEntry[] bucket = entries[index];
        if (bucket == null)
            return null;

        for (int i = 0; i < bucket.length; i++) {
            StringEntry entry = bucket[i];
            if (entry.hash == hash) {
                if (optimistic
                        || CharBuffer.equalsIgnoreCase(buf, offset, count,
                                entry.value))
                    return entry.value;
            }
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        StringPool pool = new StringPool(true, 512);

        pool.add("href");
        pool.add("src");
        pool.add("equiv");
        pool.add("value");
        pool.add("type");
        pool.add("name");
        pool.add("id");
        pool.add("alt");

        char[] src = {
            'A', 'l', 'm'
        };
        System.out.println(pool.findString(src, 0, src.length));
    }
}
