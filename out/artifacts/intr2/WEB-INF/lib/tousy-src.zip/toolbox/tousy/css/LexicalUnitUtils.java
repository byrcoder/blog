/**
 * @(#)LexicalUnitUtils.java, 2007-8-14. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tousy.css;

import org.w3c.css.sac.LexicalUnit;

/**
 * 应用于接口<code>LexicalUnit</code>的工具
 * 
 * @author liruohao
 */
public class LexicalUnitUtils {
    /**
     * 返回给定<code>LexicalUnit</code>对象的字符串表示
     * @param unit <code>LexicalUnit</code>对象
     * @return 给定<code>LexicalUnit</code>对象的字符串表示
     */
    public static String toString(LexicalUnit unit) {
        StringBuilder sb = new StringBuilder();
        
        while (unit != null) {
            sb.append(toStringForSingleUnit(unit));
            sb.append(' ');
            unit = unit.getNextLexicalUnit();
        }
        sb.deleteCharAt(sb.length() - 1);
        
        return sb.toString();
    }
    
    /**
     * 返回给定<code>LexicalUnit</code>对象的字符串表示
     * @param unit <code>LexicalUnit</code>对象
     * @return 给定<code>LexicalUnit</code>对象的字符串表示
     */
    private static String toStringForSingleUnit(LexicalUnit unit) {
        switch (unit.getLexicalUnitType()) {
            case LexicalUnit.SAC_ATTR:
            case LexicalUnit.SAC_IDENT:
            case LexicalUnit.SAC_STRING_VALUE:
            case LexicalUnit.SAC_URI:
            case LexicalUnit.SAC_UNICODERANGE:
                return unit.getStringValue();
            
            case LexicalUnit.SAC_CENTIMETER:
            case LexicalUnit.SAC_DEGREE:
            case LexicalUnit.SAC_DIMENSION:
            case LexicalUnit.SAC_EM:
            case LexicalUnit.SAC_EX:
            case LexicalUnit.SAC_GRADIAN:
            case LexicalUnit.SAC_HERTZ:
            case LexicalUnit.SAC_INCH:
            case LexicalUnit.SAC_KILOHERTZ:
            case LexicalUnit.SAC_MILLIMETER:
            case LexicalUnit.SAC_MILLISECOND:
            case LexicalUnit.SAC_PERCENTAGE:
            case LexicalUnit.SAC_PICA:
            case LexicalUnit.SAC_PIXEL:
            case LexicalUnit.SAC_POINT:
            case LexicalUnit.SAC_RADIAN:
            case LexicalUnit.SAC_REAL:
            case LexicalUnit.SAC_SECOND:
                return String.format("%f%s", unit.getFloatValue(), unit.getDimensionUnitText());
            
            case LexicalUnit.SAC_COUNTER_FUNCTION:
            case LexicalUnit.SAC_COUNTERS_FUNCTION:
            case LexicalUnit.SAC_FUNCTION:
            case LexicalUnit.SAC_RECT_FUNCTION:
            case LexicalUnit.SAC_RGBCOLOR:
                StringBuilder sb = new StringBuilder();
                
                sb.append(unit.getFunctionName() + "(");
                LexicalUnit head = unit.getParameters();
                while (head != null) {
                    sb.append(toStringForSingleUnit(head));
                    head = head.getNextLexicalUnit();
                }
                sb.append(")");
                
                return sb.toString();
                
            case LexicalUnit.SAC_INHERIT:
                return "INHERIT";
                
            case LexicalUnit.SAC_INTEGER:
                return String.format("%d", unit.getIntegerValue());
                
            case LexicalUnit.SAC_OPERATOR_COMMA:
                return ",";
                
            case LexicalUnit.SAC_OPERATOR_EXP:
                return "^";
                
            case LexicalUnit.SAC_OPERATOR_GE:
                return ">=";
                
            case LexicalUnit.SAC_OPERATOR_GT:
                return ">";
                
            case LexicalUnit.SAC_OPERATOR_LE:
                return "<=";
                
            case LexicalUnit.SAC_OPERATOR_LT:
                return "<";
                
            case LexicalUnit.SAC_OPERATOR_MINUS:
                return "-";
                
            case LexicalUnit.SAC_OPERATOR_MOD:
                return "%";
                
            case LexicalUnit.SAC_OPERATOR_MULTIPLY:
                return "*";
                
            case LexicalUnit.SAC_OPERATOR_PLUS:
                return "+";
                
            case LexicalUnit.SAC_OPERATOR_SLASH:
                return "/";
                
            case LexicalUnit.SAC_OPERATOR_TILDE:
                return "~";
                
            case LexicalUnit.SAC_SUB_EXPRESSION:
                sb = new StringBuilder();
                
                head = unit.getSubValues();
                while (head != null) {
                    sb.append(toStringForSingleUnit(head));
                    head = head.getNextLexicalUnit();
                }
                
                return sb.toString();
                
            default:
                return "UNKNOWN";
        }
    }
}
