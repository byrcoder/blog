/**
 * Classes for implementing an OAuth Service Provider; that is
 * a server that controls access to protected resources.
 */
package net.oauth.server;

