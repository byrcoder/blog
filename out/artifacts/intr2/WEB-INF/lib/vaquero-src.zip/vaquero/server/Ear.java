package vaquero.server;

import java.io.ByteArrayInputStream;
import java.util.logging.Logger;

import vaquero.omchannel.OMChannel;
import vaquero.omchannel.util.OMData;

/**
 * Listener of the incomming data
 * @author yaming
 *
 */
public class Ear extends Thread {
    
    private static final Logger LOG = Logger.getLogger(Ear.class.getName());
    
    public static final long TIME_OUT = 2000;
    public static final int RECV_QUEUE_SIZE = 1024;

    private boolean running = true;
    private OMChannel channel = null;
    
    public void setChannel(OMChannel channel) {
        this.channel = channel;
    }
    
    public void run() {
        if(channel == null) {
            LOG.severe("No valid MooChannel set");
            this.close();
        }
        channel.setReceivedQueueSize(RECV_QUEUE_SIZE);
        channel.setTimeOut(TIME_OUT);
        channel.listen();
        OMData recvData;
        while(running) {
            recvData = channel.receive();
            ByteArrayInputStream input = new ByteArrayInputStream(
                     recvData.getData(), 0, recvData.getLength());
            Shepherd.get().feed(input);
        }
    }

    public void close() {
        this.running = false;
        try { this.join(); } catch (InterruptedException e) { }
    }
}
