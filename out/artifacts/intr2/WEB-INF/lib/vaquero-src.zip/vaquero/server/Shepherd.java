package vaquero.server;

import java.io.ByteArrayInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import vaquero.VaqueroConstants;
import vaquero.herd.Cub;
import vaquero.herd.Herd;

public class Shepherd implements VaqueroConstants {

    private static final Logger LOG = Logger
            .getLogger(Shepherd.class.getName());

    private Herd herd;

    private static final Shepherd instance = new Shepherd();

    private Shepherd() {}

    public static Shepherd get() {
        return instance;
    }

    public void setHerd(Herd herd) {
        this.herd = herd;
    }

    public Herd getHerd() {
        return this.herd;
    }

    public void feed(ByteArrayInputStream input) {

        StreamSource source = new StreamSource(input);
        DOMResult result = new DOMResult();

        Transformer transformer;
        try {
            transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);
        } catch (TransformerConfigurationException e) {
            LOG.log(Level.SEVERE, "Cannot get transformer correctly", e);
            return;
        } catch (TransformerException e) {
            LOG.log(Level.WARNING, "Cannot transfer node correctly", e);
            return;
        }

        NodeList cubNodes = result.getNode().getChildNodes();

        for (int n = 0; n < cubNodes.getLength(); n++) {
            NodeList list = ((Element) cubNodes.item(n))
                    .getElementsByTagName(MOO_TAG_CUB);
            for (int i = 0; i < list.getLength(); i++) {
                Element node = (Element) list.item(i);
                String cubType = node.getAttribute(MOO_TAG_CUB_ATTR_TYPE);
                String cubName = node.getAttribute(MOO_TAG_CUB_ATTR_NAME);
                Cub cub = herd.getCub(cubType, cubName);
                if (cub == null) {
                    LOG.log(Level.SEVERE, "No cub get, maybe nonsupport type:("
                            + cubType + "," + cubName + ")");
                    return;
                }
                try {
                    cub.update(node);
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "Caught Exception when update cub, ", e);
                }
            }
        }

    }

}
