package vaquero.server;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.logging.Logger;

import org.mortbay.http.SocketListener;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.servlet.ServletHttpContext;
import org.mortbay.jetty.servlet.WebApplicationContext;

/**
 * The HTTP Server of the vaquero, for the webpage and servlet
 * Using jetty
 * @author yaming
 *
 */
public class WebServer {
    
    private static final Logger LOG = Logger.getLogger(WebServer.class.getName());
    private static final boolean WINDOWS = System.getProperty("os.name").startsWith("Windows");
    
    Server server;
    WebApplicationContext appContext;
    ServletHttpContext servletContext;
    
    public WebServer(int port) throws Exception {        
        this.server = new Server();
        
        String path = Shepherd.get().getHerd().getWebRoot().getPath();
        if (WINDOWS && path.startsWith("/")) {
            path = path.substring(1);
            try { path = URLDecoder.decode(path, "UTF-8"); } 
            catch (UnsupportedEncodingException e) { }
        }
        
        appContext = server.addWebApplication(null, "/", path);
        
        SocketListener socketListener = new SocketListener();
        socketListener.setPort(port);
        server.addListener(socketListener);
    }    

    /**
     * The thread class we need to kick off the HTTP server async-style.
     */
    private class HTTPStarter implements Runnable {
        public void run() {
            try {
                server.start();
            } catch (Exception me) {
                me.printStackTrace();
            }
        }
    }

    /**
     * Launch the HTTP server
     */
    public void start() throws IOException {
        new Thread(new HTTPStarter()).start();
        try { Thread.sleep(1000); } catch (InterruptedException e) { }
        if (! server.isStarted()) {
            LOG.severe("Could not start HTTP server");
            throw new IOException("Could not start HTTP server");
        }
    }

    /**
     * Stop the HTTP server
     */
    public void stop() {
        try { this.server.stop(); } catch (InterruptedException e) { }
    }
}
