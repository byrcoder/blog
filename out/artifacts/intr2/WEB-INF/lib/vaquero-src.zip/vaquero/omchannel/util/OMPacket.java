package vaquero.omchannel.util;

public class OMPacket {
  int length;
  byte[] data;
  
  public OMPacket(byte[] data, int offset, int count) {
    this.length = count;
    this.data = new byte[length];
    System.arraycopy(data, offset, this.data, 0, length);
  }
}
