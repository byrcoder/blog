package vaquero.omchannel.util;

import java.net.InetAddress;

public class OMData {
  InetAddress address;
  byte[] data;
  int length;
  
  public OMData(InetAddress address, byte[] data, int offset, int count) {
    this.address = address;
    this.data = new byte[count];
    System.arraycopy(data, offset, this.data, 0, count);
    this.length = count;
  }
  
  public OMData(OMBlock block) {
    this.address = block.address;
    this.data = new byte[block.dataLength];
    int offset = 0;
    for(int i = 0; i < block.getPacketsNum(); i++) {
      System.arraycopy(block.packets[i].data, 0, data, offset, block.packets[i].length);
      offset += block.packets[i].length;
    }
    this.length = block.dataLength;
  }
  
  public InetAddress getAddress() {
    return this.address;
  }
  
  public byte[] getData() {
    return this.data;
  }
  
  public int getLength() {
      return this.length;
  }
}
