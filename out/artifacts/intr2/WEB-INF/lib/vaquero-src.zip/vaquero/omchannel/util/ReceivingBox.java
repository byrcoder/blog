package vaquero.omchannel.util;

import java.util.LinkedHashMap;
import java.util.Map;

public class ReceivingBox extends LinkedHashMap<String, OMBlock> {
    
  private static final long serialVersionUID = 5399974368371025583L;
  private long timeout;
  
  public void setTimeout(long timeout) {
    this.timeout = timeout;
  }
  protected boolean removeEldestEntry(Map.Entry<String, OMBlock> eldest) {
    if(System.currentTimeMillis() - eldest.getValue().lastUpdate > timeout) {
      return true;
    }
    return false;
  }

}
