package vaquero.omchannel;

import java.io.IOException;
import java.net.InetAddress;

import vaquero.omchannel.util.OMData;

public class OMChannel implements OMChannelInterface {

  private WorkingThread worker;

    public OMChannel(InetAddress serverAddress, int port, boolean isServer) throws IOException {
        worker = new WorkingThread(serverAddress, port, isServer);
    }

    public void setTimeOut(long timeout) {
        worker.setTimeout(timeout);
    }

    public void setReceivedQueueSize(int size) {
        worker.setReceivedQueueSize(size);
    }

    public void listen() {
        worker.start();
    }

    public OMData receive() {
        return worker.receive();
    }

    public void send(byte[] data, int offset, int count) throws IOException {
        worker.send(data, offset, count);
    }

    public void close() {
    // TODO Auto-generated method stub
    }
}
