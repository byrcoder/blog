package vaquero.omchannel;

import java.io.IOException;

import vaquero.omchannel.util.OMData;

/**
 * Interface of the vaquero.omchannel
 * @author yaming
 *
 */
public interface OMChannelInterface {
  /**
   * Set timeout to abandon a packet.
   * @param timeout
   */
  void setTimeOut(long timeout);
  
  /**
   * Set the size of the received queue.
   * @param size
   */
  void setReceivedQueueSize(int size);
  
  /**
   * start to listen. 
   * In fact it is going to start a working thread.   
   *
   */
  void listen();
  
  /**
   * Get the whole data.
   * @return
   */
  OMData receive();
  
  /**
   * Send out data.
   * @param data
   * @param offset
   * @param count
   */
  void send(byte[] data, int offset, int count) throws IOException;
  
  /**
   * Close the channel.
   *
   */
  void close();
  
}
