package vaquero.omchannel;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.rmi.server.UID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import vaquero.omchannel.util.OMBlock;
import vaquero.omchannel.util.OMData;
import vaquero.omchannel.util.ReceivingBox;

public class WorkingThread extends Thread {

    private static final Logger LOG = Logger.getLogger(WorkingThread.class
            .getName());

    private static final int DEFAULT_TIMEOUT = 2000;

    private static final int DEFAULT_RECEIVEDQUEUESIZE = 128;

    // protocol
    private static final int SINGLE_PACKET_DATALENGTH_MAX = 4088;

    private static final int MULTI_PACKET_DATALENGTH_MAX = 4074;

    private short magic = 10;

    private short version = 1;

    private int maxPacketSize = 4096;

    private boolean running;

    private InetAddress serverAddress;

    private int port;

    private DatagramSocket sock;

    private long timeout;

    private int receivedQueueSize;

    private ReceivingBox receivingBox;

    private ArrayBlockingQueue<OMData> receivedQueue;

    public WorkingThread(InetAddress serverAddress, int port, boolean isServer)
            throws IOException {
        this.serverAddress = serverAddress;
        this.port = port;
        init(isServer);
    }

    public void init(boolean isServer) throws IOException {
        running = true;
        if (isServer) {
            sock = new DatagramSocket(port);
        } else {
            sock = new DatagramSocket();
        }
        timeout = DEFAULT_TIMEOUT;
        receivedQueueSize = DEFAULT_RECEIVEDQUEUESIZE;
        // TODO
    }

    public void setReceivedQueueSize(int receivedQueueSize) {
        this.receivedQueueSize = receivedQueueSize;
    }

    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }

    public void send(byte[] data, int offset, int count) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(bos);
        if (count <= SINGLE_PACKET_DATALENGTH_MAX) {
            bos.reset();
            dos.writeShort(magic + version);
            dos.writeShort(0);
            dos.writeShort(0);
            dos.writeShort(count);
            dos.write(data, offset, count);
            sock.send(new DatagramPacket(bos.toByteArray(), 0, bos.size(),
                    serverAddress, port));
        } else {
            int sendOffset = 0;
            int maxSeq = count / MULTI_PACKET_DATALENGTH_MAX;
            UID uid = new UID();
            for (int i = 0; i <= maxSeq; i++) {
                bos.reset();
                dos.writeShort(magic + version);
                dos.writeShort(maxSeq);
                dos.writeShort(i);
                uid.write(dos);
                if (i != maxSeq) {
                    dos.writeShort(MULTI_PACKET_DATALENGTH_MAX);
                    dos.write(data, sendOffset, MULTI_PACKET_DATALENGTH_MAX);
                    sendOffset += MULTI_PACKET_DATALENGTH_MAX;
                } else {
                    dos.writeShort(count - sendOffset);
                    dos.write(data, sendOffset, count - sendOffset);
                }
                sock.send(new DatagramPacket(bos.toByteArray(), 0, bos.size(),
                        serverAddress, port));
            }
        }
    }

    public OMData receive() {
        while (true) {
            try {
                return receivedQueue.take();
            } catch (InterruptedException e) {

            } catch (NullPointerException e) {

            }
        }
    }

    public void processReceivedPacket(DatagramPacket packet) throws IOException {
        ByteArrayInputStream bis = new ByteArrayInputStream(packet.getData());
        DataInputStream dis = new DataInputStream(bis);
        int maxSeq;
        int seq;
        UID uid;
        int length;
        byte[] buf = new byte[maxPacketSize];
        String key;
        OMBlock block;
        if (dis.readShort() == (magic + version)) {
            maxSeq = dis.readShort();
            if (maxSeq == 0) {
                dis.readShort();
                length = dis.readShort();
                dis.read(buf, 0, length);
                try {
                    receivedQueue.put(new OMData(packet.getAddress(), buf, 0,
                            length));
                    LOG.fine("Add a OMData to receivedQueue.");
                } catch (InterruptedException e) {

                }
            } else if (maxSeq > 0) {
                seq = dis.readShort();
                uid = UID.read(dis);
                length = dis.readShort();
                dis.read(buf, 0, length);

                key = uid.toString();
                if (receivingBox.containsKey(key)) {
                    block = receivingBox.remove(key);
                    block.update(seq, buf, 0, length);
                    if (!block.isComplete()) {
                        receivingBox.put(key, block);
                    } else {
                        try {
                            receivedQueue.put(new OMData(block));
                            LOG.fine("Add a OMData to receivedQueue.");
                        } catch (InterruptedException e) {

                        }
                    }
                } else {
                    block = new OMBlock(maxSeq, uid, packet.getAddress());
                    block.update(seq, buf, 0, length);
                    receivingBox.put(block.getKey(), block);
                }
            } else {
                LOG.info("Minus maxSeq is not valid.");
                return;
            }
        } else {
            LOG.info("The packet contains a invalid migic or version.");
            return;
        }
    }

    public void run() {
        receivingBox = new ReceivingBox();
        receivingBox.setTimeout(this.timeout);
        receivedQueue = new ArrayBlockingQueue<OMData>(receivedQueueSize);

        byte[] buffer = new byte[maxPacketSize];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        while (running) {
            try {
                sock.receive(packet);
                processReceivedPacket(packet);
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Exception in WorkingThread.run().", e);
            }
        }
    }
}
