package vaquero.omchannel.util;

import java.net.InetAddress;
import java.rmi.server.UID;
public class OMBlock {
  OMPacket[] packets;
  int dataLength;
  UID uid;
  InetAddress address;
  int received;
  long lastUpdate;
  
  public OMBlock(int maxSeq, UID uid, InetAddress address) {
    this.packets = new OMPacket[maxSeq + 1];
    this.dataLength = 0;
    this.uid = uid;
    this.address = address;
    this.received = 0;
    this.lastUpdate = System.currentTimeMillis();
  }
  
  public String getKey() {
    return uid.toString();
  }
  
  public int update(int seq, byte[] data, int offset, int count) {
    this.packets[seq] = new OMPacket(data, offset, count);
    this.dataLength += count;
    this.received ++;
    this.lastUpdate = System.currentTimeMillis();
    return received;
  }
  
  public int getPacketsNum() {
    return this.packets.length;
  }
  
  public boolean isComplete() {
    if(received == getPacketsNum()) {
      return true;
    }
    return false;
  }
}
