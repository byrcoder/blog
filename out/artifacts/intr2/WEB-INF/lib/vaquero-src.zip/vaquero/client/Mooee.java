package vaquero.client;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mooee {
    
    private static final Logger LOG = Logger.getLogger(Mooee.class.getName());

    private Timer timer;
    private IMooCaster caster;
    
    private IMooable mooable;
    private long period;
    
    public static Mooee get(IMooable mooable, long period, String channel) 
            throws IOException {
        Mooee mooee = new Mooee(BasicMooCaster.get(),mooable,period);
        String[] addrs = channel.split(":");
        InetAddress addr = InetAddress.getByName(addrs[0]);
        int port = Integer.parseInt(addrs[1]);
        mooee.caster.init(addr,port);
        return mooee;
    }
    
    protected Mooee(IMooCaster caster, IMooable mooable, long period) {
        this.caster = caster;
        this.mooable = mooable;
        this.period = period;
    }
    
    /**
     * Whether it is mooing
     */
    public synchronized boolean isMooing() {
        return timer!=null;
    }
    
    /**
     * Starts timer if it is not already started
     */
    public synchronized void startMoo() {
        if (timer == null) {
            timer = new Timer();
            TimerTask task = new TimerTask() {
                public void run() {
                    try {
                        caster.moo(mooable.getMooNode());
                    } catch (IOException e) {
                        LOG.log(Level.WARNING, "Failed to moo this node", e);
                    }
                }
            };
            long millis = period;
            timer.schedule(task, millis, millis);
         }
    }

    /**
     * Stops timer if it is running
     */
    public synchronized void stopMoo() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

}
