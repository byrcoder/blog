package vaquero.client.tool;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import vaquero.Vaquero;
import vaquero.VaqueroConstants;
import vaquero.client.BasicMooCaster;
import vaquero.client.IMooCaster;

public class AnalyzerMooee implements VaqueroConstants {
    private static final Logger LOG = Logger.getLogger(AnalyzerMooee.class
            .getName());

    private static IMooCaster caster;
    static {
        caster = BasicMooCaster.get();
        LOG.info("Vaquero: caster geted.");
        try {
            caster.init(InetAddress.getByName(Vaquero.DEFAULT_SERVER_ADDR),
                    Vaquero.DEFAULT_SERVER_PORT);
            LOG.info("Vaquero: caster inited.");
        } catch (Exception e) {
            LOG
                    .log(
                            Level.WARNING,
                            "Vaquero: initialization of caster in AnalyzerMooee failed!",
                            e);

        }
    }

    private String cubType;

    private String cubName;

    private Document document;

    private ArrayList<Element> elements;

    public AnalyzerMooee(String cubType, String cubName) {
        this.cubType = cubType;
        this.cubName = cubName;
        try {
            document = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            LOG.log(Level.WARNING,
                    "Vaquero: Cannot create xml document correctly", e);
            return;
        }
        elements = new ArrayList<Element>();
        LOG.info("Vaquero: AnalyzerMooee for " + cubType + "-" + cubName
                + " created.");
    }

    public void addDraw(String drawName, int lev, String description) {
        Element element = document.createElement(MOO_TAG_ADD_DRAW);
        element.setAttribute(MOO_TAG_ADD_DRAW_ATTR_NAME, drawName);
        element.setAttribute(MOO_TAG_ADD_DRAW_ATTR_LEV, String.valueOf(lev));
        element.setAttribute(MOO_TAG_ADD_DRAW_ATTR_DES, description);
        elements.add(element);
        LOG.info("Vaquero: draw added, name: " + drawName + " lev: " + lev
                + " des: " + description);
    }

    public void removeDraw(String drawName) {
        Element element = document.createElement(MOO_TAG_RM_DRAW);
        element.setAttribute(MOO_TAG_RM_DRAW_ATTR_NAME, drawName);
        elements.add(element);
        LOG.info("Vaquero: draw removed, name: " + drawName);
    }

    public void addProp(String propName, String drawName) {
        Element element = document.createElement(MOO_TAG_ADD_PROP);
        element.setAttribute(MOO_TAG_ADD_PROP_ATTR_NAME, propName);
        element.setAttribute(MOO_TAG_ADD_PROP_ATTR_DRAW, drawName);
        elements.add(element);
        LOG.info("Vaquero: prop added, name: " + propName + " draw: "
                + drawName);
    }

    public void removeProp(String propName) {
        Element element = document.createElement(MOO_TAG_RM_PROP);
        element.setAttribute(MOO_TAG_RM_PROP_ATTR_NAME, propName);
        elements.add(element);
        LOG.info("Vaquero: prop removed, name: " + propName);
    }

    public void report(String propName, double value) {
        Element element = document.createElement(MOO_TAG_PROP);
        element.setAttribute(MOO_TAG_PROP_ATTR_NAME, propName);
        element.setAttribute(MOO_TAG_PROP_ATTR_VAL, String.valueOf(value));
        elements.add(element);
        LOG.info("Vaquero: prop reported, name: " + propName + " value: "
                + value);
    }

    public void moo() {
        Element main = document.createElement(MOO_TAG_MAIN);
        Element cub = document.createElement(MOO_TAG_CUB);
        cub.setAttribute(MOO_TAG_CUB_ATTR_TYPE, cubType);
        cub.setAttribute(MOO_TAG_CUB_ATTR_NAME, cubName);
        cub
                .setAttribute(MOO_TAG_CUB_ATTR_USER, System
                        .getProperty("user.name"));
        for (Element element: elements) {
            cub.appendChild(element);
        }
        main.appendChild(cub);
        try {
            caster.moo(main);
        } catch (IOException e) {
            LOG.log(Level.WARNING,
                    "Vaquero: Caught IOException when moo, cubType: " + cubType
                            + ", cubName: " + cubName, e);
        }
        LOG.info("Vaquero: data moo out.");
        elements.clear();
    }

}
