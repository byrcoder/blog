package vaquero.client;

import java.io.IOException;
import java.net.InetAddress;

import org.w3c.dom.Node;

public interface IMooCaster {

    /**
     * Prepare the caster.
     * @param addr address of the channel
     * @param port port of the channel 
     * @throws IOException
     */
    public void init(InetAddress addr, int port) throws IOException;
    
    /**
     * Send the information out to the shepherd.
     * @param node
     * @throws IOException
     */
    public void moo(Node mooNode) throws IOException;
    
    /**
     * Terminate the caster.
     * @throws IOException
     */
    public void destroy() throws IOException;
    
}
