package vaquero.client;

import org.w3c.dom.Node;

/**
 * The class whose instance can be moo-ed.
 * 
 * @author Li Zhuang (zl@cs.berkeley.edu, zl@rd.netease.com)
 *
 * Created on Jul 15, 2006
 * Copyright (c) 2006 Outfox Team
 */
public interface IMooable {

    public Node getMooNode();

}
