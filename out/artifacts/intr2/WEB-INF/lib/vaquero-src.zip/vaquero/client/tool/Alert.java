package vaquero.client.tool;

import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import vaquero.Vaquero;
import vaquero.VaqueroConstants;
import vaquero.client.BasicMooCaster;
import vaquero.client.IMooCaster;
import vaquero.client.IMooable;
import vaquero.herd.AlertCub;
import vaquero.herd.Cub;
import vaquero.util.VaqueroOpts;

public class Alert implements IMooable {

    private static final Logger LOG = Logger.getLogger(Alert.class.getName());

    private static final String CUB_TYPE = "alert";

    public static final String DEFAULT_NOTIFY_GROUP = "default";

    public static final String SPECIFIC_NOTIFY_GROUP = "specific";

    String alertId;

    String summary;

    String message;

    String notifyGroup;

    String specificAddr;

    public Alert(String alertId, String summary, String message) {
        this(alertId, summary, message, DEFAULT_NOTIFY_GROUP, null);
    }

    public Alert(String alertId, String summary, String message,
            String notifyGroup, String specificAddr) {
        this.alertId = alertId;
        this.summary = summary;
        this.message = message;
        this.notifyGroup = notifyGroup;
        this.specificAddr = specificAddr;
    }

    public Node getMooNode() {
        Document document;
        try {
            document = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            LOG.log(Level.WARNING, "Cannot create xml document correctly", e);
            return null;
        }

        Element mooNode = document.createElement("moo");

        Element oNode = document.createElement(VaqueroConstants.MOO_TAG_CUB);
        oNode
                .setAttribute(VaqueroConstants.MOO_TAG_CUB_ATTR_NAME, this.alertId);
        oNode.setAttribute(VaqueroConstants.MOO_TAG_CUB_ATTR_TYPE, CUB_TYPE);

        Element user = document.createElement(Cub.USER_TAG);
        user.setAttribute(Cub.USER_ATTR_NAME, System.getProperty("user.name"));
        oNode.appendChild(user);

        Element contentTag = document.createElement(AlertCub.CONTENT_TAG);
        Element prop = document.createElement(Cub.PROP_TAG);
        prop.setAttribute(Cub.PROP_ATTR_NAME, AlertCub.CONTENT_SUMMARY_TAG);
        prop.setAttribute(Cub.PROP_ATTR_VAL, summary);
        contentTag.appendChild(prop);
        prop = document.createElement(Cub.PROP_TAG);
        prop.setAttribute(Cub.PROP_ATTR_NAME, AlertCub.CONTENT_MESSAGE_TAG);
        prop.setAttribute(Cub.PROP_ATTR_VAL, message);
        contentTag.appendChild(prop);
        oNode.appendChild(contentTag);

        Element notifyGroupTag = document
                .createElement(AlertCub.NOTIFY_GROUP_TAG);
        notifyGroupTag.setAttribute(AlertCub.NOTIFY_GROUP_ATTR_NAME,
                notifyGroup);
        oNode.appendChild(notifyGroupTag);

        if (notifyGroup.equals(SPECIFIC_NOTIFY_GROUP)) {
            Element specificAddrTag = document
                    .createElement(AlertCub.SPECIFIC_ADDR_TAG);
            specificAddrTag.setAttribute(AlertCub.SPECIFIC_ADDR_ATTR_NAME,
                    specificAddr);
            oNode.appendChild(specificAddrTag);
        }

        mooNode.appendChild(oNode);

        return mooNode;
    }

    public static void alert(String alertId, String summary, String message,
            String notifyGroup, String specificAddr) {
        try {
            Alert alert = new Alert(alertId, summary, message, notifyGroup,
                    specificAddr);
            IMooCaster caster = BasicMooCaster.get();
            caster.init(InetAddress.getByName(Vaquero.DEFAULT_SERVER_ADDR),
                    Vaquero.DEFAULT_SERVER_PORT);
            caster.moo(alert.getMooNode());
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Vaquero: caught Exception when alert.", e);
        }
    }

    public static void usage() {
        System.out
                .println("Usage: alert -i alertId -s summary -m message [-g notifyGroup]");
    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        VaqueroOpts opts = new VaqueroOpts("g:m:i:s:a:", args);
        String alertId = opts.getOpt("i");
        String summary = opts.getOpt("s");
        String message = opts.getOpt("m");
        String notifyGroup = opts.getOpt("g", DEFAULT_NOTIFY_GROUP);
        String specificAddr = opts.getOpt("a");

        if (alertId == null || summary == null || message == null) {
            usage();
            return;
        }

        if (notifyGroup.equals(DEFAULT_NOTIFY_GROUP) && specificAddr != null) {
            notifyGroup = SPECIFIC_NOTIFY_GROUP;
        }
        alert(alertId, summary, message, notifyGroup, specificAddr);
    }

}
