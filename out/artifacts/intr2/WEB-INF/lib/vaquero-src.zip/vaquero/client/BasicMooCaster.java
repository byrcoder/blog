package vaquero.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Node;

import vaquero.omchannel.OMChannel;

/**
 * Transform a DOM Node to stream, and give the channel data to send.
 * 
 * @author yaming
 */
public class BasicMooCaster implements IMooCaster {

    private static final Logger LOG = Logger.getLogger(BasicMooCaster.class
            .getName());

    protected OMChannel channel;

    protected DirectByteArrayOutputStream output;

    protected int messageCount;

    private static final BasicMooCaster instance = new BasicMooCaster();

    private BasicMooCaster() {}

    public static BasicMooCaster get() {
        return instance;
    }

    public void init(InetAddress addr, int port) throws IOException {
        messageCount = 0;
        output = new DirectByteArrayOutputStream();
        this.channel = new OMChannel(addr, port, false);
    }

    public void destroy() throws IOException {
        synchronized (output) {
            if (messageCount > 0)
                send();
        }
    }

    public void moo(Node mooNode) throws IOException {
        synchronized (output) {
            accept(mooNode);
            if (messageCount > 0)
                send();
        }
    }

    /**
     * Reset the buffer and message count
     */
    protected void reset() {
        output.reset();
        messageCount = 0;
    }

    /**
     * Send out whatever now is in the buffer without any check. After send() is
     * called, all message in the buffer is lost even if the sending process was
     * failed.
     */
    protected void send() throws IOException {
        try {
            channel.send(output.getBuffer(), 0, output.getCount());
        } finally {
            reset();
        }
    }

    /**
     * Accept a new mooNode to the output buffer
     * 
     * @param mooNode
     *                node to be accepted
     */
    protected void accept(Node mooNode) {
        try {
            DOMSource source = new DOMSource(mooNode);
            StreamResult result = new StreamResult(output);
            Transformer transformer = TransformerFactory.newInstance()
                    .newTransformer();
            transformer.transform(source, result);
            messageCount++;
        } catch (TransformerConfigurationException e) {
            LOG.log(Level.SEVERE, "Cannot get transformer correctly", e);
        } catch (TransformerException e) {
            LOG.log(Level.WARNING, "Cannot transfer node correctly", e);
        }
    }

    public static class DirectByteArrayOutputStream extends
            ByteArrayOutputStream {

        public byte[] getBuffer() {
            return buf;
        }

        public int getCount() {
            return count;
        }

    }

}
