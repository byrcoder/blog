package vaquero.herd.patrol;

import vaquero.herd.Cub;

public interface IPatrol {
    
    /**
     * 
     * @param type
     */
    public void init(String type);
    
    /**
     *
     */
    public void patrol(Cub cub);
}
