package vaquero.herd;

import java.text.DateFormat;
import java.util.Date;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import vaquero.client.tool.Alert;
import vaquero.util.SendMail;

public class AlertCub extends Cub {

    private static final long DEFAULT_ALERT_PERIOD = 60 * 60 * 1000;

    public static final String CONTENT_TAG = "content";

    public static final String CONTENT_SUMMARY_TAG = "summary";

    public static final String CONTENT_MESSAGE_TAG = "message";

    public static final String NOTIFY_GROUP_TAG = "notifygroup";

    public static final String SPECIFIC_ADDR_TAG = "specificaddr";

    public static final String NOTIFY_GROUP_ATTR_NAME = "name";

    public static final String SPECIFIC_ADDR_ATTR_NAME = "name";

    public static DateFormat dateFormat = DateFormat.getDateTimeInstance(
            DateFormat.SHORT, DateFormat.SHORT);

    private long alertPeriod;

    private long lastAlertTime;

    private boolean alerted;

    private long lastReportTime;

    private int reportedTimes;

    private String summary;

    private String message;

    private String notifyGroup;

    private String mailAddrs[];

    public void init(String type, String id, RrdHolder rrdHolder) {
        super.init(type, id, rrdHolder);
        alertPeriod = DEFAULT_ALERT_PERIOD;
        lastAlertTime = -1;
        lastReportTime = -1;
        reportedTimes = 0;
    }

    public void update(Element element) {
        super.update(element);

        Element content = (Element) (xmlNode.getElementsByTagName(CONTENT_TAG)
                .item(0));
        NodeList contentList = content.getElementsByTagName(PROP_TAG);
        for (int i = 0; i < contentList.getLength(); i++) {
            Element node = (Element) (contentList.item(i));
            if (node.getAttribute(PROP_ATTR_NAME).equals(CONTENT_SUMMARY_TAG)) {
                this.summary = node.getAttribute(PROP_ATTR_VAL);
            } else if (node.getAttribute(PROP_ATTR_NAME).equals(
                    CONTENT_MESSAGE_TAG)) {
                this.message = node.getAttribute(PROP_ATTR_VAL);
            }
        }

        Element notifyNode = (Element) (xmlNode
                .getElementsByTagName(NOTIFY_GROUP_TAG).item(0));
        notifyGroup = notifyNode.getAttribute(NOTIFY_GROUP_ATTR_NAME);

        if (notifyGroup.equals(Alert.SPECIFIC_NOTIFY_GROUP)) {
            mailAddrs = new String[1];
            Element specificaddrNode = (Element) (xmlNode
                    .getElementsByTagName(SPECIFIC_ADDR_TAG).item(0));
            mailAddrs[0] = specificaddrNode
                    .getAttribute(SPECIFIC_ADDR_ATTR_NAME);
        } else {
            String[][] notifyGroupProps = config.getTagProps(type,
                    NOTIFY_GROUP_TAG);
            mailAddrs = null;
            for (int i = 0; i < notifyGroupProps.length; i++) {
                if (config.getTagAttr(type, i, NOTIFY_GROUP_TAG,
                        NOTIFY_GROUP_ATTR_NAME).equals(notifyGroup)) {
                    mailAddrs = new String[notifyGroupProps[i].length];
                    for (int j = 0; j < mailAddrs.length; j++) {
                        mailAddrs[j] = notifyGroupProps[i][j];
                    }
                }
            }
        }
        if (mailAddrs == null) {
            mailAddrs = new String[0];
        }

        lastReportTime = System.currentTimeMillis();
        checkAlert();
    }

    public void checkAlert() {
        if (alerted
                && (System.currentTimeMillis() - lastAlertTime) < alertPeriod) {
            reportedTimes++;
        } else {
            alert();
            reportedTimes = 0;
        }
    }

    public void alert() {
        DateFormat date = DateFormat.getDateTimeInstance(DateFormat.SHORT,
                DateFormat.MEDIUM);

        String subject = "[ALERT] " + summary + " -by " + user + " "
                + date.format(lastReportTime);
        String content = "\nSummary: " + summary + "\n\nMessage: " + message
                + "\n\nUser: " + user + "\n\nNotifyGroup: " + notifyGroup
                + "\n\nMail will send to: ";
        for (String mail: mailAddrs) {
            content = content + mail + ",";
        }
        if (alerted) {
            content = content + "\n\n\nthis is reported " + reportedTimes
                    + " times from last alert("
                    + dateFormat.format(new Date(lastAlertTime)) + ").";
        } else {
            content = content + "\n\n\nthis is first time it reported";
        }
        content = content + "\n\n\n--Alerted by vaquero.";
        SendMail.send(subject, content, mailAddrs);
        alerted = true;
        lastAlertTime = System.currentTimeMillis();
    }

    public String getDisplayHeadHtml() {
        DateFormat date = DateFormat.getDateTimeInstance(DateFormat.SHORT,
                DateFormat.MEDIUM);
        String head = "<font color=red>[ALERT] </font>" + summary + " - "
                + reportedTimes + " times since last alert out " + " by "
                + user + " -" + date.format(lastReportTime);
        return head;
    }

    public String getDisplayBodyHtml() {
        String body = "Summary: " + summary + "<br>Message: " + message
                + "<br>User: " + user + "<br>NotifyGroup: " + notifyGroup
                + "<br>";
        return body;
    }
}
