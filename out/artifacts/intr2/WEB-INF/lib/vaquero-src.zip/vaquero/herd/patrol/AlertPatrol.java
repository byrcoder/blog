package vaquero.herd.patrol;

import java.util.ArrayList;
import java.util.HashMap;

import vaquero.conf.VaqueroConfig;
import vaquero.herd.Cub;
import vaquero.util.SendMail;

public class AlertPatrol implements IPatrol {

    private static final long ALERT_PERIOD = 60 * 60 * 1000;

    private static final String TAG = "alert";

    private static final String ALERT_NAME = "name";

    private static final String YELLOW_THRESHOLD = "yellowthreshold";

    private static final String YELLOW_PERIOD = "yellowperiod";

    private static final String RED_THRESHOLD = "redthreshold";

    private static final String CONDITION = "condition";

    public HashMap<String, AlertCase> workSet = new HashMap<String, AlertCase>();

    public class AlertCase {

        public ArrayList<String> propNames;

        public double yellowThreshold;

        public double yellowPeriod;

        public boolean yellowFlag;

        public double redThreshold;

        public boolean alertFlag;

        public String condition;

        public long lastAlerted;

        public long lastChecked;

        public AlertCase(ArrayList<String> propNames, double yellowThreshold,
                double yellowPeriod, double redThreshold, String condition) {
            this.propNames = propNames;
            this.yellowThreshold = yellowThreshold;
            this.yellowPeriod = yellowPeriod;
            this.redThreshold = redThreshold;
            this.condition = condition;

            this.yellowFlag = false;
            this.alertFlag = false;
            this.lastAlerted = -1;
            this.lastChecked = -1;
        }

        public void check(Cub cub) {
            double value;
            long now = System.currentTimeMillis();
            for (String prop: propNames) {
                value = cub.getProp(prop);
                if (condition.equals("above")) {
                    if (value > redThreshold) {
                        alertFlag = true;
                    }
                }
                if (condition.equals("below")) {
                    if (value < redThreshold) {
                        alertFlag = true;
                    }
                }
                if (alertFlag == true && now - lastAlerted > ALERT_PERIOD) {
                    String subject = "[ALERT]" + cub.getId() + "-" + prop + " "
                            + condition + " " + redThreshold;
                    String content = cub.getId() + "-" + prop + " (current: "
                            + value + ") is " + condition + redThreshold;
                    SendMail.send(subject, content);
                    lastAlerted = now;
                }
                alertFlag = false;
            }
            lastChecked = now;
        }
    }

    public void init(String type) {
        VaqueroConfig config = VaqueroConfig.get();
        String[] tags = config.getTag(type, TAG);
        String[][] tagProps = config.getTagProps(type, TAG);
        ArrayList<String> propList;
        for (int i = 0; i < tags.length; i++) {
            propList = new ArrayList<String>();
            for (String prop: tagProps[i]) {
                propList.add(prop);
            }
            workSet.put(config.getTagAttr(type, i, TAG, ALERT_NAME),
                    new AlertCase(propList, config.getTagAttrDouble(type, i,
                            TAG, YELLOW_THRESHOLD), config.getTagAttrDouble(
                            type, i, TAG, YELLOW_PERIOD), config
                            .getTagAttrDouble(type, i, TAG, RED_THRESHOLD),
                            config.getTagAttr(type, i, TAG, CONDITION)));
        }

    }

    public void patrol(Cub cub) {
        for (String alertName: workSet.keySet()) {
            workSet.get(alertName).check(cub);
        }
        // TODO Auto-generated method stub

    }

    public void alert() {

    }

}
