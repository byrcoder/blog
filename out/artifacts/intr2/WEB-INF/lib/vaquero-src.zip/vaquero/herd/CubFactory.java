package vaquero.herd;

import java.util.logging.Level;
import java.util.logging.Logger;

import vaquero.conf.VaqueroConfig;

public class CubFactory {

    private static final long serialVersionUID = -1994012472294578528L;

    private static final Logger LOG = Logger.getLogger(CubFactory.class
            .getName());

    private VaqueroConfig config;

    public CubFactory() {
        config = VaqueroConfig.get();
    }

    public Cub createCub(String type) {
        String cls = config.getCubClass(type);
        if (cls == null) {
            return null;
        }
        Cub cub;
        try {
            cub = (Cub) (Class.forName(cls).newInstance());
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Cannot initialize cub (" + type + ":" + cls
                    + ")", e);
            return null;
        }
        return cub;
    }
}
