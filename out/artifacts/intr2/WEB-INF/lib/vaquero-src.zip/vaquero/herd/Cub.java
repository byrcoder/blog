package vaquero.herd;

import java.io.StringWriter;
import java.util.HashSet;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import vaquero.VaqueroConstants;
import vaquero.conf.VaqueroConfig;
import vaquero.herd.patrol.AlertPatrol;
import vaquero.herd.patrol.IPatrol;
import vaquero.server.Shepherd;
import vaquero.util.ValueFormatter;

/**
 * The monitorable interface, which is herded.
 * 
 * @author river, zl
 */
public class Cub implements VaqueroConstants {

    protected static Logger LOG = Logger.getLogger(Cub.class.getName());

    protected static ValueFormatter valueFormatter = new ValueFormatter();

    /**
     * <draw name="task" type="line"> <prop name="finished" value="..." /> <prop
     * name="running" value="..." /> </draw>
     */
    public static final String BASIC_TAG = "basic";

    public static final String BASIC_ATTR_NAME = "name";

    public static final String BASIC_ATTR_TYPE = "type";

    public static final String USER_TAG = "user";

    public static final String USER_ATTR_NAME = "name";

    public static final String DRAW_TAG = "draw";

    public static final String DRAW_ATTR_NAME = "name";

    public static final String DRAW_ATTR_TYPE = "type";

    public static final String DRAW_ATTR_LEV = "lev";

    public static final String DRAW_ATTR_DES = "des";

    public static final String PROP_TAG = "prop";

    public static final String PROP_ATTR_NAME = "name";

    public static final String PROP_ATTR_VAL = "value";

    public static final String PROP_ATTR_UNIT = "unit";

    public static final String PROP_ATTR_DATUM = "datum";

    public static final String INCLUDEBY_TAG = "includeby";

    public static final String INCLUDEBY_ATTR_NAME = "name";

    public static final String INCLUDEBY_ATTR_TYPE = "type";

    public static final String INCLUDEBY_ATTR_AS = "as";

    public static final String DRAW_TYPE_LINE = "line";

    public static final String DRAW_TYPE_AREASTACK = "areastack";

    public static final int DRAW_TYPE_LINE_IDX = 1;

    public static final int DRAW_TYPE_AREASTACK_IDX = 2;

    // interval for timer
    private long interval;

    // expire period
    private long expirePeriod;

    // timer to do something periodically
    private Timer timer;

    private RrdHolder rrdHolder;

    // data of rrd properties
    protected ConcurrentHashMap<String, Double> props; // properties to be

    protected Element xmlNode; // xml node to be rendered in browser

    protected String type;

    protected String name;

    protected String user;

    protected VaqueroConfig config;

    protected HashSet<IPatrol> patrolSet;

    // alive information
    protected long createTime; // create time

    protected long lastUpTime; // last update time

    public static String getId(String type, String name) {
        return type + "-" + name;
    }

    public String getId() {
        return type + "-" + name;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String toString() {
        return type + "-" + name;
    }

    /**
     * return a value according to the given rrd property name
     * 
     * @param propName
     * @return
     */
    public double getProp(String propName) {
        return props.get(propName);
    }

    public void setprop(String propName, double value) {
        props.put(propName, value);
    }

    /**
     * Initialize rrd database and rrd properties
     * 
     * @param name
     *                the name of this Cub
     * @param xsl
     *                the xsl file name of this Cub
     * @param draws
     *                the properties to be saved in rrd and drawn
     */
    public void init(String type, String name, RrdHolder rrdHolder) {
        this.type = type;
        this.name = name;
        this.rrdHolder = rrdHolder;
        this.config = VaqueroConfig.get();
        this.user = "";

        // init interval
        interval = config.getInterval(type);
        // init expire period
        expirePeriod = config.getExpirePeriod(type);

        props = new ConcurrentHashMap<String, Double>();

        initPatrol();
        startPatrol();
    }

    public void initPatrol() { // FIXME: not a common way
        IPatrol patrol;
        patrolSet = new HashSet<IPatrol>();
        if (config.getTag(type, "alert").length != 0) {
            patrol = new AlertPatrol();
            patrol.init(type);
            patrolSet.add(patrol);
        }
    }

    public synchronized void update(Element element) {
        // update xmlNode
        this.xmlNode = element;

        user = element.getAttribute(MOO_TAG_CUB_ATTR_USER);

        // perform add and remove
        NodeList addDraws = element.getElementsByTagName(MOO_TAG_ADD_DRAW);
        for (int i = 0; i < addDraws.getLength(); i++) {
            Element elm = (Element) addDraws.item(i);
            rrdHolder.addDraw(elm.getAttribute(MOO_TAG_ADD_DRAW_ATTR_NAME), elm
                    .getAttribute(MOO_TAG_ADD_DRAW_ATTR_LEV), elm
                    .getAttribute(MOO_TAG_ADD_DRAW_ATTR_DES));
        }
        NodeList rmDraws = element.getElementsByTagName(MOO_TAG_RM_DRAW);
        for (int i = 0; i < rmDraws.getLength(); i++) {
            Element elm = (Element) rmDraws.item(i);
            rrdHolder.removeDraw(elm.getAttribute(MOO_TAG_RM_DRAW_ATTR_NAME));
        }
        NodeList addProps = element.getElementsByTagName(MOO_TAG_ADD_PROP);
        for (int i = 0; i < addProps.getLength(); i++) {
            Element elm = (Element) addProps.item(i);
            rrdHolder.addProp(elm.getAttribute(MOO_TAG_ADD_PROP_ATTR_NAME), elm
                    .getAttribute(MOO_TAG_ADD_PROP_ATTR_DRAW));
        }
        NodeList rmProps = element.getElementsByTagName(MOO_TAG_RM_PROP);
        for (int i = 0; i < rmProps.getLength(); i++) {
            Element elm = (Element) rmProps.item(i);
            rrdHolder.removeProp(elm.getAttribute(MOO_TAG_RM_PROP_ATTR_NAME));
        }
        // perform prop update
        NodeList props = element.getElementsByTagName(MOO_TAG_PROP);
        for (int i = 0; i < props.getLength(); i++) {
            Element elm = (Element) props.item(i);
            this.props.put(elm.getAttribute(MOO_TAG_PROP_ATTR_NAME), Double
                    .valueOf(elm.getAttribute(MOO_TAG_PROP_ATTR_VAL)));
        }
        lastUpTime = System.currentTimeMillis();
    }

    public Comparable getSortKey(String name) {
        if (name.equals("id") || name.equals("name")) {
            return getId();
        }
        if (name.equals("user")) {
            return user;
        }
        if (name.equals("createTime")) {
            return createTime;
        }
        if (name.equals("lastUpTime")) {
            return lastUpTime;
        }
        return props.get(name);
    }

    public String getDetailXml() {
        StreamResult result = new StreamResult(new StringWriter());
        try {
            DOMSource source = new DOMSource(xmlNode);
            Transformer transformer = TransformerFactory.newInstance()
                    .newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
                    "yes");
            transformer.transform(source, result);
        } catch (TransformerConfigurationException e) {
            LOG.log(Level.SEVERE, "Cannot get transformer correctly", e);
            return null;
        } catch (TransformerException e) {
            LOG.log(Level.WARNING, "Cannot transfer node correctly", e);
            return null;
        }
        return result.getWriter().toString();
    }

    // public String getDetailHtml() {
    // // drawGraphs(Shepherd.get().getHerd().getWebImageRoot(), "hour"); //
    // // FIXME: test only
    // StreamResult result = new StreamResult(new StringWriter());
    // try {
    // DOMSource source = new DOMSource(xmlNode);
    // Transformer transformer = TransformerFactory.newInstance()
    // .newTransformer(
    // new StreamSource(new File(Shepherd.get().getHerd()
    // .getXslRoot(), this.getXslName())));
    // transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
    // "yes");
    // transformer.transform(source, result);
    // } catch (TransformerConfigurationException e) {
    // LOG.log(Level.SEVERE, "Cannot get transformer correctly", e);
    // return null;
    // } catch (TransformerException e) {
    // LOG.log(Level.WARNING, "Cannot transfer node correctly", e);
    // return null;
    // }
    // return result.getWriter().toString();
    // }

    public boolean isExpired() {
        return System.currentTimeMillis() - lastUpTime > expirePeriod;
    }

    public void expire() {
        stopPatrol();
        Shepherd.get().getHerd().expireCub(type, name);
    }

    private void patrol() {
        for (IPatrol patrol: patrolSet) {
            patrol.patrol(this);
        }
        if (props.size() > 0) {
            rrdHolder.update(name, props, this.lastUpTime / 1000);
            props.clear();
        }
        if (isExpired()) {
            expire();
        }
    }

    /**
     * Starts timer if it is not already started
     */
    public synchronized void startPatrol() {
        if (timer == null) {
            timer = new Timer();
            TimerTask task = new TimerTask() {
                public void run() {
                    patrol();
                }
            };
            timer.scheduleAtFixedRate(task, interval, interval);
        }
    }

    public synchronized void stopPatrol() {
        if (timer == null) {
            return;
        } else {
            timer.cancel();
        }
    }

}
