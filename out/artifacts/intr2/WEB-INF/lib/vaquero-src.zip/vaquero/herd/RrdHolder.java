package vaquero.herd;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import org.jrobin.core.DsDef;
import org.jrobin.core.FetchData;
import org.jrobin.core.FetchRequest;
import org.jrobin.core.RrdDb;
import org.jrobin.core.RrdDef;
import org.jrobin.core.RrdException;
import org.jrobin.core.RrdToolkit;
import org.jrobin.core.Sample;
import org.jrobin.graph.RrdGraph;
import org.jrobin.graph.RrdGraphDef;
import org.jrobin.graph.RrdGraphInfo;

import vaquero.conf.VaqueroConfig;

public class RrdHolder {
    private static Logger LOG = Logger.getLogger(RrdHolder.class.getName());

    private static final Pattern PROP_NAME_PATTERN = Pattern
            .compile("[\\w\\-\\#\\$\\&\\=\\+\\.\\_]+");

    public static Color BOARDER_COLOR = new Color(195, 217, 255);

    public static Color BACKGROUND_LEVEL_1 = new Color(245, 245, 245);

    public static Color BACKGROUND_LEVEL_2 = new Color(181, 237, 188);

    public static Color BACKGROUND_LEVEL_3 = new Color(255, 222, 94);

    public static Color BACKGROUND_LEVEL_4 = new Color(255, 161, 94);

    public static Color BACKGROUND_LEVEL_5 = new Color(255, 99, 79);

    public static double DATUM_RATIO_LEVEL_1 = 0.1;

    public static double DATUM_RATIO_LEVEL_2 = 0.3;

    public static double DATUM_RATIO_LEVEL_3 = 0.6;

    public static double DATUM_RATIO_LEVEL_4 = 1;

    private static final long RRD_STEP = 1;

    private static final long RRD_HEARTBEAT = 600;

    public static HashMap<String, Long> periodMap = new HashMap<String, Long>();
    {
        periodMap.put("hour", 60 * 60l);
        periodMap.put("day", 24 * 60 * 60l);
        periodMap.put("week", 7 * 24 * 60 * 60l);
        periodMap.put("month", 30 * 7 * 24 * 60 * 60l);
    }

    private static Random random = new Random();

    private String cubType;

    private File rrdDir;

    private File imgDir;

    private ConcurrentHashMap<String, RrdDb> rrds;

    private ConcurrentHashMap<String, HashSet<String>> drawMap;

    private ConcurrentHashMap<String, Integer> drawLevMap;

    private ConcurrentHashMap<String, String> drawDesMap;

    private ConcurrentHashMap<String, String> dataSources;

    private VaqueroConfig config;

    public RrdHolder(String cubType, File rrdRoot, File imgRoot) {
        this.cubType = cubType;
        rrdDir = new File(rrdRoot, cubType);
        imgDir = imgRoot;
        if (!rrdDir.exists()) {
            rrdDir.mkdirs();
        }
        rrds = new ConcurrentHashMap<String, RrdDb>();
        this.config = VaqueroConfig.get();
        initFromConfig();
    }

    private void initFromConfig() {
        String[] drawNames = config.getTag(cubType, Cub.DRAW_TAG);
        String[] drawLevs = config.getTagAttrs(cubType, Cub.DRAW_TAG,
                Cub.DRAW_ATTR_LEV);
        String[] drawDess = config.getTagAttrs(cubType, Cub.DRAW_TAG,
                Cub.DRAW_ATTR_DES);
        String[][] drawProps = config.getTagProps(cubType, Cub.DRAW_TAG);
        drawMap = new ConcurrentHashMap<String, HashSet<String>>();
        drawLevMap = new ConcurrentHashMap<String, Integer>();
        drawDesMap = new ConcurrentHashMap<String, String>();
        dataSources = new ConcurrentHashMap<String, String>();
        for (int draw = 0; draw < drawProps.length; draw++) {
            drawMap.put(drawNames[draw], new HashSet<String>());
            drawLevMap.put(drawNames[draw], Integer.valueOf(drawLevs[draw]));
            drawDesMap.put(drawNames[draw], drawDess[draw]);
            for (int prop = 0; prop < drawProps[draw].length; prop++) {
                dataSources.put(drawProps[draw][prop], drawNames[draw]);
                drawMap.get(drawNames[draw]).add(drawProps[draw][prop]);
            }
        }

    }

    private void addCub(String cubName) throws RrdException, IOException {
        File rrdFile = new File(rrdDir, cubName);
        RrdDb rrdDb;
        if (rrdFile.exists()) {
            rrdDb = new RrdDb(rrdFile.getPath());
        } else {
            RrdDef rrdDef = new RrdDef(rrdFile.getPath(), RRD_STEP);
            for (String dsName: dataSources.keySet()) {
                rrdDef.addDatasource(dsName, "GAUGE", RRD_HEARTBEAT, 0,
                        Double.NaN);
            }
            rrdDef.addArchive("AVERAGE", 0.5, 60, 600); // avg archive for
            // 1hour
            rrdDef.addArchive("AVERAGE", 0.5, 480, 600); // avg archive for
            // 8hour
            rrdDef.addArchive("AVERAGE", 0.5, 1440, 600); // avg archive for
            // 1day
            rrdDef.addArchive("AVERAGE", 0.5, 10080, 600); // avg archive for
            // 1week
            rrdDef.addArchive("AVERAGE", 0.5, 43200, 600); // avg archive for
            // 1mon
            rrdDb = new RrdDb(rrdDef);
        }
        rrds.put(cubName, rrdDb);
    }

    public void expireCub(String cubName) {
        RrdDb rrdDb = rrds.remove(cubName);
        if (rrdDb != null) {
            try {
                rrdDb.close();
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Caught IOException when expiring cub: "
                        + cubType + "-" + cubName, e);
            }
            File rrdFile = new File(rrdDir, cubName);
            rrdFile.delete();
        }
    }

    public String getCubType() {
        return cubType;
    }

    public void update(String cubName, ConcurrentHashMap<String, Double> props,
            long time) {
        if (!rrds.containsKey(cubName)) {
            try {
                addCub(cubName);
            } catch (Exception e) {
                LOG.log(Level.SEVERE, "Cannot initialize rrd for cub: "
                        + cubType + "-" + cubName, e);
                return;
            }
        }
        RrdDb rrdDb = rrds.get(cubName);
        synchronized (rrdDb) {
            try {
                Sample sample = rrdDb.createSample(time);
                for (String key: props.keySet()) {
                    if (dataSources.containsKey(key)) {
                        Double value = props.get(key);
                        sample.setValue(key, value);
                    } else {
                        LOG.log(Level.WARNING, "Not a valid datasource: " + key
                                + " when update for cub: " + cubType + "-"
                                + cubName);
                    }
                }
                sample.update();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Fail to update cub: " + cubType + "-"
                        + cubName + " at time: " + time, e);
            }
        }
    }

    private void addDataSource(String cubName, String dsName)
            throws RrdException, IOException {
        RrdDb rrdDb = rrds.get(cubName);
        synchronized (rrdDb) {
            String path = rrdDb.getPath();
            rrdDb.close();
            RrdToolkit.addDatasource(path, new DsDef(dsName, "GAUGE",
                    RRD_HEARTBEAT, 0, Double.NaN), false);
            rrds.put(cubName, new RrdDb(path));
        }
    }

    public void addDraw(String drawName, String lev, String description) {
        if (description == null || description.equals("")) {
            description = "NO DESCRIPTION";
        }
        
        synchronized (drawMap) {
            if (!drawMap.containsKey(drawName)) {
                drawMap.put(drawName, new HashSet<String>());
                this.config.addDraw(cubType, drawName, lev, description);
            }
            drawLevMap.put(drawName, Integer.valueOf(lev));
            drawDesMap.put(drawName, description);
        }
    }

    public void removeDraw(String drawName) {
        synchronized (drawMap) {
            if (!drawMap.containsKey(drawName)) {
                return;
            }
            HashSet<String> props = drawMap.get(drawName);
            drawMap.remove(drawName);
            drawLevMap.remove(drawName);
            drawDesMap.remove(drawName);
            this.config.removeDraw(cubType, drawName);
            for (String prop: props) {
                removeProp(prop);
            }
        }
    }

    public void addProp(String prop, String drawName) {
        if (!PROP_NAME_PATTERN.matcher(prop).matches() || prop.length() > 64) {
            LOG.log(Level.WARNING, "Invalid prop name: " + prop
                    + " at cubType:" + cubType);
            return;
        }
        synchronized (dataSources) {
            if (!drawMap.containsKey(drawName) || dataSources.containsKey(prop)) {
                return;
            }
            for (String cubName: rrds.keySet()) {
                try {
                    addDataSource(cubName, prop);
                } catch (Exception e) {
                    LOG.log(Level.SEVERE, "Failure when add datasource: "
                            + prop + " to cub: " + cubType + "-" + cubName);
                }
            }
            dataSources.put(prop, drawName);
            drawMap.get(drawName).add(prop);
            this.config.addProp(cubType, prop, drawName);
        }
    }

    private void removeDataSource(String cubName, String dsName)
            throws RrdException, IOException {
        RrdDb rrdDb = rrds.get(cubName);
        synchronized (rrdDb) {
            String path = rrdDb.getPath();
            rrdDb.close();
            RrdToolkit.removeDatasource(path, dsName, false);
            rrds.put(cubName, new RrdDb(path));
        }
    }

    public void removeProp(String prop) {
        synchronized (dataSources) {
            if (!dataSources.containsKey(prop)) {
                return;
            }
            String drawName = dataSources.get(prop);
            dataSources.remove(prop);
            if (drawName != null) {
                drawMap.get(drawName).remove(prop);
                this.config.removeProp(cubType, prop, drawName);
            }
            for (String cubName: rrds.keySet()) {
                try {
                    removeDataSource(cubName, prop);
                } catch (Exception e) {
                    LOG.log(Level.SEVERE, "Failure when remove datasource: "
                            + prop + " to cub: " + cubType + "-" + cubName);
                }
            }
        }
    }

    public void removeAllProps() {

    }

    public byte[] getGraph(String cubName, String drawName) {
        return null; // FIXME
    }

    private File constructImgFile(String cubName, String drawName,
            String periodS) {
        File graphFile = new File(imgDir, cubType + "-" + cubName + "-"
                + drawName + "-" + periodS + random.nextInt() + ".PNG");
        return graphFile;
    }

    public RrdGraphInfo drawLineGraph(String cubName, String drawName,
            String periodS) {
        try {
            RrdDb rrdDb = rrds.get(cubName);
            if (rrdDb == null) {
                return null;
            }
            String[] drawProps = new String[drawMap.get(drawName).size()];
            drawMap.get(drawName).toArray(drawProps);
            long lastUpTime = rrdDb.getLastUpdateTime();
            long period = periodMap.get(periodS);
            RrdGraphDef graphDef = new RrdGraphDef();
            graphDef.setShowSignature(false);
            for (int i = 0; (i < drawProps.length) && (i < 6); i++) {
                graphDef.datasource(drawProps[i], rrdDb.getPath(),
                        drawProps[i], "AVERAGE");
                graphDef.line(drawProps[i], new Color((i + 1) % 2 * 255,
                        ((i + 1) / 4) % 2 * 255, ((i + 1) / 2) % 2 * 255),
                        drawProps[i], 2);
                String unit = config.getRrdPropUnit(cubType, drawProps[i]);
                if (unit != null) {
                    graphDef.comment("(" + unit + ")");
                }
                graphDef.gprint(drawProps[i], "LAST", "last=%5.3f");
                graphDef.gprint(drawProps[i], "AVERAGE", "avg=%5.3f");
                graphDef.gprint(drawProps[i], "MAX", "max=%5.3f\\l");
            }

            graphDef.setStartTime(lastUpTime - period);
            graphDef.setEndTime(lastUpTime - 60);
            File imgFile = constructImgFile(cubName, drawName, periodS);
            graphDef.setFilename(imgFile.getPath());
            graphDef.setHeight(80);
            graphDef.setWidth(250);
            synchronized (rrdDb) {
                RrdGraph graph = new RrdGraph(graphDef);
                return graph.getRrdGraphInfo();
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Fail to create graph for " + drawName + "@"
                    + cubType + "-" + cubName, e);
            return null;
        }
    }

    public TreeMap<String, RrdGraphInfo> drawAllCubLineGraphs(String drawName,
            String period) {
        TreeMap<String, RrdGraphInfo> result = new TreeMap<String, RrdGraphInfo>();
        for (String cubName: rrds.keySet()) {
            result.put(cubName, drawLineGraph(cubName, drawName, period));
        }
        return result;
    }

    public TreeMap<String, RrdGraphInfo> drawOneCubAllLineGraphs(
            String cubName, String period) {
        TreeMap<String, RrdGraphInfo> result = new TreeMap<String, RrdGraphInfo>();
        if (rrds.containsKey(cubName)) {
            for (String drawName: drawMap.keySet()) {
                result.put(drawName, drawLineGraph(cubName, drawName, period));
            }
        }
        return result;
    }

    public FetchData getCubFetchData(String cubName, String periodS) {
        RrdDb rrdDb = rrds.get(cubName);
        if (rrds == null) {
            return null;
        }
        try {
            long lastUpTime = rrdDb.getLastUpdateTime() - 60;
            long period = periodMap.get(periodS);
            FetchRequest request = rrdDb.createFetchRequest("AVERAGE",
                    lastUpTime - period, lastUpTime);
            synchronized (rrdDb) {
                return request.fetchData();
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Caught Exception when fetch data for cub: "
                    + cubType + "-" + cubName, e);
            return null;
        }
    }

    public HashSet<String> getDsNameByDrawName(String drawName) {
        return drawMap.get(drawName);
    }
}
