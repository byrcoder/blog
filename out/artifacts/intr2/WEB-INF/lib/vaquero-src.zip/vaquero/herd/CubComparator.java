package vaquero.herd;

import java.util.Comparator;

import vaquero.server.Shepherd;

public class CubComparator implements Comparator {
    String sortKeyProp;

    Cub o1Cub;

    Cub o2Cub;

    Comparable o1KeyD;

    Comparable o2KeyD;

    Herd herd = Shepherd.get().getHerd();

    public CubComparator(String sortKeyProp) {
        this.sortKeyProp = sortKeyProp;
    }

    @SuppressWarnings("unchecked")
    public int compare(Object o1, Object o2) {
        if (this.sortKeyProp.equals("id")) {
            return ((String) o1).compareTo((String) o2);
        } else {
            o1Cub = herd.findCub((String) o1);
            o2Cub = herd.findCub((String) o2);
            if (o1Cub == null) {
                return -1;
            } else {
                o1KeyD = o1Cub.getSortKey(this.sortKeyProp);
            }
            if (o2Cub == null) {
                return 1;
            } else {
                o2KeyD = o2Cub.getSortKey(this.sortKeyProp);
            }
            if (o1KeyD == null || o2KeyD == null) {
                return ((String) o1).compareTo((String) o2);
            }
            if (o1KeyD instanceof Number) {
                return o2KeyD.compareTo(o1KeyD);
            }
            return o1KeyD.compareTo(o2KeyD);
        }
    }

}
