package vaquero.herd;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeSet;

import org.apache.commons.configuration.ConfigurationException;

import vaquero.conf.VaqueroConfig;

public class Herd {

    private static final String WEB_DIR = "web";

    private static final String IMG_DIR = "img";

    private static final String RRD_DIR = "rrd";
    
    private static final String SBS_DIR = "sbs";

    private static final long IMAGE_FILE_EXPIRE_PERIOD = 3 * 60 * 1000;

    private static final long IMAGE_FILE_CLEAN_INTERVAL = 5 * 60 * 1000;

    private Timer timer;

    private File root; // rrd

    private CubFactory cubFactory;

    private VaqueroConfig config;

    private HashMap<String, Cub> IdToCub;

    private HashMap<String, ArrayList<String>> typeToCubIds;
    
    private HashMap<String, TreeSet<String>> typeToCubNames;

    private HashMap<String, RrdHolder> rrdHolders;

    public Herd(File root) throws IOException, ConfigurationException {
        this.root = root;
        this.cubFactory = new CubFactory();
        config = VaqueroConfig.get();
        IdToCub = new HashMap<String, Cub>();
        typeToCubIds = new HashMap<String, ArrayList<String>>();
        typeToCubNames = new HashMap<String, TreeSet<String>>();
        startImageClean();
        rrdHolders = new HashMap<String, RrdHolder>();
        for(String cubType : config.getTypes()) {
            rrdHolders.put(cubType, new RrdHolder(cubType, getRrdRoot(), getWebImageRoot()));
        }
    }

    public File getWebRoot() {
        return new File(root, WEB_DIR);
    }

    public File getWebImageRoot() {
        return new File(getWebRoot(), IMG_DIR);
    }

    public File getRrdRoot() {
        return new File(root, RRD_DIR);
    }
    
    public File getSubscriptionRoot() {
        return new File(root, SBS_DIR);
    }

    public Cub getCub(String type, String name) {
        String id = Cub.getId(type, name);
        Cub cub = IdToCub.get(id);
        if (cub != null)
            return cub;
        synchronized (config) {
            cub = cubFactory.createCub(type);
            if (cub == null)
                return null;
            cub.init(type, name, getRrdHolder(type));
            IdToCub.put(id, cub);
            ArrayList<String> cubs = typeToCubIds.get(type);
            if (cubs == null) {
                cubs = new ArrayList<String>();
            }
            cubs.add(cub.getId());
            typeToCubIds.put(type, cubs);
            TreeSet<String> cubnames = typeToCubNames.get(type);
            if(cubnames == null) {
                cubnames = new TreeSet<String>();
            }
            cubnames.add(name);
            typeToCubNames.put(type, cubnames);
            return cub;
        }
    }

    public Cub findCub(String id) {
        return IdToCub.get(id);
    }

    public String[] findCubs(String type) {
        ArrayList<String> cubs = typeToCubIds.get(type);
        if (cubs == null) {
            return new String[0];
        }
        String[] res = new String[cubs.size()];
        typeToCubIds.get(type).toArray(res);
        return res;
    }
    
    public TreeSet<String> getCubNames(String type) {
        return typeToCubNames.get(type);
    }

    public RrdHolder getRrdHolder(String type) {
        return rrdHolders.get(type);
    }

    public String[] getCubsHtmlByType(String type) {
        String[] res = findCubs(type);
        for (int i = 0; i < res.length; i++) {
            res[i] = findCub(res[i]).toString();
        }
        return res;
    }

    public String[] getCubsHtmlByType(String type, String sortKeyProp) {
        String[] res = findCubs(type);
        for (int i = 0; i < res.length; i++) {
            res[i] = findCub(res[i]).toString();
        }
        return res;
    }

    public void expireCub(String type, String name) {
        rrdHolders.get(type).expireCub(name);
        String cubId = Cub.getId(type, name);
        IdToCub.remove(cubId);
        ArrayList<String> cubs = typeToCubIds.get(type);
        cubs.remove(cubId);
        typeToCubIds.put(type, cubs);
        typeToCubNames.get(type).remove(name);
    }

    public String[] getTypes() {
        return VaqueroConfig.get().getTypes();
    }

    public CubFactory getCubFactory() {
        return this.cubFactory;
    }

    public void imageClean() {
        File[] imageFiles = getWebImageRoot().listFiles();
        long now = System.currentTimeMillis();
        for (File file: imageFiles) {
            if (now - file.lastModified() > IMAGE_FILE_EXPIRE_PERIOD) {
                file.delete();
            }
        }
    }

    public synchronized void startImageClean() {
        if (timer == null) {
            timer = new Timer();
            TimerTask task = new TimerTask() {
                public void run() {
                    imageClean();
                }
            };
            timer.scheduleAtFixedRate(task, IMAGE_FILE_CLEAN_INTERVAL,
                    IMAGE_FILE_CLEAN_INTERVAL);
        }
    }
}
