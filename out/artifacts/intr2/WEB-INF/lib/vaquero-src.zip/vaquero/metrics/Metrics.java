package vaquero.metrics;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utility class to simplify creation and reporting of hadoop metrics. For
 * examples of usage, see {@link org.apache.hadoop.dfs.DataNode}.
 * 
 * @see vaquero.metrics.MetricsRecord
 * @see vaquero.metrics.MetricsContext
 * @see vaquero.metrics.ContextFactory
 * @author Milind Bhandarkar
 */
public class Metrics {
    private static final Logger LOG = Logger.getLogger(Metrics.class.getName());

    /**
     * Don't allow creation of a new instance of Metrics
     */
    private Metrics() {}

    /**
     * Utility method to create and return a new tagged metrics record instance
     * within the given <code>contextName</code>. If exception is thrown
     * while creating the record for any reason, it is logged, and a null record
     * is returned.
     * 
     * @param contextName
     *            name of the context
     * @param recordName
     *            the name of the record
     * @param tagName
     *            name of the tag field of metrics record
     * @param tagValue
     *            value of the tag field
     * @return newly created metrics record
     */
    public static MetricsRecord createRecord(String contextName,
            String recordName, String tagName, String tagValue) {
        LOG.info("Vaquero: Creating record: " + contextName + "." + recordName
                + "." + tagName + "=" + tagValue);
        try {
            MetricsContext metricsContext = ContextFactory.getFactory()
                    .getContext(contextName);
            if (!metricsContext.isMonitoring()) {
                metricsContext.startMonitoring();
            }
            MetricsRecord metricsRecord = metricsContext
                    .createRecord(recordName);
            metricsRecord.setTag(tagName, tagValue);
            LOG.info("Vaquero: Record " + contextName + "." + recordName + "."
                    + tagName + "=" + tagValue + " created.");
            return metricsRecord;
        } catch (Throwable ex) {
            LOG.log(Level.WARNING,
                    "Could not create metrics record with context:"
                            + contextName, ex);
            return null;
        }
    }

    /**
     * Utility method to create and return new metrics record instance within
     * the given <code>contextName</code>. This record is tagged with
     * hostname. If exception is thrown while creating the record due to any
     * reason, it is logged, and a null record is returned.
     * 
     * @param contextName
     *            name of the context
     * @param recordName
     *            name of the record
     * @return newly created metrics record
     */
    public static MetricsRecord createRecord(String contextName,
            String recordName) {
        String hostname = null;
        try {
            hostname = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException ex) {
            LOG.log(Level.INFO, "Cannot get hostname", ex);
            hostname = "unknown";
        }
        return createRecord(contextName, recordName, "hostname", hostname);
    }

    /**
     * Sets the named metric to the specified value in the given metrics record.
     * Updates the table of buffered data which is to be sent periodically.
     * 
     * @param record
     *            record for which the metric is updated
     * @param metricName
     *            name of the metric
     * @param metricValue
     *            new value of the metric
     */
    public static void report(MetricsRecord record, String metricName,
            long metricValue) {
        LOG.fine("Vaquero: Reporting " + metricName + "=" + metricValue
                + " to record" + record.getRecordName());
        if (record != null) {
            record.setMetric(metricName, metricValue);
            record.update();
        }
        LOG.fine("Vaquero: " + metricName + "=" + metricValue
                + " reported to record" + record.getRecordName());
    }

    public static void report(MetricsRecord record, String metricName,
            float metricValue) {
        LOG.fine("Reporting " + metricName + "=" + metricValue + " to record"
                + record.getRecordName());
        if (record != null) {
            record.setMetric(metricName, metricValue);
            record.update();
        }
        LOG.fine("Vaquero: " + metricName + "=" + metricValue
                + " reported to record" + record.getRecordName());
    }

    /**
     * Sets a tag in the given metrics record. updates the record.
     * 
     * @param record
     *            record for which the tag is set
     * @param tagName
     *            name of the tag
     * @param tagValue
     *            value of the tag
     */
    public static void setTag(MetricsRecord record, String tagName,
            String tagValue) {
        if (record != null) {
            record.setTag(tagName, tagValue);
            record.update();
        }
    }
}
