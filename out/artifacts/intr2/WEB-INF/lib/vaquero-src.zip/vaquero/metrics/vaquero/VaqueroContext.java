package vaquero.metrics.vaquero;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import vaquero.Vaquero;
import vaquero.VaqueroConstants;
import vaquero.client.BasicMooCaster;
import vaquero.client.IMooCaster;
import vaquero.herd.Cub;
import vaquero.metrics.ContextFactory;
import vaquero.metrics.MetricsException;
import vaquero.metrics.spi.AbstractMetricsContext;
import vaquero.metrics.spi.OutputRecord;

public class VaqueroContext extends AbstractMetricsContext {
    private static final Logger LOG = Logger.getLogger(VaqueroContext.class
            .getName());

    private static final String CHANNEL_PROPERTY = "channel";

    private static final String PERIOD_PROPERTY = "period";

    private static final String TAG_ID = "id";

    private IMooCaster caster;

    public VaqueroContext() {

    }

    public void init(String contextName, ContextFactory factory) {
        super.init(contextName, factory);

        LOG.info("Vaquero: enter VaqueroContext.init");

        String periodStr = getAttribute(PERIOD_PROPERTY);
        if (periodStr != null) {
            int period = 0;
            try {
                period = Integer.parseInt(periodStr.trim());
            } catch (NumberFormatException nfe) {}
            if (period <= 0) {
                throw new MetricsException("Invalid period: " + periodStr);
            }
            setPeriod(period);
            LOG.info("Vaquero: set period to " + period + "s");
        }

        this.caster = BasicMooCaster.get();
        LOG.info("Vaquero: caster geted.");
        try {
            String addr = this.getAttribute(CHANNEL_PROPERTY);
            LOG.info("Vaquero: get Channel: " + addr);
            if (addr == null) {
                this.caster.init(InetAddress
                        .getByName(Vaquero.DEFAULT_SERVER_ADDR),
                        Vaquero.DEFAULT_SERVER_PORT);
                LOG.info("Vaquero: caster inited.");
            } else {
                int colon = addr.indexOf(':');
                this.caster.init(InetAddress
                        .getByName(addr.substring(0, colon)), Integer
                        .parseInt(addr.substring(colon + 1)));
                LOG.info("Vaquero: caster inited.");
            }
        } catch (Exception e) {
            LOG.warning("initialization of caster in VaqueroContext failed!"
                    + e);
        }
        LOG.info("Vaquero: init complete.");
    }

    @Override
    protected void emitRecord(String contextName, String recordName,
            OutputRecord outRec) throws IOException {

        LOG.info("Vaquero: construct mooNode.");
        String type = recordName;
        // cub id formed from tag
        String id = new String();
        for (String tagName: outRec.getTagNames()) {
            if (tagName.equals(TAG_ID)) {
                id = (String) outRec.getTag(tagName);
            }
        }
        if (id.equals("")) {
            LOG.warning("id is not set");
            return;
        }
        Document document;
        try {
            document = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            LOG.log(Level.WARNING, "Cannot create xml document correctly", e);
            return;
        }

        Element mooNode = document.createElement("moo");
        Element oNode = document.createElement(VaqueroConstants.MOO_TAG_CUB);
        oNode.setAttribute(VaqueroConstants.MOO_TAG_CUB_ATTR_NAME, id);
        oNode.setAttribute(VaqueroConstants.MOO_TAG_CUB_ATTR_TYPE, type);
        Element user = document.createElement(Cub.USER_TAG);
        user.setAttribute(Cub.USER_ATTR_NAME, System.getProperty("user.name"));
        oNode.appendChild(user);
        Element draw = document.createElement(Cub.DRAW_TAG);
        draw.setAttribute(Cub.DRAW_ATTR_NAME, "all");
        Element prop;
        for (String metricName: outRec.getMetricNames()) {
            Object metric = outRec.getMetric(metricName);
            prop = document.createElement(Cub.PROP_TAG);
            prop.setAttribute(Cub.PROP_ATTR_NAME, metricName);
            prop.setAttribute(Cub.PROP_ATTR_VAL, metric.toString());
            draw.appendChild(prop);
            LOG.info("Vaquero: metricName:" + metricName + " meticValue:"
                    + metric.toString() + " append.");
        }
        oNode.appendChild(draw);
        mooNode.appendChild(oNode);

        this.caster.moo(mooNode);
        LOG.info("Vaquero: data moo out.");
    }

}
