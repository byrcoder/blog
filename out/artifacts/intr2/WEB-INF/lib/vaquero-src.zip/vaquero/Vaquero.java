package vaquero;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

import vaquero.herd.Herd;
import vaquero.omchannel.OMChannel;
import vaquero.server.Ear;
import vaquero.server.Shepherd;
import vaquero.server.WebServer;
import vaquero.util.VaqueroOpts;
import vaquero.util.VaqueroLogFormatter;

import bsh.Interpreter;

/**
 * The main class of vaquero, start a webserver and an ear
 * 
 * @author yaming
 */
public class Vaquero {

    public static final String DEFAULT_SERVER_ADDR = "nb019";

    public static final int DEFAULT_SERVER_PORT = 10080;

    // web server: display message
    private WebServer webServer;

    private int webPort;

    // herd/shepherd: manage message
    private String root;

    private Herd herd;

    // multicast receiving: accept message
    private Ear ear;

    private OMChannel channel;

    private Interpreter interpreter;

    public Vaquero(int webPort, String multicastAddr, int multicastPort,
            String root) throws IOException {
        this.webPort = webPort;
        this.channel = new OMChannel(InetAddress.getByName(multicastAddr),
                multicastPort, true);
        this.root = root;
    }

    public void startWebServer() throws Exception {
        this.webServer = new WebServer(webPort);
        this.webServer.start();
    }

    public void startInterpreterServer() {
        interpreter = new Interpreter();
        try {
            interpreter.set("vaquero", this);
            interpreter.set("portnum", 1234);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
        } catch (Exception e) {

        }
    }

    public void startMulticastListen() {
        this.ear = new Ear();
        this.ear.setChannel(this.channel);
        this.ear.start();
    }

    public void setHerd() throws Exception {
        this.herd = new Herd(new File(root));
        Shepherd.get().setHerd(this.herd);
    }

    private static void usage() {
        System.out.println("Usage: server [-w web-port] [-a multicast-addr]"
                + " [-m multicast-port] web-root");
    }

    public static void main(String args[]) throws Exception {
        VaqueroLogFormatter.asDefaultFormatter();

        if (args.length < 1) {
            usage();
            return;
        }

        VaqueroOpts opts = new VaqueroOpts("a:w:m:", args);
        int webPort = opts.getInt("w", 8070);
        int mcPort = opts.getInt("m", DEFAULT_SERVER_PORT);
        String mcAddr = opts.getOpt("a");
        if (mcAddr == null)
            mcAddr = DEFAULT_SERVER_ADDR;
        if (opts.getRemainsCount() != 1) {
            usage();
            return;
        }
        String path = opts.getRemain(0);

        Vaquero monitor;

        try {
            monitor = new Vaquero(webPort, mcAddr, mcPort, path);
        } catch (IOException e) {
            System.out.println("Get multicastChannel error");
            e.printStackTrace();
            return;
        }

        monitor.setHerd();

        try {
            monitor.startWebServer();
        } catch (Exception e) {
            System.out.println("Cannot start WebServer");
            e.printStackTrace();
            return;
        }

        monitor.startMulticastListen();

        monitor.startInterpreterServer();

    }
}
