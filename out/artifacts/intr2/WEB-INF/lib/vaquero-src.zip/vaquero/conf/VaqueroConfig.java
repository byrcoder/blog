package vaquero.conf;

import java.io.File;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;

import vaquero.herd.Cub;

@SuppressWarnings("serial")
public class VaqueroConfig extends XMLConfiguration {

    private static final Logger LOG = Logger.getLogger(VaqueroConfig.class
            .getName());

    private static final String DEFAULT_CUB_CLASS = "vaquero.herd.Cub";

    private static final String DEFAULT_CUB_XSL = "cub.xsl";

    private static final long DEFAULT_CUB_INTERVAL = 60000;

    private static final long DEFAULT_CUB_EXPIRE = 600000;

    private static final String FILE_NAME = "vaquero.xml";

    private static final VaqueroConfig instance = new VaqueroConfig();

    private String home;

    private HashMap<String, Integer> typeIdx = new HashMap<String, Integer>();

    private HashMap<String, Integer> sinkIdx = new HashMap<String, Integer>();

    private HashMap<String, String> rrdPropUnits = new HashMap<String, String>();

    private HashMap<String, Double> rrdPropDatums = new HashMap<String, Double>();

    private HashMap<String, Integer> drawIdx = new HashMap<String, Integer>();

    public static VaqueroConfig get() {
        return instance;
    }

    public VaqueroConfig() {
        super();
        home = System.getenv("VAQUERO_HOME");
        if (home == null) {
            home = ".";
        }
        File confDir = new File(home, "conf");
        this.setFile(new File(confDir, FILE_NAME));
        try {
            load();
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE,
                    "Caught Configuration when load config. exiting...", e);
            System.exit(1);
        }
        myLoad();
    }

    public void myLoad() {
        LOG.info("Loading cub configuration: " + this.getFileName());
        typeIdx.clear();
        rrdPropUnits.clear();
        rrdPropDatums.clear();
        String[] types = this.getStringArray("cub[@type]");
        for (int i = 0; i < types.length; i++) {
            typeIdx.put(types[i], i);
            LOG.info("Loading cub type: " + types[i]);
            String[][] drawProps = this.getTagProps(types[i], Cub.DRAW_TAG);
            String[] draws = this.getTag(types[i], Cub.DRAW_TAG);
            for (int draw = 0; draw < drawProps.length; draw++) {
                drawIdx.put(types[i] + "." + draws[draw], draw);
                for (int prop = 0; prop < drawProps[draw].length; prop++) {
                    rrdPropUnits.put(types[i] + "." + drawProps[draw][prop],
                            this.getTagPropAttr(types[i], draw, Cub.DRAW_TAG,
                                    prop, Cub.PROP_ATTR_UNIT));
                    rrdPropDatums.put(types[i] + "." + drawProps[draw][prop],
                            Double.valueOf(this.getTagPropAttrDouble(types[i],
                                    draw, Cub.DRAW_TAG, prop,
                                    Cub.PROP_ATTR_DATUM)));
                }
            }
        }
        LOG.info("Loading sink configuration: " + this.getFileName());
        sinkIdx.clear();
        String[] sinks = this.getStringArray("sink[@name]");
        for (int i = 0; i < sinks.length; i++) {
            sinkIdx.put(sinks[i], i);
            LOG.info("Loading sink: " + sinks[i]);
        }
    }

    public void myReload() throws ConfigurationException {
        LOG.info("Reloading vaquero configuration.");
        clear();
        load();
        myLoad();
    }

    // for vaquero web
    public String[] getSinks() {
        String[] res = new String[sinkIdx.keySet().size()];
        sinkIdx.keySet().toArray(res);
        return res;
    }

    public String getSinkClass(String sink) {
        Integer idx = sinkIdx.get(sink);
        if (idx == null) {
            return null;
        }
        String cls = getString("sink(" + idx + ")[@class]");
        if (cls == null) {
            return null;
        }
        return cls;
    }

    public String[][] getSinkClasses() {
        String[][] res = new String[sinkIdx.keySet().size()][2];
        for (String sink: sinkIdx.keySet()) {
            Integer idx = sinkIdx.get(sink);
            res[idx][0] = sink;
            res[idx][1] = getSinkClass(sink);
        }
        return res;
    }

    public String[] getSinkCubTypes(String sink) {
        Integer idx = sinkIdx.get(sink);
        return getStringArray("sink(" + idx + ").cubtype[@name]");
    }

    // for vaquero cubs
    public String[] getTypes() {
        String[] res = new String[typeIdx.keySet().size()];
        typeIdx.keySet().toArray(res);
        return res;
    }

    public String getCubClass(String type) {
        Integer idx = typeIdx.get(type);
        if (idx == null) {
            return null;
        }
        String cls = getString("cub(" + idx + ")[@class]");
        if (cls == null) {
            return null;
        }
        return cls;
    }

    public long getInterval(String type) {
        Integer idx = typeIdx.get(type);
        return getLong("cub(" + idx + ")[@interval]");
    }

    public long getExpirePeriod(String type) {
        Integer idx = typeIdx.get(type);
        return getLong("cub(" + idx + ")[@expire]");
    }

    public String getXsl(String type) {
        Integer idx = typeIdx.get(type);
        return getString("cub(" + idx + ")[@xsl]");
    }

    public String getRrdPropUnit(String type, String propName) {
        return rrdPropUnits.get(type + "." + propName);
    }

    public Double getRrdPropDatums(String type, String propName) {
        return rrdPropDatums.get(type + "." + propName);
    }

    public String[] getTag(String type, String tag) {
        Integer idx = typeIdx.get(type);
        return getStringArray("cub(" + idx + ")." + tag + "[@name]");
    }

    public String[] getTagAttrs(String type, String tag, String attr) {
        Integer idx = typeIdx.get(type);
        return getStringArray("cub(" + idx + ")." + tag + "[@" + attr + "]");
    }

    public String getTagAttr(String type, int tagIdx, String tag, String attr) {
        Integer idx = typeIdx.get(type);
        String key = "cub(" + idx + ")." + tag + "(" + tagIdx + ")[@" + attr
                + "]";
        return getString(key);
    }

    public double getTagAttrDouble(String type, int tagIdx, String tag,
            String attr) {
        Integer idx = typeIdx.get(type);
        String key = "cub(" + idx + ")." + tag + "(" + tagIdx + ")[@" + attr
                + "]";
        return getDouble(key);
    }

    public String[] getTagProps(String type, int tagIdx, String tag) {
        Integer idx = typeIdx.get(type);
        String key = "cub(" + idx + ")." + tag + "(" + tagIdx + ")";
        return getStringArray(key + ".prop[@name]");
    }

    public String[][] getTagProps(String type, String tag) {
        Integer idx = typeIdx.get(type);
        String key = "cub(" + idx + ")." + tag;
        String[] draws = getStringArray(key + "[@name]");
        String[][] result = new String[draws.length][];
        for (int i = 0; i < draws.length; i++) {
            result[i] = getStringArray(key + "(" + i + ").prop[@name]");
        }
        return result;
    }

    public String getTagPropAttr(String type, int tagIdx, String tag,
            int propIdx, String attr) {
        Integer idx = typeIdx.get(type);
        String key = "cub(" + idx + ")." + tag + "(" + tagIdx + ").prop("
                + propIdx + ")[@" + attr + "]";
        return getString(key);
    }

    public double getTagPropAttrDouble(String type, int tagIdx, String tag,
            int propIdx, String attr) {
        Integer idx = typeIdx.get(type);
        String key = "cub(" + idx + ")." + tag + "(" + tagIdx + ").prop("
                + propIdx + ")[@" + attr + "]";
        double result = Double.NaN;
        try {
            result = getDouble(key);
        } catch (NoSuchElementException e) {

        }
        return result;
    }

    public boolean addCubType(String cubType) {
        synchronized (this) {
            if (typeIdx.keySet().contains(cubType)) {
                LOG.warning("Can not add cub type, cub type already exists.");
                return false;
            }
            Integer idx = typeIdx.keySet().size();
            typeIdx.put(cubType, idx);
            this.addProperty("cub(" + idx + ")[@type]", cubType);
            this.addProperty("cub(" + idx + ")[@class]", DEFAULT_CUB_CLASS);
            this.addProperty("cub(" + idx + ")[@xsl]", DEFAULT_CUB_XSL);
            this.addProperty("cub(" + idx + ")[@interval]",
                    DEFAULT_CUB_INTERVAL);
            this.addProperty("cub(" + idx + ")[@expire]", DEFAULT_CUB_EXPIRE);

            LOG.info("Cub type added, saving config file...");
            try {
                this.save();
            } catch (ConfigurationException e) {
                LOG.log(Level.WARNING,
                        "Caught exception when saving config file.", e);
                return false;
            }

            LOG.info("Add cub type completed.");
            myLoad();
            return true;
        }
    }

    public void addDraw(String cubType, String drawName, String lev, String des) {
        synchronized (this) {
            Integer idx = typeIdx.get(cubType);
            Integer dIdx = drawIdx.get(cubType + "." + drawName);
            if (dIdx == null) {
                dIdx = getTag(cubType, Cub.DRAW_TAG).length;
                this.addProperty("cub(" + idx + ")." + Cub.DRAW_TAG + "("
                        + dIdx + ")[@" + Cub.DRAW_ATTR_NAME + "]", drawName);
                this.addProperty("cub(" + idx + ")." + Cub.DRAW_TAG + "("
                        + dIdx + ")[@" + Cub.DRAW_ATTR_LEV + "]", lev);
                this.addProperty("cub(" + idx + ")." + Cub.DRAW_TAG + "("
                        + dIdx + ")[@" + Cub.DRAW_ATTR_DES + "]", des);
                LOG.info("saving config file.");
                try {
                    this.save();
                } catch (ConfigurationException e) {
                    LOG.log(Level.WARNING,
                            "Caught exception when saving config file.", e);
                    return;
                }
                myLoad();
            }
        }
    }

    public void addProp(String cubType, String propName, String drawName) {
        synchronized (this) {
            Integer idx = typeIdx.get(cubType);
            Integer dIdx = drawIdx.get(cubType + "." + drawName);
            int propIdx = getTagProps(cubType, dIdx, Cub.DRAW_TAG).length;
            this.addProperty("cub(" + idx + ")." + Cub.DRAW_TAG + "(" + dIdx
                    + ").prop(" + propIdx + ")[@name]", propName);

            LOG.info("saving config file.");
            try {
                this.save();
            } catch (ConfigurationException e) {
                LOG.log(Level.WARNING,
                        "Caught exception when saving config file.", e);
                return;
            }
            myLoad();
        }
    }

    public void removeDraw(String cubType, String drawName) {
        synchronized (this) {
            Integer idx = typeIdx.get(cubType);
            Integer dIdx = drawIdx.get(cubType + "." + drawName);
            if (dIdx != null) {
                this.clearTree("cub(" + idx + ")." + Cub.DRAW_TAG + "(" + dIdx
                        + ")");
                LOG.info("saving config file.");
                try {
                    this.save();
                } catch (ConfigurationException e) {
                    LOG.log(Level.WARNING,
                            "Caught exception when saving config file.", e);
                    return;
                }
                myLoad();
            }
        }
    }

    public void removeProp(String cubType, String propName, String drawName) {
        synchronized (this) {
            Integer idx = typeIdx.get(cubType);
            Integer dIdx = drawIdx.get(cubType + "." + drawName);
            int propLength = getTagProps(cubType, dIdx, Cub.DRAW_TAG).length;
            for (int propIdx = 0; propIdx < propLength; propIdx++) {
                if (propName.equals(getProperty("cub(" + idx + ")."
                        + Cub.DRAW_TAG + "(" + dIdx + ").prop(" + propIdx
                        + ")[@name]"))) {
                    this.clearTree("cub(" + idx + ")." + Cub.DRAW_TAG + "("
                            + dIdx + ").prop(" + propIdx + ")");
                }
            }
            LOG.info("saving config file.");
            try {
                this.save();
            } catch (ConfigurationException e) {
                LOG.log(Level.WARNING,
                        "Caught exception when saving config file.", e);
                return;
            }
            myLoad();
        }
    }
}
