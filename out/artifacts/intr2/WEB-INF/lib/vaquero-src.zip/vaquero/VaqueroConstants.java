package vaquero;


public interface VaqueroConstants {
    
    public static final String MOO_TAG_MAIN = "moo";

    public static final String MOO_TAG_CUB = "cub";

    public static final String MOO_TAG_CUB_ATTR_TYPE = "type";

    public static final String MOO_TAG_CUB_ATTR_NAME = "name";

    public static final String MOO_TAG_CUB_ATTR_USER = "user";

    public static final String MOO_TAG_ADD_DRAW = "adddraw";

    public static final String MOO_TAG_ADD_DRAW_ATTR_NAME = "name";

    public static final String MOO_TAG_ADD_DRAW_ATTR_LEV = "lev";

    public static final String MOO_TAG_ADD_DRAW_ATTR_DES = "des";

    public static final String MOO_TAG_ADD_PROP = "addprop";

    public static final String MOO_TAG_ADD_PROP_ATTR_NAME = "name";

    public static final String MOO_TAG_ADD_PROP_ATTR_DRAW = "draw";

    public static final String MOO_TAG_PROP = "prop";

    public static final String MOO_TAG_PROP_ATTR_NAME = "name";

    public static final String MOO_TAG_PROP_ATTR_VAL = "val";

    public static final String MOO_TAG_RM_DRAW = "rmdraw";

    public static final String MOO_TAG_RM_DRAW_ATTR_NAME = "name";

    public static final String MOO_TAG_RM_PROP = "rmprop";

    public static final String MOO_TAG_RM_PROP_ATTR_NAME = "name";
    
    public static final String CONF_TAG_CUB = "cub";
    
    public static final String CONF_TAG_DRAW = "draw";

}
