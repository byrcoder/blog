package vaquero.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Parse the command line arguments into options. we can accept "ab:[cd][ef]:" 
 * like args now.  This was stolen from toolbox.misc.GetOpts.  Change name to
 * avoid confusion
 * 
 * @author river
 *
 */
public class VaqueroOpts {
  private Map<String, String[]> opts = new HashMap<String, String[]>();

  private List<String> remains = new ArrayList<String>();

  private Map<String, Boolean> controls = new HashMap<String, Boolean>();

  public VaqueroOpts(String controlString, String[] args) throws IOException {
    parseControls(controlString);
    parse(args);
  }

  private void parseControls(String controlString) {
    int len = controlString.length();

    boolean stringArg = false;
    String lastControl = null;
    StringBuilder lastControlBuffer = new StringBuilder();

    for (int i = 0; i < len; i++) {
      char ch = controlString.charAt(i);
      if (stringArg) {
        if (ch == ']') {
          stringArg = false;
          lastControl = lastControlBuffer.toString();
          lastControlBuffer.setLength(0);
          controls.put(lastControl, false);
        } else {
          lastControlBuffer.append(ch);
          continue;
        }
      } else if (ch == '[') {
        stringArg = true;
      } else if (ch == ':') {
        if (lastControl != null)
          controls.put(lastControl, true);
      } else {
        lastControl = String.valueOf(ch);
        controls.put(lastControl, false);
      }
    }
  }

  private void parse(String[] args) throws IOException {
    for (int i = 0; i < args.length; i++) {
      String arg = args[i];
      if (arg.startsWith("-")) {
        if (arg.length() < 2)
          throw new IOException("bad parameter \"" + arg + "\"");

        String opname = arg.substring(1);
        Boolean hasArg = controls.get(opname);
        if (hasArg == null) {
          throw new IOException("unsupported option \"" + arg + "\"");
        }

        String argValue = "";
        if (hasArg) {
          argValue = args[++i];
        }

        String[] oldOpt = opts.get(opname);
        String[] newOpt;
        if (oldOpt == null) {
          newOpt = new String[] { argValue };
        } else {
          newOpt = new String[oldOpt.length + 1];
          System.arraycopy(oldOpt, 0, newOpt, 0, oldOpt.length);
          newOpt[oldOpt.length] = argValue;
        }
        opts.put(opname, newOpt);
        remains.clear();
      } else {
        remains.add(arg);
      }
    }
  }

  /**
   * Return the last value of option, or null if no setting. 
   * @param opname the name of option
   * @return the last value of option, or null if no setting
   */
  public String getOpt(String opname) {
    String[] opt = opts.get(opname);
    if (opt == null || opt.length == 0)
      return null;
    else
      return opt[opt.length - 1];
  }

  public String getOpt(String opname, String def) {
    String result = getOpt(opname);
    return (result == null) ? def : result;
  }

  /**
   * @param opname the name of option
   * @param def default value
   * @return the option value (int type)
   */
  public int getInt(String opname, int def) {
    String s = getOpt(opname);
    if (s == null)
      return def;

    try {
      return Integer.parseInt(s);
    } catch (Exception e) {
      return def;
    }
  }

  /**
   * @param opname the name of option
   * @param def default value
   * @return the option value (long type)
   */
  public long getLong(String opname, long def) {
    String s = getOpt(opname);
    if (s == null)
      return def;

    try {
      return Long.parseLong(s);
    } catch (Exception e) {
      return def;
    }
  }

  public float getFloat(String opname, float def) {
    String s = getOpt(opname);
    if (s == null)
      return def;

    try {
      return Float.parseFloat(s);
    } catch (Exception e) {
      return def;
    }
  }
  
  public double getDouble(String opname, double def) {
    String s = getOpt(opname);
    if (s == null)
      return def;

    try {
      return Double.parseDouble(s);
    } catch (Exception e) {
      return def;
    }
    
  }

  /**
   * Return all the values of option, or null if no setting.
   * 
   * @param opname the name of option
   * @return the option value (array of strings)
   */
  public String[] getOptValue(String opname) {
    return opts.get(opname);
  }

  /**
   * Check if one option is set.
   * 
   * @param c the name of option
   * @return whether the option is set
   */
  public boolean hasOption(String c) {
    return opts.get(c) != null;
  }

  /**
   * Return the number of remains.
   * 
   * @return number all the non-option arguments
   */
  public int getRemainsCount() {
    return remains.size();
  }

  /**
   * Return all the non-option arguments, never returns null.
   * 
   * @return all the non-option arguments, never returns null
   */
  public String[] getRemains() {
    String[] result = new String[remains.size()];
    remains.toArray(result);
    return result;
  }

  /**
   * Return the remained parameter at given index.
   * 
   * @param i the i-th remained parameter
   * @return the i-th remained parameter
   */
  public String getRemain(int i) {
    return remains.get(i);
  }

  public String toString() {
    StringBuilder builder = new StringBuilder();
    for (Iterator<String> it = opts.keySet().iterator(); it.hasNext();) {
      String c = it.next();
      builder.append(c).append(':').append(opts.get(c).toString()).append(' ');
    }

    for (Iterator<String> it = remains.iterator(); it.hasNext();) {
      builder.append(it.next()).append(' ');
    }

    return builder.toString();
  }

}
