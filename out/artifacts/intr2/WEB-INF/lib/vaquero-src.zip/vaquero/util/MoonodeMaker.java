package vaquero.util;

import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import vaquero.VaqueroConstants;
import vaquero.herd.Cub;

public class MoonodeMaker {

    protected static Logger LOG = Logger
            .getLogger(MoonodeMaker.class.getName());

    private Document document;

    private static final MoonodeMaker instance = new MoonodeMaker();

    public MoonodeMaker() {
        try {
            document = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            LOG.log(Level.WARNING, "Cannot create xml document correctly", e);
        }
    }

    public static MoonodeMaker get() {
        return instance;
    }

    public Element CreateMoonode(ArrayList<Node> cubnodes) {
        Element res = document.createElement("moo");
        for (Node cubnode: cubnodes) {
            res.appendChild(cubnode);
        }
        return res;
    }

    public Element CreateCubnode(String id, String type,
            ArrayList<Node> tagnodes) {
        Element res = document.createElement(VaqueroConstants.MOO_TAG_CUB);
        res.setAttribute(VaqueroConstants.MOO_TAG_CUB_ATTR_NAME, id);
        res.setAttribute(VaqueroConstants.MOO_TAG_CUB_ATTR_TYPE, type);
        for (Node tagnode: tagnodes) {
            res.appendChild(tagnode);
        }
        return res;
    }

    public Element CreateTagnode(String tagname, Properties attrs,
            Properties props) {
        Element res = document.createElement(tagname);
        for (Object key: attrs.keySet()) {
            res.setAttribute((String) key, attrs.getProperty((String) key));
        }
        Element prop;
        for (Object key: props.keySet()) {
            prop = document.createElement(Cub.PROP_TAG);
            prop.setAttribute(Cub.PROP_ATTR_NAME, (String) key);
            prop.setAttribute(Cub.PROP_ATTR_VAL, props
                    .getProperty((String) key));
            res.appendChild(prop);
        }
        return res;
    }

}
