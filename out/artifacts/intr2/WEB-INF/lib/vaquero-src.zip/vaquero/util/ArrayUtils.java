package vaquero.util;

import java.lang.reflect.Array;
import java.util.Arrays;

/**
 * Utilities to handle array.
 * 
 * @author river
 */
public class ArrayUtils {

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param o
     * @return new array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] push(T[] arr, T o) {
        T[] newArr = (T[]) Array.newInstance(o.getClass(), arr.length + 1);
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = o;
        return newArr;
    }

    public static int[] push(int[] arr, int i) {
        int[] newArr = new int[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    @SuppressWarnings("unchecked")
    public static Object[] expand(Object[] arr, Class type, int size) {
        if (size <= arr.length)
            return arr;
        Object[] newArr = (Object[]) Array.newInstance(type, size);
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public static int[] expand(int[] arr, int size) {
        if (size <= arr.length)
            return arr;
        int[] newArr = new int[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public static long[] expand(long[] arr, int size) {
        if (size <= arr.length)
            return arr;
        long[] newArr = new long[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public static byte[] expand(byte[] arr, int size) {
        if (size <= arr.length)
            return arr;
        byte[] newArr = new byte[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Remove the first element of array.
     * 
     * @param arr
     * @return new array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] shift(T[] arr) {
        assert arr.length > 0;
        T[] newArr = (T[]) Array.newInstance(arr.getClass().getComponentType(),
                arr.length - 1);
        System.arraycopy(arr, 1, newArr, 0, arr.length - 1);
        return newArr;
    }

    private static class SortWrapper implements Comparable<SortWrapper> {
        Object[] objects;

        public SortWrapper(int size) {
            objects = new Object[size];
        }

        public void setObject(int index, Object o) {
            objects[index] = o;
        }

        public Object getObject(int index) {
            return objects[index];
        }

        @SuppressWarnings("unchecked")
        public int compareTo(SortWrapper o) {
            return ((Comparable) objects[0]).compareTo(o.objects[0]);
        }

    }

    private static class SortWrapperReverseOrder implements
            Comparable<SortWrapperReverseOrder> {
        Object[] objects;

        public SortWrapperReverseOrder(int size) {
            objects = new Object[size];
        }

        public void setObject(int index, Object o) {
            objects[index] = o;
        }

        public Object getObject(int index) {
            return objects[index];
        }

        @SuppressWarnings("unchecked")
        public int compareTo(SortWrapperReverseOrder o) {
            return ((Comparable) o.objects[0]).compareTo(objects[0]);
        }

    }

    /**
     * Sort arrays by
     * 
     * @param arrays
     * @return
     */
    public static void sortArrays(Object... arrays) {
        int arrayCount = arrays.length;
        int len = ((Object[]) arrays[0]).length;
        SortWrapper[] wrappers = new SortWrapper[len];

        for (int i = 0; i < wrappers.length; i++) {
            wrappers[i] = new SortWrapper(arrayCount);
            for (int j = 0; j < arrayCount; j++)
                wrappers[i].setObject(j, ((Object[]) arrays[j])[i]);
        }

        Arrays.sort(wrappers);

        for (int i = 0; i < len; i++) {
            for (int j = 0; j < arrayCount; j++) {
                ((Object[]) arrays[j])[i] = wrappers[i].getObject(j);
            }
        }
    }

    public static void sortArraysReverseOrder(Object... arrays) {
        int arrayCount = arrays.length;
        int len = ((Object[]) arrays[0]).length;
        SortWrapperReverseOrder[] wrappers = new SortWrapperReverseOrder[len];

        for (int i = 0; i < wrappers.length; i++) {
            wrappers[i] = new SortWrapperReverseOrder(arrayCount);
            for (int j = 0; j < arrayCount; j++)
                wrappers[i].setObject(j, ((Object[]) arrays[j])[i]);
        }

        Arrays.sort(wrappers);

        for (int i = 0; i < len; i++) {
            for (int j = 0; j < arrayCount; j++) {
                ((Object[]) arrays[j])[i] = wrappers[i].getObject(j);
            }
        }
    }

}
