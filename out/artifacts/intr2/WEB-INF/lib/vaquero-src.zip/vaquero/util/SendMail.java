package vaquero.util;

import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
    private static final Logger LOG = Logger.getLogger(SendMail.class.getName());

    private static final String MAIL_SMTP_HOST = "220.181.8.38";

    private static final String MAIL_FROM = "huangyaming@rd.netease.com";

    private static final String DEFAULT_MAIL_TO = "huangyaming@rd.netease.com";

    public static void send(String subject, String content) {
        send(subject, content, DEFAULT_MAIL_TO);
    }
    
    public static void send(String subject, String content, String mailAddr) {
        send(subject, content, new String[]{mailAddr});
    }
    
    public static void send(String subject, String content, String[] mailAddrs) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", MAIL_SMTP_HOST);
            Session session = Session.getDefaultInstance(props);
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(MAIL_FROM));
            InternetAddress[] address;
            if(mailAddrs == null || mailAddrs.length == 0) {
                address = new InternetAddress[]{ new InternetAddress(DEFAULT_MAIL_TO) };
            } else {
                address = new InternetAddress[mailAddrs.length];
                for(int i=0; i<address.length; i++) {
                    address[i] = new InternetAddress(mailAddrs[i]);
                }
            }
            msg.setRecipients(Message.RecipientType.TO, address);
            msg.setSubject(subject);
            msg.setSentDate(new Date());
            msg.setText(content);

            Transport.send(msg);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Vaquero: Caught Exception when send mail.", e);
        }
    }
}
