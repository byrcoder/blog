package vaquero.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vaquero.conf.VaqueroConfig;

public class TypeIndexServlet extends HttpServlet {

    private static final long serialVersionUID = 7537847088218813644L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String product = request.getParameter("product");
        VaqueroConfig config = VaqueroConfig.get();
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<cubtypes>");
        if (product != null) {
            for (String cubType: config.getSinkCubTypes(product)) {
                out.println("<cubtype>" + cubType + "</cubtype>");
            }
        }
        out.println("</cubtypes>");
    }
}
