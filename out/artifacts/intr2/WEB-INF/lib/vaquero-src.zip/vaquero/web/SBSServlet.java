package vaquero.web;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.configuration.XMLConfiguration;

import vaquero.herd.Herd;
import vaquero.server.Shepherd;

public class SBSServlet extends HttpServlet {

    private static final long serialVersionUID = 550175635203747234L;

    private static final Logger LOG = Logger.getLogger(SBSServlet.class
            .getName());

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        try {
            Herd herd = Shepherd.get().getHerd();
            String sbsName = request.getParameter("sbsname");
            File sbsFile = new File(herd.getSubscriptionRoot(), sbsName);
            if (!sbsFile.exists()) {
                PrintWriter out = new PrintWriter(new FileOutputStream(sbsFile));
                out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                out.println("<subscription>");
                out.println("<num>0</num>");
                out.println("</subscription>");
                out.close();
            }
            XMLConfiguration conf = new XMLConfiguration(new File(herd
                    .getSubscriptionRoot(), sbsName));
            String op = request.getParameter("op");
            String cubid = request.getParameter("cubid");
            String drawname = request.getParameter("drawname");
            String period = request.getParameter("period");
            int num = conf.getInt("num");
            if (op != null) {
                if (op.equals("add") && cubid != null && period != null) {
                    boolean added = false;
                    for (int i = 0; i < num; i++) {
                        if (conf.getProperty("subitem(" + i + ")[@cubid]")
                                .equals(cubid)
                                && conf.getProperty(
                                        "subitem(" + i + ")[@drawname]")
                                        .equals(drawname)
                                && conf.getProperty(
                                        "subitem(" + i + ")[@period]").equals(
                                        period)) {
                            added = true;
                        }
                    }
                    if (added == false) {
                        conf.setProperty("subitem(" + num + ")[@cubid]", cubid);
                        conf.setProperty("subitem(" + num + ")[@drawname]",
                                drawname);
                        conf.setProperty("subitem(" + num + ")[@period]",
                                period);
                        num++;
                        conf.setProperty("num", num);
                    }
                    conf.save();
                }
                if (op.equals("del") && cubid != null && period != null) {
                    int delIndex = -1;
                    for (int i = 0; i < num; i++) {
                        if (conf.getProperty("subitem(" + i + ")[@cubid]")
                                .equals(cubid)
                                && conf.getProperty(
                                        "subitem(" + i + ")[@drawname]")
                                        .equals(drawname)
                                && conf.getProperty(
                                        "subitem(" + i + ")[@period]").equals(
                                        period)) {
                            delIndex = i;
                        }
                    }
                    if (delIndex >= 0) {
                        conf.clearProperty("subitem(" + delIndex + ")[@cubid]");
                        conf.clearProperty("subitem(" + delIndex
                                + ")[@drawname]");
                        conf
                                .clearProperty("subitem(" + delIndex
                                        + ")[@period]");
                        num--;
                        conf.setProperty("num", num);
                    }
                    conf.save();
                }
            }

            response.setContentType("text/xml");
            PrintWriter out = response.getWriter();
            out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            out.println("<sbs>");
            out.println("<name>" + sbsName + "</name>");
            out.println("<num>" + num + "</num>");
            for (int i = 0; i < num; i++) {
                out.println("<item>");
                out.println("<cubid>"
                        + conf.getProperty("subitem(" + i + ")[@cubid]")
                        + "</cubid>");
                out.println("<drawname>"
                        + conf.getProperty("subitem(" + i + ")[@drawname]")
                        + "</drawname>");
                out.println("<period>"
                        + conf.getProperty("subitem(" + i + ")[@period]")
                        + "</period>");
                out.println("</item>");
            }
            out.println("</sbs>");
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Caught Exception in SBSServlet.", e);
        }
    }
}
