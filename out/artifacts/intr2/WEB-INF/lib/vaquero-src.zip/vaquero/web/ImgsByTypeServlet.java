package vaquero.web;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jrobin.graph.RrdGraphInfo;

import vaquero.herd.Herd;
import vaquero.server.Shepherd;

public class ImgsByTypeServlet extends HttpServlet {

    private static final long serialVersionUID = -2078775307399945994L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("cubtype");
        String drawName = request.getParameter("drawname");
        String period = request.getParameter("period");
        Herd herd = Shepherd.get().getHerd();
        TreeMap<String, RrdGraphInfo> imageInfos = herd.getRrdHolder(type)
                .drawAllCubLineGraphs(drawName, period);
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<images>");
        out.println("<num>" + imageInfos.size() + "</num>");
        for (String cubName: imageInfos.keySet()) {
            RrdGraphInfo gi = imageInfos.get(cubName);
            out.println("<image>");
            out.println("<cubid>" + type + "-" + cubName + "</cubid>");
            out.println("<cubname>" + cubName + "</cubname>");
            out.println("<period>" + period + "</period>");
            out.println("<drawname>" + drawName + "</drawname>");
            out.println("<filename>" + new File(gi.getFilename()).getName()
                    + "</filename>");
            out.println("<width>" + gi.getWidth() + "</width>");
            out.println("<height>" + gi.getHeight() + "</height>");
            out.println("</image>");
        }
        out.println("</images>");
    }
}
