package vaquero.web;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jrobin.graph.RrdGraphInfo;

import vaquero.herd.Herd;
import vaquero.server.Shepherd;

public class SingleImageServlet extends HttpServlet {

    private static final long serialVersionUID = 1387974065162630471L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        String name = request.getParameter("name");
        String drawName = request.getParameter("draw");
        String period = request.getParameter("period");
        Herd herd = Shepherd.get().getHerd();
        RrdGraphInfo imageInfo = herd.getRrdHolder(type).drawLineGraph(name,
                drawName, period);
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<images>");
        out.println("<image>");
        out.println("<cubid>" + type + "-" + name + "</cubid>");
        out.println("<cubname>" + name + "</cubname>");
        out.println("<drawname>" + drawName + "</drawname>");
        out.println("<filename>" + new File(imageInfo.getFilename()).getName()
                + "</filename>");
        out.println("<width>" + imageInfo.getWidth() + "</width>");
        out.println("<height>" + imageInfo.getHeight() + "</height>");
        out.println("</image>");
        out.println("</images>");
    }

}
