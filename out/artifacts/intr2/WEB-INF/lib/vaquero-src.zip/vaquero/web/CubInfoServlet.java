package vaquero.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vaquero.conf.VaqueroConfig;
import vaquero.herd.Cub;
import vaquero.herd.Herd;
import vaquero.server.Shepherd;

public class CubInfoServlet extends HttpServlet {

    private static final long serialVersionUID = 7659039447947585734L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String cubId = request.getParameter("cubid");
        VaqueroConfig config = VaqueroConfig.get();
        Herd herd = Shepherd.get().getHerd();
        Cub cub = herd.findCub(cubId);
        PrintWriter out = response.getWriter();
        if (cub == null) {
            out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            out.println("<typeinfo>");
            out.println("<found>false</found>");
            out.println("</typeinfo>");
        } else {
            String cubType = cub.getType();
            response.setContentType("text/xml");
            out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            out.println("<typeinfo>");
            out.println("<found>true</found>");
            out.println("<cubid>" + cubId + "</cubid>");
            if (cubType != null) {
                for (String drawName: config.getTag(cubType, Cub.DRAW_TAG)) {
                    out.println("<drawname>" + drawName + "</drawname>");
                }
            }
            out.println("</typeinfo>");
        }
    }
}
