package vaquero.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jrobin.core.FetchData;
import org.jrobin.core.RrdException;

import vaquero.herd.Cub;
import vaquero.herd.Herd;
import vaquero.herd.RrdHolder;
import vaquero.server.Shepherd;

public class DetailDataServlet extends HttpServlet {

    private static final long serialVersionUID = 1502562172869429870L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String cubId = request.getParameter("cubid");
        String drawName = request.getParameter("drawname");
        String period = request.getParameter("period");
        Herd herd = Shepherd.get().getHerd();
        Cub cub = herd.findCub(cubId);
        String cubType = cub.getType();
        String cubName = cub.getName();
        RrdHolder rrdHolder = herd.getRrdHolder(cubType);
        FetchData fetchData = rrdHolder.getCubFetchData(cubName, period);
        HashSet<String> dsNames = rrdHolder.getDsNameByDrawName(drawName);
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<details>");
        out.println("<cubid>" + cubId + "</cubid>");
        out.println("<cubname>" + cubName + "</cubname>");
        out.println("<drawname>" + drawName + "</drawname>");
        out.println("<period>" + period + "</period>");
        HashMap<String, Integer> dsNameIndex = new HashMap<String, Integer>();
        for (String dsName: dsNames) {
            out.println("<propname>" + dsName + "</propname>");
            dsNameIndex.put(dsName, fetchData.getDsIndex(dsName));
        }
        long[] timestamps = fetchData.getTimestamps();
        double[][] values = fetchData.getValues();
        try {
            // last value
            out.println("<last>");
            for (String dsName: dsNames) {
                out.println("<" + dsName + ">"
                        + fetchData.getAggregate(dsName, "LAST") + "</"
                        + dsName + ">");
            }
            out.println("</last>");
            // avg value
            out.println("<avg>");
            for (String dsName: dsNames) {
                out.println("<" + dsName + ">"
                        + fetchData.getAggregate(dsName, "AVERAGE") + "</"
                        + dsName + ">");
            }
            out.println("</avg>");
        } catch (RrdException e) {}
        // all data
        for (int i = 0; i < timestamps.length; i++) {
            out.println("<data>");
            out
                    .println("<timestamp>" + (timestamps[i] * 1000)
                            + "</timestamp>");
            for (String dsName: dsNames) {
                out.println("<" + dsName + ">"
                        + values[dsNameIndex.get(dsName)][i] + "</" + dsName
                        + ">");
            }
            out.println("</data>");
        }
        out.println("</details>");
    }
}
