package vaquero.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.TreeSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vaquero.conf.VaqueroConfig;
import vaquero.herd.Cub;
import vaquero.herd.Herd;
import vaquero.server.Shepherd;

public class TypeInfoServlet extends HttpServlet {

    private static final long serialVersionUID = -2368650856597387893L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String cubType = request.getParameter("cubtype");
        VaqueroConfig config = VaqueroConfig.get();
        Herd herd = Shepherd.get().getHerd();
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<typeinfo>");
        if (cubType != null) {
            for (String drawName: config.getTag(cubType, Cub.DRAW_TAG)) {
                out.println("<drawname>" + drawName + "</drawname>");
            }
            TreeSet<String> cubNames = herd.getCubNames(cubType);
            if (cubNames != null) {
                for (String cubName: cubNames) {
                    out.println("<cubname>" + cubName + "</cubname>");
                }
            }
        }
        out.println("</typeinfo>");
    }
}
