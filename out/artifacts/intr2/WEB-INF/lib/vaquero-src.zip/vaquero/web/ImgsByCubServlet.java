package vaquero.web;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jrobin.graph.RrdGraphInfo;

import vaquero.herd.Cub;
import vaquero.herd.Herd;
import vaquero.server.Shepherd;

public class ImgsByCubServlet extends HttpServlet {

    private static final long serialVersionUID = 3576229659572841200L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String cubid = request.getParameter("cubid");
        String period = request.getParameter("period");
        Herd herd = Shepherd.get().getHerd();
        Cub cub = herd.findCub(cubid);
        String cubType = cub.getType();
        String cubName = cub.getName();
        TreeMap<String, RrdGraphInfo> imageInfos = herd.getRrdHolder(cubType)
                .drawOneCubAllLineGraphs(cubName, period);
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<images>");
        out.println("<num>" + imageInfos.size() + "</num>");
        for (String drawName: imageInfos.keySet()) {
            RrdGraphInfo gi = imageInfos.get(cubName);
            out.println("<image>");
            out.println("<cubid>" + cubType + "-" + cubName + "</cubid>");
            out.println("<cubname>" + cubName + "</cubname>");
            out.println("<period>" + period + "</period>");
            out.println("<drawname>" + drawName + "</drawname>");
            out.println("<filename>" + new File(gi.getFilename()).getName()
                    + "</filename>");
            out.println("<width>" + gi.getWidth() + "</width>");
            out.println("<height>" + gi.getHeight() + "</height>");
            out.println("</image>");
        }
        out.println("</images>");
    }

}
