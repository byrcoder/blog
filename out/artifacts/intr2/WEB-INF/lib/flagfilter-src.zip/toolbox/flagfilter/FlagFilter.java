package toolbox.flagfilter;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class FlagFilter implements Filter {

    private String[] flags = null;

    private ArrayList<long[]> allowedIps = null;

    private String forwardHeader = null;

    public void init(FilterConfig config) throws ServletException {
        String flagStr = config.getInitParameter("flag-name");
        if (flagStr == null)
            flags = null;
        else
            flags = flagStr.split(",");

        String ipStr = config.getInitParameter("ips");
        if (ipStr == null)
            allowedIps = null;
        else {
            allowedIps = getIpList(ipStr);
        }

        forwardHeader = config.getInitParameter("forward-header");
    }

    public void destroy() {
        flags = null;
        allowedIps = null;
        forwardHeader = null;
    }

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        if (allowedIps == null) {
            chain.doFilter(req, res);
            return;
        }

        if (inIpList(getIp(req), allowedIps)) {
            req.setAttribute("inFlagFilterWhiteList", "true");
        }

        // 如果flag为空或不在ip范围内, 则结束本filter
        // 只有flag不为空且在ip范围内, 才会继续设置flag中的attribute
        if (flags == null || req.getAttribute("inFlagFilterWhiteList") == null) {
            chain.doFilter(req, res);
            return;
        }

        for (String flag : flags) {
            String value = req.getParameter(flag);
            if (value == null) {
                continue;
            }
            req.setAttribute(flag, value);
        }
        req.setAttribute("toolbox.flagfilter.InWhiteList", true);

        chain.doFilter(req, res);
    }

    private String getIp(ServletRequest request) {
        String ip = null;
        if (forwardHeader != null && request instanceof HttpServletRequest) {
            ip = ((HttpServletRequest) request).getHeader(forwardHeader);
        }
        if (ip == null || ip.length() == 0) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    /** 从一个字符串(逗号分隔)获取一堆ip对, 每个ip对可以是一个单独的ip, 也可以是一个ip段 */
    public static ArrayList<long[]> getIpList(String ipStr) throws ServletException {
        ArrayList<long[]> ipList = new ArrayList<long[]>();
        String[] ipSegs = ipStr.split(",");
        for (String ipSeg : ipSegs) {
            long[] ips = new long[2];
            int index = ipSeg.indexOf('-');
            if (index == -1) {
                ips[0] = parseIpStr(ipSeg);
                ips[1] = ips[0];
            } else {
                ips[0] = parseIpStr(ipSeg.substring(0, index));
                ips[1] = parseIpStr(ipSeg.substring(index + 1));
            }
            ipList.add(ips);
        }
        return ipList;
    }

    /** 检查一个ip是否在一堆ip对中, 和getIpList配合使用 */
    public static boolean inIpList(String ipStr, ArrayList<long[]> ipList) throws ServletException {
        long ip = parseIpStr(ipStr);
        for (long ips[] : ipList) {
            if (ip >= ips[0] && ip <= ips[1]) {
                return true;
            }
        }
        return false;
    }

    /** 将一个字符串解析成一个ip(long) */
    public static long parseIpStr(String ipStr) throws ServletException {
        String[] split = ipStr.split("\\.");
        if (split.length != 4) {
            throw new ServletException("Wrong Ip Format: " + ipStr);
        }
        int[] b = new int[split.length];
        for (int i = 0; i < split.length; i++) {
            try {
                b[i] = Integer.parseInt(split[i]);
            } catch (NumberFormatException e) {
                throw new ServletException("Wrong Ip Format: " + ipStr);
            }
            if (b[i] < 0 || b[i] > 255) {
                throw new ServletException("Wrong Ip Format: " + ipStr);
            }
        }
        return (((long) b[0] & 0xff) << 24) | (((long) b[1] & 0xff) << 16) | (((long) b[2] & 0xff) << 8) | ((long) b[3] & 0xff);
    }
}
