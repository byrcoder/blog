package com.mysql.jdbc.exceptions;

public class NotYetImplementedException extends RuntimeException {

	public NotYetImplementedException() {
		// TODO Auto-generated constructor stub
	}

	public NotYetImplementedException(String reason) {
		super(reason);
		// TODO Auto-generated constructor stub
	}

	public NotYetImplementedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
