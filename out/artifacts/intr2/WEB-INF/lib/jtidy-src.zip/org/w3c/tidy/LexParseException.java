/**
 * @(#)LexParseException.java, 2009-5-27. Copyright 2009 Youdao, Inc. All rights
 *                             reserved. YOUDAO PROPRIETARY/CONFIDENTIAL. Use is
 *                             subject to license terms.
 */
package org.w3c.tidy;

/**
 * @author sunly
 */
public class LexParseException extends Exception {

    private static final long serialVersionUID = 3779529052681992104L;

    public LexParseException(String message) {
        // Constructor. Create a ParseError object containing
        // the given message as its error message.
        super(message);
    }

}
