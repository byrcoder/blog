/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 1997-2006
 *	Oracle Corporation.  All rights reserved.
 *
 * $Id: DatabaseStats.java,v 12.4 2006/08/24 14:46:07 bostic Exp $
 */
package com.sleepycat.db;

public abstract class DatabaseStats {
	// no public constructor
	/* package */ DatabaseStats() {}
}
