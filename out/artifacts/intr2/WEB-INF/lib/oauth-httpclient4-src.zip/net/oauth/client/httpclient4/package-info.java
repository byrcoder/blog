/**
 * Classes that integrate the Apache Commons HTTP Client version 4 with the OAuth library.
 */
package net.oauth.client.httpclient4;

