package odis.io;

/**
 * An exception thrown when bad object is read, like in reading sequence file.
 * 
 * @author David
 */
public class BadObjectException extends RuntimeException {
    private static final long serialVersionUID = -5648679555412431621L;

    /**
     * The constructor with the given message, The cause is not initialized, and
     * may subsequently be initialized by a call to {@link #initCause}.
     * 
     * @param message
     *            the message
     */
    public BadObjectException(String message) {
        super(message);
    }

    /**
     * The constructor with the given message and cause.
     * 
     * @param message
     *            the message
     * @param cause
     *            the cause
     */
    public BadObjectException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * The constructor with the given cause and a detail message of
     * <tt>(cause==null ? null : cause.toString())</tt> (which typically
     * contains the class and detail message of <tt>cause</tt>).
     * 
     * @param cause
     *            the original reason
     */
    public BadObjectException(Throwable cause) {
        super(cause);
    }

}
