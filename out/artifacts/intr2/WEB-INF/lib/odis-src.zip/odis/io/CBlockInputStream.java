/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.DataInput;
import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Similar to CDataInputStream except it buffers the data in blocks of 64KB for
 * better performance DataInputStream using little-endian byte order (reverse of
 * Java's big-endian). This makes interoperating with C/C++ code easy on Intel
 * machines. <b>attention</b>: readLine() and readUTF() are not implemented. Use
 * {@link odis.serialize.lib.UTF8Writable#readString(DataInput)}.
 * 
 * @see CDataOutputStream
 * @deprecated just use a BufferedInputStream in front of CDataInputStream
 * @author jimmysu
 */
public class CBlockInputStream extends FilterInputStream implements DataInput {

    private byte[] buffer;

    private boolean reachedEOF;

    private int numBytesInBuffer;

    private int index;

    /**
     * The constructor
     * 
     * @param in
     *            InputStream for buffered
     */
    public CBlockInputStream(InputStream in) throws IOException {
        super(in);
        buffer = new byte[65536]; // allocate 64KB buffer
        int bytesRead = in.read(buffer);
        if (bytesRead < 0) {
            // reached end of file without reading any bytes
            reachedEOF = true;
            numBytesInBuffer = 0;
            index = -1;
        } else {
            reachedEOF = false;
            numBytesInBuffer = bytesRead;
            index = 0;
        }
    }

    @Override
    public void readFully(byte[] b) throws IOException {
        readFully(b, 0, b.length);
    }

    private void getMoreBytes() throws IOException {
        if (reachedEOF)
            return;

        if (index < numBytesInBuffer) // still have available bytes left in
            // buffer
            return;

        int bytesRead = in.read(buffer);
        if (bytesRead < 0) {
            // reached end of file without reading any bytes
            reachedEOF = true;
            numBytesInBuffer = 0;
            index = -1;
        } else {
            // here buffer has at least one available byte, guaranteed by Java
            // API
            reachedEOF = false;
            numBytesInBuffer = bytesRead;
            index = 0;
        }
    }

    @Override
    public void readFully(byte[] b, int off, int len) throws IOException {
        if (len < 0)
            throw new IndexOutOfBoundsException();

        if (reachedEOF)
            throw new EOFException();

        if (numBytesInBuffer - index >= len) {
            // have enough bytes in buffer to satisfy this request
            System.arraycopy(buffer, index, b, off, len);
            index += len;
        } else {
            int bytesAvail = numBytesInBuffer - index;
            System.arraycopy(buffer, index, b, off, bytesAvail);
            len -= bytesAvail;
            off += bytesAvail;

            while (len > 0) {
                getMoreBytes();
                if (reachedEOF)
                    throw new EOFException();
                else {
                    if (numBytesInBuffer - index >= len) {
                        System.arraycopy(buffer, index, b, off, len);
                        index += len;
                        len = 0;
                    } else {
                        bytesAvail = numBytesInBuffer - index;
                        System.arraycopy(buffer, index, b, off, bytesAvail);
                        len -= bytesAvail;
                        off += bytesAvail;
                    }
                }
            }

            // get ready for the next read
            getMoreBytes();
        }
    }

    @Override
    public int skipBytes(int n) throws IOException {
        if (reachedEOF)
            return 0;

        int bytesAvail = numBytesInBuffer - index;
        int total = 0;
        if (bytesAvail >= n) {
            // just need to skip the bytes in buffer
            index += n;
            total = n;
        } else {
            // first skip the bytes in buffer
            index += bytesAvail;

            // now skip the remaining bytes in the input stream
            total = bytesAvail;
            int cur = 0;

            while ((total < n) && ((cur = (int) in.skip(n - total)) > 0)) {
                total += cur;
            }
        }

        // get ready for the next read
        getMoreBytes();
        return total;
    }

    @Override
    public boolean readBoolean() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch = buffer[index];
        index++;

        getMoreBytes();
        return (ch != 0);
    }

    @Override
    public byte readByte() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch = buffer[index];
        index++;
        getMoreBytes();
        return (byte) (ch);
    }

    @Override
    public int readUnsignedByte() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch = buffer[index];
        index++;
        getMoreBytes();
        return ch & 0xff;
    }

    @Override
    public short readShort() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch1 = buffer[index];
        index++;
        int bytesAvail = numBytesInBuffer - index;
        if (bytesAvail < 1) {
            getMoreBytes();
            if (reachedEOF)
                throw new EOFException();
        }

        // ready to read in the second byte
        int ch2 = buffer[index];
        index++;

        getMoreBytes();

        return (short) (((ch2 & 0xff) << 8) | (ch1 & 0xff));
    }

    @Override
    public int readUnsignedShort() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch1 = buffer[index];
        index++;
        int bytesAvail = numBytesInBuffer - index;
        if (bytesAvail < 1) {
            getMoreBytes();
            if (reachedEOF)
                throw new EOFException();
        }

        // ready to read in the second byte
        int ch2 = buffer[index];
        index++;

        getMoreBytes();

        return (((ch2 & 0xff) << 8) | (ch1 & 0xff));
    }

    @Override
    public char readChar() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch1 = buffer[index];
        index++;
        int bytesAvail = numBytesInBuffer - index;
        if (bytesAvail < 1) {
            getMoreBytes();
            if (reachedEOF)
                throw new EOFException();
        }

        // ready to read in the second byte
        int ch2 = buffer[index];
        index++;

        getMoreBytes();
        return (char) (((ch2 & 0xff) << 8) | (ch1 & 0xff));
    }

    @Override
    public int readInt() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int ch1 = buffer[index];
        index++;
        int bytesAvail = numBytesInBuffer - index;
        if (bytesAvail < 1) {
            getMoreBytes();
            if (reachedEOF)
                throw new EOFException();
        }

        // ready to read in the second byte
        int ch2 = buffer[index];
        index++;

        bytesAvail = numBytesInBuffer - index;
        if (bytesAvail < 1) {
            getMoreBytes();
            if (reachedEOF)
                throw new EOFException();
        }

        // ready to read in the third byte
        int ch3 = buffer[index];
        index++;

        bytesAvail = numBytesInBuffer - index;
        if (bytesAvail < 1) {
            getMoreBytes();
            if (reachedEOF)
                throw new EOFException();
        }

        // ready to read in the fourth byte
        int ch4 = buffer[index];
        index++;

        getMoreBytes();
        return (((ch4 & 0xff) << 24) | ((ch3 & 0xff) << 16)
                | ((ch2 & 0xff) << 8) | (ch1 & 0xff));
    }

    /**
     * Reads VInt value from bytes and returns
     * 
     * @return the <code>int</code> value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public int readVInt() throws IOException {
        if (reachedEOF)
            throw new EOFException();

        int b = buffer[index];
        index++;

        int i = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            int bytesAvail = numBytesInBuffer - index;
            if (bytesAvail < 1) {
                getMoreBytes();
                if (reachedEOF)
                    throw new EOFException();
            }

            b = buffer[index];
            index++;

            i |= (b & 0x7F) << shift;
        }
        return i;
    }

    private byte[] readBuffer = new byte[8];

    /**
     * Read long value from the bytes This method should be called carefully, it
     * could cause bad performance.
     * 
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public long readLong() throws IOException {
        readFully(readBuffer, 0, 8);
        return (((long) (readBuffer[7]) << 56)
                | ((long) (readBuffer[6] & 0xff) << 48)
                | ((long) (readBuffer[5] & 0xff) << 40)
                | ((long) (readBuffer[4] & 0xff) << 32)
                | ((long) (readBuffer[3] & 0xff) << 24)
                | ((long) (readBuffer[2] & 0xff) << 16)
                | ((long) (readBuffer[1] & 0xff) << 8) | ((long) (readBuffer[0] & 0xff)));
    }

    @Override
    public float readFloat() throws IOException {
        return Float.intBitsToFloat(readInt());
    }

    @Override
    public double readDouble() throws IOException {
        return Double.longBitsToDouble(readLong());
    }

    @Deprecated
    public String readLine() throws IOException {
        throw new AbstractMethodError("not implemented");
    }

    @Deprecated
    public String readUTF() throws IOException {
        return java.io.DataInputStream.readUTF(this);
    }
}
