package odis.io;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import sun.nio.ch.DirectBuffer;

/**
 * A block of memory that can be written by one process and read by another.
 * This class is used to share information between two processes on the same
 * machine. Currently, only support sharing of a "long". This buffer guarantees
 * atomic read/write of its whole content. The buffer is constructed as:
 * [version, content]
 * <p>
 * David: what guarentees the atomic read/write of version?
 * 
 * @author zl
 */
public abstract class InterProcessBuffer implements Closeable {

    private static FileChannel.MapMode getMapMode(String mode) {
        if ("rw".equals(mode)) {
            return FileChannel.MapMode.READ_WRITE;
        } else if ("r".equals(mode)) {
            return FileChannel.MapMode.READ_ONLY;
        } else {
            return null;
        }
    }

    private int version;

    protected RandomAccessFile raf;

    protected FileChannel channel;

    protected ByteBuffer buffer;

    /**
     * Constructor
     * 
     * @param file
     *            the file will be mapped
     * @param mode
     *            the mode to map file, "rw" or "r"
     * @param size
     *            the size to mapped
     * @throws IOException
     *             any I/O error occur
     */
    protected InterProcessBuffer(File file, String mode, long size)
            throws IOException {
        // Create a read-write memory-mapped file
        raf = new RandomAccessFile(file, mode);
        if ("rw".equals(mode)) {
            raf.setLength(size);
        }
        channel = raf.getChannel();
        buffer = channel.map(getMapMode(mode), 0, (int) channel.size());
        version = 0;
    }

    protected void writeVersion() {
        buffer.rewind();
        buffer.putInt(version++);
    }

    protected int readVersion() {
        buffer.rewind();
        return buffer.getInt();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void close() throws IOException {
        // unmap
        if (buffer != null) {
            ((DirectBuffer) buffer).cleaner().clean();
        }
        if (raf != null) {
            raf.close();
        }
    }
}
