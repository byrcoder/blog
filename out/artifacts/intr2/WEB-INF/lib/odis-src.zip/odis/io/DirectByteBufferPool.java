/**
 * @(#)DirectByteBufferPool.java, 2013-3-13. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

import sun.nio.ch.DirectBuffer;
import toolbox.collections.Pair;

/**
 * This class allocated a large DirectBuffer and slice it to several small
 * DirectBuffer to prevent too many malloc and free.
 * 
 * @author zhangduo
 */
public class DirectByteBufferPool {

    private final List<Pair<ByteBuffer, BitSet>> chunks = new ArrayList<Pair<ByteBuffer, BitSet>>();

    private final int bufferSize;

    private final int allocatedChunkSize;

    private final int buffersPerChunk;

    private final ByteOrder order;

    /**
     * Construct a DirectByteBufferPool.
     * 
     * @param bufferSize
     * @param allocatedChunkSize
     * @param order
     */
    public DirectByteBufferPool(int bufferSize, int allocatedChunkSize,
            ByteOrder order) {
        if (Integer.bitCount(bufferSize) != 1) {
            throw new IllegalArgumentException(bufferSize
                    + " is not power of 2");
        }
        if (Integer.bitCount(allocatedChunkSize) != 1) {
            throw new IllegalArgumentException(allocatedChunkSize
                    + " is not power of 2");
        }
        if (allocatedChunkSize < bufferSize) {
            throw new IllegalArgumentException("ChunkSize "
                    + allocatedChunkSize + " is smaller than bufferSize "
                    + bufferSize);
        }
        this.bufferSize = bufferSize;
        this.allocatedChunkSize = allocatedChunkSize;
        this.buffersPerChunk = allocatedChunkSize / bufferSize;
        chunks.add(new Pair<ByteBuffer, BitSet>(
                ByteBuffer.allocateDirect(allocatedChunkSize), new BitSet(
                        buffersPerChunk)));
        this.order = order;
    }

    private static final Field IS_A_MAPPED_BUFFER;

    private static final Constructor<? extends ByteBuffer> CONSTRUCTOR;

    static {
        try {
            IS_A_MAPPED_BUFFER = MappedByteBuffer.class.getDeclaredField("isAMappedBuffer");
            IS_A_MAPPED_BUFFER.setAccessible(true);
            Class<? extends ByteBuffer> directByteBufferClazz = Class.forName(
                    "java.nio.DirectByteBuffer").asSubclass(ByteBuffer.class);
            CONSTRUCTOR = directByteBufferClazz.getDeclaredConstructor(
                    int.class, long.class, Runnable.class);
            CONSTRUCTOR.setAccessible(true);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    private ByteBuffer slice(Pair<ByteBuffer, BitSet> pair, int index) {
        long addr = ((DirectBuffer) pair.getFirst()).address() + (long) index
                * bufferSize;
        BitSet used = pair.getSecond();
        used.set(index);
        ByteBuffer bb;
        try {
            bb = CONSTRUCTOR.newInstance(bufferSize, addr,
                    new Releaser(pair.getSecond(), index));
            IS_A_MAPPED_BUFFER.set(bb, false);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
        bb.order(order);
        return bb;
    }

    private final class Releaser implements Runnable {

        private BitSet used;

        private final int index;

        public Releaser(BitSet used, int index) {
            this.used = used;
            this.index = index;
        }

        @Override
        public void run() {
            synchronized (chunks) {
                if (used == null) {
                    return;
                }
                used.clear(index);
                if (chunks.size() > 1) {
                    if (used.nextSetBit(0) < 0) {
                        for (int i = 0; i < chunks.size(); i++) {
                            Pair<ByteBuffer, BitSet> pair = chunks.get(i);
                            if (pair.getSecond() == used) {
                                chunks.remove(i);
                                ((DirectBuffer) pair.getFirst()).cleaner().clean();
                                break;
                            }
                        }
                    }
                }
                used = null;
            }
        }
    }

    /**
     * Allocate a byte buffer.
     * 
     * @return
     */
    public ByteBuffer allocate() {
        synchronized (chunks) {
            for (Pair<ByteBuffer, BitSet> pair: chunks) {
                BitSet used = pair.getSecond();
                int index = used.nextClearBit(0);
                if (index >= buffersPerChunk) {
                    continue;
                }
                return slice(pair, index);
            }
            Pair<ByteBuffer, BitSet> pair = new Pair<ByteBuffer, BitSet>(
                    ByteBuffer.allocateDirect(allocatedChunkSize), new BitSet(
                            buffersPerChunk));
            chunks.add(pair);
            return slice(pair, 0);
        }
    }

    /**
     * Release a byte buffer.
     * 
     * @param bb
     */
    public void release(ByteBuffer bb) {
        ((DirectBuffer) bb).cleaner().clean();
    }
}
