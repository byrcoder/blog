/**
 * @(#)NIOUtils.java, 2013-2-25. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import sun.nio.ch.DirectBuffer;

/**
 * This class split large SocketChannel write to small pieces.This is used to
 * prevent large DirectByteBuffer allocated by sun.nio.ch.IOUtil which cause
 * Direct Buffer OOM.
 * 
 * @author zhangduo
 */
public class NIOUtils {

    /**
     * write bytes to the given SocketChannel using DirectByteBuffer <tt>bb</tt>
     * as transfer buffer.
     * <p>
     * We do not do range check, please make sure the argument is valid before
     * calling.
     * 
     * @param channel
     * @param buf
     * @param off
     * @param len
     * @param bb
     * @param writeMaxSpinCount
     * @return actual bytes written. Could be 0.
     */
    public static int write(SocketChannel channel, byte[] buf, int off,
            int len, ByteBuffer bb, int writeMaxSpinCount) throws IOException {
        outer: for (int remaining = len; remaining > 0;) {
            bb.clear();
            int toCopy = Math.min(bb.capacity(), remaining);
            bb.put(buf, off, toCopy);
            bb.flip();
            for (int i = 0; i < writeMaxSpinCount; i++) {
                channel.write(bb);
                if (!bb.hasRemaining()) {
                    off += toCopy;
                    remaining -= toCopy;
                    continue outer;
                }
            }
            return len - remaining + toCopy - bb.remaining();
        }
        return len;
    }

    /**
     * Free the given direct buffer.
     * 
     * @param bb
     */
    public static void clean(ByteBuffer bb) {
        if (bb instanceof DirectBuffer) {
            ((DirectBuffer) bb).cleaner().clean();
        }
    }
}
