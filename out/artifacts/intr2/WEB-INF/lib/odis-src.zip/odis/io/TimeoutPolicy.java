/**
 * @(#)TimeoutPolicy.java, 2011-10-27. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

/**
 * <code>RESPONSE_IN_TIME</code> means if we can not get a response within the
 * given timeout, we should make a timeout.<br>
 * <code>COMPLETE_IN_TIME</code> means if we can not finish a request within the
 * given timeout, we should make a timeout.
 * 
 * @author zhangduo
 */
public enum TimeoutPolicy {
    RESPONSE_IN_TIME, COMPLETE_IN_TIME
}
