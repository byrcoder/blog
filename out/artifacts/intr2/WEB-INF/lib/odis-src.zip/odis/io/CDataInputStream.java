/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.DataInput;
import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import odis.util.unsafe.UnsafeHelper;

/**
 * DataInputStream using little-endian byte order (reverse of Java's
 * big-endian). <br>
 * This makes interoperating with C/C++ code easy on Intel machines.<br>
 * <b>attention</b>: readLine() and readUTF() are not implemented.<br>
 * Use {@link odis.serialize.lib.StringWritable#readString(DataInput)}.
 * 
 * @see CDataOutputStream
 * @author river
 */
public class CDataInputStream extends FilterInputStream implements DataInput {

    /**
     * The constructor
     * 
     * @param in
     *            InputStream for buffered
     */
    public CDataInputStream(InputStream in) {
        super(in);
    }

    /**
     * The static function for readFully Byte[] b from InputStream in
     * 
     * @param b
     *            byte array for store data
     * @param in
     *            the InputStream
     * @IOException any I/O error occur
     */
    public static final void readFully(byte[] b, InputStream in)
            throws IOException {
        readFully(b, 0, b.length, in);
    }

    /**
     * The static function for readFully Byte[] b from InputStream in
     * 
     * @param b
     *            byte array for store data
     * @param off
     *            the start offset in array <code>b</code> at which the data is
     *            written
     * @param len
     *            the read length
     * @param in
     *            the InputStream
     * @IOException any I/O error occur
     */
    public static final void readFully(byte[] b, int off, int len,
            InputStream in) throws IOException {
        if (len < 0) {
            throw new IndexOutOfBoundsException();
        }
        int n = 0;
        while (n < len) {
            int count = in.read(b, off + n, len - n);
            if (count < 0) {
                throw new EOFException();
            }
            n += count;
        }
    }

    @Override
    public void readFully(byte[] b, int off, int len) throws IOException {
        readFully(b, off, len, in);
    }

    @Override
    public void readFully(byte[] b) throws IOException {
        readFully(b, 0, b.length);
    }

    /**
     * Skip n bytes in a DataInput.
     * 
     * @param in
     *            the DataInput instance
     * @param n
     *            the number bytes to be skipped
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void skipBytes(DataInput in, int n) throws IOException {
        if (n == 0) {
            return;
        }
        int skipped = in.skipBytes(n);
        if (skipped < n) {
            int s = skipped;
            // this may rarely happens
            while (skipped < n && s > 0) {
                s = in.skipBytes(n - skipped);
                skipped += s;
            }
            while (skipped < n) {
                in.readByte();
                skipped++;
            } // while
        } // if
    }

    @Override
    public int skipBytes(int n) throws IOException {
        int total = 0;
        int cur = 0;

        while ((total < n) && ((cur = (int) in.skip(n - total)) > 0)) {
            total += cur;
        }

        return total;
    }

    /**
     * Reads one input byte from the given InputStream and returns
     * <code>true</code> if that byte is nonzero, <code>false</code> if that
     * byte is zero.
     * 
     * @param in
     *            The InputStream
     * @return the <code>boolean</code> value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static final boolean readBoolean(InputStream in) throws IOException {
        int ch = in.read();
        if (ch < 0) {
            throw new EOFException();
        }
        return (ch != 0);
    }

    @Override
    public boolean readBoolean() throws IOException {
        return readBoolean(in);
    }

    public static final byte readByte(InputStream in) throws IOException {
        return (byte) readUnsignedByte(in);
    }

    @Override
    public byte readByte() throws IOException {
        return readByte(in);
    }

    /**
     * Static function, Reads one input byte from the given InputStream,
     * zero-extends it to type <code>int</code>, and returns the result, which
     * is therefore in the range <code>0</code> through <code>255</code>. This
     * method is suitable for reading the byte written by the
     * <code>writeByte</code> method of interface <code>DataOutput</code> if the
     * argument to <code>writeByte</code> was intended to be a value in the
     * range <code>0</code> through <code>255</code>.
     * 
     * @param in
     *            The InputStream
     * @return the unsigned 8-bit value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static final int readUnsignedByte(InputStream in) throws IOException {
        int ch = in.read();
        if (ch < 0) {
            throw new EOFException();
        }
        return ch;
    }

    @Override
    public int readUnsignedByte() throws IOException {
        return readUnsignedByte(in);
    }

    /**
     * Static function, Reads two input bytes from the given InputStream and
     * returns a <code>short</code> value.
     * 
     * @param in
     *            the InputStream to read
     * @return the 16-bit value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static final short readShort(InputStream in) throws IOException {
        return (short) readUnsignedShort(in);
    }

    /**
     * Static function, Reads two input bytes from the given byte Buffer and
     * returns a <code>short</code> value.
     * 
     * @param buf
     *            the byteBuffer to read
     * @return the 16-bit value read.
     */
    public static final short readShort(byte[] buf, int offset) {
        return (short) readUnsignedShort(buf, offset);
    }

    @Override
    public short readShort() throws IOException {
        return readShort(in);
    }

    /**
     * Reads two input bytes and returns an <code>int</code> value in the range
     * <code>0</code> through <code>65535</code>.
     * 
     * @return the unsigned 16-bit value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static final int readUnsignedShort(InputStream in)
            throws IOException {
        int ch1 = in.read();
        int ch2 = in.read();
        if ((ch1 | ch2) < 0) {
            throw new EOFException();
        }
        return (ch2 << 8) + (ch1 << 0);
    }

    /**
     * Parse an unsigned short from a byte array.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read usignedshort value.
     */
    public static final int readUnsignedShort(byte[] buf, int offset) {
        return (((buf[offset + 1] & 0xFF) << 8) | (buf[offset] & 0xFF));
    }

    @Override
    public int readUnsignedShort() throws IOException {
        return readUnsignedShort(in);
    }

    /**
     * Read a char from InputStream
     * 
     * @param in
     *            the InputStream
     * @return the read char
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final char readChar(InputStream in) throws IOException {
        return (char) readUnsignedShort(in);
    }

    /**
     * Read a char from a byte-array buffer
     * 
     * @param buf
     *            the byte-array buffer to be read from
     * @param start
     *            the start position in the buffer
     * @return the read char
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final char readChar(byte[] buf, int start) throws IOException {
        return (char) readUnsignedShort(buf, start);
    }

    @Override
    public char readChar() throws IOException {
        return readChar(in);
    }

    /**
     * Reads four input bytes from the given InputStream and returns an
     * <code>int</code> value.
     * 
     * @param in
     *            The InputStream
     * @return the <code>int</code> value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static final int readInt(InputStream in) throws IOException {
        int ch1 = in.read();
        int ch2 = in.read();
        int ch3 = in.read();
        int ch4 = in.read();
        if ((ch1 | ch2 | ch3 | ch4) < 0) {
            throw new EOFException();
        }
        return ((ch4 << 24) + (ch3 << 16) + (ch2 << 8) + (ch1 << 0));
    }

    /**
     * Parse an integer from a byte array.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read int value.
     */
    public static int readInt(byte[] bytes, int start) {
        if (bytes == null) {
            throw new NullPointerException();
        } else if (start < 0 || start >= bytes.length || start + 4 <= 0
                || start + 4 > bytes.length) {
            throw new IndexOutOfBoundsException("length=" + bytes.length
                    + ", start=" + start);
        }
        return UnsafeHelper.unsafe.getInt(bytes,
                UnsafeHelper.BYTE_ARRAY_BASE_OFFSET + start);
    }

    @Override
    public int readInt() throws IOException {
        return readInt(in);
    }

    /**
     * Read the int value of format Vint from InputStream.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read int value.
     */
    public static final int readVInt(InputStream in) throws IOException {
        int b = in.read();
        if (b == -1) {
            throw new EOFException();
        }
        int i = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = in.read();
            if (b == -1)
                throw new EOFException();
            i |= (b & 0x7F) << shift;
        } // for shift
        return i;
    }

    /**
     * Read the int value of format Vint from DataInput.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read int value.
     */
    public static final int readVInt(DataInput in) throws IOException {
        byte b = in.readByte();
        int i = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = in.readByte();
            i |= (b & 0x7F) << shift;
        } // for shift
        return i;
    }

    /**
     * Read a int number which was store in a Vint format from the buffer.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read int value.
     */
    public static int readVInt(byte[] bytes, int start) {
        byte b = bytes[start++];
        int i = b & 0x7F;

        for (int shift = 7; (b & 0x80) != 0; shift += 7, start++) {
            b = bytes[start];
            i |= (b & 0x7F) << shift;
        } // for shift

        return i;
    }

    /**
     * Read a int number which was store in a Vint format from the input-stream.
     * 
     * @return Return the read long value.
     * @throws IOException
     */
    public int readVInt() throws IOException {
        return readVInt(in);
    }

    /**
     * Makes a skip as format Vint Value to DataInput
     * 
     * @param in
     *            the DataInput.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static void skipVInt(DataInput in) throws IOException {
        for (int b = in.readByte(); (b & 0x80) != 0; b = in.readByte());
    }

    /**
     * Read the long value from InputStream.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read long value.
     */
    public static final long readLong(InputStream in) throws IOException {
        int ch1 = in.read();
        int ch2 = in.read();
        int ch3 = in.read();
        int ch4 = in.read();
        if ((ch1 | ch2 | ch3 | ch4) < 0) {
            throw new EOFException();
        }
        int ch5 = in.read();
        int ch6 = in.read();
        int ch7 = in.read();
        int ch8 = in.read();
        if ((ch5 | ch6 | ch7 | ch8) < 0) {
            throw new EOFException();
        }
        return ((long) ch8 << 56) + ((long) ch7 << 48) + ((long) ch6 << 40)
                + ((long) ch5 << 32) + ((long) ch4 << 24) + (ch3 << 16)
                + (ch2 << 8) + (ch1 << 0);
    }

    /**
     * Parse a long from a byte array.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read long value.
     */
    public static long readLong(byte[] bytes, int start) {
        if (bytes == null) {
            throw new NullPointerException();
        } else if (start < 0 || start >= bytes.length || start + 8 <= 0
                || start + 8 > bytes.length) {
            throw new IndexOutOfBoundsException("length=" + bytes.length
                    + ", start=" + start);
        }
        return UnsafeHelper.unsafe.getLong(bytes,
                UnsafeHelper.BYTE_ARRAY_BASE_OFFSET + start);
    }

    @Override
    public long readLong() throws IOException {
        return readLong(in);
    }

    /**
     * Read a long number which was stored in a vlong format from the specific
     * input-stream.
     * 
     * @param in
     *            The input stream where data is read from.
     * @return Return the read long value.
     * @throws IOException
     */
    public static final long readVLong(InputStream in) throws IOException {
        int b = in.read();
        if (b == -1) {
            throw new EOFException();
        }
        long l = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = in.read();
            if (b == -1) {
                throw new EOFException();
            }
            l |= ((long) (b & 0x7F)) << shift;
        } // for shift
        return l;
    }

    /**
     * Read a long number which was stored in a vlong format from the specific
     * data-input.
     * 
     * @param in
     *            The data-input where data is read from.
     * @return Return the read long value.
     * @throws IOException
     */
    public static final long readVLong(DataInput in) throws IOException {
        byte b = in.readByte();
        long l = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = in.readByte();
            l |= ((long) (b & 0x7F)) << shift;
        } // for shift
        return l;
    }

    /**
     * Read a long number which was stored in a vlong format from a specified
     * byte-array buffer. NOTE: The caller should assure the buffer is large
     * enough, otherwise an IndexOutOfBoundsException will be raised during
     * reading.
     * 
     * @param bytes
     *            The byte-array buffer.
     * @param start
     *            Where the offset of data in the buffer.
     * @return Return the read long value.
     */
    public static long readVLong(byte[] bytes, int start) {
        byte b = bytes[start++];
        long l = b & 0x7F;

        for (int shift = 7; (b & 0x80) != 0; shift += 7, start++) {
            b = bytes[start];
            l |= ((long) (b & 0x7F)) << shift;
        } // for shift

        return l;
    }

    /**
     * Read a long number which was store in a vlong format from the
     * input-stream.
     * 
     * @return Return the read long value.
     * @throws IOException
     */
    public long readVLong() throws IOException {
        return readVLong(in);
    }

    /**
     * Makes a skip as format Vlong Value to DataInput
     * 
     * @param in
     *            the DataInput.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public static void skipVLong(DataInput in) throws IOException {
        for (int b = in.readByte(); (b & 0x80) != 0; b = in.readByte());
    }

    public static final float readFloat(InputStream in) throws IOException {
        return Float.intBitsToFloat(readInt(in));
    }

    /**
     * Parse a float from a byte array.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read float value.
     */
    public static final float readFloat(byte[] bytes, int start) {
        return Float.intBitsToFloat(readInt(bytes, start));
    }

    /**
     * Read the float value from InputStream.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the float double value.
     */
    @Override
    public float readFloat() throws IOException {
        return readFloat(in);
    }

    /**
     * Read the double value from InputStream.
     * 
     * @param bytes
     *            the buffer to be read
     * @start the start position
     * @return Return the read double value.
     */
    public static final double readDouble(InputStream in) throws IOException {
        return Double.longBitsToDouble(readLong(in));
    }

    public static double readDouble(byte[] bytes, int start) {
        return Double.longBitsToDouble(readLong(bytes, start));
    }

    @Override
    public double readDouble() throws IOException {
        return readDouble(in);
    }

    /**
     * Not implemented.
     */
    @Deprecated
    @Override
    public String readLine() throws IOException {
        throw new UnsupportedOperationException();
    }

    @Deprecated
    @Override
    public String readUTF() throws IOException {
        return java.io.DataInputStream.readUTF(this);
    }
}
