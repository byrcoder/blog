/*
 * Copyright (c) 2005, Outfox Team. Created on Oct 26, 2005
 */
package odis.io;

import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * Wrapper around the native MiniLZO compression lib.
 * 
 * @author zf, river
 */
public class LzoCompression {
    private static final Logger LOG = LogFormatter
            .getLogger(LzoCompression.class.getName());

    private static final int MAX_COMPRESS_RATIO = 10;

    private static final byte[] EMPTY_BYTES = new byte[0];

    /*
     * It could be strange that the compressed data could be private static
     * final int MAX_DECOMPRESS_RATIO = 2;
     */

    /**
     * Load the lib, on windows os, load "lib/liblzocompression.dll"; on linux
     * os, load "liblzocompression.*arch*.so".
     */
    static {
        OdisLibConfig.loadNativeLib("lzocompression");
    }

    private static final int INITIAL_BUFFER_SIZE = 128 * 1024;

    private static ThreadLocal<byte[]> localLZOBuffer = new ThreadLocal<byte[]>() {
        protected byte[] initialValue() {
            return new byte[INITIAL_BUFFER_SIZE];
        }
    };

    /**
     * This context is used when no thread local context assigned by
     * application.
     */
    private static LzoContext globalContext = createContext();

    /**
     * This flag is false when no thread local context initialized, so we can
     * avoid thread local checking in single thread applications, such cowork
     * tasks.
     */
    private static boolean useThreadLocalContext = false;

    private static ThreadLocal<LzoContext> threadLocalContainer = new ThreadLocal<LzoContext>();

    /**
     * Create context for compress and uncompress. All context created should be
     * released by calling {@link #releaseContext(LzoContext)}.
     * 
     * @return
     */
    public static LzoContext createContext() {
        long p = createContext0();
        if (p == 0) {
            throw new RuntimeException("cannot create context");
        }
        return new LzoContext(p);
    }

    /**
     * Release the context.
     * 
     * @param ctx
     */
    public static void releaseContext(LzoContext ctx) {
        long p = ctx.pointer;
        ctx.pointer = 0;
        if (p != 0) {
            releaseContext0(p);
        }
    }

    /**
     * Set the context to be used by current thread.
     * 
     * @param ctx
     */
    public static void setThreadLocalContext(LzoContext ctx) {
        threadLocalContainer.set(ctx);
        useThreadLocalContext = true;
    }

    /**
     * Remove the context associated to this thread.
     */
    public static void removeThreadLocalContext() {
        threadLocalContainer.remove();
    }

    /**
     * compress the data using given context. The context should be previously
     * created by calling {@link #createContext()}. To determine how much buffer
     * should be ok for compressed data, call
     * {@link #getCompressBufferSize(int)}.
     * 
     * @param ctx
     *            the context to be used
     * @param in
     *            the input buffer
     * @param off
     *            the offset where input starts
     * @param len
     *            the length of input data start from offset
     * @param out
     *            the output buffer
     * @param ooff
     *            the offset where output should start from
     * @return if the returned value equals or greater than 0, it should be the
     *         length of returned value; -1 means general error, and -2 means
     *         the output buffer is not large enough.
     */
    public static int compress(LzoContext ctx, byte[] in, int off, int len,
            byte[] out, int ooff) {
        synchronized (ctx) {
            return compress(ctx.pointer, in, off, len, out, ooff);
        }
    }

    /**
     * Uncompress the data using given context. The context should be previously
     * created by calling {@link #createContext()}.
     * 
     * @param ctx
     *            the context to be used
     * @param in
     *            the input buffer(compressed data)
     * @param off
     *            the offset where input data starts
     * @param len
     *            the length of input data start from offset
     * @param out
     *            the output buffer for uncompressed data
     * @param ooff
     *            the offset where output should start from
     * @return if the returned value equals or greater than 0, it should be the
     *         length of returned value; -1 means general error, and -2 means
     *         the output buffer is not large enough.
     */
    public static int uncompress(LzoContext ctx, byte[] in, int off, int len,
            byte[] out, int ooff) {
        synchronized (ctx) {
            return uncompress(ctx.pointer, in, off, len, out, ooff);
        }
    }

    /**
     * This method determine the context to be used by:
     * <ul>
     * <li>Use the thread local context if
     * {@link #setThreadLocalContext(LzoContext)} is called previously
     * <li>Use the global context, and this will cause all the calling threads
     * synchronized on the global context
     * </ul>
     * After context determined, this method simply calls
     * {@link #compress(LzoContext, byte[], int, int, byte[], int)}.
     * 
     * @param in
     * @param off
     * @param len
     * @param out
     * @param ooff
     * @return
     */
    public static int compress(byte[] in, int off, int len, byte[] out, int ooff) {
        LzoContext ctx;
        if (useThreadLocalContext) {
            ctx = threadLocalContainer.get();
            if (ctx == null)
                ctx = globalContext;
        } else {
            ctx = globalContext;
        }
        return compress(ctx, in, off, len, out, ooff);
    }

    /**
     * This method call {@link #compress(long, byte[], int, int, byte[], int)}
     * with the output offset 0.
     * 
     * @param in
     * @param off
     * @param len
     * @param out
     * @return
     */
    public static int compress(byte[] in, int off, int len, byte[] out) {
        return compress(in, off, len, out, 0);
    }

    /**
     * Returns the max size of data after compression.
     * 
     * @param uncompressedLength
     * @return the max size of data after compression
     */
    public static int getCompressBufferSize(int uncompressedLength) {
        return uncompressedLength / 16 + 128 + uncompressedLength;
    }

    /**
     * This method is equals to call
     * "new byte[getCompressBufferSize(uncompressedLength)]".
     * 
     * @param uncompressedLength
     * @return
     */
    public static byte[] createBufferForCompress(int uncompressedLength) {
        int compressedLength = uncompressedLength / 16 + 128
                + uncompressedLength;
        return new byte[compressedLength];
    }

    /**
     * Do compression with LZO1X-1, return the compressed result, or null if
     * error occur.
     * 
     * @param in
     * @param off
     * @param len
     * @deprecated use {@link #compress(byte[], int, int, byte[], int)} instead.
     */
    // FIXME PERF zf: this is allocating a lot of small buffers!
    public static byte[] compress(byte[] in, int off, int len) {

        if (off < 0 || len < 0 || off + len > in.length) {
            return null;
        }

        if (len == 0) {
            return EMPTY_BYTES;
        }

        byte[] lzoBuffer = localLZOBuffer.get();
        int compressedLen = getCompressBufferSize(len);
        if (lzoBuffer.length < compressedLen) {
            lzoBuffer = new byte[compressedLen];
            localLZOBuffer.set(lzoBuffer);
        }
        int rv = compress(in, off, len, lzoBuffer, 0);
        if (rv < 0) {
            LOG.severe("lzo compression error : (in.length = "
                    + in.length
                    + ", off="
                    + off
                    + ", len="
                    + len
                    + ", lzoBuffer.length = "
                    + lzoBuffer.length
                    + ", rvalue = "
                    + rv
                    + ", data=["
                    + HexString.bytesToHex(in, off, len > 64 * 1024 ? 64 * 1024
                            : len) + "]");
            return null;
        } else {
            byte[] result = new byte[rv];
            System.arraycopy(lzoBuffer, 0, result, 0, rv);
            return result;
        }
    }

    /**
     * This method determine the context to be used in the same way as
     * {@link #compress(byte[], int, int, byte[], int)} and call
     * {@link #uncompress(LzoContext, byte[], int, int, byte[], int)}.
     * 
     * @see #compress(byte[], int, int, byte[], int)
     */
    public static int uncompress(byte[] in, int off, int len, byte[] out,
            int ooff) {
        LzoContext ctx;
        if (useThreadLocalContext) {
            ctx = threadLocalContainer.get();
            if (ctx == null)
                ctx = globalContext;
        } else {
            ctx = globalContext;
        }
        return uncompress(ctx, in, off, len, out, ooff);

    }
    /**
     * uncompress the given data 
     * @param in the given data input
     * @param off the offset
     * @param len the length
     * @param out the output buffer
     * @return
     */
    public static int uncompress(byte[] in, int off, int len, byte[] out) {
        return uncompress(in, off, len, out, 0);
    }

    /**
     * Do LZO decompression, return the decompressed result or null if error
     * occur.
     * 
     * @deprecated This method is unsafe when compression ratio could exceed 10.
     * @param in
     * @param off
     * @param len
     */
    public static byte[] uncompress(byte[] in, int off, int len) {
        return uncompress(in, off, len, len * MAX_COMPRESS_RATIO);
    }

    /**
     * Do Lzo decompression.
     * 
     * @param in
     * @param off
     * @param len
     * @param uncompressedLen
     *            The expected uncompressed data length.
     */
    public static byte[] uncompress(byte[] in, int off, int len,
            int uncompressedLen) {
        if (off < 0 || len < 0 || off + len > in.length)
            return null;

        if (len == 0) {
            return EMPTY_BYTES;
        }

        byte[] lzoBuffer = localLZOBuffer.get();
        if (lzoBuffer.length < uncompressedLen) {
            lzoBuffer = new byte[uncompressedLen];
            localLZOBuffer.set(lzoBuffer);
        }

        int rv = uncompress(in, off, len, lzoBuffer, 0);
        if (rv < 0) {
            LOG.severe("lzo decompress error : (in.length = "
                    + in.length
                    + ", off="
                    + off
                    + ", len="
                    + len
                    + ", uncompressedLen="
                    + uncompressedLen
                    + ", lzoBuffer.length="
                    + lzoBuffer.length
                    + ", in.data=["
                    + HexString.bytesToHex(in, off, len > 64 * 1024 ? 64 * 1024
                            : len) + "]");
            return null;
        } else {
            byte[] result = new byte[rv];
            System.arraycopy(lzoBuffer, 0, result, 0, rv);
            return result;
        }
    }

    /**
     * Context class which hold the native context handle(pointer saved as
     * long). We don't use long directly because the context object should be
     * used to synchronize between threads, so the object reference must not be
     * changed during calls.
     * 
     * @author river
     */
    public static class LzoContext {
        private long pointer;

        private LzoContext(long p) {
            this.pointer = p;
        }

        @Override
        protected void finalize() {
            if (pointer != 0)
                LzoCompression.releaseContext(this);
        }
    };

    private static native long createContext0();

    private static native void releaseContext0(long p);

    private static native int compress(long ctx, byte[] in, int off, int len,
            byte[] out, int ooff);

    private static native int uncompress(long ctx, byte[] in, int off, int len,
            byte[] out, int ooff);

}
