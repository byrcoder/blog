/**
 * @(#)ByteBufferInputStream.java, 2010-12-25. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * An <code>InputStream</code> use {@link ByteBuffer} as its internal buffer.
 * 
 * @author zhangduo
 */
public class ByteBufferInputStream extends InputStream {

    private ByteBuffer buffer;

    /**
     * Construct a <code>ByteBufferInputStream</code> with given
     * <code>ByteBuffer</code> as its internal buffer.
     * 
     * @param buffer
     */
    public ByteBufferInputStream(ByteBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public int read() {
        if (buffer.hasRemaining()) {
            return buffer.get() & 0xff;
        }
        return -1;
    }

    @Override
    public int read(byte[] b, int off, int len) {
        if (buffer.hasRemaining()) {
            int toGet = Math.min(buffer.remaining(), len);
            buffer.get(b, off, toGet);
            return toGet;
        }
        return -1;
    }

    /**
     * Set the internal <code>ByteBuffer</code>
     * 
     * @param buffer
     */
    public void setBuffer(ByteBuffer buffer) {
        this.buffer = buffer;
    }
}
