package odis.io;

import java.io.ByteArrayInputStream;

/**
 * A ByteArrayInputStream that can change its input buffer after created.
 * 
 * @author zhangkun
 */
public class ReusableByteArrayInputStream extends ByteArrayInputStream {
    /**
     * Default constructor.
     */
    public ReusableByteArrayInputStream() {
        super(new byte[0]);
    }

    /**
     * Constructor.
     * 
     * @param buf
     */
    public ReusableByteArrayInputStream(byte[] buf) {
        super(buf);
    }

    /**
     * Constructor.
     * 
     * @param buf
     * @param offset
     * @param length
     */
    public ReusableByteArrayInputStream(byte[] buf, int offset, int length) {
        super(buf, offset, length);
    }

    /**
     * Reset the buffer of this input stream.
     * 
     * @param buf
     */
    public void setBuffer(byte[] buf) {
        this.buf = buf;
        this.pos = 0;
        this.mark = 0;
        this.count = buf.length;
    }

    /**
     * Reset the buffer of this input stream.
     * 
     * @param buf
     * @param offset
     * @param length
     */
    public void setBuffer(byte[] buf, int offset, int length) {
        this.buf = buf;
        this.pos = offset;
        this.count = Math.min(offset + length, buf.length);
        this.mark = offset;
    }
}
