package odis.io;

/**
 * BufferOverflowException is thrown when buffer size exceeds a hard-coded limit.
 * We limit the buffer size to avoid OutOfMemoryError, because OOM has no stack
 * trace.
 * 
 * @author river
 */
public class BufferOverflowException extends RuntimeException {

    private static final long serialVersionUID = 5258386666100746684L;

    /**
     * The constructor with the <code>null</code> message and the cause is not
     * initialized, which may be initialized by a call to {@link #initCause}
     */
    public BufferOverflowException() {}

    /**
     * The constructor with the given cause
     * 
     * @param cause
     *            Exception cause
     */
    public BufferOverflowException(Throwable cause) {
        super(cause);
    }

    /**
     * The constructor with the given message and the cause is not initialized,
     * which may be initialized by a call to {@link #initCause}
     * 
     * @param message
     *            the given Exception message
     */
    public BufferOverflowException(String message) {
        super(message);
    }

    /**
     * The constructor with the given message and cause
     * 
     * @param message
     *            Exception message
     * @param cause
     *            Exception cause
     */
    public BufferOverflowException(String message, Throwable cause) {
        super(message, cause);
    }

}
