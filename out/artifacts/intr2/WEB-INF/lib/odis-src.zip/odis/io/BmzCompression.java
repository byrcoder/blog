/*
 * Copyright (c) 2006, Outfox Team. Created on Sep 9, 2006
 */
package odis.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import odis.conf.OdisLibConfig;

/**
 * Bentley-McIlroy pre-compression. This algorithm looks for long commons
 * strings over a large window. This is used before LZO or Gzip to form a
 * two-pass compression scheme.
 * <p>
 * BmzCompression is not thread-safe. If concurrent usage is needed, each thread
 * should use its own BmzCompression object.
 * 
 * @see LzoCompression
 * @author zf
 */
public class BmzCompression {

    private static final int MAX_WINDOW_SIZE = 1 * 1024 * 1024;

    static {
        OdisLibConfig.loadNativeLib("bmzip");
    }

    private int maxPlainLen;

    private long ctx;

    private byte[] buf;

    /**
     * constructor with the given max size of compression window and block size
     * 
     * @param maxPlainLen
     *            max size of compression window (e.g. 64*1024)
     * @param blkSize
     *            compression block size (e.g. 32)
     */
    public BmzCompression(int maxPlainLen, int blkSize) {
        this.maxPlainLen = maxPlainLen;
        ctx = newContext(maxPlainLen, blkSize);
    }

    /**
     * compress the given data 
     * 
     * @return length of the compressed data, &lt;0 if error happened. The
     *         compressed data can be found in {@link #getBuf()}
     */
    public int compress(byte[] in, int off, int len) {
        if (buf == null)
            buf = new byte[maxPlainLen * 2];
        return compress(ctx, in, off, len, buf);
    }

    /**
     * uncompress the given data
     * 
     * @return length of the uncompressed data, &lt;0 if error happened. The
     *         uncompressed data can be found in {@link #getBuf()}
     */
    public int uncompress(byte[] in, int off, int len) {
        if (buf == null)
            buf = new byte[maxPlainLen * 2];
        return uncompress(in, off, len, buf);
    }

    /**
     * Get resulting buffer of {@link #compress(byte[], int, int)} and
     * {@link #uncompress(byte[], int, int)}.
     */
    public byte[] getBuf() {
        return buf;
    }

    /**
     * return the max size of compression window
     * 
     * @return max size of compression window
     */
    public int getMaxPlainLen() {
        return maxPlainLen;
    }

    /**
     * Free the native context when this class is GC'ed
     */
    protected void finalize() throws Throwable {
        super.finalize();
        freeContext(ctx);
    }

    // ///////////////////////////////////////////////////////
    // Native methods
    // ///////////////////////////////////////////////////////
    /**
     * Initialize bmzip.
     * 
     * @return a handle to the context object.
     */
    private static native long newContext(int maxPlainLen, int blkSize);

    private static native void freeContext(long ctx);

    /**
     * Do compression with bmzip.
     * 
     * @param in
     *            input buffer
     * @param off
     *            offset where input starts
     * @param len
     *            length of actual input
     * @param out
     *            output buffer (should be at least 2X the input size)
     * @return length of ouput if >=0, <0 if error
     */
    private static native int compress(long ctx, byte[] in, int off, int len,
            byte[] out);

    /**
     * Do bmzip decompression.
     * 
     * @param out
     *            the output buffer (should be at least sized maxPlainLen)
     * @return length of ouput if >=0, <0 if error.
     */
    public static native int uncompress(byte[] in, int off, int len, byte[] out);

    // ///////////////////////////////////////////////////////
    // Test stub
    // ///////////////////////////////////////////////////////
    @SuppressWarnings("deprecation")
    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            usage();
            return;
        }

        int blkSize = 32;
        int winSize = 64 * 1024;
        boolean bmz = true;
        boolean lzo = false;
        boolean gzip = false;
        boolean uncomp = false;
        int i = 0;
        boolean record = false;

        while (i < args.length && args[i].startsWith("-")) {
            String a = args[i];
            if ("-b".equals(a)) {
                blkSize = Integer.parseInt(args[++i]);
            } else if ("-w".equals(a)) {
                winSize = 1024 * Integer.parseInt(args[++i]);
            } else if ("-lzo".equals(a)) {
                lzo = true;
            } else if ("-gzip".equals(a)) {
                gzip = true;
            } else if ("-nobmz".equals(a)) {
                bmz = false;
            } else if ("-record".equals(a)) {
                record = true;
            } else {
                System.out.println("Unknown option: " + a);
                System.exit(1);
            }
            i++;
        }

        if (i + 3 != args.length) {
            usage();
            System.exit(1);
        }
        if (args[i].equals("d"))
            uncomp = true;
        else if (!args[i].equals("c")) {
            usage();
            System.exit(1);
        }
        String inf = args[i + 1];
        String outf = args[i + 2];

        DataInputStream in = new DataInputStream(new BufferedInputStream(
                new FileInputStream(inf)));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(
                new FileOutputStream(outf)));

        // do compression/uncompression
        BmzCompression bmzc = new BmzCompression(record ? MAX_WINDOW_SIZE
                : winSize, blkSize);
        byte[] ibuf = new byte[MAX_WINDOW_SIZE];
        int len;
        byte[] data;
        int chunk = 0;

        int recordSizeHist[] = new int[1024];
        int recordCount = 0;
        long totalSize = 0;

        if (!uncomp) {
            // compression
            while (true)
                try {
                    int recordSize;
                    if (record) {
                        recordSize = in.readInt();
                        if (recordSize > MAX_WINDOW_SIZE - 4)
                            throw new RuntimeException("Record too long: "
                                    + recordSize);
                        ibuf[0] = (byte) ((recordSize >> 24) & 0xff);
                        ibuf[1] = (byte) ((recordSize >> 16) & 0xff);
                        ibuf[2] = (byte) ((recordSize >> 8) & 0xff);
                        ibuf[3] = (byte) (recordSize & 0xff);
                        len = in.read(ibuf, 4, recordSize);
                        len += 4;

                        int kb = recordSize / 1024;
                        if (kb > 1023)
                            kb = 1023;
                        recordSizeHist[kb]++;
                        if (len <= 0 && recordSize > 0)
                            throw new RuntimeException(
                                    "Premature end-of-file. recordsize="
                                            + recordSize + ", r=" + len);
                        recordCount++;
                        totalSize += recordSize;
                    } else
                        len = in.read(ibuf, 0, winSize);
                    if (len <= 0)
                        break;
                    /*
                     * if (len != winSize)
                     * System.out.println("chunk="+chunk+", len="+len);
                     */
                    data = ibuf;
                    if (bmz) {
                        len = bmzc.compress(ibuf, 0, len);
                        if (len < 0)
                            throw new RuntimeException("BMZ failure: " + len);
                        data = bmzc.getBuf();
                    }
                    if (lzo) {
                        data = LzoCompression.compress(data, 0, len);
                        if (data == null)
                            throw new RuntimeException("LZO failure");
                        len = data.length;
                    }
                    if (gzip) {
                        ByteArrayOutputStream o = new ByteArrayOutputStream();
                        GZIPOutputStream go = new GZIPOutputStream(o);
                        go.write(data, 0, len);
                        go.close();
                        data = o.toByteArray();
                        len = data.length;
                    }
                    out.writeInt(len);
                    out.write(data, 0, len);
                    chunk++;
                } catch (EOFException e) {
                    break;
                }
        } else {
            // uncompression
            byte[] gzipbuf = null;
            if (gzip)
                gzipbuf = new byte[MAX_WINDOW_SIZE];
            while (true)
                try {
                    len = in.readInt();
                    if (in.read(ibuf, 0, len) == -1)
                        break;
                    data = ibuf;
                    if (gzip) {
                        ByteArrayInputStream bi = new ByteArrayInputStream(
                                ibuf, 0, len);
                        GZIPInputStream gi = new GZIPInputStream(bi);
                        len = 0;
                        int l;
                        while ((l = gi.read(gzipbuf, len, gzipbuf.length - len)) > 0) {
                            len += l;
                        }
                        data = gzipbuf;
                    }
                    if (lzo) {
                        data = LzoCompression.uncompress(data, 0, len,
                                MAX_WINDOW_SIZE);
                        if (data == null)
                            throw new RuntimeException(
                                    "LZO decompression errro.");
                        len = data.length;
                    }
                    if (bmz) {
                        len = bmzc.uncompress(data, 0, len);
                        if (len < 0)
                            throw new RuntimeException(
                                    "BMZ decompression error: " + len);
                        data = bmzc.getBuf();
                    }
                    /*
                     * if (len != winSize)
                     * System.out.println("chunk="+chunk+",len="+len);
                     */
                    out.write(data, 0, len);
                    chunk++;
                } catch (EOFException e) {
                    // normal, end of file
                    break;
                }
        }

        if (record) {
            System.out.println("Record size histogram:");
            for (int j = 0; j < recordSizeHist.length; j++)
                if (recordSizeHist[j] != 0)
                    System.out.println(j + "KB-" + (j + 1) + "KB\t"
                            + recordSizeHist[j]);
            System.out.println("In total " + recordCount
                    + ", mean record size " + (totalSize / recordCount));
        }

        in.close();
        out.close();
    }

    private static void usage() {
        System.out
                .println("bmz [-b <blk_size>] [-w <win_size>] [-record] [-lzo] [-gzip] [-nobmz] {c|d} <infile> <outfile>");
        System.out
                .println("  -b     specify compression block size in bytes, default 32");
        System.out.println("  -w     specify window size in KB, default 64KB");
        System.out
                .println("  -record   use per-record compression rather than fixed-sized window");
        System.out
                .println("  -lzo   use minilzo as second stage compression/uncompression");
        System.out
                .println("  -gzip  use gzip as second stage compression/uncompression");
        System.out
                .println("  -nobmz do not use bmz, use with -lzo/-gzip to test lzo/gzip only");
    }
}
