/**
 * @(#)LzoInputStream.java, 2007-8-18. Copyright 2007 Yodao, Inc. All rights
 *                                     reserved. YODAO PROPRIETARY/CONFIDENTIAL.
 *                                     Use is subject to license terms.
 */
package odis.io;

import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import toolbox.misc.EmptyInstance;

/**
 * InputStream which uncompress the data by lzo during reading.
 * 
 * @author river
 */
public class LzoInputStream extends FilterInputStream {

    private byte[] compressedBuffer = EmptyInstance.BYTES;

    private byte[] buffer = EmptyInstance.BYTES;

    private int count = 0; // available bytes in buffer

    private int pos = 0; // pos in buffer

    /**
     * construct a LzoInputStream with the given InputStream
     * 
     * @param in
     *            the given InputStream for Lzo
     */
    public LzoInputStream(InputStream in) {
        super(in);
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        int avail = count - pos;
        if (avail <= 0) {
            fill();
            avail = count - pos;
            if (avail <= 0)
                return -1;
        }
        int toCopy = (avail < len) ? avail : len;
        System.arraycopy(buffer, pos, b, off, toCopy);
        pos += toCopy;
        return toCopy;
    }

    @Override
    public int read() throws IOException {
        int avail = count - pos;
        if (avail <= 0) {
            fill();
            avail = count - pos;
            if (avail <= 0)
                return -1;
        }
        return (buffer[pos++]) & 0xff;
    }

    @Override
    public int read(byte[] b) throws IOException {
        return read(b, 0, b.length);
    }

    @Override
    public void close() throws IOException {
        super.close();
    }

    private void fill() throws IOException {
        int sourceSize, compressedSize;
        try {
            sourceSize = CDataInputStream.readInt(in);
            compressedSize = CDataInputStream.readInt(in);
        } catch (EOFException e) {
            return;
        }

        if (compressedSize > compressedBuffer.length) {
            compressedBuffer = Limit
                    .createBuffer(((compressedSize + 1023) / 1024) * 1024);
        }
        if (sourceSize > buffer.length) {
            buffer = Limit.createBuffer(((sourceSize + 1023) / 1024) * 1024);
        }
        int toRead = compressedSize;
        int readPos = 0;
        while (toRead > 0) {
            int readIn = in.read(compressedBuffer, readPos, toRead);
            if (readIn < 0) {
                break;
            }
            toRead -= readIn;
            readPos += readIn;
        }
        int size = LzoCompression.uncompress(compressedBuffer, 0,
                compressedSize, buffer);
        if (size != sourceSize) {
            throw new IOException("lzo uncompression failed: source size is "
                    + sourceSize + ", but uncompressed size is " + size);
        }
        count = size;
        pos = 0;
    }

}
