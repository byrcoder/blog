package odis.io;

/**
 * The information of a file/folder.
 * 
 * @author david
 */
public abstract class FileInfo {
    protected Path path;

    /**
     * Constructor.
     */
    public FileInfo() {
        path = new Path("/");
    }

    /**
     * Constructor.
     * 
     * @param path
     *            the path of the info
     */
    public FileInfo(Path path) {
        this.path = path;
    }

    /**
     * Returns the path of the file/folder.
     * 
     * @return the path of the file/folder
     */
    public Path getPath() {
        return path;
    }

    /**
     * For a file, returns the number of bytes; for a folder, undefined.
     * 
     * @return the number of bytes for a file; undefined for a folder.
     */
    public abstract long getLength();

    /**
     * Returns true for a folder, false otherwise.
     * 
     * @return true for a folder, false otherwise
     */
    public abstract boolean isDir();

    /**
     * For a file, the last modified time; for a folder, implementation
     * dependent.
     * 
     * @return the last modified time
     */
    public abstract long getLastModified();

    /**
     * Returns true if this is a simbolic link
     * 
     * @return true if this is a simbolic link
     */
    public abstract boolean isSLink();

    /**
     * Returns path if this is not a simbolic link; the target if isSLink.
     * 
     * @return path if this is not a simbolic link; the target if isSLink
     */
    public abstract Path getTarget();
}
