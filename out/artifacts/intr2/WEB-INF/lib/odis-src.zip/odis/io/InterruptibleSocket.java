/**
 * @(#)InterruptibleSocket.java, 2012-10-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * Default ByteBufferPool.
 * 
 * @author zhangduo
 */
final class ByteBufferPoolHolder {

    static final int ALLOCATED_CHUNK_SIZE = 16 * 1024 * 1024;

    static final int BUFFER_SIZE = 8 * 1024;

    static final DirectByteBufferPool POOL = new DirectByteBufferPool(
            BUFFER_SIZE, ALLOCATED_CHUNK_SIZE, ByteOrder.LITTLE_ENDIAN);
}

/**
 * A helper class that make a socket interruptible when write, and also, a write
 * operation can have a timeout.
 * <p>
 * It uses selector and non-blocking socket channel internally, but acts as a
 * blocking socket.
 * <p>
 * The class is not thread safe.
 * 
 * @author zhangduo
 */
public class InterruptibleSocket implements Closeable {

    private static final Logger LOG = LogFormatter.getLogger(InterruptibleSocket.class);

    private final InetSocketAddress remoteAddr;

    private final SocketChannel channel;

    private final Selector selector;

    private TimeoutPolicy timeoutPolicy = TimeoutPolicy.COMPLETE_IN_TIME;

    private long timeout;

    private boolean closed;

    private final InputStreamImpl in;

    private final OutputStreamImpl out;

    private final DirectByteBufferPool pool;

    /**
     * Create an InterruptibleSocket.
     * 
     * @param hostname
     * @param port
     * @param timeout
     * @throws IOException
     */
    public InterruptibleSocket(String hostname, int port, long timeout)
            throws IOException {
        this(new InetSocketAddress(hostname, port), timeout);
    }

    /**
     * Create an InterruptibleSocket.
     * 
     * @param addr
     * @param timeout
     * @throws IOException
     */
    public InterruptibleSocket(InetSocketAddress addr, long timeout)
            throws IOException {
        this(addr, timeout, ByteBufferPoolHolder.POOL);
    }

    /**
     * Create an InterruptibleSocket.
     * 
     * @param addr
     * @param timeout
     * @param pool
     * @throws IOException
     */
    public InterruptibleSocket(InetSocketAddress addr, long timeout,
            DirectByteBufferPool pool) throws IOException {
        boolean succ = false;
        SocketChannel channel = null;
        Selector selector = null;
        try {
            channel = SocketChannel.open();
            channel.configureBlocking(false);
            selector = Selector.open();
            channel.connect(addr);
            channel.register(selector, SelectionKey.OP_CONNECT);
            if (selector.select(timeout) > 0) {
                if (!channel.finishConnect()) {
                    throw new IOException("connection failed though "
                            + "OP_CONNECT selection key ready.");
                }
                selector.selectedKeys().clear();
                channel.register(selector, SelectionKey.OP_READ);
            } else {
                throw new SocketTimeoutException("Timeout(" + timeout
                        + "ms) waiting to connect to " + addr);
            }
            succ = true;
        } finally {
            if (!succ) {
                MiscUtils.safeClose(selector);
                MiscUtils.safeClose(channel);
            }
        }
        this.remoteAddr = addr;
        this.channel = channel;
        this.selector = selector;
        this.timeout = timeout;
        this.in = new InputStreamImpl();
        this.out = new OutputStreamImpl();
        this.pool = pool;
    }

    public TimeoutPolicy getTimeoutPolicy() {
        return timeoutPolicy;
    }

    public void setTimeoutPolicy(TimeoutPolicy timeoutPolicy) {
        this.timeoutPolicy = timeoutPolicy;
    }

    public long getTimeout() {
        return timeout;
    }

    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }

    public void setTcpNoDelay(boolean on) throws SocketException {
        channel.socket().setTcpNoDelay(on);
    }

    public InetSocketAddress getRemoteAddress() {
        return remoteAddr;
    }

    public InputStream getInputStream() {
        return in;
    }

    public OutputStream getOutputStream() {
        return out;
    }

    /**
     * Test whether the connection is still valid.
     * <p>
     * This method should only called when we pick a connection from connection
     * pool, so it should not be readable unless the remote side close the
     * connection(which make SocketChannel readable and read will return -1).
     * 
     * @return
     */
    public boolean valid() {
        if (closed) {
            return false;
        }
        try {
            return selector.selectNow() == 0;
        } catch (Exception e) {
            LOG.log(Level.WARNING, "test connection failed", e);
            return false;
        }
    }

    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }
        closed = true;
        MiscUtils.safeClose(selector);
        MiscUtils.safeClose(channel);
    }

    private void assertOpen() throws IOException {
        if (closed) {
            throw new IOException("Socket already closed");
        }
    }

    private long calcTimeout(long startTime) throws SocketTimeoutException {
        if (timeout == 0) {
            return 0;
        } else if (TimeoutPolicy.COMPLETE_IN_TIME.equals(timeoutPolicy)) {
            long toWait = timeout - (System.currentTimeMillis() - startTime);
            if (toWait <= 0) {
                throw new SocketTimeoutException("Socket operation from "
                        + remoteAddr + " timeout(" + timeout + ")");
            }
            return toWait;
        } else {
            return timeout;
        }
    }

    private int select(long timeout) throws IOException {
        if (timeout > 0) {
            return selector.select(timeout);
        } else {
            return selector.select();
        }
    }

    /**
     * Read bytes into the given ByteBuffer from this socket.
     * 
     * @param bb
     * @return
     * @throws IOException
     */
    public int read(ByteBuffer bb) throws IOException {
        if (!bb.hasRemaining()) {
            return 0;
        }
        long startTime = System.currentTimeMillis();
        outer: for (;;) {
            if (select(calcTimeout(startTime)) > 0) {
                try {
                    int readBytes = 0;
                    do {
                        int read = channel.read(bb);
                        if (read == -1) {
                            return readBytes == 0 ? -1 : readBytes;
                        }
                        if (read == 0) {
                            if (readBytes > 0) {
                                return readBytes;
                            } else {
                                continue outer;
                            }
                        } else {
                            readBytes += read;
                        }
                    } while (bb.hasRemaining());
                    return readBytes;
                } finally {
                    selector.selectedKeys().clear();
                }
            } else {
                // select will quit if the current thread is interrupted, 
                // this usually because we want to quit, so throw an 
                // exception instead of retry.
                throw new SocketTimeoutException("Socket read from "
                        + remoteAddr + " timeout(" + timeout + ")");
            }
        }
    }

    /**
     * Write out bytes in the given ByteBuffer to this socket.
     * 
     * @param bb
     * @throws IOException
     */
    public void write(ByteBuffer bb) throws IOException {
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < WRITE_MAX_SPIN_COUNT; i++) {
            channel.write(bb);
            if (!bb.hasRemaining()) {
                return;
            }
        }
        channel.register(selector, SelectionKey.OP_WRITE);
        while (bb.hasRemaining()) {
            if (select(calcTimeout(startTime)) > 0) {
                try {
                    while (channel.write(bb) > 0 && bb.hasRemaining());
                } finally {
                    selector.selectedKeys().clear();
                }
            } else {
                // although the socket should be closed right after the
                // timeout exception thrown, we should unregister the write
                // event to avoid 100% cpu usage if someone try to read
                // something later.
                channel.register(selector, SelectionKey.OP_READ);
                // select will quit if the current thread is interrupted, 
                // this usually because we want to quit, so throw an 
                // exception instead of retry.
                throw new SocketTimeoutException("socket write to "
                        + remoteAddr + " timeout(" + timeout + ")");
            }
        }
        channel.register(selector, SelectionKey.OP_READ);
    }

    private class InputStreamImpl extends InputStream {

        @Override
        public int read() throws IOException {
            ByteBuffer bb = pool.allocate();
            try {
                bb.limit(1);
                if (InterruptibleSocket.this.read(bb) < 0) {
                    return -1;
                }
                return bb.get(0) & 0xFF;
            } finally {
                pool.release(bb);
            }
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if ((off | len | (off + len) | (b.length - (off + len))) < 0) {
                throw new IndexOutOfBoundsException("bad offset (offset = "
                        + off + ", len = " + len + ", buffer_size = "
                        + b.length + ")");
            } else if (len == 0) {
                return 0;
            }
            assertOpen();
            ByteBuffer bb = pool.allocate();
            try {
                bb.limit(Math.min(len, bb.capacity()));
                int read = InterruptibleSocket.this.read(bb);
                if (read < 0) {
                    return -1;
                }
                bb.flip();
                bb.get(b, off, read);
                return read;
            } finally {
                pool.release(bb);
            }
        }

    }

    private static final int WRITE_MAX_SPIN_COUNT = 16;

    private class OutputStreamImpl extends OutputStream {

        @Override
        public void write(int b) throws IOException {
            ByteBuffer bb = pool.allocate();
            try {
                bb.put((byte) b);
                bb.flip();
                InterruptibleSocket.this.write(bb);
            } finally {
                pool.release(bb);
            }
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            if ((off | len | (off + len) | (b.length - (off + len))) < 0) {
                throw new IndexOutOfBoundsException("bad offset (offset = "
                        + off + ", len = " + len + ", buffer_size = "
                        + b.length + ")");
            } else if (len == 0) {
                return;
            }
            ByteBuffer bb = pool.allocate();
            try {
                for (;;) {
                    int toCopy = Math.min(bb.capacity(), len);
                    bb.put(b, off, toCopy);
                    bb.flip();
                    InterruptibleSocket.this.write(bb);
                    len -= toCopy;
                    if (len == 0) {
                        break;
                    }
                    off += toCopy;
                    bb.clear();
                }
            } finally {
                pool.release(bb);
            }
        }
    }

    @Override
    public String toString() {
        Socket socket = channel.socket();
        return "InterruptableSocket [local=" + socket.getLocalSocketAddress()
                + " remote=" + socket.getRemoteSocketAddress() + "]";
    }

}
