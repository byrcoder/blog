/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.ByteArrayOutputStream;

/**
 * A subclass of ByteArrayOutputStream, add the function to directly get buffer
 * and buffer size
 * 
 * @author guodd
 */
public class DirectByteArrayOutputStream extends ByteArrayOutputStream {
    /**
     * Constructor with default size
     */
    public DirectByteArrayOutputStream() {
        super();
    }

    /**
     * Constructor
     * 
     * @param size
     *            the size of Array
     */
    public DirectByteArrayOutputStream(int size) {
        super(size);
    }

    /**
     * Constructor
     * 
     * @param buf
     * @param size
     */
    public DirectByteArrayOutputStream(byte[] buf) {
        setBuffer(buf);
    }

    /**
     * Constructor
     * 
     * @param buf
     * @param size
     */
    public DirectByteArrayOutputStream(byte[] buf, int off) {
        setBuffer(buf, off);
    }

    /**
     * Get the byte array buffer
     * 
     * @return the buffer
     */
    public byte[] getBuffer() {
        return buf;
    }

    /**
     * get the buffer size
     * 
     * @return the buffer size
     */
    public int getBufferSize() {
        return count;
    }

    /**
     * Set array buffer
     */
    public void setBuffer(byte[] buf) {
        setBuffer(buf, 0);
    }

    /**
     * Set array buffer, begin from off
     * 
     * @param buf
     * @param off
     */
    public void setBuffer(byte[] buf, int off) {
        this.buf = buf;
        this.count = off;
    }

}
