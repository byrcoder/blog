/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 11, 2006
 */
package odis.io;

import java.io.IOException;

/**
 * Stream that permits seeking.
 * 
 * @author guodd
 */
public interface Seekable {
    /**
     * Seek to the given offset from the start of the file. The next read() will
     * be from that location. Can't seek past the end of the file.
     */
    void seek(long pos) throws IOException;
}
