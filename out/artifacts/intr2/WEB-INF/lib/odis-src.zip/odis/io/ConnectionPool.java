/**
 * @(#)ConnectionPool.java, 2012-8-2. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.io.Closeable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * Caching connections to many addresses.
 * 
 * @author zhangduo
 */
public class ConnectionPool<T extends Closeable> implements Closeable {

    /**
     * Validator used when pick connection from pool.
     */
    public static interface ConnectionValidator<T> {
        /**
         * Return whether the given <tt>conn</tt> is valid.
         * 
         * @param conn
         * @return
         */
        boolean isValid(T conn);
    }

    private static final Logger LOG = LogFormatter.getLogger(ConnectionPool.class);

    private final int corePoolSizePerAddr;

    private final int maximumPoolSizePerAddr;

    private final long keepAliveTime;

    private final ConnectionValidator<T> validator;

    private final Future<?> checkIdleConnTask;

    private static final class PoolEntry<T extends Closeable> {
        public final T conn;

        public final long activeTime = System.currentTimeMillis();

        public PoolEntry(T conn) {
            this.conn = conn;
        }
    }

    private final ConcurrentMap<String, Deque<PoolEntry<T>>> poolMap = new ConcurrentHashMap<String, Deque<PoolEntry<T>>>();

    private void cleanIdleConnections() {
        long currentTime = System.currentTimeMillis();
        List<T> toBeClosed = new ArrayList<T>();
        for (Map.Entry<String, Deque<PoolEntry<T>>> entry: poolMap.entrySet()) {
            Deque<PoolEntry<T>> pool = entry.getValue();
            synchronized (pool) {
                while (pool.size() > corePoolSizePerAddr) {
                    PoolEntry<T> pe = pool.peekLast();
                    if (currentTime - pe.activeTime >= keepAliveTime) {
                        toBeClosed.add(pe.conn);
                        pool.pollLast();
                    } else {
                        break;
                    }
                }
            }
        }
        for (T conn: toBeClosed) {
            LOG.info("Close idle connection " + conn);
            MiscUtils.safeClose(conn);
        }
    }

    /**
     * Create a connection pool.
     * 
     * @param corePoolSizePerAddr
     *            the number of connections to keep for an address, even if they
     *            are idle.
     * @param maximumPoolSizePerAddr
     *            the maximum number of connections to allow in the pool for an
     *            address.
     * @param keepAliveTime
     *            when the number of connections for an address is greater than
     *            the core, this is the maximum time that excess idle
     *            connections will wait before closing. 0 means do not check.
     * @param validator
     *            test whether a connection is valid when pick from pool.
     *            <tt>null</tt> means do not test.
     * @param checkIdleConnTaskPool
     *            the thread pool use to schedule close idle connection task.
     */
    public ConnectionPool(int corePoolSizePerAddr, int maximumPoolSizePerAddr,
            long keepAliveTime, ConnectionValidator<T> validator,
            ScheduledExecutorService checkIdleConnTaskPool) {
        this.corePoolSizePerAddr = corePoolSizePerAddr;
        this.maximumPoolSizePerAddr = maximumPoolSizePerAddr;
        this.keepAliveTime = keepAliveTime;
        this.validator = validator;
        if (keepAliveTime > 0) {
            checkIdleConnTask = checkIdleConnTaskPool.scheduleAtFixedRate(
                    new Runnable() {

                        @Override
                        public void run() {
                            Thread currentThread = Thread.currentThread();
                            String name = currentThread.getName();
                            currentThread.setName("Check Idle Connection Thread");
                            try {
                                cleanIdleConnections();
                            } catch (Throwable t) {
                                LOG.log(Level.WARNING,
                                        "clean idle connection failed", t);
                            }
                            currentThread.setName(name);
                        }
                    }, keepAliveTime, keepAliveTime / 2, TimeUnit.MILLISECONDS);
        } else {
            checkIdleConnTask = null;
        }
    }

    public T getConnection(String addr) {
        Deque<PoolEntry<T>> pool = poolMap.get(addr);
        if (pool == null) {
            return null;
        }
        for (;;) {
            PoolEntry<T> pe;
            synchronized (pool) {
                pe = pool.pollFirst();
            }
            if (pe == null) {
                return null;
            }
            if (validator == null || validator.isValid(pe.conn)) {
                return pe.conn;
            } else {
                LOG.warning("Close broken connection " + pe.conn);
                MiscUtils.safeClose(pe.conn);
            }
        }
    }

    /**
     * release connection.
     * <p>
     * connection maybe put into pool or close directly.
     * 
     * @param addr
     * @param conn
     */
    public void releaseConnection(String addr, T conn) {
        Deque<PoolEntry<T>> pool = poolMap.get(addr);
        if (pool == null) {
            pool = new ArrayDeque<PoolEntry<T>>();
            Deque<PoolEntry<T>> previousPool = poolMap.putIfAbsent(addr, pool);
            if (previousPool != null) {
                pool = previousPool;
            }
        }

        synchronized (pool) {
            if (pool.size() < maximumPoolSizePerAddr) {
                pool.offerFirst(new PoolEntry<T>(conn));
                return;
            }
        }
        LOG.info("Close connection " + conn + " because of pool overflow("
                + maximumPoolSizePerAddr + ")");
        MiscUtils.safeClose(conn);
    }

    /**
     * Discard a connection.
     * 
     * @param conn
     */
    public void discardConnection(T conn) {
        if (conn != null) {
            LOG.info("Discard connection " + conn);
            MiscUtils.safeClose(conn);
        }
    }

    /**
     * Close all connections in the pool.
     */
    public void clear() {
        for (Deque<PoolEntry<T>> pool: poolMap.values()) {
            synchronized (pool) {
                for (PoolEntry<T> pe: pool) {
                    MiscUtils.safeClose(pe.conn);
                }
                pool.clear();
            }
        }
        poolMap.clear();
    }

    /**
     * Return how many addresses we have cached for.
     * 
     * @return
     */
    public int addrSize() {
        return poolMap.size();
    }

    /**
     * Close the pool and close all connections in pool.
     */
    @Override
    public void close() {
        if (checkIdleConnTask != null) {
            checkIdleConnTask.cancel(false);
        }
        clear();
    }
}
