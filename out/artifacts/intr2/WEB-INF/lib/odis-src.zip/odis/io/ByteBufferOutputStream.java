/**
 * @(#)ByteBufferOutputStream.java, 2010-12-25. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ReadOnlyBufferException;

/**
 * An <code>OutputStream</code> which data is written to a {@link ByteBuffer}.
 * 
 * @author zhangduo
 */
public class ByteBufferOutputStream extends OutputStream {

    private ByteBuffer buffer;

    /**
     * Construct a <code>ByteBufferOutputStream</code> with given
     * <code>ByteBuffer</code> as its internal buffer.
     * 
     * @param buffer
     */
    public ByteBufferOutputStream(ByteBuffer buffer) {
        if (buffer.isReadOnly()) {
            throw new ReadOnlyBufferException();
        }
        this.buffer = buffer;
    }

    @Override
    public void write(int b) {
        buffer.put((byte) (b & 0xff));
    }

    @Override
    public void write(byte[] b, int off, int len) {
        buffer.put(b, off, len);
    }

    /**
     * Set the internal <code>ByteBuffer</code>
     * 
     * @param buffer
     */
    public void setBuffer(ByteBuffer buffer) {
        this.buffer = buffer;
    }

}
