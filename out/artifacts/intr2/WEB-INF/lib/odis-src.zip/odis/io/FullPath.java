package odis.io;

/**
 * A data-structure containing both the file-system and the path. The full-path
 * will be represented by a single string in the format of <path>@<fs> e.g.
 * /home/data@local, /home/data@tb002:8089
 * 
 * @author David
 */
public class FullPath implements Comparable<FullPath> {
    private Path path;

    private String fs;

    private void parse(String fsPath) {
        int p = fsPath.lastIndexOf('@');
        if (p == -1) {
            fs = "local";
            path = new Path(fsPath);
        } else {
            fs = fsPath.substring(p + 1);
            path = new Path(fsPath.substring(0, p));
        } // else
    }

    /**
     * Construction from a full-path string.
     * 
     * @param fsPath
     *            the full-path string.
     */
    public FullPath(String fsPath) {
        parse(fsPath);
    }

    /**
     * Construction from a file-system name and the path.
     * 
     * @param fs
     *            the file-system name
     * @param path
     *            the path
     */
    public FullPath(String fs, String path) {
        this.fs = fs;
        this.path = new Path(path);
    }

    /**
     * Construction from a file-system name and the path.
     * 
     * @param fs
     *            the file-system name
     * @param path
     *            the path
     */
    public FullPath(String fs, Path path) {
        this.fs = fs;
        this.path = path;
    }

    @Override
    public String toString() {
        return path + "@" + fs;
    }

    /**
     * Fetch the file-system name part of the full-path.
     * 
     * @return the file-system name part
     */
    public String getFs() {
        return fs;
    }

    /**
     * Fetch the path part of the full-path.
     * 
     * @return the path part
     */
    public Path getPath() {
        return path;
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((fs == null) ? 0 : fs.hashCode());
        result = PRIME * result + ((path == null) ? 0 : path.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final FullPath other = (FullPath) obj;
        if (fs == null) {
            if (other.fs != null)
                return false;
        } else if (!fs.equals(other.fs))
            return false;
        if (path == null) {
            if (other.path != null)
                return false;
        } else if (!path.equals(other.path))
            return false;
        return true;
    }

    @Override
    public int compareTo(FullPath o) {
        return this.toString().compareTo(o.toString());
    }

    /**
     * Return a new full-path with a sub-path catenated to the current path, and
     * the file-system name remains unchanged.
     * 
     * @param sub
     *            the sub-path to be cantenated
     * @return the new full-path
     */
    public FullPath cat(String sub) {
        return new FullPath(fs, path.cat(sub));
    }

    /**
     * Return a new full-path with a new file-system name, and the path remains
     * unchanged.
     * 
     * @param fs
     *            the new file-system name
     * @return the new full-path
     */
    public FullPath fs(String fs) {
        return new FullPath(fs, path);
    }

    /**
     * Returns a new full-path with a path, and the file-system name remains
     * unchanged.
     * 
     * @param path
     *            the new path
     * @return the new full-path
     */
    public FullPath path(Path path) {
        return new FullPath(fs, path);
    }
}
