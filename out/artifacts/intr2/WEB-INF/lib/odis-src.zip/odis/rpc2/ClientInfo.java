/**
 * @(#)ClientInfo.java, 2010-8-16. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.net.InetSocketAddress;
import java.util.Map;

/**
 * All information of a {@link RPC} client
 * 
 * @author zhangduo
 */
public class ClientInfo {

    /**
     * a clientName is set by RPCClient, user can not modify it usually is the
     * machine name and prcess Id
     */
    public final String clientName;

    /**
     * client address
     */
    public final InetSocketAddress clientAddr;

    /**
     * rpc version
     */
    public final int rpcVersion;

    /**
     * protocol of this client, a RPC server may have more than 1 protocols
     */
    public final Class<?> protocol;

    /**
     * a client's domain
     */
    public final String domain;

    /**
     * a user can set a Client's username, this is useful when RPC server need
     * check authentication
     */
    public final String username;

    /**
     * all client properties
     */
    public final Map<String, String> clientProps;

    /**
     * Constructor with initial values for all fields.
     * 
     * @param clientName
     * @param clientAddr
     * @param rpcVersion
     * @param protocol
     * @param domain
     * @param username
     * @param clientProps
     */
    public ClientInfo(String clientName, InetSocketAddress clientAddr,
            int rpcVersion, Class<?> protocol, String domain, String username,
            Map<String, String> clientProps) {
        this.clientName = clientName;
        this.clientAddr = clientAddr;
        this.rpcVersion = rpcVersion;
        this.protocol = protocol;
        this.domain = domain;
        this.username = username;
        this.clientProps = clientProps;
    }

    private volatile Object attachment;

    /**
     * Attaches the given object to this key.
     * <p>
     * An attached object may later be retrieved via the {@link #attachment()
     * attachment} method. Only one object may be attached at a time; invoking
     * this method causes any previous attachment to be discarded. The current
     * attachment may be discarded by attaching <tt>null</tt>.
     * </p>
     * 
     * @param ob
     *            The object to be attached; may be <tt>null</tt>
     * @return The previously-attached object, if any, otherwise <tt>null</tt>
     */
    public final Object attach(Object ob) {
        Object a = attachment;
        attachment = ob;
        return a;
    }

    /**
     * Retrieves the current attachment. </p>
     * 
     * @return The object currently attached to this key, or <tt>null</tt> if
     *         there is no attachment
     */
    public final Object attachment() {
        return attachment;
    }

    @Override
    public String toString() {
        return "ClientInfo [clientName=" + clientName + ", clientAddr="
                + clientAddr + ", rpcVersion=" + rpcVersion + ", protocol="
                + protocol + ", domain=" + domain + ", username=" + username
                + ", clientProps=" + clientProps + "]";
    }

}
