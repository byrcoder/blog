/**
 * @(#)IDistributeStrategy.java, 2012-3-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.net.InetSocketAddress;
import java.util.List;

import odis.rpc2.RpcException;

/**
 * Interface of the distribute strategy
 * 
 * @author wangfk
 */
public interface IDistributeStrategy {
    /**
     * Lookup the suitable server for the given <tt>distributeKey</tt>
     * 
     * @param distributeKey
     * @return
     * @throws RpcException
     */
    public InetSocketAddress lookupService(Object distributeKey)
            throws RpcException;

    /**
     * List all the server address of the distributed services
     * 
     * @return
     * @throws RpcException
     */
    public List<InetSocketAddress> listService() throws RpcException;
}
