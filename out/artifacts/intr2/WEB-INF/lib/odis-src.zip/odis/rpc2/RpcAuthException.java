/**
 * @(#)RpcAuthException.java, 2010-8-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Exception indicating that authentication failed.
 * 
 * @author zhangduo
 */
public class RpcAuthException extends RpcException {

    private static final long serialVersionUID = -7057770915465542299L;

    public RpcAuthException() {
        super();
    }

    public RpcAuthException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcAuthException(String message) {
        super(message);
    }

    public RpcAuthException(Throwable cause) {
        super(cause);
    }

}
