/**
 * @(#)ServerCallable.java, 2011-4-19. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;

import odis.rpc2.RpcException;

/**
 * Class that implements {@link Callable}, used by distributed rpc actions.
 * 
 * @author wangfk
 */
public class DistributeRpcCallable<T> implements Callable<Object> {
    // RPC proxy
    protected T proxy;

    protected Class<T> clazz;

    protected Method method;

    protected Object[] args;

    private final Object distributeKey;

    private final int distributeKeyLocation;

    /**
     * Constructor
     * 
     * @param clazz
     *            the rpc proxy class
     * @param method
     *            method to be invoke by the rpc proxy
     * @param args
     *            arguments of the methods
     * @param retries
     *            retry times
     */
    public DistributeRpcCallable(Class<T> clazz, Method method, Object[] args,
            Object distributeKey, int distributeKeyLocation) {
        this.clazz = clazz;
        this.method = method;
        this.args = args;
        this.distributeKey = distributeKey;
        this.distributeKeyLocation = distributeKeyLocation;
    }

    public T getProxy() {
        return proxy;
    }

    public Class<T> getClazz() {
        return clazz;
    }

    public Method getMethod() {
        return method;
    }

    public Object[] getArguments() {
        return args;
    }

    /**
     * Instantiate the RPC proxy for the method to be invoked.
     * <p>
     * Store server provides different RPC interface for data operations and
     * non-data operations. Subclasses should implements this method according
     * to the types of the <i>method</i>.
     * 
     * @throws YDriveException
     */
    public void instantiateProxy(DistributeConnection connection)
            throws RpcException {
        proxy = connection.getDistributeSerivceProxy(clazz, distributeKey,
                distributeKeyLocation);
    }

    @Override
    public Object call() throws Exception {
        try {
            return method.invoke(proxy, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause != null && cause instanceof Exception) {
                throw (Exception) cause;
            } else {
                throw e;
            }
        }
    }
}
