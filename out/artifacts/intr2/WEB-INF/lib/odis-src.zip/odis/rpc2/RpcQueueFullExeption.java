/**
 * @(#)RpcQueueFullExeption.java, 2010-8-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Exception that indicating the waiting queue on RpcServer is full, which means
 * the RpcServer will begin to drop calls.
 * 
 * @author zhangduo
 */
public class RpcQueueFullExeption extends RpcException {

    private static final long serialVersionUID = 767053440570459760L;

    public RpcQueueFullExeption(String message) {
        super(message);
    }

}
