/**
 * @(#)DistributeRPC.java, 2012-3-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.io.Closeable;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.rpc2.distribute.RpcDistributeConnection.RpcType;

/**
 * Add distributed strategy support for {@link odis.rpc2.RPC}
 * 
 * @author wangfk
 */
public class DistributeRPC {
    /**
     * Invoker for user data operations
     */
    static class DistributeServiceInvoker<T> implements InvocationHandler,
            Closeable {
        private Map<Method, Integer> distributeKeyLocationMap = new HashMap<Method, Integer>();

        private DistributeConnection connection;

        private Class<T> protocolClazz;

        private boolean closeConnectionResponsible;

        private DistributeServiceInvoker(DistributeConnection connection,
                Class<T> protocolClazz, boolean closeConnectionResponsible) {
            this.connection = connection;
            this.protocolClazz = protocolClazz;
            this.closeConnectionResponsible = closeConnectionResponsible;
            Method[] methods = protocolClazz.getMethods();
            if (methods != null) {
                for (Method method: methods) {
                    int distributeKeyLocation = -1;
                    Annotation[][] parameterAnnotations = method.getParameterAnnotations();
                    for (int i = 0; i < parameterAnnotations.length; ++i) {
                        for (Annotation a: parameterAnnotations[i]) {
                            if (a.annotationType().equals(DistributeKey.class)) {
                                if (distributeKeyLocation == -1) {
                                    distributeKeyLocation = i;
                                } else {
                                    throw new RuntimeException(
                                            "The are more than one DistributeKey annotation in mothod: "
                                                    + method);
                                }
                            }
                        }
                    }
                    distributeKeyLocationMap.put(method, distributeKeyLocation);
                }
            }
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            Object distributeKey = null;
            int distributeKeyLocation = distributeKeyLocationMap.get(method);
            if (distributeKeyLocation != -1) {
                distributeKey = args[distributeKeyLocation];
            }

            return connection.execute(new DistributeRpcCallable<T>(
                    protocolClazz, method, args, distributeKey,
                    distributeKeyLocation));
        }

        @Override
        public void close() throws IOException {
            if (closeConnectionResponsible) {
                connection.close();
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static <T> T getDistributeProxy(Class<T> protocolClazz,
            RpcDistributeConnection connection,
            boolean closeConnectionResponsible) {
        return (T) Proxy.newProxyInstance(protocolClazz.getClassLoader(),
                new Class<?>[] {
                    protocolClazz
                }, new DistributeServiceInvoker<T>(connection, protocolClazz,
                        closeConnectionResponsible));
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * with the given <tt>connection</tt>.
     * 
     * @param protocolClazz
     * @param connection
     * @return
     */
    public static <T> T getDistributeProxy(Class<T> protocolClazz,
            RpcDistributeConnection connection) {
        return getDistributeProxy(protocolClazz, connection, false);
    }

    /**
     * Close a proxy, release the connection
     * 
     * @param proxy
     */
    public static void close(Object proxy) {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return;
        }
        DistributeServiceInvoker<?> invoker = (DistributeServiceInvoker<?>) Proxy.getInvocationHandler(proxy);
        try {
            invoker.close();
        } catch (IOException e) {}
    }

    /**
     * call
     * {@link RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME},{@link RPC#DEFAULT_CLIENT_TIMEOUT}
     */
    public static <V> V getProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy) throws RpcException {
        return getProxy(protocol, distributeStrategy, RPC.DEFAULT_AUTH_INFO,
                RPC.DEFAULT_DOMAIN, RPC.DEFAULT_USERNAME,
                RPC.DEFAULT_CLIENT_TIMEOUT);
    }

    /**
     * call
     * {@link RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME}
     */
    public static <V> V getProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy, long timeout)
            throws RpcException {
        return getProxy(protocol, distributeStrategy, RPC.DEFAULT_AUTH_INFO,
                RPC.DEFAULT_DOMAIN, RPC.DEFAULT_USERNAME, timeout);
    }

    /**
     * call
     * {@link RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}
     */
    public static <V> V getProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy, String domain,
            String username, long timeout) throws RpcException {
        return getProxy(protocol, distributeStrategy, RPC.DEFAULT_AUTH_INFO,
                domain, username, timeout);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * {@link RpcException} .<br>
     * The method inherited from {@link Object} will be handled locally.<br>
     * 
     * @param protocol
     * @param distributeStrategy
     *            the distribute strategy for service address direction
     * @param authInfo
     *            a string token the server used to do authentication.if your
     *            server do not use it, use {@link RPC#DEFAULT_AUTH_INFO} .
     * @param domain
     *            a domain certain group of calls belong to, with which server
     *            can avoid calls from one client filling up the thread pool.if
     *            you do not need this, use {@link RPC#DEFAULT_DOMAIN}
     * @param username
     *            a name the server used to identify an user.if your server do
     *            not use it, use {@link RPC#DEFAULT_USERNAME}
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinitely
     * @return
     * @throws RpcException
     */
    public static <V> V getProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy, String authInfo,
            String domain, String username, long timeout) throws RpcException {
        return getDistributeProxy(protocol, new RpcDistributeConnection(
                distributeStrategy, RpcType.TCP, timeout, domain, authInfo,
                username), true);
    }

    /**
     * call
     * {@link RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME},{@link RPC#DEFAULT_CLIENT_TIMEOUT}
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy) throws RpcException {
        return getNIOProxy(protocol, distributeStrategy, RPC.DEFAULT_AUTH_INFO,
                RPC.DEFAULT_DOMAIN, RPC.DEFAULT_USERNAME,
                RPC.DEFAULT_CLIENT_TIMEOUT);
    }

    /**
     * call
     * {@link RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME}
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy, long timeout)
            throws RpcException {
        return getNIOProxy(protocol, distributeStrategy, RPC.DEFAULT_AUTH_INFO,
                RPC.DEFAULT_DOMAIN, RPC.DEFAULT_USERNAME, timeout);
    }

    /**
     * call
     * {@link RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy, String domain,
            String username, long timeout) throws RpcException {
        return getNIOProxy(protocol, distributeStrategy, RPC.DEFAULT_AUTH_INFO,
                domain, username, timeout);
    }

    /**
     * See the comments of
     * {@link #getProxy(Class, InetSocketAddress, String, String, String, long)}
     * .<br>
     * The only different is that the proxy returned by this method will use
     * Non-Blocking IO to communicate with RpcServer.
     * 
     * @param protocol
     * @param distributeStrategy
     * @param authInfo
     * @param domain
     * @param username
     * @param timeout
     * @return
     * @throws RpcException
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            IDistributeStrategy distributeStrategy, String authInfo,
            String domain, String username, long timeout) throws RpcException {
        return getDistributeProxy(protocol, new RpcDistributeConnection(
                distributeStrategy, RpcType.NIO, timeout, domain, authInfo,
                username), true);
    }

    /**
     * See the comments of
     * {@link #getProxy(Class, InetSocketAddress, String, String, String, long)}
     * .<br>
     * The only different is that the proxy returned by this method will use UDP
     * protocol to communicate with RpcServer.
     * 
     * @param protocol
     * @param distributeStrategy
     * @return
     * @throws SocketException
     */
    public static <P> P getUDPProxy(Class<P> protocol,
            IDistributeStrategy distributeStrategy) throws SocketException {
        return getDistributeProxy(protocol,
                new RpcDistributeConnection(distributeStrategy, RpcType.UDP,
                        RPC.DEFAULT_CLIENT_TIMEOUT, RPC.DEFAULT_DOMAIN,
                        RPC.DEFAULT_AUTH_INFO, RPC.DEFAULT_USERNAME), true);
    }
}
