/**
 * @(#)NIORpcClientManager.java, 2011-3-31. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.ByteBufferInputStream;
import odis.io.CDataInputStream;
import odis.io.DirectByteBufferPool;
import odis.io.NIOUtils;
import odis.rpc2.AbstractRpcClient.Call;
import odis.rpc2.NIORpcClient.ConnectionImpl;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.concurrent.AtomicRotateInteger;

/**
 * The connection manager for {@link NIORpcClient}. All NioRpcClients should use
 * the same NIORpcClientManager.
 * 
 * @author zhangduo
 */
public class NIORpcClientManager implements RpcConstants {
    private static final Logger LOG = LogFormatter.getLogger(NIORpcClientManager.class);

    private static final int DIRECT_BYTE_BUFFER_SIZE = 8 * 1024;

    private static final int DIRECT_BYTE_BUFFER_CHUNK_SIZE = 64 * 1024 * 1024;

    static final int MAX_WRITE_SPIN_COUNT = 16;

    final DirectByteBufferPool byteBufferPool = new DirectByteBufferPool(
            DIRECT_BYTE_BUFFER_SIZE, DIRECT_BYTE_BUFFER_CHUNK_SIZE,
            ByteOrder.LITTLE_ENDIAN);

    private ExecutorService asyncOperationThreadPool = Executors.newCachedThreadPool(new ThreadFactory() {

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "NIORpcClientManager-Async-Operation");
            t.setDaemon(true);
            return t;
        }
    });

    class Worker extends Thread {
        private static final int BYTE_BUFFER_SIZE = 1024 * 1024;

        private Selector selector;

        private List<ConnectionImpl> waitingRegisterList = new ArrayList<ConnectionImpl>();

        private ByteBuffer buffer = ByteBuffer.allocateDirect(BYTE_BUFFER_SIZE).order(
                ByteOrder.LITTLE_ENDIAN);

        private ByteBufferInputStream byteBufferIn = new ByteBufferInputStream(
                buffer);

        private CDataInputStream in = new CDataInputStream(byteBufferIn);

        public Worker(ThreadGroup threadGourp, String name) throws IOException {
            super(threadGourp, name);
            selector = Selector.open();
        }

        private void closeKey(SelectionKey key) {
            closeKey(key, (ConnectionImpl) key.attachment());
        }

        private void closeKey(SelectionKey key, final ConnectionImpl conn) {
            key.cancel();
            conn.closed = true;
            MiscUtils.safeClose(conn.socket);
            conn.worker = null;
            // async close conn because it may block
            asyncOperationThreadPool.execute(new Runnable() {

                @Override
                public void run() {
                    conn.client.errorTracker.fatalErrorOccur();
                    // hold sendQueue lock to avoid further calls.
                    synchronized (conn.sendQueue) {
                        for (Call call: conn.pendingCalls.values()) {
                            synchronized (call) {
                                call.finished = true;
                                call.error = new RpcException(
                                        "connection to server "
                                                + conn.client.remoteAddr
                                                + " closed");
                                call.notifyAll();
                            }
                        }
                    }
                }
            });

        }

        private void clearRead(ConnectionImpl conn) {
            conn.callIdBuffer.clear();
            conn.callReturnValueLengthBuffer.clear();
            conn.callReturnValueBuffer = null;
        }

        private void finishCall(Call call) {
            try {
                byte errorFlag = in.readByte();
                if (errorFlag == CALL_SUCCESS) {
                    if (call.returnValueBuffer != null) {
                        call.returnValue = RpcSerializer.readReturnValue(
                                call.returnValueBuffer, in);
                    } else {
                        call.returnValue = RpcSerializer.readReturnValue(
                                call.method, in);
                    }
                } else { // CALL_EXCEPTION
                    int sz = in.readVInt();
                    byte[] buf = new byte[sz];
                    in.readFully(buf);
                    ObjectInputStream ois = new ObjectInputStream(
                            new ByteArrayInputStream(buf));
                    call.error = (Throwable) ois.readObject();
                    MiscUtils.safeClose(ois);
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "read call " + call
                        + " return value failed", t);
                call.error = new RpcWritableException("read call " + call
                        + " return value failed", t);
            }
            synchronized (call) {
                call.finished = true;
                call.notifyAll();
            }
        }

        private int read(SelectionKey key) throws IOException {
            ConnectionImpl conn = (ConnectionImpl) key.attachment();
            int totalRead = 0;
            buffer.clear();
            int read = -1;
            while (buffer.hasRemaining()
                    && (read = conn.socket.read(buffer)) > 0) {
                totalRead += read;
            }
            if (read == -1) {
                return -1;
            }
            if (totalRead > 0) {
                buffer.flip();
                while (buffer.hasRemaining()) {
                    ByteBuffer callIdBuffer = conn.callIdBuffer;
                    if (callIdBuffer.hasRemaining()) {// read call id first
                        int oldLimit = buffer.limit();
                        buffer.limit(buffer.position()
                                + Math.min(callIdBuffer.remaining(),
                                        buffer.remaining()));
                        callIdBuffer.put(buffer);
                        buffer.limit(oldLimit);
                        if (!callIdBuffer.hasRemaining()) {
                            callIdBuffer.flip();
                            conn.callId = callIdBuffer.getInt();
                        }
                        continue;
                    }

                    ByteBuffer callReturnValueLengthBuffer = conn.callReturnValueLengthBuffer;
                    if (callReturnValueLengthBuffer.hasRemaining()) { // read call arg length first
                        int oldLimit = buffer.limit();
                        buffer.limit(buffer.position()
                                + Math.min(
                                        callReturnValueLengthBuffer.remaining(),
                                        buffer.remaining()));
                        callReturnValueLengthBuffer.put(buffer);
                        buffer.limit(oldLimit);
                        if (!callReturnValueLengthBuffer.hasRemaining()) {
                            callReturnValueLengthBuffer.flip();
                            int returnValueLength = callReturnValueLengthBuffer.getInt();
                            if (buffer.remaining() >= returnValueLength) {
                                oldLimit = buffer.limit();
                                buffer.limit(buffer.position()
                                        + returnValueLength);
                                Call call = conn.pendingCalls.remove(conn.callId);
                                if (call != null) {
                                    finishCall(call);
                                }
                                clearRead(conn);
                                conn.client.errorTracker.noErrorOccur();
                                buffer.position(buffer.limit());
                                buffer.limit(oldLimit);
                            } else {
                                conn.callReturnValueBuffer = ByteBuffer.allocate(returnValueLength);
                                conn.callReturnValueBuffer.put(buffer);
                            }
                        }
                        continue;
                    }
                    ByteBuffer callReturnValueBuffer = conn.callReturnValueBuffer;
                    int oldLimit = buffer.limit();
                    buffer.limit(buffer.position()
                            + Math.min(callReturnValueBuffer.remaining(),
                                    buffer.remaining()));
                    callReturnValueBuffer.put(buffer);
                    buffer.limit(oldLimit);
                    if (!callReturnValueBuffer.hasRemaining()) {
                        Call call = conn.pendingCalls.remove(conn.callId);
                        if (call != null) {
                            callReturnValueBuffer.flip();
                            byteBufferIn.setBuffer(callReturnValueBuffer);
                            finishCall(call);
                            byteBufferIn.setBuffer(buffer);
                        }
                        clearRead(conn);
                        conn.client.errorTracker.noErrorOccur();
                    }
                }
            }
            return totalRead;
        }

        private int write(SelectionKey key) throws IOException {
            ConnectionImpl conn = (ConnectionImpl) key.attachment();
            int totalWrite = 0;
            synchronized (conn.sendQueue) {
                while (!conn.sendQueue.isEmpty()) {
                    Call call = conn.sendQueue.peek();
                    int write = NIOUtils.write(conn.socket, call.argsBuf,
                            call.argsBufOff, call.argsBufLen, buffer,
                            MAX_WRITE_SPIN_COUNT);
                    call.argsBufOff += write;
                    call.argsBufLen -= write;
                    totalWrite += write;
                    if (call.argsBufLen == 0) {
                        conn.sendQueue.poll();
                        conn.sendQueue.notify();
                    }
                }
                // all clean, unregister WRITE_OP
                synchronized (conn.interestOpLock) {
                    conn.interestOps = SelectionKey.OP_READ;
                    key.interestOps(SelectionKey.OP_READ);
                }
            }
            return totalWrite;
        }

        @Override
        public void run() {
            for (;;) {
                try {
                    int count = selector.select();
                    if (count > 0) {
                        Set<SelectionKey> keys = selector.selectedKeys();
                        for (SelectionKey key: keys) {
                            try {
                                if (key.isWritable()) {
                                    write(key);
                                } else if (key.isReadable()) {
                                    if (read(key) == -1) {
                                        closeKey(key);
                                    }
                                } else {
                                    LOG.warning("unexpected interest op: "
                                            + key.interestOps());
                                }
                            } catch (Throwable t) {
                                LOG.log(Level.WARNING,
                                        "read write socket failed", t);
                                closeKey(key);
                            }
                        }
                        keys.clear();
                    }
                    synchronized (waitingRegisterList) {
                        for (ConnectionImpl conn: waitingRegisterList) {
                            SelectionKey k = conn.socket.keyFor(selector);
                            try {
                                if (k == null) {
                                    if (conn.interestOps == 0) {
                                        MiscUtils.safeClose(conn.socket);
                                    } else {
                                        conn.socket.register(selector,
                                                conn.interestOps, conn);
                                    }
                                } else {
                                    if (conn.interestOps == 0) {
                                        k.cancel();
                                        MiscUtils.safeClose(conn.socket);
                                    } else {
                                        k.interestOps(conn.interestOps);
                                    }
                                }
                            } catch (ClosedChannelException e) {
                                LOG.log(Level.WARNING,
                                        "connection already closed", e);
                            } catch (CancelledKeyException e) {
                                LOG.log(Level.WARNING,
                                        "connection already closed", e);
                            }
                        }
                        waitingRegisterList.clear();
                    }
                } catch (Throwable t) {
                    LOG.log(Level.SEVERE, "unexpected throwable caught", t);
                }
            }
        }

        public void register(ConnectionImpl conn) {
            conn.worker = this;
            boolean needWakeup = false;
            synchronized (waitingRegisterList) {
                if (waitingRegisterList.isEmpty()) {
                    needWakeup = true;
                }
                waitingRegisterList.add(conn);
            }
            if (needWakeup) {
                selector.wakeup();
            }
        }

        public void close() {
            MiscUtils.safeClose(selector);
        }
    }

    private Worker[] workers;

    private AtomicRotateInteger currentWorker;

    /**
     * Default constructor.
     * 
     * @param workerCount
     *            the IO worker count(thread count).
     * @throws IOException
     */
    public NIORpcClientManager(ThreadGroup threadGroup, int workerCount)
            throws IOException {
        workers = new Worker[workerCount];
        currentWorker = new AtomicRotateInteger(0, workerCount, 0);
        for (int i = 0; i < workerCount; i++) {
            workers[i] = new Worker(threadGroup, "NIO-Client-Worker-" + i);
            workers[i].setDaemon(true);
        }
    }

    /**
     * Start nio worker threads.
     */
    public void start() {
        for (Worker worker: workers) {
            worker.start();
        }
    }

    /**
     * Register a connection to manager(register to a selector actually).<br>
     * 
     * @param conn
     */
    public void register(ConnectionImpl conn) {
        workers[currentWorker.getAndIncrement()].register(conn);
    }
}
