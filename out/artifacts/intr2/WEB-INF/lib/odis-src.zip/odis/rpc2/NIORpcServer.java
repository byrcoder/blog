/**
 * @(#)NIORpcServer.java, 2010-8-20. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.rmi.server.UID;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.ByteBufferInputStream;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.io.DirectByteBufferPool;
import odis.io.NIOUtils;
import odis.serialize.lib.StringPropertiesWritable;
import odis.serialize.lib.StringWritable;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.concurrent.AtomicRotateInteger;

/**
 * An RpcServer using Non-Blocking IO to communicate with RpcClient.
 * 
 * @author zhangduo
 */
public class NIORpcServer extends AbstractRpcServer {

    private static final int MAX_WRITE_SPIN_COUNT = 16;

    private static final int DIRECT_BYTE_BUFFER_SIZE = 8 * 1024;

    private static final int DIRECT_BYTE_BUFFER_CHUNK_SIZE = 64 * 1024 * 1024;

    private static final DirectByteBufferPool byteBufferPool = new DirectByteBufferPool(
            DIRECT_BYTE_BUFFER_SIZE, DIRECT_BYTE_BUFFER_CHUNK_SIZE,
            ByteOrder.LITTLE_ENDIAN);

    private static final Logger LOG = LogFormatter.getLogger(NIORpcServer.class);

    private final long maxReadBufferSize;

    protected NIORpcServer(int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime, int workerCount,
            long maxReadBufferSize) {
        super(port, handlerCount, queueSize, maxConnPerClient,
                clientDisconnectTime);
        serverIOMode = SERVER_PROP_IO_MODE_NIO;
        workers = new Worker[workerCount];
        this.maxReadBufferSize = maxReadBufferSize;
    }

    private class Worker extends Thread {

        private static final int BYTE_BUFFER_SIZE = 1024 * 1024;

        private Selector selector;

        private List<ConnectionImpl> waitingRegisterList = new ArrayList<ConnectionImpl>();

        private ByteBuffer buffer = ByteBuffer.allocateDirect(BYTE_BUFFER_SIZE).order(
                ByteOrder.LITTLE_ENDIAN);

        private ByteBufferInputStream byteBufferIn = new ByteBufferInputStream(
                buffer);

        private CDataInputStream in = new CDataInputStream(byteBufferIn);

        public Worker(ThreadGroup group, String name) throws IOException {
            super(group, name);
            selector = Selector.open();
        }

        private void clearRead(ConnectionImpl conn) {
            conn.call = null;
            conn.callIdBuffer.clear();
            conn.callArgLengthBuffer.clear();
            conn.callArgBuffer = null;
        }

        private void call(SelectionKey key, ConnectionImpl conn,
                CDataInputStream in) throws IOException {
            Call call = conn.call;
            if (call.id < 0) {
                switch (call.id) {
                    case CALL_ID_SEND_RPC_VERSION:
                        int rpcVersion = in.readInt();
                        call.args = new Object[] {
                            rpcVersion
                        };
                        receiveRpcVersion(call);
                        break;
                    case CALL_ID_SEND_CLIENT_NAME:
                        String clientName = StringWritable.readString(in);
                        call.args = new Object[] {
                            clientName
                        };
                        receiveClientName(call);
                        break;
                    case CALL_ID_SEND_AUTH_INFO:
                        String authInfo = StringWritable.readString(in);
                        call.args = new Object[] {
                            authInfo
                        };
                        doAuth(call);
                        break;
                    case CALL_ID_VERIFY_PROTOCOL:
                        ProtocolVerifyEntry verifyEntry = new ProtocolVerifyEntry();
                        verifyEntry.readFields(in);
                        call.args = new Object[] {
                            verifyEntry
                        };
                        verifyProtocol(call);
                        break;
                    case CALL_ID_SEND_DOMAIN:
                        String domain = StringWritable.readString(in);
                        call.args = new Object[] {
                            domain
                        };
                        receiveDomain(call);
                        break;
                    case CALL_ID_SEND_USERNAME:
                        String username = StringWritable.readString(in);
                        call.args = new Object[] {
                            username
                        };
                        receiveUsername(call);
                        break;
                    case CALL_ID_SEND_AND_GET_PROPS:
                        StringPropertiesWritable properties = new StringPropertiesWritable();
                        properties.readFields(in);
                        call.args = new Object[] {
                            properties
                        };
                        receiveAndSendProps(call);
                        break;
                    default:
                        LOG.warning("unknown call id: " + call.id);
                }
                finishCall(key, conn, call);
            } else {
                call.signature = in.readLong();
                Instance instance = protocolMap.get(conn.protocolName);
                call.instance = instance.instance;
                call.method = instance.signature2method.get(call.signature);
                if (serverCallListener != null) {
                    try {
                        call.attach = serverCallListener.createAttach(conn.info);
                        serverCallListener.startReceive(call.method,
                                call.attach);
                    } catch (Throwable t) {}
                }
                boolean succ;
                try {
                    call.args = RpcSerializer.readArgs(call.method, in);
                    succ = true;
                } catch (Throwable t) {
                    LOG.log(Level.WARNING,
                            "read call " + call + " args failed", t);
                    call.error = new RpcWritableException("read call " + call
                            + "args failed", t);
                    succ = false;
                }
                if (succ) {
                    if (serverCallListener != null) {
                        try {
                            serverCallListener.endReceive(call.method,
                                    call.args, call.attach);
                        } catch (Throwable t) {}
                    }
                    synchronized (queueLock) {
                        succ = callQueue.offer(call);
                        if (succ) {
                            queueLock.notify();
                        }
                    }
                    if (!succ) {
                        call.error = new RpcQueueFullExeption(
                                "RPC server queued call length reach max queue size "
                                        + queueSize);
                        finishCall(key, conn, call);
                    }
                } else {
                    finishCall(key, conn, call);
                }
            }
        }

        private int read(SelectionKey key) throws IOException {
            long startRead = System.currentTimeMillis();
            ConnectionImpl conn = (ConnectionImpl) key.attachment();
            int totalRead = 0;
            buffer.clear();

            int read = -1;
            while (buffer.hasRemaining()
                    && (read = conn.socket.read(buffer)) > 0) {
                totalRead += read;
            }

            if (read == -1) { // reach the end of stream, this means the client connection is already closed
                return -1;
            }
            if (totalRead > 0) {
                buffer.flip();
                while (buffer.hasRemaining()) {
                    if (conn.call == null) {
                        conn.call = new Call();
                        conn.call.conn = conn;
                        conn.call.startTime = startRead;
                        if (conn.clientName != null) {
                            receiveCall(conn.clientName, startRead);
                        }
                    }
                    Call call = conn.call;
                    ByteBuffer callIdBuffer = conn.callIdBuffer;
                    if (callIdBuffer.hasRemaining()) {// read call id first
                        int oldLimit = buffer.limit();
                        buffer.limit(buffer.position()
                                + Math.min(callIdBuffer.remaining(),
                                        buffer.remaining()));
                        callIdBuffer.put(buffer);
                        buffer.limit(oldLimit);
                        if (!callIdBuffer.hasRemaining()) {
                            callIdBuffer.flip();
                            call.id = callIdBuffer.getInt();
                            if (call.id == CALL_ID_HEARTBEAT) { // need to do nothing, just read next call
                                clearRead(conn);
                            }
                        }
                        continue;
                    }
                    ByteBuffer callArgLengthBuffer = conn.callArgLengthBuffer;
                    if (callArgLengthBuffer.hasRemaining()) { // read call arg length first
                        int oldLimit = buffer.limit();
                        buffer.limit(buffer.position()
                                + Math.min(callArgLengthBuffer.remaining(),
                                        buffer.remaining()));
                        callArgLengthBuffer.put(buffer);
                        buffer.limit(oldLimit);
                        if (!callArgLengthBuffer.hasRemaining()) {
                            callArgLengthBuffer.flip();
                            int argLength = callArgLengthBuffer.getInt();
                            if (argLength < 0
                                    || (maxReadBufferSize > 0 && argLength > maxReadBufferSize)) {
                                LOG.warning("Got arg length " + argLength
                                        + " from " + conn.clientAddr
                                        + " which reaches limit "
                                        + maxReadBufferSize
                                        + ", I will close the connection");
                                return -1;
                            }
                            if (buffer.remaining() >= argLength) {
                                oldLimit = buffer.limit();
                                buffer.limit(buffer.position() + argLength);
                                call(key, conn, in);
                                clearRead(conn);
                                buffer.limit(oldLimit);
                            } else {
                                conn.callArgBuffer = ByteBuffer.allocate(argLength);
                                conn.callArgBuffer.put(buffer);
                            }
                        }
                        continue;
                    }
                    ByteBuffer callArgBuffer = conn.callArgBuffer;
                    int oldLimit = buffer.limit();
                    buffer.limit(buffer.position()
                            + Math.min(callArgBuffer.remaining(),
                                    buffer.remaining()));
                    callArgBuffer.put(buffer);
                    buffer.limit(oldLimit);
                    if (!callArgBuffer.hasRemaining()) {
                        callArgBuffer.flip();
                        byteBufferIn.setBuffer(callArgBuffer);
                        call(key, conn, in);
                        byteBufferIn.setBuffer(buffer);
                        clearRead(conn);
                    } else {
                        // already timeout
                        if (callArgBuffer.capacity() > buffer.capacity()
                                && conn.clientTimeout > 0
                                && System.currentTimeMillis() - call.startTime >= conn.clientTimeout) {
                            LOG.warning("Timeout when receive data from "
                                    + conn.clientAddr
                                    + " to a large buffer with capacity "
                                    + callArgBuffer.capacity()
                                    + ", I will close the connection");
                            return -1;
                        }
                    }
                }
            }
            return totalRead;
        }

        // selector thread should not wait, so we close the connection if return queue is full
        private void finishCall(SelectionKey key, ConnectionImpl conn, Call call) {
            if (!conn.finishCall(call)) {
                closeKey(key, conn);
            }
        }

        private int write(SelectionKey key) throws IOException {
            ConnectionImpl conn = (ConnectionImpl) key.attachment();
            int totalWrite = 0;
            int write;
            synchronized (conn.returnValues) {
                while (!conn.returnValues.isEmpty()) {
                    ReturnValue rv = conn.returnValues.peek();
                    write = NIOUtils.write(conn.socket, rv.buf, rv.off, rv.len,
                            buffer, MAX_WRITE_SPIN_COUNT);
                    rv.off += write;
                    rv.len -= write;
                    totalWrite += write;
                    if (rv.len == 0) {
                        if (rv.method != null && serverCallListener != null) {
                            try {
                                serverCallListener.endSend(rv.method, rv.attach);
                            } catch (Throwable t) {}
                        }
                        conn.returnValues.poll();
                    } else {
                        return totalWrite;
                    }
                }
                // all clean, unregister WRITE_OP
                synchronized (conn.interestOpLock) {
                    conn.interestOps = SelectionKey.OP_READ;
                    key.interestOps(SelectionKey.OP_READ);
                }
            }
            return totalWrite;
        }

        private void closeKey(SelectionKey key) {
            closeKey(key, (ConnectionImpl) key.attachment());
        }

        private void closeKey(SelectionKey key, ConnectionImpl conn) {
            key.cancel();
            closeConnection(conn);
        }

        @Override
        public void run() {
            while (running) {
                try {
                    int count = selector.select();
                    if (count > 0) {
                        Set<SelectionKey> keys = selector.selectedKeys();
                        for (SelectionKey key: keys) {
                            try {
                                if (key.isWritable()) {
                                    write(key);
                                } else if (key.isReadable()) {
                                    if (read(key) == -1) {
                                        closeKey(key);
                                    }
                                } else {
                                    LOG.warning("unexpected interest op: "
                                            + key.interestOps());
                                }
                            } catch (Throwable t) {
                                LOG.log(Level.WARNING,
                                        "read write socket failed", t);
                                closeKey(key);
                            }
                        }
                        keys.clear();
                    }
                    synchronized (waitingRegisterList) {
                        for (ConnectionImpl conn: waitingRegisterList) {
                            SelectionKey k = conn.socket.keyFor(selector);
                            try {
                                if (k == null) {
                                    conn.socket.register(selector,
                                            conn.interestOps, conn);
                                } else {
                                    k.interestOps(conn.interestOps);
                                }
                            } catch (ClosedChannelException e) {
                                LOG.log(Level.WARNING,
                                        "connection already closed", e);
                            } catch (CancelledKeyException e) {
                                LOG.log(Level.WARNING,
                                        "connection already closed", e);
                            }
                        }
                        waitingRegisterList.clear();
                    }
                } catch (Throwable t) {
                    LOG.log(Level.SEVERE, "unexpected throwable caught", t);
                }
            }
        }

        public void register(ConnectionImpl conn) {
            boolean needWakeup = false;
            synchronized (waitingRegisterList) {
                if (waitingRegisterList.isEmpty()) {
                    needWakeup = true;
                }
                waitingRegisterList.add(conn);
            }
            if (needWakeup) {
                selector.wakeup();
            }
        }

        public void close() {
            MiscUtils.safeClose(selector);
        }
    }

    private static class ReturnValue {

        public final byte[] buf;

        public int off;

        public int len;

        public final Method method;

        public final Object attach;

        public ReturnValue(byte[] buf, int off, int len, Method method,
                Object attach) {
            this.buf = buf;
            this.off = off;
            this.len = len;
            this.method = method;
            this.attach = attach;
        }

    }

    private class ConnectionImpl extends Connection {

        private volatile boolean closed = false;

        private final SocketChannel socket;

        private final Object interestOpLock = new Object();

        private int interestOps = SelectionKey.OP_READ;

        private final Worker worker;

        private final Queue<ReturnValue> returnValues = new ArrayDeque<ReturnValue>();

        private Call call;

        private final ByteBuffer callIdBuffer;

        private final ByteBuffer callArgLengthBuffer;

        private ByteBuffer callArgBuffer;

        public ConnectionImpl(SocketChannel socket, Worker worker) {
            this.socket = socket;
            this.worker = worker;
            this.clientAddr = new InetSocketAddress(
                    socket.socket().getInetAddress(), socket.socket().getPort());
            callIdBuffer = ByteBuffer.allocate(4);
            callIdBuffer.order(ByteOrder.LITTLE_ENDIAN);
            callArgLengthBuffer = ByteBuffer.allocate(4);
            callArgLengthBuffer.order(ByteOrder.LITTLE_ENDIAN);
        }

        @Override
        public boolean finishCall(Call call) {
            if (closed) {
                return true;
            }
            DirectByteArrayOutputStream bos = new DirectByteArrayOutputStream(
                    32);
            CDataOutputStream dos = new CDataOutputStream(bos);
            try {
                dos.writeInt(call.id);
                if (call.id < 0) {
                    if (call.error == null) {
                        dos.writeByte(CALL_SUCCESS);
                        if (call.id == CALL_ID_SEND_AND_GET_PROPS) {
                            ((StringPropertiesWritable) call.returnValue).writeFields(dos);
                        }
                    } else {
                        dos.writeByte(CALL_EXCEPTION);
                        ByteArrayOutputStream exBos = new ByteArrayOutputStream();
                        ObjectOutputStream oos = new ObjectOutputStream(exBos);
                        oos.writeObject(call.error);
                        oos.close();
                        dos.writeVInt(exBos.size());
                        exBos.writeTo(dos);
                    }
                } else if (call.conn.clientIOMode == CLIENT_IO_MODE_BIO) {
                    if (call.error == null) {
                        dos.writeByte(CALL_SUCCESS);
                        try {
                            RpcSerializer.writeReturnValue(call.method,
                                    call.returnValue, dos);
                        } catch (Throwable t) {
                            bos.reset();
                            dos.writeInt(call.id);
                            call.error = new RpcWritableException(
                                    "Serialize return value failed", t);
                        }
                    }
                    if (call.error != null) {
                        dos.writeByte(CALL_EXCEPTION);
                        ByteArrayOutputStream exBos = new ByteArrayOutputStream();
                        ObjectOutputStream oos = new ObjectOutputStream(exBos);
                        oos.writeObject(call.error);
                        oos.close();
                        dos.writeVInt(exBos.size());
                        exBos.writeTo(dos);
                    }
                } else { // CLIENT_IO_MODE_NIO
                    if (call.error == null) {
                        dos.writeInt(0); // for length
                        dos.writeByte(CALL_SUCCESS);
                        try {
                            RpcSerializer.writeReturnValue(call.method,
                                    call.returnValue, dos);
                        } catch (Throwable t) {
                            bos.reset();
                            dos.writeInt(call.id);
                            call.error = new RpcWritableException(
                                    "Serialize return value failed", t);
                        }
                    }
                    if (call.error != null) {
                        dos.writeInt(0); // for length
                        dos.writeByte(CALL_EXCEPTION);
                        ByteArrayOutputStream exBos = new ByteArrayOutputStream();
                        ObjectOutputStream oos = new ObjectOutputStream(exBos);
                        oos.writeObject(call.error);
                        oos.close();
                        dos.writeVInt(exBos.size());
                        exBos.writeTo(dos);
                    }
                    CDataOutputStream.writeInt(bos.size() - 8, bos.getBuffer(),
                            4);
                }
            } catch (Throwable t) {
                // should not happen
                LOG.log(Level.WARNING,
                        "got unexpected exception when finish call", t);
                return false;
            }
            if (call.method != null && serverCallListener != null) {
                try {
                    serverCallListener.startSend(call.method, call.attach);
                } catch (Throwable t) {}
            }
            synchronized (returnValues) {
                if (!returnValues.isEmpty()) {
                    returnValues.add(new ReturnValue(bos.getBuffer(), 0,
                            bos.getBufferSize(), call.method, call.attach));
                    return true;
                }
                int write;
                ByteBuffer bb = byteBufferPool.allocate();
                try {
                    write = NIOUtils.write(socket, bos.getBuffer(), 0,
                            bos.getBufferSize(), bb, MAX_WRITE_SPIN_COUNT);
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "write return value failed", t);
                    shutdown();
                    return false;
                } finally {
                    byteBufferPool.release(bb);
                }
                if (write < bos.getBufferSize()) {
                    returnValues.add(new ReturnValue(bos.getBuffer(), write,
                            bos.getBufferSize() - write, call.method,
                            call.attach));
                    synchronized (interestOpLock) {
                        // if we have unfinished write request, do not read further
                        // calls from the same connection
                        interestOps = SelectionKey.OP_WRITE;
                        worker.register(this);
                    }
                    return true;
                }
            }
            if (call.method != null && serverCallListener != null) {
                try {
                    serverCallListener.endSend(call.method, call.attach);
                } catch (Throwable t) {}
            }
            return true;
        }

        @Override
        public void shutdown() {
            closed = true;
            MiscUtils.safeClose(socket);
            synchronized (returnValues) {
                returnValues.clear();
            }
            callArgBuffer = null;
        }
    }

    private class Acceptor extends Thread {

        private static final boolean TCP_NO_DELAY = true;

        private ServerSocketChannel socket;

        private Selector selector;

        public Acceptor() throws IOException {
            socket = ServerSocketChannel.open();
            socket.socket().bind(new InetSocketAddress(port));
            socket.configureBlocking(false);

            selector = Selector.open();
            socket.register(selector, SelectionKey.OP_ACCEPT);
        }

        @Override
        public void run() {
            while (running) {
                try {
                    int count = selector.select();
                    if (count > 0) {
                        Set<SelectionKey> keys = selector.selectedKeys();
                        for (SelectionKey key: keys) {
                            if (key.isAcceptable()) {
                                ServerSocketChannel server = (ServerSocketChannel) key.channel();
                                SocketChannel socket = server.accept();
                                socket.configureBlocking(false);
                                socket.socket().setTcpNoDelay(TCP_NO_DELAY);
                                LOG.info("Server connection on "
                                        + port
                                        + " from "
                                        + socket.socket().getInetAddress().getHostAddress()
                                        + ":" + socket.socket().getPort()
                                        + " started");
                                Worker worker = workers[currentWorker.getAndIncrement()];
                                ConnectionImpl conn = new ConnectionImpl(
                                        socket, worker);
                                worker.register(conn);
                            } else {
                                LOG.warning("SelectionKey " + key
                                        + " is not acceptable");
                            }
                        }
                        keys.clear();
                    }
                } catch (Throwable t) {
                    LOG.log(Level.SEVERE,
                            "unexpected throwable caught when accepting connections",
                            t);
                }
            }
        }

        public void close() {
            MiscUtils.safeClose(selector);
            MiscUtils.safeClose(socket);
        }
    }

    private Worker[] workers;

    private AtomicRotateInteger currentWorker;

    private Acceptor acceptor;

    @Override
    protected void startServer() throws IOException {
        currentWorker = new AtomicRotateInteger(0, workers.length, 0);
        // the selector.select() do not work after the selector thread is 
        // interrupted, so we create a ThreadGroup to avoid the selector 
        // thread being interrupted.
        ThreadGroup threadGroup = new ThreadGroup(
                MiscUtils.findTopThreadGroup(), "NIORpcServer-"
                        + new UID().toString());
        LOG.info("Create ThreadGroup " + threadGroup + " with parent = "
                + threadGroup.getParent() + " for Server NIO Worker");
        for (int i = 0; i < workers.length; i++) {
            workers[i] = new Worker(threadGroup, "NIO-Server-Worker-" + i);
            workers[i].start();
        }
        acceptor = new Acceptor();
        acceptor.start();
    }

    @Override
    protected void stopServer() throws IOException {
        acceptor.close();
        acceptor = null;
        for (Worker worker: workers) {
            worker.close();
        }
        workers = null;
    }

    @Override
    protected int getBoundPort() {
        if (acceptor != null) {
            return acceptor.socket.socket().getLocalPort();
        } else {
            return -1;
        }
    }
}
