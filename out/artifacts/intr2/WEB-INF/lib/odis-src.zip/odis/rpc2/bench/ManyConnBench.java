/**
 * @(#)ManyConnBench.java, 2010-12-24. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.bench;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.rpc2.ProtocolVerifier;
import odis.rpc2.ProtocolVerifyEntry;
import odis.rpc2.RpcConstants;
import odis.rpc2.RpcException;
import odis.serialize.lib.StringPropertiesWritable;
import odis.serialize.lib.StringWritable;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class ManyConnBench implements RpcConstants {

    private static final Logger LOG = LogFormatter.getLogger(ManyConnBench.class);

    private InetSocketAddress remoteAddr;

    private long signature;

    private class Connection {

        private String clientName;

        private static final int BUFFER_SIZE = 8 * 1024;

        private Socket socket;

        private CDataOutputStream out;

        private CDataInputStream in;

        private int mode;

        private static final byte BIO = 0;

        private static final byte NIO = 1;

        public Connection(String clientName) throws IOException {
            socket = new Socket(remoteAddr.getAddress(), remoteAddr.getPort());
            socket.setTcpNoDelay(true);
            in = new CDataInputStream(new BufferedInputStream(
                    socket.getInputStream(), BUFFER_SIZE));
            out = new CDataOutputStream(new BufferedOutputStream(
                    socket.getOutputStream(), BUFFER_SIZE));
            this.clientName = clientName;
        }

        private Throwable readException() throws IOException,
                ClassNotFoundException {
            int sz = in.readVInt();
            byte[] buf = new byte[sz];
            in.readFully(buf);
            ObjectInputStream ois = new ObjectInputStream(
                    new ByteArrayInputStream(buf));
            Throwable t = (Throwable) ois.readObject();
            MiscUtils.safeClose(ois);
            return t;
        }

        public void init() throws Throwable {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            CDataOutputStream dos = new CDataOutputStream(bos);

            // send rpc version
            out.writeInt(CALL_ID_SEND_RPC_VERSION);
            dos.writeInt(RPC_VERSION);
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            int id = in.readInt();
            if (id != CALL_ID_SEND_RPC_VERSION) {
                throw new RpcException("unexpected return call id " + id
                        + " for send rpc version call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }

            // send client name
            bos.reset();
            out.writeInt(CALL_ID_SEND_CLIENT_NAME);
            StringWritable.writeString(dos, clientName);
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            id = in.readInt();
            if (id != CALL_ID_SEND_CLIENT_NAME) {
                throw new RpcException("unexpected return call id " + id
                        + " for send client name call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }

            // send auth info
            bos.reset();
            out.writeInt(CALL_ID_SEND_AUTH_INFO);
            StringWritable.writeString(dos, "");
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            id = in.readInt();
            if (id != CALL_ID_SEND_AUTH_INFO) {
                throw new RpcException("unexpected return call id " + id
                        + " for send auth info call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }

            // verify protocol
            bos.reset();
            out.writeInt(CALL_ID_VERIFY_PROTOCOL);
            ProtocolVerifyEntry verifyEntry = new ProtocolVerifyEntry(
                    IManyConnProtocol.class.getName(),
                    ProtocolVerifier.clientVerify(IManyConnProtocol.class));
            verifyEntry.writeFields(dos);
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            id = in.readInt();
            if (id != CALL_ID_VERIFY_PROTOCOL) {
                throw new RpcException("unexpected return call id " + id
                        + " for veridy protocol call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }

            // send domain
            bos.reset();
            out.writeInt(CALL_ID_SEND_DOMAIN);
            StringWritable.writeString(dos, "");
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            id = in.readInt();
            if (id != CALL_ID_SEND_DOMAIN) {
                throw new RpcException("unexpected return call id " + id
                        + " for send domain call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }

            // send username
            bos.reset();
            out.writeInt(CALL_ID_SEND_USERNAME);
            StringWritable.writeString(dos, "");
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            id = in.readInt();
            if (id != CALL_ID_SEND_USERNAME) {
                throw new RpcException("unexpected return call id " + id
                        + " for send username call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }

            // send and get props
            bos.reset();
            out.writeInt(CALL_ID_SEND_AND_GET_PROPS);
            StringPropertiesWritable props = new StringPropertiesWritable();
            props.put(CLIENT_PROP_RPC_TIMEOUT, Long.toString(0));
            props.writeFields(dos);
            out.writeInt(bos.size());
            bos.writeTo(out);
            out.flush();
            id = in.readInt();
            if (id != CALL_ID_SEND_AND_GET_PROPS) {
                throw new RpcException("unexpected return call id " + id
                        + " for send and get properties call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException();
            }
            props.readFields(in);
            String serverIOMode = props.get(SERVER_PROP_IO_MODE);
            if (serverIOMode.equals(SERVER_PROP_IO_MODE_BIO)) {
                mode = BIO;
            } else {
                mode = NIO;
            }
        }

        public Throwable call(int id, long seed) throws IOException,
                ClassNotFoundException {
            out.writeInt(id);
            if (mode == BIO) {
                out.writeLong(signature);
                out.writeLong(seed);
            } else {
                out.writeInt(16);
                out.writeLong(signature);
                out.writeLong(seed);
            }
            out.flush();
            int rid = in.readInt();
            if (rid != id) {
                throw new RuntimeException("receive id " + rid
                        + " is not equal to send id " + id);
            }
            byte errorFlag = in.readByte();
            if (errorFlag == CALL_SUCCESS) {
                if (in.readBoolean()) {
                    StringWritable.readString(in);
                }
                return null;
            } else {
                return readException();
            }
        }

        public void close() throws IOException {
            socket.close();
        }
    }

    private Connection[] conns;

    private Random rand = new Random(334456789L);

    private int n;

    private TestThread[] threads;

    private class TestThread extends Thread {

        private int rangeStart;

        private int rangeEnd;

        public TestThread(int index, int rangeStart, int rangeEnd) {
            super("TestThread-" + index);
            this.rangeStart = rangeStart;
            this.rangeEnd = rangeEnd;
        }

        @Override
        public void run() {
            long start = System.currentTimeMillis();
            for (int i = 1; i <= n; i++) {
                int connIndex = rangeStart
                        + rand.nextInt(rangeEnd - rangeStart);
                try {
                    Throwable t = conns[connIndex].call(i, i);
                    if (t != null) {
                        LOG.log(Level.WARNING, "call return with exception", t);
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "call failed", e);
                }
            }
            long time = System.currentTimeMillis() - start;
            LOG.info(getName() + " run " + n + " times, time = " + time + "ms");
        }

    }

    public void prepare(int connCount, int threadNumber) throws Throwable {
        conns = new Connection[connCount];
        for (int i = 0; i < connCount; i++) {
            conns[i] = new Connection(InetAddress.getLocalHost() + "-"
                    + ManagementFactory.getRuntimeMXBean().getName() + "-" + i);
            conns[i].init();
        }
        threads = new TestThread[threadNumber];
        int rangePerThread = connCount / threadNumber;
        for (int i = 0; i < threadNumber; i++) {
            threads[i] = new TestThread(i, i * rangePerThread, (i + 1)
                    * rangePerThread);
        }
    }

    public void run() throws IOException {
        for (TestThread t: threads) {
            t.start();
        }
        for (TestThread t: threads) {
            try {
                t.join();
            } catch (InterruptedException e) {}
        }
        for (Connection conn: conns) {
            conn.close();
        }
    }

    public static void main(String[] args) throws Throwable {
        ManyConnBench bench = new ManyConnBench();
        String[] ss = args[0].split(":");
        bench.remoteAddr = new InetSocketAddress(ss[0], Integer.parseInt(ss[1]));
        bench.n = Integer.parseInt(args[1]);
        bench.signature = ProtocolVerifier.clientVerify(IManyConnProtocol.class).values().iterator().next();
        bench.prepare(Integer.parseInt(args[2]), Integer.parseInt(args[3]));
        bench.run();
    }
}
