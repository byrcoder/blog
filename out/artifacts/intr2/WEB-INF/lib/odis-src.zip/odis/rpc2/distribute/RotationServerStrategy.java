/**
 * @(#)RotationServerStrategy.java, 2012-11-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.List;

/**
 * Round-Robin Scheduling distribute strategy
 * 
 * @author wangfk
 */
public final class RotationServerStrategy implements IDistributeStrategy {
    private List<InetSocketAddress> InetSocketAddressList;

    private int index = -1;

    /**
     * Construct a round-Robin Scheduling distribute strategy by
     * <tt>inetSocketAddressList</tt>
     * 
     * @param inetSocketAddressList
     */
    public RotationServerStrategy(List<InetSocketAddress> inetSocketAddressList) {
        this.InetSocketAddressList = inetSocketAddressList;
    }

    @Override
    public synchronized InetSocketAddress lookupService(Object distributeKey) {
        return InetSocketAddressList.get((index = (++index)
                % InetSocketAddressList.size()));
    }

    @Override
    public List<InetSocketAddress> listService() {
        return Collections.unmodifiableList(InetSocketAddressList);
    }
}
