/**
 * @(#)RpcConstants.java, 2010-8-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;


/**
 * constants for rpc
 * 
 * @author zhangduo
 */
public interface RpcConstants {

    public static final int RPC_VERSION = 1;

    public static final long SERVER_CONNECTION_STACK_SIZE = 512 * 1024;

    public static final long CLIENT_CONNECTION_STACK_SIZE = 512 * 1024;

    public static final byte CALL_SUCCESS = 0;

    public static final byte CALL_EXCEPTION = 1;

    /**
     * no param
     */
    public static final int CALL_ID_HEARTBEAT = 0;

    /**
     * param is an int, return void
     */
    public static final int CALL_ID_SEND_RPC_VERSION = -1;

    /**
     * param is a String, return void
     */
    public static final int CALL_ID_SEND_CLIENT_NAME = -2;

    /**
     * param is a String, return void, or throw an {@link RpcAuthException}
     */
    public static final int CALL_ID_SEND_AUTH_INFO = -3;

    /**
     * param is a ProtocolVerifyEntry, return void, or throw an
     * {@link RpcProtocolException}<br>
     */
    public static final int CALL_ID_VERIFY_PROTOCOL = -4;

    /**
     * param is a String, return void
     */
    public static final int CALL_ID_SEND_DOMAIN = -5;

    /**
     * param is a String, return void
     */
    public static final int CALL_ID_SEND_USERNAME = -6;

    /**
     * param is a StringPropertiesWritable, return a StringPropertiesWritable
     */
    public static final int CALL_ID_SEND_AND_GET_PROPS = -7;

    public static final String SERVER_PROP_CONNECTION_PER_CLIENT = "ConnectionPerClient";

    public static final String SERVER_PROP_HEARTBEAT_INTERVAL = "HeartbeatInterval";

    public static final String SERVER_PROP_IO_MODE = "IOMode";

    public static final String SERVER_PROP_IO_MODE_BIO = "BIO";

    public static final String SERVER_PROP_IO_MODE_NIO = "NIO";

    public static final String CLIENT_PROP_RPC_TIMEOUT = "RpcTimeout";

    public static final String CLIENT_PROP_IO_MODE = "IOMode";

    public static final String CLIENT_PROP_IO_MODE_BIO = "BIO";

    public static final String CLIENT_PROP_IO_MODE_NIO = "NIO";

    public static final String CLIENT_PROP_LANGUAGE = "Language";

    public static final String CLIENT_PROP_LANGUAGE_JAVA = "Java";

    public static final String CLIENT_PROP_LANGUAGE_C = "C";
    
    public static final int PURGE_TIMEOUT_PENDING_CALLS_THRESHOLD = 1000;
}
