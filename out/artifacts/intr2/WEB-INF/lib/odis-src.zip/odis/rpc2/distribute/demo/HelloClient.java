/**
 * @(#)HelloClient.java, 2013-1-6. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute.demo;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

import odis.rpc2.RpcException;
import odis.rpc2.distribute.DistributeRPC;
import odis.rpc2.distribute.IDistributeStrategy;

/**
 * Demo project, distributed rpc client
 * 
 * @author wangfk
 */
public class HelloClient {
    static class SexDistributeStrategy implements IDistributeStrategy {
        private InetSocketAddress maleService;

        private InetSocketAddress femaleService;

        private List<InetSocketAddress> serviceList;

        public SexDistributeStrategy() {
            maleService = new InetSocketAddress(MaleHelloService.port);
            femaleService = new InetSocketAddress(FemaleHelloService.port);
            serviceList = new ArrayList<InetSocketAddress>();
            serviceList.add(maleService);
            serviceList.add(femaleService);
        }

        @Override
        public InetSocketAddress lookupService(Object distributeKey)
                throws RpcException {
            String sex = (String) distributeKey;
            if ("male".equalsIgnoreCase(sex) || "man".equalsIgnoreCase(sex)) {
                return maleService;
            } else if ("female".equalsIgnoreCase(sex)
                    || "woman".equalsIgnoreCase(sex)) {
                return femaleService;
            } else {
                throw new RpcException(
                        "Distribute strategy error, unknown sex value: " + sex);
            }
        }

        @Override
        public List<InetSocketAddress> listService() throws RpcException {
            return serviceList;
        }
    }

    public static void main(String args[]) throws RpcException {
        HelloProtocol helloProxy = DistributeRPC.getNIOProxy(
                HelloProtocol.class, new SexDistributeStrategy());
        try {
            System.out.println(helloProxy.sayHello("Abbot", "George ", "Male"));
            System.out.println(helloProxy.sayHello("Adams ", "Wood", "Man"));
            System.out.println(helloProxy.sayHello("John", "Brook", "Male"));
            System.out.println(helloProxy.sayHello("Amy", "Cook", "Female"));
            System.out.println(helloProxy.sayHello("Jane", "Macadam", "woman"));
            System.out.println(helloProxy.sayHello("Sarah", "Grey", "unknown"));
        } finally {
            DistributeRPC.close(helloProxy);
        }
    }
}
