/**
 * @(#)RpcDistributeConnection.java, 2012-3-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.net.InetSocketAddress;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;

/**
 * Rpc connections with special distribute strategy
 * 
 * @author wangfk
 */
public class RpcDistributeConnection extends DistributeConnection {
    /**
     * Enum of the rpc type
     */
    public enum RpcType {
        TCP, UDP, NIO
    }

    private RpcType rpcType;

    private long timeout;

    private String domain;

    private String authInfo;

    private String username;

    /**
     * Construct a distribute rpc connection
     */
    public RpcDistributeConnection(IDistributeStrategy distributeStrategy,
            RpcType rpcType, long timeout, String domain, String authInfo,
            String username) {
        super(distributeStrategy);
        this.rpcType = rpcType;
        this.timeout = timeout;
        this.domain = domain;
        this.authInfo = authInfo;
        this.username = username;
    }

    protected <T> T getProxy(InetSocketAddress location, Class<T> protocolClazz)
            throws RpcException {
        switch (rpcType) {
            case NIO:
                return RPC.getNIOProxy(protocolClazz, location, authInfo,
                        domain, username, timeout);
            case TCP:
                return RPC.getProxy(protocolClazz, location, authInfo, domain,
                        username, timeout);
            case UDP:
                return RPC.getUDPProxy(protocolClazz, location);
            default:
                throw new RpcException("Unknown rpc type: " + rpcType);
        }
    }

    @Override
    protected void closeProxy(Object proxy) {
        RPC.close(proxy);
    }

    @Override
    public String toString() {
        return "RpcDistributeConnection [timeout=" + timeout + ", domain="
                + domain + ", authInfo=" + authInfo + ", username=" + username
                + "]";
    }
}
