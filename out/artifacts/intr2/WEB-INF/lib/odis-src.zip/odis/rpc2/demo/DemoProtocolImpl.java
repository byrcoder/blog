/**
 * @(#)DemoProtoclImpl.java, 2011-7-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.demo;

import java.io.IOException;

import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;

/**
 * @author zhangduo
 */
public class DemoProtocolImpl implements DemoProtocol {

    @Override
    public int add(int a, int b) throws RpcException, NumberOverflowException {
        if (a > 0 && b > 0 && a + b <= 0) {
            throw new NumberOverflowException();
        }
        if (a < 0 && b < 0 && a + b >= 0) {
            throw new NumberOverflowException();
        }
        return a + b;
    }

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(args[0]);
        AbstractRpcServer server = RPC.getServer(DemoProtocol.class,
                new DemoProtocolImpl(), port, 10);
        server.start();
        System.out.println("RpcServer started on port " + port);
        try {
            server.join();
        } catch (InterruptedException e) {}
        System.out.println("RpcServer ended");
    }

}
