/**
 * @(#)AllPermitPermissionManager.java, 2010-11-24. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import odis.rpc2.AbstractRpcServer.Call;

/**
 * A permissionManager that always return PERMIT.
 * 
 * @author zhangduo
 */
public class AllPermitPermissionManager implements PermissionManager {

    @Override
    public Status getStatus() {
        return Status.NORMAL;
    }

    @Override
    public void finishedCall(Call call) {}

    @Override
    public PermitType getPermission(Call call) {
        return PermitType.PERMIT;
    }

}
