/**
 * @(#)UserId.java, 2011-7-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy; 

/**
 * Annotation for marking the special arguments as the distribute key
 *
 * @author wangfk
 *
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface DistributeKey {
}
