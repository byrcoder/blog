/**
 * @(#)ManyConnProtocolImpl.java, 2010-12-24. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.bench;

import java.io.IOException;
import java.util.Random;

import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;

/**
 * @author zhangduo
 */
public class ManyConnProtocolImpl implements IManyConnProtocol {

    private char[] base = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();

    @Override
    public String rand(long seed) throws RpcException {
        Random rand = new Random(seed);
        int length = 10 + rand.nextInt(100);
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < 100; i++) {
            sb.setLength(0);
            for (int j = 0; j < length; j++) {
                sb.append(base[rand.nextInt(base.length)]);
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) throws IOException {
        AbstractRpcServer server;
        int port = Integer.parseInt(args[1]);
        int handlerCount = Integer.parseInt(args[2]);
        if (args[0].equals("BIO")) {
            server = RPC.getServer(IManyConnProtocol.class,
                    new ManyConnProtocolImpl(), port, handlerCount);
        } else if (args[0].equals("NIO")) {
            server = RPC.getNIOServer(IManyConnProtocol.class,
                    new ManyConnProtocolImpl(), port, handlerCount);
        } else {
            throw new IllegalArgumentException();
        }
        //server.setServerCallListener(new ServerCallListenerImpl());
        server.start();
        try {
            server.join();
        } catch (InterruptedException e) {}
    }

}
