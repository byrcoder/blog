/**
 * @(#)RpcServer.java, 2010-8-7. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.lib.StringPropertiesWritable;
import odis.serialize.lib.StringWritable;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * An RpcServer using Blocking IO to communicate with RpcClient.
 * 
 * @author zhangduo
 */
public class RpcServer extends AbstractRpcServer {

    private static final Logger LOG = LogFormatter.getLogger(RpcServer.class);

    private class ConnectionImpl extends Connection implements Runnable {
        private static final int BUFFER_SIZE = 8 * 1024;

        private static final boolean TCP_NO_DELAY = true;

        private Socket socket;

        private OutputStream rawOut;

        private CDataOutputStream initOut;

        private CDataInputStream in;

        private CDataOutputStream out;

        private ReservedByteArrayOutputStream byteArrayOut;

        private Thread thread;

        public ConnectionImpl(Socket socket) throws IOException {
            this.socket = socket;
            this.clientAddr = new InetSocketAddress(socket.getInetAddress(),
                    socket.getPort());
            socket.setTcpNoDelay(TCP_NO_DELAY);
            in = new CDataInputStream(new BufferedInputStream(
                    socket.getInputStream(), BUFFER_SIZE));
            rawOut = socket.getOutputStream();
            initOut = new CDataOutputStream(new BufferedOutputStream(rawOut,
                    BUFFER_SIZE));
        }

        @Override
        public String toString() {
            return "[Connection addr=" + socket.getRemoteSocketAddress() + "]";
        }

        @Override
        public void run() {
            LOG.info(thread.getName() + " started");
            try {
                byte[] idBuf = new byte[4];
                int off = 0;
                outer: while (running) {
                    while (off < 4) {
                        try {
                            int r = in.read(idBuf, off, 4 - off);
                            if (r >= 0) {
                                off += r;
                            } else {
                                // EOF
                                break outer;
                            }
                        } catch (SocketTimeoutException e) {
                            if (off > 0) {
                                throw e;
                            } else { // this may because we do not have any call
                                continue outer;
                            }
                        }
                    }
                    off = 0;
                    int id = CDataInputStream.readInt(idBuf, 0);
                    long receiveStart = System.currentTimeMillis();

                    if (clientName != null) {
                        receiveCall(clientName, receiveStart);
                    }

                    if (id == CALL_ID_HEARTBEAT) {
                        continue;
                    }
                    Call call = new Call();
                    call.id = id;
                    call.startTime = receiveStart;
                    call.conn = this;
                    if (id < 0) {
                        int len = in.readInt();
                        byte[] bytes = new byte[len];
                        in.readFully(bytes);
                        CDataInputStream dis = new CDataInputStream(
                                new ByteArrayInputStream(bytes));
                        switch (id) {
                            case CALL_ID_SEND_RPC_VERSION:
                                int rpcVersion = dis.readInt();
                                call.args = new Object[] {
                                    rpcVersion
                                };
                                receiveRpcVersion(call);
                                break;
                            case CALL_ID_SEND_CLIENT_NAME:
                                String clientName = StringWritable.readString(dis);
                                call.args = new Object[] {
                                    clientName
                                };
                                receiveClientName(call);
                                break;

                            case CALL_ID_SEND_AUTH_INFO:
                                String authInfo = StringWritable.readString(dis);
                                call.args = new Object[] {
                                    authInfo
                                };
                                doAuth(call);
                                break;
                            case CALL_ID_VERIFY_PROTOCOL:
                                ProtocolVerifyEntry verifyEntry = new ProtocolVerifyEntry();
                                verifyEntry.readFields(dis);
                                call.args = new Object[] {
                                    verifyEntry
                                };
                                verifyProtocol(call);
                                break;
                            case CALL_ID_SEND_DOMAIN:
                                String domain = StringWritable.readString(dis);
                                call.args = new Object[] {
                                    domain
                                };
                                receiveDomain(call);
                                break;
                            case CALL_ID_SEND_USERNAME:
                                String username = StringWritable.readString(dis);
                                call.args = new Object[] {
                                    username
                                };
                                receiveUsername(call);
                                break;
                            case CALL_ID_SEND_AND_GET_PROPS:
                                StringPropertiesWritable properties = new StringPropertiesWritable();
                                properties.readFields(dis);
                                call.args = new Object[] {
                                    properties
                                };
                                receiveAndSendProps(call);
                                if (clientIOMode == CLIENT_IO_MODE_BIO) {
                                    out = new CDataOutputStream(
                                            new BufferedOutputStream(rawOut,
                                                    BUFFER_SIZE));
                                } else {
                                    byteArrayOut = new ReservedByteArrayOutputStream(
                                            BUFFER_SIZE, 8);
                                    out = new CDataOutputStream(byteArrayOut);
                                }
                                break;
                            default:
                                LOG.warning("unknown call id: " + id);
                        }
                        MiscUtils.safeClose(dis);
                        finishCall(call);
                        continue;
                    }
                    call.signature = in.readLong();
                    Instance instance = protocolMap.get(protocolName);
                    call.instance = instance.instance;
                    call.method = instance.signature2method.get(call.signature);
                    if (serverCallListener != null) {
                        try {
                            call.attach = serverCallListener.createAttach(info);
                            serverCallListener.startReceive(call.method,
                                    call.attach);
                        } catch (Throwable t) {}
                    }
                    try {
                        call.args = RpcSerializer.readArgs(call.method, in);
                    } catch (Throwable t) {
                        LOG.log(Level.WARNING, "read call " + call
                                + " args failed", t);
                        call.error = new RpcWritableException("read call "
                                + call + " args failed", t);
                        finishCall(call);
                        continue;
                    }
                    if (serverCallListener != null) {
                        try {
                            serverCallListener.endReceive(call.method,
                                    call.args, call.attach);
                        } catch (Throwable t) {}
                    }
                    boolean succ;
                    synchronized (queueLock) {
                        succ = callQueue.offer(call);
                        if (succ) {
                            queueLock.notify();
                        }
                    }
                    if (!succ) {
                        call.error = new RpcQueueFullExeption(
                                "RPC server queued call length reach max queue size "
                                        + queueSize);
                        finishCall(call);
                    }
                }
                if (running) {
                    LOG.info("Client " + socket.getRemoteSocketAddress()
                            + " disconnected");
                } else {
                    LOG.info("server is stopped, closing connection of client "
                            + socket.getRemoteSocketAddress());
                }
            } catch (EOFException e) {
                // This is what happens on linux when the other side or server
                // shuts down
                if (running) {
                    LOG.log(Level.WARNING,
                            "Client " + socket.getRemoteSocketAddress()
                                    + " disconnected", e);
                } else {
                    LOG.info("server is stopped, closing connection of client "
                            + socket.getRemoteSocketAddress());
                }
            } catch (SocketException e) {
                // This is what happens on Win32 when the other side or server
                // shuts down
                if (running) {
                    LOG.log(Level.WARNING,
                            "Client " + socket.getRemoteSocketAddress()
                                    + " disconnected", e);
                } else {
                    LOG.info("server is stopped, closing connection of client "
                            + socket.getRemoteSocketAddress());
                }
            } catch (Throwable t) {
                LOG.log(Level.SEVERE, "unexpected throwable caught, client "
                        + socket.getRemoteSocketAddress() + " disconnected", t);
            } finally {
                if (running) {
                    closeConnection(this);
                }
            }
            LOG.info(thread.getName() + " ended");
        }

        @Override
        public boolean finishCall(Call call) {
            try {
                if (call.id < 0) {
                    initOut.writeInt(call.id);
                    if (call.error == null) {
                        initOut.writeByte(CALL_SUCCESS);
                        if (call.id == CALL_ID_SEND_AND_GET_PROPS) {
                            ((StringPropertiesWritable) call.returnValue).writeFields(initOut);
                        }
                    } else {
                        initOut.writeByte(CALL_EXCEPTION);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        try {
                            ObjectOutputStream oos = new ObjectOutputStream(bos);
                            oos.writeObject(call.error);
                        } catch (Throwable t) {
                            // should not happen
                            LOG.log(Level.WARNING, "serialize exception "
                                    + call.error + " failed", t);
                            bos.reset();
                        }
                        initOut.writeVInt(bos.size());
                        bos.writeTo(initOut);
                    }
                    initOut.flush();
                    if (call.id == CALL_ID_SEND_AND_GET_PROPS) { // init end
                        initOut = null;
                    }
                    return true;
                }
                if (serverCallListener != null) {
                    try {
                        serverCallListener.startSend(call.method, call.attach);
                    } catch (Throwable t) {}
                }
                if (clientIOMode == CLIENT_IO_MODE_BIO) {
                    synchronized (out) {
                        out.writeInt(call.id);
                        out.writeByte(call.error == null ? CALL_SUCCESS
                                : CALL_EXCEPTION);
                        if (call.error == null) {
                            RpcSerializer.writeReturnValue(call.method,
                                    call.returnValue, out);
                        } else {
                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                            try {
                                ObjectOutputStream oos = new ObjectOutputStream(
                                        bos);
                                oos.writeObject(call.error);
                            } catch (Throwable t) {
                                // should not happen
                                LOG.log(Level.WARNING, "serialize exception "
                                        + call.error + " failed", t);
                                bos.reset();
                            }
                            out.writeVInt(bos.size());
                            bos.writeTo(out);
                        }
                        out.flush();
                    }
                } else {
                    synchronized (rawOut) {
                        byteArrayOut.clear();
                        if (call.error == null) {
                            out.writeByte(CALL_SUCCESS);
                            try {
                                RpcSerializer.writeReturnValue(call.method,
                                        call.returnValue, out);
                            } catch (Throwable t) {
                                LOG.log(Level.WARNING,
                                        "write return value for call " + call
                                                + " failed", t);
                                byteArrayOut.clear();
                                call.error = t;
                            }
                        }
                        if (call.error != null) {
                            out.writeByte(CALL_EXCEPTION);
                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                            try {
                                ObjectOutputStream oos = new ObjectOutputStream(
                                        bos);
                                oos.writeObject(call.error);
                            } catch (Throwable t) {
                                // should not happen
                                LOG.log(Level.WARNING, "serialize exception "
                                        + call.error + " failed", t);
                                bos.reset();
                            }
                            out.writeVInt(bos.size());
                            bos.writeTo(out);
                        }
                        byte[] data = byteArrayOut.data();
                        int size = byteArrayOut.size();
                        CDataOutputStream.writeInt(call.id, data, 0);
                        CDataOutputStream.writeInt(size - 8, data, 4);
                        rawOut.write(data, 0, size);
                        rawOut.flush();
                        byteArrayOut.clear(); // release the big byte buffer if we have a large return value.
                    }
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "unexpected throwable caught", t);
            }
            if (call != null && call.id > 0 && serverCallListener != null) {
                try {
                    serverCallListener.endSend(call.method, call.attach);
                } catch (Throwable t) {}
            }
            return true;
        }

        @Override
        public void shutdown() {
            MiscUtils.safeClose(in);
            MiscUtils.safeClose(out);
            MiscUtils.safeClose(socket);
        }
    }

    private class Listener extends Thread {
        private static final boolean TCP_NO_DELAY = true;

        private ServerSocket socket;

        public Listener() throws IOException {
            socket = new ServerSocket(port);
            if (port == 0) {
                port = socket.getLocalPort();
            }
            setDaemon(true);
            setName("Server listener on "
                    + socket.getInetAddress().getHostAddress() + ":" + port);
        }

        @Override
        public void run() {
            LOG.info(getName() + " started");
            while (running) {
                try {
                    Socket so = socket.accept();
                    so.setTcpNoDelay(TCP_NO_DELAY);
                    ConnectionImpl conn = new ConnectionImpl(so);
                    Thread t = new Thread(null, conn, "Server connection on "
                            + port + " from "
                            + conn.socket.getInetAddress().getHostAddress()
                            + ":" + conn.socket.getPort(),
                            RpcConstants.SERVER_CONNECTION_STACK_SIZE);
                    t.setDaemon(true);
                    conn.thread = t; // record thread for use during shutdown
                    t.start(); // start a new connection
                } catch (EOFException e) {
                    // zf: eof for linux according to orig nutch code
                } catch (SocketException e) {
                    // zf: eof for windows
                } catch (Throwable t) {
                    LOG.log(Level.SEVERE,
                            "unexpected throwable caught when accepting connections",
                            t);
                }
            }
            LOG.info(getName() + " ended");
        }

        public void close() {
            MiscUtils.safeClose(socket);
        }

    }

    protected RpcServer(int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime) {
        super(port, handlerCount, queueSize, maxConnPerClient,
                clientDisconnectTime);
        serverIOMode = SERVER_PROP_IO_MODE_BIO;
    }

    private Listener listener;

    @Override
    protected void startServer() throws IOException {
        listener = new Listener();
        listener.start();
    }

    @Override
    protected void stopServer() {
        listener.close();
        // connections will be shutdown by super class
    }

    @Override
    protected int getBoundPort() {
        if (listener != null) {
            return listener.socket.getLocalPort();
        } else {
            return -1;
        }
    }

}
