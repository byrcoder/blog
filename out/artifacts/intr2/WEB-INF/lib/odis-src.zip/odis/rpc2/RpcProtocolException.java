/**
 * @(#)RpcProtocolException.java, 2010-8-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Exception indicating that the protocol of RpcServer and RpcClient are not
 * compatible.
 * 
 * @author zhangduo
 */
public class RpcProtocolException extends RpcException {

    private static final long serialVersionUID = 4676455484894953041L;

    public RpcProtocolException() {
        super();
    }

    public RpcProtocolException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcProtocolException(String message) {
        super(message);
    }

    public RpcProtocolException(Throwable cause) {
        super(cause);
    }

}
