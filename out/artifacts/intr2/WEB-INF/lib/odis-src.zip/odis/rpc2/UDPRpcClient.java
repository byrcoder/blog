/**
 * @(#)UDPRpcClient.java, 2011-10-30. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Map;

import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;

/**
 * A simple rpc client using udp.
 * 
 * @author zhangduo
 */
public class UDPRpcClient<P> {

    private final Map<Method, Long> method2signature;

    private static final DatagramSocket socket;

    static {
        try {
            socket = new DatagramSocket();
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
    }

    final Class<P> protocol;

    final InetSocketAddress remoteAddr;

    protected UDPRpcClient(Class<P> protocol, InetSocketAddress remoteAddr) {
        this.protocol = protocol;
        this.method2signature = ProtocolVerifier.clientVerify(protocol);
        this.remoteAddr = remoteAddr;
    }

    /**
     * do a rpc call.
     * 
     * @param method
     * @param args
     * @throws IOException
     */
    public void call(Method method, Object[] args) throws IOException {
        DirectByteArrayOutputStream bos = new DirectByteArrayOutputStream();
        CDataOutputStream dos = new CDataOutputStream(bos);
        long signature = method2signature.get(method);
        dos.writeLong(signature);
        RpcSerializer.writeArgs(method, args, dos);
        int size = bos.size();
        byte[] buf = bos.getBuffer();
        DatagramPacket packet = new DatagramPacket(buf, 0, size, remoteAddr);
        socket.send(packet);
    }

    /**
     * close the udp socket.
     */
    public void close() {
        // do nothing, the socket is used by all clients.
    }
}
