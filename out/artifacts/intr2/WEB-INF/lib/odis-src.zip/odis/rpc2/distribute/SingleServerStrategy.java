/**
 * @(#)SingleServerStrategy.java, 2012-3-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import odis.rpc2.RpcException;

/**
 * Demo project, distribute strategy of the distributed service.
 * 
 * @author wangfk
 */
public class SingleServerStrategy implements IDistributeStrategy {

    private final InetSocketAddress inetSocketAddress;

    private final List<InetSocketAddress> serverList;

    /**
     * Constructed the SingleServerStrategy with a single inetSocketAddress
     * 
     * @param inetSocketAddress
     */
    public SingleServerStrategy(InetSocketAddress inetSocketAddress) {
        this.inetSocketAddress = inetSocketAddress;
        serverList = Collections.unmodifiableList(new ArrayList<InetSocketAddress>());
        serverList.add(inetSocketAddress);
    }

    @Override
    public InetSocketAddress lookupService(Object distributeKey)
            throws RpcException {
        return inetSocketAddress;
    }

    @Override
    public List<InetSocketAddress> listService() throws RpcException {
        return serverList;
    }

}
