/**
 * @(#)DomainPermissionManager.java, 2010-8-7. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.rpc2.AbstractRpcServer.Call;
import toolbox.misc.LogFormatter;

/**
 * A permission manager based on domain.<br>
 * If more than {@link DomainPermissionManager#HIGH_THRESHOLD} handlers are
 * used, then we will enter {@link Status#EMERGENCY} mode, which means we will
 * block the calls from domain that have used more than average handlers(e.g. 10
 * handlers, 2 domain, average handlers should be 5). We will enter
 * {@link Status#NORMAL} mode if handlers use rate fall under
 * {@link DomainPermissionManager#LOW_THRESHOLD}.
 * 
 * @author zhangduo
 */
public class DomainPermissionManager implements PermissionManager {

    private static final Logger LOG = LogFormatter.getLogger(DomainPermissionManager.class);

    private final int totalHandlerCount;

    private int usedHandlerCount;

    private Map<String, Integer> domainHandlerCountMap = new HashMap<String, Integer>();

    private int maxDomainCount = 0;

    /**
     * Default Constructor.
     * 
     * @param totalHandlerCount
     */
    public DomainPermissionManager(int totalHandlerCount) {
        this.totalHandlerCount = totalHandlerCount;
    }

    private Status status = Status.NORMAL;

    private static final double HIGH_THRESHOLD = 0.95d;

    private static final double LOW_THRESHOLD = 0.85d;

    /**
     * return the {@link Status} of the manager
     */
    public synchronized Status getStatus() {
        return status;
    }

    /**
     * return {@link PermitType} of a {@link Call}
     */
    public synchronized PermitType getPermission(Call call) {
        long timeout = call.conn.clientTimeout;
        if (timeout > 0
                && System.currentTimeMillis() - call.startTime >= timeout) {
            return PermitType.TIMEOUT;
        }
        String domain = call.conn.domain;
        if (status == Status.NORMAL) {
            usedHandlerCount++;
            Integer i = domainHandlerCountMap.get(domain);
            if (i == null) {
                domainHandlerCountMap.put(domain, 1);
            } else {
                domainHandlerCountMap.put(domain, i + 1);
            }
            if (domainHandlerCountMap.size() > maxDomainCount) {
                maxDomainCount = domainHandlerCountMap.size();
            }
            // do not limit when there is only one domain
            if (maxDomainCount > 1) {
                double usedRate = (double) usedHandlerCount / totalHandlerCount;
                if (usedRate > HIGH_THRESHOLD) {
                    LOG.warning("Handler used rate " + usedHandlerCount + "/"
                            + totalHandlerCount + " exceed threshold "
                            + HIGH_THRESHOLD + ", enter emergency status");
                    status = Status.EMERGENCY;
                }
            }
            return PermitType.PERMIT;
        } else {
            int quotaPerDomain = (int) Math.ceil((double) totalHandlerCount
                    / domainHandlerCountMap.size());
            if (quotaPerDomain > totalHandlerCount * LOW_THRESHOLD) {
                quotaPerDomain = (int) (totalHandlerCount * LOW_THRESHOLD);
            }
            Integer i = domainHandlerCountMap.get(domain);
            if (i == null || i < quotaPerDomain) {
                usedHandlerCount++;
                if (i == null) {
                    domainHandlerCountMap.put(domain, 1);
                } else {
                    domainHandlerCountMap.put(domain, i + 1);
                }
                return PermitType.PERMIT;
            } else {
                LOG.warning("Domain " + domain + " use " + i
                        + " handlers, which is larger than permit count "
                        + quotaPerDomain);
                return PermitType.WAIT;
            }
        }
    }

    /**
     * you must call when finish a {@link Call}
     */
    public synchronized void finishedCall(Call call) {
        String domain = call.conn.domain;
        Integer i = domainHandlerCountMap.get(domain);
        if (i == null) {
            LOG.warning("no handler used by domain " + domain);
            return;
        }
        usedHandlerCount--;
        if (i == 1) {
            domainHandlerCountMap.remove(domain);
        } else {
            domainHandlerCountMap.put(domain, i - 1);
        }
        if (status == Status.EMERGENCY) {
            double usedRate = (double) usedHandlerCount / totalHandlerCount;
            if (usedRate < LOW_THRESHOLD) {
                LOG.warning("Handler used rate " + usedHandlerCount + "/"
                        + totalHandlerCount + " fall under threshold "
                        + LOW_THRESHOLD + ", enter normal status");
                status = Status.NORMAL;
            }
        }
    }
}
