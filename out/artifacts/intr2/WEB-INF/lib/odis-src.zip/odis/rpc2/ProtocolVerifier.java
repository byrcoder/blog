/**
 * @(#)ProtocolVerifier.java, 2010-8-5. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.MD5Writable;
import toolbox.misc.LogFormatter;

/**
 * Check whether an interface can be an rpc protocol.
 * 
 * @author zhangduo
 */
public class ProtocolVerifier {

    private static final Logger LOG = LogFormatter.getLogger(ProtocolVerifier.class);

    /**
     * for non-array type, return true if it is primitive type, enum, Boolean,
     * Byte, Character, Short, Integer, Long, Float, Double, String, class
     * implements IWritable.<br>
     * for array type, return true if its component type return true when
     * calling this method.
     * 
     * @param type
     * @return
     */
    public static boolean isWritable(Class<?> type) {
        if (type.isPrimitive()) {
            return true;
        }
        if (IWritable.class.isAssignableFrom(type)) {
            return true;
        }
        if (type.isEnum()) {
            return true;
        }
        if (type == Boolean.class) {
            return true;
        }
        if (type == Byte.class) {
            return true;
        }
        if (type == Character.class) {
            return true;
        }
        if (type == Short.class) {
            return true;
        }
        if (type == Integer.class) {
            return true;
        }
        if (type == Long.class) {
            return true;
        }
        if (type == Float.class) {
            return true;
        }
        if (type == Double.class) {
            return true;
        }
        if (type == String.class) {
            return true;
        }
        if (type.isArray()) {
            return isWritable(type.getComponentType());
        }
        if (Collection.class.isAssignableFrom(type)) {
            return true;
        }
        if (Map.class.isAssignableFrom(type)) {
            return true;
        }
        return false;
    }

    private static void verifyDeclare(Class<?> protocol) {
        // check if it is an interface
        if (!protocol.isInterface()) {
            throw new IllegalArgumentException(protocol
                    + " is not an interface");
        }
        // check for throw RpcException
        next_method: for (Method method: protocol.getMethods()) {
            for (Class<?> exceptionType: method.getExceptionTypes()) {
                if (exceptionType.isAssignableFrom(RpcException.class)) {
                    continue next_method;
                }
            }
            throw new RuntimeException("Method " + method
                    + " of RPC interface " + protocol
                    + " is not declared as throwing RpcException");
        }

        // check for writable
        for (Method method: protocol.getMethods()) {
            if (!isWritable(method.getReturnType())) {
                throw new RuntimeException("Method " + method
                        + " of RPC interface " + protocol + " return type "
                        + method.getReturnType() + " is not writable");
            }
            Class<?>[] parameterTypes = method.getParameterTypes();
            for (int i = 0; i < parameterTypes.length; i++) {
                if (!isWritable(parameterTypes[i])) {
                    throw new RuntimeException("Method " + method
                            + " of RPC interface " + protocol + " parameter "
                            + i + " type " + parameterTypes[i]
                            + " is not writable");
                }
            }
        }
    }

    private static Map<Long, Method> checkConflict(Class<?> protocol) {
        Map<Long, Method> signature2method = new HashMap<Long, Method>(
                protocol.getMethods().length);

        // check for method signature
        for (Method method: protocol.getMethods()) {
            long signature = getSignature(method);

            Method conflict = signature2method.get(signature);
            if (conflict != null) {
                LOG.info("used signature: " + signature2method);
                throw new RuntimeException("Method " + method + " and "
                        + conflict + " of RPC interface " + protocol
                        + " has same signature " + signature);
            }
            signature2method.put(signature, method);
        }
        return signature2method;
    }

    /**
     * Verify a rpc protocol, and return a signature->method map.<br>
     * If verify failed, will throw runtime exception.<br>
     * Rules:<br>
     * All method must throws {@link RpcException}.<br>
     * Return type and parameter type is writable.See {@link #isWritable} <br>
     * method signature has no conflict.<br>
     * If conflict happens, use {@link MethodSignature} to set signature
     * manually.
     * 
     * @param protocol
     */
    public static Map<Long, Method> serverVerify(Class<?> protocol) {
        verifyDeclare(protocol);
        return checkConflict(protocol);
    }

    /**
     * Verify a protocl at client side.The rule is same with
     * {@link #serverVerify(Class)}, but the returned <code>Map</code>'s key and
     * value are reversed.
     * 
     * @param protocol
     * @return
     */
    public static Map<Method, Long> clientVerify(Class<?> protocol) {
        verifyDeclare(protocol);
        Map<Long, Method> signature2method = checkConflict(protocol);
        Map<Method, Long> method2signature = new HashMap<Method, Long>(
                signature2method.size());
        for (Map.Entry<Long, Method> entry: signature2method.entrySet()) {
            method2signature.put(entry.getValue(), entry.getKey());
        }
        return method2signature;
    }

    public static long getSignature(Method method) {
        MethodSignature signatureHint = method.getAnnotation(MethodSignature.class);
        if (signatureHint == null) {
            StringBuilder sb = new StringBuilder(method.getName());
            for (Class<?> paramType: method.getParameterTypes()) {
                sb.append(paramType);
            }
            return MD5Writable.halfDigest(sb.toString());
        } else {
            return signatureHint.value();
        }
    }
}
