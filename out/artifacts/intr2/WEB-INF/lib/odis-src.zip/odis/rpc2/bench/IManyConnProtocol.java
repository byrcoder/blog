/**
 * @(#)IManyConnProtocol.java, 2010-12-24. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.bench;

import odis.rpc2.RpcException;

/**
 * Test Interface of many connection
 * 
 * @author zhangduo
 */
public interface IManyConnProtocol {

    /**
     * generate random string based on the seed
     * 
     * @param seed
     * @return
     * @throws RpcException
     */
    String rand(long seed) throws RpcException;
}
