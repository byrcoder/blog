/**
 * @(#)HelloProtocol.java, 2013-1-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute.demo;

import odis.rpc2.RpcException;
import odis.rpc2.distribute.DistributeKey;

/**
 * Demo project, rpc service interface
 * 
 * @author wangfk
 */
public interface HelloProtocol {

    /**
     * demo method
     */
    public String sayHello(String firstName, String lastName,
            @DistributeKey String sex) throws RpcException;
}
