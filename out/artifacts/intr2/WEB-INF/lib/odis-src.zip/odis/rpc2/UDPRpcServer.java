/**
 * @(#)UDPRpcServer.java, 2011-10-30. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.ReusableByteArrayInputStream;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

/**
 * A simple rpc server using udp.
 * 
 * @author zhangduo
 */
public class UDPRpcServer {
    private static final Logger LOG = LogFormatter.getLogger(UDPRpcServer.class);

    private static final int MAX_DATAGRAM_SIZE = (int) (64 * UnitUtils.K);

    private final Map<Long, Method> signature2method;

    private final Object instance;

    private final Listener listener;

    private volatile boolean running = true;

    private final int port;

    class Listener extends Thread {
        private DatagramSocket serverSocket;

        SocketAddress remoteAddr;

        public Listener() throws IOException {
            super("UDP Server listener on " + port);
            this.setDaemon(true);
            serverSocket = new DatagramSocket(port);
        }

        @Override
        public void run() {
            byte[] datagramBuffer = new byte[MAX_DATAGRAM_SIZE];
            ReusableByteArrayInputStream bis = new ReusableByteArrayInputStream(
                    datagramBuffer);
            CDataInputStream dis = new CDataInputStream(bis);
            while (running) {
                DatagramPacket packet = new DatagramPacket(datagramBuffer,
                        datagramBuffer.length);
                try {
                    serverSocket.receive(packet);
                    bis.setBuffer(datagramBuffer, 0, packet.getLength());
                    long signature = dis.readLong();
                    Method method = signature2method.get(signature);
                    if (method == null) {
                        continue;
                    }
                    Object[] args = RpcSerializer.readArgs(method, dis);
                    remoteAddr = packet.getSocketAddress();
                    method.invoke(instance, args);
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "exception during udp call", t);
                }
            }
        }

        public void shutdown() {
            serverSocket.close();
        }
    }

    protected <P> UDPRpcServer(int port, Class<P> protocol, P instance)
            throws IOException {
        this.port = port;
        this.signature2method = ProtocolVerifier.serverVerify(protocol);
        this.instance = instance;
        this.listener = new Listener();
    }

    /**
     * Start rpc server
     */
    public void start() {
        listener.start();
    }

    /**
     * Stop rpc server
     */
    public void stop() {
        running = false;
        listener.shutdown();
    }
}
