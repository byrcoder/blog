/**
 * @(#)ClientConnectListener.java, 2010-8-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * listener for client connect and disconnect event.
 * 
 * @author zhangduo
 */
public interface ClientConnectListener {
    /**
     * client connect
     * 
     * @param clientName
     */
    void clientConnect(ClientInfo clientInfo);

    /**
     * client disconnect
     * 
     * @param clientName
     */
    void clientDisconnect(ClientInfo clientInfo);
}
