/**
 * @(#)DemoClient.java, 2011-7-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.demo;

import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;

/**
 * @author zhangduo
 */
public class DemoClient {
    public static void main(String[] args) throws RpcException,
            NumberOverflowException, SecurityException, NoSuchMethodException,
            InterruptedException, ExecutionException {
        String host = args[0];
        int port = Integer.parseInt(args[1]);
        // timeout is 5000ms
        DemoProtocol proxy = RPC.getProxy(DemoProtocol.class,
                new InetSocketAddress(host, port), 5000);
        System.out.println(proxy.add(1, 2));
        try {
            proxy.add(Integer.MAX_VALUE, Integer.MAX_VALUE);
        } catch (NumberOverflowException e) {
            // got expected exception
            e.printStackTrace();
        }
        // try an async call
        Method method = DemoProtocol.class.getMethod("add", int.class,
                int.class);
        Future<Integer> future = RPC.asyncInvoke(proxy, method, 2, 3);
        System.out.println(future.get());

        future = RPC.asyncInvoke(proxy, method, Integer.MAX_VALUE,
                Integer.MAX_VALUE);
        try {
            future.get();
        } catch (ExecutionException e) {
            // got expected exception
            e.printStackTrace();
        }
        RPC.close(proxy);
    }
}
