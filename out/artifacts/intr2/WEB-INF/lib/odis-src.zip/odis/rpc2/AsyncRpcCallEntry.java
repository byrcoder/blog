/**
 * @(#)AsyncRpcCallEntry.java, 2012-5-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;


/**
 * An entry describe an async rpc call at server side.
 * 
 * @author zhangduo
 */
public interface AsyncRpcCallEntry {

    /**
     * Set return value.
     * 
     * @param returnValue
     */
    void setReturnValue(Object returnValue);

    /**
     * Get return value.
     * 
     * @return
     */
    Object getReturnValue();

    /**
     * Set throwable.
     * 
     * @param error
     */
    void setError(Throwable error);

    /**
     * Get throwable.
     * 
     * @return
     */
    Throwable getError();

    /**
     * Finish the call, which means send return value or error back to client.
     */
    void finishCall();
}
