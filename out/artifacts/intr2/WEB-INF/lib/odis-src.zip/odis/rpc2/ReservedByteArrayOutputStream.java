/**
 * @(#)ReservedByteArrayOutputStream.java, 2010-12-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.io.OutputStream;

/**
 * A ByteArrayOutputStream that reserve some bytes at the beginning of internal
 * byte array.
 * 
 * @author zhangduo
 */
public class ReservedByteArrayOutputStream extends OutputStream {

    private final int reserved;

    private byte[] buffer;

    private byte[] actualBuffer;

    private int count;

    /**
     * Constructor with a default size, and reserved bytes.
     * 
     * @param size
     * @param reserved
     */
    public ReservedByteArrayOutputStream(int size, int reserved) {
        this.buffer = new byte[size];
        this.reserved = reserved;
        this.actualBuffer = buffer;
        count = reserved;
    }

    public int getReserved() {
        return reserved;
    }

    @Override
    public void write(int b) {
        if (count == actualBuffer.length) {
            byte[] newBuffer = new byte[actualBuffer.length << 1];
            System.arraycopy(actualBuffer, reserved, newBuffer, reserved, count
                    - reserved);
            actualBuffer = newBuffer;
        }
        actualBuffer[count++] = (byte) b;
    }

    @Override
    public void write(byte[] b) throws IOException {
        write(b, 0, b.length);
    }

    @Override
    public void write(byte[] b, int off, int len) {
        if (len == 0) {
            return;
        }
        int newCount = count + len;
        if (newCount > actualBuffer.length) {
            byte[] newBuffer = new byte[Math.max(actualBuffer.length << 1,
                    newCount)];
            if (count > reserved) {
                System.arraycopy(actualBuffer, reserved, newBuffer, reserved,
                        count - reserved);
            }
            actualBuffer = newBuffer;
        }
        System.arraycopy(b, off, actualBuffer, count, len);
        count = newCount;
    }

    /**
     * Get the internal buffer.<br>
     * <strong>NOTE:</strong> the buffer contains the reserved bytes at
     * beginning.
     * 
     * @return
     */
    public byte[] data() {
        return actualBuffer;
    }

    /**
     * Return the bytes written.This contains the reserved bytes.
     * 
     * @return
     */
    public int size() {
        return count;
    }

    /**
     * reset buffer to default size, and clear the data written.
     */
    public void clear() {
        actualBuffer = buffer;
        count = reserved;
    }

    /**
     * This will set buffer to null.
     */
    @Override
    public void close() {
        actualBuffer = buffer = null;
    }
}
