/**
 * @(#)DistributeConnection.java, 2012-3-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import odis.rpc2.RpcException;
import odis.util.ThreadLocalRandomData;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class is for rpc connection management and service invoking by
 * distribute strategy
 * 
 * @author wangfk
 * @since 2012-07-20 {@link #getAllProxies(Class)} method is added
 */
public abstract class DistributeConnection implements Closeable {
    private static final Log LOG = LogFactory.getLog(DistributeConnection.class);

    private IDistributeStrategy distributeStrategy;

    // Cached data operation rpc connection
    // Mapping: data store address -> RPC data store
    private final Map<Class<?>, Map<InetSocketAddress, Object>> cachedProxy = new HashMap<Class<?>, Map<InetSocketAddress, Object>>();

    private volatile boolean closed;

    /**
     * Construct the distribute connection by the <tt>distributeStrategy</tt>
     * 
     * @param distributeStrategy
     */
    public DistributeConnection(IDistributeStrategy distributeStrategy) {
        this.distributeStrategy = distributeStrategy;
    }

    synchronized <T> T getDistributeSerivceProxy(Class<T> clazz,
            final Object distributeKey, int distributeKeyLocation)
            throws RpcException {
        if (closed) {
            throw new RpcException("Rpc connection is closed already");
        }

        InetSocketAddress address = null;
        if (distributeKeyLocation == -1) {
            List<InetSocketAddress> listService = distributeStrategy.listService();
            address = listService.get(ThreadLocalRandomData.current().nextInt(
                    listService.size()));
        } else {
            address = distributeStrategy.lookupService(distributeKey);
        }
        return getDistributeServiceProxy(address, clazz);
    }

    private final synchronized <T> T getDistributeServiceProxy(
            final InetSocketAddress addr, Class<T> clazz) throws RpcException {
        Map<InetSocketAddress, Object> mapProxy = getProxyMapByClazz(clazz);
        T proxy = clazz.cast(mapProxy.get(addr));
        if (proxy != null) {
            return proxy;
        }
        // construct the rpc proxy and update the cache
        proxy = getProxy(addr, clazz);
        LOG.info("Build service proxy for " + clazz.getName() + ", server="
                + addr);
        mapProxy.put(addr, proxy);
        return proxy;
    }

    private <T> Map<InetSocketAddress, Object> getProxyMapByClazz(Class<T> clazz) {
        Map<InetSocketAddress, Object> mapProxy = cachedProxy.get(clazz);
        if (mapProxy == null) {
            mapProxy = new HashMap<InetSocketAddress, Object>();
            cachedProxy.put(clazz, mapProxy);
        }
        return mapProxy;
    }

    /**
     * obtain all proxies of type T
     * 
     * @param clazz
     *            <code>Class</code> object of type T
     * @return an array of all proxies of type T
     */
    @SuppressWarnings("unchecked")
    public synchronized <T> T[] getAllProxies(Class<T> clazz)
            throws RpcException {
        List<InetSocketAddress> addrs = distributeStrategy.listService();
        Map<InetSocketAddress, Object> mapProxy = getProxyMapByClazz(clazz);
        T[] ret = (T[]) Array.newInstance(clazz, addrs.size());
        for (int i = 0, n = addrs.size(); i < n; i++) {
            InetSocketAddress addr = addrs.get(i);
            T proxy = clazz.cast(mapProxy.get(addr));
            if (proxy == null) {
                proxy = getProxy(addr, clazz);
                mapProxy.put(addr, proxy);
            }
            ret[i] = proxy;
        }
        return ret;
    }

    /**
     * Establish an service proxy for store server whose address is
     * <i>location</i>
     * 
     * @param location
     *            store server location
     * @param clazz
     *            class type of the proxy
     * @return RPC proxy for store server
     * @throws YDriveException
     */
    protected abstract <T> T getProxy(InetSocketAddress location,
            Class<T> protocolClazz) throws RpcException;

    protected abstract <T> void closeProxy(T proxy);

    /**
     * Execute the <i>call</i> method of <i>callable</i> until succeed or
     * retries exhausted. ServerCallable would find the right store server for
     * the passed distributeKey, so use store server proxy in callable directly.
     * 
     * @see DistributeRpcCallable
     * @param callable
     * @return
     */
    public <T> Object execute(DistributeRpcCallable<T> callable)
            throws Exception {
        if (closed) {
            throw new RpcException("YDrive connection is closed already");
        }

        try {
            callable.instantiateProxy(this);
            return callable.call();
        } catch (RpcException e) {
            removeBrokenConnection(callable.getProxy(), callable.getClazz());
            throw e;
        }
    }

    /**
     * Remove a rpc connection from cached proxies if it is broken. Usually this
     * method is invoked when a <code>RpcException</code> is received.
     */
    public synchronized <T> void removeBrokenConnection(T proxy, Class<T> clazz) {
        if (proxy == null) {
            return;
        }
        Map<InetSocketAddress, Object> mapProxy = cachedProxy.get(clazz);
        for (Iterator<Entry<InetSocketAddress, Object>> iter = mapProxy.entrySet().iterator(); iter.hasNext();) {
            Entry<InetSocketAddress, Object> entry = iter.next();
            if (entry.getValue() == proxy) {
                iter.remove();
            }
        }
        closeProxy(proxy);
    }

    private synchronized void clearCachedConnections() {
        for (Map<InetSocketAddress, Object> mapProxy: cachedProxy.values()) {
            for (Iterator<Entry<InetSocketAddress, Object>> iter = mapProxy.entrySet().iterator(); iter.hasNext();) {
                Entry<InetSocketAddress, Object> entry = iter.next();
                closeProxy(entry.getValue());
                iter.remove();
            }
        }
    }

    @Override
    public void close() throws IOException {
        if (closed) {
            LOG.info("This connection has already been closed...");
            return;
        }

        LOG.info("Stop distribute connection.");
        closed = true;
        clearCachedConnections();
        if (distributeStrategy instanceof Closeable) {
            ((Closeable) distributeStrategy).close();
        }
    }

}
