/**
 * @(#)MaleHelloService.java, 2013-1-6. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.distribute.demo;

import odis.rpc2.NIORpcServer;
import odis.rpc2.RPC;

/**
 * Demo project, implementation of the rpc service interface
 * 
 * @author wangfk
 */
public class MaleHelloService implements HelloProtocol {
    static final int port = 23355;

    @Override
    public String sayHello(String firstName, String lastName, String sex) {
        return "Hello, my name is " + firstName + " " + lastName + ", "
                + "you can call me Mr " + lastName;
    }

    public static void main(String args[]) throws Exception {
        NIORpcServer nioServer = RPC.getNIOServer(HelloProtocol.class,
                new MaleHelloService(), port, 1);
        nioServer.start();
        nioServer.join();
    }
}
