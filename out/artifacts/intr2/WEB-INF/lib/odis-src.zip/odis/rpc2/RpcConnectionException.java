/**
 * @(#)RpcConnectionException.java, 2010-10-22. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Exception indicating that connection to RpcServer is not allowed(e.g., we
 * reach the maxConnectionPerClient limit).
 * 
 * @author zhangduo
 */
public class RpcConnectionException extends RpcException {

    private static final long serialVersionUID = 7436181347392197575L;

    public RpcConnectionException() {
        super();
    }

    public RpcConnectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcConnectionException(String message) {
        super(message);
    }

    public RpcConnectionException(Throwable cause) {
        super(cause);
    }

}
