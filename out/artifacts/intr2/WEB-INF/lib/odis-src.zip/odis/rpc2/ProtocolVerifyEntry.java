/**
 * @(#)ProtocolVerifyEntry.java, 2010-8-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * Used for RpcClient to pass protocol information to RpcServer.
 * 
 * @author zhangduo
 */
public class ProtocolVerifyEntry implements IWritable {

    private String protocolName;

    /**
     * Used for RpcClient to pass Method information to RpcServer.
     * 
     * @author zhangduo
     */
    public static class MethodEntry implements IWritable {

        private long signature;

        private String name;

        private String returnType;

        private String[] parameterTypes;

        private Set<String> exceptionTypes;

        /**
         * Default constructor for <code>IWritable</code> serialization.
         */
        public MethodEntry() {}

        /**
         * Constructor with initial values for all fields.
         * 
         * @param signature
         * @param name
         * @param returnType
         * @param parameterTypes
         * @param exceptionTypes
         */
        public MethodEntry(long signature, String name, String returnType,
                String[] parameterTypes, Set<String> exceptionTypes) {
            this.signature = signature;
            this.name = name;
            this.returnType = returnType;
            this.parameterTypes = parameterTypes;
            this.exceptionTypes = exceptionTypes;
        }

        public long getSignature() {
            return signature;
        }

        public void setSignature(long signature) {
            this.signature = signature;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getReturnType() {
            return returnType;
        }

        public void setReturnType(String returnType) {
            this.returnType = returnType;
        }

        public String[] getParameterTypes() {
            return parameterTypes;
        }

        public void setParameterTypes(String[] parameterTypes) {
            this.parameterTypes = parameterTypes;
        }

        public Set<String> getExpectionTypes() {
            return exceptionTypes;
        }

        public void setExceptionTypes(Set<String> exceptionTypes) {
            this.exceptionTypes = exceptionTypes;
        }

        /**
         * @see IWritable#readFields(DataInput)
         */
        @Override
        public void readFields(DataInput in) throws IOException {
            signature = in.readLong();
            name = StringWritable.readString(in);
            returnType = StringWritable.readString(in);
            int parameterCount = CDataInputStream.readVInt(in);
            parameterTypes = new String[parameterCount];
            for (int i = 0; i < parameterCount; i++) {
                parameterTypes[i] = StringWritable.readString(in);
            }
            int exceptionCount = CDataInputStream.readVInt(in);
            exceptionTypes = new HashSet<String>(exceptionCount);
            for (int i = 0; i < exceptionCount; i++) {
                exceptionTypes.add(StringWritable.readString(in));
            }
        }

        /**
         * @see IWritable#writeFields(DataOutput)
         */
        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(signature);
            StringWritable.writeString(out, name);
            StringWritable.writeString(out, returnType);
            CDataOutputStream.writeVInt(parameterTypes.length, out);
            for (String type: parameterTypes) {
                StringWritable.writeString(out, type);
            }
            CDataOutputStream.writeVInt(exceptionTypes.size(), out);
            for (String type: exceptionTypes) {
                StringWritable.writeString(out, type);
            }
        }

        /**
         * @see IWritable#copyFields(IWritable)
         */
        @Override
        public IWritable copyFields(IWritable value) {
            MethodEntry v = (MethodEntry) value;
            signature = v.signature;
            name = v.name;
            parameterTypes = Arrays.copyOf(v.parameterTypes,
                    v.parameterTypes.length);
            exceptionTypes = new HashSet<String>(v.exceptionTypes);
            returnType = v.returnType;
            return this;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[signature = ").append(signature).append(", ").append(
                    returnType).append(' ').append(name).append('(');
            if (parameterTypes.length > 0) {
                sb.append(parameterTypes[0]);
                for (int i = 1; i < parameterTypes.length; i++) {
                    sb.append(", ").append(parameterTypes[i]);
                }
            }
            sb.append(')');
            if (!exceptionTypes.isEmpty()) {
                Iterator<String> iter = exceptionTypes.iterator();
                sb.append(" throws ").append(iter.next());
                while (iter.hasNext()) {
                    sb.append(", ").append(iter.next());
                }
            }
            sb.append(']');
            return sb.toString();
        }

    }

    private MethodEntry[] methods;

    /**
     * Default constructor for <code>IWritable</code> serialization.
     */
    public ProtocolVerifyEntry() {}

    /**
     * Constructor a <code>ProtocolVerifyEntry</code> with protocol name and
     * method signatures.
     * 
     * @param protocolName
     * @param method2signature
     */
    public ProtocolVerifyEntry(String protocolName,
            Map<Method, Long> method2signature) {
        this.protocolName = protocolName;
        methods = new MethodEntry[method2signature.size()];
        int index = 0;
        for (Map.Entry<Method, Long> entry: method2signature.entrySet()) {
            Method method = entry.getKey();
            MethodEntry me = new MethodEntry();
            me.setName(method.getName());
            me.setSignature(entry.getValue());
            me.setReturnType(method.getReturnType().getName());
            String[] parameterTypes = new String[method.getParameterTypes().length];
            for (int i = 0; i < parameterTypes.length; i++) {
                parameterTypes[i] = method.getParameterTypes()[i].getName();
            }
            me.setParameterTypes(parameterTypes);
            Set<String> exceptionTypes = new HashSet<String>();
            for (Class<?> exceptionType: method.getExceptionTypes()) {
                exceptionTypes.add(exceptionType.getName());
            }
            me.setExceptionTypes(exceptionTypes);
            methods[index++] = me;
        }
    }

    /**
     * Constructor a <code>ProtocolVerifyEntry</code> with protocol name and
     * method entries.
     * 
     * @param protocolName
     * @param methods
     */
    public ProtocolVerifyEntry(String protocolName, MethodEntry[] methods) {
        this.protocolName = protocolName;
        this.methods = methods;
    }

    public String getProtocolName() {
        return protocolName;
    }

    public void setProtocolName(String protocolName) {
        this.protocolName = protocolName;
    }

    public MethodEntry[] getMethods() {
        return methods;
    }

    public void setMethods(MethodEntry[] methods) {
        this.methods = methods;
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        protocolName = StringWritable.readString(in);
        int methodCount = CDataInputStream.readVInt(in);
        methods = new MethodEntry[methodCount];
        for (int i = 0; i < methodCount; i++) {
            methods[i] = new MethodEntry();
            methods[i].readFields(in);
        }
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, protocolName);
        CDataOutputStream.writeVInt(methods.length, out);
        for (MethodEntry method: methods) {
            method.writeFields(out);
        }
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @Override
    public IWritable copyFields(IWritable value) {
        ProtocolVerifyEntry v = (ProtocolVerifyEntry) value;
        protocolName = v.protocolName;
        methods = new MethodEntry[v.methods.length];
        for (int i = 0; i < methods.length; i++) {
            methods[i] = new MethodEntry();
            methods[i].copyFields(v.methods[i]);
        }
        return this;
    }

    @Override
    public String toString() {
        return "ProtocolVerifyEntry [protocolName=" + protocolName
                + ", methods=" + Arrays.toString(methods) + "]";
    }

}
