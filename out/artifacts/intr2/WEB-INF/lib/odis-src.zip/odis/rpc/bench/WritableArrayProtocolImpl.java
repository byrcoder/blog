/**
 * @(#)WritableArrayProtocolImpl.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;

import bsh.Interpreter;

import odis.rpc.RpcServer;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;

/**
 * @author zhangduo
 */
public class WritableArrayProtocolImpl implements WritableArrayProtocol {

    @Override
    public LongWritable[] getLong(int size) throws IOException {
        LongWritable[] ret = new LongWritable[size];
        for (int i = 0; i < size; i++) {
            ret[i] = new LongWritable(i);
        }
        return ret;
    }

    @Override
    public StringWritable[] getString(int size) throws IOException {
        StringWritable[] ret = new StringWritable[size];
        for (int i = 0; i < size; i++) {
            ret[i] = new StringWritable("StringWritable-" + i);
        }
        return ret;
    }

    @Override
    public SimpleWritable[] getSimple(int size) throws IOException {
        SimpleWritable[] ret = new SimpleWritable[size];
        for (int i = 0; i < size; i++) {
            ret[i] = new SimpleWritable(i, i * 2);
        }
        return ret;
    }

    @Override
    public void put(LongWritable[] array) throws IOException {}

    @Override
    public void put(StringWritable[] array) throws IOException {}

    @Override
    public void put(SimpleWritable[] array) throws IOException {}

    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]);
        Interpreter interpreter = new Interpreter();
        if (args[1].equals("rpc2")) {
            AbstractRpcServer server = RPC.getServer(
                    WritableArrayProtocol.class,
                    new WritableArrayProtocolImpl(), port, 20, 1000, 2, 0);
            server.start();
            interpreter.set("server", server);
            interpreter.set("portnum", port + 1000);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            server.join();
        } else if (args[1].equals("nio")) {
            AbstractRpcServer server = RPC.getNIOServer(
                    WritableArrayProtocol.class,
                    new WritableArrayProtocolImpl(), port, 20, 1000, 2, 0);
            server.start();
            interpreter.set("server", server);
            interpreter.set("portnum", port + 1000);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            server.join();
        } else {
            RpcServer server = odis.rpc.RPC.getServer(
                    new WritableArrayProtocolImpl(), port, 20, false);
            server.start();
            interpreter.set("server", server);
            interpreter.set("portnum", port + 1000);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            server.join();
        }
    }
}
