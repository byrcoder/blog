/**
 * @(#)RandomUtils.java, 2010-8-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.util.Random;

/**
 * @author zhangduo
 */
public class RandomUtils {
    private static final String BASE = "0123456789"
            + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz"
            + "~!@#$%^&*()_+{}:\"<>?`-=[];',./" + "龘靐齉齾龗麤鱻爩龖吁灪麣鸾鹂鲡驫饢籱癵爨"
            + "滟厵麷鸜郁骊钃讟虋纞龞齽齼鼺黸麢鹳鹦鸙鸘";

    public static final Random rand = new Random(567123);

    public static String getString(int length) {
        char[] charArr = BASE.toCharArray();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(charArr[rand.nextInt(charArr.length)]);
        }
        return sb.toString();
    }
}
