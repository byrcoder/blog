/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Apr 8, 2006
 */
package odis.rpc;

import java.io.IOException;

/**
 * An <code>RpcException</code> represents any communication-related exception
 * during the process of an RPC call. Every method in an RPC interface should
 * be declared as <code>throws RpcException</code>. This is checked when the 
 * client proxy is created. 
 * 
 * @author zf
 */
@Deprecated
public class RpcException extends IOException {
    private static final long serialVersionUID = 1799815382766306081L;
    public Throwable detail;

    /**
     * Constructor.
     * @param message  the message of the details of the exception
     */
    public RpcException(String message) {
        super(message);
    }
    /**
     * 
     * @param message  the message of the details of the exception
     * @param detail  the nested exception, if any, that causes this exception
     */
    public RpcException(String message, Throwable detail) {
        super(message);
        this.detail = detail;
    }
    
    public String getMessage() {
        if (detail == null)
            return super.getMessage();
        else
            return super.getMessage() + "; nested exception is: " 
                + detail.toString();
    }
    
    public Throwable getCause() {
        return detail;
    }
}
