/**
 * @(#)BenchmarkByteArray.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Random;

import odis.rpc2.RPC;

/**
 * @author zhangduo
 */
public class BenchmarkByteArray {

    private ByteArrayProtocol client;

    public void run() throws IOException {
        System.out.println("warming up");
        client.get(1024);
        client.put(new byte[1024]);
        System.out.println("Testing");
        benchmark(4);
        benchmark(8);
        benchmark(16);
        benchmark(64);
        benchmark(1024);
        benchmark(1024 * 4);
        benchmark(1024 * 64);
        benchmark(1024 * 512);
        benchmark(1024 * 1024);
        benchmark(1024 * 1024 * 4);
        benchmarkRandomSize(1024 * 1024);
    }

    private void benchmark(int size) throws IOException {
        byte[] buf = new byte[size];
        int n = 100;
        long start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            client.get(size);
        }
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            client.put(buf);
        }
        long t2 = System.currentTimeMillis();
        long d1 = t1 - start;
        long d2 = t2 - t1;
        System.out.println("size = " + size + ", get throughput = "
                + (((double) size * n) / (1024 * d1) * 1000) + " KB/s"
                + ", put throughput = "
                + (((double) size * n) / (1024 * d2) * 1000) + " KB/s");
    }

    private void benchmarkRandomSize(int maxSize) throws IOException {
        int n = 100;
        Random rand = new Random();
        int getTotal = 0, putTotal = 0;
        long start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            int size = rand.nextInt(maxSize);
            client.get(size);
            getTotal += size;
        }
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            int size = rand.nextInt(maxSize);
            client.put(new byte[size]);
            putTotal += size;
        }
        long t2 = System.currentTimeMillis();
        long d1 = t1 - start;
        long d2 = t2 - t1;
        System.out.println("randomSize maxSize = " + maxSize + ", total get = "
                + (((double) getTotal) / 1024) + "KB, get throughput = "
                + (((double) getTotal) / (1024 * d1) * 1000) + " KB/s"
                + ", total put = " + ((double) putTotal / 1024)
                + "KB, put throughput = "
                + (((double) putTotal) / (1024 * d2) * 1000) + " KB/s");
    }

    public static void main(String[] args) throws IOException {
        String[] ss = args[0].split(":");
        String host = ss[0];
        int port = Integer.parseInt(ss[1]);
        BenchmarkByteArray bench = new BenchmarkByteArray();
        if (args[1].equals("rpc2")) {
            bench.client = (ByteArrayProtocol) RPC.getProxy(
                    ByteArrayProtocol.class, new InetSocketAddress(host, port));
        } else {
            bench.client = (ByteArrayProtocol) odis.rpc.RPC.getProxy(
                    ByteArrayProtocol.class, new InetSocketAddress(host, port));
        }
        bench.run();
    }
}
