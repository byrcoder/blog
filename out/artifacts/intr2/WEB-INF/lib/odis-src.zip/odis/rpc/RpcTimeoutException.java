/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on May 21, 2006
 */
package odis.rpc;

/**
 * Exception indicating that an RPC call has timed out.
 * @author zf
 */
@Deprecated
public class RpcTimeoutException extends RpcException {
    private static final long serialVersionUID = 1L;

    public RpcTimeoutException(String message) {
        super(message);
    }
}
