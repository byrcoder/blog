/**
 * @(#)StringProtocolmpl.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;

import odis.rpc.RpcServer;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import bsh.Interpreter;

/**
 * @author zhangduo
 */
public class StringProtocolImpl implements StringProtocol {

    @Override
    public String echo(String str) throws IOException {
        return str;
    }

    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]);
        Interpreter interpreter = new Interpreter();
        if (args[1].equals("rpc2")) {
            AbstractRpcServer server = RPC.getServer(StringProtocol.class,
                    new StringProtocolImpl(), port, 50, 1000, 2, 0);
            server.start();
            interpreter.set("server", server);
            interpreter.set("portnum", port + 1000);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            server.join();
        } else if (args[1].equals("nio")) {
            AbstractRpcServer server = RPC.getNIOServer(StringProtocol.class,
                    new StringProtocolImpl(), port, 50, 1000, 2, 0);
            server.start();
            interpreter.set("server", server);
            interpreter.set("portnum", port + 1000);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            server.join();
        } else {
            RpcServer server = odis.rpc.RPC.getServer(new StringProtocolImpl(),
                    port, 50, false);
            server.start();
            interpreter.set("server", server);
            interpreter.set("portnum", port + 1000);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            server.join();
        }
    }
}
