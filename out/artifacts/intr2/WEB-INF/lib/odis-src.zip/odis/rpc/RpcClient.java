/**
 * Copyright 2005 The Apache Software Foundation Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package odis.rpc;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.ObjectWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.toolkit.WritableMap;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * A client for an IPC service. IPC calls take a single {@link IWritable} as a
 * parameter, and return a {@link IWritable} as their value. A service runs on a
 * port and is defined by a parameter class and a value class.
 * <p>
 * Note: this is probably not what you use. See
 * {@link odis.rpc.RPC#getProxy(Class, InetSocketAddress)} for the easy-to-use
 * RPC client interface.
 * 
 * @author Doug Cutting, Feng Zhou
 * @see RpcServer
 */
@Deprecated
public class RpcClient {
    private static final Logger LOG = LogFormatter.getLogger(RpcClient.class.getName());

    /**
     * call id of clientName call
     */
    public static final int ID_CLIENTNAME = -1;

    /**
     * In protocol version 2, this will be sent to server before sending any
     * call properties, so that server can process call properties properly.
     */
    public static final int ID_HASCALLPROPERTIES = -2;

    /**
     * will reconnect after this many timeouts
     */
    public static final int DEFAULT_MAX_TIMEOUT_COUNT = 5;

    /**
     * threshold in ms of reporting calls taking too long
     */
    public static final int RPC_TOO_LONG = 1000;

    /**
     * max retry times when get new connection failed for NoRouteToHostException
     */
    public static final int MAX_CONNECT_RETRIES = 5;

    protected final ConcurrentMap<InetSocketAddress, Connection> connections = new ConcurrentHashMap<InetSocketAddress, Connection>();

    private Class<?> valueClass; // class of call values

    private HashSet<Integer> blacklistedOutPorts = null;

    private int counter; // counter for call ids

    protected int maxTimeoutCount = DEFAULT_MAX_TIMEOUT_COUNT;

    private boolean running = true; // true while client runs

    /**
     * A call waiting for a value.
     */
    private class Call {
        int id; // call id

        WritableMap<StringWritable, StringWritable> properties; // properties map

        IWritable param; // parameter

        IWritable value; // value, null if error

        Throwable error; // error, null if value

        /**
         * We haven't gotten any reply yet
         */
        final static int STATUS_INIT = 0;

        /**
         * We have started receiving reply
         */
        final static int STATUS_RECEIVNG = 1;

        /**
         * The call is finished (either success or failure)
         */
        final static int STATUS_RECEIVED = 2;

        int status;

        protected Call(WritableMap<StringWritable, StringWritable> properties,
                IWritable param) {
            this.properties = properties;
            this.param = param;
            synchronized (RpcClient.this) {
                this.id = counter++;
                if (counter < 0) {
                    counter = 0;
                }
            }
            this.status = STATUS_INIT;
        }

        public String toString() {
            return "{param=" + param + ",value=" + value + ",error=" + error
                    + ",status=" + status + "}";
        }

    }

    /**
     * Thread that reads responses and notifies callers. Each connection owns a
     * socket connected to a remote address. Calls are multiplexed through this
     * socket: responses may be delivered out of order.
     */
    protected class Connection implements Runnable {
        private static final int BUFFER_SIZE = 8 * 1024;

        private InetSocketAddress address; // address of server

        protected Socket socket; // connected socket

        private CDataInputStream in;

        private final CDataOutputStream out;

        Map<Integer, Call> calls = new ConcurrentHashMap<Integer, Call>();

        // currently active calls
        int timeoutCounts;

        boolean closed;

        private int protocolVersion = 1;

        private final ConcurrentHashMap<String, String> sentClientNames = new ConcurrentHashMap<String, String>();

        public Connection(InetSocketAddress address) throws IOException {
            this.address = address;
            if (address.getAddress() == null) {
                throw new IOException("Host not found: "
                        + address.getHostName());
            }
            while (true) {
                this.socket = new Socket(address.getAddress(),
                        address.getPort());
                LOG.info("Connection #" + this.hashCode() + "(port "
                        + socket.getLocalPort() + ") to server " + address
                        + " created.");
                if (blacklistedOutPorts != null
                        && blacklistedOutPorts.contains(socket.getLocalPort())) {
                    LOG.info("RPC out port " + socket.getLocalPort()
                            + " is blacklisted, reconnecting");
                    this.socket.close();
                    continue;
                }
                break;
            }
            socket.setTcpNoDelay(true);
            this.in = new CDataInputStream(new BufferedInputStream(
                    socket.getInputStream(), BUFFER_SIZE));
            this.out = new CDataOutputStream(new BufferedOutputStream(
                    socket.getOutputStream(), BUFFER_SIZE));
        }

        public synchronized void setProtocolVersion(int version) {
            if (protocolVersion <= version) {
                LOG.info("Connection " + address + " protocol version set to "
                        + version);
                protocolVersion = version;
            } else {
                throw new IllegalStateException("protocol already set to "
                        + protocolVersion + ", cannot be downgraded to "
                        + version);
            }
        }

        public synchronized int getProtocolVersion() {
            return protocolVersion;
        }

        public void run() {
            String threadName = Thread.currentThread().getName();
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine(threadName + ": starting");
            }
            Call call = null;
            try {
                while (running) {
                    int id;
                    try {
                        id = in.readInt(); // try to read an id
                    } catch (SocketTimeoutException e) {
                        continue;
                    }

                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.fine(threadName + " got value #" + id);
                    }

                    call = calls.remove(Integer.valueOf(id));
                    if (call == null) {
                        LOG.warning("Unknown call ID received: "
                                + id
                                + ". Possible unsynchronized RPC server-client communication?");
                        continue;
                    }
                    synchronized (call) {
                        call.status = Call.STATUS_RECEIVNG;
                    }
                    try {
                        byte errorFlag = in.readByte(); // read if error
                        if (errorFlag != RpcServer.ERROR_SUCCESS) {
                            Throwable exception = null;
                            int len = in.readInt();
                            if (len > 0) {
                                byte[] b = new byte[len];
                                in.readFully(b);
                                ObjectInputStream oi = new ObjectInputStream(
                                        new ByteArrayInputStream(b));
                                exception = (Throwable) oi.readObject();
                                if (exception == null) {
                                    LOG.warning("Exception is null: "
                                            + HexString.bytesToHexNoSpace(b));
                                }
                            }
                            synchronized (call) {
                                call.error = exception;
                                call.value = null;
                                call.status = Call.STATUS_RECEIVED;
                                call.notify();
                            }
                        } else {
                            IWritable value = makeValue();
                            // zf: this may take a long time for large return
                            // values
                            try {
                                value.readFields(in); // read value
                            } catch (Throwable e) {
                                throw new RpcWritableException(
                                        "Error reading RPC return value", e);
                            }
                            synchronized (call) {
                                call.value = value;
                                call.error = null;
                                call.status = Call.STATUS_RECEIVED;
                                call.notify();
                            }
                        }
                    } catch (Throwable e) {
                        // any error, I/O error (including timeout) or OOM
                        synchronized (call) {
                            if (e instanceof RpcException) {
                                call.error = e; // for RpcWritableException
                            } else {
                                call.error = new RpcException(
                                        "I/O exception when receiving RPC response",
                                        e);
                            }
                            call.status = Call.STATUS_RECEIVED;
                            call.notify();
                        }
                        throw e; // close this connection because socket
                        // state has become unknown
                    }
                    call = null;
                }
            } catch (EOFException eof) {
                // On Windows, this is what happens when the remote side goes
                // down
                LOG.log(Level.WARNING, "[Connection #" + this.hashCode() + "]["
                        + Thread.currentThread().getName() + ":#"
                        + Thread.currentThread().hashCode()
                        + "] Connection(port " + socket.getLocalPort()
                        + ") to server closed.", eof);
            } catch (SocketException eof) {
                // On Linux, this is what happens when the remote side goes down
                LOG.log(Level.WARNING, "[Connection #" + this.hashCode() + "]["
                        + Thread.currentThread().getName() + ":#"
                        + Thread.currentThread().hashCode()
                        + "] Connection(port " + socket.getLocalPort()
                        + ") to server closed.", eof);
            } catch (Throwable e) {
                LOG.log(Level.WARNING, threadName + " caught: "
                        + e.getClass().getName(), e);
            } finally {
                // fail any remaining outstanding calls
                for (Call c: calls.values()) {
                    synchronized (c) {
                        c.status = Call.STATUS_RECEIVED;
                        c.notify();
                    }
                }
                close();
            }
        }

        /**
         * Send the client name to server, if it hasn't been sent since this
         * connection was created.
         */
        void sendClientName(String clientName) throws RpcException {
            if (sentClientNames.containsKey(clientName)) {
                return;
            }
            // double check
            if (sentClientNames.putIfAbsent(clientName, clientName) != null) {
                return;
            }
            LOG.info("Sending client name " + clientName + " to " + address);
            try {
                synchronized (out) {
                    out.writeInt(ID_CLIENTNAME);
                    UTF8Writable.writeString(out, clientName);
                    out.flush();
                }
            } catch (IOException e) {
                throw new RpcException("Failed to send clientName", e);
            }
        }

        /**
         * Initiates a call by sending the parameter to the remote server. Note:
         * this is not called from the Connection thread, but by other threads.
         * 
         * @throws RpcException
         */
        public void sendParam(Call call) throws RpcException {
            boolean error = true;
            try {
                calls.put(Integer.valueOf(call.id), call);
                synchronized (out) {
                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.fine(Thread.currentThread().getName()
                                + " sending #" + call.id);
                    }
                    try {
                        out.writeInt(call.id);
                    } catch (IOException e) {
                        LOG.warning("Cannot write out call id: " + e.toString());
                        throw new RpcException("Cannot write out call id", e);
                    }
                    // if supports call properties
                    int curProtocolVersion = getProtocolVersion();
                    if (curProtocolVersion >= -ID_HASCALLPROPERTIES) {
                        try {
                            call.properties.writeFields(out);
                        } catch (IOException e) {
                            LOG.warning("Error writing properties: "
                                    + e.toString());
                            throw new RpcWritableException(
                                    "Error writing properties", e);
                        }
                    }
                    try {
                        call.param.writeFields(out);
                    } catch (IOException e) {
                        LOG.warning("Error writing parameter: " + e.toString());
                        throw new RpcWritableException(
                                "Error writing parameter", e);
                    }
                    try {
                        out.flush();
                    } catch (IOException e) {
                        LOG.warning("Cannot send out IPC call parameter: "
                                + e.toString());
                        throw new RpcException(
                                "Cannot send out IPC call parameter", e);
                    }
                }
                error = false;
            } finally {
                if (error) {
                    close(); // close on error
                }
            }
        }

        /**
         * Close the connection and remove it from the pool.
         */

        public synchronized void close() {
            if (closed) {
                return;
            }
            closed = true;
            LOG.info("Connection to " + address + " is being closed.");
            Connection connInPool = connections.get(address);
            if (connInPool == this) {
                LOG.info(socket + " removed from pool");
                connections.remove(address); // remove connection
            }
            try {
                in.close();
            } catch (IOException e) {

            } finally {
                try {
                    out.close();
                } catch (IOException e) {

                } finally {
                    try {
                        socket.close();
                    } catch (IOException e) {

                    }
                }
            }
        }

    }

    /**
     * Construct an IPC client whose values are of the given {@link IWritable}
     * class.
     */
    public RpcClient(Class<?> valueClass) {
        this.valueClass = valueClass;
        Configuration conf = OdisLibConfig.conf();
        String[] outportsBlackList = conf.getStringArray("rpc.client.outports-blacklist");
        if (outportsBlackList != null) {
            blacklistedOutPorts = new HashSet<Integer>();
            for (String port: outportsBlackList) {
                if (port.length() != 0) {
                    blacklistedOutPorts.add(Integer.parseInt(port));
                }
            }
            LOG.info("RPC outgoing port blacklist: " + blacklistedOutPorts);
        }
    }

    /**
     * Set the black list for client outgoing ports. Client will not bind to
     * these ports when connecting to the server.
     * 
     * @param ports
     */
    public void setOutgoingPortBlacklist(int[] ports) {
        blacklistedOutPorts = new HashSet<Integer>();
        for (int port: ports) {
            blacklistedOutPorts.add(port);
        }
        LOG.info("Updated RPC outgoing port blacklist: " + blacklistedOutPorts);
    }

    /**
     * Stop all threads related to this client. No further calls may be made
     * using this client.
     */
    public void stop() {
        LOG.info("Stopping client");
        // close all connections
        running = false;
        ArrayList<Connection> l = new ArrayList<Connection>();
        l.addAll(connections.values());
        for (Connection c: l) {
            c.close();
        }
    }

    private class CallFuture<V> implements Future<V> {

        private Call call;

        private long timeout;

        private long start;

        private Connection conn;

        private long sendTime;

        public CallFuture(Connection conn, Call call, long timeout)
                throws RpcException {
            this.conn = conn;
            this.call = call;
            this.timeout = timeout;
            start = System.currentTimeMillis();
            // send the parameter
            // zf: this normally doesn't block even when the remote host is down
            // as TCP has a large (compared to most calls we send) local send
            // buffer
            conn.sendParam(call);
            sendTime = System.currentTimeMillis() - start;
            if (timeout > 0 && sendTime > 1000) {
                LOG.warning("Network problem or overloaded server? "
                        + "Sending out RPC to " + conn.address + " took: "
                        + sendTime + "ms");
            }
        }

        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        IWritable innerGet() throws Throwable {
            synchronized (call) {
                boolean isTimeout = false;

                while (call.status != Call.STATUS_RECEIVED) {
                    long toWait = 0;
                    if (timeout > 0) {
                        toWait = timeout - (System.currentTimeMillis() - start);
                        if (toWait <= 0) {
                            isTimeout = true;
                            LOG.warning("CALL timeout(" + timeout + "): "
                                    + call);
                            break;
                        }
                    }
                    try {
                        if (timeout > 0) {
                            call.wait(toWait);
                        } else {
                            call.wait(); // wait for the result
                        }
                    } catch (InterruptedException e) {}
                    if (call.status == Call.STATUS_RECEIVED) {
                        break;
                    }
                    // we'll keep waiting when we're in STATUS_RECEIVING
                }
                if (call.error != null) {
                    Exception tmp = new Exception();
                    StackTraceElement[] clientStackTrace = tmp.getStackTrace();
                    StackTraceElement[] remoteStackTrace = call.error.getStackTrace();
                    assert remoteStackTrace != null;
                    StackTraceElement[] stackTrace = new StackTraceElement[clientStackTrace.length
                            + remoteStackTrace.length + 1];
                    System.arraycopy(remoteStackTrace, 0, stackTrace, 0,
                            remoteStackTrace.length);
                    stackTrace[remoteStackTrace.length] = new StackTraceElement(
                            "---rpc call ---", "...", "...", -1);
                    System.arraycopy(clientStackTrace, 0, stackTrace,
                            remoteStackTrace.length + 1,
                            clientStackTrace.length);
                    call.error.setStackTrace(stackTrace);
                    conn.timeoutCounts = 0;
                    throw call.error;
                } else if (call.value != null) {
                    long total = System.currentTimeMillis() - start;
                    if (total > RPC_TOO_LONG) {
                        LOG.info("Long RPC call, total=" + total + ", send="
                                + sendTime + ": " + call.param);
                    }
                    conn.timeoutCounts = 0;
                    return call.value;
                } else {
                    if (!isTimeout) {
                        LOG.log(Level.WARNING,
                                "Bad return value for call should be regarded as timeout: "
                                        + call);
                    }
                }
                // timeout case fall through (call.value == null)
            }
            // timeout
            if (maxTimeoutCount > 0) {
                if (++conn.timeoutCounts > maxTimeoutCount) {
                    LOG.warning("Closing connection to " + conn.address
                            + " because of too many timeouts.");
                    conn.close();
                }
            }
            conn.timeoutCounts = 0;
            throw new RpcTimeoutException(
                    "timed out waiting for response: timeout = " + timeout
                            + ", call.param is "
                            + (call.param == null ? "null" : call.param)
                            + ", call.error is "
                            + (call.error == null ? "null" : call.error)
                            + ", call.value is "
                            + (call.value == null ? "null" : call.value));
        }

        @SuppressWarnings("unchecked")
        @Override
        public V get() throws InterruptedException, ExecutionException {
            try {
                ObjectWritable value = (ObjectWritable) innerGet();
                return (V) value.getObject();
            } catch (Throwable e) {
                throw new ExecutionException(e);
            }
        }

        @Override
        public V get(long timeout, TimeUnit unit) throws InterruptedException,
                ExecutionException, TimeoutException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isCancelled() {
            return false;
        }

        @Override
        public boolean isDone() {
            synchronized (call) {
                return call.status == Call.STATUS_RECEIVED;
            }
        }

    }

    /**
     * make a async call
     * 
     * @param clientName
     * @param properties
     * @param param
     * @param address
     * @param timeout
     * @return
     * @throws RpcException
     */
    public <V> CallFuture<V> invoke(String clientName,
            WritableMap<StringWritable, StringWritable> properties,
            IWritable param, InetSocketAddress address, long timeout)
            throws RpcException {
        Connection connection = getConnection(address, clientName,
                properties != null);
        if (clientName != null) {
            connection.sendClientName(clientName);
        }
        Call call = new Call(properties, param);
        CallFuture<V> future = new CallFuture<V>(connection, call, timeout);
        return future;
    }

    /**
     * Make a call, passing <code>param</code>, to the IPC server running at
     * <code>address</code>, returning the value. Throws exceptions if there are
     * network problems or if the remote code threw an exception.
     * 
     * @param timeout
     *            timeout of the whole call in ms, including sending and
     *            receiving. if 0, will wait indefinately
     */
    protected IWritable call(String clientName,
            WritableMap<StringWritable, StringWritable> properties,
            IWritable param, InetSocketAddress address, long timeout)
            throws Throwable {
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("CALL " + address + ":" + param);
        }
        CallFuture<?> future = invoke(clientName, properties, param, address,
                timeout);
        return future.innerGet();
    }

    /**
     * Get a connection from the pool, or create a new one and add it to the
     * pool. Connections to a given host/port are reused.
     */
    private Connection getConnection(InetSocketAddress address,
            String clientName, boolean hasCallProperties) throws RpcException {
        Connection connection;
        int retries = 0;

        while (running) {
            connection = connections.get(address);
            if (connection != null) {
                return connection;
            }
            try {
                // I put the connection code out of synchronized(connections) block
                // so that it won't block other threads if this takes too long
                connection = new Connection(address);
                if (hasCallProperties) {
                    LOG.info("Enabling call properties (protocol version 2) on "
                            + address);
                    connection.out.writeInt(ID_HASCALLPROPERTIES);
                    connection.out.flush();
                    connection.setProtocolVersion(-ID_HASCALLPROPERTIES);
                }
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine("[Thread " + Thread.currentThread().getName()
                            + " # " + Thread.currentThread().hashCode() + "]["
                            + this.getClass().getName() + "#" + this.hashCode()
                            + "] create connection #" + connection.hashCode()
                            + " to server " + address
                            + ", connection pool size is " + connections.size());
                }
                Connection oldConn = connections.putIfAbsent(address,
                        connection);
                if (oldConn == null) {
                    Thread t = new Thread(null, connection,
                            "Client connection to "
                                    + address.getAddress().getHostAddress()
                                    + ":" + address.getPort() + " from "
                                    + connection.socket.getLocalPort(),
                            RpcConstants.CLIENT_CONNECTION_STACK_SIZE);
                    t.setDaemon(true);
                    t.start();
                    return connection;
                } else {
                    connection.close();
                    return oldConn;
                }
            } catch (NoRouteToHostException e) {
                // this exception could be raised for incidental network error, so we retry
                LOG.log(Level.WARNING, "cannot connect to " + address
                        + ", retry." + retries, e);
                retries++;
                if (retries >= MAX_CONNECT_RETRIES) {
                    throw new RpcException("cannot connection to " + address
                            + " after retry for " + retries + " times", e);
                }
            } catch (IOException e) {
                throw new RpcException("Cannot get connection to " + address, e);
            }
            // idle for 2 minutes before retry
            try {
                Thread.sleep(TimeUnit.MINUTES.toMillis(2));
            } catch (InterruptedException e) {}
        }
        return null;
    }

    private IWritable makeValue() {
        IWritable value; // construct value
        try {
            value = (IWritable) valueClass.newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e.toString());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e.toString());
        }
        return value;
    }
}
