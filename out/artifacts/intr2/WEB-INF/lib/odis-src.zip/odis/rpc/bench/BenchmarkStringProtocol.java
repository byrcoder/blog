/**
 * @(#)BenchmarkStringProtocol.java, 2010-8-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;
import java.net.InetSocketAddress;

import odis.rpc2.RPC;

/**
 * @author zhangduo
 */
public class BenchmarkStringProtocol {

    private StringProtocol client;

    private long sleep;

    private int count;

    public void run() throws IOException {
        String str = RandomUtils.getString(RandomUtils.rand.nextInt(20));
        for (int i = 0; i < count; i++) {
            client.echo(str);
            try {
                Thread.sleep(sleep);
            } catch (InterruptedException e) {}
        }
    }

    public static void main(String[] args) throws IOException {
        String[] ss = args[0].split(":");
        String host = ss[0];
        int port = Integer.parseInt(ss[1]);
        BenchmarkStringProtocol bench = new BenchmarkStringProtocol();
        if (args[1].equals("rpc2")) {
            bench.client = (StringProtocol) RPC.getProxy(StringProtocol.class,
                    new InetSocketAddress(host, port));
        } else {
            bench.client = (StringProtocol) odis.rpc.RPC.getProxy(
                    StringProtocol.class, new InetSocketAddress(host, port));
        }
        bench.sleep = Long.parseLong(args[2]);
        bench.count = Integer.parseInt(args[3]);
        bench.run();
    }
}
