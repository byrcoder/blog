/**
 * @(#)ServerCallListener.java, 2010-3-11. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc;

import java.lang.reflect.Method;
import java.net.SocketAddress;

/**
 * A callback for method invocations on RpcServer
 * 
 * @deprecated
 * @author zhangduo
 */
@Deprecated
public interface ServerCallListener {
    /**
     * Invoked when any RPC method is called.
     * 
     * @param method
     * @param params
     * @param cost
     */
    void onServerMethodCalled(SocketAddress remoteAddr, Method method,
            Object[] params, long cost);

    /**
     * Invoked when any RPC method is called and throw an exception.
     * 
     * @param method
     * @param params
     * @param error
     */
    void onServerMethodError(SocketAddress remoteAddr, Method method,
            Object[] params, Throwable error);
}
