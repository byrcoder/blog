/**
 * @(#)ClientConnectListenerImpl.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.util.logging.Logger;

import odis.rpc2.ClientConnectListener;
import odis.rpc2.ClientInfo;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class ClientConnectListenerImpl implements ClientConnectListener {

    private static final Logger LOG = LogFormatter.getLogger(ClientConnectListenerImpl.class);

    @Override
    public void clientConnect(ClientInfo clientInfo) {
        LOG.info("client " + clientInfo + " connect");

    }

    @Override
    public void clientDisconnect(ClientInfo clientInfo) {
        LOG.info("client " + clientInfo + " disconnect");
    }

}
