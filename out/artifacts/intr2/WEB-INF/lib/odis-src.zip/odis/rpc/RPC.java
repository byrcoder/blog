/**
 * Copyright 2005 The Apache Software Foundation Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package odis.rpc;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.rpc.RpcClient.Connection;
import odis.serialize.IWritable;
import odis.serialize.lib.ObjectWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.toolkit.WritableMap;
import toolbox.misc.LogFormatter;

/**
 * A simple RPC mechanism. A <i>protocol</i> is simply a Java interface. All
 * parameters and return types must be one of:
 * <ul>
 * <li>a primitive type, <code>boolean</code>, <code>byte</code>,
 * <code>char</code>, <code>short</code>, <code>int</code>, <code>long</code>,
 * <code>float</code>, <code>double</code>, or <code>void</code>; or</li>
 * <li>a {@link String}; or</li>
 * <li>a {@link IWritable}; or</li>
 * <li>an array of the above types</li>
 * </ul>
 * All exception will be sent back to the client as its original type
 * <p>
 * The server-side starts an RPC service by calling
 * {@link #getServer(Object, int)}.
 * <p>
 * The client side connects to an service remotely by calling
 * {@link #getProxy(Class, InetSocketAddress, String)}.
 */
@Deprecated
public class RPC {
    private static final Logger LOG = LogFormatter.getLogger(RPC.class.getName());

    private RPC() {} // no public ctor

    /** A method invocation, including the method name and its parameters. */
    private static class Invocation implements IWritable {
        private String methodName;

        private Class<?>[] parameterClasses;

        private Object[] parameters;

        @SuppressWarnings("unused")
        public Invocation() {}

        public Invocation(Method method, Object[] parameters) {
            this.methodName = method.getName();
            this.parameterClasses = method.getParameterTypes();
            this.parameters = parameters;
        }

        /** The name of the method invoked. */
        public String getMethodName() {
            return methodName;
        }

        /** The parameter classes. */
        public Class<?>[] getParameterClasses() {
            return parameterClasses;
        }

        /** The parameter instances. */
        public Object[] getParameters() {
            return parameters;
        }

        public void readFields(DataInput in) throws IOException {
            methodName = UTF8Writable.readString(in);
            parameters = new Object[in.readInt()];
            parameterClasses = new Class[parameters.length];

            ObjectWritable objectWritable = new ObjectWritable();
            for (int i = 0; i < parameters.length; i++) {
                parameters[i] = ObjectWritable.readObject(in, objectWritable);
                parameterClasses[i] = objectWritable.getDeclaredClass();
            }
        }

        public void writeFields(DataOutput out) throws IOException {
            UTF8Writable.writeString(out, methodName);
            out.writeInt(parameterClasses.length);
            for (int i = 0; i < parameterClasses.length; i++) {
                ObjectWritable.writeObject(out, parameters[i],
                        parameterClasses[i]);
            }
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append(methodName);
            buffer.append("(");
            // ET: The method can be void so parameters can be null
            // zf: too verbose. remove parameters for now
            // if (parameters != null) {
            // for (int i = 0; i < parameters.length; i++) {
            // if (i != 0)
            // buffer.append(", ");
            // buffer.append(parameters[i]);
            // }
            // }
            buffer.append(")");
            return buffer.toString();
        }

        public IWritable copyFields(IWritable value) {
            throw new IllegalArgumentException("Not implemented.");
        }

    }

    protected static final RpcClient CLIENT = new RpcClient(
            ObjectWritable.class);

    /**
     * Close the connection to the specified address. The connection may be
     * re-created at the next call from the bundled proxy.
     * 
     * @param addr
     */
    public static void closeConnection(InetSocketAddress addr) {
        Connection conn = CLIENT.connections.get(addr);
        if (conn != null) {
            conn.close();
        }
    }
    
    /**
     * Get number of calls pending on a address
     * @param addr
     * @return
     */
    public static int getPendingCalls(InetSocketAddress addr) {
        Connection conn = CLIENT.connections.get(addr);
        if (conn == null) {
            return 0;
        }
        return conn.calls.size();
    }

    /**
     * Check whether the client has connected to a specified server address.
     * 
     * @param addr
     * @return
     */
    public static boolean connectedToServer(InetSocketAddress addr) {
        return CLIENT.connections.containsKey(addr);
    }

    private static class Invoker implements InvocationHandler {
        private InetSocketAddress address;

        // with domain server can distribute certain calls not to fill up the
        // thread pool (since protocol version 2)
        private WritableMap<StringWritable, StringWritable> properties = null;

        private String clientName = null;

        private long timeout;

        public Invoker(InetSocketAddress address, String clientName,
                String domain, long timeout) throws IOException {
            this.address = address;
            this.clientName = clientName;

            // Report that the client support property so that server can
            // receive properties with every call to coordinate them
            if (domain != null) {
                properties = getPropertiesMap(domain, timeout);
            }
            this.timeout = timeout;
        }

        /**
         * Generates a properties map of WritableMap containiing client domain
         * and timeout
         */
        private static WritableMap<StringWritable, StringWritable> getPropertiesMap(
                String domain, long timeout) {
            WritableMap<StringWritable, StringWritable> pptMap = WritableMap.get(
                    StringWritable.class, StringWritable.class);
            pptMap.put(new StringWritable(RpcConstants.CALL_PROPERTY_DOMAIN),
                    new StringWritable(domain));
            pptMap.put(new StringWritable(RpcConstants.CALL_PROPERTY_TIMEOUT),
                    new StringWritable(Long.toString(timeout)));
            return pptMap;
        }

        private boolean isObjectToString(Method method) {
            if (method.getName().equals("toString")
                    && method.getParameterTypes().length == 0) {
                return true;
            } else {
                return false;
            }
        }

        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            if (isObjectToString(method)) {
                return proxy.getClass().getInterfaces()[0].getName() + "@"
                        + address.getAddress() + ":" + address.getPort();
            }
            ObjectWritable value = (ObjectWritable) CLIENT.call(clientName,
                    properties, new Invocation(method, args), address, timeout);
            return value.getObject();
        }
    }

    private static class UDPCallInvoker implements InvocationHandler {
        private UDPCallClient udpClient;

        public UDPCallInvoker(InetSocketAddress address) throws IOException {
            udpClient = new UDPCallClient(address);
        }

        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {

            if (method.getReturnType() != Void.TYPE) {
                throw new RpcException("method " + method.getName()
                        + " with return value of type "
                        + method.getReturnType() + " cannot be called via udp");
            }

            udpClient.call(new Invocation(method, args));
            return null;
        }

    }

    // make sure every method in protocol throws RpcException
    private static void checkRpcInterface(Class<?> protocol) {
        Method[] ms = protocol.getMethods();
        next_method: for (int i = 0; i < ms.length; i++) {
            Method m = ms[i];
            Class<?>[] ex = m.getExceptionTypes();
            for (int j = 0; j < ex.length; j++) {
                if (ex[j].isAssignableFrom(RpcException.class)) {
                    // FIXME: this should be continue
                    // BUT notice that, if we change break to continue, some
                    // programs which have methed that do not throw 
                    // RPCException may run fail. So, DO NOT fix this bug until
                    // we change the version number.
                    // by zhangduo
                    break next_method;
                }
            }
            StringBuilder exBuf = new StringBuilder();
            exBuf.append("<");
            for (Class<?> c : ex) {
                exBuf.append(c.getName()).append(",");
            }
            exBuf.append(">");
            throw new ClassCastException(
                    "Method "
                            + m.getName()
                            + "(...) of RPC interface "
                            + protocol
                            + " is not declared as throwing RpcException( available exception is "
                            + exBuf.toString() + "). Please fix that.");
        }
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr) {
        try {
            return getProxy(protocol, addr, null, 0, null);
        } catch (IOException e) {
            throw new RuntimeException("This should not happen!", e);
        }
    }

    /**
     * Set the black list for client outgoing ports. Client will not bind to
     * these ports when connecting to the server, so that the ports can be
     * reserved for the servers on this machine. You can also set the ports in
     * rpc.client.outports-blacklist in odis-site.xml.
     * 
     * @param ports
     */
    public static void setOutgoingPortBlacklist(int[] ports) {
        CLIENT.setOutgoingPortBlacklist(ports);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param clientName
     *            a name the server uses to identify this client
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            String clientName) throws IOException {
        return getProxy(protocol, addr, clientName, 0, null);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinately
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            long timeout) {
        try {
            return getProxy(protocol, addr, null, timeout, null);
        } catch (IOException e) {
            throw new RuntimeException("This should not happen!", e);
        }
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param clientName
     *            a name the server uses to identify this client
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinately
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            String clientName, long timeout) throws IOException {
        return getProxy(protocol, addr, clientName, timeout, null);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinately
     * @param defaultDomain
     *            whether send default domain to server
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            long timeout, boolean defaultDomain) throws IOException {
        return getProxy(protocol, addr, null, timeout,
                defaultDomain ? getDefaultDomain() : null);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param clientName
     *            a name the server uses to identify this client
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinately
     * @param defaultDomain
     *            whether send default domain to server (protocol version 2)
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            String clientName, long timeout, boolean defaultDomain)
            throws IOException {
        return getProxy(protocol, addr, clientName, timeout,
                defaultDomain ? getDefaultDomain() : null);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinately
     * @param domain
     *            a domain certain group of calls belong to, with which server
     *            can avoid calls filling up the thread pool (protocol version
     *            2)
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            long timeout, String domain) {
        try {
            return getProxy(protocol, addr, null, timeout, domain);
        } catch (IOException e) {
            throw new RuntimeException("This should not happen!", e);
        }
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * <code>odis.rpc.RpcException</code>.<br>
     * The {@link Object#toString()} method of the returned proxy will return
     * immediately with a String represent the remote address and port, this
     * means a call to <code>toString</code> will NOT call the
     * <code>toString</code> method of the remote RpcServer.
     * 
     * @param clientName
     *            a name the server uses to identify this client
     * @param domain
     *            a domain certain group of calls belong to, with which server
     *            can avoid calls filling up the thread pool (protocol version
     *            2)
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinately
     */
    public static Object getProxy(Class<?> protocol, InetSocketAddress addr,
            String clientName, long timeout, String domain) throws IOException {
        checkRpcInterface(protocol);
        return Proxy.newProxyInstance(protocol.getClassLoader(), new Class[] {
            protocol
        }, new Invoker(addr, clientName, domain, timeout));
    }

    private static String getDefaultDomain() {
        String hostname = "localhost";
        try {
            hostname = InetAddress.getLocalHost().getCanonicalHostName();
        } catch (UnknownHostException e) {
            LOG.log(Level.WARNING, "Not got the local hostname.");
        }
        return "default." + hostname + "." + System.currentTimeMillis();
    }

    /**
     * How many continuous timeouts before reconnect. 0 or less to disable
     * reconnection on timeouts.
     * 
     * @param value
     */
    public static void setMaxTimeoutCount(int value) {
        CLIENT.maxTimeoutCount = value;
    }

    /**
     * Construct a client-side proxy object which delegates all the method
     * invocation to remote interface by udp protocol. Only the methods without
     * returned value can be called in this proxy object.
     * 
     * @param <T>
     * @param protocol
     * @param addr
     * @return
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public static <T> T getUdpProxy(Class<T> protocol, InetSocketAddress addr)
            throws IOException {
        return (T) Proxy.newProxyInstance(protocol.getClassLoader(),
                new Class[] {
                    protocol
                }, new UDPCallInvoker(addr));
    }

    /**
     * Construct a server for a protocol implementation instance listening on a
     * port.
     */
    public static RpcServer getServer(final Object instance, final int port) {
        return getServer(instance, port, 1, 0, false);
    }

    /**
     * Construct a server for a protocol implementation instance listening on a
     * port.
     */
    public static RpcServer getServer(final Object instance, final int port,
            final int numHandlers, final boolean verbose) {
        return getServer(instance, port, numHandlers, 2, verbose);
    }

    /**
     * Construct a server for a protocol implementation instance listening on a
     * port.
     */
    public static RpcServer getServer(final Object instance, final int port,
            final int numHandlers, final int reservedHandlers,
            final boolean verbose) {
        return getServer(instance, port, numHandlers, reservedHandlers,
                numHandlers * 10, verbose);
    }

    /**
     * Construct a server for a protocol implementation instance listening on a
     * port.
     * 
     * @param reservedHandlers
     *            the server handlers number if it was reached inhibitions would
     *            start
     */
    public static RpcServer getServer(final Object instance, final int port,
            final int numHandlers, final int reservedHandlers,
            final int queueSize, final boolean verbose) {
        return new RpcServer(port, Invocation.class, numHandlers,
                reservedHandlers, queueSize) {

            Class<?> implementation = instance.getClass();

            public IWritable call(SocketAddress remoteAddr, IWritable param)
                    throws Throwable {
                Invocation call = null;
                Method method = null;
                try {
                    call = (Invocation) param;
                    if (verbose) {
                        log("Call: " + call);
                    }

                    method = implementation.getMethod(call.getMethodName(),
                            call.getParameterClasses());
                    long cost = System.currentTimeMillis();
                    Object value = method.invoke(instance, call.getParameters());
                    cost = System.currentTimeMillis() - cost;
                    if (serverCallListener != null) {
                        serverCallListener.onServerMethodCalled(remoteAddr,
                                method, call.getParameters(), cost);
                    }
                    if (verbose) {
                        log("Return: " + value);
                    }

                    return new ObjectWritable(method.getReturnType(), value);

                } catch (InvocationTargetException e) {
                    Throwable target = e.getTargetException();
                    if (serverCallListener != null) {
                        serverCallListener.onServerMethodError(remoteAddr,
                                method, call.getParameters(), target);
                    }
                    throw target;
                } catch (Throwable e) {
                    RpcException rpce = new RpcException(
                            "Error invoking method at server", e);
                    throw rpce;
                }
            }
        };
    }

    /**
     * Construct an {@link UDPCallServer} which exports the methods of
     * <code>instance</code> at <code>port</code>.
     * 
     * @param instance
     * @param port
     * @param numHandlers
     * @return
     */
    public static UDPCallServer getUdpServer(final Object instance,
            final int port, final int numHandlers) {
        return new UDPCallServer(port, Invocation.class, numHandlers) {

            Class<?> implementation = instance.getClass();

            public void call(IWritable param) throws Throwable {
                try {
                    Invocation call = (Invocation) param;
                    Method method = implementation.getMethod(
                            call.getMethodName(), call.getParameterClasses());
                    method.invoke(instance, call.getParameters());
                } catch (InvocationTargetException e) {
                    Throwable target = e.getTargetException();
                    throw target;
                } catch (Throwable e) {
                    RpcException rpce = new RpcException(
                            "Error invoking method at server", e);
                    throw rpce;
                }
            }
        };
    }

    /**
     * invoke a proxy's method in asynchronous way
     * 
     * @param <V>
     * @param proxy
     *            must be generated by <code>RPC.getProxy(...)</code>
     * @param method
     * @param args
     * @return
     * @throws RpcException
     */
    @SuppressWarnings("unchecked")
    public static <V> Future<V> invoke(Object proxy, Method method,
            Object... args) throws RpcException {
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        return (Future<V>) CLIENT.invoke(invoker.clientName,
                invoker.properties, new Invocation(method, args),
                invoker.address, invoker.timeout);
    }

    private static void log(String value) {
        if (value != null && value.length() > 55)
            value = value.substring(0, 55) + "...";
        LOG.info(value);
    }

}
