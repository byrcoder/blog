/**
 * @(#)BenchmarkLongWritableArray.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Random;

import odis.rpc2.RPC;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;

/**
 * @author zhangduo
 */
public class BenchmarkWritableArray {

    private WritableArrayProtocol client;

    private Random rand = new Random();

    public void run(String type) throws IOException {
        if (type.equals("long")) {
            benchmarkLong(4);
            benchmarkLong(8);
            benchmarkLong(16);
            benchmarkLong(64);
            benchmarkLong(256);
            benchmarkLong(1024);
            benchmarkLong(4 * 1024);
            benchmarkLong(16 * 1024);
            benchmarkLong(64 * 1024);
            benchmarkLong(-1);
        } else if (type.equals("string")) {
            benchmarkString(4);
            benchmarkString(8);
            benchmarkString(16);
            benchmarkString(64);
            benchmarkString(256);
            benchmarkString(1024);
            benchmarkString(4 * 1024);
            benchmarkString(16 * 1024);
            benchmarkString(64 * 1024);
            benchmarkString(-1);
        } else if (type.equals("simple")) {
            benchmarkSimple(4);
            benchmarkSimple(8);
            benchmarkSimple(16);
            benchmarkSimple(64);
            benchmarkSimple(256);
            benchmarkSimple(1024);
            benchmarkSimple(4 * 1024);
            benchmarkSimple(16 * 1024);
            benchmarkSimple(64 * 1024);
            benchmarkSimple(-1);
        } else {
            throw new IllegalArgumentException();
        }
    }

    private LongWritable[] genLong(int length) {
        LongWritable[] ret = new LongWritable[length];
        for (int i = 0; i < length; i++) {
            ret[i] = new LongWritable(i);
        }
        return ret;
    }

    private void benchmarkLong(int length) throws IOException {
        long size = 0;
        int n = 100;

        long start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            if (length == -1) {
                int randomLength = rand.nextInt(64 * 1024);
                client.getLong(randomLength);
                size += 8L * randomLength;
            } else {
                client.getLong(length);
                size += 8L * length;
            }
        }
        double time = (double) (System.currentTimeMillis() - start) / 1000;;

        System.out.println("Long benchmark length = " + length
                + ", get throughput = " + ((double) size / 1024) / time
                + "KB/s");

        size = 0;
        LongWritable[] buf = length == -1 ? null : genLong(length);
        start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            if (length == -1) {
                int randomLength = rand.nextInt(64 * 1024);
                client.put(genLong(randomLength));
                size += 8L * randomLength;
            } else {
                client.put(buf);
                size += 8L * length;
            }
        }
        time = (double) (System.currentTimeMillis() - start) / 1000;;

        System.out.println("Long benchmark length = " + length
                + ", put throughput = " + ((double) size / 1024) / time
                + "KB/s");
    }

    private StringWritable[] genString(int length) {
        StringWritable[] ret = new StringWritable[length];
        for (int i = 0; i < length; i++) {
            ret[i] = new StringWritable("StringWritable-" + i);
        }
        return ret;
    }

    private long calcSize(StringWritable[] array) {
        long size = 0;
        for (StringWritable sw: array) {
            size += sw.getByteLength();
        }
        return size;
    }

    private void benchmarkString(int length) throws IOException {
        long size = 0;
        int n = 100;

        long start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            if (length == -1) {
                int randomLength = rand.nextInt(64 * 1024);
                StringWritable[] array = client.getString(randomLength);
                size += calcSize(array);
            } else {
                StringWritable[] array = client.getString(length);
                size += calcSize(array);
            }
        }
        double time = (double) (System.currentTimeMillis() - start) / 1000;;

        System.out.println("String benchmark length = " + length
                + ", get throughput = " + ((double) size / 1024) / time
                + "KB/s");

        size = 0;
        StringWritable[] buf = length == -1 ? null : genString(length);
        long bufSize = buf == null ? 0 : calcSize(buf);
        start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            if (length == -1) {
                int randomLength = rand.nextInt(64 * 1024);
                StringWritable[] array = client.getString(randomLength);
                client.put(array);
                size += calcSize(array);
            } else {
                client.put(buf);
                size += bufSize;
            }
        }
        time = (double) (System.currentTimeMillis() - start) / 1000;;

        System.out.println("String benchmark length = " + length
                + ", put throughput = " + ((double) size / 1024) / time
                + "KB/s");
    }

    private SimpleWritable[] genSimple(int length) {
        SimpleWritable[] ret = new SimpleWritable[length];
        for (int i = 0; i < length; i++) {
            ret[i] = new SimpleWritable(i, i * 2);
        }
        return ret;
    }

    private void benchmarkSimple(int length) throws IOException {
        long size = 0;
        int n = 100;

        long start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            if (length == -1) {
                int randomLength = rand.nextInt(64 * 1024);
                client.getSimple(randomLength);
                size += 12L * randomLength;
            } else {
                client.getSimple(length);
                size += 12L * length;
            }
        }
        double time = (double) (System.currentTimeMillis() - start) / 1000;;

        System.out.println("Simple benchmark length = " + length
                + ", get throughput = " + ((double) size / 1024) / time
                + "KB/s");

        size = 0;
        SimpleWritable[] buf = length == -1 ? null : genSimple(length);
        start = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            if (length == -1) {
                int randomLength = rand.nextInt(64 * 1024);
                client.put(genSimple(randomLength));
                size += 12L * randomLength;
            } else {
                client.put(buf);
                size += 12L * length;
            }
        }
        time = (double) (System.currentTimeMillis() - start) / 1000;;

        System.out.println("Simple benchmark length = " + length
                + ", put throughput = " + ((double) size / 1024) / time
                + "KB/s");
    }

    public static void main(String[] args) throws IOException {
        String[] ss = args[0].split(":");
        String host = ss[0];
        int port = Integer.parseInt(ss[1]);
        BenchmarkWritableArray bench = new BenchmarkWritableArray();
        if (args[1].equals("rpc2")) {
            bench.client = (WritableArrayProtocol) RPC.getProxy(
                    WritableArrayProtocol.class, new InetSocketAddress(host,
                            port));
        } else {
            bench.client = (WritableArrayProtocol) odis.rpc.RPC.getProxy(
                    WritableArrayProtocol.class, new InetSocketAddress(host,
                            port));
        }
        bench.run(args[2]);
    }
}
