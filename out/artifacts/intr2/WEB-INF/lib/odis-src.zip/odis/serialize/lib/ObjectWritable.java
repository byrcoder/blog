package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import toolbox.misc.LogFormatter;

/**
 * A polymorphic Writable that writes an instance with it's class name. Handles
 * arrays, strings and primitive types without a Writable wrapper.
 * <p>
 * This code is ported from Nutch, change UTF8 in nutch code to UTF8Writable
 * <p>
 * This class has BAD performance. Use {@link TypedBlobWritable},
 * {@link DynamicWritable}, or {@link GenericWritable} if possible. The current
 * implementation has poor performance (10MB/s locally) for sending anything but
 * byte[] (200MB/s seen locally).
 * <p>
 * XXX: This class use {@link UTF8Writable} to serialize String, so it can only
 * handle strings shorter than 64K/3.
 * <p>
 * Add enum support by zhangduo, 2010-7-26.
 * 
 * @author zf
 */
public class ObjectWritable implements IWritable {
    static {
        WritableRegistry.registerAlias(ObjectWritable.class,
                "ObjectWritable_v3");
        WritableRegistry.registerAlias(ObjectWritable.NullInstance.class,
                "ObjectWritable_Null_v3");
    }

    private static final Logger LOG = LogFormatter.getLogger(ObjectWritable.class.getName());

    protected Class<?> declaredClass;

    protected Object instance;

    /**
     * Default Constructor.
     */
    public ObjectWritable() {}

    /**
     * Constructor with an initial instance.The declaredClass will be the
     * instance's class.
     * 
     * @param instance
     */
    public ObjectWritable(Object instance) {
        setObject(instance);
    }

    /**
     * Constructor with an initial declaredClass and an initial instance.
     * 
     * @param declaredClass
     * @param instance
     */
    public ObjectWritable(Class<?> declaredClass, Object instance) {
        this.declaredClass = declaredClass;
        this.instance = instance;
    }

    /**
     * Set declaredClass and instance to null.
     */
    public void clear() {
        declaredClass = null;
        instance = null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        writeObject(out, instance, declaredClass);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        readObject(in, this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        new BlobWritable().setData(value).getData(this);
        return this;
    }

    /**
     * Reset the instance.
     */
    public void setObject(Object instance) {
        this.declaredClass = instance.getClass();
        this.instance = instance;
    }

    /**
     * Reset the instance with declaredClass.
     * 
     * @param declaredClass
     * @param instance
     */
    public void setObject(Class<?> declaredClass, Object instance) {
        this.declaredClass = declaredClass;
        this.instance = instance;
    }

    /**
     * Return the instance, or null if none.
     */
    public Object getObject() {
        return instance;
    }

    /**
     * Return the class this is meant to be.
     */
    public Class<?> getDeclaredClass() {
        return declaredClass;
    }

    private static final Map<String, Class<?>> PRIMITIVE_NAMES = new HashMap<String, Class<?>>();
    static {
        PRIMITIVE_NAMES.put("boolean", Boolean.TYPE);
        PRIMITIVE_NAMES.put("byte", Byte.TYPE);
        PRIMITIVE_NAMES.put("char", Character.TYPE);
        PRIMITIVE_NAMES.put("short", Short.TYPE);
        PRIMITIVE_NAMES.put("int", Integer.TYPE);
        PRIMITIVE_NAMES.put("long", Long.TYPE);
        PRIMITIVE_NAMES.put("float", Float.TYPE);
        PRIMITIVE_NAMES.put("double", Double.TYPE);
        PRIMITIVE_NAMES.put("void", Void.TYPE);
    }

    private static class NullInstance implements IWritable {
        private Class<?> declaredClass;

        @SuppressWarnings("unused")
        public NullInstance() {}

        public NullInstance(Class<?> declaredClass) {
            this.declaredClass = declaredClass;
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            String className = UTF8Writable.readString(in);
            if ("null".equals(className)) {
                declaredClass = null;
                return;
            } // if
            declaredClass = PRIMITIVE_NAMES.get(className);
            if (declaredClass == null) {
                try {
                    declaredClass = Class.forName(className);
                } catch (ClassNotFoundException e) {
                    LOG.log(Level.SEVERE, "Cannot find serialized class: "
                            + className, e);
                    throw new RuntimeException(e.toString());
                }
            }
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            if (declaredClass == null)
                UTF8Writable.writeString(out, "null");
            else
                UTF8Writable.writeString(out, declaredClass.getName());
        }

        @Override
        public IWritable copyFields(IWritable value) {
            this.declaredClass = ((NullInstance) value).declaredClass;
            return this;
        }
    }

    /**
     * Write a {@link IWritable}, {@link String}, primitive type, or an array of
     * the preceding.
     */
    public static void writeObject(DataOutput out, Object instance,
            Class<?> declaredClass) throws IOException {

        if (instance == null) { // null
            instance = new NullInstance(declaredClass);
            declaredClass = IWritable.class;
        }

        // write declared class for primitives
        UTF8Writable.writeString(out, declaredClass.getName());

        if (declaredClass.isArray()) { // array
            int length = Array.getLength(instance);
            out.writeInt(length);
            Class<?> componentClass = declaredClass.getComponentType();
            if (componentClass.isPrimitive()) {
                //zf: handle primitive array specially for speed
                writePrimitiveArray(out, componentClass, instance);
            } else {
                for (int i = 0; i < length; i++) {
                    writeObject(out, Array.get(instance, i),
                            declaredClass.getComponentType());
                }
            }
        } else if (declaredClass == String.class) { // String
            // FIXME: use StringWritable instead
            UTF8Writable.writeString(out, (String) instance);
        } else if (declaredClass.isPrimitive()) { // primitive type
            // zf: reflection could have passed in a primitive as an Object      
            if (declaredClass == Boolean.TYPE) { // boolean
                out.writeBoolean(((Boolean) instance).booleanValue());
            } else if (declaredClass == Character.TYPE) { // char
                out.writeChar(((Character) instance).charValue());
            } else if (declaredClass == Byte.TYPE) { // byte
                out.writeByte(((Byte) instance).byteValue());
            } else if (declaredClass == Short.TYPE) { // short
                out.writeShort(((Short) instance).shortValue());
            } else if (declaredClass == Integer.TYPE) { // int
                out.writeInt(((Integer) instance).intValue());
            } else if (declaredClass == Long.TYPE) { // long
                out.writeLong(((Long) instance).longValue());
            } else if (declaredClass == Float.TYPE) { // float
                out.writeFloat(((Float) instance).floatValue());
            } else if (declaredClass == Double.TYPE) { // double
                out.writeDouble(((Double) instance).doubleValue());
            } else if (declaredClass == Void.TYPE) { // void
            } else {
                throw new IllegalArgumentException("Not a primitive: "
                        + declaredClass);
            }
        } else if (declaredClass == Boolean.class) { // boolean
            out.writeBoolean(((Boolean) instance).booleanValue());
        } else if (declaredClass == Character.class) { // char
            out.writeChar(((Character) instance).charValue());
        } else if (declaredClass == Byte.class) { // byte
            out.writeByte(((Byte) instance).byteValue());
        } else if (declaredClass == Short.class) { // short
            out.writeShort(((Short) instance).shortValue());
        } else if (declaredClass == Integer.class) { // int
            out.writeInt(((Integer) instance).intValue());
        } else if (declaredClass == Long.class) { // long
            out.writeLong(((Long) instance).longValue());
        } else if (declaredClass == Float.class) { // float
            out.writeFloat(((Float) instance).floatValue());
        } else if (declaredClass == Double.class) { // double
            out.writeDouble(((Double) instance).doubleValue());
        } else if (declaredClass.isEnum()) {
            CDataOutputStream.writeVInt(((Enum<?>) instance).ordinal(), out);
        } else if (instance instanceof IWritable) { // Writable
            // write instance's class, to support subclasses of the declared class
            if (!instance.getClass().equals(declaredClass))
                UTF8Writable.writeString(out, instance.getClass().getName());
            else
                // zf: common case: no subclassing, write empty string to save room 
                UTF8Writable.writeString(out, "");
            ((IWritable) instance).writeFields(out);
        } else {
            throw new IOException("Can't write: " + instance + " as "
                    + declaredClass);
        }
    }

    /**
     * Read a {@link IWritable}, {@link String}, primitive type, or an array of
     * the preceding.
     */
    public static Object readObject(DataInput in) throws IOException {
        return readObject(in, null);
    }

    /**
     * Read a {@link IWritable}, {@link String}, primitive type, or an array of
     * the preceding.
     */
    public static Object readObject(DataInput in, ObjectWritable objectWritable)
            throws IOException {
        String className = UTF8Writable.readString(in);
        Class<?> declaredClass = PRIMITIVE_NAMES.get(className);
        if (declaredClass == null) {
            // FIXME: this needs to be removed
            if (className.endsWith(".ObjectWritable$NullInstance"))
                declaredClass = NullInstance.class;
            else
                try {
                    declaredClass = Class.forName(className);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
        }

        Object instance;

        if (declaredClass.isPrimitive()) { // primitive types
            // zf: these are for primitive array elements
            if (declaredClass == Boolean.TYPE) { // boolean
                instance = Boolean.valueOf(in.readBoolean());
            } else if (declaredClass == Character.TYPE) { // char
                instance = Character.valueOf(in.readChar());
            } else if (declaredClass == Byte.TYPE) { // byte
                instance = Byte.valueOf(in.readByte());
            } else if (declaredClass == Short.TYPE) { // short
                instance = Short.valueOf(in.readShort());
            } else if (declaredClass == Integer.TYPE) { // int
                instance = Integer.valueOf(in.readInt());
            } else if (declaredClass == Long.TYPE) { // long
                instance = Long.valueOf(in.readLong());
            } else if (declaredClass == Float.TYPE) { // float
                instance = Float.valueOf(in.readFloat());
            } else if (declaredClass == Double.TYPE) { // double
                instance = Double.valueOf(in.readDouble());
            } else if (declaredClass == Void.TYPE) { // void
                instance = null;
            } else {
                throw new IllegalArgumentException("Not a primitive: "
                        + declaredClass);
            }
        } else if (declaredClass == Boolean.class) { // boolean
            instance = Boolean.valueOf(in.readBoolean());
        } else if (declaredClass == Character.class) { // char
            instance = Character.valueOf(in.readChar());
        } else if (declaredClass == Byte.class) { // byte
            instance = Byte.valueOf(in.readByte());
        } else if (declaredClass == Short.class) { // short
            instance = Short.valueOf(in.readShort());
        } else if (declaredClass == Integer.class) { // int
            instance = Integer.valueOf(in.readInt());
        } else if (declaredClass == Long.class) { // long
            instance = Long.valueOf(in.readLong());
        } else if (declaredClass == Float.class) { // float
            instance = Float.valueOf(in.readFloat());
        } else if (declaredClass == Double.class) { // double
            instance = Double.valueOf(in.readDouble());
        } else if (declaredClass.isArray()) { // array
            int length = in.readInt();
            Class<?> componentClass = declaredClass.getComponentType();
            // zf: we handle arrays of primitive types specially for speed
            if (componentClass.isPrimitive()) {
                instance = readPrimitiveArray(in, componentClass, length);
            } else {
                instance = Array.newInstance(componentClass, length);
                for (int i = 0; i < length; i++) {
                    Array.set(instance, i, readObject(in));
                }
            }
        } else if (declaredClass == String.class) { // String
            // FIXME: use StringWritable instead
            instance = UTF8Writable.readString(in);
        } else if (declaredClass.isEnum()) {
            int ordinal = CDataInputStream.readVInt(in);
            instance = declaredClass.getEnumConstants()[ordinal];
        } else { // IWritable
            String instanceClassName = UTF8Writable.readString(in);
            try {
                Class<?> instanceClass = null;
                if ("".equals(instanceClassName))
                    // common case: instance class name is the same as declared
                    instanceClass = declaredClass;
                else
                    instanceClass = Class.forName(instanceClassName);
                IWritable writable = (IWritable) instanceClass.newInstance();
                writable.readFields(in);
                instance = writable;

                if (instanceClass == NullInstance.class) { // null
                    declaredClass = ((NullInstance) instance).declaredClass;
                    instance = null;
                }
            } catch (InstantiationException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

        if (objectWritable != null) { // store values
            objectWritable.declaredClass = declaredClass;
            objectWritable.instance = instance;
        }

        return instance;
    }

    private static void writePrimitiveArray(DataOutput out,
            Class<?> componentClass, Object o) throws IOException {
        int len = Array.getLength(o);
        if (componentClass == Boolean.TYPE) {
            boolean[] a = (boolean[]) o;
            for (int i = 0; i < len; i++)
                out.writeBoolean(a[i]);
        } else if (componentClass == Character.TYPE) {
            char[] a = (char[]) o;
            for (int i = 0; i < len; i++)
                out.writeChar(a[i]);
        } else if (componentClass == Byte.TYPE) {
            byte[] a = (byte[]) o;
            // zf: BufferedOutputStream.write(byte[]) is faster because it bypasses 
            // the buffering when the writing a large byte array 
            out.write(a);
            // zf: the following has very bad performance
            //      for (int i = 0; i < len; i++)
            //        out.writeByte(a[i]);
        } else if (componentClass == Short.TYPE) {
            short[] a = (short[]) o;
            for (int i = 0; i < len; i++)
                out.writeShort(a[i]);
        } else if (componentClass == Integer.TYPE) {
            int[] a = (int[]) o;
            for (int i = 0; i < len; i++)
                out.writeInt(a[i]);
        } else if (componentClass == Long.TYPE) {
            long[] a = (long[]) o;
            for (int i = 0; i < len; i++)
                out.writeLong(a[i]);
        } else if (componentClass == Float.TYPE) {
            float[] a = (float[]) o;
            for (int i = 0; i < len; i++)
                out.writeFloat(a[i]);
        } else if (componentClass == Double.TYPE) {
            double[] a = (double[]) o;
            for (int i = 0; i < len; i++)
                out.writeDouble(a[i]);
        } else {
            throw new IllegalArgumentException(componentClass
                    + " is not a primitive type");
        }
    }

    private static Object readPrimitiveArray(DataInput in,
            Class<?> componentClass, int length) throws IOException {
        Object r;
        if (componentClass == Boolean.TYPE) { // boolean
            boolean[] a = new boolean[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readBoolean();
        } else if (componentClass == Character.TYPE) { // char
            char[] a = new char[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readChar();
        } else if (componentClass == Byte.TYPE) { // byte
            byte[] a = new byte[length];
            r = a;
            in.readFully(a);
        } else if (componentClass == Short.TYPE) { // short
            short[] a = new short[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readShort();
        } else if (componentClass == Integer.TYPE) { // int
            int[] a = new int[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readInt();
        } else if (componentClass == Long.TYPE) { // long
            long[] a = new long[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readLong();
        } else if (componentClass == Float.TYPE) { // float
            float[] a = new float[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readFloat();
        } else if (componentClass == Double.TYPE) { // double
            double[] a = new double[length];
            r = a;
            for (int i = 0; i < length; i++)
                a[i] = in.readDouble();
        } else
            throw new IllegalArgumentException(componentClass
                    + " is not a primitive type");
        return r;
    }

}
