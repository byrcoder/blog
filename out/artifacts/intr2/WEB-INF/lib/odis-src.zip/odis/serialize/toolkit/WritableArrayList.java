package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;

import odis.serialize.IWritable;

/**
 * An data structure expressing an array-list of writables.
 * 
 * Usage:
 *   Two alternative ways to use this class:
 *     1) Inherite this class, implements newElementInstance() then use the
 *        the sub-class as other IWritable class. 
 *        E.g.
 *          public class Strings extends WritableArrayList<StringWritable> {
 *              @Override
 *              protected StringWritable WritableArrayList() {
 *                  return new StringWritable();
 *              }
 *          }
 *          
 *     2) Use the WritableArrayList.get(...) to directly generate instance. This 
 *        is sometimes useful, since a writable instance whithin another 
 *        IWritable class is often modified by final, i.e. it was created at 
 *        creation of the parent class and never change again. 
 *        E.g.
 *          class ParentWritable {
 *              private final WritableArrayList<StringWritable> names =
 *                  WritableArrayList.get(StringWritable.class);
 *                  
 *              public WritableArrayList<StringWritable, IntWritable> getNames(
 *                      ) {
 *                  return names;
 *              }
 *          }
 *           
 * @author david
 *
 * @param <E> The type of the element.
 */
@SuppressWarnings("serial")
public abstract class WritableArrayList<E extends IWritable> extends ArrayList<E> implements IWritable {
    
    protected abstract E newElementInstance();

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(this.size());
        for (int i = 0; i < size(); i++) {
            ((IWritable) this.get(i)).writeFields(out);
        }
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        final int size_in = in.readInt();
        // read fields
        for (int i = 0; i < size_in; i++)
            if (i < this.size()) {
                this.get(i).readFields(in);
            } else {
                E obj = newElementInstance();
                obj.readFields(in);
                this.add(obj);
            } // else, for i
        // remove extra elements
        if (this.size() > size_in)
            this.removeRange(size_in, this.size());
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        WritableArrayList<E> that = (WritableArrayList<E>) value;
        // copy elements
        for (int i = 0; i < that.size(); i++)
            if (i < this.size()) {
                this.get(i).copyFields(that.get(i));
            } else {
                E obj = newElementInstance();
                obj.copyFields(that.get(i));
                this.add(obj);
            } // else, for i
        // remove extra elements
        if (this.size() > that.size()) {
            this.removeRange(that.size(), this.size());
        }
        return this;
    }
    /**
     * Removes from this List all of the elements whose index is between
     * fromIndex, inclusive and toIndex, exclusive.  Shifts any succeeding
     * elements to the left (reduces their index).
     * This call shortens the list by <tt>(toIndex - fromIndex)</tt> elements.
     * (If <tt>toIndex==fromIndex</tt>, this operation has no effect.)
     *
     * @param fromIndex index of first element to be removed.
     * @param toIndex index after last element to be removed.
     */
    @Override
    public void removeRange(int fromIndex, int toIndex) {
        super.removeRange(fromIndex, toIndex);
    }

    /**
     * Default constructor.
     */
    public WritableArrayList() {
        super();
    }
    /**
     * The constructor with an initial value
     * @param list  the initial value
     */
    public WritableArrayList(WritableArrayList<E> list) {
        super(list);
    }

    /**
     * Returns a string representation of this object.
     */
    @Override
    public String toString() {
        if (size() == 0) {
            return "[](#=0)";
        }
        StringBuffer sb = new StringBuffer();
        sb.append("[");
        for (int i = 0; ;i++) {
            sb.append(get(i));
            if (i == size() - 1) {
                return sb.append("](#=").append(size()).append(')').toString();
            }
            sb.append(", ");
        }
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        int hash = this.size();
        for (int i = 0; i < this.size(); i++) {
            hash = hash * 31 + this.get(i).hashCode();
        }
        return hash;
    }

    /**
     * return true iff <code>o</code> is an instance of
     * {@link WritableArrayList} with same elements.
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof WritableArrayList)) {
            return false;
        }
        if (o == this) {
            return true;
        }

        WritableArrayList<E> that = (WritableArrayList<E>) o;
        if (this.size() != that.size()) {
            return false;
        }

        for (int i = 0; i < this.size(); i++) {
            if (!this.get(i).equals(that.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Constructs a WritableArrayList instance for a specified class
     * 
     * @param <E>
     *            the type of the element
     * @param cls
     *            the class of the element
     * @return the constrcted instance
     */
    public static <E extends IWritable> WritableArrayList<E> get(
            final Class<E> cls) {
        return new WritableArrayList<E>() {
            @Override
            protected E newElementInstance() {
                try {
                    return cls.newInstance();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
