package odis.serialize.comparator;

/**
 * Compare two "vint-bytes" (length stored as vint before bytes).
 * {@link odis.io.CDataInputStream#readVInt(java.io.DataInput)} is not used
 * because we must know the exact begining of bytes after vint.
 * 
 * @author river
 */
public class VIntBytesBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored, read length from b1
     * @param l2
     *            ignored, read length from b2
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {

        // read vint from b1 and move the offset s1 to the begining of bytes
        byte b = b1[s1++];
        int len1 = b & 0x7F;
        int end = s1 + l1;

        for (int shift = 7; (b & 0x80) != 0 && s1 < end; shift += 7, s1++) {
            b = b1[s1];
            len1 |= (b & 0x7F) << shift;
        }

        // read vint from b2 and move the offset s2 to the begining of bytes
        b = b2[s2++];
        int len2 = b & 0x7F;
        end = s2 + l2;

        for (int shift = 7; (b & 0x80) != 0 && s2 < end; shift += 7, s2++) {
            b = b2[s2];
            len2 |= (b & 0x7F) << shift;
        }

        return compareBytes(b1, s1, len1, b2, s2, len2);
    }

}
