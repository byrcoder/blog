package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.DoubleBinaryComparator;

/**
 * Writable to store one double value.
 * 
 * @author river
 */
public class DoubleWritable implements IWritableComparable, ISkippable,
        IParsable, IClearable {

    static {
        WritableRegistry.register(DoubleWritable.class, "double", Double.SIZE
                / Byte.SIZE, DoubleBinaryComparator.class);
    }

    private double value;

    /**
     * The constructor with initial value 0.0.
     */
    public DoubleWritable() {}

    /**
     * The constructor with an initial value.
     * 
     * @param value
     */
    public DoubleWritable(double value) {
        this.value = value;
    }

    /**
     * Set value to 0.0.
     */
    @Override
    public void clear() {
        value = 0.0;
    }

    /**
     * Set the value of this DoubleWritable.
     * 
     * @param value
     */
    public void set(double value) {
        this.value = value;
    }

    /**
     * Return the value of this DoubleWritable.
     */
    public double get() {
        return value;
    }

    /**
     * Adds the value and returns the result. The value of this instance is also
     * changed.
     * 
     * @param m
     *            the number to be added to
     * @return the result value
     */
    public double addAndGet(double m) {
        value += m;
        return value;
    }

    /**
     * Multiplies the value and returns the result. The value of this instance
     * is also changed.
     * 
     * @param m
     *            the number to be multiplied to
     * @return the result value
     */
    public double mulAndGet(double m) {
        value *= m;
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeDouble(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readDouble();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.value = ((DoubleWritable) value).value;
        return this;
    }

    /**
     * just call {@link Double#compare(double, double)}.<br>
     * <strong>Note</strong>: this class has a natural ordering that is
     * inconsistent with equals.
     * 
     * @see Double#compare(double, double)
     */
    @Override
    public int compareTo(IWritable o) {
        double thisValue = this.value;
        double thatValue = ((DoubleWritable) o).value;
        return Double.compare(thisValue, thatValue);
    }

    /**
     * Same rule with {@link Double#equals(Object)}. <br>
     * <strong>Notice:</strong> Call <code>d1.equals(d2)</code> is not
     * encouraged, you should use <code>abs(d1 - d2) < delta</code> instead.
     * 
     * @see Double#equals(Object)
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DoubleWritable other = (DoubleWritable) o;
        return Double.doubleToLongBits(value) == Double.doubleToLongBits(other.value);
    }

    /**
     * same with {@link Double#hashCode()}
     */
    @Override
    public int hashCode() {
        long v = Double.doubleToLongBits(value);
        return (int) (v ^ (v >>> 32));
    }

    /**
     * just call {@link Double#toString(double)}
     */
    @Override
    public String toString() {
        return Double.toString(value);
    }

    /**
     * use {@link Double#parseDouble(String)} to parse.
     */
    @Override
    public void parse(String str) throws ParseException {
        set(Double.parseDouble(str));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, Double.SIZE / Byte.SIZE);
    }

}
