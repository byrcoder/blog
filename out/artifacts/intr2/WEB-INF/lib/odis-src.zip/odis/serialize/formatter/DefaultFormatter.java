package odis.serialize.formatter;

import odis.serialize.IWritable;

/**
 * Simple formatter that just call toString.
 * 
 * @author zhangduo
 */
public class DefaultFormatter implements IFormatter {

    /**
     * just call toString.
     * 
     * @see IFormatter#format(IWritable)
     */
    @Override
    public String format(IWritable w) {
        return w.toString();
    }

}
