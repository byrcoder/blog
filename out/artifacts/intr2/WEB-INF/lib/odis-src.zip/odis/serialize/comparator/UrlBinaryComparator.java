package odis.serialize.comparator;

/**
 * Compare two urls in bytes format. Rule:
 * <ul>
 * <li>pure hostname goes first, i.e., "www.163.com &lt http://www.163.com"
 * <li>first compare the "reverse(hostname)+path" in bytes order.
 * <li>compare the protocol by rules:(1)standard protocols in order:http &lt;
 * https &lt; ftp; (2) standards protocol goes before non-standard protocol; (3)
 * non-standard protocols are compared in byte order.
 * </ul>
 * 
 * @author river
 */
public class UrlBinaryComparator extends VIntBytesBinaryComparator {

    /**
     * @see VIntBytesBinaryComparator#compare(byte[], int, int, byte[], int,
     *      int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        // read protocols from each buffer
        int protocol1 = b1[s1++];
        int plen1 = protocol1 & 0x1f;
        int protocol2 = b2[s2++];
        int plen2 = protocol2 & 0x1f;

        // read hostLength from each buffer
        // read vint from b1 and move the offset s1 to the beginning of bytes
        byte b = b1[s1++];
        int hlen1 = b & 0x7F;
        int end1 = s1 + l1;
        for (int shift = 7; (b & 0x80) != 0 && s1 < end1; shift += 7, s1++) {
            b = b1[s1];
            hlen1 |= (b & 0x7F) << shift;
        }
        // read vint from b2 and move the offset s2 to the beginning of bytes
        b = b2[s2++];
        int hlen2 = b & 0x7F;
        int end2 = s2 + l2;
        for (int shift = 7; (b & 0x80) != 0 && s2 < end2; shift += 7, s2++) {
            b = b2[s2];
            hlen2 |= (b & 0x7F) << shift;
        }

        // compare
        // read size(vint) from each buffer
        // read vint from b1 and move the offset s1 to the beginning of bytes
        b = b1[s1++];
        int size1 = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0 && s1 < end1; shift += 7, s1++) {
            b = b1[s1];
            size1 |= (b & 0x7F) << shift;
        }
        // read vint from b2 and move the offset s2 to the beginning of bytes
        b = b2[s2++];
        int size2 = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0 && s2 < end2; shift += 7, s2++) {
            b = b2[s2];
            size2 |= (b & 0x7F) << shift;
        }

        // now s1 and s2 points to the exact start of data
        // compare host first
        int comp = compareBytes(b1, s1, hlen1, b2, s2, hlen2);
        if (comp != 0)
            return comp;

        // compare path if host is same
        comp = compareBytes(b1, s1 + hlen1, size1 - plen1 - hlen1, b2, s2
                + hlen2, size2 - plen2 - hlen2);
        if (comp != 0)
            return comp;

        // compare by protocol
        if (protocol1 == 0 && protocol2 != 0) {
            // pure hostname goes first
            return -1;
        } else if (protocol1 != 0 && protocol2 == 0) {
            // pure hostname goes first
            return 1;
        } else {
            // compare the protocol
            int pid1 = (protocol1 >> 5) & 0x7;
            int pid2 = (protocol2 >> 5) & 0x7;
            if (pid1 != 0 && pid2 != 0) {
                // for standard protocol, simply compare the id
                return pid1 - pid2;
            } else if (pid1 != 0 && pid2 == 0) {
                // standard protocol goes first
                return -1;
            } else if (pid1 == 0 && pid2 != 0) {
                // standard protocol goes first
                return 1;
            } else {
                // compare the protocol bytes
                if (plen1 == 0 && plen2 == 0)
                    return 0;
                else
                    return BinaryComparator.compareBytes(b1, s1
                            + (size1 - plen1), plen1, b2, s2 + (size2 - plen2),
                            plen2);
            }
        }
    }

}
