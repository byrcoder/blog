/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.BinaryKeyValComparator;
import sun.misc.Unsafe;
import toolbox.misc.LogFormatter;

/**
 * An abstract base class that compares two objects in their binary form. This
 * is the base class of all other classes in this package. The most interesting
 * use of these BinaryComparators is to allow sorting of SequenceFiles without
 * actually parsing the IWritables in them (i.e. comparing the records as byte
 * arrays).
 * <p>
 * All multi-byte type (e.g. long, double) comparison here uses
 * <b>little-endian</b>, as opposed to Java's default big-endian.
 * 
 * @author zf, zhangduo
 * @see SequenceFileSorter
 * @see BinaryKeyValComparator
 */
public abstract class BinaryComparator {

    private static final Logger LOG = LogFormatter.getLogger(BinaryComparator.class);

    private static final boolean USE_NATIVE_BYTES_COMPARE;

    private static final Unsafe UNSAFE;

    private static final int BYTE_ARRAY_BASE_OFFSET;

    static {
        boolean useNativeBytesCompare = false;
        // the 64bit version is compiled with gcc4, but nx's gcc is 3, this 
        // code will cause jvm crash when linking. Uncomment it when we solve 
        // this problem.
//        try {
//            OdisLibConfig.loadNativeLib("bytescmp");
//            useNativeBytesCompare = true;
//        } catch (Exception e) {
//            LOG.log(Level.WARNING, "load native bytes compare library failed",
//                    e);
//            useNativeBytesCompare = false;
//        }
        USE_NATIVE_BYTES_COMPARE = useNativeBytesCompare;
        Unsafe unsafe;
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            unsafe = (Unsafe) f.get(null);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "load unsafe failed", e);
            unsafe = null;
        }
        UNSAFE = unsafe;
        BYTE_ARRAY_BASE_OFFSET = unsafe != null ? unsafe.arrayBaseOffset(byte[].class)
                : 0;
    }

    /**
     * Compare two objects in binary format.
     * 
     * @param b1
     *            byte array containing first object
     * @param s1
     *            offset of first object in b1
     * @param l1
     *            length of first object in b1
     * @param b2
     *            byte array containing second object
     * @param s2
     *            offset of second object in b2
     * @param l2
     *            length of second object in b2
     * @return a negative integer, zero, or a positive integer (<, =, or >)
     */
    public abstract int compare(byte[] b1, int s1, int l1, byte[] b2, int s2,
            int l2);

    private static native int compareBytes0(byte[] b1, int s1, int l1,
            byte[] b2, int s2, int l2);

    /**
     * Compare bytes using native sse2 pcmpeqb instruction.
     * <p>
     * This is only fast when the bytes are large(more than 2048) and differs at
     * the end.
     * 
     * @param b1
     * @param s1
     * @param l1
     * @param b2
     * @param s2
     * @param l2
     * @return
     */
    public static int nativeCompareBytes(byte[] b1, int s1, int l1, byte[] b2,
            int s2, int l2) {
        if (!USE_NATIVE_BYTES_COMPARE) {
            throw new UnsupportedOperationException(
                    "the native lib is not loaded");
        }
        return compareBytes0(b1, s1, l1, b2, s2, l2);
    }

    /**
     * The pure java implements.
     * 
     * @param b1
     * @param s1
     * @param l1
     * @param b2
     * @param s2
     * @param l2
     * @return
     */
    public static int pureCompareBytes(byte[] b1, int s1, int l1, byte[] b2,
            int s2, int l2) {
        int end1 = s1 + l1;
        int end2 = s2 + l2;
        for (int i = s1, j = s2; i < end1 && j < end2; i++, j++) {
            int a = (b1[i] & 0xff);
            int b = (b2[j] & 0xff);
            if (a != b) {
                return a - b;
            }
        }
        return l1 - l2;
    }

    /**
     * Compare bytes using Unsafe.getLong.
     * <p>
     * This is usually fast(if we scan more than 8 bytes). It is the default
     * compare implementation of
     * {@link #compareBytes(byte[], int, int, byte[], int, int)}
     * 
     * @param b1
     * @param s1
     * @param l1
     * @param b2
     * @param s2
     * @param l2
     * @return
     */
    public static int unsafeCompareBytes(byte[] b1, int s1, int l1, byte[] b2,
            int s2, int l2) {
        if (UNSAFE == null) {
            if (!USE_NATIVE_BYTES_COMPARE) {
                throw new UnsupportedOperationException("unsafe is not loaded");
            }
        }
        int length = Math.min(l1, l2);
        int batchLength = (length >>> 3) << 3;
        long off1 = BYTE_ARRAY_BASE_OFFSET + s1;
        long off2 = BYTE_ARRAY_BASE_OFFSET + s2;
        for (int i = 0; i < batchLength; i += 8) {
            long v1 = UNSAFE.getLong(b1, off1 + i);
            long v2 = UNSAFE.getLong(b2, off2 + i);
            long diff = v1 ^ v2;
            if (diff != 0) {
                // binary search
                int n = 0;
                int y;
                int x = (int) diff;
                if (x == 0) {
                    x = (int) (diff >>> 32);
                    n = 32;
                }

                y = x << 16;
                if (y == 0) {
                    n += 16;
                } else {
                    x = y;
                }

                y = x << 8;
                if (y == 0) {
                    n += 8;
                }
                return (int) (((v1 >>> n) & 0xFFL) - ((v2 >>> n) & 0xFFL));
            }
        }
        for (int i = batchLength; i < length; i++) {
            int a = (b1[s1 + i] & 0xff);
            int b = (b2[s2 + i] & 0xff);
            if (a != b) {
                return a - b;
            }
        }
        return l1 - l2;
    }

    /**
     * Lexicographic order of binary data.
     */
    public static int compareBytes(byte[] b1, int s1, int l1, byte[] b2,
            int s2, int l2) {
        if (UNSAFE != null) {
            if (s1 < 0 || l1 < 0 || s2 < 0 || l2 < 0 || s1 + l1 > b1.length
                    || s2 + l2 > b2.length) {
                throw new ArrayIndexOutOfBoundsException();
            }
            return unsafeCompareBytes(b1, s1, l1, b2, s2, l2);
        } else {
            return pureCompareBytes(b1, s1, l1, b2, s2, l2);
        }
    }

}
