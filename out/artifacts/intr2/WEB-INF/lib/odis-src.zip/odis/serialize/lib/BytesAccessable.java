/**
 * @(#)BytesAccessable.java, 2007-7-30. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.lib;

/**
 * The interface representing an object that can be accessed by a byte array.
 * 
 * @author river, David
 *
 */
public interface BytesAccessable {
    /**
     * Get the buffer for the bytes of given data/object.
     * NOTE: this buffer could be larger than the actual data, so call {@link #getByteLength()} to 
     * get the actual size.
     * 
     * @return  the buffer bytes array
     */
    public byte[] getBytes();
    
    /**
     * Get the length of bytes.
     * @return
     */
    public int getByteLength();
    
}
