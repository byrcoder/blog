/**
 * 
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * A pair of Writable objects.
 * 
 * Usage:
 *   Two alternative ways to use this class:
 *     1) Inherite this class, implements newFirstInstance()/newSecondInstance() 
 *        then use the the sub-class as other IWritable class. 
 *        E.g.
 *          public class StringInt extends WritablePair<StringWritable, 
 *                      IntWritable> {
 *              @Override
 *              protected StringWritable newFirstInstance() {
 *                  return new StringWritable();
 *              }
 *              @Override
 *              protected IntWritable newSecondInstance() {
 *                  return new IntWritable();
 *              }
 *          }
 *          
 *     2) Use the WritablePair.get(...) to directly generate instance. This is
 *        sometimes useful, since a writable instance whithin another IWritable
 *        class is often modified by final, i.e. it was created at creation of
 *        the parent class and never change again. 
 *        E.g.
 *          class ParentWritable {
 *              private final WritablePair<StringWritable, IntWritable> nameAge 
 *                  = WritablePair.get(StringWritable.class, IntWritable.class);
 *                  
 *              public WritablePair<StringWritable, IntWritable> getNameAge() {
 *                  return nameAge;
 *              }
 *          }
 *           
 * @author david
 *
 * @param <E_1> The type of the first element. 
 * @param <E_2> The type of the second element.
 */
public abstract class WritablePair<E_1 extends IWritable, E_2 extends IWritable>
        implements IWritable {
    protected E_1 first;

    protected E_2 second;

    protected abstract E_1 newFirstInstance();

    protected abstract E_2 newSecondInstance();

    /**
     * Equal to {@link #first()} 
     * 
     * @return
     */
    public E_1 getFirst() {
        return first;
    }

    /**
     * Equal to {@link #second()}
     * 
     * @return
     */
    public E_2 getSecond() {
        return second;
    }

    protected void setFirst(E_1 f) {
        this.first = f;
    }

    protected void setSecond(E_2 s) {
        this.second = s;
    }

    /**
     * Returns the instance of the first element.
     * 
     * @return the instance of the first element
     */
    public E_1 first() {
        return first;
    }

    /**
     * Returns the instance of the second element.
     * 
     * @return the instance of the second element
     */
    public E_2 second() {
        return second;
    }

    /**
     * Default constructor.
     */
    public WritablePair() {
        first = newFirstInstance();
        second = newSecondInstance();
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        first.writeFields(out);
        second.writeFields(out);
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        first.readFields(in);
        second.readFields(in);
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        first.copyFields(((WritablePair<E_1, E_2>) value).first);
        second.copyFields(((WritablePair<E_1, E_2>) value).second);
        return this;
    }

    /**
     * Return string representation of this object.
     */
    @Override
    public String toString() {
        return "[" + first + " - " + second + "]";
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        return first.hashCode() ^ (second.hashCode() + 1);
    }

    /**
     * Return <code>true</code> if and only if <code>o</code> is an instance of
     * WritablePair with the same first and second element.
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof WritablePair)) {
            return false;
        }
        WritablePair<E_1, E_2> that = (WritablePair<E_1, E_2>) o;
        return this.first.equals(that.first) && this.second.equals(that.second);
    }

    /**
     * Constructs a WritablePair instance with specified element types.
     * 
     * @param <E_1>
     *            the type of the first element
     * @param <E_2>
     *            the type of the second element
     * @param cls_1
     *            the class of the first element
     * @param cls_2
     *            the class of the second element
     * @return the constructed instance
     */
    public static <E_1 extends IWritable, E_2 extends IWritable> WritablePair<E_1, E_2> get(
            final Class<E_1> cls_1, final Class<E_2> cls_2) {
        return new WritablePair<E_1, E_2>() {
            @Override
            protected E_1 newFirstInstance() {
                try {
                    return cls_1.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            protected E_2 newSecondInstance() {
                try {
                    return cls_2.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
