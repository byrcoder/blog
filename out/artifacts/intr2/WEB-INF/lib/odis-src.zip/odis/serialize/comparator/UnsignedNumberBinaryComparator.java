/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

/**
 * Comparator of unsigned bytes, hence able to compare unsigned int, short,
 * long. Little-endian assumed.<br>
 * <strong>Notice:</strong>the unsigned number's size must be fixed(i.e. VInt
 * and VLong is not support), and the two unsigned numbers must have the same
 * size(i.e., can not compare an unsigned int and an unsigned long).
 * 
 * @author river
 */
public class UnsignedNumberBinaryComparator extends BinaryComparator {

    /**
     * l1 and l2 must be equal.
     * 
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        if (l1 != l2) {
            throw new IllegalArgumentException();
        }
        int i = s1 + l1 - 1;
        int j = s2 + l2 - 1;

        for (; i >= s1 && j >= s2; i--, j--) {
            int a = b1[i] & 0xff;
            int b = b2[j] & 0xff;
            if (a != b) {
                return a - b;
            }
        }

        return 0;
    }

}
