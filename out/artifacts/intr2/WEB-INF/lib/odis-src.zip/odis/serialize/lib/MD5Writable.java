package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.MD5BinaryComparator;
import toolbox.text.util.HexString;

/**
 * A writable that represents a 16-byte long MD5 digest. The only benefit in
 * using this compared to {@link BytesWritable} or {@link HexWritable} is that
 * the length is implicit and does not need to be stored.
 * <p>
 * The class also contains utility static methods to compute MD5 digests.
 * 
 * @author xxx, David
 */
public class MD5Writable implements IWritableComparable, ISkippable, IClearable {
    /**
     * The md5 digest length in byte.
     */
    public static final int MD5_LENGTH = 16;
    static {
        WritableRegistry.register(MD5Writable.class, "MD5Hash", MD5_LENGTH,
                MD5BinaryComparator.class);
    }

    private static final ThreadLocal<MessageDigest> DIGESTER_CONTEXT = new ThreadLocal<MessageDigest>() {
        protected synchronized MessageDigest initialValue() {
            try {
                return MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
        }
    };

    private byte[] digest;

    /**
     * Constructs an MD5Hash.
     */
    public MD5Writable() {
        this.digest = new byte[MD5_LENGTH];
    }

    /**
     * Constructs an MD5Hash from a hex string.
     * 
     * @param hex
     */
    public MD5Writable(String hex) {
        setDigest(hex);
    }

    /**
     * Constructs an MD5Hash with a specified value.
     * 
     * @param digest
     */
    public MD5Writable(byte[] digest) {
        if (digest.length != MD5_LENGTH)
            throw new IllegalArgumentException("Wrong length: " + digest.length);
        this.digest = digest;
    }

    /**
     * Set digest to all zero.
     */
    @Override
    public void clear() {
        Arrays.fill(digest, (byte) 0);
    }

    /**
     * Sets the digest value from a hex string.
     * 
     * @param hex
     */
    public void setDigest(String hex) {
        if (hex.length() != MD5_LENGTH * 2) {
            throw new IllegalArgumentException("Wrong length: " + hex.length());
        }
        byte[] digest = new byte[MD5_LENGTH];
        for (int i = 0; i < MD5_LENGTH; i++) {
            int j = i << 1;
            digest[i] = (byte) (charToNibble(hex.charAt(j)) << 4 | charToNibble(hex.charAt(j + 1)));
        }
        this.digest = digest;
    }

    private static final int charToNibble(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        } else if (c >= 'a' && c <= 'f') {
            return 0xa + (c - 'a');
        } else if (c >= 'A' && c <= 'F') {
            return 0xA + (c - 'A');
        } else {
            throw new RuntimeException("Not a hex character: " + c);
        }
    }

    /**
     * Returns the digest bytes.
     */
    public byte[] getDigest() {
        return digest;
    }

    /**
     * Construct a half-sized version of this MD5. Fits in a long
     */
    public long halfDigest() {
        return halfValue(digest);
    }

    /**
     * Construct a small version of this MD5. Fits in a int
     */
    public int shortDigest() {
        return shortValue(digest);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.write(digest);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        in.readFully(digest);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        MD5Writable that = (MD5Writable) value;
        System.arraycopy(that.digest, 0, this.digest, 0, MD5_LENGTH);
        return this;
    }

    /**
     * just call
     * {@link BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)}
     */
    @Override
    public int compareTo(IWritable o) {
        MD5Writable that = (MD5Writable) o;
        return BinaryComparator.compareBytes(this.digest, 0, MD5_LENGTH,
                that.digest, 0, MD5_LENGTH);
    }

    /**
     * Returns true iff <code>o</code> is an MD5Hash whose digest contains the
     * same values.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MD5Writable other = (MD5Writable) o;
        return Arrays.equals(this.digest, other.digest);
    }

    /**
     * Returns a hash code value for this object.
     */
    @Override
    public int hashCode() {
        // xor four ints
        return ((digest[0] & 0xFF) | ((digest[1] & 0xFF) << 8)
                | ((digest[2] & 0xFF) << 16) | ((digest[3] & 0xFF) << 24))
                ^ ((digest[4] & 0xFF) | ((digest[5] & 0xFF) << 8)
                        | ((digest[6] & 0xFF) << 16) | ((digest[7] & 0xFF) << 24))
                ^ ((digest[8] & 0xFF) | ((digest[9] & 0xFF) << 8)
                        | ((digest[10] & 0xFF) << 16) | ((digest[11] & 0xFF) << 24))
                ^ ((digest[12] & 0xFF) | ((digest[13] & 0xFF) << 8)
                        | ((digest[14] & 0xFF) << 16) | ((digest[15] & 0xFF) << 24));
    }

    /**
     * Returns a string representation of this object.
     */
    public String toString() {
        return HexString.bytesToHexNoSpace(digest);
    }

    // ///////////////////////////////////////////////////////////////////////////
    // static methods
    // ///////////////////////////////////////////////////////////////////////////

    /**
     * Constructs, reads and returns an instance.
     * 
     * @param in
     */
    public static MD5Writable read(DataInput in) throws IOException {
        MD5Writable result = new MD5Writable();
        result.readFields(in);
        return result;
    }

    /**
     * Return md5 digest in byte array.
     * 
     * @return the MD5 digest byptes
     */
    public static byte[] md5(byte[] data) {
        return md5(data, 0, data.length);
    }

    /**
     * Return md5 digest in byte array.
     * 
     * @return the MD5 digest byptes
     */
    public static byte[] md5(byte[] data, int start, int len) {
        MessageDigest digester = DIGESTER_CONTEXT.get();
        digester.update(data, start, len);
        return digester.digest();
    }

    /**
     * Return md5 digest in byte array.
     * 
     * @param string
     * @return the MD5 digest byptes
     */
    public static byte[] md5(String string) {
        return md5(StringWritable.encode(string));
    }

    /**
     * Construct a hash value for a byte array.
     */
    public static MD5Writable digest(byte[] data, int start, int len) {
        byte[] digest;
        MessageDigest digester = DIGESTER_CONTEXT.get();
        digester.update(data, start, len);
        digest = digester.digest();
        return new MD5Writable(digest);
    }

    /**
     * Construct a hash value for a byte array.
     */
    public static MD5Writable digest(byte[] data) {
        return digest(data, 0, data.length);
    }

    /**
     * Constructs a hash value for a String.
     */
    public static MD5Writable digest(String string) {
        return digest(StringWritable.encode(string));
    }

    /**
     * Constructs a MD5Writable instance with an intial value.
     * 
     * @param bytesObj
     *            the intial value
     * @return the new MD5Writable instance
     */
    public static MD5Writable digest(BytesAccessable bytesObj) {
        return digest(bytesObj.getBytes(), 0, bytesObj.getByteLength());
    }

    private static long halfValue(byte[] digest) {
        return (((long) digest[0] << 56) | ((long) (digest[1] & 0xFF) << 48)
                | ((long) (digest[2] & 0xFF) << 40)
                | ((long) (digest[3] & 0xFF) << 32)
                | ((long) (digest[4] & 0xFF) << 24)
                | ((long) (digest[5] & 0xFF) << 16)
                | ((long) (digest[6] & 0xFF) << 8) | ((long) digest[7] & 0xFF));
    }

    /**
     * Returns the lower 64-bits of a MD5 code
     * 
     * @param bytesObj
     *            the data
     * @return the lower 64-bits of a MD5 code
     */
    public static long halfDigest(BytesAccessable bytesObj) {
        byte[] digest = md5(bytesObj.getBytes(), 0, bytesObj.getByteLength());
        return halfValue(digest);
    }

    /**
     * Returns the lower 64-bits of a MD5 code
     * 
     * @param s
     *            the data string
     * @return the lower 64-bits of a MD5 code
     */
    public static long halfDigest(String s) {
        byte[] digest = md5(StringWritable.encode(s));
        return halfValue(digest);
    }

    /**
     * Returns the lower 64-bits of a MD5 code
     * 
     * @param data
     *            the data-buffer
     * @param off
     *            the start position of the data in the buffer
     * @param len
     *            the number of bytes of the data
     * @return the lower 64-bits of a MD5 code
     */
    public static long halfDigest(byte[] data, int off, int len) {
        byte[] digest = md5(data, off, len);
        return halfValue(digest);
    }

    /**
     * Extracts the lower 32 bits of the digest and composes an integer value
     * 
     * @param digest
     *            the buffer containing the digest
     * @return the composed integer value
     */
    private static int shortValue(byte[] digest) {
        return ((digest[0] & 0xFF) << 24) | ((digest[1] & 0xFF) << 16)
                | ((digest[2] & 0xFF) << 8) | (digest[3] & 0xFF);
    }

    /**
     * Calculate a 32-bits md5 digest for a byte array. Use this method instead
     * of MD5Writable.digest().shortDigest() to avoid allocating a MD5Writable
     * instance.
     * 
     * @param data
     *            the buffer of the data to be digested
     * @param off
     *            the start of the data in the buffer
     * @param len
     *            the length of the data in bytes
     * @return the 32-bits md5 digest
     */
    public static int shortDigest(byte[] data, int off, int len) {
        byte[] digest = md5(data, off, len);
        return shortValue(digest);
    }

    /**
     * Calculate a 32-bits md5 digest from a string. Use this method instead of
     * MD5Writable.digest().shortDigest() to avoid allocating a MD5Writable
     * instance.
     * 
     * @param data
     *            the buffer of the data to be digested
     * @param off
     *            the start of the data in the buffer
     * @param len
     *            the length of the data in bytes
     * @return the 32-bits md5 digest
     */
    public static int shortDigest(String s) {
        byte[] digest = md5(StringWritable.encode(s));
        return shortValue(digest);
    }

    /**
     * Calculate a 32-bits md5 digest from a BytesAccessable instance. Use this
     * method instead of MD5Writable.digest().shortDigest() to avoid allocating
     * a MD5Writable instance.
     * 
     * @param data
     *            the buffer of the data to be digested
     * @param off
     *            the start of the data in the buffer
     * @param len
     *            the length of the data in bytes
     * @return the 32-bits md5 digest
     */
    public static long shortDigest(BytesAccessable bytesObj) {
        byte[] digest = md5(bytesObj.getBytes(), 0, bytesObj.getByteLength());
        return shortValue(digest);
    }

    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, MD5_LENGTH);
    }

}
