/**
 * @(#)UTF8Comparator.java 0.01 06
 * 
 * Copyright 2006 Kaiwoo, Inc. All rights reserved.
 * KAIWOO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.comparator;

import odis.serialize.lib.StringWritable;

/**
 * @deprecated This class is wrongly implemented. StringWritable.decode does not
 *             correctly decode the data by StringWritable.writeFields() use
 *             VIntBytesBinaryComparator instead
 * @version 0.01, //06
 * @author <a href="mailto:ai.sein@gmail.com">Jielong Zhou</a>
 */
@Deprecated
public class StringBinaryComparator extends BinaryComparator {

    /**
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        String str1 = StringWritable.decode(b1, s1, l1);
        String str2 = StringWritable.decode(b2, s2, l2);

        return str1.compareTo(str2);
    }

}
