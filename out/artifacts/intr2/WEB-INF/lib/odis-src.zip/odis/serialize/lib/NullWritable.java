package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * The writable object that contains nothing.
 * 
 * @author David
 */
public class NullWritable implements IWritable, ISkippable {
    static {
        WritableRegistry.registerAlias(NullWritable.class, "Null_v3");
    }

    private static final NullWritable THIS = new NullWritable();

    /** Returns the single instance of this class. */
    public static NullWritable get() {
        return THIS;
    }

    /**
     * Constructor.But usually you should call {@link #get()} to get an
     * NullWritable instance.
     */
    public NullWritable() {}

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {}

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {}

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {}

    /**
     * Return "nil"
     */
    @Override
    public String toString() {
        return "nil";
    }

    /**
     * Return 0.
     */
    @Override
    public int hashCode() {
        return 0;
    }

    /**
     * return true if and only if <code>o</code> is a NullWritable.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return true;
    }
}
