/**
 * @(#)AbstractMultiDynamicWritable.java, 2007-8-5. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import odis.serialize.IClearable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.toolkit.AbstractDynamicWritable.IClassIdMap;
import toolbox.misc.ClassUtils;

/**
 * AbstractMultiDynamicWritable can wrapp several different types of writable
 * objects in one writable. Subclass should implement {@link #getClassIdMap()}
 * to return the class-id mapping. Code sample for Wrapper class which could
 * wrap in IntWritable and LongWritable: <code>
 *      public class Wrapper extends AbstractMultiDynamicWritable {
 *          private static final IClassIdMap CLASS_ID_MAP = new AbstractClassIdMap() {
 * 
 * @Override public Map<Class, Byte> getIdMap() { HashMap<Class, Byte> map = new
 *           HashMap<Class, Byte>(); map.put(IntWritable.class, (byte)1);
 *           map.put(LongWritable.class, (byte)2); return map; } };
 * @Override protected IClassIdMap getClassIdMap() { return CLASS_ID_MAP; } }
 *           </code>
 * @author river
 */
public abstract class AbstractMultiDynamicWritable implements IWritable,
        IClearable {

    private class TriEntry {
        private IWritable instance;

        private byte id = IClassIdMap.NULL_ID;

        private Class<? extends IWritable> clazz = null;

        public void set(IWritable obj) {
            instance = obj;
            clazz = obj.getClass();
            id = classIdMap.getId(clazz);
            if (id == IClassIdMap.NULL_ID && !allowClassname) {
                throw new RuntimeException("no id defined for class " + clazz
                        + " and classname is not allowed.");
            }
        }
    }

    private IClassIdMap classIdMap;

    private boolean allowClassname;

    private LinkedList<TriEntry> objBuf = new LinkedList<TriEntry>();

    private List<TriEntry> entries = new ArrayList<TriEntry>();

    public AbstractMultiDynamicWritable() {
        classIdMap = getClassIdMap();
        allowClassname = isAllowClassname();
    }

    /**
     * Return the class-id mapping.
     * 
     * @return
     */
    protected abstract IClassIdMap getClassIdMap();

    protected boolean isAllowClassname() {
        return false;
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeShort(entries.size());
        for (TriEntry entry: entries) {
            out.writeByte(entry.id);
            if (entry.id == IClassIdMap.NULL_ID) {
                UTF8Writable.writeString(out,
                        WritableRegistry.getWritableName(entry.clazz));
            }
            entry.instance.writeFields(out);
        }
    }

    /**
     * If the object buffer is not empty, find one same type object in the
     * buffer, or return new instance.
     * 
     * @param clazzId
     * @param clazz
     * @return
     */
    @SuppressWarnings("unchecked")
    protected TriEntry allocateEntry(byte clazzId, Class clazz) {
        for (Iterator<TriEntry> it = objBuf.iterator(); it.hasNext();) {
            TriEntry entry = it.next();
            if (entry.clazz == clazz && entry.id == clazzId) {
                it.remove();
                return entry;
            }
        }
        TriEntry entry = new TriEntry();
        entry.clazz = clazz;
        entry.id = clazzId;
        entry.instance = (IWritable) ClassUtils.newInstance(clazz);
        return entry;
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @SuppressWarnings("unchecked")
    @Override
    public void readFields(DataInput in) throws IOException {
        clear();

        int size = in.readShort();
        for (int i = 0; i < size; i++) {
            byte clazzId = in.readByte();
            Class<? extends IWritable> clazz;
            if (clazzId == IClassIdMap.NULL_ID) {
                String className = UTF8Writable.readString(in);
                clazz = WritableRegistry.getWritableClass(className);
            } else {
                clazz = classIdMap.getClass(clazzId);
            }
            TriEntry entry = allocateEntry(clazzId, clazz);
            entry.instance.readFields(in);
            entries.add(entry);
        }
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || value.getClass() != this.getClass()) {
            throw new RuntimeException("bad value : " + value);
        }
        if (value == this)
            return this;
        AbstractMultiDynamicWritable that = (AbstractMultiDynamicWritable) value;

        clear();
        for (TriEntry entry: that.entries) {
            TriEntry temp = allocateEntry(entry.id, entry.clazz);
            temp.instance.copyFields(entry.instance);
            entries.add(temp);
        }
        return this;
    }

    /**
     * Add all entries to buffer and clear.
     */
    @Override
    public void clear() {
        for (TriEntry entry: entries) {
            objBuf.add(entry);
        }
        entries.clear();
    }

    /**
     * Add object.
     * 
     * @param obj
     */
    public void add(IWritable obj) {
        TriEntry entry;
        if (objBuf.isEmpty()) {
            entry = new TriEntry();
        } else {
            entry = objBuf.remove();
        }
        entry.set(obj);
        entries.add(entry);
    }

    /**
     * Return number of entries contains in this MultiDynamicWritable.
     * 
     * @return
     */
    public int size() {
        return entries.size();
    }

    /**
     * Get object by index.
     * 
     * @param index
     * @return
     */
    public IWritable get(int index) {
        return entries.get(index).instance;
    }

    /**
     * Print all entries.
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append('[').append(entries.size()).append(']');
        int idx = 0;
        for (TriEntry entry: entries) {
            builder.append('<').append(idx++).append('>').append(entry.instance);
        }
        return builder.toString();
    }

}
