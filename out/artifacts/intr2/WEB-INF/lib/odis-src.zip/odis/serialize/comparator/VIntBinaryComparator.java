/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import odis.io.CDataInputStream;

/**
 * A comparator comparing two variant integers.
 * 
 * @author david
 */
public class VIntBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as decided by {@link CDataInputStream#readVInt()}
     * @param l2
     *            ignored as decided by {@link CDataInputStream#readVInt()}
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        int thisValue = CDataInputStream.readVInt(b1, s1);
        int thatValue = CDataInputStream.readVInt(b2, s2);
        return thisValue == thatValue ? 0 : thisValue < thatValue ? -1 : 1;
    }
}
