/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

/**
 * Comparing two byte arrays with specified length.
 * 
 * @author zhangduo
 */
public class BytesBinaryComparator extends BinaryComparator {

    /**
     * just call {@link #compareBytes(byte[], int, int, byte[], int, int)}.
     * 
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        return compareBytes(b1, s1, l1, b2, s2, l2);
    }

}
