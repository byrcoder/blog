package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.IntBinaryComparator;

/**
 * The IWritable class storing an integer value.
 * 
 * @author david
 */
public class IntWritable implements IWritableComparable, IParsable, ISkippable,
        IClearable {
    static {
        WritableRegistry.register(IntWritable.class, "int", Integer.SIZE
                / Byte.SIZE, IntBinaryComparator.class);
    }

    protected int value;

    /**
     * Sets the value.
     * 
     * @param i
     *            the new value
     * @return this instance
     */
    public IntWritable set(int i) {
        this.value = i;
        return this;
    }

    /**
     * Sets the value to zero.
     */
    public void clear() {
        value = 0;
    }

    /**
     * Constructor with value 0.
     */
    public IntWritable() {}

    /**
     * Constructor.
     * 
     * @param i
     *            the initial value
     */
    public IntWritable(int i) {
        value = i;
    }

    /**
     * Returns the value
     * 
     * @return the value
     */
    public int get() {
        return value;
    }

    /**
     * Increase the value and returns the new value. new-value = old-value +
     * change <br>
     * NOTE: this method is not synchronized.
     * 
     * @param change
     *            the delta value
     * @return the new value
     */
    public int incAndGet(int change) {
        value += change;
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readInt();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        IntWritable that = (IntWritable) value;
        this.value = that.value;
        return this;
    }

    /**
     * same rule with {@link Integer#compareTo(Integer)}.
     */
    @Override
    public int compareTo(IWritable o) {
        int thatValue = ((IntWritable) o).value;
        return this.value < thatValue ? -1 : this.value == thatValue ? 0 : 1;
    }

    /**
     * use {@link Integer#parseInt(String)} to parse.
     */
    @Override
    public void parse(String s) {
        set(Integer.parseInt(s));
    }

    /**
     * Returns true iff <code>o</code> is a IntWritable with the same value.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        IntWritable that = (IntWritable) o;
        return this.value == that.value;
    }

    /**
     * same with {@link Integer#hashCode()}
     */
    @Override
    public int hashCode() {
        return value;
    }

    /**
     * just call {@link Integer#toString(int)}
     */
    @Override
    public String toString() {
        return Integer.toString(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, Integer.SIZE / Byte.SIZE);
    }
}
