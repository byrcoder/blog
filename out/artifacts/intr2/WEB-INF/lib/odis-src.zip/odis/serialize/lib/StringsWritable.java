/**
 * @(#)StringsWritable.java, 2007-6-28. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.lib;

import odis.serialize.WritableRegistry;
import odis.serialize.lib.StringWritable;
import odis.serialize.toolkit.AbstractWritableList;

/**
 * Writable list for {@link odis.serialize.lib.StringWritable}.
 * 
 * @see odis.serialize.toolkit.AbstractWritableList
 * @author river
 */
public class StringsWritable extends AbstractWritableList<StringWritable> {
    static {
        WritableRegistry.registerLegacyAlias(StringsWritable.class,
                "outfox.tools.DistillUrlsFromGoogleResultTool$QueriesWritable");
        WritableRegistry.registerAlias(StringsWritable.class,
                "StringsWritable_v1");
    }

    /**
     * @see AbstractWritableList#getElementClass()
     */
    @Override
    public Class<StringWritable> getElementClass() {
        return StringWritable.class;
    }

    /**
     * Faster method to add string directly to list.
     * 
     * @param s
     */
    public void addString(String s) {
        if (size < list.size()) {
            list.get(size).set(s);
        } else {
            StringWritable newElement = newElement();
            newElement.set(s);
            list.add(newElement);
        }
        size++;
    }

    /**
     * To string array.
     * 
     * @return
     */
    public String[] toStringArray() {
        String[] result = new String[this.size];
        for (int i = 0; i < this.size; i++) {
            result[i] = list.get(i).get();
        }
        return result;
    }

}
