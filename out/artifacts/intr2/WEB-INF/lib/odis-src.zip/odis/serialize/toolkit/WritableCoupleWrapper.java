package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * A wrapper for two Writable object. it is just a simple version of
 * DynamicWritable - it only support two writable object( in most case ,we only
 * need two) - it can use the ByteBinaryComparator as ValComparator to order the
 * type of elements in reduce - it will be more efficient than dynamic writable ,
 * since it will not new a lot of elements when read sequence is : E_1, E_2,E_1,
 * E_2,E_1, E_2,E_1, E_2,E_1, E_2
 * 
 * @author yemingjiang
 * @param <E_1>
 *            The type of the first element.
 * @param <E_2>
 *            The type of the second element.
 */
public abstract class WritableCoupleWrapper<E_1 extends IWritable, E_2 extends IWritable>
        implements IWritable {

    /**
     * Means the Writable's type is E_1
     */
    public static final byte TYPE_FIRST = 1;

    /**
     * Means the Writable's type is E_2
     */
    public static final byte TYPE_SECOND = 2;

    protected E_1 first = null;

    protected E_2 second = null;

    protected byte type = 0;

    protected abstract E_1 newFirstInstance();

    protected abstract E_2 newSecondInstance();

    /**
     * Get writable type.
     * 
     * @return
     */
    public byte getType() {
        return type;
    }

    /**
     * Get writable instance.
     * 
     * @return
     */
    public IWritable get() {
        if (type == TYPE_FIRST) {
            return first;
        } else if (type == TYPE_SECOND) {
            return second;
        }
        return null;
    }

    /**
     * Get IWritable with the first type(E_1). If the type is second type(E_2),
     * return null.
     * 
     * @return
     */
    public E_1 getFirst() {
        if (type != TYPE_FIRST) {
            return null;
        }
        return first;
    }

    /**
     * Get IWritable with the second type(E_2). If the type is first type(E_1),
     * return null.
     * 
     * @return
     */
    public E_2 getSecond() {
        if (type != TYPE_SECOND) {
            return null;
        }
        return second;
    }

    /**
     * Set IWritable with first type(E_1).
     * @param first
     */
    public void setAsFirst(E_1 first) {
        this.type = TYPE_FIRST;
        this.first = first;
    }

    /**
     * Set IWritable with second type(E_2).
     * @param first
     */
    public void setAsSecond(E_2 second) {
        this.type = TYPE_SECOND;
        this.second = second;
    }

    /**
     * Default constructor.
     */
    public WritableCoupleWrapper() {
        super();
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(type);
        if (type == TYPE_FIRST)
            first.writeFields(out);
        else if (type == TYPE_SECOND)
            second.writeFields(out);
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        type = in.readByte();
        if (type == TYPE_FIRST) {
            if (first == null)
                first = newFirstInstance();
            first.readFields(in);
        } else if (type == TYPE_SECOND) {
            if (second == null)
                second = newSecondInstance();
            second.readFields(in);
        }
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        WritableCoupleWrapper<E_1, E_2> other = (WritableCoupleWrapper<E_1, E_2>) value;
        type = other.type;
        if (type == TYPE_FIRST) {
            if (first == null)
                first = newFirstInstance();
            first.copyFields(other.first);
        } else if (type == TYPE_SECOND) {
            if (second == null)
                second = newSecondInstance();
            second.copyFields(other.second);
        }
        return this;
    }

    /**
     * Return string representation of the object.
     */
    @Override
    public String toString() {
        String val = "";
        if (type == TYPE_FIRST) {
            val = first.toString();
        } else if (type == TYPE_SECOND) {
            val = second.toString();
        }
        return "[Type:" + type + " , " + "value:" + val + "]";
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        if (type == TYPE_FIRST) {
            return first.hashCode();
        } else if (type == TYPE_SECOND) {
            return second.hashCode();
        }
        return super.hashCode();
    }

    /**
     * If <code>o</code> is not an instance of WritableCoupleWrapper, return <code>false</code>.<br>
     * If types are not equal, return <code>false</code>.<br>
     * If the writables of type are not equal, return <code>false</code>.<br>
     * Else, return <code>true</code>.
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof WritableCoupleWrapper)) {
            return false;
        }
        WritableCoupleWrapper<E_1, E_2> that = (WritableCoupleWrapper<E_1, E_2>) o;
        if (type == that.type) {
            if (type == TYPE_FIRST && !this.first.equals(that.first)) {
                return false;
            }
            if (type == TYPE_SECOND && !this.second.equals(that.second)) {
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * Construct a WritableCoupleWrapper with specified types.
     * @param <E_1>
     * @param <E_2>
     * @param cls_1
     * @param cls_2
     * @return
     */
    public static <E_1 extends IWritable, E_2 extends IWritable> WritableCoupleWrapper<E_1, E_2> get(
            final Class<E_1> cls_1, final Class<E_2> cls_2) {
        return new WritableCoupleWrapper<E_1, E_2>() {
            @Override
            protected E_1 newFirstInstance() {
                try {
                    return cls_1.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            protected E_2 newSecondInstance() {
                try {
                    return cls_2.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
