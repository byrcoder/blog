package odis.serialize.formatter;

import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;

/**
 * Manager for IWritable formatters.
 * 
 * @author zhangduo
 */
public class FormatterManager implements IFormatter {
    private static FormatterManager instance = new FormatterManager();

    private Map<Class<? extends IWritable>, IFormatter> map = new HashMap<Class<? extends IWritable>, IFormatter>();

    /**
     * Get FormatterManager instance.
     * 
     * @return
     */
    public static FormatterManager getInstance() {
        return instance;
    }

    private FormatterManager() {}

    /**
     * Format a given <code>IWritable</code> to String.
     * <code>FormatterManager</code> will find an <code>IFormatter</code> by the
     * <code>IWritable</code>'s class. If no <code>IFormatter</code> found, just
     * call <code>toString</code>.
     */
    @Override
    public String format(IWritable w) {
        Class<? extends IWritable> clazz = w.getClass();
        IFormatter f = map.get(clazz);
        if (f == null) {
            return w.toString();
        } else {
            return f.format(w);
        }
    }

    /**
     * register Class -> IFormatter.
     * 
     * @param clazz
     * @param formatter
     */
    public void register(Class<? extends IWritable> clazz, IFormatter formatter) {
        map.put(clazz, formatter);
    }

    /**
     * Static format method, equals to <code>getInstance().format(w)</code>.
     * 
     * @param w
     * @return
     */
    public static String getString(IWritable w) {
        return instance.format(w);
    }

}
