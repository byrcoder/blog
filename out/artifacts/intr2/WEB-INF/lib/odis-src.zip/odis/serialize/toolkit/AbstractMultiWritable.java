/**
 * @(#)MultiWritable.java, 2007-6-8. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.serialize.IClearable;
import odis.serialize.IWritable;
import toolbox.misc.ClassUtils;

/**
 * 包装多个对象的容器.
 * @author river
 */
public abstract class AbstractMultiWritable implements IWritable, IClearable {
    private static final int UNIT_BITS_LENGTH = 64;

    private IWritable [] writables;
    private long [] bits;
    private Class [] internalDefs;
    
    public AbstractMultiWritable() {
        internalDefs = getEntryDefs();
        int entryCount = internalDefs.length;
        if (entryCount == 0) {
            throw new RuntimeException("bad definition: entry count is zero");
        }
        
        writables = new IWritable[entryCount];
        Arrays.fill(writables, null);
        bits = new long[(entryCount + 63) / 64];
        Arrays.fill(bits, 0);
    }

    /**
     * 返回容器中各个位置上的数据的类型定义，子类必须实现这个方法，
     * 返回实际的类型定义.
     * @return
     */
    public abstract Class [] getEntryDefs();
    
    /**
     * 清除容器中的所有数据.
     */
    @Override
    public void clear() {
        Arrays.fill(bits, 0);
    }
    
    /**
     * 设置指定的索引上的对象，如果值为null，对应位上的对象会被清除.
     * @param idx
     * @param obj
     */
    public void set(int idx, IWritable obj) {
        if (idx < 0 || idx >= writables.length) {
            throw new ArrayIndexOutOfBoundsException("idx " + idx 
                    + " is out of bounds [0, " + writables.length + ")");
        }
        int i = idx / UNIT_BITS_LENGTH;
        int j = idx % UNIT_BITS_LENGTH;
        if (obj == null) {
            bits[i] = bits[i] & ~(1L<<j);
        } else {
            writables[idx] = obj;
            bits[i] = bits[i] | (1L<<j);
        }
    }
    
    /**
     * 取得指定索引上的对象，如果对应的位上没有数据，返回null.
     * @param idx
     * @return
     */
    public IWritable get(int idx) {
        if (idx < 0 || idx >= writables.length) {
            throw new ArrayIndexOutOfBoundsException("idx " + idx 
                    + " is out of bounds [0, " + writables.length + ")");
        }
        
        int i = idx / UNIT_BITS_LENGTH;
        int j = idx % UNIT_BITS_LENGTH;
        if ((bits[i] & (1L<<j)) != 0) {
            return writables[idx];
        } else {
            return null;
        }
    }
    
    /**
     * 判断这个容器中是否所有的位上都没有数据.
     * @return
     */
    public boolean isEmpty() {
        for (int i=0; i<bits.length; i++) {
            if (bits[i] != 0) return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        StringBuilder buffer = new StringBuilder();
        
        int idx = 0, bidx = 0;
        long l = bits[idx];
        for (int i = 0; i < writables.length; i++) {
            buffer.append("[").append(i).append("]");
            if ((l & 0x01) != 0) {
                buffer.append(writables[i]);
            } else {
                buffer.append("<null>");
            }
            bidx ++;
            if (bidx == UNIT_BITS_LENGTH) {
                l = bits[++idx];
                bidx = 0;
            } else {
                l = l >> 1;
            }
        }
        return buffer.toString();
    }
    
    @Override
    public void readFields(DataInput in) throws IOException {
        for (int i=0; i<bits.length; i++) {
            bits[i] = in.readLong();
        }
        
        int idx = 0, bidx = 0;
        long l = bits[idx];
        for (int i = 0; i < writables.length; i++) {
            if ((l & 0x01) != 0) {
                if (writables[i] == null) {
                    writables[i] = (IWritable)ClassUtils.newInstance(internalDefs[i]);
                }
                writables[i].readFields(in);
            }
            bidx ++;
            if (bidx == UNIT_BITS_LENGTH) {
                l = bits[++idx];
                bidx = 0;
            } else {
                l = l >> 1;
            }
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        for (int i=0; i<bits.length; i++) {
            out.writeLong(bits[i]);
        }
        int idx = 0, bidx = 0;
        long l = bits[idx];
        for (int i = 0; i < writables.length; i++) {
            if ((l & 0x01) != 0) {
                writables[i].writeFields(out);
            }
            bidx ++;
            if (bidx == UNIT_BITS_LENGTH) {
                l = bits[++idx];
                bidx = 0;
            } else {
                l = l >> 1;
            }
        }
    }

    /**
     * 默认的情况下，执行深拷贝.
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || !(value instanceof AbstractMultiWritable)) {
            throw new RuntimeException("bad value : " + value);
        }
        if (value == this) return this;
        
        AbstractMultiWritable that = (AbstractMultiWritable) value;
        if (that.internalDefs.length != this.internalDefs.length) {
            throw new RuntimeException("different definition found");
        }
        System.arraycopy(that.bits, 0, this.bits, 0, that.bits.length);
        for (int i=0; i<that.internalDefs.length; i++) {
            if (that.writables[i] != null) {
                if (this.writables[i] == null) {
                    this.writables[i] = (IWritable)ClassUtils.newInstance(this.internalDefs[i]);
                }
                this.writables[i].copyFields(that.writables[i]);
            }
        }
        return this;
    }
    
}
