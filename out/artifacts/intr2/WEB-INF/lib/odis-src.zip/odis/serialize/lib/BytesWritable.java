package odis.serialize.lib;

import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.IntBytesBinaryComparator;
import toolbox.misc.EmptyInstance;
import toolbox.text.util.HexString;

/**
 * Writable that stores a byte array.
 * 
 * @author river, David
 */
public class BytesWritable implements IWritableComparable, ISkippable,
        BytesAccessable, IClearable {

    static {
        WritableRegistry.register(BytesWritable.class, "Bytes_v3",
                IntBytesBinaryComparator.class);
    }

    private byte[] bytes = EmptyInstance.BYTES;

    private int size = 0;

    private int maxBufferSize = Integer.MAX_VALUE;

    /**
     * Constructor with empty buffer and zero size.
     */
    public BytesWritable() {}

    /**
     * The constructor with an initial value
     * 
     * @param bytes
     *            the initial value for the bytes field
     */
    public BytesWritable(byte[] bytes) {
        this.bytes = bytes;
        size = bytes.length;
    }

    /**
     * <code>maxBufferSize</code> do <strong>NOT</strong> means the buffer size
     * limit. You can set a buffer larger than <code>maxBufferSize</code> or
     * create a buffer larger than maxBufferSize by <code>readFields</code>.<br>
     * <code>maxBufferSize</code> works as follow: <br>
     * when you call <code>set</code> or
     * <code>readFields<code>, we find that you have a buffer larger
     * than maxBufferSize, and you only need a buffer smaller than maxBufferSize
     * actually, then we will recreate the buffer, so its size will be smaller than
     * maxBufferSize.
     * 
     * @param size
     */
    public void setMaxBufferSize(int size) {
        this.maxBufferSize = size;
    }

    /**
     * Set the contents. This method copy the bytes into this object.
     * 
     * @param bytes
     *            the content buffer
     * @param off
     *            the start of the content in the buffer
     * @param len
     *            the number of bytes of the content in the buffer
     */
    public void set(byte[] bytes, int off, int len) {
        if (len > this.bytes.length
                || (this.bytes.length > maxBufferSize && len < maxBufferSize)) {
            this.bytes = Limit.createBuffer(len);
        }
        System.arraycopy(bytes, off, this.bytes, 0, len);
        this.size = len;
    }

    /**
     * Set the data, this method copy the bytes into this object.
     * 
     * @param bytes
     */
    public void set(byte[] bytes) {
        set(bytes, 0, bytes.length);
    }

    /**
     * Set the content of a single byte at a give position
     * 
     * @param index
     *            the position of the byte to be set
     * @param b
     *            the value of the byte
     */
    public void setByte(int index, byte b) {
        if (index >= bytes.length) {
            byte[] temp = Limit.createBuffer((index / 16 + 1) * 16);
            Arrays.fill(temp, (byte) 0);
            System.arraycopy(bytes, 0, temp, 0, bytes.length);
            bytes = temp;
        }
        bytes[index] = b;
        if (index >= size) {
            size = index + 1;
        }
    }

    /**
     * Return the byte at index.
     * 
     * @param index
     * @return
     */
    public byte getByte(int index) {
        return bytes[index];
    }

    /**
     * Set buffer to empty, set size to 0.
     */
    @Override
    public void clear() {
        bytes = EmptyInstance.BYTES;
        size = 0;
    }

    /**
     * @deprecated use BytesWritable.copyFileds instead.
     */
    @Deprecated
    public void set(BytesWritable that) {
        set(that.bytes, 0, that.size);
    }

    /**
     * Set the buffer, this method use the given bytes directly as buffer.
     * 
     * @param bytes
     */
    public void setBuffer(byte[] bytes) {
        this.bytes = bytes;
        this.size = bytes.length;
    }

    /**
     * Set the buffer, this method use the given bytes directly as buffer.
     * 
     * @param bytes
     * @param size
     */
    public void setBuffer(byte[] bytes, int size) {
        this.bytes = bytes;
        this.size = size;
    }

    /**
     * Get the buffer for the bytes of given data/object.<br>
     * NOTE: this buffer could be larger than the actual data, so call
     * {@link #size()} to get the actual size.
     * 
     * @return the buffer bytes array
     */
    public byte[] data() {
        return bytes;
    }

    /**
     * Returns the number of bytes in the object
     * 
     * @return the number of bytes in the object
     */
    public int size() {
        return size;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int step = size / 128;
        if (step == 0) {
            step = 1;
        }
        int index = 0;
        int hash = 0;
        while (index < size) {
            hash = (hash << 31) ^ bytes[index];
            index += step;
        }
        return hash;
    }

    /**
     * return true if and only if size are same and every byte are same.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (o == this) {
            return true;
        }
        BytesWritable that = (BytesWritable) o;
        if (this.size != that.size) {
            return false;
        }
        byte[] thatData = that.bytes;
        for (int i = 0; i < size; i++) {
            if (bytes[i] != thatData[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * just call
     * {@link BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)}
     * .
     */
    @Override
    public int compareTo(IWritable o) {
        BytesWritable that = (BytesWritable) o;
        return IntBytesBinaryComparator.compareBytes(this.data(), 0, this.size,
                that.data(), 0, that.size);
    }

    /**
     * Writes the contents to a DataOutput
     * 
     * @param out
     *            the DataOutput instance
     * @throws IOException
     *             if an I/O error occurs
     */
    public void writeBytes(DataOutput out) throws IOException {
        out.write(bytes, 0, size);
    }

    /**
     * Reads the contents from a DataInput
     * 
     * @param in
     *            the DataInput instance
     * @param length
     *            the number of bytes to be read
     * @throws IOException
     *             if an I/O error occurs
     */
    public void readBytes(DataInput in, int length) throws IOException {
        size = length;
        if (size > bytes.length
                || (this.bytes.length > maxBufferSize && size < maxBufferSize)) {
            bytes = Limit.createBuffer(size);
        }
        in.readFully(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(size);
        out.write(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = in.readInt();
        if (size > bytes.length
                || (this.bytes.length > maxBufferSize && size < maxBufferSize)) {
            bytes = Limit.createBuffer(size);
        }
        in.readFully(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == this)
            return this;
        if (value == null || !(value instanceof BytesWritable)) {
            throw new RuntimeException("bad value : " + value);
        }
        BytesWritable that = (BytesWritable) value;
        set(that.bytes, 0, that.size);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int len = in.readInt();
        CDataInputStream.skipBytes(in, len);
    }

    /**
     * Read int byte array from given input.
     * 
     * @param in
     * @return
     * @throws IOException
     */
    public static byte[] readBytes(DataInput in) throws IOException {
        int sz = in.readInt();
        byte[] buf = new byte[sz];
        in.readFully(buf);
        return buf;
    }

    /**
     * Write bytes out with int length.
     * 
     * @param out
     * @param bytes
     * @throws IOException
     */
    public static void writeBytes(DataOutput out, byte[] bytes)
            throws IOException {
        out.writeInt(bytes.length);
        out.write(bytes);
    }

    /**
     * Write bytes contained in <code>bos</code> to <code>out</code> with int
     * length.
     * 
     * @param out
     * @param bos
     * @throws IOException
     */
    public static void writeBytes(DataOutputStream out,
            ByteArrayOutputStream bos) throws IOException {
        out.writeInt(bos.size());
        bos.writeTo(out);
    }

    /**
     * Write bytes contained in <code>bos</code> to <code>out</code> with int
     * length.
     * 
     * @param out
     * @param bos
     * @throws IOException
     */
    public static void writeBytes(CDataOutputStream out,
            ByteArrayOutputStream bos) throws IOException {
        out.writeInt(bos.size());
        bos.writeTo(out);
    }

    /**
     * Write range bytes to <code>out</code> with int length.
     * 
     * @param out
     * @param bytes
     * @param off
     * @param len
     */
    public static void writes(DataOutput out, byte[] bytes, int off, int len)
            throws IOException {
        out.writeInt(len);
        out.write(bytes, off, len);
    }

    /**
     * Convert to a hex string with ' ' between bytes.
     * 
     * @see HexString#bytesToHex(byte[], int, int)
     */
    @Override
    public String toString() {
        return HexString.bytesToHex(bytes, 0, size);
    }

    /**
     * equal to {@link #size()}
     * 
     * @see BytesAccessable#getByteLength()
     */
    @Override
    public int getByteLength() {
        return size;
    }

    /**
     * @deprecated the name of Bytes confuses a lot of person. Use
     *             {@link #getBuffer()} instead. Returns the raw bytes, you must
     *             use {@link #size()} to acquire the actual number of elements.
     * @return
     */
    @Override
    @Deprecated
    public byte[] getBytes() {
        return bytes;
    }

    /**
     * Returns the internal int array buffer. Call #{@link #size()} to get the
     * the number of available elements in the buffer.
     * 
     * @return the internal int array buffer
     */
    public byte[] getBuffer() {
        return bytes;
    }
}
