/**
 * 
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * A combination of three writables.
 * 
 * Usage:
 *   Two alternative ways to use this class:
 *     1) Inherite this class, implements newFirstInstance()/newSecondInstance()
 *        /newThirdInstance then use the the sub-class as other IWritable class. 
 *        E.g.
 *          public class NameAgeScore extends WritableTriplet<StringWritable, 
 *                      IntWritable, FloatWritable> {
 *              @Override
 *              protected StringWritable newFirstInstance() {
 *                  return new StringWritable();
 *              }
 *              @Override
 *              protected IntWritable newSecondInstance() {
 *                  return new IntWritable();
 *              }
 *              @Override
 *              protected FloatWritable newThirdInstance() {
 *                  return new FloatWritable();
 *              }
 *          }
 *          
 *     2) Use the WritableTriplet.get(...) to directly generate instance. This is
 *        sometimes useful, since a writable instance whithin another IWritable
 *        class is often modified by final, i.e. it was created at creation of
 *        the parent class and never change again. 
 *        E.g.
 *          class ParentWritable {
 *              private final WritableTriplet<StringWritable, IntWritable, 
 *                  FloatWritable> nameAgeScore = WritableTriplet.get(
 *                  StringWritable.class, IntWritable.class, FloatWritable);
 *                  
 *              public WritableTriplet<StringWritable, IntWritable, 
 *                      FloatWritable> getNameAgeScore() {
 *                  return nameAge;
 *              }
 *          }
 *          
 * @author david
 *
 * @param <E_1> The type of the first element. 
 * @param <E_2> The type of the second element.
 * @param <E_3> The type of the third element.
 */
public abstract class WritableTriplet<E_1 extends IWritable, 
        E_2 extends IWritable, E_3 extends IWritable> implements IWritable {
    final protected E_1 first;

    final protected E_2 second;

    final protected E_3 third;

    protected abstract E_1 newFirstInstance();

    protected abstract E_2 newSecondInstance();

    protected abstract E_3 newThirdInstance();

    /**
     * Equal to {@link #first()}
     * @return
     */
    public E_1 getFirst() {
        return first;
    }

    /**
     * Equal to {@link #second()}
     * @return
     */
    public E_2 getSecond() {
        return second;
    }

    /**
     * Equal to {@link #third()}
     * @return
     */
    public E_3 getThird() {
        return third;
    }

    /**
     * Returns the instance of the first element.
     * 
     * @return the instance of the first element
     */
    public E_1 first() {
        return first;
    }

    /**
     * Returns the instance of the second element.
     * 
     * @return the instance of the second element
     */
    public E_2 second() {
        return second;
    }

    /**
     * Returns the instance of the third element.
     * 
     * @return the instance of the third element
     */
    public E_3 third() {
        return third;
    }

    /**
     * Default constructor.
     */
    public WritableTriplet() {
        first = newFirstInstance();
        second = newSecondInstance();
        third = newThirdInstance();
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        first.writeFields(out);
        second.writeFields(out);
        third.writeFields(out);
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        first.readFields(in);
        second.readFields(in);
        third.readFields(in);
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        first.copyFields(((WritableTriplet<E_1, E_2, E_3>) value).first);
        second.copyFields(((WritableTriplet<E_1, E_2, E_3>) value).second);
        third.copyFields(((WritableTriplet<E_1, E_2, E_3>) value).third);
        return this;
    }

    /**
     * Return string representation of this object.
     */
    @Override
    public String toString() {
        return "[" + first + " - " + second + " - " + third + "]";
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        return first.hashCode() ^ (second.hashCode() + 1)
                ^ (third.hashCode() + 2);
    }

    /**
     * Return <code>true</code> if and only if <code>o</code> is an instance of
     * WritablePair with the same first, second and third element.
     */
    @SuppressWarnings("unchecked")
    public boolean equals(Object o) {
        if (o == null || !(o instanceof WritableTriplet)) {
            return false;
        }
        WritableTriplet<E_1, E_2, E_3> that = (WritableTriplet<E_1, E_2, E_3>) o;
        return this.first.equals(that.first) && this.second.equals(that.second)
                && this.third.equals(that.third);
    }

    /**
     * Constructs a WritableTriplet instance with specified element types
     * 
     * @param <E_1>
     *            the type of the first element
     * @param <E_2>
     *            the type of the second element
     * @param <E_3>
     *            the type of the third element
     * @param cls_1
     *            the class of the first element
     * @param cls_2
     *            the class of the second element
     * @param cls_3
     *            the class of the third element
     * @return the constructed instance
     */
    public static <E_1 extends IWritable, E_2 extends IWritable, E_3 extends IWritable> WritableTriplet<E_1, E_2, E_3> get(
            final Class<E_1> cls_1, final Class<E_2> cls_2,
            final Class<E_3> cls_3) {
        return new WritableTriplet<E_1, E_2, E_3>() {
            @Override
            protected E_1 newFirstInstance() {
                try {
                    return cls_1.newInstance();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }

            @Override
            protected E_2 newSecondInstance() {
                try {
                    return cls_2.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            protected E_3 newThirdInstance() {
                try {
                    return cls_3.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
