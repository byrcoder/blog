package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.IntBytesBinaryComparator;
import toolbox.misc.EmptyInstance;
import toolbox.text.util.HexString;

/**
 * For test case use.<br>
 * 
 * @author zhangduo
 */
public class RandomDatum implements IWritableComparable {

    static {
        WritableRegistry.register(RandomDatum.class, "RandomDatum_v3",
                IntBytesBinaryComparator.class);
    }

    private int length;

    private byte[] data = EmptyInstance.BYTES;

    /**
     * Default Constructor.
     */
    public RandomDatum() {}

    /**
     * Constructor.
     * 
     * @param random
     *            use this to generate random data.
     * @param len
     *            the length of data.
     */
    public RandomDatum(Random random, int len) {
        length = len;
        data = new byte[len];
        random.nextBytes(data);
    }

    /**
     * Constructor.
     * 
     * @param random
     *            use this to generate length and data.
     */
    public RandomDatum(Random random) {
        length = 10 + random.nextInt(100);
        data = new byte[length];
        random.nextBytes(data);
    }

    /**
     * Set data to empty and length to 0.
     */
    public void clear() {
        data = EmptyInstance.BYTES;
        length = 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(length);
        if (data != null) {
            out.write(data, 0, length);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        length = in.readInt();
        if (data == null || length > data.length) {
            data = new byte[length];
        }
        in.readFully(data, 0, length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        RandomDatum that = (RandomDatum) value;
        this.length = that.length;
        if (that.data != null) {
            if (data == null || length > data.length)
                data = new byte[length];
            System.arraycopy(that.data, 0, this.data, 0, this.length);
        } // else
        return this;
    }

    /**
     * just call
     * {@link BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)}
     */
    @Override
    public int compareTo(IWritable o) {
        RandomDatum that = (RandomDatum) o;
        return BinaryComparator.compareBytes(this.data, 0, this.length,
                that.data, 0, that.length);
    }

    /**
     * Return hex representation for internal data.
     */
    @Override
    public String toString() {
        return HexString.bytesToHexNoSpace(data, 0, length);
    }

    /**
     * RandomDatum generator.
     * 
     * @author zhangduo
     */
    public static class Generator {
        Random random;

        private RandomDatum key;

        private RandomDatum value;

        /**
         * Default constructor.
         */
        public Generator() {
            random = new Random();
        }

        /**
         * Constructor with initial seed.<br>
         * Use same seed will make same key and value sequence.
         * 
         * @param seed
         */
        public Generator(int seed) {
            random = new Random(seed);
        }

        /**
         * Get key.
         * 
         * @return
         */
        public RandomDatum getKey() {
            return key;
        }

        /**
         * Get value.
         * 
         * @return
         */
        public RandomDatum getValue() {
            return value;
        }

        /**
         * generate next key and value.
         */
        public void next() {
            key = new RandomDatum(random);
            value = new RandomDatum(random);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + Arrays.hashCode(data);
        result = PRIME * result + length;
        return result;
    }

    /**
     * return true if and only if <code>o</code> is an instance of RandomDatum,
     * and <code>this.compareTo(o)</code> return 0.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return compareTo((IWritable) o) == 0;
    }

}
