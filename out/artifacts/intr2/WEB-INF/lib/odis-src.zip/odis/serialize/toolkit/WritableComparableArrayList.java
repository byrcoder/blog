/**
 * 
 */
package odis.serialize.toolkit;

import odis.serialize.IWritableComparable;

/**
 * The writable array-list of comparatable writables. See javadoc of 
 * WritableArrayList for more information.
 * 
 * @author david
 *
 */
@SuppressWarnings("serial")
public abstract class WritableComparableArrayList<E extends IWritableComparable>
    extends WritableArrayList<E> {
}
