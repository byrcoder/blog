/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import odis.io.CDataInputStream;

/**
 * Comparing two "int-bytes" (ie length prefixed byte array: <code>length in 
 * a int (4 bytes) followed by the actual bytes).
 * 
 * @author zhangduo
 */
public class IntBytesBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored, read length from b1
     * @param l2
     *            ignored, read length from b2
     * 
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        int n1 = CDataInputStream.readInt(b1, s1);
        int n2 = CDataInputStream.readInt(b2, s2);
        return compareBytes(b1, s1 + 4, n1, b2, s2 + 4, n2);
    }

}
