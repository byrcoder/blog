package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.WritableRegistry;

/**
 * A compressed blob writable with its type (as an integer). NOTE: this object
 * is not thread-safe.
 * 
 * @author david
 */
public class TypedCompressedBlob extends CompressedBlob {
    static {
        WritableRegistry.registerAlias(TypedCompressedBlob.class,
                "TypedCBlob_v3");
    }

    private int type = 0;

    /**
     * Return this blob's type.
     * 
     * @return
     */
    public int getType() {
        decode();
        return type;
    }

    /**
     * Set this blob's type.
     * 
     * @param type
     */
    public void setType(int type) {
        this.type = type;
        changed();
    }

    @Override
    protected void copyByField(Object value) {
        this.type = ((TypedCompressedBlob) value).type;
        super.copyByField(value);
    }

    @Override
    protected void readBuffer(DataInput in) throws IOException {
        type = CDataInputStream.readVInt(in);
        super.readBuffer(in);
    }

    @Override
    protected void writeBuffer(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(type, out);
        super.writeBuffer(out);
    }

    /**
     * Print type and blob buffer size.
     */
    @Override
    public String toString() {
        this.decode();
        return "CBLOB(type: " + type + ", size: " + buffer.size() + ")";
    }
}
