package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.ShortBinaryComparator;

/**
 * The IWritable class storing a short value.
 * 
 * @author zhangduo
 */
public class ShortWritable implements IWritableComparable, ISkippable,
        IClearable, IParsable {
    static {
        WritableRegistry.register(ShortWritable.class, "short", Short.SIZE
                / Byte.SIZE, ShortBinaryComparator.class);
    }

    private short value;

    /**
     * Constructor with initial value 0.
     */
    public ShortWritable() {}

    /**
     * Constructor with an initial value.
     * 
     * @param value
     */
    public ShortWritable(short value) {
        this.value = value;
    }

    /**
     * Sets the value to zero.
     */
    public void clear() {
        value = 0;
    }

    /**
     * Set the value of this ShortWritable.
     */
    public void set(short value) {
        this.value = value;
    }

    /**
     * Return the value of this ShortWritable.
     */
    public short get() {
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeShort(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.value = ((ShortWritable) value).value;
        return this;
    }

    /**
     * Same rule with {@link Short#compareTo(Short)}
     */
    @Override
    public int compareTo(IWritable o) {
        int thisValue = this.value;
        int thatValue = ((ShortWritable) o).value;
        return thisValue - thatValue;
    }

    /**
     * Returns true iff <code>o</code> is a ShortWritable with the same value.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ShortWritable other = (ShortWritable) o;
        return this.value == other.value;
    }

    /**
     * same with {@link Short#hashCode()}
     */
    @Override
    public int hashCode() {
        return (int) value;
    }

    /**
     * just call {@link Short#toString(short)}.
     */
    @Override
    public String toString() {
        return Short.toString(value);
    }

    /**
     * use {@link Short#parseShort(String)} to parse.
     */
    @Override
    public void parse(String str) throws ParseException {
        set(Short.parseShort(str));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, Short.SIZE / Byte.SIZE);
    }

}
