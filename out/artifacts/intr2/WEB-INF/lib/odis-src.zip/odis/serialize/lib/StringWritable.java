package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.VIntBytesBinaryComparator;
import toolbox.misc.EmptyInstance;

/**
 * StringWritable stores string in utf-8 charset. It removes the 64k limit of
 * UTF8Writable.
 * 
 * @author river
 */
public class StringWritable implements IWritableComparable, IParsable,
        ISkippable, BytesAccessable, IClearable {

    static {
        WritableRegistry.register(StringWritable.class, "String",
                VIntBytesBinaryComparator.class);
        WritableRegistry.registerLegacyAlias(StringWritable.class,
                "odis.serialize.lib.LongUTF8Writable");
    }

    private int length = 0;

    private byte[] bytes = EmptyInstance.BYTES;

    String cachedString = EmptyInstance.STRING;

    /**
     * Default constructor.
     */
    public StringWritable() {}

    /**
     * Constructor with an initial value.
     * 
     * @param s
     */
    public StringWritable(String s) {
        set(s);
    }

    /**
     * Constructor using {@link #copyFields(IWritable)}
     * 
     * @param s
     */
    public StringWritable(StringWritable s) {
        copyFields(s);
    }

    /**
     * @deprecated
     */
    @Deprecated
    public StringWritable(UTF8Writable s) {
        set(s);
    }

    /**
     * Constructor with raw bytes.
     * 
     * @param data
     * @param offset
     * @param len
     */
    public StringWritable(byte[] data, int offset, int len) {
        set(data, offset, len);
    }

    /**
     * Set value.
     * 
     * @param string
     */
    public void set(String string) {
        if (string.length() == 0) {
            length = 0;
            cachedString = EmptyInstance.STRING;
            return;
        }
        cachedString = string;

        int targetLength = string.length() * 3;
        if (bytes.length < targetLength)
            bytes = Limit.createBuffer(targetLength);
        length = encode(string, bytes, 0);
    }

    /**
     * @deprecated
     */
    @Deprecated
    public void set(UTF8Writable other) {
        length = other.getByteLength();
        if (length > bytes.length) { // grow buffer
            bytes = Limit.createBuffer(length);
        }
        System.arraycopy(other.getBytes(), 0, bytes, 0, length);
        cachedString = other.cachedString;
    }

    /**
     * Set value using raw bytes.
     * 
     * @param data
     * @param offset
     * @param len
     */
    public void set(byte[] data, int offset, int len) {
        if (bytes.length < len) {
            bytes = new byte[len];
        }
        System.arraycopy(data, offset, bytes, 0, len);
        length = len;
        cachedString = null;
    }

    /**
     * Get value.
     * 
     * @return
     */
    public String get() {
        if (cachedString == null) {
            cachedString = decode(bytes, 0, length);
        }
        return cachedString;
    }

    /**
     * Return this StringWritable's value.
     */
    @Override
    public String toString() {
        return get();
    }

    /**
     * Return raw bytes of string. Implement {@link BytesAccessable#getBytes()}.
     */
    @Override
    public byte[] getBytes() {
        return bytes;
    }

    /**
     * Return raw bytes length of string. Implement
     * {@link BytesAccessable#getByteLength()}.
     */
    @Override
    public int getByteLength() {
        return length;
    }

    /**
     * This method is equal to call {@link #set(String)} with "".
     */
    @Override
    public void clear() {
        length = 0;
        this.cachedString = EmptyInstance.STRING;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        cachedString = null;
        length = CDataInputStream.readVInt(in);
        if (bytes.length < length) {
            Limit.checkObjectSize(length);
            bytes = Limit.createBuffer(length);
        }
        in.readFully(bytes, 0, length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(length, out);
        out.write(bytes, 0, length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        StringWritable that = (StringWritable) value;
        if (this != that) {
            this.length = that.length;
            if (bytes.length < length) {
                bytes = Limit.createBuffer(length);
            }
            System.arraycopy(that.bytes, 0, this.bytes, 0, length);
            cachedString = that.cachedString;
        }
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        skipString(in);
    }

    /**
     * compare raw bytes.
     * 
     * @see BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compareTo(IWritable o) {
        StringWritable that = (StringWritable) o;
        return BinaryComparator.compareBytes(bytes, 0, length, that.bytes, 0,
                that.length);
    }

    /**
     * return true if and only if <code>o</code> is an instance of
     * <code>StringWritable</code>, and raw bytes are equal.
     */
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        StringWritable that = (StringWritable) o;
        if (this.length != that.length) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (bytes[i] != that.bytes[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * generate hashCode using raw bytes.
     * 
     * @see Object#hashCode()
     */
    public int hashCode() {
        int hash = 1;
        for (int i = 0; i < length; i++) {
            hash = 31 * hash + bytes[i];
        }
        return hash;
    }

    /**
     * equal to {@link #set(String)}
     */
    public void parse(String str) throws ParseException {
        set(str);
    }

    /**
     * Convert <code>s</code> to a UTF8 Sequence.
     * 
     * @param s
     * @return
     */
    public static byte[] encode(String s) {
        int strlen = s.length();
        int utflen = 0;
        char c;
        for (int i = 0; i < strlen; i++) {
            c = s.charAt(i);
            if ((c >= 0x0000) && (c <= 0x007F)) {
                utflen++;
            } else if (c > 0x07FF) {
                utflen += 3;
            } else {
                utflen += 2;
            }
        }
        byte[] buf = new byte[utflen];
        encode(s, buf, 0);
        return buf;
    }

    /**
     * 将一个字符解析成为UTF8序列，需要注意的是，这里也没有检查bytes的空间.
     * 
     * @param c
     * @param bytes
     */
    public static int encode(char c, byte[] bytes) {
        if ((c >= 0x0000) && (c <= 0x007F)) {
            bytes[0] = (byte) c;
            return 1;
        } else if (c > 0x07FF) {
            bytes[0] = (byte) (0xE0 | ((c >> 12) & 0x0F));
            bytes[1] = (byte) (0x80 | ((c >> 6) & 0x3F));
            bytes[2] = (byte) (0x80 | ((c >> 0) & 0x3F));
            return 3;
        } else {
            bytes[0] = (byte) (0xC0 | ((c >> 6) & 0x1F));
            bytes[1] = (byte) (0x80 | ((c >> 0) & 0x3F));
            return 2;
        }
    }

    /**
     * 将字符串转化成为UTF-8的表示，保存在bytes从offset开始的空间内. 需要注意的是，这个方法没有做range
     * check，所以希望给出的bytes留下 足够的空间.
     * 
     * @param s
     *            String to be encoded
     * @param bytes
     *            Buffer to store encoded result
     * @param offset
     *            Start of the buffer to store the result
     * @return 实际编码后的字节数，
     */
    public static int encode(String s, byte[] bytes, int offset) {
        int strlen = s.length();

        int i = 0;
        char c;
        int pos = offset;
        for (i = 0; i < strlen; i++) {
            c = s.charAt(i);
            if (!((c >= 0x0000) && (c <= 0x007F))) {
                break;
            }
            bytes[pos++] = (byte) c;
        }

        for (; i < strlen; i++) {
            c = s.charAt(i);
            if ((c >= 0x0000) && (c <= 0x007F)) {
                bytes[pos++] = (byte) c;
            } else if (c > 0x07FF) {
                bytes[pos++] = (byte) (0xE0 | ((c >> 12) & 0x0F));
                bytes[pos++] = (byte) (0x80 | ((c >> 6) & 0x3F));
                bytes[pos++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            } else {
                bytes[pos++] = (byte) (0xC0 | ((c >> 6) & 0x1F));
                bytes[pos++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            }
        }
        return pos - offset;
    }

    /**
     * decode a UTF8 sequence to string.
     * 
     * @param bytes
     * @param offset
     * @param length
     * @return
     */
    public static String decode(byte[] bytes, int offset, int length) {
        StringBuilder buffer = new StringBuilder(length);
        int i = offset;
        int end = offset + length;

        while (i < end) {
            byte b = bytes[i++];
            if ((b & 0x80) == 0) {
                buffer.append((char) (b & 0x7F));
            } else if ((b & 0xE0) != 0xE0) {
                buffer.append((char) (((b & 0x1F) << 6) | (bytes[i++] & 0x3F)));
            } else {
                buffer.append((char) (((b & 0x0F) << 12)
                        | ((bytes[i++] & 0x3F) << 6) | (bytes[i++] & 0x3F)));
            }
        }
        return buffer.toString();
    }

    /**
     * Calculate the number of characters in a UTF8 string without converting it
     * to chars.
     */
    public static int charLength(byte[] bytes, int offset, int length) {
        int r = 0;
        int i = offset;
        int end = offset + length;
        while (i < end) {
            byte b = bytes[i++];
            r++;
            if ((b & 0x80) == 0) {
                // nothing, ASCII
            } else if ((b & 0xE0) != 0xE0) {
                i++;
            } else {
                i += 2;
            }
        }
        return r;
    }

    /**
     * Read a UTF-8 encoded string.
     * 
     * @param in
     * @return
     * @throws IOException
     */
    public static String readString(DataInput in) throws IOException {
        int bytes = CDataInputStream.readVInt(in);
        if (bytes == 0) {
            return EmptyInstance.STRING;
        }
        byte[] buf = Limit.createBuffer(bytes);
        in.readFully(buf);
        return decode(buf, 0, bytes);
    }

    /**
     * Skip a UTF8 encoded string.
     * 
     * @param in
     * @throws IOException
     * @return the number of bytes skipped.
     */
    public static int skipString(DataInput in) throws IOException {
        int b = in.readByte();
        int lenSize = 1;
        int len = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = in.readByte();
            len |= (b & 0x7F) << shift;
            lenSize++;

        }
        CDataInputStream.skipBytes(in, len);
        return lenSize + len;
    }

    /**
     * Write a UTF-8 encoded string.
     * 
     * @param out
     * @param s
     * @throws IOException
     * @return the number of bytes write out.
     */
    public static int writeString(DataOutput out, String s) throws IOException {
        if (s.length() == 0) {
            return CDataOutputStream.writeVInt(0, out);
        }
        int targetLength = s.length() * 3;
        byte[] bytes = Limit.createBuffer(targetLength);
        int length = encode(s, bytes, 0);
        int lengthSize = CDataOutputStream.writeVInt(length, out);
        out.write(bytes, 0, length);
        return lengthSize + length;
    }

    /**
     * Read a UTF-8 encoded string that could be null, stored as: (boolean,
     * StringWritable)
     */
    public static String readStringNull(DataInput in) throws IOException {
        if (in.readBoolean()) {
            return readString(in);
        } else {
            return null;
        }
    }

    /**
     * Write a UTF-8 encoded string that could be null, stored as: (boolean,
     * StringWritable)
     * 
     * @param out
     * @param s
     * @return the number of bytes write out.
     * @throws IOException
     */
    public static int writeStringNull(DataOutput out, String s)
            throws IOException {
        if (s == null) {
            out.writeBoolean(false);
            return 1;
        } else {
            out.writeBoolean(true);
            return 1 + writeString(out, s);
        }
    }

    /**
     * Skip a UTF8 encoded string that could be null, stored as: (boolean,
     * StringWritable)
     * 
     * @param in
     * @throws IOException
     * @return the number of bytes skipped.
     */
    public static int skipStringNull(DataInput in) throws IOException {
        if (in.readBoolean()) {
            return skipString(in) + 1;
        } else {
            return 1;
        }
    }
}
