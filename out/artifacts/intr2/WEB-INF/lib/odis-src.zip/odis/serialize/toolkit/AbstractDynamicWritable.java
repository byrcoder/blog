/**
 * @(#)AbstractDynamicWritable.java, 2007-8-5. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.lib.UTF8Writable;
import toolbox.misc.ClassUtils;

/**
 * AbstractDynamicWritable can wrap different types of writables in one object.
 * Subclass should implement the method {@link #getClassIdMap()} to return
 * class-id mapping. Sample code for wrapper class which can wrap IntWritable
 * and LongWritable: <code>
 *  public static class Wrapper extends AbstractDynamicWritable {
 *      
 *      private static final IClassIdMap CLASS_ID_MAP = new AbstractClassIdMap() {
 * 
 * @Override public Map<Class, Byte> getIdMap() { HashMap<Class, Byte> map = new
 *           HashMap<Class, Byte>(); map.put(LongWritable.class, (byte)1);
 *           map.put(IntWritable.class, (byte)2); return map; } };
 * @Override protected IClassIdMap getClassIdMap() { return CLASS_ID_MAP; } }
 *           </code>
 * @author river
 */
public abstract class AbstractDynamicWritable implements IWritable {
    private LinkedList<IWritable> cache = null;

    private IClassIdMap classIdMap;

    protected IWritable instance = null;

    protected Class<? extends IWritable> currentClass = null;

    protected byte currentClassId = IClassIdMap.NULL_ID;

    protected boolean allowClassname;

    protected int cacheSize = 0;

    /**
     * Create dynamic writable instance without cache.
     */
    public AbstractDynamicWritable() {
        this(0);
    }

    /**
     * Create dynamic writable instance with cache of reusable instances. We
     * could use cache to avoid creating a lot of objects when the actual
     * classes of objects are changed frequently.
     * 
     * @param cacheSize
     */
    public AbstractDynamicWritable(int cacheSize) {
        this.classIdMap = getClassIdMap();
        this.allowClassname = isAllowClassname();
        setCacheSize(cacheSize);
    }

    /**
     * Set the size of cache.
     * 
     * @param cacheSize
     */
    public void setCacheSize(int cacheSize) {
        this.cacheSize = cacheSize;
        if (cacheSize > 0) {
            cache = new LinkedList<IWritable>();
        }
    }

    /**
     * Return the writable object wrapped in this dynamic writable.
     * 
     * @return
     */
    public IWritable get() {
        return instance;
    }

    /**
     * Get an IWritable instance with given <code>clazz</code>. If we have an
     * instance in cache, than remove it from cache and return, otherwise,
     * create a new instance an return.
     * 
     * @param clazz
     * @return
     */
    private IWritable allocate(Class<? extends IWritable> clazz) {
        if (cache != null && cache.size() > 0) {
            Iterator<IWritable> it = cache.iterator();
            while (it.hasNext()) {
                IWritable v = it.next();
                if (v.getClass() == clazz) {
                    it.remove();
                    return v;
                }
            }
        }
        return (IWritable) ClassUtils.newInstance(clazz);
    }

    /**
     * Add an instance to cache.
     * 
     * @param instance
     */
    private void addToCache(IWritable instance) {
        if (cacheSize > 0) {
            if (cache.size() == cacheSize) {
                cache.removeLast();
            }
            cache.addFirst(instance);
        }
    }

    /**
     * Set the writable object to be wrapped in. <strong> Be aware that the
     * value passed in could be used to hold new value if
     * {@link #readFields(DataInput)} of this dynamic writable object is
     * invoked. </strong>
     * 
     * @param value
     */
    public void set(IWritable value) {
        if (this.instance != value && this.instance != null) {
            addToCache(this.instance);
            this.instance = null;
        }

        if (value.getClass() != currentClass) {
            byte id = classIdMap.getId(value.getClass());
            if (id == IClassIdMap.NULL_ID && !allowClassname) {
                throw new RuntimeException("no class id defined for class "
                        + value.getClass() + " and classname is not allowed.");
            }
            currentClass = value.getClass();
            currentClassId = id;
        }
        instance = value;
    }

    /**
     * Return the class-id mapping.
     * 
     * @return
     */
    protected abstract IClassIdMap getClassIdMap();

    /**
     * Subclass could override this method to determine if we allow instance
     * without id found in class-id mapping.
     * 
     * @return
     */
    protected boolean isAllowClassname() {
        return false;
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        byte classId = in.readByte();
        if (classId == IClassIdMap.NULL_ID) {
            // class without id, read class-name first
            String className = UTF8Writable.readString(in);
            Class<? extends IWritable> clazz = WritableRegistry.getWritableClass(className);
            if (clazz != currentClass) {
                currentClass = clazz;
                IWritable newValue = allocate(currentClass);
                if (instance != null) {
                    addToCache(instance);
                }
                instance = newValue;
            }
            currentClassId = classIdMap.getId(currentClass);
        } else {
            // class with classId, create new object if differnt from
            // current one.
            if (classId != currentClassId || currentClass == null) {
                currentClass = classIdMap.getClass(classId);
                currentClassId = classId;
                if (currentClass == null)
                    throw new RuntimeException("Unknown classId(" + classId
                            + "). ");
                IWritable newValue = allocate(currentClass);
                if (instance != null) {
                    addToCache(instance);
                }
                instance = newValue;
            }
        }
        instance.readFields(in);
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(currentClassId);
        if (currentClassId == IClassIdMap.NULL_ID) {
            UTF8Writable.writeString(out,
                    WritableRegistry.getWritableName(currentClass));
        }
        instance.writeFields(out);
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || (value.getClass() != this.getClass())) {
            throw new RuntimeException("bad value : " + value);
        }
        if (value == this)
            return this;
        AbstractDynamicWritable that = (AbstractDynamicWritable) value;
        if (currentClass != null && currentClass.equals(that.currentClass))
            this.instance.copyFields(that.instance);
        else {
            IWritable temp = allocate(that.currentClass);
            temp.copyFields(that.instance);
            this.currentClass = that.currentClass;
            this.currentClassId = that.currentClassId;
            if (this.instance != null)
                addToCache(instance);
            this.instance = temp;
        }
        return this;
    }

    /**
     * Print contained instance. If null, return "<null>".
     */
    @Override
    public String toString() {
        if (instance == null)
            return "<null>";
        else
            return instance.toString();
    }

    /**
     * Mapping interface to get id for class or class for id. Most of the time
     * we should inherit {@link AbstractClassIdMap} instead of implementing this
     * interface directly.
     * 
     * @author river
     */
    public static interface IClassIdMap {
        /**
         * Null id should not be used.
         */
        public static final byte NULL_ID = 0;

        /**
         * Return id for given class.
         * 
         * @param clazz
         * @return
         */
        public byte getId(Class clazz);

        /**
         * Return class for given id.
         * 
         * @param id
         * @return
         */
        public Class getClass(byte id);
    }

    /**
     * Abstract implementation for class-byteid map. Subclass should implement
     * {@link #getIdMap()} to return map[class->id].
     * 
     * @author river
     */
    public static abstract class AbstractClassIdMap implements IClassIdMap {
        private HashMap<Class, Byte> idMap;

        private Class[] classes;

        /**
         * Default constructor.
         */
        public AbstractClassIdMap() {
            Map<Class, Byte> map = getIdMap();
            idMap = new HashMap<Class, Byte>();
            classes = new Class[256];
            for (Map.Entry<Class, Byte> entry: map.entrySet()) {
                idMap.put(entry.getKey(), entry.getValue());
                int idx = entry.getValue().byteValue();
                if (idx == 0) {
                    throw new RuntimeException("bad id " + idx + " for class "
                            + entry.getKey());
                }
                if (classes[idx] != null) {
                    throw new RuntimeException("duplicate id " + idx
                            + " for class " + classes[idx] + " and "
                            + entry.getKey());
                }
                classes[idx] = entry.getKey();
            }
        }

        /**
         * Get Class->ID map.
         * 
         * @return
         */
        public abstract Map<Class, Byte> getIdMap();

        /**
         * @see IClassIdMap#getClass(byte)
         */
        @Override
        public Class getClass(byte id) {
            return classes[id & 0xff];
        }

        /**
         * @see IClassIdMap#getId(Class)
         */
        @Override
        public byte getId(Class clazz) {
            Byte obj = idMap.get(clazz);
            return obj == null ? NULL_ID : obj.byteValue();
        }
    }

    /**
     * Simple implementation for class id map.
     * 
     * @author river
     */
    public static class SimpleIdMap implements IClassIdMap {
        private HashMap<Class, Byte> idMap = new HashMap<Class, Byte>();

        private Class[] classes = new Class[255];

        /**
         * Create id map by params. The params shoule be class list or classes
         * with one byte after each class. Sample one: <code>
         *     SimpleIdMap map = new SimpleIdMap(IntWritable.class, LongWritable.class);
         * </code> The id should be 1 for IntWritable in this sample, and 2 for
         * LongWritable. Sample two: <code>
         *     SimpleIdMap map = new SimpleIdMap(IntWritable.class, 2, LongWritable.class, 3);
         * </code> The id should be 2 for IntWritable in this sample, and 2 for
         * LongWritable.
         * 
         * @param params
         */
        public SimpleIdMap(Object... params) {
            byte lastId = 1;
            int idx = 0;
            while (idx < params.length) {
                if (!(params[idx] instanceof Class)) {
                    throw new RuntimeException("bad param type at " + idx
                            + " : " + params[idx]);
                }
                Class clazz = (Class) params[idx];
                idx++;
                if (idx < params.length) {
                    if (params[idx] instanceof Integer) {
                        lastId = (byte) (((Integer) params[idx]).intValue());
                        idx++;
                    } else if (params[idx] instanceof Byte) {
                        lastId = ((Byte) params[idx]).byteValue();
                        idx++;
                    }
                }
                if (lastId == NULL_ID) {
                    throw new RuntimeException("illegal id : " + lastId);
                }
                idMap.put(clazz, lastId);
                classes[lastId] = clazz;
                lastId++;
            }
        }

        /**
         * @see IClassIdMap#getClass(byte)
         */
        @Override
        public Class getClass(byte id) {
            return classes[id];
        }

        /**
         * @see IClassIdMap#getId(Class)
         */
        @Override
        public byte getId(Class clazz) {
            Byte obj = idMap.get(clazz);
            return obj == null ? NULL_ID : obj.byteValue();
        }

    }

}
