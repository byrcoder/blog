/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

/**
 * Comparing two bytes: b1[s1] and b2[s2].
 * 
 * @author zhangduo
 */
public class ByteBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as length is always 1
     * @param l2
     *            ignored as length is always 1
     * 
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        int thisValue = b1[s1];
        int thatValue = b2[s2];
        return thisValue - thatValue;
    }

}
