package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * A writable class for storing data blob. This class is especially useful for
 * transfer data from map to reduce with different value types. A raw data blob
 * is stored when calling <code>setData/addData</code>, and retrieved to a
 * writable object when calling <code>getData/extractData</code>.
 * 
 * @author david
 */
public class BlobWritable implements IWritable, ISkippable, IClearable {
    static {
        WritableRegistry.registerAlias(BlobWritable.class, "Blob_v3");
    }

    protected DataOutputBuffer buffer = new DataOutputBuffer();

    private DataInputBuffer reader;

    /**
     * clear stored blob data.
     */
    @Override
    public void clear() {
        buffer.reset();
        reader = null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(buffer.size(), out);
        if (buffer.size() > 0) {
            out.write(buffer.getData(), 0, buffer.size());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        buffer.reset(); // reset before setting size for avoiding data copy.
        buffer.setSize(CDataInputStream.readVInt(in));
        if (buffer.size() > 0) {
            in.readFully(buffer.getData(), 0, buffer.size());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        BlobWritable that = (BlobWritable) value;

        this.buffer.reset();
        this.buffer.write(that.buffer.getData(), 0, that.buffer.size());

        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int len = CDataInputStream.readVInt(in);
        CDataInputStream.skipBytes(in, len);
    }

    /**
     * Set the blob data into a writable object's data. data.writeFields will be
     * called.
     * 
     * @param data
     *            The writable object containing data.
     * @return this.
     */
    public BlobWritable setData(IWritable... data) {
        try {
            buffer.reset();
            for (int i = 0; i < data.length; i++) {
                data[i].writeFields(buffer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * Append data into the end of the buffer.
     * 
     * @param data
     * @return this.
     */
    public BlobWritable addData(IWritable... data) {
        try {
            for (int i = 0; i < data.length; i++) {
                data[i].writeFields(buffer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * Fetch data from this BlobWritable. buf.readFields will be called
     * 
     * @param buf
     *            The buffer writable object to get from BlobWritable
     */
    public BlobWritable getData(IWritable... buf) {
        if (reader == null) {
            reader = new DataInputBuffer();
        }
        reader.reset(buffer.getData(), 0, buffer.size());
        try {
            for (int i = 0; i < buf.length; i++) {
                buf[i].readFields(reader);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * Extracting data from last get/extraction point.
     * 
     * @param buf
     * @return this.
     */
    public BlobWritable extractData(IWritable... buf) {
        try {
            for (int i = 0; i < buf.length; i++) {
                buf[i].readFields(reader);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int hash = buffer.size();
        byte[] data = buffer.getData();
        for (int i = 0; i < buffer.size(); i++) {
            hash = hash * 31 + (int) data[i];
        } // for i
        return hash;
    }

    /**
     * return true if and only if the blob data are equal(size are same, and
     * every byte are same).
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BlobWritable other = (BlobWritable) obj;
        byte[] data_this = buffer.getData();
        byte[] data_that = other.buffer.getData();

        if (buffer.size() != other.buffer.size()) {
            return false;
        }

        for (int i = 0; i < buffer.size(); i++) {
            if (data_this[i] != data_that[i]) {
                return false;
            }
        }

        return true;
    }

    /**
     * only print the size.
     */
    @Override
    public String toString() {
        return "BLOB(" + buffer.size() + ")";
    }
}
