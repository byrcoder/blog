/**
 * @(#)BenchmarkCompareBytes.java, 2012-1-31. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.comparator.bench;

import java.util.Arrays;
import java.util.Random;

import odis.serialize.comparator.BinaryComparator;

/**
 * Benchmark for BinaryComparator
 * @author zhangduo
 */
public class BenchmarkCompareBytes {

    private volatile static byte[] b1;

    private volatile static byte[] b2;

    private static void testPure() {
        long start = System.currentTimeMillis();
        int x = 0;
        for (int i = 0; i < 10000000; i++) {
            x += BinaryComparator.pureCompareBytes(b1, 0, b1.length, b2, 0,
                    b2.length);
        }
        long time = System.currentTimeMillis() - start;
        System.out.println(x + " pure time = " + time + "ms");
    }

    private static void testUnsafe() {
        long start = System.currentTimeMillis();
        int x = 0;
        for (int i = 0; i < 10000000; i++) {
            x += BinaryComparator.unsafeCompareBytes(b1, 0, b1.length, b2, 0,
                    b2.length);
        }
        long time = System.currentTimeMillis() - start;
        System.out.println(x + " unsafe time = " + time + "ms");
    }

    private static void testNative() {
        long start = System.currentTimeMillis();
        int x = 0;
        for (int i = 0; i < 10000000; i++) {
            x += BinaryComparator.nativeCompareBytes(b1, 0, b1.length, b2, 0,
                    b2.length);
        }
        long time = System.currentTimeMillis() - start;
        System.out.println(x + " native time = " + time + "ms");
    }

    public static void main(String[] args) {
        args = new String[] {
            "100"
        };
        Random rand = new Random();
        int length = Integer.parseInt(args[0]);
        b1 = new byte[length];
        rand.nextBytes(b1);
        b2 = Arrays.copyOf(b1, length);
        b2[b2.length / 2] = (byte) (~b2[b2.length / 2]);
        for (int i = 0; i < 10000; i++) {
            testPure();
            testUnsafe();
            testNative();
        }
    }
}
