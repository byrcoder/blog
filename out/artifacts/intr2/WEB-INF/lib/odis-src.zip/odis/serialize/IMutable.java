package odis.serialize;

/**
 * The interface representing an object whose content can be modified, i.e. this
 * object is a mutable object.
 * 
 * @author david
 */
public interface IMutable<E> {
    /**
     * Deep copy the fields of this object from <code>value</code>
     * 
     * @param value
     *            field values to set this object
     * @return The returned value should be ``this''
     */
    public E copyFields(E value);
}
