package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import odis.serialize.IWritable;

/**
 * An data structure expressing an array-list of writables. which provide some
 * interface of the arraylist not all it will not release the memory when call
 * the clean function, it will reuse the allocated elements Notice : the
 * copyFields function of E must be implemented
 * 
 * @author yemingjiang
 * @param <E>
 *            The type of the element.
 * @deprecated use AbstractWritableList instead
 */
@Deprecated
public abstract class CachedWritableArrayList<E extends IWritable> implements
        IWritable {

    protected abstract E newElementInstance();

    protected final ArrayList<E> list = new ArrayList<E>();

    protected int size = 0;

    public CachedWritableArrayList() {
        super();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append('[');
        for (int i = 0; i < size; i++) {
            builder.append(list.get(i));
            if (i < size - 1)
                builder.append(',');
        }
        builder.append("](#=" + size + ")");
        return builder.toString();
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        CachedWritableArrayList<E> that = (CachedWritableArrayList<E>) other;
        if (size != that.size)
            return false;
        for (int i = 0; i < size; i++) {
            if (!list.get(i).equals(that.list.get(i)))
                return false;
        }
        return true;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(size);
        for (int i = 0; i < size; i++) {
            list.get(i).writeFields(out);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        size = in.readInt();
        // read fields
        for (int i = 0; i < size; i++) {
            E element;
            if (i < list.size())
                element = list.get(i);
            else {
                element = newElementInstance();
                list.add(element);
            }
            element.readFields(in);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        CachedWritableArrayList<E> that = (CachedWritableArrayList<E>) value;

        size = that.size;

        // copy elements
        for (int i = 0; i < that.size(); i++) {
            if (i < list.size())
                list.get(i).copyFields(that.list.get(i));
            else {
                E element = newElementInstance();
                element.copyFields(that.list.get(i));
                list.add(element);
            }
        }
        return this;
    }

    public void clear() {
        size = 0;
    }

    public int size() {
        return size;
    }

    public E get(int i) {
        if (i >= size)
            return null;
        return list.get(i);
    }

    /*
     * be careful I will reuse the elment, don't change it again
     */
    public void add(E element) {
        if (size < list.size())
            list.set(size, element);
        else {
            list.add(element);
        }
        size++;
    }

    /*
     * I will use the copyFields to clonet the element so you must implement the
     * copyFields of E
     */
    public void addClone(E element) {
        E newElement;
        if (size < list.size())
            newElement = list.get(size);
        else {
            newElement = newElementInstance();
            list.add(newElement);
        }
        newElement.copyFields(element);
        size++;
    }

    @Override
    public int hashCode() {
        int hash = this.size();
        for (int i = 0; i < this.size(); i++)
            hash = hash * 31 + this.get(i).hashCode();
        return hash;
    }

    public Iterator<E> iterator() {
        final Iterator<E> iter = list.iterator();
        return new Iterator<E>() {
            int pos = 0;

            @Override
            public boolean hasNext() {
                return pos < size && iter.hasNext();
            }

            @Override
            public E next() {
                if (pos < size) {
                    pos++;
                    return iter.next();
                } else
                    throw new NoSuchElementException();
            }

            @Override
            public void remove() {
                iter.remove();
                size--;
            }
        };
    }

    public static <E extends IWritable> CachedWritableArrayList<E> get(
            final Class<E> cls) {
        return new CachedWritableArrayList<E>() {
            @Override
            protected E newElementInstance() {
                try {
                    return cls.newInstance();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
