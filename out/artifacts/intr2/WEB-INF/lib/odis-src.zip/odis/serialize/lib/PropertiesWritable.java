package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BytesBinaryComparator;

/**
 * A Properties object with IWritable interface
 * 
 * @author david
 */
@Deprecated
public class PropertiesWritable extends Properties implements IWritable,
        ISkippable {
    static {
        WritableRegistry.register(PropertiesWritable.class, "properties",
                BytesBinaryComparator.class);
    }

    private static final long serialVersionUID = 8949276597256063209L;

    @Override
    public void readFields(DataInput in) throws IOException {
        this.clear();
        int len = CDataInputStream.readVInt(in);
        for (int i = 0; i < len; i++) {
            String key = UTF8Writable.readStringNull(in);
            String val = UTF8Writable.readStringNull(in);
            this.put(key, val);
        } // for i
    }

    @Override
    public void skipFields(DataInput in) throws IOException {
        int len = CDataInputStream.readVInt(in);
        for (int i = 0; i < len; i++) {
            UTF8Writable.skipStringNull(in);
            UTF8Writable.skipStringNull(in);
        } // for i
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(this.size(), out);
        for (Map.Entry<Object, Object> entry: entrySet()) {
            UTF8Writable.writeStringNull(out, entry.getKey().toString());
            UTF8Writable.writeStringNull(out, entry.getValue().toString());
        } // for entry
    }

    @Override
    public IWritable copyFields(IWritable value) {
        this.clear();
        this.putAll(((Properties) value));
        return this;
    }
}
