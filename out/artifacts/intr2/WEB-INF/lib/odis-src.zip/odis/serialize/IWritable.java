package odis.serialize;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/** 
 * A simple, efficient, serialization protocol, based on {@link DataInput} and
 * {@link DataOutput}.
 * 
 * Implementations typically implement a static <code>read(DataInput)</code>
 * method which constructs a new instance, calls {@link #readFields(DataInput)}, 
 * and returns the instance.
 *
 * This interface is ported from Nutch.
 * 
 * @author Doug Cutting (previous nutch code)
 * @author Li Zhuang (modified outfox code)
 */
public interface IWritable extends IMutable<IWritable> {
  
  /** 
   * Writes the fields of this object to <code>out</code>.
   */
  public void writeFields(DataOutput out) throws IOException;

  /** 
   * Reads the fields of this object from <code>in</code>.  For efficiency,
   * implementations should attempt to re-use storage in the existing object
   * where possible.
   */
  public void readFields(DataInput in) throws IOException;
}
