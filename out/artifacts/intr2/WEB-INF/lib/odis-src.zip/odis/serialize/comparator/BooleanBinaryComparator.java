/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

/**
 * Comparing two booleans: b1[s1] and b2[s2].
 * 
 * @author zhangduo
 */
public class BooleanBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as length is always 1
     * @param l2
     *            ignored as length is always 1
     * 
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        boolean a = (b1[0] == 1) ? true : false;
        boolean b = (b2[0] == 1) ? true : false;
        return ((a == b) ? 0 : (a == false) ? -1 : 1);
    }
}
