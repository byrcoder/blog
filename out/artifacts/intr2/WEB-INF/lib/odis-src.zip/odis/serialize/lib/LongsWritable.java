/**
 * @(#)LongsWritable.java, 2008-2-14. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import toolbox.misc.EmptyInstance;

/**
 * Writable for long array.
 * 
 * @author river, David
 */
public class LongsWritable implements IWritable, ISkippable, IClearable {
    static {
        WritableRegistry.registerAlias(LongsWritable.class, "Longs");
    }

    private long[] arr = EmptyInstance.LONGS;

    private int size;

    /**
     * Constructor.
     */
    public LongsWritable() {
        arr = EmptyInstance.LONGS;
        size = 0;
    }

    /**
     * Constructor.
     * 
     * @param initialCapacity
     *            the intial number of elements in the buffer. size is set to 0.
     */
    public LongsWritable(int initialCapacity) {
        arr = new long[initialCapacity];
        size = 0;
    }

    /**
     * Set buffer to empty, set size to 0.
     */
    public void clear() {
        arr = EmptyInstance.LONGS;
        size = 0;
    }

    /**
     * @deprecated the name of Data confuses a lot of person. Use
     *             {@link #getBuffer()} instead. Returns the raw data, you must
     *             use {@link #size()} to acquire the actual number of elements.
     * @return
     */
    @Deprecated
    public long[] getData() {
        return arr;
    }

    /**
     * Returns the internal int array buffer. Call #{@link #size()} to get the
     * the number of available elements in the buffer.
     * 
     * @return the internal int array buffer
     */
    public long[] getBuffer() {
        return arr;
    }

    /**
     * Return size of data.
     * 
     * @return
     */
    public int size() {
        return size;
    }

    /**
     * Access the data by index.
     * 
     * @param index
     * @return
     */
    public long get(int index) {
        if (index >= size) {
            throw new ArrayIndexOutOfBoundsException(
                    "Array index out of range: " + index + ", length: " + size);
        }
        return arr[index];
    }

    /**
     * Return data as long array.
     * 
     * @return
     */
    public long[] toLongArray() {
        return Arrays.copyOf(arr, size);
    }

    /**
     * Append one long data to the tail with step 1.
     * 
     * @param v
     */
    public void addLong(long v) {
        addLong(v, 1);
    }

    /**
     * Append one long data to the tail.
     * 
     * @param v
     * @param stepWhenExceed
     *            enlarge step when size exceed capacity
     */
    public void addLong(long v, int stepWhenExceed) {
        if (size == arr.length) {
            arr = Arrays.copyOf(arr, size + stepWhenExceed);
        }
        arr[size++] = v;
    }

    /**
     * Append several long digits to the tail.
     * 
     * @param v
     */
    public void addLong(long[] v) {
        if (size + v.length > arr.length) {
            long[] newdata = new long[size + v.length];
            System.arraycopy(arr, 0, newdata, 0, size);
            arr = newdata;
        }
        System.arraycopy(v, 0, arr, size, v.length);
        size += v.length;
    }

    /**
     * Remove the first n elements in array.
     */
    public void shift(int n) {
        if (size >= n) {
            System.arraycopy(arr, n, arr, 0, size - n);
            size -= n;
        }
    }

    /**
     * Remove the first element.
     */
    public void shift() {
        shift(1);
    }

    /**
     * Set the data.
     * 
     * @param v
     */
    public void set(long[] v) {
        size = 0;
        addLong(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = CDataInputStream.readVInt(in);
        if (size > arr.length) {
            arr = new long[size];
        }

        for (int i = 0; i < size; i++) {
            arr[i] = in.readLong();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size, out);
        for (int i = 0; i < size; i++) {
            out.writeLong(arr[i]);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == this) {
            return this;
        }
        LongsWritable that = (LongsWritable) value;
        if (this.arr.length < that.size) {
            this.arr = new long[that.size];
        }
        System.arraycopy(that.arr, 0, this.arr, 0, that.size);
        this.size = that.size;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int size = CDataInputStream.readVInt(in);
        CDataInputStream.skipBytes(in, size * (Long.SIZE / Byte.SIZE));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int hash = 0;
        for (int i = 0; i < size; i++) {
            hash = hash * 31 + (int) (arr[i] ^ (arr[i] >>> 32));
        }
        return hash;
    }

    /**
     * return <code>true</code> if and only if size are same and every long are
     * same.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LongsWritable that = (LongsWritable) o;
        if (this.size != that.size) {
            return false;
        }

        for (int i = 0; i < this.size; i++) {
            if (this.arr[i] != that.arr[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * like {@link Arrays#toString(long[])}.
     * 
     * @see Arrays#toString(long[])
     */
    @Override
    public String toString() {
        if (size == 0) {
            return "[]";
        }
        StringBuilder b = new StringBuilder();
        b.append('[');
        for (int i = 0;; i++) {
            b.append(arr[i]);
            if (i == size - 1) {
                return b.append(']').toString();
            }
            b.append(", ");
        }
    }

}
