package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.toolkit.DynamicWritable;

/**
 * Object with operator to store "modification" information.
 * This class is used to store incremental data.
 * 
 * @author river
 * @deprecated Use {@link AbstractOpObject} instead.
 */
@Deprecated
public class OpObject extends DynamicWritable {
    static {
        WritableRegistry.registerAlias(OpObject.class, "OpObject_v3");
    }
    public static final byte OP_UNKNOWN = 0;
    public static final byte OP_MODIFIED = 1;
    public static final byte OP_DELETED = 2;
    
    public static final String[] OP_NAMES = new String[] {
        "OP_UNKONWN", "OP_MODIFIED", "OP_DELETED",
    };
    
    private byte op;

    public byte getOperator() {
        return op;
    }

    public void setOperator(byte op){
        this.op = op;
    }
    
    @Override
    public String toString() {
        return "[" + OP_NAMES[op] + "]" + (op == OP_MODIFIED ? super.toString() : "");
    }
    
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || !(value instanceof OpObject))
            throw new RuntimeException("bad value : " + value);
        OpObject that = (OpObject) value;
        this.op = that.op;
        if (this.op == OP_MODIFIED) {
            super.copyFields(value);
        }
        return this;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        op = in.readByte();
        if (op == OP_MODIFIED) {
            super.readFields(in);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(op);
        if (op == OP_MODIFIED) {
            super.writeFields(out);
        }
    }

}
