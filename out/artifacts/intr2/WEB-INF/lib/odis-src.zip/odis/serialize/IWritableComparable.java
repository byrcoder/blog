package odis.serialize;

/**
 * An interface which extends both {@link IWritable} and {@link Comparable}.
 * Classes implement this interface must override the equals() method too.  The
 * equals() method must be consistant as compareTo().
 *  
 * @author Li Zhuang
 */
public interface IWritableComparable extends IWritable, Comparable<IWritable> {
  
}
