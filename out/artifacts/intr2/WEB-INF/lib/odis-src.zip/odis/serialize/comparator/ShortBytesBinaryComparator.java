/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import odis.io.CDataInputStream;

/**
 * Comparing two "int-bytes" (ie length prefixed byte array: <code>length in 
 * a short (2 bytes) followed by the actual bytes).
 * 
 * @author zhangduo
 */
public class ShortBytesBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored, read length from b1
     * @param l2
     *            ignored, read length from b2
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        int n1 = CDataInputStream.readUnsignedShort(b1, s1);
        int n2 = CDataInputStream.readUnsignedShort(b2, s2);
        return compareBytes(b1, s1 + 2, n1, b2, s2 + 2, n2);
    }

}
