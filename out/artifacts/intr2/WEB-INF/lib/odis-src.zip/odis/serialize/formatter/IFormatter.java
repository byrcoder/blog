package odis.serialize.formatter;

import odis.serialize.IWritable;

/**
 * Convert writable into string. It is different from toString() since the same
 * IWritable can be registered to different FormatterManager.
 * 
 * @author river
 */
public interface IFormatter {
    /**
     * Formats an IWritable to a string.
     * 
     * @param w
     *            the IWritable instance to be formatted
     * @return the string.
     */
    public String format(IWritable w);
}
