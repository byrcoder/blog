package odis.serialize.lib;

import odis.serialize.WritableRegistry;
import odis.serialize.comparator.LongBinaryComparator;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Writable to store time as long, and can print time string in
 * {@link #toString()}.<br>
 * 
 * @author river
 */
public class TimeWritable extends LongWritable {

    /**
     * joda-time DateTimeFormatter is thread safe, so we can share one formatter
     * for all TimeWritable object.
     */
    private static final DateTimeFormatter TIME_FORMATER = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

    static {
        WritableRegistry.register(TimeWritable.class, "time", Long.SIZE
                / Byte.SIZE, LongBinaryComparator.class);
    }

    /**
     * Constructor with initial value 0.
     */
    public TimeWritable() {}

    /**
     * Constructor with an initial value.
     * 
     * @param value
     */
    public TimeWritable(long value) {
        set(value);
    }

    /**
     * Convert time to "yyyy-MM-dd HH:mm:ss" format string.
     */
    @Override
    public String toString() {
        return TIME_FORMATER.print(value);
    }
}
