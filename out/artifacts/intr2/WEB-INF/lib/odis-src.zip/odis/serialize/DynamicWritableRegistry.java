package odis.serialize;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import odis.serialize.comparator.BinaryComparator;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

/**
 * Dynamic Writable Registry use class loader.<br>
 * You should not use this class directly, use {@link WritableRegistry} with
 * <code>allowDynamicReload</code> set true(call
 * {@link WritableRegistry#enableDynamicReload()}).
 * 
 * @see WritableRegistry
 * @author tuqc
 */
public class DynamicWritableRegistry {
    /**
     * This means the Writable's size is dynamic(i.e., VInt, VLong and
     * ByteArray)
     */
    public static final int NON_FIXED_SIZE = -1;

    private static final Logger LOG = LogFormatter.getLogger(DynamicWritableRegistry.class);

    private static final HashMap<ClassLoader, DynamicWritableRegistry> REGISTRY_MAP = new HashMap<ClassLoader, DynamicWritableRegistry>();

    /**
     * get DynamicWritableRegistry associate with the given ClassLoader.
     * 
     * @param cl
     * @return
     */
    public synchronized static DynamicWritableRegistry get(ClassLoader cl) {
        if (!REGISTRY_MAP.containsKey(cl)) {
            DynamicWritableRegistry entry = new DynamicWritableRegistry(cl);
            REGISTRY_MAP.put(cl, entry);
        }
        return REGISTRY_MAP.get(cl);
    }

    /**
     * determine whether we have a DynamicWritableRegistry associate with the
     * given ClassLoader.
     * 
     * @param cl
     * @return
     */
    public synchronized static boolean exist(ClassLoader cl) {
        return REGISTRY_MAP.containsKey(cl);
    }

    private Map<Class<? extends IWritable>, String> CLASS_TO_ALIAS = new HashMap<Class<? extends IWritable>, String>();

    private Map<String, Class<? extends IWritable>> ALIAS_TO_CLASS = new HashMap<String, Class<? extends IWritable>>();

    private Map<String, Class<? extends IWritable>> LEGACY_ALIAS_TO_CLASS = new HashMap<String, Class<? extends IWritable>>();

    private Map<Class<? extends IWritable>, Integer> CLASS_TO_SIZE = new HashMap<Class<? extends IWritable>, Integer>();

    private Map<Class<? extends IWritable>, Class<? extends BinaryComparator>> CLASS_TO_COMPARATOR = new HashMap<Class<? extends IWritable>, Class<? extends BinaryComparator>>();

    private Set<Class<? extends IWritable>> INITIALIZED_CLASS = new HashSet<Class<? extends IWritable>>();

    public final String PROP_NAME = "writable_registry.list";

    private ClassLoader currentClassLoader;

    /**
     * construct a DynamicWritableRegistry, set its currentClassLoader to given
     * ClassLoader.
     * 
     * @param cl
     */
    protected DynamicWritableRegistry(ClassLoader cl) {
        currentClassLoader = cl;
    }

    /**
     * load with currentClassLoader.
     */
    public synchronized void dynamicLoad() {
        if (currentClassLoader != null) {
            dynamicLoad(currentClassLoader);
        } else
            throw new RuntimeException("Current ClassLoader is null!");
    }

    /**
     * load with given ClassLoader.
     * 
     * @param cl
     */
    public synchronized void dynamicLoad(ClassLoader cl) {
        LOG.info("Dynamic Load WritableRegisty. ClassLoader:" + cl.toString());
        currentClassLoader = cl;
        List<URL> resources = new ArrayList<URL>();
        try {
            Enumeration<URL> enume = cl.getResources(PROP_NAME);
            for (; enume.hasMoreElements();) {
                resources.add(enume.nextElement());
            }
            enume = cl.getResources("META-INF/" + PROP_NAME);
            for (; enume.hasMoreElements();) {
                resources.add(enume.nextElement());
            }
        } catch (IOException e) {
            LOG.severe("cannot find " + PROP_NAME + " in classpath");
            throw new RuntimeException("cannot find " + PROP_NAME
                    + " in classpath ");
        }
        // find all package names
        HashSet<String> pack = new HashSet<String>();
        for (URL url: resources) {
            BufferedReader reader = null;
            try {
                try {
                    reader = new BufferedReader(new InputStreamReader(
                            url.openStream()));
                    String s = reader.readLine();
                    while (s != null) {
                        if (!s.trim().equals(""))
                            pack.add(s);
                        s = reader.readLine();
                    }
                } finally {
                    if (reader != null)
                        reader.close();
                }
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "load writable id configuration from "
                        + url + " failed.", e);
                throw new RuntimeException(e);
            }
        }
        // load writables	      
        loadWritables(pack.toArray(new String[pack.size()]));
    }

    /**
     * unload all Writable classes.
     */
    public synchronized void unload() {
        CLASS_TO_ALIAS.clear();
        ALIAS_TO_CLASS.clear();
        LEGACY_ALIAS_TO_CLASS.clear();
        CLASS_TO_SIZE.clear();
        CLASS_TO_SIZE.clear();
        INITIALIZED_CLASS.clear();
    }

    /**
     * print all loaded Writable classes.
     */
    public synchronized void printLoaded() {
        System.out.println("Loaded " + INITIALIZED_CLASS.size()
                + " writables in registry");
        Iterator<Class<? extends IWritable>> it = INITIALIZED_CLASS.iterator();
        while (it.hasNext()) {
            System.out.println(it.next().toString());
        }
    }

    /**
     * Register Class <-> alias.
     * 
     * @param cls
     * @param alias
     */
    public void registerAlias(Class<? extends IWritable> cls, String alias) {
        register(cls, alias, NON_FIXED_SIZE, null);
    }

    /**
     * Register Class -> size.
     * 
     * @param cls
     * @param size
     */
    public void registerSize(Class<? extends IWritable> cls, int size) {
        register(cls, null, size, null);
    }

    /**
     * Register Class -> comparator.
     * 
     * @param cls
     * @param comparator
     */
    public void registerComparator(Class<? extends IWritable> cls,
            Class<? extends BinaryComparator> comparator) {
        register(cls, null, NON_FIXED_SIZE, comparator);
    }

    /**
     * Register alias and comparator.
     * 
     * @param cls
     * @param alias
     * @param comparator
     */
    public void register(Class<? extends IWritable> cls, String alias,
            Class<? extends BinaryComparator> comparator) {
        register(cls, alias, NON_FIXED_SIZE, comparator);
    }

    /**
     * Register size and comparator.
     * 
     * @param cls
     * @param size
     * @param comparator
     */
    public void register(Class<? extends IWritable> cls, int size,
            Class<? extends BinaryComparator> comparator) {
        register(cls, null, size, comparator);
    }

    /**
     * Register alias and size.
     * 
     * @param cls
     * @param alias
     * @param size
     */
    public void register(Class<? extends IWritable> cls, String alias, int size) {
        register(cls, alias, size, null);
    }

    /**
     * Register the alias/size/comparator for a class.<br>
     * if lib already has this alias, it will overwrite it.
     * 
     * @param cls
     *            the class to be registered
     * @param alias
     *            the alais of this class
     * @param size
     *            the size of the IWritable in bytes. -1 means non-fixed size
     * @param comparator
     *            the binary-comparator for this class. Could be null
     */
    public synchronized void register(Class<? extends IWritable> cls,
            String alias, int size, Class<? extends BinaryComparator> comparator) {
        if (alias != null && !"".equals(alias)) {
            if (CLASS_TO_ALIAS.containsKey(cls)) {
                LOG.warning("Class " + cls + " has been given an " + "aliase "
                        + CLASS_TO_ALIAS.get(cls) + " when trying to "
                        + "register it with an alias " + alias);
            }

            if (ALIAS_TO_CLASS.containsKey(alias)) {
                LOG.warning(alias + " has been "
                        + "registered as the alias of "
                        + ALIAS_TO_CLASS.get(alias)
                        + " when trying to register it as the alias of " + cls);
            }

            CLASS_TO_ALIAS.put(cls, alias);
            ALIAS_TO_CLASS.put(alias, cls);
        } // if
        if (size > 0)
            CLASS_TO_SIZE.put(cls, size);
        if (comparator != null)
            CLASS_TO_COMPARATOR.put(cls, comparator);
    }

    /**
     * register legacy alias.
     * 
     * @param cls
     * @param legacyAlias
     */
    public synchronized void registerLegacyAlias(
            Class<? extends IWritable> cls, String legacyAlias) {
        if (legacyAlias != null && !"".equals(legacyAlias))
            LEGACY_ALIAS_TO_CLASS.put(legacyAlias, cls);
    }

    private boolean initClass(Class<? extends IWritable> clazz) {
        if (INITIALIZED_CLASS.contains(clazz)) {
            return true;
        }
        synchronized (INITIALIZED_CLASS) {
            if (!INITIALIZED_CLASS.contains(clazz)) {
                INITIALIZED_CLASS.add(clazz);
                try {
                    Class.forName(clazz.getName(), true, currentClassLoader);
                } catch (Exception e) {
                    LOG.severe("Initialize class " + clazz + " error:" + e);
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * Get writable name. If no alias found, return its class name.
     * 
     * @param clazz
     * @return
     */
    public synchronized String getWritableName(Class<? extends IWritable> clazz) {
        // initialize class?
        assert clazz != null;
        if (!initClass(clazz)) {
            return clazz.getName();
        }
        // get alias name?
        String value = CLASS_TO_ALIAS.get(clazz);
        if (value == null) {
            return clazz.getName();
        } else {
            return value;
        }
    }

    /**
     * Get Writable class. If no class found, return null.
     * 
     * @param alias
     * @return
     */
    @SuppressWarnings("unchecked")
    public synchronized Class<? extends IWritable> getWritableClass(String alias) {
        assert alias != null;
        Class<? extends IWritable> cls = ALIAS_TO_CLASS.get(alias);
        if (cls == null) {
            cls = LEGACY_ALIAS_TO_CLASS.get(alias);
        }
        if (cls == null) {
            try {
                cls = (Class<? extends IWritable>) Class.forName(alias, true,
                        currentClassLoader);
            } catch (ClassNotFoundException e) {
                LOG.warning("Cannot find class with alias: "
                        + alias
                        + " when use class loader"
                        + currentClassLoader.toString()
                        + ", maybe forgot to add your packge/class in META-INF/writable_registry.list?");
                return WritableRegistry.getWritableClass(alias);
            }
        }
        return cls;
    }

    /**
     * Get writable size. If no size found, return {@link #NON_FIXED_SIZE}
     * 
     * @param clazz
     * @return
     */
    public synchronized int getWritableSize(Class<? extends IWritable> clazz) {
        // initialize class?
        assert clazz != null;
        if (!initClass(clazz)) {
            return NON_FIXED_SIZE;
        }
        // get size?
        Integer value = CLASS_TO_SIZE.get(clazz);
        if (value == null) {
            return NON_FIXED_SIZE;
        } else {
            return value.intValue();
        }
    }

    /**
     * Get writable comparator class. If no comparator class found, return null.
     * 
     * @param clazz
     * @return
     */
    public synchronized Class<? extends BinaryComparator> getBinaryComparatorClass(
            Class<? extends IWritable> clazz) {
        // initialize class?
        if (!initClass(clazz)) {
            return null;
        }
        // get comparator?
        return CLASS_TO_COMPARATOR.get(clazz);
    }

    /**
     * Get writable comparator instance. If no comparator class found, return
     * null, else return a comparator instance with its comparator class.
     * 
     * @param clazz
     * @return
     */
    public synchronized BinaryComparator getBinaryComparator(
            Class<? extends IWritable> clazz) {
        assert clazz != null;
        // initialize class?
        if (!initClass(clazz))
            return null;
        // get comparator?
        Class<? extends BinaryComparator> value = CLASS_TO_COMPARATOR.get(clazz);
        if (value == null) {
            return null;
        } else {
            return (BinaryComparator) ClassUtils.newInstance(value);
        }
    }

    @SuppressWarnings("unchecked")
    private void loadWritables(String[] packages) {
        String[] cls;
        for (int i = 0; i < packages.length; i++) {
            // find classes
            try {
                //	        	LOG.info("Find package:" + packages[i]);
                cls = findClassesInPackage(packages[i],
                        new ArrayList<String>(), new ArrayList<String>(),
                        currentClassLoader);
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "load writables error: " + packages[i], e);
                continue;
            }
            // load classes
            for (int j = 0; j < cls.length; j++) {
                try {
                    //	        	  LOG.info("Load Class:" + cls[j] + " with " + currentClassLoader);
                    Class<?> clazz = Class.forName(cls[j], true,
                            currentClassLoader);
                    //	            clazz.newInstance();
                    if (IWritable.class.isAssignableFrom(clazz)
                            && !clazz.isInterface())
                        initClass((Class<? extends IWritable>) clazz);
                } catch (Throwable e) {
                    LOG.log(Level.WARNING, "Error loading " + cls[j]
                            + ", ignoring ...", e);
                }
            }
        }
    }

    /**
     * Find classes in a package under class paths
     * 
     * @param packageName
     * @return The list of all the classes inside this package
     * @throws IOException
     */
    public static String[] findClassesInPackage(String packageName,
            List<String> included, List<String> excluded,
            ClassLoader classLoader) throws IOException {
        String packageOnly = packageName;
        boolean recursive = false;
        if (packageName.endsWith(".*")) {
            packageOnly = packageName.substring(0,
                    packageName.lastIndexOf(".*"));
            recursive = true;
        }

        List<String> vResult = new ArrayList<String>();
        String packageDirName = packageOnly.replace('.', '/');
        Enumeration<URL> dirs = classLoader.getResources(packageDirName);
        while (dirs.hasMoreElements()) {
            URL url = dirs.nextElement();
            String protocol = url.getProtocol();
            if ("file".equals(protocol)) {
                findClassesInDirPackage(packageOnly, included, excluded,
                        URLDecoder.decode(url.getFile(), "UTF-8"), recursive,
                        vResult, classLoader);
            } else if ("jar".equals(protocol)) {
                JarFile jar = ((JarURLConnection) url.openConnection()).getJarFile();
                Enumeration<JarEntry> entries = jar.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (name.charAt(0) == '/')
                        name = name.substring(1);
                    if (name.startsWith(packageDirName)) {
                        int idx = name.indexOf('/', packageDirName.length() + 1);
                        if ((idx == -1) || recursive)
                            //it's not inside a deeper dir
                            if (name.endsWith(".class") && !entry.isDirectory()) {
                                String className = name.substring(
                                        packageDirName.length() + 1,
                                        name.length() - 6).replace('/', '.');
                                String pkgName = packageOnly.replace('/', '.');
                                includeOrExcludeClass(url.toString(), pkgName,
                                        className, included, excluded, vResult,
                                        classLoader);
                            }
                    }
                } // while
            } // else if
        } // while

        String[] result = vResult.toArray(new String[vResult.size()]);
        return result;
    }

    private static void findClassesInDirPackage(String packageName,
            List<String> included, List<String> excluded, String packagePath,
            final boolean recursive, List<String> classes,
            ClassLoader classLoader) {
        File dir = new File(packagePath);

        if (!dir.exists() || !dir.isDirectory())
            return;

        File[] dirfiles = dir.listFiles(new FileFilter() {
            public boolean accept(File file) {
                return (recursive && file.isDirectory())
                        || (file.getName().endsWith(".class"));
            }
        });

        for (File file: dirfiles) {
            if (file.isDirectory()) {
                findClassesInDirPackage(
                        catPackageName(packageName, file.getName()), included,
                        excluded, file.getAbsolutePath(), recursive, classes,
                        classLoader);
            } else {
                String className = file.getName().substring(0,
                        file.getName().length() - 6);
                includeOrExcludeClass(file.getAbsolutePath(), packageName,
                        className, included, excluded, classes, classLoader);
            }
        }
    }

    private static void includeOrExcludeClass(String from, String packageName,
            String className, List<String> included, List<String> excluded,
            List<String> classes, ClassLoader classLoader) {
        if (isIncluded(className, included, excluded)) {
            String fullName = catPackageName(packageName, className);
            try {
                Class.forName(fullName, true, classLoader);
            } catch (Throwable e) {
                System.err.println("bad class def from " + from + " : "
                        + fullName);
                //	      		e.printStackTrace(System.err);
                return;
            }
            classes.add(packageName + '.' + className);
        }
    }

    private static String catPackageName(String parent, String name) {
        if (parent.length() > 0) {
            return parent + "." + name;
        } else {
            return name;
        }
    }

    /**
     * @return true if name should be included.
     */
    private static boolean isIncluded(String name, List<String> included,
            List<String> excluded) {

        boolean result = false;
        // If no includes nor excludes were specified, return true.
        if (included.size() == 0 && excluded.size() == 0)
            result = true;
        else {
            boolean isIncluded = find(name, included);
            boolean isExcluded = find(name, excluded);
            if (isIncluded && !isExcluded)
                result = true;
            else if (isExcluded)
                result = false;
            else {
                result = included.size() == 0;
            }
        }
        return result;
    }

    private static boolean find(String name, List<String> list) {
        for (String regexpStr: list) {
            if (Pattern.matches(regexpStr, name))
                return true;
        }
        return false;
    }

    //	  public static void main(String[] args) throws Exception {
    //	    long t1 = System.currentTimeMillis();
    //	    loadWritables(new String[]{"odis.serialize.lib","outfox.io.*"});
    //	    System.out.println((System.currentTimeMillis()-t1)+": loaded " + INITIALIZED_CLASS.size());
    //	    Iterator<Class<? extends IWritable>> it = INITIALIZED_CLASS.iterator();
    //	    while (it.hasNext()) {
    //	      System.out.println(it.next().toString());
    //	    }
    //	  }
}
