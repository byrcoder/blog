package odis.net;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.ClosedByInterruptException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.LzoOutputStream;
import odis.serialize.lib.UTF8Writable;
import toolbox.misc.LogFormatter;

/**
 * Server which server local file to remote client.
 * 
 * @author river
 */
public class DataServer implements Runnable {
    private static final Logger LOG = LogFormatter.getLogger(DataServer.class);

    public static final byte CMD_LENGTH = 1;

    public static final byte CMD_TRANSFER = 2;

    public static final byte CMD_SEEKTRANSFER = 3;

    public static final String COMPRESS_TAG = "COMPRESS:";

    public static final long ERR_NO_SUCH_FILE = -1;

    public static final long ERR_NO_SUCH_COMMAND = -2;

    public static final long ERR_BAD_OFFSET = -3;

    public static final long ERR_CONCURRENT_LIMIT = -4;

    private static final int MAX_DISK_NUMBER = 6;

    private HashMap<String, List<String>> diskConcurrentMap = new HashMap<String, List<String>>();

    private File[] dirs;

    private int port;

    private int concurrentPerDisk;

    private ExecutorService threadPool;

    volatile private Thread mainThread;

    private boolean daemon = true;

    private boolean isRunning = true;

    private ServerSocket server;

    /**
     * construct a <code>DataServer</code> with the given parameters
     * 
     * @param dirs
     *            the data dirs where the files are stored
     * @param port
     *            the server port
     * @param concurrent
     *            the limit of concurrent number per Disk
     * @param daemon
     *            the server daemon flag
     * @throws IOException
     *             any I/O error occur
     */
    public DataServer(File[] dirs, int port, int concurrent, boolean daemon)
            throws IOException {
        this.dirs = dirs;
        this.port = port;
        this.concurrentPerDisk = concurrent;
        this.daemon = daemon;
        server = new ServerSocket(port, 512);
    }

    /**
     * get the data dirs
     * 
     * @return the data dirs
     */
    public File[] getDirs() {
        return dirs;
    }

    /**
     * check the server is isRunning
     * 
     * @return the server running status
     */
    public synchronized boolean isRunning() {
        return isRunning;
    }

    /**
     * set the server running status
     * 
     * @param b
     *            the given status
     */
    public synchronized void setRunning(boolean b) {
        isRunning = b;
    }

    /**
     * start the data server
     * 
     * @throws IOException
     *             any I/O error occurs
     */
    public void start() throws IOException {
        threadPool = Executors.newFixedThreadPool(concurrentPerDisk
                * MAX_DISK_NUMBER);
        mainThread = new Thread(this, "DataServer on " + port);
        if (daemon)
            mainThread.setDaemon(true);
        mainThread.start();
    }

    /**
     * stop the servers
     */
    public void stop() {
        Thread t = mainThread;
        mainThread = null;
        t.interrupt();
        threadPool.shutdown();
    }

    /**
     * thread run functions
     */
    public void run() {
        Thread currentThread = Thread.currentThread();
        setRunning(true);
        try {
            while (currentThread == mainThread) {
                try {
                    try {
                        while (true) {
                            Socket socket = server.accept();
                            LOG.log(Level.INFO, "Connection from "
                                    + socket.getRemoteSocketAddress()
                                    + " accepted.");
                            DataConnection conn = new DataConnection(socket);
                            conn.start();
                        }
                    } finally {
                        server.close();
                    }
                } catch (ClosedByInterruptException e) { // closed
                    break;
                } catch (IOException e) {
                    LOG.log(Level.SEVERE, "data server on port " + port
                            + " error", e);
                }

                if (currentThread == mainThread)
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        break;
                    }
            }
        } finally {
            setRunning(false);
        }
    }

    private boolean acquireConcurrentToken(String filename) {
        String fileSystemName = "default";
        try {
            /*
             * Get the top level path as the file-system
             */
            int p = filename.indexOf("/", 1);
            if (p >= 0) {
                fileSystemName = filename.substring(0, p);
            } // if
        } catch (Throwable e) {
            LOG.log(Level.WARNING, "cannot use df to determine filesystem, "
                    + "use default filesystem");
        }

        synchronized (diskConcurrentMap) {
            List<String> files = (List<String>) diskConcurrentMap
                    .get(fileSystemName);
            if (files == null) {
                files = new ArrayList<String>();
                diskConcurrentMap.put(fileSystemName, files);
            }
            if (files.size() >= concurrentPerDisk) {
                return false;
            }
            files.add(filename);
            return true;
        }
    }

    private void releaseConcurrentToken(String filename) {
        synchronized (diskConcurrentMap) {
            for (List<String> files: diskConcurrentMap.values()) {
                for (Iterator<String> it = files.iterator(); it.hasNext();) {
                    if (it.next().equals(filename)) {
                        it.remove();
                        return;
                    }
                }
            }
        }
        LOG.log(Level.WARNING, "try to release non-exists file");
    }

    private class DataTransfer implements Runnable {
        private Socket socket;

        private File file;

        private SocketAddress clientAddress;

        private long offset;

        private OutputStream socketOutput;

        private boolean compressed;

        public DataTransfer(Socket socket, File file, long offset,
                boolean compressed) throws IOException {
            this.socket = socket;
            this.file = file;
            clientAddress = socket.getRemoteSocketAddress();
            this.offset = offset;
            this.socketOutput = socket.getOutputStream();
            this.compressed = compressed;
        }

        private void transfer() throws IOException {
            long beginTime = System.currentTimeMillis();
            long size = file.length();
            if (offset < 0 || offset > size) {
                CDataOutputStream.writeLong(ERR_BAD_OFFSET, socketOutput);
                return;
            } else {
                CDataOutputStream.writeLong(size, socketOutput);
            }

            LOG.info("Serving file " + file.getAbsolutePath()
                    + (compressed ? "(compressed)" : "") + " from offset "
                    + offset + " to client " + socket.getRemoteSocketAddress());

            FileInputStream fis = new FileInputStream(file);
            try {
                if (offset > 0) {
                    fis.skip(offset);
                } // if

                OutputStream dataOutput = socketOutput;
                if (compressed) {
                    dataOutput = new LzoOutputStream(socketOutput);
                }

                byte[] buffer = new byte[8192];
                int len;
                long remains = size - offset;
                while (remains > 0) {
                    len = fis.read(buffer);
                    if (len <= 0) {
                        throw new IOException("no enough data could be read "
                                + "out from file " + file);
                    } // if
                    dataOutput.write(buffer, 0, len);
                    remains -= len;
                } // while
                dataOutput.flush();

                long endTime = System.currentTimeMillis();
                LOG.info("Finished file " + file.getAbsolutePath()
                        + (compressed ? "(compressed)" : "") + " from offset "
                        + offset + " to client "
                        + socket.getRemoteSocketAddress() + ", file size: "
                        + size + ", used: " + (endTime - beginTime) + "ms");

            } finally {
                fis.close();
            }
        }

        public void run() {
            try {
                try {
                    transfer();
                } finally {
                    releaseConcurrentToken(file.getAbsolutePath());
                    socketOutput.close();
                    socket.close();
                }
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Transfer data to client "
                        + clientAddress + " error", e);
            }
        }
    }

    private class DataConnection extends Thread {
        private Socket socket;

        public DataConnection(Socket socket) {
            super("Data connection " + socket.getRemoteSocketAddress());
            this.socket = socket;
            this.setDaemon(true);
        }

        private boolean scheduleTransfer(File file, long offset,
                boolean compressed) {
            String filename = file.getAbsolutePath();
            if (acquireConcurrentToken(filename)) {
                boolean submitFailed = true;
                try {
                    DataTransfer transfer = new DataTransfer(socket, file,
                            offset, compressed);
                    threadPool.execute(transfer);
                    submitFailed = false;
                    return true;
                } catch (RejectedExecutionException e) {
                    LOG.log(Level.WARNING, "start transfer " + file
                            + " failed dur to concurrent limit");
                } catch (IOException e) {
                    LOG.log(Level.SEVERE, "start transfer " + file + " failed",
                            e);
                } finally {
                    if (submitFailed) {
                        releaseConcurrentToken(filename);
                    } // if
                }
            } // if
            return false;
        }

        private void processCommand() throws IOException {
            CDataInputStream in = new CDataInputStream(socket.getInputStream());
            CDataOutputStream out = new CDataOutputStream(socket
                    .getOutputStream());

            byte command = in.readByte();
            UTF8Writable filename = new UTF8Writable();
            filename.readFields(in);
            String filenameString = filename.get();
            boolean compressed = false;
            if (filenameString.startsWith(COMPRESS_TAG)) {
                filenameString = filenameString
                        .substring(COMPRESS_TAG.length());
                compressed = true;
            }

            File file = getFile(filenameString);

            if (file == null) {
                out.writeLong(ERR_NO_SUCH_FILE);
            } else {
                switch (command) {
                    case CMD_LENGTH: {
                        out.writeLong(file.length());
                        return;
                    }

                    case CMD_TRANSFER: {
                        if (scheduleTransfer(file, 0, compressed)) {
                            // transfer thread will close the socket
                            socket = null;
                        } else {
                            out.writeLong(ERR_CONCURRENT_LIMIT);
                        }
                        return;
                    }

                    case CMD_SEEKTRANSFER: {
                        long offset = in.readLong();
                        if (scheduleTransfer(file, offset, compressed)) {
                            // transfer thread will close the socket
                            socket = null;
                        } else {
                            out.writeLong(ERR_CONCURRENT_LIMIT);
                        } // else
                        return;
                    }

                    default: {
                        out.writeLong(ERR_NO_SUCH_COMMAND);
                    }
                } // switch
            } // else
        }
        
        @Override
        public void run() {
            try {
                try {
                    processCommand();
                } finally {
                    if (socket != null)
                        socket.close();
                }
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Client connection exception", e);
            }
        }

        private File getFile(String filename) {
            for (int i = 0; i < dirs.length; i++) {
                File file = new File(dirs[i], filename.toString());
                if (file.exists()) {
                    return file;
                }
            }
            return null;
        }

    }

    /**
     * print the usage
     */
    public static void usage() {
        System.out.println("params: port dir1 dir2 ...");
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            usage();
            return;
        } // if
        int port = Integer.parseInt(args[0]);
        File[] files = new File[args.length - 1];
        for (int i = 1; i < args.length; i++)
            files[i - 1] = new File(args[i]);
        DataServer server = new DataServer(files, port, 10, false);
        server.start();
    }

}
