/**
 * @(#)NativeRamBufferCDataOutputStream.java, 2012-4-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.DataOutput;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;

import odis.io.BufferOverflowException;
import odis.io.CDataOutputStream;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF16Writable;

/**
 * A CDataOutputStream with several NativeRamBuffer as its buffer.
 * 
 * @author zhangduo
 */
public abstract class BufferCDataOutputStream<T extends AbstractBuffer> extends
        OutputStream implements DataOutput {

    protected T[] buffers;

    protected int indexOfBufferShift;

    protected long offsetInBufferMask;

    protected long pos;

    protected long capacity;

    /**
     * Construct a BufferCDataOutputStream.
     * <p>
     * Count should be less than or equal to sum of buffers' length.
     * <p>
     * The buffer size should be a power of 2 unless you have only one buffer,
     * and all the buffers' length should be bufferSize.
     * 
     * @param buffers
     * @param bufferSize
     */
    public BufferCDataOutputStream(T[] buffers, long bufferSize) {
        resetBuffers(buffers, bufferSize);
    }

    /**
     * Append the <tt>newBuffers</tt> to the end of original buffers.
     * <p>
     * Each buffer in <tt>newBuffers</tt> should have the same size which is
     * equal to the original bufferSize.
     * 
     * @param newBuffers
     */
    public void appendBuffers(T[] newBuffers) {
        if (newBuffers.length == 0) {
            return;
        }
        T[] buffers = Arrays.copyOf(this.buffers, this.buffers.length
                + newBuffers.length);
        System.arraycopy(newBuffers, 0, buffers, this.buffers.length,
                newBuffers.length);
        resetBuffers(buffers, buffers[0].getCapacity());
    }

    /**
     * Reconstruct the OutputStream.
     * <p>
     * Note that the <tt>pos</tt> will not be changed after this call, you
     * should call {@link #resetToPos(long)} if you want to reset it to 0.
     * 
     * @param buffers
     * @param bufferSize
     */
    public void resetBuffers(T[] buffers, long bufferSize) {
        if (buffers.length > 1 && bufferSize < Long.SIZE / Byte.SIZE) {
            throw new IllegalArgumentException(
                    "bufferSize is too small(less than long size)");
        }
        for (T buffer: buffers) {
            if (buffer.getCapacity() != bufferSize) {
                throw new IllegalArgumentException();
            }
        }
        if (buffers.length <= 1) {
            this.indexOfBufferShift = 63;
            this.offsetInBufferMask = -1L;
        } else {
            int indexOfBufferShift = 0;
            for (long tmp = bufferSize; tmp > 1; indexOfBufferShift++) {
                if ((tmp & 1) != 0) {
                    throw new IllegalArgumentException();
                }
                tmp >>>= 1;
            }
            this.indexOfBufferShift = indexOfBufferShift;
            this.offsetInBufferMask = bufferSize - 1;
        }
        this.capacity = bufferSize * buffers.length;
        this.buffers = buffers;
    }

    /**
     * Get the back buffers directly.
     * <p>
     * This operation is not safe, change the returned buffers will effect the
     * OutputStream.
     */
    public T[] getBuffers() {
        return buffers;
    }

    /**
     * Get current position.
     * 
     * @return
     */
    public long getPos() {
        return pos;
    }

    /**
     * Reset position to the given <tt>pos</tt>.
     */
    public void resetToPos(long pos) {
        if (pos > capacity) {
            this.pos = capacity;
        } else if (pos < 0) {
            this.pos = 0;
        } else {
            this.pos = pos;
        }
    }

    /**
     * Get the total buffer size of this OutputStream.
     */
    public long getCapacity() {
        return capacity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(int b) throws IOException {
        if (pos + 1 > capacity) {
            throw new BufferOverflowException();
        }
        buffers[indexOfBuffer()].put(offsetInBuffer(), b);
        pos++;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b) throws IOException {
        write(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (pos + len > capacity) {
            throw new BufferOverflowException();
        }
        while (len > 0) {
            int size = (int) (buffers[indexOfBuffer()].getCapacity() - offsetInBuffer());
            size = Math.min(len, size);
            buffers[indexOfBuffer()].put(offsetInBuffer(), b, off, size);
            len -= size;
            off += size;
            pos += size;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeBoolean(boolean v) throws IOException {
        write(v ? 1 : 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeByte(int v) throws IOException {
        write(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeChar(int v) throws IOException {
        writeShort(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFloat(float v) throws IOException {
        writeInt(Float.floatToIntBits(v));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeDouble(double v) throws IOException {
        writeLong(Double.doubleToLongBits(v));
    }

    /**
     * @see CDataOutputStream#writeVInt(int)
     */
    public abstract int writeVInt(int v) throws IOException;

    /**
     * @see CDataOutputStream#writeVLong(long)
     */
    public abstract int writeVLong(long v) throws IOException;

    /**
     * Not implemented.
     */
    @Override
    public void writeBytes(String s) {
        throw new UnsupportedOperationException();
    }

    /**
     * Not implemented.
     * <p>
     * Use {@link UTF16Writable#writeString(DataOutput, String)} instead.
     */
    @Override
    public void writeChars(String s) {
        throw new UnsupportedOperationException();
    }

    /**
     * Not implemented.
     * <p>
     * Use {@link StringWritable#writeString(DataOutput, String)} instead.
     */
    @Override
    public void writeUTF(String s) {
        throw new UnsupportedOperationException();
    }

    /**
     * calculate index by shift
     * 
     * @param pos
     * @param offsetInBufferMask
     * @return
     */
    protected int indexOfBuffer() {
        return (int) (pos >>> indexOfBufferShift);
    }

    /**
     * calculate offset by and.
     * 
     * @param pos
     * @param offsetInBufferMask
     * @return
     */
    protected long offsetInBuffer() {
        return pos & offsetInBufferMask;
    }
}
