/**
 * @(#)NativeRamBufferPool.java, 2012-3-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import odis.util.AbstractBufferPool;

/**
 * Manages {@link NativeRamBuffer} with a total size limit and chunk size.
 * <p>
 * This class is not thread safe.
 * 
 * @author zhangduo
 */
public class NativeRamBufferPool extends AbstractBufferPool<NativeRamBuffer> {
    private static final int DEFAULT_FREE_CHUNK_INDEX_POOL_SIZE = 128;

    private final long ptr;

    /**
     * @see #NativeRamBufferPool(long, long, long, int)
     */
    public NativeRamBufferPool(long ptr, long maxBufferSize, long chunkSize) {
        this(ptr, maxBufferSize, chunkSize, DEFAULT_FREE_CHUNK_INDEX_POOL_SIZE);
    }

    /**
     * Constructor.
     * 
     * @param ptr
     * @param maxBufferSize
     * @param chunkSize
     * @param freeChunkIndexPoolSize
     * @see AbstractBufferPool#AbstractBufferPool(long, long, int)
     */
    public NativeRamBufferPool(long ptr, long maxBufferSize, long chunkSize,
            int freeChunkIndexPoolSize) {
        super(maxBufferSize, chunkSize, freeChunkIndexPoolSize);
        this.ptr = ptr;
    }

    @Override
    protected NativeRamBuffer createBuffer(int freeChunk) {
        return new NativeRamBuffer(ptr + (long) chunkSize * freeChunk,
                chunkSize);
    }

    @Override
    protected NativeRamBuffer[] createBufferTemplateArray() {
        return NativeRamBuffer.EMPTY_ARRAY;
    }
}
