/**
 * @(#)HeapCDataInputStream.java, 2012-5-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import odis.io.CDataInputStream;
import odis.io.Seekable;

/**
 * A CDataInputStream with byte array as its buffer.
 * 
 * @author zhangduo
 */
public class HeapCDataInputStream extends InputStream implements DataInput,
        Seekable {

    private byte[] buf;

    private int start;

    private int pos;

    private int mark;

    private int count;

    /**
     * Create a <code>HeapCDataInputStream</code> so that it uses
     * <code>buf</code> as its buffer array.
     * 
     * @param buf
     */
    public HeapCDataInputStream(byte[] buf) {
        this(buf, 0, buf.length);
    }

    /**
     * Create a <code>HeapCDataInputStream</code> so that it uses
     * <code>buf</code> as its buffer array which starts from off, total bytes
     * count is len.
     * 
     * @param buf
     * @param off
     * @param len
     */
    public HeapCDataInputStream(byte[] buf, int off, int len) {
        resetBuf(buf, off, len);
    }

    /**
     * Recreate the <code>InputStream</code>.
     * 
     * @param buf
     * @param off
     * @param len
     */
    public void resetBuf(byte[] buf, int off, int len) {
        this.buf = buf;
        this.start = off;
        this.count = Math.min(off + len, buf.length);
        this.pos = off;
        this.mark = off;
    }

    /**
     * Get current position.
     * 
     * @return
     */
    public int getPos() {
        return pos - start;
    }

    /**
     * Get total bytes count.
     * 
     * @return
     */
    public int getCount() {
        return count - start;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read() {
        if (pos >= count) {
            return -1;
        }
        return buf[pos++] & 0xFF;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b) {
        return read(b, 0, b.length);
    }

    private int readInternal(byte[] b, int off, int len) {
        int toCopy = Math.min(len, count - pos);
        System.arraycopy(buf, pos, b, off, toCopy);
        pos += toCopy;
        return toCopy;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b, int off, int len) {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return 0;
        }
        if (pos >= count) {
            return -1;
        }
        return readInternal(b, off, len);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long skip(long n) {
        int originPos = pos;
        pos = (int) Math.min(count, originPos + n);
        return pos - originPos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int available() {
        return count - pos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void mark(int readlimit) {
        mark = pos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void reset() {
        pos = mark;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean markSupported() {
        return true;
    }

    /**
     * Does nothing.
     */
    @Override
    public void close() {}

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b) throws EOFException {
        readFully(b, 0, b.length);
    }

    @Override
    public void readFully(byte[] b, int off, int len) throws EOFException {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        if (len > count - pos) {
            throw new EOFException();
        }
        readInternal(b, off, len);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int skipBytes(int n) {
        int originPos = pos;
        pos = (int) Math.min(count, originPos + n);
        return pos - originPos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean readBoolean() throws EOFException {
        return readByte() != 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte readByte() throws EOFException {
        return (byte) readUnsignedByte();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedByte() throws EOFException {
        if (pos >= count) {
            throw new EOFException();
        }
        return buf[pos++] & 0xFF;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public short readShort() throws EOFException {
        return (short) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedShort() throws EOFException {
        if (pos >= count - 1) {
            throw new EOFException();
        }
        int v = UnsafeHelper.unsafe.getShort(buf,
                UnsafeHelper.BYTE_ARRAY_BASE_OFFSET + pos) & 0xFFFF;
        pos += 2;
        return v;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public char readChar() throws EOFException {
        return (char) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readInt() throws EOFException {
        if (pos >= count - 3) {
            throw new EOFException();
        }
        int v = UnsafeHelper.unsafe.getInt(buf,
                UnsafeHelper.BYTE_ARRAY_BASE_OFFSET + pos);
        pos += 4;
        return v;
    }

    /**
     * @see CDataInputStream#readVInt()
     */
    public int readVInt() throws EOFException {
        byte b = readByte();
        int i = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = readByte();
            i |= (b & 0x7F) << shift;
        } // for shift
        return i;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long readLong() throws EOFException {
        if (pos >= count - 7) {
            throw new EOFException();
        }
        long v = UnsafeHelper.unsafe.getLong(buf,
                UnsafeHelper.BYTE_ARRAY_BASE_OFFSET + pos);
        pos += 8;
        return v;
    }

    /**
     * @see CDataInputStream#readVLong()
     */
    public long readVLong() throws EOFException {
        byte b = readByte();
        long l = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = readByte();
            l |= ((long) (b & 0x7F)) << shift;
        } // for shift
        return l;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public float readFloat() throws EOFException {
        return Float.intBitsToFloat(readInt());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double readDouble() throws EOFException {
        return Double.longBitsToDouble(readLong());
    }

    /**
     * Not implemented.
     */
    @Override
    public String readLine() throws EOFException {
        throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String readUTF() throws IOException {
        return DataInputStream.readUTF(this);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void seek(long pos) {
        this.pos = (int) Math.min(start + pos, count);
    }
}
