/**
 * @(#)RandomAccessFileBufferCDataInputStream.java, 2013-8-17. 
 * 
 * Copyright 2013 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.EOFException;
import java.io.IOException;

import odis.io.CDataInputStream;

/**
 * A CDataInputStream with several RandomAccessFileBuffer as its buffer.
 * 
 * @author zhangduo
 */
public class RandomAccessFileBufferCDataInputStream extends
        BufferCDataInputStream<RandomAccessFileBuffer> {

    private final byte[] buffer;

    private int bufferSize;

    /**
     * Construct a RandomAccessFileBufferCDataInputStream.
     * 
     * @param buffers
     * @param bufferSize
     * @param count
     */
    public RandomAccessFileBufferCDataInputStream(
            RandomAccessFileBuffer[] buffers, long bufferSize, long count) {
        super(buffers, bufferSize, count);
        buffer = new byte[10];
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedShort() throws IOException {
        loadTempBuffer(2);
        if (bufferSize < 2) {
            throw new EOFException();
        }
        pos += 2;
        return CDataInputStream.readUnsignedShort(buffer, 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readInt() throws IOException {
        loadTempBuffer(4);
        if (bufferSize < 4) {
            throw new EOFException();
        }
        pos += 4;
        return CDataInputStream.readInt(buffer, 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readVInt() throws IOException {
        loadTempBuffer(5);
        int b = buffer[0];
        int i = b & 0x7F;
        pos++;
        for (int index = 1, shift = 7; (b & 0x80) != 0; index++, shift += 7, pos++) {
            if (index >= bufferSize) {
                throw new EOFException();
            }
            b = buffer[index];
            i |= (b & 0x7F) << shift;
        } // for shift
        return i;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long readLong() throws IOException {
        loadTempBuffer(8);
        if (bufferSize < 8) {
            throw new EOFException();
        }
        pos += 8;
        return CDataInputStream.readLong(buffer, 0);
    }

    /**
     * @see CDataInputStream#readVLong()
     */
    @Override
    public long readVLong() throws IOException {
        loadTempBuffer(10);
        int b = buffer[0];
        long l = b & 0x7FL;
        pos++;
        for (int index = 1, shift = 7; (b & 0x80) != 0; index++, shift += 7, pos++) {
            if (index >= bufferSize) {
                throw new EOFException();
            }
            b = buffer[index];
            l |= (b & 0x7FL) << shift;
        } // for shift
        return l;
    }

    private void loadTempBuffer(int size) throws IOException {
        for (int remaining = size;;) {
            int read = read(buffer, 0, remaining);
            if (read == -1) {
                bufferSize = size - remaining;
                if (bufferSize == 0) {
                    throw new EOFException();
                }
                pos -= bufferSize;
                return;
            }
            remaining -= read;
            if (remaining == 0) {
                bufferSize = size;
                pos -= size;
                return;
            }
        }
    }
}
