/**
 * @(#)NativeRamBufferCDataInputStream.java, 2012-3-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.io.EOFException;

import odis.io.CDataInputStream;
import odis.util.BufferCDataInputStream;

/**
 * A CDataInputStream with several NativeRamBuffer as its buffer.
 * 
 * @author zhangduo
 */
public class NativeRamBufferCDataInputStream extends
        BufferCDataInputStream<NativeRamBuffer> {

    /**
     * Construct a NativeRamBufferCDataInputStream.
     * 
     * @param buffers
     * @param bufferSize
     * @param count
     * @see BufferCDataInputStream#BufferCDataInputStream(odis.util.AbstractBuffer[],
     *      long, long)
     */
    public NativeRamBufferCDataInputStream(NativeRamBuffer[] buffers,
            long bufferSize, long count) {
        super(buffers, bufferSize, count);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read() {
        int read = UnsafeHelper.read(buffers, count, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        if (read >= 0) {
            pos++;
        }
        return read;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b) {
        return read(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b, int off, int len) {
        int read = UnsafeHelper.read(b, off, len, buffers, count,
                indexOfBufferShift, offsetInBufferMask, pos, false);
        if (read > 0) {
            pos += read;
        }
        return read;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b) throws EOFException {
        readFully(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b, int off, int len) throws EOFException {
        UnsafeHelper.readFully(b, off, len, buffers, count, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += len;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean readBoolean() throws EOFException {
        return readByte() != 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte readByte() throws EOFException {
        return (byte) readUnsignedByte();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedByte() throws EOFException {
        int ret = UnsafeHelper.readUnsignedByte(buffers, count,
                indexOfBufferShift, offsetInBufferMask, pos, false);
        pos++;
        return ret;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public short readShort() throws EOFException {
        return (short) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedShort() throws EOFException {
        int ret = UnsafeHelper.readUnsignedShort(buffers, count,
                indexOfBufferShift, offsetInBufferMask, pos, false);
        pos += 2;
        return ret;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public char readChar() throws EOFException {
        return (char) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readInt() throws EOFException {
        int ret = UnsafeHelper.readInt(buffers, count, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += 4;
        return ret;
    }

    /**
     * @see CDataInputStream#readVInt()
     */
    public int readVInt() throws EOFException {
        byte b = readByte();
        int i = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = readByte();
            i |= (b & 0x7F) << shift;
        } // for shift
        return i;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long readLong() throws EOFException {
        long ret = UnsafeHelper.readLong(buffers, count, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += 8;
        return ret;
    }

    /**
     * @see CDataInputStream#readVLong()
     */
    public long readVLong() throws EOFException {
        byte b = readByte();
        long l = b & 0x7FL;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = readByte();
            l |= (b & 0x7FL) << shift;
        } // for shift
        return l;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public float readFloat() throws EOFException {
        return Float.intBitsToFloat(readInt());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double readDouble() throws EOFException {
        return Double.longBitsToDouble(readLong());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void seek(long pos) {
        this.pos = (int) Math.min(pos, count);
    }
}
