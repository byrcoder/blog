/**
 * @(#)SystemInfoUtils.java, 2010-5-13. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.OperatingSystemMXBean;

/**
 * System infos of memory and operation system.
 * 
 * @author zhangduo
 */
public class SystemInfoUtils {

    private static final MemoryMXBean MEMORY_MX_BEAN = ManagementFactory.getMemoryMXBean();

    private static final OperatingSystemMXBean OPERATING_SYSTEM_MX_BEAN = ManagementFactory.getOperatingSystemMXBean();

    /**
     * Heap memory usage.
     * 
     * @return
     */
    public static MemoryUsage getMemoryUsage() {
        return MEMORY_MX_BEAN.getHeapMemoryUsage();
    }

    /**
     * Non-Heap memory usage.
     * 
     * @return
     */
    public static MemoryUsage getNonHeapMemoryUsage() {
        return MEMORY_MX_BEAN.getNonHeapMemoryUsage();
    }

    /**
     * Processor count.
     * 
     * @return
     */
    public static int getProcessors() {
        return OPERATING_SYSTEM_MX_BEAN.getAvailableProcessors();
    }

    /**
     * System load.
     * <p>
     * May return -1 under windows.
     * 
     * @return
     */
    public static double getLoad() {
        return OPERATING_SYSTEM_MX_BEAN.getSystemLoadAverage();
    }

    /**
     * load/processors.
     * 
     * @return
     */
    public static double getLoadPerProcessor() {
        return OPERATING_SYSTEM_MX_BEAN.getSystemLoadAverage()
                / OPERATING_SYSTEM_MX_BEAN.getAvailableProcessors();
    }

}
