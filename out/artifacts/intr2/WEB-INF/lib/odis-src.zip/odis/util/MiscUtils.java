/**
 * @(#)MiscUtils.java, 2010-8-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.Closeable;
import java.io.File;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.Selector;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.IRecordReader;
import toolbox.misc.LogFormatter;

/**
 * contains some util methods.
 * 
 * @author zhangduo
 */
public final class MiscUtils {
    private static final Logger LOG = LogFormatter.getLogger(MiscUtils.class);

    /**
     * close without throwing any exception.
     * 
     * @param c
     */
    public static void safeClose(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close failed", t);
            }
        }
    }

    /**
     * close without throwing any exception.
     * 
     * @param socket
     */
    public static void safeClose(DatagramSocket socket) {
        if (socket != null) {
            try {
                socket.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close failed", t);
            }
        }
    }

    /**
     * close without throwing any exception.
     * 
     * @param c
     */
    public static void safeClose(Selector selector) {
        if (selector != null) {
            try {
                selector.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close failed", t);
            }
        }
    }

    /**
     * close without throwing any exception.
     * 
     * @param c
     */
    public static void safeClose(ServerSocket socket) {
        if (socket != null) {
            try {
                socket.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close failed", t);
            }
        }
    }

    /**
     * close without throwing any exception.
     * 
     * @param c
     */
    public static void safeClose(Socket socket) {
        if (socket != null) {
            try {
                socket.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close failed", t);
            }
        }
    }

    /**
     * close without throwing any exception.
     * 
     * @param c
     */
    public static void safeClose(IRecordReader<?, ?> reader) {
        if (reader != null) {
            try {
                reader.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close failed", t);
            }
        }
    }

    /**
     * delete a directory recursively.
     * 
     * @param dir
     * @return
     */
    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            boolean result = true;
            for (File f: dir.listFiles()) {
                result &= deleteDir(f);
            }
            result &= dir.delete();
            return result;
        } else {
            return dir.delete();
        }
    }

    /**
     * Get the root ThreadGroup of all thread in this process.
     * 
     * @return
     */
    public static ThreadGroup findTopThreadGroup() {
        ThreadGroup current = Thread.currentThread().getThreadGroup();
        while (current.getParent() != null) {
            current = current.getParent();
        }
        return current;
    }
}
