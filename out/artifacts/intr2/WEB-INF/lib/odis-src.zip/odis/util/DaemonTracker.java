/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Aug 8, 2006
 */
package odis.util;

import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * Simple utility class to track the status of a daemon thread. Currently it
 * logs any unexpected exceptions thrown by the thread and terminates the whole
 * process when it enters a state throwing exception too fast. If a daemon
 * throws more than {@link #EXCEPTION_LIMIT} exceptions in a row we will stop the
 * process. However the count is reset to 0 if it doesn't throw an exception for
 * {@link #EXCEPTION_PERIOD} time.
 * 
 * @author zf
 */
public class DaemonTracker {

    public final static int EXCEPTION_LIMIT = 100;

    public final static long EXCEPTION_PERIOD = 60 * 1000;

    private static Logger LOG = LogFormatter.getLogger(DaemonTracker.class.getName());

    private int exceptionCount;

    private long lastExceptionTime;

    /**
     * Default constructor.
     */
    public DaemonTracker() {}

    /**
     * Report that the daemon has caught an exception.
     */
    public void gotThrowable(Throwable e) {
        LOG.log(Level.WARNING, "DaemonTracker: "
                + Thread.currentThread().getName()
                + " got unexpected exception", e);
        if (System.currentTimeMillis() - lastExceptionTime > EXCEPTION_PERIOD) {
            exceptionCount = 0;
        }
        if (++exceptionCount > EXCEPTION_LIMIT) {
            LOG.log(Level.SEVERE, "Got " + exceptionCount + " exceptions from "
                    + Thread.currentThread().getName() + " continuously. "
                    + "Shutting down the process!");
            System.exit(1000);
        }
        lastExceptionTime = System.currentTimeMillis();
    }
}
