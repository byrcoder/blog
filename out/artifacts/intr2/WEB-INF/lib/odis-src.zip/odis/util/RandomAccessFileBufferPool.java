/**
 * @(#)RandomAccessFileBufferPool.java, 2013-7-17. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayDeque;
import java.util.concurrent.locks.ReentrantLock;

import odis.util.RandomAccessFileBuffer.RandomAccessFilePool;

/**
 * The buffer pool, provided by random access file instead of memory. This pool
 * is for ssd cache.
 * 
 * @author wangfk
 */
public class RandomAccessFileBufferPool extends
        AbstractBufferPool<RandomAccessFileBuffer> implements
        RandomAccessFilePool, Closeable {

    private static final int DEFAULT_FREE_CHUNK_INDEX_POOL_SIZE = 10240;

    private static final int DEFAULT_RANDOM_ACCESS_FILE_POOL_SIZE = 32;

    private final File file;

    private final int randomAccessFilePoolSize;

    private final ArrayDeque<RandomAccessFile> randomAccessFileQueue;

    private final ReentrantLock randomAccessFileQueueLock = new ReentrantLock();

    private boolean closed = false;

    /**
     * @see #RandomAccessFileBufferPool(File, long, long, int)
     */
    public RandomAccessFileBufferPool(File file, long maxBufferSize,
            long chunkSize) throws IOException {
        this(file, maxBufferSize, chunkSize,
                DEFAULT_RANDOM_ACCESS_FILE_POOL_SIZE);
    }

    /**
     * @see #RandomAccessFileBufferPool(File, long, long, int, int)
     */
    public RandomAccessFileBufferPool(File file, long maxBufferSize,
            long chunkSize, int randomAccessFilePoolSize) throws IOException {
        this(file, maxBufferSize, chunkSize, randomAccessFilePoolSize,
                DEFAULT_FREE_CHUNK_INDEX_POOL_SIZE);
    }

    /**
     * Constructor.
     * 
     * @param file
     *            the file for caching the buffer data
     * @param maxBufferSize
     *            the max total size of the buffer pool
     * @param chunkSize
     *            the size of each buffer slice
     * @param randomAccessFilePoolSize
     *            the pool size of the random access file
     * @param freeChunkIndexPoolSize
     * @throws IOException
     * @see AbstractBufferPool#AbstractBufferPool(long, long, int)
     */
    public RandomAccessFileBufferPool(File file, long maxBufferSize,
            long chunkSize, int randomAccessFilePoolSize,
            int freeChunkIndexPoolSize) throws IOException {
        super(maxBufferSize, chunkSize, freeChunkIndexPoolSize);
        this.randomAccessFilePoolSize = randomAccessFilePoolSize;
        this.file = file;
        File parentDir = file.getParentFile();
        if (!parentDir.isDirectory() && !parentDir.mkdirs()) {
            throw new IOException("Fail to create dir: "
                    + file.getParentFile().getAbsolutePath());
        }
        if (!file.exists() && !file.createNewFile()) {
            throw new IOException("Fail to create file: "
                    + file.getAbsolutePath());
        }
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
        try {
            randomAccessFile.setLength(maxBufferSize);
        } finally {
            MiscUtils.safeClose(randomAccessFile);
        }
        randomAccessFileQueue = new ArrayDeque<RandomAccessFile>(
                randomAccessFilePoolSize + 16);
    }

    @Override
    public void returnRandomAccessFile(RandomAccessFile randomAccessFile,
            boolean hasError) {
        randomAccessFileQueueLock.lock();
        try {
            if (closed || hasError
                    || randomAccessFileQueue.size() >= randomAccessFilePoolSize) {
                MiscUtils.safeClose(randomAccessFile);
            } else {
                randomAccessFileQueue.addFirst(randomAccessFile);
            }
        } finally {
            randomAccessFileQueueLock.unlock();
        }
    }

    @Override
    public RandomAccessFile borrowRandomAccessFile() throws IOException {
        randomAccessFileQueueLock.lock();
        try {
            if (closed) {
                throw new IllegalStateException("Pool is already closed");
            }
            if (randomAccessFileQueue.isEmpty()) {
                return new RandomAccessFile(file, "rw");
            }
            return randomAccessFileQueue.removeFirst();
        } finally {
            randomAccessFileQueueLock.unlock();
        }
    }

    @Override
    public void close() throws IOException {
        randomAccessFileQueueLock.lock();
        try {
            if (closed) {
                return;
            }
            closed = true;
            for (RandomAccessFile raf: randomAccessFileQueue) {
                MiscUtils.safeClose(raf);
            }
        } finally {
            randomAccessFileQueueLock.unlock();
        }
    }

    @Override
    protected RandomAccessFileBuffer[] createBufferTemplateArray() {
        return RandomAccessFileBuffer.EMPTY_ARRAY;
    }

    @Override
    protected RandomAccessFileBuffer createBuffer(int freeChunk) {
        return new RandomAccessFileBuffer(this, chunkSize * freeChunk,
                chunkSize);
    }
}
