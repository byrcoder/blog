/**
 * @(#)SysInfo.java, 2008-12-23. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.BufferedReader;
import java.io.IOException;

import toolbox.misc.FileUtils;
import toolbox.misc.UnitUtils;

/**
 * System parameters, such as swap usage.<br>
 * Swap only worked under linux.
 * 
 * @author river, zhangduo
 */
public class SysInfo {
    private static boolean IS_LINUX;
    static {
        String os = System.getProperty("os.name", "linux");
        IS_LINUX = !(os.toLowerCase().contains("win") || os.toLowerCase().contains(
                "mac os x"));
    }

    private static final String PROC_SWAP_FILE = "/proc/swaps";

    /**
     * Check if the system is linux system.
     * 
     * @return
     */
    public static boolean isLinux() {
        return IS_LINUX;
    }

    /**
     * Return current swap usage in bytes. The swap used information is read
     * from "/proc/swaps", and 0 will be returned on non-linux system.
     * 
     * @return
     */
    public static long getSwapUsed() throws IOException {

        // return 0 on non-linux system
        if (!IS_LINUX) {
            return 0;
        }

        BufferedReader reader = FileUtils.createReader(PROC_SWAP_FILE);
        try {
            String header = reader.readLine();
            String line = null;
            if (header != null) {
                line = reader.readLine();
            }
            if (line == null) {
                throw new IOException("cannot find data in " + PROC_SWAP_FILE);
            }

            // find index for "Used" column in header
            String[] headerColumns = header.split("\\s+");
            int idx = 0;
            while (idx < headerColumns.length
                    && !headerColumns[idx].equalsIgnoreCase("used")) {
                idx++;
            }
            if (idx >= headerColumns.length) {
                throw new IOException("cannot find used column");
            }

            // find the used data
            String[] dataColumns = line.split("\\s+");
            if (idx >= dataColumns.length) {
                throw new IOException("cannot find used data column");
            }

            return Long.parseLong(dataColumns[idx]) * UnitUtils.K;
        } finally {
            reader.close();
        }

    }
}
