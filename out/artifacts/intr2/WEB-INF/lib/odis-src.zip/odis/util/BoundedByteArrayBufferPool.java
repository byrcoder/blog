/**
 * @(#)BoundedByteArrayBufferPool.java, 2011-7-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.util.Iterator;
import java.util.LinkedList;

import odis.io.Limit;

/**
 * A ByteArrayBufferPool with max size limit
 * 
 * @author zhangduo
 */
public class BoundedByteArrayBufferPool implements ByteArrayBufferPool {

    private final long maxSize;

    private long currentSize;

    private final LinkedList<byte[]> pool = new LinkedList<byte[]>();

    /**
     * Construct a BoundedByteArrayBufferPool with maxSize
     * 
     * @param maxSize
     *            the max size of all byte arrays.
     */
    public BoundedByteArrayBufferPool(long maxSize) {
        this.maxSize = maxSize;
    }

    @Override
    public synchronized byte[] allocate(int size) {
        Iterator<byte[]> iter = pool.iterator();
        while (iter.hasNext()) {
            byte[] buffer = iter.next();
            if (buffer.length >= size) {
                iter.remove();
                currentSize -= buffer.length;
                return buffer;
            }
        }
        return Limit.createBuffer(size);
    }

    @Override
    public synchronized void release(byte[] buffer) {
        if (buffer.length > maxSize) {
            return;
        }
        while (currentSize + buffer.length > maxSize) {
            currentSize -= pool.poll().length;
        }
        pool.offer(buffer);
        currentSize += buffer.length;
    }

    /**
     * Get current pooled buffers' size
     * 
     * @return
     */
    public synchronized long getCurrentPoolSize() {
        return currentSize;
    }

    /**
     * Get max size limit
     * 
     * @return
     */
    public long getMaxPoolSize() {
        return maxSize;
    }

    /**
     * Clear all pooled buffers
     */
    public synchronized void clear() {
        pool.clear();
        currentSize = 0;
    }

}
