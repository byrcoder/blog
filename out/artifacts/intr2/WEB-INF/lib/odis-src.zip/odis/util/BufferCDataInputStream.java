/**
 * @(#)NativeRamBufferCDataInputStream.java, 2012-3-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import odis.io.CDataInputStream;
import odis.io.Seekable;
import odis.util.unsafe.UnsafeHelper;

/**
 * A CDataInputStream with several buffers as its buffer.
 * 
 * @author zhangduo
 */
public abstract class BufferCDataInputStream<T extends AbstractBuffer> extends
        InputStream implements DataInput, Seekable {

    protected T[] buffers;

    protected int indexOfBufferShift;

    protected long offsetInBufferMask;

    protected long count;

    protected long mark;

    protected long pos;

    /**
     * Construct a BufferCDataInputStream.
     * <p>
     * Count should be less than or equal to sum of buffers' length.
     * <p>
     * The buffer size should be a power of 2 unless you have only one buffer,
     * and all the buffers' length should be bufferSize.
     * 
     * @param buffers
     * @param bufferSize
     * @param count
     */
    public BufferCDataInputStream(T[] buffers, long bufferSize, long count) {
        resetBuffers(buffers, bufferSize, count);
    }

    /**
     * Reconstruct the InputStream.
     * <p>
     * Note that the <tt>pos</tt> will not be changed after this call, you
     * should call {@link #seek(long)} if you want to reset it to 0.
     * 
     * @param buffers
     * @param bufferSize
     * @param count
     */
    public void resetBuffers(T[] buffers, long bufferSize, long count) {
        if (buffers.length > 1 && bufferSize < Long.SIZE / Byte.SIZE) {
            throw new IllegalArgumentException(
                    "bufferSize is too small(less than long size)");
        }
        for (T buffer: buffers) {
            if (buffer.getCapacity() != bufferSize) {
                throw new IllegalArgumentException();
            }
        }
        if (count > bufferSize * buffers.length) {
            throw new IllegalArgumentException();
        }
        if (buffers.length <= 1) {
            this.indexOfBufferShift = 63;
            this.offsetInBufferMask = -1L;
            this.count = count;
        } else {
            this.indexOfBufferShift = UnsafeHelper.log2(bufferSize);
            this.offsetInBufferMask = bufferSize - 1;
            this.count = count;
        }
        this.buffers = buffers;
    }

    /**
     * Get the back buffers directly.
     * <p>
     * This operation is not safe, change the returned buffers will effect the
     * InputStream.
     */
    public T[] getBuffers() {
        return buffers;
    }

    /**
     * Get current position.
     * 
     * @return
     */
    public long getPos() {
        return pos;
    }

    /**
     * Get the total bytes count.
     */
    public long getCount() {
        return count;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read() throws IOException {
        if (pos >= count) {
            return -1;
        }
        int indexOfBuffer = indexOfBuffer();
        long offsetInBuffer = offsetInBuffer();
        int ret = buffers[indexOfBuffer].get(offsetInBuffer);
        pos++;
        return ret;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b) throws IOException {
        return read(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return 0;
        }
        if (pos >= count) {
            return -1;
        }
        for (int remaining = len;;) {
            AbstractBuffer buffer = buffers[indexOfBuffer()];
            long offsetInBuffer = offsetInBuffer();
            long bufferRemaining = Math.min(count - pos, buffer.getCapacity()
                    - offsetInBuffer);
            int toRead = (int) Math.min(remaining, bufferRemaining);
            int read = buffer.get(offsetInBuffer, b, off, toRead);
            pos += read;
            off += read;
            remaining -= read;
            if (remaining == 0 || pos == count) {
                return len - remaining;
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long skip(long n) {
        long originPos = pos;
        pos = Math.min(count, originPos + n);
        return pos - originPos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int available() {
        int remaining = (int) Math.min(count - pos, Integer.MAX_VALUE);
        return remaining;
    }

    /**
     * Set the current marked position in the stream. ByteArrayInputStream
     * objects are marked at position zero by default when constructed. They may
     * be marked at another position within the buffer by this method.
     * <p>
     * If no mark has been set, then the value of the mark is the offset passed
     * to the constructor (or 0 if the offset was not supplied).
     * <p>
     * Note: The <code>readAheadLimit</code> for this class has no meaning.
     * 
     * @since JDK1.1
     */
    @Override
    public void mark(int readlimit) {
        mark = pos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void reset() {
        pos = mark;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean markSupported() {
        return true;
    }

    /**
     * Does nothing.
     */
    @Override
    public void close() {}

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b) throws IOException {
        readFully(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b, int off, int len) throws IOException {
        int read = read(b, off, len);
        if (read != len) {
            throw new EOFException();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int skipBytes(int n) {
        long originPos = pos;
        pos = Math.min(count, originPos + n);
        return (int) (pos - originPos);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean readBoolean() throws IOException {
        return readByte() != 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte readByte() throws IOException {
        return (byte) readUnsignedByte();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedByte() throws IOException {
        int ret = read();
        if (ret == -1) {
            throw new EOFException();
        }
        return ret;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public short readShort() throws IOException {
        return (short) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public char readChar() throws IOException {
        return (char) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public float readFloat() throws IOException {
        return Float.intBitsToFloat(readInt());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double readDouble() throws IOException {
        return Double.longBitsToDouble(readLong());
    }

    /**
     * @see CDataInputStream#readVInt()
     */
    public abstract int readVInt() throws IOException;

    /**
     * @see CDataInputStream#readVLong()
     */
    public abstract long readVLong() throws IOException;

    /**
     * Not implemented.
     */
    @Override
    public String readLine() throws EOFException {
        throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String readUTF() throws IOException {
        return DataInputStream.readUTF(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void seek(long pos) {
        this.pos = (int) Math.min(pos, count);
    }

    /**
     * calculate index by shift
     * 
     * @param pos
     * @param offsetInBufferMask
     * @return
     */
    protected int indexOfBuffer() {
        return (int) (pos >>> indexOfBufferShift);
    }

    /**
     * calculate offset by and.
     * 
     * @param pos
     * @param offsetInBufferMask
     * @return
     */
    protected long offsetInBuffer() {
        return pos & offsetInBufferMask;
    }
}
