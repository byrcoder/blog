/**
 * @(#)RandomAccessFileBuffer.java, 2013-7-17. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.IOException;
import java.io.RandomAccessFile;

import odis.io.BufferOverflowException;

/**
 * The data buffer, provided by random access file {@link RandomAccessFile}
 * instead of memory.
 * 
 * @author wangfk
 */
public class RandomAccessFileBuffer extends AbstractBuffer {

    public static final RandomAccessFileBuffer[] EMPTY_ARRAY = new RandomAccessFileBuffer[0];

    /**
     * A pool for allocating and reusing of RandomAccessFile
     * 
     * @author wangfk
     */
    public interface RandomAccessFilePool {
        /**
         * Borrow a RandomAccessFile instance
         * 
         * @return RandomAccessFile instance
         * @throws IOException
         */
        public RandomAccessFile borrowRandomAccessFile() throws IOException;

        /**
         * Return the RandomAccessFile instance borrowed from the pool
         * 
         * @param randomAccessFile
         *            the borrowed RandomAccessFile instance
         * @param hasError
         *            whether the borrowed instance has error while accessing
         *            data. If hasError is true, the RandomAccessFile instance
         *            should not be reused again
         */
        public void returnRandomAccessFile(RandomAccessFile randomAccessFile,
                boolean hasError);
    }

    private final RandomAccessFilePool randomAccessFilePool;

    private final long startPos;

    private boolean hasError = false;

    /**
     * Construct the buffer, start at <tt>startPosition</tt> of the file
     * <tt>randomAccessFile</tt> with the <tt>capacity</tt>
     * 
     * @param randomAccessFile
     * @param startPosition
     * @param capacity
     */
    public RandomAccessFileBuffer(RandomAccessFilePool randomAccessFilePool,
            long startPosition, long capacity) {
        super(capacity);
        this.randomAccessFilePool = randomAccessFilePool;
        this.startPos = startPosition;
    }

    /**
     * Get byte count between the start of the buffer and the start of the under
     * file.
     * 
     * @return
     */
    public long getStartPos() {
        return startPos;
    }

    @Override
    public int get(long pos) throws IOException {
        if (pos < 0 || pos >= capacity) {
            throw new IndexOutOfBoundsException();
        }
        RandomAccessFile randomAccessFile = randomAccessFilePool.borrowRandomAccessFile();
        try {
            hasError = true;
            randomAccessFile.seek(startPos + pos);
            int ret = randomAccessFile.read();
            hasError = false;
            return ret;
        } finally {
            randomAccessFilePool.returnRandomAccessFile(randomAccessFile,
                    hasError);
        }
    }

    @Override
    public void put(long pos, int b) throws IOException {
        if (pos < 0) {
            throw new IndexOutOfBoundsException();
        }
        if (pos >= capacity) {
            throw new BufferOverflowException();
        }
        RandomAccessFile randomAccessFile = randomAccessFilePool.borrowRandomAccessFile();
        try {
            hasError = true;
            randomAccessFile.seek(startPos + pos);
            randomAccessFile.write(b);
            hasError = false;
        } finally {
            randomAccessFilePool.returnRandomAccessFile(randomAccessFile,
                    hasError);
        }
    }

    @Override
    public int get(long pos, byte[] buffer, int offset, int length)
            throws IOException {
        check(pos, buffer, offset, length);
        if (pos >= capacity || length == 0) {
            return 0;
        }
        RandomAccessFile randomAccessFile = randomAccessFilePool.borrowRandomAccessFile();
        try {
            int toRead = (int) Math.min(capacity - pos, length);
            hasError = true;
            randomAccessFile.seek(startPos + pos);
            randomAccessFile.readFully(buffer, offset, toRead);
            hasError = false;
            return toRead;
        } finally {
            randomAccessFilePool.returnRandomAccessFile(randomAccessFile,
                    hasError);
        }
    }

    @Override
    public void put(long pos, byte[] buffer, int offset, int length)
            throws IOException {
        check(pos, buffer, offset, length);
        if (pos >= capacity || pos + length < 0 || pos + length > capacity) {
            throw new BufferOverflowException();
        }
        RandomAccessFile randomAccessFile = randomAccessFilePool.borrowRandomAccessFile();
        try {
            hasError = true;
            randomAccessFile.seek(startPos + pos);
            randomAccessFile.write(buffer, offset, length);
            hasError = false;
        } finally {
            randomAccessFilePool.returnRandomAccessFile(randomAccessFile,
                    hasError);
        }
    }

    boolean hasError() {
        return hasError;
    }
}
