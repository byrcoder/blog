/**
 * @(#)AbstractBuffer.java, 2013-7-17. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.IOException;

import odis.util.unsafe.NativeRamBuffer;

/**
 * The parent class of {@link RandomAccessFileBuffer} and
 * {@link NativeRamBuffer}
 * 
 * @author wangfk
 */
public abstract class AbstractBuffer {
    private int chunkIndex;

    protected final long capacity;

    /**
     * constructor
     * 
     * @param capacity
     */
    public AbstractBuffer(long capacity) {
        if (capacity < 0) {
            throw new IllegalArgumentException();
        }
        this.capacity = capacity;
    }

    /**
     * Used to by AbstractBufferPool to locate buffer position.
     * 
     * @return
     */
    int getChunkIndex() {
        return chunkIndex;
    }

    /**
     * Set by AbstractBufferPool.
     * 
     * @param chunkIndex
     */
    void setChunkIndex(int chunkIndex) {
        this.chunkIndex = chunkIndex;
    }

    public long getCapacity() {
        return capacity;
    }

    /**
     * Get the byte at <tt>pos</tt> of this buffer.
     * 
     * @param pos
     * @return
     * @throws IOException
     */
    public abstract int get(long pos) throws IOException;

    /**
     * Put the byte into this buffer at <tt>pos</tt>
     * 
     * @param b
     * @throws IOException
     */
    public abstract void put(long pos, int b) throws IOException;

    /**
     * Get the buffer contents start at <tt>pos</tt> to the given byte array.
     * 
     * @param pos
     *            relative to the start of this NativeRamBuffer, not absolute.
     * @param buffer
     * @param offset
     * @param length
     * @return
     * @throws IOException
     */
    public abstract int get(long pos, byte[] buffer, int offset, int length)
            throws IOException;

    /**
     * Put the byte array's contents to the buffer start at <tt>pos</tt>.
     * 
     * @param pos
     *            relative to the start of this NativeRamBuffer, not absolute.
     * @param buffer
     * @param offset
     * @param length
     * @throws IOException
     */
    public abstract void put(long pos, byte[] buffer, int offset, int length)
            throws IOException;

    protected void check(long pos, byte[] buffer, int offset, int length) {
        if (pos < 0 || offset < 0 || length < 0 || offset + length < 0
                || buffer.length < offset + length) {
            throw new IndexOutOfBoundsException();
        }
    }

    /**
     * Copy the byte array's content to several buffers.
     * 
     * @param buffers
     * @param arr
     * @param off
     * @param len
     * @throws IOException
     */
    public static <T extends AbstractBuffer> void copyFromArray(T[] buffers,
            byte[] arr, int off, int len) throws IOException {
        if (off < 0 || len < 0 || off + len < 0 || arr.length < off + len) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        for (AbstractBuffer buffer: buffers) {
            int toCopy = (int) Math.min(len, buffer.capacity);
            buffer.put(0, arr, off, toCopy);
            off += toCopy;
            len -= toCopy;
            if (len == 0) {
                return;
            }
        }
    }

    /**
     * Copy several buffers' content to the given byte array.
     * 
     * @param buffers
     * @param arr
     * @param off
     * @param len
     * @throws IOException
     */
    public static <T extends AbstractBuffer> void copyToArray(T[] buffers,
            byte[] arr, int off, int len) throws IOException {
        if (off < 0 || len < 0 || off + len < 0 || arr.length < off + len) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        for (AbstractBuffer buffer: buffers) {
            int toCopy = (int) Math.min(len, buffer.capacity);
            buffer.get(0, arr, off, toCopy);
            off += toCopy;
            len -= toCopy;
            if (len == 0) {
                return;
            }
        }
    }

}
