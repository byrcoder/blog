/**
 * @(#)AbstractBufferPool.java, 2013-7-17. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

import odis.util.unsafe.NativeRamBufferPool;

/**
 * The parent class of {@link NativeRamBufferPool} and
 * {@link RandomAccessFileBufferPool}
 * 
 * @author wangfk
 */
public abstract class AbstractBufferPool<T extends AbstractBuffer> {

    protected final long maxBufferSize;

    protected final long chunkSize;

    protected final int totalChunk;

    protected final BitSet usedBitSet;

    protected long allocatedBufferSize;

    protected int[] freeChunkIndexPool;

    protected int freeChunkIndexPoolPointor;

    private void addFreeChunkIndex(int freeChunkIndex) {
        if (freeChunkIndexPoolPointor < freeChunkIndexPool.length) {
            freeChunkIndexPool[freeChunkIndexPoolPointor++] = freeChunkIndex;
        }
    }

    private int getFreeChunkIndex() {
        if (freeChunkIndexPoolPointor == 0) {
            return -1;
        }
        return freeChunkIndexPool[--freeChunkIndexPoolPointor];
    }

    /**
     * Construct a BufferPool.
     * <p>
     * The <tt>maxBufferSize</tt> should be divided with no remainder by
     * <tt>chunkSize</tt>.
     * 
     * @param maxBufferSize
     * @param chunkSize
     * @param freeChunkIndexPoolSize
     *            max cached size for free chunks. This is for fast locate free
     *            chunk.
     */
    protected AbstractBufferPool(long maxBufferSize, long chunkSize,
            int freeChunkIndexPoolSize) {
        this.maxBufferSize = maxBufferSize;
        this.chunkSize = chunkSize;
        this.freeChunkIndexPool = new int[freeChunkIndexPoolSize];
        this.freeChunkIndexPoolPointor = 0;
        if (maxBufferSize % chunkSize != 0) {
            throw new IllegalArgumentException("maxBufferSize " + maxBufferSize
                    + " can not be divided with no remainder by chunkSize "
                    + chunkSize);
        }
        long totalChunk = maxBufferSize / chunkSize;
        if (totalChunk > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("too many chunks");
        }
        this.totalChunk = (int) totalChunk;
        usedBitSet = new BitSet(this.totalChunk);
    }

    /**
     * Return buffers which total size is larger than or equal to the given
     * <tt>size</tt> unless we do not have enough space.
     * <p>
     * Each buffer will be <tt>chunkSize</tt> bytes and may not be continuous.
     * 
     * @param size
     * @return
     */
    public T[] allocBuffer(long size) {
        long leftSize = maxBufferSize - allocatedBufferSize;
        if (leftSize == 0) {
            return createBufferTemplateArray();
        } else if (leftSize < size) {
            size = leftSize;
        }
        List<T> buffers = new ArrayList<T>();
        int freeChunk = -1;
        long allocatedSize = 0;
        while (allocatedSize < size) {
            freeChunk = getFreeChunkIndex();
            if (freeChunk == -1) {
                freeChunk = usedBitSet.nextClearBit(freeChunk + 1);
            }
            if (freeChunk >= totalChunk) {
                break;
            }
            usedBitSet.set(freeChunk);
            allocatedSize += chunkSize;
            T buffer = createBuffer(freeChunk);
            buffer.setChunkIndex(freeChunk);
            buffers.add(buffer);
        }
        this.allocatedBufferSize += allocatedSize;
        return buffers.toArray(createBufferTemplateArray());
    }

    private boolean managed(T buf) {
        return buf.getChunkIndex() >= 0 && buf.getChunkIndex() < totalChunk;
    }

    /**
     * Release buffer's space in the given <tt>bufs</tt>.
     * <p>
     * All the buffers in <tt>bufs</tt> should be managed by this pool.
     * 
     * @param bufs
     */
    public void freeBuffer(T[] bufs) {
        int size = 0;
        for (T buf: bufs) {
            if (!managed(buf)) {
                throw new IllegalArgumentException(buf
                        + " is not managed by me");
            }
            size += chunkSize;
            usedBitSet.clear(buf.getChunkIndex());
            addFreeChunkIndex(buf.getChunkIndex());
            freeBuffer(buf);
        }
        allocatedBufferSize -= size;
    }

    /**
     * Get current used size.
     */
    public long getAllocatedBufferSize() {
        return allocatedBufferSize;
    }

    /**
     * Get max size.
     */
    public long getMaxBufferSize() {
        return maxBufferSize;
    }

    /**
     * Get chunk size.
     */
    public long getChunkSize() {
        return chunkSize;
    }

    /**
     * Get the chunk number we have.
     * <p>
     * The number should be getMaxBufferSize() / getChunkSize().
     */
    public int getTotalChunk() {
        return totalChunk;
    }

    protected abstract T[] createBufferTemplateArray();

    protected abstract T createBuffer(int freeChunk);

    protected void freeBuffer(T buffer) {}
}
