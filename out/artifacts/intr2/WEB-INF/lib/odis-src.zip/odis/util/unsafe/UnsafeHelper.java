/**
 * @(#)UnsafeHelper.java, 2012-2-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.EOFException;
import java.io.InputStream;
import java.lang.reflect.Field;

import odis.io.BufferOverflowException;

import sun.misc.Unsafe;

/**
 * Helper of sun.misc.Unsafe.
 * <p>
 * You should use copy method in this class instead of using unsafe's copy
 * method directly. The method in this class does some extra work when the
 * copied content is too small or too large.
 * <p>
 * If too small, direct unsafe.putByte will be faster than a jni call. See
 * {@link #JNI_COPY_ARRAY_THRESHOLD}
 * <p>
 * If too large, a single jni copy call will block gc for a long time, we should
 * split into several copies. See {@link #UNSAFE_COPY_THRESHOLD}
 * <p>
 * <strong>WARNING</strong>: This class is only valid on X86 architecture.
 * First, all codes are written with little endian, and second, the multi-thread
 * memory consistency model is only valid on X86. And be careful for read and
 * write bytes method, its normal and volatile version is same, you need to call
 * getXXXVolatile or putXXXVolatile to emit a read-barrier or write-barrier
 * yourself if you really need a barrier(sadly that sun.misc.Unsafe has no
 * method to generate a single memory barrier).
 * <p>
 * MORE THINGS: on x86, write-barrier is an addl instruction with lock prefix,
 * and read-barrier is not needed(but the newest intel processors somehow
 * documented that it has a weaker memory consistency model than before).
 * 
 * @author zhangduo
 */
public class UnsafeHelper {
    /**
     * Instance of sun.misc.Unsafe.
     */
    public static final Unsafe unsafe;

    /**
     * unsafe.arrayBaseOffset(byte[].class)
     */
    public static final long BYTE_ARRAY_BASE_OFFSET;

    /**
     * This number limits the number of bytes to copy per call to Unsafe's
     * copyMemory method. A limit is imposed to allow for safepoint polling
     * during a large copy
     */
    public static final long UNSAFE_COPY_THRESHOLD = 1024L * 1024L;

    /**
     * We only use jni array copy when the copied bytes length larger than this
     * value.
     */
    public static final long JNI_COPY_ARRAY_THRESHOLD = 8;

    static {
        try {
            Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            unsafe = (Unsafe) field.get(null);
            BYTE_ARRAY_BASE_OFFSET = unsafe.arrayBaseOffset(byte[].class);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Test whether addr1 is lower than addr2
     */
    public static boolean lower(long addr1, long addr2) {
        return addr1 < addr2 ^ (addr1 < 0) ^ (addr2 < 0);
    }

    /**
     * Test whether addr1 is lower than addr2
     */
    public static boolean higher(long addr1, long addr2) {
        return addr1 > addr2 ^ (addr1 < 0) ^ (addr2 < 0);
    }

    /**
     * Found the nearest address higher than
     * <tt>addr<tt> that with alignment <tt>align</tt>.
     * 
     * @param addr
     * @param align
     *            must be power of 2.
     * @return
     */
    public static long align(long addr, int align) {
        return ((addr - 1) & ~(align - 1)) + align;
    }

    /**
     * Copy native content to byte array.
     * <p>
     * No range check, and len must be greater than 0.
     * 
     * @param addr
     * @param arr
     * @param off
     * @param len
     */
    public static void copyToArray(long addr, byte[] arr, int off, int len) {
        if (len > JNI_COPY_ARRAY_THRESHOLD) {
            off += BYTE_ARRAY_BASE_OFFSET;
            while (len > 0) {
                long size = Math.min(len, UNSAFE_COPY_THRESHOLD);
                unsafe.copyMemory(null, addr, arr, off, size);
                addr += size;
                off += size;
                len -= size;
            }
        } else {
            for (int i = off, end = off + len; i < end; i++, addr++) {
                arr[i] = unsafe.getByte(addr);
            }
        }
    }

    /**
     * Copy byte array content to native.
     * <p>
     * No range check, and len must be greater than 0.
     * 
     * @param addr
     * @param arr
     * @param off
     * @param len
     */
    public static void copyFromArray(long addr, byte[] arr, int off, int len) {
        if (len > JNI_COPY_ARRAY_THRESHOLD) {
            off += BYTE_ARRAY_BASE_OFFSET;
            while (len > 0) {
                long size = Math.min(len, UNSAFE_COPY_THRESHOLD);
                unsafe.copyMemory(arr, off, null, addr, size);
                addr += size;
                off += size;
                len -= size;
            }
        } else {
            for (int i = off, end = off + len; i < end; i++, addr++) {
                unsafe.putByte(addr, arr[i]);
            }
        }
    }

    /**
     * wrapper of <code>Unsafe.getByte</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static byte getByte(long addr, boolean isVolatile) {
        if (isVolatile) {
            return unsafe.getByteVolatile(null, addr);
        } else {
            return unsafe.getByte(addr);
        }
    }

    /**
     * wrapper of <code>Unsafe.putByte</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static void putByte(long addr, byte v, boolean isVolatile) {
        if (isVolatile) {
            unsafe.putByteVolatile(null, addr, v);
        } else {
            unsafe.putByte(addr, v);
        }
    }

    /**
     * wrapper of <code>Unsafe.getShort</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static short getShort(long addr, boolean isVolatile) {
        if (isVolatile) {
            return unsafe.getShortVolatile(null, addr);
        } else {
            return unsafe.getShort(addr);
        }
    }

    /**
     * wrapper of <code>Unsafe.putShort</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static void putShort(long addr, short v, boolean isVolatile) {
        if (isVolatile) {
            unsafe.putShortVolatile(null, addr, v);
        } else {
            unsafe.putShort(addr, v);
        }
    }

    /**
     * wrapper of <code>Unsafe.getInt</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static int getInt(long addr, boolean isVolatile) {
        if (isVolatile) {
            return unsafe.getIntVolatile(null, addr);
        } else {
            return unsafe.getInt(addr);
        }
    }

    /**
     * wrapper of <code>Unsafe.putInt</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static void putInt(long addr, int v, boolean isVolatile) {
        if (isVolatile) {
            unsafe.putIntVolatile(null, addr, v);
        } else {
            unsafe.putInt(addr, v);
        }
    }

    /**
     * wrapper of <code>Unsafe.getLong</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static long getLong(long addr, boolean isVolatile) {
        if (isVolatile) {
            return unsafe.getLongVolatile(null, addr);
        } else {
            return unsafe.getLong(addr);
        }
    }

    /**
     * wrapper of <code>Unsafe.putLong</code>.
     * 
     * @param addr
     * @param isVolatile
     * @return
     */
    public static void putLong(long addr, long v, boolean isVolatile) {
        if (isVolatile) {
            unsafe.putLongVolatile(null, addr, v);
        } else {
            unsafe.putLong(addr, v);
        }
    }

    /**
     * Get log value base 2.
     * <p>
     * v must be power of 2.
     * 
     * @param v
     * @return
     */
    public static int log2(long v) {
        if (Long.bitCount(v) != 1) {
            throw new IllegalArgumentException(v + " is not power of 2");
        }
        return Long.numberOfTrailingZeros(v);
    }

    /**
     * calculate index by shift
     * 
     * @param pos
     * @param offsetInBufferMask
     * @return
     */
    public static int indexOfBuffer(long pos, int indexOfBufferShift) {
        return (int) (pos >>> indexOfBufferShift);
    }

    /**
     * calculate offset by and.
     * 
     * @param pos
     * @param offsetInBufferMask
     * @return
     */
    public static long offsetInBuffer(long pos, long offsetInBufferMask) {
        return pos & offsetInBufferMask;
    }

    /**
     * @see InputStream#read()
     */
    public static int read(NativeRamBuffer[] buffers, long bound,
            int indexOfBufferShift, long offsetInBufferMask, long pos,
            boolean isVolatile) {
        if (pos >= bound) {
            return -1;
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer(pos, indexOfBufferShift)];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        return getByte(buffer.getPtr() + offsetInBuffer, isVolatile) & 0xFF;
    }

    // read as much as possible
    private static int readInternal(byte[] b, int off, int len,
            NativeRamBuffer[] buffers, long bound, int indexOfBufferShift,
            long offsetInBufferMask, long pos, boolean isVolatile) {
        for (int remaining = len;;) {
            NativeRamBuffer buffer = buffers[indexOfBuffer(pos,
                    indexOfBufferShift)];
            long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
            long bufferRemaining = Math.min(bound - pos, buffer.getCapacity()
                    - offsetInBuffer);
            int toRead = (int) Math.min(remaining, bufferRemaining);
            UnsafeHelper.copyToArray(buffer.getPtr() + offsetInBuffer, b, off,
                    toRead);
            pos += toRead;
            off += toRead;
            remaining -= toRead;
            if (remaining == 0 || pos == bound) {
                return len - remaining;
            }
        }
    }

    /**
     * @see InputStream#read(byte[], int, int)
     */
    public static int read(byte[] b, int off, int len,
            NativeRamBuffer[] buffers, long bound, int indexOfBufferShift,
            long offsetInBufferMask, long pos, boolean isVolatile) {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return 0;
        }
        if (pos >= bound) {
            return -1;
        }
        return readInternal(b, off, len, buffers, bound, indexOfBufferShift,
                offsetInBufferMask, pos, isVolatile);
    }

    private static void checkEOF(long bound, long pos, int read)
            throws EOFException {
        if (pos + read > bound) {
            throw new EOFException("Can not read " + read
                    + " bytes start from " + pos + " because bound is " + bound);
        }
    }

    /**
     * @see DataInput#readFully(byte[], int, int)
     */
    public static void readFully(byte[] b, int off, int len,
            NativeRamBuffer[] buffers, long bound, int indexOfBufferShift,
            long offsetInBufferMask, long pos, boolean isVolatile)
            throws EOFException {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        checkEOF(bound, pos, len);
        readInternal(b, off, len, buffers, bound, indexOfBufferShift,
                offsetInBufferMask, pos, isVolatile);
    }

    /**
     * @see DataInput#readUnsignedByte()
     */
    public static int readUnsignedByte(NativeRamBuffer[] buffers, long bound,
            int indexOfBufferShift, long offsetInBufferMask, long pos,
            boolean isVolatile) throws EOFException {
        checkEOF(bound, pos, 1);
        NativeRamBuffer buffer = buffers[indexOfBuffer(pos, indexOfBufferShift)];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        return getByte(buffer.getPtr() + offsetInBuffer, isVolatile) & 0xFF;
    }

    /**
     * @see DataInput#readUnsignedShort()
     */
    public static int readUnsignedShort(NativeRamBuffer[] buffers, long bound,
            int indexOfBufferShift, long offsetInBufferMask, long pos,
            boolean isVolatile) throws EOFException {
        checkEOF(bound, pos, 2);
        int bufferIndex = indexOfBuffer(pos, indexOfBufferShift);
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        if (offsetInBuffer < buffer.getCapacity() - 1) {
            return UnsafeHelper.unsafe.getShort(buffer.getPtr()
                    + offsetInBuffer) & 0xFFFF;
        } else {
            int low = getByte(buffer.getPtr() + offsetInBuffer, isVolatile) & 0xFF;
            buffer = buffers[bufferIndex + 1];
            int high = getByte(buffer.getPtr(), isVolatile) & 0xFF;
            return (high << 8) | low;
        }
    }

    /**
     * @see DataInput#readInt()
     */
    public static int readInt(NativeRamBuffer[] buffers, long bound,
            int indexOfBufferShift, long offsetInBufferMask, long pos,
            boolean isVolatile) throws EOFException {
        checkEOF(bound, pos, 4);
        int bufferIndex = indexOfBuffer(pos, indexOfBufferShift);
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        if (offsetInBuffer < buffer.getCapacity() - 3) {
            return getInt(buffer.getPtr() + offsetInBuffer, isVolatile);
        } else {
            // read 2 bytes only on even address, we assume that buffer bound
            // is always even.
            switch ((int) (buffer.getCapacity() - offsetInBuffer)) {
                case 1: {// 1 | 2 1
                    int v1 = getByte(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFF;
                    buffer = buffers[bufferIndex + 1];
                    int v2 = getShort(buffer.getPtr(), isVolatile) & 0xFFFF;
                    int v3 = getByte(buffer.getPtr() + 2, isVolatile) & 0xFF;
                    return (v3 << 24) | (v2 << 8) | v1;
                }
                case 2: {// 2 | 2
                    int v1 = getShort(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFFF;
                    buffer = buffers[bufferIndex + 1];
                    int v2 = getShort(buffer.getPtr(), isVolatile) & 0xFFFF;
                    return (v2 << 16) | v1;
                }
                case 3: {// 1 2 | 1
                    int v1 = getByte(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFF;
                    int v2 = getShort(buffer.getPtr() + offsetInBuffer + 1,
                            isVolatile) & 0xFFFF;
                    buffer = buffers[bufferIndex + 1];
                    int v3 = getByte(buffer.getPtr(), isVolatile) & 0xFF;
                    return (v3 << 24) | (v2 << 8) | v1;
                }
                default:
                    throw new RuntimeException("should not reach here");
            }
        }
    }

    /**
     * @see DataInput#readLong()
     */
    public static long readLong(NativeRamBuffer[] buffers, long bound,
            int indexOfBufferShift, long offsetInBufferMask, long pos,
            boolean isVolatile) throws EOFException {
        checkEOF(bound, pos, 8);
        int bufferIndex = indexOfBuffer(pos, indexOfBufferShift);
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        if (offsetInBuffer < buffer.getCapacity() - 7) {
            return getLong(buffer.getPtr() + offsetInBuffer, isVolatile);
        } else {
            // read 2 bytes only on even address, read 4 bytes only on 4-align 
            // address, we assume the buffer bound is always 4-align.
            switch ((int) (buffer.getCapacity() - offsetInBuffer)) {
                case 1: {// 1 | 4 2 1
                    long v1 = getByte(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v2 = getInt(buffer.getPtr(), isVolatile) & 0xFFFFFFFFL;
                    long v3 = getShort(buffer.getPtr() + 4, isVolatile) & 0xFFFFL;
                    long v4 = getByte(buffer.getPtr() + 6, isVolatile) & 0xFFL;
                    return (v4 << 56) | (v3 << 40) | (v2 << 8) | v1;
                }
                case 2: {// 2 | 4 2
                    long v1 = getShort(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v2 = getInt(buffer.getPtr(), isVolatile) & 0xFFFFFFFFL;
                    long v3 = getShort(buffer.getPtr() + 4, isVolatile) & 0xFFFFL;
                    return (v3 << 48) | (v2 << 16) | v1;
                }
                case 3: {// 1 2 | 4 1
                    long v1 = getByte(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFL;
                    long v2 = getShort(buffer.getPtr() + offsetInBuffer + 1,
                            isVolatile) & 0xFFFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v3 = getInt(buffer.getPtr(), isVolatile) & 0xFFFFFFFFL;
                    long v4 = getByte(buffer.getPtr() + 4, isVolatile) & 0xFFL;
                    return (v4 << 56) | (v3 << 24) | (v2 << 8) | v1;
                }
                case 4: {// 4 | 4
                    long v1 = getInt(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFFFFFFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v2 = getInt(buffer.getPtr(), isVolatile) & 0xFFFFFFFFL;
                    return (v2 << 32) | v1;
                }
                case 5: {// 1 4 | 2 1
                    long v1 = getByte(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFL;
                    long v2 = getInt(buffer.getPtr() + offsetInBuffer + 1,
                            isVolatile) & 0xFFFFFFFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v3 = getShort(buffer.getPtr(), isVolatile) & 0xFFFFL;
                    long v4 = getByte(buffer.getPtr() + 2, isVolatile);
                    return (v4 << 56) | (v3 << 40) | (v2 << 8) | v1;
                }
                case 6: {// 2 4 | 2
                    long v1 = getShort(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFFFL;
                    long v2 = getInt(buffer.getPtr() + offsetInBuffer + 2,
                            isVolatile) & 0xFFFFFFFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v3 = getShort(buffer.getPtr(), isVolatile) & 0xFFFFL;
                    return (v3 << 48) | (v2 << 16) | v1;
                }
                case 7: {// 1 2 4 | 1
                    long v1 = getByte(buffer.getPtr() + offsetInBuffer,
                            isVolatile) & 0xFFL;
                    long v2 = getShort(buffer.getPtr() + offsetInBuffer + 1,
                            isVolatile) & 0xFFFFL;
                    long v3 = getInt(buffer.getPtr() + offsetInBuffer + 3,
                            isVolatile) & 0xFFFFFFFFL;
                    buffer = buffers[bufferIndex + 1];
                    long v4 = getByte(buffer.getPtr(), isVolatile) & 0xFFL;
                    return (v4 << 56) | (v3 << 24) | (v2 << 8) | v1;
                }
                default:
                    throw new RuntimeException("should not reach here");
            }
        }
    }

    private static void checkOverflow(long capacity, long pos, int writeSize) {
        if (pos + writeSize > capacity) {
            throw new BufferOverflowException();
        }
    }

    /**
     * @see DataOutput#write(int)
     */
    public static void write(int b, NativeRamBuffer[] buffers, long capacity,
            int indexOfBufferShift, long offsetInBufferMask, long pos,
            boolean isVolatile) {
        checkOverflow(capacity, pos, 1);
        NativeRamBuffer buffer = buffers[indexOfBuffer(pos, indexOfBufferShift)];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        putByte(buffer.getPtr() + offsetInBuffer, (byte) b, isVolatile);
    }

    /**
     * @see DataOutput#write(byte[], int, int)
     */
    public static void write(byte[] b, int off, int len,
            NativeRamBuffer[] buffers, long capacity, int indexOfBufferShift,
            long offsetInBufferMask, long pos, boolean isVolatile) {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        checkOverflow(capacity, pos, len);
        for (;;) {
            NativeRamBuffer buffer = buffers[indexOfBuffer(pos,
                    indexOfBufferShift)];
            long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
            int toWrite = (int) Math.min(len, buffer.getCapacity()
                    - offsetInBuffer);
            UnsafeHelper.copyFromArray(buffer.getPtr() + offsetInBuffer, b,
                    off, toWrite);
            pos += toWrite;
            off += toWrite;
            len -= toWrite;
            if (len == 0) {
                break;
            }
        }
    }

    /**
     * @see DataOutput#writeShort(int)
     */
    public static void writeShort(int v, NativeRamBuffer[] buffers,
            long capacity, int indexOfBufferShift, long offsetInBufferMask,
            long pos, boolean isVolatile) {
        checkOverflow(capacity, pos, 2);
        int bufferIndex = indexOfBuffer(pos, indexOfBufferShift);
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        if (offsetInBuffer < buffer.getCapacity() - 1) {
            putShort(buffer.getPtr() + offsetInBuffer, (short) v, isVolatile);
        } else {
            putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
            buffer = buffers[bufferIndex + 1];
            putByte(buffer.getPtr(), (byte) (v >>> 8), isVolatile);
        }
    }

    /**
     * @see DataOutput#writeInt(int)
     */
    public static void writeInt(int v, NativeRamBuffer[] buffers,
            long capacity, int indexOfBufferShift, long offsetInBufferMask,
            long pos, boolean isVolatile) {
        checkOverflow(capacity, pos, 4);
        int bufferIndex = indexOfBuffer(pos, indexOfBufferShift);
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        if (offsetInBuffer < buffer.getCapacity() - 3) {
            putInt(buffer.getPtr() + offsetInBuffer, v, isVolatile);
        } else {
            // write 2 bytes only on even address, we assume that buffer bound
            // is always even.
            switch ((int) (buffer.getCapacity() - offsetInBuffer)) {
                case 1: {// 1 | 2 1
                    putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
                    buffer = buffers[bufferIndex + 1];
                    putShort(buffer.getPtr(), (short) (v >>> 8), false);
                    putByte(buffer.getPtr() + 2, (byte) (v >>> 24), isVolatile);
                    break;
                }
                case 2: {// 2 | 2
                    putShort(buffer.getPtr() + offsetInBuffer, (short) v, false);
                    buffer = buffers[bufferIndex + 1];
                    putShort(buffer.getPtr(), (short) (v >>> 16), isVolatile);
                    break;
                }
                case 3: {// 1 2 | 1
                    putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
                    putShort(buffer.getPtr() + offsetInBuffer + 1,
                            (short) (v >>> 8), false);
                    buffer = buffers[bufferIndex + 1];
                    putByte(buffer.getPtr(), (byte) (v >>> 24), isVolatile);
                    break;
                }
                default:
                    throw new RuntimeException("should not reach here");
            }
        }
    }

    /**
     * @see DataOutput#writeLong(long)
     */
    public static void writeLong(long v, NativeRamBuffer[] buffers,
            long capacity, int indexOfBufferShift, long offsetInBufferMask,
            long pos, boolean isVolatile) {
        checkOverflow(capacity, pos, 8);
        int bufferIndex = indexOfBuffer(pos, indexOfBufferShift);
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer(pos, offsetInBufferMask);
        if (offsetInBuffer < buffer.getCapacity() - 7) {
            putLong(buffer.getPtr() + offsetInBuffer, v, isVolatile);
        } else {
            // read 2 bytes only on even address, read 4 bytes only on 4-align 
            // address, we assume the buffer bound is always 4-align.
            switch ((int) (buffer.getCapacity() - offsetInBuffer)) {
                case 1: {// 1 | 4 2 1
                    putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
                    buffer = buffers[bufferIndex + 1];
                    putInt(buffer.getPtr(), (int) (v >>> 8), false);
                    putShort(buffer.getPtr() + 4, (short) (v >>> 40), false);
                    putByte(buffer.getPtr() + 6, (byte) (v >>> 56), isVolatile);
                    break;
                }
                case 2: {// 2 | 4 2
                    putShort(buffer.getPtr() + offsetInBuffer, (short) v,
                            isVolatile);
                    buffer = buffers[bufferIndex + 1];
                    putInt(buffer.getPtr(), (int) (v >>> 16), isVolatile);
                    putShort(buffer.getPtr() + 4, (short) (v >>> 48),
                            isVolatile);
                    break;
                }
                case 3: {// 1 2 | 4 1
                    putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
                    putShort(buffer.getPtr() + offsetInBuffer + 1,
                            (short) (v >>> 8), false);
                    buffer = buffers[bufferIndex + 1];
                    putInt(buffer.getPtr(), (int) (v >>> 24), false);
                    putByte(buffer.getPtr() + 4, (byte) (v >>> 56), isVolatile);
                    break;
                }
                case 4: {// 4 | 4
                    putInt(buffer.getPtr() + offsetInBuffer, (int) v, false);
                    buffer = buffers[bufferIndex + 1];
                    putInt(buffer.getPtr(), (int) (v >>> 32), isVolatile);
                    break;
                }
                case 5: {// 1 4 | 2 1
                    putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
                    putInt(buffer.getPtr() + offsetInBuffer + 1,
                            (int) (v >>> 8), false);
                    buffer = buffers[bufferIndex + 1];
                    putShort(buffer.getPtr(), (short) (v >>> 40), false);
                    putByte(buffer.getPtr() + 2, (byte) (v >>> 56), isVolatile);
                    break;
                }
                case 6: {// 2 4 | 2
                    putShort(buffer.getPtr() + offsetInBuffer, (short) v, false);
                    putInt(buffer.getPtr() + offsetInBuffer + 2,
                            (int) (v >>> 16), false);
                    buffer = buffers[bufferIndex + 1];
                    putShort(buffer.getPtr(), (short) (v >>> 48), isVolatile);
                    break;
                }
                case 7: {// 1 2 4 | 1
                    putByte(buffer.getPtr() + offsetInBuffer, (byte) v, false);
                    putShort(buffer.getPtr() + offsetInBuffer + 1,
                            (short) (v >>> 8), false);
                    putInt(buffer.getPtr() + offsetInBuffer + 3,
                            (int) (v >>> 24), false);
                    buffer = buffers[bufferIndex + 1];
                    putByte(buffer.getPtr(), (byte) (v >>> 56), isVolatile);
                    break;
                }
                default:
                    throw new RuntimeException("should not reach here");
            }
        }
    }

    /** largest prime smaller than 65536 */
    private static final long BASE = 65521L;

    /**
     * NMAX is the largest n such that 255n(n+1)/2 + (n+1)(BASE-1) <=
     * 2<sup>63</sup>-1
     */
    private static final long NMAX = 190184348;

    /**
     * Calc adler32 using <tt>count</tt> bytes start from addr
     * 
     * @param adler32
     * @param addr
     * @param count
     * @return
     */
    public static int adler32(int adler32, long addr, long count) {
        long a = adler32 & 0xFFFF;
        long b = adler32 >>> 16;
        while (count > 0) {
            long k = count < NMAX ? count : NMAX;
            count -= k;
            while (k >= 16) {
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;
                a += unsafe.getByte(addr++) & 0xFF;
                b += a;

                k -= 16;
            }
            while (k > 0) {
                a += unsafe.getByte(addr) & 0xFFL;
                b += a;

                addr++;
                k--;
            }
            a %= BASE;
            b %= BASE;
        }
        return (int) (b << 16 | a);
    }
}
