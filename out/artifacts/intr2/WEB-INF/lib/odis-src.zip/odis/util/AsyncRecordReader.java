/**
 * @(#)AsyncRecordReader.java, 2007-6-8. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import odis.file.ARecordReader;
import odis.file.IRecordReader;
import toolbox.misc.ClassUtils;

/**
 * 异步的RecordReader wrapper，用另外的线程来进行数据下载.
 * <p>
 * 
 * @author river
 * @param <K>
 *            key类型
 * @param <V>
 *            value类型
 * @deprecated use {@link ARecordReader} instead
 */
@Deprecated
public class AsyncRecordReader<K, V> {

    /**
     * 保存读到的记录.
     * 
     * @param <K>
     * @param <V>
     */
    public static class KeyValPair<K, V> {
        private K key;

        private V val;

        /**
         * Constructor with specific element classes.
         * 
         * @param keyClass
         * @param valClass
         */
        @SuppressWarnings("unchecked")
        public KeyValPair(Class<?> keyClass, Class<?> valClass) {
            key = (K) ClassUtils.newInstance(keyClass);
            val = (V) ClassUtils.newInstance(valClass);
        }

        /**
         * Return key.
         * 
         * @return
         */
        public K key() {
            return key;
        }

        /**
         * Return value.
         */
        public V val() {
            return val;
        }

    }

    private Queue<KeyValPair<K, V>> buffer = new LinkedList<KeyValPair<K, V>>();

    private BlockingQueue<KeyValPair<K, V>> writeablePool;

    private IRecordReader reader;

    private boolean end = false;

    private Throwable except = null;

    private KeyValPair<K, V> current = null;

    private int batchCount = 1000;

    private FillThread fillThread = null;

    /**
     * 创建一个异步的reader，包装reader，缓存的对象个数是batchCount.
     * 
     * @param reader
     * @param batchCount
     */
    public AsyncRecordReader(IRecordReader reader, int batchCount) {
        this.reader = reader;
        this.batchCount = batchCount;
        writeablePool = new ArrayBlockingQueue<KeyValPair<K,V>>(batchCount);
        this.fillThread = new FillThread();
        fillThread.setDaemon(true);
        fillThread.start();
    }

    /**
     * 关闭reader，释放资源.
     */
    public void close() {
        MiscUtils.safeClose(reader);
    }

    /**
     * 返回reader中是否存在更多的数据.
     * 
     * @return
     * @throws IOException
     */
    public boolean next() throws IOException {
        if (current != null) {
            writeablePool.offer(current);
            current = null;
        }

        synchronized (buffer) {
            if (!buffer.isEmpty()) {
                current = buffer.poll();
                if (buffer.size() < batchCount) {
                    buffer.notify();
                }
                return true;
            } else {
                while (buffer.isEmpty()) {
                    if (except != null) {
                        if (except instanceof IOException) {
                            throw (IOException) except;
                        } else {
                            if (except instanceof RuntimeException) {
                                throw (RuntimeException) except;
                            } else {
                                throw new RuntimeException("unknown exception",
                                        except);
                            }
                        }
                    }
                    if (end) {
                        return false;
                    }
                    buffer.notify();
                    try {
                        buffer.wait();
                    } catch (InterruptedException e) {}
                }
                current = buffer.poll();
                return true;
            }
        }
    }

    public K getKey() {
        return current != null ? current.key : null;
    }

    public V getValue() {
        return current != null ? current.val : null;
    }

    private boolean fill() {
        List<KeyValPair<K, V>> buckets = new ArrayList<AsyncRecordReader.KeyValPair<K, V>>(
                batchCount);
        writeablePool.drainTo(buckets);
        int moreBuckets = batchCount - buckets.size();
        for (int i = 0; i < moreBuckets; i++) {
            buckets.add(new KeyValPair<K, V>(reader.getKeyClass(),
                    reader.getValueClass()));
        }

        boolean more = true;
        int count = 0;
        Throwable ex = null;
        for (KeyValPair<K, V> pair: buckets) {
            try {
                more = reader.next(pair.key, pair.val);
            } catch (Throwable e) {
                ex = e;
                break;
            }

            if (!more) {
                break;
            } else {
                count++;
            }
        }

        synchronized (buffer) {
            end = !more;
            except = ex;
            for (int i = 0; i < count; i++) {
                buffer.add(buckets.get(i));
            }
            buffer.notify();
        }
        return more;
    }

    private class FillThread extends Thread {
        public FillThread() {
            super("FillThread");
        }

        @Override
        public void run() {
            while (fill()) {
                synchronized (buffer) {
                    while (buffer.size() >= batchCount) {
                        try {
                            buffer.wait();
                        } catch (InterruptedException e) {}
                    }
                }
            }
        }

    }

}
