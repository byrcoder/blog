/**
 * @(#)NativeRamBufferCDataOutputStream.java, 2012-4-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import odis.util.BufferCDataOutputStream;

/**
 * A CDataOutputStream with several NativeRamBuffer as its buffer.
 * 
 * @author zhangduo
 */
public class NativeRamBufferCDataOutputStream extends
        BufferCDataOutputStream<NativeRamBuffer> {

    /**
     * Construct a NativeRamBufferCDataOutputStream.
     * 
     * @param buffers
     * @param bufferSize
     * @see BufferCDataOutputStream#BufferCDataOutputStream(odis.util.AbstractBuffer[],
     *      long)
     */
    public NativeRamBufferCDataOutputStream(NativeRamBuffer[] buffers,
            long bufferSize) {
        super(buffers, bufferSize);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(int b) {
        UnsafeHelper.write(b, buffers, capacity, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos++;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b) {
        write(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b, int off, int len) {
        UnsafeHelper.write(b, off, len, buffers, capacity, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += len;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeBoolean(boolean v) {
        write(v ? 1 : 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeByte(int v) {
        write(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeShort(int v) {
        UnsafeHelper.writeShort(v, buffers, capacity, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += 2;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeChar(int v) {
        writeShort(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeInt(int v) {
        UnsafeHelper.writeInt(v, buffers, capacity, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += 4;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeVInt(int v) {
        int size = 0;
        while ((v & ~0x7F) != 0) {
            write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        }
        write((byte) v);
        return size + 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeLong(long v) {
        UnsafeHelper.writeLong(v, buffers, capacity, indexOfBufferShift,
                offsetInBufferMask, pos, false);
        pos += 8;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeVLong(long v) {
        int size = 0;
        while ((v & ~(long) 0x7F) != 0) {
            write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        }
        write((byte) v);
        return size + 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFloat(float v) {
        writeInt(Float.floatToIntBits(v));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeDouble(double v) {
        writeLong(Double.doubleToLongBits(v));
    }
}
