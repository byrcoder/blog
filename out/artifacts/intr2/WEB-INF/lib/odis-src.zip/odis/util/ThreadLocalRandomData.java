/**
 * @(#)ThreadLocalRandomData.java, 2012-10-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import org.apache.commons.math3.random.RandomDataImpl;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;

/**
 * Wrapper class of commons-math's RandomDataImpl.
 * 
 * @author zhangduo
 */
public class ThreadLocalRandomData extends RandomDataImpl {

    private static final long serialVersionUID = 121977364445562025L;

    private final RandomGenerator rand;

    private static final ThreadLocal<ThreadLocalRandomData> localRandom = new ThreadLocal<ThreadLocalRandomData>() {

        @Override
        protected ThreadLocalRandomData initialValue() {
            return new ThreadLocalRandomData(new Well19937c(
                    System.currentTimeMillis()
                            + System.identityHashCode(Thread.currentThread())));
        }

    };

    private ThreadLocalRandomData(RandomGenerator rand) {
        super(rand);
        this.rand = rand;
    }

    /**
     * Return the RandomData Object for current thread.
     * 
     * @return
     */
    public static ThreadLocalRandomData current() {
        return localRandom.get();
    }

    /**
     * Returns a pseudorandom, uniformly distributed {@code int} value between 0
     * (inclusive) and the specified value (exclusive)
     * 
     * @param n
     * @return
     */
    public int nextInt(int n) {
        return n == 1 ? 0 : super.nextInt(0, n - 1);
    }

    /**
     * Returns a pseudorandom, uniformly distributed {@code long} value between
     * 0 (inclusive) and the specified value (exclusive)
     * 
     * @param n
     * @return
     */
    public long nextLong(long n) {
        return n == 1 ? 0 : super.nextLong(0, n - 1);
    }

    /**
     * Returns the next pseudorandom, uniformly distributed <code>int</code>
     * value from this random number generator's sequence. All 2<font
     * size="-1"><sup>32</sup></font> possible <tt>int</tt> values should be
     * produced with (approximately) equal probability.
     * 
     * @return
     */
    public int nextInt() {
        return rand.nextInt();
    }

    /**
     * Returns the next pseudorandom, uniformly distributed <code>long</code>
     * value from this random number generator's sequence. All 2<font
     * size="-1"><sup>64</sup></font> possible <tt>long</tt> values should be
     * produced with (approximately) equal probability.
     * 
     * @return
     */
    public long nextLong() {
        return rand.nextLong();
    }

    /**
     * Generates random bytes and places them into a user-supplied byte array.
     * The number of random bytes produced is equal to the length of the byte
     * array.
     * 
     * @param bytes
     */
    public void nextBytes(byte[] bytes) {
        nextBytes(bytes, 0, bytes.length);
    }

    /**
     * Generates random bytes and places them into the range of a user-supplied
     * byte array.
     * 
     * @param bytes
     * @param off
     * @param len
     */
    public void nextBytes(byte[] bytes, int off, int len) {
        for (int i = 0; i < len;) {
            for (int rnd = nextInt(), n = Math.min(len - i, Integer.SIZE
                    / Byte.SIZE); n-- > 0; rnd >>= Byte.SIZE, i++) {
                bytes[off + i] = (byte) rnd;
            }
        }
    }
}
