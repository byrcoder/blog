/**
 * @(#)RandomAccessFileBufferCDataOutputStream.java, 2013-8-17. 
 * 
 * Copyright 2013 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.IOException;

import odis.io.CDataOutputStream;

/**
 * A CDataOutputStream with several RandomAccessFileBuffer as its buffer.
 * 
 * @author zhangduo
 */
public class RandomAccessFileBufferCDataOutputStream extends
        BufferCDataOutputStream<RandomAccessFileBuffer> {

    private final byte[] buffer;

    /**
     * Construct a RandomAccessFileBufferCDataOutputStream.
     * 
     * @param buffers
     * @param bufferSize
     * @see BufferCDataOutputStream#BufferCDataOutputStream(AbstractBuffer[],
     *      long)
     */
    public RandomAccessFileBufferCDataOutputStream(
            RandomAccessFileBuffer[] buffers, long bufferSize) {
        super(buffers, bufferSize);
        buffer = new byte[10];
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeShort(int v) throws IOException {
        CDataOutputStream.writeShort(v, buffer, 0);
        write(buffer, 0, 2);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeInt(int v) throws IOException {
        CDataOutputStream.writeInt(v, buffer, 0);
        write(buffer, 0, 4);
    }

    /**
     * @see CDataOutputStream#writeVInt(int)
     */
    public int writeVInt(int v) throws IOException {
        int size = CDataOutputStream.writeVInt(v, buffer, 0);
        write(buffer, 0, size);
        return size;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeLong(long v) throws IOException {
        CDataOutputStream.writeLong(v, buffer, 0);
        write(buffer, 0, 8);
    }

    /**
     * @see CDataOutputStream#writeVLong(long)
     */
    public int writeVLong(long v) throws IOException {
        int size = CDataOutputStream.writeVLong(v, buffer, 0);
        write(buffer, 0, size);
        return size;
    }

}
