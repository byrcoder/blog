package odis.util;

import odis.conf.OdisLibConfig;

/**
 * The utilities for manipulating OS processes
 * 
 * @author xxx, david
 */
public class ProcessUtils {
    /**
     * Load the lib, on windows os, load "lib/libprocessutils.dll"; on linux os,
     * load "libprocessutils.*arch*.so".
     */
    static {
        OdisLibConfig.loadNativeLib("processutils");
    }

    /**
     * Returns the current PID(process ID)
     * 
     * @return the current PID(process ID)
     */
    public static native int getPid();
}
