/**
 * @(#)MergeSorter.java, 2008-7-30. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;

/**
 * This is a {@link TreeMap} wrapper which store the value as {@link Pair}, the
 * original value is stored in value list in pair.
 * <p>
 * If multiply values for same key are put into sorter by
 * {@link #put(Object, Object)}, all the values are stored in the pair for the
 * key, and later you can remove the key and value out by invoking
 * {@link #remove()}.
 * 
 * @author river
 */
public class MultiValueTreeMapSorter<K, V> {
    private TreeMap<K, Pair> map;

    private Pair freeList = null;

    /**
     * Constructor. The key type should be comparable.
     */
    public MultiValueTreeMapSorter() {
        map = new TreeMap<K, Pair>();
    }

    /**
     * Constructor with comparator.
     * 
     * @param keyComp
     */
    public MultiValueTreeMapSorter(Comparator<K> keyComp) {
        map = new TreeMap<K, Pair>(keyComp);
    }

    /**
     * Put key and value into sorter. If there's value previously put into the
     * sorter, the old value should be stored with the new value in pair.
     * 
     * @param key
     * @param value
     */
    public void put(K key, V value) {
        Pair newPair;
        if (freeList != null) {
            newPair = freeList;
            freeList = freeList.next;
        } else {
            newPair = new Pair();
        }

        newPair.key = key;
        newPair.values.add(value);

        Pair oldPair = map.put(key, newPair);
        if (oldPair != null) {
            newPair.values.addAll(oldPair.values);
            releasePair(oldPair);
        }
    }

    /**
     * Return the count of different keys in sorter.
     * 
     * @return
     */
    public int size() {
        return map.size();
    }

    /**
     * Return if the sorter has any key.
     * 
     * @return
     */
    public boolean isEmpty() {
        return map.isEmpty();
    }

    /**
     * Remove the first pair from sorter. The returned value is one {@link Pair}
     * , which contains the key and values. After the returned pair used, please
     * call {@link #releasePair(odis.util.MultiValueTreeMapSorter.Pair)} to
     * release the pair into pair buffer, which will help to reduce the new
     * object allocation and improve the performance.
     * 
     * @return the key and values pair
     */
    public Pair remove() {
        if (map.isEmpty()) {
            return null;
        }
        K firstKey = map.firstKey();
        return map.remove(firstKey);
    }

    /**
     * Release useless pair into pair buffer.
     * 
     * @param p
     */
    public void releasePair(Pair p) {
        p.clear();
        p.next = freeList;
        freeList = p;
    }

    /**
     * Object to store key and multiple values.
     * 
     * @author river
     */
    public class Pair {
        K key;

        List<V> values = new ArrayList<V>();

        Pair next = null; // link for free list

        /**
         * This method is called by
         * {@link MultiValueTreeMapSorter#releasePair(odis.util.MultiValueTreeMapSorter.Pair)}
         * to clear the pair before putting it into buffer.
         */
        void clear() {
            this.key = null;
            this.values.clear();
        }

        /**
         * Return the key.
         * 
         * @return
         */
        public K getKey() {
            return key;
        }

        /**
         * Return the value list.
         * 
         * @return
         */
        public List<V> getValues() {
            return values;
        }

    }

}
