/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 12, 2005
 */
package odis.pexec;

/**
 * A call back class for background receiving of data from another host.
 * 
 * @author zf
 */
public interface PExecReceiver {

    /**
     * Processes the call from another host.
     * 
     * @param orig
     *            index of the originating node
     */
    public void process(Object data, int orig);
}
