package odis.pexec;

/**
 * PExecException, a subclass of RuntimeException
 * 
 * @author guodd
 */
@SuppressWarnings("serial")
public class PExecException extends RuntimeException {
    /**
     * construct a <code>PExecException</code> with message m
     * 
     * @param m
     *            the message of m
     */
    public PExecException(String m) {
        super(m);
    }
}
