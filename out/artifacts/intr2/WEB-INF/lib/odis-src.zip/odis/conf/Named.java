package odis.conf;

/**
 * Any object implements this interface will with a name.
 * 
 * @author Zig
 * @version 2006-2-18
 */
public interface Named {
    /**
     * This method will return the name of the named object.
     * 
     * @return The name.
     */
    String getName();
}
