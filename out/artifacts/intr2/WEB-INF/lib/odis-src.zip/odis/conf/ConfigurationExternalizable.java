package odis.conf;

import org.apache.commons.configuration.Configuration;

/**
 * The interface indicating this configuration is externalizable.
 * 
 * @author Zig
 * @version Apr 15, 2006
 */
public interface ConfigurationExternalizable {
    /**
     * write configures to given config.
     * 
     * @param config
     */
    void writeConfig(Configuration config);
}
