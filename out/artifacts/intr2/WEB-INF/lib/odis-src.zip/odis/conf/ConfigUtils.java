/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 12, 2006
 */
package odis.conf;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import odis.util.MiscUtils;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.HierarchicalConfiguration.Node;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;
import org.apache.commons.configuration.XMLConfiguration;

import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;
import toolbox.text.util.StringUtils;

/**
 * Utilities for handling config files.
 * 
 * @author zf This class contains some helper functions which the Configuration
 *         class doesn't contain.
 * @author Zig
 * @version 2006-2-17
 */
public class ConfigUtils {

    private static final Logger LOG = LogFormatter.getLogger(ConfigUtils.class.getName());

    /**
     * Parse the property configuration file.
     * 
     * @param confDir
     * @param fileName
     * @return
     * @throws ConfigurationException
     */
    public static CompositeConfiguration parsePropertyConfig(File confDir,
            String[] fileName) throws ConfigurationException {
        CompositeConfiguration config = new CompositeConfiguration();
        for (int i = 0; i < fileName.length; i++) {
            File configFile = new File(confDir, fileName[i]);
            if (configFile.exists()) {
                LOG.fine("Loading config from " + configFile.getAbsolutePath());
                PropertiesConfiguration thisConf = new PropertiesConfiguration(
                        configFile);
                // clear keys to be added by this conf file
                HashSet<String> removeKeys = new HashSet<String>();
                @SuppressWarnings("rawtypes")
                Iterator it = config.getKeys();
                while (it.hasNext()) {
                    String key = (String) (it.next());
                    if (thisConf.containsKey(key)) {
                        removeKeys.add(key);
                    }
                }
                for (String key: removeKeys) {
                    config.clearProperty(key);
                }
                // add this conf file
                config.addConfiguration(thisConf);
            } else
                LOG.fine("Ignoring config file " + configFile.getAbsolutePath()
                        + " because it does not exist");
        }
        // allow users to override on command line
        config.addConfiguration(new SystemConfiguration());
        return config;
    }

    /**
     * Parse the xml-configure file
     * 
     * @param confDir
     * @param fileName
     * @return
     * @throws ConfigurationException
     */
    public static CompositeConfiguration parseXmlConfig(File confDir,
            String[] fileName) throws ConfigurationException {
        CompositeConfiguration config = new CompositeConfiguration();
        for (int i = 0; i < fileName.length; i++) {
            File xmlFile = new File(confDir, fileName[i]);
            if (xmlFile.exists()) {
                LOG.fine("Loading config from " + xmlFile.getAbsolutePath());
                XMLConfiguration thisConf = new XMLConfiguration(xmlFile);
                // clear keys to be added by this conf file
                HashSet<String> removeKeys = new HashSet<String>();
                @SuppressWarnings("rawtypes")
                Iterator it = config.getKeys();
                while (it.hasNext()) {
                    String key = (String) (it.next());
                    if (thisConf.containsKey(key)) {
                        removeKeys.add(key);
                    }
                }
                for (String key: removeKeys) {
                    config.clearProperty(key);
                }
                // add this conf file
                config.addConfiguration(thisConf);
            } else
                LOG.fine("Ignoring config file " + xmlFile.getAbsolutePath()
                        + " because it does not exist.");
        }
        return config;
    }

    /**
     * Create a object from <code>config</code>. The type of the object is
     * defined in the configuration. This method will do the following flow:
     * <p/>
     * <ol>
     * <li>According to &quot;<code>keyName[@name]</code>&quot;, read out the
     * name of object to create.</li>
     * <li>According to &quot;<code>keyName[@class]</code>&quot;, read out the
     * type of object to create.</li>
     * <li>Call
     * {@link ConfigUtils#createObjectInternal(org.apache.commons.configuration.Configuration, String, String, Object...)}
     * to create the object.</li>
     * </ol>
     * 
     * @param config
     *            The configuration for object.
     * @param keyName
     *            The key name for object to read name and class from.
     * @param params
     *            The other parameters for constructing the object.
     * @return The created object.
     */
    public static Object createObject(Configuration config, String keyName,
            Object... params) {
        String className = config.getString(keyName + "[@class]");
        String name = config.getString(keyName + "[@name]");

        if (className == null) {
            throw new RuntimeException("Cannot find class name in " + keyName
                    + ", specify it with 'class'");
        }

        return createObjectInternal(config, name, className, params);
    }

    /**
     * Create an array of objects.
     * 
     * @param config
     *            The configuration for use.
     * @param name
     *            The name for identify objects.
     * @param aClass
     *            The type of the array element.
     * @return The array created.
     */
    public static Object createObjectArray(Configuration config, String name,
            Class<?> aClass) {
        String[] names = config.getStringArray(name + "[@name]");
        String[] classNames = config.getStringArray(name + "[@class]");

        int n = classNames.length;
        Object a = Array.newInstance(aClass, n);

        for (int i = 0; i < n; i++) {
            Array.set(a, i,
                    createObjectInternal(config, names[i], classNames[i]));
        }

        return a;
    }

    /**
     * This class will do the actual creation process. It will do the following
     * process:
     * <p/>
     * <ol>
     * <li>Create an object with type <code>className</code>, and use the
     * constructor with parameters <code>params</code>.</li>
     * <li>If the object is {@link Named}, assign the name.</li>
     * <li>If the object is {@link Configurable}, call the configure method with
     * Configuration as <code>config.subset(name)</code>. In this way, objects
     * can configure their components recursively.</li>
     * </ol>
     * 
     * @param config
     *            The configuration.
     * @param name
     *            The name of the object.
     * @param className
     *            The class of the object.
     * @param params
     *            The other parameters for calling the constructor.
     * @return The created object.
     */
    @SuppressWarnings("unchecked")
    private static Object createObjectInternal(Configuration config,
            String name, String className, Object... params) {
        @SuppressWarnings("rawtypes")
        Class clazz;
        try {
            clazz = Class.forName(className);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }

        Object[] newparams;

        if (Named.class.isAssignableFrom(clazz)) {
            newparams = new Object[params.length + 1];
            System.arraycopy(params, 0, newparams, 1, params.length);
            newparams[0] = name;
        } else {
            newparams = params;
        }

        params = newparams;

        Object obj = null;

        try {
            @SuppressWarnings("rawtypes")
            Class[] classes = new Class[params.length];
            for (int i = 0; i < params.length; i++) {
                classes[i] = params[i].getClass();
            }

            @SuppressWarnings("rawtypes")
            Constructor constructor = null;
            try {
                constructor = clazz.getConstructor();
            } catch (NoSuchMethodException e) {}

            if (constructor == null) {
                /* a hook, i don't know whether it is graceful, yemingjiang */
                @SuppressWarnings("rawtypes")
                Constructor[] constructors = clazz.getConstructors();
                for (int i = 0; i < constructors.length; i++) {
                    @SuppressWarnings("rawtypes")
                    Class[] declParams = constructors[i].getParameterTypes();
                    if (declParams.length != params.length)
                        continue;
                    for (int j = 0; j < declParams.length; j++) {
                        if (!declParams[i].isAssignableFrom(classes[i])) {
                            continue;
                        }
                    }
                    obj = constructors[i].newInstance(params);
                    break;
                }
            } else
                obj = constructor.newInstance(params);

            if (obj == null) {
                System.out.println("no corresponding construcotr for "
                        + className);
                return null;
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "create object failed", e);
            return null;
        }

        if (obj instanceof Configurable) {
            Configurable configurable = (Configurable) obj;
            Configuration sconfig = config.subset(name);
            configurable.configure(sconfig);
        }

        return obj;
    }

    /**
     * Convert a string representation of a {@link Configuration} object into a
     * new Configuration. Just the reverse process of the
     * {@link ConfigUtils#saveConfig(org.apache.commons.configuration.Configuration)}
     * method.
     * 
     * @param content
     *            The String representation.
     * @return The new Configuration object.
     */
    public static Configuration readConfig(String content) {
        try {
            ByteArrayInputStream bst = new ByteArrayInputStream(
                    HexString.hexToBytes(content));
            GZIPInputStream st = new GZIPInputStream(bst);
            InputStreamReader sr = new InputStreamReader(st);
            try {
                PropertiesConfiguration config = new PropertiesConfiguration();
                config.load(sr);
                return config;
            } finally {
                MiscUtils.safeClose(sr);
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "read config failed", e);
            return null;
        }
    }

    /**
     * Convert a {@link Configuration} object into a String. So that we can
     * transmit this String.
     * <p/>
     * Flow:
     * <ol>
     * <li>First copy the data from <code>config</code> into a new configuration
     * object. Here it is a {@link PropertiesConfiguration} object.</li>
     * <li>Then write all of the contents into a new
     * {@link ByteArrayOutputStream} and GZIP it.</li>
     * <li>Transform the byte array into a hex representation.</li>
     * </ol>
     * 
     * @param config
     *            The configuration.
     * @return a String representation of the configuration.
     */
    public static String saveConfig(Configuration config) {
        PropertiesConfiguration conf = new PropertiesConfiguration();

        @SuppressWarnings("rawtypes")
        Iterator keyIter = config.getKeys();
        while (keyIter.hasNext()) {
            String key = (String) keyIter.next();
            conf.addProperty(key, config.getProperty(key));
        }

        try {
            ByteArrayOutputStream bst = new ByteArrayOutputStream();
            GZIPOutputStream st = new GZIPOutputStream(bst);
            OutputStreamWriter sw = new OutputStreamWriter(st);

            try {
                conf.save(sw);
                return HexString.bytesToHexNoSpace(bst.toByteArray());
            } finally {
                MiscUtils.safeClose(sw);
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "save config failed", e);
            return null;
        }

    }

    /**
     * This method serialize object <code>obj</code> into configuration
     * <code>config</code> with given keyName.
     * 
     * @param config
     *            The config.
     * @param keyName
     *            The key name for storing the content.
     * @param obj
     *            The object.
     */
    public static void writeObject(Configuration config, String keyName,
            Object obj) {
        if (obj instanceof ConfigurationSerializable) {
            throw new RuntimeException("Unimplemented.");
        }
        if (obj instanceof ConfigurationExternalizable) {
            String name = StringUtils.randomString(10);
            config.setProperty(keyName + "[@name]", name);
            config.setProperty(keyName + "[@class]", obj.getClass().getName());
            ((ConfigurationExternalizable) obj).writeConfig(config.subset(name));
        } else {
            throw new RuntimeException("Do not know how to serialize.");
        }
    }

    /**
     * Merge two subset for the given Configuration to one
     * CompositeConfiguration.
     * 
     * @param config
     * @param subset1
     * @param subset2
     * @return
     */
    public static Configuration getMergedSubConfiguration(Configuration config,
            String subset1, String subset2) {
        CompositeConfiguration cc = new CompositeConfiguration();
        cc.addConfiguration(config.subset(subset1));
        cc.addConfiguration(config.subset(subset2));
        return cc;
    }

    /**
     * Add two Configuration to a CompositeConfiguration.
     */
    public static Configuration getMergedSubConfiguration(
            Configuration config1, Configuration config2) {
        CompositeConfiguration cc = new CompositeConfiguration();
        cc.addConfiguration(config1);
        cc.addConfiguration(config2);
        return cc;
    }

    /**
     * Copy attributes match the pattern from one configuration to another.
     * 
     * @param src
     * @param dest
     * @param regex
     */
    public static void copyConfig(Configuration src, Configuration dst,
            String regex) {
        copyConfig(src, dst, regex, "");
    }

    /**
     * Copy configuration from one to another, this tool will handle
     * hierarchical structure.
     * 
     * @param src
     * @param dst
     * @param prefix
     * @param dstPrefix
     * @param nameSet
     */
    private static void copySubConfig(Configuration src, Configuration dst,
            String prefix, String dstPrefix, Set<String> nameSet) {
        int prefixLength = prefix.length();

        if (dst instanceof HierarchicalConfiguration) {
            if (src instanceof CompositeConfiguration) {
                CompositeConfiguration compConfig = (CompositeConfiguration) src;
                for (int i = compConfig.getNumberOfConfigurations() - 1; i >= 0; i--) {
                    copySubConfig(compConfig.getConfiguration(i), dst, prefix,
                            dstPrefix, nameSet);
                }
                return;
            } else if (src instanceof HierarchicalConfiguration) {
                // clear config in destination
                for (@SuppressWarnings("rawtypes")
                Iterator it = src.getKeys(); it.hasNext();) {
                    String name = (String) it.next();
                    if (!name.startsWith(prefix)) {
                        continue;
                    }

                    if (!nameSet.contains(name)) {
                        String realName = dstPrefix
                                + name.substring(prefixLength);
                        dst.clearProperty(realName);
                        nameSet.add(name);
                    }
                }

                // copy nodes
                HierarchicalConfiguration sConfig = (HierarchicalConfiguration) src;
                HierarchicalConfiguration dConfig = (HierarchicalConfiguration) dst;
                @SuppressWarnings("rawtypes")
                List subConfs = sConfig.configurationsAt(prefix);
                for (Object o: subConfs) {
                    HierarchicalConfiguration sub = (HierarchicalConfiguration) o;
                    ArrayList<Node> nodes = new ArrayList<Node>();
                    for (Object o1: sub.getRootNode().getChildren()) {
                        Node node = (Node) o1;
                        nodes.add(node);
                    }
                    dConfig.addNodes(dstPrefix, nodes);
                }
                return;
            }
        }

        for (@SuppressWarnings("rawtypes")
        Iterator it = src.getKeys(); it.hasNext();) {
            String name = (String) it.next();
            if (!name.startsWith(prefix)) {
                continue;
            }

            if (!nameSet.contains(name)) {
                dst.clearProperty(name);
                nameSet.add(name);
            }

            @SuppressWarnings("rawtypes")
            List list = src.getList(name);
            String realName = name;
            if (!dstPrefix.equals(prefix)) {
                realName = dstPrefix + name.substring(prefix.length());
            }
            for (Object value: list) {
                dst.addProperty(realName, value);
            }
        }
    }

    /**
     * Copy configuration from one to another, this tool will handle
     * hierarchical structure.
     * 
     * @param src
     * @param dst
     * @param srcPrefix
     * @param dstPrefix
     */
    public static void copySubConfig(Configuration src, Configuration dst,
            String srcPrefix, String dstPrefix) {
        HashSet<String> nameSet = new HashSet<String>();
        copySubConfig(src, dst, srcPrefix, dstPrefix, nameSet);
    }

    /**
     * Copy attributes match the pattern from one configuration to another, and
     * remove the given prefix.
     * 
     * @param src
     * @param dst
     * @param regex
     * @param removePrefix
     */
    public static void copyConfig(Configuration src, Configuration dst,
            String regex, String removePrefix) {
        Pattern p = Pattern.compile(regex);
        for (@SuppressWarnings("rawtypes")
        Iterator it = src.getKeys(); it.hasNext();) {
            String name = (String) it.next();
            if (p.matcher(name).matches()) {
                if (removePrefix.length() > 0 && name.startsWith(removePrefix)) {
                    name = name.substring(removePrefix.length());
                }
                dst.setProperty(name, src.getProperty(name));
            }
        }
    }

}
