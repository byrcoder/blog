package odis.conf;

/**
 * This is a mark-up interface just like {@link java.io.Serializable}.
 * 
 * @author Zig
 * @version May 3, 2006
 */
public class ConfigurationSerializable {
}
