/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 14, 2006
 */
package odis.file;

import odis.serialize.IWritable;

/**
 * An interface to compare pairs of (key,value).
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu), David
 */
public interface IRecordComparator {
    /**
     * Compares two key-value pair instances.
     * 
     * @param key1
     *            the first key
     * @param value1
     *            the first value
     * @param key2
     *            the second key
     * @param value2
     *            the second value
     * @return -1 if key1-value1 is less than key2-value2, 1 if key1-value1 is
     *         greater than key2-value2, 0 of they are equal
     */
    public int compare(IWritable key1, IWritable value1, IWritable key2,
            IWritable value2);

    /**
     * Compares two key-value pairs given binary buffer. For each pair, key data
     * and value data are stored in turn.
     * 
     * @param buffer1
     *            the buffer for first pair
     * @param start1
     *            the start offset of the first key
     * @param keyLength1
     *            the number of bytes for the first key
     * @param valLength1
     *            the number of bytes for the first value
     * @param buffer2
     *            the buffer for seconde pair
     * @param start2
     *            the start offset of the seconde key
     * @param keyLength2
     *            the number of bytes for the seconde key
     * @param valLength2
     *            the number of bytes for the seconde value
     * @return -1 if key1-value1 is less than key2-value2, 1 if key1-value1 is
     *         greater than key2-value2, 0 of they are equal
     */
    public int compare(byte[] buffer1, int start1, int keyLength1,
            int valLength1, byte[] buffer2, int start2, int keyLength2,
            int valLength2);

    /**
     * Returns the class of the key.
     * 
     * @return the class of the key
     */
    public Class<?> getKeyClass();

    /**
     * Returns the class of the value.
     * 
     * @return the class of the value
     */
    public Class<?> getValClass();

}
