package odis.file;

import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;

import odis.file.IRecordReader;
import odis.serialize.IMutable;
import toolbox.misc.ClassUtils;

/**
 * A merger that merges multi-way sources. Usage: This implements the
 * IRecordReader interface, so use IRecordReader's methods. MultiWayMerger
 * merger = new MultiWayMerger(sources, keyComp, valComp); while
 * (merger.next(key, val)) { ... } // while merger.close();
 * 
 * @author David
 */
public class MultiWayMerger implements IRecordReader {
    private static final int BEFORE_FIRST = -1;

    private static final int AFTER_LAST = -2;

    IRecordReader[] srcs;

    IMutable<?>[] keys;

    IMutable<?>[] vals;

    PriorityQueue<Integer> q;

    long size;

    /**
     * Constructor.
     * 
     * @param srcs
     *            the array of source record-readers. These readers will be
     *            closed when MultiWayMerger.close() is called.
     * @param keyComp
     *            the comparator for keys. If null, the key-class should be
     *            Comparable.
     * @param valComp
     *            if comparator for values. If null, values are not compareed.
     * @throws IOException
     *             if an I/O error occurs
     */
    @SuppressWarnings("unchecked")
    public MultiWayMerger(IRecordReader[] srcs, Comparator<?> keyComp,
            final Comparator<?> valComp) throws IOException {
        this.srcs = srcs;
        if (keyComp == null) {
            if (Comparable.class.isAssignableFrom(srcs[0].getKeyClass())) {
                keyComp = new Comparator<Comparable<?>>() {
                    @SuppressWarnings("unchecked")
                    public int compare(Comparable o1, Comparable o2) {
                        return o1.compareTo(o2);
                    }
                };
            } else
                throw new RuntimeException("Either keyComp need to be non-"
                        + "null or key is a Comparable class.");
        } // if
        final Comparator keyCmp = keyComp;
        q = new PriorityQueue<Integer>(srcs.length, new Comparator<Integer>() {
            public int compare(Integer arg0, Integer arg1) {
                int cmp = keyCmp.compare(keys[arg0], keys[arg1]);
                if (cmp != 0)
                    return cmp;

                if (valComp != null)
                    cmp = ((Comparator) valComp)
                            .compare(vals[arg0], vals[arg1]);
                return cmp;
            }
        });

        if (!IMutable.class.isAssignableFrom(srcs[0].getKeyClass())
                || !IMutable.class.isAssignableFrom(srcs[0].getValueClass()))
            throw new RuntimeException("Only support IMultable key/value, "
                    + "while one/both of " + srcs[0].getKeyClass() + "/"
                    + srcs[0].getValueClass() + " is not.");

        keys = new IMutable[srcs.length];
        vals = new IMutable[srcs.length];

        for (int i = 0; i < srcs.length; i++) {
            keys[i] = (IMutable) ClassUtils.newInstance(srcs[i].getKeyClass());
            vals[i] = (IMutable) ClassUtils
                    .newInstance(srcs[i].getValueClass());

            if (srcs[i].next(keys[i], vals[i]))
                q.add(i);
        } // for i
        current = BEFORE_FIRST;
        size = 0;
        for (int i = 0; i < srcs.length; i++)
            size += srcs[i].getSize();
    }

    @Override
    public void close() throws IOException {
        for (int i = 0; i < srcs.length; i++)
            srcs[i].close();
    }

    @Override
    public Class<?> getKeyClass() {
        return srcs[0].getKeyClass();
    }

    /**
     * This function returns the possition read not the possition of the current
     * data.
     */
    public long getPos() throws IOException {
        int pos = 0;
        for (int i = 0; i < srcs.length; i++)
            pos += srcs[i].getPos();
        return pos;
    }

    @Override
    public long getSize() throws IOException {
        return size;
    }

    @Override
    public Class<?> getValueClass() {
        return srcs[0].getValueClass();
    }

    int current;

    /**
     * Iterates to next key/value
     * 
     * @return true if the current key/value are available after calling, false
     *         otherwise.
     * @throws IOException
     *             if an I/O error occurs
     */
    public boolean moveToNext() throws IOException {
        if (current == AFTER_LAST)
            return false;
        if (current != BEFORE_FIRST) {
            if (srcs[current].next(keys[current], vals[current]))
                q.add(current);
        } // if
        if (q.isEmpty()) {
            current = AFTER_LAST;
            return false;
        } // if

        current = q.poll();
        return true;
    }

    /**
     * Returns the instance of the current key. The caller should copy the
     * contents out before moving the pointer of the reader.
     * 
     * @return the instance of the current key, null if no data avialalbe
     */
    public Object getCurrentKey() {
        return current < 0 ? null : keys[current];
    }

    /**
     * Returns the instance of the current value. The caller should copy the
     * contents out before moving the pointer of the reader.
     * 
     * @return the instance of the current value, null if no data avialalbe
     */
    public Object getCurrentVal() {
        return current < 0 ? null : vals[current];
    }

    @SuppressWarnings("unchecked")
    public boolean next(Object key, Object val) throws IOException {
        if (!moveToNext())
            return false;

        ((IMutable) key).copyFields(keys[current]);
        ((IMutable) val).copyFields(vals[current]);

        return true;
    }
}
