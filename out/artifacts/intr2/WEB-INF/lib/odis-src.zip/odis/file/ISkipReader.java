package odis.file;

import java.io.IOException;

/**
 * The reader for skip reading.
 * 
 * @author guodd
 */
public interface ISkipReader<K, V> {

    /**
     * Iterating the objects, return the key and value until key is greater or
     * equals to target.
     * 
     * @param target
     * @param key
     * @param value
     * @return
     * @throws IOException
     */
    public boolean next(K target, K key, V value) throws IOException;

}
