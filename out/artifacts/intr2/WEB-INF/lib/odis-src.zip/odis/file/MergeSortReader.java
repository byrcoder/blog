package odis.file;

import java.io.IOException;
import java.util.PriorityQueue;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

/**
 * A sequence reader reads from a few readers backed by sorted sequence files,
 * and provides merge-sorted data.
 * 
 * @author zhangkun
 */
public class MergeSortReader implements IRecordReader {
    private final IRecordReader[] readers;

    private final PriorityQueue<PQElement> pQueue;

    private final Class<? extends IWritableComparable> keyClass;

    private final Class<? extends IWritable> valueClass;

    private static class PQElement implements Comparable<PQElement> {
        final IWritableComparable key;

        final IWritable value;

        final int idx;

        public PQElement(IWritableComparable key, IWritable value, int idx) {
            this.key = key;
            this.value = value;
            this.idx = idx;
        }

        public int compareTo(PQElement o) {
            int ret = this.key.compareTo(o.key);
            if (ret != 0) {
                return ret;
            } else {
                return this.idx - o.idx;
            }
        }

        @Override
        public int hashCode() {
            return key.hashCode() ^ idx;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null || obj.getClass() != getClass()) {
                return false;
            }
            return compareTo((PQElement) obj) == 0;
        }

    }

    /**
     * The constructor.
     * 
     * @param readers
     *            input readers for MergeSort
     */
    @SuppressWarnings("unchecked")
    public MergeSortReader(IRecordReader[] readers) {
        this.readers = readers;
        pQueue = new PriorityQueue<PQElement>();
        keyClass = readers[0].getKeyClass();
        valueClass = readers[0].getValueClass();
        for (int i = 0; i < readers.length; i++) {
            IRecordReader reader = readers[i];
            if (!keyClass.equals(reader.getKeyClass())) {
                throw new RuntimeException("file " + reader + " has key of "
                        + reader.getKeyClass() + ", should be " + keyClass);
            }
            if (!valueClass.equals(reader.getValueClass())) {
                throw new RuntimeException("file " + reader + " has value of "
                        + reader.getValueClass() + ", should be " + valueClass);
            }
            // initially fill the queue
            try {
                PQElement e = new PQElement(keyClass.newInstance(),
                        valueClass.newInstance(), i);
                fillQueue(e);
            } catch (Exception e) {
                if (e instanceof RuntimeException) {
                    throw (RuntimeException) e;
                } else {
                    throw new RuntimeException(e);
                }
            }
        }

    }

    @Override
    public void close() throws IOException {
        for (IRecordReader reader: readers) {
            reader.close();
        }
    }

    @Override
    public Class<? extends IWritableComparable> getKeyClass() {
        return keyClass;
    }

    // FIXME: the pos is not right because we may prefetch some records...
    @Override
    public long getPos() throws IOException {
        long pos = 0;
        for (IRecordReader reader: readers) {
            pos += reader.getPos();
        }
        return pos;
    }

    @Override
    public long getSize() throws IOException {
        long size = 0;
        for (IRecordReader reader: readers) {
            size += reader.getSize();
        }
        return size;
    }

    @Override
    public Class<? extends IWritable> getValueClass() {
        return valueClass;
    }

    private void fillQueue(PQElement reusedElement) throws IOException {
        boolean hasNext = readers[reusedElement.idx].next(reusedElement.key,
                reusedElement.value);
        if (hasNext) {
            pQueue.add(reusedElement);
        }
    }

    @Override
    public boolean next(Object key, Object value) throws IOException {
        if (pQueue.isEmpty()) {
            return false;
        }
        PQElement next = pQueue.poll();
        ((IWritable) key).copyFields(next.key);
        ((IWritable) value).copyFields(next.value);
        fillQueue(next);
        return true;
    }

}
