package odis.file;

/**
 * An abstract class for writing asynchronized job. Usage: public class
 * MyAsyncWork extends AsyncWork { protected boolean hasJob() { ... } protected
 * void pollJob() { ... } protected boolean runJob() throws Exception { ... }
 * protected void passJob(Object... objects) { ... } }; MyAsyncWork work = new
 * MyAsyncWork(); work.addJob(); work.addJob(); work.stopWork();
 * 
 * @author david
 */
public abstract class AsyncWork extends Thread {
    /**
     * The work just starts, not in run() loop yet
     */
    public static final int STATUS_READY = 0;

    /**
     * The working thread is checking or waiting for a new job.
     */
    public static final int STATUS_WAITING = 1;

    /**
     * The working thread is running a job
     */
    public static final int STATUS_RUNNING = 2;

    /**
     * The working thread has quitted from the loop
     */
    public static final int STATUS_STOPPED = 3;

    Object sync;

    protected boolean stopping = false;

    protected boolean stopNow = false;

    protected int threadStatus = STATUS_READY;

    protected Throwable exception = null;

    /**
     * The constructor.
     * 
     * @param isDaemon
     *            whether this thread is a daemon
     */
    public AsyncWork(boolean isDaemon) {
        this(isDaemon, null);
    }

    /**
     * The constructor.
     * 
     * @param isDaemon
     *            whether this thread is a daemon
     * @param sync
     *            the instance for synchronization. If null, use this.
     */
    public AsyncWork(boolean isDaemon, Object sync) {
        this("Async-Work", isDaemon, sync);
    }

    /**
     * The constructor.
     * 
     * @param name
     *            the name of the thread. Setting this may help debugging.
     * @param isDaemon
     *            whether this thread is a daemon
     * @param sync
     *            the instance for synchronization. If null, use this.
     */
    public AsyncWork(String name, boolean isDaemon, Object sync) {
        super(name);
        this.setDaemon(isDaemon);
        if (sync == null)
            this.sync = this;
        else
            this.sync = sync;
    }

    /**
     * Checks whether there is at least one job for working thread to run. This
     * method is called in both the working thread and main thread within
     * synchronization.
     * 
     * @return whether the work-thread has a job to run.
     */
    protected abstract boolean hasJob();

    /**
     * Fetches a job (maybe in a pending list) for the working thread. This
     * method is called in the working thread within synchronization.
     */
    protected abstract void pollJob();

    /**
     * Runs the job taken on pollJob. This method is called in the working
     * thread WITHOUT synchronization.
     * 
     * @return true if continue to work, false to make the work-thread quit
     * @throws Exception
     *             if an error occurs. This will cause the working thread quit
     *             and the exception is stored in AsyncWork.exception.
     */
    protected abstract boolean runJob() throws Exception;

    protected void setThreadStatus(int threadStatus) {
        this.threadStatus = threadStatus;
        sync.notifyAll();
    }

    /**
     * Called when the working thread is about to exit
     */
    protected void onWorkExit() {}

    @Override
    public void run() {
        try {
            while (true) {
                synchronized (sync) {
                    setThreadStatus(STATUS_WAITING);

                    while (!stopNow && !stopping && !hasJob()) {
                        sync.wait();
                    } // while

                    if (stopNow || stopping && !hasJob())
                        break;

                    pollJob();

                    setThreadStatus(STATUS_RUNNING);
                } // synchornized

                if (!runJob())
                    break;
            } // while
        } catch (Throwable e) {
            this.exception = e;
        }

        synchronized (sync) {
            onWorkExit();
            setThreadStatus(STATUS_STOPPED);
        }
    }

    /**
     * Stops the work from allowing new jobs to be added and waits for the
     * running and pending jobs to finish
     * 
     * @throws InterruptedException
     *             if the current thread was interrupted
     */
    public void stopWork() throws InterruptedException {
        synchronized (sync) {
            this.stopping = true;
            sync.notifyAll();
        }

        join();
    }

    /**
     * Stops the work now. After the current processing job, the work stops. The
     * pending jobs will be ignored. The method returns after the thread is
     * closed.
     * 
     * @throws InterruptedException
     *             if the current thread was interrupted
     */
    public void stopWorkNow() throws InterruptedException {
        synchronized (sync) {
            this.stopping = true;
            this.stopNow = true;
            sync.notifyAll();
        }

        join();
    }

    /**
     * Passes the job (in objects) to the the work-thread.
     * 
     * @param objects
     *            the job
     */
    protected abstract void passJob(Object... objects);

    /**
     * Checks whether we can pass a job to the working thread or pending list.
     * This method is called in the main thread withing locking. The default
     * implementation assumes no buffer at all. When there is a pending list,
     * the method needs to be overriden.
     * 
     * @return whether we can pass a job to the working thread or pending list
     */
    protected boolean canPassJob() {
        return this.threadStatus == STATUS_WAITING && !hasJob();
    }

    /**
     * Checks if any exception thrown in work thread, throw it if any.
     * 
     * @throws Exception
     *             if an exception was thrown in work thread
     */
    public void checkException() throws Exception {
        if (exception != null) {
            if (exception instanceof Exception)
                throw (Exception) exception;
            else
                throw new RuntimeException(exception);
        } // if
    }

    /**
     * Adds a new job to the working thread.
     * 
     * @param objects
     *            the parameters, will be passed to passJob
     * @return true if successfully added, false otherwise
     * @throws Exception
     *             if any error occurs (in this thread or in work thread)
     */
    public boolean addJob(Object... objects) throws Exception {
        synchronized (sync) {
            // wait
            while (this.threadStatus != STATUS_STOPPED && !canPassJob()) {
                sync.wait();
            } // while
            // until stopped or can-pass job
            // throw exception if any
            checkException();

            if (threadStatus == STATUS_STOPPED) {
                return false;
            } // if

            if (stopping)
                return false;
            /*
             * Since threadStatus != STATUS_STOPPED, canPassJob equals true
             */
            passJob(objects);
            sync.notifyAll();

            return true;
        }
    }
}
