package odis.file;

import java.io.IOException;

import odis.file.IRecordReader;
import odis.serialize.IMutable;

/**
 * A wrapper class implements IRecordReader interface that read
 * records(key-value pairs) asynchronously. Data are read in a different thread
 * as the reader. Usage: <code>
 * ARecordReader aReader = new AsyncRecordReader(reader);
 * while (aReader.next(key, val)) { 
 *     ... 
 * } // while
 * aReader.close();
 * </code>
 * 
 * @author david
 */
public class ARecordReader extends Thread implements IRecordReader {
    IMutable[] keys;

    IMutable[] vals;

    long[] poses;

    int readRecords = 0;

    int startIdx;

    long pos;

    Exception exception;

    IRecordReader reader;

    boolean more;

    boolean isClosed = false;

    private static boolean isCopyFieldBad(IMutable o) {
        if (o.copyFields(o) != o) {
            return true;
        }
        return false;
    }

    /**
     * The constructor with bufferLen set to 1.
     * 
     * @param reader
     *            the reader of the data
     * @throws IOException
     *             if an I/O error occurs
     */
    public ARecordReader(IRecordReader reader) throws IOException {
        this(reader, 1);
    }

    /**
     * The constructor.
     * 
     * @param reader
     *            the reader of the data
     * @param bufferLen
     *            the number of the records in the buffer
     * @throws IOException
     *             if an I/O error occurs
     */
    public ARecordReader(IRecordReader reader, int bufferLen)
            throws IOException {
        super("async-read-thread");
        this.reader = reader;
        /*
         * Assure the key/value classes implement IMutable
         */
        if (!IMutable.class.isAssignableFrom(reader.getKeyClass()))
            throw new IOException("The key class " + reader.getKeyClass()
                    + " does not implement IMutable interface.");
        if (!IMutable.class.isAssignableFrom(reader.getValueClass()))
            throw new IOException("The value class " + reader.getValueClass()
                    + " does not implement IMutable interface.");

        /*
         * Create buffers
         */
        keys = new IMutable[bufferLen];
        vals = new IMutable[bufferLen];
        poses = new long[bufferLen];

        startIdx = 0;
        readRecords = 0;

        try {
            for (int i = 0; i < bufferLen; i++) {
                keys[i] = (IMutable) reader.getKeyClass().newInstance();
                vals[i] = (IMutable) reader.getValueClass().newInstance();
            } // for i
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        /*
         * Check the copyFields function.
         */
        if (isCopyFieldBad(keys[0]))
            throw new IOException("The copyFields of the key class "
                    + reader.getKeyClass() + " is not propertly implemented!");
        if (isCopyFieldBad(vals[0]))
            throw new IOException("The copyFields of the value class "
                    + reader.getValueClass() + " is not propertly implemented!");

        pos = reader.getPos();
        more = true;
        /*
         * Set the current to daeomn and start it
         */
        this.setDaemon(true);
        this.start();
    }

    @Override
    public void run() {
        try {
            IMutable key = (IMutable) reader.getKeyClass().newInstance();
            IMutable val = (IMutable) reader.getValueClass().newInstance();
            while (!isClosed && reader.next(key, val)) {
                synchronized (this) {
                    /*
                     * Wait for an available buffer (i.e. the buffer is not
                     * full-filled or the next() thread read and remove one
                     * record from the buffer)
                     */
                    while (!isClosed && readRecords == keys.length) {
                        wait();
                    } // while

                    if (isClosed)
                        /*
                         * ARecordReader.close() was called, jump out of the
                         * loop
                         */
                        break;

                    /*
                     * Exchange key/val with the key/value in the buffer and
                     * record the position
                     */
                    int lastIdx = (startIdx + readRecords) % keys.length;
                    IMutable tmp;
                    tmp = keys[lastIdx];
                    keys[lastIdx] = key;
                    key = tmp;
                    tmp = vals[lastIdx];
                    vals[lastIdx] = val;
                    val = tmp;
                    poses[lastIdx] = reader.getPos();
                    /*
                     * We've got a new read-record
                     */
                    readRecords++;
                    /*
                     * Notify the next() thread to read
                     */
                    this.notifyAll();
                }
            } // while
            synchronized (this) {
                more = false;
                this.notifyAll();
            }
        } catch (Exception e) {
            synchronized (this) {
                exception = e;
                this.notifyAll();
            }
        }
    }

    @Override
    public void close() throws IOException {
        synchronized (this) {
            isClosed = true;
            this.notifyAll();
        }
        reader.close();
    }

    @Override
    public Class getKeyClass() {
        return reader.getKeyClass();
    }

    @Override
    public long getPos() throws IOException {
        return pos;
    }

    @Override
    public long getSize() throws IOException {
        return reader.getSize();
    }

    @Override
    public Class getValueClass() {
        return reader.getValueClass();
    }

    /**
     * Check this.exceptioin, throw if not null
     * 
     * @throws IOException
     *             if any IOException found in this.exception
     */
    protected void checkException() throws IOException {
        if (exception != null) {
            if (exception instanceof IOException)
                throw (IOException) exception;
            else
                throw new RuntimeException(exception);
        } // if
    }

    @Override
    public boolean next(Object key, Object value) throws IOException {
        synchronized (this) {
            while (!isClosed && exception == null && readRecords == 0 && more) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } // while
            if (isClosed) {
                /*
                 * Read a closed reader is an error
                 */
                throw new IOException("The reader has been closed!");
            } // if
            /*
             * Throw the exception thrown in read-thread
             */
            checkException();

            if (readRecords > 0) {
                /*
                 * We have more data, copy it to key/value
                 */
                ((IMutable) key).copyFields(keys[startIdx]);
                ((IMutable) value).copyFields(vals[startIdx]);
                pos = poses[startIdx];
                /*
                 * Move the copied record out
                 */
                startIdx++;
                if (startIdx == keys.length)
                    startIdx = 0;
                readRecords--;
                /*
                 * Notify the read-thread to fill the buffer
                 */
                this.notifyAll();
                return true;
            } else {
                /*
                 * No more record
                 */
                return false;
            } // else
        } // synchronized
    }
}
