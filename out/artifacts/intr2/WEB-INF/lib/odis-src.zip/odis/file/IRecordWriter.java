/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 14, 2006
 */
package odis.file;

import java.io.Closeable;
import java.io.IOException;

/**
 * The writer interface for writing a destination which is organized
 * record-by-record. Each record is a pair of (key,value). The destination could
 * be a file, a database, or even others. Usage: <code>
 * IRecordWriter writer = ...; 
 * try {
 *     writer.write(...); 
 *     ...
 * } finally {
 *     writer.close();
 * }
 * </code>
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public interface IRecordWriter<K, V> extends Closeable {
    /**
     * Writes a key/value pair.
     * <p>
     * NOTE:
     * <ol>
     * <li>write 方法需要保证 thread-safe，也就是说，多个不同的 thread 写的时候要保证 write 函数是原子执行不被打断的
     * </li>
     * <li>the key and value are NOT necessarily IWritable(s).</li>
     * </ol>
     * 
     * @param key
     *            the key to write
     * @param value
     *            the value to write
     * @throws IOException
     * @see IWritable#writeFields(DataOutput)
     */
    public void write(K key, V value) throws IOException;

    /**
     * Returns the total size written to the file so far
     * 
     * @throws IOException
     * @return the total size written so far
     */
    public long getSize() throws IOException;
}
