package org.codehaus.jackson.map.deser;

/**
 * @deprecated Since 1.9, use {@link org.codehaus.jackson.map.deser.std.JsonNodeDeserializer} instead.
 */
@Deprecated
public class DateDeserializer
    extends org.codehaus.jackson.map.deser.std.DateDeserializer
{ }
