package org.codehaus.jackson.map.ser;

/**
 * @deprecated Since 1.9 use {@link org.codehaus.jackson.map.ser.std.StdContainerSerializers} instead
 */
@Deprecated
public class ContainerSerializers
    extends org.codehaus.jackson.map.ser.std.StdContainerSerializers { }
