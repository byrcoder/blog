package net.spy.memcached.ops;

/**
 * ConcatenationOperation is used to append or prepend data to an existing
 * object in the cache.
 */
public interface ConcatenationOperation extends Operation {
	// Nothing here.
}
