package net.spy.memcached.ops;

/**
 * Operation that represents object storage.
 */
public interface StoreOperation extends Operation {
	// nothing
}