package net.spy.memcached.ops;


/**
 * Deletion operation.
 */
public interface DeleteOperation extends Operation {
	// nothing in particular.
}