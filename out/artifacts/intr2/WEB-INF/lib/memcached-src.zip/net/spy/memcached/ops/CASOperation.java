package net.spy.memcached.ops;

/**
 * Operation that represents compare-and-swap.
 */
public interface CASOperation extends Operation {
	// nothing
}
