package net.spy.memcached.ops;


/**
 * incr and decr operations.
 */
public interface MutatatorOperation extends Operation {
	// nothing
}