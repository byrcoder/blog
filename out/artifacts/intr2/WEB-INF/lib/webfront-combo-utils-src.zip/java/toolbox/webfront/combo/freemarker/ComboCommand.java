package toolbox.webfront.combo.freemarker;

import java.io.*;
import java.util.Collection;
import java.util.Properties;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import toolbox.webfront.combo.Combo;

public class ComboCommand {

	
	private static FreemarkerUtils utils;
	
	static{
		Combo.DEBUG = true;
	}
	
	
	private static void write(String resource_id , Collection js , Collection css) throws Exception{
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("FILE_NAME=" + resource_id);
		buffer.append("\n");
		if(js.size() > 0)buffer.append("JS_FILES=(\n" + StringUtils.join(js , "\n")+"\n)\n");
		if(css.size() > 0)buffer.append("CSS_FILES=(\n" + StringUtils.join(css , "\n")+"\n)\n");
		
		IOUtils.write(buffer.toString(), new FileOutputStream(new File(resource_id+"_pack.sh")));
	}
	
	
	private static void render(String resourceLoaderPath , File dir , String type) throws IOException, Exception{
		for(File f : dir.listFiles(new FileFilter() {
			
			public boolean accept(File pathname) {
				return pathname.isDirectory() || pathname.getName().endsWith(".ftl");
			}
		})){
			if(f.isDirectory()){
				render(resourceLoaderPath , f , type);
			}else{
				System.out.println("Combo " + f.getCanonicalPath());
				Combo combo = utils.getCombo(f.getCanonicalPath().replace(resourceLoaderPath, ""));
				if("page".equals(type)){
					if(!StringUtils.isEmpty(combo.getModuleId()))write("m-"+combo.getModuleId() , combo.getModuleJs() , combo.getModuleCss());
					if(!StringUtils.isEmpty(combo.getPageId()))write("p-"+combo.getPageId() , combo.getPageJs() , combo.getPageCss());
				}else{
					if(!StringUtils.isEmpty(combo.getGlobalId()))write("g-"+combo.getGlobalId() , combo.getGlobalJs() , combo.getGlobalCss());
				}
			}
		}
	}
	
	
	
	public static void main(String[] args) throws Exception {
		if(args.length != 1){
			throw new Exception("please set config file path");
		}
		
		Properties props = new Properties();
		props.load(new FileInputStream(new File(args[0])));
		
		File resourceLoaderPath = new File(props.getProperty("freemarker.resource.dir"));
		
		System.out.println("Freemarker ResourceLoaderPath: " + resourceLoaderPath.getCanonicalPath());
		System.out.println("Freemarker Layout: " + props.getProperty("freemarker.layout.dir"));
		System.out.println("Freemarker Page: " + props.getProperty("freemarker.page.dir"));
		
		File layoutDir = new File(resourceLoaderPath , props.getProperty("freemarker.layout.dir"));
		File pageDir = new File(resourceLoaderPath , props.getProperty("freemarker.page.dir"));
		
		if(!pageDir.isDirectory()){
			throw new Exception(pageDir.getCanonicalPath() + " not exist! ");
		}
		
		utils = new FreemarkerUtils();
		utils.setDirectoryForTemplateLoading(resourceLoaderPath.getCanonicalPath());
		utils.setDefaultEncoding(props.getProperty("freemarker.encoding"));
		utils.init();
		
		if(layoutDir.isDirectory()){
			//render layout
			render(resourceLoaderPath.getCanonicalPath() , layoutDir , "layout");
		}
		
		//render page
		render(resourceLoaderPath.getCanonicalPath() , pageDir , "page");
	}
	
}
