package toolbox.webfront.combo;

import java.util.Collection;
import java.util.LinkedHashSet;

public class Combo {
	
	private final LinkedHashSet<String> global_js = new LinkedHashSet<String>();
	private final LinkedHashSet<String> module_js = new LinkedHashSet<String>();
	private final LinkedHashSet<String> page_js = new LinkedHashSet<String>();
	
	private final LinkedHashSet<String> global_css = new LinkedHashSet<String>();
	private final LinkedHashSet<String> module_css = new LinkedHashSet<String>();
	private final LinkedHashSet<String> page_css = new LinkedHashSet<String>();
	
	private String globalId;
	private String moduleId;
	private String pageId;
	
	public static boolean COMBO_MODE = false;
	public static boolean DEBUG = false;
	
	
	private Combo(){
		
	}
	
	public void addGlobalJs(String js){
		global_js.add(js);
	}
	public void addModuleJs(String js){
		if(!global_js.contains(js)){
			module_js.add(js);
		}else if(DEBUG){
			System.out.println("["+pageId+"] Skip include "+js+", alway include in global["+globalId+"].");
		}
	}
	
	public void addPageJs(String js){
		if(global_js.contains(js)){
			if(DEBUG){
				System.out.println("["+pageId+"] Skip include "+js+", alway include in global["+globalId+"].");
			}
			return;
		}
				
		if(module_js.contains(js)){
			if(DEBUG){
				System.out.println("["+pageId+"] Skip include "+js+", alway include in module["+moduleId+"].");
			}
			return;
		}
		page_js.add(js);
	}
	
	public void addGlobalCss(String css){
		global_css.add(css);
	}
	public void addModuleCss(String css){
		if(!global_css.contains(css)){
			module_css.add(css);
		} if(DEBUG){
			System.out.println("["+pageId+"] Skip include "+css+", alway include in global["+globalId+"].");
		}
	}
	
	public void addPageCss(String css){
		if(global_css.contains(css)){
			if(DEBUG){
				System.out.println("["+pageId+"] Skip include "+css+", alway include in global["+globalId+"].");
			}
			return;
		}
				
		if(module_css.contains(css)){
			if(DEBUG){
				System.out.println("["+pageId+"] Skip include "+css+", alway include in module["+moduleId+"].");
			}
			return;
		}
		page_css.add(css);
	}
	
	public Collection<String> getGlobalJs()
	{
		return global_js;
	}
	public Collection<String> getModuleJs()
	{
		return module_js;
	}
	public Collection<String> getPageJs()
	{
		return page_js;
	}
	
	public Collection<String> getGlobalCss()
	{
		return global_css;
	}
	public Collection<String> getModuleCss()
	{
		return module_css;
	}
	public Collection<String> getPageCss()
	{
		return page_css;
	}
	
	
	
	
	public String getGlobalId() {
		return globalId;
	}

	public void setGlobalId(String globalId) {
		this.globalId = globalId;
	}

	public String getModuleId() {
		return moduleId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	
	public boolean isComboMode(){
		return COMBO_MODE;
	}

	public static Combo getInstance(){
		return new Combo();
	}
	
	public static Combo getInstance(boolean comboMode){
		COMBO_MODE = true;
		return getInstance();
	}
}
