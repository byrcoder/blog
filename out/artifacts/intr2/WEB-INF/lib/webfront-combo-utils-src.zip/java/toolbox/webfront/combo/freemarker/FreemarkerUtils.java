package toolbox.webfront.combo.freemarker;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;


import toolbox.webfront.combo.Combo;

import freemarker.core.Environment;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

public class FreemarkerUtils {

	Configuration cfg = new Configuration();
	
	private String defaultEncoding = "UTF-8";
	private String directoryForTemplateLoading;
	
	
	
	public FreemarkerUtils(){
        
	}
	
	public void init(){
		try {
			cfg.setDirectoryForTemplateLoading(new File(directoryForTemplateLoading));
	        cfg.setObjectWrapper(new DefaultObjectWrapper());
	        cfg.setDefaultEncoding(defaultEncoding);
	        cfg.setURLEscapingCharset(defaultEncoding);
	        cfg.setClassicCompatible(true);
	        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.IGNORE_HANDLER);
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public Combo getCombo(String template) throws IOException, TemplateException{
		Map parameter = new HashMap();
		Combo combo = Combo.getInstance(true);
		parameter.put("combo", combo);
		
		StringWriter writer = new StringWriter();
		Template temp=cfg.getTemplate(template);
        Environment env = temp.createProcessingEnvironment(parameter, writer);
        env.process();
        if(env.getVariable("page_id") != null){
        	combo.setPageId(env.getVariable("page_id").toString());
        }
        if(env.getVariable("m_resource_id") != null){
        	combo.setModuleId(env.getVariable("m_resource_id").toString());
        }
        
        if(env.getVariable("g_resource_id") != null){
        	combo.setGlobalId(env.getVariable("g_resource_id").toString());
        }
        
        return combo;
	}

	public void setDefaultEncoding(String defaultEncoding) {
		this.defaultEncoding = defaultEncoding;
	}

	public void setDirectoryForTemplateLoading(String directoryForTemplateLoading) {
		this.directoryForTemplateLoading = directoryForTemplateLoading;
	}
	
}
