package test;

import java.io.File;
import java.io.StringWriter;
import java.util.HashMap;

import freemarker.core.Environment;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import toolbox.webfront.combo.freemarker.ComboCommand;

public class testMain {

	public static void main(String[] args) throws Exception {
		ComboCommand.main(new String[]{
			"E:/workspace/webfront/combo-utils/test/combo.properties"
		});
		
		
	}
	
	
}
