/**
 * @(#)MetadataAndOmapClientCache.java, 2011-1-12. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.OmapMetadata;
import outfox.omap.master.ClearTableMetaTask;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class OmapTsMetadataCache {
    private static final Logger LOG = LogFormatter.getLogger(ClearTableMetaTask.class);

    public interface MetaDataChangeListener {
        public void metaDataChanged(long schemaId, OmapMetadata oldMeta, OmapMetadata newMeta);
    }

    private List<MetaDataChangeListener> metaDataChangeListenerList = new ArrayList<MetaDataChangeListener>();

    private ConcurrentMap<Long, OmapMetadata> metaMap = new ConcurrentHashMap<Long, OmapMetadata>();

    private volatile ClientMasterProtocol master;

    public void setMaster(ClientMasterProtocol master) {
        this.master = master;
    }

    public OmapMetadata getMetadata(long schemaId) throws IOException {
        OmapMetadata meta = metaMap.get(schemaId);
        if (meta != null) {
            return meta;
        }
        synchronized (metaMap) {
            meta = metaMap.get(schemaId);
            if (meta == null) {
                meta = master.getMetadata(schemaId);
                if (meta != null) {
                    metaMap.put(schemaId, meta);
                }
            }
        }
        return meta;
    }

    public void addNewMetaDataListener(MetaDataChangeListener listener) {
        metaDataChangeListenerList.add(listener);
    }

    public void addMetadata(OmapMetadata metadata) {
        metaMap.put(metadata.getTableDesc().getSchemaId(), metadata);
    }

    public void clearMetadata(long schemaId, boolean forRefresh) {
        OmapMetadata removed = metaMap.remove(schemaId);
        if (forRefresh) {
            try {
                OmapMetadata meta = getMetadata(schemaId);
                for(MetaDataChangeListener listener : metaDataChangeListenerList) {
                    listener.metaDataChanged(schemaId, removed, meta);
                }
            } catch (IOException e) {
                LOG.log(Level.WARNING,
                        "Fail to fetch new metadata for table," +
                        " schemaId=" + HexString.longToPaddedHex(schemaId));
            }
        }
    }
}
