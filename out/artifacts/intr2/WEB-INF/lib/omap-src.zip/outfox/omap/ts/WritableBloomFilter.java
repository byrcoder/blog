/**
 * @(#)WritableBloomFilter.java, 2009-4-20. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.BitSet;

import odis.serialize.IWritable;
import toolbox.misc.bloom.BloomFilter;
import toolbox.misc.bloom.HashFunction;

/**
 * @author zhangduo
 */
public class WritableBloomFilter extends BloomFilter implements IWritable {
    private static final byte[] bitvalues = new byte[] {
        (byte) 0x01, (byte) 0x02, (byte) 0x04, (byte) 0x08, (byte) 0x10,
        (byte) 0x20, (byte) 0x40, (byte) 0x80
    };

    /**
     * for readFields
     */
    public WritableBloomFilter() {}

    public WritableBloomFilter(long expectedElements, float errorRate,
            int hashType) {
        super(expectedElements, errorRate, hashType);
    }

    public WritableBloomFilter(int bitSetSize, int nbHash, int hashType) {
        super(bitSetSize, nbHash, hashType);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        nbHash = in.readInt();
        hashType = in.readInt();
        bitSetSize = in.readInt();
        hash = new HashFunction(bitSetSize, nbHash, hashType);
        bitSet = new BitSet(bitSetSize);
        byte[] bytes = new byte[getNBytes()];
        in.readFully(bytes);
        for (int i = 0, byteIndex = 0, bitIndex = 0; i < bitSetSize; i++, bitIndex++) {
            if (bitIndex == 8) {
                bitIndex = 0;
                byteIndex++;
            }
            if ((bytes[byteIndex] & bitvalues[bitIndex]) != 0) {
                bitSet.set(i);
            }
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(nbHash);
        out.writeInt(hashType);
        out.writeInt(bitSetSize);
        byte[] bytes = new byte[getNBytes()];
        for (int i = 0, byteIndex = 0, bitIndex = 0; i < bitSetSize; i++, bitIndex++) {
            if (bitIndex == 8) {
                bitIndex = 0;
                byteIndex++;
            }
            if (bitIndex == 0) {
                bytes[byteIndex] = 0;
            }
            if (bitSet.get(i)) {
                bytes[byteIndex] |= bitvalues[bitIndex];
            }
        }
        out.write(bytes);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        throw new UnsupportedOperationException();
    }
}
