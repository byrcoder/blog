/**
 * @(#)SchemaIdAndTablet.java, 2010-8-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.util.OmapUtils;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class SchemaIdAndRange implements IWritableComparable {

    private long schemaId;

    private long tabletId;

    private KeyPair range;

    public SchemaIdAndRange() {}

    public SchemaIdAndRange(long tabletId, KeyPair range) {
        this.tabletId = tabletId;
        this.schemaId = OmapUtils.tid2sid(tabletId);
        this.range = range;
    }

    public long getTabletId() {
        return tabletId;
    }

    public void setTabletId(long tabletId) {
        this.tabletId = tabletId;
        this.schemaId = OmapUtils.tid2sid(tabletId);
    }

    public KeyPair getRange() {
        return range;
    }

    public void setRange(KeyPair range) {
        this.range = range;
    }

    public long getSchemaId() {
        return schemaId;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        tabletId = in.readLong();
        range = new KeyPair();
        range.readFields(in);
        schemaId = OmapUtils.tid2sid(tabletId);
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(tabletId);
        range.writeFields(out);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        SchemaIdAndRange v = (SchemaIdAndRange) value;
        tabletId = v.tabletId;
        range = new KeyPair();
        range.copyFields(v.range);
        schemaId = OmapUtils.tid2sid(tabletId);
        return this;
    }

    @Override
    public int compareTo(IWritable o) {
        SchemaIdAndRange v = (SchemaIdAndRange) o;
        if (schemaId > v.schemaId) {
            return 1;
        }
        if (schemaId < v.schemaId) {
            return -1;
        }
        return KeyRange.compareRange(range, v.range);
    }

    @Override
    public int hashCode() {
        return (int) (tabletId ^ (tabletId >>> 32));
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        SchemaIdAndRange that = (SchemaIdAndRange) obj;
        return tabletId == that.tabletId;

    }

    public static SchemaIdAndRange createFromKeyRange(KeyRange kr) {
        return new SchemaIdAndRange(kr.getTabletId(), new KeyPair(kr.getKey1(),
                kr.getKey2()));
    }

    @Override
    public String toString() {
        return "SchemaIdAndRange [tabletId="
                + HexString.longToPaddedHex(tabletId) + ", range=" + range
                + "]";
    }
}
