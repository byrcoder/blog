/**
 * @(#)PermissionValidator.java, 2011-2-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.util.HashSet;
import java.util.Set;

import odis.serialize.lib.MD5Writable;
import outfox.omap.client.protocol.IPermissionValidator;
import outfox.omap.client.protocol.PermissionType;
import outfox.omap.conf.OmapConfig;
import outfox.omap.exceptions.OperationNotPermittedException;
import toolbox.collections.CacheMap;
import toolbox.text.util.StringUtils;

/**
 * Permission validator for ACL
 * 
 * @author wangfk
 */
public class PermissionValidator implements IPermissionValidator {
    private static final IPermissionValidator EMPTY_VALIDATOR = new IPermissionValidator() {
        @Override
        public void validatePermission(String user, PermissionType type) {
            //Do nothing
        }
    };

    private static final int VALIDATOR_CACHE_SIZE = 1024;

    private static final int USER_CACHE_SIZE = 32;

    private static final CacheMap<Long, PermissionValidator> cachedValidator = new CacheMap<Long, PermissionValidator>(
            true, VALIDATOR_CACHE_SIZE);

    private String superUser;

    private String owner;

    private Set<String> groupUserSet;

    private String strategy;

    private CacheMap<String, Integer> cachedUser = new CacheMap<String, Integer>(
            true, USER_CACHE_SIZE);

    private boolean[][] validValue = new boolean[3][3];

    public static IPermissionValidator createValidator(String owner,
            String groupUser, String strategy) {
        if (StringUtils.isEmptyString(strategy)
                || !OmapUtils.validatePermissionMode(strategy)
                || StringUtils.isEmptyString(owner) || groupUser == null) {
            return EMPTY_VALIDATOR;
        }
        String superUser = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_ACL_SUPER_USER,
                OmapConfig.DEFAULT_ACL_SUPER_USER);
        long id = uniqueValidatorId(superUser, owner, groupUser, strategy);
        PermissionValidator permissionValidator;
        synchronized (cachedValidator) {
            permissionValidator = cachedValidator.get(id);
            if (permissionValidator == null) {
                permissionValidator = new PermissionValidator(superUser, owner,
                        groupUser, strategy);
                cachedValidator.put(id, permissionValidator);
            }
        }
        return permissionValidator;
    }

    private static long uniqueValidatorId(String superUser, String owner,
            String groupUser, String strategy) {
        return MD5Writable.halfDigest(superUser)
                ^ MD5Writable.halfDigest(owner)
                ^ MD5Writable.halfDigest(groupUser)
                ^ MD5Writable.halfDigest(strategy);
    }

    private PermissionValidator(String superUser, String owner,
            String groupUser, String strategy) {
        this.superUser = superUser;
        this.owner = owner;
        String[] split = groupUser.split(";");
        this.groupUserSet = new HashSet<String>();
        for (String s: split) {
            groupUserSet.add(s);
        }
        this.strategy = strategy;
        // rwxrwxrwx
        validValue[0][PermissionType.READ.ordinal()] = strategy.charAt(0) == 'r';
        validValue[1][PermissionType.READ.ordinal()] = strategy.charAt(3) == 'r';
        validValue[2][PermissionType.READ.ordinal()] = strategy.charAt(6) == 'r';
        validValue[0][PermissionType.WRITE.ordinal()] = strategy.charAt(1) == 'w';
        validValue[1][PermissionType.WRITE.ordinal()] = strategy.charAt(4) == 'w';
        validValue[2][PermissionType.WRITE.ordinal()] = strategy.charAt(7) == 'w';
        validValue[0][PermissionType.EXECUTE.ordinal()] = strategy.charAt(2) == 'x';
        validValue[1][PermissionType.EXECUTE.ordinal()] = strategy.charAt(5) == 'x';
        validValue[2][PermissionType.EXECUTE.ordinal()] = strategy.charAt(8) == 'x';
    }

    @Override
    public void validatePermission(String user, PermissionType type)
            throws OperationNotPermittedException {
        int userType = getUserType(user);
        if (userType == -1) {
            return;
        } else if (!validValue[userType][type.ordinal()]) {
            throw new OperationNotPermittedException("UserName=" + user
                    + ", PermissionType=" + type.name() + ", Strategy="
                    + strategy + ", SuperUser=" + superUser + ", Owner="
                    + owner);
        }
    }

    /**
     * user type. -1: super, 0: owner, 1: group, 2: guest
     * 
     * @param user
     * @return
     */
    private int getUserType(String user) {
        if (StringUtils.isEmptyString(user)) {
            return 2;
        }

        Integer integer = cachedUser.get(user);
        if (integer != null) {
            return integer;
        }
        int res = superUser.equals(user) ? -1 : (owner.equals(user) ? 0
                : (groupUserSet.contains(user) ? 1 : 2));
        cachedUser.put(user, res);
        return res;
    }

    @Override
    public String toString() {
        return "PermissionValidator[SuperUser=" + superUser + "; owner="
                + owner + "; groupUserSet=" + groupUserSet + "; strategy="
                + strategy + "]";
    }
}
