package outfox.omap.ts.insertlog;

import outfox.omap.walog.CorruptedWALogEntryException;
import outfox.omap.walog.WALogBody;
import outfox.omap.walog.WALogEntry;

public class InsertLogEntry extends WALogEntry {
    /**
     * The number of logTypes
     */
    public static final int TYPE_INSERT = 0;

    public static final int TYPE_CHKPT = 1;

    public static final int TYPE_INDEX_INSERT = 10;

    public void setBody(WALogBody body) throws CorruptedWALogEntryException {
        this.body = body;
        if (body instanceof WALogChkPt) {
            logType = TYPE_CHKPT;
        } else if (body instanceof WALogInsert) {
            logType = TYPE_INSERT;
        } else if (body instanceof WALogIndexInsert) {
            logType = TYPE_INDEX_INSERT;
        } else {
            throw new CorruptedWALogEntryException(body.getClass()
                    + " doesn't correspond to a logType");
        }
    }

    protected void prepareLogBody(int logtype)
            throws CorruptedWALogEntryException {
        switch (logtype) {
            case TYPE_INSERT:
                if (!(body instanceof WALogInsert)) {
                    body = new WALogInsert();
                }
                break;
            case TYPE_CHKPT:
                if (!(body instanceof WALogChkPt)) {
                    body = new WALogChkPt(null);
                }
                break;
            case TYPE_INDEX_INSERT:
                if (!(body instanceof WALogIndexInsert)) {
                    body = new WALogIndexInsert();
                }
                break;
            default:
                throw new CorruptedWALogEntryException("Unknown log type: "
                        + logtype);
        }
    }

    @Override
    public String toString() {
        return "InsertLogEntry(type :" + this.logType + " body: " + body + ")";
    }
}
