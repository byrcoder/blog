package outfox.omap.metadata;

import java.io.IOException;
import java.util.Comparator;

import odis.io.CDataInputStream;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.data.KeyCell;
import outfox.omap.util.ReusableByteArrayInputStream;

public class DataRowBinaryComparator implements Comparator<ByteArrayWritable> {

    private KeyCell cell1;

    private KeyCell cell2;

    private ReusableByteArrayInputStream istream;

    private CDataInputStream dataInput;

    private KeyColumnDesc cd;

    /**
     * Will borrow two KeyCells from the KeyColumnDesc.
     * 
     * @param cd
     */
    public DataRowBinaryComparator(KeyColumnDesc cd) {
        this.cd = cd;
        this.cell1 = cd.borrowKeyCell();
        this.cell2 = cd.borrowKeyCell();
        istream = new ReusableByteArrayInputStream();
        dataInput = new CDataInputStream(istream);
    }

    public int compare(ByteArrayWritable o1, ByteArrayWritable o2) {
        try {
            istream.setBuffer(o1.data(), 1, o1.size() - 1);
            cell1.readPIFields(dataInput);
            istream.setBuffer(o2.data(), 1, o2.size() - 1);
            cell2.readPIFields(dataInput);
            return cell1.compareTo(cell2);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Return the borrowed KeyCells back to the KeyColumnDesc. Calling
     * {@link #compare(byte[], byte[])} after close() will cause unpredictable
     * results.
     */
    public void close() {
        cd.returnKeyCell(cell1);
        cd.returnKeyCell(cell2);
        cell1 = null;
        cell2 = null;
    }

}
