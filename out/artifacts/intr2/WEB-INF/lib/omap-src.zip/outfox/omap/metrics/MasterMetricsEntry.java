/**
 * @(#)MasterMetricsEntry.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * @author zhangduo
 */
public class MasterMetricsEntry implements IWritable {

    private String masterName;

    private final MasterGlobalMetricsEntry globalMetricsEntry;

    private final Map<Long, MasterTableMetricsEntry> tableMetricsEntries;

    public MasterMetricsEntry() {
        globalMetricsEntry = new MasterGlobalMetricsEntry();
        tableMetricsEntries = new TreeMap<Long, MasterTableMetricsEntry>();
    }

    public MasterMetricsEntry(String masterName) {
        this();
        this.masterName = masterName;
    }

    public MasterMetricsEntry(String masterName,
            MasterGlobalMetricsEntry globalMetricsEntry,
            Map<Long, MasterTableMetricsEntry> tabletMetricsEntries) {
        this.masterName = masterName;
        this.globalMetricsEntry = globalMetricsEntry;
        this.tableMetricsEntries = tabletMetricsEntries;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        MasterMetricsEntry that = (MasterMetricsEntry) value;

        masterName = that.masterName;
        globalMetricsEntry.copyFields(that.globalMetricsEntry);
        tableMetricsEntries.clear();
        for (Map.Entry<Long, MasterTableMetricsEntry> e: tableMetricsEntries.entrySet()) {
            MasterTableMetricsEntry entry = new MasterTableMetricsEntry();
            entry.copyFields(e.getValue());
            tableMetricsEntries.put(e.getKey(), entry);
        }

        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, masterName);
        globalMetricsEntry.writeFields(out);
        CDataOutputStream.writeVInt(tableMetricsEntries.size(), out);
        for (Map.Entry<Long, MasterTableMetricsEntry> e: tableMetricsEntries.entrySet()) {
            out.writeLong(e.getKey());
            e.getValue().writeFields(out);
        }

    }

    @Override
    public void readFields(DataInput in) throws IOException {
        masterName = StringWritable.readString(in);
        globalMetricsEntry.readFields(in);
        tableMetricsEntries.clear();
        int sz = CDataInputStream.readVInt(in);
        for (int i = 0; i < sz; i++) {
            long id = in.readLong();
            MasterTableMetricsEntry entry = new MasterTableMetricsEntry();
            entry.readFields(in);
            tableMetricsEntries.put(id, entry);
        }
    }

    public String getMasterName() {
        return masterName;
    }

    public MasterGlobalMetricsEntry getGlobalMetricsEntry() {
        return globalMetricsEntry;
    }

    public Map<Long, MasterTableMetricsEntry> getTableMetricsEntries() {
        return tableMetricsEntries;
    }

}
