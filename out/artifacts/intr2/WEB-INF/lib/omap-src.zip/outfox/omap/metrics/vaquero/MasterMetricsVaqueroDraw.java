/**
 * @(#)MasterMetricsVaqueroDraw.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public enum MasterMetricsVaqueroDraw {
    INFO("info", "basic information of omapmaster"), 
    LOAD("load", "system load"), 
    MEMORY("memory", "heap memory usage"),
    REQUEST_RATE("request.rate", "rate of total request"),
    
    GET_FS_NAME_RATE("getFsName.rate", "rate of getFsName request"),
    GET_FS_NAME_DELAY("getFsName.delay", "delay of getFsName request"),
    
    GET_TABLES_RATE("getTables.rate", "rate of getTables request"),
    GET_TABLES_DELAY("getTables.delay", "delay of getTables request"),
    
    GET_TABLES_IN_SPACE_RATE("getTablesInSpace.rate", "rate of getTablesInSpace request"),
    GET_TABLES_IN_SPACE_DELAY("getTablesInSpace.delay", "delay of getTablesInSpace request"),
    
    GET_TABLESPACES_RATE("getTableSpaces.rate", "rate of getTableSpaces request"),
    GET_TABLESPACES_DELAY("getTableSpaces.delay", "delay of getTableSpaces request"),
    
    CREATE_TABLE_RATE("createTable.rate", "rate of createTable request"),
    CREATE_TABLE_DELAY("createTable.delay", "delay of createTable request"),
    
    DELETE_TABLE_RATE("deleteTable.rate", "rate of deleteTable request"),
    DELETE_TABLE_DELAY("deleteTable.delay", "delay of deleteTable request"),
    
    LOOKUP_KEY_RATE("lookupKey.rate", "rate of lookupKey request"),
    LOOKUP_KEY_DELAY("lookupKey.delay", "delay of lookupKey request"),
    
    RENAME_TABLE_RATE("renameTable.rate", "rate of renameTable request"),
    RENAME_TABLE_DELAY("renameTable.delay", "delay of renameTable request"),
    
    SET_TABLE_PROPERTIES_RATE("setTableProperties.rate", "rate of setTableProperties request"),
    SET_TABLE_PROPERTIES_DELAY("setTableProperties.delay", "delay of setTableProperties request"),
    
    GET_SCHEMA_ID_RATE("getSchemaId.rate", "rate of getSchemaId request"),
    GET_SCHEMA_ID_DELAY("getSchemaId.delay", "delay of getSchemaId request"),
    
    GET_METADATA_RATE("getMetadata.rate", "rate of getMetadata request"),
    GET_METADATA_DELAY("getMetadata.delay", "delay of getMetadata request"),
    
    SET_READ_ONLY_RATE("setReadOnly.rate", "rate of setReadOnly request"),
    SET_READ_ONLY_DELAY("setReadOnly.delay", "delay of setReadOnly request");

    private final String drawName;
    
    private final String description;

    private MasterMetricsVaqueroDraw(String drawName, String description) {
        this.drawName = drawName;
        this.description = description;
    }

    public String getDrawName() {
        return drawName;
    }

    public String getDescription() {
        return description;
    }

}
