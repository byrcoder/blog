/**
 * @(#)SSTableMetadataSchemaIdRemover.java, 2008-9-18. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FSDataInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.LongWritable;
import outfox.omap.ts.Tablet;
import toolbox.misc.LogFormatter;

/**
 * @author zhangkun
 */
public class SSTableMetadataSchemaIdRemover {
    private static final Logger LOG = LogFormatter
            .getLogger(SSTableMetadataSchemaIdRemover.class);

    public static boolean removeSchemaId(IFileSystem fs, Path oldFile,
            Path newFile) {
        try {
            FSDataInputStream in = fs.open(oldFile);
            SequenceFile.Reader reader = new SequenceFile.Reader(fs, oldFile,
                    in);
            LongWritable k = new LongWritable();
            LongWritable v = new LongWritable();

            if (!reader.next(k, v)) {
                return false;
            }
            long entryCount = (int) k.get();
            if (!reader.next(k, v)) {
                return false;
            }
            // long schemaId = (int)k.get();
            if (!reader.next(k, v)) {
                return false;
            }
            long indexEntryCount = (int) k.get();
            reader.close();

            SequenceFile.Writer writer = new SequenceFile.Writer(fs, newFile,
                    LongWritable.class, LongWritable.class);
            k.set(entryCount);
            writer.write(k, k);
            k.set(indexEntryCount);
            writer.write(k, k);
            writer.close();
            return true;
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Exception", e);
            return false;
        }
    }

    public static void process(IFileSystem fs, Path path) throws Exception {
        if (fs.isDirectory(path)) {
            FileInfo[] files = fs.listFiles(path);
            if (files != null) {
                for (FileInfo file: files) {
                    process(fs, file.getPath());
                }
            }
        } else {
            if (path.getParentFile() != null
                    && path.getParentFile().getName().startsWith(
                            Tablet.SS_PREFIX)) {
                if (path.getName().equals("metadata")) {
                    Path newFile = new Path(path + ".new");
                    Path oldFile = new Path(path + ".old");
                    if (removeSchemaId(fs, path, newFile)) {
                        LOG.info("Converted " + path);
                    } else {
                        LOG.warning("Skipped " + path);
                    }
                    fs.rename(path, oldFile);
                    fs.rename(newFile, path);
                }
            }
        }
    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        IFileSystem fs = FileSystem.getNamed(args[0]);
        Path dir = new Path(args[1]);
        process(fs, dir);
    }

}
