/**
 * @(#)SqlDataReader.java, 2010-3-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.VIntWritable;

import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.exceptions.BadSchemaDefinitionException;
import outfox.omap.exceptions.InvalidDataSourceException;
import outfox.omap.metadata.Types;
import outfox.omap.metadata.Types.Type;
import outfox.omap.util.TableConfig;
import toolbox.misc.LogFormatter;

/**
 * Implement of {@link IDataReader}, read data from sql database
 * 
 * @see IDataReader
 * @author wangfk
 */
public class SqlDataReader implements IDataReader {

    private static final Logger LOG = LogFormatter.getLogger(SqlDataReader.class);

    private String connUrl;

    private String sqlTableName;

    private String colNames;

    private String colTypes;

    private String conditions;

    private TableConfig tableConfig;

    private ResultSet resultSet;

    private PreparedStatement statement;

    private Connection connection;

    //    private static final int FETCH_SIZE = 64; 
    private ThreadLocal<DataRow> tlDataRow = new ThreadLocal<DataRow>();

    private static Properties driverManagers = new Properties();

    private Map<Integer, AbstractDataFormatConvertor> convertors = new HashMap<Integer, AbstractDataFormatConvertor>();

    static {
        driverManagers.setProperty("mysql", "com.mysql.jdbc.Driver");
        //register more DriverManager
    }

    public SqlDataReader() {}

    private String createQueryStatement(boolean bRowCount) {
        StringTokenizer ntk = new StringTokenizer(colNames, ";");

        if (ntk.countTokens() < 2) {
            throw new BadSchemaDefinitionException("Bad columns defines: "
                    + colNames);
        }

        String key = ntk.nextToken().trim();
        StringBuilder statement = new StringBuilder("SELECT ");

        if (!bRowCount) {
            statement.append(key);
            while (ntk.hasMoreElements()) {
                statement.append(',').append(ntk.nextToken().trim());
            }
        } else {
            statement.append("COUNT(*) ");
        }

        statement.append(" FROM ").append(sqlTableName);
        if (!StringUtils.isEmpty(conditions)) {
            statement.append(" WHERE ").append(conditions);
        }
        if (!bRowCount) {
            statement.append(" order by ").append(key);
        }
        statement.append(';');

        return statement.toString();
    }

    @Override
    public long getRowCount() {

        ResultSet localResultSet = null;
        Statement localStatement = null;
        Connection localconnection = null;
        long ret = 0;
        try {
            localconnection = DriverManager.getConnection(connUrl);

            localStatement = localconnection.createStatement();
            localResultSet = localStatement.executeQuery(createQueryStatement(true));

            if (localResultSet.next()) {
                ret = localResultSet.getLong(1);
            }
        } catch (SQLException e) {
            throw new InvalidDataSourceException(e);
        } finally {
            try {
                if (localconnection != null) {
                    localconnection.close();
                }
                if (localResultSet != null) {
                    localResultSet.close();
                }
                if (localStatement != null) {
                    localStatement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
        return ret;
    }

    @Override
    synchronized public DataRow getNextRow() {
        if (tlDataRow.get() == null) {
            tlDataRow.set(this.tableConfig.td.createDataRow());
        }
        DataRow dr = tlDataRow.get();

        try {
            if (resultSet.next()) {
                readDataRow(resultSet, dr);
                return dr;
            } else {
                resultSet.close();
                resultSet = null;
                return null;
            }

        } catch (SQLException e) {
            throw new InvalidDataSourceException(e);
        }
    }

    private void readDataRow(ResultSet rs, DataRow dr) {
        StringTokenizer ntk = new StringTokenizer(colTypes, ";");
        DataCell[] columns = dr.getColumns();

        if (ntk.countTokens() != columns.length) {
            throw new BadSchemaDefinitionException("number of col. names "
                    + "must equal to number of types");
        }

        for (int i = 0; i < columns.length; ++i) {
            String dcType = ntk.nextToken().trim();
            readDataCell(rs, i + 1, columns[i], dcType);
        }
    }

    private void readDataCell(ResultSet rs, int cellIndex, DataCell dc,
            String dcType) {
        AbstractDataFormatConvertor convertor = convertors.get(cellIndex - 1);
        if (convertor != null) {
            try {
                byte[] vbytesValue = rs.getBytes(cellIndex);
                ByteArrayWritable byteArrayWritable = new ByteArrayWritable();
                byteArrayWritable.set(vbytesValue);
                convertor.convert(byteArrayWritable, dc);
                return;
            } catch (SQLException e) {
                LOG.warning("exception while read cell data.");
                throw new InvalidDataSourceException(e);
            }
        }

        Type type = Types.getType(dcType);
        try {
            switch (type) {
                case BOOLEAN:
                    boolean boolValue = rs.getBoolean(cellIndex);
                    dc.setValue(boolValue);
                    break;
                case BYTE:
                    byte byteValue = rs.getByte(cellIndex);
                    dc.setValue(byteValue);
                    break;
                case BYTEARRAY:
                case CUSTOM:
                    byte[] bytesValue = rs.getBytes(cellIndex);
                    dc.setValue(bytesValue);
                    break;
                case DOUBLE:
                    double doubleValue = rs.getDouble(cellIndex);
                    dc.setValue(doubleValue);
                    break;
                case FIXEDLENBYTEARRAY:
                    byte[] fixedBytesValue = rs.getBytes(cellIndex);
                    dc.setValueFixLen(fixedBytesValue);
                    break;
                case FLOAT:
                    float floatValue = rs.getFloat(cellIndex);
                    dc.setValue(floatValue);
                    break;
                case INTEGER:
                    int intValue = rs.getInt(cellIndex);
                    dc.setValue(intValue);
                    break;
                case LONG:
                    long longValue = rs.getLong(cellIndex);
                    dc.setValue(longValue);
                    break;
                case NULL:
                    dc.setNull();
                    break;
                case SHORT:
                    short shortValue = rs.getShort(cellIndex);
                    dc.setValue(shortValue);
                    break;
                case STRING:
                    String stringValue = rs.getString(cellIndex);
                    dc.setValue(stringValue);
                    break;
                case VINT:
                    int vintValue = rs.getInt(cellIndex);
                    VIntWritable vintWritable = new VIntWritable();
                    vintWritable.set(vintValue);
                    dc.setBuffer(vintWritable);
                    break;
                case VINTBYTEARRAY:
                    byte[] vbytesValue = rs.getBytes(cellIndex);
                    ByteArrayWritable byteArrayWritable = new ByteArrayWritable();
                    byteArrayWritable.set(vbytesValue);
                    dc.setBuffer(byteArrayWritable);
                    break;
                case VINTSTRING:
                    String vstringValue = rs.getString(cellIndex);
                    StringWritable stringWritebale = new StringWritable();
                    stringWritebale.set(vstringValue);
                    dc.setBuffer(stringWritebale);
                    break;
                default:
                case INDEXSCHEMA:
                case KEYRANGE:
                case OMAPQUERY:
                case SCHEMAIDANDKEYRANGE:
                case TABLEDESC:
                case TABLEREF:
                case TASKDESC:
                case TPKEY:
                    throw new BadSchemaDefinitionException(
                            "Bad column type defination: " + dcType);
            }
        } catch (SQLException e) {
            LOG.warning("exception while read cell data.");
            throw new InvalidDataSourceException(e);
        }
    }

    public void setConnUrl(String connUrl) {
        this.connUrl = connUrl;
    }

    @Override
    public void setColTypes(String colTypes) {
        this.colTypes = colTypes;
    }

    @Override
    public void setColNames(String colNames) {
        this.colNames = colNames;
    }

    public void setConditions(String conditions) {
        this.conditions = conditions;
    }

    public void setSqlTableName(String table) {
        this.sqlTableName = table;
    }

    @Override
    public void setTableConfig(TableConfig config) {
        this.tableConfig = config;
    }

    @Override
    public void openDataSource() throws IOException {

        try {
            connection = DriverManager.getConnection(connUrl);
            statement = connection.prepareStatement(
                    createQueryStatement(false), ResultSet.TYPE_FORWARD_ONLY,
                    ResultSet.CONCUR_READ_ONLY);
            statement.setFetchSize(Integer.MIN_VALUE);
            resultSet = statement.executeQuery();
        } catch (SQLException e) {
            throw new IOException("Open SQL data source error.", e);
        }
    }

    @Override
    public void closeDataSouce() {
        try {
            if (resultSet != null && !resultSet.isClosed()) {
                resultSet.close();
            }
            if (statement != null && !statement.isClosed()) {
                statement.close();
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            LOG.warning("Exception while close data source: " + connUrl);
        }
    }

    public void setDBType(String dbType) {
        String strDMClsName = driverManagers.getProperty(dbType.toLowerCase());
        try {
            Class.forName(strDMClsName).newInstance();
        } catch (Exception e) {
            LOG.warning("Exception while loading class: " + strDMClsName + ".");
            throw new InvalidDataSourceException(
                    "Exception while loading sql DriverManager", e);
        }
    }

    @Override
    public void setProperties(Properties properties) {
        if (properties == null) {
            return;
        }
        String value;
        value = properties.getProperty("ConnUrl".toLowerCase());
        if (!StringUtils.isEmpty(value)) {
            setConnUrl(value);
        }

        value = properties.getProperty("Conditions".toLowerCase());
        if (!StringUtils.isEmpty(value)) {
            setConditions(value);
        }

        value = properties.getProperty("SqlTableName".toLowerCase());
        if (!StringUtils.isEmpty(value)) {
            setSqlTableName(value);
        }

        value = properties.getProperty("dbtype".toLowerCase());
        if (!StringUtils.isEmpty(value)) {
            setDBType(value);
        }
    }

    @Override
    public void setDataConvertor(int columnIndex,
            AbstractDataFormatConvertor convertor) {
        convertors.put(columnIndex, convertor);
    }
}
