package outfox.omap.util;

public interface LogDebugEventHandler {
    
    public void handle(String message) ;

}
