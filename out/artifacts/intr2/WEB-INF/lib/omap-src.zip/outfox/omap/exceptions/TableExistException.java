package outfox.omap.exceptions;

public class TableExistException extends OmapException {

    private static final long serialVersionUID = -6715100684784744995L;

    public TableExistException(String s) {
        super(s);
    }

}
