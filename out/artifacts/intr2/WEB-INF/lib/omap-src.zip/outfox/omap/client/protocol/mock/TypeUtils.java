/**
 * @(#)TypeUtils.java, 2009-5-1. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol.mock;

import outfox.omap.exceptions.BadTypeStringException;
import outfox.omap.metadata.Types;

/**
 * @author zhangduo
 */
public class TypeUtils {
    public static Class<?> getClass(String typeName) {
        if (typeName.startsWith("CUSTOM")) {
            try {
                return Class.forName(typeName.substring(7,
                        typeName.length() - 1));
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        } else {
            try {
                return Types.getIWritable(typeName).getClass();
            } catch (BadTypeStringException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
