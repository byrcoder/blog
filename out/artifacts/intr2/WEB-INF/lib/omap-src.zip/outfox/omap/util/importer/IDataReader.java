/**
 * @(#)IDataReader.java, 2010-3-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.IOException;
import java.util.Properties;

import outfox.omap.data.DataRow;
import outfox.omap.util.TableConfig;

/**
 * Read data from data source, and convert it into omap data format
 * @author wangfk
 *
 */
public interface IDataReader {
    
    /**
     * column names may be useful while fetching data. For example, creating query statment in sql reader
     * <p>
     * @param colNames column names of the table, split by ';'
     */
    public void setColNames(String colNames);

    /**
     * Let the DataReader know the 
     * @param colTypes column types of the table, split by ';'
     */
    public void setColTypes(String colTypes);
    
    /**
     * TableConfig is used for create DataRow 
     * @param config should be created by {@link outfox.omap.common.ClientMasterProtocol#createImportedTable}
     */
    public void setTableConfig(TableConfig config);
    
    /**
     * Set properties defined by task(or user)
     * <p>
     * The properties should be explained by each IDataReader Impl
     * @param properties 
     */
    public void setProperties(Properties properties);
    
    /**
     * Thread safe method.
     * <p>
     * If you call this method, the last DataRow Object fetched by this method is invalid.
     * @return the next data row, null if reaches the end.
     */
    public DataRow getNextRow();
    
    /**
     * @return row count of the data source
     */
    public long getRowCount();
    
    /**
     * Open data source before {@link #getNextRow()}
     * @throws IOException
     */
    public void openDataSource() throws IOException;
    
    /**
     * Close data source, ignore excepions
     */
    public void closeDataSouce();
    
    /**
     * Convert data source to {@link outfox.omap.data.DataCell} format, see {@link AbstractDataFormatConvertor}
     * @param columnIndex
     * @param convertor
     */
    public void setDataConvertor(int columnIndex, AbstractDataFormatConvertor convertor);
    
}
