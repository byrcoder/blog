/**
 * @(#)TsGlobalMetricsAnalyzer.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TimeRangeUtils;
import outfox.omap.metrics.TsMetricsType;

/**
 * @author zhangduo
 */
public class TsGlobalMetricsAnalyzer {
    protected long[] metricsRecords = new long[TsMetricsType.globalTypeCount()];

    protected double[] statisticResults = new double[TsGlobalStatisticType.getTypeCount()];

    protected long count;

    public void process(long[] metricsRecords) {
        for (int i = 0; i < TsMetricsType.globalTypeCount(); i++) {
            this.metricsRecords[i] += metricsRecords[i];
        }
        count++;
    }

    public void done() {
        statisticResults[TsGlobalStatisticType.HEARTBEAT_COUNT.offset()] = metricsRecords[TsMetricsType.GLOBAL_HEARTBEAT_COUNT.offset()];
        if (metricsRecords[TsMetricsType.GLOBAL_HEARTBEAT_COUNT.offset()] > 0) {
            statisticResults[TsGlobalStatisticType.HEARTBEAT_DELAY.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_HEARTBEAT_DELAY.offset()]
                    / metricsRecords[TsMetricsType.GLOBAL_HEARTBEAT_COUNT.offset()];
        } else {
            statisticResults[TsGlobalStatisticType.HEARTBEAT_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsGlobalStatisticType.TIME_RANGE_HEARTBEAT_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.GLOBAL_TIME_RANGE_HEARTBEAT_COUNT.offset()
                    + i];
        }

        statisticResults[TsGlobalStatisticType.SSTABLE_SEEK_COUNT.offset()] = metricsRecords[TsMetricsType.GLOBAL_SSTABLE_SEEK_COUNT.offset()];
        if (metricsRecords[TsMetricsType.GLOBAL_SSTABLE_SEEK_COUNT.offset()] > 0) {
            statisticResults[TsGlobalStatisticType.SSTABLE_SEEK_DELAY.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_SSTABLE_SEEK_DELAY.offset()]
                    / metricsRecords[TsMetricsType.GLOBAL_SSTABLE_SEEK_COUNT.offset()];
        } else {
            statisticResults[TsGlobalStatisticType.SSTABLE_SEEK_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsGlobalStatisticType.TIME_RANGE_SSTABLE_SEEK_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.GLOBAL_TIME_RANGE_SSTABLE_SEEK_COUNT.offset()
                    + i];
        }

        statisticResults[TsGlobalStatisticType.SYSTEM_LOAD.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_SYSTEM_LOAD.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.SYSTEM_LOAD_PER_PROCESSOR.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_SYSTEM_LOAD.offset()]
                / metricsRecords[TsMetricsType.GLOBAL_PROCESSOR_NUM.offset()];

        statisticResults[TsGlobalStatisticType.MEMORY_INIT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_MEMORY_INIT.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.MEMORY_USED.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_MEMORY_USED.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.MEMORY_COMMITTED.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_MEMORY_COMMITTED.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.MEMORY_MAX.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_MEMORY_MAX.offset()]
                / count;

        statisticResults[TsGlobalStatisticType.WRITE_BUFFER_USED.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_WRITE_BUFFER_USED.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.WRITE_BUFFER_MAX.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_WRITE_BUFFER_MAX.offset()]
                / count;

        statisticResults[TsGlobalStatisticType.BLOOMFILTER_USED.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOOMFILTER_USED.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.BLOOMFILTER_MAX.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOOMFILTER_MAX.offset()]
                / count;

        statisticResults[TsGlobalStatisticType.INDEX_POOL_USED.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_INDEX_POOL_USED.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.INDEX_POOL_MAX.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_INDEX_POOL_MAX.offset()]
                / count;

        statisticResults[TsGlobalStatisticType.BLOCK_CACHE_USED.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_USED.offset()]
                / count;
        statisticResults[TsGlobalStatisticType.BLOCK_CACHE_MAX.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_MAX.offset()]
                / count;

        statisticResults[TsGlobalStatisticType.BLOCK_CACHE_CACHE_COUNT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_CACHE_COUNT.offset()];
        statisticResults[TsGlobalStatisticType.BLOCK_CACHE_GET_COUNT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_GET_COUNT.offset()];
        statisticResults[TsGlobalStatisticType.BLOCK_CACHE_GET_HIT_COUNT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_GET_HIT_COUNT.offset()];
        statisticResults[TsGlobalStatisticType.BLOCK_CACHE_EVICT_COUNT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_EVICT_COUNT.offset()];

        statisticResults[TsGlobalStatisticType.REQUEST_COUNT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_REQUEST_NUM.offset()];
        statisticResults[TsGlobalStatisticType.TIMEOUT_REQUEST_COUNT.offset()] = (double) metricsRecords[TsMetricsType.GLOBAL_TIMEOUT_REQUEST_NUM.offset()];
    }

    public double[] getStatisticResults() {
        return statisticResults;
    }

}
