/**
 * @(#)PermissionType.java, 2011-2-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol;

/**
 * Enum the permission type of the table
 *
 * @author wangfk
 *
 */
public enum PermissionType {
    /**
     * READ: read/query/contains operations of the table
     */
    READ,
    /**
     * WRITE: write/delete operations of the table
     */
    WRITE,
    /**
     * delete/acl/schema/properties opertations of the table
     */
    EXECUTE;
}
