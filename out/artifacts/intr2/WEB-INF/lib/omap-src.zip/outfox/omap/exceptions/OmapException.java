package outfox.omap.exceptions;

public class OmapException extends Exception {

    private static final long serialVersionUID = -8054989886773810894L;

    public OmapException() {
        super();
    }

    public OmapException(String message) {
        super(message);
    }

    public OmapException(String message, Throwable cause) {
        super(message, cause);
    }

    public OmapException(Throwable cause) {
        super(cause);
    }
}
