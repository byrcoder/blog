package outfox.omap.walog;

import odis.serialize.IWritable;
/**
 * The body of a {@link WALogBody}
 * @author zhangkun
 *
 */
public interface WALogBody extends IWritable {

    String toStructuredString(MetadataProvider provider);
}
