/**
 * @(#)OmapMetricsMonitor.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem.PathFilter;
import odis.io.Path;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.serialize.lib.LongWritable;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooKeeper;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.webapp.WebAppContext;

import outfox.omap.conf.OmapConfig;
import outfox.omap.metrics.statistic.StatisticMergeHandler;
import outfox.omap.metrics.statistic.StatisticReader;
import outfox.omap.metrics.statistic.StatisticRecorder;
import outfox.omap.metrics.statistic.StatisticReporter;
import outfox.omap.metrics.vaquero.MasterMetricsVaqueroReporter;
import outfox.omap.metrics.vaquero.TsMetricsVaqueroReporter;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.NoActionWatcher;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class OmapMetricsMonitor {

    private static final Logger LOG = LogFormatter.getLogger(OmapMetricsMonitor.class);

    private final ScheduledExecutorService updateExecutor = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "Metrics-Monitor-Updater");
            t.setDaemon(true);
            return t;
        }
    });

    private final ExecutorService taskExecutor = new ThreadPoolExecutor(5, 100,
            60L, TimeUnit.SECONDS, new SynchronousQueue<Runnable>(),
            new ThreadFactory() {

                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "Metrics-Monitor-Task");
                    t.setDaemon(true);
                    return t;
                }
            });

    private final MasterMetricsVaqueroReporter masterMetricsVaqueroReporter;

    private final TsMetricsVaqueroReporter tsMetricsVaqueroReporter;

    private final StatisticRecorder statisticRecorder;

    private final Server statisticWebServer;

    private IMasterMetricsReport masterMetricsReport;

    private SortedMap<String, ITsMetricsReport> tsMetricsReports = new TreeMap<String, ITsMetricsReport>();

    private void prepareMasterMetricsReport(String masterAddr)
            throws RpcException {
        String[] ss = masterAddr.split(":");
        InetSocketAddress addr = InetSocketAddress.createUnresolved(ss[0],
                Integer.parseInt(ss[1]));
        if (masterMetricsReport != null) {
            if (RPC.getRemoteAddr(masterMetricsReport).equals(addr)) {
                return;
            }
            RPC.close(masterMetricsReport);
        }
        masterMetricsReport = RPC.getProxy(
                IMasterMetricsReport.class,
                addr,
                OmapConfig.getConfiguration().getLong(
                        OmapConfig.NAME_METRICS_INTERVAL,
                        OmapConfig.DEFAULT_METRICS_INTERVAL) / 2 * 1000);
    }

    private void prepareTsMetricsReport(SortedSet<String> tsAddrs) {
        Iterator<Map.Entry<String, ITsMetricsReport>> oldIter = tsMetricsReports.entrySet().iterator();
        Iterator<String> newIter = tsAddrs.iterator();
        SortedMap<String, ITsMetricsReport> newTsMetricsReports = new TreeMap<String, ITsMetricsReport>();
        if (oldIter.hasNext() && newIter.hasNext()) {
            Map.Entry<String, ITsMetricsReport> oldEntry = oldIter.next();
            String newAddr = newIter.next();
            while (true) {
                int cmp = oldEntry.getKey().compareTo(newAddr);
                if (cmp < 0) {
                    RPC.close(oldEntry.getValue());
                    if (!oldIter.hasNext()) {
                        String[] ss = newAddr.split(":");
                        try {
                            ITsMetricsReport tsMetricsReport = RPC.getProxy(
                                    ITsMetricsReport.class,
                                    new InetSocketAddress(ss[0],
                                            Integer.parseInt(ss[1])),
                                    OmapConfig.getConfiguration().getLong(
                                            OmapConfig.NAME_METRICS_INTERVAL,
                                            OmapConfig.DEFAULT_METRICS_INTERVAL) / 2 * 1000);
                            newTsMetricsReports.put(newAddr, tsMetricsReport);
                        } catch (Exception e) {
                            LOG.log(Level.WARNING, "get proxy for ts "
                                    + newAddr + " failed", e);
                        }
                        break;
                    }
                    oldEntry = oldIter.next();
                } else if (cmp == 0) {
                    newTsMetricsReports.put(oldEntry.getKey(),
                            oldEntry.getValue());
                    if (!oldIter.hasNext() || !newIter.hasNext()) {
                        break;
                    }
                    oldEntry = oldIter.next();
                    newAddr = newIter.next();
                } else { // cmp > 0
                    String[] ss = newAddr.split(":");
                    try {
                        ITsMetricsReport tsMetricsReport = RPC.getProxy(
                                ITsMetricsReport.class,
                                new InetSocketAddress(ss[0],
                                        Integer.parseInt(ss[1])),
                                OmapConfig.getConfiguration().getLong(
                                        OmapConfig.NAME_METRICS_INTERVAL,
                                        OmapConfig.DEFAULT_METRICS_INTERVAL) / 2 * 1000);
                        newTsMetricsReports.put(newAddr, tsMetricsReport);
                    } catch (Exception e) {
                        LOG.log(Level.WARNING, "get proxy for ts " + newAddr
                                + " failed", e);
                    }
                    if (!newIter.hasNext()) {
                        RPC.close(oldEntry.getValue());
                        break;
                    }
                    newAddr = newIter.next();
                }
            }
        }
        while (oldIter.hasNext()) {
            RPC.close(oldIter.next().getValue());
        }
        while (newIter.hasNext()) {
            String newAddr = newIter.next();
            String[] ss = newAddr.split(":");
            try {
                ITsMetricsReport tsMetricsReport = RPC.getProxy(
                        ITsMetricsReport.class,
                        new InetSocketAddress(ss[0], Integer.parseInt(ss[1])),
                        OmapConfig.getConfiguration().getLong(
                                OmapConfig.NAME_METRICS_INTERVAL,
                                OmapConfig.DEFAULT_METRICS_INTERVAL) / 2 * 1000);
                newTsMetricsReports.put(newAddr, tsMetricsReport);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "get proxy for ts " + newAddr
                        + " failed", e);
            }
        }
        tsMetricsReports = newTsMetricsReports;
    }

    private MetricsEntry getMetricsEntry() throws IOException, KeeperException,
            InterruptedException {
        String masterAddr;
        SortedSet<String> tsAddrs;
        ZooKeeper zk = null;
        try {
            zk = new ZooKeeper(OmapConfig.getZkAddress(), 15000,
                    new NoActionWatcher());
            byte[] masterAddrData = zk.getData(
                    OmapConfig.getZkActiveMasterPath(), null, null);
            masterAddr = new String(masterAddrData);
            tsAddrs = new TreeSet<String>(zk.getChildren(
                    OmapConfig.getZkTsPath(), new NoActionWatcher()));
        } finally {
            OmapUtils.safeClose(zk);
        }
        prepareMasterMetricsReport(masterAddr);
        prepareTsMetricsReport(tsAddrs);

        MasterMetricsEntry masterMetricsEntry = masterMetricsReport.getMetricsEntry();
        List<TsMetricsEntry> tsMetricsEntries = new ArrayList<TsMetricsEntry>(
                tsAddrs.size());
        Map<String, Future<TsMetricsEntry>> futures = new TreeMap<String, Future<TsMetricsEntry>>();
        for (final Map.Entry<String, ITsMetricsReport> entry: tsMetricsReports.entrySet()) {
            futures.put(entry.getKey(),
                    taskExecutor.submit(new Callable<TsMetricsEntry>() {

                        @Override
                        public TsMetricsEntry call() throws Exception {
                            LOG.info("Get ts metrics entry from "
                                    + entry.getKey());
                            return entry.getValue().getMetricsEntry();
                        }

                    }));
        }
        for (Map.Entry<String, Future<TsMetricsEntry>> entry: futures.entrySet()) {
            try {
                tsMetricsEntries.add(entry.getValue().get());
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "get ts metrics info for " + entry.getKey() + " failed",
                        e);
            }
        }
        return new MetricsEntry(masterMetricsEntry, tsMetricsEntries);
    }

    private void initDir(FileSystem fs, Path dir) throws IOException {
        if (!fs.exists(dir)) {
            fs.mkdirs(dir);
            fs.mkdirs(dir.cat(StatisticReporter.REPORT_DIR));
            return;
        }
        FileInfo[] mergeFiles = fs.listFiles(dir, new PathFilter() {

            @Override
            public boolean accept(Path path) {
                return path.getName().startsWith(
                        StatisticMergeHandler.MERGE_FILE_PREFIX);
            }
        });
        for (FileInfo info: mergeFiles) {
            OmapUtils.safeDelete(fs, info.getPath());
        }
        FileInfo[] mergeCommitFiles = fs.listFiles(dir, new PathFilter() {

            @Override
            public boolean accept(Path path) {
                return path.getName().startsWith(
                        StatisticMergeHandler.COMMIT_MERGE_FILE_PREFIX);
            }
        });
        for (FileInfo commitMergeFile: mergeCommitFiles) {
            String[] ss = commitMergeFile.getPath().getName().split("_");
            long startTime = Long.parseLong(ss[1]);
            long endTime = Long.parseLong(ss[2]);
            for (FileInfo file: fs.listFiles(dir, new PathFilter() {

                @Override
                public boolean accept(Path path) {
                    return path.getName().startsWith(
                            StatisticRecorder.STATISTIC_FILE_PREFIX);
                }
            })) {
                long time = StatisticReader.getStatFileTime(
                        file.getPath().getName()).getFirst();
                if (time >= startTime || time <= endTime) {
                    OmapUtils.safeDelete(fs, file.getPath());
                }
            }
            Path newFile = dir.cat(StatisticRecorder.STATISTIC_FILE_PREFIX
                    + ss[3] + "_" + ss[4]);
            if (!fs.rename(commitMergeFile.getPath(), newFile)) {
                LOG.warning("rename " + commitMergeFile.getPath() + " to "
                        + newFile + " failed, I will quit");
                System.exit(1000);
            }
        }

        for (FileInfo openStatFile: fs.listFiles(dir, new PathFilter() {

            @Override
            public boolean accept(Path path) {
                return path.getName().startsWith(
                        StatisticRecorder.OPEN_STATISTIC_FILE_NAME);
            }
        })) {
            long entryMinTime = Long.MAX_VALUE;
            long entryMaxTime = Long.MIN_VALUE;
            LongWritable key = new LongWritable();
            MetricsEntry value = new MetricsEntry();
            SequenceFile.Reader reader = null;
            try {
                reader = new SequenceFile.Reader(fs,
                        openStatFile.getPath());
                while (reader.next(key, value)) {
                    if (key.get() < entryMinTime) {
                        entryMinTime = key.get();
                    }
                    if (key.get() > entryMaxTime) {
                        entryMaxTime = key.get();
                    }
                }
            } catch (EOFException e) {
                LOG.log(Level.WARNING,
                        "incompleted stat file, ignore last metrics entry", e);
            } finally {
                OmapUtils.safeClose(reader);
            }
            if (entryMinTime == Long.MAX_VALUE) { // no entry, just delete it
                LOG.info("empty stat file, delete it");
                fs.delete(openStatFile.getPath());
            } else {
                fs.rename(
                        openStatFile.getPath(),
                        dir.cat(StatisticRecorder.STATISTIC_FILE_PREFIX
                                + entryMinTime + "_" + (entryMaxTime + 1)));
            }
        }
    }

    public OmapMetricsMonitor() throws Exception {
        String fsName = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_METRICS_STATISTIC_FS_NAME);
        if (fsName == null) {
            fsName = OmapConfig.getConfiguration().getString(
                    OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
        }
        FileSystem fs = FileSystem.getNamed(fsName);
        Path dir = new Path(OmapConfig.getMetricsStatisticPath());
        initDir(fs, dir);

        MetricsEntry metricsEntry = getMetricsEntry();
        long currentTime = System.currentTimeMillis();
        masterMetricsVaqueroReporter = new MasterMetricsVaqueroReporter(
                currentTime);
        tsMetricsVaqueroReporter = new TsMetricsVaqueroReporter(currentTime);
        statisticRecorder = new StatisticRecorder(fs, dir);
        statisticRecorder.update(metricsEntry, currentTime);
        long metricsInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_METRICS_INTERVAL,
                OmapConfig.DEFAULT_METRICS_INTERVAL);
        updateExecutor.scheduleAtFixedRate(new Runnable() {

            @Override
            public void run() {
                try {
                    update();
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "update failed", t);
                }
            }
        }, metricsInterval, metricsInterval, TimeUnit.SECONDS);

        int webPort = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_METRICS_STATISTIC_WEB_PORT,
                OmapConfig.DEFAULT_METRICS_STATISTIC_WEB_PORT);
        statisticWebServer = new Server(webPort);
        WebAppContext wac = new WebAppContext();
        wac.setContextPath("/");
        wac.setWar("./webapps/web-metrics/");
        statisticWebServer.setHandler(wac);
        statisticWebServer.setStopAtShutdown(true);
        statisticWebServer.start();

        new DailyTask().start();
    }

    private void update() throws IOException, KeeperException,
            InterruptedException {
        MetricsEntry metricsEntry = getMetricsEntry();
        long currentTime = System.currentTimeMillis();
        masterMetricsVaqueroReporter.update(
                metricsEntry.getMasterMetricsEntry(), currentTime);
        tsMetricsVaqueroReporter.update(metricsEntry.getTsMetricsEntries(),
                currentTime);
        statisticRecorder.update(metricsEntry, currentTime);
    }

    private class DailyTask extends Thread {

        private long nextSendTime;

        public DailyTask() {
            super("Daily-Report-Task");
            setDaemon(true);
            DateTime dt = new DateTime();
            DateTime startOfDay = dt.minusMillis(dt.getMillisOfDay());
            nextSendTime = startOfDay.plusHours(6).getMillis();
            if (nextSendTime < dt.getMillis()) {
                nextSendTime += DateTimeConstants.MILLIS_PER_DAY;
            }
        }

        @Override
        public void run() {
            for (;;) {
                long currentTime = System.currentTimeMillis();
                while (currentTime < nextSendTime) {
                    try {
                        Thread.sleep(nextSendTime - currentTime);
                    } catch (InterruptedException e) {}
                    currentTime = System.currentTimeMillis();
                }
                try {
                    sendDailyMail();
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "failed to send mail", t);
                }
                try {
                    deleteOldStatisticFile();
                } catch (Throwable t) {
                    LOG.log(Level.WARNING,
                            "failed to delete old statistic file", t);
                }
                nextSendTime += DateTimeConstants.MILLIS_PER_DAY;
            }
        }

    }

    private final DateTimeFormatter dateFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");

    private void deleteOldStatisticFile() throws IOException {
        int life = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_METRICS_STATISTIC_FILE_LIFE,
                OmapConfig.DEFAULT_METRICS_STATISTIC_FILE_LIFE);
        long beforeTime = new DateTime().minusDays(life).getMillis();
        LOG.info("Delete staticstic files before "
                + dateFormatter.print(beforeTime));
        statisticRecorder.deleteStatisticFileBeforeTime(beforeTime);
    }

    private void sendDailyMail() throws IOException {
        LOG.info("send daily mail");
        HttpParams params = new BasicHttpParams();
        params.setIntParameter(CoreConnectionPNames.SO_TIMEOUT,
                2 * DateTimeConstants.MILLIS_PER_HOUR);
        params.setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
                2 * DateTimeConstants.MILLIS_PER_HOUR);
        HttpClient client = new DefaultHttpClient(params);
        HttpGet get = new HttpGet("http://127.0.0.1:"
                + OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_METRICS_STATISTIC_WEB_PORT,
                        OmapConfig.DEFAULT_METRICS_STATISTIC_WEB_PORT)
                + "/daily.s");
        HttpResponse res = client.execute(get);
        if (res.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String subject = "Omap Statistic Daily Report of "
                    + OmapConfig.getZkActiveMasterPath() + "("
                    + dateFormatter.print(System.currentTimeMillis()) + ")";
            HttpEntity entity = res.getEntity();
            int contentLength = (int) entity.getContentLength();
            ByteArrayOutputStream bos = contentLength > 0 ? new ByteArrayOutputStream(
                    contentLength) : new ByteArrayOutputStream();
            entity.writeTo(bos);
            String content = new String(bos.toByteArray(), "UTF-8");
            AlertUtils.sendEmail(subject, content);
        } else {
            AlertUtils.sendEmail("Failed to get daily report", "Request " + get
                    + " got http return code "
                    + res.getStatusLine().getStatusCode());
        }
    }

    public void join() throws InterruptedException {
        statisticWebServer.join();
    }

    public static void main(String[] args) throws Exception {
        OmapUtils.setupFileLogger("omapmetrics");
        OmapMetricsMonitor monitor = new OmapMetricsMonitor();
        monitor.join();
    }
}
