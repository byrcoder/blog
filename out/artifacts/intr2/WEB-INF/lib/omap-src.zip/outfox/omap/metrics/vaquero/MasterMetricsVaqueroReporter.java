/**
 * @(#)MasterMetricsReporter.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

import java.util.ArrayList;
import java.util.List;

import outfox.omap.conf.OmapConfig;
import outfox.omap.metrics.MasterMetricsEntry;
import outfox.omap.metrics.MasterMetricsType;
import outfox.omap.metrics.MasterTableMetricsEntry;

import vaquero.client.udp.AnalyzerMooee;

/**
 * @author zhangduo
 */
public class MasterMetricsVaqueroReporter {

    private final List<Updater> globalUpdaters;

    private final List<Updater> tableUpdaters;

    private final AnalyzerMooee mooee;

    private long prevTime;

    private void initUpdater() {
        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.NUM_TABLE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_TABLE_NUM.offset()));
        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.NUM_TABLET.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_TABLET_NUM.offset()));

        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.SYSTEM_LOAD.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_SYSTEM_LOAD.offset(), 100));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.SYSTEM_LOAD_PER_PROCESSOR.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_SYSTEM_LOAD.offset(),
                MasterMetricsType.GLOBAL_PROCESSOR_NUM.offset(), 100));

        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.MEMORY_INIT.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_MEMORY_INIT.offset(), 1024 * 1024));
        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.MEMORY_USED.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_MEMORY_USED.offset(), 1024 * 1024));
        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.MEMORY_COMMITTED.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_MEMORY_COMMITTED.offset(), 1024 * 1024));
        globalUpdaters.add(new OpNum(
                MasterMetricsVaqueroType.MEMORY_MAX.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_MEMORY_MAX.offset(), 1024 * 1024));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_REQUEST.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_REQUEST_NUM.offset()));
        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_TIMEOUT_REQUEST.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_TIMEOUT_REQUEST_NUM.offset()));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_GET_FS_NAME.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_FS_NAME_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_GET_FS_NAME.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_FS_NAME_DELAY.offset(),
                MasterMetricsType.GLOBAL_GET_FS_NAME_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_GET_TABLES.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_TABLES_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_GET_TABLES.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_TABLES_DELAY.offset(),
                MasterMetricsType.GLOBAL_GET_TABLES_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_GET_TABLES_IN_SPACE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_GET_TABLES_IN_SPACE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_DELAY.offset(),
                MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_GET_TABLESPACES.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_TABLESPACES_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_GET_TABLESPACES.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_GET_TABLESPACES_DELAY.offset(),
                MasterMetricsType.GLOBAL_GET_TABLESPACES_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_CREATE_TABLE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_CREATE_TABLE_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_CREATE_TABLE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_CREATE_TABLE_DELAY.offset(),
                MasterMetricsType.GLOBAL_CREATE_TABLE_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_DELETE_TABLE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_DELETE_TABLE_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_DELETE_TABLE.getVaqueroPropName(),
                MasterMetricsType.GLOBAL_DELETE_TABLE_DELAY.offset(),
                MasterMetricsType.GLOBAL_DELETE_TABLE_COUNT.offset()));

        tableUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_LOOKUP_KEY.getVaqueroPropName(),
                MasterMetricsType.LOOKUP_KEY_COUNT.offset()));
        tableUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_LOOKUP_KEY.getVaqueroPropName(),
                MasterMetricsType.LOOKUP_KEY_DELAY.offset(),
                MasterMetricsType.LOOKUP_KEY_COUNT.offset()));

        tableUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_RENAME_TABLE.getVaqueroPropName(),
                MasterMetricsType.RENAME_TABLE_COUNT.offset()));
        tableUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_RENAME_TABLE.getVaqueroPropName(),
                MasterMetricsType.RENAME_TABLE_DELAY.offset(),
                MasterMetricsType.RENAME_TABLE_COUNT.offset()));

        tableUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_SET_TABLE_PROPERTIES.getVaqueroPropName(),
                MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()));
        tableUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_SET_TABLE_PROPERTIES.getVaqueroPropName(),
                MasterMetricsType.SET_TABLE_PROPERTIES_DELAY.offset(),
                MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()));

        tableUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_GET_SCHEMA_ID.getVaqueroPropName(),
                MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()));
        tableUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_GET_SCHEMA_ID.getVaqueroPropName(),
                MasterMetricsType.GET_SCHEMA_ID_DELAY.offset(),
                MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()));

        tableUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_GET_METADATA.getVaqueroPropName(),
                MasterMetricsType.GET_METADATA_COUNT.offset()));
        tableUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_GET_METADATA.getVaqueroPropName(),
                MasterMetricsType.GET_METADATA_DELAY.offset(),
                MasterMetricsType.GET_METADATA_COUNT.offset()));

        tableUpdaters.add(new OpRate(
                MasterMetricsVaqueroType.RATE_SET_READ_ONLY.getVaqueroPropName(),
                MasterMetricsType.SET_READ_ONLY_COUNT.offset()));
        tableUpdaters.add(new OpAvg(
                MasterMetricsVaqueroType.DELAY_SET_READ_ONLY.getVaqueroPropName(),
                MasterMetricsType.SET_READ_ONLY_DELAY.offset(),
                MasterMetricsType.SET_READ_ONLY_COUNT.offset()));
    }

    private void initVaquero() {
        int lev = 0;
        MasterMetricsVaqueroDraw draw = MasterMetricsVaqueroDraw.INFO;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(MasterMetricsVaqueroType.NUM_TABLE.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(MasterMetricsVaqueroType.NUM_TABLET.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.LOAD;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.SYSTEM_LOAD.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                MasterMetricsVaqueroType.SYSTEM_LOAD_PER_PROCESSOR.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.MEMORY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.MEMORY_INIT.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                MasterMetricsVaqueroType.MEMORY_USED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                MasterMetricsVaqueroType.MEMORY_COMMITTED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(MasterMetricsVaqueroType.MEMORY_MAX.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.REQUEST_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_REQUEST.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_TIMEOUT_REQUEST.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.GET_FS_NAME_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_GET_FS_NAME.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.GET_FS_NAME_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_GET_FS_NAME.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.GET_TABLES_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_GET_TABLES.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.GET_TABLES_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_GET_TABLES.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.GET_TABLES_IN_SPACE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_GET_TABLES_IN_SPACE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.GET_TABLES_IN_SPACE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_GET_TABLES_IN_SPACE.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.GET_TABLESPACES_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_GET_TABLESPACES.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.GET_TABLESPACES_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_GET_TABLESPACES.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.CREATE_TABLE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_CREATE_TABLE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.CREATE_TABLE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_CREATE_TABLE.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.DELETE_TABLE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_DELETE_TABLE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.DELETE_TABLE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_DELETE_TABLE.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.LOOKUP_KEY_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_LOOKUP_KEY.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.LOOKUP_KEY_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_LOOKUP_KEY.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.RENAME_TABLE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_RENAME_TABLE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.RENAME_TABLE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_RENAME_TABLE.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.SET_TABLE_PROPERTIES_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_SET_TABLE_PROPERTIES.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.SET_TABLE_PROPERTIES_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_SET_TABLE_PROPERTIES.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.GET_SCHEMA_ID_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_GET_SCHEMA_ID.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.GET_SCHEMA_ID_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_GET_SCHEMA_ID.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.GET_METADATA_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_GET_METADATA.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.GET_METADATA_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_GET_METADATA.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = MasterMetricsVaqueroDraw.SET_READ_ONLY_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.RATE_SET_READ_ONLY.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = MasterMetricsVaqueroDraw.SET_READ_ONLY_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                MasterMetricsVaqueroType.DELAY_SET_READ_ONLY.getVaqueroPropName(),
                draw.getDrawName());
        
        mooee.moo();
    }

    public MasterMetricsVaqueroReporter(long currentTime) {
        globalUpdaters = new ArrayList<Updater>();
        tableUpdaters = new ArrayList<Updater>();
        initUpdater();
        ((ArrayList<Updater>) globalUpdaters).trimToSize();
        ((ArrayList<Updater>) tableUpdaters).trimToSize();

        String addr = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_METRICS_VAQUERO_ADDR);
        String host = addr.split(":")[0];
        int port = Integer.parseInt(addr.split(":")[1]);
        String product = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_METRICS_VAQUERO_PRODUCT);
        mooee = new AnalyzerMooee(host, port, product, product + "_master",
                "master");
        initVaquero();
        
        prevTime = currentTime;
    }

    public void update(MasterMetricsEntry metricsEntry, long currentTime) {
        for (Updater globalUpdater: globalUpdaters) {
            globalUpdater.update(
                    metricsEntry.getGlobalMetricsEntry().getMetricsRecords(),
                    prevTime, currentTime);
            mooee.report(globalUpdater.getVaqueroPropName(),
                    globalUpdater.getValue());
        }
        long[] tableMetricsRecords = new long[MasterMetricsType.tableTypeCount()];
        for (MasterTableMetricsEntry tableMetricsEntry: metricsEntry.getTableMetricsEntries().values()) {
            for (int i = 0; i < MasterMetricsType.tableTypeCount(); i++) {
                tableMetricsRecords[i] += tableMetricsEntry.getMetricsRecords()[i];
            }
        }
        for (Updater tableUpdater: tableUpdaters) {
            tableUpdater.update(tableMetricsRecords, prevTime, currentTime);
            mooee.report(tableUpdater.getVaqueroPropName(),
                    tableUpdater.getValue());
        }
        mooee.moo();
        prevTime = currentTime;
    }
}
