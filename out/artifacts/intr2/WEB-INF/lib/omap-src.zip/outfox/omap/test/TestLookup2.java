package outfox.omap.test;

import java.util.Date;
import java.util.Random;
import java.util.logging.Logger;

import junit.framework.TestCase;
import odis.io.FileSystem;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.LongWritable;

import org.apache.commons.lang.StringUtils;

import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.conf.OmapConfig;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapLogFormatter;

/**
 * This test assume table has serial keys: [0, MAX) <br>
 * Provide two lookup modes: random(seek by randomLong%MAX) and cursor(from 0)<br>
 * The data can be provided by dummy data source importer, see
 * {@link outfox.omap.util.importer.ImporterTaskManager} and
 * {@link outfox.omap.util.importer.DummyDataReader}
 * 
 * @author wangfk
 */
public class TestLookup2 {
    static FileSystem nfs;

    long maxkey;

    long count;

    int dataSize;

    String tableName = "TestTable2";

    String tablespace = "test";

    WorkerThread workers[] = null;

    private static Logger LOG = OmapLogFormatter.getLogger(TestLookup2.class.getName());

    private boolean stopOnNotFound = true;

    private boolean useCursor = false;

    private long id = 0;

    private int scancache;

    public TestLookup2(String[] args) throws Exception {
        for (int i = 0; i < args.length; i++)
            System.out.println(args[i]);

        id = Long.parseLong(args[0]);
        maxkey = Long.parseLong(args[1]);
        count = Long.parseLong(args[2]);

        workers = new WorkerThread[Integer.parseInt(args[3])];

        dataSize = Integer.parseInt(args[4]) - 8; //minus the size of the key
        if (args[5].equalsIgnoreCase("cursor")) {
            useCursor = true;
        }
        if (args[6].equalsIgnoreCase("false")) {
            stopOnNotFound = false;
        }

        tablespace = args[7];

        if (!StringUtils.isEmpty(args[8])) {
            tableName = args[8];
        }
        if (args.length > 9 && !StringUtils.isEmpty(args[9])) {
            scancache = Integer.parseInt(args[9]);
        } else {
            scancache = 10;
        }

        this.exec();
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 9) {
            System.out.println("USAGE:"
                    + "TestLookup2 <id> <max_key> <count> <workers> <dataSize> "
                    + "<useCursor?cursor:nocursor> <stopOnNotFound?true:false> <tablespace> <tableName> [scancache]");
            return;
        }
        new TestLookup2(args);

    }

    public void exec() throws Exception {

        long startTime = new Date().getTime();
        String[] colNames = new String[] {
            "key", "value"
        };
        String[] colTypes = new String[] {
            "LONG", "VINTBYTEARRAY"
        };
        Table testTable = null;
        try {
            TableSpace tableSpace = new OmapTableSpace(tablespace,
                    new MasterWatcherAndClientConfig(new ClientConfig(
                            OmapConfig.getConfiguration())));
            if (tableSpace.findTable(tableName) != null) {
                LOG.info("find table");
                testTable = tableSpace.openTable(tableName);
            } else {
                LOG.info("Create table");
                testTable = tableSpace.createTable(tableName, colNames,
                        colTypes);
            }

            if (testTable == null) {
                System.out.println("testTable=null");
                return;
            }

            System.out.println("Lookup record...");
            // nfs=FileSystem.get();

            // initialize worker threads

            for (int i = 0; i < workers.length; i++) {
                workers[i] = new WorkerThread(testTable, i, count
                        / workers.length);
            }

            // start worker threads
            for (int i = 0; i < workers.length; i++) {
                workers[i].start();
                LOG.info("thread " + i + " started");
            }
            long currentNum = 0;
            long lastNum = 0;
            // monitor worker threads
            while (true) {

                try {
                    Thread.sleep(5000);
                    boolean allEnd = true;
                    for (int i = 0; i < workers.length; i++)
                        if (workers[i].end == false) {
                            allEnd = false;
                            break;
                        }
                    if (allEnd)
                        break;
                    lastNum = currentNum;
                    currentNum = 0;
                    double periodResponseTime = 0.0;
                    for (int i = 0; i < workers.length; i++) {
                        System.out.println("Worker" + i + ":" + workers[i].num);
                        currentNum += workers[i].num;
                        periodResponseTime += workers[i].periodResponseTime;
                        workers[i].periodResponseTime = 0.0;
                    }
                    LOG.info("Total:" + currentNum);
                    LOG.info("Throughtput:" + (currentNum - lastNum));
                    LOG.info("periodResponseTime:" + periodResponseTime
                            / (double) (currentNum - lastNum));

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } catch (Error e) {
            e.printStackTrace();
        } finally {
            System.out.println("End");
            double totalResponseTime = 0.0;
            double maxResponseTime = 0.0;
            long totalNotFound = 0;
            for (int i = 0; i < workers.length; i++) {
                totalResponseTime += workers[i].totalResponseTime;
                totalNotFound += workers[i].notFound;
                if (workers[i].maxResponseTime > maxResponseTime)
                    maxResponseTime = workers[i].maxResponseTime;

            }
            long endTime = new Date().getTime();
            double totalTime = (double) (endTime - startTime) / 1000.0;
            LOG.info("Total time:" + totalTime);
            LOG.info("Throughtput:" + (double) count / totalTime);
            LOG.info("Average Response Time:" + totalResponseTime
                    / (double) count * 1000);
            LOG.info("Max Response Time:" + maxResponseTime);
            LOG.info("Not found:" + totalNotFound);

        }
        if (stopOnNotFound) {
            TestCase.assertFalse("All found", stopped);
        }
    }

    private boolean stopped = false;

    private void stop() {
        System.out.println("Stopping");
        stopped = true;
    }

    private class WorkerThread extends Thread {
        public int num = 0;

        public long notFound = 0;

        public boolean end = false;

        long count;

        long scanFrom = 0;

        Table table;

        private Random rand = new Random();

        double totalResponseTime = 0.0;

        double maxResponseTime = 0.0;

        double periodResponseTime = 0.0;

        /**
         * @param testTable
         * @param maxkey
         * @param count
         */
        public WorkerThread(Table testTable, long index, long count) {
            this.count = count;
            this.table = testTable;
            rand.setSeed((id << 8) + index);
            this.scanFrom = index * count;
        }

        public void run() {
            ByteArrayWritable bytes = new ByteArrayWritable();
            LongWritable longWritable = new LongWritable();
            long key = -1;
            Row row = null;
            try {
                row = table.newRow();
            } catch (OmapException e) {
                e.printStackTrace();
                return;
            }
            TableCursor cursor = null;
            if (useCursor) {
                try {
                    cursor = table.getTableCursor();
                    cursor.setPrefetch(scancache);
                    longWritable.set(scanFrom);
                    cursor.moveTo(longWritable, true);
                    LOG.info("cursor: " + cursor);
                } catch (Exception e) {
                    e.printStackTrace();
                    TestLookup2.this.stop();
                }
            }
            while (num < count && !stopped) {
                try {
                    Long start = new Date().getTime();
                    boolean found;
                    if (useCursor) {
                        ++key;
                        found = cursor.next(row);
                    } else {
                        key = rand.nextLong();
                        if (key < 0) {
                            key *= (-1);
                        }
                        key = key % maxkey;
                        found = table.lookup(new LongWritable(key), row);
                    }
                    if (found) {
                        row.get("key", longWritable);

                        if (longWritable.get() != key) {
                            LOG.warning("Looked up key=" + key
                                    + ", but found key=" + longWritable.get()
                                    + ", i=" + num);
                            if (stopOnNotFound) {
                                TestLookup2.this.stop();
                            }
                            key = longWritable.get();
                        }
                        row.get("value", bytes);
                        if (bytes.size() != dataSize) {
                            LOG.warning("Got data size=" + bytes.size()
                                    + ", but expected size=" + dataSize
                                    + ", i=" + num);
                            if (stopOnNotFound) {
                                TestLookup2.this.stop();
                            }
                        }
                        byte expectedByte = (byte) (key & 0xFF);
                        if (bytes.getByte(0) != (byte) (key & 0xFF)) {
                            LOG.warning("Got first byte= " + bytes.getByte(0)
                                    + ", expected=" + expectedByte + ", i="
                                    + num);
                            if (stopOnNotFound) {
                                TestLookup2.this.stop();
                            }
                        }
                    } else {
                        if (notFound == 0) {
                            LOG.warning("Key:" + key + " not found, i=" + num);
                        }
                        notFound++;
                        if (stopOnNotFound) {
                            TestLookup2.this.stop();
                        }
                    }
                    Long end = new Date().getTime();

                    double time = (double) (end - start) / 1000.0;
                    if (time > this.maxResponseTime)
                        this.maxResponseTime = time;
                    this.totalResponseTime += time;
                    this.periodResponseTime += time;
                    num++;
                } catch (Exception e) {
                    e.printStackTrace();
                    TestLookup2.this.stop();
                } catch (Error e) {
                    e.printStackTrace();
                    TestLookup2.this.stop();
                }

            }

            if (useCursor) {
                notFound = key - num + 1;
            }

            end = true;
        }

    }

}
