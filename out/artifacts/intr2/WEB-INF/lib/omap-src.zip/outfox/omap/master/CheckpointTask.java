package outfox.omap.master;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import odis.serialize.IWritable;
import outfox.omap.ts.OmapTs;
import toolbox.text.util.HexString;

public class CheckpointTask extends Task {
    /**
     * TabletIDs that to be checkpointed.
     */
    private List<Long> tablets;
    public List<Long> getTablets() {
        return tablets;
    }
    public CheckpointTask() {
        super();
    }
    public CheckpointTask(Collection<Long> tablets, String reason) {
        super(reason);
        this.tablets = new ArrayList<Long>();
        this.tablets.addAll(tablets);
    }
    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        int tabletCount = in.readInt();
        tablets = new ArrayList<Long>(tabletCount);
        for(int i = 0; i < tabletCount; i++) {
            tablets.add(in.readLong());
        }
    }
    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        out.writeInt(tablets.size());
        for(long tablet : tablets) {
            out.writeLong(tablet);
        }
    }
    @Override
    public IWritable copyFields(IWritable value) {
        super.copyFields(value);
        tablets = new ArrayList<Long>();
        tablets.addAll(((CheckpointTask)value).tablets);
        return this;
    }
    @Override
    public int execTask(OmapTs ts) {
        for(long tablet : tablets) {
            ts.checkpoint(tablet);
        }
        return 0;
    }
    @Override
    public String getTaskDetail() {
        StringBuilder buffer = new StringBuilder();
        buffer.append("CHECKPOINT: ");
        for(int i = 0; i < tablets.size(); i++) {
            if(i > 0) {
                buffer.append(" ");
            }
            buffer.append(HexString.longToPaddedHex(tablets.get(i)));
        }
        return buffer.toString();
    }

    public void rollbackTask(OmapTs ts) {
        // nothing
    }

}
