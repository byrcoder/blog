/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

import outfox.omap.test.bench.WorkloadRunner.AccessType;
import outfox.omap.test.bench.WorkloadRunner.ThreadManager;

/**
 *
 * @author zhangkun
 */
class ConcurrencyFlowController extends FlowController {
    private int expectedConcurrency;
    public ConcurrencyFlowController() {}
    public void setExpectedConcurrency(int concurrency) {
        this.expectedConcurrency = concurrency;
    }
    public ConcurrencyFlowController(AccessType accessType, int expectedConcurrency) {
        super(accessType);
        this.expectedConcurrency = expectedConcurrency;
    }
    @Override
    protected void workThreadRest() {
        // Do nothing
    }

    @Override
    protected void throughputUpdated(ThreadManager tm) {
        int current = tm.getNumThreads();
        if(current < expectedConcurrency) {
            tm.addThread(expectedConcurrency - current);
        } else if(current > expectedConcurrency) {
            tm.reduceThread(current - expectedConcurrency);
        }
    }
    
    @Override
    public String toString() {
        return "[" + this.getClass().getSimpleName() + " expectedConcurrency=" + expectedConcurrency + "]";
    }

}
