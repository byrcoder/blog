/**
 * @(#)CatalogueLogRange.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import outfox.omap.common.TsDesc;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogBody;

/**
 * @author zhangduo
 */
public class CatalogueLogRange implements WALogBody {

    private SchemaIdAndRange[] ranges;

    private boolean[] deleted;

    private TsDesc[] tsDescs;

    public CatalogueLogRange() {}

    public CatalogueLogRange(SchemaIdAndRange range, boolean deleted,
            TsDesc tsDesc) {
        this(new SchemaIdAndRange[] {
            range
        }, new boolean[] {
            deleted
        }, new TsDesc[] {
            tsDesc
        });
    }

    public CatalogueLogRange(SchemaIdAndRange[] ranges, boolean[] deleted,
            TsDesc[] tsDescs) {
        this.ranges = ranges;
        this.deleted = deleted;
        this.tsDescs = tsDescs;
    }

    public SchemaIdAndRange[] getRanges() {
        return ranges;
    }

    public void setRanges(SchemaIdAndRange[] ranges) {
        this.ranges = ranges;
    }

    public boolean[] getDeleted() {
        return deleted;
    }

    public void setDeleted(boolean[] deleted) {
        this.deleted = deleted;
    }

    public TsDesc[] getTsDescs() {
        return tsDescs;
    }

    public void setTsDescs(TsDesc[] tsDescs) {
        this.tsDescs = tsDescs;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int sz = CDataInputStream.readVInt(in);
        ranges = new SchemaIdAndRange[sz];
        for (int i = 0; i < sz; i++) {
            ranges[i] = new SchemaIdAndRange();
            ranges[i].readFields(in);
        }
        deleted = new boolean[sz];
        for (int i = 0; i < sz; i++) {
            deleted[i] = in.readBoolean();
        }
        tsDescs = new TsDesc[sz];
        for (int i = 0; i < sz; i++) {
            if (!deleted[i]) {
                tsDescs[i] = new TsDesc();
                tsDescs[i].readFields(in);
            }
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(ranges.length, out);
        for (SchemaIdAndRange range: ranges) {
            range.writeFields(out);
        }
        for (boolean d: deleted) {
            out.writeBoolean(d);
        }
        for (int i = 0; i < deleted.length; i++) {
            if (!deleted[i]) {
                tsDescs[i].writeFields(out);
            }
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        CatalogueLogRange v = (CatalogueLogRange) value;
        ranges = new SchemaIdAndRange[v.ranges.length];
        for (int i = 0; i < v.ranges.length; i++) {
            ranges[i] = new SchemaIdAndRange();
            ranges[i].copyFields(v.ranges[i]);
        }
        deleted = new boolean[v.deleted.length];
        System.arraycopy(v.deleted, 0, deleted, 0, deleted.length);
        tsDescs = new TsDesc[v.tsDescs.length];
        for (int i = 0; i < v.tsDescs.length; i++) {
            if (!deleted[i]) {
                tsDescs[i] = new TsDesc();
                tsDescs[i].copyFields(v.tsDescs[i]);
            }
        }
        return this;
    }

    @Override
    public String toString() {
        return "CatalogueLogRange [ranges=" + Arrays.toString(ranges)
                + ", deleted=" + Arrays.toString(deleted) + ", tsDescs="
                + Arrays.toString(tsDescs) + "]";
    }

    @Override
    public String toStructuredString(MetadataProvider provider) {
        return toString();
    }

}
