package outfox.omap.client;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

import odis.rpc2.RpcException;
import odis.serialize.IWritableComparable;
import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.protocol.AbstractTableSpace;
import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryCondition;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryCondition;
import outfox.omap.client.query.OmapQueryUtils;
import outfox.omap.exceptions.NoSuchSchemaException;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapLogFormatter;
import outfox.omap.util.OmapUtils;

/**
 * <p>
 * The OmapTableSpace manages Tables on a OMAP instance.
 * </p>
 * <p>
 * The Table Space is a flat name space to isolate the names of the Tables on a
 * OMAP instance. A Table must be within a Table Space.
 * </p>
 * <p>
 * The name of Tables Spaces, Tables and Fields could consist of any characters
 * except '$'.
 * </p>
 * 
 * @author zhangkun
 */
public class OmapTableSpace extends AbstractTableSpace {
    public Logger LOG = OmapLogFormatter.getLogger(OmapTableSpace.class);

    private final MasterWatcherAndClientConfig masterWatcher;

    protected String tableSpaceName;

    public String getName() {
        return tableSpaceName;
    }

    public MasterWatcherAndClientConfig getMasterWatcher() {
        return masterWatcher;
    }

    /**
     * Construct an OmapTableSpace instance to access a table space on OMAP.
     * 
     * @param tableSpaceName
     * @throws OmapException
     */
    public OmapTableSpace(String tableSpaceName,
            MasterWatcherAndClientConfig masterWatcher) throws OmapException {
        OmapUtils.validateTableName(tableSpaceName);
        this.tableSpaceName = tableSpaceName;
        this.masterWatcher = masterWatcher;
    }

    public ClientMasterProtocol getMaster() {
        return masterWatcher.getMaster();
    }

    public MetadataCache getMetadataCache() {
        return masterWatcher.getMetadataCache();
    }

    /**
     * Close this OmapTableSpace.
     */
    public void close() {

    }

    public String toInternalTableName(String tableName) {
        return OmapUtils.toInternalTableName(tableSpaceName, tableName);
    }

    /**
     * Create a Table with the given tableName. Define the name and type of
     * every column. The first column is the key, by which the rows are sorted
     * in ascending order. The key can be also used in lookup.
     * 
     * @param tableName
     *            the name of the Table.
     * @param colNames
     *            The names of the columns.
     * @param colTypes
     *            The types of the columns. For types, see
     *            {@link outfox.omap.metadata.Types}
     * @throws OmapException
     */
    public Table createTable(String tableName, String[] colNames,
            String[] colTypes, Query[] queries) throws OmapException {
        long timeout = masterWatcher.getConf().getLong(
                ClientConfig.NAME_CLIENT_CONNECT_TIMEOUT,
                ClientConfig.DEFAULT_CLIENT_CONNECT_TIMEOUT);
        return createTable(tableName, colNames, colTypes, queries, timeout);
    }

    /**
     * Create a Table with the given tableName. Define the name and type of
     * every column. The first column is the key, by which the rows are sorted
     * in ascending order. The key can be also used in lookup.
     * 
     * @param tableName
     *            the name of the Table.
     * @param colNames
     *            The names of the columns.
     * @param colTypes
     *            The types of the columns. For types, see
     *            {@link outfox.omap.metadata.Types}
     * @param timeout
     *            the timeout used by the returned Table
     * @throws OmapException
     */
    public Table createTable(String tableName, String[] colNames,
            String[] colTypes, Query[] queries, long timeout)
            throws OmapException {
        OmapUtils.validateTableName(tableName);
        return internalCreateTable(toInternalTableName(tableName), colNames,
                colTypes,
                OmapQueryUtils.convertQueryArrayToOmapQueryArray(queries),
                timeout);
    }

    private Table internalCreateTable(String tableName, String[] colNames,
            String[] colTypes, OmapQuery[] queries, long timeout)
            throws OmapException {
        for (String name: colNames) {
            OmapUtils.validateTableName(name);
        }
        LOG.info("Creating " + tableName + ", colNames="
                + Arrays.toString(colNames) + ", colTypes="
                + Arrays.toString(colTypes));

        // directly create table
        createTableSimple(tableName, colNames, colTypes, queries, timeout);
        return internalOpenTable(tableName, timeout);
    }

    private void createTableSimple(String tableName, String[] colNames,
            String[] colTypes, OmapQuery[] queries, long timeout)
            throws OmapException {
        if (colNames.length != colTypes.length) {
            throw new OmapException(
                    "Canot createTable, numbers of colNames and colTypes not match!.");
        }
        String fields = StringUtils.join(colNames, "; ");
        String types = StringUtils.join(colTypes, "; ");
        try {
            OmapClient retClient = new OmapClient(masterWatcher, tableName,
                    timeout);
            retClient.createTable(fields, types, queries);
        } catch (IOException e) {
            throw new OmapException(e);
        }
    }

    /**
     * Delete the table with the given tableName in this tableSpace.
     * 
     * @param tableName
     *            the name of the table.
     * @throws OmapException
     */
    public void deleteTable(String tableName) throws OmapException {
        internalDeleteTable(toInternalTableName(tableName));
    }

    private void internalDeleteTable(String tableName) throws OmapException {
        Table table = this.internalOpenTable(tableName, 0);
        if (table == null) {
            throw new OmapException(tableName + " not existed");
        }
        OmapUserTable userTable = (OmapUserTable) table;
        userTable.client.deleteTable();
    }

    public Metadata[] listTables() throws OmapException {
        try {
            return masterWatcher.getMaster().getTables(tableSpaceName);
        } catch (RpcException e) {
            throw new OmapException(e);
        }
    }

    /**
     * Find table in this table space using the given tableName. Return the
     * metadata of the table if found.
     * 
     * @param tableName
     *            the name of the table
     * @return return the metadata of the table if the table if found in this
     *         table space, if not found, return null. See
     *         {@link outfox.omap.client.protocol.Metadata}
     * @throws OmapException
     */
    public OmapMetadata findTable(String tableName) throws OmapException {
        return internalFindTable(toInternalTableName(tableName));
    }

    private OmapMetadata internalFindTable(String tableName)
            throws OmapException {
        try {
            return masterWatcher.getMetadataCache().findMetadata(tableName);
        } catch (NoSuchSchemaException e) {
            LOG.log(Level.INFO, "", e);
            return null;
        } catch (RpcException e) {
            throw new OmapException("internalFindTable failed", e);
        }
    }

    /**
     * Open the table with the given tableName in this tablespace, and return
     * it.
     * 
     * @param tableName
     *            the name of the table;
     * @return the opened table as {@link outfox.omap.client.protocol.Table}
     * @throws OmapException
     */
    @Override
    public OmapUserTable openTable(String tableName) throws OmapException {
        long timeout = masterWatcher.getConf().getLong(
                ClientConfig.NAME_CLIENT_CONNECT_TIMEOUT,
                ClientConfig.DEFAULT_CLIENT_CONNECT_TIMEOUT);
        return openTable(tableName, timeout);
    }

    /**
     * Open the table with the given tableName in this tablespace, and return
     * it.
     * 
     * @param tableName
     *            the name of the table;
     * @param timeout
     *            the operation timeout used by the returned Table
     * @return the opened table as {@link outfox.omap.client.protocol.Table}
     * @throws OmapException
     */
    public OmapUserTable openTable(String tableName, long timeout)
            throws OmapException {
        return internalOpenTable(toInternalTableName(tableName), timeout);
    }

    private OmapUserTable internalOpenTable(String tableName, long timeout)
            throws OmapException {
        if (internalFindTable(tableName) == null) {
            return null;
        }
        try {
            OmapClient retClient = new OmapClient(masterWatcher, tableName,
                    timeout);
            if (retClient.getTableName().equals(tableName)) {
                LOG.info("opening normal table " + tableName);
                return new OmapUserTable(retClient, this);
            } else {
                return null;
            }
        } catch (IOException e) {
            throw new OmapException(e);
        }
    }

    public void snapshot(String tableName, String targetDir, boolean checkpoint)
            throws OmapException {
        LOG.info("Snapshoting table" + tableName);
        Table t = openTable(tableName);
        if (t != null) {
            LOG.info("Table " + tableName + "is a simple table.");
            LOG.info("Snapshot table " + tableName + " to " + targetDir
                    + "....");
            try {
                masterWatcher.getNoTimeoutMaster().snapshot(
                        toInternalTableName(tableName), targetDir, checkpoint);
            } catch (Exception e) {
                throw new OmapException(e);
            }
            LOG.info("Done snapshot table " + tableName);
        }
    }

    public void importSnapshot(String tableName, String targetDir)
            throws OmapException {
        try {
            masterWatcher.getNoTimeoutMaster().importSnapshot(
                    toInternalTableName(tableName), targetDir);
        } catch (Exception e) {
            throw new OmapException(e);
        }
    }

    public Query createQuery(String queryName, QueryCondition[] conditions) {
        OmapQueryCondition[] omapConditions = OmapQueryUtils.convertQueryConditionArrayToOmapQueryConditionArray(conditions);
        return new OmapQuery(queryName, omapConditions);
    }

    public Query createQuery(String queryName, QueryCondition[] conditions,
            int offset) {
        OmapQueryCondition[] omapConditions = OmapQueryUtils.convertQueryConditionArrayToOmapQueryConditionArray(conditions);
        return new OmapQuery(queryName, omapConditions, offset);
    }

    public Query createQuery(String queryName, QueryCondition[] conditions,
            int offset, int limit) {
        OmapQueryCondition[] omapConditions = OmapQueryUtils.convertQueryConditionArrayToOmapQueryConditionArray(conditions);
        return new OmapQuery(queryName, omapConditions, offset, limit);
    }

    public QueryCondition createQueryCondition(String colName, QueryOperation op) {
        return new OmapQueryCondition(colName, op);
    }

    public QueryCondition createQueryCondition(String colName,
            QueryOperation op, IWritableComparable para1) {
        return new OmapQueryCondition(colName, op, para1);
    }

    public QueryCondition createQueryCondition(String colName,
            QueryOperation op, IWritableComparable para1,
            IWritableComparable para2) {
        return new OmapQueryCondition(colName, op, para1, para2);

    }

    @Override
    public String toString() {
        return "[" + this.getClass().getSimpleName() + " spacename="
                + tableSpaceName + "]";
    }

    @Override
    public void renameTable(String originName, String currName)
            throws OmapException {
        OmapUtils.validateTableName(originName);
        OmapUtils.validateTableName(currName);

        try {
            masterWatcher.getMaster().renameTable(
                    toInternalTableName(originName),
                    toInternalTableName(currName));
        } catch (Exception e) {
            LOG.info("Raname table name error: from " + originName + " to "
                    + currName);
            throw new OmapException(e);
        }
        masterWatcher.getMetadataCache().clearTableInfo(
                toInternalTableName(originName));
    }
}
