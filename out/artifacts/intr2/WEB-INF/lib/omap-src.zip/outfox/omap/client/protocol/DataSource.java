package outfox.omap.client.protocol;

import outfox.omap.exceptions.OmapException;

/**
 * DataSource is a global Omap instance, you can open many table spaces on a
 * DataSource, and there is no relationship between two different table spaces.
 * 
 * @author yaming
 */
public interface DataSource {

    /**
     * Acquire new table space instance on this datasource.
     * 
     * @return a table space as {@link outfox.omap.client.protocol.TableSpace}
     * @throws IOException
     */
    TableSpace openTableSpace(String tableSpaceName) throws OmapException;

    /**
     * list all TableSpaces.
     * 
     * @return
     * @throws OmapException
     */
    String[] listTableSpaces() throws OmapException;

    /**
     * Increment reference count and return whether the DataSource is still
     * alive.
     * 
     * @return
     */
    boolean retain();

    /**
     * Close the DataSource.
     */
    void close();

}
