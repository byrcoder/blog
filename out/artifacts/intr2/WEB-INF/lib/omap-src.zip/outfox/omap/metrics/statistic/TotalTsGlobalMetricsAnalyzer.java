/**
 * @(#)TotalTsGlobalMetricsAnalyzer.java, 2011-6-20. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TsMetricsType;

/**
 * @author zhangduo
 */
public class TotalTsGlobalMetricsAnalyzer extends TsGlobalMetricsAnalyzer {
    public void process(long[] metricsRecords) {
        for (int i = 0; i < TsMetricsType.globalTypeCount(); i++) {
            this.metricsRecords[i] += metricsRecords[i];
        }
    }

    public void incCount() {
        count++;
    }
}
