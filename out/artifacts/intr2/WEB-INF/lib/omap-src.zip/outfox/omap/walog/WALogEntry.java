/**
 * @(#)WALogEntry.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.walog;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import toolbox.text.util.HexString;

public abstract class WALogEntry implements IWritable {
    /**
     * The end flag of every log entry when serialized.<br>
     * Note that the 4 bytes of this flag is different, this can be useful when
     * searching for valid LogEntries in a broken file.
     */
    public static final int END_FLAG = (132 << 24) + (57 << 16) + (238 << 8)
            + 3;

    /**
     * The Log Serial No.
     */
    private long LSN;

    private long timeStamp;

    /**
     * May be one of {@value WALogEntry#TYPE_INSERT},
     * {@value WALogEntry#TYPE_CHKPT}
     */
    protected int logType;

    protected WALogBody body;

    /**
     * Back pointer, pointing to the position of previous log entry in the log
     * file
     */
    private long backptr;

    /**
     * This field is not serialized. Used to return if writes successful
     */
    private WRITE_STATUS writeStatus;

    public static enum WRITE_STATUS {
        SUCCESS, FLUSH_ERROR
    }

    public WRITE_STATUS getWriteStatus() {
        return writeStatus;
    }

    public void setWriteStatus(WRITE_STATUS writeStatus) {
        this.writeStatus = writeStatus;
    }

    public long getLSN() {
        return LSN;
    }

    public void setLSN(long value) {
        LSN = value;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public int getLogType() {
        return logType;
    }

    public long getBackPointer() {
        return backptr;
    }

    public void setBackPointer(long ptr) {
        backptr = ptr;
    }

    public WALogBody getBody() {
        return body;
    }

    abstract public void setBody(WALogBody body)
            throws CorruptedWALogEntryException;

    abstract protected void prepareLogBody(int logType)
            throws CorruptedWALogEntryException;

    public void readFields(DataInput in) throws IOException {
        this.timeStamp = in.readLong();
        this.LSN = in.readLong();
        this.logType = in.readInt();
        prepareLogBody(logType);
        this.body.readFields(in);
        this.backptr = in.readLong();
        int endFlag = in.readInt();
        if (endFlag != END_FLAG) { // read end flag
            throw new CorruptedWALogEntryException("incomplete log entry, LSN="
                    + LSN + ", body=" + body);
        }
    }

    public IWritable copyFields(IWritable value) {
        WALogEntry val = (WALogEntry) value;
        this.timeStamp = val.timeStamp;
        this.LSN = val.LSN;
        this.logType = val.logType;
        try {
            prepareLogBody(logType);
        } catch (CorruptedWALogEntryException e) {
            throw new RuntimeException(e);
        }
        body.copyFields(val.body);
        this.backptr = val.backptr;
        return this;
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(timeStamp);
        out.writeLong(this.LSN);
        out.writeInt(this.logType);
        body.writeFields(out);
        out.writeLong(backptr);
        out.writeInt(END_FLAG);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        WALogEntry v = (WALogEntry) obj;
        // one log entry can move among log files,, not need to check back pointer
        return (this.LSN == v.LSN) && this.logType == v.logType
                && this.body.equals(v.body);
    }

    @Override
    public int hashCode() {
        return logType ^ (int) LSN ^ this.body.hashCode();
    }

    public String toStructuredString(MetadataProvider provider) {
        StringBuilder sb = new StringBuilder();

        sb.append(HexString.longToPaddedHex(LSN)).append(" ").append(
                this.logType);
        sb.append('(').append(body.toStructuredString(provider)).append(')');
        sb.append("<-" + this.backptr);
        sb.append(" ").append(super.toString());
        return sb.toString();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("%16X", LSN)).append(" ").append(this.logType);
        sb.append('(').append(body).append(')');
        sb.append("<-" + this.backptr);
        sb.append(" ").append(super.toString());
        return sb.toString();
    }

}
