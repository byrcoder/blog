/**
 * @(#)MockOmapDataSource.java, 2009-4-29. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol.mock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.exceptions.OmapException;

/**
 * @author zhangduo
 */
public class MockOmapDataSource implements DataSource {

    private final Map<String, MockOmapTableSpace> tableSpaces = new HashMap<String, MockOmapTableSpace>();

    private final List<OpInterceptor> interceptors = new ArrayList<OpInterceptor>();

    @Override
    public synchronized TableSpace openTableSpace(String tableSpaceName)
            throws OmapException {
        MockOmapTableSpace tableSpace = tableSpaces.get(tableSpaceName);
        if (tableSpace == null) {
            tableSpace = new MockOmapTableSpace(tableSpaceName, interceptors);
            tableSpaces.put(tableSpaceName, tableSpace);
        }
        return tableSpace;
    }

    @Override
    public void close() {}

    @Override
    public String[] listTableSpaces() throws OmapException {
        return tableSpaces.keySet().toArray(new String[0]);
    }

    @Override
    public boolean retain() {
        return true;
    }

    public void addInterceptor(OpInterceptor interceptor) {
        interceptors.add(interceptor);
    }

    public void clearInterceptor() {
        interceptors.clear();
    }
}
