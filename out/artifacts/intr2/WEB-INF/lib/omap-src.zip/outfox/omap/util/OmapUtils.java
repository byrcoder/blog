package outfox.omap.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockInfo;
import odis.dfs.common.DFSClientConfig;
import odis.file.SequenceFile;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FSInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritableComparable;
import odis.util.MiscUtils;

import org.apache.commons.configuration.BaseConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;

import outfox.omap.client.protocol.AbstractTableSpace;
import outfox.omap.conf.OmapConfig;
import outfox.omap.conf.OmapConstants;
import outfox.omap.data.IPreInitializedWritable;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.exceptions.BadSchemaDefinitionException;
import outfox.omap.exceptions.BadTableNameException;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

public class OmapUtils {
    private static final Logger LOG = LogFormatter.getLogger(OmapUtils.class);

    /**
     * Parse the Table definition into column names and types.
     * 
     * @param def
     *            the definition string
     * @return returned[0] is the column names array. returned[1] is the column
     *         types array.
     */
    public static String[][] parseTableDefinition(String def) {
        String trailingDef = def + " "; // add space to the end to make the
        // parsing easier
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<String> types = new ArrayList<String>();
        int bracketLevel = 0;
        StringBuilder currentColumn = new StringBuilder();
        for (int i = 0; i < trailingDef.length(); i++) {
            char ch = trailingDef.charAt(i);
            if (ch == ' ') {
                if (bracketLevel == 0) {
                    if (currentColumn.length() > 0) {
                        String colDef = currentColumn.toString();
                        int sepPos = colDef.indexOf(AbstractTableSpace.NAME_TYPE_SEPARATOR);
                        if (sepPos == -1) {
                            throw new BadSchemaDefinitionException("Missing '"
                                    + AbstractTableSpace.NAME_TYPE_SEPARATOR
                                    + "' in column definition '" + colDef + "'");
                        }
                        names.add(colDef.substring(0, sepPos));
                        types.add(colDef.substring(sepPos + 1));
                        currentColumn = new StringBuilder();
                    }
                } else if (currentColumn.length() > 0) {
                    // within a bracket, the space is added
                    currentColumn.append(ch);
                }
            } else {
                // non-spaces are added anyway
                currentColumn.append(ch);
                if (ch == '(') {
                    bracketLevel++;
                } else if (ch == ')') {
                    if (bracketLevel > 0) {
                        bracketLevel--;
                    } else {
                        throw new BadSchemaDefinitionException(
                                "dismatched ')' at " + i
                                        + " in Table definition '" + def + "'");
                    }
                }
            }
        }
        String[][] returned = new String[2][];
        returned[0] = names.toArray(new String[names.size()]);
        returned[1] = types.toArray(new String[types.size()]);
        return returned;
    }

    /**
     * Split a command line into parameters. Parameters are separated by spaces,
     * except that the spaces between a pair of quotes (&quot;) are considered
     * part of a parameter.
     * 
     * @param line
     * @return
     */
    public static String[] parseCmdLine(String line) {
        ArrayList<String> result = new ArrayList<String>();
        boolean inQuotes = false;
        boolean tokenStart = false;
        int startIndex = 0;
        for (int i = 0; i < line.length(); i++) {
            if (!tokenStart) {
                if (line.charAt(i) != ' ' && line.charAt(i) != '"') {
                    startIndex = i;
                    tokenStart = true;
                    if (i == (line.length() - 1)) {
                        result.add(line.substring(startIndex, i + 1));
                    }
                } else if (line.charAt(i) == '"') {
                    startIndex = i + 1;
                    inQuotes = true;
                    tokenStart = true;
                }
            } else {
                if (inQuotes) {
                    if (line.charAt(i) == '"') {
                        result.add(line.substring(startIndex, i));
                        tokenStart = false;
                        inQuotes = false;
                    }
                } else {
                    if (line.charAt(i) == ' ') {
                        result.add(line.substring(startIndex, i));
                        tokenStart = false;
                    } else if (i == (line.length() - 1)) {
                        result.add(line.substring(startIndex, i + 1));
                        tokenStart = false;
                    }
                }
            }
        }
        String[] ret = new String[result.size()];
        result.toArray(ret);
        return ret;
    }

    public static byte[] convertPIWritableToBytes(IPreInitializedWritable data) {
        ByteArrayOutputStream ostream = new ByteArrayOutputStream();
        CDataOutputStream dstream = new CDataOutputStream(ostream);

        try {
            data.writePIFields(dstream);
            byte[] b = ostream.toByteArray();
            return b;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            MiscUtils.safeClose(dstream);
            MiscUtils.safeClose(ostream);
        }
    }

    // length can help us find some bugs
    public static void convertBytesToPIWritable(byte[] b, int offset,
            int length, IPreInitializedWritable data) {
        ByteArrayInputStream istream = new ByteArrayInputStream(b, offset,
                length);
        CDataInputStream dstream = new CDataInputStream(istream);

        try {
            data.readPIFields(dstream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            MiscUtils.safeClose(dstream);
            MiscUtils.safeClose(istream);
        }
    }

    public static void convertBytesToPIWritable(byte[] b,
            IPreInitializedWritable data) {
        convertBytesToPIWritable(b, 0, b.length, data);
    }

    public static void setupFileLogger(String serviceType) throws IOException {
        File logDir = new File(OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_LOG_OUTPUT_DIR,
                OmapConfig.DEFAULT_LOG_OUTPUT_DIR));
        if (!logDir.exists()) {
            if (!logDir.mkdirs()) {
                throw new IOException("Create log dir " + logDir + " failed");
            }
        }
        LogFormatter.clearLoggerHandlers("");
        LogFormatter.setRotateFileLogger(
                "",
                logDir.getPath(),
                serviceType + ".log",
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_LOG_FILE_SIZE_LIMIT,
                        OmapConfig.DEFAULT_LOG_FILE_SIZE_LIMIT),
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_LOG_FILE_COUNT_LIMIT,
                        OmapConfig.DEFAULT_LOG_FILE_COUNT_LIMIT), true);
    }

    /**
     * Given an array of column names, such as TYPE1, TYPE2, TYPE3, TYPE4 .....,
     * build a declaration of tuple key such as TPKEY(TYPE1 TPKEY(TYPE2,
     * TPKEY(TYPE3, TPKEY(TYPE4, ...)))). If there is only one column type name,
     * it will be simply returned without TPKEY. This guarantees that the result
     * can be directly applied in the createTable method.
     * 
     * @param colTypeNames
     * @return the TPKEY declaration
     */
    public static String buildTupleKeyDeclaration(String[] colTypeNames) {
        if (colTypeNames.length == 0)
            throw new RuntimeException("Cannot build TPKEY for nothing");
        if (colTypeNames.length == 1)
            return colTypeNames[0];

        StringBuffer sb = new StringBuffer();
        // for more than one colTypeNames
        sb.append(colTypeNames[colTypeNames.length - 1]);// the last col type
        // name
        String colTypeName = colTypeNames[colTypeNames.length - 2]; // the
        // second to
        // last col
        // type name

        sb.insert(0, "TPKEY(" + colTypeName + " ");
        sb.append(")");
        int i = colTypeNames.length - 3;
        while (i >= 0) {
            colTypeName = colTypeNames[i];
            sb.insert(0, "TPKEY(" + colTypeName + " ");
            sb.append(")");
            i--;
        }
        return sb.toString();
    }

    /**
     * Given an array of IWritableComparable objects, such as obj1, obj2, obj3,
     * ... build a <code>KeyPair</code> object that is new KeyPair(obj1,
     * KeyPair(obj2, KeyPair(obj3, .... If there is only one object, it will be
     * simply returned. This guarantees that the result can be directly applied
     * in the DataRow construction.
     * 
     * @param objs
     *            an array of objects
     * @return
     */
    public static IWritableComparable buildTupleKey(IWritableComparable[] objs) {
        if (objs.length == 0)
            throw new RuntimeException("Cannot build TPKEY for nothing");
        if (objs.length == 1)
            return objs[0];

        // for more than one object
        KeyPair key = new KeyPair(objs[objs.length - 2], objs[objs.length - 1]);
        int i = objs.length - 3;
        while (i >= 0) {
            key = new KeyPair(objs[i], key);
            i--;
        }
        return key;
    }

    public static boolean isIndexTable(String tableName) {
        return tableName.contains(OmapConstants.TABLENAME_SEPARATOR
                + OmapConstants.INDEX_TABLE_NAME_TAG
                + OmapConstants.TABLENAME_SEPARATOR);
    }

    public static void validateTableName(String name) {
        if (name.contains(OmapConstants.TABLENAME_SEPARATOR)) {
            throw new BadTableNameException("name should not contain "
                    + OmapConstants.TABLENAME_SEPARATOR);
        }
        if (name.contains(AbstractTableSpace.NAME_TYPE_SEPARATOR)) {
            throw new BadTableNameException("name should not contain "
                    + AbstractTableSpace.NAME_TYPE_SEPARATOR);
        }
        if (name.length() == 0) {
            throw new BadTableNameException("name should not be empty");
        }
    }

    public static FSInputStream createFSInputStream(IFileSystem fs, Path file,
            int flags) throws IOException {
        if (!(fs instanceof DistributedFileSystem)) {
            return fs.openRaw(file);
        }
        return ((DistributedFileSystem) fs).openRaw(file, flags);
    }

    public static FSDataInputStream createFSDataInputStream(IFileSystem fs,
            Path file, boolean useRandomRead) throws IOException {
        if (!(fs instanceof DistributedFileSystem)) {
            return fs.open(file);
        }
        int flags = 0;
        if (useRandomRead) {
            flags |= DFSClient.IS_RANDOMREAD;
        }
        return new FSDataInputStream(((DistributedFileSystem) fs).openRaw(file,
                flags));
    }

    public static FSDataOutputStream createFSDataOutputStream(IFileSystem fs,
            Path file, boolean overwrite, int flags) throws IOException {
        if (fs instanceof DistributedFileSystem) {
            return new FSDataOutputStream(
                    ((DistributedFileSystem) fs).createRaw(file, overwrite,
                            false, flags));
        } else {
            LOG.warning(fs.getClass().getName()
                    + " doesn't support flags, flags=" + flags + " ignored");
            return fs.create(file, overwrite, false);
        }
    }

    public static long getFileSize(FileSystem fs, Path file) throws IOException {
        BlockInfo[] blocks = fs.getFileBlocksInfo(file);
        long blockCalcSize = 0;
        for (BlockInfo block: blocks) {
            blockCalcSize += block.getLength();
        }
        long metaCalcLength = fs.getLength(file);
        return Math.max(blockCalcSize, metaCalcLength);
    }

    public static void safeClose(SequenceFile.Reader reader) {
        if (reader != null) {
            try {
                reader.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close " + reader + " failed", t);
            }
        }
    }

    public static void safeClose(SequenceFile.Writer writer) {
        if (writer != null) {
            try {
                writer.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close " + writer + " failed", t);
            }
        }
    }

    public static void safeClose(ServerSocket ss) {
        if (ss != null) {
            try {
                ss.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close " + ss + " failed", t);
            }
        }
    }

    public static void safeClose(ZooKeeper zk) {
        if (zk != null) {
            try {
                zk.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close " + zk + " failed", t);
            }
        }
    }

    public static void safeClose(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close " + c + " failed", t);
            }
        }
    }

    public static void safeClose(FileSystem fs) {
        if (fs != null) {
            try {
                fs.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close fs " + fs.getName() + " failed",
                        t);
            }
        }
    }

    public static void safeDelete(FileSystem fs, Path path) {
        try {
            if (!fs.delete(path)) {
                LOG.warning("delete " + path + " failed");
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "delete " + path + " failed", e);
        }
    }

    public static void createZooKeeperRootNode(ZooKeeper zk)
            throws KeeperException, InterruptedException {
        String root = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_OMAP_ZOOKEEPER_ROOT);
        if (!root.startsWith("/")) {
            throw new IllegalArgumentException(
                    "ZooKeeper path must start with / character");
        }
        String[] dirs = root.split("/");

        LOG.info("create zookeeper root " + root);
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < dirs.length; i++) {
            String dir = sb.append("/").append(dirs[i]).toString();
            if (zk.exists(dir, null) == null) {
                zk.create(dir, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                        CreateMode.PERSISTENT);
            }
        }
        String tsPath = OmapConfig.getZkTsPath();
        if (zk.exists(tsPath, null) == null) {
            zk.create(tsPath, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                    CreateMode.PERSISTENT);
        }
    }

    public static String parseTabelSpaceName(String internalTableName) {
        if (internalTableName.contains(OmapConstants.TABLENAME_SEPARATOR)) {
            return internalTableName.substring(
                    0,
                    internalTableName.indexOf(OmapConstants.TABLENAME_SEPARATOR));
        } else {
            return "";
        }
    }

    public static String toOriginalTableName(String internalTableName) {
        return internalTableName.substring(internalTableName.indexOf(OmapConstants.TABLENAME_SEPARATOR) + 1);
    }

    public static String toInternalTableName(String tableSpaceName,
            String tableName) {
        return tableSpaceName + OmapConstants.TABLENAME_SEPARATOR + tableName;
    }

    /**
     * return {@link KeyPair#MAX_WRITABLE} if success, else return last valid
     * KeyRange's lastKey
     * 
     * @param krl
     * @return
     */
    public static IWritableComparable checkKeyRangeCoverage(KeyRangeList krl) {
        IWritableComparable lastEndKey = null;
        for (KeyRange kr: krl.getRangeSet().keySet()) {
            if (lastEndKey == null) {
                if (kr.getKey1() != null) {
                    return kr.getKey1();
                }
            } else {
                if (!lastEndKey.equals(kr.getKey1())) {
                    return kr.getKey1();
                }
            }
            lastEndKey = kr.getKey2();
        }
        return lastEndKey;
    }

    public static String getOmapInstanceName() {
        return "{OMAP [" + OmapConfig.getZkAddress() + "] "
                + OmapConfig.getZkActiveMasterPath() + "}";
    }

    public static String getSSTableFileDirPath(String tabletDir, long tabletId) {
        String strId = HexString.longToPaddedHex(tabletId);
        return tabletDir + "/" + strId.substring(0, 8) + "/"
                + strId.substring(8, 14) + "/" + strId.substring(14, 16);
    }

    public static List<FileInfo> listTabletsByTabletFileDir(FileSystem fs,
            Path path) throws IOException {
        FileInfo[] subFolders = fs.listFiles(path);
        List<FileInfo> res = new ArrayList<FileInfo>();
        if (subFolders != null) {
            for (FileInfo folder: subFolders) {
                FileInfo[] tablets = fs.listFiles(folder.getPath());
                if (tablets != null) {
                    for (FileInfo tablet: tablets) {
                        res.add(tablet);
                    }
                }
            }
        }
        return res;
    }

    public static String getTabletIdBySSTableFileDirPath(String dir) {
        Path path = new Path(dir);
        Path p = new Path(path.getParent());
        Path pp = new Path(p.getParent());
        return pp.getName() + p.getName() + path.getName();
    }

    public static String getTabletFileDirByTableSchemaId(String tabletDir,
            long schemaId) {
        String longToPaddedHex = HexString.longToPaddedHex(schemaId);
        return tabletDir + "/" + longToPaddedHex.substring(8, 16);
    }

    public static String getStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        pw.close();
        return sw.toString();
    }

    public static long minTabletId(long schemaId) {
        return schemaId << 32;
    }

    public static long tid2sid(long tabletId) {
        long ret = tabletId >>> 32;
        return ret;
    }

    public static long tid2tabletsn(long tabletid) {
        return tabletid << 32 >>> 32;
    }

    public static boolean validatePermissionMode(String mode) {
        if (mode.length() != 9) {
            return false;
        }

        // rwxrwxrwx
        // 012345678
        boolean isOk = true;
        isOk = isOk && (mode.charAt(0) == 'r' || mode.charAt(0) == '-');
        isOk = isOk && (mode.charAt(1) == 'w' || mode.charAt(1) == '-');
        isOk = isOk && (mode.charAt(2) == 'x' || mode.charAt(2) == '-');
        isOk = isOk && (mode.charAt(3) == 'r' || mode.charAt(3) == '-');
        isOk = isOk && (mode.charAt(4) == 'w' || mode.charAt(4) == '-');
        isOk = isOk && (mode.charAt(5) == 'x' || mode.charAt(5) == '-');
        isOk = isOk && (mode.charAt(6) == 'r' || mode.charAt(6) == '-');
        isOk = isOk && (mode.charAt(7) == 'w' || mode.charAt(7) == '-');
        isOk = isOk && (mode.charAt(8) == 'x' || mode.charAt(8) == '-');
        return isOk;
    }

    private static final Set<String> IGNORED_CONFIG_NAME;

    static {
        Set<String> set = new HashSet<String>();
        set.add("NAME_FS_NAME");
        set.add("NAME_FS_TEMP_ROOT");
        IGNORED_CONFIG_NAME = Collections.unmodifiableSet(set);
    }

    public static DFSClientConfig getDistributedFileSystemConfig() {
        // can not simplely use subset because the default value in omap is 
        // different from odfs.
        LOG.info("Set up dfs config");
        Configuration omapConf = OmapConfig.getConfiguration();
        BaseConfiguration dfsConf = new BaseConfiguration();
        for (Field field: OmapConfig.class.getFields()) {
            if (field.getName().startsWith("NAME_FS")) {
                if (IGNORED_CONFIG_NAME.contains(field.getName())) {
                    continue;
                }
                try {
                    String name = (String) field.get(null);
                    Object value = omapConf.getProperty(name);
                    if (value == null) {
                        Field defaultValueField = OmapConfig.class.getField("DEFAULT"
                                + field.getName().substring("NAME".length()));
                        value = defaultValueField.get(null);
                    }
                    dfsConf.setProperty(
                            "dfs.client." + name.substring("omap.fs.".length()),
                            value);
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "error load dfs config " + field.getName(), e);
                }
            }
        }
        for (@SuppressWarnings("unchecked")
        Iterator<String> iter = dfsConf.getKeys(); iter.hasNext();) {
            String key = iter.next();
            LOG.info(key + "=" + dfsConf.getProperty(key));
        }

        return new DFSClientConfig(dfsConf);
    }

    /**
     * Find a free port that cound be bind start from the <code>fromPort</code>.
     * 
     * @param fromPort
     * @return
     */
    public static int probeFreePort(int fromPort) {
        int port = fromPort;
        while (true) {
            ServerSocket ss = null;
            try {
                ss = new ServerSocket(port);
                ss.setReuseAddress(true);
                return port;
            } catch (IOException e) {
                LOG.log(Level.INFO, "try to bind to port " + port
                        + " failed, try next", e);
            } finally {
                safeClose(ss);
            }
            port += 2;
        }
    }

    private final static long multiplier = 6364136223846793005L;

    private final static long addend = 1442695040888963407L;

    public static long nextLong(long value) {
        return value * multiplier + addend;
    }

    /**
     * round up <tt>size</tt> with alignment <tt>align</tt>
     * 
     * @param size
     * @param align
     *            must be power of 2
     * @return
     */
    public static int roundUp(int size, int align) {
        return ((size - 1) & ~(align - 1)) + align;
    }

    /**
     * This enum can only be used by testcase!
     */
    public static enum TESTCASE_PREPENSE_EXCEPTION_TYPE {
        MASTER_PREPENSE_EXCEPTION_WHILE_RECOVERING_TASK,
        MASTER_PREPENSE_EXCEPTION_WHILE_RECOVERING_TS_TASK,
        MASTER_PREPENSE_EXCEPTION_WHILE_SPLITTING_LOG,
        MASTER_PREPENSE_EXCEPTION_AFTER_SPLIT_LOG,
        MASTER_PREPENSE_EXCEPTION_WHILE_INSERT_TABLET,
        MASTER_PREPENSE_EXCEPTION_WHILE_INSERT_TABLET2,
        MASTER_PREPENSE_EXCEPTION_WHILE_SPLITTING_TABLET,
        MASTER_PREPENSE_EXCEPTION_WHILE_SPLITTING_TABLET2,
        MASTER_PREPENSE_EXCEPTION_AFTER_TS_TASK_DONE,
        MASTER_PREPENSE_EXCEPTION_WHILE_GET_NEXT_SCHEMA_ID,
        MASTER_PREPENSE_EXCEPTION_WHILE_ASSIGN_TASK_TO_TS,
        MASTER_PREPENSE_EXCEPTION_WHILE_CHECKPOINTING_CATALOGUE,
        TS_PREPENSE_EXCEPTION_WHILE_SPLITTING_LOG,
        TS_PREPENSE_EXCEPTION_WHILE_SPLITTING_LOG_DONE,
        TS_PREPENSE_EXCEPTION_WHILE_WRITE_CHECKPOINT,
        TS_PREPENSE_EXCEPTION_WHILE_CHECKPOINT,
        TS_PREPENSE_EXCEPTION_WHILE_COMPACTION;

        private static final Map<TESTCASE_PREPENSE_EXCEPTION_TYPE, Integer> requestRecord = new HashMap<TESTCASE_PREPENSE_EXCEPTION_TYPE, Integer>();

        private static boolean isMyException(
                TESTCASE_PREPENSE_EXCEPTION_TYPE type) {
            if (!requestRecord.containsKey(type)) {
                return false;
            }
            int times = requestRecord.get(type);
            String myThreadGroupName = Thread.currentThread().getThreadGroup().getName();
            if (myThreadGroupName == null) { //NOT in test case
                return false;
            }

            if (myThreadGroupName.startsWith("MASTER_THREADGROUP")
                    && type.name().startsWith("MASTER_")
                    || myThreadGroupName.startsWith("TS_THREADGROUP_")
                    && type.name().startsWith("TS_")) {
                --times;
                if (times == 0) {
                    requestRecord.remove(type);
                    return true;
                }
                requestRecord.put(type, times);
            }
            return false;
        }

        /**
         * @param type
         * @param timing
         *            the exception will be throw iff the code pass through for
         *            timing times
         */
        public static void setPrepenseException(
                TESTCASE_PREPENSE_EXCEPTION_TYPE type, int timing) {
            if (timing > 0) {
                synchronized (requestRecord) {
                    requestRecord.put(type, timing);
                }
            }
        }

        public static void setPrepenseException(
                TESTCASE_PREPENSE_EXCEPTION_TYPE type) {
            setPrepenseException(type, 1);
        }

        public static void prepenseException(
                TESTCASE_PREPENSE_EXCEPTION_TYPE type) {
            synchronized (requestRecord) {
                if (isMyException(type)) {
                    try {
                        throw new RuntimeException(
                                "This is an prepense exception by test case,"
                                        + " exception type: " + type);
                    } finally {
                        requestRecord.notifyAll();
                    }
                }
            }
        }

        public static boolean isTriggered(TESTCASE_PREPENSE_EXCEPTION_TYPE type) {
            synchronized (requestRecord) {
                return !requestRecord.containsKey(type);
            }
        }

        public static void waitingForTigger(
                TESTCASE_PREPENSE_EXCEPTION_TYPE type)
                throws InterruptedException {
            while (true) {
                synchronized (requestRecord) {
                    if (!requestRecord.containsKey(type)) {
                        break;
                    }
                    requestRecord.wait();
                }
            }
        }
    }
}
