/**
 * @(#)OmapQueryExecutor.java, Dec 3, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.query;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.client.OmapClient;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.OmapException;

/**
 * The query execution engine
 * 
 * @author xingjk
 */
public class OmapQueryExecutor {

    private OmapMetadata metadata;

    private Map<String, OmapClient> indexClients;

    private static final int KEYS_FIND_NUM = 200;

    public OmapQueryExecutor(OmapClient client) {
        this.metadata = client.getMetadata();
        this.indexClients = client.getIndexClients();
    }

    public List<IWritable> doExecute(OmapQuery query) throws OmapException {
        // first check whether the query is ready to execute
        for (OmapQueryCondition condition: query.getConditions()) {
            if (!condition.isReadyToExecute())
                throw new OmapException("The query condition " + condition
                        + " is not ready to execute");
        }

        // execute it
        QueryExecutionAssist assist = null;
        QueryOperation firstOp = query.getFirstCondition().getOperation();
        if (firstOp.isSpecifyRange()) {
            assist = new QueryExecutionAssist(query, true); // prepare the
            // assist for
            // query's execution
            switch (firstOp) {
                case LIRI:
                    doExecuteRangedQuery(assist, true, true);
                    break;
                case LIRE:
                    doExecuteRangedQuery(assist, true, false);
                    break;
                case LERI:
                    doExecuteRangedQuery(assist, false, true);
                    break;
                case LERE:
                    doExecuteRangedQuery(assist, false, false);
                    break;
                default:
                    throw new OmapException("Not supported query operation");
            }
        } else {
            assist = new QueryExecutionAssist(query, false);
            switch (firstOp) {
                case EQUAL:
                    doExecuteEqualQuery(assist);
                    break;
                case GT:
                    doExecuteQueryWithLowerBound(assist, false);
                    break;
                case GET:
                    doExecuteQueryWithLowerBound(assist, true);
                    break;
                case LT:
                    doExecuteQueryWithUpperBound(assist, false);
                    break;
                case LET:
                    doExecuteQueryWithUpperBound(assist, true);
                    break;

                case INEQUAL:
                    doExecuteInequalQuery(assist);
                    break;
                default:
                    throw new OmapException("Not supported query operation");
            }
        }

        return assist.getResultList();
    }

    /**
     * Perform the query with an INEQUAL operation in the first key
     * 
     * @param assist
     *            in-out parameter support the query execution and keep the
     *            result
     * @author xingjk
     */
    private void doExecuteInequalQuery(QueryExecutionAssist assist)
            throws OmapException {
        // this kind of query is equivalent to a union of a "<" and a ">" query
        doExecuteQueryWithUpperBound(assist, false);
        if (assist.limit > 0) { // not done yet
            doExecuteQueryWithLowerBound(assist, false);
        }
    }

    /**
     * Perform the query with a range, such as LIRI, LERI
     * 
     * @param assist
     * @param leftInc
     *            indicates it is left inclusive or not
     * @param rightInc
     *            indicates it is right inclusive or not
     * @param txn
     * @throws OmapException
     * @author xingjk
     */
    private void doExecuteRangedQuery(QueryExecutionAssist assist,
            boolean leftInc, boolean rightInc) throws OmapException {
        // create the start and end query key
        KeyCell startKey = assist.createQueryKey();
        KeyCell endKey = null;
        // we assume that endKey is greater than startKey, which is guaranteed
        // by QueryCondition#isReadyToExecute

        int i = 0;

        // start query
        DataRow[] rows = assist.keysFind(startKey, KEYS_FIND_NUM);
        if (rows.length == 0)
            return; // nothing is found

        if (!leftInc) {
            // jump over the first numerous rows in the case of "left exclusive"
            while (true) {
                if (OmapQueryUtils.getFirstKey(
                        rows[rows.length - 1].getKeyCell()).compareTo(
                        assist.firstKey) == 0) {
                    if (rows.length < KEYS_FIND_NUM) {
                        return; // reach the end of table
                    } else {
                        // the last row still not satisfy "exclusive", so must
                        // retrieve another KEYS_FIND_NUM rows
                        startKey = rows[rows.length - 1].getKeyCell();
                        rows = assist.keysFind(startKey, KEYS_FIND_NUM);
                        if (rows.length == 0)
                            return;
                    }
                } else {
                    // find the index of the first row whose first key is
                    // greater than firstValue
                    i = OmapQueryUtils.binarySearchFirstRowWithGreaterKey(rows,
                            assist.firstKey);
                    break;
                }
            }
        }

        // loop find
        int end = -1;
        while (true) {
            if (OmapQueryUtils.getFirstKey(rows[rows.length - 1].getKeyCell()).compareTo(
                    assist.firstKey2) < 0) {
                // the last row is less than the firstKey2, so try to add them
                // to result
                if (!assist.addMatchedRowsToResult(rows, i, rows.length)
                        || rows.length < KEYS_FIND_NUM) {
                    return;
                }
            } else {
                end = OmapQueryUtils.binarySearchLastRowWithLessKey(rows,
                        assist.firstKey2);
                assist.addMatchedRowsToResult(rows, i, end + 1);
                if (rightInc && assist.limit > 0) {
                    assist.shiftKey(); // shift the firstkey2 to firstkey to
                    // finish the remaining query
                    doExecuteEqualQuery(assist);
                }
                return;
            }

            // restart a keys find
            endKey = rows[rows.length - 1].getKeyCell();
            rows = assist.keysFind(endKey, KEYS_FIND_NUM);
            if (rows.length == 0)
                return; // nothing is found
            if (rows.length == 1
                    && rows[0].getKeyCell().compareTo(endKey) == 0) {
                return; // only find the last key
            }
            i = 1;
        }
    }

    /**
     * Perform the query with an upper bound, such as LT and LET
     * 
     * @param txn
     * @param inclusive
     *            true indicates LET and false indicates LT
     * @param assist
     *            in-out parameter support the query execution and keep the
     *            result
     * @throws OmapException
     * @author xingjk
     */
    private void doExecuteQueryWithUpperBound(QueryExecutionAssist assist,
            boolean inclusive) throws OmapException {

        KeyCell startKey = assist.createNullKey(); // create a null key to start
        // from the first row
        int i = 0;

        // start query
        DataRow[] rows = assist.keysFind(startKey, KEYS_FIND_NUM);
        if (rows.length == 0)
            return; // nothing is found

        int end = -1;
        while (true) {
            if (OmapQueryUtils.getFirstKey(rows[rows.length - 1].getKeyCell()).compareTo(
                    assist.firstKey) < 0) {
                // the last row is less than the first key, so try to add them
                // to result
                if (!assist.addMatchedRowsToResult(rows, i, rows.length)
                        || rows.length < KEYS_FIND_NUM) {
                    return;
                }
            } else {
                end = OmapQueryUtils.binarySearchLastRowWithLessKey(rows,
                        assist.firstKey);
                assist.addMatchedRowsToResult(rows, i, end + 1);

                if (inclusive && assist.limit > 0) {
                    assist.startKey = OmapQueryUtils.constructEndKey(
                            assist.query, assist.is);
                    doExecuteEqualQuery(assist);
                }
                return;
            }

            // restart a keys find
            startKey = rows[rows.length - 1].getKeyCell();
            rows = assist.keysFind(startKey, KEYS_FIND_NUM);
            if (rows.length == 0)
                return; // nothing is found
            if (rows.length == 1
                    && rows[0].getKeyCell().compareTo(startKey) == 0) {
                return; // only find the last key
            }
            i = 1;
        }
    }

    /**
     * Perform the query with an EQUAL operation in the first key
     * 
     * @param txn
     * @param assist
     *            in-out parameter support the query execution and keep the
     *            result
     * @author xingjk
     */
    private void doExecuteEqualQuery(QueryExecutionAssist assist)
            throws OmapException {

        KeyCell startKey = assist.createQueryKey();

        int i = 0;

        // start query
        DataRow[] rows = assist.keysFind(startKey, KEYS_FIND_NUM);
        if (rows.length == 0)
            return; // nothing is found

        while (true) {
            if (OmapQueryUtils.getFirstKey(rows[i].getKeyCell()).compareTo(
                    assist.firstKey) == 0) {
                if (OmapQueryUtils.getFirstKey(
                        rows[rows.length - 1].getKeyCell()).compareTo(
                        assist.firstKey) == 0) {
                    // the last row start with the first key, so try to match
                    // them all
                    if (!assist.addMatchedRowsToResult(rows, i, rows.length)
                            || rows.length < KEYS_FIND_NUM) // either limit is
                        // reached, either
                        // table's end is
                        // reached
                        return;
                } else {
                    // use binary search to find the end position
                    int end = OmapQueryUtils.binarySearchFirstRowWithGreaterKey(
                            rows, assist.firstKey);
                    // according above, search must find some index in the range
                    // [i, rows.length - 1]
                    assist.addMatchedRowsToResult(rows, i, end);
                    return; // No matter what happens, we know we must stop here
                }
            } else {
                return;
            }
            // get the last row's key of latest keysFind
            startKey = rows[rows.length - 1].getKeyCell();
            rows = assist.keysFind(startKey, KEYS_FIND_NUM);
            // nothing is found
            if (rows.length == 0)
                return;
            if (rows.length == 1
                    && rows[0].getKeyCell().compareTo(startKey) == 0) {
                return; // only find the last key
            }
            // ignore the first row since it has been handled by the latest
            // keysFind
            i = 1;
        }
    }

    /**
     * Perform the query with a lower bound in the first key, such as GT, GET
     * 
     * @param assist
     *            in-out parameter support the query execution and keep the
     *            result
     * @param inclusive
     *            true means GET and false means
     * @param txn
     * @throws OmapException
     * @author xingjk
     */
    private void doExecuteQueryWithLowerBound(QueryExecutionAssist assist,
            boolean inclusive) throws OmapException {

        // create the start query key
        KeyCell startKey = assist.createQueryKey();

        // create other data structure
        int i = 0;

        // start query
        DataRow[] rows = assist.keysFind(startKey, KEYS_FIND_NUM);
        if (rows.length == 0)
            return; // nothing is found

        if (!inclusive) {
            // jump over the first numerous rows in the case of "Greater Than"
            while (true) {
                if (OmapQueryUtils.getFirstKey(
                        rows[rows.length - 1].getKeyCell()).compareTo(
                        assist.firstKey) == 0) {
                    if (rows.length < KEYS_FIND_NUM) {
                        return; // reach the end of table
                    } else {
                        // the last row still not satisfy "GT", so must retrieve
                        // another KEYS_FIND_NUM rows
                        startKey = rows[rows.length - 1].getKeyCell();
                        rows = assist.keysFind(startKey, KEYS_FIND_NUM);
                        if (rows.length == 0)
                            return;
                    }
                } else {
                    // find the index of the first row whose first key is
                    // greater than firstValue
                    i = OmapQueryUtils.binarySearchFirstRowWithGreaterKey(rows,
                            assist.firstKey);
                    break;
                }
            }
        }

        // loop find
        while (true) { // break by return
            if (!assist.addMatchedRowsToResult(rows, i, rows.length)
                    || rows.length < KEYS_FIND_NUM) // either limit is reached,
                // either table's end is
                // reached
                return;
            startKey = rows[rows.length - 1].getKeyCell(); // get the last row's
            // key of latest
            // keysFind
            rows = assist.keysFind(startKey, KEYS_FIND_NUM);
            if (rows.length == 0)
                return; // nothing is found
            if (rows.length == 1
                    && rows[0].getKeyCell().compareTo(startKey) == 0) {
                return; // only find the last key
            }
            // ignore the first row since it has been handled by the latest
            // keysFind
            i = 1;
        }
    }

    /**
     * A set of data that the query execution process needs.
     * 
     * @author xingjk
     */
    private class QueryExecutionAssist {
        ArrayList<IWritable> results = new ArrayList<IWritable>();

        int offset;

        int limit;

        IndexSchema is;

        OmapQuery query;

        OmapClient indexClient;

        /**
         * The nested TPKEY in the index table's key cell will be flattened in
         * this buffer
         */
        IWritableComparable[] paraBuffer;

        /**
         * The first key's value in parameters of query conditions
         */
        IWritableComparable firstKey;

        /**
         * The first key's value in parameters of query conditions, the para2 if
         * the first query operation specifies a range
         */
        IWritableComparable firstKey2;

        KeyCell startKey;

        QueryExecutionAssist(OmapQuery query, boolean forRangedQuery) {
            this.query = query;
            this.offset = query.getOffset();
            this.limit = query.getLimit();
            is = metadata.getPreparedIndexSchema(query.getIndexSchema());
            indexClient = indexClients.get(metadata.getIndexes().get(is));

            startKey = OmapQueryUtils.constructStartKey(query, is);

            firstKey = query.getFirstCondition().getPara();

            if (is.getConditionCount() > 1) {
                paraBuffer = new IWritableComparable[is.getIndexColCount()];
            }

            if (forRangedQuery)
                prepareQueryParas2();
        }

        public void prepareQueryParas2() {
            firstKey2 = query.getFirstCondition().getPara2();
        }

        /**
         * Add a result in caring about
         * 
         * @param key
         *            the input key
         * @return true means query should be continued; false means limit is
         *         reached, the query should be stopped.
         */
        public boolean addResultKey(IWritable key) {
            if (offset > 0) {
                offset--;
                return true;
            }

            results.add(key);
            limit--;
            if (limit == 0) // we should end query
                return false;
            else
                return true;
        }

        public List<IWritable> getResultList() {
            return results;
        }

        public KeyCell createQueryKey() {
            return startKey;
        }

        /**
         * Shift the firstKey2 to firstKey for finishing ranged query. This job
         * includes reconstruct "start key"
         */
        public void shiftKey() {
            firstKey = firstKey2;
            startKey = OmapQueryUtils.constructEndKey(query, is);
        }

        public KeyCell createNullKey() {
            return is.createNullKey();
        }

        /**
         * Add those matched rows in the raw rows returned by keysFind to the
         * query result
         * 
         * @param rows
         *            the raw rows returned by KeysFind
         * @param start
         *            the start index of rows, inclusively
         * @param end
         *            the end index of rows, exclusively
         * @return true means additional rows is needed to be retrieved; false
         *         means the query should be stopped
         * @author xingjk
         */
        public boolean addMatchedRowsToResult(DataRow[] rows, int start, int end) {

            // put the rest rows into the result
            if (is.getConditionCount() > 1) {
                for (int i = start; i < end; i++) {
                    if (OmapQueryUtils.isMatchWithoutFirstKey(query,
                            rows[i].getKeyCell(), paraBuffer)) {
                        if (!addResultKey(rows[i].getIWritable(1)))
                            return false;
                    }
                }
            } else {
                // only one key in the index, just add them to the result
                for (int i = start; i < end; i++) {
                    if (!addResultKey(rows[i].getIWritable(1)))
                        return false;
                }
            }

            return true;
        }

        public DataRow[] keysFind(KeyCell key, int num) throws OmapException {
            return indexClient.keysFind(key, num);
        }
    }
}
