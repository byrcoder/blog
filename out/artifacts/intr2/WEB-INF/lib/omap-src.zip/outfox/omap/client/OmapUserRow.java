package outfox.omap.client;

import java.io.IOException;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import outfox.omap.client.protocol.Row;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.exceptions.EmptyDataException;
import outfox.omap.exceptions.OmapException;
import toolbox.misc.LogFormatter;

/**
 * notice that, if you use get and getKey method which return IWritable, you
 * will get ByteArrayWritable if the column is in custom type. <br>
 * for Omap users, you should always call the get method which the IWritable is
 * passed in by caller.<br>
 * This is important. Because the IWritable is passed in by caller, we do not
 * need to create the IWritable Object. Omap user can set the column type to an
 * abstract class or interface, such as IWritable.
 * 
 * @author zhangduo
 */
public class OmapUserRow implements Row {

    private DataRow dataRow;

    @SuppressWarnings("unused")
    private static Logger LOG = LogFormatter.getLogger(OmapUserRow.class);

    private OmapUserTable table;

    public OmapUserRow(DataRow dataRow, OmapUserTable table) {
        this.dataRow = dataRow;
        this.table = table;
    }

    public DataRow getDataRow() {
        return dataRow;
    }

    public void setDataRow(DataRow dataRow) {
        this.dataRow = dataRow;
    }

    @Override
    public void empty(int colIndex) throws OmapException {
        dataRow.getColumn(colIndex).setNull();
    }

    @Override
    public void empty(String colName) throws OmapException {
        empty(this.getMetaData().getColumnIndex(colName));
    }

    /**
     * if type is custom, this method will return ByteArrayWritable even at
     * client side.
     * 
     * @param colIndex
     * @return
     * @throws OmapException
     */
    public IWritable get(int colIndex) throws OmapException {
        return dataRow.getColumn(colIndex).getIWritable();
    }

    /**
     * if type is custom, this method will return ByteArrayWritable even at
     * client side.
     * 
     * @param colName
     * @return
     * @throws EmptyDataException
     * @throws OmapException
     */
    public IWritable get(String colName) throws EmptyDataException,
            OmapException {
        return get(this.getMetaData().getColumnIndex(colName));
    }

    public int get(int colIndex, IWritable value) throws OmapException {
        DataCell dataCell = dataRow.getColumn(colIndex);
        byte status = dataCell.getStatus();
        if (status == DataCell.STATUS_INVALID) {
            return STATUS_NOT_SET;
        } else if (status == DataCell.STATUS_NULL) {
            return STATUS_NULL;
        } else {
            try {
                dataCell.getCIWritable(value);
            } catch (IOException e) {
                throw new OmapException(e);
            }
            return STATUS_NORMAL;
        }
    }

    public int get(String colName, IWritable value) throws OmapException {
        return get(this.getMetaData().getColumnIndex(colName), value);
    }

    /**
     * if type is custom, this method will return ByteArrayWritable even at
     * client side.
     * 
     * @return
     * @throws OmapException
     */
    public IWritable getKey() throws OmapException {
        return get(0);
    }

    @Override
    public void getKey(IWritable key) throws OmapException {
        get(0, key);
    }

    @Override
    public void set(int colIndex, IWritable value) throws OmapException {
        dataRow.getColumn(colIndex).setCIWritable(value);
    }

    @Override
    public void set(String colName, IWritable value) throws OmapException {
        set(this.getMetaData().getColumnIndex(colName), value);
    }

    @Override
    public void clear(int colIndex) throws OmapException {
        dataRow.getColumn(colIndex).setInvalid();
    }

    @Override
    public void clear(String colName) throws OmapException {
        clear(this.getMetaData().getColumnIndex(colName));

    }

    @Override
    public void setNull(int colIndex) throws OmapException {
        dataRow.getColumn(colIndex).setNull();
    }

    @Override
    public void setNull(String colName) throws OmapException {
        setNull(this.getMetaData().getColumnIndex(colName));

    }

    public void setKey(IWritable key) throws OmapException {
        this.dataRow.getKeyCell().setCIWritable(key);
    }

    public String toString() {
        return this.dataRow.toString();
    }

    private OmapMetadata getMetaData() {
        return (OmapMetadata) this.table.getMetadata();
    }
}
