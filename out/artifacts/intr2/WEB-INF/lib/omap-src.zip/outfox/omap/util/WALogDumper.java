package outfox.omap.util;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.io.FSDataInputStream;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import outfox.omap.client.OmapMetadata;
import outfox.omap.conf.OmapConfig;
import outfox.omap.ts.insertlog.InsertLogEntry;
import outfox.omap.ts.insertlog.InsertLogger;
import outfox.omap.walog.LogIterator;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogEntry;
import outfox.omap.walog.WALogger;
import toolbox.misc.LogFormatter;

/**
 * Dump the content of the WALog for debugging.<br>
 * FIXME: it does not work because metadata has not store as file on odfs
 * anyway.
 * 
 * @author zhangkun
 */
public class WALogDumper {
    private static final Logger LOG = LogFormatter.getLogger(WALogDumper.class);

    public static void dumpWALog(Writer out, FileSystem fs, Path logDir)
            throws IOException {
        WALogger logger;
        WALogEntry entry;
        logger = new InsertLogger(logDir, fs, true);
        entry = new InsertLogEntry();
        LogIterator iter = logger.iterator(true);
        while (iter.next(entry)) {
            out.write(entry.toStructuredString(cache) + "\n");
        }
        iter.close();
    }

    private static class Cache implements MetadataProvider {

        private Map<Long, OmapMetadata> metas = new HashMap<Long, OmapMetadata>();

        @Override
        public OmapMetadata get(long schemaId) {
            return metas.get(schemaId);
        }

    }

    private static Cache cache = new Cache();

    private static void readMetadata(IFileSystem fs, Path metaDir)
            throws IOException {
        Path[] metaFiles = fs.listPaths(metaDir);
        if (metaFiles == null) {
            return;
        }
        for (Path metaFile: metaFiles) {
            LOG.info("Reading metadata file: " + metaFile);
            FSDataInputStream tdIn = fs.open(metaFile);
            OmapMetadata meta = new OmapMetadata();
            meta.readFields(tdIn);
            tdIn.close();
            cache.metas.put(meta.getTableDesc().getSchemaId(), meta);
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.err.println("Usage: WALogDumper <logDir> [metaDir]");
            return;
        }
        Path logDir = new Path(args[0]);
        String metaDir = null;
        if (args.length > 1) {
            metaDir = args[1];
        }
        FileSystem fs = FileSystem.getNamed(OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME));
        if (metaDir != null) {
            readMetadata(fs, new Path(metaDir));
        }
        OutputStreamWriter writer = new OutputStreamWriter(System.out, "UTF-8");
        LOG.info("Dumping log: " + logDir);
        dumpWALog(writer, fs, logDir);
        writer.close();
    }
}
