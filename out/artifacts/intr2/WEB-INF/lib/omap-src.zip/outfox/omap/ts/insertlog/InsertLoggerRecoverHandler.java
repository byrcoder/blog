package outfox.omap.ts.insertlog;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import outfox.omap.exceptions.NullDataException;
import outfox.omap.exceptions.UnInitializedDataCellException;
import outfox.omap.exceptions.WriteBufferOverflowException;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.Tablet;
import outfox.omap.util.WaitUtils;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.misc.LogFormatter;

/**
 * Recover logs and re-insert to the Tablet
 * 
 * @author zhangkun
 */
public class InsertLoggerRecoverHandler extends InsertLogReaderHandler {
    private static Logger LOG = LogFormatter.getLogger(InsertLoggerRecoverHandler.class);

    private OmapTs ts;

    private long tabletId;

    /**
     * Constructor
     * 
     * @param ts
     * @param recoverTablets
     *            tabletId that need to be recovered
     */
    public InsertLoggerRecoverHandler(OmapTs ts, long tabletId,
            LongLongHashMap checkpoints) {
        super(checkpoints);
        this.ts = ts;
        this.tabletId = tabletId;
    }

    public void done() {}

    public void fail() {}

    @Override
    protected void handle(WALogInsert body) throws IOException {
        long tabletId = body.getTabletId();
        if (this.tabletId != tabletId) {
            return;
        }
        while (true) {
            try {
                Tablet tablet = ts.getTablets().get(tabletId);
                ts.insertRow(tablet, body.getData(), true);
                break;
            } catch (WriteBufferOverflowException e) {
                LOG.log(Level.WARNING,
                        "Write buffer overflow, I'll wait and retry", e);
                WaitUtils.sleepIgnoreInterrupt(1000);
            } catch (NullDataException e) {
                LOG.log(Level.WARNING, "insert failed when recover, ignored", e);
            } catch (UnInitializedDataCellException e) {
                LOG.log(Level.WARNING, "insert failed when recover, ignored", e);
            }
        }
    }

    @Override
    protected void handle(WALogIndexInsert body) throws IOException {
        long tabletId = body.getTabletId();
        if (this.tabletId != tabletId) {
            return;
        }
        while (true) {
            try {
                Tablet tablet = ts.getTablets().get(tabletId);
                ts.insertRow(tablet, body.getNewData(), true);
                return;
            } catch (WriteBufferOverflowException e) {
                LOG.log(Level.WARNING,
                        "Write buffer overflow, I'll wait and retry", e);
                WaitUtils.sleepIgnoreInterrupt(1000);
            } catch (NullDataException e) {
                LOG.log(Level.WARNING, "insert failed when recover, ignored", e);
            } catch (UnInitializedDataCellException e) {
                LOG.log(Level.WARNING, "insert failed when recover, ignored", e);
            }
        }

    }

    @Override
    protected void handle(WALogChkPt body) throws IOException {}
}
