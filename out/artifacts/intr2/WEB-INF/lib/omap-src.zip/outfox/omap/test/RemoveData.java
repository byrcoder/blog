/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package outfox.omap.test;

import java.io.IOException;

import odis.io.FileSystem;
import odis.io.Path;

/**
 * This demo shows how to use a MapOnlyJobDef and MapOnlyTasks The demo mapper
 * will do two things: 1). compute 1/value and output (key,1/value) to directory
 * DIR_INV; 2). compute value^2 and output (key,value^2) to directory DIR_SQR.
 * 
 * @author zl
 */

public class RemoveData {

    static FileSystem nfs;

    public static void main(String []args) throws IOException{
    	nfs=FileSystem.get();
    	System.out.println("Deleting "+args[0]);
    	Path path=new Path(args[0]);
    	nfs.delete(path);
    	
    }

}
