/**
 * @(#)StatisticReaderHandler.java, 2011-6-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.IOException;
import java.util.List;

import odis.io.Path;
import outfox.omap.metrics.MetricsEntry;

/**
 * @author zhangduo
 */
public interface StatisticReaderHandler {

    void handle(long time, MetricsEntry metricsEntry) throws IOException;

    void done(List<Path> processedFiles);

    void fail();
}
