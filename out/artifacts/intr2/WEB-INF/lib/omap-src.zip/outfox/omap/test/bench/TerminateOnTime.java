/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

/**
 * Will meet the termination condition after a specified time.
 * @author zhangkun
 */
public class TerminateOnTime implements TerminationCondition{
    private long endTime;
    private long expectedDuration;
    private boolean terminateBench = true;
    public TerminateOnTime(){}
    public void setExpectedDuration(long expectedDuration) {
        this.expectedDuration = expectedDuration;
    }
    public void setTerminateBench(boolean terminateBench) {
        this.terminateBench = terminateBench;
    }
    /**
     * Constructor
     * @param expectedDuration the time before termination, in milliseconds
     * @param terminateBench true to terminate the bench when time's up; false
     *                       to only terminate a workload.
     */
    public TerminateOnTime(long expectedDuration, boolean terminateBench) {
        this.expectedDuration = expectedDuration;
        this.terminateBench = terminateBench;
    }

    @Override
    public boolean shouldTerminateWorkload(WorkloadRunner workloadRunner) {
        if(System.currentTimeMillis() > endTime) {
            return true;
        }
        return false;
    }

    @Override
    public boolean shouldTerminateBench(WorkloadRunner workloadRunner) {
        if(terminateBench) {
            return shouldTerminateWorkload(workloadRunner);
        }
        return false;
    }
    @Override
    public String toString() {
        return "[" + this.getClass().getSimpleName() + " expectedDuration=" + expectedDuration
                + " terminateBench=" + terminateBench + "]";
    }

    @Override
    public void initialize(WorkloadRunner workloadRunner) {
        endTime = System.currentTimeMillis() + expectedDuration;
    }
}
