package outfox.omap.client.protocol.mock;

import java.util.Arrays;
import java.util.HashSet;

import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryCondition;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryCondition;
import outfox.omap.exceptions.QueryInitializationException;

public class MockOmapQuery implements Query {

    private String name;

    private int limit;

    private int offset;

    private OmapQueryCondition[] conditions;

    public MockOmapQuery() {}

    public MockOmapQuery(String name, OmapQueryCondition[] conditions) {
        this(name, conditions, OmapQuery.DEFAULT_OFFSET);
    }

    public MockOmapQuery(String name, OmapQueryCondition[] conditions,
            int offset) {
        this(name, conditions, offset, OmapQuery.DEFAULT_LIMIT);
    }

    /**
     * A null or an empty name is disallowed
     * 
     * @param name
     */
    private void setQueryName(String name) {
        if (name == null || name.equals(""))
            throw new QueryInitializationException("Invalid query name");
        this.name = name;
    }

    /**
     * @param conditions
     */
    private void setConditions(OmapQueryCondition[] conditions) {
        if (conditions == null || conditions.length == 0)
            throw new QueryInitializationException("Invalid conditions");

        // check whether there is duplicated column names and only one
        // non-equality
        validateConditions(conditions);

        // duplicate the array to keep the array's order when conditions are set
        this.conditions = new OmapQueryCondition[conditions.length];
        System.arraycopy(conditions, 0, this.conditions, 0, conditions.length);
        Arrays.sort(this.conditions);
    }

    /**
     * Check whether the input conditions is valid. The conditions have to
     * confirm to:
     * <ol>
     * <li>One condition, one column. The case of multiple conditions for the
     * same column is not allowed.</li>
     * <li>Only one non-equality (LIRI, GREATER_THAN, INEQUAL or the like) is
     * allowed to appear in one query.</li>
     * </ol>
     * If some invalidation is detected, {@link QueryInitializationException} is
     * thrown.
     * 
     * @param conditions
     */
    private void validateConditions(OmapQueryCondition[] conditions) {

        boolean bNonEqualityExisted = false;
        HashSet<String> colNames = new HashSet<String>();
        for (OmapQueryCondition condition: conditions) {
            if (colNames.contains(condition.getColumnName()))
                throw new QueryInitializationException(
                        "A query can contain only one condition for one column");

            if (condition.getOperation().compareTo(QueryOperation.EQUAL) != 0) {
                if (bNonEqualityExisted == true)
                    throw new QueryInitializationException(
                            "A query can contain only one condition with non-equality operator");
                else
                    bNonEqualityExisted = true;
            }

            colNames.add(condition.getColumnName());
        }
    }

    public MockOmapQuery(String name, OmapQueryCondition[] conditions,
            int offset, int limit) {
        setQueryName(name);
        setConditions(conditions);
        setOffset(offset);
        setLimit(limit);
    }

    @Override
    public QueryCondition getCondition(String colName) {
        for (OmapQueryCondition condition: conditions) {
            if (condition.getColumnName().equals(colName)) {
                return condition;
            }
        }
        return null;
    }

    @Override
    public QueryCondition getFirstCondition() {
        return conditions[0];
    }

    @Override
    public int getLimit() {
        return limit;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getOffset() {
        return offset;
    }

    @Override
    public boolean isCompitable(Query query) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void setLimit(int limit) {
        if (limit < -1)
            throw new QueryInitializationException("Invalid limit:" + limit);
        this.limit = limit;

    }

    @Override
    public void setOffset(int offset) {
        if (offset < 0)
            throw new QueryInitializationException("Invalid offset:" + offset);

        this.offset = offset;

    }

    public OmapQueryCondition[] getConditions() {
        return conditions;
    }

}
