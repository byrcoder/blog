/**
 * @(#)TsUsageReport.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.management.MemoryUsage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConfig;
import outfox.omap.util.SystemInfoUtils;

public class TsUsageReport implements IWritable {

    private TsDesc ts;

    private List<TabletLoadPair> sortedTabletsLoad = new ArrayList<TabletLoadPair>();

    private Map<Long, LoadValue> tabletsLoad = new HashMap<Long, LoadValue>();

    public Collection<Long> getTablets() {
        ArrayList<Long> tablets = new ArrayList<Long>();
        tablets.addAll(tabletsLoad.keySet());
        return tablets;
    }

    // the sum of all tablets load, not serialized
    // master should call calcLoadValue first when received TsUageReport
    private double loadValue;

    private long maxHeapSize = 0;

    private long usedHeapSize = 0;

    private long maxWriteBuffer = 0;

    private long usedWriteBuffer = 0;

    private long usedIndexPool = 0;

    private long maxIndexPool = 0;

    private long usedBlockCache = 0;

    private long maxBlockCache = 0;

    private long maxBloomFilterSize = 0;

    private long usedBloomFilterSize = 0;

    private long maxSSTableDataCacheSize = 0;

    private long usedSSTableDataCacheSize = 0;

    private long heartBeatSeq = 0;

    private long readCount;

    private long writeCount;

    private double systemLoadValue;

    private int processors;

    public long getMaxSSTableDataCacheSize() {
        return maxSSTableDataCacheSize;
    }

    public void setMaxSSTableDataCacheSize(long maxSSTableDataCacheSize) {
        this.maxSSTableDataCacheSize = maxSSTableDataCacheSize;
    }

    public long getUsedSSTableDataCacheSize() {
        return usedSSTableDataCacheSize;
    }

    public void setUsedSSTableDataCacheSize(long usedSSTableDataCacheSize) {
        this.usedSSTableDataCacheSize = usedSSTableDataCacheSize;
    }

    // only used for test
    public void setMaxWriteBuffer(long maxWriteBuffer) {
        this.maxWriteBuffer = maxWriteBuffer;
    }

    // only used for test
    public void setUsedWriteBuffer(long usedWriteBuffer) {
        this.usedWriteBuffer = usedWriteBuffer;
    }

    // only used for test
    public void setMaxHeapSize(long maxHeapSize) {
        this.maxHeapSize = maxHeapSize;
    }

    // only used for test
    public void setUsedHeapSize(long usedHeapSize) {
        this.usedHeapSize = usedHeapSize;
    }

    public void setLoadValue(double loadValue) {
        this.loadValue = loadValue;
    }

    public long getMaxWriteBuffer() {
        return maxWriteBuffer;
    }

    public long getUsedWriteBuffer() {
        return usedWriteBuffer;
    }

    public long getHeartBeatSeq() {
        return heartBeatSeq;
    }

    public long increaseHearBeatSeq() {
        heartBeatSeq++;
        return heartBeatSeq;
    }

    private long lastHeartBeat;

    public long getLastHeartBeat() {
        return lastHeartBeat;
    }

    public void recordHeatBeatTime() {
        lastHeartBeat = System.currentTimeMillis();
    }

    public int getProcessors() {
        return processors;
    }

    // 1M
    private static final long MEMORY_NORMALIZE_VALUE = 2 * 1024;

    private static final long READ_NORMALIZE_VALUE = 10000;

    private static final long WRITE_NORMALIZE_VALUE = 10000;

    // 1M
    private static final long WRITE_BUFFER_NORMALIZE_VALUE = 2 * 1024;

    // call at master
    public void calcLoadValue() {
        double memoryWeight = OmapConfig.getConfiguration().getDouble(
                OmapConfig.NAME_LOAD_MEMORY_WEIGHT,
                OmapConfig.DEFAULT_LOAD_MEMORY_WEIGHT);
        double readWeight = OmapConfig.getConfiguration().getDouble(
                OmapConfig.NAME_LOAD_READ_WEIGHT,
                OmapConfig.DEFAULT_LOAD_READ_WEIGHT);
        double writeWeight = OmapConfig.getConfiguration().getDouble(
                OmapConfig.NAME_LOAD_WRITE_WEIGHT,
                OmapConfig.DEFAULT_LOAD_WRITE_WEIGHT);
        double writeBufferWeight = OmapConfig.getConfiguration().getDouble(
                OmapConfig.NAME_LOAD_WRITE_BUFFER_WEIGHT,
                OmapConfig.DEFAULT_LOAD_WRITE_BUFFER_WEIGHT);
        sortedTabletsLoad.clear();
        double loadValue = 0;
        for (Map.Entry<Long, LoadValue> entry: tabletsLoad.entrySet()) {
            LoadValue value = entry.getValue();
            double memoryNormalizeValue = (double) maxHeapSize
                    / MEMORY_NORMALIZE_VALUE;
            double writeBufferNormalizeValue = (double) maxWriteBuffer
                    / WRITE_BUFFER_NORMALIZE_VALUE;
            double load = (double) value.getMemory() / memoryNormalizeValue
                    * memoryWeight + (double) value.getReadLoad()
                    / READ_NORMALIZE_VALUE * readWeight
                    + (double) value.getWriteLoad() / WRITE_NORMALIZE_VALUE
                    * writeWeight + (double) value.getWriteBufferSize()
                    / writeBufferNormalizeValue * writeBufferWeight;
            sortedTabletsLoad.add(new TabletLoadPair(entry.getKey(), load));
            loadValue += load;
        }
        this.loadValue = loadValue;
        Collections.sort(sortedTabletsLoad);
    }

    public void resetHeartBeatTime() {
        lastHeartBeat = -1;
    }

    public TsUsageReport() {}

    public TsUsageReport(TsDesc ts) {
        this.ts = ts;
    }

    public long getMaxHeapSize() {
        return maxHeapSize;
    }

    public long getUsedHeapSize() {
        return usedHeapSize;
    }

    public long getUsedIndexPool() {
        return usedIndexPool;
    }

    public long getMaxIndexPool() {
        return maxIndexPool;
    }

    public long getUsedBlockCache() {
        return usedBlockCache;
    }

    public long getMaxBlockCache() {
        return maxBlockCache;
    }

    public int getNumTablets() {
        return tabletsLoad.size();
    }

    public TsDesc getTsDesc() {
        return ts;
    }

    public void updateTsUsage(OmapTs ts) {
        systemLoadValue = SystemInfoUtils.getLoad();
        processors = SystemInfoUtils.getProcessors();
        maxSSTableDataCacheSize = ts.sstableDataFileCache.getMaxCacheSize();
        usedSSTableDataCacheSize = ts.sstableDataFileCache.getCurrentCacheSize();
        maxWriteBuffer = ts.bufferPool.getMaxBufferSize();
        usedWriteBuffer = ts.bufferPool.getAllocatedBufferSize();
        maxBloomFilterSize = ts.filterPool.getMaxSize();
        usedBloomFilterSize = ts.filterPool.getAllocatedSize();
        maxIndexPool = ts.indexPool.getMaxSize();
        usedIndexPool = ts.indexPool.getAllocatedSize();
        maxBlockCache = ts.blockCache.getMaxSize();
        usedBlockCache = ts.blockCache.getUsedSize();
        MemoryUsage memoryUsage = SystemInfoUtils.getMemoryUsage();
        maxHeapSize = memoryUsage.getMax();
        usedHeapSize = memoryUsage.getUsed();
        readCount = 0;
        writeCount = 0;
        tabletsLoad.clear();
        for (Tablet tablet: ts.getTablets().values()) {
            LoadValue loadValue = tablet.getLoadValue();
            readCount += loadValue.getReadCount();
            writeCount += loadValue.getWriteCount();
            tabletsLoad.put(tablet.getTabletId(), loadValue);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        TsUsageReport that = (TsUsageReport) value;
        this.ts = new TsDesc();
        this.ts.copyFields(that.ts);
        this.maxWriteBuffer = that.maxWriteBuffer;
        this.usedWriteBuffer = that.usedWriteBuffer;
        this.maxBloomFilterSize = that.maxBloomFilterSize;
        this.usedBloomFilterSize = that.usedBloomFilterSize;
        this.maxIndexPool = that.maxIndexPool;
        this.usedIndexPool = that.usedIndexPool;
        this.maxBlockCache = that.maxBlockCache;
        this.usedBlockCache = that.usedBlockCache;
        this.maxSSTableDataCacheSize = that.maxSSTableDataCacheSize;
        this.usedSSTableDataCacheSize = that.usedSSTableDataCacheSize;
        this.maxHeapSize = that.maxHeapSize;
        this.usedHeapSize = that.usedHeapSize;
        this.heartBeatSeq = that.heartBeatSeq;
        this.lastHeartBeat = that.lastHeartBeat;
        this.tabletsLoad.clear();
        this.tabletsLoad.putAll(that.tabletsLoad);
        this.sortedTabletsLoad.addAll(that.sortedTabletsLoad);
        this.loadValue = that.loadValue;
        this.systemLoadValue = that.systemLoadValue;
        this.processors = that.processors;
        this.readCount = that.readCount;
        this.writeCount = that.writeCount;
        return this;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        ts = new TsDesc();
        ts.readFields(in);
        maxWriteBuffer = CDataInputStream.readVLong(in);
        usedWriteBuffer = CDataInputStream.readVLong(in);
        maxBloomFilterSize = CDataInputStream.readVLong(in);
        usedBloomFilterSize = CDataInputStream.readVLong(in);
        maxIndexPool = CDataInputStream.readVLong(in);
        usedIndexPool = CDataInputStream.readVLong(in);
        maxBlockCache = CDataInputStream.readVLong(in);
        usedBlockCache = CDataInputStream.readVLong(in);
        maxSSTableDataCacheSize = CDataInputStream.readVLong(in);
        usedSSTableDataCacheSize = CDataInputStream.readVLong(in);
        maxHeapSize = CDataInputStream.readVLong(in);
        usedHeapSize = CDataInputStream.readVLong(in);
        heartBeatSeq = CDataInputStream.readVLong(in);
        lastHeartBeat = CDataInputStream.readVLong(in);
        systemLoadValue = in.readDouble();
        processors = CDataInputStream.readVInt(in);
        readCount = CDataInputStream.readVLong(in);
        writeCount = CDataInputStream.readVLong(in);
        int sz = CDataInputStream.readVInt(in);
        tabletsLoad.clear();
        for (int i = 0; i < sz; i++) {
            long tabletId = in.readLong();
            LoadValue value = new LoadValue();
            value.readFields(in);
            tabletsLoad.put(tabletId, value);
        }

    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        ts.writeFields(out);
        CDataOutputStream.writeVLong(maxWriteBuffer, out);
        CDataOutputStream.writeVLong(usedWriteBuffer, out);
        CDataOutputStream.writeVLong(maxBloomFilterSize, out);
        CDataOutputStream.writeVLong(usedBloomFilterSize, out);
        CDataOutputStream.writeVLong(maxIndexPool, out);
        CDataOutputStream.writeVLong(usedIndexPool, out);
        CDataOutputStream.writeVLong(maxBlockCache, out);
        CDataOutputStream.writeVLong(usedBlockCache, out);
        CDataOutputStream.writeVLong(maxSSTableDataCacheSize, out);
        CDataOutputStream.writeVLong(usedSSTableDataCacheSize, out);
        CDataOutputStream.writeVLong(maxHeapSize, out);
        CDataOutputStream.writeVLong(usedHeapSize, out);
        CDataOutputStream.writeVLong(heartBeatSeq, out);
        CDataOutputStream.writeVLong(lastHeartBeat, out);
        out.writeDouble(systemLoadValue);
        CDataOutputStream.writeVInt(processors, out);
        CDataOutputStream.writeVLong(readCount, out);
        CDataOutputStream.writeVLong(writeCount, out);
        CDataOutputStream.writeVInt(tabletsLoad.size(), out);
        for (Map.Entry<Long, LoadValue> entry: tabletsLoad.entrySet()) {
            out.writeLong(entry.getKey());
            LoadValue value = entry.getValue();
            value.writeFields(out);
        }
    }

    public double getLoadValue() {
        return loadValue;
    }

    public String getLoadValue(int precision) {
        return String.format("%." + precision + "f", loadValue);
    }

    public double getSystemLoadValue() {
        return systemLoadValue;
    }

    public String getSystemLoadValue(int precision) {
        return String.format("%." + precision + "f", systemLoadValue);
    }

    public String getSystemLoadValueAndProcessors(int precision) {
        return String.format("%." + precision + "f/%d", systemLoadValue,
                processors);
    }

    public boolean underCriticalLoad() {
        return systemLoadValue > processors * 2;
    }

    @Override
    public String toString() {
        return "TsUsageReport [ts=" + ts + ", loadValue=" + loadValue
                + ", maxHeapSize=" + maxHeapSize + ", usedHeapSize="
                + usedHeapSize + ", maxWriteBuffer=" + maxWriteBuffer
                + ", usedWriteBuffer=" + usedWriteBuffer
                + ", maxBloomFilterSize=" + maxBloomFilterSize
                + ", usedBloomFilterSize=" + usedBloomFilterSize
                + ", maxSSTableDataCacheSize=" + maxSSTableDataCacheSize
                + ", usedSSTableDataCacheSize=" + usedSSTableDataCacheSize
                + ", heartBeatSeq=" + heartBeatSeq + ", readCount=" + readCount
                + ", writeCount=" + writeCount + ", systemLoadValue="
                + systemLoadValue + ", processors=" + processors
                + ", lastHeartBeat=" + lastHeartBeat + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        TsUsageReport that = (TsUsageReport) o;
        return ts.equals(that.ts);
    }

    @Override
    public int hashCode() {
        return ts.hashCode();
    }

    public static class TabletLoadPair implements Comparable<TabletLoadPair> {
        public final long id;

        public final double load;

        public TabletLoadPair(long id, double load) {
            this.id = id;
            this.load = load;
        }

        // reverse
        @Override
        public int compareTo(TabletLoadPair o) {
            if (load > o.load) {
                return -1;
            }
            if (load < o.load) {
                return 1;
            }
            if (id > o.id) {
                return -1;
            }
            if (id < o.id) {
                return 1;
            }
            return 0;
        }

        @Override
        public int hashCode() {
            return (int) id;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            TabletLoadPair that = (TabletLoadPair) obj;
            return id == that.id;
        }

        @Override
        public String toString() {
            return "[" + id + ", " + load + "]";
        }
    }

    public List<TabletLoadPair> getSortedTabletsLoad() {
        return sortedTabletsLoad;
    }

    public LoadValue getTabletLoad(long tabletId) {
        return tabletsLoad.get(tabletId);
    }

    public Map<Long, LoadValue> getAllTabletsLoad() {
        return tabletsLoad;
    }

    public long getReadCount() {
        return readCount;
    }

    public long getWriteCount() {
        return writeCount;
    }

    public long getMaxBloomFilterSize() {
        return maxBloomFilterSize;
    }

    public long getUsedBloomFilterSize() {
        return usedBloomFilterSize;
    }
}
