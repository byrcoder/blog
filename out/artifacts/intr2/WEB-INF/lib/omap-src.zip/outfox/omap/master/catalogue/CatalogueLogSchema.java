/**
 * @(#)CatalogueLogSchema.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import outfox.omap.client.OmapMetadata;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogBody;

/**
 * @author zhangduo
 */
public class CatalogueLogSchema implements WALogBody {

    private long schemaId;

    private boolean deleted;

    private OmapMetadata metadata;

    public CatalogueLogSchema() {}

    public CatalogueLogSchema(long schemaId, boolean deleted,
            OmapMetadata metadata) {
        this.schemaId = schemaId;
        this.deleted = deleted;
        this.metadata = metadata;
    }

    public long getSchemaId() {
        return schemaId;
    }

    public void setSchemaId(long schemaId) {
        this.schemaId = schemaId;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public OmapMetadata getMetadata() {
        return metadata;
    }

    public void setMetadata(OmapMetadata metadata) {
        this.metadata = metadata;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        schemaId = in.readLong();
        deleted = in.readBoolean();
        if (!deleted) {
            if (metadata == null) {
                metadata = new OmapMetadata();
            }
            metadata.readFields(in);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(schemaId);
        out.writeBoolean(deleted);
        if (!deleted) {
            metadata.writeFields(out);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        CatalogueLogSchema v = (CatalogueLogSchema) value;
        schemaId = v.schemaId;
        deleted = v.deleted;
        if (!deleted) {
            if (metadata == null) {
                metadata = new OmapMetadata();
            }
            metadata.copyFields(v.metadata);
        }
        return this;
    }

    @Override
    public String toString() {
        return "CatalogueLogSchema [schemaId=" + schemaId + ", deleted="
                + deleted + ", metadata=" + metadata + "]";
    }

    @Override
    public String toStructuredString(MetadataProvider provider) {
        return toString();
    }

}
