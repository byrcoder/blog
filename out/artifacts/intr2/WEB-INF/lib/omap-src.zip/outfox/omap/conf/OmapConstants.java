package outfox.omap.conf;

import java.util.Collections;
import java.util.Map;

import outfox.omap.client.query.IndexSchema;

/**
 * Consts for omap.
 * 
 * @author yf, xuw, river
 */
public interface OmapConstants {

    public static final String TABLENAME_SEPARATOR = "$";

    public static final String INDEX_TABLE_NAME_TAG = "IDX";

    public static final String INDEX_COL_NAMES = "IndexKey; OriginalKey";

    /**
     * It is always empty (immutable)
     */
    public static final Map<IndexSchema, String> EMPTY_INDEX_MAP = Collections
            .emptyMap();

    /**
     * This should be larger than all catalog schemaIds
     */
    public static final long FIRST_USER_SCHEMAID = 0x10;

    // /////////////////////////////
    // default configuration

    // static public final String MASTERNAME ="test6";
    static public final int DEFAULT_MASTERPORT = 7390;

    // static public final String WAL_PATH= TS_DATA_PATH;
    // static public final String MASTER_DATA_PATH = "/tmp/omap_master/";

    static public final long RETRY_WAIT_TIME = 3000;

    static public final int DUPLICATE_TASK_STATUS = 9999;

    // static public int max_keys_in_writebuf = 10000;

    // static public int max_keys_per_tablet =
    // OdisConfig.getInt("omap.max_keys_per_tablet",3000000);

    public static final String CHKPT_FILENAME = "checkpoint";

}
