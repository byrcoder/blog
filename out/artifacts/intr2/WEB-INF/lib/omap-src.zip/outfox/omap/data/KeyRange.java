/**
 * @(#)KeyRange.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.common.TsDesc;
import outfox.omap.util.GenericWritableComparator;
import outfox.omap.util.OmapUtils;
import toolbox.text.util.HexString;

/**
 * <p>
 * KeyRange maps a range of keys to a TS node.
 * </p>
 * <p>
 * <ul>
 * <li>Key1 is the start key, which is inclusive, a null value means min
 * possible value.</li>
 * <li>Key2 is the end key, which is exclusive.</li>
 * </ul>
 * </p>
 * <p>
 * KeyRange is comparable to both a KeyRange and a single key.
 * </p>
 * <p>
 * <strong>NOTE</strong>: Because a key(IWritableComparable) which is within a
 * KeyRange will return true in equals(), equals() IS NOT compatible with the
 * stricter hashCode(). So think twice before using KeyRange as the key in
 * hash-based Maps(HashMap or Hashtable), i.e., if single keys are used together
 * with KeyRange, DO NOT use hash-based Maps. Tree-based Maps are valid
 * alternatives.
 * </p>
 */
public class KeyRange extends KeyPair implements IWritableComparable {

    private TsDesc tsDesc;

    private long tabletId;

    /**
     * Only used with copyFields, because this contructor doesn't initialize
     * buffers.
     */
    public KeyRange() {
        super();
    }

    /**
     * Construct a KeyRange covering the whole range [null, MAX).
     * 
     * @param td
     * @param tsDesc
     * @param tabletId
     */
    public KeyRange(TsDesc tsDesc, long tabletId) {
        super(null, MAX_WRITABLE);
        this.tabletId = tabletId;
        if (tsDesc == null) {
            throw new IllegalArgumentException("tsDesc should not be null");
        }
        this.tsDesc = tsDesc;
    }

    public KeyRange(IWritableComparable startKey, IWritableComparable endKey,
            TsDesc tsDesc, long tabletId) {
        super(startKey, endKey);
        if (tsDesc == null) {
            throw new IllegalArgumentException("tsDesc should not be null");
        }
        this.tsDesc = tsDesc;
        this.tabletId = tabletId;
    }

    public long getSchemaId() {
        return OmapUtils.tid2sid(tabletId);
    }

    public boolean containsKey(IWritableComparable key) {
        return compareKey(key) == 0;
    }

    public int compareKey(IWritableComparable key) {
        GenericWritableComparator comp = GenericWritableComparator.instance;
        int cstart = comp.compare(key, getKey1());
        if (cstart < 0) {
            return 1;
        }
        int cend = comp.compare(key, getKey2());
        if (cend >= 0) {
            return -1;
        }
        return 0;
    }

    public boolean isOverLap(KeyRange b) {
        GenericWritableComparator comp = GenericWritableComparator.instance;
        int startkcomp = comp.compare(getKey1(), b.getKey1());
        if (startkcomp < 0) {
            if (comp.compare(getKey2(), b.getKey1()) > 0) {
                return true;
            }
            return false;
        } else if (startkcomp > 0) {
            if (comp.compare(getKey1(), b.getKey2()) < 0) {
                return true;
            }
            return false;
        } else {
            return true;
        }
    }

    // ///////////////////////////////////
    // IWritableComparable
    // ///////////////////////////////////

    /**
     * for split, we let the splitted KeyRanges greater than original KeyRange.
     */
    public int compareTo(IWritable o) {
        GenericWritableComparator comp = GenericWritableComparator.instance;
        // check sanity
        if (comp.compare(getKey1(), getKey2()) > 0) {
            throw new RuntimeException("start key(" + getKey1()
                    + ") is larger than end key(" + getKey2() + ")");
        }
        if (o instanceof KeyRange) { // o is a KeyRange
            return compareRange(this, (KeyRange) o);
        } else {
            return compareKey((IWritableComparable) o);
        }
    }

    public static int compareRange(KeyPair k1, KeyPair k2) {
        GenericWritableComparator comp = GenericWritableComparator.instance;
        int c11 = comp.compare(k1.getKey1(), k2.getKey1());
        int c12 = comp.compare(k1.getKey1(), k2.getKey2());
        int c21 = comp.compare(k1.getKey2(), k2.getKey1());
        int c22 = comp.compare(k1.getKey2(), k2.getKey2());
        if (c11 < 0) {
            if (c21 <= 0) { // k1 is all left
                return -1;
            } else { // overlap
                if (c22 >= 0) { // k2 is the split child
                    return -1;
                }
                throw new RuntimeException("unexpected overlap occur, " + k1
                        + " and " + k2);
            }
        } else if (c11 == 0) {
            if (c22 < 0) { // overlap, and k1 is the split child
                return 1;
            }
            if (c22 > 0) { // overlap, and k2 is the split child
                return -1;
            }
            // equal
            return 0;
        } else { // c11 > 0
            if (c12 >= 0) { // k1 is all right
                return 1;
            } else { // overlap
                if (c22 <= 0) { // k1 is the split child
                    return 1;
                }
                throw new RuntimeException("unexpected overlap occur, " + k1
                        + " and " + k2);
            }
        }
    }

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            throw new IllegalArgumentException("cannot copy from myself");
        }
        KeyRange val = (KeyRange) value;
        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }
        setKey1(val.getKey1());
        setKey2(val.getKey2());
        try {
            if (val.getTsDesc() != null) {
                this.tsDesc = val.getTsDesc().getClass().newInstance();
                tsDesc.copyFields(val.tsDesc);
            } else {
                throw new RuntimeException("val's tsDesc is null");
            }
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        this.tabletId = val.tabletId;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        tsDesc.writeFields(out);
        out.writeLong(tabletId);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        if (tsDesc == null) {
            tsDesc = new TsDesc();
        }
        tsDesc.readFields(in);
        tabletId = in.readLong();
    }

    @Override
    public void writePIFields(DataOutput out) throws IOException {
        super.writePIFields(out);
        tsDesc.writeFields(out);
        out.writeLong(tabletId);
    }

    @Override
    public void readPIFields(DataInput in) throws IOException {
        super.readPIFields(in);
        if (tsDesc == null) {
            tsDesc = new TsDesc();
        }
        tsDesc.readFields(in);
        tabletId = in.readLong();
    }

    /**
     * <p>
     * If o is a KeyRange, return true only when the start keys are identical
     * and so are the end keys.
     * </p>
     * <p>
     * If o is a IWritableComparable other than a KeyRange, which is a single
     * key, return true when the key is within the KeyRange.
     * </p>
     */
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if ((IWritableComparable.class.isAssignableFrom(o.getClass()))
                && !(o instanceof KeyRange)) {
            return this.containsKey((IWritableComparable) o);
        }
        return super.equals(o);
    }

    public TsDesc getTsDesc() {
        return tsDesc;
    }

    public void setTsDesc(TsDesc tsDesc) {
        if (tsDesc == null) {
            throw new IllegalArgumentException("tsDesc cannot be null");
        }
        this.tsDesc = tsDesc;
    }

    public long getTabletId() {
        return tabletId;
    }

    public boolean isKey1Equal(KeyRange kr) {
        IWritableComparable k1 = getKey1();
        IWritableComparable krk1 = kr.getKey1();
        return (k1 == null && krk1 == null)
                || (k1 != null && krk1 != null && k1.equals(krk1));
    }

    public boolean isKey2Equal(KeyRange kr) {
        return getKey2().equals(kr.getKey2());
    }

    public String toString() {
        return "{tabletId=" + HexString.longToPaddedHex(this.tabletId)
                + " range=[" + getKey1() + ":" + getKey2() + ") Ts="
                + this.tsDesc + "}";
    }

}
