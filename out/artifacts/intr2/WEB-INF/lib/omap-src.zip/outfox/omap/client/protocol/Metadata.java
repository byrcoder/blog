package outfox.omap.client.protocol;

import java.util.Map;

/**
 * Metadata contains attributes of a Table.
 * 
 * @author yaming
 */
public interface Metadata {

    /**
     * Return names of columns.
     * 
     * @return names of columns in an array of String
     */
    public String[] getColumnNames();

    /**
     * Return types of the column values.
     * 
     * @return type names of columns in an array of string
     */
    public String[] getColumnTypes();
    
    /**
     * Return type classes of the column values
     * @return type classes of columns in an array of Class
     */
    public Class<?>[] getColumnTypeClasses();

    /**
     * Return attribute of this table, formatted in a string.
     * 
     * @return attribute of this table as a String
     */
    public String getAttributes();

    /**
     * Return name of this table.
     * 
     * @return name of this table
     */
    public String getTableName();

    /**
     * Return number of columns of this table.
     * 
     * @return number of columns of this table
     */
    public int getColumnNum();
    
    /**
     * Get the queries associated to this table
     * @return
     */
    public Map<String, ? extends Query> getQueries();
}
