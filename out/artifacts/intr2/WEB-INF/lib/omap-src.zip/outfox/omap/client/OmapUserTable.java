package outfox.omap.client;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.IWritable;

import org.apache.commons.lang.StringUtils;

import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.query.IndexSchema;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryCursor;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.NoSuchSchemaException;
import outfox.omap.exceptions.OmapException;
import outfox.omap.metadata.KeyColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

public class OmapUserTable implements Table {

    private static final Logger LOG = LogFormatter.getLogger(OmapUserTable.class);

    protected OmapClient client;

    protected OmapTableSpace tableSpace;

    public OmapUserTable(OmapClient client, OmapTableSpace tableSpace) {
        this.client = client;
        this.tableSpace = tableSpace;
    }

    public OmapTableSpace getTableSpace() {
        return tableSpace;
    }

    @Override
    public void close() {}

    @Override
    public Row newRow() throws OmapException {
        return new OmapUserRow(client.createDataRow(), this);
    }

    @Override
    public void delete(IWritable key) throws OmapException {
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        KeyCell keyCell = kcDesc.borrowKeyCell();
        try {
            keyCell.setCIWritable(key);
            if (client.getMetadata().getIndexes().isEmpty()) {
                client.deleteRow(keyCell);
            } else {
                client.deleteRowWithQuery(keyCell);
            }
        } finally {
            kcDesc.returnKeyCell(keyCell);
        }
    }

    @Override
    public void delete(IWritable[] keys) throws OmapException {
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        if (client.getMetadata().getIndexes().isEmpty()) {
            KeyCell[] keyCells = new KeyCell[keys.length];
            try {
                for (int i = 0; i < keys.length; i++) {
                    keyCells[i] = kcDesc.borrowKeyCell();
                    keyCells[i].setCIWritable(keys[i]);
                }
                client.deleteRows(keyCells);
            } finally {
                for (KeyCell keyCell: keyCells) {
                    if (keyCell != null) {
                        kcDesc.returnKeyCell(keyCell);
                    }
                }
            }
        } else {
            KeyCell keyCell = kcDesc.borrowKeyCell();
            try {
                for (IWritable key: keys) {
                    keyCell.setCIWritable(key);
                    client.deleteRowWithQuery(keyCell);
                }
            } finally {
                kcDesc.returnKeyCell(keyCell);
            }
        }

    }

    @Override
    public Metadata getMetadata() {
        return client.getMetadata();
    }

    @Override
    public TableCursor getTableCursor() throws OmapException {
        return new OmapUserTableCursor(this.client);
    }

    @Override
    public boolean lookup(IWritable key, Row row) throws OmapException {
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        KeyCell keyCell = kcDesc.borrowKeyCell();
        try {
            keyCell.setCIWritable(key);
            DataRow dataRow = client.keyFind(keyCell);
            if (dataRow != null) {
                ((OmapUserRow) row).setDataRow(dataRow);
                return true;
            } else {
                return false;
            }
        } finally {
            kcDesc.returnKeyCell(keyCell);
        }
    }

    @Override
    public boolean[] lookup(IWritable[] keys, Row[] rows) throws OmapException {
        if (keys.length != rows.length) {
            throw new IllegalArgumentException(
                    "keys and rows length must be equal");
        }
        KeyCell[] keyCells = new KeyCell[keys.length];
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        for (int i = 0; i < keys.length; i++) {
            keyCells[i] = kcDesc.borrowKeyCell();
            keyCells[i].setCIWritable(keys[i]);
        }
        DataRow[] drs = client.keysFind(keyCells);
        boolean[] ret = new boolean[keys.length];
        for (int i = 0; i < keys.length; i++) {
            if (drs[i] != null) {
                ((OmapUserRow) rows[i]).setDataRow(drs[i]);
                ret[i] = true;
            } else {
                ret[i] = false;
            }
            kcDesc.returnKeyCell(keyCells[i]);
        }
        return ret;
    }

    @Override
    public boolean contains(IWritable key) throws OmapException {
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        KeyCell keyCell = kcDesc.borrowKeyCell();
        try {
            keyCell.setCIWritable(key);
            return client.contains(keyCell);
        } finally {
            kcDesc.returnKeyCell(keyCell);
        }
    }

    @Override
    public boolean[] contains(IWritable[] keys) throws OmapException {
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        KeyCell[] keyCells = new KeyCell[keys.length];
        for (int i = 0; i < keys.length; i++) {
            keyCells[i] = kcDesc.borrowKeyCell();
            keyCells[i].setCIWritable(keys[i]);
        }
        boolean[] ret = client.contains(keyCells);
        for (KeyCell keyCell: keyCells) {
            kcDesc.returnKeyCell(keyCell);
        }
        return ret;
    }

    @Override
    public void update(Row row) throws OmapException {
        if (client.getMetadata().getIndexes().isEmpty()) {
            client.insertRow(((OmapUserRow) row).getDataRow());
        } else {
            client.insertRowWithQuery(((OmapUserRow) row).getDataRow());
        }
    }

    @Override
    public void update(Row[] rows) throws OmapException {
        if (client.getMetadata().getIndexes().isEmpty()) {
            DataRow[] dataRows = new DataRow[rows.length];
            for (int i = 0; i < rows.length; i++) {
                dataRows[i] = ((OmapUserRow) rows[i]).getDataRow();
            }
            client.insertRows(((DataRow[]) dataRows));
        } else {
            for (Row row: rows) {
                client.insertRowWithQuery(((OmapUserRow) row).getDataRow());
            }
        }
    }

    @Override
    public Query getQuery(String queryName) {
        return client.getMetadata().getQueries().get(queryName);
    }

    @Override
    public Iterator<OmapQuery> queryIterator() {
        return client.getMetadata().getQueries().values().iterator();
    }

    @Override
    public int getQueryCount() {
        return client.getMetadata().getQueries().size();
    }

    @Override
    public List<IWritable> execute(Query query) throws OmapException {
        if (query == null) {
            throw new IllegalArgumentException("query can not be null");
        }
        return client.doExecute((OmapQuery) query);
    }

    /**
     * Check whether the query is valid to execute. Only those specified ones
     * and compitable ones are valid.
     * 
     * @param query
     *            the query to be checked
     * @return the check result
     */
    public boolean isValidToExecute(Query query) {
        IndexSchema is = ((OmapQuery) query).getIndexSchema();
        return client.getMetadata().getIndexes().containsKey(is);
    }

    @Override
    public List<IWritable> execute(String queryName) throws OmapException {
        return execute(getQuery(queryName));
    }

    @Override
    public TableCursor getQueryCursor(String queryName) throws OmapException {
        return getQueryCursor(getQuery(queryName));
    }

    @Override
    public TableCursor getQueryCursor(Query query) throws OmapException {
        if (query == null) {
            throw new IllegalArgumentException("query can not be null");
        }
        if (!isValidToExecute(query)) {
            throw new OmapException("query = " + query
                    + " is not valid to execute");
        }
        OmapQuery oQuery = (OmapQuery) query;
        while (true) {
            try {
                return new OmapQueryCursor(this.client, oQuery);
            } catch (NoSuchSchemaException e) {
                LOG.log(Level.WARNING, "metadata not correct, need refresh", e);
                client.handleNoSuchSchemaFailure(oQuery);
            }
        }
    }

    @Override
    public void setProperty(String name, String value) throws OmapException {
        String[] propArr = new String[2];
        propArr[0] = name;
        propArr[1] = value;
        client.setTableProperties(propArr);
        try {
            client.updateTableMetaFromMaster();
        } catch (IOException e) {
            throw new OmapException(
                    "update table meta failed after set property", e);
        }
    }

    @Override
    public void delete(IWritable startKeyIncludsive, IWritable endKeyExclusive)
            throws OmapException {
        KeyColumnDesc kcDesc = client.getMetadata().getTableDesc().getKey();
        KeyCell start = kcDesc.borrowKeyCell();
        KeyCell end = kcDesc.borrowKeyCell();
        try {
            start.setCIWritable(startKeyIncludsive);
            end.setCIWritable(endKeyExclusive);
            client.deleteRows(start, end);
        } finally {
            kcDesc.returnKeyCell(start);
            kcDesc.returnKeyCell(end);
        }
    }

    @Override
    public boolean compareAndUpdate(IWritable key, String columnName,
            IWritable columnValue, Row update) throws OmapException {
        TableDesc td = client.getMetadata().getTableDesc();
        DataCell column;
        if (columnName == null) {
            column = null;
        } else {
            int colIndex = td.getColumnIndex(columnName);
            column = td.getColumn(colIndex).createDataCell();
            if (columnValue == null) {
                column.setNull();
            } else {
                column.setCIWritable(columnValue);
            }
        }
        KeyColumnDesc kcd = td.getKey();
        KeyCell keyCell = kcd.borrowKeyCell();
        try {
            keyCell.setCIWritable(key);
            return client.compareAndInsertRow(keyCell, columnName, column,
                    ((OmapUserRow) update).getDataRow());
        } finally {
            kcd.returnKeyCell(keyCell);
        }
    }

    @Override
    public boolean compareAndDelete(IWritable key, String columnName,
            IWritable columnValue, IWritable delete) throws OmapException {
        TableDesc td = client.getMetadata().getTableDesc();
        DataCell column;
        if (columnName == null) {
            column = null;
        } else {
            int colIndex = td.getColumnIndex(columnName);
            column = td.getColumn(colIndex).createDataCell();
            if (columnValue == null) {
                column.setNull();
            } else {
                column.setCIWritable(columnValue);
            }
        }
        KeyColumnDesc kcd = td.getKey();
        KeyCell keyCell = kcd.borrowKeyCell();
        KeyCell deleteKeyCell = kcd.borrowKeyCell();
        try {
            keyCell.setCIWritable(key);
            deleteKeyCell.setCIWritable(delete);
            return client.compareAndDeleteRow(keyCell, columnName, column,
                    deleteKeyCell);
        } finally {
            kcd.returnKeyCell(keyCell);
            kcd.returnKeyCell(deleteKeyCell);
        }
    }

    @Override
    public void chmod(String mode) throws OmapException {
        if (!OmapUtils.validatePermissionMode(mode)) {
            throw new IllegalArgumentException("The mode string is illegal: "
                    + mode);
        }
        setProperty(Table.Property.ACL_PERMISSION_NAME, mode);
    }

    @Override
    public void setGroupUsers(List<String> groupUsers) throws OmapException {
        String group = StringUtils.join(groupUsers, ';');
        setProperty(Table.Property.ACL_GROUP_NAME, group);
    }
}
