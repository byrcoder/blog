package outfox.omap.test.resultanalyzer;

import java.io.DataOutput;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

public class EventList {
    private TreeMap<Long, TreeMap<Integer, EventRecord>> allData = null;

    private double totalThroughput;

    private double averageResponseTime;

    private int totalClient = 0;

    private String name = null;

    public EventList(String name) {
        allData = new TreeMap<Long, TreeMap<Integer, EventRecord>>();
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getTotalThroughput() {
        NumberFormat nf = NumberFormat.getInstance();
        nf.setGroupingUsed(false);
        nf.setMaximumFractionDigits(5);
        String res = nf.format(this.totalThroughput);
        return res;
    }

    public double getAverageResponseTime() {
        return this.averageResponseTime;
    }

    public int getClientNum() {
        return this.totalClient;
    }

    public void addEvent(EventRecord data) {
        if (data.getID() == EventRecord.AVERAGE_THROUGHPUT) {
            this.totalThroughput += Double.valueOf(data.getData());
            return;
        }
        if (data.getID() == EventRecord.AVERAGE_RESPONSE_TIME) {
            this.totalClient += 1;
            this.averageResponseTime = (this.averageResponseTime
                    * (this.totalClient - 1) + Double.valueOf(data.getData()))
                    / this.totalClient;
            return;
        }
        TreeMap<Integer, EventRecord> d = allData.get(data.getTime().getTimeInMillis() / 1000);
        if (d == null) {
            d = new TreeMap<Integer, EventRecord>();
            d.put(data.getID(), data);
            allData.put(data.getTime().getTimeInMillis() / 1000, d);
        } else
            d.put(data.getID(), data);

    }

    public void output(DataOutput out) throws IOException {
        out.write("Time".getBytes());
        for (int i = 0; i < EventRecord.MAX_ID - 2; i++)
            out.write(("\t" + EventRecord.idName[i]).getBytes());
        out.write("\n".getBytes());
        Iterator<Entry<Long, TreeMap<Integer, EventRecord>>> iter1 = allData.entrySet().iterator();
        long start = -1;
        while (iter1.hasNext()) {
            Entry<Long, TreeMap<Integer, EventRecord>> e = iter1.next();
            if (start == -1)
                start = e.getKey().longValue();
            long now = e.getKey().longValue() - start;
            out.write(String.valueOf(now).getBytes());
            e.getValue().values().iterator();
            Iterator<EventRecord> iter2 = e.getValue().values().iterator();
            int index = -1;
            while (iter2.hasNext()) {
                EventRecord record = iter2.next();
                for (int j = 0; j < record.getID() - index; j++)
                    out.write("\t".getBytes());
                out.write(record.getData().getBytes());
                index = record.getID();
            }
            out.write("\n".getBytes());

        }
    }
}
