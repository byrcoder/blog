package outfox.omap.util;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import toolbox.misc.LogFormatter;

/**
 * A utility that constrains the total throughput of one or more simultaneous
 * flows (threads) by sleeping when necessary.
 * 
 * @author zhangkun
 */
public class ThroughputController {
    private static final Logger LOG = LogFormatter.getLogger(ThroughputController.class);

    /**
     * Stores the information of one controlled flow.
     */
    private static class Flow {
        double sleep = 1;

        double throughput;

        long lastUpdateTime;

        final long startTime;

        double totalSize;

        Flow() {
            startTime = System.currentTimeMillis();
            lastUpdateTime = startTime;
        }
    }

    /**
     * The factor used to adjust sleep time
     */
    private double adjustFactor = 0.1;

    /**
     * Set the sleep time adjust factor. Sleep time is multiplied/divided by
     * (1+factor) to slow down/accelerate a flow.
     * 
     * @param factor
     *            factor, should be larger than 0.
     */
    public void setAdjustFactor(double factor) {
        if (factor <= 0) {
            throw new IllegalArgumentException("should be larger than 0 ("
                    + factor + ")");
        }
        this.adjustFactor = factor;
    }

    /**
     * Set the maximum total throughput (per second) of the flows controlled by
     * this FlowController.
     * 
     * @param throughput
     */
    public void setMaxThroughput(double throughput) {
        this.maxThroughput = throughput;
    }

    /**
     * threadId->Flow map
     */
    private ConcurrentMap<Long, Flow> flows = new ConcurrentHashMap<Long, Flow>();

    private double maxThroughput;

    /**
     * Constructor.
     * 
     * @param maxThroughput
     *            the maximum total throughput (per second) of the flows
     *            controlled by this FlowController.
     */
    public ThroughputController(double maxThroughput) {
        this.maxThroughput = maxThroughput;
    }

    /**
     * This method should be called after every fragment of a flow is
     * transmitted. It may sleep current thread for some time if the total
     * throughput has exceeded the maxThroughput limit.
     * 
     * @param size
     *            the size of the fragment that has just been transmitted
     * @return the actual sleep time
     * @throws java.lang.InterruptedException
     */
    public long control(double size) throws InterruptedException {
        long threadId = Thread.currentThread().getId();
        Flow flow = flows.get(threadId);
        if (flow == null) {
            flow = new Flow();
            flows.put(threadId, flow);
            flow.totalSize = size;
            return 0;
        }
        flow.totalSize += size;
        long currentTime = System.currentTimeMillis();
        double duration = (currentTime - flow.lastUpdateTime) / 1000.0;
        flow.lastUpdateTime = currentTime;
        if (duration <= 0) {
            duration = 0.001;
        }
        flow.throughput = ((double) size) / duration;
        double totalThroughput = getCurrentThroughput();
        double averageThroughput = totalThroughput / flows.size();
        if (totalThroughput > maxThroughput) {
            if (flow.throughput >= averageThroughput) {
                // slow down
                flow.sleep *= (1 + adjustFactor);
            }
        } else {
            if (flow.sleep >= 1) {
                // accelerate
                flow.sleep /= (1 + adjustFactor);
            }
        }
        if (LOG.isLoggable(Level.FINEST)) {
            LOG.finest("Sleep for " + flow.sleep + " throughput="
                    + flow.throughput + " duration=" + duration);
        }
        if (flow.sleep >= 1) {
            long sleepTime = (long) flow.sleep;
            Thread.sleep(sleepTime);
            return sleepTime;
        }
        return 0;
    }

    /**
     * This method should be called after a flow is being closed.
     */
    public void finish() {
        long threadId = Thread.currentThread().getId();
        Flow flow = flows.remove(threadId);
        if (flow != null) {
            long duration = (System.currentTimeMillis() - flow.startTime) / 1000;
            if (duration <= 0) {
                duration = 1;
            }
            LOG.info("Average throughput: " + (flow.totalSize / duration)
                    + ". " + flows.size()
                    + " flows left, current total throughput: "
                    + getCurrentThroughput() + ", limit=" + maxThroughput);
        }
    }

    /**
     * Get the current total throughput of all flows
     * 
     * @return
     */
    public double getCurrentThroughput() {
        double ret = 0;
        for (Flow flow: flows.values()) {
            ret += flow.throughput;
        }
        return ret;
    }
}
