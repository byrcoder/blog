package outfox.omap.client.protocol;

import java.util.Iterator;
import java.util.List;
import odis.serialize.IWritable;
import outfox.omap.conf.OmapConfig;
import outfox.omap.exceptions.OmapException;

/**
 * Interface of a omap Table, include methods of operation of rows.
 * 
 * @author yaming
 */
public interface Table {

    public static final class Property {
        /**
         * The replication number on odfs of this table's data.<br>
         * default is 2.For importent data, you may set this value to 3 or
         * larger.If you use OMAP as an cache, you should set this value to 1
         */
        public static final String REPLICATION_NAME = "replication";

        /**
         * Default replication number is 3
         */
        public static final String DEFAULT_REPLICATION = "3";

        /**
         * The compress algorithm used for this table. Default is
         * {@link #LZO_COMPRESS}
         */
        public static final String COMPRESS_NAME = "compress";

        /**
         * No compress
         */
        public static final String NO_COMPRESS = CompressType.toString(CompressType.NULL);

        /**
         * GZIP
         */
        public static final String GZIP_COMPRESS = CompressType.toString(CompressType.GZIP);

        /**
         * LZO
         */
        public static final String LZO_COMPRESS = CompressType.toString(CompressType.LZO);

        /**
         * Default is lzo compress
         */
        public static final String DEFAULT_COMPRESS = LZO_COMPRESS;

        /**
         * <code>false</code> means you only add new row to the table most of
         * the time, and <code>true</code> means you often update exist row in
         * the table.<br>
         * if this set to <code>true</code>, OMAP will consider the max
         * sstable's size as a tablet's size when doing split.<br>
         * Notice that, this is only a hint for OMAP, set it to
         * <code>true</code> or <code>false</code> will not effect the
         * correctness or consistency. So please leave it in <code>false</code>
         * unless you have a lot of update operations
         */
        public static final String OVERWRITE_NAME = "overwrite";

        /**
         * Default overwrite is <code>false</code>
         */
        public static final String DEFAULT_OVERWRITE = "false";

        /**
         * False-rate is set for sstable's bloomfilter, the float value should
         * be in (0,1). <br>
         * Default value is <code>0.05f</code> <br>
         * Apparently, the lower the rate is set, the bigger the filter file
         * size is.
         */
        public static final String BLOOMFILTER_FALSERATE_NAME = "bloomfilter_falserate";

        /**
         * Default value is <code>0.05f</code>
         */
        public static final String DEFAULT_BLOOMFILTER_FALSERATE = "0.05";

        /**
         * The group user of omap acl
         */
        public static final String ACL_GROUP_NAME = "acl_group";

        /**
         * default: no user in group
         */
        public static final String DEFAULT_ACL_GROUP = "";

        /**
         * The table owner of omap acl
         */
        public static final String ACL_OWNER_NAME = "acl_owner";

        /**
         * The default owner is current user
         */
        public static final String DEFAULT_ACL_OWNER = System.getProperty("user.name");

        /**
         * the acl permission strategy of the table
         */
        public static final String ACL_PERMISSION_NAME = "acl_perssion";

        /**
         * the default acl permission strategy
         */
        public static final String DEFAULT_ACL_PERMISSION = OmapConfig.DEFAULT_ACL_DEFAULT_PERMISSION;

        public static final String RESERVE_WAL_PATH_NAME = "reserve_wal_path";

        public static final String DEFAULT_RESERVE_WAL_PATH = "";

        public static final String ENABLE_MEMORY_CACHE_NAME = "enable_memory_cache";

        public static final String DEFAUL_ENABLE_MEMORY_CACHE = "false";

        /**
         * max size per tablet, 0 means use global setting.
         */
        public static final String MAX_TABLET_SIZE_NAME = "max_tablet_size";

        /**
         * the default max tablet size is 0(which means use global setting)
         */
        public static final String DEFAULT_MAX_TABLET_SIZE = "0";

        /**
         * whether to use block cache for this table.
         */
        public static final String USE_BLOCK_CACHE_NAME = "use_block_cache";

        /**
         * default to use block cache
         */
        public static final String DEFAULT_USE_BLOCK_CACHE = "true";
    }

    /**
     * <p>
     * Create a Row object. The fields of this row is determined by the current
     * table.
     * </p>
     * <p>
     * <strong>NOTE</strong>: this doesn't mean inserting a row into OMAP, but
     * just creating a local Row object for further use.
     * </p>
     * 
     * @return
     * @throws OmapException
     */
    public Row newRow() throws OmapException;

    /**
     * Get the table cursor of this table.
     * 
     * @return
     * @throws OmapException
     */
    public TableCursor getTableCursor() throws OmapException;

    /**
     * Write the content of the Row object to OMAP, and apply the modifications
     * made to its column family. If the key of this Row doesn't exist, will
     * insert a new row; otherwise, will replace the existing row. If the Row
     * object has invalid cells (that hasn't been set since created), their
     * corresponding cells of the row in OMAP will be left intact.
     * 
     * @param row
     * @throws OmapException
     */
    public void update(Row row) throws OmapException;

    /**
     * Batch update.
     * 
     * @param rows
     * @see #update(Row)
     * @throws OmapException
     */
    public void update(Row[] rows) throws OmapException;

    /**
     * Delete row with given key. If the given key doesn't exist, do nothing.
     * 
     * @param key
     * @throws OmapException
     */
    public void delete(IWritable key) throws OmapException;

    /**
     * Batch delete.
     * 
     * @param keys
     * @throws OmapException
     * @see {@link #delete(IWritable)}
     */
    public void delete(IWritable[] keys) throws OmapException;

    /**
     * Batch delete range
     * 
     * @param startKeyInclusive
     * @param endKeyExclusive
     * @throws OmapException
     */
    public void delete(IWritable startKeyInclusive, IWritable endKeyExclusive)
            throws OmapException;

    /**
     * Lookup in the table for given key. If found, put the content of the found
     * row into the Row in the argument. If not found, the Row object will not
     * be modified.
     * 
     * @param key
     * @param row
     *            the content of the found row will be put here
     * @return true if found
     * @throws OmapException
     */
    public boolean lookup(IWritable key, Row row) throws OmapException;

    /**
     * batch lookup<br>
     * 
     * @param keys
     * @param rows
     * @return
     * @throws OmapException
     */
    public boolean[] lookup(IWritable[] keys, Row[] rows) throws OmapException;

    /**
     * Execute a query by the Query object. Only the queries specified during
     * the creation of this table or the compatible queries are supported.
     * 
     * @param query
     *            the specified query object
     * @return the list of result of keys. If the query return nothing an empty
     *         list will be returned
     * @throws OmapException
     *             If the query is not supported, or any other errors occur,
     *             throw this exception
     * @author xingjk
     */
    public List<IWritable> execute(Query query) throws OmapException;

    /**
     * Execute a query by the Query's name. Only the queries specified during
     * the creation of this table or the compatible queries are supported when
     * the creator names those queries.
     * 
     * @param queryName
     * @return the list of result of keys. If the query return nothing an empty
     *         list will be returned
     * @throws OmapException
     *             If the query is not supported, query's parameter is not set,
     *             or any other errors occur, throw this exception
     * @author xingjk
     */
    public List<IWritable> execute(String queryName) throws OmapException;

    /**
     * Get a Query object according to its name
     * 
     * @param queryName
     * @return the query object or null if it does not exist
     * @author xingjk
     */
    public Query getQuery(String queryName);

    /**
     * Get a Query iterator
     * 
     * @param index
     * @return the iterator
     * @author xingjk
     */
    public Iterator<? extends Query> queryIterator();

    /**
     * Get the total number of supported queries
     * 
     * @return the queries' number
     * @author xingjk
     */
    public int getQueryCount();

    /**
     * Return true if the table contains the given key.
     * 
     * @param key
     * @return
     * @throws OmapException
     */
    public boolean contains(IWritable key) throws OmapException;

    /**
     * Return true if the table contains the given key.
     * 
     * @param key
     * @return
     * @throws OmapException
     */
    public boolean[] contains(IWritable[] keys) throws OmapException;

    /**
     * Update the given <tt>update</tt> row if we match the given column.
     * <p>
     * if columnName == null, we will check non-existence.
     * 
     * @param key
     * @param columnName
     * @param columnValue
     * @param update
     * @return
     * @throws OmapException
     */
    public boolean compareAndUpdate(IWritable key, String columnName,
            IWritable columnValue, Row update) throws OmapException;

    /**
     * Delete row with the given <tt>delete</tt> key if we match the given
     * column.
     * <p>
     * if columnName == null, we will check non-existence.
     * 
     * @param key
     * @param columnName
     * @param columnValue
     * @param delete
     * @return
     * @throws OmapException
     */
    public boolean compareAndDelete(IWritable key, String columnName,
            IWritable columnValue, IWritable delete) throws OmapException;

    /**
     * Close current table.
     */
    public void close();

    /**
     * Get the Metadata of the current table.
     * 
     * @return
     */
    public Metadata getMetadata();

    /**
     * Execute query with cursor by query name
     * 
     * @param queryName
     * @return cursor for query result or null if the query with specified name
     *         is not found
     * @throws OmapException
     */
    public TableCursor getQueryCursor(String queryName) throws OmapException;

    /**
     * Execute query with cursor by query object
     * 
     * @param query
     * @return cursor for query result or null if the given query is not
     *         compitable to queries of this table
     * @throws OmapException
     */
    public TableCursor getQueryCursor(Query query) throws OmapException;

    /**
     * Change the permission mode of the table.
     * 
     * @param mode
     *            "rwx" mode of all users(owner, group user, guest), just as
     *            file mode in linux. For example, mode can be "rwxrw-r--"
     * @throws OmapException
     */
    public void chmod(String mode) throws OmapException;

    /**
     * Set group users, users in group has the permission of group user
     * 
     * @param groupUsers
     *            group users
     * @throws OmapException
     */
    public void setGroupUsers(List<String> groupUsers) throws OmapException;

    /**
     * @param props
     * @throws OmapException
     */
    void setProperty(String name, String value) throws OmapException;
}
