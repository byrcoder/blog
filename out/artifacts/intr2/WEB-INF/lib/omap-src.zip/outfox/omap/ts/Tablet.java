/**
 * @(#)Tablet.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.IFileSystem.PathFilter;
import odis.io.Path;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.client.protocol.Table;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyRange;
import outfox.omap.exceptions.NullDataException;
import outfox.omap.exceptions.ServerUnavailableException;
import outfox.omap.exceptions.TabletNotFoundException;
import outfox.omap.exceptions.UnInitializedDataCellException;
import outfox.omap.metadata.DataRowBinaryComparator;
import outfox.omap.metadata.KeyColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.metrics.TsTabletMetricsEntry;
import outfox.omap.ts.SSTable.SSType;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.CloseableIterator;
import outfox.omap.util.MergingIterator;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.OmapUtils.TESTCASE_PREPENSE_EXCEPTION_TYPE;
import outfox.omap.util.WaitUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

public class Tablet {
    private final static Logger LOG = LogFormatter.getLogger(Tablet.class.getName());

    private final IFileSystem dfs;

    private KeyRange keyRange;

    private final long tabletId;

    private final ReentrantReadWriteLock writeBufferStructureLock = new ReentrantReadWriteLock();

    private final Object writeBufferLock = new Object();

    private NativeRamWriteBuffer writeBuffer;

    private NativeRamWriteBuffer flushBuffer;

    private final int writeBufferCheckpointSizeLimit;

    private Random rand = new Random();

    private AtomicLong readCount = new AtomicLong(0);

    private AtomicLong writeCount = new AtomicLong(0);

    private AtomicLong readLoad = new AtomicLong(0);

    private AtomicLong writeLoad = new AtomicLong(0);

    final TsTabletMetricsEntry metricsEntry = new TsTabletMetricsEntry();

    private void recordReadLoad(int count, int load) {
        readCount.addAndGet(count);
        readLoad.addAndGet(load);
    }

    private void recordWriteLoad(int count, int load) {
        writeCount.addAndGet(count);
        writeLoad.addAndGet(load);
    }

    private void setLoadFromParent(Tablet parent) {
        readCount.set(parent.readCount.get() / 2);
        writeCount.set(parent.writeCount.get() / 2);
        readLoad.set(parent.readLoad.get() / 2);
        writeLoad.set(parent.writeLoad.get() / 2);
    }

    public void setLoadFromLoadValue(LoadValue load) {
        readCount.set(load.getReadCount());
        writeCount.set(load.getWriteCount());
        readLoad.set(load.getReadLoad());
        writeLoad.set(load.getWriteLoad());
    }

    /**
     * most recent LSN of write buffer
     */
    private volatile long updateLSN;

    /**
     * Prefix for normal sstables.
     */
    public static final String SS_PREFIX = "SS_";

    /**
     * Prefix for reference sstables.
     */
    public static final String REF_PREFIX = "REF_";

    public static final String TOP_REF_PREFIX = REF_PREFIX + "TOP_";

    public static final String BOTTOM_REF_PREFIX = REF_PREFIX + "BOTTOM_";

    private final static int SS_CHECKPOINT_INITIAL_FILE_ID = 1;

    private final static int SS_TEMP_CHECKPOINT_FILE_ID = -1;

    private final static int SS_TEMP_COMPACTSS_FILE_ID = -2;

    // Every new SSTables from checkpoint will skip one ID to make room for
    // compacted SSTables in the future.
    private final static int SS_ID_INCREASE_STEP = 2;

    private final static int MINOR_COMPACT_INITIAL_SET_SIZE = 2;

    private final OmapTs ts;

    // status flags
    static final String STATUS_CHECKPOINTING = "CHECKPOINTING";

    static final String STATUS_COMPACTING_SS = "COMPACTING_SS";

    // splitting
    static final String STATUS_SPLITTING = "SPLITTING";

    // being a child from splitting, and the split is still under way
    static final String STATUS_SPLIT_CHILD = "SPLIT_CHILD";

    // being recovered from logs
    static final String STATUS_RECOVERING = "RECOVERING";

    // TS is going to request Master to make a SplitTabletTask for this Tablet
    static final String STATUS_SPLIT_REQUEST_PENDING = "SPLIT_REQUEST_PENDING";

    static final String STATUS_TO_BE_CLOSED = "TO_BE_CLOSED";

    static final String STATUS_CLOSED = "CLOSED";

    public KeyRange getKeyRange() {
        return keyRange;
    }

    private final String[] writeInhibitors = new String[] {
        STATUS_RECOVERING, STATUS_TO_BE_CLOSED, STATUS_CLOSED
    };

    private void checkWritable(boolean recovering) {
        for (String flag: writeInhibitors) {
            if (statusFlags.hasFlag(flag)) {
                if (!recovering || !flag.equals(STATUS_RECOVERING)) {
                    // under recovery Tablet can be written for recovery
                    if (flag.equals(STATUS_RECOVERING)) {
                        throw new ServerUnavailableException("under recovery");
                    } else {
                        LOG.info(flag + " forbids write");
                        throw new TabletNotFoundException(tabletId);
                    }
                }
            }
        }
    }

    private final String[] readInhibitors = new String[] {
        STATUS_RECOVERING, STATUS_TO_BE_CLOSED, STATUS_CLOSED
    };

    private void checkReadable() {
        for (String flag: readInhibitors) {
            if (statusFlags.hasFlag(flag)) {
                // catalogueTS under recovery can still be read
                if (flag.equals(STATUS_RECOVERING)) {
                    throw new ServerUnavailableException("under recovery");
                } else {
                    LOG.info(flag + " forbids read");
                    throw new TabletNotFoundException(tabletId);
                }
            }
        }
    }

    private class DelayedRemoveTasks implements Runnable {
        public void run() {
            removeTasks();
        }
    }

    private volatile long lastCheckpointTime = System.currentTimeMillis();

    private volatile long lastWriteTime = 0;

    public long getLastCheckpointTime() {
        return lastCheckpointTime;
    }

    public long getLastWriteTime() {
        return lastWriteTime;
    }

    private AtomicBoolean toBeCheckpointGuard = new AtomicBoolean(false);

    private class CheckpointTask implements Runnable {

        public void run() {
            try {
                checkpoint();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception when checkpointing "
                        + HexString.longToPaddedHex(tabletId), e);
            } finally {
                toBeCheckpointGuard.set(false);
            }
        }
    }

    private class LoadDecreaseTask implements Runnable {

        @Override
        public void run() {
            long oldLoad;
            long newLoad;
            do {
                oldLoad = readLoad.get();
                newLoad = oldLoad / 2;
            } while (!readLoad.compareAndSet(oldLoad, newLoad));

            do {
                oldLoad = writeLoad.get();
                newLoad = oldLoad / 2;
            } while (!writeLoad.compareAndSet(oldLoad, newLoad));
        }
    }

    private AtomicBoolean forceMajor = new AtomicBoolean(false);

    private class CompactSSTablesTask implements Runnable {
        public void run() {
            try {
                if (statusFlags.hasFlag(STATUS_CLOSED)) {
                    ts.perTabletTaskPool.schedule(new DelayedRemoveTasks(), 1,
                            TimeUnit.SECONDS);
                    return;
                }
                if (statusFlags.hasFlag(STATUS_RECOVERING)) {
                    return;
                }
                if (forceMajor.get()) {
                    if (!(statusFlags.hasFlag(STATUS_COMPACTING_SS))) {
                        compactSSTables(true);
                    }
                    forceMajor.set(false);
                } else {
                    int sstableCountLow = OmapConfig.getConfiguration().getInt(
                            OmapConfig.NAME_SSTABLE_COUNT_LOW,
                            OmapConfig.DEFAULT_SSTABLE_COUNT_LOW);

                    int count = getValidSSCount();
                    // Try to compact only if there are more than
                    // sstableCountLow
                    // sstables.
                    if (count > sstableCountLow) {
                        if (count > sstableCountLow * 10) {
                            AlertUtils.alert(
                                    ts.getHostPortName()
                                            + " too many sstable for "
                                            + HexString.longToPaddedHex(tabletId),
                                    "Already have " + count + " sstables",
                                    false, true);
                        }
                        if (!(statusFlags.hasFlag(STATUS_COMPACTING_SS))) {
                            if (!ts.compactSSTablesMutex.tryAcquire()) {
                                return;
                            }
                            try {
                                compactSSTables(false);
                            } finally {
                                ts.compactSSTablesMutex.release();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception in CompactSSTablesTask", e);
            }
        }
    }

    private boolean hasReferenceSSTable() {
        ssTableListUpdateLock.readLock().lock();
        try {
            return (!sstables.isEmpty()) && sstables.get(0).isReference();
        } finally {
            ssTableListUpdateLock.readLock().unlock();
        }
    }

    private class TabletSplitCheckTask implements Runnable {
        private OmapTs ts;

        public TabletSplitCheckTask(OmapTs ts) {
            this.ts = ts;
        }

        public void run() {
            try {
                boolean requestSplit = false;
                if (statusFlags.hasFlag(STATUS_CLOSED)) {
                    ts.perTabletTaskPool.schedule(new DelayedRemoveTasks(), 1,
                            TimeUnit.SECONDS);
                    return;
                }
                if (!statusFlags.waitForFlagsAndSet(null, splitBlockers,
                        splitCheckInhibitors, null)) {
                    return;
                }
                ssTableListUpdateLock.readLock().lock();
                try {
                    if (sstables.size() <= 0) {
                        return;
                    }
                } finally {
                    ssTableListUpdateLock.readLock().unlock();
                }
                long maxRecords = OmapConfig.getConfiguration().getLong(
                        OmapConfig.NAME_MAX_RECORDS_PER_TABLET,
                        OmapConfig.DEFAULT_MAX_RECORDS_PER_TABLET);
                long maxBytes = Long.parseLong(getTableDesc().getProperty(
                        Table.Property.MAX_TABLET_SIZE_NAME,
                        Table.Property.DEFAULT_MAX_TABLET_SIZE));
                if (maxBytes <= 0) {
                    maxBytes = OmapConfig.getConfiguration().getLong(
                            OmapConfig.NAME_MAX_BYTES_PER_TABLET,
                            OmapConfig.DEFAULT_MAX_BYTES_PER_TABLET);
                }
                long records;
                long bytes;
                if (getTableDesc().getProperty(Table.Property.OVERWRITE_NAME,
                        Table.Property.DEFAULT_OVERWRITE).equals("true")) {
                    records = getMaxSSNumKeys(true);
                    bytes = getMaxSSByteSize(true);
                } else {
                    records = getSSTotalNumKeys();
                    bytes = getSSTotalByteSize();
                }
                if (records >= maxRecords || bytes > maxBytes) {
                    if (bytes > maxBytes * 5) {
                        AlertUtils.alert(ts.getHostPortName() + " tablet "
                                + HexString.longToPaddedHex(tabletId)
                                + " is too large", "Already " + bytes
                                + " bytes large", false, true);
                    }
                    // if we have reference SSTable, do an major compaction
                    // first
                    if (hasReferenceSSTable()) {
                        forceMajor.set(true);
                    } else {
                        requestSplit = true;
                    }
                }

                if (requestSplit) {
                    ts.requestSplit(Tablet.this);
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "Exception in OmapTs.TabletSplitCheckTask.run", e);
            }
        }
    }

    private ScheduledFuture<?> ssCompactTask;

    private ScheduledFuture<?> splitCheckTask;

    private ScheduledFuture<?> loadUpdateTask;

    /**
     * Schedule the Tablet routine tasks in the TS's task pool. Will ignore the
     * tasks that are already scheduled.
     * 
     * @param ts
     */
    protected synchronized void scheduleTasks() {
        if (ssCompactTask == null) {
            long compactSSInterval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_COMPACT_SS_INTERVAL,
                    OmapConfig.DEFAULT_COMPACT_SS_INTERVAL);
            ssCompactTask = ts.perTabletTaskPool.scheduleWithFixedDelay(
                    new CompactSSTablesTask(), compactSSInterval,
                    compactSSInterval, TimeUnit.SECONDS);
            LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                    + ": ssCompactTask scheduled");
        }
        if (splitCheckTask == null) {
            long splitCheckInterval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_SPLIT_CHECK_INTERVAL,
                    OmapConfig.DEFAULT_SPLIT_CHECK_INTERVAL);
            splitCheckTask = ts.perTabletTaskPool.scheduleWithFixedDelay(
                    new TabletSplitCheckTask(ts), splitCheckInterval,
                    splitCheckInterval, TimeUnit.SECONDS);
            LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                    + ": splitCheckTask scheduled");
        }
        if (loadUpdateTask == null) {
            long interval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_DECREASE_TABLET_LOAD_INTERVAL,
                    OmapConfig.DEFAULT_DECREASE_TABLET_LOAD_INTERVAL);
            loadUpdateTask = ts.perTabletTaskPool.scheduleAtFixedRate(
                    new LoadDecreaseTask(), interval, interval,
                    TimeUnit.SECONDS);
            LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                    + ": loadUpdateTask scheduled");
        }
    }

    /**
     * Remove the Tablet routine tasks from the TS's task pool.
     * 
     * @param ts
     */
    protected synchronized void removeTasks() {
        if (ssCompactTask != null) {
            if (ssCompactTask.cancel(true)) {
                LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                        + ": succesfully removed ssCompactTask");
                ssCompactTask = null;
            } else {
                LOG.warning("Tablet " + HexString.longToPaddedHex(tabletId)
                        + ": failed to remove ssCompactTask");
            }
        }
        if (splitCheckTask != null) {
            if (splitCheckTask.cancel(true)) {
                LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                        + ": succesfully removed splitCheckTask");
                splitCheckTask = null;
            } else {
                LOG.warning("Tablet " + HexString.longToPaddedHex(tabletId)
                        + ": failed to remove splitCheckTask");
            }
        }
        if (loadUpdateTask != null) {
            if (loadUpdateTask.cancel(true)) {
                LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                        + ": succesfully removed loadUpdateTask");
                loadUpdateTask = null;
            } else {
                LOG.warning("Tablet " + HexString.longToPaddedHex(tabletId)
                        + ": failed to remove loadUpdateTask");
            }
        }
        ts.perTabletTaskPool.purge();
    }

    // To prevent dead lock, if more than one locks of the 2 locks below is required at a time,
    // acquire them in the following order: statusFlag.readLock(), writeBufferLock.
    // And release them in the reverse order.
    final FlagSet<String> statusFlags;

    /**
     * This lock protects the array of the currently used SSTableFiles
     * {@link sstables}
     */
    final ReentrantReadWriteLock ssTableListUpdateLock = new ReentrantReadWriteLock();

    /**
     * The currently used SSTableFiles, protected by
     * {@link ssTableListUpdateLock}. All before reading this table, one should
     * acquire the read lock; while before writing it, one should aqcuire the
     * write lock.
     */
    ArrayList<SSTable> sstables;

    public Tablet(KeyRange keyrange, OmapTs ts) throws IOException {
        this(keyrange, ts, false);
    }

    public Tablet(KeyRange keyrange, OmapTs ts, boolean recover)
            throws IOException {
        this(keyrange, ts, recover, null);
    }

    public Tablet(KeyRange keyrange, OmapTs ts, boolean recover, Tablet parent)
            throws IOException {
        this.dfs = ts.getFs();
        this.keyRange = keyrange;
        this.tabletId = keyrange.getTabletId();
        this.statusFlags = new FlagSet<String>(
                HexString.longToPaddedHex(tabletId));
        this.ts = ts;
        this.writeBufferCheckpointSizeLimit = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_WRITE_BUFFER_SIZE,
                OmapConfig.DEFAULT_WRITE_BUFFER_SIZE);
        Path ssDir = new Path(OmapUtils.getSSTableFileDirPath(ts.tabletDir,
                tabletId));

        //This is for update_lsn initialization
        if (ts.getInsertLogger() != null) {
            updateLSN = ts.getInsertLogger().getCurrentLSN();
        } else {
            LOG.warning("The InsertLogger of OmapTs is null, that is impossible");
        }

        // find sstables
        LOG.info("sstable files are at: " + ssDir.getAbsolutePath());
        TableDesc tableDesc = getTableDesc();
        if (!dfs.exists(ssDir)) {
            dfs.mkdirs(ssDir);
            if (dfs instanceof DistributedFileSystem) {
                byte replicationNumber;
                String str = tableDesc.getProperties().get(
                        Table.Property.REPLICATION_NAME);
                if (str == null) {
                    str = Table.Property.DEFAULT_REPLICATION;
                }
                replicationNumber = Byte.parseByte(str);
                ((DistributedFileSystem) dfs).setReplication(ssDir,
                        replicationNumber, true);
            } else {
                LOG.warning("only DistributedFileSystem can set ReplicationNumber");
            }
        }

        sstables = new ArrayList<SSTable>();
        if (parent != null) {
            // its parent is still splitting
            LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                    + " is a split child");
            statusFlags.setFlag(STATUS_SPLIT_CHILD);
            setLoadFromParent(parent);
        } else {
            FileInfo[] ss = dfs.listFiles(ssDir, new PathFilter() {

                @Override
                public boolean accept(Path path) {
                    String name = path.getName();
                    return name.startsWith(SS_PREFIX)
                            || name.startsWith(TOP_REF_PREFIX)
                            || name.startsWith(BOTTOM_REF_PREFIX);
                }
            });
            LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                    + " initially has " + ss.length + " SSTable files");
            for (int i = 0; i < ss.length; i++) {
                Path path = ss[i].getPath();
                SSTable ssfile = null;
                if (path.getName().startsWith(SS_PREFIX)) {
                    long id = getSSFileId(path.getName());
                    if (id >= 0) {
                        ssfile = createSSTable(path);
                    } else {
                        LOG.warning("unfinish SSTable " + path + ", delete it");
                        dfs.delete(path);
                    }
                } else if (path.getName().startsWith(TOP_REF_PREFIX)) {
                    long id = getTopREFFileId(path.getName());
                    ssfile = new SSTable(ts, tabletId, id, SSType.TOP_REF,
                            keyRange.getKey2());
                } else if (path.getName().startsWith(BOTTOM_REF_PREFIX)) {
                    long id = getBottomREFFileId(path.getName());
                    ssfile = new SSTable(ts, tabletId, id, SSType.BOTTOM_REF,
                            keyRange.getKey1());
                }
                if (ssfile != null) {
                    sstables.add(ssfile);
                }
            }
            Collections.sort(sstables, SSTable.COMPARATOR);
            // check if we already do a major compaction and delete ref sstables
            for (int i = 0; i < sstables.size(); i++) {
                SSTable sstable = sstables.get(i);
                if (!sstable.isReference()) {
                    if (sstable.getFileId() == 0) {
                        if (i > 0) {
                            LOG.info("a major compaction is already done, delete ref sstables");
                            for (int j = 0; j < i; j++) {
                                SSTable refsstable = sstables.get(j);
                                LOG.info("Deleting " + refsstable.path);
                                dfs.delete(refsstable.path);
                            }
                            ArrayList<SSTable> newsstables = new ArrayList<SSTable>(
                                    sstables.size() - i);
                            for (int j = i; j < sstables.size(); j++) {
                                newsstables.add(sstables.get(j));
                            }
                            sstables = newsstables;
                        }
                    }
                    break;
                }
            }

            // check and fix the monotonicity of file IDs, which is required by the
            // naming of compacted SSTables.
            for (int pos = 1; pos < sstables.size(); pos++) {
                if (sstables.get(pos - 1).isReference()
                        && !sstables.get(pos).isReference()) {
                    if (sstables.get(pos - 1).getFileId() >= sstables.get(pos).getFileId()) {
                        LOG.info("File ID monotonicity broken at " + pos
                                + " for tablet "
                                + HexString.longToPaddedHex(tabletId)
                                + ", sstables=" + sstables);
                        // fix file ID monotonicity, pos points to the first non-reference file
                        ArrayList<SSTable> nonRefFiles = new ArrayList<SSTable>();
                        long newId = Math.max(
                                sstables.get(pos - 1).getFileId(), // the latest refFile
                                sstables.get(sstables.size() - 1).getFileId()); // the latest nonRefFile
                        for (int i = pos; i < sstables.size(); i++) {
                            newId += SS_ID_INCREASE_STEP;
                            Path newSSTablePath = new Path(
                                    Tablet.getSSTableFilePath(ts, tabletId,
                                            newId));
                            LOG.info("Renaming "
                                    + sstables.get(i).getODFSFile() + " to "
                                    + newSSTablePath);
                            dfs.rename(sstables.get(i).getODFSFile(),
                                    newSSTablePath);
                            SSTable newSS = createSSTable(newId);
                            nonRefFiles.add(newSS);
                        }
                        for (int i = sstables.size() - 1; i >= pos; i--) {
                            sstables.remove(i);
                        }
                        sstables.addAll(nonRefFiles);
                    }
                    break;
                }
            }
        }
        LOG.info("SSTables of " + toString() + ": " + sstables);
        if (recover) {
            statusFlags.setFlag(STATUS_RECOVERING);
        }
    }

    /**
     * Clear the RECOVERING flag of the Tablet
     */
    public void doneRecovery() {
        statusFlags.clearFlag(STATUS_RECOVERING);
    }

    public boolean hasStatusFlag(String flag) {
        return statusFlags.hasFlag(flag);
    }

    public int getValidSSCount() {
        this.ssTableListUpdateLock.readLock().lock();
        try {
            return sstables.size();
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
    }

    /**
     * Get the max number of keys of the SS Files. It is less than, or equal to
     * (right after a compacting following a checkpoint) the actual number of
     * keys of the Tablet.
     * 
     * @return
     */
    public long getMaxSSNumKeys(boolean actual) throws IOException {
        long count = 0;
        this.ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                long c = actual ? ss.actualNumKeys() : ss.numKeys();
                if (c > count) {
                    count = c;
                }
            }
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
        return count;
    }

    public long getMaxSSByteSize(boolean isRefHalf) throws IOException {
        long maxSize = 0;
        this.ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                long size = ss.dataSize();
                if (ss.isReference() && isRefHalf) {
                    size /= 2;
                }
                if (size > maxSize) {
                    maxSize = size;
                }
            }
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
        return maxSize;
    }

    /**
     * Get the number of keys all all SS files.
     * 
     * @return
     */
    public long getSSTotalNumKeys() {
        long count = 0;
        this.ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                count += ss.actualNumKeys();
            }
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
        return count;
    }

    public long getSSTotalByteSize() {
        long size = 0;
        this.ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                size += ss.actualDataSize();
            }
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
        return size;
    }

    /**
     * size before compression
     * 
     * @return
     * @throws IOException
     */
    public long getSSTotalOriginByteSize() {
        long size = 0;
        this.ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                size += ss.actualOriginalDataSize();
            }
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
        return size;
    }

    public long getSSTotalIndexByteSize() {
        long size = 0;
        ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                size += ss.getLoadedIndexSize();
            }
        } finally {
            ssTableListUpdateLock.readLock().unlock();
        }
        return size;
    }

    public long getSSTotalBloomFilterSize() {
        long size = 0;
        ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                size += ss.getLoadedBloomFilterSize();
            }
        } finally {
            ssTableListUpdateLock.readLock().unlock();
        }
        return size;
    }

    public long getWBNumKeysEsti() {
        long numKeys;
        writeBufferStructureLock.readLock().lock();
        try {
            synchronized (writeBufferLock) {
                numKeys = writeBuffer == null ? 0 : writeBuffer.getNumKeys();
                if (flushBuffer != null) {
                    numKeys += flushBuffer.getNumKeys();
                }
            }
        } finally {
            writeBufferStructureLock.readLock().unlock();
        }
        return numKeys;
    }

    public long getSSTotalDeletedNumKeys() {
        long count = 0;
        this.ssTableListUpdateLock.readLock().lock();
        try {
            for (SSTable ss: sstables) {
                count += ss.deletedNumKeys();
            }
        } finally {
            this.ssTableListUpdateLock.readLock().unlock();
        }
        return count;
    }

    public static long getSSTableFileId(String fileName) {
        int startIndex = fileName.lastIndexOf('_');
        return Long.parseLong(fileName.substring(startIndex + 1));
    }

    public static long getSSFileId(String fileName) {
        String idstr = fileName.substring(SS_PREFIX.length());
        return Long.parseLong(idstr);
    }

    public static long getTopREFFileId(String fileName) {
        String idstr = fileName.substring(TOP_REF_PREFIX.length());
        return Long.parseLong(idstr);
    }

    public static long getBottomREFFileId(String fileName) {
        String idstr = fileName.substring(BOTTOM_REF_PREFIX.length());
        return Long.parseLong(idstr);
    }

    /**
     * @return an estimation of total number of keys in SS tables and
     *         WriteBuffer
     */
    public long getNumKeys() {
        return getSSTotalNumKeys() + getWBNumKeysEsti();
    }

    public long getDataSize() {
        return getSSTotalByteSize() + getWBActualByteSize();
    }

    public long getWBActualByteSize() {
        long size;
        writeBufferStructureLock.readLock().lock();
        try {
            synchronized (writeBufferLock) {
                size = writeBuffer == null ? 0
                        : writeBuffer.getActualByteSize();
                if (flushBuffer != null) {
                    size += flushBuffer.getActualByteSize();
                }
            }

        } finally {
            writeBufferStructureLock.readLock().unlock();
        }
        return size;
    }

    public long getWBValidByteSize() {
        long size;
        writeBufferStructureLock.readLock().lock();
        try {
            synchronized (writeBufferLock) {
                size = writeBuffer == null ? 0 : writeBuffer.getValidByteSize();
                if (flushBuffer != null) {
                    size += flushBuffer.getValidByteSize();
                }
            }
        } finally {
            writeBufferStructureLock.readLock().unlock();
        }
        return size;
    }

    public void closeSSTableFiles() {
        this.ssTableListUpdateLock.writeLock().lock();
        try {
            for (SSTable ss: this.sstables) {
                ss.close();
            }
            this.sstables = null;
        } finally {
            this.ssTableListUpdateLock.writeLock().unlock();
        }
    }

    /**
     * Shut down this Tablet completely. You must call {@link #setToBeClosed()}
     * first before calling this method, otherwise an
     * {@link IllegalStateException} will be thrown. Once closed, this Tablet
     * can not be used again.
     */
    public void close() {
        if (!statusFlags.testAndSet(STATUS_TO_BE_CLOSED, STATUS_CLOSED, true)) {
            throw new IllegalStateException(
                    "STATUS_TO_BE_CLOSED is not set, call setToBeClosed() first");
        }
        removeTasks();
        LOG.info("Closing Tablet " + HexString.longToPaddedHex(tabletId));
        closeSSTableFiles();
        ts.sstableDataFileCache.releaseCache(new Path(
                OmapUtils.getSSTableFileDirPath(ts.tabletDir, tabletId)));
        writeBufferStructureLock.writeLock().lock();
        try {
            if (writeBuffer != null) {
                writeBuffer.close();
            }
            if (flushBuffer != null) {
                flushBuffer.close();
            }
        } finally {
            writeBufferStructureLock.writeLock().unlock();
        }
        LOG.info("Tablet closed " + HexString.longToPaddedHex(tabletId));
    }

    private final Collection<String> toBeClosedInhibitors = Arrays.asList(new String[] {
        STATUS_CLOSED,
    });

    private final Collection<String> toBeClosedBlockers = Arrays.asList(new String[] {
        STATUS_CHECKPOINTING, STATUS_COMPACTING_SS, STATUS_SPLITTING,
        STATUS_RECOVERING, STATUS_TO_BE_CLOSED
    });

    private volatile boolean abandoned = false;

    public boolean isAbandoned() {
        return abandoned;
    }

    public void setAbandoned() {
        LOG.info("Tablet " + HexString.longToPaddedHex(tabletId)
                + " set abandoned");
        this.abandoned = true;
    }

    /**
     * Mark the Tablet TO_BE_CLOSED and stop tasks. No further read/write can go
     * through. If the Tablet is already closed, will throw an
     * {@link IllegalStateException}
     */
    public void setToBeClosed() {
        LOG.info("Going to set TO_BE_CLOSED: " + this);
        try {
            if (!statusFlags.waitForFlagsAndSet(null, toBeClosedBlockers,
                    toBeClosedInhibitors, STATUS_TO_BE_CLOSED)) {
                throw new IllegalStateException("already closed");
            }
            removeTasks();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Clear the TO_BE_CLOSED flag and resume tasks. If TO_BE_CLOSED is not set,
     * will throw an {@link IllegalStateException}
     */
    public void clearToBeClosed() {
        LOG.info("Clearing TO_BE_CLOSED: " + this);
        if (!statusFlags.testAndSet(STATUS_TO_BE_CLOSED, STATUS_CLOSED, true)) {
            throw new IllegalStateException("STATUS_TO_BE_CLOSED is not set");
        }
        scheduleTasks();
    }

    private final Collection<String> compactInhibitors = Arrays.asList(new String[] {
        STATUS_CLOSED, STATUS_SPLITTING, STATUS_SPLIT_CHILD
    });

    private final Collection<String> compactBlockers = Arrays.asList(new String[] {
        STATUS_COMPACTING_SS
    });

    /**
     * Compact the SSTables for a tablet. Compacting will not start until there
     * is no other compacting process.
     */
    public int compactSSTables(boolean forceMajor) throws IOException {
        int entryCount = 0;
        LOG.info("Going to compact " + this);
        try {
            // if any of compactInhibitors is set, cancel compacting
            // immediately;
            // otherwise wait until that none of compactBlockers is set and then
            // set STATUS_COMPACTING_SS flag.
            if (!statusFlags.waitForFlagsAndSet(null, compactBlockers,
                    compactInhibitors, STATUS_COMPACTING_SS)) {
                LOG.warning("CompactSSTables canceled: " + this);
                return entryCount;
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        int sstableCountLow = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_SSTABLE_COUNT_LOW,
                OmapConfig.DEFAULT_SSTABLE_COUNT_LOW);

        int sstableCountHigh = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_SSTABLE_COUNT_HIGH,
                OmapConfig.DEFAULT_SSTABLE_COUNT_HIGH);
        boolean skip = false;
        try {
            LOG.info("Start compacting sstables "
                    + HexString.longToPaddedHex(this.tabletId));

            this.ssTableListUpdateLock.readLock().lock();
            ArrayList<SSTable> sstablesToCompact = new ArrayList<SSTable>(
                    this.sstables.size());
            long newSSId = -1;
            try {
                if (this.sstables.isEmpty()
                        || (this.sstables.size() == 1 && !this.sstables.get(0).isReference())) {
                    return 0;
                }
                boolean hasReference = false;
                for (SSTable ss: sstables) {
                    if (ss.isReference()) {
                        hasReference = true;
                        break;
                    }
                }
                if (hasReference) {
                    newSSId = 0;
                } else {
                    // check if we need a major compaction to remove deleted rows.
                    long totalKeys = 0;
                    long deletedKeys = 0;
                    for (SSTable ss: sstables) {
                        totalKeys += ss.numKeys();
                        deletedKeys += ss.deletedNumKeys();
                    }
                    double threshold = OmapConfig.getConfiguration().getDouble(
                            OmapConfig.NAME_MAJOR_COMPACTION_DELETED_ROW_THRESHOLD,
                            OmapConfig.DEFAULT_MAJOR_COMPCATION_DELETED_ROW_THRESHOLD);
                    if (totalKeys == deletedKeys
                            || (double) deletedKeys / (totalKeys - deletedKeys) > threshold) {
                        LOG.info("Tablet "
                                + HexString.longToPaddedHex(tabletId)
                                + " delete row rate reach the threshold "
                                + threshold + "(totalKeys " + totalKeys
                                + " deletedKeys " + deletedKeys
                                + "), force to do a major compaction");
                        forceMajor = true;
                    }

                    // find a spare ID for the new SSTable, it must be between the compacted
                    // SSTables to maintain the priority of written data.
                    for (int i = sstables.size() - 1; i > 0; i--) {
                        if (sstables.get(i).getFileId()
                                - sstables.get(i - 1).getFileId() > 1) {
                            newSSId = sstables.get(i - 1).getFileId() + 1;
                            break;
                        }
                    }
                }

                if (forceMajor || hasReference) {
                    if (newSSId == -1) {
                        LOG.warning("MajorCompaction, No SSTable ID available for "
                                + HexString.longToPaddedHex(tabletId)
                                + ", compaction canceled");
                        return 0;
                    }
                    // If tablet has referenced SSTable, we will do a major compaction
                    // to remove the unused data
                    sstablesToCompact.addAll(sstables);
                } else {
                    if (newSSId == -1) {
                        LOG.warning("MinorCompaction No SSTable ID gap found for "
                                + HexString.longToPaddedHex(tabletId)
                                + ", compaction canceled");
                        return 0;
                    }
                    // Select SSTables to be compacted
                    if (sstables.size() < sstableCountLow) {
                        LOG.info("No need to compact sstables for "
                                + HexString.longToPaddedHex(this.tabletId)
                                + ", Increase sstableCountLow");
                        return 0;
                    }

                    // Select sstables for compaction based on rule :
                    // We always compact the two latest sstables, then check
                    // for older ones.
                    // If the older one is less than twice the average size
                    // of the to-be-compacted sstables, we add it to the list
                    // and continue to next older one.
                    long totalSize = 0;
                    for (int i = sstables.size()
                            - MINOR_COMPACT_INITIAL_SET_SIZE; i < sstables.size(); i++) {
                        sstablesToCompact.add(sstables.get(i));
                        totalSize += sstables.get(i).actualDataSize();
                    }
                    for (int i = sstables.size()
                            - MINOR_COMPACT_INITIAL_SET_SIZE - 1; i >= 0; i--) {
                        double avgSize = totalSize
                                / (double) sstablesToCompact.size();
                        SSTable next = sstables.get(i);
                        if (next.actualDataSize() > avgSize * 2
                                && sstablesToCompact.get(0).getFileId() < newSSId) {
                            break;
                        }
                        totalSize += next.actualDataSize();
                        sstablesToCompact.add(0, next);
                    }
                    // We add more sstables to the list if necessary,
                    // so that after compaction, there is no more than
                    // sstableCountHigh sstables.
                    if (sstables.size() - sstablesToCompact.size() >= sstableCountHigh) {
                        while (sstables.size() - sstablesToCompact.size() >= (sstableCountLow + sstableCountHigh) / 2) {
                            sstablesToCompact.add(
                                    0,
                                    sstables.get(sstables.size()
                                            - sstablesToCompact.size() - 1));
                        }
                    }
                }
                // Only if we compact all stables, we can skip deleted
                // entries
                if (sstablesToCompact.size() == sstables.size()) {
                    skip = true;
                }
                LOG.info("Ready to compact "
                        + HexString.longToPaddedHex(tabletId) + ", SSTables: "
                        + sstables + ", compact: " + sstablesToCompact
                        + ", newSSId: " + newSSId);
            } finally {
                this.ssTableListUpdateLock.readLock().unlock();
            }
            // create write stream for output
            Path tempSSTablePath = new Path(Tablet.getSSTableFilePath(ts,
                    tabletId, SS_TEMP_COMPACTSS_FILE_ID));
            if (dfs.exists(tempSSTablePath)) {
                LOG.warning(tempSSTablePath
                        + " already exists, this is not normal unless OMap has recently crashed. I'm deleting it.");
                dfs.delete(tempSSTablePath);
            }
            int flags = DFSClient.OS_NOLOCALBACKUP;

            TableDesc tableDesc = getTableDesc();
            CompressType compressType = CompressType.toType(tableDesc.getProperty(
                    Table.Property.COMPRESS_NAME,
                    Table.Property.DEFAULT_COMPRESS));
            float bfFalseRate = Float.parseFloat(tableDesc.getProperty(
                    Table.Property.BLOOMFILTER_FALSERATE_NAME,
                    Table.Property.DEFAULT_BLOOMFILTER_FALSERATE));
            byte replication = Byte.parseByte(tableDesc.getProperty(
                    Table.Property.REPLICATION_NAME,
                    Table.Property.DEFAULT_REPLICATION));
            long totalNumKeys = 0;
            for (SSTable sstable: sstablesToCompact) {
                totalNumKeys += sstable.actualNumKeys();
                if (skip) {
                    // because deletedNumKeys is also recorded in numKeys, 
                    // so we should minus 2 * deletedNumKeys.
                    // eg. two sstable, the first has 100 record, the second has 
                    // 100 records that delete all the keys in the first, we will 
                    // get a numKeys of 200 and deletedNumKeys 100.
                    totalNumKeys -= 2 * sstable.actualDeletedNumKeys();
                }
            }
            if (totalNumKeys < 100) {
                totalNumKeys = 100;
            }
            // always generate bloomfilter
            SSTableWriter writer = new SSTableWriter(dfs, tempSSTablePath,
                    false, flags, totalNumKeys,
                    true && OmapConfig.getConfiguration().getBoolean(
                            OmapConfig.NAME_ENABLE_BLOOM_FILTER,
                            OmapConfig.DEFAULT_ENABLE_BLOOM_FILTER),
                    compressType, bfFalseRate, replication);
            boolean closeWriterFailed = false;
            try {
                // Do the compaction. do not use random read because we will 
                // read the whole file.
                KeyColumnDesc desc = tableDesc.getKey();
                KeyCell key = desc.borrowKeyCell();
                KeyCell prevKey = null;
                ByteArrayWritable r = new ByteArrayWritable();
                long prevPos = 0;
                CloseableIterator<ByteArrayWritable> iter = new TabletIter(
                        false, skip, null, sstablesToCompact, false);
                try {
                    while (iter.next(r)) {
                        // before IO operations for each key, check if the
                        // tablet is closed.
                        if (abandoned) {
                            throw new IOException("Tablet abandoned");
                        }
                        DataRow.keyCellFromBinaryRow(key, r.data(), 0, r.size());
                        if (prevKey == null) {
                            prevKey = desc.borrowKeyCell();
                        } else {
                            if (prevKey.compareTo(key) >= 0) {
                                String msg = "Got unordered key when compact "
                                        + HexString.longToPaddedHex(tabletId)
                                        + ", prev = " + prevKey + " cur = "
                                        + key;
                                AlertUtils.alert(ts.getHostPortName()
                                        + " compact failed", msg, false, true);
                                throw new RuntimeException(msg);
                            }
                        }
                        prevKey.copyFields(key);
                        if (keyRange.containsKey(key.getKey())) {
                            writer.write(
                                    new ByteArrayWritable(
                                            OmapUtils.convertPIWritableToBytes(key)),
                                    r);
                            long currentPos = writer.getSize();
                            if (!forceMajor
                                    && ts.compactSSThroughputController != null) {
                                try {
                                    ts.compactSSThroughputController.control(currentPos
                                            - prevPos);
                                } catch (InterruptedException e) {}
                            }
                            entryCount += 1;
                            prevPos = currentPos;
                            if (OmapConfig.traceDataFlow) {
                                LOG.info("CompactSS: writing " + key + " of "
                                        + HexString.longToPaddedHex(tabletId));
                            }
                        }
                    }
                } finally {
                    OmapUtils.safeClose(iter);
                    if (key != null) {
                        desc.returnKeyCell(key);
                    }
                    if (prevKey != null) {
                        desc.returnKeyCell(prevKey);
                    }
                    if (!forceMajor && ts.compactSSThroughputController != null) {
                        ts.compactSSThroughputController.finish();
                    }
                }
            } finally {
                try {
                    writer.close();
                } catch (IOException e) {
                    LOG.log(Level.WARNING, "close sstable writer failed", e);
                    closeWriterFailed = true;
                }
            }
            if (closeWriterFailed) {
                throw new IOException(
                        "Close sstable writer failed for when compact "
                                + HexString.longToPaddedHex(tabletId));
            }
            List<SSTable> deletedSS = sstablesToCompact;
            SSTable newSS = null;
            if (entryCount > 0) {
                // rename the temporary sstable's file to the new sstable's file name
                Path newSSTablePath = new Path(Tablet.getSSTableFilePath(ts,
                        tabletId, newSSId));
                dfs.delete(newSSTablePath);
                dfs.rename(tempSSTablePath, newSSTablePath);
                newSS = createSSTable(newSSId);
                LOG.info("New SSTable file " + newSSTablePath + " generated");
                this.ssTableListUpdateLock.writeLock().lock();
                try {
                    this.sstables.removeAll(deletedSS);
                    this.sstables.add(newSS);
                    Collections.sort(this.sstables, SSTable.COMPARATOR);
                    LOG.info("After compaction for "
                            + HexString.longToPaddedHex(tabletId)
                            + ", sstables=" + sstables.toString());
                } finally {
                    this.ssTableListUpdateLock.writeLock().unlock();
                }
            } else {
                LOG.info("No entry write to new sstable when compaction, delete it.");
                dfs.delete(tempSSTablePath);
                this.ssTableListUpdateLock.writeLock().lock();
                try {
                    this.sstables.removeAll(deletedSS);
                    Collections.sort(this.sstables, SSTable.COMPARATOR);
                    LOG.info("After compaction for "
                            + HexString.longToPaddedHex(tabletId)
                            + ", sstables=" + sstables.toString());
                } finally {
                    this.ssTableListUpdateLock.writeLock().unlock();
                }
            }
            TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.TS_PREPENSE_EXCEPTION_WHILE_COMPACTION);
            // delete files. 
            // XXX: this depends on file system late-delete support, i.e.,
            // if the deleted file is already open, it will stay readable/writable 
            // until it is closed and only then it is really deleted.
            // Modern Linux filesystems such as Ext3 support this feature.
            // Otherwise all iterator threads will fail.
            for (SSTable deleted: deletedSS) {
                deleted.closeAndDelete();
            }

            if (newSS != null) {
                LOG.info("Done compacting sstables "
                        + HexString.longToPaddedHex(this.tabletId)
                        + ", created: " + newSS.getODFSFile().getPath()
                        + ", keys written: " + entryCount);
            } else {
                LOG.info("Done compacting sstables "
                        + HexString.longToPaddedHex(this.tabletId)
                        + ", No new sstable created");
            }
        } finally {
            // just unlock the table, if there is a half written file, leave it there
            statusFlags.clearFlag(STATUS_COMPACTING_SS);
        }
        return entryCount;
    }

    private NativeRamWriteBuffer getWriteBuffer() throws IOException {
        if (writeBuffer == null) {
            writeBuffer = new NativeRamWriteBuffer(tabletId, ts.bufferPool,
                    getTableDesc().getKey());
        }
        return writeBuffer;
    }

    private void scheduleCheckpointTask() {
        try {
            if (toBeCheckpointGuard.compareAndSet(false, true)) {
                ts.tabletCheckpointTaskPool.execute(new CheckpointTask());
            }
        } catch (RejectedExecutionException e) {
            LOG.log(Level.WARNING, "schedule checkpoint task failed", e);
            toBeCheckpointGuard.set(false);
        }
    }

    private boolean needCheckpoint() {
        return writeBuffer.getActualByteSize() >= writeBufferCheckpointSizeLimit;
    }

    /**
     * Remove a row from the tablet
     * 
     * @param key
     *            the serialized KeyCell
     * @param recovering
     *            true if this deletion is of recovery process, and will not
     *            write the WALog
     */
    public void remove(ByteArrayWritable key, boolean recovering)
            throws IOException {
        statusFlags.readLock().lock();
        try {
            checkWritable(recovering);
            if (KeyCell.isInvalid(key.data(), 0)) {
                throw new UnInitializedDataCellException(
                        "Can not delete invalid key");
            } else if (KeyCell.isNull(key.data(), 0)) {
                throw new NullDataException("Can not delete null key");
            } else if (!KeyCell.isNormal(key.data(), 0)) {
                throw new IllegalStateException(
                        "Can not delete with unknown status");
            }
            ByteArrayWritable row = new ByteArrayWritable(
                    DataRow.createDeletedRow(key));
            writeBufferStructureLock.readLock().lock();
            try {
                synchronized (writeBufferLock) {
                    getWriteBuffer().put(row);
                    if (!recovering) {
                        updateLSN = ts.getInsertLogger().writeInsertLog(
                                tabletId, row);
                    }
                    if (needCheckpoint()) {
                        scheduleCheckpointTask();
                    }
                }
            } finally {
                writeBufferStructureLock.readLock().unlock();
            }

            lastWriteTime = System.currentTimeMillis();
            if (!recovering && !statusFlags.hasFlag(STATUS_SPLIT_CHILD)) {
                recordWriteLoad(1, calcLoad(row.getByteLength()));
            }
            // if the Tablet is splitting, also remove in the two children.
            if (statusFlags.hasFlag(STATUS_SPLITTING)) {
                synchronized (splitChildren) {
                    for (Tablet child: splitChildren) {
                        if (child != null) {
                            child.remove(key, recovering);
                        }
                    }
                }
            }
        } finally {
            statusFlags.readLock().unlock();
        }
    }

    private ByteArrayWritable findKeyWithoutCheckRange(ByteArrayWritable key,
            boolean recovering) throws IOException {
        ByteArrayWritable result = new ByteArrayWritable();
        boolean found = false;
        statusFlags.readLock().lock();
        try {
            // if this Tablet is a split child (splitting not done yet)
            // lookup the key from parent.
            if (statusFlags.hasFlag(STATUS_SPLIT_CHILD)) {
                return splitParent.findKeyWithoutCheckRange(key, recovering);
            }
            if (!recovering) {
                checkReadable();
            }
            writeBufferStructureLock.readLock().lock();
            try {
                synchronized (writeBufferLock) {
                    if (writeBuffer != null && writeBuffer.get(key, result)) {
                        found = true;
                    }
                    if (!found && flushBuffer != null) {
                        found = flushBuffer.get(key, result);
                    }
                }

            } finally {
                writeBufferStructureLock.readLock().unlock();
            }
            if (found) {
                if (DataRow.isDeleted(result)) {
                    // already deleted,no need to search further
                    if (!recovering) {
                        recordReadLoad(1, 1);
                    }
                    return null;
                }
                if (!recovering) {
                    recordReadLoad(1, calcLoad(result.getByteLength()));
                }
                return result;
            }
            this.ssTableListUpdateLock.readLock().lock();
            try {
                for (int i = sstables.size() - 1; i >= 0; i--) {
                    SSTable sst = sstables.get(i);
                    SSTableReader ssf = sst.borrowReader(true);
                    try {
                        if (ssf.get(key, result)) {
                            found = true;
                            if (DataRow.isDeleted(result)) {
                                if (!recovering) {
                                    recordReadLoad(1, 1);
                                }
                                return null;
                            }
                            break;
                        }
                    } finally {
                        sst.returnReader(ssf);
                    }
                }
            } finally {
                this.ssTableListUpdateLock.readLock().unlock();
            }
        } finally {
            statusFlags.readLock().unlock();
        }
        if (found) {
            if (!recovering) {
                recordReadLoad(1, calcLoad(result.getByteLength()));
            }
            return result;
        } else {
            if (!recovering) {
                recordReadLoad(1, 1);
            }
            return null;
        }
    }

    public ByteArrayWritable findKey(ByteArrayWritable key) throws IOException {
        return findKeyWithoutCheckRange(key, false);
    }

    private int calcLoad(int byteLength) {
        return byteLength <= 1024 ? 1 : (byteLength + 1023) / 1024;
    }

    private int calcLoad(List<ByteArrayWritable> rows) {
        int length = 0;
        for (ByteArrayWritable row: rows) {
            if (row != null) {
                length += row.getByteLength();
            }
        }
        return calcLoad(length);
    }

    private int calcLoad(ByteArrayWritable[] rows) {
        int length = 0;
        for (ByteArrayWritable row: rows) {
            if (row != null) {
                length += row.getByteLength();
            }
        }
        return calcLoad(length);
    }

    public ByteArrayWritable[] findKeys(KeyCell startKeyInclusive,
            KeyCell endKeyExclusive, int num) throws IOException {
        statusFlags.readLock().lock();
        try {
            if (statusFlags.hasFlag(STATUS_SPLIT_CHILD)) {
                return splitParent.findKeys(startKeyInclusive, endKeyExclusive,
                        num);
            }
            checkReadable();
            TableDesc tableDesc = getTableDesc();
            KeyCell keyCell = tableDesc.getKey().borrowKeyCell();
            CloseableIterator<ByteArrayWritable> iter = new TabletIter(true,
                    true, startKeyInclusive, true);
            try {
                ArrayList<ByteArrayWritable> result = new ArrayList<ByteArrayWritable>(
                        num);
                int total = 0;
                while (total < num) {
                    ByteArrayWritable row = new ByteArrayWritable();
                    if (iter.next(row)) {
                        if (endKeyExclusive != null) {
                            DataRow.keyCellFromBinaryRow(keyCell, row.data());
                            if (keyCell.compareTo(endKeyExclusive) >= 0) {
                                break;
                            }
                        }
                        result.add(row);
                        total++;
                    } else {
                        break;
                    }
                }
                recordReadLoad(total, calcLoad(result));
                return result.toArray(new ByteArrayWritable[0]);
            } finally {
                OmapUtils.safeClose(iter);
                tableDesc.getKey().returnKeyCell(keyCell);
            }
        } finally {
            statusFlags.readLock().unlock();
        }
    }

    public ByteArrayWritable[] findKeys(ByteArrayWritable[] keys)
            throws IOException {
        statusFlags.readLock().lock();
        try {
            if (statusFlags.hasFlag(STATUS_SPLIT_CHILD)) {
                return splitParent.findKeys(keys);
            }
            checkReadable();
            ByteArrayWritable[] ret = new ByteArrayWritable[keys.length];
            ssTableListUpdateLock.readLock().lock();
            writeBufferStructureLock.readLock().lock();
            try {
                SSTableReader[] readers = new SSTableReader[sstables.size()];
                try {
                    for (int i = 0; i < keys.length; i++) {
                        ByteArrayWritable key = keys[i];
                        ByteArrayWritable row = new ByteArrayWritable();
                        boolean found = false;
                        synchronized (writeBufferLock) {
                            if (writeBuffer != null) {
                                found = writeBuffer.get(key, row);
                            }
                            if (!found && flushBuffer != null) {
                                found = flushBuffer.get(key, row);
                            }
                        }

                        if (!found) {
                            for (int j = readers.length - 1; j >= 0; j--) {
                                if (readers[j] == null) {
                                    readers[j] = sstables.get(j).borrowReader(
                                            true);
                                }
                                if (readers[j].get(key, row)) {
                                    found = true;
                                    break;
                                }
                            }
                        }
                        if (found && !DataRow.isDeleted(row)) {
                            ret[i] = row;
                        }
                    }
                    recordReadLoad(ret.length, calcLoad(ret));
                } finally {
                    for (int i = 0; i < readers.length; i++) {
                        if (readers[i] != null) {
                            sstables.get(i).returnReader(readers[i]);
                        }
                    }
                }
            } finally {
                writeBufferStructureLock.readLock().unlock();
                ssTableListUpdateLock.readLock().unlock();
            }

            return ret;
        } finally {
            statusFlags.readLock().unlock();
        }
    }

    /**
     * Insert a serialized DataRow
     * 
     * @param row
     *            the serialized DataRow
     * @param recovering
     *            true if this insertion is of the recovery process, and will
     *            not write WALog
     * @throws IOException
     */
    public void insert(ByteArrayWritable row, boolean recovering)
            throws IOException {
        statusFlags.readLock().lock();
        try {
            checkWritable(recovering);
            TableDesc tableDesc = getTableDesc();
            DataRow dataRow = tableDesc.borrowDataRow();
            OmapUtils.convertBytesToPIWritable(row.data(), 0, row.size(),
                    dataRow);
            KeyCell keyCell = dataRow.getKeyCell();
            if (keyCell.getStatus() == DataCell.STATUS_INVALID) {
                throw new UnInitializedDataCellException("Can not insert "
                        + dataRow + " with invalid key cell");
            } else if (keyCell.getStatus() == DataCell.STATUS_NULL) {
                throw new NullDataException("Can not insert " + dataRow
                        + " with null key cell");
            } else if (keyCell.getStatus() != DataCell.STATUS_NORMAL) {
                throw new IllegalStateException("Can not insert " + dataRow
                        + " with unknown status");
            }
            ByteArrayWritable toPutRow;
            if (dataRow.isDeleted() || !dataRow.hasInvalidCell()) {
                // just insert
                toPutRow = row;
            } else { // hasInvalidCell
                ByteArrayWritable originalRow = findKeyWithoutCheckRange(
                        new ByteArrayWritable(
                                OmapUtils.convertPIWritableToBytes(keyCell)),
                        recovering);
                // not exists, just insert
                if (originalRow == null || DataRow.isDeleted(originalRow)) {
                    toPutRow = row;
                } else {
                    DataRow originalDataRow = tableDesc.borrowDataRow();
                    OmapUtils.convertBytesToPIWritable(originalRow.data(), 0,
                            originalRow.size(), originalDataRow);
                    originalDataRow.overWriteValid(dataRow);
                    toPutRow = new ByteArrayWritable(
                            OmapUtils.convertPIWritableToBytes(originalDataRow));
                    tableDesc.returnDataRow(originalDataRow);
                }
            }
            tableDesc.returnDataRow(dataRow);
            writeBufferStructureLock.readLock().lock();
            try {
                synchronized (writeBufferLock) {
                    getWriteBuffer().put(toPutRow);
                    if (!recovering) {
                        updateLSN = ts.getInsertLogger().writeInsertLog(
                                tabletId, row);
                    }
                    if (needCheckpoint()) {
                        scheduleCheckpointTask();
                    }
                }
            } finally {
                writeBufferStructureLock.readLock().unlock();
            }

            lastWriteTime = System.currentTimeMillis();
            if (!recovering && !statusFlags.hasFlag(STATUS_SPLIT_CHILD)) {
                recordWriteLoad(1, calcLoad(row.getByteLength()));
            }
            // if this tablet is splitting, also write the row
            // to the two children.
            if (statusFlags.hasFlag(STATUS_SPLITTING)) {
                synchronized (splitChildren) {
                    for (Tablet child: splitChildren) {
                        if (child != null) {
                            child.insert(row, recovering);
                        }
                    }
                }
            }
        } finally {
            statusFlags.readLock().unlock();
        }
    }

    private final Collection<String> checkpointBlockers = Arrays.asList(new String[] {
        STATUS_CHECKPOINTING
    });

    private final Collection<String> checkpointInhibitors = Arrays.asList(new String[] {
        STATUS_CLOSED
    });

    /**
     * Checkpoint the Tablet. Flush the write buffer and write the content to
     * SSTableFile. If it is checkpointing is already on the way, nothing will
     * be done.
     * 
     * @param ts
     * @return
     * @throws IOException
     */
    public void checkpoint() throws IOException {
        LOG.info("Going to checkpoint " + this);
        try {
            if (!statusFlags.waitForFlagsAndSet(null, checkpointBlockers,
                    checkpointInhibitors, STATUS_CHECKPOINTING)) {
                LOG.warning("Checkpoint canceled for "
                        + HexString.longToPaddedHex(tabletId));
                return;
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            LOG.info("Start checkpointing "
                    + HexString.longToPaddedHex(this.tabletId));
            Path tempSSTablePath = new Path(Tablet.getSSTableFilePath(ts,
                    tabletId, SS_TEMP_CHECKPOINT_FILE_ID));
            if (dfs.exists(tempSSTablePath)) {
                LOG.warning(tempSSTablePath
                        + " already exists, this is not normal unless OMAP has recently crashed. I'm deleting it.");
                if (!dfs.delete(tempSSTablePath)) {
                    throw new IOException("can not clean " + tempSSTablePath
                            + " for write when checkpointing "
                            + HexString.longToPaddedHex(tabletId));
                }
            }

            // prepare To flush writebuffer
            long lastLSN;
            NativeRamWriteBuffer.WriteBufferIterator iter;
            writeBufferStructureLock.writeLock().lock();
            try {
                if (writeBuffer == null || writeBuffer.getNumKeys() == 0) {
                    LOG.info("write buffer is empty, nothing to checkpoint");
                    lastCheckpointTime = System.currentTimeMillis();
                    return;
                }
                if (flushBuffer != null) {
                    throw new IllegalStateException(
                            "flushBuffer is not null when trying to checkpoint "
                                    + HexString.longToPaddedHex(tabletId));
                }
                flushBuffer = writeBuffer;
                writeBuffer = null;
                // Get Iterator under lock protection
                iter = flushBuffer.iterator();
                lastLSN = this.updateLSN;
            } finally {
                writeBufferStructureLock.writeLock().unlock();
            }
            int numKeysToFlush = flushBuffer.getNumKeys();
            LOG.info("checkpoint Tablet: "
                    + HexString.longToPaddedHex(this.tabletId) + ", numKeys="
                    + numKeysToFlush);
            // flush the writebuffer to SSTableFile
            SSTableWriter writer = null;

            int retryCount = 0;
            while (true) {
                try {
                    if (retryCount > 100) {
                        LOG.severe("Checkpoint failed for " + retryCount
                                + " times, I have to kill myself");
                        ts.shutdown(false);
                    }
                    if (retryCount > 0) {
                        LOG.info("Retrying to flush write buffer, retry="
                                + retryCount);
                    }
                    TableDesc tableDesc = getTableDesc();
                    CompressType compressType = CompressType.toType(tableDesc.getProperty(
                            Table.Property.COMPRESS_NAME,
                            Table.Property.DEFAULT_COMPRESS));
                    float bfFalseRate = Float.parseFloat(tableDesc.getProperty(
                            Table.Property.BLOOMFILTER_FALSERATE_NAME,
                            Table.Property.DEFAULT_BLOOMFILTER_FALSERATE));
                    byte replication = Byte.parseByte(tableDesc.getProperty(
                            Table.Property.REPLICATION_NAME,
                            Table.Property.DEFAULT_REPLICATION));
                    writer = new SSTableWriter(dfs, tempSSTablePath, false,
                            DFSClient.OS_NOLOCALBACKUP, numKeysToFlush,
                            true && OmapConfig.getConfiguration().getBoolean(
                                    OmapConfig.NAME_ENABLE_BLOOM_FILTER,
                                    OmapConfig.DEFAULT_ENABLE_BLOOM_FILTER),
                            compressType, bfFalseRate, replication);
                    int writeCount = 0;
                    ByteArrayWritable key = new ByteArrayWritable();
                    ByteArrayWritable row = new ByteArrayWritable();
                    KeyCell prevKeyCell = null;
                    KeyCell keyCell = flushBuffer.kcd.borrowKeyCell();
                    DirectByteArrayOutputStream bos = new DirectByteArrayOutputStream();
                    CDataOutputStream dos = new CDataOutputStream(bos);
                    while (iter.next(row)) {
                        if (abandoned) {
                            throw new RuntimeException("Tablet "
                                    + HexString.longToPaddedHex(tabletId)
                                    + " closed when checkpointing");
                        }
                        DataRow.keyCellFromBinaryRow(keyCell, row.data(), 0,
                                row.size());
                        if (prevKeyCell == null) {
                            prevKeyCell = flushBuffer.kcd.borrowKeyCell();
                        } else {
                            if (prevKeyCell.compareTo(keyCell) >= 0) {
                                String msg = "Got unordered key when checkpoint "
                                        + HexString.longToPaddedHex(tabletId)
                                        + ", prev = "
                                        + prevKeyCell
                                        + " cur = "
                                        + keyCell;
                                AlertUtils.alert(ts.getHostPortName()
                                        + " checkpoint failed", msg, false,
                                        true);
                                throw new RuntimeException(msg);
                            }
                        }
                        prevKeyCell.copyFields(keyCell);
                        bos.reset();
                        keyCell.writePIFields(dos);
                        key.setBuffer(bos.getBuffer(), bos.getBufferSize());
                        writer.write(key, row);
                        writeCount++;
                    }
                    TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.TS_PREPENSE_EXCEPTION_WHILE_CHECKPOINT);
                    writer.close();
                    OmapUtils.safeClose(iter);
                    if (prevKeyCell != null) {
                        flushBuffer.kcd.returnKeyCell(prevKeyCell);
                    }
                    flushBuffer.kcd.returnKeyCell(keyCell);
                    LOG.info("checkponting "
                            + HexString.longToPaddedHex(tabletId)
                            + ": total number of keys written: " + writeCount);
                    if (writeCount != numKeysToFlush) {
                        LOG.severe("Bug: " + writeCount
                                + " keys flushed, while " + numKeysToFlush
                                + " exists");
                    }
                    break;
                } catch (Throwable ex) {
                    LOG.log(Level.SEVERE, HexString.longToPaddedHex(tabletId)
                            + " checkpoint failed, I will have to try again",
                            ex);
                    OmapUtils.safeClose(writer);
                    try {
                        if (dfs.exists(tempSSTablePath)) {
                            dfs.delete(tempSSTablePath);
                        }
                    } catch (Exception e) {
                        LOG.log(Level.SEVERE,
                                "Tablet "
                                        + HexString.longToPaddedHex(tabletId)
                                        + " failed to delete unfinished checkpoint SSTables",
                                e);
                    }
                    if (abandoned) {
                        throw new RuntimeException("Tablet "
                                + HexString.longToPaddedHex(tabletId)
                                + " closed when checkpointing", ex);
                    }
                    iter.reset();
                    WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                            retryCount, rand));
                    retryCount++;
                }
            }

            FileInfo[] sstablesOnFs = dfs.listFiles(
                    new Path(OmapUtils.getSSTableFileDirPath(ts.tabletDir,
                            tabletId)), new PathFilter() {

                        @Override
                        public boolean accept(Path path) {
                            String name = path.getName();
                            return name.startsWith(SS_PREFIX)
                                    || name.startsWith(TOP_REF_PREFIX)
                                    || name.startsWith(BOTTOM_REF_PREFIX);
                        }
                    });
            long maxSSTableId = -1;
            for (FileInfo info: sstablesOnFs) {
                long sstableId = getSSTableFileId(info.getPath().getName());
                if (sstableId > maxSSTableId) {
                    maxSSTableId = sstableId;
                }
            }
            this.ssTableListUpdateLock.readLock().lock();
            try {
                if (!sstables.isEmpty()) {
                    maxSSTableId = Math.max(maxSSTableId,
                            sstables.get(sstables.size() - 1).getFileId());
                }
            } finally {
                this.ssTableListUpdateLock.readLock().unlock();
            }
            long newid = maxSSTableId < 0 ? SS_CHECKPOINT_INITIAL_FILE_ID
                    : maxSSTableId + SS_ID_INCREASE_STEP;
            // Only after the new SS has been successfully written, can we
            // rename it to the new name. So that partially written SS will
            // not be visible to the Tablet after the TS restarts.
            Path newSSTablePath = new Path(getSSTableFilePath(ts, tabletId,
                    newid));
            dfs.rename(tempSSTablePath, newSSTablePath);
            SSTable newss = createSSTable(newid);
            int sstableSize;
            this.ssTableListUpdateLock.writeLock().lock();
            try {
                // add new sstable
                // this has to be inside the writebuf lock since
                // we need a consistent view in find..
                sstables.add(newss);
                sstableSize = sstables.size();
            } finally {
                this.ssTableListUpdateLock.writeLock().unlock();
            }
            // Only after the new SSTable file becomes readable, can we
            // invoke close the flush buffer
            this.writeBufferStructureLock.writeLock().lock();
            try {
                flushBuffer.close();
                flushBuffer = null;
            } finally {
                this.writeBufferStructureLock.writeLock().unlock();
            }

            // write checkpoint record after checkpoint so it won't get lost
            // if crash here
            if (ts.getInsertLogger() != null) {
                ts.getInsertLogger().checkPoint(tabletId, lastLSN);
            }
            LOG.info("Done checkpointing "
                    + HexString.longToPaddedHex(this.tabletId) + ", sstables="
                    + sstableSize + ", lsn=" + lastLSN);
            lastCheckpointTime = System.currentTimeMillis();
        } finally {
            statusFlags.clearFlag(STATUS_CHECKPOINTING);
        }
    }

    public static class SplitResult {
        public final Tablet oldTablet;

        public final Tablet newTablet1;

        public final Tablet newTablet2;

        public final KeyCell middleKey;

        public SplitResult(Tablet oldTablet, Tablet newTablet1,
                Tablet newTablet2, KeyCell middleKey) {
            this.oldTablet = oldTablet;
            this.newTablet1 = newTablet1;
            this.newTablet2 = newTablet2;
            this.middleKey = middleKey;
        }

        @Override
        public String toString() {
            return "[SplitResult " + oldTablet + "->(" + newTablet1 + ","
                    + newTablet2 + ") " + " middle=" + middleKey + "]";
        }
    }

    private final Collection<String> splitInhibitors = Arrays.asList(new String[] {
        STATUS_CLOSED, STATUS_TO_BE_CLOSED, STATUS_SPLITTING,
        STATUS_SPLIT_CHILD, STATUS_RECOVERING
    });

    private final Collection<String> splitCheckInhibitors = Arrays.asList(new String[] {
        STATUS_CLOSED, STATUS_TO_BE_CLOSED, STATUS_SPLITTING,
        STATUS_SPLIT_CHILD, STATUS_SPLIT_REQUEST_PENDING, STATUS_RECOVERING
    });

    private final Collection<String> splitBlockers = Arrays.asList(new String[] {
        STATUS_COMPACTING_SS, STATUS_CHECKPOINTING
    });

    public static String getSSTableFilePath(OmapTs ts, long tabletId,
            long fileId) {
        return OmapUtils.getSSTableFileDirPath(ts.tabletDir, tabletId) + "/"
                + Tablet.SS_PREFIX + fileId;
    }

    public static String getTopREFTableFilePath(OmapTs ts, long tabletId,
            long fileId) {
        return OmapUtils.getSSTableFileDirPath(ts.tabletDir, tabletId) + "/"
                + Tablet.TOP_REF_PREFIX + fileId;
    }

    public static String getBottomREFTableFilePath(OmapTs ts, long tabletId,
            long fileId) {
        return OmapUtils.getSSTableFileDirPath(ts.tabletDir, tabletId) + "/"
                + Tablet.BOTTOM_REF_PREFIX + fileId;
    }

    private Tablet splitParent = null;

    private final Tablet[] splitChildren = new Tablet[2];

    /**
     * <p>
     * Split the Tablet. If split is successful, mark it as TO_BE_CLOSED and
     * stop tasks.
     * </p>
     * <p>
     * At the beginning of split, SPLITTING will be set, and 2 children Tablets
     * will be created and be set to SPLIT_CHILD. Then create the reference
     * files
     * </p>
     * <p>
     * To allow read/write even during splitting, inserts go to this Tablet and
     * both its children. And lookups, including the lookup for original Rows
     * are done in this Tablet.
     * </p>
     * <p>
     * During split, the parent and children Tablets can still do checkpoints,
     * but compactSSTables is disabled. The children Tablets are not visible to
     * OmapTs, but can be found in the SplitResult when split is done.
     * </p>
     * 
     * @param newid1
     * @param newid2
     * @return
     * @throws IOException
     */
    public SplitResult split(long newid1, long newid2) throws IOException {
        long[] newIds = new long[] {
            newid1, newid2
        };
        try {
            LOG.info("Going to spliting tablet: " + this);

            KeyRange[] newkr = new KeyRange[2];
            try {
                if (!statusFlags.waitForFlagsAndSet(null, splitBlockers,
                        splitInhibitors, STATUS_SPLITTING)) {
                    LOG.warning("Split canceled: " + this);
                    return null;
                }
            } catch (InterruptedException e) {
                throw new IOException(e);
            } finally {
                statusFlags.clearFlag(STATUS_SPLIT_REQUEST_PENDING);
            }
            // create two child tablets
            for (int i = 0; i < 2; i++) {
                // Create children tablets.
                // Set the KeyRanges of the child tablets to that of the parent,
                // because during split, Rows inserted to the parent will also
                // be inserted into the child tablets.
                newkr[i] = new KeyRange(keyRange.getKey1(), keyRange.getKey2(),
                        keyRange.getTsDesc(), newIds[i]);
            }

            synchronized (splitChildren) {
                for (int i = 0; i < 2; i++) {
                    splitChildren[i] = new Tablet(newkr[i], ts, false, this);
                    splitChildren[i].splitParent = this;
                    splitChildren[i].scheduleTasks();
                }
            }
            LOG.info("Beginning split of "
                    + HexString.longToPaddedHex(tabletId)
                    + ": generated new tablets: " + splitChildren[0] + ", "
                    + splitChildren[1]);

            // checkpoint before splitting SSTables to flush data inserted
            // before splitting to SSTables.
            // Rows inserted after this checkpoint will be written to the
            // parents and both the children to prevent data loss.
            checkpoint();

            long ssNumKeys = getSSTotalNumKeys();
            LOG.info("Split Tablet " + HexString.longToPaddedHex(tabletId)
                    + ": ssNumKeys= " + ssNumKeys);
            TableDesc tableDesc = getTableDesc();
            KeyColumnDesc kcd = tableDesc.getKey();
            // get approximated middle key from current sstables
            // which might change before creating references.
            // does not matter, it is just an approximation.
            KeyCell middleKey = kcd.borrowKeyCell();
            if (!getSplitMiddleKey(middleKey)) {
                kcd.returnKeyCell(middleKey);
                // throw exception because we need to do some revert jobs
                throw new RuntimeException("middle key is null");
            }

            ssTableListUpdateLock.readLock().lock();
            List<SSTable> sstables = new ArrayList<SSTable>();
            try {
                // make a copy of current sstables in case checkpoints during
                // split that change
                // sstables
                sstables.addAll(this.sstables);
            } finally {
                ssTableListUpdateLock.readLock().unlock();
            }

            IWritableComparable mk = middleKey.getKey();
            // create top half and bottom half references for each sstable
            int childSSTableId = 1;
            KeyCell firstKey = kcd.borrowKeyCell();
            KeyCell lastKey = kcd.borrowKeyCell();
            for (SSTable sstable: sstables) {
                // if first key is already greater than or equal to middleKey,
                // then top ref is not needed
                sstable.getFirstKey(firstKey);
                if (firstKey.compareTo(middleKey) < 0) {
                    // link data from parent tablet to children tablet 1, named
                    // REF_TOP_id
                    dfs.link(sstable.getODFSFile(), new Path(
                            getTopREFTableFilePath(ts, newid1, childSSTableId)));
                    // create Reference sstable and add into children
                    SSTable ssfile1 = new SSTable(ts, newid1, childSSTableId,
                            SSType.TOP_REF, mk);
                    splitChildren[0].sstables.add(ssfile1);
                }

                // if last index key < middleKey, then we should check the
                // real last key, if lastKey < middleKey, bottom ref is not
                // needed
                sstable.getLastIndexKey(lastKey);
                boolean needBottomRef = lastKey.compareTo(middleKey) >= 0;
                if (!needBottomRef) {
                    sstable.getLastKey(lastKey);
                    needBottomRef = lastKey.compareTo(middleKey) >= 0;
                }

                if (needBottomRef) {
                    // link data from parent tablet to children tablet 2, named
                    // REF_BOTTOM_id
                    dfs.link(
                            sstable.getODFSFile(),
                            new Path(getBottomREFTableFilePath(ts, newid2,
                                    childSSTableId)));
                    // create Reference sstable and add into children
                    SSTable ssfile2 = new SSTable(ts, newid2, childSSTableId,
                            SSType.BOTTOM_REF, mk);
                    splitChildren[1].sstables.add(ssfile2);
                }
                childSSTableId += SS_ID_INCREASE_STEP;
            }

            newkr[0] = new KeyRange(keyRange.getKey1(), middleKey.getKey(),
                    keyRange.getTsDesc(), newid1);
            newkr[1] = new KeyRange(middleKey.getKey(), keyRange.getKey2(),
                    keyRange.getTsDesc(), newid2);
            // set the TO_BE_CLOSED flag before clearing the SPLITTING flag
            // to prevent further read/writes.
            statusFlags.setFlag(STATUS_TO_BE_CLOSED);
            setAbandoned();
            // update key ranges of children, and clear flags
            for (int i = 0; i < 2; i++) {
                splitChildren[i].statusFlags.clearFlag(STATUS_SPLIT_CHILD);
                splitChildren[i].splitParent = null;
                splitChildren[i].keyRange = newkr[i];
            }
            removeTasks();
            return new SplitResult(this, splitChildren[0], splitChildren[1],
                    middleKey);
        } catch (Exception ex) {
            LOG.log(Level.WARNING,
                    "Split encountered exception, reverting changes", ex);

            // if we have initialized new tablets, delete them
            for (int i = 0; i < 2; i++) {
                if (splitChildren[i] != null) {
                    LOG.info("Revert: closing new tablet" + i + ": "
                            + splitChildren[i]);
                    try {
                        splitChildren[i].setAbandoned();
                        splitChildren[i].setToBeClosed();
                        splitChildren[i].close();
                        splitChildren[i] = null;
                    } catch (Exception e) {
                        LOG.log(Level.WARNING, "Failed to close new tablet "
                                + splitChildren[i], e);
                    }
                }
            }
            if (ex instanceof IOException) {
                throw (IOException) ex;
            }
            if (RuntimeException.class.isAssignableFrom(ex.getClass())) {
                throw (RuntimeException) ex;
            }
            throw new RuntimeException(ex);
        } finally {
            statusFlags.clearFlag(STATUS_SPLITTING);
        }
    }

    public CloseableIterator<ByteArrayWritable> iterator(KeyCell startKey,
            boolean useRandomRead) throws IOException {
        return new TabletIter(true, true, startKey, useRandomRead);
    }

    public CloseableIterator<ByteArrayWritable> iterator(boolean useRandomRead)
            throws IOException {
        return new TabletIter(true, true, useRandomRead);
    }

    public long getSchemaId() {
        return OmapUtils.tid2sid(tabletId);
    }

    public long getTabletId() {
        return tabletId;
    }

    /**
     * Iterate through tablet.
     */
    private class TabletIter implements CloseableIterator<ByteArrayWritable> {

        private final boolean skipDeleted;

        private final boolean includeWriteBuffer;

        private CloseableIterator<ByteArrayWritable> mergingIter;

        public TabletIter(boolean includeWriteBuffer, boolean skipDeleted,
                boolean useRandomRead) throws IOException {
            this(includeWriteBuffer, skipDeleted, null, useRandomRead);
        }

        public TabletIter(boolean includeWriteBuffer, boolean skipDeleted,
                KeyCell startKey, boolean useRandomRead) throws IOException {
            if (statusFlags.hasFlag(STATUS_CLOSED)) {
                throw new TabletNotFoundException(tabletId);
            }
            this.includeWriteBuffer = includeWriteBuffer;
            this.skipDeleted = skipDeleted;
            ssTableListUpdateLock.readLock().lock();
            try {
                init(includeWriteBuffer, startKey, sstables, useRandomRead);
            } finally {
                ssTableListUpdateLock.readLock().unlock();
            }
        }

        public TabletIter(boolean includeWriteBuffer, boolean skipDeleted,
                KeyCell startKey, List<SSTable> sstables, boolean useRandomRead)
                throws IOException {
            if (statusFlags.hasFlag(STATUS_CLOSED)) {
                throw new TabletNotFoundException(tabletId);
            }
            this.includeWriteBuffer = includeWriteBuffer;
            this.skipDeleted = skipDeleted;
            init(includeWriteBuffer, startKey, sstables, useRandomRead);
        }

        @SuppressWarnings("unchecked")
        private void init(boolean includeWriteBuffer, KeyCell startKey,
                List<SSTable> sstables, boolean useRandomRead)
                throws IOException {
            List<CloseableIterator<ByteArrayWritable>> subIters = new ArrayList<CloseableIterator<ByteArrayWritable>>();
            if (includeWriteBuffer) {
                ByteArrayWritable binaryStartKey = startKey == null ? null
                        : new ByteArrayWritable(
                                OmapUtils.convertPIWritableToBytes(startKey));
                boolean succ = false;
                writeBufferStructureLock.readLock().lock();
                try {
                    synchronized (writeBufferLock) {
                        if (writeBuffer != null) {
                            subIters.add(writeBuffer.iterator(binaryStartKey));
                        }
                        if (flushBuffer != null) {
                            subIters.add(flushBuffer.iterator(binaryStartKey));
                        }
                    }
                    for (int i = 0; i < sstables.size(); i++) {
                        subIters.add(sstables.get(sstables.size() - i - 1).iterator(
                                startKey, useRandomRead));
                    }
                    succ = true;
                } finally {
                    if (!succ) {
                        writeBufferStructureLock.readLock().unlock();
                        for (CloseableIterator<ByteArrayWritable> iter: subIters) {
                            OmapUtils.safeClose(iter);
                        }
                    }
                }
            } else {
                boolean succ = false;
                try {
                    for (int i = 0; i < sstables.size(); i++) {
                        subIters.add(sstables.get(sstables.size() - i - 1).iterator(
                                startKey, useRandomRead));
                    }
                    succ = true;
                } finally {
                    if (!succ) {
                        for (CloseableIterator<ByteArrayWritable> iter: subIters) {
                            OmapUtils.safeClose(iter);
                        }
                    }
                }
            }
            TableDesc tableDesc = getTableDesc();
            mergingIter = new MergingIterator<ByteArrayWritable>(
                    new DataRowBinaryComparator(tableDesc.getKey()),
                    subIters.toArray(new CloseableIterator[0]));
            keyCell = tableDesc.getKey().borrowKeyCell();
        }

        private KeyCell keyCell;

        public void close() throws IOException {
            if (includeWriteBuffer) {
                writeBufferStructureLock.readLock().unlock();
            }
            OmapUtils.safeClose(mergingIter);
            if (keyCell != null) {
                getTableDesc().getKey().returnKeyCell(keyCell);
            }
        }

        @Override
        public boolean next(ByteArrayWritable value) throws IOException {
            while (mergingIter.next(value)) {
                if (skipDeleted && DataRow.isDeleted(value)) {
                    continue;
                } else {
                    // skip keys that are out of the key range
                    DataRow.keyCellFromBinaryRow(keyCell, value.data(), 0,
                            value.size());
                    int cmp = keyRange.compareKey(keyCell.getKey());
                    if (cmp > 0) {
                        continue;
                    }
                    if (cmp < 0) {
                        return false;
                    }
                    return true;
                }
            }
            return false;
        }
    }

    public String toString() {
        return "[Tablet tabletId=" + HexString.longToPaddedHex(this.tabletId)
                + " flags=" + getStatusFlagsString() + "]";
    }

    public String getKeyRangeString() {
        return this.keyRange.toString();
    }

    public String getStatusFlagsString() {
        return statusFlags.toString();
    }

    private SSTable createSSTable(Path ssFile) throws IOException {
        return createSSTable(getSSFileId(ssFile.getName()));
    }

    /**
     * a newly created SSTable will load metadata immediately, so you can not
     * create a SSTable on a Path which is not exists yet.<br>
     * See {@link #checkpoint()}, you should rename the temp SSTable to the
     * actual SSTable before you create it.
     */
    private SSTable createSSTable(long fileId) throws IOException {
        return new SSTable(ts, tabletId, fileId);
    }

    private final LoadValue load = new LoadValue();

    // update load value
    public LoadValue getLoadValue() {
        load.numKeys = getNumKeys();
        load.dataSize = getDataSize();
        load.memory = getSSTotalIndexByteSize();
        long writeBufferSize;
        writeBufferStructureLock.readLock().lock();
        try {
            synchronized (writeBufferLock) {
                writeBufferSize = writeBuffer == null ? 0
                        : writeBuffer.getBufferSize();
                if (flushBuffer != null) {
                    writeBufferSize += flushBuffer.getBufferSize();
                }
            }
        } finally {
            writeBufferStructureLock.readLock().unlock();
        }
        load.writeBufferSize = writeBufferSize;
        load.readCount = readCount.get();
        load.writeCount = writeCount.get();
        load.readLoad = readLoad.get();
        load.writeLoad = writeLoad.get();
        load.bloomFilterSize = getSSTotalBloomFilterSize();
        return load;
    }

    /**
     * Check if a tablet is splitable.
     * 
     * @return true if splitable, false otherwise.
     */
    public boolean getSplitMiddleKey(KeyCell middleKey) {
        ssTableListUpdateLock.readLock().lock();
        try {
            if (sstables.size() <= 0) {
                LOG.warning(this + " doesn't have any SSTables, cannot split");
                return false;
            }
            for (SSTable sstable: sstables) {
                if (sstable.isReference()) {
                    LOG.warning(HexString.longToPaddedHex(tabletId)
                            + " has reference sstable " + sstable
                            + ", we need an major compaction before split");
                    forceMajor.set(true);
                    return false;
                }
            }

            SSTable maxsstable = sstables.get(0);
            long maxSize = maxsstable.dataSize();

            for (int i = 1; i < sstables.size(); i++) {
                SSTable sstable = sstables.get(i);
                long size = sstable.dataSize();
                if (size > maxSize) {
                    maxSize = size;
                    maxsstable = sstable;
                }
            }

            TableDesc tableDesc = getTableDesc();
            KeyColumnDesc kcd = tableDesc.getKey();
            // Get midkey of maxsstable, check with first and lastkey to make
            // sure it is splitable.
            KeyCell firstKey = kcd.borrowKeyCell();
            KeyCell lastKey = kcd.borrowKeyCell();
            maxsstable.getFirstKey(firstKey);
            maxsstable.getMiddleIndexKey(middleKey);
            maxsstable.getLastIndexKey(lastKey);
            LOG.info("MAX SSTALE : " + maxsstable + " firstKey= " + firstKey
                    + " lastKey= " + lastKey + " middleKey= " + middleKey);
            if (firstKey.compareTo(middleKey) == 0
                    || lastKey.compareTo(middleKey) == 0) {
                LOG.info("Cannot split because midkey is the same as first or last key");
                kcd.returnKeyCell(firstKey);
                kcd.returnKeyCell(lastKey);
                return false;
            }
            kcd.returnKeyCell(firstKey);
            kcd.returnKeyCell(lastKey);
            return true;
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Failed getSplitMiddleKey", e);
            return false;
        } finally {
            ssTableListUpdateLock.readLock().unlock();
        }
    }

    public TableDesc getTableDesc() throws IOException {
        return ts.getMetaCache().getMetadata(OmapUtils.tid2sid(tabletId)).getTableDesc();
    }
}
