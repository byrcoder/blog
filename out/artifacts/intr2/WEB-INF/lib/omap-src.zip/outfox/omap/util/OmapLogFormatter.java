package outfox.omap.util;

import java.util.Hashtable;
import java.util.logging.LogRecord;

import toolbox.misc.LogFormatter;

/** Prints just the date and the log message. */

public class OmapLogFormatter extends LogFormatter {
    static {
        install(new OmapLogFormatter());
    }
    private static boolean runDebugEventHandler = false;
    
    private static Hashtable<String, LogDebugEventHandler> debug_handlers 
        = new Hashtable<String, LogDebugEventHandler>();
    
    public static void enableDebugHandler() {
        runDebugEventHandler=true;
    }
    
    public static void disableDebugHandler() {
        runDebugEventHandler = false;
    }
    
    public static void registerDebugHandler(String msg, LogDebugEventHandler handler) {
        debug_handlers.put(msg, handler);
    }
    
    public static void removeDebugHandler(String msg) {
        debug_handlers.remove(msg);
    }

    /**
     * Format the given LogRecord.
     * 
     * @param record
     *            the log record to be formatted.
     * @return a formatted log record
     */
    public String format(LogRecord record) {
        String result = super.format(record);
        try {
            if (runDebugEventHandler) {
                LogDebugEventHandler handler = debug_handlers.get(record
                        .getMessage());
                if (handler != null) {
                    handler.handle(record.getMessage());
                }
            }
        } catch(Exception ex) {
            result = result + ex;
        }
        
        return result;
        
    }
}
