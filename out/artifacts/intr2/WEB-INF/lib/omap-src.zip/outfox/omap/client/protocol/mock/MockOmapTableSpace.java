/**
 * @(#)MockOmapTableSpace.java, 2009-4-29. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol.mock;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import odis.serialize.IWritableComparable;
import outfox.omap.client.protocol.AbstractTableSpace;
import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryCondition;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.query.OmapQueryCondition;
import outfox.omap.client.query.OmapQueryUtils;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapUtils;

/**
 * @author zhangduo
 */
public class MockOmapTableSpace extends AbstractTableSpace {

    private final String tableSpaceName;

    private final Map<String, MockOmapTable> tableMap = new HashMap<String, MockOmapTable>();

    private final ReadWriteLock lock = new ReentrantReadWriteLock();

    private final List<OpInterceptor> interceptors;

    public String getName() {
        return tableSpaceName;
    }

    public MockOmapTableSpace(String tableSpaceName,
            List<OpInterceptor> interceptors) {
        this.tableSpaceName = tableSpaceName;
        OmapUtils.validateTableName(this.tableSpaceName);
        this.interceptors = interceptors;
    }

    @Override
    public void close() {
        // nothing

    }

    @Override
    public Query createQuery(String queryName, QueryCondition[] conditions) {
        return new MockOmapQuery(
                queryName,
                OmapQueryUtils.convertQueryConditionArrayToOmapQueryConditionArray(conditions));
    }

    @Override
    public Query createQuery(String queryName, QueryCondition[] conditions,
            int offset) {
        return new MockOmapQuery(
                queryName,
                OmapQueryUtils.convertQueryConditionArrayToOmapQueryConditionArray(conditions),
                offset);
    }

    @Override
    public Query createQuery(String queryName, QueryCondition[] conditions,
            int offset, int limit) {
        return new MockOmapQuery(
                queryName,
                OmapQueryUtils.convertQueryConditionArrayToOmapQueryConditionArray(conditions),
                offset, limit);
    }

    @Override
    public QueryCondition createQueryCondition(String colName, QueryOperation op) {
        return new OmapQueryCondition(colName, op);
    }

    @Override
    public QueryCondition createQueryCondition(String colName,
            QueryOperation op, IWritableComparable para1) {
        return new OmapQueryCondition(colName, op, para1);
    }

    @Override
    public QueryCondition createQueryCondition(String colName,
            QueryOperation op, IWritableComparable para1,
            IWritableComparable para2) {
        return new OmapQueryCondition(colName, op, para1, para2);
    }

    @Override
    public Table createTable(String tableName, String[] colNames,
            String[] colTypes, Query[] queries) throws OmapException {
        lock.writeLock().lock();
        try {
            if (tableMap.containsKey(tableName)) {
                throw new OmapException("table already exists");
            }
            MockOmapTable table = new MockOmapTable(tableName, colNames,
                    colTypes, queries, interceptors);
            tableMap.put(tableName, table);
            return table;
        } finally {
            lock.writeLock().unlock();
        }
    }

    @Override
    public void deleteTable(String tableName) throws OmapException {
        lock.writeLock().lock();
        try {
            tableMap.remove(tableName);
        } finally {
            lock.writeLock().unlock();
        }

    }

    @Override
    public Metadata findTable(String tableName) throws OmapException {
        lock.readLock().lock();
        try {
            MockOmapTable table = tableMap.get(tableName);
            if (table != null) {
                return table.getMetadata();
            } else {
                return null;
            }
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public void importSnapshot(String tableName, String targetDir)
            throws OmapException {
        // TODO Auto-generated method stub

    }

    @Override
    public Metadata[] listTables() throws OmapException {
        lock.readLock().lock();
        try {
            Metadata[] metas = new Metadata[tableMap.size()];
            int i = 0;
            for (MockOmapTable table: tableMap.values()) {
                metas[i++] = table.getMetadata();
            }
            return metas;
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public Table openTable(String tableName) throws OmapException {
        return openTable(tableName, 0);
    }

    @Override
    public void snapshot(String tableName, String targetDir, boolean checkpoint)
            throws OmapException {
        // TODO Auto-generated method stub

    }

    @Override
    public void renameTable(String originName, String currName)
            throws OmapException {
        MockOmapTable mockOmapTable = tableMap.remove(originName);
        if (mockOmapTable == null) {
            throw new OmapException("Table " + originName + " is not existed.");
        }
        tableMap.put(currName, mockOmapTable);
    }

    @Override
    public Table openTable(String tableName, long timeout) throws OmapException {
        return tableMap.get(tableName);
    }
}
