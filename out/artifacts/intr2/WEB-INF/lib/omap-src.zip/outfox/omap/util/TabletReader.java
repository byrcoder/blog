/**
 * @(#)TabletReader.java, Jul 21, 2010. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.CDataInputStream;
import odis.io.FileSystem;
import odis.io.LzoCompression;
import odis.io.Path;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.IntWritable;
import outfox.omap.client.OmapMetadata;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyRange;
import outfox.omap.metadata.TableDesc;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.Tablet;
import toolbox.misc.LogFormatter;

/**
 * A utility that provides methods to read a Tablet's on-FS data without
 * starting an OMap service.
 * 
 * @author zhangkun
 */
public class TabletReader implements Closeable {
    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(TabletReader.class);

    private final Tablet tablet;

    private final TableDesc td;

    public TabletReader(FileSystem fs, String tabletsDir, KeyRange kr,
            TableDesc td) throws IOException {
        OmapTs ts = new OmapTs(fs, tabletsDir);
        ts.getMetaCache().addMetadata(new OmapMetadata(td));
        this.tablet = new Tablet(kr, ts, false, null);
        this.td = td;
    }

    public DataRow findKey(KeyCell key) throws IOException {
        ByteArrayWritable rowBytes = tablet.findKey(new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key)));
        if (rowBytes == null) {
            return null;
        }
        DataRow row = td.borrowDataRow();
        OmapUtils.convertBytesToPIWritable(rowBytes.data(), row);
        return row;
    }

    private class Iterator implements CloseableIterator<DataRow> {
        final CloseableIterator<ByteArrayWritable> innerIter;

        Iterator(KeyCell startKey) throws IOException {
            innerIter = tablet.iterator(startKey, true);
        }

        Iterator() throws IOException {
            innerIter = tablet.iterator(true);
        }

        @Override
        public boolean next(DataRow value) throws IOException {
            ByteArrayWritable rowBytes = new ByteArrayWritable();
            boolean hasNext = innerIter.next(rowBytes);
            if (!hasNext) {
                return false;
            }
            OmapUtils.convertBytesToPIWritable(rowBytes.data(), value);
            return true;
        }

        @Override
        public void close() throws IOException {
            innerIter.close();
        }
    }

    public CloseableIterator<DataRow> iterator(KeyCell startKey)
            throws IOException {
        return new Iterator(startKey);
    }

    public CloseableIterator<DataRow> iterator() throws IOException {
        return new Iterator();
    }

    public long getNumKeys() throws IOException {
        return tablet.getNumKeys();
    }

    public void close() {
        if (tablet != null) {
            tablet.closeSSTableFiles();
        }
    }

    public static void main(String[] args) throws Exception {
        SequenceFile.Reader reader = new SequenceFile.Reader(
                FileSystem.getNamed("local"), new Path(
                        "D:/armani-tablet/000005f1/000000/dc/SS_42/data"));
        IntWritable key = new IntWritable();
        ByteArrayWritable baw = new ByteArrayWritable();
        ByteArrayWritable value = new ByteArrayWritable();
        PrintWriter pw = new PrintWriter("D:/ak");
        int prevKey = Integer.MIN_VALUE;
        KeyCell kc = new KeyCell(new IntWritable());
        while (reader.next(key, value)) {
            byte[] buf = new byte[key.get()];
            LzoCompression.uncompress(value.data(), 0, value.size(), buf);
            CDataInputStream dis = new CDataInputStream(
                    new ByteArrayInputStream(buf));
            while (true) {
                try {
                    baw.readFields(dis);
                } catch (EOFException e) {
                    break;
                }
                pw.println(baw);
                OmapUtils.convertBytesToPIWritable(baw.data(), 0, baw.size(),
                        kc);
                int k = kc.getInt();
                if (k <= prevKey) {
                    pw.close();
                    throw new RuntimeException(k + "is less than " + prevKey);
                }
                prevKey = k;
                baw.readFields(dis);
            }
        }
        reader.close();
        pw.close();
        //        ClientMasterProtocol p = RPC.getProxy(ClientMasterProtocol.class,
        //                new InetSocketAddress("nb109", 6190));
        //        OmapMetadata metadata = p.getMetadata(0x5f1L);
        //        RPC.close(p);
        //        TabletReader reader = new TabletReader(FileSystem.getNamed("local"),
        //                "D:/armani-tablet", new KeyRange(new IntWritable(1947209994),
        //                        new IntWritable(1980306753), TsDesc.getDummyTsDesc(),
        //                        0x000005f1000000dcL), metadata.getTableDesc());
        //        CloseableIterator<DataRow> iter = reader.iterator();
        //        DataRow dr = metadata.getTableDesc().createDataRow();
        //        while (iter.next(dr)) {
        //
        //        }
    }
}
