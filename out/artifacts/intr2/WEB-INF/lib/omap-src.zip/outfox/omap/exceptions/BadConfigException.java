package outfox.omap.exceptions;

public class BadConfigException extends RuntimeException {

    private static final long serialVersionUID = 3902825127408831025L;

    public BadConfigException(String configName, String entryName) {
        super("cannot find " + entryName + " in config " + configName);
    }

    public BadConfigException(String msg) {
        super(msg);
    }

}
