/**
 * @(#)NativeRamBloomFilter.java, 2012-5-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import odis.util.unsafe.NativeRamBuffer;
import outfox.omap.exceptions.LogicException;
import toolbox.misc.LogFormatter;
import toolbox.misc.bloom.HashFunction;

/**
 * @author zhangduo
 */
class NativeRamBloomFilter {

    private static final Logger LOG = LogFormatter.getLogger(NativeRamBloomFilter.class);

    private final HashFunction hash;

    private final NativeRamBitSet bitSet;

    private final SSTable sstable;

    private final BloomFilterPool pool;

    NativeRamBloomFilter(NativeRamBuffer[] buffers, int bufferSize,
            byte[] bits, int bitSetSize, HashFunction hash, SSTable sstable,
            BloomFilterPool pool) {
        this.hash = hash;
        this.bitSet = new NativeRamBitSet(buffers, bufferSize, bits, bitSetSize);
        this.sstable = sstable;
        this.pool = pool;
    }

    boolean contains(byte[] b) {
        return contains(b, b.length);
    }

    boolean contains(byte[] b, int length) {
        int[] hashs = hash.hash(b, length);
        return bitSet.get(hashs);
    }

    int getNBytes() {
        return bitSet.byteSize();
    }

    private final AtomicInteger ref = new AtomicInteger(2);

    void acquire() {
        ref.incrementAndGet();
    }

    private boolean released = false;

    boolean release() {
        if (ref.decrementAndGet() == 0) {
            synchronized (pool.pool) {
                if (released) {
                    throw new LogicException("BloomFilter for " + sstable
                            + " released multiple times");
                }
                released = true;
                pool.bufferPool.releaseBuffer(bitSet.buffers);
                LOG.info("Unload bloomfilter for " + sstable
                        + ", filter pool usage: "
                        + pool.bufferPool.getAllocatedBufferSize() + "/"
                        + pool.bufferPool.getMaxBufferSize());
            }
            return true;
        } else {
            return false;
        }
    }
}
