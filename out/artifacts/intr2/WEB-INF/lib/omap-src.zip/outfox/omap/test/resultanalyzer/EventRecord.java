package outfox.omap.test.resultanalyzer;

import java.text.NumberFormat;
import java.util.Calendar;

public class EventRecord {
    public static final int START_CHECKPOINT = 0;

    public static final int DONE_CHECKPOINT = 1;

    public static final int START_SPLIT = 2;

    public static final int DONE_SPLIT = 3;

    public static final int START_COMPACT = 4;

    public static final int DONE_COMPACT = 5;

    public static final int START_TRUNCATE = 6;

    public static final int DONE_TRUNCATE = 7;

    public static final int PERIOD_THROUGHPUT = 8;

    public static final int PERIOD_RESPONSE_TIME = 9;

    public static final int AVERAGE_THROUGHPUT = 10;

    public static final int AVERAGE_RESPONSE_TIME = 11;

    public static final int MAX_ID = 12;

    public static final String[] idName = {
        "SCHECK", "DCHECK", "SSPLIT", "DSPLIT", "SCOMP", "DCOMP", "STRUNC",
        "DTRUNC", "PTHROU", "PRT", "ATHROU", "ART"
    };

    private int id;

    private Calendar time;

    private String data = null;

    public int getID() {
        return id;
    }

    public Calendar getTime() {
        return time;
    }

    public String getData() {

        if (data != null) {
            if ((this.id == PERIOD_RESPONSE_TIME || this.id == AVERAGE_RESPONSE_TIME)
                    && !this.data.equals("NaN")) {

                Double d = Double.valueOf(this.data);
                NumberFormat nf = NumberFormat.getInstance();
                nf.setGroupingUsed(false);
                nf.setMaximumFractionDigits(5);
                String res = nf.format(d.doubleValue());
                return res;
            } else
                return data;
        } else {
            switch (id) {
                case START_CHECKPOINT:
                    return "1";
                case DONE_CHECKPOINT:
                    return "1";
                case START_SPLIT:
                    return "2";
                case DONE_SPLIT:
                    return "2";
                case START_COMPACT:
                    return "3";
                case DONE_COMPACT:
                    return "3";
                case START_TRUNCATE:
                    return "4";
                case DONE_TRUNCATE:
                    return "4";
                default:
                    return null;
            }
        }
    }

    public static EventRecord getEvent(String line) {
        if (line.indexOf("Start checkpointing") != -1) {
            return new EventRecord(EventRecord.START_CHECKPOINT, getTime(line));
        }
        if (line.indexOf("Done checkpointing") != -1) {
            return new EventRecord(EventRecord.DONE_CHECKPOINT, getTime(line));
        }
        if (line.indexOf("Start spliting") != -1) {
            return new EventRecord(EventRecord.START_SPLIT, getTime(line));
        }
        if (line.indexOf("Done spliting") != -1) {
            return new EventRecord(EventRecord.DONE_SPLIT, getTime(line));
        }
        if (line.indexOf("Start compacting") != -1) {
            return new EventRecord(EventRecord.START_COMPACT, getTime(line));
        }
        if (line.indexOf("Done compacting") != -1) {
            return new EventRecord(EventRecord.DONE_COMPACT, getTime(line));
        }
        if (line.indexOf("Start truncating") != -1) {
            return new EventRecord(EventRecord.START_TRUNCATE, getTime(line));
        }
        if (line.indexOf("Done truncating") != -1) {
            return new EventRecord(EventRecord.DONE_TRUNCATE, getTime(line));
        }

        if (line.indexOf("periodThroughput") != -1) {
            return new EventRecord(EventRecord.PERIOD_THROUGHPUT,
                    getTime(line), getData(line));
        }
        if (line.indexOf("Average Throughput") != -1) {
            return new EventRecord(EventRecord.AVERAGE_THROUGHPUT,
                    getTime(line), getData(line));
        }
        if (line.indexOf("periodResponseTime") != -1) {
            return new EventRecord(EventRecord.PERIOD_RESPONSE_TIME,
                    getTime(line), getData(line));
        }
        if (line.indexOf("Average Response Time") != -1) {
            return new EventRecord(EventRecord.AVERAGE_RESPONSE_TIME,
                    getTime(line), getData(line));
        }
        return null;
    }

    private EventRecord(int id, Calendar time) {
        this.id = id;
        this.time = time;
    }

    private EventRecord(int id, Calendar time, String data) {
        this.id = id;
        this.time = time;
        this.data = data;
    }

    private static Calendar getTime(String log) {
        int year = Integer.parseInt(log.substring(0, 2)) + 2000;
        int month = Integer.parseInt(log.substring(2, 4));
        int day = Integer.parseInt(log.substring(4, 6));
        int hour = Integer.parseInt(log.substring(7, 9));
        int minute = Integer.parseInt(log.substring(9, 11));
        int second = Integer.parseInt(log.substring(11, 13));
        Calendar c = Calendar.getInstance();

        c.set(year, month - 1, day, hour, minute, second);
        return c;
    }

    private static String getData(String log) {
        int index = log.indexOf(':');
        if (index != -1)
            return log.substring(index + 1, log.length());
        else
            return null;
    }

}
