/**
 * @(#)TsConnectionManager.java, 2011-5-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.common;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import odis.rpc2.RPC;
import outfox.omap.exceptions.NoSuchTsException;

/**
 * @author zhangduo
 */
public class TsConnectionManager<P> {

    private static final class Key {
        public final String host;

        public final int port;

        public final String domain;

        public final String username;

        public final long timeout;

        public Key(String host, int port, String domain, String username,
                long timeout) {
            this.host = host;
            this.port = port;
            this.domain = domain;
            this.username = username;
            this.timeout = timeout;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + domain.hashCode();
            result = prime * result + username.hashCode();
            result = prime * result + host.hashCode();
            result = prime * result + port;
            result = prime * result + (int) (timeout ^ (timeout >>> 32));
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null || obj.getClass() != Key.class) {
                return false;
            }
            Key that = (Key) obj;
            return host.equals(that.host) && port == that.port
                    && domain.equals(that.domain)
                    && username.equals(that.username)
                    && timeout == that.timeout;
        }
    }

    private final ConcurrentMap<Key, P> proxyCache = new ConcurrentHashMap<Key, P>();

    private final Class<P> protocol;

    public static enum ConnectionType {
        BIO, NIO, UDP
    }

    private final ConnectionType type;

    public TsConnectionManager(Class<P> protocol, ConnectionType type) {
        this.protocol = protocol;
        this.type = type;
    }

    /**
     * Notice we use all the things passed in as the cache key, so you need to
     * pass the same domain, username and timeout although they have no use when
     * type is UDP.
     * 
     * @param tsDesc
     * @param domain
     * @param username
     * @param timeout
     * @return
     * @throws IOException
     */
    public P getRpcProxy(TsDesc tsDesc, String domain, String username,
            long timeout) throws IOException {
        if (tsDesc.isDummyTs()) {
            throw new NoSuchTsException("Dummy TS");
        }
        Key key = new Key(tsDesc.getHost(), tsDesc.getPort(), domain, username,
                timeout);
        P proxy = proxyCache.get(key);
        if (proxy == null) {
            synchronized (this) {
                proxy = proxyCache.get(key);
                if (proxy == null) {
                    switch (type) {
                        case BIO:
                            proxy = RPC.getProxy(protocol,
                                    new InetSocketAddress(key.host, key.port),
                                    domain, username, timeout);
                            break;
                        case NIO:
                            proxy = RPC.getNIOProxy(protocol,
                                    new InetSocketAddress(key.host, key.port),
                                    domain, username, timeout);
                            break;
                        case UDP:
                            proxy = RPC.getUDPProxy(protocol,
                                    new InetSocketAddress(key.host, key.port));
                            break;
                    }
                    proxyCache.put(key, proxy);
                }
            }
        }
        return proxy;
    }

    public void close() {
        synchronized (this) {
            for (P proxy: proxyCache.values()) {
                if (type == ConnectionType.UDP) {
                    RPC.closeUDPProxy(proxy);
                } else {
                    RPC.close(proxy);
                }
            }
        }
    }
}
