/**
 * @(#)ModifyAclTool.java, 2011-4-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.tools;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.logging.Logger;
import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.util.OmapLogFormatter;

/**
 * The configuer file should be in the format below:<p/>
 * <TABLE_TAMILY_NAME>=<OWNER>|<GROUP USERS>|<AUTHORITY>
 * # There is more than one group user, should be splitted by ";"
 *
 * @author wangfk
 *
 */
public class ModifyAclTool {
    private static final Logger LOG = OmapLogFormatter
            .getLogger(ModifyAclTool.class);

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("USAGE: " + ModifyAclTool.class.getName()
                    + " <ACL Configure file>");
            return;
        }
        File file = new File(args[0]);
        if (!file.exists()) {
            throw new RuntimeException("The specified file does not exist: "
                    + args[0]);
        }
        FileInputStream fis = new FileInputStream(file);
        Properties properties = new Properties();
        properties.load(fis);
        for (Entry<Object, Object> entry: properties.entrySet()) {
            String space = (String) entry.getKey();
            String acl = (String) entry.getValue();
            changeTableAclByFamily(space, acl);
        }
    }

    private static void changeTableAclByFamily(String space, String acl)
            throws Exception {
        String[] split = acl.split("\\|");
        if (split.length != 3) {
            throw new RuntimeException("Invalid alc setting for table space "
                    + space + ": " + acl);
        }
        String owner = split[0].trim();
        String groupUsers = split[1].trim();
        String authority = split[2].trim();

        ArrayList<String> groupUserList = new ArrayList<String>();
        String[] split2 = groupUsers.split(";");
        for (String str: split2) {
            String trim = str.trim();
            if (!trim.isEmpty()) {
                groupUserList.add(trim);
            }
        }

        DataSource dataSource = DataSourceFactory.getNamed("OmapDataSource");
        TableSpace tableSpace = dataSource.openTableSpace(space);
        Metadata[] listTables = tableSpace.listTables();
        for (Metadata metaData: listTables) {
            String tableName = metaData.getTableName();
            Table openTable = tableSpace.openTable(tableName);
            openTable.setProperty(Table.Property.ACL_OWNER_NAME, owner);
            openTable.setGroupUsers(groupUserList);
            openTable.chmod(authority);
            openTable.close();
            LOG.info("Finish Table ACL setting[" + space + "$" + tableName
                    + "]: onwer=" + owner + ", groupUser=" + groupUsers
                    + ", authority=" + authority);
        }
        tableSpace.close();
        dataSource.close();
        LOG.info("Finish Space ACL setting[" + space + "]: onwer=" + owner
                + ", groupUser=" + groupUsers + ", authority=" + authority);
    }
}
