/**
 * @(#)TabletModifyColumnTask.java, 2010-7-25. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.tools;

import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.JobConfig;
import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.io.FSDataInputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.client.protocol.Table;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.metadata.TableDesc;
import outfox.omap.ts.SSTableWriter;
import outfox.omap.ts.Tablet;
import outfox.omap.util.CloseableIterator;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.TabletReader;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class TabletModifyColumnTask extends TaskRunnable {

    private static final Logger LOG = LogFormatter.getLogger(TabletModifyColumnTask.class);

    public static final String CONVERT_ROW_TOOL_CLASS_NAME = "ConvertRowTool.ClassName";

    public static final String TABLET_ID_PREFIX = "TabletId.";

    public static final String FS_NAME = "FsName";

    public static final String INPUT_PATH = "InputPath";

    public static final String OUTPUT_PATH = "OutputPath";

    private AbstractConvertRowTool tool;

    private FileSystem fs;

    private KeyRange kr;

    private TableDesc td;

    private TableDesc dstTd;

    private Path inputPath;

    private Path outputPath;

    @Override
    public void configure(JobDef job, TaskWorker runner) {
        JobConfig conf = job.getConfig();
        try {
            String clazz = conf.getString(CONVERT_ROW_TOOL_CLASS_NAME);
            tool = (AbstractConvertRowTool) Class.forName(clazz).newInstance();
            String fsName = conf.getString(FS_NAME);
            fs = FileSystem.getNamed(fsName);
            String inputPath = conf.getString(INPUT_PATH);
            this.inputPath = new Path(inputPath);
            String outputPath = conf.getString(OUTPUT_PATH);
            this.outputPath = new Path(outputPath);
            long tabletId = conf.getLong(TABLET_ID_PREFIX + part);
            KeyRangeList krl = new KeyRangeList();
            FSDataInputStream krlInput = fs.open(this.inputPath.cat("keyRangeList"));
            krl.readFields(krlInput);
            krlInput.close();
            for (KeyRange kr: krl.getRangeSet().keySet()) {
                if (kr.getTabletId() == tabletId) {
                    this.kr = kr;
                }
            }
            if (kr == null) {
                throw new RuntimeException("KeyRange for tablet id = "
                        + HexString.longToPaddedHex(tabletId) + " not found");
            }
            td = new TableDesc();
            FSDataInputStream tdInput = fs.open(this.inputPath.cat("tableDesc"));
            td.readFields(tdInput);
            tdInput.close();
            dstTd = new TableDesc();
            tdInput = fs.open(this.outputPath.cat("tableDesc"));
            dstTd.readFields(tdInput);
            tdInput.close();
            tool.prepare(td, dstTd);
            LOG.info("Modify tablet "
                    + HexString.longToPaddedHex(kr.getTabletId())
                    + " task configure success");
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "config job failed", e);
            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            } else {
                throw new RuntimeException(e);
            }
        }
    }

    private AtomicLong rowCount = new AtomicLong(0);

    @Override
    protected long cursor() {
        return rowCount.get();
    }

    @Override
    public void run() {
        LOG.info("Modify tablet " + HexString.longToPaddedHex(kr.getTabletId())
                + " task start");
        TabletReader reader = null;
        CloseableIterator<DataRow> iter = null;
        SSTableWriter writer = null;
        try {
            reader = new TabletReader(fs,
                    inputPath.cat("ts").getAbsolutePath(), kr, td);
            iter = reader.iterator();
            String outputTabletDir = OmapUtils.getSSTableFileDirPath(
                    outputPath.cat("ts").getAbsolutePath(), kr.getTabletId());
            writer = new SSTableWriter(fs, new Path(outputTabletDir,
                    Tablet.SS_PREFIX + "0"), true, 0, reader.getNumKeys(),
                    OmapConfig.getConfiguration().getBoolean(
                            OmapConfig.NAME_ENABLE_BLOOM_FILTER,
                            OmapConfig.DEFAULT_ENABLE_BLOOM_FILTER),
                    CompressType.toType(td.getProperty(
                            Table.Property.COMPRESS_NAME,
                            Table.Property.DEFAULT_COMPRESS)),
                    Float.parseFloat(td.getProperty(
                            Table.Property.BLOOMFILTER_FALSERATE_NAME,
                            Table.Property.DEFAULT_BLOOMFILTER_FALSERATE)),
                    Byte.parseByte(td.getProperty(
                            Table.Property.REPLICATION_NAME,
                            Table.Property.DEFAULT_REPLICATION)));
            DataRow dr = td.borrowDataRow();
            KeyCell keyCell = td.getKey().borrowKeyCell();
            ByteArrayWritable rowBytes = new ByteArrayWritable();
            ByteArrayWritable key = new ByteArrayWritable();
            while (iter.next(dr)) {
                DataRow newDr = tool.convert(dr);
                rowBytes.set(OmapUtils.convertPIWritableToBytes(newDr));
                DataRow.keyCellFromBinaryRow(keyCell, rowBytes.getBytes());
                key.set(OmapUtils.convertPIWritableToBytes(keyCell));
                writer.write(key, rowBytes);
                rowCount.incrementAndGet();
            }
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "run job failed", e);
            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            } else {
                throw new RuntimeException(e);
            }
        } finally {
            OmapUtils.safeClose(iter);
            OmapUtils.safeClose(reader);
            OmapUtils.safeClose(writer);
        }
        LOG.info("Modify tablet " + HexString.longToPaddedHex(kr.getTabletId())
                + " task end, Row count " + rowCount.get());
    }
}
