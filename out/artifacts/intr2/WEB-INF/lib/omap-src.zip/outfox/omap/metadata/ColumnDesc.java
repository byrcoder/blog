package outfox.omap.metadata;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import outfox.omap.data.DataCell;
import outfox.omap.exceptions.BadTypeStringException;
import outfox.omap.exceptions.NoSuchTypeException;
import toolbox.misc.LogFormatter;

/**
 * <p>
 * A definition of a column. It also keeps an IWritable buffer for reuse.
 * </p>
 * <p>
 * The type of column could be any type defined in {@link Types}, or
 * {@link ColumnDesc#REF_COLUMN} (this column is a reference to an internal
 * table) or {@link ColumnDesc#REF_COL_FAMILY} (this column is a tuple key, the
 * keys' types are stored as type1 and type2)
 * </p>
 * 
 * @author xuw
 */
public class ColumnDesc implements IWritable {
    @SuppressWarnings("unused")
    private static Logger LOG = LogFormatter.getLogger(ColumnDesc.class);

    public static final String ATTR_CLIENT_TYPE = "ctype";

    /**
     * name of the column
     */
    private String name;

    /**
     * Type define string of this column.
     */
    private String typeString;

    /**
     * It also allocate space for reading/writing this column, (esp. on ts
     * server) so we don't have to create one each time. This will not be
     * written to disk when calling write
     */
    protected IWritable buffer;

    // attributes for processing on client side
    protected HashMap<String, String> attr;

    /**
     * Construct a ColumnDesc with an empty name and null buffer. Can call
     * readFields() later to fill the data.
     */
    public ColumnDesc() {
        this.name = "";
    }

    /**
     * Construct a ColumnDesc with a name. Can call readFields() later to fill
     * the data.
     * 
     * @param name
     */
    protected ColumnDesc(String name) {
        this();
        this.name = name;
    }

    /**
     * Construct a ColumnDesc with a name and a type.
     * 
     * @param name
     *            name of the column
     * @param type
     *            can be one of the followings:
     *            <ul>
     *            <li>type alias defined in Types.java, e.g. "INTEGER",
     *            "odis.serialize.lib.LongWritable"</li>
     *            <li>fixed length byte array, e.g. "FIXEDLENBYTEARRAY(23)"</li>
     *            <li>tuple key, e.g. "TPKEY(LONG STRING)"</li>
     *            <li>internal table, e.g. "TABLEREF(Table1)</li>
     *            </ul>
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws NoSuchTypeException
     */
    public ColumnDesc(String name, String typeString)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException, NoSuchTypeException, BadTypeStringException {
        this(name);
        this.typeString = typeString;
        initBuffer(typeString);
    }

    /**
     * Init the buffer with a type string
     * 
     * @param type
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws NoSuchTypeException
     */
    private void initBuffer(String typeString) throws ClassNotFoundException,
            InstantiationException, IllegalAccessException,
            NoSuchTypeException, BadTypeStringException {
        this.buffer = Types.getIWritable(typeString);
        if (Types.isCustomType(typeString)) {
            int startPos = typeString.indexOf('(');
            int endPos = typeString.lastIndexOf(')');
            this.setAttr(ATTR_CLIENT_TYPE,
                    typeString.substring(startPos + 1, endPos));
        }
    }

    /**
     * Get the type string of the column
     */
    public String getTypeString() {
        return this.typeString;
    }

    /**
     * create a blank data cell
     * 
     * @return
     */
    public DataCell createDataCell() {
        DataCell ret = new DataCell();
        try {
            if ((attr != null) && (attr.get(ATTR_CLIENT_TYPE) != null)) {
                ret.setClientType(attr.get(ATTR_CLIENT_TYPE));
            }
            ret.setBuffer(this.buffer.getClass().newInstance());
            ret.getBuffer().copyFields(this.buffer);
            ret.setInvalid();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return ret;
    }

    public String getAttr(String attrName) {
        if (attr == null) {
            return null;
        } else {
            return attr.get(attrName);
        }
    }

    public void setAttr(String attrName, String attrValue) {
        if (attr == null) {
            attr = new HashMap<String, String>();
        }
        attr.put(attrName, attrValue);
    }

    public IWritable copyFields(IWritable value) {
        assert this != value;
        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }
        ColumnDesc val = (ColumnDesc) value;
        // String is an immutable object, no need to copy
        this.name = val.name;
        this.typeString = val.typeString;

        try {
            this.initBuffer(typeString);
        } catch (BadTypeStringException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }

        if (val.attr == null) {
            this.attr = null;
        } else {
            this.attr = new HashMap<String, String>();
            for (String key: val.attr.keySet()) {
                this.attr.put(key, val.attr.get(key));
            }
        }

        return this;
    }

    public void readFields(DataInput in) throws IOException {
        this.name = in.readUTF();
        this.typeString = in.readUTF();

        try {
            this.initBuffer(typeString);
        } catch (BadTypeStringException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }

        int attrSize = in.readInt();
        if (attrSize == -1) {
            this.attr = null;
        } else {
            this.attr = new HashMap<String, String>();
            for (int i = 0; i < attrSize; i++) {
                this.attr.put(in.readUTF(), in.readUTF());
            }
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(this.name);
        out.writeUTF(this.typeString);

        if (this.attr == null) {
            out.writeInt(-1);
        } else {
            out.writeInt(this.attr.size());
            for (String key: this.attr.keySet()) {
                out.writeUTF(key);
                out.writeUTF(this.attr.get(key));
            }
        }
    }

    @Override
    public String toString() {
        return this.name + " [" + this.typeString + "]";
    }

    public String getName() {
        return name;
    }

    public IWritable getBuffer() {
        return buffer;
    }

    @Override
    public int hashCode() {
        return name.hashCode() ^ typeString.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ColumnDesc o = (ColumnDesc) obj;
        return this.name.equals(o.name) && this.typeString.equals(o.typeString);
    }

}
