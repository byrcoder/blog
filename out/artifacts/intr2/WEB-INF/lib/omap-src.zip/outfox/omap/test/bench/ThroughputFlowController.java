/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

import outfox.omap.test.bench.WorkloadRunner.AccessType;
import outfox.omap.test.bench.WorkloadRunner.ThreadManager;
import java.util.logging.Logger;
import toolbox.misc.LogFormatter;

/**
 *
 * @author zhangkun
 */
class ThroughputFlowController extends FlowController {
    private double expectedThroughput;
    private double sleepTime = 1;
    private int maxThreadNum = 200;
    private static final Logger LOG = LogFormatter.getLogger(ThroughputFlowController.class);
    
    public ThroughputFlowController() {}
    public void setExpectedThroughput(double throughput) {
        this.expectedThroughput = throughput;
        throughputCountPeriod = Math.max((long) (10 / expectedThroughput), throughputCountPeriod);
    }
    public void setMaxThreadNum(int num) {
        this.maxThreadNum = num;
    }
    public ThroughputFlowController(AccessType accessType,
            double expectedThroughput) {
        super(accessType);
        setExpectedThroughput(expectedThroughput);
    }
    @Override
    protected void workThreadRest() {
        try {
            long sleep = (long)sleepTime;
            if(sleep > 1) {
                Thread.sleep(sleep);
            }
        } catch(Exception e){}
    }

    @Override
    protected void throughputUpdated(ThreadManager tm) {
        if(currentThroughput > expectedThroughput * 3 / 2) {
            if(tm.getNumThreads() <= 1) {
                sleepTime = sleepTime * 1.2;
            } else {
                tm.reduceThread(1);
            }
        } else if(currentThroughput > expectedThroughput) {
            sleepTime = sleepTime * 1.2;
        } else if(currentThroughput < expectedThroughput) {
            if(sleepTime > 1) {
                sleepTime = sleepTime / 1.2;
            } else {
                if(tm.getNumThreads() >= maxThreadNum) {
                    LOG.warning("Thread number of " + workload.tableName + " reaches limit " + maxThreadNum);
                } else {
                    tm.addThread(1);
                }
            }
        }
    }
    @Override
    public String toString() {
        return "[" + this.getClass().getSimpleName() + " expectedThroughput=" + expectedThroughput + "]";
    }
}
