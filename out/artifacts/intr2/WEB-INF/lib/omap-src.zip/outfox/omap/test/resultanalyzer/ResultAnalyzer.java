package outfox.omap.test.resultanalyzer;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.InputStreamReader;

public class ResultAnalyzer {

    /**
     * @param args
     */
    public void analyze(String[] args) throws Exception {
        String path = args[0];
        System.out.println("Analyzing " + path);
        File logDir = new File(path);
        File logs[] = logDir.listFiles(new LogFilter());
        EventList lists[] = new EventList[logs.length];
        for (int i = 0; i < logs.length; i++) {
            String size = logs[i].getName().substring(4);
            int totalMachine = 0;
            long totalThroughtPut = 0;
            int totalClient = 0;
            //Calendar start=Calendar.getInstance();

            System.out.println("Analyzing " + size);
            lists[i] = new EventList(size);
            File logFiles[] = logs[i].listFiles(new LogFilter());
            for (int j = 0; j < logFiles.length; j++) {
                System.out.println("Analyzing " + logFiles[j].getName());
                BufferedReader r = new BufferedReader(new InputStreamReader(
                        new FileInputStream(logFiles[j])));
                String line = r.readLine();
                while (line != null) {
                    EventRecord record = EventRecord.getEvent(line);
                    if (record != null)
                        lists[i].addEvent(record);
                    line = r.readLine();
                }
                r.close();
            }
        }

        DataOutputStream out = new DataOutputStream(new FileOutputStream(
                new File(path + File.separator + "result.txt")));
        for (int i = 0; i < lists.length; i++) {
            out.write((lists[i].getName() + "\n").getBytes());
            lists[i].output(out);
        }

        out.write("\n".getBytes());
        out.write("\tThou\tART\n".getBytes());
        for (int i = 0; i < lists.length; i++)
            out.write((lists[i].getName() + "\t"
                    + lists[i].getTotalThroughput() + "\t"
                    + lists[i].getAverageResponseTime() + "\n").getBytes());

    }

    public static void main(String[] args) throws Exception {
        new ResultAnalyzer().analyze(args);
    }

    public static class LogFilter implements FilenameFilter {
        public boolean accept(File dir, String name) {
            if (name.startsWith("log_") || name.endsWith(".log"))
                return true;
            else
                return false;
        }
    }

}
