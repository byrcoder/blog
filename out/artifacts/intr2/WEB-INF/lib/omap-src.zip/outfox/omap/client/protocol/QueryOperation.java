/**
 * @(#)QueryOperation.java, Oct 7, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol;

import java.util.HashMap;

/**
 * The Predicate used by QueryCondition
 * 
 * @author xingjk
 */
public enum QueryOperation {
    EQUAL((byte) 0, (byte) 0), 
    LIRI((byte) 1, (byte) 1), // range of left inclusive, right inclusive
    LIRE((byte) 2, (byte) 1), // range of left inclusive, right exclusive
    LERI((byte) 3, (byte) 2), // range of left exclusive, right inclusive
    LERE((byte) 4, (byte) 2), // range of left exclusive, right exclusive
    GET((byte) 5, (byte) 3), 
    LET((byte) 6, (byte) 3), 
    GT((byte) 7, (byte) 4), 
    LT((byte) 8, (byte) 4), 
    INEQUAL((byte) 9, (byte) 5);

    private final static HashMap<Byte, QueryOperation> codeMap = new HashMap<Byte, QueryOperation>();
    static {
        for(QueryOperation op : QueryOperation.values()) {
            codeMap.put(op.code, op);
        }
    }
    public static QueryOperation valueOf(byte code) {
        QueryOperation ret = codeMap.get(code);
        if(ret == null) {
            throw new IllegalArgumentException("invalid code " + code);
        }
        return ret;
    }
    QueryOperation(byte code, byte priority) {
        this.code = code;
        this.priority = priority;
    }

    /**
     * Indicate whether this operation needs two parameters or not
     * 
     * @return
     */
    public boolean isSpecifyRange() {
        if (this == QueryOperation.LIRI || this == QueryOperation.LIRE
                || this == QueryOperation.LERI || this == QueryOperation.LERE) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isSpecifyLowerBound() {
        if (this == QueryOperation.GET || this == QueryOperation.GT)
            return true;
        else
            return false;
    }

    public boolean isSpecifyUpperBound() {
        if (this == QueryOperation.LET || this == QueryOperation.LT)
            return true;
        else
            return false;
    }

    private final byte priority;
    private final byte code;

    public byte getPriority() {
        return priority;
    }

    public byte getCode() {
        return code;
    }
}
