/**
 * @(#)InvalidDataSourceException.java, 2010-3-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author wangfk
 */
public class InvalidDataSourceException extends RuntimeException {

    private static final long serialVersionUID = 2722813875092469991L;

    public InvalidDataSourceException() {
        super();
    }

    public InvalidDataSourceException(String message) {
        super(message);
    }

    public InvalidDataSourceException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidDataSourceException(Throwable cause) {
        super(cause);
    }

}
