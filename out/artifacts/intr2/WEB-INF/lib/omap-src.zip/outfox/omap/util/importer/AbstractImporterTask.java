/**
 * @(#)AbstractImporterTask.java, 2010-3-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.IOException;
import java.util.logging.Logger;

import odis.rpc2.RPC;

import org.apache.commons.lang.StringUtils;

import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.exceptions.MasterNotInitializedException;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.TableConfig;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;

/**
 * ImporterTask contents several DataReaders ({@link IDataReader})
 * <p>
 * Run as an independent thread, fetch data from DataReaders and write data to
 * SSTable
 * 
 * @author wangfk
 */
public abstract class AbstractImporterTask implements Runnable {

    private static Logger LOG = LogFormatter.getLogger(AbstractImporterTask.class.getName());

    enum DataDistrib {
        ORDINAL, BLANCED,
    }

    private String tableName;

    private String tableSpace;

    private String masterAddr;

    protected TableConfig tableConfig;

    protected ClientMasterProtocol master;

    protected String colNames;

    protected String colTypes;

    protected CompressType compressType;

    protected int sstableNumber = 1;

    protected DataDistrib dataDistrib = DataDistrib.ORDINAL;

    private boolean initFlag;

    public AbstractImporterTask() {
        super();
        initFlag = false;
    }

    /**
     * @param tableName
     *            the tableName to set
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    /**
     * @param tableSpace
     *            the tableSpace to set
     */
    public void setTableSpace(String tableSpace) {
        this.tableSpace = tableSpace;
    }

    /**
     * @param masterAddr
     *            the masterAddr to set
     */
    public void setMasterAddr(String masterAddr) {
        this.masterAddr = masterAddr;
    }

    /**
     * @param colNames
     *            the colNames to set
     */
    public void setColNames(String colNames) {
        this.colNames = colNames;
    }

    /**
     * @param colTypes
     *            the colTypes to set
     */
    public void setColTypes(String colTypes) {
        this.colTypes = colTypes;
    }

    /**
     * @param compressAlgo
     *            the compressAlgo to set
     */
    public void setCompressType(String compressType) {
        if (StringUtils.isEmpty(compressType)) {
            this.compressType = CompressType.NULL;
        } else {
            this.compressType = CompressType.toType(compressType);
        }
    }

    /**
     * DataReader added to the task, should be implemented by subclass
     * 
     * @param reader
     */
    protected abstract void addDataReaderInner(IDataReader reader);

    /**
     * Get master and create table by
     * {@link outfox.omap.common.ClientMasterProtocol#createImportedTable}
     */
    private void initBeforeAddDataReader() {
        if (initFlag) {
            return;
        }
        initFlag = true;
        try {
            if (StringUtils.isEmpty(masterAddr)) {
                throw new MasterNotInitializedException("Master addr is null.");
            }
            master = (ClientMasterProtocol) RPC.getProxy(
                    ClientMasterProtocol.class,
                    InetAddressUtils.createSocketAddr(masterAddr), tableSpace,
                    System.getProperty("user.name"), 0);
            tableConfig = master.createImportedTable(
                    OmapUtils.toInternalTableName(tableSpace, tableName),
                    colNames, colTypes, null);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Add DataReader to ImporterTask
     * 
     * @param reader
     */
    public void addDataReader(IDataReader reader) {
        initBeforeAddDataReader();

        reader.setColNames(colNames);
        reader.setColTypes(colTypes);
        reader.setTableConfig(tableConfig);
        try {
            reader.openDataSource();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        addDataReaderInner(reader);
    }

    /**
     * This method is just for JUnit test
     * 
     * @param master
     * @param tableConfig
     */
    @Deprecated
    void initJustForTestCase(ClientMasterProtocol master,
            TableConfig tableConfig) {
        initFlag = true;
        this.master = master;
        this.tableConfig = tableConfig;
    }

    public void setSstableNumber(String sstableNumber) {
        if (StringUtils.isEmpty(sstableNumber)) {
            return;
        }
        try {
            this.sstableNumber = Integer.parseInt(sstableNumber);
        } catch (Exception e) {
            this.sstableNumber = 1;
            LOG.warning("Unknow sstable number: " + sstableNumber
                    + ". Use default: 1");
        }
    }

    public void setDataDistrib(String dataDistrib) {
        if (StringUtils.isEmpty(dataDistrib)) {
            return;
        }

        if (DataDistrib.BLANCED.name().equalsIgnoreCase(dataDistrib)) {
            this.dataDistrib = DataDistrib.BLANCED;
        } else if (DataDistrib.ORDINAL.name().equalsIgnoreCase(dataDistrib)) {
            this.dataDistrib = DataDistrib.ORDINAL;
        } else {
            LOG.warning("Unknow data distribution method: " + dataDistrib
                    + ". Use default: ORDINAL");
        }

    }

}
