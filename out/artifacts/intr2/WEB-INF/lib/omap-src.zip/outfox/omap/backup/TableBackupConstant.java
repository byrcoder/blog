/**
 * @(#)TableBackupConstant.java, 2011-8-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.backup;

/**
 *
 * @author wangfk
 *
 */
public interface TableBackupConstant {

    public static final String SnapshotPath = "snapshot";

    public static final String WALogPath = "walog";

    public static final String ReplayPath = "replay";

    public static final String TempPath = "temp";

    public static final String WALogFilePattern = "wal_\\d+-\\d+";
}
