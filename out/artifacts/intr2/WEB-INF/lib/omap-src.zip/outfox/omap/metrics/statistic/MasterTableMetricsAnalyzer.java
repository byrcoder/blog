/**
 * @(#)MasterTableAnalyzer.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.MasterMetricsType;
import outfox.omap.metrics.TimeRangeUtils;

/**
 * @author zhangduo
 */
public class MasterTableMetricsAnalyzer {
    private long[] metricsRecords = new long[MasterMetricsType.tableTypeCount()];

    private double[] statisticResults = new double[MasterTableStatisticType.getTypeCount()];

    public void process(long[] metricsRecords) {
        for (int i = 0; i < MasterMetricsType.tableTypeCount(); i++) {
            this.metricsRecords[i] += metricsRecords[i];
        }
    }

    public void done() {
        statisticResults[MasterTableStatisticType.LOOKUP_KEY_COUNT.offset()] = metricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()] > 0) {
            statisticResults[MasterTableStatisticType.LOOKUP_KEY_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.LOOKUP_KEY_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()];
        } else {
            statisticResults[MasterTableStatisticType.LOOKUP_KEY_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterTableStatisticType.TIME_RANGE_LOOKUP_KEY_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.TIME_RANGE_LOOKUP_KEY_COUNT.offset()
                    + i];
        }

        statisticResults[MasterTableStatisticType.RENAME_TABLE_COUNT.offset()] = metricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()] > 0) {
            statisticResults[MasterTableStatisticType.RENAME_TABLE_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.RENAME_TABLE_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()];
        } else {
            statisticResults[MasterTableStatisticType.RENAME_TABLE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterTableStatisticType.TIME_RANGE_RENAME_TABLE_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.TIME_RANGE_RENAME_TABLE_COUNT.offset()
                    + i];
        }

        statisticResults[MasterTableStatisticType.SET_TABLE_PROPERTIES_COUNT.offset()] = metricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()] > 0) {
            statisticResults[MasterTableStatisticType.SET_TABLE_PROPERTIES_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()];
        } else {
            statisticResults[MasterTableStatisticType.SET_TABLE_PROPERTIES_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterTableStatisticType.TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset()
                    + i];
        }

        statisticResults[MasterTableStatisticType.GET_SCHEMA_ID_COUNT.offset()] = metricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()] > 0) {
            statisticResults[MasterTableStatisticType.GET_SCHEMA_ID_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GET_SCHEMA_ID_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()];
        } else {
            statisticResults[MasterTableStatisticType.GET_SCHEMA_ID_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterTableStatisticType.TIME_RANGE_GET_SCHEMA_ID_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.TIME_RANGE_GET_SCHEMA_ID_COUNT.offset()
                    + i];
        }

        statisticResults[MasterTableStatisticType.GET_METADATA_COUNT.offset()] = metricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()] > 0) {
            statisticResults[MasterTableStatisticType.GET_METADATA_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GET_METADATA_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()];
        } else {
            statisticResults[MasterTableStatisticType.GET_METADATA_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterTableStatisticType.TIME_RANGE_GET_METADATA_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.TIME_RANGE_GET_METADATA_COUNT.offset()
                    + i];
        }

        statisticResults[MasterTableStatisticType.SET_READ_ONLY_COUNT.offset()] = metricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()] > 0) {
            statisticResults[MasterTableStatisticType.SET_READ_ONLY_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.SET_READ_ONLY_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()];
        } else {
            statisticResults[MasterTableStatisticType.SET_READ_ONLY_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterTableStatisticType.TIME_RANGE_SET_READ_ONLY_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.TIME_RANGE_SET_READ_ONLY_COUNT.offset()
                    + i];
        }
    }

    public double[] getStatisticResults() {
        return statisticResults;
    }

}
