/**
 * @(#)TsGlobalMetricsEntry.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.management.MemoryUsage;
import java.util.Arrays;

import odis.serialize.IWritable;
import outfox.omap.ts.OmapTs;
import outfox.omap.util.SystemInfoUtils;

/**
 * @author zhangduo
 */
public class TsGlobalMetricsEntry implements IWritable {

    private final long[] metricsRecords = new long[TsMetricsType.globalTypeCount()];

    public long[] getMetricsRecords() {
        return metricsRecords;
    }

    public synchronized void heartbeat(long delay) {
        metricsRecords[TsMetricsType.GLOBAL_HEARTBEAT_COUNT.offset()]++;
        metricsRecords[TsMetricsType.GLOBAL_HEARTBEAT_DELAY.offset()] += delay;
        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.GLOBAL_TIME_RANGE_HEARTBEAT_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void sstableSeek(long delay) {
        metricsRecords[TsMetricsType.GLOBAL_SSTABLE_SEEK_COUNT.offset()]++;
        metricsRecords[TsMetricsType.GLOBAL_SSTABLE_SEEK_DELAY.offset()] += delay;
        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.GLOBAL_TIME_RANGE_SSTABLE_SEEK_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void request() {
        metricsRecords[TsMetricsType.GLOBAL_REQUEST_NUM.offset()]++;
    }

    public synchronized void requestTimeout() {
        metricsRecords[TsMetricsType.GLOBAL_TIMEOUT_REQUEST_NUM.offset()]++;
    }

    public synchronized void blockCacheCache() {
        metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_CACHE_COUNT.offset()]++;
    }

    public synchronized void blockCacheGet(boolean hit) {
        metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_GET_COUNT.offset()]++;
        if (hit) {
            metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_GET_HIT_COUNT.offset()]++;
        }
    }

    public synchronized void blockCacheEvict(int count) {
        metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_EVICT_COUNT.offset()] += count;
    }

    public synchronized void copyToAndClear(TsGlobalMetricsEntry entry) {
        entry.copyFields(this);
        Arrays.fill(metricsRecords, 0L);
    }

    public void setTabletNumber(int number) {
        metricsRecords[TsMetricsType.GLOBAL_TABLET_NUM.offset()] = number;
    }

    public void updateSystemInfo(OmapTs ts) {
        metricsRecords[TsMetricsType.GLOBAL_SYSTEM_LOAD.offset()] = (long) (SystemInfoUtils.getLoad() * 100);
        metricsRecords[TsMetricsType.GLOBAL_PROCESSOR_NUM.offset()] = SystemInfoUtils.getProcessors();
        MemoryUsage memoryUsage = SystemInfoUtils.getMemoryUsage();
        metricsRecords[TsMetricsType.GLOBAL_MEMORY_INIT.offset()] = memoryUsage.getInit();
        metricsRecords[TsMetricsType.GLOBAL_MEMORY_USED.offset()] = memoryUsage.getUsed();
        metricsRecords[TsMetricsType.GLOBAL_MEMORY_COMMITTED.offset()] = memoryUsage.getCommitted();
        metricsRecords[TsMetricsType.GLOBAL_MEMORY_MAX.offset()] = memoryUsage.getMax();

        metricsRecords[TsMetricsType.GLOBAL_WRITE_BUFFER_USED.offset()] = ts.getBufferPool().getAllocatedBufferSize();
        metricsRecords[TsMetricsType.GLOBAL_WRITE_BUFFER_MAX.offset()] = ts.getBufferPool().getMaxBufferSize();

        metricsRecords[TsMetricsType.GLOBAL_BLOOMFILTER_USED.offset()] = ts.getFilterPool().getAllocatedSize();
        metricsRecords[TsMetricsType.GLOBAL_BLOOMFILTER_MAX.offset()] = ts.getFilterPool().getMaxSize();

        metricsRecords[TsMetricsType.GLOBAL_INDEX_POOL_USED.offset()] = ts.getIndexPool().getAllocatedSize();
        metricsRecords[TsMetricsType.GLOBAL_INDEX_POOL_MAX.offset()] = ts.getIndexPool().getMaxSize();

        metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_USED.offset()] = ts.getBlockCache().getUsedSize();
        metricsRecords[TsMetricsType.GLOBAL_BLOCK_CACHE_MAX.offset()] = ts.getBlockCache().getMaxSize();
    }

    @Override
    public IWritable copyFields(IWritable value) {
        TsGlobalMetricsEntry that = (TsGlobalMetricsEntry) value;
        System.arraycopy(that.metricsRecords, 0, metricsRecords, 0,
                metricsRecords.length);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        for (long metricsRecord: metricsRecords) {
            out.writeLong(metricsRecord);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        for (int i = 0; i < metricsRecords.length; i++) {
            metricsRecords[i] = in.readLong();
        }
    }

}
