/**
 * @(#)TableReadOnlyException.java, 2009-11-12. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author zhangduo
 */
public class TableReadOnlyException extends RuntimeException {

    private static final long serialVersionUID = 6176105555849471594L;

    public TableReadOnlyException() {
        super();
    }

    public TableReadOnlyException(String message, Throwable cause) {
        super(message, cause);
    }

    public TableReadOnlyException(String message) {
        super(message);
    }

    public TableReadOnlyException(Throwable cause) {
        super(cause);
    }

}
