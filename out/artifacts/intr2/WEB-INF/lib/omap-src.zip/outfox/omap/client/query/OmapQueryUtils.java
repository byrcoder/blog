/**
 * @(#)OmapQueryUtils.java, Dec 3, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.query;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryCondition;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyPair;

/**
 * The utility methods that private to query
 * 
 * @author xingjk
 */
public class OmapQueryUtils {

    public static final List<IWritable> EMPTY_IWRITABLE_LIST = Collections.emptyList();

    public static final Map<String, OmapQuery> EMPTY_QUERY_MAP = Collections.emptyMap();

    public static final Map<IndexSchema, String> EMPTY_INDEX_MAP = Collections.emptyMap();

    /**
     * Flat the nested KeyPair objs in the index key into
     * <code>flatValues</code>. The length of flatValues must be exactly fit to
     * the nested KeyPair
     * 
     * @param key
     *            the key cell
     * @param flatValues
     *            the result array whose head space has been allocated
     * @author xingjk
     */
    static void flattenIndexKey(KeyCell key, IWritableComparable[] flatValues) {
        IWritableComparable w = key.getKey();
        for (int i = 0; i < flatValues.length; i++) {
            if (i == flatValues.length - 1) {
                flatValues[i] = w;
            } else {
                KeyPair kp = (KeyPair) w;
                flatValues[i] = kp.getKey1();
                w = kp.getKey2();
            }
        }
    }

    /**
     * Judge whether key is match with query without care about the first key of
     * outside most KeyPair, which is handled by the main execution logic.
     * 
     * @param query
     *            the query to be checked
     * @param key
     *            the key cell
     * @paramp paras the array spaces that is allocated before to put the
     *         flattened key
     * @return whether is match
     * @author xingjk
     */
    static boolean isMatchWithoutFirstKey(OmapQuery query, KeyCell key,
            IWritableComparable[] paras) {
        OmapQueryUtils.flattenIndexKey(key, paras);
        OmapQueryCondition[] conditions = query.getConditions();
        for (int i = 1; i < conditions.length; i++) {
            if (!conditions[i].isMatch(paras[i])) {
                return false;
            }
        }

        return true;
    }

    public static OmapQueryCondition[] convertQueryConditionArrayToOmapQueryConditionArray(
            QueryCondition[] conditions) {
        OmapQueryCondition[] ret = new OmapQueryCondition[conditions.length];
        for (int i = 0; i < conditions.length; i++) {
            ret[i] = (OmapQueryCondition) conditions[i];
        }
        return ret;
    }

    public static OmapQuery[] convertQueryArrayToOmapQueryArray(Query[] queries) {
        if (queries == null) {
            return null;
        }
        OmapQuery[] ret = new OmapQuery[queries.length];
        for (int i = 0; i < queries.length; i++) {
            ret[i] = (OmapQuery) queries[i];
        }
        return ret;
    }

    public static IWritableComparable[] convertDataRowToIWritableComparableArray(
            DataRow row) {
        DataCell[] data = row.getColumns();
        IWritableComparable[] values = new IWritableComparable[data.length];
        for (int i = 0; i < data.length; i++) {
            values[i] = (IWritableComparable) data[i].getIWritable();
        }
        return values;
    }

    /**
     * For a key cell, it may contain conventional data (like IntWritable) or a
     * KeyPair. For the former this method return directly; for the later, the
     * first sub key of key pair is returned.
     * 
     * @author xingjk
     */
    static IWritableComparable getFirstKey(KeyCell key) {
        IWritableComparable w = key.getKey();
        if (w.getClass().isAssignableFrom(KeyPair.class))
            return ((KeyPair) w).getKey1();
        else
            return w;
    }

    /**
     * Given the first key "target", search the last row whose first key is less
     * than the given "target", even the the rows with "target" do not exist.
     * For example, for given rows with first keys(start = 0, end = 4):<br>
     * <table border=1>
     * <tr>
     * <td>index</td>
     * <td>0</td>
     * <td>1</td>
     * <td>2</td>
     * <td>3</td>
     * <td>4</td>
     * </tr>
     * <tr>
     * <td>key</td>
     * <td>2</td>
     * <td>2</td>
     * <td>6</td>
     * <td>9</td>
     * <td>9</td>
     * </tr>
     * </table>
     * <ul>
     * <li>search 1 returns -1</li>
     * <li>search 2 returns -1</li>
     * <li>search 4 returns 1</li>
     * <li>search 9 returns 2</li>
     * <li>search 10 returns 4</li>
     * </ul>
     * It should be noted that, if the given key is less or equal than the key
     * in <code>start</code> , start - 1 will be returns, which may be beyond
     * the minimal index of the given array. So you'd better check the first
     * item by yourself.
     * 
     * @param rows
     *            the rows to be searched, which are sorted ascendingly by their
     *            first keys
     * @param target
     *            the key to be searched
     * @return the last row's index whose first key is less than
     *         <code>target</code> in the range of [start - 1, end]/
     * @author xingjk
     */
    public static int binarySearchLastRowWithLessKey(DataRow[] rows,
            IWritableComparable target) {
        assert (rows.length > 0);
        int start = 0, end = rows.length - 1;
        if (getFirstKey(rows[end].getKeyCell()).compareTo(target) < 0)
            return end;
        while (start < end) {
            int mid = start + ((end - start) >>> 1);
            if (getFirstKey(rows[mid].getKeyCell()).compareTo(target) < 0)
                start = mid + 1;
            else
                end = mid;
        }
        return start - 1;
    }

    /**
     * Given the first key "target", search the first row whose first key is
     * greater than the given "target", even the the rows with "target" do not
     * exist. For example, for given rows with first keys (start = 0, end = 4):<br>
     * <table border=1>
     * <tr>
     * <td>index</td>
     * <td>0</td>
     * <td>1</td>
     * <td>2</td>
     * <td>3</td>
     * <td>4</td>
     * </tr>
     * <tr>
     * <td>key</td>
     * <td>2</td>
     * <td>2</td>
     * <td>6</td>
     * <td>9</td>
     * <td>9</td>
     * </tr>
     * </table>
     * <ul>
     * <li>search 1 returns 0</li>
     * <li>search 2 returns 2</li>
     * <li>search 4 returns 2</li>
     * <li>search 9 returns 5</li>
     * <li>search 10 returns 5</li>
     * </ul>
     * It should be noted that, if the given key is greater or equal than the
     * key in the <code>
     * end</code>, end + 1 will be returns, which may be beyond the maximal
     * index of the given array. So you'd better check the last item by
     * yourself.
     * 
     * @param rows
     *            the rows to be searched, which are sorted ascendingly by their
     *            first key
     * @param target
     *            the key to be searched
     * @return the first row's index in the range [start, end + 1] whose first
     *         key is greater than target.
     * @author xingjk
     */
    public static int binarySearchFirstRowWithGreaterKey(DataRow[] rows,
            IWritableComparable target) {
        assert (rows.length > 0);
        int start = 0, end = rows.length - 1;
        if (getFirstKey(rows[start].getKeyCell()).compareTo(target) > 0)
            return start;
        while (start < end) {
            int mid = start + ((end - start + 1) >>> 1);
            if (getFirstKey(rows[mid].getKeyCell()).compareTo(target) > 0)
                end = mid - 1;
            else
                start = mid;
        }
        return end + 1;
    }

    /**
     * Convert the parameters in the query conditions into a KeyCell object to
     * start a certain query
     * 
     * @param query
     *            the query object that hold all query conditions
     * @param is
     *            index schema
     * @return the key cell object
     */
    static KeyCell constructStartKey(OmapQuery query, IndexSchema is) {
        OmapQueryCondition[] conditions = query.getConditions();
        IWritableComparable[] queryParas = new IWritableComparable[conditions.length];
        for (int i = 0; i < queryParas.length; i++) {
            QueryCondition condition = conditions[i];
            // for LT and LET, we need to start from a null key
            // if LT or LET is the first condition, we will create a null
            // key to start
            // but if LT or LET is not the first condition, we should do
            // this
            switch (condition.getOperation()) {
                case LT:
                case LET:
                    queryParas[i] = null;
                    break;
                default:
                    queryParas[i] = condition.getPara();
                    break;
            }
        }

        return is.createQueryKey(queryParas);
    }

    /**
     * Convert the parameters in the query conditions into a KeyCell object to
     * identify the end of query. For those conditions which have two
     * parameters, use the param2.
     * 
     * @param query
     *            the query object that hold all query conditions
     * @param is
     *            index schema
     * @return the key cell object
     */
    static KeyCell constructEndKey(OmapQuery query, IndexSchema is) {
        OmapQueryCondition[] conditions = query.getConditions();
        IWritableComparable[] queryParas = new IWritableComparable[conditions.length];
        for (int i = 0; i < queryParas.length; i++) {
            QueryCondition condition = conditions[i];
            if (condition.getOperation().isSpecifyRange()) {
                queryParas[i] = condition.getPara2();
            } else {
                queryParas[i] = condition.getPara();
            }
        }

        return is.createQueryKey(queryParas);
    }
}
