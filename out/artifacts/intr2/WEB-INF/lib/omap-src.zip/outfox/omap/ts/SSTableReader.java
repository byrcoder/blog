/**
 * @(#)SSTableReader.java, 2010-3-22. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;

import odis.io.CDataInputStream;
import odis.io.LzoCompression;
import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.IntWritable;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.DataCell;
import outfox.omap.exceptions.LogicException;
import outfox.omap.metadata.KeyCellBinaryComparator;
import outfox.omap.ts.SSTable.SSType;
import outfox.omap.ts.SparseIndex.IndexStruct;
import toolbox.misc.LogFormatter;

/**
 * @author wangfk, zhangduo
 */
public class SSTableReader {

    private static final Logger LOG = LogFormatter.getLogger(SSTableReader.class);

    private BlockDataInput currentBlockDataInput;

    private IndexStruct currentIndex;

    private final SSTable sstable;

    private static class NonKeyPartBuffer implements IWritable {
        private ByteArrayWritable row;

        private ByteArrayWritable key;

        @Override
        public IWritable copyFields(IWritable value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            throw new UnsupportedOperationException();
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            int nonKeyPartSize = CDataInputStream.readVInt(in);
            byte[] buffer = row.data();
            if (buffer.length < key.size() + nonKeyPartSize) {
                buffer = new byte[key.size() + nonKeyPartSize];
            }
            buffer[0] = in.readByte();
            System.arraycopy(key.data(), 0, buffer, 1, key.size());
            in.readFully(buffer, key.size() + 1, nonKeyPartSize - 1);
            row.setBuffer(buffer, key.size() + nonKeyPartSize);
        }

    }

    private NonKeyPartBuffer nonKeyPartBuffer = new NonKeyPartBuffer();

    private ByteArrayWritable binaryMiddleKey;

    private KeyCellBinaryComparator keyComparator;

    private final BlockDataReader blockDataReader;

    final SparseIndex sparseIndex;

    final NativeRamBloomFilter bloomFilter;

    //can only be constructed in the same package
    SSTableReader(SSTable ssTable, BlockDataReader blockDataReader,
            SparseIndex sparseIndex, NativeRamBloomFilter bloomFilter,
            KeyCellBinaryComparator keyComparator,
            ByteArrayWritable binaryMiddleKey) {
        this.sstable = ssTable;
        this.blockDataReader = blockDataReader;
        this.sparseIndex = sparseIndex;
        this.bloomFilter = bloomFilter;
        this.keyComparator = keyComparator;
        this.binaryMiddleKey = binaryMiddleKey;
    }

    public boolean first(ByteArrayWritable key, ByteArrayWritable value)
            throws IOException {
        IndexStruct index = sparseIndex.first();
        loadIndexedBlock(index);

        // if BOTTOM_REF, the real first should be seeked. 
        // we seek until fetch the real first and count. then redo the process 
        // and not read the real first
        if (sstable.getSsType() == SSType.BOTTOM_REF) {
            while (next(key, value)) {
                if (keyComparator.compare(key.data(), 0,
                        binaryMiddleKey.data(), 0) >= 0) {
                    return true;
                }
            }
            return false;
        } else {
            return next(key, value);
        }
    }

    public boolean next(ByteArrayWritable key, ByteArrayWritable value)
            throws IOException {
        if (currentIndex == null) {
            throw new LogicException(
                    "The reader is not initialized, table should be seeked before invoke 'next' method");
        }
        //using the min key to search current block, it will return iff read the next key
        return blockSeekAndRead(currentIndex.key, key, value, true);
    }

    private ByteArrayWritable tmpKey = new ByteArrayWritable();

    /**
     * Atomically seek to a position and read.
     * 
     * @param key
     * @param val
     * @return
     * @throws IOException
     */
    public boolean get(ByteArrayWritable key, ByteArrayWritable val)
            throws IOException {
        if (!checkBloomFilter(key)) {
            return false;
        }

        if (seekAndRead(key, tmpKey, val, false)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Try to seek to the key specified by <b>toSearch</b>.
     * <ul>
     * <li>If the key exists, seek to it, read the record and fill it in
     * <b>key</b> and <b>value</b>.</li>
     * <li>If the key doesn't exist, and <b>seekNextWhenNotFound</b>==true, will
     * seek to the record whose key is the smallest of those greater than
     * <b>toSearch</b>, and fill <b>key</b> and <b>value</b> with the record.</li>
     * <li>Otherwise, will do nothing</li>
     * </ul>
     * 
     * @param toSearch
     *            the key to search
     * @param key
     * @param value
     *            combine key and nonKeyPart together
     * @param seekNextWhenNotFound
     * @return if seekNextWhenNotFound is set to true, will return false iff we
     *         reach the end of file(means we have nothing to read). otherwise
     *         return true if toSearch is found, and false if not found
     * @throws IOException
     */
    public boolean seekAndRead(ByteArrayWritable toSearch,
            ByteArrayWritable key, ByteArrayWritable value,
            boolean seekNextWhenNotFound) throws IOException {
        IndexStruct index = sparseIndex.getIndex(toSearch, keyComparator);

        //search key exactly, but the start key is already bigger than toSearch
        if (keyComparator.compare(index.key.data(), 0, toSearch.data(), 0) > 0
                && !seekNextWhenNotFound) {
            return false;
        }

        loadIndexedBlock(index);

        return blockSeekAndRead(toSearch, key, value, seekNextWhenNotFound);
    }

    private void loadIndexedBlock(IndexStruct index) throws IOException {
        //current block is what you want, just reset the stream point
        if (currentIndex != null && index.index == currentIndex.index) {
            ((InputStream) currentBlockDataInput).reset();
        } else {
            if (currentBlockDataInput != null) {
                currentBlockDataInput.dropBlock();
                currentBlockDataInput = null;
            }
            currentIndex = index;
            currentBlockDataInput = decompressBlock();
        }
    }

    private IntWritable blockOriginLength = new IntWritable();

    private ByteArrayWritable blockBuffer = new ByteArrayWritable();

    private byte[] decompressedBlockBuffer;

    private BlockDataInput cacheBlockAndCreateBlockDataInput(int blockIndex,
            byte[] block, int off, int len, boolean cache) {
        if (cache) {
            BlockCache.BlockCacheEntry blockCache = sstable.ts.blockCache.cacheBlock(
                    sstable, blockIndex, block, off, len);
            if (blockCache != null) {
                return new NativeRamBlockDataInput(blockCache,
                        sstable.ts.blockCache.getChunkSize());
            }
        }
        return new HeapBlockDataInput(block, off, len);
    }

    private boolean blockCacheEnabled(int readBlockResult) throws IOException {
        try {
            return readBlockResult == -1 && blockDataReader.isUseRandomRead()
                    && sstable.getTableDesc().getBlockCacheEnabled();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "get block cache enabled failed", e);
            return false;
        }
    }

    /**
     * Get Indexed block, decompress the block and return it as DataInput
     * 
     * @return the stream, else exception
     * @throws IOException
     */
    private BlockDataInput decompressBlock() throws IOException {
        BlockCache.BlockCacheEntry blockCache = sstable.ts.blockCache.getBlock(
                sstable, currentIndex.index);
        if (blockCache != null) {
            return new NativeRamBlockDataInput(blockCache,
                    sstable.ts.blockCache.getChunkSize());
        }
        int readBlockResult = blockDataReader.readBlock(currentIndex,
                blockOriginLength, blockBuffer);
        if (readBlockResult == 0) {
            throw new IOException(
                    "Can not read block data from data file: arrive the end of file.");
        }
        int originLength = blockOriginLength.get();
        CompressType cType = sstable.metaData.getCompressType();
        if (cType == CompressType.NULL) {
            if (originLength != blockBuffer.size()) {
                throw new IOException(
                        "The actual length of block is not matched with discription of the key.");
            }
            return cacheBlockAndCreateBlockDataInput(currentIndex.index,
                    blockBuffer.data(), 0, blockBuffer.size(),
                    blockCacheEnabled(readBlockResult));
        } else {
            if (decompressedBlockBuffer == null
                    || decompressedBlockBuffer.length < originLength) {
                decompressedBlockBuffer = new byte[originLength];
            }
            if (sstable.metaData.getCompressType() == CompressType.LZO) {
                int dataLen = LzoCompression.uncompress(blockBuffer.data(), 0,
                        blockBuffer.getByteLength(), decompressedBlockBuffer);
                if (dataLen <= 0) {
                    throw new IOException(
                            "Error while uncompress lzo block. uncompress result: "
                                    + dataLen);
                }
                if (dataLen != originLength) {
                    throw new IOException(
                            "The actual length of block is not matched with discription of the key.");
                }
            } else if (sstable.metaData.getCompressType() == CompressType.GZIP) { //GZIP
                GZIPInputStream gzipInputStream = new GZIPInputStream(
                        new ByteArrayInputStream(blockBuffer.data(), 0,
                                blockBuffer.getByteLength()));
                try {
                    int offset = 0;
                    while (offset < originLength) {
                        int res = gzipInputStream.read(decompressedBlockBuffer,
                                offset, originLength - offset);
                        if (res <= 0) {
                            break;
                        }
                        offset += res;
                    }
                    if (offset != originLength) {
                        throw new IOException(
                                "The actual length of block is not matched with discription of the key.");
                    }
                } finally {
                    gzipInputStream.close();
                }
            } else {
                throw new RuntimeException("Why are you here?");
            }
            return cacheBlockAndCreateBlockDataInput(currentIndex.index,
                    decompressedBlockBuffer, 0, originLength,
                    blockCacheEnabled(readBlockResult));
        }
    }

    /**
     * This is for seek compressed datablock
     * 
     * @return
     */
    private boolean blockSeekAndRead(ByteArrayWritable toSearch,
            ByteArrayWritable key, ByteArrayWritable value,
            boolean seekNextWhenNotFound) throws IOException {
        while (((InputStream) currentBlockDataInput).available() > 0) {
            key.readFields(currentBlockDataInput);
            if (DataCell.isInvalid(key.data(), 0)) {
                LOG.warning("got invalid key cell in sstable " + sstable);
                key.skipFields(currentBlockDataInput);
                continue;
            }
            int comp = keyComparator.compare(key.data(), 0, toSearch.data(), 0);
            //not arrived
            if (comp < 0) {
                key.skipFields(currentBlockDataInput);
                continue;
            }
            //comp > 0, get rid of seekNextWhenNotFound and check range
            else if (comp > 0) {
                if (!seekNextWhenNotFound || isOutOfRange(key)) {
                    return false;
                }
            }
            //comp == 0 or ( comp >0 && seekNextWhenNotFound == true && in range)
            nonKeyPartBuffer.key = key;
            nonKeyPartBuffer.row = value;
            nonKeyPartBuffer.readFields(currentBlockDataInput);
            nonKeyPartBuffer.key = null;
            nonKeyPartBuffer.row = null;
            return true;
        }

        //Not in this block. if seekNextWhenNotFound, the first key of the next block should be returned
        if (seekNextWhenNotFound) {
            IndexStruct index = sparseIndex.getNextIndex(currentIndex);
            //have next block
            if (index != null) {
                //This judgment is just for debug, index.key should be greater than toSearch
                if (OmapConfig.debug
                        && keyComparator.compare(index.key.data(), 0,
                                toSearch.data(), 0) <= 0) {
                    throw new LogicException(
                            "There are logic errors, all the keys in next block should be greater than toSearch");
                }
                loadIndexedBlock(index);
                boolean res = blockSeekAndRead(toSearch, key, value,
                        seekNextWhenNotFound);
                //This judgment is just for debug
                if (OmapConfig.debug
                        && keyComparator.compare(key.data(), 0,
                                index.key.data(), 0) != 0) {
                    throw new LogicException("Logic error for " + sstable.path
                            + ", block " + index + ", actual start key is "
                            + key);
                }
                return res;
            }
        }
        return false;
    }

    private boolean isOutOfRange(ByteArrayWritable key) throws IOException {
        return sstable.getSsType() == SSType.TOP_REF
                && keyComparator.compare(key.data(), 0, binaryMiddleKey.data(),
                        0) >= 0;
    }

    private boolean checkBloomFilter(ByteArrayWritable key) {
        return bloomFilter == null
                || bloomFilter.contains(key.data(), key.getByteLength());
    }

    BlockDataReader close() {
        sparseIndex.release();
        if (bloomFilter != null) {
            bloomFilter.release();
        }
        if (currentBlockDataInput != null) {
            currentBlockDataInput.dropBlock();
            currentBlockDataInput = null;
        }
        return blockDataReader;
    }

    @Override
    public String toString() {
        return "[SSTableReader path=" + sstable.getODFSFile() + "]";
    }
}
