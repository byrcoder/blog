package outfox.omap.client.protocol.mock;

import java.util.Arrays;
import java.util.Map;

import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Query;

public class MockOmapMetadata implements Metadata {

    private String tableName;

    private String[] colNames;

    private String[] colTypes;

    private Map<String, ? extends Query> queries;

    public MockOmapMetadata(String tableName, String[] colNames,
            String[] colTypes, Map<String, ? extends Query> queries) {
        this.colNames = colNames;
        this.colTypes = colTypes;
        this.tableName = tableName;
        this.queries = queries;
    }

    @Override
    public String getAttributes() {
        return null;
    }

    @Override
    public String[] getColumnNames() {
        return colNames;
    }

    @Override
    public int getColumnNum() {
        return colNames.length;
    }

    @Override
    public Class<?>[] getColumnTypeClasses() {
        Class<?>[] ret = new Class[colTypes.length];
        for (int i = 0; i < colTypes.length; i++) {
            ret[i] = TypeUtils.getClass(colTypes[i]);
        }
        return ret;
    }

    @Override
    public String[] getColumnTypes() {
        return colTypes;
    }

    @Override
    public Map<String, ? extends Query> getQueries() {
        return queries;
    }

    @Override
    public String getTableName() {
        return tableName;
    }

    public int getColumnIndex(String columnName) {
        for (int i = 0; i < colNames.length; i++) {
            if (colNames[i].equals(columnName)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public String toString() {
        return "MockOmapMetadata [tableName=" + tableName + ", colNames="
                + Arrays.toString(colNames) + ", colTypes="
                + Arrays.toString(colTypes) + ", queries=" + queries + "]";
    }

}
