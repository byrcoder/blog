/**
 * @(#)Updater.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public abstract class Updater {

    protected final String vaqueroPropName;

    public Updater(String vaqueroPropName) {
        this.vaqueroPropName = vaqueroPropName;
    }

    public String getVaqueroPropName() {
        return vaqueroPropName;
    }

    public abstract void update(long[] metricsRecords, long prevTime,
            long currentTime);

    public abstract double getValue();
}
