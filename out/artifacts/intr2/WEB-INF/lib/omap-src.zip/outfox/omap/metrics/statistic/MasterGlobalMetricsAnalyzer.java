/**
 * @(#)MasterGlobalMetricsAnalyzer.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.MasterMetricsType;
import outfox.omap.metrics.TimeRangeUtils;

/**
 * @author zhangduo
 */
public class MasterGlobalMetricsAnalyzer {
    private long[] metricsRecords = new long[MasterMetricsType.globalTypeCount()];

    private double[] statisticResults = new double[MasterGlobalStatisticType.getTypeCount()];

    private long count;

    public void process(long[] metricsRecords) {
        for (int i = 0; i < MasterMetricsType.globalTypeCount(); i++) {
            this.metricsRecords[i] += metricsRecords[i];
        }
        count++;
    }

    public void done() {
        statisticResults[MasterGlobalStatisticType.GET_FS_NAME_COUNT.offset()] = metricsRecords[MasterMetricsType.GLOBAL_GET_FS_NAME_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GLOBAL_GET_FS_NAME_COUNT.offset()] > 0) {
            statisticResults[MasterGlobalStatisticType.GET_FS_NAME_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_GET_FS_NAME_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GLOBAL_GET_FS_NAME_COUNT.offset()];
        } else {
            statisticResults[MasterGlobalStatisticType.GET_FS_NAME_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterGlobalStatisticType.TIME_RANGE_GET_FS_NAME_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_FS_NAME_COUNT.offset()
                    + i];
        }

        statisticResults[MasterGlobalStatisticType.GET_TABLES_COUNT.offset()] = metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_COUNT.offset()] > 0) {
            statisticResults[MasterGlobalStatisticType.GET_TABLES_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_COUNT.offset()];
        } else {
            statisticResults[MasterGlobalStatisticType.GET_TABLES_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterGlobalStatisticType.TIME_RANGE_GET_TABLES_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_TABLES_COUNT.offset()
                    + i];
        }
        
        statisticResults[MasterGlobalStatisticType.GET_TABLES_IN_SPACE_COUNT.offset()] = metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset()] > 0) {
            statisticResults[MasterGlobalStatisticType.GET_TABLES_IN_SPACE_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset()];
        } else {
            statisticResults[MasterGlobalStatisticType.GET_TABLES_IN_SPACE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterGlobalStatisticType.TIME_RANGE_GET_TABLES_IN_SPACE_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_TABLES_IN_SPACE_COUNT.offset()
                    + i];
        }

        statisticResults[MasterGlobalStatisticType.CREATE_TABLE_COUNT.offset()] = metricsRecords[MasterMetricsType.GLOBAL_CREATE_TABLE_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GLOBAL_CREATE_TABLE_COUNT.offset()] > 0) {
            statisticResults[MasterGlobalStatisticType.CREATE_TABLE_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_CREATE_TABLE_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GLOBAL_CREATE_TABLE_COUNT.offset()];
        } else {
            statisticResults[MasterGlobalStatisticType.CREATE_TABLE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterGlobalStatisticType.TIME_RANGE_CREATE_TABLE_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_CREATE_TABLE_COUNT.offset()
                    + i];
        }

        statisticResults[MasterGlobalStatisticType.DELETE_TABLE_COUNT.offset()] = metricsRecords[MasterMetricsType.GLOBAL_DELETE_TABLE_COUNT.offset()];
        if (metricsRecords[MasterMetricsType.GLOBAL_DELETE_TABLE_COUNT.offset()] > 0) {
            statisticResults[MasterGlobalStatisticType.DELETE_TABLE_DELAY.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_DELETE_TABLE_DELAY.offset()]
                    / metricsRecords[MasterMetricsType.GLOBAL_DELETE_TABLE_COUNT.offset()];
        } else {
            statisticResults[MasterGlobalStatisticType.DELETE_TABLE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[MasterGlobalStatisticType.TIME_RANGE_DELETE_TABLE_COUNT.offset()
                    + i] = metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_DELETE_TABLE_COUNT.offset()
                    + i];
        }

        statisticResults[MasterGlobalStatisticType.SYSTEM_LOAD.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_SYSTEM_LOAD.offset()]
                / count;
        statisticResults[MasterGlobalStatisticType.SYSTEM_LOAD_PER_PROCESSOR.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_SYSTEM_LOAD.offset()]
                / metricsRecords[MasterMetricsType.GLOBAL_PROCESSOR_NUM.offset()];

        statisticResults[MasterGlobalStatisticType.MEMORY_INIT.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_MEMORY_INIT.offset()]
                / count;
        statisticResults[MasterGlobalStatisticType.MEMORY_USED.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_MEMORY_USED.offset()]
                / count;
        statisticResults[MasterGlobalStatisticType.MEMORY_COMMITTED.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_MEMORY_COMMITTED.offset()]
                / count;
        statisticResults[MasterGlobalStatisticType.MEMORY_MAX.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_MEMORY_MAX.offset()]
                / count;

        statisticResults[MasterGlobalStatisticType.REQUEST_COUNT.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_REQUEST_NUM.offset()];
        statisticResults[MasterGlobalStatisticType.TIMEOUT_REQUEST_COUNT.offset()] = (double) metricsRecords[MasterMetricsType.GLOBAL_TIMEOUT_REQUEST_NUM.offset()];
    }

    public double[] getStatisitcResults() {
        return statisticResults;
    }
}
