/**
 * @(#)BlockDataInput.java, 2012-5-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.DataInput;

import odis.io.Seekable;

/**
 * An interface for read block data.
 * 
 * @author zhangduo
 */
public interface BlockDataInput extends DataInput, Seekable {

    /**
     * Means we want to drop the block data. Especially useful for native ram
     * block cache to release native memory.
     */
    void dropBlock();
}
