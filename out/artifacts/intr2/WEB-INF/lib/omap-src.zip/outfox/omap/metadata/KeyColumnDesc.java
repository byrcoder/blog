package outfox.omap.metadata;

import java.lang.ref.WeakReference;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.BadTypeStringException;
import outfox.omap.exceptions.NoSuchTypeException;
import toolbox.collections.ArrayQueue;
import toolbox.misc.LogFormatter;

/**
 * A KeyColumnDesc defines a key column. Every table has one key column and one
 * or more non-key columns.
 * 
 * @author zhangkun
 */
public class KeyColumnDesc extends ColumnDesc implements IWritableComparable {

    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(KeyColumnDesc.class.getName());

    private ArrayQueue<WeakReference<KeyCell>> keyCellPool;

    private Object keyCellPoolLock = new Object();

    public KeyCell borrowKeyCell() {
        synchronized (keyCellPoolLock) {
            if (keyCellPool == null) {
                return createDataCell();
            }
            WeakReference<KeyCell> wr;
            while ((wr = keyCellPool.poll()) != null) {
                KeyCell kc = wr.get();
                if (kc != null) {
                    return kc;
                }
            }
            return createDataCell();
        }
    }

    public void returnKeyCell(KeyCell keyCell) {
        if (keyCell == null) {
            return;
        }
        synchronized (keyCellPoolLock) {
            if (keyCellPool == null) {
                keyCellPool = new ArrayQueue<WeakReference<KeyCell>>(200);
            }
            keyCellPool.offer(new WeakReference<KeyCell>(keyCell));
        }
    }

    public KeyColumnDesc() {
        super();
    }

    public KeyColumnDesc(String name, String typeString)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException, NoSuchTypeException, BadTypeStringException {
        super(name, typeString);
    }

    protected KeyColumnDesc(String name) {
        super(name);
    }

    public IWritableComparable getKey() {
        return (IWritableComparable) this.getBuffer();
    }

    public int compareTo(IWritable o) {
        return this.getKey().compareTo(((KeyColumnDesc) o).getKey());
    }

    /**
     * Just use ColumnDesc's equals because the added fields are used for
     * caching.
     */
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    /**
     * Just use ColumnDesc's equals because the added fields are used for
     * caching.
     */
    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public KeyCell createDataCell() {
        try {
            KeyCell ret = new KeyCell();
            if ((attr != null) && (attr.get(ATTR_CLIENT_TYPE) != null)) {
                ret.setClientType(attr.get(ATTR_CLIENT_TYPE));
            }
            ret.setBuffer(this.buffer.getClass().newInstance());
            // this ensures that the correct data type propergates to the data
            // cell
            ret.getBuffer().copyFields(this.buffer);
            ret.setInvalid();
            return ret;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
