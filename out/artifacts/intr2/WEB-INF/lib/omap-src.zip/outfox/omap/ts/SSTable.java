/**
 * @(#)SSTable.java, 2010-3-19. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FSDataInputStream;
import odis.io.FSInputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.ByteArrayWritable;

import org.apache.commons.lang.StringUtils;

import outfox.omap.client.protocol.CompressType;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.KeyCell;
import outfox.omap.metadata.KeyCellBinaryComparator;
import outfox.omap.metadata.KeyColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.metrics.TsGlobalMetricsEntry;
import outfox.omap.util.CloseableIterator;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * New SSTable, support data compress
 * 
 * @author wangfk, zhangduo
 */
public class SSTable {

    private static final Logger LOG = LogFormatter.getLogger(SSTable.class);

    /** The name of the index file. */
    public static final String SPARSE_INDEX_FILE_NAME = "index";

    /** The name of the data file. */
    public static final String DATA_FILE_NAME = "data";

    /** The name of the metadata file. */
    public static final String METADATA_FILE_NAME = "metadata";

    /** The name of the bloomfilter file */
    public static final String BLOOMFILTER_FILE_NAME = "bloomfilter";

    public static enum SSType {
        NORMAL, TOP_REF, BOTTOM_REF
    };

    private final SSType ssType;

    OmapTs ts;

    final Path path;

    final Path bloomfilterFile;

    final Path sparseIndexFile;

    final Path dataFile;

    final IWritableComparable middleKey;

    final ByteArrayWritable binaryMiddleKey;

    final KeyColumnDesc kcd;

    final long tabletId;

    final long fileId;

    // only cache random read pool
    private final BlockingQueue<BlockDataReader> readerPool;

    final MetaData metaData;

    private final AtomicInteger refCount = new AtomicInteger(1);

    /**
     * Class for reading meta data<br>
     * 
     * @author wangfk
     */
    public class MetaData {

        final Properties properties;

        public static final String NAME_ENTRY_COUNT = "EntryCount";

        private final long entryCount;

        public static final String NAME_SPARSE_INDEX_ENTRY_COUNT = "SparseIndexEntryCount";

        private final long sparseIndexEntryCount;

        public static final String NAME_COMPRESS_TYPE = "CompressType";

        private final CompressType compressType;

        public static final String NAME_DELETED_ENTRY_COUNT = "DeletedEntryCount";

        private final long deletedEntryCount;

        public static final String NAME_ORIGINAL_DATA_SIZE = "OriginalDataSize";

        private final long originalDataSize;

        public static final String NAME_DATA_FILE_SYNC = "DataFileSync";

        private final byte[] sync;

        private final long generatedTime;

        private final long indexFileSize;

        private final long dataSize;

        /**
         * Can only be constructed by {@link SSTable}
         * 
         * @throws IOException
         */
        private MetaData(FileSystem fs) throws IOException {
            generatedTime = fs.lastModified(path);
            Path indexFile = path.cat(SPARSE_INDEX_FILE_NAME);
            indexFileSize = OmapUtils.getFileSize(fs, indexFile);
            Path dataFile = path.cat(DATA_FILE_NAME);
            dataSize = OmapUtils.getFileSize(fs, dataFile);

            Path metaPath = path.cat(METADATA_FILE_NAME);
            FSInputStream in = null;
            FSDataInputStream dataIn = null;
            properties = new Properties();
            try {
                in = fs.openRaw(metaPath);
                in.setReadFromLocalHost(OmapConfig.getConfiguration().getBoolean(
                        OmapConfig.NAME_TS_READ_BLOCK_FROM_LOCALHOST,
                        OmapConfig.DEFAULT_TS_READ_BLOCK_FROM_LOCALHOST));
                dataIn = new FSDataInputStream(in);
                properties.load(dataIn);
                String value = properties.getProperty(NAME_ENTRY_COUNT);
                if (!StringUtils.isEmpty(value)) {
                    entryCount = Long.parseLong(value);
                } else {
                    throw new IOException("There are no " + NAME_ENTRY_COUNT
                            + " " + "info in meta file" + metaPath);
                }

                value = properties.getProperty(NAME_SPARSE_INDEX_ENTRY_COUNT);
                if (!StringUtils.isEmpty(value)) {
                    sparseIndexEntryCount = Long.parseLong(value);
                } else {
                    throw new IOException("There are no "
                            + NAME_SPARSE_INDEX_ENTRY_COUNT
                            + " info in meta file " + metaPath);
                }

                value = properties.getProperty(NAME_COMPRESS_TYPE);
                if (!StringUtils.isEmpty(value)) {
                    compressType = CompressType.toType(value);
                } else {
                    compressType = CompressType.NULL;
                    LOG.warning("There are no " + NAME_SPARSE_INDEX_ENTRY_COUNT
                            + " info in meta file " + metaPath
                            + ". Use default: " + compressType);
                }

                value = properties.getProperty(NAME_DELETED_ENTRY_COUNT);
                if (!StringUtils.isEmpty(value)) {
                    deletedEntryCount = Long.parseLong(value);
                } else {
                    deletedEntryCount = 0;
                    LOG.warning("There are no " + NAME_DELETED_ENTRY_COUNT
                            + " info in meta file " + metaPath + ". set to 0");
                }

                value = properties.getProperty(NAME_ORIGINAL_DATA_SIZE);
                if (!StringUtils.isEmpty(value)) {
                    originalDataSize = Long.parseLong(value);
                } else {
                    LOG.warning("There are no " + NAME_DELETED_ENTRY_COUNT
                            + " info in meta file " + metaPath
                            + ". set to data size " + dataSize);
                    originalDataSize = dataSize;
                }
                value = properties.getProperty(NAME_DATA_FILE_SYNC);
                if (!StringUtils.isEmpty(value)) {
                    byte[] sync = HexString.hexToBytes(value);
                    if (sync.length != 16) {
                        LOG.warning("Sync length is not 16 in meta file "
                                + metaPath + ". set to null");
                        this.sync = null;
                    } else {
                        this.sync = sync;
                    }
                } else {
                    LOG.warning("There are no " + NAME_DATA_FILE_SYNC
                            + " info in meta file " + metaPath
                            + ". set to null");
                    sync = null;
                }
            } finally {
                if (dataIn != null) {
                    OmapUtils.safeClose(dataIn);
                } else {
                    OmapUtils.safeClose(in);
                }
            }
        }

        // only used for testcase
        private MetaData() {
            this.properties = new Properties();
            this.entryCount = 0;
            this.sparseIndexEntryCount = 0;
            this.compressType = CompressType.NULL;
            this.deletedEntryCount = 0;
            this.originalDataSize = 0;
            this.sync = SequenceFile.getSync();
            this.generatedTime = 0;
            this.indexFileSize = 0;
            this.dataSize = 0;
        }

        public long getEntryCount() {
            return entryCount;
        }

        public long getSparseIndexEntryCount() {
            return sparseIndexEntryCount;
        }

        public CompressType getCompressType() {
            return compressType;
        }

        public long getDataSize() {
            return dataSize;
        }

        public long getOriginalDataSize() {
            return originalDataSize;
        }

        public long getGeneratedTime() {
            return generatedTime;
        }

        public String getProperty(String name) {
            return properties.getProperty(name);
        }

        public long getIndexFileSize() {
            return indexFileSize;
        }

        public long getDeletedEntryCount() {
            return deletedEntryCount;
        }

        public byte[] getSync() {
            return sync;
        }

    }

    /**
     * Only used for testcase
     * 
     * @param path
     */
    SSTable(OmapTs ts, Path path, long tabletId, long fileId) {
        this.ts = ts;
        this.ssType = SSType.NORMAL;
        this.tabletId = tabletId;
        this.fileId = fileId;
        this.path = path;
        this.bloomfilterFile = path.cat(BLOOMFILTER_FILE_NAME);
        this.sparseIndexFile = path.cat(SPARSE_INDEX_FILE_NAME);
        this.dataFile = path.cat(DATA_FILE_NAME);
        this.middleKey = null;
        this.metaData = new MetaData();
        this.kcd = null;
        this.binaryMiddleKey = null;
        readerPool = null;
    }

    public SSTable(OmapTs ts, long tabletId, long fileId) throws IOException {
        this(ts, tabletId, fileId, SSType.NORMAL, null);
    }

    public SSTable(OmapTs ts, long tabletId, long fileId, SSType ssType,
            IWritableComparable middleKey) throws IOException {
        this.ts = ts;
        this.ssType = ssType;
        switch (ssType) {
            case TOP_REF:
                path = new Path(Tablet.getTopREFTableFilePath(ts, tabletId,
                        fileId));
                break;
            case BOTTOM_REF:
                path = new Path(Tablet.getBottomREFTableFilePath(ts, tabletId,
                        fileId));
                break;
            default:
                path = new Path(Tablet.getSSTableFilePath(ts, tabletId, fileId));
                break;
        }

        this.bloomfilterFile = path.cat(BLOOMFILTER_FILE_NAME);
        this.sparseIndexFile = path.cat(SPARSE_INDEX_FILE_NAME);
        this.dataFile = path.cat(DATA_FILE_NAME);
        this.tabletId = tabletId;
        this.fileId = fileId;
        this.middleKey = middleKey;
        KeyColumnDesc kcd = ts.metaCache.getMetadata(
                OmapUtils.tid2sid(tabletId)).getTableDesc().getKey();
        if (middleKey != null) {
            KeyCell key = kcd.borrowKeyCell();
            key.setIWritable(middleKey);
            this.binaryMiddleKey = new ByteArrayWritable(
                    OmapUtils.convertPIWritableToBytes(key));
            kcd.returnKeyCell(key);
        } else {
            this.binaryMiddleKey = null;
        }
        this.kcd = kcd;
        metaData = new MetaData(ts.dfs);
        readerPool = new ArrayBlockingQueue<BlockDataReader>(4);
    }

    private volatile boolean closed = false;

    public boolean isReference() {
        return ssType != SSType.NORMAL;
    }

    public boolean isTopRef() {
        return ssType == SSType.TOP_REF;
    }

    public boolean isBottomRef() {
        return ssType == SSType.BOTTOM_REF;
    }

    public static final Comparator<SSTable> COMPARATOR = new Comparator<SSTable>() {

        @Override
        public int compare(SSTable o1, SSTable o2) {
            boolean ref1 = o1.isReference();
            boolean ref2 = o2.isReference();
            if (ref1 && !ref2) {
                return -1;
            } else if (!ref1 && ref2) {
                return 1;
            } else {
                return o1.fileId > o2.fileId ? 1 : o1.fileId == o2.fileId ? 0
                        : -1;
            }
        }
    };

    public long getFileId() {
        return fileId;
    }

    public Path getODFSFile() {
        return path;
    }

    public long getIndexFileSize() {
        return metaData.getIndexFileSize();
    }

    public long getLoadedIndexSize() {
        return ts.indexPool.getLoadedIndexSize(this);
    }

    public SparseIndex loadSparseIndex() throws IOException {
        return ts.indexPool.loadIndex(this);
    }

    public NativeRamBloomFilter loadBloomfilter() {
        return ts.filterPool.loadBloomFilter(this);
    }

    public long getLoadedBloomFilterSize() {
        return ts.filterPool.getLoadedBloomFilterSize(this);
    }

    public long numKeys() {
        return metaData.getEntryCount();
    }

    public long deletedNumKeys() {
        return metaData.getDeletedEntryCount();
    }

    /**
     * ref sstable will divide by 2
     * 
     * @return
     * @throws IOException
     */
    public long actualNumKeys() {
        if (isReference()) {
            return numKeys() / 2;
        } else {
            return numKeys();
        }
    }

    /**
     * ref sstable will divide by 2
     * 
     * @return
     */
    public long actualDeletedNumKeys() {
        if (isReference()) {
            return deletedNumKeys() / 2;
        } else {
            return deletedNumKeys();
        }
    }

    public long dataSize() {
        return metaData.getDataSize();
    }

    /**
     * ref sstable will divide by 2
     * 
     * @return
     * @throws IOException
     */
    public long actualDataSize() {
        long ret = dataSize();
        if (isReference()) {
            return ret / 2;
        } else {
            return ret;
        }
    }

    public long originalDataSize() {
        return metaData.getOriginalDataSize();
    }

    public long actualOriginalDataSize() {
        long ret = originalDataSize();
        if (isReference()) {
            return ret / 2;
        } else {
            return ret;
        }
    }

    /**
     * First key in the file(also the first key in sparseIndex).
     * 
     * @param key
     * @throws IOException
     */
    public void getFirstKey(KeyCell key) throws IOException {
        ByteArrayWritable binaryKey;
        SparseIndex index = loadSparseIndex();
        try {
            binaryKey = index.getFirstKey();
        } finally {
            index.release();
        }
        OmapUtils.convertBytesToPIWritable(binaryKey.data(), 0,
                binaryKey.size(), key);
    }

    /**
     * Last key in sparseIndex
     * 
     * @param key
     * @throws IOException
     */
    public void getLastIndexKey(KeyCell key) throws IOException {
        ByteArrayWritable binaryKey;
        SparseIndex index = loadSparseIndex();
        try {
            binaryKey = index.getLastKey();
        } finally {
            index.release();
        }
        OmapUtils.convertBytesToPIWritable(binaryKey.data(), 0,
                binaryKey.size(), key);
    }

    /**
     * Last key in the file.
     * 
     * @param key
     * @throws IOException
     */
    public void getLastKey(KeyCell key) throws IOException {
        ByteArrayWritable lastKey;
        SparseIndex index = loadSparseIndex();
        try {
            lastKey = index.getLastKey();
        } finally {
            index.release();
        }
        ByteArrayWritable binaryKey = new ByteArrayWritable();
        ByteArrayWritable binaryValue = new ByteArrayWritable();
        SSTableReader reader = borrowReader(true);
        try {
            reader.seekAndRead(lastKey, binaryKey, binaryValue, true);
            while (reader.next(binaryKey, binaryValue));
        } finally {
            returnReader(reader);
        }
        OmapUtils.convertBytesToPIWritable(binaryKey.data(), 0,
                binaryKey.size(), key);

    }

    /**
     * Middle key in spardeIndex
     * 
     * @param key
     * @return
     * @throws IOException
     */
    public void getMiddleIndexKey(KeyCell key) throws IOException {
        ByteArrayWritable binaryKey;
        SparseIndex index = loadSparseIndex();
        try {
            binaryKey = index.getMidKey();
        } finally {
            index.release();
        }
        OmapUtils.convertBytesToPIWritable(binaryKey.data(), 0,
                binaryKey.size(), key);
    }

    public TsGlobalMetricsEntry getTsGlobalMetricsEntry() {
        return ts.globalMetricsEntry;
    }

    private SSTableReader createReader(BlockDataReader blockDataReader)
            throws IOException {
        SparseIndex sparseIndex = loadSparseIndex();
        NativeRamBloomFilter filter = loadBloomfilter();
        KeyCellBinaryComparator keyComparator = new KeyCellBinaryComparator(kcd);
        return new SSTableReader(this, blockDataReader, sparseIndex, filter,
                keyComparator, binaryMiddleKey);
    }

    public SSTableReader borrowReader(boolean useRandomRead) throws IOException {
        if (closed) {
            throw new IllegalStateException("SSTable " + path
                    + " already closed");
        }
        BlockDataReader blockDataReader;
        if (!useRandomRead) {
            blockDataReader = new BlockDataReader(this, false,
                    ts.globalMetricsEntry);
        } else {
            blockDataReader = readerPool.poll();
            if (blockDataReader == null) {
                blockDataReader = new BlockDataReader(this, true,
                        ts.globalMetricsEntry);
            }
        }
        boolean succ = false;
        try {
            SSTableReader reader = createReader(blockDataReader);
            succ = true;
            refCount.incrementAndGet();
            return reader;
        } finally {
            if (!succ) {
                returnReader(blockDataReader);
            }
        }
    }

    private void returnReader(BlockDataReader reader) {
        if (closed || !reader.isUseRandomRead()) {
            OmapUtils.safeClose(reader);
        } else {
            if (!readerPool.offer(reader)) {
                OmapUtils.safeClose(reader);
            }
        }
    }

    public void returnReader(SSTableReader reader) {
        BlockDataReader blockDataReader = reader.close();
        returnReader(blockDataReader);
        tryDelete();
    }

    public SSType getSsType() {
        return ssType;
    }

    public MetaData getMetaData() {
        return metaData;
    }

    public CloseableIterator<ByteArrayWritable> iterator(boolean useRandomRead)
            throws IOException {
        return iterator(null, useRandomRead);
    }

    public CloseableIterator<ByteArrayWritable> iterator(KeyCell startKey,
            boolean useRandomRead) throws IOException {
        return new SSTableIterImpl(this, startKey, useRandomRead);
    }

    /**
     * The implement of the SSTable iterator. Adapter to SSTableReader
     * 
     * @author wangfk
     */
    private class SSTableIterImpl implements
            CloseableIterator<ByteArrayWritable> {
        private SSTableReader reader;

        private KeyCell startKey;

        private ByteArrayWritable tmpKey;

        private boolean read = false;

        public SSTableIterImpl(SSTable sst, KeyCell startKey,
                boolean useRandomRead) throws IOException {
            this.startKey = startKey;
            this.reader = borrowReader(useRandomRead);
        }

        private boolean firstRead(ByteArrayWritable value) throws IOException {
            tmpKey = new ByteArrayWritable();
            boolean result;
            if (startKey != null) {
                result = reader.seekAndRead(
                        new ByteArrayWritable(
                                OmapUtils.convertPIWritableToBytes(startKey)),
                        tmpKey, value, true);
            } else {
                result = reader.first(tmpKey, value);
            }
            read = true;
            return result;
        }

        @Override
        public boolean next(ByteArrayWritable value) throws IOException {
            if (!read) {
                return firstRead(value);
            } else {
                return reader.next(tmpKey, value);
            }
        }

        @Override
        public synchronized void close() throws IOException {
            if (reader != null) {
                returnReader(reader);
                reader = null;
            }
        }
    }

    String getBlockNameByIdx(int idx) {
        return Long.toHexString(tabletId) + "-" + fileId + "-" + idx;
    }

    public void unload() {
        List<BlockDataReader> toClose = new ArrayList<BlockDataReader>();
        readerPool.drainTo(toClose);
        for (BlockDataReader reader: toClose) {
            OmapUtils.safeClose(reader);
        }
        ts.filterPool.unloadBloomFilter(this);
        ts.indexPool.unloadIndex(this);
        ts.blockCache.evictBlock(this);
        ts.sstableDataFileCache.releaseCache(path);
    }

    private void tryDelete() {
        if (refCount.decrementAndGet() == 0) {
            unload();
            LOG.info("Deleting " + path);
            try {
                ts.dfs.delete(path);
            } catch (IOException e) {
                LOG.log(Level.WARNING, "delete " + path + " failed", e);
            }
        }
    }

    /**
     * This is used for tablet migration or table deletion. We can make sure no
     * one will read this sstable after that time, so just release resources.
     * (But do not delete file).
     */
    public void close() {
        closed = true;
        unload();
    }

    /**
     * This is used for compaction. Someone may still reading this sstable when
     * compaction end, so we use refCount to deal with it.
     * 
     * @throws IOException
     */
    public void closeAndDelete() throws IOException {
        closed = true;
        tryDelete();
    }

    public String getCacheKey() {
        return HexString.longToPaddedHex(tabletId) + "-" + fileId + "."
                + metaData.generatedTime;
    }

    public TableDesc getTableDesc() throws IOException {
        return ts.getMetaCache().getMetadata(OmapUtils.tid2sid(tabletId)).getTableDesc();
    }

    public String toString() {
        return "[SSTable file=" + getODFSFile() + "]";
    }
}
