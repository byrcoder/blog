package outfox.omap.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * IPreInitialiedWritable is similar to IWritable, which defines writeFields()
 * and readFields(). However, IPreInitialiedWritable doesn't output class information
 * in writePIFields(). Therefore if some fields of a IPreInitialiedWritable cannot
 * determine their types by the class definition, they must be initialized (i.e.
 * determine the actual type) before calling readPIFields().
 * @author zhangkun
 *
 */
public interface IPreInitializedWritable {
    /**
     * Read the fields from the DataInput. Before calling this method, the fields of this
     * object must be initialized.
     * @param in
     * @throws IOException
     */
    public void readPIFields(DataInput in) throws IOException;
    /**
     * Write the fields to the DataOutput.
     * @param out
     * @throws IOException
     */
    public void writePIFields(DataOutput out) throws IOException;
}
