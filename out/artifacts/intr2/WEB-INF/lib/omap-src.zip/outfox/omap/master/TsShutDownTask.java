package outfox.omap.master;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import outfox.omap.ts.OmapTs;
import toolbox.misc.LogFormatter;

public class TsShutDownTask extends Task {
    private static final Logger LOG = LogFormatter.getLogger(TsShutDownTask.class);
    private boolean checkpoint;
    @Override
    public int execTask(OmapTs ts) {
        LOG.info("Shutting down myself according to Master");
        ts.shutdown(checkpoint);
        return 0;
    }

    public TsShutDownTask() {}
    
    public TsShutDownTask(String reason, boolean checkpoint) {
        super(reason);
        this.checkpoint = checkpoint;
    }
    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        checkpoint = in.readBoolean();
    }
    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        out.writeBoolean(checkpoint);
    }
    @Override
    public IWritable copyFields(IWritable value) {
        super.copyFields(value);
        this.checkpoint = ((TsShutDownTask)value).checkpoint;
        return this;
    }
    @Override
    public String getTaskDetail() {
        return "SHUTDOWN: checkpoint=" + checkpoint;
    }

    public void rollbackTask(OmapTs ts) {
        // do nothing
    }

}
