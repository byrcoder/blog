/**
 * @(#)KeyCellBinaryComparator.java, 2010-11-25. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metadata;

import java.io.DataInput;
import java.io.IOException;

import odis.io.CDataInputStream;
import outfox.omap.data.KeyCell;
import outfox.omap.util.ReusableByteArrayInputStream;

/**
 * Compares two byte arrays written by KeyCell.writePIFields(). It will borrow
 * two KeyCell objects from the KeyColumnDesc. When finishing comparison,
 * Remember to return the KeyCell objects by calling {@link #close()} <br>
 * NOTE: this is not thread-safe.
 * 
 * @author zhangduo, zhangkun
 */
public class KeyCellBinaryComparator {
    private KeyCell key1;

    private KeyCell key2;

    private ReusableByteArrayInputStream byteIn;

    private CDataInputStream dataIn;

    private KeyColumnDesc cd;

    public KeyCellBinaryComparator(KeyColumnDesc cd) {
        this.cd = cd;
        this.key1 = cd.borrowKeyCell();
        this.key2 = cd.borrowKeyCell();
        byteIn = new ReusableByteArrayInputStream();
        dataIn = new CDataInputStream(byteIn);
    }

    public int compare(byte[] o1, int offset1, byte[] o2, int offset2)
            throws IOException {
        byteIn.setBuffer(o1, offset1, o1.length - offset1);
        key1.readPIFields(dataIn);
        byteIn.setBuffer(o2, offset2, o2.length - offset2);
        key2.readPIFields(dataIn);
        return key1.compareTo(key2);
    }

    public int compare(DataInput o1, byte[] o2, int offset2) throws IOException {
        key1.readPIFields(o1);
        byteIn.setBuffer(o2, offset2, o2.length - offset2);
        key2.readPIFields(dataIn);
        return key1.compareTo(key2);
    }

    public int compare(byte[] o1, int offset1, DataInput o2) throws IOException {
        byteIn.setBuffer(o1, offset1, o1.length - offset1);
        key1.readPIFields(dataIn);
        key2.readPIFields(o2);
        return key1.compareTo(key2);
    }

    public void close() {
        cd.returnKeyCell(key1);
        cd.returnKeyCell(key2);
    }
}
