/**
 * @(#)OpAvg.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public class OpAvg extends Updater {

    private final double normalizer;

    private final int metricsOpIndex;

    private final int metricsDivisorIndex;

    private double value;

    public OpAvg(String vaqueroPropName, int metricsOpIndex,
            int metricsDivisorIndex) {
        this(vaqueroPropName, metricsOpIndex, metricsDivisorIndex, 1.0);
    }

    public OpAvg(String vaqueroPropName, int metricsOpIndex,
            int metricsDivisorIndex, double normalizer) {
        super(vaqueroPropName);
        this.metricsOpIndex = metricsOpIndex;
        this.metricsDivisorIndex = metricsDivisorIndex;
        this.normalizer = normalizer;
    }

    @Override
    public double getValue() {
        return value;
    }

    @Override
    public void update(long[] metricsRecords, long prevTime, long currentTime) {
        value = (double) metricsRecords[metricsOpIndex]
                / metricsRecords[metricsDivisorIndex] / normalizer;
    }
}
