package outfox.omap.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

import odis.serialize.lib.BooleanWritable;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.UTF8Writable;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.exceptions.OmapException;
import toolbox.misc.cli.Options;

public class RandomTest extends Thread {

    private static final int DEFAULT_SCALE = 10000;

    private static final int DEFAULT_THREAD_NUM = 1;

    private static final long DEFAULT_DURATION = 10 * 60 * 1000;

    private static final int BATCH_RECORDS_NUM = 100;

    private static final String TABLE_NAME_PREFIX = "RandomTestTable";

    private final String COLUMN_5_PREFIX = "This is a record of a test, and I am a prefix of a column, and after me is the value: ";

    private String tableName;

    private int scale;

    private long duration;

    private OmapTableSpace space;

    private Table table;

    private HashMap<Long, Long> checkValues;

    private Random random;

    private String[] colNames = new String[] {
        "key", "column1", "column2", "column3", "column4", "column5",
        "column6",
    };

    private String[] colTypes = new String[] {
        "LONG", "LONG", "BOOLEAN", "INTEGER", "DOUBLE", "STRING", "STRING",
    };

    public RandomTest(String tableName, int scale, long duration)
            throws OmapException {
        this.tableName = tableName;
        this.scale = scale;
        this.duration = duration;
        checkValues = new HashMap<Long, Long>();
        random = new Random();
        try {
            space = new OmapTableSpace("test",
                    new MasterWatcherAndClientConfig(new ClientConfig(
                            "omap.xml")));
        } catch (IOException e) {
            throw new OmapException(e);
        }
        createTable();
    }

    private void createTable() throws OmapException {
        if (space.findTable(tableName) == null) {
            table = space.createTable(tableName, colNames, colTypes);
        } else {
            table = space.openTable(tableName);
        }
    }

    public void run() {
        try {
            long insertCounter = 0;
            long deleteCounter = 0;
            long checkCounter = 0;
            insertRecords(0, scale);
            System.out.println(tableName + ": Total " + scale
                    + " records inserted for initialization.");
            long startTime = System.currentTimeMillis();
            while (System.currentTimeMillis() - startTime < duration) {
                int choice = random.nextInt(3);
                int startKey = random.nextInt(scale);
                switch (choice) {
                    case 1:
                        insertRecords(startKey, startKey + BATCH_RECORDS_NUM);
                        insertCounter += BATCH_RECORDS_NUM;
                        System.out.println(tableName + ": Insert "
                                + BATCH_RECORDS_NUM
                                + " records. Total insert: " + insertCounter);
                        break;
                    case 2:
                        deleteRecords(startKey, startKey + BATCH_RECORDS_NUM);
                        deleteCounter += BATCH_RECORDS_NUM;
                        System.out.println(tableName + ": Delete "
                                + BATCH_RECORDS_NUM
                                + " records. Total delete: " + insertCounter);
                        break;
                    case 3:
                        checkRecords(startKey, startKey + BATCH_RECORDS_NUM);
                        checkCounter += BATCH_RECORDS_NUM;
                        System.out.println(tableName + ": Check "
                                + BATCH_RECORDS_NUM + " records. Total check: "
                                + insertCounter);
                        break;
                }
            }
            checkRecords(0, scale);
            System.out.println(tableName + ": Total " + scale
                    + " records checked before finish.");
            long finishTime = System.currentTimeMillis();

            System.out.println(tableName + ": Test Finished.");
            System.out.println(tableName + ": Start at " + startTime);
            System.out.println(tableName + ": Finish at " + finishTime);
            System.out.println(tableName + ": Total time: "
                    + (finishTime - startTime) / 1000 + " s.");
            System.out.println(tableName + ": Total insert: " + insertCounter);
            System.out.println(tableName + ": Total delete: " + deleteCounter);
            System.out.println(tableName + ": Total check: " + checkCounter);
        } catch (OmapException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void insertRecords(long startKey, long endKey) throws OmapException {
        for (long i = startKey; i <= endKey; i++) {
            long checkValue = random.nextLong();
            checkValues.put(i, checkValue);
            Row row = table.newRow();
            row.setKey(new LongWritable(i));
            row.set("column1", getColumn1(i));
            row.set("column2", getColumn2(i));
            row.set("column3", getColumn3(i));
            row.set("column4", getColumn4(i));
            row.set("column5", getColumn5(i));
            row.set("column6", getColumn6(i));
            table.update(row);
        }
    }

    private void deleteRecords(long startKey, long endKey) throws OmapException {
        for (long i = startKey; i <= endKey; i++) {
            table.delete(new LongWritable(i));
            checkValues.remove(i);
        }
    }

    private void checkRecords(long startKey, long endKey) throws OmapException {
        Row row = table.newRow();
        LongWritable column1 = new LongWritable();
        BooleanWritable column2 = new BooleanWritable();
        IntWritable column3 = new IntWritable();
        DoubleWritable column4 = new DoubleWritable();
        UTF8Writable column5 = new UTF8Writable();
        UTF8Writable column6 = new UTF8Writable();
        for (long i = startKey; i <= endKey; i++) {
            boolean find = table.contains(new LongWritable(i));
            if (!checkValues.containsKey(i)) {
                assert find == false;
            } else {
                assert find == true;
                table.lookup(new LongWritable(i), row);
                row.get("column1", column1);
                assert column1.equals(getColumn1(i));
                row.get("column2", column2);
                assert column2.equals(getColumn2(i));
                row.get("column3", column3);
                assert column3.equals(getColumn3(i));
                row.get("column4", column4);
                assert column4.equals(getColumn4(i));
                row.get("column5", column5);
                assert column5.equals(getColumn5(i));
                row.get("column6", column6);
                assert column6.equals(getColumn6(i));
            }
        }
    }

    private LongWritable getColumn1(long key) {
        return new LongWritable(key + checkValues.get(key));
    }

    private BooleanWritable getColumn2(long key) {
        if (((key + checkValues.get(key)) % 2) == 1) {
            return new BooleanWritable(true);
        } else {
            return new BooleanWritable(false);
        }
    }

    private IntWritable getColumn3(long key) {
        return new IntWritable((int) ((key + checkValues.get(key)) % 1024));
    }

    private DoubleWritable getColumn4(long key) {
        return new DoubleWritable((key + checkValues.get(key)) / 1024.0);
    }

    private UTF8Writable getColumn5(long key) {
        return new UTF8Writable(COLUMN_5_PREFIX + (key + checkValues.get(key)));
    }

    private UTF8Writable getColumn6(long key) {
        StringBuilder urls = new StringBuilder();
        for (int i = 0; i < 100; i++) {
            urls.append("http://").append(key + checkValues.get(key)).append(
                    ".testurl.com/testurlspage");
        }
        return new UTF8Writable(urls.toString());
    }

    private static void exec(String[] args) throws InterruptedException,
            OmapException {
        Options opts = new Options();
        opts.withOption("s", "scale",
                "scale of one test thread, number of max records.").setDefault(
                DEFAULT_SCALE);
        opts.withOption("n", "threadnum", "number of test threads.").setDefault(
                DEFAULT_THREAD_NUM);
        opts.withOption("t", "time", "time of this test in ms").setDefault(
                DEFAULT_DURATION);
        try {
            opts.parse(args);
        } catch (Exception e) {
            opts.printHelpInfo(System.out, "RandomTest");
        }
        int scale = opts.getIntOpt("s");
        int threadNum = opts.getIntOpt("n");
        long duration = opts.getLongOpt("t");
        RandomTest[] threads = new RandomTest[threadNum];
        for (int i = 0; i < threadNum; i++) {
            threads[i] = new RandomTest(TABLE_NAME_PREFIX + i, scale, duration);
            threads[i].start();
        }
        threads[threadNum - 1].join();

    }

    public static void main(String[] args) throws Exception {
        exec(args);
    }

}
