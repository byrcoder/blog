package outfox.omap.master;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.collections.ExtendedProperties;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.apache.velocity.tools.view.servlet.VelocityViewServlet;

import outfox.omap.client.OmapMetadata;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.KeyRange;
import outfox.omap.metadata.TableDesc;
import outfox.omap.ts.LoadValue;
import outfox.omap.ts.TsUsageReport;
import outfox.omap.util.OmapLogFormatter;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.PrintUtils;
import outfox.omap.util.SystemInfoUtils;
import toolbox.text.util.HexString;
import toolbox.web.WebServer;

public class InspectorServlet extends VelocityViewServlet {
    private static final long serialVersionUID = 3293834238257481397L;

    private static final Logger LOG = OmapLogFormatter.getLogger(InspectorServlet.class);

    static OmapMaster master;

    public static class RWCount {
        private long readCount;

        private long writeCount;

        private long keyCount;

        public long getReadCount() {
            return readCount;
        }

        public long getWriteCount() {
            return writeCount;
        }

        public long getKeyCount() {
            return keyCount;
        }
    }

    private HashMap<Long, RWCount> lastTabletRWCount = new HashMap<Long, RWCount>();

    private long lastTabletRWRecordStamp;

    private HashMap<Long, RWCount> lastTableRWCount = new HashMap<Long, RWCount>();

    private long lastTableRWRecordStamp;

    private HashMap<TsDesc, RWCount> lastTsRWCount = new HashMap<TsDesc, RWCount>();

    private long lastTsRWRecordStamp;

    public class MyPrintUtils extends PrintUtils {
        private URLCodec codec = new URLCodec();

        public String getSortParam(String key) {
            StringBuilder res = new StringBuilder("&sort=" + key);
            if (!key.equalsIgnoreCase(sortKey)) {
                res.append("&decr=true");
            } else {
                res.append("&decr=").append(Boolean.toString(increase));
            }

            for (Map.Entry<String, String> entry: queryParams.get().entrySet()) {
                try {
                    res.append('&').append(entry.getKey()).append('=').append(
                            codec.encode(entry.getValue()));
                } catch (EncoderException e) {
                    LOG.log(Level.WARNING, "Can not format url", e);
                }
            }
            return res.toString();
        }

        public String getSortComment(String key, String text) {
            if (key.equalsIgnoreCase(sortKey)) {
                if (increase)
                    return "<b>" + text + "&uarr;" + "</b>";
                else
                    return "<b>" + text + "&darr;" + "</b>";
            } else {
                return text;
            }
        }

        public String getSpaceLink(String spaceName) {
            return "<a href=\"tables.s?space=" + spaceName + "\">" + spaceName
                    + "</a>";
        }

        private long trCount = -1;

        private long tdCount = -1;

        public String nextTrStyle() {
            ++trCount;
            tdCount = -1;
            if (trCount % 2 == 0) {
                return "";
            } else {
                return " style=\"background-color: rgb(240, 240, 240);\"";
            }
        }

        public String nextTdStyle() {
            ++tdCount;
            if (tdCount % 4 == 0) {
                return "";
            } else if (tdCount % 4 == 1) {
                return " style=\"color: rgb(200, 0, 0);\"";
            } else if (tdCount % 4 == 2) {
                return " style=\"color: rgb(0, 200, 0);\"";
            } else {
                return " style=\"color: rgb(0, 0, 200);\"";
            }
        }
    }

    protected ExtendedProperties loadConfiguration(ServletConfig conf)
            throws FileNotFoundException, IOException {
        return super.loadConfiguration(conf);
    }

    private String sortKey = "";

    private ThreadLocal<Map<String, String>> queryParams = new ThreadLocal<Map<String, String>>();

    private boolean increase = true;

    protected Template handleRequest(HttpServletRequest req,
            HttpServletResponse resp, Context ctx) throws Exception {
        req.setCharacterEncoding("UTF-8"); // default is ISO8859
        String cmd = req.getServletPath();
        sortKey = req.getParameter("sort");
        queryParams.set(new HashMap<String, String>());
        increase = !Boolean.parseBoolean(req.getParameter("decr"));

        if (cmd != null)
            cmd = WebServer.trimSlashes(cmd);
        if (cmd == null || cmd.equals("")) {
            cmd = "home.s";
        }

        ctx.put("cmd", cmd);
        ctx.put("navbar", "leftbar.vm");
        ctx.put("master", master);
        if (cmd.equals("home.s")) {
            doHome(req, resp, ctx);
        } else if (cmd.equals("tables.s")) {
            doTables(req, resp, ctx);
        } else if (cmd.equals("tablets.s")) {
            doTablets(req, resp, ctx);
        } else if (cmd.equals("ts.s")) {
            doTs(req, resp, ctx);
        } else if (cmd.equals("space.s")) {
            doSpace(req, resp, ctx);
        }
        ctx.put("dateFormat", new java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss"));
        ctx.put("date", new Date());
        ctx.put("printutil", new MyPrintUtils());
        return getTemplate("framework.vm");
    }

    private int compareLong(long l1, long l2) {
        return l1 > l2 ? 1 : l1 == l2 ? 0 : -1;
    }

    private class TsComparator implements Comparator<TsUsageReport> {
        private HashMap<TsDesc, RWCount> tsRWDelta;

        public TsComparator(HashMap<TsDesc, RWCount> tsRWDelta) {
            this.tsRWDelta = tsRWDelta;
        }

        @Override
        public int compare(TsUsageReport o1, TsUsageReport o2) {
            String compField = sortKey;
            int res;
            if (StringUtils.isEmpty(compField)
                    || compField.equalsIgnoreCase("TsDesc")) {
                res = o1.getTsDesc().compareTo(o2.getTsDesc());
            } else if (compField.equalsIgnoreCase("TsNumber")) {
                res = compareLong(o1.getNumTablets(), o2.getNumTablets());
            } else if (compField.equalsIgnoreCase("WriteBuffer")) {
                res = compareLong(o1.getUsedWriteBuffer(),
                        o2.getUsedWriteBuffer());
            } else if (compField.equalsIgnoreCase("IndexPool")) {
                res = compareLong(o1.getUsedIndexPool(), o2.getUsedIndexPool());
            } else if (compField.equalsIgnoreCase("BlockCache")) {
                res = compareLong(o1.getUsedBlockCache(),
                        o2.getUsedBlockCache());
            } else if (compField.equalsIgnoreCase("ReadCount")) {
                res = compareLong(o1.getReadCount(), o2.getReadCount());
            } else if (compField.equalsIgnoreCase("WriteCount")) {
                res = compareLong(o1.getWriteCount(), o2.getWriteCount());
            } else if (compField.equalsIgnoreCase("LoadValue")) {
                res = Double.compare(o1.getLoadValue(), o2.getLoadValue());
            } else if (compField.equalsIgnoreCase("LastHeartBeat")) {
                res = compareLong(o1.getLastHeartBeat(), o2.getLastHeartBeat());
            } else if (compField.equalsIgnoreCase("HeartBeatSeq")) {
                res = compareLong(o1.getHeartBeatSeq(), o2.getHeartBeatSeq());
            } else if (compField.equalsIgnoreCase("SystemLoadValue")) {
                res = Double.compare(o1.getSystemLoadValue(),
                        o2.getSystemLoadValue());
            } else if (compField.equalsIgnoreCase("DeltaRead")) {
                res = compareLong(tsRWDelta.get(o1.getTsDesc()).readCount,
                        tsRWDelta.get(o2.getTsDesc()).readCount);
            } else if (compField.equalsIgnoreCase("DeltaWrite")) {
                res = compareLong(tsRWDelta.get(o1.getTsDesc()).writeCount,
                        tsRWDelta.get(o2.getTsDesc()).writeCount);
            } else if (compField.equalsIgnoreCase("BloomFilter")) {
                res = compareLong(o1.getUsedBloomFilterSize(),
                        o2.getUsedBloomFilterSize());
            } else if (compField.equalsIgnoreCase("Memory")) {
                res = compareLong(o1.getUsedHeapSize(), o2.getUsedHeapSize());
            } else {
                res = o1.getTsDesc().compareTo(o2.getTsDesc()); //default: by TsDesc
            }
            if (!increase) {
                res = -res;
            }
            return res;
        }
    }

    private void doTs(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        HashMap<TsDesc, RWCount> tsRWCount = new HashMap<TsDesc, RWCount>();
        HashMap<TsDesc, RWCount> tsRWDelta = new HashMap<TsDesc, RWCount>();
        List<TsUsageReport> tslist = master.getAvailableTSList();
        long timestamp = System.currentTimeMillis();
        ctx.put("deltaTime", timestamp - lastTsRWRecordStamp);
        lastTsRWRecordStamp = timestamp;

        for (TsUsageReport ts: tslist) {
            RWCount rw = new RWCount();
            rw.readCount = ts.getReadCount();
            rw.writeCount = ts.getWriteCount();
            tsRWCount.put(ts.getTsDesc(), rw);
            RWCount rwDelta = new RWCount();
            if (lastTsRWCount.containsKey(ts.getTsDesc())) {
                rwDelta.readCount = rw.readCount
                        - lastTsRWCount.get(ts.getTsDesc()).readCount;
                rwDelta.writeCount = rw.writeCount
                        - lastTsRWCount.get(ts.getTsDesc()).writeCount;
            } else {
                rwDelta.readCount = rw.readCount;
                rwDelta.writeCount = rw.writeCount;
            }
            tsRWDelta.put(ts.getTsDesc(), rwDelta);
        }
        lastTsRWCount = tsRWCount;
        Collections.sort(tslist, new TsComparator(tsRWDelta));
        ctx.put("tslist", tslist);
        ctx.put("tsRWDelta", tsRWDelta);
        ctx.put("content", "ts.vm");
    }

    private Map<Long, LoadValue> getTabletLoads() {
        List<TsUsageReport> tsUsages = master.getAvailableTSList();
        Map<Long, LoadValue> tabletLoads = new HashMap<Long, LoadValue>();
        for (TsUsageReport tsu: tsUsages) {
            for (Long tabletId: tsu.getTablets()) {
                tabletLoads.put(tabletId, tsu.getTabletLoad(tabletId));
            }
        }
        return tabletLoads;
    }

    private class TabletComparator implements Comparator<Map<String, Object>> {

        @Override
        public int compare(Map<String, Object> o1, Map<String, Object> o2) {
            KeyRange kr1 = (KeyRange) o1.get("KeyRange");
            KeyRange kr2 = (KeyRange) o2.get("KeyRange");

            LoadValue lv1 = (LoadValue) o1.get("Load");
            LoadValue lv2 = (LoadValue) o2.get("Load");

            RWCount rwc1 = (RWCount) o1.get("Delta");
            RWCount rwc2 = (RWCount) o2.get("Delta");

            int res;

            if (StringUtils.isEmpty(sortKey)
                    || sortKey.equalsIgnoreCase("tabletId")) {
                res = compareLong(kr1.getTabletId(), kr2.getTabletId());
            } else if (sortKey.equalsIgnoreCase("KeyRange")) {
                res = compareLong(kr1.getSchemaId(), kr2.getSchemaId());
                if (res == 0) {
                    res = kr1.compareTo(kr2);
                }
            } else if (sortKey.equalsIgnoreCase("TabletServer")) {
                res = kr1.getTsDesc().toString().compareTo(
                        kr2.getTsDesc().toString());
            } else if (lv1 == null || lv2 == null) {
                res = compareLong(kr1.getTabletId(), kr2.getTabletId());
            } else if (sortKey.equalsIgnoreCase("mem")) {
                res = compareLong(lv1.getMemory(), lv2.getMemory());
            } else if (sortKey.equalsIgnoreCase("numKeys")) {
                res = compareLong(lv1.getNumKeys(), lv2.getNumKeys());
            } else if (sortKey.equalsIgnoreCase("dataSize")) {
                res = compareLong(lv1.getDataSize(), lv2.getDataSize());
            } else if (sortKey.equalsIgnoreCase("reads")) {
                res = compareLong(lv1.getReadCount(), lv2.getReadCount());
            } else if (sortKey.equalsIgnoreCase("writes")) {
                res = compareLong(lv1.getWriteCount(), lv2.getWriteCount());
            } else if (sortKey.equalsIgnoreCase("readLoad")) {
                res = compareLong(lv1.getReadLoad(), lv2.getReadLoad());
            } else if (sortKey.equalsIgnoreCase("writeLoad")) {
                res = compareLong(lv1.getWriteLoad(), lv2.getWriteLoad());
            } else if (sortKey.equalsIgnoreCase("memoryUsage")) {
                res = compareLong(lv1.getMemory(), lv2.getMemory());
            } else if (sortKey.equalsIgnoreCase("writeBufferSize")) {
                res = compareLong(lv1.getWriteBufferSize(),
                        lv2.getWriteBufferSize());
            } else if (sortKey.equalsIgnoreCase("deltaReads")) {
                res = compareLong(rwc1.readCount, rwc2.readCount);
            } else if (sortKey.equalsIgnoreCase("deltaWrites")) {
                res = compareLong(rwc1.writeCount, rwc2.writeCount);
            } else if (sortKey.equalsIgnoreCase("deltaKeys")) {
                res = compareLong(rwc1.keyCount, rwc2.keyCount);
            } else if (sortKey.equalsIgnoreCase("BloomFilterSize")) {
                res = compareLong(lv1.getBloomFilterSize(),
                        lv2.getBloomFilterSize());
            } else {
                res = compareLong(kr1.getTabletId(), kr2.getTabletId()); //default by TabletId
            }

            if (!increase) {
                res *= (-1);
            }

            return res;
        }
    }

    private void doTablets(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        String groupBy = req.getParameter("groupby");
        int tabletCount = 0;
        Map<Object, Collection<Map<String, Object>>> result = new TreeMap<Object, Collection<Map<String, Object>>>(
                new Comparator<Object>() {
                    public int compare(Object o1, Object o2) {
                        if (o1 instanceof TableDesc) {
                            return ((TableDesc) o1).getTableName().compareTo(
                                    ((TableDesc) o2).getTableName());
                        } else {
                            return ((TsDesc) o1).compareTo((TsDesc) o2);
                        }
                    }
                });

        Map<Long, LoadValue> tabletLoads = getTabletLoads();
        HashMap<Long, RWCount> tabletRWCount = new HashMap<Long, RWCount>();

        long timestamp = System.currentTimeMillis();
        ctx.put("deltaTime", timestamp - lastTabletRWRecordStamp);
        lastTabletRWRecordStamp = timestamp;

        if ("table".equals(groupBy)) {
            OmapMetadata[] metadatas = master.getTables();
            for (OmapMetadata metadata: metadatas) {
                TableDesc td = metadata.getTableDesc();
                List<KeyRange> tablets = master.masterCatalogue.getTablets(td.getSchemaId());
                List<Map<String, Object>> tabletInfos = new ArrayList<Map<String, Object>>();
                for (KeyRange kr: tablets) {
                    Map<String, Object> tabletInfo = new TreeMap<String, Object>();
                    tabletInfo.put("KeyRange", kr);
                    LoadValue loadValue = tabletLoads.get(kr.getTabletId());
                    RWCount delta = null;
                    if (loadValue != null) {
                        delta = new RWCount();
                        RWCount rw = new RWCount();
                        rw.readCount = loadValue.getReadCount();
                        rw.writeCount = loadValue.getWriteCount();
                        rw.keyCount = loadValue.getNumKeys();
                        tabletRWCount.put(kr.getTabletId(), rw);
                        if (lastTabletRWCount.containsKey(kr.getTabletId())) {
                            delta.readCount = rw.readCount
                                    - lastTabletRWCount.get(kr.getTabletId()).readCount;
                            delta.writeCount = rw.writeCount
                                    - lastTabletRWCount.get(kr.getTabletId()).writeCount;
                            delta.keyCount = rw.keyCount
                                    - lastTabletRWCount.get(kr.getTabletId()).keyCount;
                        } else {
                            delta.readCount = rw.readCount;
                            delta.writeCount = rw.writeCount;
                            delta.keyCount = rw.keyCount;
                        }
                    }
                    tabletInfo.put("Load", loadValue);
                    tabletInfo.put("Delta", delta);
                    tabletInfos.add(tabletInfo);
                }
                Collections.sort(tabletInfos, new TabletComparator());
                result.put(td, tabletInfos);
                tabletCount += tablets.size();
            }
        } else {
            groupBy = "ts";
            Map<TsDesc, List<KeyRange>> tablets = master.masterCatalogue.groupTabletsByTs();
            for (Map.Entry<TsDesc, List<KeyRange>> entry: tablets.entrySet()) {
                TsDesc ts = entry.getKey();
                List<Map<String, Object>> tabletInfos = new ArrayList<Map<String, Object>>();
                for (KeyRange kr: entry.getValue()) {
                    Map<String, Object> tabletInfo = new TreeMap<String, Object>();
                    tabletInfo.put("KeyRange", kr);
                    LoadValue loadValue = tabletLoads.get(kr.getTabletId());
                    RWCount delta = null;
                    if (loadValue != null) {
                        delta = new RWCount();
                        RWCount rw = new RWCount();
                        rw.readCount = loadValue.getReadCount();
                        rw.writeCount = loadValue.getWriteCount();
                        rw.keyCount = loadValue.getNumKeys();
                        tabletRWCount.put(kr.getTabletId(), rw);
                        if (lastTabletRWCount.containsKey(kr.getTabletId())) {
                            delta.readCount = rw.readCount
                                    - lastTabletRWCount.get(kr.getTabletId()).readCount;
                            delta.writeCount = rw.writeCount
                                    - lastTabletRWCount.get(kr.getTabletId()).writeCount;
                            delta.keyCount = rw.keyCount
                                    - lastTabletRWCount.get(kr.getTabletId()).keyCount;
                        } else {
                            delta.readCount = rw.readCount;
                            delta.writeCount = rw.writeCount;
                            delta.keyCount = rw.keyCount;
                        }
                    }
                    tabletInfo.put("Load", loadValue);
                    tabletInfo.put("Delta", delta);
                    tabletInfos.add(tabletInfo);
                }
                Collections.sort(tabletInfos, new TabletComparator());
                result.put(ts, tabletInfos);
                tabletCount += tabletInfos.size();
            }
        }
        lastTabletRWCount = tabletRWCount;
        ctx.put("result", result);
        ctx.put("hexString", new HexString());
        ctx.put("groupBy", groupBy);
        ctx.put("content", "tablets.vm");
        ctx.put("tabletCount", tabletCount);
    }

    private class TableSpaceComparator implements
            Comparator<Map<String, Object>> {

        @Override
        public int compare(Map<String, Object> o1, Map<String, Object> o2) {
            String spaceName1 = (String) o1.get("SpaceName");
            String spaceName2 = (String) o2.get("SpaceName");

            Integer tableCount1 = (Integer) o1.get("TableCount");
            Integer tableCount2 = (Integer) o2.get("TableCount");

            LoadValue loadValue1 = (LoadValue) o1.get("Load");
            LoadValue loadValue2 = (LoadValue) o2.get("Load");

            int res = 0;
            if (StringUtils.isEmpty(sortKey)
                    || sortKey.equalsIgnoreCase("SpaceName")) {
                res = spaceName1.compareTo(spaceName2);
            } else if (sortKey.equalsIgnoreCase("TableCount")) {
                res = tableCount1.compareTo(tableCount2);
            } else if (sortKey.equalsIgnoreCase("TotalKey")) {
                res = compareLong(loadValue1.getNumKeys(),
                        loadValue2.getNumKeys());
            } else if (sortKey.equalsIgnoreCase("TotalSize")) {
                res = compareLong(loadValue1.getDataSize(),
                        loadValue2.getDataSize());
            } else if (sortKey.equalsIgnoreCase("ReadCount")) {
                res = compareLong(loadValue1.getReadCount(),
                        loadValue2.getReadCount());
            } else if (sortKey.equalsIgnoreCase("WriteCount")) {
                res = compareLong(loadValue1.getWriteCount(),
                        loadValue2.getWriteCount());
            } else if (sortKey.equalsIgnoreCase("ReadLoad")) {
                res = compareLong(loadValue1.getReadLoad(),
                        loadValue2.getReadLoad());
            } else if (sortKey.equalsIgnoreCase("WriteLoad")) {
                res = compareLong(loadValue1.getWriteLoad(),
                        loadValue2.getWriteLoad());
            } else if (sortKey.equalsIgnoreCase("MemoryUsage")) {
                res = compareLong(loadValue1.getMemory(),
                        loadValue2.getMemory());
            } else if (sortKey.equalsIgnoreCase("WriteBufferSize")) {
                res = compareLong(loadValue1.getWriteBufferSize(),
                        loadValue2.getWriteBufferSize());
            } else if (sortKey.equalsIgnoreCase("BloomFilterSize")) {
                res = compareLong(loadValue1.getBloomFilterSize(),
                        loadValue2.getBloomFilterSize());
            }

            if (!increase) {
                res *= (-1);
            }

            return res;
        }
    }

    private void doSpace(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        ctx.put("content", "space.vm");

        Map<Long, LoadValue> tableLoads = new HashMap<Long, LoadValue>();
        Map<Long, LoadValue> tabletLoads = getTabletLoads();
        for (Entry<Long, LoadValue> tabletLoad: tabletLoads.entrySet()) {
            long schemaId = OmapUtils.tid2sid(tabletLoad.getKey());
            LoadValue tableLoad = tableLoads.get(schemaId);
            if (tableLoad == null) {
                tableLoad = new LoadValue();
                tableLoads.put(schemaId, tableLoad);
            }
            tableLoad.add(tabletLoad.getValue());
        }

        Map<String, LoadValue> spaceLoad = new HashMap<String, LoadValue>();
        Map<String, Integer> spaceTableCount = new HashMap<String, Integer>();

        for (OmapMetadata meta: master.getTables()) {
            String tableSpaceName = meta.getTableSpaceName();
            LoadValue loadValue = spaceLoad.get(tableSpaceName);
            if (loadValue == null) {
                loadValue = new LoadValue();
                spaceLoad.put(tableSpaceName, loadValue);
            }
            if (tableLoads.containsKey(meta.getTableDesc().getSchemaId())) {
                loadValue.add(tableLoads.get(meta.getTableDesc().getSchemaId()));
            }

            if (!spaceTableCount.containsKey(tableSpaceName)) {
                spaceTableCount.put(tableSpaceName, 1);
            } else {
                spaceTableCount.put(tableSpaceName,
                        spaceTableCount.get(tableSpaceName) + 1);
            }
        }

        ArrayList<Map<String, Object>> itemList = new ArrayList<Map<String, Object>>();
        for (Map.Entry<String, Integer> entry: spaceTableCount.entrySet()) {
            HashMap<String, Object> item = new HashMap<String, Object>();
            item.put("SpaceName", entry.getKey());
            item.put("TableCount", entry.getValue());
            LoadValue value = spaceLoad.get(entry.getKey());
            if (value == null) {
                value = new LoadValue();
            }
            item.put("Load", value);
            itemList.add(item);
        }

        Collections.sort(itemList, new TableSpaceComparator());
        ctx.put("spaces", itemList);
    }

    private class TableComparator implements Comparator<Map<String, Object>> {

        @Override
        public int compare(Map<String, Object> o1, Map<String, Object> o2) {
            LoadValue lv1 = (LoadValue) o1.get("Load");
            LoadValue lv2 = (LoadValue) o2.get("Load");
            String name1 = (String) o1.get("Name");
            String name2 = (String) o2.get("Name");
            Long id1 = (Long) o1.get("Id");
            Long id2 = (Long) o2.get("Id");

            RWCount delta1 = (RWCount) o1.get("Delta");
            RWCount delta2 = (RWCount) o2.get("Delta");

            int res;

            if (StringUtils.isEmpty(sortKey)
                    || sortKey.equalsIgnoreCase("schemaId")) {
                res = id1.compareTo(id2);
            } else if (sortKey.equalsIgnoreCase("tableName")) {
                res = name1.compareTo(name2);
            } else if (lv1 == null || lv2 == null) { //Load maybe NULL?
                res = id1.compareTo(id2);
            } else if (sortKey.equalsIgnoreCase("numKeys")) {
                res = new Long(lv1.getNumKeys()).compareTo(lv2.getNumKeys());
            } else if (sortKey.equalsIgnoreCase("dataSize")) {
                res = new Long(lv1.getDataSize()).compareTo(lv2.getDataSize());
            } else if (sortKey.equalsIgnoreCase("reads")) {
                res = new Long(lv1.getReadCount()).compareTo(lv2.getReadCount());
            } else if (sortKey.equalsIgnoreCase("writes")) {
                res = new Long(lv1.getWriteCount()).compareTo(lv2.getWriteCount());
            } else if (sortKey.equalsIgnoreCase("readLoad")) {
                res = new Long(lv1.getReadLoad()).compareTo(lv2.getReadLoad());
            } else if (sortKey.equalsIgnoreCase("writeLoad")) {
                res = new Long(lv1.getWriteLoad()).compareTo(lv2.getWriteLoad());
            } else if (sortKey.equalsIgnoreCase("deltaReads")) {
                res = new Long(delta1.readCount).compareTo(delta2.readCount);
            } else if (sortKey.equalsIgnoreCase("deltaWrites")) {
                res = new Long(delta1.writeCount).compareTo(delta2.writeCount);
            } else if (sortKey.equalsIgnoreCase("deltaKeys")) {
                res = new Long(delta1.keyCount).compareTo(delta2.keyCount);
            } else if (sortKey.equalsIgnoreCase("BloomFilterSize")) {
                res = new Long(lv1.getBloomFilterSize()).compareTo(lv2.getBloomFilterSize());
            } else {
                res = id1.compareTo(id2);
            }
            if (!increase) {
                res *= (-1);
            }

            return res;
        }

    }

    private void doTables(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        ctx.put("tables", master.getTables());
        ctx.put("hexString", new HexString());
        ctx.put("content", "tables.vm");

        boolean regexError = false;
        String spaceName = req.getParameter("space");
        if (spaceName == null || spaceName.isEmpty()) {
            spaceName = ".*";
        }
        queryParams.get().put("space", spaceName);
        Pattern pattern = null;
        try {
            pattern = Pattern.compile(spaceName);
        } catch (PatternSyntaxException e) {
            regexError = true;
            pattern = null;
        }

        long timestamp = System.currentTimeMillis();
        ctx.put("deltaTime", timestamp - lastTableRWRecordStamp);

        lastTableRWRecordStamp = timestamp;

        List<Map<String, Object>> listTalbeLoad = new ArrayList<Map<String, Object>>();
        Map<Long, LoadValue> tableLoads = new HashMap<Long, LoadValue>();
        Map<Long, LoadValue> tabletLoads = getTabletLoads();
        for (Entry<Long, LoadValue> tabletLoad: tabletLoads.entrySet()) {
            long schemaId = OmapUtils.tid2sid(tabletLoad.getKey());
            LoadValue tableLoad = tableLoads.get(schemaId);
            if (tableLoad == null) {
                tableLoad = new LoadValue();
                tableLoads.put(schemaId, tableLoad);
            }
            tableLoad.add(tabletLoad.getValue());
        }

        HashMap<Long, RWCount> tableRWCount = new HashMap<Long, RWCount>();

        for (OmapMetadata meta: master.getTables()) {
            long schemaId = meta.getTableDesc().getSchemaId();
            String tableName = meta.getInternalTableName();
            if (pattern != null
                    && !pattern.matcher(meta.getTableSpaceName()).matches()) {
                continue;
            }
            LoadValue loadValue = tableLoads.get(schemaId);
            RWCount delta = null;
            if (loadValue != null) {
                delta = new RWCount();
                RWCount rw = new RWCount();
                rw.readCount = loadValue.getReadCount();
                rw.writeCount = loadValue.getWriteCount();
                rw.keyCount = loadValue.getNumKeys();
                tableRWCount.put(schemaId, rw);
                if (lastTableRWCount.containsKey(schemaId)) {
                    delta.readCount = rw.readCount
                            - lastTableRWCount.get(schemaId).readCount;
                    delta.writeCount = rw.writeCount
                            - lastTableRWCount.get(schemaId).writeCount;
                    delta.keyCount = rw.keyCount
                            - lastTableRWCount.get(schemaId).keyCount;
                } else {
                    delta.readCount = rw.readCount;
                    delta.writeCount = rw.writeCount;
                    delta.keyCount = rw.keyCount;
                }
            }

            Map<String, Object> map = new HashMap<String, Object>();
            map.put("Id", schemaId);
            map.put("Name", tableName);
            map.put("Load", loadValue);
            map.put("Meta", meta);
            map.put("Delta", delta);
            listTalbeLoad.add(map);
        }
        lastTableRWCount = tableRWCount;

        Collections.sort(listTalbeLoad, new TableComparator());
        ctx.put("loads", listTalbeLoad);
        ctx.put("spaceName", spaceName);
        ctx.put("regexError", regexError);
    }

    private void doHome(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        ctx.put("systime", new Date().toString());
        ctx.put("hostport",
                OmapConfig.getConfiguration().getString(
                        OmapConfig.NAME_MASTER_HOST)
                        + ":" + master.getMasterPort());
        ctx.put("fs",
                OmapConfig.getConfiguration().getString(
                        OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME));
        ctx.put("path", OmapConfig.getOmapDataRoot());
        ctx.put("zookeeper", OmapConfig.getZkAddress());
        ctx.put("zookeeperroot",
                OmapConfig.getConfiguration().getString(
                        OmapConfig.NAME_OMAP_ZOOKEEPER_ROOT));
        ctx.put("starttime", master.getStartTime().toString());
        long uptime = System.currentTimeMillis()
                - master.getStartTime().getTime();
        ctx.put("uptime", (uptime / 3600 / 1000) + " hours "
                + (uptime / 1000 / 60 % 60) + " minutes");
        ctx.put("tses", master.getNumOfAvailableTs());
        Map<Task, TsDesc> map = new TreeMap<Task, TsDesc>(Task.ID_COMPATATOR);
        int taskCount = master.getTasks(map, 200);
        ctx.put("taskcount", taskCount);
        ctx.put("tasks", map);
        ctx.put("systemload", SystemInfoUtils.getLoad());
        ctx.put("content", "home.vm");
    }
}
