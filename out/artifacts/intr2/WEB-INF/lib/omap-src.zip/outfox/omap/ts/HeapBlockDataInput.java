/**
 * @(#)HeapBlockDataInput.java, 2012-5-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import odis.util.unsafe.HeapCDataInputStream;

/**
 * @author zhangduo
 */
public class HeapBlockDataInput extends HeapCDataInputStream implements
        BlockDataInput {
    public HeapBlockDataInput(byte[] buf) {
        super(buf);
    }

    public HeapBlockDataInput(byte[] buf, int off, int len) {
        super(buf, off, len);
    }

    /**
     * Dose nothing.
     */
    @Override
    public void dropBlock() {}

}
