/**
 * @(#)StatisticReader.java, 2011-6-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.io.IFileSystem.PathFilter;
import odis.serialize.lib.LongWritable;
import outfox.omap.metrics.MetricsEntry;
import outfox.omap.util.OmapUtils;
import toolbox.collections.primitive.LongLongPair;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class StatisticReader {
    private static final Logger LOG = LogFormatter.getLogger(StatisticReader.class);

    private final FileSystem fs;

    private final Path dir;

    private final long startTime;

    private final long endTime;

    private final List<StatisticReaderHandler> handlers = new ArrayList<StatisticReaderHandler>();

    public StatisticReader(FileSystem fs, Path dir, long startTime, long endTime) {
        if (startTime > endTime) {
            throw new IllegalArgumentException();
        }
        this.fs = fs;
        this.dir = dir;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public static LongLongPair getStatFileTime(String fileName) {
        String[] ss = fileName.split("_");
        return new LongLongPair(Long.parseLong(ss[1]), Long.parseLong(ss[2]));
    }

    public void addHandler(StatisticReaderHandler handler) {
        handlers.add(handler);
    }

    private List<Path> getSortedStatisticFiles() throws IOException {
        FileInfo[] infos = fs.listFiles(dir, new PathFilter() {

            @Override
            public boolean accept(Path path) {
                return path.getName().startsWith(
                        StatisticRecorder.STATISTIC_FILE_PREFIX);
            }
        });
        Arrays.sort(infos, new Comparator<FileInfo>() {

            @Override
            public int compare(FileInfo o1, FileInfo o2) {
                long tm1 = getStatFileTime(o1.getPath().getName()).getFirst();
                long tm2 = getStatFileTime(o2.getPath().getName()).getFirst();
                return tm1 > tm2 ? 1 : tm1 == tm2 ? 0 : -1;
            }

        });
        List<Path> result = new ArrayList<Path>();
        for (FileInfo info: infos) {
            LongLongPair time = getStatFileTime(info.getPath().getName());
            if (time.getSecond() < startTime) {
                continue;
            }
            if (time.getFirst() >= endTime) {
                break;
            }
            result.add(info.getPath());
        }
        return result;
    }

    public void read() throws IOException {
        List<Path> files = getSortedStatisticFiles();
        LOG.info("Need to process files " + files);
        long count = 0;
        boolean succ = false;
        try {
            LongWritable key = new LongWritable();
            MetricsEntry value = new MetricsEntry();
            for (Path file: files) {
                LOG.info("Read file " + file);
                SequenceFile.Reader reader = new SequenceFile.Reader(fs, file);
                try {
                    while (reader.next(key, value)) {
                        if (key.get() >= startTime && key.get() < endTime) {
                            for (StatisticReaderHandler handler: handlers) {
                                handler.handle(key.get(), value);
                            }
                            count++;
                        }
                    }
                } catch (EOFException e) {
                    LOG.log(Level.WARNING,
                            "incompleted stat file, ignore last metrics entry",
                            e);
                } finally {
                    OmapUtils.safeClose(reader);
                }
            }
            succ = true;
            LOG.info("Process end, " + count + " entries read");
        } finally {
            if (succ) {
                for (StatisticReaderHandler handler: handlers) {
                    handler.done(files);
                }
            } else {
                for (StatisticReaderHandler handler: handlers) {
                    handler.fail();
                }
            }
        }
    }
}
