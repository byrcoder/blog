/**
 * @(#)SparseIndexPool.java, 2011-10-12. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.util.logging.Logger;

import odis.io.BufferOverflowException;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferPool;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class SparseIndexPool {

    private static final Logger LOG = LogFormatter.getLogger(SparseIndexPool.class);

    final LRUMap<String, SparseIndex> pool = new LRUMap<String, SparseIndex>(
            16, 0.75f);

    final NativeRamBufferPool bufferPool;

    public SparseIndexPool(long ptr, long maxSize, int chunkSize) {
        this.bufferPool = new NativeRamBufferPool(ptr, maxSize, chunkSize);
        LOG.info("Create sparse index pool with max size = " + maxSize
                + ", chunk size = " + chunkSize);
    }

    public NativeRamBuffer[] createBuffer(SSTable sstable, int size) {
        synchronized (pool) {
            if (bufferPool.getAllocatedBufferSize() + size > bufferPool.getMaxBufferSize()) {
                do {
                    LRUMap.Entry<String, SparseIndex> entry = pool.poll();
                    if (entry == null) {
                        throw new BufferOverflowException(
                                "Can not load sparse index for " + sstable
                                        + " with size " + size
                                        + ", index pool usage: "
                                        + bufferPool.getAllocatedBufferSize()
                                        + "/" + bufferPool.getMaxBufferSize());
                    }
                    if (!entry.getValue().release()) {
                        // This means the index is held by someone, we can 
                        // assume that all the index after it may also by held
                        // by someone, so give up and throw exception.
                        throw new BufferOverflowException(
                                "Can not load sparse index for " + sstable
                                        + " with size " + size
                                        + ", index pool usage: "
                                        + bufferPool.getAllocatedBufferSize()
                                        + "/" + bufferPool.getMaxBufferSize());
                    }
                } while (bufferPool.getAllocatedBufferSize() + size > bufferPool.getMaxBufferSize());
            }
            NativeRamBuffer[] buffers = bufferPool.newBuffer(size);
            LOG.info("Load sparseIndex for " + sstable + " with size " + size
                    + ", allocatedSize "
                    + (bufferPool.getChunkSize() * buffers.length)
                    + ", index pool usage: "
                    + bufferPool.getAllocatedBufferSize() + "/"
                    + bufferPool.getMaxBufferSize());
            return buffers;
        }
    }

    public SparseIndex loadIndex(SSTable sstable) throws IOException {
        String key = sstable.getCacheKey();
        synchronized (pool) {
            SparseIndex index = pool.get(key, true);
            if (index != null) {
                index.acquire();
                return index;
            }
        }

        synchronized (sstable.sparseIndexFile) {
            synchronized (pool) {
                SparseIndex index = pool.get(key, true);
                if (index != null) {
                    index.acquire();
                    return index;
                }
            }
            SparseIndex index = new SparseIndex(sstable, this);
            synchronized (pool) {
                pool.put(key, index);
            }
            return index;
        }
    }

    public long getLoadedIndexSize(SSTable sstable) {
        String key = sstable.getCacheKey();
        synchronized (pool) {
            SparseIndex index = pool.get(key, false);
            return index != null ? index.getIndexSize() : 0;
        }
    }

    public void unloadIndex(SSTable sstable) {
        String key = sstable.getCacheKey();
        synchronized (pool) {
            SparseIndex index = pool.remove(key);
            if (index != null) {
                index.release();
            }
        }
    }

    public long getMaxSize() {
        return bufferPool.getMaxBufferSize();
    }

    public long getAllocatedSize() {
        synchronized (pool) {
            return bufferPool.getAllocatedBufferSize();
        }
    }
}
