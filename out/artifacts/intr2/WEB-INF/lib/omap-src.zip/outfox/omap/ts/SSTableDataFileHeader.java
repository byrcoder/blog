/**
 * @(#)SSTableDataFileHeader.java, 2011-8-11. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;

import odis.file.SequenceFile;
import odis.io.FSDataInputStream;
import odis.io.Path;
import odis.io.ramfs.RAMFileSystem;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.IntWritable;
import outfox.omap.util.OmapUtils;

/**
 * Notice that this do not contain the right sync.Use
 * {@link SSTableDataSequenceFileReader} to get sync information when first
 * read.
 * 
 * @author zhangduo
 */
class SSTableDataFileHeader {

    private static final RAMFileSystem RAMFS = new RAMFileSystem();

    private static final Path HEADER_FILE = new Path("/SSTableHeader");

    static {
        init();
    }

    private static void init() {
        try {
            SequenceFile.Writer writer = new SequenceFile.Writer(
                    OmapUtils.createFSDataOutputStream(RAMFS, HEADER_FILE,
                            false, 0), IntWritable.class,
                    ByteArrayWritable.class, null, 0);
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static FSDataInputStream getHeaderInput() throws IOException {
        return RAMFS.open(HEADER_FILE);
    }
}
