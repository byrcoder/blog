package outfox.omap.ts;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * A set of flags. Flags are stored in a HashSet and protected by a
 * {@link ReentrantReadWriteLock}.
 * 
 * @author zhangkun
 * @param <T>
 *            The type of flags. You have to override
 *            {@link java.lang.Object#hashCode()} of T correctly because they
 *            are stored in a HashSet.
 */
class FlagSet<T> {
    private static final Logger LOG = LogFormatter.getLogger(FlagSet.class.getName());

    /**
     * The status flags set of the Tablet. NOTE: the monitor of flags is used
     * only to wait and notify changes of it, while concurrent access is
     * protected by {@link #flagChangeLock}.
     */
    private final Set<T> flags = new HashSet<T>();

    /**
     * Lock the read lock to make sure that no {@link #flags} modifications can
     * be taken during a certain operation. This lock also protects concurrent
     * read/write to {@link #flags}.
     */
    private final ReentrantReadWriteLock flagChangeLock = new ReentrantReadWriteLock();

    private final Condition flagChanged = flagChangeLock.writeLock().newCondition();

    private String name;

    public FlagSet(String name) {
        this.name = name;
    }

    public void setFlag(T flag) {
        flagChangeLock.writeLock().lock();
        try {
            flags.add(flag);
            LOG.info(name + " set " + flag);
            flagChanged.signalAll();
        } finally {
            flagChangeLock.writeLock().unlock();
        }
    }

    public void clearFlag(T flag) {
        flagChangeLock.writeLock().lock();
        try {
            flags.remove(flag);
            LOG.info(name + " clear " + flag);
            flagChanged.signalAll();
        } finally {
            flagChangeLock.writeLock().unlock();
        }
    }

    public boolean hasFlag(T flag) {
        flagChangeLock.readLock().lock();
        try {
            return flags.contains(flag);
        } finally {
            flagChangeLock.readLock().unlock();
        }
    }

    /**
     * Get the read lock to the flags. Lock it to prevent the flags being
     * modified by other threads.
     * 
     * @return
     */
    public ReentrantReadWriteLock.ReadLock readLock() {
        return flagChangeLock.readLock();
    }

    /**
     * <p>
     * Test whether requiredFlag is set:
     * </p>
     * <ul>
     * <li>Yes: set the setFlag and return true</li>
     * <li>No: return false</li>
     * </ul>
     * 
     * @param requiredFlag
     * @param setFlag
     * @param clear
     *            whether to clear the requiredFlag
     * @return
     */
    public boolean testAndSet(T requiredFlag, T setFlag, boolean clear) {
        flagChangeLock.writeLock().lock();
        try {
            if (flags.contains(requiredFlag)) {
                flags.add(setFlag);
                LOG.info(name + " set " + setFlag);
                if (clear) {
                    flags.remove(requiredFlag);
                    LOG.info(name + " clear " + requiredFlag);
                }
                flagChanged.signalAll();
                return true;
            } else {
                LOG.info(name + " will not set " + setFlag + " because "
                        + requiredFlag + " is not set");
                return false;
            }
        } finally {
            flagChangeLock.writeLock().unlock();
        }
    }

    public boolean testNotAndSet(T requiredFlag, T setFlag) {
        flagChangeLock.writeLock().lock();
        try {
            if (!flags.contains(requiredFlag)) {
                flags.add(setFlag);
                LOG.info(name + " set " + setFlag);
                flagChanged.signalAll();
                return true;
            } else {
                LOG.info(name + " will not set " + setFlag + " because "
                        + requiredFlag + " is set");
                return false;
            }
        } finally {
            flagChangeLock.writeLock().unlock();
        }
    }

    /**
     * <p>
     * It executes in the following order:
     * </p>
     * <ol>
     * <li>Wait until all of requiredFlags are set, and none of blockingFlags
     * are set.</li>
     * <li>Check whether any of the exitFlags is set.
     * <ul>
     * <li>Yes: return false.</li>
     * <li>No: set the setFlag and return true.</li>
     * </ul>
     * </li>
     * </ol>
     * <p>
     * It will lock the write lock of the flags while checking, and unlock it
     * when waiting, giving other threads the chance of modifying the flags.
     * </p>
     * 
     * @param requiredFlags
     *            will wait until all of requiredFlags are set
     * @param blockingFlags
     *            will wait until none of blockingFlags are set
     * @param exitFlags
     *            will return false if any of exitFlags are set
     * @param setFlag
     *            if return true, will set this setFlag
     * @return true if none of exitFlags are set, false otherwise.
     */
    public boolean waitForFlagsAndSet(Collection<T> requiredFlags,
            Collection<T> blockingFlags, Collection<T> exitFlags, T setFlag)
            throws InterruptedException {
        flagChangeLock.writeLock().lock();
        try {
            while (true) {
                boolean pass = true;
                if (requiredFlags != null) {
                    for (T flag: requiredFlags) {
                        if (!flags.contains(flag)) {
                            pass = false;
                            break;
                        }
                    }
                }
                if (pass && blockingFlags != null) {
                    for (T flag: blockingFlags) {
                        if (flags.contains(flag)) {
                            pass = false;
                            break;
                        }
                    }
                }
                if (!pass) {
                    LOG.info(name
                            + " waiting for flags:"
                            + ((requiredFlags == null) ? " " : " required="
                                    + requiredFlags)
                            + ((blockingFlags == null) ? " " : " blocker="
                                    + blockingFlags) + " current=" + flags
                            + ((setFlag == null) ? " " : " setFlag=" + setFlag));
                    flagChanged.await();
                } else {
                    if (exitFlags != null) {
                        for (T flag: exitFlags) {
                            if (flags.contains(flag)) {
                                LOG.info(name + " will not set " + setFlag
                                        + " because " + flag + " is set");
                                return false;
                            }
                        }
                    }
                    if (setFlag != null) {
                        setFlag(setFlag);
                    }
                    return true;
                }
            }
        } finally {
            flagChangeLock.writeLock().unlock();
        }
    }

    @Override
    public String toString() {
        flagChangeLock.readLock().lock();
        try {
            return flags.toString();
        } finally {
            flagChangeLock.readLock().unlock();
        }
    }
}
