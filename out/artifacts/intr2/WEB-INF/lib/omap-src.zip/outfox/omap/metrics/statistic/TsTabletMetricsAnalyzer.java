/**
 * @(#)TsTabletMetricsAnalyzer.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TimeRangeUtils;
import outfox.omap.metrics.TsMetricsType;

/**
 * @author zhangduo
 */
public class TsTabletMetricsAnalyzer {
    private long[] metricsRecords = new long[TsMetricsType.tabletTypeCount()];

    private double[] statisticResults = new double[TsTabletStatisticType.getTypeCount()];

    public void process(long[] metricsRecords) {
        for (int i = 0; i < TsMetricsType.tabletTypeCount(); i++) {
            this.metricsRecords[i] += metricsRecords[i];
        }
    }

    public void done() {
        statisticResults[TsTabletStatisticType.KEY_FIND_COUNT.offset()] = metricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()];
        if (metricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.KEY_FIND_DELAY.offset()] = (double) metricsRecords[TsMetricsType.KEY_FIND_DELAY.offset()]
                    / metricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.KEY_FIND_SIZE_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.KEY_FIND_SIZE.offset()]
                    / metricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.KEY_FIND_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.KEY_FIND_SIZE_PER_COUNT.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_KEY_FIND_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_KEY_FIND_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_COUNT.offset()] = metricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
        if (metricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_DELAY.offset()] = (double) metricsRecords[TsMetricsType.MULTI_KEY_FIND_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_ROWS_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.MULTI_KEY_FIND_ROWS.offset()]
                    / metricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_SIZE_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.MULTI_KEY_FIND_SIZE.offset()]
                    / metricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_DELAY_PER_ROW.offset()] = (double) metricsRecords[TsMetricsType.MULTI_KEY_FIND_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_KEY_FIND_ROWS.offset()];
        } else {
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_SIZE_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_KEY_FIND_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_MULTI_KEY_FIND_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_MULTI_KEY_FIND_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_COUNT.offset()] = metricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
        if (metricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_DELAY.offset()] = (double) metricsRecords[TsMetricsType.RANGE_KEY_FIND_DELAY.offset()]
                    / metricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_ROWS_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.RANGE_KEY_FIND_ROWS.offset()]
                    / metricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_SIZE_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.RANGE_KEY_FIND_SIZE.offset()]
                    / metricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_DELAY_PER_ROW.offset()] = (double) metricsRecords[TsMetricsType.RANGE_KEY_FIND_DELAY.offset()]
                    / metricsRecords[TsMetricsType.RANGE_KEY_FIND_ROWS.offset()];
        } else {
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_SIZE_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.RANGE_KEY_FIND_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_RANGE_KEY_FIND_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_RANGE_KEY_FIND_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.CONTAINS_COUNT.offset()] = metricsRecords[TsMetricsType.CONTAINS_COUNT.offset()];
        if (metricsRecords[TsMetricsType.CONTAINS_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.CONTAINS_DELAY.offset()] = (double) metricsRecords[TsMetricsType.CONTAINS_DELAY.offset()]
                    / metricsRecords[TsMetricsType.CONTAINS_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.CONTAINS_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_CONTAINS_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_CONTAINS_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.MULTI_CONTAINS_COUNT.offset()] = metricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()];
        if (metricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.MULTI_CONTAINS_DELAY.offset()] = (double) metricsRecords[TsMetricsType.MULTI_CONTAINS_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_CONTAINS_ROWS_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.MULTI_CONTAINS_ROWS.offset()]
                    / metricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_CONTAINS_DELAY_PER_ROW.offset()] = (double) metricsRecords[TsMetricsType.MULTI_CONTAINS_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_CONTAINS_ROWS.offset()];
        } else {
            statisticResults[TsTabletStatisticType.MULTI_CONTAINS_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_CONTAINS_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_CONTAINS_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_MULTI_CONTAINS_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_MULTI_CONTAINS_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.INSERT_COUNT.offset()] = metricsRecords[TsMetricsType.INSERT_COUNT.offset()];
        if (metricsRecords[TsMetricsType.INSERT_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.INSERT_DELAY.offset()] = (double) metricsRecords[TsMetricsType.INSERT_DELAY.offset()]
                    / metricsRecords[TsMetricsType.INSERT_COUNT.offset()];
            statisticResults[TsTabletStatisticType.INSERT_SIZE_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.INSERT_SIZE.offset()]
                    / metricsRecords[TsMetricsType.INSERT_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.INSERT_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.INSERT_SIZE_PER_COUNT.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_INSERT_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_INSERT_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.MULTI_INSERT_COUNT.offset()] = metricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
        if (metricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.MULTI_INSERT_DELAY.offset()] = (double) metricsRecords[TsMetricsType.MULTI_INSERT_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_INSERT_ROWS_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.MULTI_INSERT_ROWS.offset()]
                    / metricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_INSERT_SIZE_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.MULTI_INSERT_SIZE.offset()]
                    / metricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_INSERT_DELAY_PER_ROW.offset()] = (double) metricsRecords[TsMetricsType.MULTI_INSERT_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_INSERT_ROWS.offset()];
        } else {
            statisticResults[TsTabletStatisticType.MULTI_INSERT_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_INSERT_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_INSERT_SIZE_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_INSERT_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_MULTI_INSERT_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_MULTI_INSERT_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.DELETE_COUNT.offset()] = metricsRecords[TsMetricsType.DELETE_COUNT.offset()];
        if (metricsRecords[TsMetricsType.DELETE_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.DELETE_DELAY.offset()] = (double) metricsRecords[TsMetricsType.DELETE_DELAY.offset()]
                    / metricsRecords[TsMetricsType.DELETE_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.DELETE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_DELETE_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_DELETE_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.MULTI_DELETE_COUNT.offset()] = metricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()];
        if (metricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.MULTI_DELETE_DELAY.offset()] = (double) metricsRecords[TsMetricsType.MULTI_DELETE_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_DELETE_ROWS_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.MULTI_DELETE_ROWS.offset()]
                    / metricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()];
            statisticResults[TsTabletStatisticType.MULTI_DELETE_DELAY_PER_ROW.offset()] = (double) metricsRecords[TsMetricsType.MULTI_DELETE_DELAY.offset()]
                    / metricsRecords[TsMetricsType.MULTI_DELETE_ROWS.offset()];
        } else {
            statisticResults[TsTabletStatisticType.MULTI_DELETE_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_DELETE_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.MULTI_DELETE_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_MULTI_DELETE_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_MULTI_DELETE_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.RANGE_DELETE_COUNT.offset()] = metricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()];
        if (metricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.RANGE_DELETE_DELAY.offset()] = (double) metricsRecords[TsMetricsType.RANGE_DELETE_DELAY.offset()]
                    / metricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()];
            statisticResults[TsTabletStatisticType.RANGE_DELETE_ROWS_PER_COUNT.offset()] = (double) metricsRecords[TsMetricsType.RANGE_DELETE_ROWS.offset()]
                    / metricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()];
            statisticResults[TsTabletStatisticType.RANGE_DELETE_DELAY_PER_ROW.offset()] = (double) metricsRecords[TsMetricsType.RANGE_DELETE_DELAY.offset()]
                    / metricsRecords[TsMetricsType.RANGE_DELETE_ROWS.offset()];
        } else {
            statisticResults[TsTabletStatisticType.RANGE_DELETE_DELAY.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.RANGE_DELETE_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TsTabletStatisticType.RANGE_DELETE_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_RANGE_DELETE_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_RANGE_DELETE_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.COMPARE_AND_SET_COUNT.offset()] = metricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()];
        if (metricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.COMPARE_AND_SET_DELAY.offset()] = (double) metricsRecords[TsMetricsType.COMPARE_AND_SET_DELAY.offset()]
                    / metricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.LOCK_ROW_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_COMPARE_AND_SET_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_COMPARE_AND_SET_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.LOCK_ROW_COUNT.offset()] = metricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()];
        if (metricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.LOCK_ROW_DELAY.offset()] = (double) metricsRecords[TsMetricsType.LOCK_ROW_DELAY.offset()]
                    / metricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.LOCK_ROW_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_LOCK_ROW_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_LOCK_ROW_COUNT.offset()
                    + i];
        }

        statisticResults[TsTabletStatisticType.UNLOCK_ROW_COUNT.offset()] = metricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()];
        if (metricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()] > 0) {
            statisticResults[TsTabletStatisticType.UNLOCK_ROW_DELAY.offset()] = (double) metricsRecords[TsMetricsType.UNLOCK_ROW_DELAY.offset()]
                    / metricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()];
        } else {
            statisticResults[TsTabletStatisticType.UNLOCK_ROW_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TsTabletStatisticType.TIME_RANGE_UNLOCK_ROW_COUNT.offset()
                    + i] = metricsRecords[TsMetricsType.TIME_RANGE_UNLOCK_ROW_COUNT.offset()
                    + i];
        }
    }

    public double[] getStatisticResults() {
        return statisticResults;
    }

}
