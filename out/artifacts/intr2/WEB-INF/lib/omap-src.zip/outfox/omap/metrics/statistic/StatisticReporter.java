/**
 * @(#)StatisticReporter.java, 2011-6-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem.PathFilter;
import odis.io.Path;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.format.DateTimeFormatter;

import outfox.omap.util.OmapUtils;
import toolbox.collections.Pair;

/**
 * @author zhangduo
 */
public class StatisticReporter {

    private final FileSystem fs;

    private final Path dir;

    public static final String REPORT_DIR = "report";

    public static final String ANALYSIS_FILE_PREFIX = "ANALYSIS_";

    public StatisticReporter(FileSystem fs, Path dir) throws IOException {
        this.fs = fs;
        this.dir = dir;
        for (FileInfo info: fs.listFiles(dir.cat(REPORT_DIR), new PathFilter() {

            @Override
            public boolean accept(Path path) {
                return path.getName().endsWith(".tmp");
            }
        })) {
            fs.delete(info.getPath());
        }
    }

    public StatisticResult getStatisticReport(long startTime, long endTime,
            boolean merge) throws IOException {
        Path reportDir = dir.cat(REPORT_DIR);
        if (!fs.exists(reportDir)) {
            fs.mkdirs(reportDir);
        }
        Path outputFile = reportDir.cat(ANALYSIS_FILE_PREFIX + startTime + "_"
                + endTime);
        // first see if we already have an analyzed result
        if (fs.exists(outputFile)) {
            StatisticResult result = new StatisticResult();
            FSDataInputStream in = fs.open(outputFile);
            try {
                result.readFields(in);
            } finally {
                OmapUtils.safeClose(in);
            }
            return result;
        }
        StatisticReader reader = new StatisticReader(fs, dir, startTime,
                endTime);
        if (merge) {
            reader.addHandler(new StatisticMergeHandler(fs, dir));
        }
        StatisticAnalysisHandler handler = new StatisticAnalysisHandler();
        reader.addHandler(handler);
        reader.read();
        StatisticResult result = handler.getStatisticResult();

        Path tmpOutputFile = reportDir.cat(ANALYSIS_FILE_PREFIX + startTime
                + "_" + endTime + ".tmp");
        FSDataOutputStream out = fs.create(tmpOutputFile);
        try {
            result.writeFields(out);
        } finally {
            out.close();
        }
        fs.rename(tmpOutputFile, outputFile);
        return result;
    }

    public List<Pair<String, String>> getExistsDailyStatisticReports(
            int maxDays, DateTimeFormatter formatter) throws IOException {
        Path reportDir = dir.cat("report");
        if (!fs.exists(reportDir)) {
            fs.mkdirs(reportDir);
            return new ArrayList<Pair<String, String>>(0);
        }
        DateTime dt = new DateTime();
        long startTime = dt.minusMillis(dt.getMillisOfDay()).getMillis();
        List<Pair<String, String>> ret = new ArrayList<Pair<String, String>>(
                maxDays);
        for (int i = 0; i < maxDays; i++) {
            long endTime = startTime + DateTimeConstants.MILLIS_PER_DAY;
            Path file = reportDir.cat(ANALYSIS_FILE_PREFIX + startTime + "_"
                    + endTime);
            if (fs.exists(file)) {
                ret.add(new Pair<String, String>(formatter.print(startTime),
                        formatter.print(endTime)));
            }
            startTime -= DateTimeConstants.MILLIS_PER_DAY;
        }
        return ret;
    }
}
