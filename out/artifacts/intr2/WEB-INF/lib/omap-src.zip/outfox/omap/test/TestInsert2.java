/**
 * @(#)TestInsert2.java, 2011-11-3. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.test;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;

import outfox.omap.client.OmapDataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.exceptions.OmapException;
import toolbox.misc.LogFormatter;

/**
 *
 * @author wangfk
 *
 */
public class TestInsert2 {
    private static final Logger LOG = LogFormatter.getLogger(TestInsert2.class);

    private static final String tableSpaceName = "test";
    private static final String tableName = "insert2-" + System.currentTimeMillis();

    private static BlockingQueue<InsertValue> queue = new ArrayBlockingQueue<InsertValue>(2048);

    /**
     * @param args
     * @throws OmapException 
     * @throws InterruptedException 
     */
    public static void main(String[] args) throws OmapException {
        if (args.length == 0) {
            System.err.println("TestInsert2 <Thread Number> [Max Insert Count]");
            return;
        }
        OmapDataSource dataSource = (OmapDataSource) DataSourceFactory.getNamed(
                DataSourceFactory.NAME_OMAP_DATA_SOURCE);
        TableSpace tableSpace = dataSource.openTableSpace(tableSpaceName);
        Table table = tableSpace.createTable(tableName,
                new String[]{"key", "value"}, new String[]{"INTEGER", "VINTSTRING"});

        int threadNumber = Integer.parseInt(args[0]);
        long maxInsertCount = Long.MAX_VALUE;
        if(args.length > 1) {
            maxInsertCount = Long.parseLong(args[1]);
        }
        InsertThread[] threads = new InsertThread[threadNumber];
        for (int i = 0; i < threadNumber; ++ i) {
            threads[i] = new InsertThread(table);
            threads[i].start();
        }

        Random rand = new Random(System.currentTimeMillis());
        long insertCount = 0;
        while (true && insertCount < maxInsertCount) {
            InsertValue insertValue = new InsertValue(rand.nextInt(), new Date().toString());
            try {
                queue.put(insertValue);
            } catch (InterruptedException e) {
                LOG.log(Level.WARNING, "Interrupted, quit...", e);
                break;
            }
            ++ insertCount;
            if(insertCount % 1000 == 0) {
                String info = "Insert count: " + insertCount;
                System.err.println(info);
                LOG.info(info);
            }
        }
        for(InsertThread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
            }
        }
        String info = "Total insert count: " + insertCount;
        System.err.println(info);
        LOG.info(info);
    }

    private static class InsertValue {
        public int key;
        public String value;

        public InsertValue(int key, String value) {
            this.key = key;
            this.value = value;
        }
    }
    private static class InsertThread extends Thread {
        private final Table table;

        public InsertThread(Table table) {
            this.table = table;
            this.setDaemon(true);
        }

        @Override
        public void run() {
            Row newRow;
            try {
                newRow = table.newRow();
            } catch (OmapException e) {
                LOG.log(Level.WARNING, "Fail to create new row, quit thread", e);
                return;
            }
            while (true) {
                try {
                    InsertValue iv = queue.poll(2, TimeUnit.SECONDS);
                    if (iv == null) {
                        return;
                    }
                    newRow.set(0, new IntWritable(iv.key));
                    newRow.set(1, new StringWritable(iv.value));
                    table.update(newRow);
                    Thread.sleep(100);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Fail to insert new row", e);
                    return;
                }
            }
        }
        
    }
}
