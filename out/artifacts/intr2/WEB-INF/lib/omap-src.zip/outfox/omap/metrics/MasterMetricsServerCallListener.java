/**
 * @(#)MasterMetricsServerCallListener.java, 2011-6-3. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.lang.reflect.Method;

import odis.rpc2.ClientInfo;
import odis.rpc2.ServerCallListener;
import odis.rpc2.PermissionManager.PermitType;

/**
 * @author zhangduo
 */
public class MasterMetricsServerCallListener implements ServerCallListener {

    private final MasterGlobalMetricsEntry globalMetricsEntry;

    public MasterMetricsServerCallListener(
            MasterGlobalMetricsEntry globalMetricsEntry) {
        this.globalMetricsEntry = globalMetricsEntry;
    }

    @Override
    public Object createAttach(ClientInfo clientInfo) {
        return null;
    }

    @Override
    public void startReceive(Method method, Object attach) {}

    @Override
    public void endReceive(Method method, Object[] args, Object attach) {
        globalMetricsEntry.request();
    }

    @Override
    public void getPermit(Method method, PermitType permit, Object attach) {
        if (permit.equals(PermitType.TIMEOUT)) {
            globalMetricsEntry.requestTimeout();
        }
    }

    @Override
    public void startCall(Method method, Object attach) {}

    @Override
    public void endCall(Method method, Object returnValue, Throwable error,
            Object attach) {}

    @Override
    public void callTimeout(Method method, Object returnValue, Throwable error,
            Object attach) {
        globalMetricsEntry.requestTimeout();
    }

    @Override
    public void startSend(Method method, Object attach) {}

    @Override
    public void endSend(Method method, Object attach) {}

}
