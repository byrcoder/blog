package outfox.omap.master;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.Path;
import odis.serialize.IWritable;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.TabletAlreadyExistsException;
import outfox.omap.metadata.TableDesc;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.Tablet;
import outfox.omap.ts.Tablet.SplitResult;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

public class SplitTabletTask extends Task {
    private static final Logger LOG = LogFormatter.getLogger(SplitTabletTask.class.getName());

    long oldId;

    long newId1;

    long newId2;

    KeyCell middleKey;

    private TableDesc td;

    /**
     * Empty constructor, should only be used before copyFields() or
     * readFields()
     */
    public SplitTabletTask() {

    }

    public SplitTabletTask(long oldId, long newId1, long newId2, TableDesc td,
            String reason) {
        super(reason);
        this.oldId = oldId;
        this.newId1 = newId1;
        this.newId2 = newId2;
        this.td = td;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        super.copyFields(value);
        SplitTabletTask v = (SplitTabletTask) value;
        this.oldId = v.oldId;
        this.newId1 = v.newId1;
        this.newId2 = v.newId2;
        this.middleKey = new KeyCell();
        middleKey.copyFields(v.middleKey);
        td = new TableDesc();
        td.copyFields(v.td);
        return this;
    }

    /**
     * For roll back use only, not serialized
     */
    private SplitResult splitResult = null;

    @Override
    public int execTask(OmapTs ts) {
        try {
            this.splitResult = ts.splitTablet(this.oldId, this.newId1,
                    this.newId2);
            if (splitResult == null || splitResult.middleKey == null) {
                LOG.warning("split " + HexString.longToPaddedHex(oldId)
                        + " failed");
                return -1;
            }
            LOG.info("Split done: " + splitResult.oldTablet.getKeyRangeString()
                    + " split to " + splitResult.newTablet1.getKeyRangeString()
                    + " and " + splitResult.newTablet2.getKeyRangeString());
            this.middleKey = splitResult.middleKey;
            return 0;
        } catch (Exception e) {
            // shouldn't happen.
            LOG.log(Level.SEVERE,
                    "Exception when split " + HexString.longToPaddedHex(oldId),
                    e);
            return -1;
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        this.oldId = in.readLong();
        this.newId1 = in.readLong();
        this.newId2 = in.readLong();
        td = new TableDesc();
        td.readFields(in);
        this.middleKey = td.createKeyCell();
        this.middleKey.readFields(in);
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        out.writeLong(this.oldId);
        out.writeLong(this.newId1);
        out.writeLong(this.newId2);
        td.writeFields(out);
        if (this.middleKey != null) {
            ;
        } else {
            this.middleKey = new KeyCell();
        }
        this.middleKey.writeFields(out);
    }

    @Override
    public String getTaskDetail() {
        return "SPLIT: tablet " + HexString.longToPaddedHex(this.oldId)
                + " -> " + HexString.longToPaddedHex(this.newId1) + ","
                + HexString.longToPaddedHex(this.newId2) + " middlekey="
                + this.middleKey;
    }

    public void rollbackTask(OmapTs ts) throws IOException {
        if (splitResult != null) {
            LOG.info("Rollback: " + splitResult);
            Path oldTabletPath = new Path(OmapUtils.getSSTableFileDirPath(
                    OmapConfig.getTsTabletDir(),
                    splitResult.oldTablet.getTabletId()));
            if (!ts.getFs().exists(oldTabletPath)) {
                LOG.warning(splitResult.oldTablet
                        + " is already deleted, no need to roll back");
                return;
            }
            Tablet tablet = new Tablet(splitResult.oldTablet.getKeyRange(), ts,
                    false);
            try {
                ts.addTablet(tablet);
            } catch (TabletAlreadyExistsException e) {
                LOG.log(Level.WARNING, splitResult.oldTablet
                        + " exists, no need to add back", e);
            }
            ts.closeTablet(splitResult.newTablet1.getTabletId());
            ts.closeTablet(splitResult.newTablet2.getTabletId());
        } else {
            LOG.info(this + " unsuccessful, no need to roll back");
        }
    }

}
