package outfox.omap.walog;

import java.io.IOException;

public interface LogIterator {
    
    /**
     * Fetch the next log entry.
     * @param entry
     * @return false if no more entry could be found.
     */
    public boolean next(WALogEntry entry) throws IOException;

    /** 
     * Get current read position of the file
     * @return
     * @throws IOException
     */
    public long getPos() throws IOException;
    
    /**
     * Close the iterator and related streams.
     * @throws IOException
     */
    public void close();
    
}
