/**
 * @(#)DataReaderFactory.java, 2010-3-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import outfox.omap.exceptions.BadSchemaDefinitionException;
import toolbox.misc.LogFormatter;

/**
 * Fatcory mode class, used for create IDataReader Impl.
 * @author wangfk
 *
 */
public class DataReaderFactory {
    private static final Logger LOG = 
        LogFormatter.getLogger(DataReaderFactory.class);
    private static Map<String, ReaderType> readerTypeMap;


    /**
     * register a new DataReader here 
     * @author wangfk
     *
     */
    public static enum ReaderType {
        SQL,
        SEQFILE,
        DUMMY,
    }
    
    static {
        readerTypeMap = new HashMap<String, ReaderType>();
        readerTypeMap.put("SQL", ReaderType.SQL);
        readerTypeMap.put("SEQFILE", ReaderType.SEQFILE);
        readerTypeMap.put("DUMMY", ReaderType.DUMMY);
    }
    
    public static IDataReader createDataReader(String strType) {
        IDataReader res;
        ReaderType type = getReaderTypeFromString(strType);
        switch (type) {
            case SQL:
                res = new SqlDataReader();
                break;
            case SEQFILE:
                res = new SequenceFileReader();
                break;
            case DUMMY:
                res = new DummyDataReader();
                break;
            default:
                try {
                    res = (IDataReader)Class.forName(strType).newInstance();
                } catch (Exception e) {
                    LOG.warning("Unknown reader type: " + type);
                    throw new BadSchemaDefinitionException("Unknown reader type: " + type, e);
                }
        }
        return res;
    }
    
    /**
     * Lookup DataReader Type by String
     * @param str
     * @return
     */
    private static ReaderType getReaderTypeFromString(String str) {
        return readerTypeMap.get(str.toUpperCase());
    }
}
