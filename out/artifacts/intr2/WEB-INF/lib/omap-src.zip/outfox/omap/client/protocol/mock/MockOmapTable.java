/**
 * @(#)MockOmapTable.java, 2009-4-29. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol.mock;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.query.OmapQueryCondition;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapUtils;
import toolbox.misc.concurrent.KeyLock;

/**
 * @author zhangduo
 */
public class MockOmapTable implements Table {

    private final String tableName;

    private final Map<String, Integer> name2index = new HashMap<String, Integer>();

    private final String[] colTypes;

    private final MockOmapMetadata metadata;

    private final Map<String, Query> queries = new HashMap<String, Query>();

    private final SortedMap<IWritableComparable, MockOmapRow> rows = new TreeMap<IWritableComparable, MockOmapRow>();

    private final ReadWriteLock lock = new ReentrantReadWriteLock();

    private final KeyLock<IWritable> rowLock = new KeyLock<IWritable>();

    private final List<OpInterceptor> interceptors;

    public MockOmapTable(String tableName, String[] colNames,
            String[] colTypes, Query[] queries, List<OpInterceptor> interceptors) {
        this.tableName = tableName;
        OmapUtils.validateTableName(this.tableName);
        for (int i = 0; i < colNames.length; i++) {
            name2index.put(colNames[i], i);
        }
        this.colTypes = colTypes;
        if (queries != null) {
            for (Query query: queries) {
                this.queries.put(query.getName(), query);
            }
            metadata = new MockOmapMetadata(tableName, colNames, colTypes,
                    this.queries);
        } else {
            metadata = new MockOmapMetadata(tableName, colNames, colTypes, null);
        }
        this.interceptors = interceptors;
    }

    @Override
    public void close() {}

    private boolean validate(MockOmapQuery query, MockOmapRow row) {
        for (OmapQueryCondition condition: query.getConditions()) {
            if (!condition.isMatch((IWritableComparable) (row.getIWritable(metadata.getColumnIndex(condition.getColumnName()))))) {
                return false;
            }
        }
        return true;
    }

    private static class QueryComparator implements Comparator<MockOmapRow> {
        private MockOmapQuery query;

        public QueryComparator(MockOmapQuery query) {
            this.query = query;
        }

        private IWritableComparable buildQueryKey(MockOmapRow row) {
            OmapQueryCondition[] conditions = query.getConditions();
            IWritableComparable[] objs = new IWritableComparable[conditions.length + 1];
            for (int i = 0; i < conditions.length; i++) {
                objs[i] = (IWritableComparable) row.getIWritable(conditions[i].getColumnName());
            }
            objs[objs.length - 1] = row.getKey();
            return OmapUtils.buildTupleKey(objs);
        }

        @Override
        public int compare(MockOmapRow o1, MockOmapRow o2) {
            IWritableComparable k1 = buildQueryKey(o1);
            IWritableComparable k2 = buildQueryKey(o2);
            return k1.compareTo(k2);
        }
    }

    // how to sort by query condtions?
    @Override
    public List<IWritable> execute(Query query) throws OmapException {
        MockOmapQuery mq = (MockOmapQuery) query;

        lock.readLock().lock();
        try {
            PriorityQueue<MockOmapRow> queue = new PriorityQueue<MockOmapRow>(
                    rows.size(), new QueryComparator(mq));
            for (Map.Entry<IWritableComparable, MockOmapRow> entry: rows.entrySet()) {
                MockOmapRow row = entry.getValue();
                if (validate(mq, row)) {
                    queue.add(row);
                }
            }
            List<IWritable> ret = new ArrayList<IWritable>(queue.size());
            while (!queue.isEmpty()) {
                ret.add(queue.poll().getKey());
            }
            return ret;
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public List<IWritable> execute(String queryName) throws OmapException {
        return execute(getQuery(queryName));
    }

    @Override
    public Metadata getMetadata() {
        return metadata;
    }

    @Override
    public Query getQuery(String queryName) {
        return queries.get(queryName);
    }

    @Override
    public int getQueryCount() {
        return queries.size();
    }

    @Override
    public TableCursor getQueryCursor(String queryName) throws OmapException {
        return getQueryCursor(getQuery(queryName));
    }

    private class MockOmapQueryCursor implements TableCursor {

        private PriorityQueue<MockOmapRow> queue;

        public MockOmapQueryCursor(MockOmapQuery query) {
            lock.readLock().lock();
            try {
                queue = new PriorityQueue<MockOmapRow>(rows.size(),
                        new QueryComparator(query));
                for (Map.Entry<IWritableComparable, MockOmapRow> entry: rows.entrySet()) {
                    MockOmapRow row = entry.getValue();
                    if (validate(query, row)) {
                        MockOmapRow copyRow = new MockOmapRow(name2index,
                                colTypes);
                        copyRow.copyFields(row);
                        queue.add(copyRow);
                    }
                }
            } finally {
                lock.readLock().unlock();
            }
        }

        @Override
        public void close() throws OmapException {}

        @Override
        public boolean hasNext() throws OmapException {
            return !queue.isEmpty();
        }

        @Override
        public boolean moveTo(IWritable key, boolean accurate)
                throws OmapException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean next(Row row) throws OmapException {
            if (queue.isEmpty()) {
                return false;
            }
            ((MockOmapRow) row).copyFields(queue.poll());
            return true;
        }

        @Override
        public void remove() throws OmapException {
            throw new UnsupportedOperationException();
        }

        @Override
        public void reset() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setEndKey(IWritable endKeyExclusive) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setPrefetch(int prefetchDistance) throws OmapException {}
    }

    @Override
    public TableCursor getQueryCursor(Query query) throws OmapException {
        return new MockOmapQueryCursor((MockOmapQuery) query);
    }

    @Override
    public TableCursor getTableCursor() throws OmapException {
        for (OpInterceptor interceptor: interceptors) {
            interceptor.beforeGetTableCursor(tableName);
        }
        TableCursor cursor = new MockOmapTableCursor();
        for (OpInterceptor interceptor: interceptors) {
            interceptor.afterGetTableCursor(tableName);
        }
        return cursor;
    }

    private class MockOmapTableCursor implements TableCursor {

        private LinkedList<MockOmapRow> prefetchQueue = new LinkedList<MockOmapRow>();

        private int prefetchDistance = 5;

        private IWritable currentKey;

        private MockOmapRow currentRow;

        private IWritableComparable endKeyExclusive;

        private void fetch(boolean moveTo) {
            if (!prefetchQueue.isEmpty()) {
                return;
            }
            lock.readLock().lock();
            try {
                Iterator<Map.Entry<IWritableComparable, MockOmapRow>> iter = rows.entrySet().iterator();
                if (currentKey != null) {
                    while (iter.hasNext()) {
                        Map.Entry<IWritableComparable, MockOmapRow> entry = iter.next();
                        if (endKeyExclusive != null
                                && entry.getKey().compareTo(endKeyExclusive) >= 0) {
                            return;
                        }
                        int cmp = entry.getKey().compareTo(currentKey);
                        if (cmp > 0 || (moveTo && cmp == 0)) {
                            prefetchQueue.add(entry.getValue());
                            break;
                        }
                    }
                }
                while (prefetchQueue.size() < prefetchDistance
                        && iter.hasNext()) {
                    Map.Entry<IWritableComparable, MockOmapRow> entry = iter.next();
                    if (endKeyExclusive != null
                            && entry.getKey().compareTo(endKeyExclusive) >= 0) {
                        break;
                    }
                    prefetchQueue.add(entry.getValue());
                }
            } finally {
                lock.readLock().unlock();
            }
        }

        @Override
        public void close() throws OmapException {}

        @Override
        public boolean hasNext() throws OmapException {
            fetch(false);
            return !prefetchQueue.isEmpty();
        }

        @Override
        public boolean moveTo(IWritable key, boolean accurate)
                throws OmapException {
            for (OpInterceptor interceptor: interceptors) {
                interceptor.beforeTableCursorMoveTo(tableName, key, accurate);
            }
            currentKey = key;
            prefetchQueue.clear();
            fetch(true);
            if (prefetchQueue.isEmpty()) {
                for (OpInterceptor interceptor: interceptors) {
                    interceptor.afterTableCursorMoveTo(tableName, key,
                            accurate, false);
                }
                return false;
            }
            if (accurate && !prefetchQueue.getFirst().getKey().equals(key)) {
                for (OpInterceptor interceptor: interceptors) {
                    interceptor.afterTableCursorMoveTo(tableName, key,
                            accurate, false);
                }
                return false;
            }
            for (OpInterceptor interceptor: interceptors) {
                interceptor.afterTableCursorMoveTo(tableName, key, accurate,
                        true);
            }
            return true;

        }

        @Override
        public boolean next(Row row) throws OmapException {
            for (OpInterceptor interceptor: interceptors) {
                interceptor.beforeTableCursorNext(tableName);
            }
            fetch(false);
            if (prefetchQueue.isEmpty()) {
                currentRow = null;
                currentKey = null;
                for (OpInterceptor interceptor: interceptors) {
                    interceptor.afterTableCursorNext(tableName, row, false);
                }
                return false;
            }
            currentRow = prefetchQueue.poll();
            currentKey = currentRow.getKey();
            ((MockOmapRow) row).copyFields(currentRow);
            for (OpInterceptor interceptor: interceptors) {
                interceptor.afterTableCursorNext(tableName, row, true);
            }
            return true;
        }

        @Override
        public void remove() throws OmapException {
            for (OpInterceptor interceptor: interceptors) {
                interceptor.beforeTableCursorRemove(tableName);
            }
            if (currentKey == null) {
                throw new NoSuchElementException();
            }
            delete(currentKey);
            for (OpInterceptor interceptor: interceptors) {
                interceptor.afterTableCursorRemove(tableName, currentKey);
            }
        }

        @Override
        public void setPrefetch(int prefetchDistance) throws OmapException {
            this.prefetchDistance = prefetchDistance;
        }

        @Override
        public void setEndKey(IWritable endKeyExclusive) {
            this.endKeyExclusive = (IWritableComparable) endKeyExclusive;
        }

        @Override
        public void reset() {
            lock.readLock().lock();
            try {
                Iterator<Entry<IWritableComparable, MockOmapRow>> iterator = rows.entrySet().iterator();
                if (iterator.hasNext()) {
                    currentKey = iterator.next().getKey();
                    fetch(true);
                }
            } finally {
                lock.readLock().unlock();
            }
        }

    }

    @Override
    public boolean lookup(IWritable key, Row row) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeLookup(tableName, key);
        }
        boolean found;
        lock.readLock().lock();
        try {
            MockOmapRow r = rows.get(key);
            if (r != null) {
                ((MockOmapRow) row).copyFields(r);
                found = true;
            } else {
                found = false;
            }
        } finally {
            lock.readLock().unlock();
        }
        for (OpInterceptor i: interceptors) {
            i.afterLookup(tableName, key, row, found);
        }
        return found;
    }

    @Override
    public boolean[] lookup(IWritable[] keys, Row[] rows) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeLookup(tableName, keys);
        }
        if (keys.length != rows.length) {
            throw new IllegalArgumentException();
        }
        boolean[] ret = new boolean[keys.length];
        for (int i = 0; i < keys.length; i++) {
            ret[i] = lookup(keys[i], rows[i]);
        }
        for (OpInterceptor i: interceptors) {
            i.afterLookup(tableName, keys, rows, ret);
        }
        return ret;
    }

    @Override
    public boolean contains(IWritable key) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeContains(tableName, key);
        }
        boolean found;
        lock.readLock().lock();
        try {
            found = rows.containsKey(key);
        } finally {
            lock.readLock().unlock();
        }
        for (OpInterceptor i: interceptors) {
            i.afterContains(tableName, key, found);
        }
        return found;
    }

    @Override
    public boolean[] contains(IWritable[] keys) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeContains(tableName, keys);
        }
        boolean[] ret = new boolean[keys.length];
        for (int i = 0; i < keys.length; i++) {
            ret[i] = contains(keys[i]);
        }
        for (OpInterceptor i: interceptors) {
            i.afterContains(tableName, keys, ret);
        }
        return ret;
    }

    @Override
    public void update(Row row) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeUpdate(tableName, row);
        }
        lock.writeLock().lock();
        try {
            MockOmapRow r = new MockOmapRow(name2index, colTypes);
            r.copyFields((MockOmapRow) row);
            rows.put(r.getKey(), r);
        } finally {
            lock.writeLock().unlock();
        }
        for (OpInterceptor i: interceptors) {
            i.afterUpdate(tableName, row);
        }
    }

    @Override
    public void update(Row[] rows) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeUpdate(tableName, rows);
        }
        for (Row row: rows) {
            update(row);
        }
        for (OpInterceptor i: interceptors) {
            i.afterUpdate(tableName, rows);
        }
    }

    @Override
    public void delete(IWritable key) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeDelete(tableName, key);
        }
        lock.writeLock().lock();
        try {
            rows.remove(key);
        } finally {
            lock.writeLock().unlock();
        }
        for (OpInterceptor i: interceptors) {
            i.afterDelete(tableName, key);
        }
    }

    @Override
    public void delete(IWritable[] keys) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeDelete(tableName, keys);
        }
        for (IWritable key: keys) {
            delete(key);
        }
        for (OpInterceptor i: interceptors) {
            i.afterDelete(tableName, keys);
        }
    }

    @Override
    public void delete(IWritable startKeyInclusive, IWritable endKeyExclusive)
            throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeDelete(tableName, startKeyInclusive, endKeyExclusive);
        }
        lock.writeLock().lock();
        try {
            rows.subMap((IWritableComparable) startKeyInclusive,
                    (IWritableComparable) endKeyExclusive).clear();
        } finally {
            lock.writeLock().unlock();
        }
        for (OpInterceptor i: interceptors) {
            i.afterDelete(tableName, startKeyInclusive, endKeyExclusive);
        }
    }

    @Override
    public boolean compareAndUpdate(IWritable key, String columnName,
            IWritable columnValue, Row update) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeCompareAndUpdate(columnName, key, columnName, columnValue,
                    update);
        }
        boolean pass;
        IWritable ck = new MockOmapRow(name2index, colTypes).getKey();
        ck.copyFields(key);
        rowLock.lock(ck, 0);
        try {
            MockOmapRow r = new MockOmapRow(name2index, colTypes);
            boolean found = lookup(key, r);
            if (columnName == null) {
                pass = !found;
            } else {
                if (columnValue == null) {
                    pass = r.getStatus(columnName) == Row.STATUS_NULL;
                } else {
                    pass = columnValue.equals(r.getIWritable(columnName));
                }
            }
            if (pass) {
                update(update);
            }
        } finally {
            rowLock.unlock(ck);
        }
        for (OpInterceptor i: interceptors) {
            i.afterCompareAndUpdate(columnName, key, columnName, columnValue,
                    update, pass);
        }
        return pass;
    }

    @Override
    public boolean compareAndDelete(IWritable key, String columnName,
            IWritable columnValue, IWritable delete) throws OmapException {
        for (OpInterceptor i: interceptors) {
            i.beforeCompareAndDelete(columnName, key, columnName, columnValue,
                    delete);
        }
        boolean pass;
        IWritable ck = new MockOmapRow(name2index, colTypes).getKey();
        ck.copyFields(key);
        rowLock.lock(ck, 0);
        try {
            MockOmapRow r = new MockOmapRow(name2index, colTypes);
            boolean found = lookup(key, r);

            if (columnName == null) {
                pass = !found;
            } else {
                if (columnValue == null) {
                    pass = r.getStatus(columnName) == Row.STATUS_NULL;
                } else {
                    pass = columnValue.equals(r.getIWritable(columnName));
                }
            }
            if (pass) {
                delete(delete);
            }
        } finally {
            rowLock.unlock(ck);
        }
        for (OpInterceptor i: interceptors) {
            i.afterCompareAndDelete(columnName, key, columnName, columnValue,
                    delete, pass);
        }
        return pass;
    }

    @Override
    public Row newRow() throws OmapException {
        return new MockOmapRow(name2index, colTypes);
    }

    @Override
    public Iterator<? extends Query> queryIterator() {
        return queries.values().iterator();
    }

    @Override
    public void setProperty(String name, String value) throws OmapException {
        // TODO Auto-generated method stub

    }

    @Override
    public void chmod(String mode) throws OmapException {
        // TODO Auto-generated method stub

    }

    @Override
    public void setGroupUsers(List<String> groupUsers) throws OmapException {
        // TODO Auto-generated method stub

    }

}
