package outfox.omap.util;

import java.util.Comparator;

import odis.serialize.IWritableComparable;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
/**
 * A generic comparator that accepts null values. The meaning of null values is defined as MIN.
 * It also supports the comparison between KeyPair/KeyRange and IWritable
 * {@link #nullAsMax}.
 * @author zhangkun
 *
 */
public class GenericWritableComparator implements Comparator<IWritableComparable> {
    public static final GenericWritableComparator instance = new GenericWritableComparator();
    public int compare(IWritableComparable o1, IWritableComparable o2) {
        // patch to let NULL values (representing MIN) comparable to KeyRange
        if(o1 instanceof KeyRange) {
            return o1.compareTo(o2);
        }
        if(o2 instanceof KeyRange) {
            return -o2.compareTo(o1);
        }
        
        if(o1 == null) {
            if(o2 != null) {
                return -1;
            } else {
                return 0;
            }
        } else if(o2 == null) {
            if(o1 != null) {
                return 1;
            }
        }
        if(KeyPair.class.isAssignableFrom(o2.getClass())) {
            // o2 is KeyPair or subclass of KeyPair
            return -o2.compareTo(o1);
        }
        if(o2 instanceof KeyRange.MaxWritable) {
            return -o2.compareTo(o1);
        }
        return o1.compareTo(o2);
    }

}
