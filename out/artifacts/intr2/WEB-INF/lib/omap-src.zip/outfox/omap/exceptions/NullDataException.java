package outfox.omap.exceptions;

public class NullDataException extends RuntimeException {

    private static final long serialVersionUID = 6570195220406537654L;
    
    public NullDataException() {
        this("Trying to get data from a NULL data cell");
    }
    
    public NullDataException(String message) {
        super(message);
    }
    

}
