/**
 * @(#)ClientConfig.java, 2010-12-29. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import odis.conf.ConfigUtils;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import toolbox.misc.LogFormatter;

/**
 * Configuration used at client side.
 * 
 * @author zhangduo
 */
public class ClientConfig implements Configuration {

    private static final Logger LOG = LogFormatter.getLogger(ClientConfig.class);

    private static final File OMAP_HOME;

    static {
        String tmp = System.getProperty("omap.home");
        if (tmp == null) {
            tmp = System.getenv("OMAP_HOME");
        }
        if (tmp == null) {
            tmp = System.getProperty("odis.home");
        }
        if (tmp == null) {
            tmp = System.getenv("ODIS_HOME");
        }
        if (tmp == null) {
            tmp = ".";
        }
        OMAP_HOME = new File(tmp);
        LOG.info("omap home set to " + OMAP_HOME.getAbsolutePath());
    }

    public static final String NAME_ZOOKEEPER_ADDRESS = "omap.zookeeper.address";

    public static final String NAME_OMAP_ZOOKEEPER_ROOT = "omap.zookeeper.root";

    public static final String NAME_ACTIVE_MASTER_ZNODE_NAME = "omap.master.active-znode";

    public static final String DEFAULT_ACTIVE_MASTER_ZNODE_NAME = "master.active";

    public static final String NAME_CLIENT_ZOOKEEPER_TIMEOUT = "omap.client.zookeeper-timeout";

    // in milliseconds
    public static final int DEFAULT_CLIENT_ZOOKEEPER_TIMEOUT = 5000;

    // connection timeout in millis
    public static final String NAME_CLIENT_CONNECT_TIMEOUT = "omap.client.connect-timeout";

    public static final long DEFAULT_CLIENT_CONNECT_TIMEOUT = 60000;
    
    public static final String NAME_CLIENT_USER_NAME = "omap.client.user-name";
    
    public static final String DEFAULT_CLIENT_USER_NAME = System.getProperty("user.name");

    private final Configuration conf;

    public ClientConfig(String configFile) {
        LOG.info("load client config from configFile " + configFile);
        try {
            conf = ConfigUtils.parseXmlConfig(new File(OMAP_HOME, "conf"),
                    new String[] {
                        configFile
                    });
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "parse omap configuration failed", e);
            throw new RuntimeException("parse omap configuration failed", e);
        }
        Set<String> validKeys = getValidKeys();
        for (Iterator<String> iter = conf.getKeys(); iter.hasNext();) {
            String key = iter.next();
            if (validKeys.contains(key)) {
                LOG.info("Read configuration: " + key + "="
                        + conf.getProperty(key));
            } else {
                LOG.warning("Undefined configuration item: " + key);
            }
        }
    }

    public static Set<String> getValidKeys() {
        Set<String> validKeys = new HashSet<String>();
        for (Field field: ClientConfig.class.getFields()) {
            if (field.getType().equals(String.class)
                    && field.getName().startsWith("NAME_")) {
                try {
                    validKeys.add((String) field.get(null));
                } catch (Exception e) {}
            }
        }
        return validKeys;
    }

    public ClientConfig(Configuration conf) {
        this.conf = conf;
    }

    public Configuration getConf() {
        return conf;
    }

    public String getZkAddress() {
        String[] addrs = conf.getStringArray(NAME_ZOOKEEPER_ADDRESS);
        StringBuilder sb = new StringBuilder(addrs[0]);
        for (int i = 1; i < addrs.length; i++) {
            sb.append(',').append(addrs[i]);
        }
        return sb.toString();
    }

    public String getZkActiveMasterPath() {
        return conf.getString(NAME_OMAP_ZOOKEEPER_ROOT)
                + "/"
                + conf.getString(NAME_ACTIVE_MASTER_ZNODE_NAME,
                        DEFAULT_ACTIVE_MASTER_ZNODE_NAME);
    }

    @Override
    public Configuration subset(String prefix) {
        return conf.subset(prefix);
    }

    @Override
    public boolean isEmpty() {
        return conf.isEmpty();
    }

    @Override
    public boolean containsKey(String key) {
        return conf.containsKey(key);
    }

    @Override
    public void addProperty(String key, Object value) {
        conf.addProperty(key, value);
    }

    @Override
    public void setProperty(String key, Object value) {
        conf.setProperty(key, value);
    }

    @Override
    public void clearProperty(String key) {
        conf.clearProperty(key);
    }

    @Override
    public void clear() {
        conf.clear();
    }

    @Override
    public Object getProperty(String key) {
        return null;
    }

    @Override
    public Iterator getKeys(String prefix) {
        return conf.getKeys(prefix);
    }

    @Override
    public Iterator getKeys() {
        return conf.getKeys();
    }

    @Override
    public Properties getProperties(String key) {
        return conf.getProperties(key);
    }

    @Override
    public boolean getBoolean(String key) {
        return conf.getBoolean(key);
    }

    @Override
    public boolean getBoolean(String key, boolean defaultValue) {
        return conf.getBoolean(key, defaultValue);
    }

    @Override
    public Boolean getBoolean(String key, Boolean defaultValue) {
        return conf.getBoolean(key, defaultValue);
    }

    @Override
    public byte getByte(String key) {
        return conf.getByte(key);
    }

    @Override
    public byte getByte(String key, byte defaultValue) {
        return conf.getByte(key, defaultValue);
    }

    @Override
    public Byte getByte(String key, Byte defaultValue) {
        return conf.getByte(key, defaultValue);
    }

    @Override
    public double getDouble(String key) {
        return conf.getDouble(key);
    }

    @Override
    public double getDouble(String key, double defaultValue) {
        return conf.getDouble(key, defaultValue);
    }

    @Override
    public Double getDouble(String key, Double defaultValue) {
        return conf.getDouble(key, defaultValue);
    }

    @Override
    public float getFloat(String key) {
        return conf.getFloat(key);
    }

    @Override
    public float getFloat(String key, float defaultValue) {
        return conf.getFloat(key, defaultValue);
    }

    @Override
    public Float getFloat(String key, Float defaultValue) {
        return conf.getFloat(key, defaultValue);
    }

    @Override
    public int getInt(String key) {
        return conf.getInt(key);
    }

    @Override
    public int getInt(String key, int defaultValue) {
        return conf.getInt(key, defaultValue);
    }

    @Override
    public Integer getInteger(String key, Integer defaultValue) {
        return conf.getInteger(key, defaultValue);
    }

    @Override
    public long getLong(String key) {
        return conf.getLong(key);
    }

    @Override
    public long getLong(String key, long defaultValue) {
        return conf.getLong(key, defaultValue);
    }

    @Override
    public Long getLong(String key, Long defaultValue) {
        return conf.getLong(key, defaultValue);
    }

    @Override
    public short getShort(String key) {
        return conf.getShort(key);
    }

    @Override
    public short getShort(String key, short defaultValue) {
        return conf.getShort(key, defaultValue);
    }

    @Override
    public Short getShort(String key, Short defaultValue) {
        return conf.getShort(key, defaultValue);
    }

    @Override
    public BigDecimal getBigDecimal(String key) {
        return conf.getBigDecimal(key);
    }

    @Override
    public BigDecimal getBigDecimal(String key, BigDecimal defaultValue) {
        return conf.getBigDecimal(key, defaultValue);
    }

    @Override
    public BigInteger getBigInteger(String key) {
        return conf.getBigInteger(key);
    }

    @Override
    public BigInteger getBigInteger(String key, BigInteger defaultValue) {
        return conf.getBigInteger(key, defaultValue);
    }

    @Override
    public String getString(String key) {
        return conf.getString(key);
    }

    @Override
    public String getString(String key, String defaultValue) {
        return conf.getString(key, defaultValue);
    }

    @Override
    public String[] getStringArray(String key) {
        return conf.getStringArray(key);
    }

    @Override
    public List getList(String key) {
        return conf.getList(key);
    }

    @Override
    public List getList(String key, List defaultValue) {
        return conf.getList(key, defaultValue);
    }
}
