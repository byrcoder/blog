package outfox.omap.ts.insertlog;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogBody;
import toolbox.text.util.HexString;

/**
 * A LogBody for an insertion operation
 * 
 * @author zhangkun
 */
public class WALogInsert implements WALogBody {

    private long tabletId;

    public long getTabletId() {
        return tabletId;
    }

    private ByteArrayWritable data;

    public ByteArrayWritable getData() {
        return data;
    }

    public WALogInsert() {
        this.data = new ByteArrayWritable();
    }

    /**
     * The data will be copied, rather than just referenced.
     * 
     * @param tabletId
     * @param data
     */
    public WALogInsert(long tabletId, ByteArrayWritable data) {
        this();
        this.tabletId = tabletId;
        this.data.copyFields(data);
    }

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            throw new IllegalArgumentException("cannot copy from myself");
        }
        WALogInsert v = (WALogInsert) value;
        this.tabletId = v.tabletId;
        this.data.copyFields(v.data);
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        this.tabletId = in.readLong();
        data.readFields(in);
    }

    public void getKey(KeyCell key) {
        DataRow.keyCellFromBinaryRow(key, data.data());
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(this.tabletId);
        data.writeFields(out);
    }

    @Override
    public int hashCode() {
        return (int) (tabletId ^ (tabletId >>> 32)) ^ data.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        WALogInsert v = (WALogInsert) obj;
        return this.tabletId == v.tabletId && this.data.equals(v.data);
    }

    public String toString() {
        return HexString.longToPaddedHex(tabletId) + "(RAW)" + data;
    }

    @Override
    public String toStructuredString(MetadataProvider provider) {
        TableDesc td = provider.get(OmapUtils.tid2sid(tabletId)).getTableDesc();
        DataRow row = td.borrowDataRow();
        try {
            DataRow.dataRowFromBinaryRow(row, data.data());
            return HexString.longToPaddedHex(tabletId) + ": " + row;
        } finally {
            td.returnDataRow(row);
        }
    }

}
