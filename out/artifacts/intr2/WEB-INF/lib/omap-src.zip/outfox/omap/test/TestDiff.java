/**
 * @(#)TestDiff.java, 2011-11-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.test;

import java.util.Random;
import java.io.PrintWriter;

import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.util.OmapUtils;

/**
 * @author wangfk
 */
public class TestDiff {
    public static void main(String[] args) throws Exception {
        if (args.length != 3 && args.length != 4) {
            System.err.println("USAGE: TestDiff2 <table1> <table2> <rows_limit> [out file]");
            return;
        }
        DataSource dataSource = DataSourceFactory.getNamed(DataSourceFactory.NAME_OMAP_DATA_SOURCE);
        String tableSpace1 = args[0].split("\\$")[0];
        String tableSpace2 = args[1].split("\\$")[0];
        String tableName1 = args[0].split("\\$")[1];
        String tableName2 = args[1].split("\\$")[1];

        int rowsLimit = Integer.parseInt(args[2]);

        PrintWriter pw = args.length == 4 ? new PrintWriter(args[3]) : null;

        Table table1 = dataSource.openTableSpace(tableSpace1).openTable(
                tableName1);
        Table table2 = dataSource.openTableSpace(tableSpace2).openTable(
                tableName2);

        TableCursor tableCursor1 = table1.getTableCursor();
        TableCursor tableCursor2 = table2.getTableCursor();

        IntWritable key1 = new IntWritable();
        IntWritable key2 = new IntWritable();
        StringWritable value1 = new StringWritable();
        StringWritable value2 = new StringWritable();

        tableCursor1.reset();
        tableCursor2.reset();

        Row row1 = table1.newRow();
        Row row2 = table2.newRow();

        Random rand = new Random();
        IntWritable randKey = new IntWritable();
        Row randRow = table1.newRow();

        for (int i = 0; i < rowsLimit; ++i) {
            randKey.set(rand.nextInt());
            TableCursor randCursor = null;
            if (rand.nextBoolean()) {
                randCursor = tableCursor1;
            } else {
                randCursor = tableCursor2;
            }
            if (!randCursor.moveTo(randKey, false)) {
                continue;
            }
            randCursor.next(randRow);
            randRow.get(0, randKey);

            boolean lookup1 = table1.lookup(randKey, row1);
            boolean lookup2 = table2.lookup(randKey, row2);

            if (lookup1) {
                row1.get(0, key1);
                row1.get(1, value1);
            }
            if (lookup2) {
                row2.get(0, key2);
                row2.get(1, value2);
            }

            if (lookup1 && lookup2) {
                if (value1.compareTo(value2) != 0) {
                    pw.println(key1.get() + "\t" + value1.get() + "\t"
                            + value2.get());
                }
            } else if (lookup1) {
                if (pw == null) {
                    System.out.println(key1.get() + "\t" + value1.get()
                            + "\tNULL");
                } else {
                    pw.println(key1.get() + "\t" + value1.get() + "\tNULL");
                }
            } else if (lookup2) {
                if (pw == null) {
                    System.out.println(key2.get() + "\tNULL\t" + value2.get());
                } else {
                    pw.println(key2.get() + "\tNULL\t" + value2.get());
                }
            }
        }

        OmapUtils.safeClose(pw);
    }
}
