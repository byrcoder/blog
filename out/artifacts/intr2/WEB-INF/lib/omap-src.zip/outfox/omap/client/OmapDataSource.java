/**
 * @(#)OmapDataSource.java, 2010-1-13. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

import odis.rpc2.RpcException;

import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.exceptions.OmapException;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class OmapDataSource implements DataSource {

    private static final Logger LOG = LogFormatter.getLogger(OmapDataSource.class);

    private final MasterWatcherAndClientConfig masterWatcher;

    private final AtomicLong refCount = new AtomicLong(1);

    public OmapDataSource(ClientConfig conf) throws IOException {
        masterWatcher = new MasterWatcherAndClientConfig(conf);
        Runtime.getRuntime().addShutdownHook(new Thread() {

            @Override
            public void run() {
                LOG.info("OmapDataSource shutdown hook");
                close();
            }

        });
    }

    public MasterWatcherAndClientConfig getMasterWatcher() {
        return masterWatcher;
    }

    public TableSpace openTableSpace(String tableSpaceName)
            throws OmapException {
        return new OmapTableSpace(tableSpaceName, masterWatcher);
    }

    @Override
    public void close() {
        if (refCount.decrementAndGet() == 0) {
            LOG.info("closing OmapDataSource");
            masterWatcher.close();
        }
    }

    @Override
    public String[] listTableSpaces() throws OmapException {
        try {
            return masterWatcher.getMaster().getTableSpaces();
        } catch (RpcException e) {
            throw new OmapException(e);
        }
    }

    @Override
    public boolean retain() {
        for (;;) {
            long current = refCount.get();
            if (current == 0) {
                return false;
            }
            long next = current + 1;
            if (refCount.compareAndSet(current, next)) {
                return true;
            }
        }
    }

}
