/**
 * @(#)MetricsEntry.java, 2011-6-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class MetricsEntry implements IWritable {

    private final MasterMetricsEntry masterMetricsEntry;

    private final List<TsMetricsEntry> tsMetricsEntries;

    public MetricsEntry() {
        masterMetricsEntry = new MasterMetricsEntry();
        tsMetricsEntries = new ArrayList<TsMetricsEntry>();
    }

    public MetricsEntry(MasterMetricsEntry masterMetricsEntry,
            List<TsMetricsEntry> tsMetricsEntries) {
        this.masterMetricsEntry = masterMetricsEntry;
        this.tsMetricsEntries = tsMetricsEntries;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        MetricsEntry that = (MetricsEntry) value;
        masterMetricsEntry.copyFields(that.masterMetricsEntry);
        int length = Math.min(tsMetricsEntries.size(),
                that.tsMetricsEntries.size());
        for (int i = 0; i < length; i++) {
            tsMetricsEntries.get(i).copyFields(that.tsMetricsEntries.get(i));
        }
        for (int i = tsMetricsEntries.size() - 1; i>= length; i--) {
            tsMetricsEntries.remove(i);
        }
        for (int i = length; i < that.tsMetricsEntries.size(); i++) {
           TsMetricsEntry tsMetricsEntry = new TsMetricsEntry();
           tsMetricsEntry.copyFields(that.tsMetricsEntries.get(i));
           tsMetricsEntries.add(tsMetricsEntry);
        }
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        masterMetricsEntry.writeFields(out);
        CDataOutputStream.writeVInt(tsMetricsEntries.size(), out);
        for (TsMetricsEntry tsMetricsEntry: tsMetricsEntries) {
            tsMetricsEntry.writeFields(out);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        masterMetricsEntry.readFields(in);
        int size = CDataInputStream.readVInt(in);
        int copyLength = Math.min(size, tsMetricsEntries.size());
        for (int i = 0; i < copyLength; i++) {
            tsMetricsEntries.get(i).readFields(in);
        }
        for (int i = tsMetricsEntries.size() - 1; i>= copyLength; i--) {
            tsMetricsEntries.remove(i);
        }
        for (int i = copyLength; i < size; i++) {
            TsMetricsEntry tsMetricsEntry = new TsMetricsEntry();
            tsMetricsEntry.readFields(in);
            tsMetricsEntries.add(tsMetricsEntry);
        }
    } 

    public MasterMetricsEntry getMasterMetricsEntry() {
        return masterMetricsEntry;
    }

    public List<TsMetricsEntry> getTsMetricsEntries() {
        return tsMetricsEntries;
    }

}
