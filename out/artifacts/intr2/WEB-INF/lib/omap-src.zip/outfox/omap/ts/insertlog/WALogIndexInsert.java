/**
 * @(#)WALogIndexInsert.java, 2009-3-13. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts.insertlog;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.data.DataRow;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogBody;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class WALogIndexInsert implements WALogBody {

    private long tabletId;

    private ByteArrayWritable oldData = new ByteArrayWritable();

    private ByteArrayWritable newData = new ByteArrayWritable();

    public WALogIndexInsert() {}

    /**
     * @return the tabletId
     */
    public long getTabletId() {
        return tabletId;
    }

    /**
     * @return the oldData
     */
    public ByteArrayWritable getOldData() {
        return oldData;
    }

    /**
     * @return the newData
     */
    public ByteArrayWritable getNewData() {
        return newData;
    }

    public WALogIndexInsert(long tabletId, ByteArrayWritable oldData,
            ByteArrayWritable newData) {
        this.tabletId = tabletId;
        this.oldData.copyFields(oldData);
        this.newData.copyFields(newData);
    }

    public void readFields(DataInput in) throws IOException {
        tabletId = in.readLong();
        oldData.readFields(in);
        newData.readFields(in);
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(tabletId);
        oldData.writeFields(out);
        newData.writeFields(out);
    }

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            throw new IllegalArgumentException("cannot copy from myself");
        }
        WALogIndexInsert v = (WALogIndexInsert) value;
        tabletId = v.tabletId;
        oldData.copyFields(v.oldData);
        newData.copyFields(v.newData);
        return this;
    }

    @Override
    public int hashCode() {
        return (int) (tabletId ^ (tabletId >>> 32)) ^ oldData.hashCode()
                ^ newData.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        WALogIndexInsert other = (WALogIndexInsert) obj;
        return tabletId == other.tabletId && oldData.equals(other.oldData)
                && newData.equals(other.newData);
    }

    @Override
    public String toStructuredString(MetadataProvider provider) {
        StringBuilder sb;
        TableDesc td = provider.get(OmapUtils.tid2sid(tabletId)).getTableDesc();
        DataRow row = td.borrowDataRow();
        try {
            DataRow.dataRowFromBinaryRow(row, newData.data());
            sb = new StringBuilder(HexString.longToPaddedHex(tabletId)).append(
                    ": newData").append(row).append(" oldData");
            DataRow.dataRowFromBinaryRow(row, oldData.data());
            sb.append(oldData);
            return sb.toString();
        } finally {
            td.returnDataRow(row);
        }
    }

    @Override
    public String toString() {
        return HexString.longToPaddedHex(tabletId) + " newData(RAW)" + newData
                + " oldData(RAW)" + oldData;
    }

}
