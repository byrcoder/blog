package outfox.omap.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.Serializable;

import odis.serialize.IWritable;
import odis.serialize.lib.UTF8Writable;

/**
 * keeps necessary information to locate a TS.
 * 
 * @author xuw
 */
public class TsDesc implements IWritable, Serializable, Comparable<TsDesc> {
    private static final long serialVersionUID = 9049537714211408410L;

    private String host = null;

    private int port = -1;

    // useful when ts reboot
    private long timestamp;

    private static final String DUMMY_TS_HOST = "NO_SUCH_TS";

    private static final TsDesc DUMMY_TS_DESC = new TsDesc(DUMMY_TS_HOST, -1, 0);

    public static TsDesc getDummyTsDesc() {
        return DUMMY_TS_DESC;
    }

    /**
     * Only for use with readFields/copyFields
     */
    public TsDesc() {}

    public TsDesc(String host, int port, long timestamp) {
        this.host = host;
        this.port = port;
        this.timestamp = timestamp;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void readFields(DataInput in) throws IOException {
        host = UTF8Writable.readString(in);
        port = in.readInt();
        timestamp = in.readLong();
    }

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            throw new IllegalArgumentException("cannot copy to myself");
        }
        TsDesc v = (TsDesc) value;
        this.host = v.host;
        this.port = v.port;
        this.timestamp = v.timestamp;
        return this;
    }

    public void writeFields(DataOutput out) throws IOException {
        UTF8Writable.writeString(out, host);
        out.writeInt(port);
        out.writeLong(timestamp);
    }

    public String toString() {
        if (DUMMY_TS_HOST.equals(host)) {
            return "DUMMY";
        }
        return host + ":" + port + ":" + timestamp;
    }

    public String getHostPort() {
        return host + ":" + port;
    }

    public String getWALDirLastName() {
        return this.host + "-" + this.port + "-" + timestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof TsDesc))
            return false;

        TsDesc td = (TsDesc) o;
        return port == td.port && host.equals(td.host)
                && timestamp == td.timestamp;
    }

    @Override
    public int hashCode() {
        return host.hashCode() ^ port ^ (int) timestamp;
    }

    @Override
    public int compareTo(TsDesc o) {
        int res = host.compareTo(o.host);
        if (res != 0) {
            return res;
        }
        if (port > o.port) {
            return 1;
        }
        if (port < o.port) {
            return -1;
        }

        return timestamp > o.timestamp ? 1 : timestamp == o.timestamp ? 0 : -1;
    }

    public boolean isDummyTs() {
        return DUMMY_TS_HOST.equals(host);
    }
}
