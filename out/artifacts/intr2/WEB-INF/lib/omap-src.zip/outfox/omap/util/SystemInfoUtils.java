/**
 * @(#)SystemInfoUtils.java, 2010-5-13. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.OperatingSystemMXBean;

/**
 * @author zhangduo
 */
public class SystemInfoUtils {

    private static final MemoryMXBean MEMORY_MX_BEAN = ManagementFactory.getMemoryMXBean();

    private static final OperatingSystemMXBean OPERATING_SYSTEM_MX_BEAN = ManagementFactory.getOperatingSystemMXBean();

    public static MemoryUsage getMemoryUsage() {
        return MEMORY_MX_BEAN.getHeapMemoryUsage();
    }

    public static int getProcessors() {
        return OPERATING_SYSTEM_MX_BEAN.getAvailableProcessors();
    }

    public static double getLoadPerProcessor() {
        return OPERATING_SYSTEM_MX_BEAN.getSystemLoadAverage()
                / OPERATING_SYSTEM_MX_BEAN.getAvailableProcessors();
    }

    public static double getLoad() {
        return OPERATING_SYSTEM_MX_BEAN.getSystemLoadAverage();
    }
}
