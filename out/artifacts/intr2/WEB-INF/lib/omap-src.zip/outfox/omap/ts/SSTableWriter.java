/**
 * @(#)SSTWriter.java, 2010-3-19. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.Closeable;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPOutputStream;

import odis.dfs.client.DistributedFileSystem;
import odis.file.IRecordWriter;
import odis.file.SequenceFile;
import odis.io.CDataOutputStream;
import odis.io.DataOutputBuffer;
import odis.io.DirectByteArrayOutputStream;
import odis.io.FSDataOutputStream;
import odis.io.IFileSystem;
import odis.io.LzoCompression;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.client.protocol.Table;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.DataRow;
import outfox.omap.ts.SSTable.MetaData;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.bloom.Hash;
import toolbox.text.util.HexString;

/**
 * @author wangfk, zhangduo
 */
public class SSTableWriter implements
        IRecordWriter<ByteArrayWritable, ByteArrayWritable>, Closeable {

    private static final Logger LOG = LogFormatter.getLogger(SSTableWriter.class);

    private final IFileSystem fs;

    /** writer for data */
    private final SequenceFile.Writer dataOut;

    /** writer for sparse index */
    private final SequenceFile.Writer sparseIndexWriter;

    /** writer for bloom filter */
    private final WritableBloomFilter bloomFilter;

    private final DataOutputBuffer compressBuffer;

    private long sparseIndexEntryCount = 0;

    private long entryCount = 0;

    private long deletedEntryCount = 0;

    private long originalDataSize = 0;

    private final int indexKeyMaxByteDistance;

    private final int indexKeyMaxRecordDistance;

    private long lastIndexedEntryOffset = 0;

    private long lastIndexedEntryIndex = 0;

    private final Path path;

    private final CompressType compressType;

    private final int flags;

    private double compressRate;

    public Path getPath() {
        return path;
    }

    public SSTableWriter(IFileSystem nfs, Path dir, long expectedElements,
            CompressType compressType) throws IOException {
        this(nfs, dir, false, 0, expectedElements,
                OmapConfig.getConfiguration().getBoolean(
                        OmapConfig.NAME_ENABLE_BLOOM_FILTER,
                        OmapConfig.DEFAULT_ENABLE_BLOOM_FILTER), compressType,
                Float.parseFloat(Table.Property.DEFAULT_BLOOMFILTER_FALSERATE),
                Byte.parseByte(Table.Property.DEFAULT_REPLICATION));
    }

    /**
     * @param nfs
     * @param dir
     * @param overwrite
     * @param flags
     * @param expectedElements
     * @param generateBloomFilter
     * @param compressType
     * @param bloomfilterFalseRate
     * @param replication
     *            use DFS default setting if replication=0
     * @throws IOException
     */
    public SSTableWriter(IFileSystem nfs, Path dir, boolean overwrite,
            int flags, long expectedElements, boolean generateBloomFilter,
            CompressType compressType, float bloomfilterFalseRate,
            byte replication) throws IOException {
        this.fs = nfs;
        this.flags = flags;
        if (generateBloomFilter
                && (bloomfilterFalseRate <= 0.0 || bloomfilterFalseRate > 1.0)) {
            float defaultF = Float.parseFloat(Table.Property.DEFAULT_BLOOMFILTER_FALSERATE);
            LOG.info("Error properties of bloomfilter_falserate: "
                    + bloomfilterFalseRate + ", set it to default: " + defaultF);
            bloomfilterFalseRate = defaultF;
        }
        if (generateBloomFilter && bloomfilterFalseRate > 0.99) {
            //false rate is so high, bloom filter is meaningless
            LOG.info("False-rate is so high: " + bloomfilterFalseRate
                    + ", bloom filter is meaningless. Disable bloomfilter.");
            generateBloomFilter = false;
        }
        if (nfs.exists(dir)) {
            if (nfs.listFiles(dir).length != 0) {
                if (overwrite) {
                    nfs.delete(dir);
                    nfs.mkdirs(dir);
                } else {
                    throw new IOException("already exists and is not empty: "
                            + dir);
                }
            }
        } else {
            nfs.mkdirs(dir);
        }
        if (nfs instanceof DistributedFileSystem) {
            DistributedFileSystem dfs = (DistributedFileSystem) nfs;
            Path[] pendingFiles = dfs.pendingFilesInDir(dir);
            if (pendingFiles != null) {
                for (Path pendingFile: pendingFiles) {
                    dfs.abandonFile(pendingFile);
                }
            }
            if (replication > 0) {
                dfs.setReplication(dir, replication, true);
            }
        }

        this.path = dir;
        this.compressType = compressType;
        this.indexKeyMaxByteDistance = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_SSTABLE_INDEX_KEY_MAX_BYTE_DISTANCE,
                OmapConfig.DEFAULT_TS_SSTABLE_INDEX_KEY_MAX_BYTE_DISTANCE);
        this.indexKeyMaxRecordDistance = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_SSTABLE_INDEX_KEY_MAX_RECORD_DISTANCE,
                OmapConfig.DEFAULT_TS_SSTABLE_INDEX_KEY_MAX_RECORD_DISTANCE);
        Path dataFile = dir.cat(SSTable.DATA_FILE_NAME);
        SequenceFile.Writer writer = null;
        boolean succ = false;
        try {
            writer = new SequenceFile.Writer(
                    OmapUtils.createFSDataOutputStream(nfs, dataFile, false,
                            flags), IntWritable.class, ByteArrayWritable.class,
                    null, 0);
            succ = true;
        } finally {
            if (!succ) {
                OmapUtils.safeClose(writer);
            }
        }
        this.dataOut = writer;

        Path sparseIndexFile = dir.cat(SSTable.SPARSE_INDEX_FILE_NAME);
        writer = null;
        succ = false;
        try {
            writer = new SequenceFile.Writer(
                    OmapUtils.createFSDataOutputStream(nfs, sparseIndexFile,
                            false, flags), ByteArrayWritable.class,
                    LongWritable.class, null, 0);
            succ = true;
        } finally {
            if (!succ) {
                OmapUtils.safeClose(this.dataOut);
                OmapUtils.safeClose(writer);
            }
        }
        writer.disableSync();
        this.sparseIndexWriter = writer;
        if (generateBloomFilter) {
            bloomFilter = new WritableBloomFilter(expectedElements,
                    bloomfilterFalseRate, Hash.MURMUR_HASH);
        } else {
            bloomFilter = null;
        }
        this.compressBuffer = new DataOutputBuffer(indexKeyMaxByteDistance);
        this.compressRate = 1.0;
    }

    private boolean writeBloomFilter() {
        Path bloomFilterFile = path.cat(SSTable.BLOOMFILTER_FILE_NAME);
        boolean succ = true;
        FSDataOutputStream out = null;
        try {
            out = OmapUtils.createFSDataOutputStream(fs, bloomFilterFile,
                    false, flags);
            bloomFilter.writeFields(out);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "write bloomfilter failed", e);
            succ = false;
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "close bloomfilter out failed", e);
                    succ = false;
                }
            }
        }
        return succ;
    }

    private boolean writeMetaData() {
        Path metaDataFile = path.cat(SSTable.METADATA_FILE_NAME);
        boolean succ = true;
        FSDataOutputStream out = null;
        try {
            out = OmapUtils.createFSDataOutputStream(fs, metaDataFile, false,
                    flags);
            Properties properties = new Properties();
            properties.setProperty(MetaData.NAME_COMPRESS_TYPE,
                    CompressType.toString(compressType));
            properties.setProperty(MetaData.NAME_ENTRY_COUNT,
                    Long.toString(entryCount));
            properties.setProperty(MetaData.NAME_SPARSE_INDEX_ENTRY_COUNT,
                    Long.toString(sparseIndexEntryCount));
            properties.setProperty(MetaData.NAME_DELETED_ENTRY_COUNT,
                    Long.toString(deletedEntryCount));
            properties.setProperty(MetaData.NAME_ORIGINAL_DATA_SIZE,
                    Long.toString(originalDataSize));
            properties.setProperty(MetaData.NAME_DATA_FILE_SYNC,
                    HexString.bytesToHexNoSpace(dataOut.getSync()));
            properties.store(out, null);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "write metadata failed", e);
            succ = false;
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "close metadata out failed", e);
                    succ = false;
                }
            }
        }
        return succ;
    }

    @Override
    public void close() throws IOException {
        boolean failed = false;
        try {
            compressedDataToSequenceFile();
        } catch (Exception e) {
            LOG.log(Level.WARNING,
                    "compressedDataToSequenceFile before close failed", e);
            failed = true;
        }
        String msg = "Closing " + this + ", size=" + dataOut.getPos()
                + ", entryCount=" + entryCount + ", sparseIndexEntryCount="
                + sparseIndexEntryCount + ", maxByteDist="
                + indexKeyMaxByteDistance + ", maxRecordDist="
                + indexKeyMaxRecordDistance + ", compressAlgo=" + compressType;
        LOG.info(msg);
        failed |= !closeWriter(sparseIndexWriter);
        failed |= !closeWriter(dataOut);
        if (!failed) {
            failed |= !writeMetaData();
        }
        if (!failed && bloomFilter != null) {
            failed |= !writeBloomFilter();
        }
        if (failed) {
            throw new IOException(msg + " failed");
        }
    }

    @Override
    public long getSize() throws IOException {
        return dataOut.getPos();
    }

    private boolean closeWriter(SequenceFile.Writer writer) {
        if (writer != null) {
            try {
                writer.close();
                return true;
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "close writer failed", t);
                return false;
            }
        } else {
            return true;
        }
    }

    private static class NonKeyPartBuffer implements IWritable {

        private ByteArrayWritable row;

        private int keyLength;

        @Override
        public void writeFields(DataOutput out) throws IOException {
            CDataOutputStream.writeVInt(row.size() - keyLength, out);
            out.write(row.data()[0]);
            out.write(row.data(), keyLength + 1, row.size() - keyLength - 1);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            throw new UnsupportedOperationException();
        }
    }

    private NonKeyPartBuffer nonKeyPartBuffer = new NonKeyPartBuffer();

    private ByteArrayWritable blockBuffer = new ByteArrayWritable();

    private IntWritable blockOriginLength = new IntWritable();

    /**
     * Append a key/value pair to the map. The key must be strictly greater than
     * the previous key added to the map. The key must be a KeyCell that has
     * been converted to ByteArrayWritable using
     * {@link OmapUtils#convertPIWritableToBytes(outfox.omap.data.IPreInitializedWritable)}
     * ; the value must be a DataRow that has been converted to
     * ByteArrayWritable using
     * {@link OmapUtils#convertPIWritableToBytes(outfox.omap.data.IPreInitializedWritable)}
     */
    @Override
    public void write(ByteArrayWritable key, ByteArrayWritable value)
            throws IOException {
        if (bloomFilter != null) {
            bloomFilter.add(key.data(), key.size());
        }

        if (entryCount == 0) {
            sparseIndexWriter.write(key, new LongWritable(dataOut.getPos()));
            ++sparseIndexEntryCount;
        }
        //Make sure the buffer size is below the indexKeyMaxByteDistance
        //Otherwise one block may read data twice from DFS
        if (entryCount - lastIndexedEntryIndex >= indexKeyMaxRecordDistance
                || entryCount != lastIndexedEntryIndex
                && compressBuffer.size() + value.size() > indexKeyMaxByteDistance
                        * compressRate) {
            compressedDataToSequenceFile();
            //create index for the new block
            sparseIndexWriter.write(key, new LongWritable(
                    lastIndexedEntryOffset));
            ++sparseIndexEntryCount;
        }

        key.writeFields(compressBuffer);
        nonKeyPartBuffer.row = value;
        nonKeyPartBuffer.keyLength = key.size();
        nonKeyPartBuffer.writeFields(compressBuffer);
        entryCount++;
        if (DataRow.isDeleted(value)) {
            deletedEntryCount++;
        }
        nonKeyPartBuffer.row = null;
    }

    private void compressedDataToSequenceFile() throws IOException {
        int outputLength;
        int originLength = compressBuffer.size();
        if (compressType == CompressType.NULL) {
            compressOutputBuffer = compressBuffer.getData();
            outputLength = compressBuffer.size();
        } else if (compressType == CompressType.LZO) {
            int expectCompressedSize = LzoCompression.getCompressBufferSize(originLength);
            ensureCompressOutputBufferCapacity(expectCompressedSize);
            outputLength = LzoCompression.compress(compressBuffer.getData(), 0,
                    compressBuffer.size(), compressOutputBuffer, 0);
            compressRate = Math.max(1.0, (double) compressBuffer.size()
                    / outputLength);
        } else if (compressType == CompressType.GZIP) {
            DirectByteArrayOutputStream byteStream;
            if (compressOutputBuffer == null) {
                byteStream = new DirectByteArrayOutputStream();
            } else {
                byteStream = new DirectByteArrayOutputStream(
                        compressOutputBuffer);
            }
            GZIPOutputStream go = new GZIPOutputStream(byteStream);
            go.write(compressBuffer.getData(), 0, originLength);
            go.close();
            compressOutputBuffer = byteStream.getBuffer();
            outputLength = byteStream.getBufferSize();
            compressRate = Math.max(1.0, (double) compressBuffer.size()
                    / outputLength);
        } else {
            throw new IOException("unknown compress algorithm: " + compressType);
        }
        originalDataSize += originLength;
        blockBuffer.set(compressOutputBuffer, 0, outputLength);
        blockOriginLength.set(originLength);
        dataOut.write(blockOriginLength, blockBuffer);
        compressBuffer.reset();
        lastIndexedEntryIndex = entryCount;
        lastIndexedEntryOffset = dataOut.getPos();
    }

    private byte[] compressOutputBuffer;

    private void ensureCompressOutputBufferCapacity(int size) {
        if (compressOutputBuffer == null || compressOutputBuffer.length < size) {
            compressOutputBuffer = new byte[size];
        }
    }

    @Override
    public String toString() {
        return "[SSTableWriter path=" + path + "]";
    }

}
