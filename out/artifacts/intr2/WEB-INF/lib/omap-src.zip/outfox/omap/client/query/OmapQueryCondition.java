/**
 * @(#)OmapQueryCondition.java, Oct 25, 2008. Copyright 2008 Yodao, Inc. All
 *                              rights reserved. YODAO PROPRIETARY/CONFIDENTIAL.
 *                              Use is subject to license terms.
 */
package outfox.omap.client.query;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.UTF8Writable;
import outfox.omap.client.protocol.QueryCondition;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.exceptions.NoSuchTypeException;
import outfox.omap.exceptions.QueryConditionInitializationException;

/**
 * A query condition is a tri-tuple <colName, query op, para(s)>. Users use this
 * condition to indicate a constraint in the query.
 * 
 * @author xingjk
 */
public class OmapQueryCondition implements QueryCondition, IWritableComparable {

    private String colName;

    private QueryOperation op;

    private IWritableComparable para;

    private IWritableComparable para2;

    private String colIWritableName = "NULL";

    public OmapQueryCondition() {} // for serialization only

    public OmapQueryCondition(String colName, QueryOperation op) {
        this(colName, op, null);
    }

    public OmapQueryCondition(String colName, QueryOperation op,
            IWritableComparable para) {
        this(colName, op, para, null);
    }

    public OmapQueryCondition(String colName, QueryOperation op,
            IWritableComparable para, IWritableComparable para2) {
        if (para != null && para2 != null
                && !para.getClass().equals(para2.getClass())) {
            throw new QueryConditionInitializationException(
                    "Two parameters belong to different classes");
        }
        this.colName = colName;
        this.op = op;

        if (para != null) {
            this.para = para;
            this.colIWritableName = para.getClass().getName();
            if (para2 != null) {
                this.para2 = para2;
            }
        } else {
            if (para2 != null) {
                this.para2 = para2;
                this.colIWritableName = para2.getClass().getName();
            }
        }
    }

    public String getColumnName() {
        return colName;
    }

    public QueryOperation getOperation() {
        return op;
    }

    public IWritableComparable getPara() {
        return para;
    }

    public IWritableComparable getPara2() {
        return para2;
    }

    public void setPara(IWritableComparable para) {
        this.para = para;
        if (this.para != null && this.para2 != null
                && !this.para.getClass().equals(para2.getClass())) {
            throw new QueryConditionInitializationException(
                    "Two parameters belong to different classes");
        }

        if (para != null)
            colIWritableName = para.getClass().getName();
    }

    public void setPara2(IWritableComparable para) {
        this.para2 = para;
        if (this.para != null && para2 != null
                && !this.para.getClass().equals(para2.getClass())) {
            throw new QueryConditionInitializationException(
                    "Two parameters belong to different classes");
        }

        if (para != null)
            colIWritableName = para.getClass().getName();
    }

    public String toString() {
        switch (op) {
            case EQUAL:
                return colName + " = " + para;
            case LIRI:
                return para + " <= " + colName + " <= " + para2;
            case LIRE:
                return para + " <= " + colName + " < " + para2;
            case LERI:
                return para + " < " + colName + " <= " + para2;
            case LERE:
                return para + " < " + colName + " < " + para2;
            case GET:
                return colName + " >= " + para;
            case LET:
                return colName + " <= " + para;
            case GT:
                return colName + " > " + para;
            case LT:
                return colName + " < " + para;
            case INEQUAL:
                return colName + " != " + para;
            default:
                return "Unknown QueryOperation " + op;
        }
    }

    public void readFields(DataInput in) throws IOException {
        colName = UTF8Writable.readString(in);
        op = QueryOperation.valueOf(in.readByte());
        try {
            colIWritableName = UTF8Writable.readString(in);
            if (!colIWritableName.equals("NULL")) {
                Class<?> clz = Class.forName(colIWritableName);
                byte paraSchema = in.readByte();
                switch (paraSchema) {
                    case 1:
                        para = (IWritableComparable) clz.newInstance();
                        para.readFields(in);
                        break;
                    case 2:
                        para2 = (IWritableComparable) clz.newInstance();
                        para2.readFields(in);
                        break;
                    case 3:
                        para = (IWritableComparable) clz.newInstance();
                        para2 = (IWritableComparable) clz.newInstance();
                        para.readFields(in);
                        para2.readFields(in);
                        break;
                    default:
                        throw new RuntimeException("Should never execute here");
                }
            }
        } catch (ClassNotFoundException e) {
            throw new QueryConditionInitializationException(
                    "Invalid parameter's class " + colIWritableName
                            + " for column " + colName, e);
        } catch (NoSuchTypeException e) {
            throw new QueryConditionInitializationException(
                    "Invalid parameter's class " + colIWritableName
                            + " for column " + colName, e);
        } catch (Exception e) {
            throw new QueryConditionInitializationException(
                    "Fail in initiate the parameters for column " + colName, e);
        }
    }

    public void writeFields(DataOutput out) throws IOException {

        UTF8Writable.writeString(out, colName);
        out.writeByte(op.getCode());
        UTF8Writable.writeString(out, colIWritableName);
        if (!colIWritableName.equals("NULL")) {
            if (para == null) {
                if (para2 == null) {
                    assert false; // should never be here!s
                } else {
                    out.writeByte(2);
                    para2.writeFields(out);
                }
            } else {
                if (para2 == null) {
                    out.writeByte(1);
                    para.writeFields(out);
                } else {
                    out.writeByte(3);
                    para.writeFields(out);
                    para2.writeFields(out);
                }
            }
        }
    }

    public IWritable copyFields(IWritable w) {
        OmapQueryCondition that = (OmapQueryCondition) w;
        this.colName = that.colName;
        this.colIWritableName = that.colIWritableName;
        this.op = that.op;
        try {
            if (!colIWritableName.equals("NULL")) {
                if (that.para != null) {
                    this.para = (IWritableComparable) Class.forName(
                            colIWritableName).newInstance();
                    this.para.copyFields(that.para);
                }
                if (that.para2 != null) {
                    this.para2 = (IWritableComparable) Class.forName(
                            colIWritableName).newInstance();
                    this.para2.copyFields(that.para2);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return this;
    }

    public int compareTo(IWritable o) {
        OmapQueryCondition that = (OmapQueryCondition) o;
        if (this.op.getPriority() > that.op.getPriority())
            return 1;
        if (this.op.getPriority() < that.op.getPriority())
            return -1;
        return this.colName.compareTo(that.colName);
    }

    public boolean isReadyToExecute() {
        if (colIWritableName.equals("NULL"))
            return false;

        if (op.isSpecifyRange()) {
            if (para == null
                    || para2 == null
                    || para.getClass().getCanonicalName().compareTo(
                            para2.getClass().getCanonicalName()) != 0
                    || para2.compareTo(para) <= 0)
                return false;
        } else {
            if (para == null)
                return false;
        }

        if (!colIWritableName.equals(para.getClass().getName()))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        return colName.hashCode();
    }

    @Override
    public boolean equals(Object another) {
        if (this == another)
            return true;
        if (!(another instanceof OmapQueryCondition))
            return false;
        return (this.colName.equals(((OmapQueryCondition) another).colName));
    }

    public boolean isMatch(IWritableComparable target) {
        switch (op) {
            case EQUAL:
                return target.compareTo(para) == 0;
            case GT:
                return target.compareTo(para) > 0;
            case GET: {
                int result = target.compareTo(para);
                return (result > 0 || result == 0);
            }
            case LT:
                return target.compareTo(para) < 0;
            case LET: {
                int result = target.compareTo(para);
                return (result < 0 || result == 0);
            }
            case LIRI: {
                int result1 = target.compareTo(para);
                int result2 = target.compareTo(para2);
                return ((result1 > 0 || result1 == 0) && (result2 < 0 || result2 == 0));
            }
            case LERI: {
                int result1 = target.compareTo(para);
                int result2 = target.compareTo(para2);
                return ((result1 > 0) && (result2 < 0 || result2 == 0));
            }
            case LIRE: {
                int result1 = target.compareTo(para);
                int result2 = target.compareTo(para2);
                return ((result1 > 0 || result1 == 0) && (result2 < 0));
            }
            case LERE: {
                int result1 = target.compareTo(para);
                int result2 = target.compareTo(para2);
                return (result1 > 0 && result2 < 0);
            }
            case INEQUAL:
                return target.compareTo(para) != 0;

            default:
                throw new RuntimeException("Unkown Query Operation");
        }
    }
}
