package outfox.omap.exceptions;

public class NoSuchTypeException extends RuntimeException {

    private static final long serialVersionUID = 5607377228744449637L;

    public NoSuchTypeException() {
        super();
    }

    public NoSuchTypeException(String msg) {
        super(msg);
    }
}
