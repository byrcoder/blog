package outfox.omap.exceptions;

public class NoSuchTsException extends RuntimeException {
	private static final long serialVersionUID = -2711900707823287336L;
	public NoSuchTsException() {
		super();
	}
	public NoSuchTsException(String msg) {
		super(msg);
	}
}
