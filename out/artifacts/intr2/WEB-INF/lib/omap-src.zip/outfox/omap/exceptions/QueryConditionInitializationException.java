/**
 * @(#)QueryConditionInitializationException.java, Oct 28, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * When the query condition is unable to be initialized properly, such as during
 * binding the query condition to a table, or reading from serialization stream,
 * this exception is thrown.
 * 
 * @author xingjk
 */
public class QueryConditionInitializationException extends RuntimeException {

    private static final long serialVersionUID = -2519582566046703467L;

    public QueryConditionInitializationException(String message) {
        super(message);
    }

    public QueryConditionInitializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
