package outfox.omap.test.bench;

import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.exceptions.OmapException;
import outfox.omap.test.bench.WorkloadRunner.AccessType;

/**
 * Defines a workload.
 * @author zhangkun
 */
public class WorkloadConfig {
    ClientMasterProtocol master;
    OmapTableSpace tableSpace;
    int maxWrittenKeysRecord;

    public WorkloadConfig(){}
    
    /**
     * @param maxWrittenKeysRecord the maxWrittenKeysRecord to set
     */
    public void setMaxWrittenKeysRecord(int maxWrittenKeysRecord) {
        this.maxWrittenKeysRecord = maxWrittenKeysRecord;
    }
    
    /**
     * Set the Table location in the format: <code>DataSource$TableSpace</code>
     * @param spaceLocation
     * @throws OmapException 
     */
    public void setOmapTableSpace(String spaceLocation) throws OmapException {
        String[] split = spaceLocation.split("\\$");
        tableSpace = (OmapTableSpace) DataSourceFactory.getNamed(split[0]).openTableSpace(split[1]);
        master = tableSpace.getMaster();
    }
    /**
     * The name of the Table that this workload operates on. A workload
     * read/write only one Table, and vice versa.
     */
    String tableName;
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    /**
     * How many records already exists in the Table before the benchmark
     * starts.
     */
    long initialNumRecords;
    public void setInitialNumRecords(long num) {
        this.initialNumRecords = num;
    }
    /**
     * The size in bytes of the value in the Table.
     */
    int valueSize;
    public void setValueSize(int valueSize) {
        this.valueSize = valueSize;
    }
    public void setReadTimeout(long timeout) {
        this.readTimeout = timeout;
    }
    long readTimeout;
    public void setWriteTimeout(long timeout) {
        this.writeTimeout = timeout;
    }
    long writeTimeout;
    /**
     * Controls the concurrency and frequency of reads.
     * DO NOT set this field directly, use {@link #setReadFlowController(FlowController)} instead.
     */
    FlowController readFlowController;
    public void setReadFlowController(FlowController fc) {
        if(fc.accessType != AccessType.READ) {
            throw new IllegalArgumentException(fc + "'s accessType is not READ");
        }
        if(fc.workload != null) {
            throw new IllegalArgumentException(fc + " is already used by " + fc.workload);
        }
        this.readFlowController = fc;
        fc.workload = this;
    }
    /**
     * Controls the concurrency and frequency of writes.
     * DO NOT set this field directly, use {@link #setWriteFlowController(FlowController)} instead.
     */
    FlowController writeFlowController;
    public void setWriteFlowController(FlowController fc) {
        if(fc.accessType != AccessType.WRITE) {
            throw new IllegalArgumentException(fc + "'s accessType is not WRITE");
        }
        if(fc.workload != null) {
            throw new IllegalArgumentException(fc + " is already used by " + fc.workload);
        }
        this.writeFlowController = fc;
        fc.workload = this;
    }
    /**
     * The expected probability (ranging [0,1]) of overwriting a record that already exists in
     * the Table when writing a record.
     */
    double overwriteRate;
    public void setOverwriteRate(double rate) {
        this.overwriteRate = rate;
    }
    /**
     * The expected probability (ranging [0,1]) of finding the record existing when reading
     * a record.
     */
    double readHitRate = 1;
    public void setReadHitRate(double rate) {
        readHitRate = rate;
    }
    /**
     * Defines the condition when the workload/bench terminates.
     */
    TerminationCondition terminationCondition;
    public void setTerminationCondition(TerminationCondition cond) {
        this.terminationCondition = cond;
    }
    CompressType compressType;
    public void setCompressType(String type) {
        this.compressType = CompressType.toType(type);
    }
    
    WorkloadConfig(OmapTableSpace tableSpace,
            String tableName, long initialNumRecords, int valueSize,
            long readTimeout, long writeTimeout,
            double overwriteRate, double readHitRate,
            TerminationCondition terminationCondition, String compressType,
            boolean continueOnExistTable, boolean createSnapshot,
            int maxWrittenKeysRecord, boolean readNewRowOnly,
            boolean testCursor) {
        this.master = tableSpace.getMaster();
        this.tableSpace = tableSpace;
        this.tableName = tableName;
        this.initialNumRecords = initialNumRecords;
        this.valueSize = valueSize;
        this.readTimeout = readTimeout;
        this.writeTimeout = writeTimeout;
        this.overwriteRate = overwriteRate;
        this.readHitRate = readHitRate;
        this.terminationCondition = terminationCondition;
        this.compressType = CompressType.toType(compressType);
        this.continueOnExistTable = continueOnExistTable;
        this.createSnapshot = createSnapshot;
        this.readNewRowOnly = readNewRowOnly;
        this.maxWrittenKeysRecord = maxWrittenKeysRecord;
        this.testCursor = testCursor;
    }
    
    /**
     * If the table already exists, continue test on this table
     */
    boolean continueOnExistTable;
    
    public void setContinueOnExistTable(boolean continueOnExistTable) {
        this.continueOnExistTable = continueOnExistTable;
    }
    
    /**
     * Should we create snapshot on current test table.
     * THis can be set to <code>false</code> if there are not enough space on DFS
     */
    boolean createSnapshot;
    boolean readNewRowOnly;
    boolean testCursor;
    
    public void setTestCursor(boolean testCursor) {
        this.testCursor = testCursor;
    }

    public void setReadNewRowOnly(boolean readNewRowOnly) {
        this.readNewRowOnly = readNewRowOnly;
    }

    public void setCreateSnapshot(boolean createSnapshot) {
        this.createSnapshot = createSnapshot;
    }
    
    
    @Override
    public String toString() {
        return "[WorkloadConfig tableSpace=" + tableSpace + " tableName=" + tableName
                + " initialNumRecords=" + initialNumRecords + " valueSize=" + valueSize
                + " readTimeout=" + readTimeout + " writeTimeout=" + writeTimeout
                + " readFlowController=" + readFlowController
                + " writeFlowController=" + writeFlowController
                + " overwriteRate=" + overwriteRate
                + " readHitRate=" + readHitRate
                + " terminationCondition=" + terminationCondition
                + " compressType=" + compressType 
                + " continueOnExistTable=" + continueOnExistTable
                + " createSnapshot=" + createSnapshot
                + "]";
    }
    /**
     * Get the signature the the initial environment defined in this workload.
     * This is for re-using initial data, because initial data set may be
     * very large and time-costing to prepare.
     * If two workloads have the same signiture, they can share the same set
     * of initial data.
     * @return
     */
    public String getInitialEnvironmentSig() {
        return valueSize + "-" + initialNumRecords;
    }
}

