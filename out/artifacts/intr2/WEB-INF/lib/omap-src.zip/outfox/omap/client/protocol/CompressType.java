/**
 * @(#)CompressType.java, 2010-4-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol;

import java.util.HashMap;
import java.util.Map;

/**
 * The compress type of omap data
 * @author wangfk
 *
 */
public enum CompressType{
    //No Compress
    NULL,
    //LZO
    LZO,
    //GZIP
    GZIP;
    
    private static Map<String, CompressType> typeStringMap = 
        new HashMap<String, CompressType>();
    
    static {
        for(CompressType type : CompressType.values()) {
            typeStringMap.put(type.name(), type);
        }
    }
    
    /** 
     * Method to convert CompressType to String
     * @param type
     * @return
     */
    public static String toString(CompressType type) {
        return type.name();
    }
    
    /**
     * Method to convert String to CompressType
     * @param type
     * @return
     */
    public static CompressType toType(String type) {
        CompressType cp = typeStringMap.get(type);
        if(cp != null) {
            return cp;
        }
        throw new RuntimeException("Unknown Compress Type: " + type);
    }
}
