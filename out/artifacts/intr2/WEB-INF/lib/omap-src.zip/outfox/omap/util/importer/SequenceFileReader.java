/**
 * @(#)SequenceFileReader.java, 2010-3-16. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

import odis.file.IRecordReader;
import odis.file.MergeSortReader;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

import outfox.omap.data.DataRow;
import outfox.omap.exceptions.BadSchemaDefinitionException;
import outfox.omap.util.TableConfig;
import toolbox.misc.LogFormatter;

/**
 * Implement of {@link IDataReader}, read data from sequece file
 * @see IDataReader
 * @author wangfk
 *
 */
public class SequenceFileReader implements IDataReader {
    private static final Logger LOG = LogFormatter
                                .getLogger(SequenceFileReader.class);
    
    private String inputPath;
    private String inputFS;
    private IRecordReader reader;
    private TableConfig tableConfig;
    
    private ThreadLocal<IWritableComparable> tlKey = new ThreadLocal<IWritableComparable>();
    private ThreadLocal<IWritable> tlValue = new ThreadLocal<IWritable>();    
    private ThreadLocal<DataRow> tlDataRow = new ThreadLocal<DataRow>();
    
    private AbstractDataFormatConvertor keyConvertor = null;
    private AbstractDataFormatConvertor valueConvertor = null;


    public void setInputFS(String inputFS) {
        this.inputFS = inputFS;
    }

    public void setInputPath(String inputPath) {
        this.inputPath = inputPath;
    }
    
    private boolean nextRecord(IWritableComparable key, IWritable value) throws IOException {
        boolean hasNext = reader.next(key, value);
        if(!hasNext) {
            reader.close();
        }
        return hasNext;
    }
    
    @Override
    public void openDataSource()  throws IOException {
        IFileSystem fileSystem = FileSystem.getNamed(inputFS);
        Path path = new Path(inputPath);
        
        if (fileSystem.isDirectory(path)) {
            List<SequenceFile.Reader> readers = new ArrayList<SequenceFile.Reader>();
            FileInfo[] files = fileSystem.listFiles(path);
            for (FileInfo file: files) {
                LOG.info(file.getPath() + " to be imported");
                readers.add(new SequenceFile.Reader(fileSystem, file.getPath()));
            }
            reader = new MergeSortReader(readers
                    .toArray(new SequenceFile.Reader[readers.size()]));
        } else {
            LOG.info(inputPath + " to be imported");
            reader = new SequenceFile.Reader(fileSystem, path);
        }
    }

    @Override
    public void closeDataSouce() {
        try {
            reader.close();
        } catch (IOException e) {
            //do nothing
            //e.printStackTrace();
        }
    }

    @Override
    synchronized public DataRow getNextRow() {
        if(tlDataRow.get() == null) {
            tlDataRow.set(tableConfig.td.createDataRow()); 
        }
        
        DataRow dr = tlDataRow.get();
        
        if(dr.getColumns().length != 2) {
            throw new BadSchemaDefinitionException
                ("Imported table from sequence file can only have two columns(key; value).");
        }
        
        try {
            if(tlKey.get() == null || tlValue.get() == null) {
                Class<? extends IWritableComparable> keyClass = reader.getKeyClass();
                Class<? extends IWritable> valueClass = reader.getValueClass();    
    
                tlKey.set(keyClass.newInstance());
                tlValue.set(valueClass.newInstance());
            }
            
            if(nextRecord(tlKey.get(), tlValue.get())) {
                if(keyConvertor == null) {
                    dr.getKeyCell().setIWritable(tlKey.get());
                }else {
                    keyConvertor.convert(tlKey.get(), dr.getKeyCell());
                }
                if(valueConvertor == null) {
                    dr.getColumn(1).setIWritable(tlValue.get());
                } else {
                    valueConvertor.convert(tlValue.get(), dr.getColumn(1));
                }
                return dr;
            }
        
        } catch (Exception e) {
            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            } else {
                throw new RuntimeException(e);
            }
        }
        return null;
    }

    @Override
    public long getRowCount() {
        try {
            reader.getSize();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    @Override
    public void setColNames(String colNames) {
        LOG.info("Columns name:" + colNames + ". Ignored in SequenceFileReader.");
    }

    @Override
    public void setColTypes(String colTypes) {
        LOG.info("Columns type:" + colTypes + ". Ignored in SequenceFileReader.");
    }

    @Override
    public void setProperties(Properties properties) {
        if(properties == null) {
            return;
        }
        
        String value;
        value = properties.getProperty("InputFS".toLowerCase());
        if(!StringUtils.isEmpty(value)) {
            this.setInputFS(value);
        }
        value = properties.getProperty("InputPath".toLowerCase());
        if(!StringUtils.isEmpty(value)) {
            this.setInputPath(value);
        }
    }

    @Override
    public void setTableConfig(TableConfig config) {
        this.tableConfig = config;
    }

    @Override
    public void setDataConvertor(int columnIndex, AbstractDataFormatConvertor convertor) {
        if(columnIndex == 0) {
            keyConvertor = convertor;
        }else if(columnIndex == 1) {
            valueConvertor = convertor;
        }else {
            LOG.warning("Column index of convertor is out of range: " + 
                    columnIndex);
            throw new RuntimeException("Column index of convertor is out of range: " + 
                    columnIndex);
        }
    }

}
