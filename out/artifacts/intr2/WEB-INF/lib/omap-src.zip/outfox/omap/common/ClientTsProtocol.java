/**
 * @(#)ClientTsProtocol.java, 2011-1-24. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.common;

import java.io.IOException;

import odis.rpc2.RpcException;
import odis.serialize.lib.ByteArrayWritable;

/**
 * Protocol that and OMap client uses to communicate with the Tablet Node Server
 * 
 * @author yf, xuw
 */

public interface ClientTsProtocol {

    /**
     * Return if the tablet contains the given key
     * 
     * @param tabletId
     *            : the id of the target tablet
     * @param key
     *            : the key to find
     * @return true if the tablet contains the key, false if not
     */
    boolean contains(long tabletId, ByteArrayWritable key) throws RpcException,
            IOException;

    /**
     * Return if the tablet contains the given keys
     * 
     * @param tabletId
     * @param keys
     * @return
     * @throws RpcException
     * @throws IOException
     */
    boolean[] contains(long tabletId, ByteArrayWritable[] keys)
            throws RpcException, IOException;

    /**
     * find row with the given key
     * 
     * @param tabletId
     * @param key
     * @return
     * @throws RpcException
     * @throws IOException
     */
    ByteArrayWritable keyFind(long tabletId, ByteArrayWritable key)
            throws RpcException, IOException;

    /**
     * try to find no more than num rows start with the startKeyw
     * 
     * @param tabletId
     * @param startKeyw
     * @param num
     * @return
     * @throws RpcException
     * @throws IOException
     */
    ByteArrayWritable[] keysFind(long tabletId,
            ByteArrayWritable startKeywInclusive, int num) throws RpcException,
            IOException;

    /**
     * try to find no more than num rows start with the startKeyw, end with the
     * endKeyw
     * 
     * @param tabletId
     * @param startKeyw
     * @param endKeyw
     *            null means no end
     * @param num
     * @return
     * @throws RpcException
     * @throws IOException
     */
    ByteArrayWritable[] keysFind(long tabletId,
            ByteArrayWritable startKeywInclusive,
            ByteArrayWritable endKeywExclusive, int num) throws RpcException,
            IOException;

    /**
     * find multi rows with given keys
     * 
     * @param tabletId
     * @param keys
     * @return
     * @throws RpcException
     * @throws IOException
     */
    ByteArrayWritable[] keysFind(long tabletId, ByteArrayWritable[] keys)
            throws RpcException, IOException;

    /**
     * insert a row to a tablet
     * 
     * @param tabletId
     * @param row
     * @throws RpcException
     * @throws IOException
     */
    void insertRow(long tabletId, ByteArrayWritable row) throws RpcException,
            IOException;

    /**
     * insert a serious of rows into a tablet, keys can be random, but must be
     * in the tablet
     * 
     * @param tabletId
     *            the id of the target tablet
     * @param rowsw
     *            the wrapper of the rows to insert param@overWrite: true if new
     *            rows
     * @param overwrite
     *            the old ones when both keys are the same return: 0 if success
     * @exception this
     *                function will throw IOExceptions when the tablet does not
     *                exist, or keys are not in this tablet, etc. Client should
     *                retry the insert process. by wangyang
     */
    void insertRows(long tabletId, ByteArrayWritable[] rows)
            throws RpcException, IOException;

    /**
     * Delete a row from a Tablet
     * 
     * @param tabletId
     * @param key
     * @throws RpcException
     * @throws IOException
     */
    void deleteRow(long tabletId, ByteArrayWritable key) throws RpcException,
            IOException;

    /**
     * delete a serious of rows into a tablet, keys can be random, but must be
     * in the tablet
     * 
     * @param tabletId
     * @param keys
     * @throws RpcException
     * @throws IOException
     */
    void deleteRows(long tabletId, ByteArrayWritable[] keys)
            throws RpcException, IOException;

    /**
     * delete all keys in the range [startKeyInclusive, endKeyExclusive) in a
     * tablet.<br>
     * because there may be too many rows to be deleted, so we may delete part
     * of them and return the deleted row count.client should call this method
     * several times until it returns 0.
     * 
     * @param tabletId
     * @param startKeyInclusive
     * @param endKeyExclusive
     * @throws RpcException
     * @throws IOException
     */
    int deleteRows(long tabletId, ByteArrayWritable startKeyInclusive,
            ByteArrayWritable endKeyExclusive) throws RpcException, IOException;

    /**
     * Atomically sets the value to the given updated value if the current
     * column value matches the given columnValue.
     * <p>
     * if columnName == null, check for non-existence.
     * <p>
     * if update is a deleted DataRow, we will do a deleteRow operation.
     * 
     * @param tabletId
     * @param key
     * @param update
     * @throws RpcException
     * @throws IOException
     */
    boolean compareAndSet(long tabletId, ByteArrayWritable key, String columnName,
            ByteArrayWritable columnValue, ByteArrayWritable update)
            throws RpcException, IOException;

    /**
     * Lock a row which key is <code>key</code>.<br>
     * This method will return a lockName, you can use this lockName in one
     * update session. You should set <code>lockName</code> to <code>null</code>
     * when you called first time.
     * 
     * @param tabletId
     * @param key
     *            the key of the row that should be locked
     * @param expireTime
     *            automatically unlock the row after <code>expireTime</code>
     *            even if unlockRow is not called. Notice that it is in
     *            milliseconds.
     * @param lockName
     * @throws RpcException
     * @throws IOException
     * @return
     */
    String lockRow(long tabletId, ByteArrayWritable key, long expireTime,
            String lockName) throws RpcException, IOException;

    /**
     * unlock a row which name is <code>lockName</code>
     * 
     * @param tabletId
     * @param lockName
     * @throws RpcException
     * @throws IOException
     */
    void unlockRow(long tabletId, String lockName) throws RpcException,
            IOException;
}
