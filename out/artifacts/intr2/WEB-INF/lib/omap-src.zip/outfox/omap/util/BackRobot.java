package outfox.omap.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DFSShell;
import odis.dfs.client.DistributedFileSystem;
import odis.io.FileSystem;
import odis.io.LocalFileSystem;
import odis.io.Path;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import toolbox.misc.LogFormatter;

public class BackRobot extends Thread {
    private static final Logger LOG = LogFormatter.getLogger(BackRobot.class);

    private static final String BACKUP_LIST_FILE_NAME = "backuplist";

    private SimpleDateFormat timeFormat = new java.text.SimpleDateFormat(
            "yyyyMMddHHmmss");

    private File backupListFile;

    private File backupDir1;

    private File backupDir2;

    private DFSShell tc;

    private String backupFsName1;

    private String backupFsName2;

    private FileSystem fs1;

    private FileSystem fs2;

    private HashMap<BackupEntry, Long> backupList = new HashMap<BackupEntry, Long>();

    private MasterWatcherAndClientConfig masterWatcher;

    public BackRobot(String backupFsName1, String backupDir1,
            String backupFsName2, String backupDir2) throws IOException {
        backupListFile = new File("./", BACKUP_LIST_FILE_NAME);
        this.backupDir1 = new File(backupDir1);
        this.backupDir2 = new File(backupDir2);
        this.backupFsName1 = backupFsName1;
        this.backupFsName2 = backupFsName2;
        fs1 = FileSystem.getNamed(backupFsName1);
        fs2 = FileSystem.getNamed(backupFsName2);
        if (!(fs2 instanceof DistributedFileSystem)) {
            throw new IOException("The second backup filesystem mustbe a ODFS.");
        }
        this.tc = new DFSShell(FileSystem.getNamed(backupFsName2), System.in,
                System.out, System.err);
        this.masterWatcher = new MasterWatcherAndClientConfig(new ClientConfig(
                "omap.xml"));
    }

    private static class BackupEntry {
        public String spaceName;

        public String tableName;

        public long interval;

        public BackupEntry(String spaceName, String tableName, long interval) {
            this.spaceName = spaceName;
            this.tableName = tableName;
            this.interval = interval;
        }

        public boolean equals(Object o) {
            if (o instanceof BackupEntry) {
                BackupEntry oo = (BackupEntry) o;
                return this.spaceName.equals(oo.spaceName)
                        && this.tableName.equals(oo.tableName);
            }
            return false;
        }

        public int hashCode() {
            return this.spaceName.hashCode() + this.tableName.hashCode();
        }
    }

    public void run() {
        while (true) {
            try {
                sleep(60 * 1000);
            } catch (InterruptedException e) {

            }
            loadBackupList();
            for (BackupEntry be: backupList.keySet()) {
                long curTime = System.currentTimeMillis();
                Date date = new Date(curTime);
                if ((curTime - backupList.get(be)) > be.interval) {
                    try {
                        Path dstPath1 = new Path(backupDir1, be.spaceName + "$"
                                + be.tableName + "_" + timeFormat.format(date));
                        Path dstPath2 = new Path(backupDir2, be.spaceName + "$"
                                + be.tableName + "_" + timeFormat.format(date));
                        new OmapTableSpace(be.spaceName, masterWatcher).snapshot(
                                be.tableName, dstPath1.getPath(), false);
                        backupList.put(be, curTime);

                        if (fs1 instanceof DistributedFileSystem) {
                            String[] args = new String[] {
                                "xfer", backupFsName1 + dstPath1.getPath(),
                                backupFsName2 + dstPath1.getPath()
                            };
                            tc.exec(args);
                        } else if (fs1 instanceof LocalFileSystem) {
                            String[] args = new String[] {
                                "put", dstPath1.getPath(), dstPath2.getPath()
                            };
                            tc.exec(args);
                        } else {
                            LOG.log(Level.WARNING,
                                    "backup from a" + fs1.getClass() + " to a "
                                            + fs2.getClass()
                                            + " is not allowed.");
                        }
                    } catch (Exception e) {
                        LOG.log(Level.WARNING,
                                "Caught Exception when snapshot table "
                                        + be.tableName + " of space "
                                        + be.spaceName, e);
                    }
                }
            }
        }
    }

    public void loadBackupList() {
        LOG.info("Try to load backup list");
        if (backupListFile.exists()) {
            HashMap<BackupEntry, Long> oldBackupList = backupList;
            this.backupList = new HashMap<BackupEntry, Long>();
            //long curTime = System.currentTimeMillis();
            try {
                BufferedReader reader = new BufferedReader(new FileReader(
                        backupListFile));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.startsWith("#")) {
                        String[] tokens = line.split("\\$");
                        if (tokens.length == 3) {
                            BackupEntry be = new BackupEntry(tokens[0],
                                    tokens[1], Long.parseLong(tokens[2]));
                            Long lastBackupTime = oldBackupList.get(be);
                            if (lastBackupTime == null) {
                                lastBackupTime = 0l;
                            }
                            backupList.put(new BackupEntry(tokens[0],
                                    tokens[1], Long.parseLong(tokens[2])),
                                    lastBackupTime);
                            LOG.info("Back up entry added: " + tokens[0] + " "
                                    + tokens[1] + " " + tokens[2]);
                        }
                    }
                }
                reader.close();
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "Caught exception when load protected list.", e);
            }
        } else {
            LOG.info("Cannot find backup list file.");
        }
    }

    public static void usage() {
        System.out.println("args: backupFilesystem1 backupDir1 backFileSystem2 backupDir2");
    }

    public static void main(String args[]) throws Exception {
        if (args.length != 4 || args[0].equals("help")) {
            usage();
            return;
        }
        BackRobot robot = new BackRobot(args[0], args[1], args[2], args[3]);
        robot.start();
    }
}
