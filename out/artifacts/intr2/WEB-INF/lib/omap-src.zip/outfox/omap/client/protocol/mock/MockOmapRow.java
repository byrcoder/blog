package outfox.omap.client.protocol.mock;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;
import outfox.omap.client.protocol.Row;
import outfox.omap.exceptions.OmapException;

public class MockOmapRow implements Row, IWritable {

    private Map<String, Integer> name2index;

    private String[] colTypes;

    private IWritable[] colDatas;

    private int[] status;

    public MockOmapRow(Map<String, Integer> name2index, String[] colTypes) {
        this.name2index = name2index;
        this.colTypes = colTypes;
        this.colDatas = new IWritable[colTypes.length];
        this.status = new int[colTypes.length];
        Arrays.fill(status, STATUS_NOT_SET);
    }

    public int getStatus(int colIndex) {
        return status[colIndex];
    }

    public int getStatus(String colName) {
        return status[name2index.get(colName)];
    }

    public void setStatus(int colIndex, int status) {
        this.status[colIndex] = status;
    }

    @Override
    public void empty(int colIndex) throws OmapException {
        setStatus(colIndex, STATUS_NULL);
    }

    @Override
    public void empty(String colName) throws OmapException {
        empty(name2index.get(colName));

    }

    @Override
    public int get(int colIndex, IWritable value) {
        if (status[colIndex] == STATUS_NORMAL) {
            value.copyFields(colDatas[colIndex]);
        }
        return status[colIndex];
    }

    @Override
    public int get(String colName, IWritable value) throws OmapException {
        return get(name2index.get(colName), value);
    }

    public IWritable getIWritable(String colName) {
        return getIWritable(name2index.get(colName));
    }

    public IWritable getIWritable(int colIndex) {
        if (status[colIndex] != STATUS_NORMAL) {
            return null;
        }
        IWritable value;
        try {
            value = colDatas[colIndex].getClass().newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        value.copyFields(colDatas[colIndex]);
        return value;
    }

    @Override
    public void getKey(IWritable key) {
        get(0, key);
    }

    public IWritableComparable getKey() {
        IWritableComparable key;
        try {
            key = (IWritableComparable) colDatas[0].getClass().newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        getKey(key);
        return key;
    }

    @Override
    public void set(int colIndex, IWritable value) throws OmapException {
        if (value == null) {
            setStatus(colIndex, STATUS_NULL);
        } else {
            if (colDatas[colIndex] == null
                    || !colDatas[colIndex].getClass().equals(value.getClass())) {
                try {
                    colDatas[colIndex] = value.getClass().newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
            colDatas[colIndex].copyFields(value);
            setStatus(colIndex, STATUS_NORMAL);
        }
    }

    @Override
    public void set(String colName, IWritable value) throws OmapException {
        set(name2index.get(colName), value);
    }

    @Override
    public void setKey(IWritable key) throws OmapException {
        set(0, key);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int sz = in.readInt();
        name2index = new HashMap<String, Integer>();
        for (int i = 0; i < sz; i++) {
            String name = StringWritable.readString(in);
            int index = in.readInt();
            name2index.put(name, index);
        }
        colTypes = new String[sz];
        for (int i = 0; i < sz; i++) {
            colTypes[i] = StringWritable.readString(in);
        }

        status = new int[sz];
        for (int i = 0; i < sz; i++) {
            status[i] = in.readInt();
        }
        colDatas = new IWritable[sz];
        for (int i = 0; i < sz; i++) {
            if (status[i] == STATUS_NORMAL) {
                String className = StringWritable.readString(in);
                try {
                    colDatas[i] = (IWritable) Class.forName(className).newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
                colDatas[i].readFields(in);
            }
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(name2index.size());
        for (Map.Entry<String, Integer> entry: name2index.entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            out.writeInt(entry.getValue());
        }
        for (String colType: colTypes) {
            StringWritable.writeString(out, colType);
        }

        for (int s: status) {
            out.writeInt(s);
        }
        for (int i = 0; i < status.length; i++) {
            if (status[i] == STATUS_NORMAL) {
                StringWritable.writeString(out,
                        colDatas[i].getClass().getName());
                colDatas[i].writeFields(out);
            }
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        MockOmapRow val = (MockOmapRow) value;
        name2index = new HashMap<String, Integer>(val.name2index);
        colTypes = new String[name2index.size()];
        System.arraycopy(val.colTypes, 0, colTypes, 0, colTypes.length);
        status = new int[name2index.size()];
        System.arraycopy(val.status, 0, status, 0, status.length);
        colDatas = new IWritable[colTypes.length];
        for (int i = 0; i < colDatas.length; i++) {
            if (status[i] == STATUS_NORMAL) {
                try {
                    colDatas[i] = val.colDatas[i].getClass().newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
                colDatas[i].copyFields(val.colDatas[i]);
            }
        }
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < colDatas.length; i++) {
            if (status[i] == STATUS_NORMAL) {
                sb.append(colDatas[i] + "; ");
            } else if (status[i] == STATUS_NULL) {
                sb.append("NULL; ");
            } else {
                sb.append("NOT_SET;");
            }
        }
        return sb.substring(0, sb.length() - 2);
    }

    @Override
    public void clear(int colIndex) throws OmapException {
        setStatus(colIndex, STATUS_NOT_SET);
    }

    @Override
    public void clear(String colName) throws OmapException {
        clear(name2index.get(colName));
    }

    @Override
    public void setNull(int colIndex) throws OmapException {
        setStatus(colIndex, STATUS_NULL);
    }

    @Override
    public void setNull(String colName) throws OmapException {
        setNull(name2index.get(colName));
    }

}
