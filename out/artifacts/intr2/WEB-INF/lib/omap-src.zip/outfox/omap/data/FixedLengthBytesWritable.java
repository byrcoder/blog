package outfox.omap.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.BytesBinaryComparator;
import odis.serialize.lib.BytesWritable;
import toolbox.misc.EmptyInstance;
import toolbox.text.util.HexString;

public class FixedLengthBytesWritable implements IWritableComparable,
        IPreInitializedWritable {

    static {
        WritableRegistry.registerComparator(BytesWritable.class,
                BytesBinaryComparator.class);
    }

    private byte[] bytes = EmptyInstance.BYTES;

    public FixedLengthBytesWritable() {}

    public FixedLengthBytesWritable(int size) {
        this.bytes = new byte[size];
    }

    public FixedLengthBytesWritable(byte[] bytes) {
        this.bytes = bytes;
    }

    public void set(byte[] bytes) {
        this.bytes = bytes;
    }

    public byte[] data() {
        return bytes;
    }

    public int size() {
        return this.bytes.length;
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(bytes.length);
        out.write(bytes, 0, bytes.length);
    }

    public void readFields(DataInput in) throws IOException {
        int length = in.readInt();
        if (this.bytes.length != length) {
            this.bytes = new byte[length];
        }
        in.readFully(bytes, 0, this.bytes.length);
    }

    public IWritable copyFields(IWritable value) {
        FixedLengthBytesWritable that = (FixedLengthBytesWritable) value;
        if (that.data().length > bytes.length)
            bytes = new byte[that.data().length];

        System.arraycopy(that.bytes, 0, this.bytes, 0, that.bytes.length);
        return this;
    }

    public String toString() {
        return "<" + HexString.bytesToHex(bytes, 0, this.bytes.length) + ">";
    }

    public int compareTo(IWritable o) {
        FixedLengthBytesWritable that = (FixedLengthBytesWritable) o;
        return BinaryComparator.compareBytes(this.bytes, 0, this.size(),
                that.bytes, 0, that.size());
    }

    @Override
    public int hashCode() {
        int step = bytes.length / 128;
        if (step == 0) {
            step = 1;
        }
        int index = 0;
        int hash = 0;
        while (index < bytes.length) {
            hash = (hash << 31) ^ bytes[index];
            index += step;
        }
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Arrays.equals(bytes, ((FixedLengthBytesWritable) obj).bytes);
    }

    @Override
    public void readPIFields(DataInput in) throws IOException {
        in.readFully(bytes);
    }

    @Override
    public void writePIFields(DataOutput out) throws IOException {
        out.write(bytes);
    }

}
