/**
 * @(#)TsMetricsCallListener.java, 2011-6-2. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.lang.reflect.Method;

import outfox.omap.exceptions.LogicException;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.OmapUtils;

import odis.rpc2.ClientInfo;
import odis.rpc2.PermissionManager.PermitType;
import odis.rpc2.ServerCallListener;

/**
 * @author zhangduo
 */
public class TsMetricsCallListener implements ServerCallListener {

    private final String tsName;

    private final TsGlobalMetricsEntry globalMetricsEntry;

    public TsMetricsCallListener(String tsName,
            TsGlobalMetricsEntry globalMetricsEntry) {
        this.tsName = tsName;
        this.globalMetricsEntry = globalMetricsEntry;
    }

    @Override
    public Object createAttach(ClientInfo clientInfo) {
        return null;
    }

    @Override
    public void startReceive(Method method, Object attach) {}

    @Override
    public void endReceive(Method method, Object[] args, Object attach) {
        globalMetricsEntry.request();
    }

    @Override
    public void getPermit(Method method, PermitType permit, Object attach) {
        if (permit.equals(PermitType.TIMEOUT)) {
            globalMetricsEntry.requestTimeout();
        }
    }

    @Override
    public void startCall(Method method, Object attach) {}

    private void sendAlert(Throwable error) {
        if (error instanceof LogicException) {
            AlertUtils.alert(tsName + " got logic error",
                    OmapUtils.getStackTrace(error), false, true);
        }
    }

    @Override
    public void endCall(Method method, Object returnValue, Throwable error,
            Object attach) {
        sendAlert(error);
    }

    @Override
    public void callTimeout(Method method, Object returnValue, Throwable error,
            Object attach) {
        globalMetricsEntry.requestTimeout();
        sendAlert(error);
    }

    @Override
    public void startSend(Method method, Object attach) {}

    @Override
    public void endSend(Method method, Object attach) {}

}
