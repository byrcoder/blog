/**
 * @(#)AlertUtils.java, 2010-1-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import outfox.omap.conf.OmapConfig;
import toolbox.maintain.alarm.Emailer;
import toolbox.maintain.alarm.SmsSender;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class AlertUtils {

    private static final Logger LOG = LogFormatter.getLogger(AlertUtils.class);

    private static final Emailer EMAILER = new Emailer();

    private static final AtomicLong lastAlertTime = new AtomicLong(0);

    private static class AlertEntry {
        public final String subject;

        public final String content;

        public final boolean sms;

        public final boolean email;

        public AlertEntry(String subject, String content, boolean sms,
                boolean email) {
            this.subject = subject;
            this.content = content;
            this.sms = sms;
            this.email = email;
        }

        @Override
        public String toString() {
            return "AlertEntry [subject=" + subject + ", content=" + content
                    + ", sms=" + sms + ", email=" + email + "]";
        }

    }

    private static final BlockingQueue<AlertEntry> alertQueue = new ArrayBlockingQueue<AlertUtils.AlertEntry>(
            10);

    private static final Thread alertThread = new Thread() {

        @Override
        public void run() {
            while (true) {
                try {
                    AlertEntry entry = alertQueue.take();
                    if (entry.email && OmapConfig.enableEmailAlert()) {
                        sendEmail(entry.subject, entry.content);
                    }
                    if (entry.sms && OmapConfig.enableSmsAlert()) {
                        String group = OmapConfig.getConfiguration().getString(
                                OmapConfig.NAME_ALERT_SMS_SENDER_GROUP,
                                OmapConfig.DEFAULT_ALERT_SMS_SENDER_GROUP);
                        SmsSender.send(new String[] {
                            group
                        }, entry.subject + ";" + entry.content);
                    }

                    List<String> alertUrlTemplateList = OmapConfig.getAlertUrlTemplateList();
                    for (String urlTemplate: alertUrlTemplateList) {
                        try {
                            String msg = URLEncoder.encode(entry.subject + ";"
                                    + entry.content, "UTF-8");
                            msg = msg.replace("+", "%20");
                            String url = urlTemplate.replace("${msg}", msg);
                            LOG.info("alert url: " + url);
                            LOG.info(new URL(url).getContent().toString());
                        } catch (Exception e) {
                            LOG.log(Level.WARNING, "connect to urlTemplate "
                                    + urlTemplate + " failed", e);
                        }
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "alert failed", e);
                }
            }
        }

    };

    static {
        alertThread.setDaemon(true);
        alertThread.setName("Alert Thread");
        alertThread.start();
    }

    /**
     * send email and sms for alert
     * 
     * @param msg
     */
    public static void alert(String subject, String content, boolean sms,
            boolean email) {
        long lastTime = lastAlertTime.get();
        long currentTime = System.currentTimeMillis();
        long alertInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_ALERT_MIN_INTERVAL,
                OmapConfig.DEFAULT_ALERT_MIN_INTERVAL);
        if (currentTime - lastTime < alertInterval) {
            return;
        }
        AlertEntry entry = new AlertEntry(subject, content, sms, email);
        if (alertQueue.offer(entry)) {
            lastAlertTime.set(currentTime);
        } else {
            LOG.warning("AlertQueue is full, " + entry + " is dropped");
        }
    }

    public static void sendEmail(String subject, String content) {
        String fromEmail = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_ALERT_FROM_EMAIL,
                OmapConfig.DEFAULT_ALERT_FROM_EMAIL);
        String toEmail = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_ALERT_TO_EMAIL,
                OmapConfig.DEFAULT_ALERT_TO_EMAIL);
        EMAILER.sendEmail(fromEmail, toEmail, subject, content, null);
    }

    public static void main(String[] args) throws UnsupportedEncodingException {
        System.out.println("http://172.16.80.115:8163/cgi-bin/alert.cgi?msg=${msg}".replace(
                "${msg}", URLEncoder.encode("wahaha+123:;::asdsa", "UTF-8")));
    }
}
