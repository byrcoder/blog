/**
 * @(#)LRUMap.java, 2012-5-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

/**
 * Add recordAccess for get method.
 * <p>
 * In SparseIndexPool and BloomFilterPool, we need to get the loaded object size
 * periodically for getting tablet load, but we do not want to record these
 * accesses. So we add this class.
 * 
 * @author zhangduo
 */
class LRUMap<K, V> {

    static class Entry<K, V> extends HashHelper.HashEntryBase<Entry<K, V>> {

        private final K key;

        private V value;

        private Entry<K, V> before, after;

        private Entry(int hash, K key, V value, Entry<K, V> next) {
            super(hash);
            this.key = key;
            this.value = value;
            this.next = next;
        }

        private void addBefore(Entry<K, V> existingEntry) {
            after = existingEntry;
            before = existingEntry.before;
            before.after = this;
            after.before = this;
        }

        private void remove() {
            before.after = after;
            after.before = before;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }

    private final float loadFactor;

    private int threshold;

    private Entry<K, V>[] table;

    private int size;

    private final Entry<K, V> head;

    /**
     * Capacity must be power of 2.
     * 
     * @param capacity
     * @param loadFactor
     */
    @SuppressWarnings("unchecked")
    LRUMap(int capacity, float loadFactor) {
        this.loadFactor = loadFactor;
        table = new Entry[capacity];
        threshold = (int) (capacity * loadFactor);
        head = new Entry<K, V>(0, null, null, null);
        head.before = head.after = head;
    }

    public V get(K key, boolean recordAccess) {
        int hash = HashHelper.hash(key.hashCode());
        for (Entry<K, V> e = table[HashHelper.indexFor(hash, table.length)]; e != null; e = e.next) {
            K k;
            if (e.hash == hash && ((k = e.key) == key || key.equals(k))) {
                if (recordAccess) {
                    e.remove();
                    e.addBefore(head);
                }
                return e.value;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private void resize(int newCapacity) {
        Entry<K, V>[] newTable = new Entry[newCapacity];
        HashHelper.transfer(table, newTable);
        table = newTable;
        threshold = (int) (newCapacity * loadFactor);
    }

    private void addEntry(int hash, K key, V value, int bucketIndex) {
        Entry<K, V> entryHead = table[bucketIndex];
        Entry<K, V> e = new Entry<K, V>(hash, key, value, entryHead);
        table[bucketIndex] = e;
        e.addBefore(head);
        if (size++ >= threshold) {
            resize(2 * table.length);
        }
    }

    public V put(K key, V value) {
        int hash = HashHelper.hash(key.hashCode());
        int i = HashHelper.indexFor(hash, table.length);
        for (Entry<K, V> e = table[i]; e != null; e = e.next) {
            K k;
            if (e.hash == hash && ((k = e.key) == key || key.equals(k))) {
                V oldValue = e.value;
                e.value = value;
                e.remove();
                e.addBefore(head);
                return oldValue;
            }
        }
        addEntry(hash, key, value, i);
        return null;
    }

    public V remove(K key) {
        int hash = HashHelper.hash(key.hashCode());
        int i = HashHelper.indexFor(hash, table.length);
        Entry<K, V> prev = table[i];
        Entry<K, V> e = prev;
        while (e != null) {
            Entry<K, V> next = e.next;
            K k;
            if (e.hash == hash && ((k = e.key) == key || key.equals(k))) {
                size--;
                if (prev == e) {
                    table[i] = next;
                } else {
                    prev.next = next;
                }
                e.remove();
                return e.value;
            }
            prev = e;
            e = next;
        }
        return null;
    }

    public Entry<K, V> poll() {
        if (size == 0) {
            return null;
        }
        Entry<K, V> entry = head.after;
        remove(entry.key);
        return entry;
    }

    public int size() {
        return size;
    }

}
