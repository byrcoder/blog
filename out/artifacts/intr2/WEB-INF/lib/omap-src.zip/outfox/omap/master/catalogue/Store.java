/**
 * @(#)Store.java, 2010-8-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem.PathFilter;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.util.MiscUtils;
import toolbox.collections.primitive.IntegerArrayList;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class Store<K extends IWritableComparable, V extends IWritable> {

    private static final Logger LOG = LogFormatter.getLogger(Store.class);

    private Class<K> keyClass;

    private Class<V> valueClass;

    public class Value implements IWritable {
        boolean deleted;

        V value;

        public Value() {}

        public Value(V value) {
            this.deleted = false;
            this.value = value;
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            deleted = in.readBoolean();
            if (!deleted) {
                if (value == null) {
                    value = createValue();
                    try {
                        value = valueClass.newInstance();
                    } catch (InstantiationException e) {
                        throw new RuntimeException(e);
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }
                value.readFields(in);
            }
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeBoolean(deleted);
            if (!deleted) {
                value.writeFields(out);
            }
        }

        @Override
        public IWritable copyFields(IWritable value) {
            @SuppressWarnings("unchecked")
            Value v = (Value) value;
            deleted = v.deleted;
            if (!deleted) {
                if (this.value == null) {
                    this.value = createValue();
                }
                this.value.copyFields(v.value);
            }
            return this;
        }

        @Override
        public String toString() {
            return "Value [deleted=" + deleted + ", value=" + value + "]";
        }
    }

    private FileSystem fs;

    private Path dir;

    private SortedMap<K, Value> buffer = new TreeMap<K, Value>();

    private SortedMap<K, Value> flushBuffer;

    public static final String FILE_PREFIX = "F_";

    public static final int CHECKPOINT_TEMP_FILE_SEQ = -1;

    public static final int COMPACT_TEMP_FILE_SEQ = -2;

    public static final int COMPACT_FILE_COUNT = 4;

    private IntegerArrayList fileSeqList = new IntegerArrayList();

    public Store(FileSystem fs, Path dir, Class<K> keyClass, Class<V> valueClass)
            throws IOException {
        this.fs = fs;
        this.dir = dir;
        this.keyClass = keyClass;
        this.valueClass = valueClass;
        FileInfo[] infos = fs.listFiles(dir, new PathFilter() {

            @Override
            public boolean accept(Path path) {
                return path.getName().startsWith(FILE_PREFIX);
            }
        });
        Arrays.sort(infos, new Comparator<FileInfo>() {

            @Override
            public int compare(FileInfo o1, FileInfo o2) {
                int i1 = getFileSeq(o1.getPath().getName());
                int i2 = getFileSeq(o2.getPath().getName());
                return i1 > i2 ? 1 : i1 == i2 ? 0 : -1;
            }

        });
        for (FileInfo info: infos) {
            int fileSeq = getFileSeq(info.getPath().getName());
            if (fileSeq < 0) {
                LOG.warning("temp file seq " + fileSeq + ", delete it");
                fs.delete(info.getPath());
            } else {
                fileSeqList.add(fileSeq);
            }
        }
    }

    private int getFileSeq(String fileName) {
        return Integer.parseInt(fileName.substring(fileName.lastIndexOf(FILE_PREFIX) + 2));
    }

    private int getCheckpointFileSeq() {
        synchronized (fileSeqList) {
            if (fileSeqList.isEmpty()) {
                return 0;
            } else {
                return fileSeqList.get(fileSeqList.size() - 1) + 2;
            }
        }
    }

    private void addFile(int fileSeq) {
        synchronized (fileSeqList) {
            for (int i = 0; i < fileSeqList.size(); i++) {
                if (fileSeqList.get(i) > fileSeq) {
                    fileSeqList.insert(fileSeq, i);
                    return;
                }
            }
            fileSeqList.add(fileSeq);
        }
    }

    public void prepareForFlush() {
        if (flushBuffer != null) {
            throw new IllegalStateException("flush buffer already exists");
        }
        if (buffer.size() == 0) {
            return;
        }
        flushBuffer = buffer;
        buffer = new TreeMap<K, Value>();
    }

    public int flush() throws IOException {
        if (flushBuffer == null) {
            return 0;
        }
        int fileSeq = getCheckpointFileSeq();
        SequenceFile.Writer writer = new SequenceFile.Writer(fs,
                dir.cat(FILE_PREFIX + CHECKPOINT_TEMP_FILE_SEQ), keyClass,
                Value.class, true);
        for (Map.Entry<K, Value> entry: flushBuffer.entrySet()) {
            writer.write(entry.getKey(), entry.getValue());
        }
        writer.close();
        int count = flushBuffer.size();
        flushBuffer = null;
        fs.rename(dir.cat(FILE_PREFIX + CHECKPOINT_TEMP_FILE_SEQ),
                dir.cat(FILE_PREFIX + fileSeq));
        addFile(fileSeq);
        return count;
    }

    public int compact() throws IOException {
        IntegerArrayList compactFileSeqList = new IntegerArrayList();
        synchronized (fileSeqList) {
            if (fileSeqList.isEmpty()) {
                return 0;
            }
            for (int i = 0; i < fileSeqList.size(); i++) {
                compactFileSeqList.add(fileSeqList.get(i));
            }
        }
        if (compactFileSeqList.size() < COMPACT_FILE_COUNT) {
            return 0;
        }
        int count = 0;
        SequenceFile.Writer writer = new SequenceFile.Writer(fs,
                dir.cat(FILE_PREFIX + COMPACT_TEMP_FILE_SEQ), keyClass,
                Value.class, true);
        StoreCursor<K, V> storeCursor = new StoreCursor<K, V>();
        List<K> keys = new ArrayList<K>();
        List<Value> values = new ArrayList<Value>();
        try {
            for (int i = compactFileSeqList.size() - 1; i >= 0; i--) {
                keys.add(createKey());
                values.add(new Value());
                storeCursor.add(getFileCursor(dir.cat(FILE_PREFIX
                        + compactFileSeqList.get(i))));
            }
            storeCursor.init(keys, values);
            K key = createKey();
            Value value = new Value();

            while (storeCursor.next(key, value)) {
                if (!value.deleted) {
                    writer.write(key, value);
                    count++;
                }
            }
        } finally {
            MiscUtils.safeClose(storeCursor);
            writer.close();
        }

        int fileSeq = compactFileSeqList.get(compactFileSeqList.size() - 1) + 1;
        fs.rename(dir.cat(FILE_PREFIX + COMPACT_TEMP_FILE_SEQ),
                dir.cat(FILE_PREFIX + fileSeq));
        synchronized (fileSeqList) {
            IntegerArrayList keepList = new IntegerArrayList();
            for (int i = compactFileSeqList.size(); i < fileSeqList.size(); i++) {
                keepList.add(fileSeqList.get(i));
            }
            fileSeqList.clear();
            fileSeqList.add(fileSeq);
            for (int i = 0; i < keepList.size(); i++) {
                fileSeqList.add(keepList.get(i));
            }
        }
        for (int i = 0; i < compactFileSeqList.size(); i++) {
            fs.delete(dir.cat(FILE_PREFIX + compactFileSeqList.get(i)));
        }
        return count;
    }

    public Cursor<K, Value> getStoreCursor() throws IOException {
        StoreCursor<K, V> cursor = new StoreCursor<K, V>();
        List<K> keys = new ArrayList<K>();
        List<Value> values = new ArrayList<Value>();
        cursor.add(getMemCursor(buffer));
        keys.add(createKey());
        values.add(new Value());
        for (int i = fileSeqList.size() - 1; i >= 0; i--) {
            cursor.add(getFileCursor(dir.cat(FILE_PREFIX + fileSeqList.get(i))));
            keys.add(createKey());
            values.add(new Value());
        }
        cursor.init(keys, values);
        return cursor;
    }

    private Cursor<K, Value> getMemCursor(SortedMap<K, Value> map) {
        final Iterator<Map.Entry<K, Value>> iter = map.entrySet().iterator();
        return new Cursor<K, Value>() {

            @Override
            public boolean next(K key, Value value) throws IOException {
                if (!iter.hasNext()) {
                    return false;
                }
                Map.Entry<K, Value> entry = iter.next();
                key.copyFields(entry.getKey());
                value.copyFields(entry.getValue());
                return true;
            }

            @Override
            public void close() throws IOException {}
        };
    }

    private Cursor<K, Value> getFileCursor(Path file) throws IOException {
        final SequenceFile.Reader reader = new SequenceFile.Reader(fs, file);
        return new Cursor<K, Value>() {

            @Override
            public boolean next(K key, Value value) throws IOException {
                return reader.next(key, value);
            }

            @Override
            public void close() throws IOException {
                reader.close();
            }

        };
    }

    private K createKey() {
        try {
            return keyClass.newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    private V createValue() {
        try {
            return valueClass.newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public void add(K key, V value) {
        K k = createKey();
        k.copyFields(key);
        V v = createValue();
        v.copyFields(value);
        buffer.put(k, new Value(v));
    }

    public void delete(K key) {
        Value v = new Value();
        v.deleted = true;
        buffer.put(key, v);
    }

    public boolean needFlush() {
        return buffer.size() > 1000;
    }

    public int count() {
        return buffer.size();
    }

    public Value getValue() {
        return new Value();
    }

    /**
     * only used for testcase
     * 
     * @return
     */
    SortedMap<K, Value> getBuffer() {
        return buffer;
    }

}
