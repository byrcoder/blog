/**
 * @(#)IndexSchemaNotPreparedException.java, Nov 19, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * When some methods in the IndexSchema are invoked, but IndexSchema is not prepared,
 * this exception is thrown.
 * @author xingjk
 *
 */
public class IndexSchemaNotPreparedException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 4744280478309651449L;

    public IndexSchemaNotPreparedException(){}
    
    public IndexSchemaNotPreparedException(String msg){
        super(msg);
    }
}
