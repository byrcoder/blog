/**
 * @(#)MasterTableMetricsEntry.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class MasterTableMetricsEntry implements IWritable {

    // do not serialize it. this is a status bit used at master side to decide 
    // whether to remove the TableMetricesEntry
    private boolean tableDeleted = false;

    private final long[] metricsRecords = new long[MasterMetricsType.tableTypeCount()];

    public synchronized void lookupKey(long delay) {
        metricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.LOOKUP_KEY_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.LAST_LOOKUP_KEY_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.TIME_RANGE_LOOKUP_KEY_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void getMetadata(long delay) {
        metricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GET_METADATA_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.LAST_GET_METADATA_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.TIME_RANGE_GET_METADATA_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void getSchemaId(long delay) {
        metricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GET_SCHEMA_ID_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.LAST_GET_SCHEMA_ID_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.TIME_RANGE_GET_SCHEMA_ID_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void renameTable(long delay) {
        metricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.RENAME_TABLE_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.LAST_RENAME_TABLE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.TIME_RANGE_RENAME_TABLE_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void setTableProperties(long delay) {
        metricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.LAST_SET_TABLE_PROPERTIES_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void setReadOnly(long delay) {
        metricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.SET_READ_ONLY_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.LAST_SET_READ_ONLY_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.TIME_RANGE_SET_READ_ONLY_COUNT.offset()
                + rangeOffset]++;
    }
    
    public synchronized void copyToAndClear(MasterTableMetricsEntry entry) {
        entry.copyFields(this);
        Arrays.fill(metricsRecords, 0L);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        MasterTableMetricsEntry that = (MasterTableMetricsEntry) value;
        System.arraycopy(that.metricsRecords, 0, metricsRecords, 0,
                metricsRecords.length);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        for (long metricsRecord: metricsRecords) {
            out.writeLong(metricsRecord);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        for (int i = 0; i < metricsRecords.length; i++) {
            metricsRecords[i] = in.readLong();
        }
    }

    public boolean isTableDeleted() {
        return tableDeleted;
    }

    public void setTableDeleted(boolean tableDeleted) {
        this.tableDeleted = tableDeleted;
    }

    public long[] getMetricsRecords() {
        return metricsRecords;
    }

}
