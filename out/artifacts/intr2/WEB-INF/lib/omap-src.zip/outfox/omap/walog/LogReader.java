/**
 * @(#)LogReader.java, 2010-8-30. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.walog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import outfox.omap.util.OmapUtils.TESTCASE_PREPENSE_EXCEPTION_TYPE;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class LogReader {

    private static final Logger LOG = LogFormatter.getLogger(LogReader.class);

    private PriorityQueue<WALogFile> logFiles;

    private LogReaderHandler handler;

    private WALogEntry sampleEntry;

    private long startTimestamp;

    private long endTimestamp;

    private volatile float progress;

    private boolean checkLSN;

    public LogReader(PriorityQueue<WALogFile> logFiles, WALogEntry sampleEntry,
            LogReaderHandler handler, long startTimestamp, long endTimestamp,
            boolean checkLSN) {
        this.logFiles = logFiles;
        this.sampleEntry = sampleEntry;
        this.handler = handler;
        this.startTimestamp = startTimestamp;
        this.endTimestamp = endTimestamp;
        this.checkLSN = checkLSN;
    }

    public LogReader(PriorityQueue<WALogFile> logFiles, WALogEntry sampleEntry,
            LogReaderHandler handler) {
        this(logFiles, sampleEntry, handler, Long.MIN_VALUE, Long.MAX_VALUE,
                true);
    }

    public void read() throws IOException {
        int readCount = 0;
        long maxLSN = 0;
        long logFileTotalSize = 0;
        long readSize = 0;
        for (WALogFile file: logFiles) {
            logFileTotalSize += file.getFileSize();
        }
        boolean succ = false;
        List<WALogFile> logs = new ArrayList<WALogFile>(logFiles.size());
        try {
            while (!logFiles.isEmpty()) {
                WALogFile logFile = logFiles.poll();
                LOG.info("Reading log chunk: " + logFile);
                LogIterator iter = logFile.iterator();
                try {
                    while (iter.next(sampleEntry)) {
                        readCount++;
                        if (checkLSN && sampleEntry.getLSN() < maxLSN) {
                            LOG.warning("LSN out of order: LSN = "
                                    + sampleEntry.getLSN()
                                    + " smaller than maxLSN = " + maxLSN);
                        } else {
                            maxLSN = sampleEntry.getLSN();
                        }
                        if (sampleEntry.getTimeStamp() < startTimestamp) {
                            continue;
                        } else if (sampleEntry.getTimeStamp() > endTimestamp) {
                            break;
                        }
                        handler.handle(sampleEntry);
                        progress = 1.0f * (readSize + iter.getPos())
                                / logFileTotalSize;
                    }
                    readSize += logFile.getFileSize();
                } finally {
                    iter.close();
                }
                logs.add(logFile);
                TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.TS_PREPENSE_EXCEPTION_WHILE_SPLITTING_LOG);
            }
            succ = true;
        } finally {
            if (!succ) {
                try {
                    handler.fail();
                } catch (Throwable t) {
                    LOG.log(Level.WARNING,
                            "invoke handler for fail recovery failed", t);
                }
            }
        }
        LOG.info("Finish log reading, total log entries read: " + readCount
                + ", logFiles: " + logs);
        handler.done();
    }

    public float getProgress() {
        return progress;
    }
}
