package outfox.omap.exceptions;

public class EmptyDataException extends OmapException {

    private static final long serialVersionUID = -1910068397685480827L;

    public EmptyDataException() {}

    public EmptyDataException(String message) {
        super(message);
    }

}
