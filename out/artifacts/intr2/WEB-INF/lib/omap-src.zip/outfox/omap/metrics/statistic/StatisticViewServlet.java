/**
 * @(#)StatisticViewServlet.java, 2011-6-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.io.FileSystem;
import odis.io.Path;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.apache.velocity.tools.view.servlet.VelocityViewServlet;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapMetadata;
import outfox.omap.conf.OmapConfig;
import outfox.omap.metrics.TimeRangeUtils;
import outfox.omap.util.PrintUtils;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;
import toolbox.web.WebServer;

/**
 * @author zhangduo
 */
public class StatisticViewServlet extends VelocityViewServlet {

    private static final long serialVersionUID = -8866377805446198313L;

    private static final Logger LOG = LogFormatter.getLogger(StatisticViewServlet.class);

    private StatisticReporter statisticReport;

    private MasterWatcherAndClientConfig masterWatcher;

    private static final int DAILY_TOP_TABLE_COUNT = 10;

    private static final String VM_HOME = "home.vm";

    private static final String VM_DAILY = "daily.vm";

    private static final String VM_CALC = "calc.vm";

    private static final int SHOW_TABLE_OP_MIN = 1000;

    private enum ServletType {
        HOME, DAILY, CALC, ERROR
    }

    public class MyPrintUtils extends PrintUtils {

        private int trCount = 0;

        private int tdCount = 0;

        public String printFloat(double d, int precision) {
            if (Double.isNaN(d)) {
                return "N/A";
            }
            return String.format("%." + precision + "f", d);
        }

        public String nextTrStyle() {
            ++trCount;
            tdCount = -1;
            return curTrStyle();
        }

        public String curTrStyle() {
            if (trCount % 2 == 0) {
                return "";
            } else {
                return " style=\"background-color: rgb(240, 240, 240);\"";
            }
        }

        public String nextTdStyle() {
            ++tdCount;
            if (tdCount % 4 == 0) {
                return "";
            } else if (tdCount % 4 == 1) {
                return " style=\"color: rgb(200, 0, 0);\"";
            } else if (tdCount % 4 == 2) {
                return " style=\"color: rgb(0, 200, 0);\"";
            } else {
                return " style=\"color: rgb(0, 0, 200);\"";
            }
        }

        public void resetTr() {
            trCount = -1;
        }

        public String printTime(long timestamp) {
            return formatter.print(timestamp);
        }

        public String getSortText(String text, boolean increase) {
            if (increase) {
                return "<b>" + text + "&uarr;" + "</b>";
            } else {
                return "<b>" + text + "&darr;" + "</b>";
            }
        }
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        String fsName = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_METRICS_STATISTIC_FS_NAME);
        if (fsName == null) {
            fsName = OmapConfig.getConfiguration().getString(
                    OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
        }
        try {
            statisticReport = new StatisticReporter(
                    FileSystem.getNamed(fsName), new Path(
                            OmapConfig.getMetricsStatisticPath()));
        } catch (IOException e) {
            throw new ServletException("init failed", e);
        }
        try {
            masterWatcher = new MasterWatcherAndClientConfig(new ClientConfig(
                    OmapConfig.getConfiguration()));
        } catch (IOException e) {
            throw new ServletException("init failed", e);
        }
    }

    @Override
    protected Template handleRequest(HttpServletRequest request,
            HttpServletResponse response, Context ctx) throws Exception {
        ServletType type = getType(request);
        Template template;
        switch (type) {
            case HOME:
                template = doHome(ctx, request);
                break;
            case DAILY:
                template = doDaily(ctx, request);
                break;
            case CALC:
                template = doCalc(ctx, request);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return null;
        }
        ctx.put("PrintUtils", new MyPrintUtils());
        ctx.put("TimeRangeCount", TimeRangeUtils.rangeCount());
        return template;
    }

    private Template doHome(Context ctx, HttpServletRequest request)
            throws Exception {
        long time = System.currentTimeMillis();
        ctx.put("fs", formatter.print(time - TimeUnit.DAYS.toMillis(1)));
        ctx.put("ts", formatter.print(time));
        ctx.put("calcResults", statisticReport.getExistsDailyStatisticReports(
                DateTimeConstants.DAYS_PER_WEEK, formatter));
        return getTemplate(VM_HOME);
    }

    private DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy:MM:dd HH:mm:ss");

    private Template doCalc(Context ctx, HttpServletRequest request)
            throws Exception {
        String fromTimeStr = request.getParameter("from-time");
        String toTimeStr = request.getParameter("to-time");
        ctx.put("fs", fromTimeStr);
        ctx.put("ts", toTimeStr);
        long fromTime;
        try {
            fromTime = formatter.parseDateTime(fromTimeStr).getMillis();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "parse from time failed", e);
            ctx.put("fe", true);
            return getTemplate(VM_HOME);
        }

        long toTime;
        try {
            toTime = formatter.parseDateTime(toTimeStr).getMillis();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "parse to time failed", e);
            ctx.put("te", true);
            return getTemplate(VM_HOME);
        }

        StatisticResult result = statisticReport.getStatisticReport(fromTime,
                toTime, false);
        String calcType = request.getParameter("type");
        final String sortBy = request.getParameter("sortBy");
        final boolean increase = "1".equals(request.getParameter("increase"));
        ctx.put("sortBy", sortBy);
        ctx.put("increase", increase);
        if (calcType != null && calcType.equals("master")) {
            Map<String, Object> masterStatisticResult = new HashMap<String, Object>();
            for (MasterGlobalStatisticType type: MasterGlobalStatisticType.values()) {
                if (type == MasterGlobalStatisticType.MAX_TYPE) {
                    continue;
                }
                if (type.name().startsWith("TIME_RANGE_")) {
                    double[] values = Arrays.copyOfRange(
                            result.getMasterStatisticResults().getFirst(),
                            type.offset(),
                            type.offset() + TimeRangeUtils.rangeCount());
                    masterStatisticResult.put(type.name(), values);
                } else {
                    masterStatisticResult.put(
                            type.name(),
                            result.getMasterStatisticResults().getFirst()[type.offset()]);
                }
            }
            for (MasterTableStatisticType type: MasterTableStatisticType.values()) {
                if (type == MasterTableStatisticType.MAX_TYPE) {
                    continue;
                }
                if (type.name().startsWith("TIME_RANGE_")) {
                    double[] values = Arrays.copyOfRange(
                            result.getMasterStatisticResults().getSecond(),
                            type.offset(),
                            type.offset() + TimeRangeUtils.rangeCount());
                    masterStatisticResult.put(type.name(), values);
                } else {
                    masterStatisticResult.put(
                            type.name(),
                            result.getMasterStatisticResults().getSecond()[type.offset()]);
                }
            }
            ctx.put("calcType", "master");
            ctx.put("MasterResult", masterStatisticResult);
        } else if (calcType != null && calcType.equals("ts")) {
            List<Pair<String, Map<String, Object>>> tsStatisticResults = new ArrayList<Pair<String, Map<String, Object>>>(
                    result.getTsStatisticResults().size());
            for (Map.Entry<String, Pair<double[], double[]>> entry: result.getTsStatisticResults().entrySet()) {
                Map<String, Object> tsStatisticResult = new HashMap<String, Object>();
                for (TsGlobalStatisticType type: TsGlobalStatisticType.values()) {
                    if (type == TsGlobalStatisticType.MAX_TYPE) {
                        continue;
                    }
                    if (type.name().startsWith("TIME_RANGE_")) {
                        double[] values = Arrays.copyOfRange(
                                entry.getValue().getFirst(), type.offset(),
                                type.offset() + TimeRangeUtils.rangeCount());
                        tsStatisticResult.put(type.name(), values);
                    } else {
                        tsStatisticResult.put(type.name(),
                                entry.getValue().getFirst()[type.offset()]);
                    }
                }
                for (TsTabletStatisticType type: TsTabletStatisticType.values()) {
                    if (type == TsTabletStatisticType.MAX_TYPE) {
                        continue;
                    }
                    if (type.name().startsWith("TIME_RANGE_")) {
                        double[] values = Arrays.copyOfRange(
                                entry.getValue().getSecond(), type.offset(),
                                type.offset() + TimeRangeUtils.rangeCount());
                        tsStatisticResult.put(type.name(), values);
                    } else {
                        tsStatisticResult.put(type.name(),
                                entry.getValue().getSecond()[type.offset()]);
                    }
                }
                tsStatisticResults.add(new Pair<String, Map<String, Object>>(
                        entry.getKey(), tsStatisticResult));
            }
            Map<String, Object> tsStatisticResult = new HashMap<String, Object>();
            for (TsGlobalStatisticType type: TsGlobalStatisticType.values()) {
                if (type == TsGlobalStatisticType.MAX_TYPE) {
                    continue;
                }
                if (type.name().startsWith("TIME_RANGE_")) {
                    double[] values = Arrays.copyOfRange(
                            result.getTotalTsStatisticResults().getFirst(),
                            type.offset(),
                            type.offset() + TimeRangeUtils.rangeCount());
                    tsStatisticResult.put(type.name(), values);
                } else {
                    tsStatisticResult.put(
                            type.name(),
                            result.getTotalTsStatisticResults().getFirst()[type.offset()]);
                }
            }
            for (TsTabletStatisticType type: TsTabletStatisticType.values()) {
                if (type == TsTabletStatisticType.MAX_TYPE) {
                    continue;
                }
                if (type.name().startsWith("TIME_RANGE_")) {
                    double[] values = Arrays.copyOfRange(
                            result.getTotalTsStatisticResults().getSecond(),
                            type.offset(),
                            type.offset() + TimeRangeUtils.rangeCount());
                    tsStatisticResult.put(type.name(), values);
                } else {
                    tsStatisticResult.put(
                            type.name(),
                            result.getTotalTsStatisticResults().getSecond()[type.offset()]);
                }
            }
            tsStatisticResults.add(new Pair<String, Map<String, Object>>(
                    "total", tsStatisticResult));
            Collections.sort(tsStatisticResults,
                    new Comparator<Pair<String, Map<String, Object>>>() {

                        @Override
                        public int compare(
                                Pair<String, Map<String, Object>> o1,
                                Pair<String, Map<String, Object>> o2) {
                            int cmp;
                            if (StringUtils.isNotBlank(sortBy)) {
                                cmp = ((Double) o1.getSecond().get(sortBy)).compareTo((Double) o2.getSecond().get(
                                        sortBy));
                            } else {
                                cmp = o1.getFirst().compareTo(o2.getFirst());
                            }
                            return increase ? cmp : -cmp;
                        }
                    });
            ctx.put("calcType", "ts");
            ctx.put("TsResult", tsStatisticResults);
        } else { // table
            List<TableStatisticEntry> tableStatisticResults = new ArrayList<TableStatisticEntry>(
                    result.getTableStatisticResults().size());
            for (Map.Entry<Long, double[]> entry: result.getTableStatisticResults().entrySet()) {
                // only show tables with large op count
                if (entry.getValue()[TableStatisticType.TOTAL_OPERATION_COUNT.offset()] < SHOW_TABLE_OP_MIN) {
                    continue;
                }
                Map<String, Object> tableStatisticResult = new HashMap<String, Object>();
                for (TableStatisticType type: TableStatisticType.values()) {
                    if (type == TableStatisticType.MAX_TYPE) {
                        continue;
                    }
                    if (type.name().startsWith("TIME_RANGE_")) {
                        double[] values = Arrays.copyOfRange(entry.getValue(),
                                type.offset(),
                                type.offset() + TimeRangeUtils.rangeCount());
                        tableStatisticResult.put(type.name(), values);
                    } else {
                        tableStatisticResult.put(type.name(),
                                entry.getValue()[type.offset()]);
                    }
                }
                OmapMetadata metadata = masterWatcher.getMaster().getMetadata(
                        entry.getKey());
                String tableName = metadata == null ? ""
                        : metadata.getInternalTableName();
                tableStatisticResults.add(new TableStatisticEntry(
                        entry.getKey(), tableName, tableStatisticResult));
            }
            Collections.sort(tableStatisticResults,
                    new Comparator<TableStatisticEntry>() {

                        @Override
                        public int compare(TableStatisticEntry o1,
                                TableStatisticEntry o2) {
                            int cmp;
                            if (StringUtils.isNotBlank(sortBy)) {
                                if (sortBy.equals("TABLE_NAME")) {
                                    cmp = o1.tableName.compareTo(o2.tableName);
                                } else {
                                    cmp = ((Double) o1.statisticResults.get(sortBy)).compareTo((Double) o2.statisticResults.get(sortBy));
                                }
                            } else {
                                cmp = o1.schemaId > o2.schemaId ? 1
                                        : o1.schemaId == o2.schemaId ? 0 : -1;
                            }
                            return increase ? cmp : -cmp;
                        }
                    });
            ctx.put("calcType", "table");
            ctx.put("TableResult", tableStatisticResults);
        }
        return getTemplate(VM_CALC);
    }

    public static class TableStatisticEntry {
        public long schemaId;

        public String tableName;

        public Map<String, Object> statisticResults;

        public TableStatisticEntry(long schemaId, String tableName,
                Map<String, Object> statisticResults) {
            this.schemaId = schemaId;
            this.tableName = tableName;
            this.statisticResults = statisticResults;
        }

        public long getSchemaId() {
            return schemaId;
        }

        public String getTableName() {
            return tableName;
        }

        public Map<String, Object> getStatisticResults() {
            return statisticResults;
        }

    }

    private Template doDaily(Context ctx, HttpServletRequest request)
            throws Exception {
        DateTime dt = new DateTime();
        DateTime startOfDay = dt.minusMillis(dt.getMillisOfDay());
        StatisticResult result = statisticReport.getStatisticReport(
                startOfDay.getMillis() - DateTimeConstants.MILLIS_PER_DAY,
                startOfDay.getMillis(), true);
        Map<String, Object> masterStatisticResult = new HashMap<String, Object>();
        for (MasterGlobalStatisticType type: MasterGlobalStatisticType.values()) {
            if (type == MasterGlobalStatisticType.MAX_TYPE) {
                continue;
            }
            if (type.name().startsWith("TIME_RANGE_")) {
                double[] values = Arrays.copyOfRange(
                        result.getMasterStatisticResults().getFirst(),
                        type.offset(),
                        type.offset() + TimeRangeUtils.rangeCount());
                masterStatisticResult.put(type.name(), values);
            } else {
                masterStatisticResult.put(
                        type.name(),
                        result.getMasterStatisticResults().getFirst()[type.offset()]);
            }
        }
        for (MasterTableStatisticType type: MasterTableStatisticType.values()) {
            if (type == MasterTableStatisticType.MAX_TYPE) {
                continue;
            }
            if (type.name().startsWith("TIME_RANGE_")) {
                double[] values = Arrays.copyOfRange(
                        result.getMasterStatisticResults().getSecond(),
                        type.offset(),
                        type.offset() + TimeRangeUtils.rangeCount());
                masterStatisticResult.put(type.name(), values);
            } else {
                masterStatisticResult.put(
                        type.name(),
                        result.getMasterStatisticResults().getSecond()[type.offset()]);
            }
        }
        ctx.put("MasterResult", masterStatisticResult);

        Map<String, Object> totalTsStatisticResult = new HashMap<String, Object>();
        for (TsGlobalStatisticType type: TsGlobalStatisticType.values()) {
            if (type == TsGlobalStatisticType.MAX_TYPE) {
                continue;
            }
            if (type.name().startsWith("TIME_RANGE_")) {
                double[] values = Arrays.copyOfRange(
                        result.getTotalTsStatisticResults().getFirst(),
                        type.offset(),
                        type.offset() + TimeRangeUtils.rangeCount());
                totalTsStatisticResult.put(type.name(), values);
            } else {
                totalTsStatisticResult.put(
                        type.name(),
                        result.getTotalTsStatisticResults().getFirst()[type.offset()]);
            }
        }
        for (TsTabletStatisticType type: TsTabletStatisticType.values()) {
            if (type == TsTabletStatisticType.MAX_TYPE) {
                continue;
            }
            if (type.name().startsWith("TIME_RANGE_")) {
                double[] values = Arrays.copyOfRange(
                        result.getTotalTsStatisticResults().getSecond(),
                        type.offset(),
                        type.offset() + TimeRangeUtils.rangeCount());
                totalTsStatisticResult.put(type.name(), values);
            } else {
                totalTsStatisticResult.put(
                        type.name(),
                        result.getTotalTsStatisticResults().getSecond()[type.offset()]);
            }
        }
        ctx.put("TsResult", totalTsStatisticResult);

        List<Pair<Long, double[]>> toSortList = new ArrayList<Pair<Long, double[]>>();
        for (Map.Entry<Long, double[]> entry: result.getTableStatisticResults().entrySet()) {
            toSortList.add(new Pair<Long, double[]>(entry.getKey(),
                    entry.getValue()));
        }
        Collections.sort(toSortList, new Comparator<Pair<Long, double[]>>() {

            @Override
            public int compare(Pair<Long, double[]> o1, Pair<Long, double[]> o2) {
                return Double.compare(
                        o2.getSecond()[TableStatisticType.TOTAL_OPERATION_COUNT.offset()],
                        o1.getSecond()[TableStatisticType.TOTAL_OPERATION_COUNT.offset()]);
            }

        });
        List<TableStatisticEntry> tableStatisticResult = new ArrayList<TableStatisticEntry>(
                DAILY_TOP_TABLE_COUNT);
        int count = 0;
        for (Pair<Long, double[]> pair: toSortList) {
            OmapMetadata metadata = masterWatcher.getMaster().getMetadata(
                    pair.getFirst());
            String tableName = metadata == null ? ""
                    : metadata.getInternalTableName();
            Map<String, Object> statisticResult = new HashMap<String, Object>();
            for (TableStatisticType type: TableStatisticType.values()) {
                if (type == TableStatisticType.MAX_TYPE) {
                    continue;
                }
                if (type.name().startsWith("TIME_RANGE_")) {
                    double[] values = Arrays.copyOfRange(pair.getSecond(),
                            type.offset(),
                            type.offset() + TimeRangeUtils.rangeCount());
                    statisticResult.put(type.name(), values);
                } else {
                    statisticResult.put(type.name(),
                            pair.getSecond()[type.offset()]);
                }
            }
            tableStatisticResult.add(new TableStatisticEntry(pair.getFirst(),
                    tableName, statisticResult));
            count++;
            if (count == DAILY_TOP_TABLE_COUNT) {
                break;
            }
        }
        ctx.put("TableResult", tableStatisticResult);
        return getTemplate(VM_DAILY);
    }

    private ServletType getType(HttpServletRequest request) {
        String servletName = request.getServletPath();
        LOG.info("ServletName: " + servletName);
        if (servletName == null) {
            servletName = "query.s";
        }
        servletName = WebServer.trimSlashes(servletName);
        if ("home.s".equalsIgnoreCase(servletName)) {
            return ServletType.HOME;
        } else if ("daily.s".equalsIgnoreCase(servletName)) {
            return ServletType.DAILY;
        } else if ("calc.s".equalsIgnoreCase(servletName)) {
            return ServletType.CALC;
        } else
            return ServletType.ERROR;
    }
}
