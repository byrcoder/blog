/**
 * @(#)StatisticRecorder.java, 2011-6-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.joda.time.DateTime;

import odis.file.SequenceFile;
import odis.io.FSDataOutputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.lib.LongWritable;
import outfox.omap.conf.OmapConfig;
import outfox.omap.metrics.MetricsEntry;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class StatisticRecorder {

    private static final Logger LOG = LogFormatter.getLogger(StatisticRecorder.class);

    private final FileSystem fs;

    private final Path dir;

    private FSDataOutputStream fsOut;

    private SequenceFile.Writer writer;

    public static final String OPEN_STATISTIC_FILE_NAME = "OPEN_STAT";

    public static final String STATISTIC_FILE_PREFIX = "STAT_";

    private long entryMinTime = Long.MAX_VALUE;

    private long entryMaxTime = Long.MIN_VALUE;

    private long nextRollingTime;

    public StatisticRecorder(FileSystem fs, Path dir) {
        this.fs = fs;
        this.dir = dir;

    }

    public void update(MetricsEntry metricsEntry, long currentTime)
            throws IOException {
        if (writer == null) {
            entryMinTime = currentTime;
            fsOut = fs.create(dir.cat(OPEN_STATISTIC_FILE_NAME));
            writer = new SequenceFile.Writer(fsOut, LongWritable.class,
                    MetricsEntry.class, null, 0);
            DateTime dt = new DateTime(currentTime);
            nextRollingTime = dt.minusMillis(dt.getMillisOfSecond()).minusSeconds(
                    dt.getSecondOfMinute()).minusMinutes(dt.getMinuteOfHour()).getMillis();
            long rollingInterval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_METRICS_STATISTIC_FILE_ROLLING_INTERVAL,
                    OmapConfig.DEFAULT_METRICS_STATISTIC_FILE_ROLLING_INTERVAL);
            while (nextRollingTime <= currentTime) {
                nextRollingTime += rollingInterval;
            }
        }
        if (currentTime >= nextRollingTime) {
            writer.close();
            fs.rename(
                    dir.cat(OPEN_STATISTIC_FILE_NAME),
                    dir.cat(STATISTIC_FILE_PREFIX + entryMinTime + "_"
                            + (entryMaxTime + 1)));
            entryMinTime = currentTime;
            fsOut = fs.create(dir.cat(OPEN_STATISTIC_FILE_NAME));
            writer = new SequenceFile.Writer(fsOut, LongWritable.class,
                    MetricsEntry.class, null, 0);
            nextRollingTime = nextRollingTime
                    + OmapConfig.getConfiguration().getLong(
                            OmapConfig.NAME_METRICS_STATISTIC_FILE_ROLLING_INTERVAL,
                            OmapConfig.DEFAULT_METRICS_STATISTIC_FILE_ROLLING_INTERVAL);
        }
        writer.write(new LongWritable(currentTime), metricsEntry);
        entryMaxTime = currentTime;
        writer.flushBuffer();
        fsOut.flush();
    }

    public void deleteStatisticFileBeforeTime(long time) throws IOException {
        for (FileInfo fileInfo: fs.listFiles(dir)) {
            if (fileInfo.isDir()
                    || !fileInfo.getPath().getName().startsWith(
                            STATISTIC_FILE_PREFIX)) {
                continue;
            }
            String[] ss = fileInfo.getPath().getName().split("_");
            long entryMaxTime = Long.parseLong(ss[2]);
            if (entryMaxTime < time) {
                LOG.info("Delete statistic file "
                        + fileInfo.getPath().getAbsolutePath());
                fs.delete(fileInfo.getPath());
            }
        }
    }

    public void close() {
        if (writer != null) {
            OmapUtils.safeClose(writer);
            try {
                fs.rename(
                        dir.cat(OPEN_STATISTIC_FILE_NAME),
                        dir.cat(STATISTIC_FILE_PREFIX + entryMinTime + "_"
                                + (entryMaxTime + 1)));
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "rename open stat file failed when close", e);
            }
        }
    }
}
