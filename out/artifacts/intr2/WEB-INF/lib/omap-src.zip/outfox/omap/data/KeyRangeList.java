/**
 * @(#)KeyRangeList.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.util.GenericWritableComparator;

/**
 * renamed from TableRangeInfo to KeyRangeList xuw<br>
 * XXX don't know why you use priority queue? why not just use a sorted list?<br>
 * XXX Need modification later this class implements a mapping between ranges
 * and its corresponding ts. It is used for communication between master /
 * client and ts. Master stores continuous range information in an easier
 * format.
 * 
 * @author zhihua xuw
 */
public class KeyRangeList implements IWritable {
    private TreeMap<KeyRange, KeyRange> rangeSet;

    public TreeMap<KeyRange, KeyRange> getRangeSet() {
        return rangeSet;
    }

    /**
     */
    public KeyRangeList() {
        this.rangeSet = new TreeMap<KeyRange, KeyRange>(
                GenericWritableComparator.instance);
    }

    public KeyRangeList(Collection<KeyRange> keyRanges) {
        this();
        for (KeyRange kr: keyRanges) {
            insert(kr);
        }
    }

    public synchronized KeyRange first() {
        if (this.rangeSet.isEmpty()) {
            return null;
        } else {
            return this.rangeSet.firstKey();
        }
    }

    public synchronized KeyRange last() {
        if (this.rangeSet.isEmpty()) {
            return null;
        } else {
            return this.rangeSet.lastKey();
        }
    }

    public synchronized KeyRange lookup(IWritableComparable o) {
        return this.rangeSet.get(o);
    }

    public synchronized boolean insert(KeyRange r) {
        // // first we make sure it is not overlap one range in the TreeMap
        Iterator<KeyRange> i = this.rangeSet.keySet().iterator();
        KeyRange cur = null;

        while (i.hasNext()) {

            cur = (KeyRange) i.next();
            if (cur.isOverLap(r)) {
                i.remove();
            }
        }
        if (this.rangeSet.containsKey(r)) {
            return false;
        } else {
            this.rangeSet.put(r, r); // if overlaps with something, the
            // compare method will throw exception
            return true;
        }
    }

    public synchronized void merge(KeyRangeList krl) {

        if (krl == null)
            return; // nothing to merge
        Iterator<KeyRange> iter = krl.rangeSet.keySet().iterator();

        while (iter.hasNext()) {
            KeyRange o = (KeyRange) iter.next();
            Iterator<KeyRange> iter2 = this.rangeSet.keySet().iterator();
            while (iter2.hasNext()) {
                KeyRange originalkr = (KeyRange) iter2.next();
                if (originalkr.isOverLap(o)) {
                    iter2.remove();
                    // reuse tsconnection
                    if (originalkr.getTsDesc().equals(o.getTsDesc())) {
                        o.setTsDesc(originalkr.getTsDesc());
                    }
                }
            }
            this.rangeSet.put(o, o);
        }
    }

    /**
     * delete keyrange containing the key k
     * 
     * @param k
     * @return
     */
    public synchronized KeyRange delete(IWritableComparable k) {
        return this.rangeSet.remove(k);
    }

    public synchronized boolean delete(KeyRange r) {
        KeyRange rr = this.rangeSet.remove(r);
        if (rr == null) {
            return false;
        } else {
            return true;
        }
    }

    public synchronized boolean split(KeyRange oldKr, KeyRange newKr1,
            KeyRange newKr2) {
        if (!delete(oldKr)) {
            return false;
        }
        if (!insert(newKr1)) {
            return false;
        }
        if (!insert(newKr2)) {
            return false;
        }
        return true;
    }

    // ///////////////////////////////////
    // IWritable
    // ///////////////////////////////////

    public synchronized void readFields(DataInput in) throws IOException {

        int num = in.readInt();

        KeyRange tmp = null;
        for (int i = 0; i < num; i++) {
            tmp = new KeyRange(); // xuw: this is necessary, I believe --
            // otherwise everything share a single
            // keyrange
            tmp.readFields(in);
            this.insert(tmp);
        }
    }

    public synchronized IWritable copyFields(IWritable value) {
        assert this != value;
        KeyRangeList val = (KeyRangeList) value;

        this.rangeSet = new TreeMap<KeyRange, KeyRange>();

        KeyRange k1, k2;
        Iterator<KeyRange> i = val.rangeSet.keySet().iterator();
        while (i.hasNext()) {
            k1 = (KeyRange) i.next();
            k2 = new KeyRange();
            k2.copyFields(k1);
            this.insert(k2);
        }
        return this;
    }

    public synchronized void writeFields(DataOutput out) throws IOException {
        int num = rangeSet.size();
        out.writeInt(num);

        Iterator<KeyRange> i = rangeSet.keySet().iterator();

        while (i.hasNext()) {
            KeyRange cur = (KeyRange) i.next();
            cur.writeFields(out);
        }
    }

    public synchronized String toString() {
        Collection<KeyRange> ranges = this.rangeSet.keySet();
        StringBuffer buf = new StringBuffer();
        for (IWritableComparable r: ranges) {
            buf.append(r).append("; ");
        }
        return buf.toString();
    }

    public synchronized int size() {
        return rangeSet.size();
    }

    public synchronized List<KeyRange> getRangeList() {
        List<KeyRange> list = new ArrayList<KeyRange>(rangeSet.values());
        return list;
    }
}
