package outfox.omap.walog;

import java.util.Comparator;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import outfox.omap.util.OmapUtils;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.IFileSystem;
import odis.io.Path;
import toolbox.misc.LogFormatter;

/**
 * A Log file. The log in OMAP is used for restoration, not for transaction. It
 * ensures the operations be executed at least once, while tolerating duplicate
 * operations.
 * 
 * @author zhangkun
 */
public class WALogFile {
    public static final String FILE_PREFIX = "wal_";

    public static final Logger LOG = LogFormatter.getLogger(WALogFile.class);

    private IFileSystem fs;

    private Path walfile;

    private long fileNumber;

    /**
     * Create a WALogFile from a File descriptor. The file name must consist of
     * a {@value WALogFile#FILE_PREFIX} and a number, like
     * <code>"{FILE_PREFIX}34"</code>, otherwise an Exception will be thrown.
     * 
     * @param fs
     * @param file
     */
    public WALogFile(IFileSystem fs, Path file) {
        this.fs = fs;
        this.walfile = file;
        String s = this.walfile.getName();
        if (!s.startsWith(FILE_PREFIX)) {
            throw new IllegalArgumentException("file name must start with "
                    + FILE_PREFIX);
        }
        this.fileNumber = Long.parseLong(s.substring(FILE_PREFIX.length()));
    }

    public Path getFile() {
        return walfile;
    }

    public long getFileSize() throws IOException {
        return fs.getLength(walfile);
    }

    public long getFileNumber() {
        return fileNumber;
    }

    public class Writer implements Closeable {
        /**
         * The output stream of this writer
         */
        protected FSDataOutputStream out;

        private long backptr = WALogger.BACKPT_START; // backpointer is local to log-chuck (file)

        private Writer(boolean overwrite, int flags) throws IOException {
            if (fs instanceof DistributedFileSystem) {
                out = new FSDataOutputStream(
                        ((DistributedFileSystem) fs).createRaw(walfile,
                                overwrite, true, flags));
            } else {
                LOG.warning(fs.getClass().getName()
                        + " doesn't support flags, flags=" + flags + " ignored");
                out = fs.create(walfile, overwrite, true);
            }
        }

        public void write(WALogEntry entry) throws IOException {
            entry.setBackPointer(backptr);
            backptr = out.getPos();
            entry.writeFields(out);
        }

        public long getBackptr() {
            return backptr;
        }

        public void flush() throws IOException {
            out.flush();
        }

        public void close() throws IOException {
            out.close();
        }

        public long getPos() throws IOException {
            return out.getPos();
        }
    }

    public Writer createWriter() throws IOException {
        return new Writer(false, DFSClient.OS_NOLOCALBACKUP);
    }

    public Writer createWriter(boolean overwrite) throws IOException {
        return new Writer(overwrite, DFSClient.OS_NOLOCALBACKUP);
    }

    public LogIterator iterator() throws IOException {
        return new LogIteratorImpl();
    }

    public LogIterator reverseIterator(WALogEntry sampleEntry)
            throws IOException {
        return new ReverseLogIteratorImpl(sampleEntry);
    }

    private boolean locateNextEntry(FSDataInputStream in, long startPos,
            WALogEntry entry) throws IOException {
        for (;;) {
            in.seek(startPos);
            int endFlag;
            try {
                endFlag = in.readInt();
            } catch (EOFException e) {
                LOG.log(Level.WARNING,
                        "Got EOF when try to locate next entry at pos "
                                + startPos, e);
                return false;
            }
            if (endFlag != WALogEntry.END_FLAG) {
                startPos++;
                continue;
            }
            startPos = in.getPos();
            try {
                entry.readFields(in);
                return true;
            } catch (EOFException e) {
                LOG.log(Level.WARNING,
                        "Got EOF when try to locate next entry at pos "
                                + startPos, e);
                return false;
            } catch (CorruptedWALogEntryException e) {
                LOG.log(Level.WARNING,
                        "Got corrupted WALogEntry after valid end flag at pos "
                                + startPos, e);
                continue;
            }
        }
    }

    private class LogIteratorImpl implements LogIterator {
        private final FSDataInputStream in;

        public LogIteratorImpl() throws IOException {
            in = fs.open(walfile);
        }

        public boolean next(WALogEntry entry) throws IOException {
            long pos = in.getPos();
            try {
                entry.readFields(in);
                return true;
            } catch (EOFException e) {
                return false;
            } catch (CorruptedWALogEntryException e) {
                LOG.log(Level.WARNING, "Corrupted WALogEntry found at " + pos
                        + " of file " + walfile.getAbsolutePath(), e);
            }
            return locateNextEntry(in, pos, entry);
        }

        public long getPos() throws IOException {
            return in.getPos();
        }

        public void close() {
            OmapUtils.safeClose(in);
        }

    }

    /**
     * Search from the tail to the head, trying to find the first valid LogEntry
     * and return its position.<br>
     * 
     * @param in
     * @return
     * @throws IOException
     */
    public long locateLastEntry(FSDataInputStream in, WALogEntry sampleEntry)
            throws IOException {
        long startPos = fs.getLength(this.walfile);
        while (startPos >= Integer.SIZE / 8) {
            long endFlagPos = startPos - Integer.SIZE / 8;
            // try to find an END_FLAG
            in.seek(endFlagPos);
            if (in.readInt() != WALogEntry.END_FLAG) {
                // last log entry is not complete
                LOG.warning("Incomplete log tail.  Scanning forward byte by byte");
                endFlagPos -= 1;
                in.seek(endFlagPos);
                int rr = in.readInt();
                while (rr != WALogEntry.END_FLAG && endFlagPos >= 1) {
                    endFlagPos -= 1;
                    in.seek(endFlagPos);
                    rr = in.readInt();
                }
                if (endFlagPos < 1) {
                    break;
                }
            }

            // seek to the last (possible) back pointer
            // the back pointer is right before the END_FLAG
            in.seek(endFlagPos - Long.SIZE / 8);
            long backptr = in.readLong();
            if (backptr < 0 || backptr > startPos) {
                // not a valid backpointer, need continue searching
                startPos = endFlagPos;
            } else {
                // try to read the entry.. it is likely to be a correct back
                // pointer, but still not sure
                try {
                    in.seek(backptr);
                    sampleEntry.readFields(in); // the one before last
                    return in.getPos();
                } catch (IOException e) {
                    LOG.log(Level.WARNING, "Backpointer " + backptr
                            + " seems invalid", e);
                    startPos = endFlagPos;
                }
            }
        }
        // try to read an entry from start of the file, if success, 
        // this maybe the only entry in WALogFile
        try {
            in.seek(0);
            sampleEntry.readFields(in);
            return 0;
        } catch (IOException e) {
            LOG.log(Level.WARNING, "read from start failed", e);
        }

        // no bytes left for a END_FLAG
        throw new EOFException("No valid log entry found in the file!!");
    }

    private class ReverseLogIteratorImpl implements LogIterator {
        private final FSDataInputStream in;

        private boolean eof = false;

        public ReverseLogIteratorImpl(WALogEntry sampleEntry)
                throws IOException {
            in = OmapUtils.createFSDataInputStream(fs, walfile, true);
            boolean succ = false;
            try {
                long off = locateLastEntry(in, sampleEntry);
                if (off >= 0) {
                    in.seek(off);
                } else {
                    eof = true;
                }
                succ = true;
            } finally {
                if (!succ) {
                    OmapUtils.safeClose(in);
                }
            }
        }

        public boolean next(WALogEntry entry) throws IOException {
            if (eof) {
                return false;
            }
            entry.readFields(in);
            long backptr = entry.getBackPointer();
            if (backptr < 0) {
                eof = true;
            } else {
                in.seek(backptr);
            }
            return true;
        }

        @Override
        public long getPos() throws IOException {
            return in.getPos();
        }

        public void close() {
            OmapUtils.safeClose(in);
        }
    }

    @Override
    public String toString() {
        return "[" + this.getClass().getSimpleName() + " path=" + walfile + "]";
    }

    public static final Comparator<WALogFile> FORWARD_COMP = new Comparator<WALogFile>() {

        @Override
        public int compare(WALogFile o1, WALogFile o2) {
            if (o1.fileNumber == o2.fileNumber) {
                return 0;
            }
            return o1.fileNumber < o2.fileNumber ? -1 : 1;
        }
    };

    public static final Comparator<WALogFile> BACKWARD_COMP = new Comparator<WALogFile>() {

        @Override
        public int compare(WALogFile o1, WALogFile o2) {
            if (o2.fileNumber == o1.fileNumber) {
                return 0;
            }
            return o2.fileNumber < o1.fileNumber ? -1 : 1;
        }
    };
}
