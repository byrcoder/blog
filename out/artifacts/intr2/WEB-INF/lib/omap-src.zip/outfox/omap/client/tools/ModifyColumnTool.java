/**
 * @(#)ModifyColumnTool.java, 2010-7-25. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.tools;

import java.io.IOException;
import java.util.logging.Logger;

import odis.cowork.GenericJobDef;
import odis.cowork.JobClient;
import odis.cowork.JobConfig;
import odis.cowork.JobResult;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.tools.ToolContext;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.OmapDataSource;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.exceptions.OmapException;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class ModifyColumnTool {
    private static final Logger LOG = LogFormatter.getLogger(ModifyColumnTool.class);

    private ToolContext context;

    private String tableSpaceName;

    private String tableName;

    private String templateTableName;

    private TableDesc tableDesc;

    private TableDesc templateTableDesc;

    private Class<? extends AbstractConvertRowTool> convertRowToolClass;

    private String fsName;

    private int workerNumber = 16;

    private FileSystem fs;

    public void setContext(ToolContext context) {
        this.context = context;
    }

    public void setTableSpaceName(String tableSpaceName) {
        this.tableSpaceName = tableSpaceName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setTemplateTableName(String templateTableName) {
        this.templateTableName = templateTableName;
    }

    public void setFsName(String fsName) {
        this.fsName = fsName;
    }

    public void setWorkerNumber(int workerNumber) {
        this.workerNumber = workerNumber;
    }

    public void setConvertRowToolClass(
            Class<? extends AbstractConvertRowTool> convertRowToolClass) {
        this.convertRowToolClass = convertRowToolClass;
    }

    private GenericJobDef createCoworkJob() throws IOException {
        KeyRangeList krl = new KeyRangeList();
        String targetDir = OmapConfig.getOmapDataRoot() + "/snapshot-"
                + HexString.longToPaddedHex(tableDesc.getSchemaId());
        FSDataInputStream krlInput = fs.open(new Path(targetDir, "keyRangeList"));
        krl.readFields(krlInput);
        krlInput.close();

        int taskNumber = krl.size();
        GenericJobDef job = context.createGenericJob("ColumnModify-"
                + tableDesc.getTableName(),
                taskNumber < workerNumber ? taskNumber : workerNumber);
        LOG.info("Worker number = " + job.getWorkerNumber(Integer.MAX_VALUE));

        job.setTaskClass(TabletModifyColumnTask.class);

        LOG.info("Task number = " + taskNumber);
        job.setTaskNumber(krl.size());

        JobConfig conf = job.getConfig();

        LOG.info(TabletModifyColumnTask.FS_NAME + " = " + fsName);
        conf.setProperty(TabletModifyColumnTask.FS_NAME, fsName);

        LOG.info(TabletModifyColumnTask.INPUT_PATH + " = " + targetDir);
        conf.setProperty(TabletModifyColumnTask.INPUT_PATH, targetDir);

        String outputPath = OmapConfig.getOmapDataRoot() + "/snapshot-"
                + HexString.longToPaddedHex(templateTableDesc.getSchemaId());
        LOG.info(TabletModifyColumnTask.OUTPUT_PATH + " = " + outputPath);
        conf.setProperty(TabletModifyColumnTask.OUTPUT_PATH, outputPath);

        LOG.info(TabletModifyColumnTask.CONVERT_ROW_TOOL_CLASS_NAME + " = "
                + getClass().getName());
        conf.setProperty(TabletModifyColumnTask.CONVERT_ROW_TOOL_CLASS_NAME,
                convertRowToolClass.getName());

        int part = 0;
        for (KeyRange kr: krl.getRangeSet().keySet()) {
            LOG.info(TabletModifyColumnTask.TABLET_ID_PREFIX + part + " = "
                    + kr.getTabletId());
            conf.setProperty(TabletModifyColumnTask.TABLET_ID_PREFIX + part,
                    kr.getTabletId());
            part++;
        }
        return job;
    }

    public void run() throws IOException, OmapException {
        fs = FileSystem.getNamed(fsName);
        OmapDataSource ds = new OmapDataSource(new ClientConfig(
                OmapConfig.getConfiguration()));
        TableSpace ts = ds.openTableSpace(tableSpaceName);
        Table table = ts.openTable(tableName);
        tableDesc = ((OmapMetadata) table.getMetadata()).getTableDesc();
        String targetDir = OmapConfig.getOmapDataRoot() + "/snapshot-"
                + HexString.longToPaddedHex(tableDesc.getSchemaId());
        if (fs.exists(new Path(targetDir))) {
            fs.delete(new Path(targetDir));
        }
        ts.snapshot(tableName, targetDir, true);
        Table templateTable = ts.openTable(templateTableName);
        templateTableDesc = ((OmapMetadata) templateTable.getMetadata()).getTableDesc();
        Path outputPath = new Path(OmapConfig.getOmapDataRoot() + "/snapshot-"
                + HexString.longToPaddedHex(templateTableDesc.getSchemaId()));
        if (fs.exists(outputPath)) {
            fs.delete(outputPath);
        }
        fs.mkdirs(outputPath);
        fs.link(new Path(targetDir, "keyRangeList"),
                outputPath.cat("keyRangeList"));
        FSDataOutputStream tdOutput = fs.create(outputPath.cat("tableDesc"),
                false, 4096);
        templateTableDesc.writeFields(tdOutput);
        tdOutput.close();
        LOG.info("Using Cowork " + context.getCoWork());
        GenericJobDef job = createCoworkJob();
        LOG.info("GenericJob created, Running...");
        JobResult result = JobClient.runJob(context.getCoWork(), job);
        if (!result.isSuccess()) {
            throw new RuntimeException("Cowork job run failed");
        }
        LOG.info("GenericJob ended, begin import new snapshot");
        ts.deleteTable(templateTableName);
        ts.importSnapshot(templateTableName, outputPath.getAbsolutePath());
        LOG.info("import ended, new table named "
                + OmapUtils.toInternalTableName(tableSpaceName,
                        templateTableName));
        ds.close();
    }
}
