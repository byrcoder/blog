/**
 * @(#)TableOpInterceptor.java, 2013-4-7. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol.mock;

import odis.serialize.IWritable;
import outfox.omap.client.protocol.Row;
import outfox.omap.exceptions.OmapException;

/**
 * @author zhangduo
 */
public interface OpInterceptor {

    void beforeLookup(String tableName, IWritable key) throws OmapException;

    void afterLookup(String tableName, IWritable key, Row row, boolean found)
            throws OmapException;

    void beforeLookup(String tableName, IWritable[] keys) throws OmapException;

    void afterLookup(String tableName, IWritable[] keys, Row[] rows,
            boolean[] founds) throws OmapException;

    void beforeContains(String tableName, IWritable key) throws OmapException;

    void afterContains(String tableName, IWritable key, boolean found)
            throws OmapException;

    void beforeContains(String tableName, IWritable[] keys)
            throws OmapException;

    void afterContains(String tableName, IWritable[] keys, boolean[] founds)
            throws OmapException;

    void beforeUpdate(String tableName, Row row) throws OmapException;

    void afterUpdate(String tableName, Row row) throws OmapException;

    void beforeUpdate(String tableName, Row[] rows) throws OmapException;

    void afterUpdate(String tableName, Row[] rows) throws OmapException;

    void beforeDelete(String tableName, IWritable key) throws OmapException;

    void afterDelete(String tableName, IWritable key) throws OmapException;

    void beforeDelete(String tableName, IWritable[] keys) throws OmapException;

    void afterDelete(String tableName, IWritable[] keys) throws OmapException;

    void beforeDelete(String tableName, IWritable startKeyInclusive,
            IWritable endKeyExclusive) throws OmapException;

    void afterDelete(String tableName, IWritable startKeyInclusive,
            IWritable endKeyExclusive) throws OmapException;

    void beforeCompareAndUpdate(String tableName, IWritable key,
            String columnName, IWritable columnValue, Row update)
            throws OmapException;

    void afterCompareAndUpdate(String tableName, IWritable key,
            String columnName, IWritable columnValue, Row update, boolean succ)
            throws OmapException;

    void beforeCompareAndDelete(String tableName, IWritable key,
            String columnName, IWritable columnValue, IWritable delete)
            throws OmapException;

    void afterCompareAndDelete(String tableName, IWritable key,
            String columnName, IWritable columnValue, IWritable delete,
            boolean succ) throws OmapException;

    void beforeGetTableCursor(String tableName) throws OmapException;

    void afterGetTableCursor(String tableName) throws OmapException;

    void beforeTableCursorMoveTo(String tableName, IWritable key,
            boolean accurate) throws OmapException;

    void afterTableCursorMoveTo(String tableName, IWritable key,
            boolean accurate, boolean found) throws OmapException;

    void beforeTableCursorNext(String tableName) throws OmapException;

    void afterTableCursorNext(String tableName, Row row, boolean found)
            throws OmapException;

    void beforeTableCursorRemove(String tableName) throws OmapException;

    void afterTableCursorRemove(String tableName, IWritable key)
            throws OmapException;
}
