/**
 * @(#)WriteBufferPool.java, 2012-3-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.util.logging.Logger;

import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferPool;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class WriteBufferPool {

    private static final Logger LOG = LogFormatter.getLogger(WriteBufferPool.class);

    final NativeRamBufferPool pool;

    public WriteBufferPool(long ptr, long maxBufferSize, int chunkSize) {
        pool = new NativeRamBufferPool(ptr, maxBufferSize, chunkSize);
        LOG.info("Create write buffer pool with max size = " + maxBufferSize
                + ", chunk size = " + chunkSize);
    }

    public synchronized NativeRamBuffer[] newBuffer(int size) {
        NativeRamBuffer[] buffers = pool.newBuffer(size);
        if (buffers.length == 0) {
            LOG.warning("No write buffer left");
        } else {
            long allocatedSize = buffers.length * pool.getChunkSize();
            LOG.info("Allocating write buffer of size " + allocatedSize
                    + ", write buffer usage: " + pool.getAllocatedBufferSize()
                    + "/" + pool.getMaxBufferSize());
        }
        return buffers;
    }

    public synchronized void releaseBuffer(NativeRamBuffer[] bufs) {
        if (bufs != null) {
            pool.releaseBuffer(bufs);
            long size = bufs.length * pool.getChunkSize();
            LOG.info("Releasing write buffer of size " + size
                    + ", write buffer usage: " + pool.getAllocatedBufferSize()
                    + "/" + pool.getMaxBufferSize());
        }
    }

    public synchronized long getAllocatedBufferSize() {
        return pool.getAllocatedBufferSize();
    }

    public long getMaxBufferSize() {
        return pool.getMaxBufferSize();
    }

    public int getChunkSize() {
        return (int) pool.getChunkSize();
    }
}
