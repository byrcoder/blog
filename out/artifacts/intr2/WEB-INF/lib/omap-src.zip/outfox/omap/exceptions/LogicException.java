/**
 * @(#)LogicException.java, 2013-3-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * Thrown when program run into impossible branches.
 * 
 * @author zhangduo
 */
public class LogicException extends RuntimeException {

    private static final long serialVersionUID = -7907755946199228340L;

    public LogicException(String message, Throwable cause) {
        super(message, cause);
    }

    public LogicException(String message) {
        super(message);
    }

}
