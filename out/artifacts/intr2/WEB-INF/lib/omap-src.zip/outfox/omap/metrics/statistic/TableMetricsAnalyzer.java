/**
 * @(#)TableMetricsAnalyzer.java, 2011-6-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.MasterMetricsType;
import outfox.omap.metrics.TimeRangeUtils;
import outfox.omap.metrics.TsMetricsType;

/**
 * @author zhangduo
 */
public class TableMetricsAnalyzer {

    private long[] masterMetricsRecords = new long[MasterMetricsType.tableTypeCount()];

    private long[] tsMetricsRecords = new long[TsMetricsType.tabletTypeCount()];

    private double[] statisticResults = new double[TableStatisticType.getTypeCount()];

    public void processMasterMetrics(long[] masterMetricsRecords) {
        for (int i = 0; i < MasterMetricsType.tableTypeCount(); i++) {
            this.masterMetricsRecords[i] += masterMetricsRecords[i];
        }
    }

    public void processTsMetrics(long[] tsMetricsRecords) {
        for (int i = 0; i < TsMetricsType.tabletTypeCount(); i++) {
            this.tsMetricsRecords[i] += tsMetricsRecords[i];
        }
    }

    public void done() {
        // Master
        statisticResults[TableStatisticType.LOOKUP_KEY_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()];
        if (masterMetricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.LOOKUP_KEY_DELAY.offset()] = (double) masterMetricsRecords[MasterMetricsType.LOOKUP_KEY_DELAY.offset()]
                    / masterMetricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.LOOKUP_KEY_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_LOOKUP_KEY_COUNT.offset()
                    + i] = masterMetricsRecords[MasterMetricsType.TIME_RANGE_LOOKUP_KEY_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.RENAME_TABLE_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()];
        if (masterMetricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.RENAME_TABLE_DELAY.offset()] = (double) masterMetricsRecords[MasterMetricsType.RENAME_TABLE_DELAY.offset()]
                    / masterMetricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.RENAME_TABLE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_RENAME_TABLE_COUNT.offset()
                    + i] = masterMetricsRecords[MasterMetricsType.TIME_RANGE_RENAME_TABLE_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.SET_TABLE_PROPERTIES_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()];
        if (masterMetricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.SET_TABLE_PROPERTIES_DELAY.offset()] = (double) masterMetricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_DELAY.offset()]
                    / masterMetricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.SET_TABLE_PROPERTIES_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset()
                    + i] = masterMetricsRecords[MasterMetricsType.TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.GET_SCHEMA_ID_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()];
        if (masterMetricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.GET_SCHEMA_ID_DELAY.offset()] = (double) masterMetricsRecords[MasterMetricsType.GET_SCHEMA_ID_DELAY.offset()]
                    / masterMetricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.GET_SCHEMA_ID_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_GET_SCHEMA_ID_COUNT.offset()
                    + i] = masterMetricsRecords[MasterMetricsType.TIME_RANGE_GET_SCHEMA_ID_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.GET_METADATA_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()];
        if (masterMetricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.GET_METADATA_DELAY.offset()] = (double) masterMetricsRecords[MasterMetricsType.GET_METADATA_DELAY.offset()]
                    / masterMetricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.GET_METADATA_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_GET_METADATA_COUNT.offset()
                    + i] = masterMetricsRecords[MasterMetricsType.TIME_RANGE_GET_METADATA_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.SET_READ_ONLY_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()];
        if (masterMetricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.SET_READ_ONLY_DELAY.offset()] = (double) masterMetricsRecords[MasterMetricsType.SET_READ_ONLY_DELAY.offset()]
                    / masterMetricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.SET_READ_ONLY_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_SET_READ_ONLY_COUNT.offset()
                    + i] = masterMetricsRecords[MasterMetricsType.TIME_RANGE_SET_READ_ONLY_COUNT.offset()
                    + i];
        }

        // Ts
        statisticResults[TableStatisticType.KEY_FIND_COUNT.offset()] = tsMetricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.KEY_FIND_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.KEY_FIND_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.KEY_FIND_SIZE_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.KEY_FIND_SIZE.offset()]
                    / tsMetricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.KEY_FIND_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.KEY_FIND_SIZE_PER_COUNT.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_KEY_FIND_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_KEY_FIND_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.MULTI_KEY_FIND_COUNT.offset()] = tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.MULTI_KEY_FIND_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_KEY_FIND_ROWS_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_ROWS.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_KEY_FIND_SIZE_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_SIZE.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_KEY_FIND_DELAY_PER_ROW.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_ROWS.offset()];
        } else {
            statisticResults[TableStatisticType.MULTI_KEY_FIND_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_KEY_FIND_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_KEY_FIND_SIZE_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_KEY_FIND_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_MULTI_KEY_FIND_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_MULTI_KEY_FIND_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.RANGE_KEY_FIND_COUNT.offset()] = tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.RANGE_KEY_FIND_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.RANGE_KEY_FIND_ROWS_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_ROWS.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.RANGE_KEY_FIND_SIZE_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_SIZE.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()];
            statisticResults[TableStatisticType.RANGE_KEY_FIND_DELAY_PER_ROW.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_ROWS.offset()];
        } else {
            statisticResults[TableStatisticType.RANGE_KEY_FIND_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.RANGE_KEY_FIND_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.RANGE_KEY_FIND_SIZE_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.RANGE_KEY_FIND_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_RANGE_KEY_FIND_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_RANGE_KEY_FIND_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.CONTAINS_COUNT.offset()] = tsMetricsRecords[TsMetricsType.CONTAINS_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.CONTAINS_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.CONTAINS_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.CONTAINS_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.CONTAINS_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.CONTAINS_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_CONTAINS_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_CONTAINS_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.MULTI_CONTAINS_COUNT.offset()] = tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.MULTI_CONTAINS_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_CONTAINS_ROWS_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_ROWS.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_CONTAINS_DELAY_PER_ROW.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_ROWS.offset()];
        } else {
            statisticResults[TableStatisticType.MULTI_CONTAINS_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_CONTAINS_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_CONTAINS_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_MULTI_CONTAINS_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_MULTI_CONTAINS_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.INSERT_COUNT.offset()] = tsMetricsRecords[TsMetricsType.INSERT_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.INSERT_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.INSERT_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.INSERT_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.INSERT_COUNT.offset()];
            statisticResults[TableStatisticType.INSERT_SIZE_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.INSERT_SIZE.offset()]
                    / tsMetricsRecords[TsMetricsType.INSERT_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.INSERT_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.INSERT_SIZE_PER_COUNT.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_INSERT_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_INSERT_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.MULTI_INSERT_COUNT.offset()] = tsMetricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.MULTI_INSERT_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_INSERT_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_INSERT_ROWS_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_INSERT_ROWS.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_INSERT_SIZE_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_INSERT_SIZE.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_INSERT_DELAY_PER_ROW.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_INSERT_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_INSERT_ROWS.offset()];
        } else {
            statisticResults[TableStatisticType.MULTI_INSERT_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_INSERT_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_INSERT_SIZE_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_INSERT_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_MULTI_INSERT_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_MULTI_INSERT_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.DELETE_COUNT.offset()] = tsMetricsRecords[TsMetricsType.DELETE_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.DELETE_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.DELETE_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.DELETE_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.DELETE_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.DELETE_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_DELETE_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_DELETE_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.MULTI_DELETE_COUNT.offset()] = tsMetricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.MULTI_DELETE_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_DELETE_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_DELETE_ROWS_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_DELETE_ROWS.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()];
            statisticResults[TableStatisticType.MULTI_DELETE_DELAY_PER_ROW.offset()] = (double) tsMetricsRecords[TsMetricsType.MULTI_DELETE_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.MULTI_DELETE_ROWS.offset()];
        } else {
            statisticResults[TableStatisticType.MULTI_DELETE_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_DELETE_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.MULTI_DELETE_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_MULTI_DELETE_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_MULTI_DELETE_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.RANGE_DELETE_COUNT.offset()] = tsMetricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.RANGE_DELETE_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_DELETE_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()];
            statisticResults[TableStatisticType.RANGE_DELETE_ROWS_PER_COUNT.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_DELETE_ROWS.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()];
            statisticResults[TableStatisticType.RANGE_DELETE_DELAY_PER_ROW.offset()] = (double) tsMetricsRecords[TsMetricsType.RANGE_DELETE_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.RANGE_DELETE_ROWS.offset()];
        } else {
            statisticResults[TableStatisticType.RANGE_DELETE_DELAY.offset()] = Double.NaN;
            statisticResults[TableStatisticType.RANGE_DELETE_ROWS_PER_COUNT.offset()] = Double.NaN;
            statisticResults[TableStatisticType.RANGE_DELETE_DELAY_PER_ROW.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_RANGE_DELETE_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_RANGE_DELETE_COUNT.offset()
                    + i];
        }
        
        statisticResults[TableStatisticType.COMPARE_AND_SET_COUNT.offset()] = tsMetricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.COMPARE_AND_SET_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.COMPARE_AND_SET_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.COMPARE_AND_SET_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_COMPARE_AND_SET_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_COMPARE_AND_SET_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.LOCK_ROW_COUNT.offset()] = tsMetricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.LOCK_ROW_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.LOCK_ROW_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.LOCK_ROW_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_LOCK_ROW_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_LOCK_ROW_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.UNLOCK_ROW_COUNT.offset()] = tsMetricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()];
        if (tsMetricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()] > 0) {
            statisticResults[TableStatisticType.UNLOCK_ROW_DELAY.offset()] = (double) tsMetricsRecords[TsMetricsType.UNLOCK_ROW_DELAY.offset()]
                    / tsMetricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()];
        } else {
            statisticResults[TableStatisticType.UNLOCK_ROW_DELAY.offset()] = Double.NaN;
        }
        for (int i = 0; i < TimeRangeUtils.rangeCount(); i++) {
            statisticResults[TableStatisticType.TIME_RANGE_UNLOCK_ROW_COUNT.offset()
                    + i] = tsMetricsRecords[TsMetricsType.TIME_RANGE_UNLOCK_ROW_COUNT.offset()
                    + i];
        }

        statisticResults[TableStatisticType.TOTAL_OPERATION_COUNT.offset()] = masterMetricsRecords[MasterMetricsType.LOOKUP_KEY_COUNT.offset()]
                + masterMetricsRecords[MasterMetricsType.RENAME_TABLE_COUNT.offset()]
                + masterMetricsRecords[MasterMetricsType.SET_TABLE_PROPERTIES_COUNT.offset()]
                + masterMetricsRecords[MasterMetricsType.GET_SCHEMA_ID_COUNT.offset()]
                + masterMetricsRecords[MasterMetricsType.GET_METADATA_COUNT.offset()]
                + masterMetricsRecords[MasterMetricsType.SET_READ_ONLY_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.CONTAINS_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.INSERT_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.DELETE_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()]
                + tsMetricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()];
    }

    public double[] getStatisticResults() {
        return statisticResults;
    }

}
