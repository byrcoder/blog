package outfox.omap.conf;

import java.io.File;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.ConfigUtils;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.FSConstants;
import odis.io.Path;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;

import outfox.omap.util.OmapLogFormatter;

/**
 * OMAP configurations which provides some additional const entries.
 * 
 * @author river
 */
public class OmapConfig {
    public static final Logger LOG = OmapLogFormatter.getLogger(OmapConfig.class);

    private static Configuration omapConf;

    private static File omapHome;
    static {
        String tmp = System.getProperty("omap.home");
        if (tmp == null) {
            tmp = System.getenv("OMAP_HOME");
        }
        if (tmp == null) {
            tmp = System.getProperty("odis.home");
        }
        if (tmp == null) {
            tmp = System.getenv("ODIS_HOME");
        }
        if (tmp == null) {
            tmp = ".";
        }
        omapHome = new File(tmp);

        System.setProperty("omap.home", omapHome.getAbsolutePath());

        File confDir = new File(omapHome, "conf");

        try {
            omapConf = ConfigUtils.parseXmlConfig(confDir, new String[] {
                "omap.xml"
            });
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "parse omap configuration failed", e);
            throw new RuntimeException("parse omap configuration failed", e);
        }

        Set<String> validKeys = getValidKeys();
        // check validity of configuration file
        for (@SuppressWarnings("unchecked")
        Iterator<String> it = omapConf.getKeys(); it.hasNext();) {
            String key = it.next();
            if (validKeys.contains(key)) {
                LOG.info("Read configuration: " + key + "="
                        + omapConf.getProperty(key));
            } else {
                LOG.warning("Undefined configuration item: " + key);
            }
        }
        OmapLogFormatter.setShowThreadIDs(true);
    }

    public static Set<String> getValidKeys() {
        Set<String> validKeys = new HashSet<String>();
        for (Field field: OmapConfig.class.getFields()) {
            if (field.getType().equals(String.class)
                    && field.getName().startsWith("NAME_")) {
                try {
                    validKeys.add((String) field.get(null));
                } catch (Exception e) {}
            }
        }
        return validKeys;
    }

    public static String getDefaultValue(String key) {
        for (Field field: OmapConfig.class.getFields()) {
            if (field.getType().equals(String.class)
                    && field.getName().startsWith("NAME_")) {
                try {
                    String configKey = (String) field.get(null);
                    if (key.equals(configKey)) {
                        Field defaultField = OmapConfig.class.getField("DEFAULT_"
                                + field.getName().substring("NAME_".length()));
                        if (defaultField != null) {
                            return defaultField.get(null).toString();
                        }
                    }
                } catch (Exception e) {}
            }
        }
        return null;
    }

    public static Configuration getConfiguration() {
        return omapConf;
    }

    public static final String NAME_LOG_OUTPUT_DIR = "omap.logging.dir";

    public static final String DEFAULT_LOG_OUTPUT_DIR = "logs";

    public static final String NAME_LOG_FILE_SIZE_LIMIT = "omap.logging.file-size-limit";

    public static final int DEFAULT_LOG_FILE_SIZE_LIMIT = 100 * 1024 * 1024;

    public static final String NAME_LOG_FILE_COUNT_LIMIT = "omap.logging.file-count-limit";

    public static final int DEFAULT_LOG_FILE_COUNT_LIMIT = 100;

    public static final String NAME_MAX_BYTES_PER_ROW = "omap.ts.max-bytes-per-row";

    public static final int DEFAULT_MAX_BYTES_PER_ROW = 10 * 1024 * 1024;

    /**
     * The max bytes of a Tablet. Exceeding it will cause split. The size of a
     * Tablet is decided by the size of the largest SS table of the tablet.
     */
    public static final String NAME_MAX_BYTES_PER_TABLET = "omap.ts.max-bytes-per-tablet";

    public static final long DEFAULT_MAX_BYTES_PER_TABLET = 200 * 1024 * 1024;

    /**
     * The max number of records of a Tablet. Exceeding it will cause split. The
     * number of records of a Tablet is decided by that of the largest SS table
     * of the tablet.
     */
    public static final String NAME_MAX_RECORDS_PER_TABLET = "omap.ts.max-records-per-tablet";

    public static final long DEFAULT_MAX_RECORDS_PER_TABLET = 10000000L;

    public static final String NAME_ENABLE_BLOOM_FILTER = "omap.ts.enable-bloom-filter";

    public static final boolean DEFAULT_ENABLE_BLOOM_FILTER = true;

    public static final String NAME_COMPACT_SS_INTERVAL = "omap.ts.compact-ss-interval";

    // seconds
    public static final long DEFAULT_COMPACT_SS_INTERVAL = 10L;

    /**
     * The lower threshold of the SSTable compation routine. The compact process
     * is controlled so that at most of the time the number of sstables is
     * between [lower threshold, higher threshold]. Once there are more than
     * sstableCountLow sstables, compact process is triggered and at least two
     * sstables are merged.
     */
    public static final String NAME_SSTABLE_COUNT_LOW = "omap.ts.sstable-count-low";

    public static final int DEFAULT_SSTABLE_COUNT_LOW = 4;

    /**
     * The higher threshold of the SSTable compaction routine. Whenever a
     * compaciton is about to happen, we make sure that no more SSTables than
     * the higher threshold after the compaciton.
     */
    public static final String NAME_SSTABLE_COUNT_HIGH = "omap.ts.sstable-count-high";

    public static final int DEFAULT_SSTABLE_COUNT_HIGH = 8;

    public static final String NAME_COMPACT_SS_MAX_CONCURRENCY = "omap.ts.compact-ss-max-concurrency";

    public static final int DEFAULT_COMPACT_SS_MAX_CONCURRENCY = 2;

    /**
     * The higher bound of the total write throughput (Bps) of SSTable
     * compaction on a Tablet Server.
     */
    public static final String NAME_COMPACT_SS_THROUGHPUT_HIGH = "omap.ts.compact-ss-throughput-high";

    public static final long DEFAULT_COMPACT_SS_THROUGHPUT_HIGH = 1024 * 1024;

    /**
     * The lower bound of the total write throughput (Bps) of SSTable compaction
     * on a Tablet Server.
     */
    public static final String NAME_COMPACT_SS_THROUGHPUT_LOW = "omap.ts.compact-ss-throughput-low";

    public static final long DEFAULT_COMPACT_SS_THROUGHPUT_LOW = 100 * 1024;

    public static final String NAME_COMPACTION_TUNER_INTERVAL = "omap.ts.compact-throughput-tuner-interval";

    public static final long DEFAULT_COMPACTION_TUNER_INTERVAL = 60L;

    public static final String NAME_CHECKPOINT_MAX_INTERVAL = "omap.ts.checkpoint-max-interval";

    // set to 0 to disable mandatory periodical checkpoint, in seconds
    public static final long DEFAULT_CHECKPOINT_MAX_INTERVAL = 3600L;

    public static final String NAME_MANDATORY_CHECKPOINT_TASK_INTERVAL = "omap.ts.mandatory-checkpoint-task-interval";

    // in seconds
    public static final long DEFAULT_MANDATORY_CHECKPOINT_TASK_INTERVAL = 5L;

    public static final String NAME_MANDATORY_CHECKPOINT_TASK_CHECKPOINT_INTERVAL = "omap.ts.mandatory-checkpoint-task-checkpoint-interval";

    // in seconds
    public static final long DEFAULT_MANDATORY_CHECKPOINT_TASK_CHECKPOINT_INTERVAL = 60L;

    /**
     * The maximum interval in which the WALogger generates a new chunk (in
     * seconds)
     */
    public static final String NAME_WAL_NEWCHUNK_MAX_INTERVAL = "omap.ts.log-newchunk-max-interval";

    // in seconds, set to 0 to disable mandatory periodical new chunk
    public static final long DEFAULT_WAL_NEWCHUNK_MAX_INTERVAL = 3600L;

    public static final String NAME_DISASSEMBLE_WAL_INTERVAL = "omap.ts.disassemble-log-interval";

    public static final long DEFAULT_DISASSEMBLE_WAL_INTERVAL = 30L;

    /**
     * The max native ram file size, ts would disassemble log and write to odfs
     * directly iff exceeding
     */
    public static final String NAME_DISASSEMBLE_WAL_MAX_BUFFER_SIZE = "omap.ts.disassemble-log-max-buffer-size";

    public static final int DEFAULT_DISASSEMBLE_WAL_MAX_BUFFER_SIZE = 512 * 1024 * 1024;

    public static final String NAME_DISASSEMBLE_WAL_RETRY_COUNT = "omap.ts.disassemble-log-retry-count";

    public static final int DEFAULT_DISASSEMBLE_WAL_RETRY_COUNT = 5;

    /**
     * The maximum total write throughput (Bps) of log truncation on a Tablet
     * Server. Set to 0 to disable throughput limits.
     */
    public static final String NAME_TRUNCATE_WAL_MAX_THROUGHPUT = "omap.ts.truncate-log-max-throughput";

    public static final long DEFAULT_TRUNCATE_WAL_MAX_THROUGHPUT = 1024 * 1024;

    public static final String NAME_SPLIT_CHECK_INTERVAL = "omap.ts.split-check-interval";

    public static final long DEFAULT_SPLIT_CHECK_INTERVAL = 5L;

    public static final String NAME_HEARTBEAT_INTERVAL = "omap.ts.heartbeat-interval";

    // in seconds
    public static final long DEFAULT_HEARTBEAT_INTERVAL = 5L;

    public static final String NAME_TS_CLEAN_EXPIRE_LOCK_INTERVAL = "omap.ts.clean-expire-lock-interval";

    // in seconds
    public static final long DEFAULT_TS_CLEAN_EXPIRE_LOCL_INTERVAL = 5;

    public static final String NAME_TS_TABLET_CHECKPOINT_TASK_POOL_SIZE = "omap.ts.tablet-checkpoint-task-pool-size";

    public static final int DEFAULT_TS_TABLET_CHECKPOINT_TASK_POOL_SIZE = 30;

    public static final String NAME_TS_BACKGROUND_TASK_POOL_CORE_POOL_SIZE = "omap.ts.background-task-pool-core-pool-size";

    public static final int DEFAULT_TS_BACKGROUND_TASK_POOL_CORE_POOL_SIZE = 3;

    public static final String NAME_TS_PER_TABLET_TASK_POOL_CORE_POOL_SIZE = "omap.ts.per-tablet-task-pool-core-pool-size";

    public static final int DEFAULT_TS_PER_TABLET_TASK_POOL_CORE_POOL_SIZE = 16;

    public static final String NAME_TS_MASTER_TASK_POOL_CORE_POOL_SIZE = "omap.ts.master-task-pool-core-pool-size";

    public static final int DEFAULT_TS_MASTER_TASK_POOL_CORE_POOL_SIZE = 10;

    public static final String NAME_TS_ROW_LOCK_QUEUE_MAX_CAPACITY = "omap.ts.row-lock-queue-max-capacity";

    public static final int DEFAULT_TS_ROW_LOCK_QUEUE_MAX_CAPACITY = 32768;

    public static final String NAME_TS_MAX_SSTABLE_NATIVE_CACHE_SIZE = "omap.ts.max-sstable-native-cache-size";

    public static final long DEFAULT_TS_MAX_SSTABLE_NATIVE_CACHE_SIZE = 1L * 1024 * 1024 * 1024;

    public static final String NAME_TS_SSTABLE_NATIVE_CACHE_LOAD_CONCURRENCY = "omap.ts.sstable-native-cache-load-concurrency";

    public static final int DEFAULT_TS_SSTABLE_NATIVE_CACHE_LOAD_CONCURRENCY = 2;

    public static final String NAME_FS_NAME = "omap.fs.name";

    public static final String DEFAULT_FS_NAME = "local";

    private static final int FS_CONFIG_NAME_START_INDEX = "dfs.client.".length();

    public static final String NAME_FS_NAMENODE_RPC_TIMEOUT = "omap.fs."
            + DFSClientConfig.NAMENODE_PRC_TIME_OUT.substring(FS_CONFIG_NAME_START_INDEX);

    public static final long DEFAULT_FS_NAMENODE_RPC_TIMEOUT = 15000;

    public static final String NAME_FS_OPEN_DATANODE_MAX_RETRY_TIMES = "omap.fs."
            + DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_OPEN_DATANODE_MAX_RETRY_TIMES = 1;

    public static final String NAME_FS_DATANODE_BLOCK_READ_TIMEOUT = "omap.fs."
            + DFSClientConfig.DATANODE_BLOCK_READ_TIMEOUT.substring(FS_CONFIG_NAME_START_INDEX);

    public static final long DEFAULT_FS_DATANODE_BLOCK_READ_TIMEOUT = 15000;

    public static final String NAME_FS_BLOCK_WRITE_TIMEOUT = "omap.fs."
            + DFSClientConfig.CLIENT_BLOCK_WRITE_TIMEOUT.substring(FS_CONFIG_NAME_START_INDEX);

    public static final long DEFAULT_FS_BLOCK_WRITE_TIMEOUT = 10000;

    public static final String NAME_FS_COMPLETE_FILE_MAX_RETRY_TIME = "omap.fs."
            + DFSClientConfig.COMPLETE_FILE_MAX_RETRY_TIME.substring(FS_CONFIG_NAME_START_INDEX);

    public static final long DEFAULT_FS_COMPLETE_FILE_MAX_RETRY_TIME = 15000;

    public static final String NAME_FS_COMPLETE_FILE_RETRY_INTERVAL = "omap.fs."
            + DFSClientConfig.COMPLETE_FILE_RETRY_INTERVAL.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_COMPLETE_FILE_RETRY_INTERVAL = 1000;

    public static final String NAME_FS_RECOVER_BLOCK_MAX_RETRY_COUNT = "omap.fs."
            + DFSClientConfig.RECOVER_BLOCK_MAX_RETRY_COUNT.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_RECOVER_BLOCK_MAX_RETRY_COUNT = 0;

    public static final String NAME_FS_DATANODE_FLUSH_MAX_RETRY_COUNT = "omap.fs."
            + DFSClientConfig.DATANODE_FLUSH_MAX_RETRY_COUNT.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_DATANODE_FLUSH_MAX_RETRY_COUNT = 5;

    public static final String NAME_FS_CLIENT_WRITE_BUFFER_SIZE = "omap.fs."
            + DFSClientConfig.CLIENT_WRITE_BUFFER_SIZE.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_CLIENT_WRITE_BUFFER_SIZE = 64 * 1024;

    public static final String NAME_FS_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME = "omap.fs."
            + DFSClientConfig.CLIENT_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME.substring(FS_CONFIG_NAME_START_INDEX);

    public static final long DEFAULT_FS_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME = 60 * 1000;

    public static final String NAME_FS_DEFAULT_CREATE_PERMISSION = "omap.fs."
            + DFSClientConfig.DEFAULT_CREATE_PERMISSION.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_DEFAULT_CREATE_PERMISSION = 00755;

    public static final String NAME_FS_SEQUENTIAL_READER_MAX_SKIP = "omap.fs."
            + DFSClientConfig.SEQUENTIAL_READER_MAX_SKIP.substring(FS_CONFIG_NAME_START_INDEX);

    public static final int DEFAULT_FS_SEQUENTIAL_READER_MAX_SKIP = 64 * 1024;

    public static final String NAME_OMAP_DATA_ROOT = "omap.fs.root";

    public static final String DEFAULT_OMAT_DATA_ROOT = "/tmp"; // absolute

    public static String getOmapDataRoot() {
        return omapConf.getString(NAME_OMAP_DATA_ROOT, DEFAULT_OMAT_DATA_ROOT);
    }

    public static String getWalPath() {
        return getOmapDataRoot() + "/wal";
    }

    public static String getWalPathForRecovery() {
        return getOmapDataRoot() + "/wal-recover";
    }

    public static final String NAME_WAL_ENTRIES_PER_FLUSH = "omap.ts.wal-entries-per-flush";

    public static final int DEFAULT_WAL_ENTRIES_PER_FLUSH = 100;

    public static final String NAME_WAL_SIZE_PER_FLUSH = "omap.ts.wal-size-per-flush";

    public static final int DEFAULT_WAL_SIZE_PER_FLUSH = 1024 * 1024;

    public static final String NAME_WAL_CHUNK_SIZE = "omap.ts.wal-chunksize";

    public static final int DEFAULT_WAL_CHUNK_SIZE = 120 * 1024 * 1024;

    public static final String NAME_TS_DATA_PATH_LASTNAME = "omap.ts.data-path-lastname";

    // relative to OMAP_DATA_ROOT
    public static final String DEFAULT_TS_DATA_PATH_LASTNAME = "ts";

    public static String getTsDataPath() {
        return getOmapDataRoot()
                + "/"
                + omapConf.getString(NAME_TS_DATA_PATH_LASTNAME,
                        DEFAULT_TS_DATA_PATH_LASTNAME);
    }

    public static String getTsTabletDir() {
        return getTsDataPath() + "/tablets";
    }

    public static final String NAME_OMAP_META_DATA_PATH_LASTNAME = "omap.metadata-path-lastname";

    public static final String DEFAULT_OMAP_META_DATA_PATH_LASTNAME = "meta";

    public static final String getMetadataDir() {
        return getOmapDataRoot()
                + "/"
                + omapConf.getString(NAME_OMAP_META_DATA_PATH_LASTNAME,
                        DEFAULT_OMAP_META_DATA_PATH_LASTNAME);
    }

    public static final String NAME_OMAP_TASK_PATH_LASTNAME = "omap.task-path-lastname";

    public static final String DEFAULT_OMAP_TASK_PATH_LASTNAME = "task";

    public static final String getTaskDir() {
        return getOmapDataRoot()
                + "/"
                + omapConf.getString(NAME_OMAP_TASK_PATH_LASTNAME,
                        DEFAULT_OMAP_TASK_PATH_LASTNAME);
    }

    public static final String NAME_OMAP_RECYCLED_PATH_LAST_NAME = "omap.recycled-path-lastname";

    public static final String DEFAULT_OMAP_RECYCLED_PATH_LAST_NAME = "recycled";

    public static final String getRecycledDir() {
        return getOmapDataRoot()
                + "/"
                + omapConf.getString(NAME_OMAP_RECYCLED_PATH_LAST_NAME,
                        DEFAULT_OMAP_RECYCLED_PATH_LAST_NAME);
    }

    public static final String NAME_TS_LOCAL_ROOT = "omap.ts.localroot";

    public static final String NAME_FS_TEMP_ROOT = "omap.fs.temp-root";

    public static final String DEFAULT_FS_TEMP_ROOT = "fstemp";

    public static final String NAME_TS_TEMP_PATH_LASTNAME = "omap.ts.temp-path-lastname";

    // relative to TS_LOCAL_ROOT
    public static final String DEFAULT_TS_TEMP_PATH_LASTNAME = "tstemp";

    public static final String NAME_MASTER_MIGRATION_CHECK_INTERVAL = "omap.master.migration-check-interval";

    public static final long DEFAULT_MASTER_MIGRATION_CHECK_INTERVAL = 10;

    // the name that identify the master (i.e. the OMAP instance)
    public static final String NAME_MASTER_NAME = "omap.master.name";

    // the network host of the master
    public static final String NAME_MASTER_HOST = "omap.master.host";

    // the listening port of the master
    public static final String NAME_MASTER_PORT = "omap.master.port";

    public static final String NAME_MASTER_WEB_PORT = "omap.master.web.port";

    public static final int DEFAULT_MASTER_WEB_PORT = 6980;

    public static final String NAME_MASTER_BEANSHELL_PORT = "omap.master.bsh.port";

    public static final int DEFAULT_MASTER_BEANSHELL_PORT = 6992;

    public static final String NAME_TS_BEANSHELL_PORT = "omap.ts.bsh.port";

    public static final int DEFAULT_TS_BEANSHELL_PORT = 6998;

    public static final int DEFAULT_MASTER_PORT = OmapConstants.DEFAULT_MASTERPORT;

    public static final String NAME_MASTER_CHECK_TASK_INTERVAL = "omap.master.check-task-interval";

    public static final long DEFAULT_MASTER_CHECK_TASK_INTERVAL = 15L;

    public static final String NAME_PER_TS_MAX_TABLETS = "omap.ts.max-tablets";

    public static final int DEFAULT_PER_TS_MAX_TABLETS = 100;

    public static final String NAME_WRITE_BUFFER_TOTAL_SIZE = "omap.ts.writebuffer-totalsize";

    public static final long DEFAULT_WRITE_BUFFER_TOTAL_SIZE = 1024 * 1024 * 1024;

    public static final String NAME_WRITE_BUFFER_SIZE = "omap.ts.writebuffer-size";

    public static final int DEFAULT_WRITE_BUFFER_SIZE = 16 * 1024 * 1024;

    public static final String NAME_WRITE_BUFFER_CHUNK_SIZE = "omap.ts.writebuffer-chunksize";

    public static final int DEFAULT_WRITE_BUFFER_CHUNK_SIZE = 1024 * 1024;

    public static final String NAME_BLOOM_FILTER_MAX_SIZE = "omap.ts.bloomfilter-maxsize";

    public static final long DEFAULT_BLOOM_FILTER_MAX_SIZE = 128L * 1024 * 1024;

    public static final String NAME_BLOOM_FILTER_CHUNK_SIZE = "omap.ts.bloomfilter-chunksize";

    public static final int DEFAULT_BLOOM_FILTER_CHUNK_SIZE = 256;

    public static final String NAME_SPARSE_INDEX_MAX_SIZE = "omap.ts.sparseindex-maxsize";

    public static final long DEFAULT_SPARSE_INDEX_MAX_SIZE = 1024 * 1024 * 1024;

    public static final String NAME_SPARSE_INDEX_CHUNK_SIZE = "omap.ts.sparseindex-chunksize";

    public static final int DEFAULT_SPARSE_INDEX_CHUNK_SIZE = 1024;

    public static final String NAME_BLOCK_CACHE_MAX_SIZE = "omap.ts.blockcache-maxsize";

    public static final long DEFAULT_BLOCK_CACHE_MAX_SIZE = 128 * 1024 * 1024;

    public static final String NAME_BLOCK_CACHE_CHUNK_SIZE = "omap.ts.blockcache-chunksize";

    public static final int DEFAULT_BLOCK_CACHE_CHUNK_SIZE = 1024;

    public static final String NAME_ZOOKEEPER_ADDRESS = "omap.zookeeper.address";

    public static final String NAME_TS_ZOOKEEPER_TIMEOUT = "omap.ts.zookeeper-timeout";

    // in milliseconds
    public static final int DEFAULT_TS_ZOOKEEPER_TIMEOUT = 5000;

    public static final String NAME_MASTER_ZOOKEEPER_TIMEOUT = "omap.master.zookeeper-timeout";

    // in milliseconds
    public static final int DEFAULT_MASTER_ZOOKEEPER_TIMEOUT = 5000;

    public static final String NAME_ACTIVE_MASTER_ZNODE_NAME = "omap.master.active-znode";

    public static final String DEFAULT_ACTIVE_MASTER_ZNODE_NAME = "master.active";

    public static final String NAME_OMAP_ZOOKEEPER_ROOT = "omap.zookeeper.root";

    public static final String NAME_TS_ZOOKEEPER_ZNODE_PATH = "omap.ts.znode-path";

    public static final String DEFAULT_TS_ZOOKEEPER_ZNODE_PATH = "ts";

    public static String getZkAddress() {
        String[] addrs = omapConf.getStringArray(NAME_ZOOKEEPER_ADDRESS);
        StringBuilder sb = new StringBuilder(addrs[0]);
        for (int i = 1; i < addrs.length; i++) {
            sb.append(',').append(addrs[i]);
        }
        return sb.toString();
    }

    public static String getZkActiveMasterPath() {
        return omapConf.getString(NAME_OMAP_ZOOKEEPER_ROOT)
                + "/"
                + omapConf.getString(NAME_ACTIVE_MASTER_ZNODE_NAME,
                        DEFAULT_ACTIVE_MASTER_ZNODE_NAME);
    }

    public static String getZkTsPath() {
        return omapConf.getString(NAME_OMAP_ZOOKEEPER_ROOT)
                + "/"
                + omapConf.getString(NAME_TS_ZOOKEEPER_ZNODE_PATH,
                        DEFAULT_TS_ZOOKEEPER_ZNODE_PATH);
    }

    public static final String NAME_DECREASE_TABLET_LOAD_INTERVAL = "omap.ts.decreasetabletload-interval";

    // in seconds
    public static final long DEFAULT_DECREASE_TABLET_LOAD_INTERVAL = 3600;

    public static final String NAME_UNLOAD_SSTABLE_INTERVAL = "omap.ts.unload-sstable-interval";

    // in seconds
    public static final long DEFAULT_UNLOAD_SSTABLE_INTERVAL = 1800;

    public static final String NAME_UPDATE_TABLET_LOAD_INTERVAL = "omap.ts.updatetabletload-interval";

    // in seconds
    public static final long DEFAULT_UPDATE_TABLET_LOAD_INTERVAL = 5;

    public static final String NAME_LOAD_MEMORY_WEIGHT = "omap.master.load-memory-weight";

    public static final double DEFAULT_LOAD_MEMORY_WEIGHT = 0.3d;

    public static final String NAME_LOAD_READ_WEIGHT = "omap.master.load-read-weight";

    public static final double DEFAULT_LOAD_READ_WEIGHT = 0.2d;

    public static final String NAME_LOAD_WRITE_WEIGHT = "omap.master.load-write-weight";

    public static final double DEFAULT_LOAD_WRITE_WEIGHT = 0.2d;

    public static final String NAME_LOAD_WRITE_BUFFER_WEIGHT = "omap.master.load-write-buffer-weight";

    public static final double DEFAULT_LOAD_WRITE_BUFFER_WEIGHT = 0.3d;

    public static final String NAME_LOAD_BALANCE_MIGRATE_THRESHOLD = "omap.master.load-balance-migrate-threshold";

    public static final double DEFAULT_LOAD_BALANCE_MIGRATE_THRESHOLD = 1.25d;

    public static final String NAME_BALANCE_BY_LOAD_HEARTBEAT_THRESHOLD = "omap.master.balance-by-load-heartbeat-threshold";

    public static final int DEFAULT_BALANCE_BY_LOAD_HEARTBEAT_THRESHOLD = 360;

    public static final String NAME_DISPATCHER_WEB_PORT = "omap.dispathcer.web-port";

    public static final int DEFAULT_DISPATCHER_WEB_PORT = 6790;

    public static final String NAME_ENABLE_EMAIL_ALERT = "omap.alert.enable-email";

    public static final boolean DEFAULT_ENABLE_EMAIL_ALERT = false;

    public static boolean enableEmailAlert() {
        return omapConf.getBoolean(NAME_ENABLE_EMAIL_ALERT,
                DEFAULT_ENABLE_EMAIL_ALERT);
    }

    public static final String NAME_ENABLE_SMS_ALERT = "omap.alert.enable-sms";

    public static final boolean DEFAULT_ENABLE_SMS_ALERT = false;

    public static boolean enableSmsAlert() {
        return omapConf.getBoolean(NAME_ENABLE_SMS_ALERT,
                DEFAULT_ENABLE_SMS_ALERT);
    }

    public static final String NAME_ALERT_SMS_SENDER_GROUP = "omap.alert.sms-sender-group";

    public static final String DEFAULT_ALERT_SMS_SENDER_GROUP = "omap";

    public static final String NAME_ALERT_FROM_EMAIL = "omap.alert.from-email";

    public static final String DEFAULT_ALERT_FROM_EMAIL = "omap-alert@rd.netease.com";

    public static final String NAME_ALERT_TO_EMAIL = "omap.alert.to-email";

    public static final String DEFAULT_ALERT_TO_EMAIL = "infra@rd.netease.com";

    public static final String NAME_ALERT_MIN_INTERVAL = "omap.alert.min-interval";

    // milliseconds
    public static final long DEFAULT_ALERT_MIN_INTERVAL = 60000;

    public static final String NAME_MONITOR_TS_LIST = "omap.monitor.ts-list";

    @SuppressWarnings("unchecked")
    public static List<String> getMonitorTsList() {
        return omapConf.getList(NAME_MONITOR_TS_LIST);
    }

    public static final String NAME_MONITOR_INTERVAL = "omap.monitor.interval";

    // in seconds
    public static final long DEFAULT_MONITOR_INTERVAL = 60;

    public static final String NAME_MONITOR_REPORT_INTERVAL = "omap.monitor.report-interval";

    // in seconds
    public static final long DEFAULT_MONITOR_REPORT_INTERVAL = 300;

    public static final String NAME_METRICS_INTERVAL = "omap.metrics.interval";

    // in seconds
    public static final long DEFAULT_METRICS_INTERVAL = 60;

    public static final String NAME_METRICS_VAQUERO_ADDR = "omap.metrics.vaquero-addr";

    public static final String NAME_METRICS_VAQUERO_PRODUCT = "omap.metrics.vaquero-product";

    public static final String NAME_METRICS_STATISTIC_FILE_ROLLING_INTERVAL = "omap.metrics.statistic-file-rolling-interval";

    // Time in millis
    public static final int DEFAULT_METRICS_STATISTIC_FILE_ROLLING_INTERVAL = 60 * 60 * 1000;

    // default value is omap's fs name.
    public static final String NAME_METRICS_STATISTIC_FS_NAME = "omap.metrics.statistic-fs-name";

    // default value is OmapRoot/statistic
    public static final String NAME_METRICS_STATISTIC_FILE_PATH = "omap.metrics.statistic-file-path";

    public static String getMetricsStatisticPath() {
        String path = omapConf.getString(NAME_METRICS_STATISTIC_FILE_PATH);
        if (path == null) {
            path = getOmapDataRoot() + "/statistic";
        }
        return path;
    }

    public static final String NAME_METRICS_STATISTIC_WEB_PORT = "omap.metrics.statistic-web-port";

    public static final int DEFAULT_METRICS_STATISTIC_WEB_PORT = 7190;

    public static final String NAME_METRICS_STATISTIC_FILE_LIFE = "omap.metrics.statistic-file-life";

    // in days
    public static final int DEFAULT_METRICS_STATISTIC_FILE_LIFE = 7;

    public static final String NAME_ALERT_URL_TEMPLATE = "omap.alert.url-template";

    @SuppressWarnings("unchecked")
    public static List<String> getAlertUrlTemplateList() {
        return omapConf.getList(NAME_ALERT_URL_TEMPLATE);
    }

    public static final String NAME_TS_SSTABLE_INDEX_KEY_MAX_BYTE_DISTANCE = "omap.ts.sstable-index-key-max-byte-distance";

    public static final int DEFAULT_TS_SSTABLE_INDEX_KEY_MAX_BYTE_DISTANCE = FSConstants.DEFAULT_CLIENT_RANDOM_READER_BUFFER_SIZE;

    public static final String NAME_TS_SSTABLE_INDEX_KEY_MAX_RECORD_DISTANCE = "omap.ts.sstable-index-key-max-byte-distance";

    public static final int DEFAULT_TS_SSTABLE_INDEX_KEY_MAX_RECORD_DISTANCE = 100;

    public static final String NAME_RESET_FS_STREAM_INTERVAL = "omap.ts.reset-fsstream-interval";

    //in milliseconds, 0 means disable
    public static final int DEFAULT_RESET_FS_STREAM_INTERVAL = 0;

    public static final String NAME_MASTER_CATALOGUE_DATA_ROOT = "omap.master.catalogue-data-root";

    public static final String DEFAULT_MASTER_CATALOGUE_DATA_ROOT = "catalogue";

    public static Path getMasterCatalogueDataRoot() {
        return new Path(getOmapDataRoot(), omapConf.getString(
                NAME_MASTER_CATALOGUE_DATA_ROOT,
                DEFAULT_MASTER_CATALOGUE_DATA_ROOT));
    }

    public static final String NAME_MASTER_CATALOGUE_CHECKPOINT_INTERVAL = "omap.master.catalogue-checkpoint-interval";

    // in seconds
    public static final long DEFAULT_MASTER_CATALOGUE_CHECKPOINT_INTERVAL = 30L;

    public static final String NAME_MASTER_CATALOGUE_COMPACT_INTERVAL = "omap.master.catalogue-compact-interval";

    // in seconds
    public static final long DEFAULT_MASTER_CATALOGUE_COMPACT_INTERVAL = 60 * 60L;

    public static final String NAME_MASTER_CATALOGUE_FORCE_CHECKPOINT_INTERVAL = "omap.master.catalogue-checkpoint-interval";

    // in seconds
    public static final long DEFAULT_MASTER_CATALOGUE_FORCE_CHECKPOINT_INTERVAL = 60 * 60L;

    public static final String NAME_MASTER_RPC_HANDLER_COUNT = "omap.master.rpc-handler-count";

    public static final int DEFAULT_MASTER_RPC_HANDLER_COUNT = 100;

    // no default queue size, because the queue size is related to handler count
    public static final String NAME_MASTER_RPC_QUEUE_SIZE = "omap.master.rpc-queue-size";

    public static final String NAME_MASTER_RPC_MAX_CONNECTION_PER_CLIENT = "omap.master.rpc-max-conn-per-client";

    public static final int DEFAULT_MASTER_RPC_MAX_CONNECTION_PER_CLIENT = 2;

    public static final String NAME_MASTER_RPC_CLIENT_DISCONNECT_TIME = "omap.master.rpc-client-disconnect-time";

    // in milliseconds
    public static final int DEFAULT_MASTER_RPC_CLIENT_DISCONNECT_TIME = 10 * 60 * 1000;

    public static final String NAME_TS_RPC_HANDLER_COUNT = "omap.ts.rpc-handler-count";

    public static final int DEFAULT_TS_RPC_HANDLER_COUNT = 200;

    // no default queue size, because the queue size is related to handler count
    public static final String NAME_TS_RPC_QUEUE_SIZE = "omap.ts.rpc-queue-size";

    public static final String NAME_TS_RPC_MAX_CONNECTION_PER_CLIENT = "omap.ts.rpc-max-conn-per-client";

    public static final int DEFAULT_TS_RPC_MAX_CONNECTION_PER_CLIENT = 2;

    public static final String NAME_TS_RPC_CLIENT_DISCONNECT_TIME = "omap.ts.rpc-client-disconnect-time";

    // in milliseconds
    public static final int DEFAULT_TS_RPC_CLIENT_DISCONNECT_TIME = 0;

    public static final String NAME_TS_SET_FS_CONN_POOL_SIZE_INTERVAL = "omap.ts.set-fs-conn-pool-size-interval";

    // in milliseconds
    public static final long DEFAULT_TS_SET_FS_CONN_POOL_SIZE_INTERVAL = 4 * 60 * 1000;

    public static final String NAME_MAJOR_COMPACTION_DELETED_ROW_THRESHOLD = "omap.ts.major-compaction-deleted-row-threshold";

    public static final double DEFAULT_MAJOR_COMPCATION_DELETED_ROW_THRESHOLD = 0.2d;

    // acl default permission strategy
    public static final String NAME_ACL_DEFAULT_PERMISSION = "omap.acl.default-permission";

    // simulate linux file permissions
    public static final String DEFAULT_ACL_DEFAULT_PERMISSION = "rwxrw-r--";

    // acl super user
    public static final String NAME_ACL_SUPER_USER = "omap.acl.super-user";

    // acl default super user
    public static final String DEFAULT_ACL_SUPER_USER = "ndfs";

    public static final String NAME_BACKUP_ROOT_PATH = "omap.backup.root-path";

    public static final String DEFAULT_BACKUP_ROOT_PATH = "/tmp/omap-backup";

    public static final String NAME_TS_READ_BLOCK_FROM_LOCALHOST = "omap.ts.read-block-from-localhost";

    public static final boolean DEFAULT_TS_READ_BLOCK_FROM_LOCALHOST = true;

    public static final String NAME_TS_READ_BLOCK_MIN_TIMEOUT = "omap.ts.read-block-min-timeout";

    public static final long DEFAULT_TS_READ_BLOCK_MIN_TIMEOUT = 1000;

    /**
     * Print a log for every data insertion, checkpoint, compacting SS, log
     * truncation and log recovery. For debugging.
     */
    public static final boolean traceDataFlow = false;

    public static final boolean debug = true;

}
