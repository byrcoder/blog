/**
 * @(#)BlockDataReader.java, 2011-10-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.Closeable;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DFSClient;
import odis.file.SequenceFile;
import odis.io.FSDataInputStream;
import odis.io.FSInputStream;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.rpc2.ClientInfo;
import odis.rpc2.RPC;
import odis.rpc2.RpcConstants;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.IntWritable;
import outfox.omap.conf.OmapConfig;
import outfox.omap.metrics.TsGlobalMetricsEntry;
import outfox.omap.ts.SparseIndex.IndexStruct;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class BlockDataReader implements Closeable {

    private static final Logger LOG = LogFormatter.getLogger(BlockDataReader.class);

    private final int resetFsStreamInterval;

    private final long defaultReadTimeout;

    private final long minReadBlockTimeout;

    private final SSTable sstable;

    private SequenceFile.Reader dataReader;

    private SequenceFile.Reader nativeCachedDataReader;

    private FSInputStream fsInStream;

    private long currentOffset = -1;

    private long fsStreamCreateTime = 0;

    private final int openFlags;

    private final TsGlobalMetricsEntry tsGlobalMetricsEntry;

    BlockDataReader(SSTable sstable, boolean useRandomRead,
            TsGlobalMetricsEntry tsGlobalMetricsEntry) throws IOException {
        this.tsGlobalMetricsEntry = tsGlobalMetricsEntry;
        this.sstable = sstable;
        this.resetFsStreamInterval = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_RESET_FS_STREAM_INTERVAL,
                OmapConfig.DEFAULT_RESET_FS_STREAM_INTERVAL);
        this.minReadBlockTimeout = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_TS_READ_BLOCK_MIN_TIMEOUT,
                OmapConfig.DEFAULT_TS_READ_BLOCK_MIN_TIMEOUT);
        this.defaultReadTimeout = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_FS_DATANODE_BLOCK_READ_TIMEOUT,
                OmapConfig.DEFAULT_FS_DATANODE_BLOCK_READ_TIMEOUT);
        if (useRandomRead) {
            openFlags = DFSClient.IS_RANDOMREAD;
        } else {
            openFlags = 0;
        }
        fsInStream = OmapUtils.createFSInputStream(sstable.ts.dfs,
                sstable.dataFile, openFlags);
        fsInStream.setReadFromLocalHost(OmapConfig.getConfiguration().getBoolean(
                OmapConfig.NAME_TS_READ_BLOCK_FROM_LOCALHOST,
                OmapConfig.DEFAULT_TS_READ_BLOCK_FROM_LOCALHOST));
        fsStreamCreateTime = System.currentTimeMillis();
        boolean succ = false;
        FSDataInputStream dataIn;
        try {
            dataIn = new FSDataInputStream(fsInStream);
            succ = true;
        } finally {
            if (!succ) {
                OmapUtils.safeClose(fsInStream);
            }
        }

        succ = false;
        try {
            dataReader = createSequenceFileReader(sstable.ts.dfs,
                    sstable.dataFile, dataIn);
            succ = true;
        } finally {
            if (!succ) {
                OmapUtils.safeClose(dataIn);
            }
        }
    }

    private SequenceFile.Reader createSequenceFileReader(IFileSystem fs,
            Path dataPath, FSDataInputStream dataIn) throws IOException {
        currentOffset = -1;
        if (sstable.metaData.getSync() != null) {
            return new SSTableDataFileReader(fs, dataPath, dataIn,
                    SSTableDataFileHeader.getHeaderInput(), sstable.dataSize(),
                    sstable.metaData.getSync());
        } else {
            return new SequenceFile.Reader(fs, dataPath, dataIn);
        }
    }

    private boolean refreshFsStream() throws IOException {
        if (resetFsStreamInterval == 0) {
            return false;
        }
        if (System.currentTimeMillis() - fsStreamCreateTime > resetFsStreamInterval) {
            LOG.info("Hold a block stream for a long time, try to reopen it: "
                    + sstable.dataFile);
            OmapUtils.safeClose(dataReader);
            fsInStream = OmapUtils.createFSInputStream(sstable.ts.dfs,
                    sstable.dataFile, openFlags);
            fsInStream.setReadFromLocalHost(OmapConfig.getConfiguration().getBoolean(
                    OmapConfig.NAME_TS_READ_BLOCK_FROM_LOCALHOST,
                    OmapConfig.DEFAULT_TS_READ_BLOCK_FROM_LOCALHOST));
            FSDataInputStream dataIn = new FSDataInputStream(fsInStream);
            dataReader = createSequenceFileReader(sstable.ts.dfs,
                    sstable.dataFile, dataIn);
            fsStreamCreateTime = System.currentTimeMillis();
            return true;
        } else {
            return false;
        }
    }

    private long getReadTimeout() {
        ClientInfo info = RPC.getClientInfo();
        if (info == null) {
            return defaultReadTimeout;
        }
        long timeout = Long.parseLong(info.clientProps.get(RpcConstants.CLIENT_PROP_RPC_TIMEOUT));;
        if (timeout == 0 || timeout > defaultReadTimeout) {
            return defaultReadTimeout;
        } else if (timeout < minReadBlockTimeout) {
            return minReadBlockTimeout;
        } else {
            return timeout;
        }
    }

    /**
     * Read block from sequence file by index
     * 
     * @param index
     *            see {@link outfox.omap.ts.SSTable.SparseIndex.IndexStruct}
     * @param blockOriginLength
     *            the original length og block before compress
     * @param block
     *            bytes of the block
     * @return <code>0</code> if fail to read block<br/>
     *         <code>1</code> if reading from cache<br/>
     *         <code>-1</code> if reading from filesystem
     * @throws IOException
     */
    int readBlock(IndexStruct index, IntWritable blockOriginLength,
            ByteArrayWritable block) throws IOException {
        if (getDataFileCacheEnabled()) {
            if (nativeCachedDataReader == null) {
                nativeCachedDataReader = sstable.ts.sstableDataFileCache.getSequenceFileReader(
                        sstable.dataFile, sstable.dataSize());
            }
            if (nativeCachedDataReader != null) {
                try {
                    nativeCachedDataReader.seek(index.offset);
                    if (nativeCachedDataReader.next(blockOriginLength, block)) {
                        return 1;
                    }
                } catch (Throwable e) {
                    LOG.log(Level.WARNING, "Fail to read from native cache", e);
                    nativeCachedDataReader = null;
                }
            }
        } else if (nativeCachedDataReader != null) {
            OmapUtils.safeClose(nativeCachedDataReader);
            nativeCachedDataReader = null;
        }
        boolean readSucc = false;
        try {
            if (refreshFsStream() || currentOffset != index.offset) {
                if (!isUseRandomRead() && currentOffset > index.offset) {
                    LOG.log(Level.WARNING,
                            sstable
                                    + " seek backward from "
                                    + currentOffset
                                    + " to "
                                    + index.offset
                                    + " when random read is false. This may cause performance issue",
                            new Exception("Stacktrace for debug"));
                }
                long startTime = System.currentTimeMillis();
                dataReader.seek(index.offset);
                long delay = System.currentTimeMillis() - startTime;
                tsGlobalMetricsEntry.sstableSeek(delay);
            }
            if (isUseRandomRead()) { //use random read
                fsInStream.setReadLengthHint(index.size);
            }
            fsInStream.setTimeout(getReadTimeout());
            currentOffset = index.offset + index.size;
            boolean result = dataReader.next(blockOriginLength, block);
            // only set idle hint when random read.
            // for sequential read(e.g., compactSSTable), setIdleHint will 
            // close the connection to datanode. we will close it directly 
            // after we read all the data, so do not call setIdleHint.
            if (isUseRandomRead() && fsInStream != null) {
                fsInStream.setIdleHint();
            }
            readSucc = true;
            return result ? -1 : 0;
        } finally {
            if (!readSucc) {
                // if read timeout or other errors happen, we will never know
                // the actual offset, so set to -1 to force a seek when next
                // read.
                currentOffset = -1;
            }
        }
    }

    private boolean getDataFileCacheEnabled() {
        try {
            return sstable.getTableDesc().getDataFileCacheEnabled();
        } catch (Throwable e) {
            LOG.log(Level.WARNING, "Fail to fetch metadata", e);
        }
        return false;
    }

    boolean isUseRandomRead() {
        return (openFlags & DFSClient.IS_RANDOMREAD) != 0;
    }

    @Override
    public void close() throws IOException {
        OmapUtils.safeClose(dataReader);
        OmapUtils.safeClose(nativeCachedDataReader);
    }

    @Override
    public String toString() {
        return "[BlockDataReader Path= " + sstable.dataFile + " ]";
    }

}
