package outfox.omap.test.bench;

import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import outfox.omap.test.bench.WorkloadRunner.AccessType;
import outfox.omap.test.bench.WorkloadRunner.ThreadManager;
import toolbox.misc.LogFormatter;
import java.io.IOException;

/**
 *
 * @author zhangkun
 */
abstract class FlowController {
    private static Logger LOG = LogFormatter.getLogger(FlowController.class);
    protected volatile double currentThroughput; // operations per second
    protected long throughputCountPeriod = 1; // in seconds
    AtomicLong flowCounter = new AtomicLong();
    WorkloadConfig workload;
    AccessType accessType;
    protected FlowController() {}
    /**
     * Used by XML configuration.
     * @param type one of {@link AccessType} 's value
     */
    public void setAccessType(String type) {
        this.accessType = AccessType.valueOf(type);
    }
    protected FlowController(AccessType accessType) {
        this.accessType = accessType;
    }
    /**
     * Start a thread to manipulate WorkThreads using the given ThreadManager.
     */
    public Thread manipulate(ThreadManager tm) {
        ThroughputCounter tc = new ThroughputCounter(tm);
        tc.start();
        return tc;
    }
    private class ThroughputCounter extends Thread {
        final ThreadManager tm;
        ThroughputCounter(ThreadManager tm) {
            setDaemon(true);
            this.tm = tm;
        }
        @Override
        public void run() {
            try {
                while(true) {
                    Thread.sleep(throughputCountPeriod * 1000);
                    currentThroughput = ((double)flowCounter.getAndSet(0)) / throughputCountPeriod;
                    LOG.info(workload.tableName + "'s " + accessType + " throughput: " + currentThroughput);
                    throughputUpdated(tm);
                }
            } catch(Exception e){
                LOG.log(Level.WARNING, "ThroughputCounter interrupted", e);
            }
        }
    }
    /**
     * This method is called by WorkloadRunner once an read/write has
     * completed.
     * @param wr
     * @param tm
     */
    final void doneAnOperation(WorkloadRunner wr) throws IOException {
        if(workload.terminationCondition.shouldTerminateBench(wr)) {
            LOG.info(wr + " being stopped by " + workload.terminationCondition + ", also stopping bench");
            wr.stop(true);
        } else if(workload.terminationCondition.shouldTerminateWorkload(wr)) {
            LOG.info(wr + " being stopped by " + workload.terminationCondition);
            wr.stop(false);
        } else {
            flowCounter.incrementAndGet();
            workThreadRest();
        }
    }
    /**
     * This method is called by WorkloadRunner once an read/write has
     * completed. The implementer may sleep for a duration in order to
     * reduce throughput.
     * @param wr
     * @param tm
     */
    protected abstract void workThreadRest();
    /**
     * This method is called every throughput-counting period. The implementer
     * may add/reduce WorkThreads if necessary.
     * @param tm
     */
    protected abstract void throughputUpdated(ThreadManager tm);
}
