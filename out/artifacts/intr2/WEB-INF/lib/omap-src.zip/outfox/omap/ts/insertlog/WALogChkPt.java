package outfox.omap.ts.insertlog;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import odis.serialize.IWritable;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogBody;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.text.util.HexString;

/**
 * The log body of a checkpoint
 * 
 * @author zhangkun
 */
public class WALogChkPt implements WALogBody {

    /**
     * The checkpoint records [tabletId->LSN] pairs.
     */
    private LongLongHashMap checkpoint;

    public WALogChkPt() {

    }

    public WALogChkPt(LongLongHashMap checkpoint) {
        this.checkpoint = checkpoint;
    }

    /**
     * Get the backed [tabletId->LSN] map
     * 
     * @return
     */
    public LongLongHashMap getCheckpoint() {
        return checkpoint;
    }

    public void setCheckpoint(LongLongHashMap checkpoint) {
        this.checkpoint = checkpoint;
    }

    public IWritable copyFields(IWritable value) {
        WALogChkPt v = (WALogChkPt) value;
        checkpoint = new LongLongHashMap(v.checkpoint.size());
        for (LongLongHashMap.Entry entry: v.checkpoint) {
            checkpoint.put(entry.getKey(), entry.getValue(), -1);
        }
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        int size = in.readInt();
        this.checkpoint = new LongLongHashMap(size);
        for (int i = 0; i < size; i++) {
            this.checkpoint.put(in.readLong(), in.readLong(), -1);
        }

    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(checkpoint.size());
        for (LongLongHashMap.Entry entry: checkpoint) {
            out.writeLong(entry.getKey());
            out.writeLong(entry.getValue());
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        for (LongLongHashMap.Entry entry: checkpoint) {
            long xor = entry.getKey() ^ entry.getValue();
            result = prime * result + (int) (xor ^ (xor >>> 32));
        }
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        WALogChkPt v = (WALogChkPt) obj;
        if (checkpoint.size() != v.checkpoint.size()) {
            return false;
        }
        for (LongLongHashMap.Entry entry: checkpoint) {
            if (v.checkpoint.get(entry.getKey(), -1) != entry.getValue()) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        Iterator<LongLongHashMap.Entry> iter = checkpoint.iterator();
        StringBuilder sb = new StringBuilder("CHKPT: ");
        if (iter.hasNext()) {
            LongLongHashMap.Entry entry = iter.next();
            sb.append('(').append(HexString.longToPaddedHex(entry.getKey())).append(
                    "->").append(entry.getValue()).append(')');
        }
        while (iter.hasNext()) {
            LongLongHashMap.Entry entry = iter.next();
            sb.append(", (").append(HexString.longToPaddedHex(entry.getKey())).append(
                    "->").append(entry.getValue()).append(')');
        }
        return sb.toString();
    }

    @Override
    public String toStructuredString(MetadataProvider provider) {
        return toString();
    }

}
