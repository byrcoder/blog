package outfox.omap.walog;

import java.io.IOException;

public interface LogReaderHandler {
    /**
     * Handle a log body. Note the given WALogEntry is reused during the whole
     * iteration, so if you want to record the entry in your handler for future
     * use, you must make a copy of it.
     * 
     * @param entry
     * @param lsn
     */
    public void handle(WALogEntry entry) throws IOException;
    /**
     * Invoked when all entries have been read
     */
    public void done() throws IOException;
    /**
     * Invoked when reading log fails
     * @throws IOException
     */
    public void fail() throws IOException;
}
