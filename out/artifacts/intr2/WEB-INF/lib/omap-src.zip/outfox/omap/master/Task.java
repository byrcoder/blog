package outfox.omap.master;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Comparator;

import odis.serialize.IWritable;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import outfox.omap.ts.OmapTs;

/**
 * Describe a background job, returned when a ts sends heartbeats to master To
 * be inherited for each specific task type (e.g. split a tablet, migrate)
 * 
 * @author xuw, zhangduo
 */
public abstract class Task implements IWritable {

    public static final Comparator<Task> ID_COMPATATOR = new Comparator<Task>() {

        @Override
        public int compare(Task o1, Task o2) {
            return o1.taskId > o2.taskId ? 1 : o1.taskId == o2.taskId ? 0 : -1;
        }
    };

    /**
     * to be set by master
     */
    protected long taskId;

    /**
     * The reason to explain why this task has been generated, for debug use.
     */
    protected String reason;

    protected long generatedTime;

    // negative time means the task hasn't been sent to ts
    protected long sentTime = -1;

    /**
     * to be set by ts
     */
    protected long startedTime = -1;

    protected long doneTime = -1;

    /**
     * >=0 means success, <0 means failed. But the actual means is defined by
     * sub classes.
     */
    protected int returnStatus;

    public void setTaskId(long id) {
        taskId = id;
    }

    public long getTaskId() {
        return taskId;
    }

    public int getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(int status) {
        this.returnStatus = status;
    }

    public void recordStartTime() {
        startedTime = System.currentTimeMillis();
    }

    public void recordDoneTime() {
        doneTime = System.currentTimeMillis();
    }

    public void recordSentTime() {
        sentTime = System.currentTimeMillis();
    }

    public long getStartTime() {
        return startedTime;
    }

    public long getDoneTime() {
        return doneTime;
    }

    public long getSentTime() {
        return sentTime;
    }

    public long getGeneratedTime() {
        return generatedTime;
    }

    public String getReason() {
        return reason;
    }

    /**
     * Empty constructor, only for use by the default constructors of subclasses
     */
    protected Task() {}

    /**
     * @param reason
     *            The reason to explain why this task has been generated, for
     *            debug use.
     */
    protected Task(String reason) {
        generatedTime = System.currentTimeMillis();
        this.reason = reason;
    }

    /*
     * IWritable
     */

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            throw new RuntimeException("should not copy from myself");
        }
        Task t = (Task) value;
        this.taskId = t.taskId;
        this.generatedTime = t.generatedTime;
        this.sentTime = t.sentTime;
        this.startedTime = t.startedTime;
        this.doneTime = t.doneTime;
        this.returnStatus = t.returnStatus;
        this.reason = t.reason;
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        this.taskId = in.readLong();
        this.generatedTime = in.readLong();
        this.sentTime = in.readLong();
        this.startedTime = in.readLong();
        this.doneTime = in.readLong();
        this.returnStatus = in.readInt();
        this.reason = in.readUTF();
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(taskId);
        out.writeLong(generatedTime);
        out.writeLong(sentTime);
        out.writeLong(startedTime);
        out.writeLong(doneTime);
        out.writeInt(returnStatus);
        out.writeUTF(reason);
    }

    public abstract int execTask(OmapTs ts);

    /**
     * Only executed when a task is successful but failed to return to Master.
     * 
     * @param ts
     */
    public abstract void rollbackTask(OmapTs ts) throws Exception;

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Task td = (Task) obj;
        return this.taskId == td.taskId
                && this.generatedTime == td.generatedTime;
    }

    @Override
    public int hashCode() {
        return (int) this.generatedTime;
    }

    /**
     * Should be overridden by subclasses to return the task-specific details,
     * which will be displayed in {@link #toString()}
     * 
     * @return
     */
    public abstract String getTaskDetail();

    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormat.forPattern("(yy-MM-dd)HH:mm:ss");

    @Override
    public String toString() {
        StringBuilder buffer = new StringBuilder();
        buffer.append("[Task class=").append(this.getClass().getSimpleName());
        buffer.append(" id=").append(taskId);
        buffer.append(" g_time=").append(TIME_FORMATTER.print(generatedTime));
        buffer.append(" s_time=").append(
                startedTime > 0 ? TIME_FORMATTER.print(startedTime)
                        : "NOT_STARTED");
        buffer.append(" d_time=").append(
                doneTime > 0 ? TIME_FORMATTER.print(doneTime) : "NOT_DONE");
        buffer.append(" detail=\"").append(getTaskDetail());
        buffer.append("\"\nreason=\"").append(reason);
        buffer.append("\" r_status=\"").append(returnStatus);
        buffer.append("\"]");
        return buffer.toString();
    }
}
