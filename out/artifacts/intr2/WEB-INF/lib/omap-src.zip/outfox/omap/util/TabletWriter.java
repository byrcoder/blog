/**
 * @(#)TabletWriter.java, 2010-10-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.io.IOException;

import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.ts.SSTableWriter;
import outfox.omap.ts.Tablet;

/**
 * @author zhangduo
 */
public class TabletWriter {
    private long recordCount;

    private SSTableWriter writer;

    public TabletWriter(FileSystem fs, Path dir, long expectedElements,
            CompressType compressType) throws IOException {
        writer = new SSTableWriter(fs, dir.cat(Tablet.SS_PREFIX + "1"),
                expectedElements, compressType);
    }

    public void write(DataRow dr) throws IOException {
        KeyCell kc = dr.getKeyCell();
        ByteArrayWritable key = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(kc));
        ByteArrayWritable value = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(dr));
        writer.write(key, value);
        recordCount++;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public long getDataSize() throws IOException {
        return writer.getSize();
    }

    public void close() throws IOException {
        writer.close();
    }
}
