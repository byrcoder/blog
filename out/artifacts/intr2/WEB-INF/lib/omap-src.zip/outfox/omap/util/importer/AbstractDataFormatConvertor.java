/**
 * @(#)AbstractDataFormatConvertor.java, 2010-5-4. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import outfox.omap.data.DataCell;
import toolbox.misc.LogFormatter;

/**
 * This class is used for convert user defined data to omap data.<br>
 * <br>
 * By default, DataReader would try to parse user data by Omap table description. 
 * But you can extends this class and set it to DataReader, 
 * to change the default parse mothod.<br>
 * <br>
 * Convertor will be setted to individual column, 
 * and transform data from {@link odis.serialize.IWritable} to {@link outfox.omap.data.DataCell}.
 * The convertor would be passed by String, and finally be constructed by {@link AbstractDataFormatConvertor#getConvertorByClassName}
 * 
 * @author wangfk
 *
 */
public abstract class AbstractDataFormatConvertor {
    private static final Logger LOG = LogFormatter.getLogger(AbstractDataFormatConvertor.class);
    private static Map<String, AbstractDataFormatConvertor> map = 
        Collections.synchronizedMap(new HashMap<String, AbstractDataFormatConvertor>());

    /**
     * Convert data from {@link odis.serialize.IWritable} to {@link outfox.omap.data.DataCell} <br>
     * <b>This method's implementation must be thread-safe<b> 
     * @param data
     * <ul>
     * <li> For {@link SequenceFileReader}, data is fetched by 
     * {@link odis.file.SequenceFile.Reader#getKeyClass} or 
     * {@link odis.file.SequenceFile.Reader#getValueClass}</li>
     * <li> For {@link SqlDataReader}, data is type of 
     * {@link odis.serialize.lib.ByteArrayWritable}, filled by byte[] from 
     * {@link java.sql.ResultSet#getBytes}
     * </ul>
     * @param cell
     */
    public abstract void convert(IWritable data, DataCell cell);
    
    public static AbstractDataFormatConvertor getConvertorByClassName(String className) {
        AbstractDataFormatConvertor res = null;
        res = map.get(className);
        if(res != null) {
            return res;
        }
        try {
            res = (AbstractDataFormatConvertor)Class.forName(className).newInstance();
        } catch (Exception e) {
            LOG.warning("Create data convert exception: " + className);
            throw new RuntimeException(e);
        }
        map.put(className, res);
        return res;
    }
}
