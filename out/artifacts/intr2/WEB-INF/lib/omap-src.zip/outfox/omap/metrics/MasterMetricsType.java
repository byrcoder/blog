/**
 * @(#)MasterMetricsItem.java, 2011-5-31. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

/**
 * <p>
 * GLOBAL_XX means the metrics record is the global state of master. All other
 * type is for tablet.
 * </p>
 * <p>
 * XX_NUM means the metrics record is the number of XX.
 * </p>
 * <p>
 * XX_COUNT means the metrics record is the count of XX operation.
 * </p>
 * <p>
 * XX_DELAY means the metrics record is the total delay of XX operation.
 * </p>
 * <p>
 * LAST_XX means the metrics record is the record of last XX operation.
 * </p>
 * <p>
 * TIME_RANGE_XX_COUNT means the metrics record is an array with XX operation
 * count for different delay range. See {@link TimeRangeUtils}.
 * </p>
 * 
 * @author zhangduo
 */
public enum MasterMetricsType {
    GLOBAL_TABLE_NUM(0),
    GLOBAL_TABLET_NUM(GLOBAL_TABLE_NUM.offset + 1),
    
    GLOBAL_GET_FS_NAME_COUNT(GLOBAL_TABLET_NUM.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_GET_FS_NAME_DELAY(GLOBAL_GET_FS_NAME_COUNT.offset + 1),
    GLOBAL_LAST_GET_FS_NAME_DELAY(GLOBAL_GET_FS_NAME_DELAY.offset + 1),
    GLOBAL_TIME_RANGE_GET_FS_NAME_COUNT(GLOBAL_LAST_GET_FS_NAME_DELAY.offset + 1),
    
    GLOBAL_GET_TABLES_COUNT(GLOBAL_TIME_RANGE_GET_FS_NAME_COUNT.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_GET_TABLES_DELAY(GLOBAL_GET_TABLES_COUNT.offset + 1),
    GLOBAL_LAST_GET_TABLES_DELAY(GLOBAL_GET_TABLES_DELAY.offset + 1),
    GLOBAL_TIME_RANGE_GET_TABLES_COUNT(GLOBAL_LAST_GET_TABLES_DELAY.offset + 1),

    GLOBAL_GET_TABLES_IN_SPACE_COUNT(GLOBAL_TIME_RANGE_GET_TABLES_COUNT.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_GET_TABLES_IN_SPACE_DELAY(GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset + 1),
    GLOBAL_LAST_GET_TABLES_IN_SPACE_DELAY(GLOBAL_GET_TABLES_IN_SPACE_DELAY.offset + 1),
    GLOBAL_TIME_RANGE_GET_TABLES_IN_SPACE_COUNT(GLOBAL_LAST_GET_TABLES_IN_SPACE_DELAY.offset + 1),

    GLOBAL_GET_TABLESPACES_COUNT(GLOBAL_TIME_RANGE_GET_TABLES_IN_SPACE_COUNT.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_GET_TABLESPACES_DELAY(GLOBAL_GET_TABLESPACES_COUNT.offset + 1),
    GLOBAL_LAST_GET_TABLESPACES_DELAY(GLOBAL_GET_TABLESPACES_DELAY.offset + 1),
    GLOBAL_TIME_RANGE_GET_TABLESPACES_COUNT(GLOBAL_LAST_GET_TABLESPACES_DELAY.offset + 1),
    
    GLOBAL_CREATE_TABLE_COUNT(GLOBAL_TIME_RANGE_GET_TABLESPACES_COUNT.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_CREATE_TABLE_DELAY(GLOBAL_CREATE_TABLE_COUNT.offset + 1),
    GLOBAL_LAST_CREATE_TABLE_DELAY(GLOBAL_CREATE_TABLE_DELAY.offset + 1),
    GLOBAL_TIME_RANGE_CREATE_TABLE_COUNT(GLOBAL_LAST_CREATE_TABLE_DELAY.offset + 1),

    GLOBAL_DELETE_TABLE_COUNT(GLOBAL_TIME_RANGE_CREATE_TABLE_COUNT.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_DELETE_TABLE_DELAY(GLOBAL_DELETE_TABLE_COUNT.offset + 1),
    GLOBAL_LAST_DELETE_TABLE_DELAY(GLOBAL_DELETE_TABLE_DELAY.offset + 1),
    GLOBAL_TIME_RANGE_DELETE_TABLE_COUNT(GLOBAL_LAST_DELETE_TABLE_DELAY.offset + 1),
    
    GLOBAL_SYSTEM_LOAD(GLOBAL_TIME_RANGE_DELETE_TABLE_COUNT.offset + TimeRangeUtils.rangeCount()),
    GLOBAL_PROCESSOR_NUM(GLOBAL_SYSTEM_LOAD.offset + 1),
    
    GLOBAL_MEMORY_INIT(GLOBAL_PROCESSOR_NUM.offset + 1),
    GLOBAL_MEMORY_USED(GLOBAL_MEMORY_INIT.offset + 1),
    GLOBAL_MEMORY_COMMITTED(GLOBAL_MEMORY_USED.offset + 1),
    GLOBAL_MEMORY_MAX(GLOBAL_MEMORY_COMMITTED.offset + 1),
    
    GLOBAL_REQUEST_NUM(GLOBAL_MEMORY_MAX.offset + 1),
    GLOBAL_TIMEOUT_REQUEST_NUM(GLOBAL_REQUEST_NUM.offset + 1),
    
    MAX_GLOBAL_TYPE(GLOBAL_TIMEOUT_REQUEST_NUM.offset + 1),

    LOOKUP_KEY_COUNT(0),
    LOOKUP_KEY_DELAY(LOOKUP_KEY_COUNT.offset + 1),
    LAST_LOOKUP_KEY_DELAY(LOOKUP_KEY_DELAY.offset + 1),
    TIME_RANGE_LOOKUP_KEY_COUNT(LAST_LOOKUP_KEY_DELAY.offset + 1),

    RENAME_TABLE_COUNT(TIME_RANGE_LOOKUP_KEY_COUNT.offset + TimeRangeUtils.rangeCount()),
    RENAME_TABLE_DELAY(RENAME_TABLE_COUNT.offset + 1),
    LAST_RENAME_TABLE_DELAY(RENAME_TABLE_DELAY.offset + 1),
    TIME_RANGE_RENAME_TABLE_COUNT(LAST_RENAME_TABLE_DELAY.offset + 1),

    SET_TABLE_PROPERTIES_COUNT(TIME_RANGE_RENAME_TABLE_COUNT.offset + TimeRangeUtils.rangeCount()),
    SET_TABLE_PROPERTIES_DELAY(SET_TABLE_PROPERTIES_COUNT.offset + 1),
    LAST_SET_TABLE_PROPERTIES_DELAY(SET_TABLE_PROPERTIES_DELAY.offset + 1),
    TIME_RANGE_SET_TABLE_PROPERTIES_COUNT(LAST_SET_TABLE_PROPERTIES_DELAY.offset + 1),

    GET_SCHEMA_ID_COUNT(TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_SCHEMA_ID_DELAY(GET_SCHEMA_ID_COUNT.offset + 1),
    LAST_GET_SCHEMA_ID_DELAY(GET_SCHEMA_ID_DELAY.offset + 1),
    TIME_RANGE_GET_SCHEMA_ID_COUNT(LAST_GET_SCHEMA_ID_DELAY.offset + 1),

    GET_METADATA_COUNT(TIME_RANGE_GET_SCHEMA_ID_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_METADATA_DELAY(GET_METADATA_COUNT.offset + 1),
    LAST_GET_METADATA_DELAY(GET_METADATA_DELAY.offset + 1),
    TIME_RANGE_GET_METADATA_COUNT(LAST_GET_METADATA_DELAY.offset + 1),
    
    SET_READ_ONLY_COUNT(TIME_RANGE_GET_METADATA_COUNT.offset + TimeRangeUtils.rangeCount()),
    SET_READ_ONLY_DELAY(SET_READ_ONLY_COUNT.offset + 1),
    LAST_SET_READ_ONLY_DELAY(SET_READ_ONLY_DELAY.offset + 1),
    TIME_RANGE_SET_READ_ONLY_COUNT(LAST_SET_READ_ONLY_DELAY.offset + 1),
    
    MAX_TABLE_TYPE(TIME_RANGE_SET_READ_ONLY_COUNT.offset + TimeRangeUtils.rangeCount());
    
    private final int offset;

    private MasterMetricsType(int offset) {
        this.offset = offset;
    }

    public int offset() {
        return offset;
    }
    
    public static int globalTypeCount() {
        return MAX_GLOBAL_TYPE.offset;
    }
    
    public static int tableTypeCount() {
        return MAX_TABLE_TYPE.offset;
    }
}
