package outfox.omap.util;

import java.io.ByteArrayInputStream;

/**
 * A ByteArrayInputStream that can change its input buffer after created.
 * 
 * @author zhangkun
 */
public class ReusableByteArrayInputStream extends ByteArrayInputStream {
    public ReusableByteArrayInputStream() {
        super(new byte[0]);
    }

    public ReusableByteArrayInputStream(byte[] buf) {
        super(buf);
    }

    public ReusableByteArrayInputStream(byte[] buf, int offset, int length) {
        super(buf, offset, length);
    }

    public void setBuffer(byte[] buf) {
        this.buf = buf;
        this.pos = 0;
        this.mark = 0;
        this.count = buf.length;
    }

    public void setBuffer(byte[] buf, int offset, int length) {
        this.buf = buf;
        this.pos = offset;
        this.count = Math.min(offset + length, buf.length);
        this.mark = offset;
    }
}
