package outfox.omap.client.protocol;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import outfox.omap.client.ClientConfig;
import outfox.omap.client.OmapDataSource;
import outfox.omap.client.protocol.mock.MockOmapDataSource;
import outfox.omap.exceptions.OmapException;

/**
 * The DataSourceFactory is used to acquire a DataSource of Omap.
 * 
 * @author yaming
 */

public class DataSourceFactory {

    private static final ConcurrentMap<String, DataSource> NAME_TO_DS = new ConcurrentHashMap<String, DataSource>();

    public static final String NAME_OMAP_DATA_SOURCE = "OmapDataSource";

    public static final String NAME_MOCK_OMAP_DATA_SOURCE = "MockOmapDataSource";

    /**
     * Get a DataSource of Omap using the given name <br>
     * Note that, you should reuse the DataSource instance if you use
     * "OmapDataSource". OmapDataSource will create an ZooKeeper Client, which
     * need close if you do not use this DataSource any more.
     * 
     * @param dsName
     *            the name of the Omap DataSource, please use "OmapDataSource"
     *            for default.
     * @return a DataSource as a {@link outfox.omap.client.protocol.DataSource}.
     * @throws OmapException
     */
    public static DataSource getNamed(String dsName) throws OmapException {
        return getNamed(dsName, true);
    }

    private static DataSource createDataSource(String dsName)
            throws OmapException {
        try {
            if (dsName.equals(NAME_OMAP_DATA_SOURCE)) {
                return new OmapDataSource(new ClientConfig("omap.xml"));
            } else if (dsName.equals(NAME_MOCK_OMAP_DATA_SOURCE)) {
                return new MockOmapDataSource();
            } else if (dsName.startsWith("file:")) {
                return new OmapDataSource(new ClientConfig(dsName.substring(5)));
            } else {
                return (DataSource) Class.forName(dsName).newInstance();
            }
        } catch (ClassNotFoundException e) {
            throw new OmapException("create DataSource " + dsName + " failed",
                    e);
        } catch (InstantiationException e) {
            throw new OmapException("create DataSource " + dsName + " failed",
                    e);
        } catch (IllegalAccessException e) {
            throw new OmapException("create DataSource " + dsName + " failed",
                    e);
        } catch (IOException e) {
            throw new OmapException("create DataSource " + dsName + " failed",
                    e);
        }
    }

    /**
     * Get a DataSource of Omap using the given name <br>
     * Notice that, you should reuse the DataSource instance if you use
     * <code>DataSourceFactory.NAME_OMAP_DATA_SOURCE</code>. OmapDataSource will
     * create an ZooKeeper Client, which need close if you do not use this
     * DataSource any more.<br>
     * since 1.4, you can set dsName as file:xxx, which xxx is your config file
     * name instead of "omap.xml".This means you can use different config in
     * your project.
     * 
     * @param dsName
     *            the name of the Omap DataSource.<br>
     * @param reuse
     *            reuse DataSource instance
     * @return a DataSource as a {@link outfox.omap.client.protocol.DataSource}.
     * @throws OmapException
     * @throws OmapException
     */
    public static DataSource getNamed(String dsName, boolean reuse)
            throws OmapException {
        if (!reuse) {
            return createDataSource(dsName);
        }
        DataSource ds = NAME_TO_DS.get(dsName);
        if (ds == null || !ds.retain()) {
            synchronized (NAME_OMAP_DATA_SOURCE) {
                ds = NAME_TO_DS.get(dsName);
                if (ds == null || !ds.retain()) {
                    ds = createDataSource(dsName);
                    NAME_TO_DS.put(dsName, ds);
                }
            }
        }
        return ds;
    }

    public DataSource get(String dsName) throws OmapException {
        return get(dsName, true);
    }

    public DataSource get(String dsName, boolean reuse) throws OmapException {
        return getNamed(dsName, reuse);
    }
}
