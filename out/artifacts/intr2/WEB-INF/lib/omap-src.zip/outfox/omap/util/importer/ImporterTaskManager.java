/**
 * @(#)ImporterTaskManager.java, 2010-3-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import outfox.omap.exceptions.BadSchemaDefinitionException;
import toolbox.misc.LogFormatter;

/**
 * Create tasks by XML file, and run tasks in multi-thread mode.<br>
 * The XML file format description see 
 * <a href="https://dev.corp.youdao.com/outfoxwiki/ODIS/OMap/Docs/DataImporter">
 * https://dev.corp.youdao.com/outfoxwiki/ODIS/OMap/Docs/DataImporter</a>
 * <p>
 * The program entry of the importer. 
 * <p>
 * The program can be run by command: "./odis omapimport &lt;XML_FILE_PATH&gt;"
 * @author wangfk
 *
 */
public class ImporterTaskManager {
    private static final Logger LOG = 
        LogFormatter.getLogger(ImporterTaskManager.class);

    public final String THREADPOOL_NAME = "IMPORTER_TASK_POOL";
    
    private List<Runnable> taskList;
    private String masterAddr;
    
    
    
    /**
     * Private Construct, Object can only be created by {@link #instanceByXMLFile}
     * 
     * @param xmlFilePath
     */
    private ImporterTaskManager(String xmlFilePath) {
        taskList = new LinkedList<Runnable>();
        parseTaskProfile(xmlFilePath);
    }

    private void parseTaskProfile(String xmlFilePath) {
        File xmlFile = new File(xmlFilePath);
        SAXReader reader = new SAXReader();
        
        try {
            Document doc = reader.read(xmlFile);
            Element rootElement = doc.getRootElement();
            if(!rootElement.getName().equals("root")) {
                throw new BadSchemaDefinitionException(
                        "The profile should use 'root' element as root.");
            }
            Element masteraddrElement = rootElement.element("masteraddr");
            if(masteraddrElement == null) {
                throw new BadSchemaDefinitionException (
                        "Less element of 'masteraddr'");
            }
            masterAddr = masteraddrElement.getStringValue();
            LOG.info("Master addr: " + masterAddr);
            
            Element tasksElement = rootElement.element("tasks");
            List<?> taskElementList = tasksElement.elements("task");
            
            if(taskElementList != null) {
                for(Object e : taskElementList) {
                    Runnable task = createTask((Element) e);
                    if(task != null) {
                        taskList.add(task);
                    }
                }
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }
    
    private Runnable createTask(Element taskElem) {

        Attribute attrType = taskElem.attribute("type");
        if(attrType == null) {
            throw new BadSchemaDefinitionException (
                "Type attribute is necessary to task.");
        }
        String taskType = getAttribute(taskElem, "type", true);
        AbstractImporterTask task = null;
        if(taskType.equalsIgnoreCase("mergesort")) {
            task = new MergeSortTask();            
        }
//        else if(...){
//            
//        }
        else {
            throw new BadSchemaDefinitionException (
                "Unknown task type: " + taskType);
        }

        task.setMasterAddr(masterAddr);
        task.setTableName(getAttribute(taskElem, "tablename", true));
        task.setTableSpace(getAttribute(taskElem, "tablespace", true));
        task.setColNames(getAttribute(taskElem, "colnames", true));
        task.setColTypes(getAttribute(taskElem, "coltypes", true));
        task.setSstableNumber(getAttribute(taskElem, "sstablenumber", false));
        task.setDataDistrib(getAttribute(taskElem, "datadistrib", false));
        task.setCompressType(getAttribute(taskElem, "compress", false));
        LOG.info("Compress type: " + getAttribute(taskElem, "compress", false));
        
        List<?> readerElems = taskElem.elements("reader");
        for(Object e : readerElems) {
            IDataReader reader = createDataReader((Element)e);
            task.addDataReader(reader);
        }        
        return task;
    }
    
    private String getAttribute(Element e, String attrName, boolean exceptionNotFound) {
        Attribute attr = e.attribute(attrName);
        if(attr == null ) {
            if(exceptionNotFound) {
                throw new BadSchemaDefinitionException (
                        attrName + " attribute is necessary to " + e.getName());
            }
            return "";
        }
        return attr.getValue();
    }
    
    private IDataReader createDataReader(Element readerElem) {
        String readerType = getAttribute(readerElem, "type", true);
        LOG.info("data reader type string: " + readerType);
        IDataReader dataReader = DataReaderFactory.createDataReader(readerType);
        
        List<?> propertyElems = readerElem.elements("property");
        Properties properties = new Properties();
        for(Object e : propertyElems) {
            String name = getAttribute((Element)e, "name", true).toLowerCase();
            String value = ((Element)e).getStringValue();
            if(name.startsWith("convertor.")) {
                int columnIndex = Integer.parseInt(name.substring("convertor.".length()));
                AbstractDataFormatConvertor convertor = 
                    AbstractDataFormatConvertor.getConvertorByClassName(value);
                dataReader.setDataConvertor(columnIndex, convertor);
            }else {
                properties.put(name, value);
            }
        }
        
        dataReader.setProperties(properties);
        
        return dataReader;
    }
    
    /**
     * Call this method for executing all tasks asynchronously
     */
    public void runAllTask() {

        for(Runnable task : taskList) {
            new Thread(task).start();
        }
        return;

    }
    
    public static ImporterTaskManager instanceByXMLFile(String xmlFilePath) {
        return new ImporterTaskManager(xmlFilePath);
    }
    
    /**
     * Usage: ./odis import &lt;XML_FILE_PATH&gt
     * @param args
     */
    public static void main(String[] args) {
        
        if(args.length != 1) {
            System.err
            .println("Usage: ./odis import <XML_FILE_PATH>"); 
        }
        ImporterTaskManager taskManager = ImporterTaskManager.instanceByXMLFile(args[0]);
        taskManager.runAllTask();
    }
}
