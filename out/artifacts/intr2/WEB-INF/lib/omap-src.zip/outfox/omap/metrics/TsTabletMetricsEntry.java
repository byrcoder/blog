/**
 * @(#)TsTabletMetricsEntry.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class TsTabletMetricsEntry implements IWritable {

    private final long[] metricsRecords = new long[TsMetricsType.tabletTypeCount()];

    public synchronized void contains(long delay) {
        metricsRecords[TsMetricsType.CONTAINS_COUNT.offset()]++;
        metricsRecords[TsMetricsType.CONTAINS_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_CONTAINS_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_CONTAINS_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void multiContains(int rows, long delay) {
        metricsRecords[TsMetricsType.MULTI_CONTAINS_COUNT.offset()]++;
        metricsRecords[TsMetricsType.MULTI_CONTAINS_ROWS.offset()] += rows;
        metricsRecords[TsMetricsType.MULTI_CONTAINS_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_MULTI_CONTAINS_ROWS.offset()] = rows;
        metricsRecords[TsMetricsType.LAST_MULTI_CONTAINS_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_CONTAINS_COUNT.offset()
                + rangeOffset]++;

        long delayPerRow = rows > 0 ? delay / rows : delay;
        rangeOffset = TimeRangeUtils.getRangeOffset(delayPerRow);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_CONTAINS_PER_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void keyFind(int size, long delay) {
        metricsRecords[TsMetricsType.KEY_FIND_COUNT.offset()]++;
        metricsRecords[TsMetricsType.KEY_FIND_SIZE.offset()] += size;
        metricsRecords[TsMetricsType.KEY_FIND_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_KEY_FIND_SIZE.offset()] = size;
        metricsRecords[TsMetricsType.LAST_KEY_FIND_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_KEY_FIND_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void multiKeyFind(int rows, int size, long delay) {
        metricsRecords[TsMetricsType.MULTI_KEY_FIND_COUNT.offset()]++;
        metricsRecords[TsMetricsType.MULTI_KEY_FIND_ROWS.offset()] += rows;
        metricsRecords[TsMetricsType.MULTI_KEY_FIND_SIZE.offset()] += size;
        metricsRecords[TsMetricsType.MULTI_KEY_FIND_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_MULTI_KEY_FIND_ROWS.offset()] = rows;
        metricsRecords[TsMetricsType.LAST_MULTI_KEY_FIND_SIZE.offset()] = size;
        metricsRecords[TsMetricsType.LAST_MULTI_KEY_FIND_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_KEY_FIND_COUNT.offset()
                + rangeOffset]++;

        long delayPerRow = rows > 0 ? delay / rows : delay;
        rangeOffset = TimeRangeUtils.getRangeOffset(delayPerRow);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_KEY_FIND_PER_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void rangeKeyFind(int rows, int size, long delay) {
        metricsRecords[TsMetricsType.RANGE_KEY_FIND_COUNT.offset()]++;
        metricsRecords[TsMetricsType.RANGE_KEY_FIND_ROWS.offset()] += rows;
        metricsRecords[TsMetricsType.RANGE_KEY_FIND_SIZE.offset()] += size;
        metricsRecords[TsMetricsType.RANGE_KEY_FIND_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_RANGE_KEY_FIND_ROWS.offset()] = rows;
        metricsRecords[TsMetricsType.LAST_RANGE_KEY_FIND_SIZE.offset()] = size;
        metricsRecords[TsMetricsType.LAST_RANGE_KEY_FIND_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_RANGE_KEY_FIND_COUNT.offset()
                + rangeOffset]++;

        long delayPerRow = rows > 0 ? delay / rows : delay;
        rangeOffset = TimeRangeUtils.getRangeOffset(delayPerRow);
        metricsRecords[TsMetricsType.TIME_RANGE_RANGE_KEY_FIND_PER_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void insert(int size, long delay) {
        metricsRecords[TsMetricsType.INSERT_COUNT.offset()]++;
        metricsRecords[TsMetricsType.INSERT_SIZE.offset()] += size;
        metricsRecords[TsMetricsType.INSERT_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_INSERT_SIZE.offset()] = size;
        metricsRecords[TsMetricsType.LAST_INSERT_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_INSERT_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void multiInsert(int rows, int size, long delay) {
        metricsRecords[TsMetricsType.MULTI_INSERT_COUNT.offset()]++;
        metricsRecords[TsMetricsType.MULTI_INSERT_ROWS.offset()] += rows;
        metricsRecords[TsMetricsType.MULTI_INSERT_SIZE.offset()] += size;
        metricsRecords[TsMetricsType.MULTI_INSERT_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_MULTI_INSERT_ROWS.offset()] = rows;
        metricsRecords[TsMetricsType.LAST_MULTI_INSERT_SIZE.offset()] = size;
        metricsRecords[TsMetricsType.LAST_MULTI_INSERT_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_INSERT_COUNT.offset()
                + rangeOffset]++;

        long delayPerRow = rows > 0 ? delay / rows : delay;
        rangeOffset = TimeRangeUtils.getRangeOffset(delayPerRow);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_INSERT_PER_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void delete(long delay) {
        metricsRecords[TsMetricsType.DELETE_COUNT.offset()]++;
        metricsRecords[TsMetricsType.DELETE_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_DELETE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_DELETE_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void multiDelete(int rows, long delay) {
        metricsRecords[TsMetricsType.MULTI_DELETE_COUNT.offset()]++;
        metricsRecords[TsMetricsType.MULTI_DELETE_ROWS.offset()] += rows;
        metricsRecords[TsMetricsType.MULTI_DELETE_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_MULTI_DELETE_ROWS.offset()] = rows;
        metricsRecords[TsMetricsType.LAST_MULTI_DELETE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_DELETE_COUNT.offset()
                + rangeOffset]++;

        long delayPerRow = rows > 0 ? delay / rows : delay;
        rangeOffset = TimeRangeUtils.getRangeOffset(delayPerRow);
        metricsRecords[TsMetricsType.TIME_RANGE_MULTI_DELETE_PER_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void rangeDelete(int rows, long delay) {
        metricsRecords[TsMetricsType.RANGE_DELETE_COUNT.offset()]++;
        metricsRecords[TsMetricsType.RANGE_DELETE_ROWS.offset()] += rows;
        metricsRecords[TsMetricsType.RANGE_DELETE_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_RANGE_DELETE_ROWS.offset()] = rows;
        metricsRecords[TsMetricsType.LAST_RANGE_DELETE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_RANGE_DELETE_COUNT.offset()
                + rangeOffset]++;

        long delayPerRow = rows > 0 ? delay / rows : delay;
        rangeOffset = TimeRangeUtils.getRangeOffset(delayPerRow);
        metricsRecords[TsMetricsType.TIME_RANGE_RANGE_DELETE_PER_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void compareAndSet(long delay) {
        metricsRecords[TsMetricsType.COMPARE_AND_SET_COUNT.offset()]++;
        metricsRecords[TsMetricsType.COMPARE_AND_SET_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_COMPARE_AND_SET_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_COMPARE_AND_SET_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void lockRow(long delay) {
        metricsRecords[TsMetricsType.LOCK_ROW_COUNT.offset()]++;
        metricsRecords[TsMetricsType.LOCK_ROW_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_LOCK_ROW_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_LOCK_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void unlockRow(long delay) {
        metricsRecords[TsMetricsType.UNLOCK_ROW_COUNT.offset()]++;
        metricsRecords[TsMetricsType.UNLOCK_ROW_DELAY.offset()] += delay;

        metricsRecords[TsMetricsType.LAST_UNLOCK_ROW_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[TsMetricsType.TIME_RANGE_UNLOCK_ROW_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void copyToAndClear(TsTabletMetricsEntry entry) {
        entry.copyFields(this);
        Arrays.fill(metricsRecords, 0L);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        TsTabletMetricsEntry that = (TsTabletMetricsEntry) value;
        System.arraycopy(that.metricsRecords, 0, metricsRecords, 0,
                metricsRecords.length);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        for (long metricsRecord: metricsRecords) {
            out.writeLong(metricsRecord);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        for (int i = 0; i < metricsRecords.length; i++) {
            metricsRecords[i] = in.readLong();
        }
    }

    public long[] getMetricsRecords() {
        return metricsRecords;
    }

}
