/**
 * @(#)BackupTableTask.java, 2011-8-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.backup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.io.IFileSystem.PathFilter;
import odis.rpc2.RpcException;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapDataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.AlertUtils;
import toolbox.misc.LogFormatter;

/**
 * @author wangfk
 */
public class TableBackupTask implements Runnable {
    private static final Logger LOG = LogFormatter.getLogger(TableBackupTask.class);

    private static final long MAX_SNAPSHOT_EXEC_TIME_IN_MILLI = 60L * 1000;

    private static final long MIN_BACKUP_PERIOD_IN_MILLI = 2L * 24 * 3600 * 1000;

    private static final long MIN_BACKUP_SECURE_PERIOD_IN_MILLI = 1L * 24 * 3600 * 1000;

    private static final long BACKUP_DATA_CHECK_PERIOD = Math.min(
            MIN_BACKUP_PERIOD_IN_MILLI, MIN_BACKUP_SECURE_PERIOD_IN_MILLI) / 500;

    String tableName;

    long backupPeriodInMilli;

    long backupSecurePeriodInMilli;

    IFileSystem fs;

    Path tableBackupPath;

    MasterWatcherAndClientConfig masterWatcher;

    Path snapshotPath;

    Path walogPath;

    public TableBackupTask(IFileSystem fs, String tableName, String backupPath,
            long backupPeriodInMilli, long backupSecurePeriodInMilli)
            throws OmapException {
        this.fs = fs;
        this.tableName = tableName;
        if (backupPeriodInMilli < MIN_BACKUP_PERIOD_IN_MILLI) {
            LOG.warning("The backup period should not be shorter than "
                    + MIN_BACKUP_PERIOD_IN_MILLI + " ms, change it to "
                    + MIN_BACKUP_PERIOD_IN_MILLI);
        }
        this.backupPeriodInMilli = Math.max(backupPeriodInMilli,
                MIN_BACKUP_PERIOD_IN_MILLI);

        if (backupSecurePeriodInMilli < MIN_BACKUP_SECURE_PERIOD_IN_MILLI) {
            LOG.warning("The backup secure period should not be shorter than "
                    + MIN_BACKUP_SECURE_PERIOD_IN_MILLI + " ms, change it to "
                    + MIN_BACKUP_SECURE_PERIOD_IN_MILLI);
        }
        this.backupSecurePeriodInMilli = Math.max(backupSecurePeriodInMilli,
                MIN_BACKUP_SECURE_PERIOD_IN_MILLI);

        this.tableBackupPath = new Path(backupPath).cat(tableName);
        this.walogPath = tableBackupPath.cat(TableBackupConstant.WALogPath);
        this.snapshotPath = tableBackupPath.cat(TableBackupConstant.SnapshotPath);

        OmapDataSource datasource = (OmapDataSource) DataSourceFactory.getNamed("OmapDataSource");
        masterWatcher = datasource.getMasterWatcher();
    }

    @Override
    public void run() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    createNewBackup();
                } catch (Exception e) {
                    AlertUtils.alert(
                            "Backup: fail to create snapshot of table: "
                                    + tableName, e.getMessage(), true, true);
                }
            }
        }, 0, backupPeriodInMilli);
        while (true) {
            try {
                Thread.sleep(BACKUP_DATA_CHECK_PERIOD);
            } catch (InterruptedException e) {
                LOG.warning("Thread interrupted, exit.");
                break;
            }
            try {
                cleanOldData();
            } catch (Exception e) {
                AlertUtils.alert("Backup: fail to clean old data of table: "
                        + tableName, e.toString(), true, true);
            }
        }
        timer.cancel();
    }

    private void createNewBackup() throws RpcException, IOException {
        Path currentSnapshot = snapshotPath.cat(
                Long.toString(System.currentTimeMillis()));
        masterWatcher.getMaster().reserveTableWALog(tableName,
                walogPath.toString());
        masterWatcher.getMaster().snapshot(tableName,
                currentSnapshot.toString(), true);
    }

    private void cleanOldData() throws IOException {
        long currentTimeMillis = System.currentTimeMillis();
        FileInfo[] listFiles = null;
        listFiles = fs.listFiles(snapshotPath, new PathFilter() {
            private final Pattern fileNamePattern = Pattern.compile("\\d+");

            @Override
            public boolean accept(Path path) {
                return fileNamePattern.matcher(path.getName()).matches();
            }
        });
        ArrayList<Path> pathes = new ArrayList<Path>();
        for (FileInfo fi: listFiles) {
            if (fi.isDir()) {
                pathes.add(fi.getPath());
            }
        }
        if (pathes == null || pathes.size() <= 1) {
            return;
        }

        Collections.sort(pathes, new Comparator<Path>() {

            @Override
            public int compare(Path o1, Path o2) {
                Long ts1 = Long.parseLong(o1.getName());
                Long ts2 = Long.parseLong(o2.getName());
                return -1 * ts1.compareTo(ts2);
            }
        });

        int index = 0;
        long lastTimestamp = 0;
        for (index = 0; index != pathes.size(); ++index) {
            Path p = pathes.get(index);
            long ts = Long.parseLong(p.getName());
            if (ts < currentTimeMillis - backupSecurePeriodInMilli) {
                lastTimestamp = ts - MAX_SNAPSHOT_EXEC_TIME_IN_MILLI;
                break;
            }
        }
        for (int i = index + 1; i < pathes.size(); ++i) {
            Path p = pathes.get(i);
            LOG.info("Remove old backup file[snapshot]: " + p);
            fs.delete(p);
        }
        removeWALogFile(lastTimestamp);
    }

    private static final Pattern WALOG_PATTERN =
        Pattern.compile(TableBackupConstant.WALogFilePattern);

    private void removeWALogFile(long timestamp) throws IOException {
        if (!fs.exists(walogPath)) {
            return;
        }
        List<Path> recursiveListAllFiles = BackupUtils.recursiveListAllFiles(
                fs, walogPath, false);

        for (Path p: recursiveListAllFiles) {
            String fileName = p.getName();
            if (!WALOG_PATTERN.matcher(fileName).matches()) {
                LOG.warning("Unknown file: " + p);
                continue;
            }
            long currTimestamp = Long.parseLong(fileName.split("-")[1]);
            if (currTimestamp < timestamp) {
                LOG.info("Remove old backup file[WALog]: " + p);
                fs.delete(p);
                Path parent = p.getParentFile();
                if(fs.getLengthRecursive(parent) == 0L) {
                    fs.delete(parent);
                }
            }
        }
    }

    public static void main(String args[]) {
        System.err.println(
                WALOG_PATTERN.matcher("wal_10583581-1313656159365").matches());
    }
}
