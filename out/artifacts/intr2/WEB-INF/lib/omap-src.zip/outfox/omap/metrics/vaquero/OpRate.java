/**
 * @(#)OpRate.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public class OpRate extends Updater {

    private final double normalizer;

    private final int metricsOpIndex;

    private double rate;

    public OpRate(String vaqueroPropName, int metricsOpIndex) {
        this(vaqueroPropName, metricsOpIndex, 0.001);
    }

    public OpRate(String vaqueroPropName, int metricsOpIndex, double normalizer) {
        super(vaqueroPropName);
        this.metricsOpIndex = metricsOpIndex;
        this.normalizer = normalizer;
    }

    @Override
    public double getValue() {
        return rate;
    }

    @Override
    public void update(long[] metricsRecords, long prevTime, long currentTime) {
        long numOps = metricsRecords[metricsOpIndex];
        rate = (double) numOps / (currentTime - prevTime) / normalizer;
    }

}
