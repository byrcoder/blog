/**
 * @(#)FixSSTableMetaTool.java, 2011-8-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.Path;
import outfox.omap.ts.SSTable;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class FixSSTableMetaTool {

    private static final Logger LOG = LogFormatter.getLogger(FixSSTableMetaTool.class);

    private FileSystem fs;

    private Path tabletDir;

    public void fix() throws IOException, InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(50);
        for (Path tableDir: fs.listPaths(tabletDir)) {
            for (Path prefixDir: fs.listPaths(tableDir)) {
                for (final Path path: fs.listPaths(prefixDir)) {
                    pool.submit(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                for (Path sstablePath: fs.listPaths(path)) {
                                    Path metaPath = sstablePath.cat(SSTable.METADATA_FILE_NAME);
                                    if (fs.exists(metaPath)) {
                                        try {
                                            Properties properties = new Properties();
                                            FSDataInputStream in = fs.open(metaPath);
                                            try {
                                                properties.load(in);
                                            } finally {
                                                OmapUtils.safeClose(in);
                                            }
                                            if (properties.getProperty(SSTable.MetaData.NAME_DATA_FILE_SYNC) == null) {
                                                SequenceFile.Reader reader = new SequenceFile.Reader(
                                                        fs,
                                                        sstablePath.cat(SSTable.DATA_FILE_NAME));
                                                try {
                                                    properties.setProperty(
                                                            SSTable.MetaData.NAME_DATA_FILE_SYNC,
                                                            HexString.bytesToHexNoSpace(reader.getSync()));
                                                } finally {
                                                    OmapUtils.safeClose(reader);
                                                }
                                                FSDataOutputStream out = fs.create(sstablePath.cat("meta.tmp"));
                                                try {
                                                    properties.store(out, null);
                                                } finally {
                                                    OmapUtils.safeClose(out);
                                                }
                                                fs.rename(
                                                        sstablePath.cat("meta.tmp"),
                                                        sstablePath.cat(SSTable.METADATA_FILE_NAME));
                                                LOG.info("add data file sync "
                                                        + HexString.bytesToHexNoSpace(reader.getSync())
                                                        + " to " + metaPath);
                                            }
                                        } catch (Exception e) {
                                            LOG.log(Level.WARNING,
                                                    "fix meta for "
                                                            + sstablePath
                                                            + " failed", e);
                                        }
                                    }
                                }
                            } catch (IOException e) {
                                LOG.log(Level.WARNING, "fix meta for " + path
                                        + " failed", e);
                            }

                        }
                    });
                }
            }
        }
        pool.shutdown();
        while (!pool.awaitTermination(1, TimeUnit.HOURS));
    }

    public static void main(String[] args) throws IOException,
            InterruptedException {
        FixSSTableMetaTool t = new FixSSTableMetaTool();
        t.fs = FileSystem.getNamed("nb420:7080");
        t.tabletDir = new Path("/omap-1.4/ts/tablets");
        t.fix();
    }
}
