/**
 * @(#)PrintUtils.java, 2010-11-15. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import outfox.omap.common.TsDesc;
import toolbox.text.util.HexString;

/**
 * @author wangfk
 */
public class PrintUtils {

    private static final long KB = 1024;

    private static final long MB = 1024 * KB;

    private static final long GB = 1024 * MB;

    private static final long TB = 1024 * GB;

    private static final long PB = 1024 * TB;

    public static String formatSize(double size) {
        return formatSize((long) size);
    }

    public static String formatSize(long size) {
        if (size < KB) {
            return size + "B";
        } else if (size < MB) {
            return String.format("%.2f%s", (double) size / KB, "KB");
        } else if (size < GB) {
            return String.format("%.2f%s", (double) size / MB, "MB");
        } else if (size < TB) {
            return String.format("%.2f%s", (double) size / GB, "GB");
        } else if (size < PB) {
            return String.format("%.2f%s", (double) size / TB, "TB");
        } else {
            return String.format("%.2f%s", (double) size / PB, "PB");
        }
    }

    public static String getMBSize(long size) {
        return String.format("%.2f%s", (double) size / MB, "MB");
    }

    public static String formatTime(long timeInMilli) {
        return (timeInMilli / 3600 / 1000) + "h "
                + (timeInMilli / 1000 / 60 % 60) + "m "
                + (timeInMilli / 1000 % 60) + "s";
    }

    public static String countPerSecond(long count, long timeInMilli) {
        double second = (double) timeInMilli / 1000.0;
        if (second == 0.0) {
            ++second;
        }
        return String.format("%.2f", count / second);
    }

    public static boolean isNull(Object obj) {
        return obj == null;
    }

    public static boolean not(boolean value) {
        return !value;
    }

    public static String long2Hex(Object value) {
        if (Long.class.isInstance(value) || long.class.isInstance(value)) {
            return HexString.longToPaddedHex((Long) value);
        }
        return value.toString();
    }

    private static final DateTimeFormatter TS_TIMESTAMP_FORMATTER = DateTimeFormat.forPattern("yyMMdd.HHmmss");

    public static String printTsDesc(TsDesc tsDesc) {
        if (tsDesc.isDummyTs()) {
            return "DUMMY";
        }
        return tsDesc.getHost() + ":" + tsDesc.getPort() + "@"
                + TS_TIMESTAMP_FORMATTER.print(tsDesc.getTimestamp());
    }
}
