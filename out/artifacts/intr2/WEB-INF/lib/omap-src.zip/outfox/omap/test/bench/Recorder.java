/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Date;

import odis.io.FileSystem;
import odis.io.Path;
import outfox.omap.test.bench.WorkloadRunner.AccessType;

/**
 *
 * @author zhangkun
 */
public class Recorder {
    private Writer log;
    private Writer readMissRecorder;
    private final long startTime;
    private long readCount;
    private long writeCount;
    private long missCount;
    private long writeErrorCount;
    private long readErrorCount;
    private FileSystem fs;
    private Path outputDir;
    public static enum ResultType {
        OTHER, READ_HIT, READ_MISS, ERROR
    }
    public Recorder(FileSystem fs, Path outputDir, WorkloadConfig workload) throws IOException {
        this.fs = fs;
        this.outputDir = outputDir;
        fs.mkdirs(outputDir);
        // record configurations
        Writer out = new OutputStreamWriter(fs.create(new Path(outputDir, "env")), "UTF-8");
        out.write(workload.master.dumpServiceConfigurations());
        out.write("Workload: " + workload + "\n");
        out.close();
        // open operation log file
        log = new OutputStreamWriter(fs.create(new Path(outputDir, "log")), "UTF-8");
        readMissRecorder = new OutputStreamWriter(fs.create(new Path(outputDir, "readmiss")), "UTF-8");
        startTime = System.currentTimeMillis();
        log.write("#if use cursor to read, a few miss may be acceptable: " +
        		"check the missed key from \"readmiss\" file, " +
        		"it is expected that the missed key is in the last 20 rows of the table.");
        log.write("#timeStamp type delay status\n");
        readMissRecorder.write("#timeStamp read-miss-key\n");
    }
    public void close() throws IOException {
        // write statistical data
        Writer out = new OutputStreamWriter(fs.create(new Path(outputDir, "stats")), "UTF-8");
        long elapsedTime = System.currentTimeMillis() - startTime;
        out.write("Elapsed time: " + elapsedTime + "ms\n");
        out.write("Read count: " + readCount + "\n");
        out.write("Read miss count: " + missCount + "\n");
        out.write("Read error count: " + readErrorCount + "\n");
        out.write("Read throughput: " + (readCount / (elapsedTime / 1000.0)) + " per second\n");
        out.write("Write count: " + writeCount + "\n");
        out.write("Write error count: " + writeErrorCount + "\n");
        out.write("Write throughput: " + (writeCount / (elapsedTime / 1000.0)) + " per second\n");
        out.close();
        log.close();
        readMissRecorder.close();
    }
    public synchronized void record(AccessType type, ResultType resultType, long elapsedTime) throws IOException {
        long currentTime = System.currentTimeMillis();
        long timeStamp = currentTime - startTime;
        String typeString = " ? ";
        String resultString = "";
        switch(type) {
            case READ:
                readCount ++;
                typeString = " R ";
                break;
            case WRITE:
                writeCount ++;
                typeString = " W ";
                break;
        }
        switch(resultType) {
            case READ_MISS:
                missCount ++;
                resultString = " MISS";
                break;
            case ERROR:
                switch(type) {
                    case READ:
                        readErrorCount ++;
                        break;
                    case WRITE:
                        writeErrorCount ++;
                        break;
                }
                resultString = " ERROR";
                break;
        }
        log.write(timeStamp + typeString + elapsedTime + resultString + "\n");
    }
    
    public synchronized void recordReadMiss(String key) throws IOException {
        Date date = new Date(System.currentTimeMillis());
        readMissRecorder.write(date.toString() + " : " + key + "\n");
        readMissRecorder.flush();
    }
}
