/**
 * @(#)SSTableDataFileReader.java, 2011-8-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;

import odis.file.SequenceFile.Reader;
import odis.io.FSDataInputStream;
import odis.io.IFileSystem;
import odis.io.Path;

/**
 * Construct a SequenceFile.Reader using in memory InputStream and the given
 * sync.
 * 
 * @author zhangduo
 */
public class SSTableDataFileReader extends Reader {
    public SSTableDataFileReader(IFileSystem fs, Path file,
            FSDataInputStream in, FSDataInputStream headerIn, long length,
            byte[] sync) throws IOException {
        super();
        this.file = file;
        this.in = headerIn;
        this.start = headerIn.getPos();
        init();
        this.fs = fs;
        this.in = in;
        this.start = in.getPos();
        this.fileEnd = in.getPos() + length;
        this.end = this.fileEnd;
        this.sync = sync;
    }
}
