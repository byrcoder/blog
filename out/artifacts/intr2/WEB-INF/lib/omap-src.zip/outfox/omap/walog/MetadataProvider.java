/**
 * @(#)MetadataProvider.java, 2011-1-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.walog;

import outfox.omap.client.OmapMetadata;

/**
 *
 * @author zhangduo
 *
 */
public interface MetadataProvider {
    OmapMetadata get(long schemaId);
}
