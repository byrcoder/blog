/**
 * @(#)XMLBenchMaker.java, Jun 18, 2010. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.test.bench;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Construct a bench configuration from a bean-style XML file
 * @author zhangkun
 *
 */
public class XMLBenchMaker {
    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        if(args.length < 1) {
            System.err.println("Usage: XMLBenchMaker <benchConfig.xml>");
            System.exit(1);
        }
        String configFile = args[0];
        ApplicationContext context = new FileSystemXmlApplicationContext(configFile);
        OmapBench bench = (OmapBench) context.getBean("bench");
        bench.start();
        bench.join();
    }

}
