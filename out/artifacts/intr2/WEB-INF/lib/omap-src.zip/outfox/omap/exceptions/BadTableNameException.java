package outfox.omap.exceptions;

public class BadTableNameException extends RuntimeException {
    private static final long serialVersionUID = 800984256658848656L;

    public BadTableNameException(String msg) {
        super(msg);
    }
}
