/**
 * @(#)BloomFilterPool.java, 2009-5-9. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FSDataInputStream;
import odis.io.IFileSystem;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferPool;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.bloom.HashFunction;

/**
 * a pool to limit the total size for bloomfilter
 * 
 * @author zhangduo, wangfk
 */
public class BloomFilterPool {
    private static final Logger LOG = LogFormatter.getLogger(BloomFilterPool.class);

    final NativeRamBufferPool bufferPool;

    final LRUMap<String, NativeRamBloomFilter> pool = new LRUMap<String, NativeRamBloomFilter>(
            16, 0.75f);

    private final IFileSystem fs;

    public BloomFilterPool(long ptr, IFileSystem fs, long maxSize, int chunkSize) {
        this.fs = fs;
        this.bufferPool = new NativeRamBufferPool(ptr, maxSize, chunkSize);
        LOG.info("Create Bloomfilter pool with max size = " + maxSize
                + ", chunk size = " + chunkSize);
    }

    public NativeRamBloomFilter loadBloomFilter(SSTable sstable) {
        String key = sstable.getCacheKey();
        synchronized (pool) {
            NativeRamBloomFilter filter = pool.get(key, true);
            if (filter != null) {
                filter.acquire();
                return filter;
            }
        }

        synchronized (sstable.bloomfilterFile) {
            synchronized (pool) {
                NativeRamBloomFilter filter = pool.get(key, true);
                if (filter != null) {
                    filter.acquire();
                    return filter;
                }
            }
            HashFunction hash;
            int bitSetSize;
            byte[] bits;
            FSDataInputStream in = null;
            try {
                in = OmapUtils.createFSDataInputStream(fs,
                        sstable.bloomfilterFile, false);
                int nbHash = in.readInt();
                int hashType = in.readInt();
                bitSetSize = in.readInt();
                hash = new HashFunction(bitSetSize, nbHash, hashType);
                bits = new byte[(bitSetSize + 7) / 8];
                in.readFully(bits);
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "error occured when reading bloomfilter", e);
                return null;
            } finally {
                OmapUtils.safeClose(in);
            }
            int size = (bitSetSize + 7) >> 3;
            synchronized (pool) {
                if (bufferPool.getAllocatedBufferSize() + size > bufferPool.getMaxBufferSize()) {
                    do {
                        LRUMap.Entry<String, NativeRamBloomFilter> entry = pool.poll();
                        if (entry == null || !entry.getValue().release()) {
                            LOG.log(Level.WARNING,
                                    "can not allocate a buffer with size "
                                            + size
                                            + " when loading bloomfilter");
                            return null;
                        }
                    } while (bufferPool.getAllocatedBufferSize() + size > bufferPool.getMaxBufferSize());
                }
                NativeRamBuffer[] buffers = bufferPool.newBuffer(size);
                LOG.info("Load bloomfilter for " + sstable + " with size "
                        + size + ", allocatedSize "
                        + (bufferPool.getChunkSize() * buffers.length)
                        + ", filter pool usage: "
                        + bufferPool.getAllocatedBufferSize() + "/"
                        + bufferPool.getMaxBufferSize());
                NativeRamBloomFilter filter = new NativeRamBloomFilter(buffers,
                        (int) bufferPool.getChunkSize(), bits, bitSetSize,
                        hash, sstable, this);
                pool.put(key, filter);
                return filter;
            }
        }
    }

    public void unloadBloomFilter(SSTable sstable) {
        String key = sstable.getCacheKey();
        synchronized (pool) {
            NativeRamBloomFilter filter = pool.remove(key);
            if (filter != null) {
                filter.release();
            }
        }
    }

    public long getLoadedBloomFilterSize(SSTable sstable) {
        String key = sstable.getCacheKey();
        synchronized (pool) {
            NativeRamBloomFilter filter = pool.get(key, false);
            return filter != null ? filter.getNBytes() : 0;
        }
    }

    public long getMaxSize() {
        return bufferPool.getMaxBufferSize();
    }

    public long getAllocatedSize() {
        synchronized (pool) {
            return bufferPool.getAllocatedBufferSize();
        }
    }

}
