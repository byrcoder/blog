package outfox.omap.test;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.lib.IntWritable;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryCondition;
import outfox.omap.conf.OmapConfig;
import toolbox.misc.LogFormatter;

public class TestQuery {

    private static final Logger LOG = LogFormatter.getLogger(TestQuery.class);

    private static final int COLUMN_MAX = 10;

    private static final String[] COLUMN_NAMES;

    private static final String[] COLUMN_TYPES;

    private static final String TABLE_NAME = "TestTable";

    private static final String TABLE_SPACE_NAME = "TestSpace";

    static {
        COLUMN_NAMES = new String[COLUMN_MAX];
        COLUMN_TYPES = new String[COLUMN_MAX];
        for (int i = 0; i < COLUMN_MAX; i++) {
            COLUMN_NAMES[i] = "COLUMN" + i;
            COLUMN_TYPES[i] = "INTEGER";
        }
    }

    private int seed;

    private int count;

    private int queryConditionCount;

    private QueryWorkerThread[] queryWorkers;

    private Random keyRand;

    private Table table;

    public TestQuery(int seed, int count, int workerNumber,
            int queryConditionCount) {
        if (queryConditionCount >= COLUMN_MAX) {
            throw new IllegalArgumentException();
        }
        this.seed = seed;
        this.keyRand = new Random(seed);
        this.count = count;
        this.queryConditionCount = queryConditionCount;
        queryWorkers = new QueryWorkerThread[workerNumber];
    }

    public void exec() throws Exception {
        execInsert();
        execQuery();
    }

    private OmapQuery[] getQueries() {
        OmapQueryCondition[] qcs = new OmapQueryCondition[queryConditionCount];
        for (int j = 1; j <= queryConditionCount; j++) {
            qcs[j] = new OmapQueryCondition(COLUMN_NAMES[j],
                    QueryOperation.EQUAL);
        }
        return new OmapQuery[] {
            new OmapQuery("QUERY", qcs)
        };
    }

    public void execInsert() throws Exception {
        TableSpace tableSpace = new OmapTableSpace(TABLE_SPACE_NAME,
                new MasterWatcherAndClientConfig(new ClientConfig(
                        OmapConfig.getConfiguration())));
        if (tableSpace.findTable(TABLE_NAME) != null) {
            LOG.info("delete old table " + TABLE_NAME);
            tableSpace.deleteTable(TABLE_NAME);
        }
        LOG.info("create table " + TABLE_NAME + " with " + queryConditionCount
                + " queryConditions for each query");
        Table table = tableSpace.createTable(TABLE_NAME, COLUMN_NAMES,
                COLUMN_TYPES, getQueries());
        Thread.sleep(10000);
        int insertCount = count * queryWorkers.length;
        Row row = table.newRow();
        for (int i = 0; i < insertCount; i++) {
            if (i % 10000 == 0) {
                LOG.info("insert " + i + " rows");
            }
            int key = keyRand.nextInt();
            for (int j = 0; j < COLUMN_MAX; j++) {
                row.set(i, new IntWritable(key));
            }
            table.update(row);
        }
    }

    public void execQuery() {
        keyRand.setSeed(seed);

    }

    private class WorkerThread extends Thread {
        protected int id;

        protected long totalResponseTime = 0;

        protected long totalResponseTime2 = 0;

        protected long maxResponseTime = 0;

        protected AtomicLong periodResponseTime = new AtomicLong(0);

        protected AtomicInteger num = new AtomicInteger(0);
    }

    private class QueryWorkerThread extends WorkerThread {

        public QueryWorkerThread(int id) {
            this.id = id;
        }

        @Override
        public void run() {
            LOG.info("");
            try {
                Row row = table.newRow();
                Query query = table.getQuery("query");
                IntWritable key = new IntWritable();
                while (num.get() < count) {
                    int k = keyRand.nextInt();
                    for (int i = 0; i < queryConditionCount; i++) {
                        query.getCondition(COLUMN_NAMES[i + 1]).setPara(
                                new IntWritable(k));
                    }
                    TableCursor cursor = table.getQueryCursor(query);
                    if (!cursor.next(row)) {
                        LOG.warning("key = " + k + " not found");
                        System.exit(1);
                    }
                    for (int i = 0; i < COLUMN_MAX; i++) {
                        row.get(i, key);
                        if (key.get() != k) {
                            LOG.warning("data error");
                            System.exit(1);
                        }
                    }
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "query failed", t);
            }
        }

    }

    private static class MonitorThread extends Thread {
        private WorkerThread[] workers;

        public MonitorThread(WorkerThread[] workers) {
            super("Monitor");
            this.workers = workers;
        }

        private volatile boolean stop = false;

        @Override
        public void run() {
            long currentNum = 0;
            long lastNum = 0;
            int zeroTimes = 0;
            while (!stop) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {}
                lastNum = currentNum;
                currentNum = 0;
                long periodResponseTime = 0;
                for (int i = 0; i < workers.length; i++) {
                    LOG.info("Worker" + i + ":" + workers[i].num.get());
                    currentNum += workers[i].num.get();
                    periodResponseTime += workers[i].periodResponseTime.getAndSet(0);
                }
                LOG.info("Total:" + currentNum);
                LOG.info("periodThroughput:" + (currentNum - lastNum));
                LOG.info("periodResponseTime:" + (double) periodResponseTime
                        / (currentNum - lastNum));
                if (currentNum - lastNum == 0) {
                    zeroTimes++;
                    if (zeroTimes >= 20) {
                        LOG.info("Long time zero");
                    }
                } else
                    zeroTimes = 0;
            }
        }
    }
}
