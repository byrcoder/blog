/**
 * @(#)SafeNativeRamFile.java, 2011-10-26. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import odis.io.nram.NativeRamFile;

/**
 *
 * @author wangfk
 *
 */
public class SafeNativeRamFile extends NativeRamFile {
    private volatile boolean isClosed;
    
    public SafeNativeRamFile() throws IOException {
        super();
        isClosed = false;
    }

    private void checkClosed() {
        if (isClosed) {
            throw new IllegalStateException("The native ram file is already closed.");
        }
    }

    @Override
    public synchronized void close() {
        try {
            super.close();
        } finally {
            isClosed = true;
        }
    }

    @Override
    public synchronized int get(long position, byte[] buffer, int offset, int length)
            throws IOException {
        checkClosed();
        return super.get(position, buffer, offset, length);
    }

    @Override
    public synchronized long getPosition() {
        checkClosed();
        return super.getPosition();
    }

    @Override
    public synchronized long length() {
        checkClosed();
        return super.length();
    }

    @Override
    public synchronized void mirrorLocalFile(String filename) throws IOException {
        checkClosed();
        super.mirrorLocalFile(filename);
    }

    @Override
    public synchronized void put(long position, byte[] buffer, int offset, int length)
            throws IOException {
        checkClosed();
        super.put(position, buffer, offset, length);
    }

    @Override
    public synchronized int read(byte[] buffer, int offset, int length) throws IOException {
        checkClosed();
        return super.read(buffer, offset, length);
    }

    @Override
    public synchronized long seek(long pos) throws IOException {
        checkClosed();
        return super.seek(pos);
    }

    @Override
    public synchronized void setLength(long length) throws IOException {
        checkClosed();
        super.setLength(length);
    }

    @Override
    public synchronized void write(byte[] buffer, int offset, int length) throws IOException {
        checkClosed();
        super.write(buffer, offset, length);
    }

}
