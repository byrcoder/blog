/**
 * @(#)MasterWatcher.java, 2009-8-16. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.rpc2.RPC;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper;

import outfox.omap.ClientMasterProtocol;
import outfox.omap.common.ClientTsProtocol;
import outfox.omap.common.TsConnectionManager;
import outfox.omap.exceptions.MasterNotInitializedException;
import outfox.omap.util.NoActionWatcher;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class MasterWatcherAndClientConfig {

    private static final Logger LOG = LogFormatter.getLogger(MasterWatcherAndClientConfig.class);

    private volatile ClientMasterProtocol master;

    private volatile ClientMasterProtocol noTimeoutMaster;

    private TsConnectionManager<ClientTsProtocol> tsConnManager = new TsConnectionManager<ClientTsProtocol>(
            ClientTsProtocol.class, TsConnectionManager.ConnectionType.NIO);

    private MetadataCache metadataCache = new MetadataCache();

    private ZooKeeper zooKeeper;

    private String masterAddress;

    private ClientConfig conf;

    private enum State {
        SUCCESS, FAIL, EXPIRED
    }

    public MasterWatcherAndClientConfig(ClientConfig conf) throws IOException {
        this.conf = conf;
        zooKeeper = new ZooKeeper(conf.getZkAddress(), conf.getInt(
                ClientConfig.NAME_CLIENT_ZOOKEEPER_TIMEOUT,
                ClientConfig.DEFAULT_CLIENT_ZOOKEEPER_TIMEOUT),
                new NoActionWatcher());
        watchMasterAddress();
    }

    public ClientConfig getConf() {
        return conf;
    }

    public MetadataCache getMetadataCache() {
        return metadataCache;
    }

    public TsConnectionManager<ClientTsProtocol> getTsConnManager() {
        return tsConnManager;
    }

    private synchronized void reInit() {
        try {
            zooKeeper.close();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "close zookeeper failed", e);
        }

        int retry = -1;
        while (true) {
            retry++;
            if (retry >= 3) {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {}
            }
            LOG.warning("create zookeeper, retry = " + retry);
            try {
                zooKeeper = new ZooKeeper(conf.getZkAddress(), conf.getInt(
                        ClientConfig.NAME_CLIENT_ZOOKEEPER_TIMEOUT,
                        ClientConfig.DEFAULT_CLIENT_ZOOKEEPER_TIMEOUT),
                        new NoActionWatcher());
                return;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "create zookeeper failed", e);
            }
        }
    }

    private synchronized State setMaster() {
        int retry = -1;
        while (true) {
            retry++;
            if (retry >= 3) {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {}
            }
            LOG.warning("set master, retry = " + retry);
            try {
                byte[] data = zooKeeper.getData(conf.getZkActiveMasterPath(),
                        null, null);
                String addressStr = new String(data);
                String[] ss = addressStr.split(":");
                InetSocketAddress addr = new InetSocketAddress(ss[0],
                        Integer.parseInt(ss[1]));
                String clientAddr = InetAddress.getLocalHost().getHostName();
                ClientMasterProtocol oldMaster = master;
                String userName = conf.getString(
                        ClientConfig.NAME_CLIENT_USER_NAME,
                        ClientConfig.DEFAULT_CLIENT_USER_NAME);
                master = (ClientMasterProtocol) RPC.getProxy(
                        ClientMasterProtocol.class, addr, clientAddr, userName,
                        conf.getLong(ClientConfig.NAME_CLIENT_CONNECT_TIMEOUT,
                                ClientConfig.DEFAULT_CLIENT_CONNECT_TIMEOUT));
                masterAddress = addressStr;
                if (oldMaster != null) {
                    RPC.close(oldMaster);
                }
                oldMaster = noTimeoutMaster;
                noTimeoutMaster = (ClientMasterProtocol) RPC.getProxy(
                        ClientMasterProtocol.class, addr, clientAddr, userName,
                        0);
                if (oldMaster != null) {
                    RPC.close(oldMaster);
                }
                metadataCache.setMaster(master);
                LOG.info("set master address to " + addr);
                return State.SUCCESS;
            } catch (KeeperException e) {
                if (e.code().equals(Code.SESSIONEXPIRED)) {
                    LOG.log(Level.WARNING, "ZooKeeper session expired", e);
                    return State.EXPIRED;
                }
                if (e.code().equals(Code.NONODE)) {
                    LOG.log(Level.WARNING, "master znode not exists", e);
                    return State.FAIL;
                }
                LOG.log(Level.WARNING, "set master failed", e);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "set master failed", e);
            }
        }
    }

    private synchronized void watchMasterAddress() {
        int retry = -1;

        while (true) {
            retry++;
            if (retry >= 3) {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {}
            }
            boolean exists = false;
            try {
                exists = zooKeeper.exists(conf.getZkActiveMasterPath(),
                        addressWatcher) != null;
            } catch (KeeperException e) {
                if (e.code().equals(Code.SESSIONEXPIRED)) {
                    LOG.info("ZooKeeper session expired, try to reinit");
                    reInit();
                } else {
                    LOG.log(Level.WARNING, "failed to set watcher", e);
                }
                continue;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "failed to set watcher", e);
                continue;
            }

            if (exists) {
                State result = setMaster();
                if (result == State.FAIL) {
                    LOG.info("maybe the master znode was deleted just now, "
                            + "left for watcher thread to solve");
                } else if (result == State.EXPIRED) {
                    LOG.warning("ZooKeeper session expired, try to reinit");
                    reInit();
                    continue;
                }
            }
            return;
        }
    }

    private final Watcher addressWatcher = new Watcher() {

        @Override
        public void process(WatchedEvent event) {
            if (event.getState() == KeeperState.Expired) {
                LOG.warning("ZooKeeper session expired, try to reinit");
                reInit();
                watchMasterAddress();
            }
            if (event.getType().equals(EventType.NodeDeleted)
                    || event.getType().equals(EventType.NodeCreated)) {
                LOG.info("Master address event: " + event);
                watchMasterAddress();
            } else {
                LOG.warning("unexpected event: " + event);
                watchMasterAddress();
            }
        }
    };

    public ClientMasterProtocol getMaster() {
        ClientMasterProtocol master = this.master;
        if (master == null) {
            throw new MasterNotInitializedException(
                    "master has not been initialized");
        }
        return master;
    }

    public String getMasterAddress() {
        return masterAddress;
    }

    public ClientMasterProtocol getNoTimeoutMaster() {
        ClientMasterProtocol master = this.noTimeoutMaster;
        if (master == null) {
            throw new MasterNotInitializedException(
                    "master has not been initialized");
        }
        return master;
    }

    public void close() {
        try {
            zooKeeper.close();
        } catch (InterruptedException e) {
            LOG.log(Level.WARNING, "close zookeeper failed", e);
        }
        if (master != null) {
            RPC.close(master);
            master = null;
        }
        if (noTimeoutMaster != null) {
            RPC.close(noTimeoutMaster);
            noTimeoutMaster = null;
        }
        tsConnManager.close();
    }
}
