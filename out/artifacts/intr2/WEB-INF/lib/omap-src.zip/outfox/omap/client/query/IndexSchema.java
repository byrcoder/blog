/**
 * @(#)IndexSchema.java, Nov 16, 2008. Copyright 2008 Yodao, Inc. All rights
 *                       reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                       subject to license terms.
 */
package outfox.omap.client.query;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.UTF8Writable;
import outfox.omap.conf.OmapConstants;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.IndexSchemaNotPreparedException;
import outfox.omap.metadata.ColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;

/**
 * An <code>IndexSchema</code> object that identifies an index uniquely.
 * 
 * @author xingjk
 */
public class IndexSchema implements IWritableComparable {

    public static final OmapQueryCondition[] EMPTY_CONDITIONS =
            new OmapQueryCondition[0];

    OmapQueryCondition[] conditions = EMPTY_CONDITIONS;

    /**
     * A map between the position of fields in the original data row and in the
     * index row.
     */
    private int[] col2index;

    private boolean isPrepared = false;

    private String indexTypeDeclaration;

    public boolean isPrepared() {
        return isPrepared;
    }

    public IndexSchema() {}// only for serialization

    public IndexSchema(OmapQueryCondition[] conditions) {
        if (conditions != null) {
            this.conditions = new OmapQueryCondition[conditions.length];
            System.arraycopy(conditions, 0, this.conditions, 0,
                    conditions.length);
        }
    }

    /**
     * Get the index type declaration. This method must be invoked after index's
     * preparation. Otherwise, the IndexSchemaNotPreparedException is thrown.
     * 
     * @return the type declaration of index table
     */
    public String getIndexTypeDeclaration() {
        if (!isPrepared) {
            throw new IndexSchemaNotPreparedException(
                    "Cannot get index type declaration before preparation is done");
        }

        return indexTypeDeclaration;
    }

    /**
     * Get the index column name declaration
     */
    public String getIndexNameDeclaration() {
        return OmapConstants.INDEX_COL_NAMES;
    }

    /**
     * Create a data row for the index table defined by this index schema. This
     * method must be invoked after index's preparation. Otherwise, the
     * IndexSchemaNotPreparedException is thrown.<br>
     * The reason why use keyCell and values, rather than row, as the parameters
     * is that the conversion from row to keyCell and values can be done only
     * once for original row, while the construction of new index row is
     * necessary for each index schema. For more detail see
     * {@link outfox.omap.client.OmapClient#insertIndexRow}
     * 
     * @param keyCell
     *            the key cell of the original row.
     * @param values
     *            the IWritableComparable Array of data in all columns of
     *            original row the original DataRow object (include key)
     * @return the DataRow object that can be inserted to the index table
     */
    public DataRow createIndexRow(KeyCell keyCell, IWritableComparable[] values) {
        if (!isPrepared) {
            throw new IndexSchemaNotPreparedException(
                    "Cannot get index type declaration before preparation is done");
        }

        IWritableComparable[] indexObjs = getIndexKeyIWritableArray(values);
        KeyCell indexKey = new KeyCell(OmapUtils.buildTupleKey(indexObjs)); // index
                                                                            // key
                                                                            // /
                                                                            // /
                                                                            // key
        DataCell[] originalKey = {
            keyCell
        }; // original key
        return new DataRow(indexKey, originalKey);
    }

    /**
     * Create an all-null key to match the index schema, which is used to find
     * the very first row of table in the case that query condition is given
     * only upperbound.
     * 
     * @return the all-null key
     */
    public KeyCell createNullKey() {
        if (!isPrepared) {
            throw new IndexSchemaNotPreparedException(
                    "Cannot get index type declaration before preparation is done");
        }

        IWritableComparable[] values =
                new IWritableComparable[col2index.length];
        IWritable nullKey = OmapUtils.buildTupleKey(values);
        if (values.length == 1)
            return new KeyCell(nullKey, DataCell.STATUS_NULL); // in this case,
                                                               // nullKey is
                                                               // purely a null
        else
            return new KeyCell(nullKey); // in this case nullKey is a nested
                                         // KeyPairs with all null
    }

    /**
     * Create a key for query.
     * 
     * @param values
     *            . The parameters specified in the query. They are sorted in
     *            the index schema order.
     * @return the key to perform query
     */
    public KeyCell createQueryKey(IWritableComparable[] values) {
        if (!isPrepared) {
            throw new IndexSchemaNotPreparedException(
                    "Cannot get index type declaration before preparation is done");
        }

        if (this.col2index.length > this.conditions.length) {
            // in the case of original key is auto included into the index key
            IWritableComparable[] newValues =
                    new IWritableComparable[values.length + 1];
            System.arraycopy(values, 0, newValues, 0, values.length);
            newValues[newValues.length - 1] = null;
            return new KeyCell(OmapUtils.buildTupleKey(newValues));
        } else {
            return new KeyCell(OmapUtils.buildTupleKey(values));
        }
    }

    /**
     * Convert the object array in the original row to the array sorted in the
     * index key order.
     * 
     * @param objs
     *            the IWritableComparable objects in the original data row
     * @return the IWritableComparable objects in the index tuple key order
     */
    public IWritableComparable[] getIndexKeyIWritableArray(
            IWritableComparable objs[]) {
        IWritableComparable[] indexObjs =
                new IWritableComparable[col2index.length];
        for (int i = 0; i < indexObjs.length; i++) {
            indexObjs[i] = objs[col2index[i]];
        }
        return indexObjs;
    }

    /*
     * (non-Javadoc)
     * @see odis.serialize.IWritable#readFields(java.io.DataInput)
     */
    public void readFields(DataInput in) throws IOException {
        int length = in.readInt();
        conditions = new OmapQueryCondition[length];
        for (int i = 0; i < length; i++) {
            conditions[i] = new OmapQueryCondition();
            conditions[i].readFields(in);
        }
        isPrepared = in.readBoolean();
        if (isPrepared) {
            indexTypeDeclaration = UTF8Writable.readString(in);
            int count = in.readInt();
            col2index = new int[count];
            for (int i = 0; i < count; i++) {
                col2index[i] = in.readInt();
            }
        }
    }

    /*
     * (non-Javadoc)
     * @see odis.serialize.IWritable#writeFields(java.io.DataOutput)
     */
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(conditions.length);
        for (OmapQueryCondition condition: conditions) {
            condition.writeFields(out);
        }
        out.writeBoolean(isPrepared);
        if (isPrepared) {
            UTF8Writable.writeString(out, indexTypeDeclaration);
            out.writeInt(col2index.length);
            for (int pos: col2index) {
                out.writeInt(pos);
            }
        }
    }

    /*
     * (non-Javadoc)
     * @see odis.serialize.IMutable#copyFields(java.lang.Object)
     */
    public IWritable copyFields(IWritable value) {
        IndexSchema that = (IndexSchema) value;
        this.conditions = new OmapQueryCondition[that.conditions.length];
        System.arraycopy(that.conditions, 0, this.conditions, 0,
                that.conditions.length);
        this.isPrepared = that.isPrepared;
        if (this.isPrepared) {
            this.indexTypeDeclaration = that.indexTypeDeclaration;
            this.col2index = new int[that.col2index.length];
            System.arraycopy(that.col2index, 0, this.col2index, 0,
                    that.col2index.length);
        }
        return this;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("conditions: ");
        for (int i = 0; i < conditions.length; i++) {
            sb.append(conditions[i].toString());
            if (i < conditions.length - 1) {
                sb.append(" and ");
            }
        }
        return sb.toString();
    }

    public int compareTo(IWritable value) {
        IndexSchema that = (IndexSchema) value;
        int length = Math.min(this.conditions.length, that.conditions.length);
        for (int i = 0; i < length; i++) {
            // this criteria can be changed if additional comparisons are
            // necessary
            int result =
                    this.conditions[i].getColumnName().compareTo(
                            that.conditions[i].getColumnName());
            if (result != 0)
                return result;
        }
        if (this.conditions.length < that.conditions.length)
            return -1;
        else if (this.conditions.length > that.conditions.length)
            return 1;
        else
            return 0;
    }

    /**
     * Prepare the index schema for index table construction. When methods
     * <code>getIndexTypeSchemaDeclaration</code> and <code>
     * generateIndexRow</code>
     * are invoked, this method must have been invoked.
     * 
     * @param td
     */
    public void prepare(TableDesc td) {
        Map<String, Integer> colPosMap = new HashMap<String, Integer>();
        ColumnDesc[] cols = td.getColumns();
        for (int i = 0; i < cols.length; i++) {
            colPosMap.put(cols[i].getName(), i);
        }

        // check whether the index schema's conditions contains key
        boolean containKey = false;
        for (OmapQueryCondition condition: conditions) {
            if (condition.getColumnName().equals(cols[0].getName())) {
                containKey = true;
                break;
            }
        }

        // initialized col2index
        if (containKey == true) {
            col2index = new int[conditions.length];
        } else {
            col2index = new int[conditions.length + 1];
        }

        for (int i = 0; i < conditions.length; i++) {
            col2index[i] = colPosMap.get(conditions[i].getColumnName());
        }

        if (containKey == false) {
            col2index[conditions.length] = 0; // the key's position
        }

        // create index table's type declaration
        String[] indexColTypeNames = new String[col2index.length];
        for (int i = 0; i < indexColTypeNames.length; i++) {
            indexColTypeNames[i] = cols[col2index[i]].getTypeString();
        }

        String indexKeyTypeName =
                OmapUtils.buildTupleKeyDeclaration(indexColTypeNames);
        indexTypeDeclaration = indexKeyTypeName + ";" + cols[0].getTypeString();

        // change state
        isPrepared = true;
    }

    @Override
    public int hashCode() {
        int ret = 0;
        for (OmapQueryCondition condition: conditions) {
            ret ^= condition.hashCode();
        }
        return ret;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!(obj instanceof IndexSchema))
            return false;
        IndexSchema that = (IndexSchema) obj;
        if (this.conditions.length != that.conditions.length)
            return false;
        for (int i = 0; i < this.conditions.length; i++) {
            if (!this.conditions[i].equals(that.conditions[i]))
                return false;
        }
        return true;
    }

    public int getConditionCount() {
        return conditions.length;
    }

    public int getIndexColCount() {
        return col2index.length;
    }
}
