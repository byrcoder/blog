/**
 * @(#)CatalogueLogger.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.IOException;

import odis.io.IFileSystem;
import odis.io.Path;
import outfox.omap.client.OmapMetadata;
import outfox.omap.common.TsDesc;
import outfox.omap.master.AssignTabletTask;
import outfox.omap.walog.WALogger;

/**
 * @author zhangduo
 */
public class CatalogueLogger extends WALogger {

    public CatalogueLogger(Path logDir, IFileSystem fs, boolean readonly)
            throws IOException {
        super(logDir, fs, readonly, new CatalogueLogEntry());
        if (!readonly) {
            startWriter();
        }
    }

    public long writeSchemaLog(long schemaId, boolean deleted,
            OmapMetadata metadata) throws IOException {
        CatalogueLogEntry entry = new CatalogueLogEntry();
        entry.setBody(new CatalogueLogSchema(schemaId, deleted, metadata));
        return write(entry);
    }

    public long writeRangeLog(SchemaIdAndRange range, boolean deleted,
            TsDesc tsDesc) throws IOException {
        CatalogueLogEntry entry = new CatalogueLogEntry();
        entry.setBody(new CatalogueLogRange(range, deleted, tsDesc));
        return write(entry);
    }

    public long writeRangeLog(SchemaIdAndRange[] ranges, boolean[] deleted,
            TsDesc[] tsDescs) throws IOException {
        CatalogueLogEntry entry = new CatalogueLogEntry();
        entry.setBody(new CatalogueLogRange(ranges, deleted, tsDescs));
        return write(entry);
    }

    public long writeTaskLog(long taskId, boolean deleted, AssignTabletTask task)
            throws IOException {
        CatalogueLogEntry entry = new CatalogueLogEntry();
        entry.setBody(new CatalogueLogTask(taskId, deleted, task));
        return write(entry);
    }
}
