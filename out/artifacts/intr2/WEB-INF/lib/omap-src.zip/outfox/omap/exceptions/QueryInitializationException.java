/**
 * @(#)QueryInitializationException.java, Oct 28, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author xingjk
 */
public class QueryInitializationException extends RuntimeException {

    private static final long serialVersionUID = 1183649381298040285L;

    public QueryInitializationException(String message) {
        super(message);
    }

    public QueryInitializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
