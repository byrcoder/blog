package outfox.omap.client.protocol;

import odis.serialize.IWritable;
import outfox.omap.data.DataCell;
import outfox.omap.exceptions.OmapException;

/**
 * Interface of a row in an omap table, including methods of operations like set
 * and put etc. But the changes of row is not submitted to server immediately,
 * the changes are updated to server after Table.update(Row) is called. See
 * {@link outfox.omap.client.protocol.Table}.
 * 
 * @author yaming
 */
public interface Row {

    // This means that this row is not readable,maybe by a failed lookup
    @Deprecated
    public static final byte INVALID = 0x1;

    // This means that the row contains some data,but user has changed the key
    // without calling table.update
    @Deprecated
    public static final byte NEEDREFRESH = 0x2;

    /**
     * This column is set to a value
     */
    public static final int STATUS_NORMAL = DataCell.STATUS_NORMAL;

    /**
     * This column is set to NULL
     */
    public static final int STATUS_NULL = DataCell.STATUS_NULL;

    /**
     * This column is not set yet
     */
    public static final int STATUS_NOT_SET = DataCell.STATUS_INVALID;

    /**
     * Return the key value.
     * 
     * @param key
     * @throws OmapException
     */
    void getKey(IWritable key) throws OmapException;

    /**
     * Set the key value.
     * 
     * @param key
     * @throws OmapException
     */
    void setKey(IWritable key) throws OmapException;

    /**
     * Get cell at given column index. Data returned in given IWritable
     * instance, and caller could reuse the instance to gain performance
     * improvement.
     * 
     * @param colIndex
     * @param value
     * @return {@link #STATUS_NORMAL} or {@link #STATUS_NULL}
     * @throws OmapException
     */
    int get(int colIndex, IWritable value) throws OmapException;

    /**
     * Get cell at named column. Data returned in given IWritable instance, and
     * caller could reuse the instance to gain performance improvement.
     * 
     * @param colName
     * @param value
     * @return {@link #STATUS_NORMAL} or {@link #STATUS_NULL}
     * @throws OmapException
     */
    int get(String colName, IWritable value) throws OmapException;

    /**
     * Put data into cell at column index.
     * 
     * @param colIndex
     * @param value
     * @throws OmapException
     */
    void set(int colIndex, IWritable value) throws OmapException;

    /**
     * Put data into cell at named column.
     * 
     * @param colName
     * @param value
     * @throws OmapException
     */
    void set(String colName, IWritable value) throws OmapException;

    /**
     * Set cell as empty.<br>
     * This means set the cell to null.Use {@link #setNull(int)} instead.
     * 
     * @param colIndex
     * @throws OmapException
     */
    @Deprecated
    void empty(int colIndex) throws OmapException;

    /**
     * Set cell as empty.<br>
     * This means set the cell to null.Use {@link #setNull(String)} instead.
     * 
     * @param colName
     * @throws OmapException
     */
    @Deprecated
    void empty(String colName) throws OmapException;

    /**
     * Set cell as null.<br>
     * See {@link #STATUS_NULL}
     * 
     * @param colIndex
     * @throws OmapException
     */
    void setNull(int colIndex) throws OmapException;

    /**
     * Set cell as null.<br>
     * See {@link #STATUS_NULL}
     * 
     * @param colName
     * @throws OmapException
     */
    void setNull(String colName) throws OmapException;

    /**
     * Set cell as not set.<br>
     * See {@link #STATUS_NOT_SET}
     * 
     * @param colIndex
     * @throws OmapException
     */
    void clear(int colIndex) throws OmapException;

    /**
     * Set cell as not set.<br>
     * See {@link #STATUS_NOT_SET}
     * 
     * @param colName
     * @throws OmapException
     */
    void clear(String colName) throws OmapException;
}
