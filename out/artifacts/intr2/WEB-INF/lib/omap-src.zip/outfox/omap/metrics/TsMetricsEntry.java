/**
 * @(#)TsMetricsEntry.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * @author zhangduo
 */
public class TsMetricsEntry implements IWritable {

    private String tsName;

    private final TsGlobalMetricsEntry globalMetricsEntry;

    private final Map<Long, TsTabletMetricsEntry> tabletMetricsEntries;

    public TsMetricsEntry() {
        globalMetricsEntry = new TsGlobalMetricsEntry();
        tabletMetricsEntries = new TreeMap<Long, TsTabletMetricsEntry>();
    }

    public TsMetricsEntry(String tsName) {
        this();
        this.tsName = tsName;
    }

    public TsMetricsEntry(String tsName,
            TsGlobalMetricsEntry globalMetricsEntry,
            Map<Long, TsTabletMetricsEntry> tabletMetricsEntries) {
        this.tsName = tsName;
        this.globalMetricsEntry = globalMetricsEntry;
        this.tabletMetricsEntries = tabletMetricsEntries;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        TsMetricsEntry that = (TsMetricsEntry) value;

        tsName = that.tsName;
        globalMetricsEntry.copyFields(that.globalMetricsEntry);
        tabletMetricsEntries.clear();
        for (Map.Entry<Long, TsTabletMetricsEntry> e: tabletMetricsEntries.entrySet()) {
            TsTabletMetricsEntry entry = new TsTabletMetricsEntry();
            entry.copyFields(e.getValue());
            tabletMetricsEntries.put(e.getKey(), entry);
        }

        return this;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        tsName = StringWritable.readString(in);
        globalMetricsEntry.readFields(in);
        tabletMetricsEntries.clear();
        int sz = CDataInputStream.readVInt(in);
        for (int i = 0; i < sz; i++) {
            long id = in.readLong();
            TsTabletMetricsEntry entry = new TsTabletMetricsEntry();
            entry.readFields(in);
            tabletMetricsEntries.put(id, entry);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, tsName);
        globalMetricsEntry.writeFields(out);
        CDataOutputStream.writeVInt(tabletMetricsEntries.size(), out);
        for (Map.Entry<Long, TsTabletMetricsEntry> e: tabletMetricsEntries.entrySet()) {
            out.writeLong(e.getKey());
            e.getValue().writeFields(out);
        }
    }

    public String getTsName() {
        return tsName;
    }

    public TsGlobalMetricsEntry getGlobalMetricsEntry() {
        return globalMetricsEntry;
    }

    public Map<Long, TsTabletMetricsEntry> getTabletMetricsEntries() {
        return tabletMetricsEntries;
    }

}
