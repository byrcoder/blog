package outfox.omap.exceptions;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

import org.apache.commons.lang.NotImplementedException;

import outfox.omap.common.TsDesc;
import toolbox.text.util.HexString;

public class TabletNotFoundException extends RuntimeException implements
        IWritable {

    private static final long serialVersionUID = 3196825743912761720L;

    public enum Reasons {
        UNKNOWN, SPLITTED, JUST_MOVED
    };

    private long tabletId;

    private TsDesc hintTs = null;

    private Reasons reason = Reasons.UNKNOWN;

    /**
     * Create with an UNKOWN reason.
     * 
     * @param tabletId
     */
    public TabletNotFoundException(long tabletId) {
        super();
        this.tabletId = tabletId;
        this.reason = Reasons.UNKNOWN;
    }

    /**
     * Create with a given reason.
     * 
     * @param tabletId
     * @param reason
     */
    public TabletNotFoundException(long tabletId, Reasons reason) {
        this(tabletId);
        this.reason = reason;
    }

    /**
     * Create with a JUST_MOVED reason.
     * 
     * @param tabletId
     * @param hintTs
     * @param port
     */
    public TabletNotFoundException(long tabletId, TsDesc hintTs) {
        this(tabletId);
        this.hintTs = hintTs;
        this.reason = Reasons.JUST_MOVED;
    }

    public void setReason(Reasons reason) {
        this.reason = reason;
    }

    public Reasons getReason() {
        return this.reason;
    }

    public long getTabletId() {
        return tabletId;
    }

    public TsDesc getHintTs() {
        return hintTs;
    }

    public void setTabletId(long tabletId) {
        this.tabletId = tabletId;
    }

    @Override
    public String getMessage() {
        return "id=" + HexString.longToPaddedHex(this.tabletId) + ", reason="
                + reason + ", hintTs=" + hintTs;
    }

    public void readFields(DataInput in) throws IOException {
        this.reason = Reasons.valueOf(in.readUTF());
        this.tabletId = in.readLong();
        boolean hasHintTs = in.readBoolean();
        if (hasHintTs) {
            this.hintTs = new TsDesc();
            this.hintTs.readFields(in);
        } else {
            this.hintTs = null;
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(reason.name());
        out.writeLong(this.tabletId);
        out.writeBoolean(hintTs != null);
        if (hintTs != null) {
            this.hintTs.writeFields(out);
        }
    }

    public IWritable copyFields(IWritable value) {
        throw new NotImplementedException();
    }

}
