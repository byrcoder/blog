/**
 * @(#)OmapQueryCursor.java, Dec 3, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.query;

import java.util.Iterator;
import java.util.Queue;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.client.OmapClient;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.OmapUserRow;
import outfox.omap.client.OmapUserTableCursor;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.OmapException;
import toolbox.collections.ArrayQueue;

/**
 * A cursor to traverse all query reuslts
 * 
 * @author xingjk
 */
public class OmapQueryCursor implements TableCursor {

    protected OmapClient client;

    protected OmapClient indexClient;

    protected OmapMetadata metadata;

    private int prefetchDistance = 5;

    // the keys
    private Queue<IWritable> prefetchQueue = new ArrayQueue<IWritable>(
            prefetchDistance);

    private int curPoint;

    private OmapQuery query;

    private OmapUserTableCursor indexTableCursor;

    private IndexSchema indexSchema;

    private StopCondition stopCondition;

    private static final int NO_ELEMENT_AVAILABLE = -2;

    private boolean isStop = false; // indicate whether to fetch further or not

    private IWritableComparable[] paraBuffer;

    private IWritableComparable firstKey;

    private boolean inequal = false;

    /**
     * @param client
     *            user table's client
     * @param query
     * @param txn
     * @throws OmapException
     */
    public OmapQueryCursor(OmapClient client, OmapQuery query)
            throws OmapException {
        this.client = client;
        this.metadata = client.getMetadata();
        this.query = query;
        this.indexSchema = metadata.getPreparedIndexSchema(query.getIndexSchema());
        this.indexClient = client.getIndexClients().get(
                metadata.getIndexes().get(indexSchema));
        this.paraBuffer = new IWritableComparable[indexSchema.getIndexColCount()]; // the
        // buffer
        // used
        // for
        // match
        this.firstKey = query.getFirstCondition().getPara();

        // make sure the lower bound
        KeyCell startKey = null;
        QueryOperation op = query.getFirstCondition().getOperation();
        if (op == QueryOperation.INEQUAL) {
            inequal = true;
        }

        if (op == QueryOperation.EQUAL || op.isSpecifyLowerBound()
                || op.isSpecifyRange()) {
            startKey = OmapQueryUtils.constructStartKey(query, indexSchema);
        } else {
            startKey = indexSchema.createNullKey();
        }

        indexTableCursor = new OmapUserTableCursor(indexClient);
        indexTableCursor.moveTo(startKey);

        // set the stop condition
        if (op == QueryOperation.EQUAL || op == QueryOperation.LET
                || op == QueryOperation.LIRI || op == QueryOperation.LERI) {
            KeyCell endKey = OmapQueryUtils.constructEndKey(query, indexSchema);
            stopCondition = new GreaterThanStopCondition(
                    OmapQueryUtils.getFirstKey(endKey));
        } else if (op == QueryOperation.LT || op == QueryOperation.LERE
                || op == QueryOperation.LIRE || op == QueryOperation.INEQUAL) {
            KeyCell endKey = OmapQueryUtils.constructEndKey(query, indexSchema);
            stopCondition = new EqualStopCondition(
                    OmapQueryUtils.getFirstKey(endKey));
        } else {
            stopCondition = new NoStopCondition();
        }

        // need jump over
        if (op == QueryOperation.GT || op == QueryOperation.LERI
                || op == QueryOperation.LERE) {
            // it's necessary to jump over some rows
            while (true) {
                DataRow dr = indexTableCursor.next();
                if (dr == null || stopCondition.isStop(dr)) {
                    isStop = true;
                    curPoint = NO_ELEMENT_AVAILABLE;
                    break;
                } else {

                    if (OmapQueryUtils.getFirstKey(dr.getKeyCell()).compareTo(
                            firstKey) != 0)
                        break; // finish jump over
                }
            }
        }

        fetch();

        curPoint = 0;
    }

    public void close() throws OmapException {
        indexTableCursor.close();
    }

    private boolean validate(DataRow row) {
        for (OmapQueryCondition condition: query.getConditions()) {
            if (!condition.isMatch((IWritableComparable) (row.getIWritable(metadata.getColumnIndex(condition.getColumnName()))))) {
                return false;
            }
        }
        return true;
    }

    private DataRow curRow = null;

    public boolean hasNext() throws OmapException {
        if (curRow != null) {
            return true;
        }
        if (curPoint == NO_ELEMENT_AVAILABLE) {
            return false;
        }
        while (true) {
            if (prefetchQueue.size() == 0) {
                fetch();
                if (prefetchQueue.size() == 0) {
                    curPoint = NO_ELEMENT_AVAILABLE;
                    return false;
                }
            }
            KeyCell keyCell = new KeyCell();
            IWritable key = prefetchQueue.poll();
            keyCell.setIWritable(key);
            DataRow dr = client.keyFind(keyCell);
            if (dr != null && validate(dr)) {
                curRow = dr;
                return true;
            }
        }

    }

    /**
     * Not Supported
     */
    public boolean moveTo(IWritable key, boolean accurate) throws OmapException {
        throw new UnsupportedOperationException();
    }

    public boolean next(Row row) throws OmapException {
        if (!hasNext())
            return false;

        // fetch the first one in queue
        if (row instanceof OmapUserRow) {
            ((OmapUserRow) row).setDataRow(curRow);
            curRow = null;
        } else {
            throw new OmapException(row + " is not a OmapUserRow.");
        }

        return true;
    }

    /**
     * @throws OmapException
     */
    private void fetch() throws OmapException {
        DataRow dr;
        while (prefetchQueue.size() < prefetchDistance) {
            dr = indexTableCursor.next();
            if (dr == null || stopCondition.isStop(dr)) {
                setStop(true);
                if (!inequal)
                    return; // except for INEQUAL, exit
                else
                    continue;
            } else {
                if (OmapQueryUtils.isMatchWithoutFirstKey(query,
                        dr.getKeyCell(), paraBuffer)) {
                    prefetchQueue.add(dr.getIWritable(1));
                }
            }
        }
    }

    private void setStop(boolean isStop) throws OmapException {
        if (inequal) {
            // jump over
            while (true) {
                DataRow dr = indexTableCursor.next();
                if (dr == null) {
                    isStop = true;
                    return;
                }
                if (this.firstKey.compareTo(OmapQueryUtils.getFirstKey(dr.getKeyCell())) != 0) {
                    prefetchQueue.add(dr.getIWritable(1));
                    break;
                }
            }
            stopCondition = new NoStopCondition();
            inequal = false; // cancel the special inequal
        } else {
            this.isStop = isStop;
        }
    }

    public void refresh() throws OmapException {
        if (!isStop)
            fetch();
    }

    /**
     * Not Supported
     */
    public void remove() throws OmapException {
        throw new UnsupportedOperationException();
    }

    public void setPrefetch(int prefetchDistance) throws OmapException {
        int newDistance = prefetchDistance < 2 ? 2 : prefetchDistance;
        if (newDistance != this.prefetchDistance) {
            this.prefetchDistance = newDistance;
            ArrayQueue<IWritable> newQueue = new ArrayQueue<IWritable>(
                    newDistance);
            Iterator<IWritable> iter = prefetchQueue.iterator();
            while (iter.hasNext()) {
                newQueue.add(iter.next());
            }
            prefetchQueue = newQueue;
            indexTableCursor.setPrefetch(newDistance);
        }
    }

    static interface StopCondition {
        boolean isStop(DataRow row);
    }

    /**
     * always deny stop
     * 
     * @author xingjk
     */
    static class NoStopCondition implements StopCondition {
        public boolean isStop(DataRow row) {
            return false;
        }
    }

    /**
     * If the first key of given row equals to "stopFirstKey" return true for
     * stop
     * 
     * @author xingjk
     */
    static class EqualStopCondition implements StopCondition {

        IWritableComparable stopFirstKey;

        public EqualStopCondition(IWritableComparable stopFirstKey) {
            this.stopFirstKey = stopFirstKey;
        }

        public boolean isStop(DataRow row) {
            if (OmapQueryUtils.getFirstKey(row.getKeyCell()).compareTo(
                    stopFirstKey) == 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * If the first key of given row is greater than "stopFirstKey" return true
     * for stop.
     * 
     * @author xingjk
     */
    static class GreaterThanStopCondition implements StopCondition {

        IWritableComparable stopFirstKey;

        public GreaterThanStopCondition(IWritableComparable stopFirstKey) {
            this.stopFirstKey = stopFirstKey;
        }

        public boolean isStop(DataRow row) {
            if (OmapQueryUtils.getFirstKey(row.getKeyCell()).compareTo(
                    stopFirstKey) > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * Not Supported
     */
    @Override
    public void setEndKey(IWritable endKeyExclusive) {
        throw new UnsupportedOperationException();
    }

    /**
     * Not Supported
     */
    @Override
    public void reset() {
        throw new UnsupportedOperationException();
    }
}
