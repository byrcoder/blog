/**
 * @(#)SkipListSet.java, 2012-5-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Logger;

import odis.serialize.lib.ByteArrayWritable;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.UnsafeHelper;

import org.apache.commons.collections.BufferOverflowException;

import outfox.omap.data.KeyCell;
import outfox.omap.ts.NativeRamWriteBuffer.KeyComparator;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class SkipListSet implements Closeable {

    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(SkipListSet.class);

    private static final int ENTRY_SIZE = 16;

    // static class Node {
    //     long offsetAndLength;
    //     Node next;
    // }
    private static final int NODE_FIELD_NEXT_OFFSET = 0;

    // X86 is little endian, so an unsafe.getLong at this offset will get a 
    // long with length at lower 4 bytes and offset at higher 4 bytes.
    private static final int NODE_FIELD_LENGTH_OFFSET = 4;

    @SuppressWarnings("unused")
    private static final int NODE_FIELD_OFFSET_OFFSET = 8;

    // static class Index {
    //     Node node;
    //     Index down;
    //     Index right;
    // }
    private static final int INDEX_FIELD_NODE_OFFSET = 0;

    private static final int INDEX_FIELD_DOWN_OFFSET = 4;

    private static final int INDEX_FIELD_RIGHT_OFFSET = 8;

    // static class HeadIndex extends Index {
    //     int level;
    // }
    private static final int HEAD_INDEX_FIELD_LEVEL_OFFSET = 12;

    final KeyComparator comparator;

    private final WriteBufferPool bufferPool;

    // The array element is immutable
    private volatile NativeRamBuffer[] buffers;

    private volatile int capacity;

    private volatile int writeOffset;

    private final int indexOfBufferShift;

    private final int offsetInBufferMask;

    private volatile int head;

    private volatile int entryCount;

    private int indexOfBuffer(int pos) {
        return pos >>> indexOfBufferShift;
    }

    private int offsetInBuffer(int pos) {
        return pos & offsetInBufferMask;
    }

    private int createNode(long offsetAndLength, int next) {
        int node = writeOffset;
        NativeRamBuffer buffer = buffers[indexOfBuffer(node)];
        int offsetInBuffer = offsetInBuffer(node);
        UnsafeHelper.putInt(buffer.getPtr() + offsetInBuffer
                + NODE_FIELD_NEXT_OFFSET, next, false);
        UnsafeHelper.putLong(buffer.getPtr() + offsetInBuffer
                + NODE_FIELD_LENGTH_OFFSET, offsetAndLength, false);
        writeOffset = node + ENTRY_SIZE;
        return node;
    }

    // level > 0 means this is a head index
    private int createIndex(int node, int down, int right, int level) {
        int index = writeOffset;
        NativeRamBuffer buffer = buffers[indexOfBuffer(index)];
        int offsetInBuffer = offsetInBuffer(index);
        UnsafeHelper.putInt(buffer.getPtr() + offsetInBuffer
                + INDEX_FIELD_NODE_OFFSET, node, false);
        UnsafeHelper.putInt(buffer.getPtr() + offsetInBuffer
                + INDEX_FIELD_DOWN_OFFSET, down, false);
        UnsafeHelper.putInt(buffer.getPtr() + offsetInBuffer
                + INDEX_FIELD_RIGHT_OFFSET, right, false);
        if (level > 0) {
            UnsafeHelper.putInt(buffer.getPtr() + offsetInBuffer
                    + HEAD_INDEX_FIELD_LEVEL_OFFSET, level, false);
        }
        writeOffset = index + ENTRY_SIZE;
        return index;
    }

    private int readIntAtPos(int base, int fieldOffset, boolean isVolatile) {
        if (base < 0) {
            return -1;
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer(base)];
        int offsetInBuffer = offsetInBuffer(base);
        return UnsafeHelper.getInt(buffer.getPtr() + offsetInBuffer
                + fieldOffset, isVolatile);
    }

    private void writeIntAtPos(int value, int base, int fieldOffset,
            boolean isVolatile) {
        if (base < 0) {
            return;
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer(base)];
        int offsetInBuffer = offsetInBuffer(base);
        UnsafeHelper.putInt(buffer.getPtr() + offsetInBuffer + fieldOffset,
                value, isVolatile);
    }

    private long readLongAtPos(int base, int fieldOffset, boolean isVolatile) {
        if (base < 0) {
            return -1;
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer(base)];
        int offsetInBuffer = offsetInBuffer(base);
        return UnsafeHelper.getLong(buffer.getPtr() + offsetInBuffer
                + fieldOffset, isVolatile);
    }

    private void writeLongAtPos(long value, int base, int fieldOffset,
            boolean isVolatile) throws IOException {
        if (base < 0) {
            return;
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer(base)];
        int offsetInBuffer = offsetInBuffer(base);
        UnsafeHelper.putLong(buffer.getPtr() + offsetInBuffer + fieldOffset,
                value, isVolatile);
    }

    int nextOf(int node, boolean isVolatile) throws IOException {
        return readIntAtPos(node, NODE_FIELD_NEXT_OFFSET, isVolatile);
    }

    private void setNext(int node, int next, boolean isVolatile)
            throws IOException {
        writeIntAtPos(next, node, NODE_FIELD_NEXT_OFFSET, isVolatile);
    }

    long lengthAndOffsetOf(int node, boolean isVolatile) throws IOException {
        return readLongAtPos(node, NODE_FIELD_LENGTH_OFFSET, isVolatile);
    }

    private void setLengthAndOffset(int node, long lengthAndOffset,
            boolean isVolatile) throws IOException {
        writeLongAtPos(lengthAndOffset, node, NODE_FIELD_LENGTH_OFFSET,
                isVolatile);
    }

    private int nodeOf(int index) throws IOException {
        return readIntAtPos(index, INDEX_FIELD_NODE_OFFSET, false);
    }

    private int downOf(int index) throws IOException {
        return readIntAtPos(index, INDEX_FIELD_DOWN_OFFSET, false);
    }

    private int rightOf(int index, boolean isVolatile) throws IOException {
        return readIntAtPos(index, INDEX_FIELD_RIGHT_OFFSET, isVolatile);
    }

    private void setRight(int index, int right, boolean isVolatile)
            throws IOException {
        writeIntAtPos(right, index, INDEX_FIELD_RIGHT_OFFSET, isVolatile);
    }

    private int levelOf(int headIndex) throws IOException {
        return readIntAtPos(headIndex, HEAD_INDEX_FIELD_LEVEL_OFFSET, false);
    }

    private final Random rand;

    SkipListSet(KeyComparator comparator, WriteBufferPool bufferPool) {
        this.comparator = comparator;
        this.bufferPool = bufferPool;
        int chunkSize = bufferPool.getChunkSize();
        this.indexOfBufferShift = UnsafeHelper.log2(chunkSize);
        this.offsetInBufferMask = chunkSize - 1;
        this.buffers = new NativeRamBuffer[0];
        this.capacity = 0;
        this.writeOffset = 0;
        // we will allocate a write buffer when first write.
        this.head = -1;
        this.rand = new Random();
    }

    // the version of ConcurrentSkipListMap sucks, use the original version
    // with p = 0.5 and max = 32
    private int randomLevel() {
        int level = 0;
        while (rand.nextInt() >= 0 && level < 32) {
            level++;
        }
        return level;
    }

    private int findPredecessor(long key, KeyCell keyCell) throws IOException {
        int q = head;
        int r = rightOf(q, false);
        for (;;) {
            if (r != -1) {
                int n = nodeOf(r);
                if (comparator.compare(keyCell, lengthAndOffsetOf(n, false)) > 0) {
                    q = r;
                    r = rightOf(r, false);
                    continue;
                }
            }
            int d = downOf(q);
            if (d != -1) {
                q = d;
                r = rightOf(d, false);
            } else {
                return nodeOf(q);
            }
        }
    }

    private void ensureCapacity(int size) throws IOException {
        if (writeOffset + size > capacity) {
            NativeRamBuffer[] allocatedBuffers = bufferPool.newBuffer(size);
            if (allocatedBuffers.length == 0) {
                throw new BufferOverflowException(
                        "Cannot allocate buffer to store index");
            } else {
                NativeRamBuffer[] oldBuffers = this.buffers;
                NativeRamBuffer[] newBuffers = Arrays.copyOf(oldBuffers,
                        oldBuffers.length + allocatedBuffers.length);
                System.arraycopy(allocatedBuffers, 0, newBuffers,
                        oldBuffers.length, allocatedBuffers.length);
                this.buffers = newBuffers;
                this.capacity = newBuffers.length * bufferPool.getChunkSize();
            }
        }
    }

    private void createHeadIndex() throws IOException {
        if (head == -1) {
            ensureCapacity(ENTRY_SIZE);
            int node = createNode(-1L, -1);
            head = createIndex(node, -1, -1, 1);
        }
    }

    private int calcPutSize(int level) throws IOException {
        int size = ENTRY_SIZE; // node
        if (level > 0) {
            size += ENTRY_SIZE * level; // index
            int max = levelOf(head);
            if (level > max) {
                size += ENTRY_SIZE; // a new level need a new head index
            }
        }
        return size;
    }

    private void addIndex(int idx, int h, int indexLevel, KeyCell keyCell)
            throws IOException {
        int insertionLevel = indexLevel;
        int j = levelOf(h);
        int q = h;
        int r = rightOf(q, false);
        int t = idx;
        for (;;) {
            if (r != -1) {
                int n = nodeOf(r);
                if (comparator.compare(keyCell, lengthAndOffsetOf(n, false)) > 0) {
                    q = r;
                    r = rightOf(r, false);
                    continue;
                }
            }
            if (j == insertionLevel) {
                setRight(t, r, false);
                setRight(q, t, true);
                if (--insertionLevel == 0) {
                    return;
                }
            }
            if (--j >= insertionLevel && j < indexLevel) {
                t = downOf(t);
            }
            q = downOf(q);
            r = rightOf(q, false);
        }
    }

    private void insertIndex(int z, int level, KeyCell keyCell)
            throws IOException {
        int h = head;
        int max = levelOf(h);
        if (level <= max) {
            int idx = -1;
            for (int i = 1; i <= level; i++) {
                idx = createIndex(z, idx, -1, 0);
            }
            addIndex(idx, h, level, keyCell);
        } else {
            level = max + 1;
            int idx = -1;
            for (int i = 1; i <= level; i++) {
                idx = createIndex(z, idx, -1, 0);
            }
            int newHead = createIndex(nodeOf(h), h, -1, level);
            head = newHead;
            addIndex(idx, newHead, level, keyCell);
        }
    }

    // in put related methods, volatile read is not needed. At the time you 
    // link a node or a index into the skip list, the link operation should be
    // volatile, and if you modify a node's value, the modify operation should
    // be volatile.
    long put(long key) throws IOException {
        createHeadIndex();
        KeyCell keyCell = comparator.readKey(key);
        int b = findPredecessor(key, keyCell);
        int n = nextOf(b, false);
        while (n != -1) {
            int f = nextOf(n, false);
            long oldKey = lengthAndOffsetOf(n, false);
            int c = comparator.compare(keyCell, oldKey);
            if (c > 0) {
                b = n;
                n = f;
            } else if (c == 0) {
                setLengthAndOffset(n, key, true);
                return oldKey;
            } else {
                break;
            }
        }
        int level = randomLevel();
        ensureCapacity(calcPutSize(level));
        int z = createNode(key, n);
        setNext(b, z, true);
        if (level > 0) {
            insertIndex(z, level, keyCell);
        }
        entryCount++;
        return -1L;
    }

    // all read operation should use volatile read
    private int ceilingNode(ByteArrayWritable key, boolean accurate)
            throws IOException {
        KeyCell keyCell = comparator.getKey(key);
        int bound = -1;
        int q = head;
        int r = rightOf(q, true);
        int n;
        for (;;) {
            int d;
            if (r != -1 && (n = nodeOf(r)) != bound) {
                long lengthAndOffset = lengthAndOffsetOf(n, true);
                int c = comparator.compare(keyCell, lengthAndOffset);
                if (c > 0) {
                    q = r;
                    r = rightOf(r, true);
                    continue;
                } else if (c == 0) {
                    return n;
                } else {
                    bound = n;
                }
            }
            if ((d = downOf(q)) != -1) {
                q = d;
                r = rightOf(d, true);
            } else {
                break;
            }
        }
        for (n = nextOf(nodeOf(q), true); n != -1; n = nextOf(n, true)) {
            long lengthAndOffset = lengthAndOffsetOf(n, true);
            int c = comparator.compare(keyCell, lengthAndOffset);
            if (c == 0) {
                return n;
            } else if (c < 0) {
                if (accurate) {
                    return -1;
                } else {
                    return n;
                }
            }
        }
        return -1;
    }

    // all read operation should use volatile read
    long get(ByteArrayWritable key) throws IOException {
        if (head == -1) {
            return -1L;
        }
        int n = ceilingNode(key, true);
        if (n != -1) {
            return lengthAndOffsetOf(n, true);
        } else {
            return -1L;
        }
    }

    // all read operation should use volatile read
    int ceilingNode(ByteArrayWritable key) throws IOException {
        if (head == -1) {
            return -1;
        }
        if (key == null) {
            return nextOf(nodeOf(head), true);
        }
        return ceilingNode(key, false);
    }

    boolean isEmpty() {
        return head < 0;
    }

    int getEntryCount() {
        return entryCount;
    }

    KeyComparator getComparator() {
        return comparator;
    }

    int actualByteSize() {
        return writeOffset;
    }

    int getBufferSize() {
        return capacity;
    }

    @Override
    public void close() {
        bufferPool.releaseBuffer(buffers);
        buffers = null;
        head = -1;
        entryCount = 0;
    }
}
