/**
 * @(#)CatalogueLogTask.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import outfox.omap.master.AssignTabletTask;
import outfox.omap.walog.MetadataProvider;
import outfox.omap.walog.WALogBody;

/**
 * @author zhangduo
 */
public class CatalogueLogTask implements WALogBody {

    private long taskId;

    private boolean deleted;

    private AssignTabletTask task;

    public CatalogueLogTask() {}

    public CatalogueLogTask(long taskId, boolean deleted, AssignTabletTask task) {
        this.taskId = taskId;
        this.deleted = deleted;
        this.task = task;
    }

    public long getTaskId() {
        return taskId;
    }

    public void setTaskId(long taskId) {
        this.taskId = taskId;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public AssignTabletTask getTask() {
        return task;
    }

    public void setTask(AssignTabletTask task) {
        this.task = task;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        taskId = in.readLong();
        deleted = in.readBoolean();
        if (!deleted) {
            task = new AssignTabletTask();
            task.readFields(in);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(taskId);
        out.writeBoolean(deleted);
        if (!deleted) {
            task.writeFields(out);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        CatalogueLogTask v = (CatalogueLogTask) value;
        taskId = v.taskId;
        deleted = v.deleted;
        if (!deleted) {
            try {
                task = v.task.getClass().newInstance();
            } catch (InstantiationException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
            task.copyFields(v.task);
        }
        return this;
    }

    @Override
    public String toString() {
        return "CatalogueLogTask [taskId=" + taskId + ", deleted=" + deleted
                + ", task=" + task + "]";
    }

    @Override
    public String toStructuredString(MetadataProvider provider) {
        return toString();
    }

}
