/**
 * @(#)HashHelper.java, 2012-5-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;


/**
 * @author zhangduo
 */
class HashHelper {

    public static abstract class HashEntryBase<E extends HashEntryBase<E>> {
        protected final int hash;

        protected E next;

        public HashEntryBase(int hash) {
            this.hash = hash;
        }
    }

    public static int hash(int h) {
        h ^= (h >>> 20) ^ (h >>> 12);
        return h ^ (h >>> 7) ^ (h >>> 4);
    }

    public static int indexFor(int h, int length) {
        return h & (length - 1);
    }

    public static <E extends HashEntryBase<E>> void transfer(E[] oldTable,
            E[] newTable) {
        int newCapacity = newTable.length;
        for (E e: oldTable) {
            if (e != null) {
                do {
                    E next = e.next;
                    int i = indexFor(e.hash, newCapacity);
                    e.next = newTable[i];
                    newTable[i] = e;
                    e = next;
                } while (e != null);
            }
        }
    }
}
