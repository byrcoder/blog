/**
 * @(#)MasterGlobalStatisticType.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TimeRangeUtils;

/**
 * @author zhangduo
 */
public enum MasterGlobalStatisticType {

    GET_FS_NAME_COUNT(0),
    GET_FS_NAME_DELAY(GET_FS_NAME_COUNT.offset + 1),
    TIME_RANGE_GET_FS_NAME_COUNT(GET_FS_NAME_DELAY.offset + 1),

    GET_TABLES_COUNT(TIME_RANGE_GET_FS_NAME_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_TABLES_DELAY(GET_TABLES_COUNT.offset + 1),
    TIME_RANGE_GET_TABLES_COUNT(GET_TABLES_DELAY.offset + 1),

    GET_TABLES_IN_SPACE_COUNT(TIME_RANGE_GET_TABLES_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_TABLES_IN_SPACE_DELAY(GET_TABLES_IN_SPACE_COUNT.offset + 1),
    TIME_RANGE_GET_TABLES_IN_SPACE_COUNT(GET_TABLES_IN_SPACE_DELAY.offset + 1),
    
    GET_TABLESPACES_COUNT(TIME_RANGE_GET_TABLES_IN_SPACE_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_TABLESPACES_DELAY(GET_TABLESPACES_COUNT.offset + 1),
    TIME_RANGE_GET_TABLESPACES_COUNT(GET_TABLESPACES_DELAY.offset + 1),

    CREATE_TABLE_COUNT(TIME_RANGE_GET_TABLESPACES_COUNT.offset + TimeRangeUtils.rangeCount()),
    CREATE_TABLE_DELAY(CREATE_TABLE_COUNT.offset + 1),
    TIME_RANGE_CREATE_TABLE_COUNT(CREATE_TABLE_DELAY.offset + 1),

    DELETE_TABLE_COUNT(TIME_RANGE_CREATE_TABLE_COUNT.offset + TimeRangeUtils.rangeCount()),
    DELETE_TABLE_DELAY(DELETE_TABLE_COUNT.offset + 1),
    TIME_RANGE_DELETE_TABLE_COUNT(DELETE_TABLE_DELAY.offset + 1),

    SYSTEM_LOAD(TIME_RANGE_DELETE_TABLE_COUNT.offset + TimeRangeUtils.rangeCount()),
    SYSTEM_LOAD_PER_PROCESSOR(SYSTEM_LOAD.offset + 1),

    MEMORY_INIT(SYSTEM_LOAD_PER_PROCESSOR.offset + 1),
    MEMORY_USED(MEMORY_INIT.offset + 1),
    MEMORY_COMMITTED(MEMORY_USED.offset + 1),
    MEMORY_MAX(MEMORY_COMMITTED.offset + 1),

    REQUEST_COUNT(MEMORY_MAX.offset + 1),
    TIMEOUT_REQUEST_COUNT(REQUEST_COUNT.offset + 1),

    MAX_TYPE(TIMEOUT_REQUEST_COUNT.offset + 1);

    private final int offset;

    private MasterGlobalStatisticType(int offset) {
        this.offset = offset;
    }

    public int offset() {
        return offset;
    }

    public static int getTypeCount() {
        return MAX_TYPE.offset;
    }

}
