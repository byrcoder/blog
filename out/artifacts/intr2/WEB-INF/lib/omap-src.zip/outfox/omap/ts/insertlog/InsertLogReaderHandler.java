/**
 * @(#)InsertLogReaderHandler.java, 2010-9-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts.insertlog;

import java.io.IOException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import outfox.omap.walog.LogReaderHandler;
import outfox.omap.walog.WALogEntry;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public abstract class InsertLogReaderHandler implements LogReaderHandler {
    private static final Logger LOG = LogFormatter.getLogger(InsertLogEntry.class);

    protected LongLongHashMap checkpoints;

    protected InsertLogEntry entry;

    public InsertLogReaderHandler(LongLongHashMap checkpoints) {
        this.checkpoints = checkpoints;
        if (checkpoints == null) {
            LOG.info("No checkpoint found in log");
        } else {
            StringBuilder sb = new StringBuilder("[");
            Iterator<LongLongHashMap.Entry> iter = checkpoints.iterator();
            if (iter.hasNext()) {
                LongLongHashMap.Entry entry = iter.next();
                sb.append(entry.getKey()).append('=').append(entry.getValue());
            }
            while (iter.hasNext()) {
                LongLongHashMap.Entry entry = iter.next();
                sb.append(", ").append(entry.getKey()).append('=').append(
                        entry.getValue());
            }
            sb.append(']');
            LOG.info("Using checkpoint: " + sb.toString());
        }
    }

    @Override
    public void handle(WALogEntry entry) throws IOException {
        if (!(entry instanceof InsertLogEntry)) {
            LOG.log(Level.WARNING, entry.getClass() + " is not insert log");
            return;
        }
        this.entry = (InsertLogEntry) entry;
        if (entry.getLogType() == InsertLogEntry.TYPE_CHKPT) {
            handle((WALogChkPt) entry.getBody());
        } else if (entry.getLogType() == InsertLogEntry.TYPE_INSERT) {
            WALogInsert body = (WALogInsert) entry.getBody();
            if (!checkEntryByLastLSN(entry.getLSN(), body.getTabletId())) {
                return;
            }
            handle(body);
        } else if (entry.getLogType() == InsertLogEntry.TYPE_INDEX_INSERT) {
            WALogIndexInsert body = (WALogIndexInsert) entry.getBody();
            if (!checkEntryByLastLSN(entry.getLSN(), body.getTabletId())) {
                return;
            }
            handle(body);
        } else {
            Class<?> logBodyClass = entry.getBody() != null ? entry.getBody().getClass()
                    : null;
            LOG.severe("unknown log type: " + entry.getLogType()
                    + ", body class: " + logBodyClass + ", discarded");
        }
    }

    /**
     * Check whether the entry is useful by comparing entry's LSN with tablet checkpoint
     * @param entry
     * @return
     */
    protected boolean checkEntryByLastLSN(long entryLSN, long tabletId) {
        if (checkpoints == null) {
            return true;
        }
        long checkpointLSN = checkpoints.get(tabletId, -1);
        return entryLSN > checkpointLSN;
    }

    protected abstract void handle(WALogInsert body) throws IOException;

    protected abstract void handle(WALogIndexInsert body) throws IOException;

    protected abstract void handle(WALogChkPt body) throws IOException;

}
