/**
 * @(#)DispatchHandler.java, 2009-11-18. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.KeeperException.Code;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.handler.AbstractHandler;

import outfox.omap.conf.OmapConfig;
import outfox.omap.util.NoActionWatcher;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class DispatchHandler extends AbstractHandler {

    private static final Logger LOG = LogFormatter.getLogger(DispatchHandler.class);

    private ZooKeeper zk;

    public DispatchHandler() throws IOException {
        zk = new ZooKeeper(OmapConfig.getZkAddress(), 30000, new NoActionWatcher());
    }

    private void reInit() throws IOException {
        try {
            zk.close();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "close zookeeper failed", e);
        }
        zk = new ZooKeeper(OmapConfig.getZkAddress(), 30000, new NoActionWatcher());
    }

    @Override
    public void handle(String target, HttpServletRequest request,
            HttpServletResponse response, int dispatch) throws IOException,
            ServletException {
        try {
            byte[] data = zk.getData(OmapConfig.getZkActiveMasterPath(), null,
                    null);
            String host = new String(data, "UTF-8").split(":")[0];
            int port = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_MASTER_WEB_PORT,
                    OmapConfig.DEFAULT_MASTER_WEB_PORT);
            String redirectUrl = "http://" + host + "x.corp.youdao.com:" + port
                    + "/home.s";
            LOG.info("redirect to " + redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (KeeperException e) {
            if (e.code() == Code.SESSIONEXPIRED) {
                reInit();
            }
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doStop() throws Exception {
        zk.close();
        super.doStop();
    }

    public static void main(String[] args) throws Exception {
        int webPort = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_DISPATCHER_WEB_PORT,
                OmapConfig.DEFAULT_DISPATCHER_WEB_PORT);
        Server webServer = new Server(webPort);
        webServer.setHandler(new DispatchHandler());
        webServer.setStopAtShutdown(true);
        webServer.start();
        webServer.join();
    }

}
