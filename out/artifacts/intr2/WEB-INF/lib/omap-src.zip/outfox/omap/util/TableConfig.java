/**
 * @(#)Config.java, 2010-3-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import outfox.omap.metadata.TableDesc;

/**
 * Table Config from master
 * 
 * @see outfox.omap.common.ClientMasterProtocol#createImportedTable
 * @author wangfk
 */
public class TableConfig implements IWritable {
    public String path;

    public String fs;

    public TableDesc td;

    public long maxTabletSize;

    public long maxTabletRecords;

    public void readFields(DataInput in) throws IOException {
        path = in.readUTF();
        fs = in.readUTF();
        td.readFields(in);
        maxTabletSize = in.readLong();
        maxTabletRecords = in.readLong();
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(path);
        out.writeUTF(fs);
        td.writeFields(out);
        out.writeLong(maxTabletSize);
        out.writeLong(maxTabletRecords);
    }

    public IWritable copyFields(IWritable value) {
        path = ((TableConfig) value).path;
        fs = ((TableConfig) value).fs;
        td.copyFields(((TableConfig) value).td);
        maxTabletSize = ((TableConfig) value).maxTabletSize;
        maxTabletRecords = ((TableConfig) value).maxTabletRecords;
        return this;
    }

    public TableConfig(String fs, String path, TableDesc td,
            long maxTabletSize, long maxTabletRecords) {
        this.fs = fs;
        this.path = path;
        this.maxTabletSize = maxTabletSize;
        this.maxTabletRecords = maxTabletRecords;
        this.td = td;
    }

    public TableConfig() {
        td = new TableDesc();
    }
}
