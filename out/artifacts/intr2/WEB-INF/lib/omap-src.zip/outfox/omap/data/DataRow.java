/**
 * @(#)DataRow.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.exceptions.FieldNotInitializedException;
import outfox.omap.master.AssignTabletTask;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * Contains a data of a row. It maintains a KeyCell to store the key, and an
 * array of DataCell to store the cells except the key. TODO DataRow should not
 * implement IWritable, but now SSFileTable depends on that DataRow implements
 * IWritable, therefore SSFileTable must first be rewritten.
 * 
 * @author zhangkun
 */
public class DataRow implements IWritable, IPreInitializedWritable {

    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(DataRow.class);

    private boolean deleted = false;

    private KeyCell key;

    private DataCell[] values;

    public DataRow() {
        super();
    }

    public DataRow(KeyCell key, DataCell[] columns) {
        super();
        this.key = key;
        this.values = columns;
    }

    public KeyCell getKeyCell() {
        return this.key;
    }

    public int getInt(int index) {
        return getColumn(index).getInt();
    }

    @Deprecated
    public String getString(int index) {
        return getColumn(index).getString();
    }

    public String getText(int index) {
        return getColumn(index).getText();
    }

    public long getLong(int index) {
        return getColumn(index).getLong();
    }

    public boolean getBoolean(int index) {
        return getColumn(index).getBoolean();
    }

    public double getDouble(int index) {
        return getColumn(index).getDouble();
    }

    public TableDesc getTableDesc(int index) {
        return getColumn(index).getTableDesc();
    }

    public KeyPair getKeyPair(int index) {
        return getColumn(index).getKeyPair();
    }

    public void setValue(int index, int value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public void setValue(int index, long value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public void setValue(int index, boolean value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    @Deprecated
    public void setValue(int index, String value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public void setValueText(int index, String value) {
        this.deleted = false;
        getColumn(index).setValueText(value);
    }

    public void setValueFixLen(int index, byte[] value) {
        this.deleted = false;
        getColumn(index).setValueFixLen(value);
    }

    public void setValue(int index, TableDesc value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public void setValue(int index, KeyRange value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public void setValue(int index, KeyPair value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public void setValue(int index, AssignTabletTask value) {
        this.deleted = false;
        getColumn(index).setValue(value);
    }

    public IWritable getIWritable(int index) {
        return getColumn(index).getIWritable();
    }

    public void setIWritable(int index, IWritable value) {
        this.deleted = false;
        getColumn(index).setIWritable(value);
    }

    public void setCIWritable(int index, IWritable value) {
        this.deleted = false;
        getColumn(index).setCIWritable(value);
    }

    public void setNull(int index) {
        getColumn(index).setNull();
    }

    public void setInvalid(int index) {
        getColumn(index).setInvalid();
    }

    /**
     * copies a data row, overwritting only fields that are valid, ignoring
     * others
     * 
     * @param row
     */
    public void overWriteValid(DataRow val) {
        this.deleted = val.deleted;
        if (deleted) {
            return;
        }

        if (this.values == null) {
            this.values = new DataCell[val.values.length];
            for (int i = 0; i < val.values.length; i++) {
                this.values[i] = new DataCell();
            }
        }
        if (this.key == null) {
            this.key = new KeyCell();
        }
        this.key.copyFields(val.key);

        for (int i = 0; i < val.values.length; i++) {
            if (val.values[i].getStatus() != DataCell.STATUS_INVALID) {
                this.values[i].copyFields(val.values[i]);
            }
        }

    }

    // /// TODO implement other accessor for primitive types

    /*
     * IWritable Methods
     */

    public IWritable copyFields(IWritable value) {

        if (this == value) {
            throw new IllegalArgumentException("cannot copy from myself");
        }
        DataRow val = (DataRow) value;

        this.deleted = val.deleted;
        if (this.key == null) {
            this.key = new KeyCell();
        }
        if (val.key != null) {
            this.key.copyFields(val.key);
        }

        if (deleted) {
            return this;
        }

        if (this.values == null) {
            this.values = new DataCell[val.values.length];
            for (int i = 0; i < val.values.length; i++) {
                this.values[i] = new DataCell();
            }
        }

        for (int i = 0; i < val.values.length; i++) {
            this.values[i].copyFields(val.values[i]);
        }
        return this;
    }

    public void readFields(DataInput in) throws IOException {

        this.deleted = (in.readByte() == 1);
        if (this.key == null) {
            this.key = new KeyCell();
        }
        this.key.readFields(in);
        if (deleted) {
            return;
        }
        int valueCount = in.readInt();
        if (values == null) {
            values = new DataCell[valueCount];
        }
        for (int i = 0; i < values.length; i++) {
            this.values[i] = new DataCell();
            this.values[i].readFields(in);
        }

    }

    public void writeFields(DataOutput out) throws IOException {

        out.writeByte(this.deleted ? 1 : 0);
        this.key.writeFields(out);
        if (deleted)
            return;
        out.writeInt(values.length);
        for (int i = 0; i < values.length; i++) {
            this.values[i].writeFields(out);
        }

    }

    @Override
    public int hashCode() {
        int result = deleted ? 1231 : 1237;
        if (key != null) {
            result ^= key.hashCode();
        }
        if (deleted || values == null) {
            return result;
        }
        return result ^ Arrays.hashCode(values);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        DataRow v = (DataRow) obj;
        if (this.deleted != v.deleted) {
            return false;
        }
        if (this.key == null) {
            if (v.key != null) {
                return false;
            }
        } else {
            if (v.key == null) {
                return false;
            }
            if (!this.key.equals(v.key)) {
                return false;
            }
        }
        if (this.deleted) {
            return true;
        }
        if (this.values == null) {
            if (v.values != null) {
                return false;
            }
        } else {
            if (v.values == null) {
                return false;
            }
            for (int i = 0; i < values.length; i++) {
                if (!this.values[i].equals(v.values[i])) {
                    return false;
                }
            }
        }
        return true;
    }

    /*
     * trivial getter/ setters
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append('[').append(key).append("]->");
        if (this.deleted) {
            sb.append("<<DELETED>>");
        } else {
            for (int i = 0; i < this.values.length; i++) {
                if (values[i] != null) {
                    sb.append("[").append(values[i].toString()).append("] ");
                } else {
                    sb.append("[").append("null-column").append("] ");
                }
            }
        }
        return sb.toString();
    }

    /**
     * @return a single array containing all key (at position 0) and values
     */
    public DataCell[] getColumns() {
        DataCell[] ret = new DataCell[this.values.length + 1];
        ret[0] = this.key;
        for (int i = 1; i < ret.length; i++) {
            ret[i] = this.values[i - 1];
        }
        return ret;
    }

    // return everything except for the key
    public DataCell[] getValues() {
        return this.values;
    }

    public DataCell getColumn(int i) {
        if (i == 0) {
            return this.key;
        } else {
            return this.values[i - 1]; // 0 is the key cell
        }
    }

    public boolean isDeleted() {
        return this.deleted;
    }

    public void setDeleted() {
        this.deleted = true;
    }

    public void setKeyCell_ncp(KeyCell key) {
        this.key = key;
    }

    public void setKeyCell(KeyCell key) {
        if (key != this.key) {
            this.key.copyFields(key);
        } else {
            ; // do nothing
        }
    }

    public void readPIFields(DataInput in) throws IOException {
        if (key == null) {
            throw new FieldNotInitializedException("key is null");
        }
        this.deleted = (in.readByte() == 1);
        this.key.readPIFields(in);
        if (deleted)
            return;
        if (values == null) {
            throw new FieldNotInitializedException("values is null");
        }
        for (int i = 0; i < values.length; i++) {
            this.values[i].readPIFields(in);
        }
    }

    public void writePIFields(DataOutput out) throws IOException {
        out.writeByte(this.deleted ? 1 : 0);
        this.key.writePIFields(out);
        if (deleted)
            return;
        for (int i = 0; i < values.length; i++) {
            this.values[i].writePIFields(out);
        }
    }

    public static boolean isDeleted(ByteArrayWritable row) {
        return row.data()[0] == 1;
    }

    public boolean hasInvalidCell() {
        for (int i = 0; i < getColumns().length; i++) {
            if (getColumn(i).getStatus() == DataCell.STATUS_INVALID) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasInvalidCell(TableDesc desc, ByteArrayWritable row) {
        DataRow dataRow = desc.borrowDataRow();
        OmapUtils.convertBytesToPIWritable(row.data(), dataRow);
        boolean isOverWrite = dataRow.hasInvalidCell();
        desc.returnDataRow(dataRow);
        return isOverWrite;
    }

    /**
     * Create a row (represented by a byte[]) marked as deleted, with the given
     * KeyCell (also represented by a ByteArrayWritable). The returned byte[] is
     * compatible with {@link #writePIFields(DataOutput)}.
     * 
     * @param key
     * @return
     */
    public static byte[] createDeletedRow(ByteArrayWritable key) {
        return createDeletedRow(key.data(), 0, key.size());
    }

    public static byte[] createDeletedRow(byte[] key) {
        return createDeletedRow(key, 0, key.length);
    }

    public static byte[] createDeletedRow(byte[] key, int off, int len) {
        byte[] row = new byte[len + 1];
        row[0] = 1;
        System.arraycopy(key, off, row, 1, len);
        return row;
    }

    /**
     * Read the row from the given byte[] to the DataRow, by using
     * {@link #readPIFields(DataInput)}.
     * 
     * @param row
     * @param data
     */
    public static void dataRowFromBinaryRow(DataRow row, byte[] data) {
        dataRowFromBinaryRow(row, data, 0, data.length);
    }

    /**
     * Read the row from the given byte[] to the DataRow, by using
     * {@link #readPIFields(DataInput)}.
     * 
     * @param row
     * @param data
     */
    public static void dataRowFromBinaryRow(DataRow row, byte[] data,
            int offset, int length) {
        OmapUtils.convertBytesToPIWritable(data, offset, length, row);
    }

    /**
     * Read and fill the KeyCell from a byte array representing a DataRow. The
     * byte array is got by calling
     * {@link outfox.omap.data.DataRow#writePIFields(java.io.DataOutput)}.
     * 
     * @param key
     * @param row
     */
    public static void keyCellFromBinaryRow(KeyCell key, byte[] row) {
        keyCellFromBinaryRow(key, row, 0, row.length);

    }

    public static void keyCellFromBinaryRow(KeyCell key, byte[] row,
            int offset, int length) {
        OmapUtils.convertBytesToPIWritable(row, offset + 1, length - 1, key);
    }

    /**
     * From the row's bytes, exclude the key's bytes and put the rest to the
     * output ByteArrayWritable.
     * 
     * @param keyBytes
     * @param rowBytes
     * @param output
     * @see #combineKeyAndNonKeyBytes(ByteArrayWritable, ByteArrayWritable,
     *      ByteArrayWritable)
     */
    public static void getNonKeyBytes(ByteArrayWritable keyBytes,
            ByteArrayWritable rowBytes, ByteArrayWritable output) {
        int nonKeyPartLength = rowBytes.size() - keyBytes.size();
        byte[] buffer = output.data();
        if (buffer.length < nonKeyPartLength) {
            buffer = new byte[nonKeyPartLength];
        }
        // don't include the key in the value. only the delete flag and the
        // non-key fields
        buffer[0] = rowBytes.getByte(0);
        System.arraycopy(rowBytes.data(), 1 + keyBytes.size(), buffer, 1,
                nonKeyPartLength - 1);
        output.setBuffer(buffer, nonKeyPartLength);
    }

    /**
     * Combine the key's bytes and the non-key's bytes into a whole row's bytes.
     * 
     * @param keyBytes
     * @param nonKeyBytes
     * @param outputRow
     * @see #getNonKeyBytes(ByteArrayWritable, ByteArrayWritable,
     *      ByteArrayWritable)
     */
    public static void combineKeyAndNonKeyBytes(ByteArrayWritable keyBytes,
            ByteArrayWritable nonKeyBytes, ByteArrayWritable outputRow) {
        int totalLength = keyBytes.size() + nonKeyBytes.size();
        byte[] totalBuffer = outputRow.data();
        if (totalBuffer == null || totalBuffer.length < totalLength) {
            totalBuffer = new byte[totalLength];
        }
        totalBuffer[0] = nonKeyBytes.getByte(0);
        System.arraycopy(keyBytes.data(), 0, totalBuffer, 1, keyBytes.size());
        System.arraycopy(nonKeyBytes.data(), 1, totalBuffer,
                1 + keyBytes.size(), nonKeyBytes.size() - 1);
        outputRow.setBuffer(totalBuffer, totalLength);
    }
}
