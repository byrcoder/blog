/**
 * @(#)WaitUtils.java, 2011-1-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class WaitUtils {

    private static final Logger LOG = LogFormatter.getLogger(WaitUtils.class);

    private static int[] powers = {
        1, 2, 4, 8, 16, 32, 64, 128, 256
    };

    public static int getExpWaitTime(int retryCount, Random rand) {
        int salt = rand.nextInt(100);
        if (retryCount < powers.length)
            return 50 * powers[retryCount] + salt;
        else
            return 50 * powers[powers.length - 1] + salt;
    }

    public static void sleep(long waitTime) throws InterruptedException {
        if (waitTime <= 0) {
            return;
        }
        Thread.sleep(waitTime);
    }

    public static void sleepIgnoreInterrupt(long waitTime) {
        if (waitTime <= 0) {
            return;
        }
        try {
            Thread.sleep(waitTime);
        } catch (InterruptedException e) {
            LOG.log(Level.WARNING, "sleep interrupted", e);
        }
    }

    public static long getGaussianWaitTime(long maxWaitTime, Random rand) {
        if (maxWaitTime <= 0) {
            return 0;
        }
        long toWait = (long) (maxWaitTime + maxWaitTime * rand.nextGaussian()
                / 4);
        toWait = toWait > 0 ? toWait : 0;
        toWait = toWait < maxWaitTime ? toWait : maxWaitTime;
        return toWait;
    }
}
