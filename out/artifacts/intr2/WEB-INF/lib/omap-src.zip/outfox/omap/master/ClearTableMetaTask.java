/**
 * @(#)ClearTableMetaTask.java, 2010-3-15. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import outfox.omap.ts.OmapTs;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class ClearTableMetaTask extends Task {
    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(ClearTableMetaTask.class);

    private long schemaId;

    private String tableName;

    public ClearTableMetaTask() {}

    public ClearTableMetaTask(long schemaId, String tableName, String reason) {
        super(reason);
        this.schemaId = schemaId;
        this.tableName = tableName;
    }

    public long getSchemaId() {
        return schemaId;
    }

    public String getTableName() {
        return tableName;
    }

    @Override
    public int execTask(OmapTs ts) {
        ts.getMetaCache().clearMetadata(schemaId, true);
        return 0;
    }

    @Override
    public String getTaskDetail() {
        return "CLEAR META: " + HexString.longToPaddedHex(schemaId) + " "
                + tableName;
    }

    @Override
    public void rollbackTask(OmapTs ts) {
        // nothing
    }

    @Override
    public IWritable copyFields(IWritable value) {
        ClearTableMetaTask task = (ClearTableMetaTask) value;
        schemaId = task.schemaId;
        tableName = task.tableName;
        return super.copyFields(value);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        schemaId = in.readLong();
        tableName = StringWritable.readString(in);
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        out.writeLong(schemaId);
        StringWritable.writeString(out, tableName);
    }

}
