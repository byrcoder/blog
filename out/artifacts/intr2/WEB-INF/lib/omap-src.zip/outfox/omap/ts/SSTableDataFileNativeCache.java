/**
 * @(#)SSTableDataFileNativeCache.java, 2011-10-12. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.file.SequenceFile.Reader;
import odis.io.FSDataInputStream;
import odis.io.IFileSystem;
import odis.io.Path;

import outfox.omap.conf.OmapConfig;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * Cache the whole sstable file for read performance optimization
 *
 * @author wangfk
 *
 */
public class SSTableDataFileNativeCache {
    private static final Logger LOG = LogFormatter.getLogger(SSTableDataFileNativeCache.class);

    static final long REMOVE_DELAY_TIME_IN_MILLI = 60L * 1000;

    private long maxCacheSize =
        OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_TS_MAX_SSTABLE_NATIVE_CACHE_SIZE,
                OmapConfig.DEFAULT_TS_MAX_SSTABLE_NATIVE_CACHE_SIZE);
    private int maxLoadConcurrency =
        OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_SSTABLE_NATIVE_CACHE_LOAD_CONCURRENCY,
                OmapConfig.DEFAULT_TS_SSTABLE_NATIVE_CACHE_LOAD_CONCURRENCY);

    private ScheduledThreadPoolExecutor backgroundtaskpool;

    private final IFileSystem dfs;

    final HashMap<Path, NRFInputStreamContainer> nativeStreamCache =
        new HashMap<Path, NRFInputStreamContainer>();
    private volatile long currentCacheSize = 0;
    private final ThreadPoolExecutor dataLoaderPool = new ThreadPoolExecutor(
            maxLoadConcurrency, maxLoadConcurrency, 60 * 1000, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<Runnable>());

    public SSTableDataFileNativeCache(IFileSystem dfs,
            ScheduledThreadPoolExecutor backgroundtaskpool) {
        this.dfs = dfs;
        this.backgroundtaskpool = backgroundtaskpool;
    }

    public SequenceFile.Reader getSequenceFileReader(Path dataPath,
            long dataSize) throws IOException {
        synchronized (nativeStreamCache) {
            if(!nativeStreamCache.containsKey(dataPath)) {
                if(currentCacheSize + dataSize <= maxCacheSize) {
                    nativeStreamCache.put(dataPath,
                            new NRFInputStreamContainer(dataPath, dataSize));
                    currentCacheSize += dataSize;
                }
            } else {
                Reader sequenceFileReader = nativeStreamCache.get(dataPath)
                        .createSequenceFileReader();
                return sequenceFileReader;
            }
        }
        return null;
    }

    public long getMaxCacheSize() {
        return maxCacheSize;
    }

    public long getCurrentCacheSize() {
        return currentCacheSize;
    }

    public void releaseCache(Path path) {
        // use toRemove to avoid lock the nativeStreamCache for too long time
        ArrayList<NRFInputStreamContainer> toRemove =
            new ArrayList<NRFInputStreamContainer>();
        synchronized (nativeStreamCache) {
            for(Path p : nativeStreamCache.keySet()) {
                if (isSubPath(path, p)) {
                    toRemove.add(nativeStreamCache.get(p));
                }
            }
        }

        //remove by fine-grain lock
        for (NRFInputStreamContainer container : toRemove) {
            OmapUtils.safeClose(container);
        }
    }

    private boolean isSubPath(Path parent, Path child) {
        while(child != null) {
            if(parent.equals(child)) {
                return true;
            }
            child = child.getParentFile();
        }
        return false;
    }

    class NRFInputStreamContainer implements Runnable, Closeable{
        Path dataPath;
        long dataSize;

        SafeNativeRamFile nrFile;
        AtomicBoolean loadingFlag = new AtomicBoolean(true);

        public NRFInputStreamContainer(Path dataPath, long dataSize) {
            this.dataPath = dataPath;
            this.dataSize = dataSize;
            dataLoaderPool.execute(this);
        }

        public synchronized SequenceFile.Reader createSequenceFileReader(
                ) throws IOException {
            if(loadingFlag.get() || nrFile == null) {
                return null;
            }
            return new SequenceFile.Reader(dfs, dataPath,
                    new FSDataInputStream(new NativeRamFileInputStream(nrFile)));
        }

        @Override
        public synchronized void close() {
            if(loadingFlag.getAndSet(false)) {
                return;
            }

            if(nrFile != null) {
                try {
                    nrFile.close();
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "close native file failed", t);
                }
                currentCacheSize -= dataSize;
                nrFile = null;
            }
            LOG.info("Remove sstable data file from native cache, path="
                    + dataPath + ", dataSize=" + dataSize);

            // Remove asynchronously after a delay time,
            // to avoid to be reloaded by other thread immediately
            backgroundtaskpool.schedule(new Runnable() {

                @Override
                public void run() {
                    synchronized (nativeStreamCache) {
                        nativeStreamCache.remove(dataPath);
                    }
                }
            }, REMOVE_DELAY_TIME_IN_MILLI, TimeUnit.MILLISECONDS);
        }

        @Override
        public void run() {
            if(!loadingFlag.get()) {
                return;
            }

            boolean successful = false;
            FSDataInputStream fsDis = null;
            try {
                if(!loadingFlag.get()) {
                    return;
                }

                LOG.info("Start to load sstable data file to native cache," +
                                " path=" + dataPath + ", dataSize=" + dataSize);
                byte[] buffer = new byte[1024];
                nrFile = new SafeNativeRamFile();
                fsDis = OmapUtils.createFSDataInputStream(dfs, dataPath, false);
                int readLen = -1;
                while(loadingFlag.get() && (readLen = fsDis.read(buffer)) != -1) {
                    nrFile.write(buffer, 0, readLen);
                }
                if(loadingFlag.get()) {
                    successful = true;
                    LOG.info("Finish loading sstable data file to native cache," +
                                " path=" + dataPath + ", dataSize=" + dataSize);
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, 
                        "Fail to load sstable to native memory cache: path=" + dataPath, t);
            } finally {
                if(fsDis != null) {
                    OmapUtils.safeClose(fsDis);
                }
                if(!loadingFlag.getAndSet(false) || !successful) {
                    close();
                }
            }
        }

        @Override
        public String toString() {
            return "[NRFInputStreamContainer path=" + dataPath + ", size=" + dataSize + "]";
        }
    }
}
