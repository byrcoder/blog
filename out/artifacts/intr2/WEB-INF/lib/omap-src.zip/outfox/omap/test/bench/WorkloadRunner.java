package outfox.omap.test.bench;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.StringWritable;
import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.common.TsDesc;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.exceptions.OmapException;
import outfox.omap.test.bench.Recorder.ResultType;
import outfox.omap.ts.SSTableWriter;
import outfox.omap.ts.Tablet;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.TableConfig;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * Runs a workload, simulating a single application that uses Omap. A workload
 * consists of several reading threads and writing threads working
 * simultaneously. A {@link WorkloadConfig} defines the characteristics of a
 * workload's read and write operations.
 * 
 * @author zhangkun
 */
public class WorkloadRunner {
    private static final Logger LOG = LogFormatter.getLogger(WorkloadRunner.class);

    private static final int DEFAULT_EXPECTED_ELEMENTS = 1000000;

    final WorkloadConfig workload;

    final KeyGenerator keyGen;

    final Recorder recorder;

    final OmapBench bench;

    final Random rand = new Random(0);

    static final Class<? extends IWritableComparable> keyClass = StringWritable.class;

    static final Class<? extends IWritable> valueClass = ByteArrayWritable.class;

    static enum AccessType {
        READ, WRITE
    }

    static interface DataFeeder {
        public Class<? extends IWritableComparable> keyClass();

        public Class<? extends IWritable> valueClass();

        public boolean nextRecord(IWritableComparable key, IWritable value)
                throws IOException;
    }

    WorkloadRunner(WorkloadConfig workload, OmapBench bench) throws IOException {
        this.workload = workload;
        this.keyGen = new KeyGenerator(workload.initialNumRecords,
                workload.maxWrittenKeysRecord, workload.readNewRowOnly);
        this.bench = bench;
        this.recorder = new Recorder(bench.fs, new Path(bench.outputDir,
                workload.tableName), workload);
    }

    @Override
    public String toString() {
        return "[WorkloadRunner workload=" + workload + "]";
    }

    private class InitialDataFeeder implements DataFeeder {
        private int i = 0;

        private final ByteArrayWritable value;

        private final StringWritable key = new StringWritable();

        byte[] bytes = new byte[workload.valueSize];

        InitialDataFeeder() {
            if (workload.compressType != CompressType.NULL) {
                rand.nextBytes(bytes);
            }
            value = new ByteArrayWritable(bytes);
        }

        @Override
        public Class<? extends IWritableComparable> keyClass() {
            return keyClass;
        }

        @Override
        public Class<? extends IWritable> valueClass() {
            return valueClass;
        }

        @Override
        public boolean nextRecord(IWritableComparable key, IWritable value)
                throws IOException {
            if (i >= workload.initialNumRecords) {
                return false;
            }
            this.key.set(keyGen.getExistingKey(i, false));
            key.copyFields(this.key);
            if (workload.compressType != CompressType.NULL) {
                rand.nextBytes(bytes);
            }
            this.value.set(bytes);
            value.copyFields(this.value);
            i++;
            return true;
        }

    }

    public void prepareInitialEnvironment() throws Exception {
        LOG.info("Preparing initial environment for " + workload);
        if (workload.tableSpace.findTable(workload.tableName) != null) {
            if (workload.continueOnExistTable) {
                LOG.info("Table " + workload.tableName
                        + " exists, bench will continue on this table.");
                LOG.info(this + ": prepared");
                return;
            }
            LOG.info("Table " + workload.tableName + " exists, deleting it");
            workload.tableSpace.deleteTable(workload.tableName);
        }
        FileSystem fs = FileSystem.getNamed(workload.master.getFsName());
        Path snapshotDir = new Path("/omapbench/initial-snapshots/",
                workload.getInitialEnvironmentSig());
        if (fs.exists(snapshotDir)) {
            LOG.info("Found matching snapshot in " + snapshotDir
                    + ", importing it");
            workload.tableSpace.importSnapshot(workload.tableName,
                    snapshotDir.toString());
        } else {
            LOG.info("Not found any matching snapshot, writing initial data");
            importFromFeeder(new InitialDataFeeder(),
                    workload.tableSpace.getName(), workload.tableName,
                    workload.master, true, workload.compressType);
            if (workload.createSnapshot) {
                // Snapshot the initial data, so that next time I can directly import it
                workload.tableSpace.snapshot(workload.tableName,
                        snapshotDir.toString(), false);
            }
        }
        LOG.info(this + ": prepared");
    }

    private ThreadManager readThreadManager;

    private ThreadManager writeThreadManager;

    /**
     * Start workload
     */
    public void start() throws Exception {
        if (readThreadManager != null) {
            throw new IllegalStateException("already started");
        }
        readThreadManager = new ThreadManager(AccessType.READ,
                workload.readFlowController);
        writeThreadManager = new ThreadManager(AccessType.WRITE,
                workload.writeFlowController);
        workload.terminationCondition.initialize(this);
        // Let FlowControllers, which will start WorkThreads through ThreadManager
        workload.readFlowController.manipulate(readThreadManager);
        workload.writeFlowController.manipulate(writeThreadManager);
    }

    private boolean stopped = false;

    /**
     * Stop workload
     * 
     * @param stopBench
     *            also stop the whole bench
     */
    public void stop(boolean stopBench) throws IOException {
        if (stopped) {
            return;
        }
        LOG.info(this + ": stopping");
        readThreadManager.closeAllThreads();
        writeThreadManager.closeAllThreads();
        recorder.close();
        stopped = true;
        if (stopBench) {
            LOG.info(this + ": stopping bench");
            bench.stop();
        }
    }

    class ThreadManager {
        private final ArrayList<WorkThread> threads = new ArrayList<WorkThread>();

        final AccessType accessType;

        final FlowController flowController;

        final Table table;

        ThreadManager(AccessType accessType, FlowController flowController)
                throws OmapException {
            this.accessType = accessType;
            this.flowController = flowController;
            long timeout = 0;
            switch (accessType) {
                case READ:
                    timeout = workload.readTimeout;
                    break;
                case WRITE:
                    timeout = workload.writeTimeout;
                    break;
            }
            table = workload.tableSpace.openTable(workload.tableName, timeout);
            if (workload.compressType != CompressType.NULL) {
                table.setProperty(Table.Property.COMPRESS_NAME,
                        CompressType.toString(workload.compressType));
            }
        }

        synchronized void addThread(int n) {
            for (int i = 0; i < n; i++) {
                WorkThread t = new WorkThread(accessType);
                threads.add(t);
                t.start();
            }
            LOG.info(accessType + " threads of " + workload.tableName
                    + " added by " + n + ", current: " + threads.size());
        }

        synchronized int getNumThreads() {
            return threads.size();
        }

        synchronized void reduceThread(int n) {
            if (n > threads.size()) {
                n = threads.size();
            }
            for (int i = 0; i < n; i++) {
                WorkThread t = threads.remove(threads.size() - 1);
                t.terminate();
            }
            LOG.info(accessType + " threads of " + workload.tableName
                    + " reduced by " + n + ", current: " + threads.size());
        }

        synchronized void closeAllThreads() {
            reduceThread(threads.size());
        }

        private synchronized void threadDead(WorkThread thread) {
            threads.remove(thread);
        }

        private class WorkThread extends Thread {
            final AccessType accessType;

            boolean stopped = false;

            WorkThread(AccessType accessType) {
                this.accessType = accessType;

            }

            void terminate() {
                stopped = true;
                interrupt();
            }

            @Override
            public void run() {
                try {
                    StringWritable key = new StringWritable();
                    byte[] bytes = new byte[workload.valueSize];
                    if (workload.compressType != CompressType.NULL) {
                        rand.nextBytes(bytes);
                    }
                    ByteArrayWritable value = new ByteArrayWritable(bytes);
                    Row row = table.newRow();
                    TableCursor tableCursor = table.getTableCursor();
                    tableCursor.setPrefetch(9);
                    while (!stopped) {
                        long startTime = System.currentTimeMillis();
                        ResultType resultType = ResultType.OTHER;
                        try {
                            switch (accessType) {
                                case READ:
                                    key.set(keyGen.getWorkloadKey(
                                            workload.readHitRate, true));
                                    if (workload.testCursor) {
                                        boolean found = tableCursor.moveTo(key,
                                                true);
                                        if (!found) {
                                            resultType = ResultType.READ_MISS;
                                            break;
                                        }
                                        int i = 0;
                                        int cursorSize = rand.nextInt(21);
                                        while (tableCursor.next(row)
                                                && i < cursorSize) {
                                            ++i;
                                        }
                                        if (i == cursorSize) {
                                            resultType = ResultType.READ_HIT;
                                        } else {
                                            //may misjudge if reach the real end
                                            resultType = ResultType.READ_MISS;
                                        }
                                    } else {
                                        boolean found = table.lookup(key, row);
                                        if (found) {
                                            resultType = ResultType.READ_HIT;
                                        } else {
                                            resultType = ResultType.READ_MISS;
                                        }
                                        break;
                                    }
                                case WRITE:
                                    String workloadKey = keyGen.getWorkloadKey(
                                            workload.overwriteRate, false);
                                    key.set(workloadKey);
                                    row.setKey(key);
                                    if (workload.compressType != CompressType.NULL) {
                                        rand.nextBytes(bytes);
                                    }
                                    value.set(bytes);
                                    row.set(1, value);
                                    table.update(row);
                                    keyGen.doneWorkloadKey(workloadKey);
                                    break;
                            }
                        } catch (Exception e) {
                            LOG.log(Level.WARNING, "Exception from OMap", e);
                            resultType = ResultType.ERROR;
                        }
                        recorder.record(accessType, resultType,
                                System.currentTimeMillis() - startTime);
                        if (resultType == ResultType.READ_MISS) {
                            recorder.recordReadMiss(key.get());
                        }
                        flowController.doneAnOperation(WorkloadRunner.this);
                    }
                } catch (Exception e) {
                    if (!stopped) {
                        LOG.log(Level.WARNING, "WorkThread got Exception", e);
                        threadDead(this);
                    }
                }
            }
        }
    }

    public static void importFromFeeder(DataFeeder source, String tableSpace,
            String tableName, ClientMasterProtocol master,
            boolean waitForTabletsAssigned, CompressType compressType)
            throws IOException, OmapException {
        Class<? extends IWritableComparable> keyClass = source.keyClass();
        Class<? extends IWritable> valueClass = source.valueClass();

        // create an empty Table
        IWritableComparable key;
        IWritable value;
        try {
            key = keyClass.newInstance();
            value = valueClass.newInstance();
        } catch (Exception e) {
            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            } else {
                throw new RuntimeException(e);
            }
        }

        String colNames = "key; value";
        String colTypes = keyClass.getName() + "; " + valueClass.getName();
        TableConfig config = master.createImportedTable(
                OmapUtils.toInternalTableName(tableSpace, tableName), colNames,
                colTypes, null);

        long totalSize = 0;
        long totalRecords = 0;
        long tabletSize = 0;
        long tabletRecords = 0;
        long tabletId = OmapUtils.minTabletId(config.td.getSchemaId());
        FileSystem outputFs = FileSystem.getNamed(config.fs);
        SSTableWriter writer = null;
        DataRow row = config.td.createDataRow();
        ByteArrayWritable keyw = new ByteArrayWritable();
        ByteArrayWritable roww = new ByteArrayWritable();
        ArrayList<KeyRange> tablets = new ArrayList<KeyRange>();
        IWritableComparable startKey = null;
        while (true) {
            boolean hasNext = source.nextRecord(key, value);
            if (!hasNext || writer == null
                    || tabletSize >= config.maxTabletSize / 2
                    || tabletRecords + 1 >= config.maxTabletRecords) {
                if (writer != null) {
                    IWritableComparable endKey;
                    if (hasNext) {
                        endKey = key;
                    } else {
                        endKey = KeyPair.MAX_WRITABLE;
                    }
                    LOG.info("Done writing Tablet "
                            + HexString.longToPaddedHex(tabletId) + ", rows="
                            + tabletRecords + ", size=" + tabletSize
                            + ", startKey=" + startKey + ", endKey=" + endKey);
                    writer.close();
                    KeyRange keyRange = new KeyRange(startKey, endKey,
                            TsDesc.getDummyTsDesc(), tabletId);

                    tablets.add(keyRange);
                    if (startKey == null) {
                        try {
                            startKey = keyClass.newInstance();
                        } catch (Exception e) {
                            if (e instanceof RuntimeException) {
                                throw (RuntimeException) e;
                            } else {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                    startKey.copyFields(key);
                }
                if (!hasNext) {
                    break;
                }
                tabletId++;
                LOG.info("New Tablet: " + HexString.longToPaddedHex(tabletId));
                tabletSize = 0;
                tabletRecords = 0;

                writer = new SSTableWriter(outputFs, new Path(
                        OmapUtils.getSSTableFileDirPath(config.path, tabletId)
                                + "/" + Tablet.SS_PREFIX + "1"),
                        DEFAULT_EXPECTED_ELEMENTS, compressType);
            }
            row.getKeyCell().setIWritable(key);
            row.getColumn(1).setIWritable(value);
            keyw.set(OmapUtils.convertPIWritableToBytes(row.getKeyCell()));
            roww.set(OmapUtils.convertPIWritableToBytes(row));
            writer.write(keyw, roww);
            totalRecords++;
            tabletRecords++;
            long sizeDelta = writer.getSize() - tabletSize;
            tabletSize += sizeDelta;
            totalSize += sizeDelta;
        }
        LOG.info("Done writing SSTableFiles, written " + totalRecords
                + " rows, total size=" + totalSize);

        // create and assign Tablets
        master.assignTabletsForImportedTable(config.td.getSchemaId(),
                tablets.toArray(new KeyRange[tablets.size()]),
                waitForTabletsAssigned);
        LOG.info("Succesfully imported data from " + source + " to "
                + config.td);
    }
}
