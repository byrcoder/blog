/**
 * @(#)TsMasterProtocol.java, 2011-1-12. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap;

import odis.rpc2.RpcException;
import outfox.omap.common.TsDesc;
import outfox.omap.exceptions.OmapTaskException;
import outfox.omap.master.Task;
import outfox.omap.ts.TsUsageReport;

/**
 * protocol that TS is using to communicate with master.<br>
 * we let TsMasterProtocol extends ClientMasterProtocol for that TS update index
 * may get metadata and keyrange list from master.
 */
public interface TsMasterProtocol extends ClientMasterProtocol {

    public Task[] tsHeartbeat(TsUsageReport usage) throws RpcException;

    public Task[] tsTaskDone(Task task, TsDesc ts) throws RpcException,
            OmapTaskException;

    public Task requestSplit(long tabletId, TsDesc tsDesc) throws RpcException;
}
