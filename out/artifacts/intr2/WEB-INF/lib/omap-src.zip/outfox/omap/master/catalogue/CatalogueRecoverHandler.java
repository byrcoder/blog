/**
 * @(#)CatalogueRecoverHandler.java, 2010-8-30. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.IOException;
import java.util.logging.Logger;

import odis.serialize.lib.LongWritable;
import outfox.omap.client.OmapMetadata;
import outfox.omap.common.TsDesc;
import outfox.omap.data.KeyRange;
import outfox.omap.master.AssignTabletTask;
import outfox.omap.walog.LogReaderHandler;
import outfox.omap.walog.WALogEntry;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class CatalogueRecoverHandler implements LogReaderHandler {

    private static final Logger LOG = LogFormatter.getLogger(CatalogueRecoverHandler.class);

    private Store<LongWritable, OmapMetadata> metaStore;

    private Store<SchemaIdAndRange, TsDesc> rangeStore;

    private Store<LongWritable, AssignTabletTask> taskStore;

    public CatalogueRecoverHandler(Store<LongWritable, OmapMetadata> metaStore,
            Store<SchemaIdAndRange, TsDesc> rangeStore,
            Store<LongWritable, AssignTabletTask> taskStore) {
        this.metaStore = metaStore;
        this.rangeStore = rangeStore;
        this.taskStore = taskStore;
    }

    @Override
    public void done() throws IOException {}

    @Override
    public void fail() throws IOException {}

    private void handlerSchema(CatalogueLogSchema body) {
        if (body.isDeleted()) {
            metaStore.delete(new LongWritable(body.getSchemaId()));
        } else {
            metaStore.add(new LongWritable(body.getSchemaId()),
                    body.getMetadata());
        }
    }

    private void handleRange(CatalogueLogRange body) {
        SchemaIdAndRange[] ranges = body.getRanges();
        boolean[] deleted = body.getDeleted();
        TsDesc[] tsDescs = body.getTsDescs();
        for (int i = 0; i < ranges.length; i++) {
            if (deleted[i]) {
                rangeStore.delete(ranges[i]);
            } else {
                rangeStore.add(ranges[i], tsDescs[i]);
            }
        }
    }

    private void handleTask(CatalogueLogTask body) {
        if (body.isDeleted()) {
            taskStore.delete(new LongWritable(body.getTaskId()));
        } else {
            AssignTabletTask task = body.getTask();
            taskStore.add(new LongWritable(body.getTaskId()), task);
            KeyRange kr = task.getKr();
            rangeStore.add(SchemaIdAndRange.createFromKeyRange(kr),
                    kr.getTsDesc());
        }
    }

    @Override
    public void handle(WALogEntry entry) throws IOException {
        if (entry.getLogType() == CatalogueLogEntry.TYPE_SCHEMA) {
            handlerSchema((CatalogueLogSchema) entry.getBody());
        } else if (entry.getLogType() == CatalogueLogEntry.TYPE_RANGE) {
            handleRange((CatalogueLogRange) entry.getBody());
        } else if (entry.getLogType() == CatalogueLogEntry.TYPE_TASK) {
            handleTask((CatalogueLogTask) entry.getBody());
        } else {
            LOG.warning("Wrong type of body, "
                    + entry.getBody().getClass().getName()
                    + " is not CatalogueLogEntry's body type");
        }

    }
}
