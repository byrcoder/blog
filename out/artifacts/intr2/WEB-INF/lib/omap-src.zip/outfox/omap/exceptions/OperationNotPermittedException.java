/**
 * @(#)OperationNotPermittedException.java, 2011-2-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 *
 * @author wangfk
 *
 */
public class OperationNotPermittedException extends RuntimeException {

    private static final long serialVersionUID = 6997610633439543111L;

    public OperationNotPermittedException() {
    // TODO Auto-generated constructor stub
    }

    public OperationNotPermittedException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }
    
    public OperationNotPermittedException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public OperationNotPermittedException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
