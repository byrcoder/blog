package outfox.omap.master;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DistributedFileSystem;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.ClientConnectListener;
import odis.rpc2.ClientInfo;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.ByteArrayWritable;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.UnsafeHelper;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.webapp.WebAppContext;

import outfox.omap.ClientMasterProtocol;
import outfox.omap.TsMasterProtocol;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.PermissionType;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.query.IndexSchema;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryUtils;
import outfox.omap.common.MasterTsProtocol;
import outfox.omap.common.TsConnectionManager;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConfig;
import outfox.omap.conf.OmapConstants;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.exceptions.BadConfigException;
import outfox.omap.exceptions.NoSuchSchemaException;
import outfox.omap.exceptions.OmapException;
import outfox.omap.exceptions.OmapTaskException;
import outfox.omap.exceptions.TableExistException;
import outfox.omap.master.catalogue.MasterCatalogue;
import outfox.omap.metadata.TableDesc;
import outfox.omap.metrics.IMasterMetricsReport;
import outfox.omap.metrics.MasterGlobalMetricsEntry;
import outfox.omap.metrics.MasterMetricsEntry;
import outfox.omap.metrics.MasterMetricsServerCallListener;
import outfox.omap.metrics.MasterTableMetricsEntry;
import outfox.omap.ts.LoadValue;
import outfox.omap.ts.TsUsageReport;
import outfox.omap.ts.insertlog.InsertLogger;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.NoActionWatcher;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.OmapUtils.TESTCASE_PREPENSE_EXCEPTION_TYPE;
import outfox.omap.util.TableConfig;
import outfox.omap.util.WaitUtils;
import outfox.omap.walog.WALogFile;
import toolbox.collections.Pair;
import toolbox.collections.primitive.LongClosedHashSet;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;
import bsh.Interpreter;

/**
 * @author zhihua, xuw, jimmysu
 */
public class OmapMaster implements OmapConstants, TsMasterProtocol,
        ClientMasterProtocol, IMasterMetricsReport {

    private static Logger LOG = LogFormatter.getLogger(OmapMaster.class);

    private String masterName;

    MasterCatalogue masterCatalogue;

    private final String tabletDir = OmapConfig.getTsTabletDir();

    private int masterPort;

    static final LoadValue ZERO_LOAD = new LoadValue();

    /**
     * A list of available TS'es sorted by TsSelectPolicy, so the first one is
     * the best to allocate the next tablet In memory only. The Catalogue TS is
     * not included. NOTE: If you want to see whether a TS is in this set by
     * giving a TsUsageReport with a different load value from which is recorded
     * in this set, contains() won't work, because it's sorted by load.
     * TsUsageReports. If you want to find a TS in this set, iterate over it and
     * use TsUsageReport.equals() to judge.
     */
    private final TreeSet<TsUsageReport> tsUsageSet;

    /**
     * TsDesc -> TsUsageReport(exactly same with the one stored in tsUsageSet),
     * we can use this map to remove TsUsageReport from tsUsageSet.<br>
     * Also used as a lock which protect tsUsageSet and aliveTsMap.
     */
    private final Map<TsDesc, TsUsageReport> aliveTsMap;

    /**
     * Get a copy of the list of available TS'es
     * 
     * @return
     */
    public List<TsUsageReport> getAvailableTSList() {
        synchronized (aliveTsMap) {
            ArrayList<TsUsageReport> result = new ArrayList<TsUsageReport>(
                    tsUsageSet);
            return result;
        }
    }

    public TsDesc[] getAvailableTSes() {
        synchronized (aliveTsMap) {
            TsDesc[] result = new TsDesc[tsUsageSet.size()];
            int i = 0;
            for (TsUsageReport ts: tsUsageSet) {
                result[i++] = ts.getTsDesc();
            }
            return result;
        }
    }

    /**
     * SchemaIDs that are to be snapshot, which should not be split.
     */
    private final ConcurrentHashMap<Long, Long> tablesToBeSnapshot = new ConcurrentHashMap<Long, Long>();

    /**
     * Per Ts Task Queue each time a ts heartbeats, master check the queue and
     * return TaskDesc to the ts in memory only jimmysu: tasks that have been
     * reported done by ts should be removed from task queue, no need to keep
     * them around tasks that are sent are moved to onGoingTasks tasks in
     * taskQueues are unsent tasks currently assuming the network will not
     * reorder or lose the tasks for Ts
     */
    private final HashMap<TsDesc, TreeMap<Long, Task>> taskQueues = new HashMap<TsDesc, TreeMap<Long, Task>>();

    /**
     * keep track of what task_id to assign next
     */
    private final AtomicLong nextTaskId;

    /**
     * thread pool for the background task check heart beat thread
     */
    ScheduledThreadPoolExecutor backgroundtaskpool;

    private static final Task[] EMPTY_TASK_ARRAY = new Task[0];

    /**
     * Compare two ts based on their TsUsageReport
     * 
     * @author xuw
     */
    static class TsSelectPolicy implements Comparator<TsUsageReport> {
        public int compare(TsUsageReport o1, TsUsageReport o2) {
            double load1 = o1.getLoadValue();
            double load2 = o2.getLoadValue();
            if (load1 > load2) {
                return 1;
            } else if (load1 < load2) {
                return -1;
            } else {
                // if loads are equal, sort by toString().
                // should not return 0 directly here, otherwise available_ts
                // (TreeSet<TsUsageReport>)
                // will see different TS'es with the same load value as the same
                // TS, which is wrong.
                return o1.getTsDesc().compareTo(o2.getTsDesc());
            }
        }

    }

    private AbstractRpcServer server;

    private final FileSystem nfs;

    private final ZooKeeper zooKeeper;

    private final MasterGlobalMetricsEntry globalMetricsEntry = new MasterGlobalMetricsEntry();

    private final TsConnectionManager<MasterTsProtocol> tsConnManager;

    public OmapMaster() throws Exception {
        this(OmapConfig.getConfiguration().getInt(OmapConfig.NAME_MASTER_PORT,
                OmapConfig.DEFAULT_MASTER_PORT));
    }

    public FileSystem getFS() {
        return nfs;
    }

    private final Date startTime;

    public Date getStartTime() {
        return startTime;
    }

    private AtomicBoolean isShutdown = new AtomicBoolean(false);

    private void checkSessionExpired(WatchedEvent event) {
        if (!isShutdown.get() && event.getState() == KeeperState.Expired) {
            LOG.severe("zookeeper connection expired, I must kill myself");
            stopService();
        }
    }

    private void checkSessionExpired(KeeperException exc) {
        if (!isShutdown.get() && exc.code() == Code.SESSIONEXPIRED) {
            LOG.severe("zookeeper connection expired, I must kill myself");
            stopService();
        }
    }

    public OmapMaster(int port) throws Exception {
        try {
            int zkMasterTimeout = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_MASTER_ZOOKEEPER_TIMEOUT,
                    OmapConfig.DEFAULT_MASTER_ZOOKEEPER_TIMEOUT);
            String host = OmapConfig.getConfiguration().getString(
                    OmapConfig.NAME_MASTER_HOST);
            if (host == null) {
                throw new BadConfigException("omap",
                        OmapConfig.NAME_MASTER_HOST);
            }
            String localHost = InetAddress.getLocalHost().getHostName();
            if (!InetAddress.getByName(localHost).getHostAddress().equals(
                    InetAddress.getByName(host).getHostAddress())) {
                throw new BadConfigException("config omap.master.host " + host
                        + " seems incorrect, may be " + localHost + "?");
            }
            masterName = "OMAPMASTER@" + host + ":" + port;
            masterPort = port;
            byte[] addr = (host + ":" + port).getBytes("UTF-8");
            String activeZNodePath = OmapConfig.getZkActiveMasterPath();
            zooKeeper = new ZooKeeper(OmapConfig.getZkAddress(),
                    zkMasterTimeout, new NoActionWatcher());
            OmapUtils.createZooKeeperRootNode(zooKeeper);
            String fsName = OmapConfig.getConfiguration().getString(
                    OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
            LOG.info("File system name: " + fsName);
            this.nfs = FileSystem.getNamed(fsName, false,
                    OmapUtils.getDistributedFileSystemConfig());

            final Object lock = new Object();
            while (true) {
                synchronized (lock) {
                    try {
                        if (zooKeeper.exists(activeZNodePath, new Watcher() {

                            @Override
                            public void process(WatchedEvent event) {
                                checkSessionExpired(event);
                                if (event.getType() == EventType.NodeDeleted) {
                                    LOG.info("active master die");
                                } else if (event.getType() == EventType.NodeCreated) {
                                    LOG.info("active master created");
                                } else {
                                    LOG.warning("unexpected event : " + event);
                                }
                                synchronized (lock) {
                                    lock.notifyAll();
                                }

                            }
                        }) != null) {
                            LOG.info("Node already exists, I will sleep until the active master die");
                            lock.wait();
                        } else {
                            LOG.info("try to become active master");
                            zooKeeper.create(activeZNodePath, addr,
                                    ZooDefs.Ids.OPEN_ACL_UNSAFE,
                                    CreateMode.EPHEMERAL);
                            break;

                        }
                    } catch (KeeperException e) {
                        if (e.code().equals(Code.NODEEXISTS)) {
                            LOG.info("fail to become active master");
                        } else {
                            LOG.log(Level.WARNING,
                                    "process active master error", e);
                            if (e.code() == Code.SESSIONEXPIRED) {
                                LOG.severe("zookeeper connection expired, init failed");
                                System.exit(1);
                            }
                        }
                    }
                }
            }

            LOG.info("successfully became active master");
            this.backgroundtaskpool = (ScheduledThreadPoolExecutor) Executors.newScheduledThreadPool(
                    5, new ThreadFactory() {

                        @Override
                        public Thread newThread(Runnable r) {
                            Thread thread = new Thread(r,
                                    "Master-Background-Task-Thread");
                            thread.setDaemon(true);
                            return thread;
                        }
                    });
            // we do not need to confirm whether the task is send to ts if 
            // failed, ts heartbeat will get the task finally. So we just use
            // an udp protocol.
            tsConnManager = new TsConnectionManager<MasterTsProtocol>(
                    MasterTsProtocol.class,
                    TsConnectionManager.ConnectionType.UDP);
            masterCatalogue = new MasterCatalogue(nfs, backgroundtaskpool);
            // start omap master
            startTime = new Date(System.currentTimeMillis());

            tsUsageSet = new TreeSet<TsUsageReport>(new TsSelectPolicy());

            nextTaskId = new AtomicLong(1000);

            Set<TsDesc> aliveTsSet = masterCatalogue.getTses();
            LOG.info("original aliveTsSet = " + aliveTsSet);
            aliveTsMap = new TreeMap<TsDesc, TsUsageReport>();
            for (TsDesc tsDesc: aliveTsSet) {
                aliveTsMap.put(tsDesc, null);
            }
            LOG.info("scan for undeleted IndexTable");

            Set<String> indexTableNames = new HashSet<String>();

            List<OmapMetadata> tables = masterCatalogue.getTables();

            for (OmapMetadata metadata: tables) {
                if (!OmapUtils.isIndexTable(metadata.getTableDesc().getTableName())) {
                    for (String tableName: metadata.getIndexes().values()) {
                        indexTableNames.add(tableName);
                    }
                }
            }
            for (OmapMetadata metadata: tables) {
                if (OmapUtils.isIndexTable(metadata.getTableName())) {
                    if (!indexTableNames.contains(metadata.getTableDesc().getTableName())) {
                        LOG.info("delete unused indexTable: " + metadata);
                        masterCatalogue.deleteSchema(
                                metadata.getTableDesc().getSchemaId(), true);
                    }
                }
            }

            LOG.info("Cleaning up files of deleted Tablets");
            Path trashDir = new Path(OmapConfig.getTsDataPath(), "trash");
            nfs.mkdirs(trashDir);
            Collection<KeyRange> tablets = masterCatalogue.getAllTablets();
            Set<String> tabletIds = new HashSet<String>();
            for (KeyRange kr: tablets) {
                tabletIds.add(HexString.longToPaddedHex(kr.getTabletId()));
            }
            FileInfo[] files = nfs.listFiles(new Path(
                    OmapConfig.getTsTabletDir()));
            for (FileInfo tableFile: files) {
                List<FileInfo> tabletFiles = OmapUtils.listTabletsByTabletFileDir(
                        nfs, tableFile.getPath());
                for (FileInfo tabletFile: tabletFiles) {
                    String tabletId = OmapUtils.getTabletIdBySSTableFileDirPath(tabletFile.getPath().getPath());
                    if (!tabletIds.contains(tabletId)) {
                        LOG.info("Moving " + tabletFile.getPath() + " to trash");
                        nfs.rename(tabletFile.getPath(), trashDir.cat(tabletId));
                    } else {
                        LOG.fine("Confirm tablet localtion: "
                                + tabletFile.getPath() + ", tablet id: "
                                + tabletId);
                    }
                }
            }

            // recover unfinished assigntablet tasks
            LOG.info("Recovering unfinished AssignTabletTasks");
            List<Task> undonetasks = masterCatalogue.getUnFinishedTasks();
            for (Task task: undonetasks) {
                if (task instanceof AssignTabletTask) {
                    AssignTabletTask td = (AssignTabletTask) task;
                    // recover taskid cnt
                    if (td.getTaskId() >= this.nextTaskId.get()) {
                        this.nextTaskId.set(td.getTaskId() + 1);
                    }
                    // assigntask is generated BEFORE tablet record is written
                    // need to recover tablet record
                    // overwrite tablet record that already exists
                    if (aliveTsSet.contains(td.getAssignedTs())) {
                        // do not assign task to ts, because the ts in original 
                        // aliveTsSet maybe dead already.
                        addTask(td.getAssignedTs(), td, false, false);
                    } else {
                        td.reassignTs(TsDesc.getDummyTsDesc(),
                                "reassign AssignTabletTasks from dead TS");
                        addDummyTask(td, false);
                    }
                }
                TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_RECOVERING_TS_TASK);
            }
            List<Class<?>> protocols = new ArrayList<Class<?>>(3);
            protocols.add(ClientMasterProtocol.class);
            protocols.add(TsMasterProtocol.class);
            protocols.add(IMasterMetricsReport.class);
            List<Object> instances = new ArrayList<Object>(3);
            instances.add(this);
            instances.add(this);
            instances.add(this);

            int rpcHandlerCount = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_MASTER_RPC_HANDLER_COUNT,
                    OmapConfig.DEFAULT_MASTER_RPC_HANDLER_COUNT);
            int rpcQueueSize = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_MASTER_RPC_QUEUE_SIZE, 10 * rpcHandlerCount);
            int rpcMaxConnPerClient = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_MASTER_RPC_MAX_CONNECTION_PER_CLIENT,
                    OmapConfig.DEFAULT_MASTER_RPC_MAX_CONNECTION_PER_CLIENT);
            int rpcClientDisconnectTime = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_MASTER_RPC_CLIENT_DISCONNECT_TIME,
                    OmapConfig.DEFAULT_MASTER_RPC_CLIENT_DISCONNECT_TIME);
            this.server = RPC.getNIOServer(protocols, instances, port,
                    rpcHandlerCount, rpcQueueSize, rpcMaxConnPerClient,
                    rpcClientDisconnectTime);
            this.server.addClientConnectListener(new ClientConnectListener() {

                @Override
                public void clientDisconnect(ClientInfo clientInfo) {
                    if (clientInfo.protocol.equals(ClientMasterProtocol.class)) {
                        LOG.info("Client " + clientInfo + " disconnected");
                    } else if (clientInfo.protocol.equals(TsMasterProtocol.class)) {
                        LOG.info("TS " + clientInfo + " disconnected");
                    } else if (clientInfo.protocol.equals(IMasterMetricsReport.class)) {
                        LOG.info("Metrics " + clientInfo + " disconnected");
                    } else {
                        LOG.warning("Unknown protocol " + clientInfo
                                + " disconnected");
                    }

                }

                @Override
                public void clientConnect(ClientInfo clientInfo) {
                    if (clientInfo.protocol.equals(ClientMasterProtocol.class)) {
                        LOG.info("Client " + clientInfo + " connected");
                    } else if (clientInfo.protocol.equals(TsMasterProtocol.class)) {
                        LOG.info("TS " + clientInfo + " connected");
                    } else if (clientInfo.protocol.equals(IMasterMetricsReport.class)) {
                        LOG.info("Metrics " + clientInfo + " connected");
                    } else {
                        LOG.warning("Unknown protocol " + clientInfo
                                + " connected");
                    }
                }
            });
            this.server.setServerCallListener(new MasterMetricsServerCallListener(
                    globalMetricsEntry));
            this.server.start();

            Path recoverLogPath = new Path(OmapConfig.getWalPathForRecovery());
            nfs.mkdirs(recoverLogPath);

            checkTsChange(true);

            long checkTaskInterval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_MASTER_CHECK_TASK_INTERVAL,
                    OmapConfig.DEFAULT_MASTER_CHECK_TASK_INTERVAL);
            this.backgroundtaskpool.scheduleWithFixedDelay(
                    new CheckTasksTask(), 0L, checkTaskInterval,
                    TimeUnit.SECONDS);
            long migrationCheckInterval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_MASTER_MIGRATION_CHECK_INTERVAL,
                    OmapConfig.DEFAULT_MASTER_MIGRATION_CHECK_INTERVAL);
            this.backgroundtaskpool.scheduleWithFixedDelay(
                    new LoadBalanceTask(), migrationCheckInterval,
                    migrationCheckInterval, TimeUnit.SECONDS);
            Runtime.getRuntime().addShutdownHook(new Thread() {
                public void run() {
                    OmapUtils.safeClose(masterCatalogue);
                    OmapUtils.safeClose(nfs);
                    OmapUtils.safeClose(zooKeeper);
                    LOG.info("Shutdown hook: shutting down Catalogue, FileSystem and ZooKeeper");
                }
            });
            LOG.info("Master initialized...");
        } catch (Exception e) {
            LOG.info("Master crash when initialize...");
            shutdown();
            throw e;
        }
    }

    private Object checkTsChangeLock = new Object();

    private Random rand = new Random();

    private class CheckTsChangeTask implements Runnable {

        @Override
        public void run() {
            try {
                checkTsChange(false);
            } catch (IOException e) {
                LOG.log(Level.SEVERE,
                        "check ts change failed, I must kill myself", e);
                stopService();
            }
        }

    }

    private void checkTsChange(boolean setWatcher) throws IOException {
        LOG.info("check ts change");
        List<TsDesc> deadTsList = new ArrayList<TsDesc>();
        boolean recheck = false;
        synchronized (checkTsChangeLock) {
            List<String> addrList;
            int retryCount = 0;
            while (true) {
                try {
                    addrList = zooKeeper.getChildren(OmapConfig.getZkTsPath(),
                            setWatcher ? tsChangeWatcher : null);
                    break;
                } catch (KeeperException e) {
                    checkSessionExpired(e);
                    LOG.log(Level.WARNING, "get ts list failed", e);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "get ts list failed", e);
                }
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
            Set<TsDesc> newAliveTsSet = new HashSet<TsDesc>();
            for (String addr: addrList) {
                String[] ss = addr.split(":");
                newAliveTsSet.add(new TsDesc(ss[0], Integer.parseInt(ss[1]),
                        Long.parseLong(ss[2])));
            }
            synchronized (aliveTsMap) {
                Iterator<Map.Entry<TsDesc, TsUsageReport>> iter = aliveTsMap.entrySet().iterator();
                while (iter.hasNext()) {
                    Map.Entry<TsDesc, TsUsageReport> entry = iter.next();
                    TsDesc tsDesc = entry.getKey();
                    if (!newAliveTsSet.contains(tsDesc)) {
                        LOG.warning(tsDesc + " is dead ");
                        if (nfs instanceof DistributedFileSystem) {
                            try {
                                // check for unclosed WALogs
                                Path logPath = new Path(
                                        OmapConfig.getWalPath(),
                                        tsDesc.getWALDirLastName());
                                Path[] unclosedLogs = ((DistributedFileSystem) nfs).pendingFilesInDir(logPath);
                                if (unclosedLogs != null
                                        && unclosedLogs.length > 0) {
                                    LOG.severe("WALogs of "
                                            + tsDesc
                                            + " is not closed (files="
                                            + Arrays.toString(unclosedLogs)
                                            + ")."
                                            + " This usually happens when the TS hasn't completely shut down."
                                            + " I cannot recover the TS until is completely shut down.");
                                    recheck = true;
                                    continue;
                                }
                            } catch (Exception e) {
                                LOG.log(Level.WARNING,
                                        "check TS WALogs failed", e);
                                recheck = true;
                                continue;
                            }
                        }
                        TsUsageReport usage = entry.getValue();
                        if (usage != null) {
                            tsUsageSet.remove(usage);
                        }
                        deadTsList.add(tsDesc);
                        iter.remove();
                    }
                }

                for (TsDesc tsDesc: newAliveTsSet) {
                    if (!aliveTsMap.containsKey(tsDesc)) {
                        LOG.info("TS " + tsDesc + " join");
                        aliveTsMap.put(tsDesc, null);
                    }
                }
            }
        }

        if (recheck) {
            backgroundtaskpool.schedule(
                    new CheckTsChangeTask(),
                    OmapConfig.getConfiguration().getLong(
                            OmapConfig.NAME_HEARTBEAT_INTERVAL,
                            OmapConfig.DEFAULT_HEARTBEAT_INTERVAL),
                    TimeUnit.SECONDS);
        }
        if (!deadTsList.isEmpty()) {
            recoverFromDeadTSes(deadTsList);
        }
    }

    private Watcher tsChangeWatcher = new Watcher() {

        @Override
        public void process(WatchedEvent event) {
            checkSessionExpired(event);
            if (event.getType() != EventType.NodeChildrenChanged) {
                LOG.warning("unexpected event: " + event);
            }
            try {
                checkTsChange(true);
            } catch (Exception e) {
                LOG.log(Level.SEVERE, "check ts change failed, kill myself", e);
                stopService();
            }
        }

    };

    /**
     * Move the logs of a dead TS to a dedicated place for recovery
     * 
     * @param deadTs
     *            the dead TS
     * @return the new location of the logs. null if no Tablets were assigned to
     *         the dead Ts
     */
    private Path prepareWALogsForRecovery(TsDesc deadTs) throws IOException {
        Path recoverLogDir = new Path(OmapConfig.getWalPathForRecovery(),
                deadTs.getWALDirLastName());
        if (nfs.exists(recoverLogDir)) {
            LOG.info("WALog for recovery is already prepared");
            return recoverLogDir;
        }

        // move the original logs to a new position
        Path oldPath = new Path(OmapConfig.getWalPath(),
                deadTs.getWALDirLastName());

        // if there are no tablets in the deadTs, just remove it's logs and return null
        Map<TsDesc, List<KeyRange>> allTablets = masterCatalogue.groupTabletsByTs();
        List<KeyRange> tablets = allTablets.get(deadTs);
        if (tablets == null || tablets.isEmpty()) {
            LOG.info("No Tablets assigned to dead " + deadTs);
            if (nfs.exists(oldPath)) {
                LOG.info("Remove useless log path: " + oldPath);
                nfs.delete(oldPath);
            }
            return null;
        }

        if (nfs.exists(oldPath)) {
            if (!nfs.rename(oldPath, recoverLogDir)) {
                throw new IOException("rename WALog from " + oldPath + " to "
                        + recoverLogDir + " failed");
            }
            LOG.info("Moved " + oldPath + " to " + recoverLogDir
                    + " for recovery");
        } else {
            nfs.mkdirs(recoverLogDir);
            LOG.warning("The WALog " + oldPath
                    + " is not exists, create it for recovery");
        }

        return recoverLogDir;
    }

    /**
     * Recover the AssignTabletTasks of a dead TS, by assigning them to another
     * TS
     * 
     * @param ts
     * @param excludeHavingAssignsTses
     *            if true, will exclude TSes that have AssignTabletTasks running
     *            from destination TSes.
     * @return the Tablets that has been reassigned
     * @throws IOException
     */
    private void recoverTsTasks(TsDesc ts, boolean excludeHavingAssignsTses)
            throws IOException {
        synchronized (taskQueues) {
            TreeMap<Long, Task> tqDead = taskQueues.remove(ts);
            // transfer tasks in deadTs task queue to this live Ts
            if (tqDead != null) {
                List<AssignTabletTask> tasks = new ArrayList<AssignTabletTask>();
                for (Task task: tqDead.values()) {
                    if (task instanceof AssignTabletTask) {
                        tasks.add((AssignTabletTask) task);
                    }
                }
                if (tasks.isEmpty()) {
                    return;
                }
                List<TsDesc> tses = this.getTSForAssignTabletTask(tasks.size(),
                        excludeHavingAssignsTses);
                for (int w = 0; w < tasks.size(); w++) {
                    AssignTabletTask task = tasks.get(w);
                    if (tses.isEmpty() || w >= tses.size()) {
                        task.reassignTs(TsDesc.getDummyTsDesc(),
                                "reassign AssignTabletTasks for dead TS");
                        addDummyTask(task, false);
                    } else {
                        TsDesc liveTs = tses.get(w);
                        task.reassignTs(liveTs,
                                "reassign AssignTabletTasks for dead TS");
                        addTask(liveTs, task, false, true);
                    }
                    // discard all other unfinished tasks..
                    TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_RECOVERING_TS_TASK);
                }
            }
        }
    }

    /**
     * Recover the Tablets of a dead TS, by splitting the log into parts, one of
     * which contains only the logs for one Tablet, and assigning the Tablets to
     * different live TS'es.
     * 
     * @param deadTs
     * @param recoveryWalPath
     * @param excludeHavingAssignsTses
     *            if true, will exclude TSes that have AssignTabletTasks running
     *            from destination TSes.
     */
    private void recoverTsTablets(TsDesc deadTs, Path recoveryWalPath,
            boolean excludeHavingAssignsTses, NativeRamBuffer splitBuffer)
            throws IOException {
        // read tablet list first
        Map<TsDesc, List<KeyRange>> allTablets = masterCatalogue.groupTabletsByTs();
        List<KeyRange> tablets = allTablets.get(deadTs);
        if (tablets == null || tablets.isEmpty()) {
            LOG.info("No Tablets assigned to dead " + deadTs);
            return;
        }

        HashSet<Long> tabletIds = new HashSet<Long>();
        for (KeyRange kr: tablets) {
            tabletIds.add(kr.getTabletId());
        }

        HashMap<Long, String> logReservePathMap = new HashMap<Long, String>();
        List<KeyRange> allTabletsList = masterCatalogue.getAllTablets();
        for (KeyRange tablet: allTabletsList) {
            long sid = tablet.getSchemaId();
            if (logReservePathMap.containsKey(sid)) {
                continue;
            }
            OmapMetadata metadata = masterCatalogue.findMetadata(sid);
            if (metadata != null) {
                String logReservePath = metadata.getTableDesc().getProperty(
                        Table.Property.RESERVE_WAL_PATH_NAME, null);
                if (logReservePath != null && !logReservePath.isEmpty()) {
                    logReservePathMap.put(sid, logReservePath);
                }
            }

        }

        // if the original logs exists, split them
        if (nfs.exists(recoveryWalPath)) {
            InsertLogger insertLogger = new InsertLogger(recoveryWalPath, nfs,
                    true);
            PriorityQueue<WALogFile> files = insertLogger.getLogChunks(true,
                    true);
            TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_SPLITTING_LOG);
            insertLogger.disassembleAllChunks(tabletIds, files,
                    logReservePathMap, null, splitBuffer);
            insertLogger.close();
        } else {
            LOG.warning(recoveryWalPath + " doens't exist");
        }
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_AFTER_SPLIT_LOG);

        if (!tablets.isEmpty()) {
            // recover tablets
            List<TsDesc> tses = this.getTSForAssignTabletTask(tablets.size(),
                    excludeHavingAssignsTses);
            int assigned = 0;
            for (TsDesc ts: tses) {
                // ts with same host is started in one process, so at most time
                // they will be dead at the same time
                if (ts.getHost().equals(deadTs.getHost())) {
                    continue;
                }
                KeyRange tablet = tablets.get(assigned);
                tablet.setTsDesc(ts);
                OmapMetadata metadata = masterCatalogue.findMetadata(tablet.getSchemaId());
                if (metadata == null) {
                    LOG.warning("metadata is null when recover tablet "
                            + tablet + ", maybe table is already deleted");
                } else {
                    AssignTabletTask task = new AssignTabletTask(tablet,
                            metadata, recoveryWalPath.getAbsolutePath(),
                            ZERO_LOAD, "recover from " + recoveryWalPath);
                    this.addTask(ts, task, true, true);
                }
                if (++assigned >= tablets.size()) {
                    break;
                }
            }
            TsDesc dummyTs = TsDesc.getDummyTsDesc();
            for (; assigned < tablets.size(); assigned++) {
                KeyRange tablet = tablets.get(assigned);
                LOG.warning("Not enough available tses, assign " + tablet
                        + " to DummyTS first");
                tablet.setTsDesc(dummyTs);
                OmapMetadata metadata = masterCatalogue.findMetadata(tablet.getSchemaId());
                if (metadata == null) {
                    LOG.warning("metadata is null when recover tablet "
                            + tablet + ", maybe table is already deleted");
                } else {
                    AssignTabletTask task = new AssignTabletTask(tablet,
                            masterCatalogue.findMetadata(tablet.getSchemaId()),
                            recoveryWalPath.getAbsolutePath(), ZERO_LOAD,
                            "recover from " + recoveryWalPath);
                    addDummyTask(task, true);
                }
            }
        }
    }

    private void shutdown() {
        LOG.info("Shutting down Master");
        if (!isShutdown.compareAndSet(false, true)) {
            LOG.info("Master is already shutdown");
            return;
        }

        LOG.info("Close ts connections");
        if (tsConnManager != null) {
            tsConnManager.close();
        }

        LOG.info("Shutting down Task Pool");
        if (backgroundtaskpool != null) {
            this.backgroundtaskpool.shutdownNow();
            this.backgroundtaskpool.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
        }
        LOG.info("Shutting down ZooKeeper");
        OmapUtils.safeClose(zooKeeper);
        LOG.info("Shutting down MasterCatalogue");
        if (masterCatalogue != null) {
            masterCatalogue.close();
        }
    }

    /**
     * Generate tasks that shutdown all TSes. The tasks are run in the
     * background and are not guaranteed to be completed when this method
     * returns.
     * 
     * @param checkpointAllTablets
     */
    public void shutdownAllTs(boolean checkpointAllTablets) {
        LOG.info("Shutting down all TSes, checkpointAllTablets="
                + checkpointAllTablets);
        synchronized (aliveTsMap) {
            for (TsUsageReport ts: tsUsageSet) {
                TsShutDownTask task = new TsShutDownTask(
                        "Shutdown requested by OmapMaster.shutdownAllTs()",
                        checkpointAllTablets);
                try {
                    addTask(ts.getTsDesc(), task, true, true);
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "Failed to generate shutdown task for "
                                    + ts.getTsDesc(), e);
                }
            }
        }
    }

    /**
     * stop service
     */
    public void stopService() {
        server.stop();
    }

    /**
     * Run forever
     */
    public void join() {
        try {
            this.server.join();
        } catch (InterruptedException e) {
            LOG.warning("rpc server interrupted, stop");
            this.server.stop();
        }
        LOG.info("Master server stopped");
        shutdown();
        LOG.info("Master shutdown process ended");
    }

    public static void main(String[] args) throws Exception {
        OmapUtils.setupFileLogger("omapmaster");
        OmapMaster omapmaster = new OmapMaster();
        InspectorServlet.master = omapmaster;
        // start web server
        int webPort = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_MASTER_WEB_PORT,
                OmapConfig.DEFAULT_MASTER_WEB_PORT);
        int bsPort = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_MASTER_BEANSHELL_PORT,
                OmapConfig.DEFAULT_MASTER_BEANSHELL_PORT);
        LOG.info("Bean shell port: " + bsPort);
        Server webServer = new Server(webPort);
        WebAppContext wac = new WebAppContext();
        wac.setContextPath("/");
        wac.setWar("./webapps/web/");
        webServer.setHandler(wac);
        webServer.setStopAtShutdown(true);
        webServer.start();
        // start bean shell
        Interpreter interpreter = new Interpreter();
        interpreter.set("master", omapmaster);
        interpreter.set("portnum", bsPort);
        interpreter.eval("setAccessibility(true)");
        interpreter.eval("server(portnum)");

        omapmaster.join();
        System.exit(0);
    }

    private Map<TsDesc, LongClosedHashSet> incorrectTabletMap = new HashMap<TsDesc, LongClosedHashSet>();

    private Task[] tsUsageReport(TsUsageReport usage) {
        usage.recordHeatBeatTime();
        usage.calcLoadValue();

        synchronized (aliveTsMap) {
            if (aliveTsMap.containsKey(usage.getTsDesc())) {
                TsUsageReport oldUsage = aliveTsMap.get(usage.getTsDesc());
                if (oldUsage != null) {
                    tsUsageSet.remove(oldUsage);
                }
                usage.recordHeatBeatTime();
                usage.calcLoadValue();
                aliveTsMap.put(usage.getTsDesc(), usage);
                tsUsageSet.add(usage);
            } else {
                LOG.warning("TS " + usage.getTsDesc()
                        + " was not expected to send a heartbeat");
                backgroundtaskpool.execute(new CheckTsChangeTask());
                return EMPTY_TASK_ARRAY;
            }
        }

        Map<Long, TsDesc> incorrectTablets = masterCatalogue.checkTabletConsistency(usage);
        synchronized (taskQueues) {
            TreeMap<Long, Task> tq = taskQueues.get(usage.getTsDesc());
            // consistency check
            if (tq != null) {
                for (Task task: tq.values()) {
                    if (task instanceof CloseTabletTask) {
                        CloseTabletTask ct = (CloseTabletTask) task;
                        incorrectTablets.remove(ct.tabletId);
                    }
                }
            }
            LongClosedHashSet prevIncorrectTablets = incorrectTabletMap.get(usage.getTsDesc());
            LongClosedHashSet currentIncorrectTablets = new LongClosedHashSet(
                    incorrectTablets.size());
            for (Map.Entry<Long, TsDesc> entry: incorrectTablets.entrySet()) {
                // just split
                if (entry.getValue() == null) {
                    continue;
                }
                if (prevIncorrectTablets != null
                        && prevIncorrectTablets.contains(entry.getKey())) {
                    String msg = "Tablet "
                            + HexString.longToPaddedHex(entry.getKey())
                            + " is reported by " + usage.getTsDesc()
                            + ", but is expected to be managed by "
                            + entry.getValue();
                    LOG.severe(msg);
                    AlertUtils.alert(masterName
                            + " tablet consistency check failed", msg, false,
                            true);
                    CloseTabletTask ct = new CloseTabletTask(entry.getKey(),
                            usage.getTsDesc(), null, new LoadValue(), false,
                            "Consistency Fixing");
                    addTask(usage.getTsDesc(), ct, true, false);
                }
                currentIncorrectTablets.add(entry.getKey());
            }
            if (currentIncorrectTablets.isEmpty()) {
                incorrectTabletMap.remove(usage.getTsDesc());
            } else {
                incorrectTabletMap.put(usage.getTsDesc(),
                        currentIncorrectTablets);
            }

            // get tasks
            if (tq == null) {
                // this ts has no task queue yet, create one
                tq = new TreeMap<Long, Task>();
                taskQueues.put(usage.getTsDesc(), tq);
                return EMPTY_TASK_ARRAY;
            } else {
                ArrayList<Task> toSent = new ArrayList<Task>();
                Iterator<Task> it = tq.values().iterator();
                while (it.hasNext()) {
                    Task td = it.next();
                    if (td.getSentTime() < 0) {
                        td.recordSentTime();
                        toSent.add(td);
                    } else if (td.getDoneTime() < 0) {
                        td.recordSentTime();
                        toSent.add(td);
                    } else {
                        // remove completed task
                        it.remove();
                    }
                }
                return toSent.toArray(EMPTY_TASK_ARRAY);
            }
        }
    }

    public Task[] tsHeartbeat(TsUsageReport usage) {
        usage.recordHeatBeatTime();
        usage.calcLoadValue();
        LOG.info("HEARTBEAT: " + usage);
        try {
            return tsUsageReport(usage);
        } catch (Throwable t) {
            LOG.log(Level.SEVERE,
                    "Exception when processing heartbeat information: " + usage,
                    t);
            return EMPTY_TASK_ARRAY;
        }
    }

    public Task[] tsTaskDone(Task task, TsDesc ts) throws OmapTaskException {
        Task[] toAssignedTasks = EMPTY_TASK_ARRAY;
        synchronized (taskQueues) {
            Map<Long, Task> queue = taskQueues.get(ts);
            if (queue == null) {
                LOG.warning("Cannot get the task queue of " + ts
                        + " in taskQueues");
                throw new OmapTaskException("Task queue is null");
            }

            if (queue.remove(task.getTaskId()) == null) {
                LOG.warning("Cannot find task for " + ts + ": " + task);
                throw new OmapTaskException("The task with id = "
                        + task.getTaskId() + " not exists");
            }
            if (task.getReturnStatus() >= 0) {
                LOG.info("TASK DONE: " + task);
            } else {
                LOG.warning("TASK FAILED: " + task + " return status is: "
                        + task.getReturnStatus());
            }

            try {
                if (task instanceof AssignTabletTask) {
                    AssignTabletTask at = (AssignTabletTask) task;
                    toAssignedTasks = tsTaskDone(at, ts);
                    masterCatalogue.deleteTask(at);
                } else if (task instanceof CloseTabletTask) {
                    tsTaskDone((CloseTabletTask) task);
                } else if (task instanceof SplitTabletTask) {
                    tsTaskDone((SplitTabletTask) task);
                } else if (task instanceof ClearTableMetaTask) {
                    tsTaskDone((ClearTableMetaTask) task);
                } else if (task instanceof CheckpointTask) {
                    tsTaskDone((CheckpointTask) task);
                } else {
                    LOG.warning("Unknown task subclass: "
                            + task.getClass().getName());
                    throw new OmapTaskException("Unknown task class "
                            + task.getClass().getName());
                }
            } catch (IOException e) {
                throw new OmapTaskException(e);
            }
        }
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_AFTER_TS_TASK_DONE);
        return toAssignedTasks;
    }

    private Task[] tsTaskDone(AssignTabletTask task, TsDesc tsDesc) {
        if (task.getReturnStatus() < -1) { // failed, reassign
            List<TsDesc> tses = this.getTSForAssignTabletTask(1, true);
            if (tses.isEmpty()) {
                LOG.warning("Assign tablet " + task + " failed, reassign to "
                        + TsDesc.getDummyTsDesc());
                task.reassignTs(TsDesc.getDummyTsDesc(),
                        "AssignTabletTask failed, reassign");
                addDummyTask(task, false);
            } else {
                TsDesc ts = tses.get(0);
                LOG.warning("Assign tablet " + task + " failed, reassign to "
                        + ts);
                task.reassignTs(ts, "AssignTabletTask failed, reassign");
                addTask(ts, task, false, true);
            }
            return EMPTY_TASK_ARRAY;
        } else {
            Task[] newTasks = EMPTY_TASK_ARRAY;
            // find an unsettled assign tablet task
            synchronized (taskQueues) {
                TreeMap<Long, Task> dummyTasks = taskQueues.get(TsDesc.getDummyTsDesc());
                if (dummyTasks != null) {
                    Iterator<Task> taskIter = dummyTasks.values().iterator();
                    while (taskIter.hasNext()) {
                        Task dummyTask = taskIter.next();
                        if (dummyTask instanceof AssignTabletTask) {
                            AssignTabletTask assignTask = (AssignTabletTask) dummyTask;
                            assignTask.reassignTs(tsDesc,
                                    "reassign timed-out AssignTabletTasks to an available TS");
                            taskIter.remove();
                            TreeMap<Long, Task> tsTasks = taskQueues.get(tsDesc);
                            if (tsTasks == null) {
                                tsTasks = new TreeMap<Long, Task>();
                                taskQueues.put(tsDesc, tsTasks);
                            }
                            tsTasks.put(assignTask.getTaskId(), assignTask);
                            try {
                                masterCatalogue.insertTask(assignTask);
                            } catch (Throwable t) {
                                LOG.log(Level.SEVERE, "insert task "
                                        + assignTask
                                        + " failed, I must kill myself", t);
                                stopService();
                            }
                            newTasks = new Task[] {
                                assignTask
                            };
                            break;
                        }
                    }
                    if (dummyTasks.isEmpty()) {
                        taskQueues.remove(TsDesc.getDummyTsDesc());
                    }
                }
            }
            return newTasks;
        }
    }

    private void tsTaskDone(ClearTableMetaTask task) {
        // nothing
    }

    private void tsTaskDone(CheckpointTask task) {
        // nothing to do
    }

    private void tsTaskDone(CloseTabletTask task) {
        if (task.migrateTo != null) {
            if (task.getReturnStatus() < 0) { // failed, ignore next step
                LOG.warning(task + " failed, ignoring");
                return;
            }
            KeyRange kr = (KeyRange) new KeyRange().copyFields(task.kr);
            kr.setTsDesc(task.migrateTo);
            OmapMetadata metadata = masterCatalogue.findMetadata(kr.getSchemaId());
            if (metadata != null) {
                AssignTabletTask newTask = new AssignTabletTask(kr,
                        masterCatalogue.findMetadata(kr.getSchemaId()), null,
                        task.load, "CloseTabletTask for migrate done");
                addTask(task.migrateTo, newTask, true, true);
            } else {
                LOG.warning("OmapMetadata for keyrange " + kr
                        + " is null, maybe the table is already deleted");
            }
            // FIXME: if we crash here, tablet maybe assigned to different ts
        } else {
            LOG.info("Deleting tablet: "
                    + HexString.longToPaddedHex(task.tabletId));
            if (task.getReturnStatus() < 0) {
                LOG.warning(task
                        + " failed, this may because tablet was assigned to other ts");
            } else {
                if (task.removeCatalogue) {
                    try {
                        masterCatalogue.deleteTablet(task.kr);
                    } catch (Exception e) {
                        LOG.log(Level.SEVERE, "delete tablet " + task.kr
                                + " failed, I must kill myself", e);
                        stopService();
                    }
                }
            }
        }
    }

    private void cleanFileSystemAfterSplitFailed(SplitTabletTask task)
            throws IOException {
        Path newTabletFile1 = new Path(OmapUtils.getSSTableFileDirPath(
                OmapConfig.getTsTabletDir(), task.newId1));

        nfs.delete(newTabletFile1);
        Path newTabletFile2 = new Path(OmapUtils.getSSTableFileDirPath(
                OmapConfig.getTsTabletDir(), task.newId2));
        nfs.delete(newTabletFile2);
    }

    private void tsTaskDone(SplitTabletTask task) throws IOException {
        if (task.getReturnStatus() < 0) { // failed, forget about it
            LOG.warning(task + " FAILED.. REMOVED FROM TASK QUEUE (status="
                    + task.getReturnStatus() + ")");
            cleanFileSystemAfterSplitFailed(task);
            return;
        }
        if (task.middleKey == null) { // did not get middle key, forget about it
            LOG.warning(task
                    + " FAILED.. REMOVED FROM TASK QUEUE (middle key=null)");
            cleanFileSystemAfterSplitFailed(task);
            return;
        }
        long schemaId = OmapUtils.tid2sid(task.oldId);
        KeyRange oldKr = masterCatalogue.findKeyRange(schemaId,
                task.middleKey.getKey());
        KeyRange newKr1 = new KeyRange(oldKr.getKey1(),
                task.middleKey.getKey(), oldKr.getTsDesc(), task.newId1);
        KeyRange newKr2 = new KeyRange(task.middleKey.getKey(),
                oldKr.getKey2(), oldKr.getTsDesc(), task.newId2);
        // do not delete oldKr at this point
        // if master crash before we delete old tablet file, then TS will roll back the split task
        // if we delete old kr, when master restart, it will find newKr1 and newKr2 managed by this TS
        // but actually, ts managed the oldKr.
        // so we must do it in three step:
        // 1. insert newKr1 and newKr2
        // 2. delete old tablet files
        // 3. delete oldKr
        masterCatalogue.splitTabletBegin(newKr1, newKr2);
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_SPLITTING_TABLET);
        // delete old tablet files
        Path oldTabletFile = new Path(OmapUtils.getSSTableFileDirPath(
                OmapConfig.getTsTabletDir(), task.oldId));
        nfs.delete(oldTabletFile);
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_SPLITTING_TABLET2);
        masterCatalogue.splitTabletEnd(oldKr, newKr1, newKr2);
        LOG.info("Split done: Tablet " + oldKr + " split to " + newKr1
                + " and " + newKr2);
    }

    private boolean checkGoodToSplit(long tabletId, TsDesc tsDesc) {
        long schemaId = OmapUtils.tid2sid(tabletId);
        if (tablesToBeSnapshot.containsKey(schemaId)) {
            LOG.warning("Table " + HexString.longToPaddedHex(schemaId)
                    + " is to be snapshot. Split is disabled now");
            return false;
        }
        TsDesc managedBy = masterCatalogue.getTsDesc(tabletId);
        if (!tsDesc.equals(managedBy)) {
            LOG.severe("Tablet " + HexString.longToPaddedHex(tabletId)
                    + " is not managed by " + tsDesc + "(should be "
                    + managedBy + "), split will be canceled");
            return false;
        }

        TsDesc dummyTs = TsDesc.getDummyTsDesc();
        synchronized (taskQueues) {
            for (TreeMap<Long, Task> list: taskQueues.values()) {
                for (Task t: list.values()) {
                    if (t instanceof AssignTabletTask) {
                        if (dummyTs.equals(((AssignTabletTask) t).getAssignedTs())) {
                            LOG.warning("I have unsettled Tablets. Split is disabled now");
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }

    private void addDummyTask(AssignTabletTask task, boolean changeTaskId) {
        if (!TsDesc.getDummyTsDesc().equals(task.getAssignedTs())) {
            throw new RuntimeException("AssignTabletTaskDesc is assigned to "
                    + task.getAssignedTs()
                    + ", but this task is added to the queue of "
                    + TsDesc.getDummyTsDesc());
        }
        if (changeTaskId) {
            task.setTaskId(nextTaskId.getAndIncrement());
            task.generatedTime = System.currentTimeMillis();
        }
        synchronized (taskQueues) {
            try {
                masterCatalogue.insertTask(task);
            } catch (Throwable t) {
                LOG.log(Level.SEVERE, "insert task " + task
                        + " failed, I must kill myself", t);
                stopService();
            }
            TreeMap<Long, Task> tq = taskQueues.get(TsDesc.getDummyTsDesc());
            if (tq == null) {
                tq = new TreeMap<Long, Task>();
                taskQueues.put(TsDesc.getDummyTsDesc(), tq);
            }
            tq.put(task.getTaskId(), task);
        }
    }

    /**
     * Schedule a Task. If the task is a AssignTabletTask, will update the
     * Tablets record in catalogue table.
     * 
     * @param ts
     * @param newTask
     * @param changeTaskId
     * @param assignToTs
     *            whether call {@link MasterTsProtocol#assignTask(Task[])} to
     *            tell ts to execute the task.
     * @throws IOException
     */
    private boolean addTask(TsDesc ts, Task newTask, boolean changeTaskId,
            boolean assignToTs) {
        if (ts.isDummyTs()) {
            if (newTask instanceof AssignTabletTask) {
                LOG.warning("Call addDummyTask instead of addTask for task "
                        + newTask);
            } else {
                LOG.info("Discard "
                        + newTask
                        + " because only AssignTabletTask could be assigned to DummyTs");
                return false;
            }
        }
        if (changeTaskId) {
            newTask.setTaskId(nextTaskId.getAndIncrement());
            newTask.generatedTime = System.currentTimeMillis();
        }
        synchronized (taskQueues) {
            boolean alive;
            synchronized (aliveTsMap) {
                alive = aliveTsMap.containsKey(ts);
            }
            if (!alive) {
                LOG.warning("TS " + ts + " is already dead, " + newTask
                        + " should not be assigned to it");
                // reassign tablet to dummyTs
                if (newTask instanceof AssignTabletTask) {
                    AssignTabletTask at = (AssignTabletTask) newTask;
                    at.reassignTs(TsDesc.getDummyTsDesc(),
                            "Reassign to dummy ts for " + ts
                                    + " is already dead");
                    addDummyTask(at, false);
                }
                return false;
            }
            if (newTask instanceof AssignTabletTask) {
                AssignTabletTask newAssignTask = (AssignTabletTask) newTask;
                TsDesc assignedTs = newAssignTask.getAssignedTs();
                if (!assignedTs.equals(ts)) {
                    throw new RuntimeException(
                            "AssignTabletTaskDesc is assigned to "
                                    + assignedTs
                                    + ", but this task is added to the queue of "
                                    + ts);
                }
                // filter out the Tablets that are being assigned by other Tasks
                // right now
                for (TreeMap<Long, Task> tq: taskQueues.values()) {
                    for (Task task: tq.values()) {
                        if (task instanceof AssignTabletTask
                                && task.getTaskId() != newAssignTask.getTaskId()) {
                            if (newAssignTask.getKr().getTabletId() == ((AssignTabletTask) task).getKr().getTabletId()) {
                                LOG.warning(HexString.longToPaddedHex(newAssignTask.getKr().getTabletId())
                                        + " is being assigned by "
                                        + task
                                        + ", cannot be assinged again by "
                                        + newTask + ". Abouted");
                                return false;
                            }
                        }
                    }
                }

                try {
                    masterCatalogue.insertTask(newAssignTask);
                } catch (Throwable t) {
                    LOG.log(Level.SEVERE, "insert task " + newAssignTask
                            + " failed, I must kill myself", t);
                    stopService();
                }
            } else if (newTask instanceof SplitTabletTask) {
                TreeMap<Long, Task> tq = taskQueues.get(ts);
                for (Task task: tq.values()) {
                    if (task instanceof SplitTabletTask) {
                        if (((SplitTabletTask) task).oldId == ((SplitTabletTask) newTask).oldId) {
                            LOG.warning("Skipping " + newTask + " because "
                                    + task + " already exists");
                            return false;
                        }
                    }
                }
            }
            LOG.info("TASK Generated: " + ts + " " + newTask);
            if (assignToTs && !isShutdown.get()) {
                try {
                    MasterTsProtocol tsNode = tsConnManager.getRpcProxy(ts, "",
                            "", 0);
                    tsNode.assignTask(new Task[] {
                        newTask
                    });
                    TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_ASSIGN_TASK_TO_TS);
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "send task to ts failed", t);
                }
            }
            TreeMap<Long, Task> tq = taskQueues.get(ts);
            if (tq == null) {
                // this ts has no task queue yet, create one
                tq = new TreeMap<Long, Task>();
                taskQueues.put(ts, tq);
            }
            tq.put(newTask.getTaskId(), newTask);
        }
        return true;
    }

    /**
     * schemaId -> next TabletId map
     */
    private HashMap<Long, AtomicLong> nextTabletIds = new HashMap<Long, AtomicLong>();

    private long getNextTabletId(long schemaId) {
        synchronized (nextTabletIds) {
            AtomicLong next = nextTabletIds.get(schemaId);

            if (next == null) {
                Collection<KeyRange> tablets = masterCatalogue.getTablets(schemaId);
                long id = OmapUtils.minTabletId(schemaId);
                for (KeyRange t: tablets) {
                    if (t.getTabletId() > id) {
                        id = t.getTabletId();
                    }
                }
                next = new AtomicLong(id);
                nextTabletIds.put(schemaId, next);
            }
            return next.incrementAndGet();
        }
    }

    public void migrate(long tabletId, TsDesc from, TsDesc target,
            LoadValue load, String reason) throws IOException {
        CloseTabletTask task = new CloseTabletTask(tabletId, from, target,
                load, false, reason);
        addTask(from, task, true, true);
    }

    /**
     * Return a copy of the Table list
     * 
     * @return
     */
    public OmapMetadata[] getTables() {
        long start = System.currentTimeMillis();
        OmapMetadata[] ret = masterCatalogue.getTables().toArray(
                new OmapMetadata[0]);
        long delay = System.currentTimeMillis() - start;
        globalMetricsEntry.getTables(delay);
        return ret;
    }

    private synchronized TableDesc createTableMetadata(String tableName,
            String colName, String colType, OmapQuery[] queries)
            throws IOException, OmapException {
        LOG.info("Inserting table " + tableName + " " + colName + " " + colType);
        // detect duplicate table definition
        try {
            masterCatalogue.getSchemaId(tableName);
            throw new TableExistException("Table " + tableName
                    + " already exists");
        } catch (NoSuchSchemaException e) {}
        long schemaId = masterCatalogue.getNextSchemaIdAndIncrement();
        TableDesc td = new TableDesc(tableName, colName, colType, schemaId);
        if (!OmapUtils.isIndexTable(tableName)) {
            addAclInfoToTableDesc(td);
        }
        OmapMetadata metadata;
        if (!OmapUtils.isIndexTable(tableName) && queries != null) {
            Map<IndexSchema, String> indexMap = createIndexTables(td, queries);
            metadata = new OmapMetadata(td, queries, indexMap);
        } else {
            metadata = new OmapMetadata(td, OmapQueryUtils.EMPTY_QUERY_MAP,
                    OmapQueryUtils.EMPTY_INDEX_MAP);
        }
        LOG.info("Table Created: " + td);
        masterCatalogue.addSchema(metadata);
        return td;
    }

    private Map<IndexSchema, String> createIndexTables(TableDesc td,
            OmapQuery[] queries) throws OmapException, IOException {
        Set<IndexSchema> iss = new HashSet<IndexSchema>();
        Map<IndexSchema, String> indexMap = new HashMap<IndexSchema, String>();
        for (OmapQuery query: queries) {
            iss.add(query.getIndexSchema());
        }

        Iterator<IndexSchema> it = iss.iterator();
        int indexTableIndex = 0;
        while (it.hasNext()) {
            IndexSchema is = it.next();
            String indexTableName = td.getTableName() + TABLENAME_SEPARATOR
                    + INDEX_TABLE_NAME_TAG + TABLENAME_SEPARATOR
                    + indexTableIndex;
            is.prepare(td);
            createTable(indexTableName, is.getIndexNameDeclaration(),
                    is.getIndexTypeDeclaration(), null);
            indexMap.put(is, indexTableName);
            indexTableIndex++;
        }
        return indexMap;
    }

    // /////////////////////////////////////////
    // Client Master Protocol
    // ////////////////////////////////////////
    public TableConfig createImportedTable(String tableName, String colName,
            String colType, OmapQuery[] queries) throws OmapException,
            IOException {
        TableDesc td = createTableMetadata(tableName, colName, colType, queries);
        addAclInfoToTableDesc(td);
        String path = OmapConfig.getTsTabletDir();
        String fs = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
        long maxTabletSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_MAX_BYTES_PER_TABLET,
                OmapConfig.DEFAULT_MAX_BYTES_PER_TABLET);
        long maxTabletRecords = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_MAX_RECORDS_PER_TABLET,
                OmapConfig.DEFAULT_MAX_RECORDS_PER_TABLET);
        return new TableConfig(fs, path, td, maxTabletSize, maxTabletRecords);
    }

    public void assignTabletsForImportedTable(long schemaId,
            KeyRange[] keyRanges, boolean waitForTabletsAssigned)
            throws IOException, OmapException {
        OmapMetadata metadata = masterCatalogue.findMetadata(schemaId);
        if (metadata == null) {
            throw new OmapException("schemaId "
                    + HexString.longToPaddedHex(schemaId) + " not found");
        }
        TableDesc td = metadata.getTableDesc();
        //write keyrange to dummy first, 
        //else may loss tablet iff crash during create AssignTabletTask
        for (int i = 0; i < keyRanges.length; i++) {
            keyRanges[i].setTsDesc(TsDesc.getDummyTsDesc());
            masterCatalogue.insertTablet(keyRanges[i]);
        }
        //finish writing keyrange files, the table can not be lost now

        //create AssignTabletTask for all the imported tablets
        List<TsDesc> availableTses = getTSForAssignTabletTask(keyRanges.length,
                true);
        TsDesc ts = TsDesc.getDummyTsDesc();
        for (int i = 0; i < keyRanges.length; ++i) {
            if (!availableTses.isEmpty()) {
                ts = availableTses.get(i % availableTses.size());
            }
            KeyRange kr = keyRanges[i];
            kr.setTsDesc(ts);
            AssignTabletTask newTask = new AssignTabletTask(kr,
                    masterCatalogue.findMetadata(kr.getSchemaId()), null,
                    ZERO_LOAD, "imported Table");
            LOG.info("Assigning Table "
                    + HexString.longToPaddedHex(keyRanges[i].getTabletId())
                    + " to " + ts);
            if (ts.isDummyTs()) {
                addDummyTask(newTask, true);
            } else {
                addTask(kr.getTsDesc(), newTask, true, true);
            }
        }

        // wait for all Tablets to be assigned
        if (waitForTabletsAssigned) {
            TsDesc dummyTs = TsDesc.getDummyTsDesc();
            while (true) {
                List<KeyRange> krl = masterCatalogue.getTablets(td.getSchemaId());
                int toBeAssignedCount = 0;
                for (KeyRange kr: krl) {
                    if (kr.getTsDesc().equals(dummyTs)) {
                        toBeAssignedCount++;
                    }
                }
                if (toBeAssignedCount > 0) {
                    LOG.info(td.getTableName() + " still has "
                            + toBeAssignedCount + " Tablets to be assigned");
                } else {
                    LOG.info(td.getTableName() + " has all Tablets assigned");
                    break;
                }
                long waitInterval = OmapConfig.getConfiguration().getLong(
                        OmapConfig.NAME_HEARTBEAT_INTERVAL,
                        OmapConfig.DEFAULT_HEARTBEAT_INTERVAL) * 1000 / 2;
                try {
                    Thread.sleep(waitInterval);
                } catch (Exception e) {
                    throw new OmapException(e);
                }
            }
        }
    }

    public void createTable(String tableName, String colName, String colType,
            OmapQuery[] queries) throws IOException, OmapException {
        long start = System.currentTimeMillis();
        TableDesc td = createTableMetadata(tableName, colName, colType, queries);
        allocateTabletsToNewTable(tableName, td);
        long delay = System.currentTimeMillis() - start;
        globalMetricsEntry.createTable(delay);

    }

    @SuppressWarnings("unchecked")
    private void allocateTabletsToNewTable(String tableName, TableDesc td)
            throws IOException {
        List<TsDesc> tses = getTSForAssignTabletTask(1, true);
        TsDesc ts;
        if (tses.isEmpty()) {
            LOG.warning("Master could not get a TS to assign the first Tablet of "
                    + tableName + ", using DummyTS");
            ts = TsDesc.getDummyTsDesc();
        } else {
            ts = tses.get(0);
        }

        LOG.info("Table " + td + " assigned to TS " + ts);

        // put the task in this TS's task queue
        KeyRange kr;
        AssignTabletTask newTask;
        long tabletId;

        /* Create new task */
        // initial tablet takes all keys
        tabletId = getNextTabletId(td.getSchemaId());
        kr = new KeyRange(null, KeyRange.MAX_WRITABLE, ts, tabletId);
        newTask = new AssignTabletTask(kr,
                masterCatalogue.findMetadata(kr.getSchemaId()), null,
                ZERO_LOAD, "first Tablet of a new Table");
        if (ts.isDummyTs()) {
            addDummyTask(newTask, true);
        } else {
            addTask(ts, newTask, true, true);
        }
        waitForTask(td.getSchemaId(), AssignTabletTask.class);
    }

    private void deleteIndexTable(OmapMetadata metadata) throws IOException {
        for (String tableName: metadata.getIndexes().values()) {
            deleteTable(tableName);
        }
    }

    public void deleteTable(String tableName) throws IOException {
        LOG.info("Deleting table " + tableName);
        long start = System.currentTimeMillis();

        // check permission
        OmapMetadata metadata = masterCatalogue.findMetadata(tableName);
        TableDesc td = metadata.getTableDesc();
        td.validatePermission(PermissionType.EXECUTE);

        // do snapshot
        Path snapshotPath = new Path(OmapConfig.getRecycledDir());
        snapshotPath = snapshotPath.cat(tableName + "."
                + System.currentTimeMillis());
        snapshot(tableName, snapshotPath.getPath(), true);

        masterCatalogue.deleteSchema(td.getSchemaId(), false);

        HashSet<Long> tabletsBeingClosed = new HashSet<Long>();
        while (true) {
            List<KeyRange> krl = masterCatalogue.getTablets(td.getSchemaId());
            if (krl.isEmpty()) {
                LOG.info("DeleteTable: all tablets of " + td
                        + " has been closed");
                break;
            } else {
                LOG.info("DeleteTable: " + td + " has " + krl.size()
                        + " tablets to be closed");
            }
            tabletsBeingClosed.clear();
            synchronized (taskQueues) {
                for (TreeMap<Long, Task> queue: taskQueues.values()) {
                    for (Task task: queue.values()) {
                        if (task instanceof CloseTabletTask) {
                            tabletsBeingClosed.add(((CloseTabletTask) task).tabletId);
                        }
                    }
                }
            }
            // close remaining Tablets
            for (KeyRange kr: krl) {
                if (!tabletsBeingClosed.contains(kr.getTabletId())) {
                    LOG.info("Closing "
                            + HexString.longToPaddedHex(kr.getTabletId()));
                    CloseTabletTask task = new CloseTabletTask(
                            kr.getTabletId(), kr.getTsDesc(), null, ZERO_LOAD,
                            true, "deleteTable requested");
                    this.addTask(kr.getTsDesc(), task, true, true);
                }
            }
            long waitInterval = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_HEARTBEAT_INTERVAL,
                    OmapConfig.DEFAULT_HEARTBEAT_INTERVAL) * 1000 / 2;
            try {
                Thread.sleep(waitInterval);
            } catch (InterruptedException e) {}
        }

        if (!OmapUtils.isIndexTable(tableName)) {
            deleteIndexTable(metadata);
        }

        Path tablePath = new Path(OmapUtils.getTabletFileDirByTableSchemaId(
                tabletDir, td.getSchemaId()));
        LOG.info("Deleting " + tablePath.getAbsolutePath());
        nfs.delete(tablePath);
        long delay = System.currentTimeMillis() - start;
        globalMetricsEntry.deleteTable(delay);
        LOG.info("Table Deleted: " + td);
    }

    private boolean hasTaskRunning(long schemaId,
            Class<? extends Task>... taskClasses) {
        synchronized (taskQueues) {
            for (TreeMap<Long, Task> queue: taskQueues.values()) {
                for (Task task: queue.values()) {
                    boolean found = false;
                    for (Class<? extends Task> taskClass: taskClasses) {
                        if (task.getClass().equals(taskClass)) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        continue;
                    }

                    if (task instanceof SplitTabletTask) {
                        if (OmapUtils.tid2sid(((SplitTabletTask) task).oldId) == schemaId) {
                            return true;
                        }
                    } else if (task instanceof CheckpointTask) {
                        for (long tabletId: ((CheckpointTask) task).getTablets()) {
                            if (OmapUtils.tid2sid(tabletId) == schemaId) {
                                return true;
                            }
                        }
                    } else if (task instanceof AssignTabletTask) {
                        if (((AssignTabletTask) task).getKr().getSchemaId() == schemaId) {
                            return true;
                        }
                    } else if (task instanceof CloseTabletTask) {
                        if (OmapUtils.tid2sid(((CloseTabletTask) task).tabletId) == schemaId) {
                            return true;
                        }
                    } else if (task instanceof ClearTableMetaTask) {
                        if (((ClearTableMetaTask) task).getSchemaId() == schemaId) {
                            return true;
                        }
                    } else {
                        throw new RuntimeException("unknown task type: "
                                + task.getClass());
                    }
                }
            }
        }
        return false;
    }

    /**
     * Wait until all tasks of the given task class and the given schemaId is
     * done
     * 
     * @param task
     */
    private void waitForTask(long schemaId,
            Class<? extends Task>... taskClasses) {
        // sleep for a short time first
        WaitUtils.sleepIgnoreInterrupt(100);
        long waitInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_HEARTBEAT_INTERVAL,
                OmapConfig.DEFAULT_HEARTBEAT_INTERVAL) * 1000 / 2;
        while (hasTaskRunning(schemaId, taskClasses)) {
            WaitUtils.sleepIgnoreInterrupt(waitInterval);
        }
    }

    /**
     * Return the name of FileSystem
     */
    public String getFsName() {
        long start = System.currentTimeMillis();
        String fsName = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
        long delay = System.currentTimeMillis() - start;
        globalMetricsEntry.getFsName(delay);
        return fsName;
    }

    public LoadValue getTableLoad(String tableName) {
        long schemaId = masterCatalogue.getSchemaId(tableName);
        List<TsUsageReport> tsUsages = getAvailableTSList();
        LoadValue value = new LoadValue();
        for (TsUsageReport tsu: tsUsages) {
            for (Long tabletId: tsu.getTablets()) {
                if (schemaId == OmapUtils.tid2sid(tabletId)) {
                    value.add(tsu.getTabletLoad(tabletId));
                }
            }
        }
        return value;
    }

    /**
     * Snapshot a Table, save the data of a Table at the moment to a directory
     * which can be used to restore the whole data of the Table in the future.
     * 
     * @param tableName
     *            the Table to be snapshot
     * @param targetDir
     * @param checkpoint
     *            if set to true, checkpoint before snapshot
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    public void snapshot(String tableName, String targetDir, boolean checkpoint)
            throws IOException {
        OmapMetadata metadata = masterCatalogue.findMetadata(tableName);
        TableDesc td = metadata.getTableDesc();
        LOG.info("Begin to snapshot " + metadata + " to " + targetDir);

        Path target = new Path(targetDir);
        if (!nfs.exists(target)) {
            nfs.mkdirs(target);
        }

        // disable split
        tablesToBeSnapshot.put(td.getSchemaId(), td.getSchemaId());
        try {
            // wait for all current split done
            waitForTask(td.getSchemaId(), SplitTabletTask.class);

            // checkpoint Tablets
            if (checkpoint) {
                Map<TsDesc, Collection<KeyRange>> tablets = masterCatalogue.groupTabletsByTable(td.getSchemaId());
                for (Entry<TsDesc, Collection<KeyRange>> entry: tablets.entrySet()) {
                    ArrayList<Long> tabletIds = new ArrayList<Long>();
                    for (KeyRange kr: entry.getValue()) {
                        tabletIds.add(kr.getTabletId());
                    }
                    CheckpointTask task = new CheckpointTask(tabletIds,
                            "prepare for snapshot");
                    addTask(entry.getKey(), task, true, true);
                }
            }
            // Writing OmapMetadata
            Path tableDescFile = new Path(targetDir + File.separator
                    + "tableDesc");
            FSDataOutputStream tdStream = nfs.create(tableDescFile);
            td.writeFields(tdStream);
            tdStream.close();

            // wait for all CheckpointTask done
            if (checkpoint) {
                waitForTask(td.getSchemaId(), CheckpointTask.class);
            }

            // Write KeyRangeList
            List<KeyRange> krs = masterCatalogue.getTablets(td.getSchemaId());
            KeyRangeList krl = new KeyRangeList(krs);
            Path krlFile = new Path(targetDir + File.separator + "keyRangeList");
            FSDataOutputStream krlStream = nfs.create(krlFile);
            krl.writeFields(krlStream);
            krlStream.close();
            // link SSTable files
            Path tsDir = new Path(targetDir + File.separator + "ts");
            if (!nfs.exists(tsDir)) {
                nfs.mkdirs(tsDir);
            }

            // ln sstablefiles
            for (KeyRange kr: masterCatalogue.getTablets(td.getSchemaId())) {
                long tabletId = kr.getTabletId();
                Path source = new Path(OmapUtils.getSSTableFileDirPath(
                        tabletDir, tabletId));
                Path dest = new Path(OmapUtils.getSSTableFileDirPath(
                        tsDir.getPath(), tabletId));

                nfs.mkdirs(new Path(dest.getParent()));
                LOG.info("snapshot link " + source + "->" + dest);
                nfs.link(source, dest);
            }

            LOG.info("Snapshot done");
        } finally {
            // enable split
            tablesToBeSnapshot.remove(td.getSchemaId());
        }
    }

    /**
     * Import a saved snapshot into OMAP. Will create a new Table and import the
     * data from the snapshot.
     * 
     * @param tableName
     *            the name of the created table
     * @param dir
     *            the snapshot dir
     * @throws OmapException
     */
    public void importSnapshot(String tableName, String dir)
            throws OmapException {
        try {
            // detect duplicate table definition
            try {
                masterCatalogue.getSchemaId(tableName);
                throw new TableExistException("Table " + tableName
                        + " already exists");
            } catch (NoSuchSchemaException e) {}
            LOG.info("Importing from snapshot " + dir + " to " + tableName);

            // read OmapMetadata
            TableDesc td = new TableDesc();
            Path tableDescFile = new Path(dir + File.separator + "tableDesc");
            FSDataInputStream tdStream = nfs.open(tableDescFile);
            td.readFields(tdStream);
            tdStream.close();

            // insert the new TableDesc
            td.setTableName(tableName);
            td.setSchemaId(masterCatalogue.getNextSchemaIdAndIncrement());
            addAclInfoToTableDesc(td);
            OmapMetadata metadata = new OmapMetadata(td,
                    OmapQueryUtils.EMPTY_QUERY_MAP,
                    OmapQueryUtils.EMPTY_INDEX_MAP);
            masterCatalogue.addSchema(metadata);

            // read KeyRangeList
            KeyRangeList oldkrl = new KeyRangeList();
            Path krlFile = new Path(dir + File.separator + "keyRangeList");
            FSDataInputStream krlStream = nfs.open(krlFile);
            oldkrl.readFields(krlStream);
            krlStream.close();

            // check KeyRange coverage
            IWritableComparable lastEndKey = OmapUtils.checkKeyRangeCoverage(oldkrl);
            if (!KeyPair.MAX_WRITABLE.equals(lastEndKey)) {
                throw new RuntimeException(
                        "KeyRange coverage check failed, last valid key is "
                                + lastEndKey);
            }

            // map old tableIds to new tabletIds and link SSTables
            Path tsDir = new Path(dir + File.separator + "ts");
            List<KeyRange> newkrl = new ArrayList<KeyRange>();
            for (KeyRange kr: oldkrl.getRangeSet().values()) {
                long newTabletId = getNextTabletId(td.getSchemaId());
                KeyRange newkr = new KeyRange(kr.getKey1(), kr.getKey2(),
                        TsDesc.getDummyTsDesc(), newTabletId);
                newkrl.add(newkr);
                Path source = new Path(OmapUtils.getSSTableFileDirPath(
                        tsDir.getPath(), kr.getTabletId()));
                Path dest = new Path(OmapUtils.getSSTableFileDirPath(
                        OmapConfig.getTsTabletDir(), newTabletId));
                nfs.mkdirs(new Path(dest.getParent()));
                LOG.info("link " + source + " to " + dest);
                nfs.link(source, dest);
            }

            // create Tablets
            assignTabletsForImportedTable(td.getSchemaId(),
                    newkrl.toArray(new KeyRange[newkrl.size()]), true);
            LOG.info("Snapshot " + dir + " successfully restored as " + td);
        } catch (IOException e) {
            throw new OmapException(e);
        }
    }

    public KeyRangeList lookupKey(String tableName, ByteArrayWritable key,
            int prefetch_hint) throws IOException {
        long start = System.currentTimeMillis();
        Pair<OmapMetadata, MasterTableMetricsEntry> pair = masterCatalogue.findMetadataAndMetricsEntry(tableName);
        TableDesc td = pair.getFirst().getTableDesc();
        KeyCell keyCell = td.getKey().borrowKeyCell();
        KeyCell.keyCellFromBinaryKey(keyCell, key.data());
        KeyRangeList krl = lookupKey(td.getSchemaId(), keyCell.getKey(),
                prefetch_hint);
        long delay = System.currentTimeMillis() - start;
        pair.getSecond().lookupKey(delay);
        return krl;
    }

    public KeyRangeList lookupKey(long schemaId, IWritableComparable key,
            int prefetch_hint) {
        KeyRangeList krlist = new KeyRangeList();
        KeyRange kr = masterCatalogue.findKeyRange(schemaId, key);
        krlist.insert(kr);
        return krlist;
    }

    /**
     * Check load balance between TSes and migrate Tablets
     * 
     * @author zhangkun
     */
    private class LoadBalanceTask implements Runnable {

        private final double mirateThreshold = OmapConfig.getConfiguration().getDouble(
                OmapConfig.NAME_LOAD_BALANCE_MIGRATE_THRESHOLD,
                OmapConfig.DEFAULT_LOAD_BALANCE_MIGRATE_THRESHOLD);

        private void balanceByTabletsNumber(List<TsUsageReport> availTses)
                throws IOException {

            TsUsageReport mostTs = null;
            TsUsageReport leastTs = null;

            for (TsUsageReport ts: availTses) {
                TsDesc desc = ts.getTsDesc();
                if (!hasMigrationTask(desc)) {
                    if (mostTs == null
                            || ts.getNumTablets() > mostTs.getNumTablets()) {
                        mostTs = ts;
                    }
                    if (leastTs == null
                            || ts.getNumTablets() < leastTs.getNumTablets()) {
                        leastTs = ts;
                    }
                }
            }
            if (mostTs != null && leastTs != null
                    && mostTs.getNumTablets() - leastTs.getNumTablets() > 1) {
                List<KeyRange> mostLoadedTablets = masterCatalogue.groupTabletsByTs().get(
                        mostTs.getTsDesc());
                if (mostLoadedTablets != null) {
                    for (TsUsageReport.TabletLoadPair pair: mostTs.getSortedTabletsLoad()) {
                        boolean found = false;
                        // check if TS really managed this tablet
                        for (KeyRange kr: mostLoadedTablets) {
                            if (kr.getTabletId() == pair.id) {
                                found = true;
                                break;
                            }
                        }
                        if (found && !duringSplit(mostTs.getTsDesc(), pair.id)) {
                            LOG.info("Migrate "
                                    + HexString.longToPaddedHex(pair.id)
                                    + " from " + mostTs.getTsDesc() + " to "
                                    + leastTs.getTsDesc()
                                    + " for tablet number balance");
                            LoadValue loadValue = mostTs.getTabletLoad(pair.id);
                            migrate(pair.id, mostTs.getTsDesc(),
                                    leastTs.getTsDesc(), loadValue,
                                    "migrate to balance TS tablet number : "
                                            + mostTs.getNumTablets() + " -> "
                                            + leastTs.getNumTablets());
                            return;
                        }
                    }
                }
            }
        }

        private final int balanceByLoadHeartbeatThreshold = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_BALANCE_BY_LOAD_HEARTBEAT_THRESHOLD,
                OmapConfig.DEFAULT_BALANCE_BY_LOAD_HEARTBEAT_THRESHOLD);

        private boolean balanceByLoadValue(List<TsUsageReport> availTses)
                throws IOException {

            boolean need = false;
            for (TsUsageReport ts: availTses) {
                if (ts.getHeartBeatSeq() > balanceByLoadHeartbeatThreshold) {
                    need = true;
                    break;
                }
            }
            if (!need) {
                return false;
            }
            TsUsageReport leastLoaded = null;
            TsUsageReport mostLoaded = null;
            for (TsUsageReport ts: availTses) {
                if ((leastLoaded == null || ts.getLoadValue() < leastLoaded.getLoadValue())
                        && !ts.underCriticalLoad()
                        && !hasAssignTask(ts.getTsDesc())) {
                    leastLoaded = ts;
                }
                if ((mostLoaded == null || ts.getLoadValue() > mostLoaded.getLoadValue())
                        && ts.getNumTablets() > 1
                        && !hasMigrationTask(ts.getTsDesc())) {
                    mostLoaded = ts;
                }
            }

            if (leastLoaded == null
                    || mostLoaded == null
                    || leastLoaded.equals(mostLoaded)
                    || (double) mostLoaded.getLoadValue()
                            / leastLoaded.getLoadValue() < mirateThreshold) {
                return true;
            }

            Map<TsDesc, List<KeyRange>> tabletsByTs = masterCatalogue.groupTabletsByTs();
            List<KeyRange> mostLoadedTablets = tabletsByTs.get(mostLoaded.getTsDesc());

            for (TsUsageReport.TabletLoadPair pair: mostLoaded.getSortedTabletsLoad()) {
                boolean found = false;
                // check if TS really managed this tablet
                for (KeyRange kr: mostLoadedTablets) {
                    if (kr.getTabletId() == pair.id) {
                        found = true;
                        break;
                    }
                }
                if (found
                        && !duringSplit(mostLoaded.getTsDesc(), pair.id)
                        && mostLoaded.getLoadValue() - pair.load > leastLoaded.getLoadValue()
                                + (pair.load / 16)) {
                    LOG.info("Migrate " + pair.id + " from "
                            + mostLoaded.getTsDesc() + " to "
                            + leastLoaded.getTsDesc() + " for load balance");
                    LoadValue loadValue = mostLoaded.getTabletLoad(pair.id);
                    migrate(pair.id,
                            mostLoaded.getTsDesc(),
                            leastLoaded.getTsDesc(),
                            loadValue,
                            "migrate to balance TS loads: "
                                    + mostLoaded.getLoadValue() + " "
                                    + leastLoaded.getLoadValue());
                    return true;
                }
            }
            return true;
        }

        public void run() {
            LOG.info("Checking load balance among TSes..");
            if (getNumOfAvailableTs() < 2) {
                return; // nothing to do
            }
            try {
                List<TsUsageReport> availTses = getAvailableTSList();
                if (!balanceByLoadValue(availTses)) {
                    balanceByTabletsNumber(availTses);
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "Exception in LoadBalanceTask", t);
            }
        }
    }

    // check the timeout tasks
    private void checkTasks() {
        synchronized (aliveTsMap) {
            LOG.info("There are " + aliveTsMap.size() + " live Ts");
            if (aliveTsMap.isEmpty()) {
                return; // no ts nothing to check
            }
        }
        // first see if all table assignment has gone through
        // and clean up timed-out tasks
        synchronized (taskQueues) {
            try {
                TreeMap<Long, Task> dummyTasks = taskQueues.get(TsDesc.getDummyTsDesc());
                if (dummyTasks != null) {
                    Iterator<Task> taskIter = dummyTasks.values().iterator();
                    while (taskIter.hasNext()) {
                        Task task = taskIter.next();
                        if (task instanceof AssignTabletTask) {
                            AssignTabletTask at = (AssignTabletTask) task;
                            List<TsDesc> newTS = getTSForAssignTabletTask(1,
                                    true);
                            if (!newTS.isEmpty()) {
                                at.reassignTs(newTS.get(0),
                                        "reassign timed-out AssignTabletTasks to an available TS");
                                addTask(at.getAssignedTs(), at, false, true);
                                taskIter.remove();
                            }
                        }
                    }
                    if (dummyTasks.isEmpty()) {
                        taskQueues.remove(TsDesc.getDummyTsDesc());
                    }
                }
                Iterator<Map.Entry<TsDesc, TreeMap<Long, Task>>> iter = taskQueues.entrySet().iterator();
                while (iter.hasNext()) {
                    Map.Entry<TsDesc, TreeMap<Long, Task>> entry = iter.next();
                    TsDesc tsDesc = entry.getKey();
                    TreeMap<Long, Task> tasks = entry.getValue();
                    if (!tsDesc.isDummyTs()) {
                        boolean alive;
                        synchronized (aliveTsMap) {
                            alive = aliveTsMap.containsKey(tsDesc);
                        }
                        if (!alive && tasks != null && !tasks.isEmpty()) {
                            String msg = tsDesc
                                    + " is already dead, but it has unfinished tasks "
                                    + Arrays.toString(tasks.values().toArray());
                            LOG.severe(msg);
                            AlertUtils.alert(masterName + " unfinished tasks",
                                    msg, false, true);
                        }
                    }
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "Exception when checking tasks", t);
            }
        }
    }

    private class CheckTasksTask implements Runnable {

        @Override
        public void run() {
            checkTasks();
        }

    }

    private boolean hasAssignTask(TsDesc ts) {
        boolean hasAssignTask = false;
        synchronized (taskQueues) {
            Map<Long, Task> tasks = taskQueues.get(ts);
            if (tasks != null) {
                for (Task task: tasks.values()) {
                    if (task instanceof AssignTabletTask) {
                        hasAssignTask = true;
                        break;
                    }
                }
            }
        }
        return hasAssignTask;
    }

    private boolean duringSplit(TsDesc ts, long tabletId) {
        synchronized (taskQueues) {
            Map<Long, Task> tasks = taskQueues.get(ts);
            if (tasks != null) {
                for (Task task: tasks.values()) {
                    if (task instanceof SplitTabletTask) {
                        if (((SplitTabletTask) task).oldId == tabletId) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private boolean hasMigrationTask(TsDesc ts) {
        boolean hasMigrationTask = false;
        synchronized (taskQueues) {
            Map<Long, Task> tasks = taskQueues.get(ts);
            if (tasks != null) {
                for (Task task: tasks.values()) {
                    if (task instanceof AssignTabletTask
                            || task instanceof CloseTabletTask) {
                        hasMigrationTask = true;
                        break;
                    }
                }
            }
        }
        return hasMigrationTask;
    }

    /**
     * Get available TSes for a Tablet assignment. TS that is under critical
     * will be excluded.
     * 
     * @param number
     *            how many TS needed
     * @param excludeHavingAssignsTses
     *            if true, will exclude TSes that have AssignTabletTasks
     *            running.
     * @return a list of available TSes, may be less than the requested number
     */
    private List<TsDesc> getTSForAssignTabletTask(int number,
            boolean excludeHavingAssignsTses) {
        ArrayList<TsDesc> result = new ArrayList<TsDesc>();
        if (number == 0) {
            return result;
        }
        List<TsDesc> underCriticalLoadTses = new ArrayList<TsDesc>();
        List<TsUsageReport> availTses = getAvailableTSList();
        for (TsUsageReport tsu: availTses) {
            if (!(excludeHavingAssignsTses && hasAssignTask(tsu.getTsDesc()))) {
                if (tsu.underCriticalLoad()) {
                    underCriticalLoadTses.add(tsu.getTsDesc());
                } else {
                    result.add(tsu.getTsDesc());
                    if (result.size() >= number) {
                        break;
                    }
                }
            }
        }
        if (!result.isEmpty()) {
            return result;
        }
        // we have no normal ts, return ts under critical load
        return underCriticalLoadTses;
    }

    /**
     * Recover Tablets from dead TSes by reassigning them to other live TSes.<br>
     * Delete deadTs tasks first
     * 
     * @param deadTsList
     */
    private void recoverFromDeadTSes(Collection<TsDesc> deadTsList)
            throws IOException {
        int expectedSplitBufferSize = 6 * OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_WAL_CHUNK_SIZE,
                OmapConfig.DEFAULT_WAL_CHUNK_SIZE) / 5;
        NativeRamBuffer splitBuffer = new NativeRamBuffer(
                UnsafeHelper.unsafe.allocateMemory(expectedSplitBufferSize),
                expectedSplitBufferSize);
        try {
            for (TsDesc deadTsDesc: deadTsList) {
                recoverTsTasks(deadTsDesc, true);
                Path recoverLogPath = prepareWALogsForRecovery(deadTsDesc);
                if (recoverLogPath != null) {
                    recoverTsTablets(deadTsDesc, recoverLogPath, true,
                            splitBuffer);
                }
            }
        } finally {
            UnsafeHelper.unsafe.freeMemory(splitBuffer.getPtr());
        }
    }

    public int getTasks(Map<Task, TsDesc> map, int maxCount) {
        int count = 0;
        synchronized (taskQueues) {
            for (Map.Entry<TsDesc, TreeMap<Long, Task>> entry: taskQueues.entrySet()) {
                TsDesc ts = entry.getKey();
                TreeMap<Long, Task> tasks = entry.getValue();
                for (Task task: tasks.values()) {
                    if (map.size() < maxCount) {
                        map.put(task, ts);
                    }
                    count++;
                }
            }
        }
        return count;
    }

    // //////////////////////////////
    // MBean Interface
    // //////////////////////////////

    public String getMasterName() {
        return masterName;
    }

    public int getMasterPort() {
        return masterPort;
    }

    public int getNumOfAvailableTs() {
        synchronized (aliveTsMap) {
            return tsUsageSet.size();
        }
    }

    public int getNumOfTasks() {
        int size = 0;
        synchronized (taskQueues) {
            for (TreeMap<Long, Task> tasks: taskQueues.values()) {
                size += tasks.size();
            }
        }
        return size;
    }

    @Override
    public String toString() {
        return "[OmapMaster name=" + masterName + " startTime=" + startTime
                + "]";
    }

    /**
     * Return a human-readable description of the current configuration of this
     * OMap service, which can be used as a reference to benchmark results.
     * 
     * @return
     */
    public String dumpServiceConfigurations() {
        StringBuilder buffer = new StringBuilder();
        buffer.append("Configuration dump of " + this.toString()).append(":\n");
        buffer.append("Current time: " + new Date() + "\n");
        buffer.append("Configurations:\n");
        TreeSet<String> configKeys = new TreeSet<String>(
                OmapConfig.getValidKeys());
        for (String configKey: configKeys) {
            buffer.append("\t");
            if (OmapConfig.getConfiguration().containsKey(configKey)) {
                buffer.append(configKey + "="
                        + OmapConfig.getConfiguration().getString(configKey));
            } else {
                buffer.append(configKey + "="
                        + OmapConfig.getDefaultValue(configKey) + " (default)");
            }
            buffer.append("\n");
        }
        synchronized (aliveTsMap) {
            buffer.append(this.tsUsageSet.size() + " Tablet Servers:\n");
            for (TsUsageReport tsr: this.tsUsageSet) {
                buffer.append("\t").append(tsr.getTsDesc()).append("\n");
            }
        }
        buffer.append("End of configuration dump.\n");
        return buffer.toString();
    }

    @Override
    public OmapMetadata getMetadata(long schemaId) throws RpcException {
        long start = System.currentTimeMillis();
        Pair<OmapMetadata, MasterTableMetricsEntry> pair = masterCatalogue.findMetadataAndMetricsEntry(schemaId);
        if (pair == null) {
            return null;
        }
        long delay = System.currentTimeMillis() - start;
        pair.getSecond().getMetadata(delay);
        return pair.getFirst();
    }

    @Override
    public long getSchemaId(String tableName) throws RpcException {
        long start = System.currentTimeMillis();
        Pair<Long, MasterTableMetricsEntry> pair = masterCatalogue.getSchemaIdAndMetricsEntry(tableName);
        long delay = System.currentTimeMillis() - start;
        pair.getSecond().getSchemaId(delay);
        return pair.getFirst();
    }

    @SuppressWarnings("unchecked")
    @Override
    public void setTableProperties(long schemaId, String[] properties)
            throws RpcException, IOException {
        OmapMetadata oldMetadata = masterCatalogue.findMetadata(schemaId);
        if (oldMetadata == null) {
            throw new NoSuchSchemaException("schemaId = " + schemaId
                    + " not found");
        }
        oldMetadata.getTableDesc().validatePermission(PermissionType.EXECUTE);
        OmapMetadata newMetadata = new OmapMetadata();
        newMetadata.copyFields(oldMetadata);
        TableDesc desc = newMetadata.getTableDesc();
        Map<String, String> props = desc.getProperties();
        for (int i = 0; i < properties.length; i += 2) {
            props.put(properties[i], properties[i + 1]);
            // set replication number for exist tablet
            if (properties[i].equals(Table.Property.REPLICATION_NAME)) {
                String tabletDir = OmapConfig.getTsTabletDir();
                byte replicationNumber = Byte.parseByte(properties[i + 1]);
                // all tablets are stored in this folder
                Path tabletPath = new Path(
                        OmapUtils.getTabletFileDirByTableSchemaId(tabletDir,
                                schemaId));
                if (nfs instanceof DistributedFileSystem) {
                    ((DistributedFileSystem) nfs).setReplication(tabletPath,
                            replicationNumber, true);
                } else {
                    LOG.warning("only DistributedFileSystem can set ReplicationNumber");
                }
            }
        }
        masterCatalogue.updateSchema(newMetadata);
        List<TsDesc> tses;
        synchronized (aliveTsMap) {
            tses = new ArrayList<TsDesc>(aliveTsMap.keySet());
        }
        for (TsDesc tsDesc: tses) {
            addTask(tsDesc,
                    new ClearTableMetaTask(schemaId, desc.getTableName(),
                            "change table properties"), true, true);
        }
        waitForTask(schemaId, ClearTableMetaTask.class);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void renameTable(String originName, String currName)
            throws OmapException, RpcException, IOException {
        LOG.info("Rename table from " + originName + " to " + currName);
        if (OmapUtils.isIndexTable(originName)) {
            throw new OmapException("Can not rename an index table: "
                    + originName);
        }
        OmapMetadata metaData = masterCatalogue.findMetadata(originName);
        if (metaData == null) {
            throw new NoSuchSchemaException("TableName = " + originName
                    + " not found");
        }
        metaData.getTableDesc().validatePermission(PermissionType.EXECUTE);

        long schemaId = masterCatalogue.changeTableName(originName, currName);

        //Sync metadata to TS. This is not necessary now, 
        //because there is not concept of table name in TS. 
        //But maybe this reason is not correct in future.
        synchronized (aliveTsMap) {
            for (TsDesc tsDesc: aliveTsMap.keySet()) {
                addTask(tsDesc, new ClearTableMetaTask(schemaId, originName,
                        "change table name"), true, true);
            }
        }
        waitForTask(schemaId, ClearTableMetaTask.class);
    }

    @Override
    public void invokeTsMethod(String methodName, IWritable[] parameters)
            throws RpcException {
        throw new UnsupportedOperationException();
    }

    @Override
    public OmapMetadata[] getTables(String tableSpaceName) throws RpcException {
        long start = System.currentTimeMillis();
        OmapMetadata[] ret = masterCatalogue.getTables(tableSpaceName).toArray(
                new OmapMetadata[0]);
        long delay = System.currentTimeMillis() - start;
        globalMetricsEntry.getTablesInSpace(delay);
        return ret;
    }

    @Override
    public String[] getTableSpaces() throws RpcException {
        long start = System.currentTimeMillis();
        String[] ret = masterCatalogue.getTableSpaces();
        long delay = System.currentTimeMillis() - start;
        globalMetricsEntry.getTableSpaces(delay);
        return ret;
    }

    private void addAclInfoToTableDesc(TableDesc td) {
        if (RPC.getClientInfo() != null) {
            td.getProperties().put(Table.Property.ACL_OWNER_NAME,
                    RPC.getClientInfo().username);
            td.getProperties().put(Table.Property.ACL_GROUP_NAME, "");
            td.getProperties().put(
                    Table.Property.ACL_PERMISSION_NAME,
                    OmapConfig.getConfiguration().getString(
                            OmapConfig.NAME_ACL_DEFAULT_PERMISSION,
                            OmapConfig.DEFAULT_ACL_DEFAULT_PERMISSION));
        }
    }

    @Override
    public Task requestSplit(long tabletId, TsDesc tsDesc) throws RpcException {
        long schemaId = OmapUtils.tid2sid(tabletId);
        if (checkGoodToSplit(tabletId, tsDesc)) {
            SplitTabletTask task = new SplitTabletTask(tabletId,
                    this.getNextTabletId(schemaId),
                    this.getNextTabletId(schemaId),
                    masterCatalogue.findMetadata(schemaId).getTableDesc(),
                    "split requested by " + tsDesc);
            addTask(tsDesc, task, true, true);
        }
        return null;
    }

    @Override
    public MasterMetricsEntry getMetricsEntry() throws RpcException {
        MasterGlobalMetricsEntry globalMetricsEntry = new MasterGlobalMetricsEntry();
        this.globalMetricsEntry.copyToAndClear(globalMetricsEntry);
        globalMetricsEntry.updateSystemInfo();
        Map<Long, MasterTableMetricsEntry> tableMetricsEntries = masterCatalogue.getTableMetricsEntries();
        globalMetricsEntry.setTableNumber(tableMetricsEntries.size());
        globalMetricsEntry.setTabletNumber(masterCatalogue.getTabletNum());
        return new MasterMetricsEntry(masterName, globalMetricsEntry,
                tableMetricsEntries);
    }

    @Override
    public void reserveTableWALog(String tableName, String targetDir)
            throws IOException, RpcException {
        Path path = new Path(targetDir);
        Path omapDataRoot = new Path(OmapConfig.getOmapDataRoot());
        if (!path.isAbsolute()) {
            throw new IllegalArgumentException(
                    "The targetDir should be absolute path: " + path);
        }
        boolean validate = true;
        if (validate && path.equals(omapDataRoot)) {
            validate = false;
        }
        Path temp = path;
        while (validate && (temp = temp.getParentFile()) != null) {
            if (temp.equals(omapDataRoot)) {
                validate = false;
            }
        }
        temp = omapDataRoot;
        while (validate && (temp = temp.getParentFile()) != null) {
            if (temp.equals(path)) {
                validate = false;
            }
        }
        if (!validate) {
            throw new IllegalArgumentException("The targetDir (" + path
                    + ") should not be relative to omap root: " + omapDataRoot);
        }
        long schemaId = getSchemaId(tableName);
        setTableProperties(schemaId, new String[] {
            Table.Property.RESERVE_WAL_PATH_NAME, targetDir
        });
    }

    @Override
    public void stopReserveTableWALog(String tableName) throws IOException,
            RpcException {
        long schemaId = getSchemaId(tableName);
        setTableProperties(schemaId, new String[] {
            Table.Property.RESERVE_WAL_PATH_NAME,
            Table.Property.DEFAULT_RESERVE_WAL_PATH
        });
    }

    @Override
    public void setReadOnly(long schemaId, boolean readOnly)
            throws RpcException {
        throw new UnsupportedOperationException();
    }
}
