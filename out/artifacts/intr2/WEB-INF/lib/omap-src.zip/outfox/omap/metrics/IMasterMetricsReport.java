/**
 * @(#)IMasterMetricsReport.java, 2011-6-2. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import odis.rpc2.RpcException;

/**
 * @author zhangduo
 */
public interface IMasterMetricsReport {
    MasterMetricsEntry getMetricsEntry() throws RpcException;
}
