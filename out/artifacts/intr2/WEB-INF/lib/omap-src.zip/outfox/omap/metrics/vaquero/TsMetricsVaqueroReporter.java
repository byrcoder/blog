/**
 * @(#)TsMetricsReporter.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

import java.util.ArrayList;
import java.util.List;

import outfox.omap.conf.OmapConfig;
import outfox.omap.metrics.TsMetricsEntry;
import outfox.omap.metrics.TsMetricsType;
import outfox.omap.metrics.TsTabletMetricsEntry;
import vaquero.client.udp.AnalyzerMooee;

/**
 * @author zhangduo
 */
public class TsMetricsVaqueroReporter {
    private final List<Updater> globalUpdaters;

    private final List<Updater> tabletUpdaters;

    private final AnalyzerMooee mooee;

    private long prevTime;

    private void initUpdater() {
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.NUM_TABLET.getVaqueroPropName(),
                TsMetricsType.GLOBAL_TABLET_NUM.offset()));

        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.SYSTEM_LOAD.getVaqueroPropName(),
                TsMetricsType.GLOBAL_SYSTEM_LOAD.offset(), 100));
        globalUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.SYSTEM_LOAD_PER_PROCESSOR.getVaqueroPropName(),
                TsMetricsType.GLOBAL_SYSTEM_LOAD.offset(),
                TsMetricsType.GLOBAL_PROCESSOR_NUM.offset(), 100));

        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.MEMORY_INIT.getVaqueroPropName(),
                TsMetricsType.GLOBAL_MEMORY_INIT.offset(), 1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.MEMORY_USED.getVaqueroPropName(),
                TsMetricsType.GLOBAL_MEMORY_USED.offset(), 1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.MEMORY_COMMITTED.getVaqueroPropName(),
                TsMetricsType.GLOBAL_MEMORY_COMMITTED.offset(),
                1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.MEMORY_MAX.getVaqueroPropName(),
                TsMetricsType.GLOBAL_MEMORY_MAX.offset(), 1024 * 1024 * 1024));

        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.WRITE_BUFFER_USED.getVaqueroPropName(),
                TsMetricsType.GLOBAL_WRITE_BUFFER_USED.offset(),
                1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.WRITE_BUFFER_MAX.getVaqueroPropName(),
                TsMetricsType.GLOBAL_WRITE_BUFFER_MAX.offset(),
                1024 * 1024 * 1024));

        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.BLOOMFILTER_USED.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOOMFILTER_USED.offset(),
                1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.BLOOMFILTER_MAX.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOOMFILTER_MAX.offset(),
                1024 * 1024 * 1024));

        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.INDEX_POOL_USED.getVaqueroPropName(),
                TsMetricsType.GLOBAL_INDEX_POOL_USED.offset(),
                1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.INDEX_POOL_MAX.getVaqueroPropName(),
                TsMetricsType.GLOBAL_INDEX_POOL_MAX.offset(),
                1024 * 1024 * 1024));

        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.BLOCK_CACHE_USED.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOCK_CACHE_USED.offset(),
                1024 * 1024 * 1024));
        globalUpdaters.add(new OpNum(
                TsMetricsVaqueroType.BLOCK_CACHE_MAX.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOCK_CACHE_MAX.offset(),
                1024 * 1024 * 1024));

        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_HEARTBEAT.getVaqueroPropName(),
                TsMetricsType.GLOBAL_HEARTBEAT_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_HEARTBEAT.getVaqueroPropName(),
                TsMetricsType.GLOBAL_HEARTBEAT_DELAY.offset(),
                TsMetricsType.GLOBAL_HEARTBEAT_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_SSTABLE_SEEK.getVaqueroPropName(),
                TsMetricsType.GLOBAL_SSTABLE_SEEK_COUNT.offset()));
        globalUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_SSTABLE_SEEK.getVaqueroPropName(),
                TsMetricsType.GLOBAL_SSTABLE_SEEK_DELAY.offset(),
                TsMetricsType.GLOBAL_SSTABLE_SEEK_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_CACHE.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOCK_CACHE_CACHE_COUNT.offset()));
        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_GET.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOCK_CACHE_GET_COUNT.offset()));
        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_GET_HIT.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOCK_CACHE_GET_HIT_COUNT.offset()));
        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_EVICT.getVaqueroPropName(),
                TsMetricsType.GLOBAL_BLOCK_CACHE_EVICT_COUNT.offset()));

        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_REQUEST.getVaqueroPropName(),
                TsMetricsType.GLOBAL_REQUEST_NUM.offset()));
        globalUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_TIMEOUT_REQUEST.getVaqueroPropName(),
                TsMetricsType.GLOBAL_TIMEOUT_REQUEST_NUM.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_KEY_FIND.getVaqueroPropName(),
                TsMetricsType.KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_KEY_FIND_SIZE.getVaqueroPropName(),
                TsMetricsType.KEY_FIND_SIZE.offset(), 1024 * 1024));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.SIZE_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.KEY_FIND_SIZE.offset(),
                TsMetricsType.KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_KEY_FIND.getVaqueroPropName(),
                TsMetricsType.KEY_FIND_DELAY.offset(),
                TsMetricsType.KEY_FIND_COUNT.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_KEY_FIND.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_KEY_FIND_ROWS.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_ROWS.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_KEY_FIND_SIZE.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_SIZE.offset(), 1024 * 1024));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.ROWS_MULTI_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_ROWS.offset(),
                TsMetricsType.MULTI_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.SIZE_MULTI_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_SIZE.offset(),
                TsMetricsType.MULTI_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_KEY_FIND.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_DELAY.offset(),
                TsMetricsType.MULTI_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_KEY_FIND_PER_ROW.getVaqueroPropName(),
                TsMetricsType.MULTI_KEY_FIND_DELAY.offset(),
                TsMetricsType.MULTI_KEY_FIND_ROWS.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_RANGE_KEY_FIND.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_RANGE_KEY_FIND_ROWS.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_ROWS.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_RANGE_KEY_FIND_SIZE.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_SIZE.offset(), 1024 * 1024));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.ROWS_RANGE_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_ROWS.offset(),
                TsMetricsType.RANGE_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.SIZE_RANGE_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_SIZE.offset(),
                TsMetricsType.RANGE_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_RANGE_KEY_FIND.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_DELAY.offset(),
                TsMetricsType.RANGE_KEY_FIND_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_RANGE_KEY_FIND_PER_ROW.getVaqueroPropName(),
                TsMetricsType.RANGE_KEY_FIND_DELAY.offset(),
                TsMetricsType.RANGE_KEY_FIND_ROWS.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_CONTAINS.getVaqueroPropName(),
                TsMetricsType.CONTAINS_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_CONTAINS.getVaqueroPropName(),
                TsMetricsType.CONTAINS_DELAY.offset(),
                TsMetricsType.CONTAINS_COUNT.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_CONTAINS.getVaqueroPropName(),
                TsMetricsType.MULTI_CONTAINS_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_CONTAINS_ROWS.getVaqueroPropName(),
                TsMetricsType.MULTI_CONTAINS_ROWS.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.ROWS_MULTI_CONTAINS_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.MULTI_CONTAINS_ROWS.offset(),
                TsMetricsType.MULTI_CONTAINS_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_CONTAINS.getVaqueroPropName(),
                TsMetricsType.MULTI_CONTAINS_DELAY.offset(),
                TsMetricsType.MULTI_CONTAINS_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_CONTAINS_PER_ROW.getVaqueroPropName(),
                TsMetricsType.MULTI_CONTAINS_DELAY.offset(),
                TsMetricsType.MULTI_CONTAINS_ROWS.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_INSERT.getVaqueroPropName(),
                TsMetricsType.INSERT_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_INSERT_SIZE.getVaqueroPropName(),
                TsMetricsType.INSERT_SIZE.offset(), 1024 * 1024));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.SIZE_INSERT_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.INSERT_SIZE.offset(),
                TsMetricsType.INSERT_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_INSERT.getVaqueroPropName(),
                TsMetricsType.INSERT_DELAY.offset(),
                TsMetricsType.INSERT_COUNT.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_INSERT.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_INSERT_ROWS.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_ROWS.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_INSERT_SIZE.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_SIZE.offset(), 1024 * 1024));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.ROWS_MULTI_INSERT_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_ROWS.offset(),
                TsMetricsType.MULTI_INSERT_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.SIZE_MULTI_INSERT_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_SIZE.offset(),
                TsMetricsType.MULTI_INSERT_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_INSERT.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_DELAY.offset(),
                TsMetricsType.MULTI_INSERT_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_INSERT_PER_ROW.getVaqueroPropName(),
                TsMetricsType.MULTI_INSERT_DELAY.offset(),
                TsMetricsType.MULTI_INSERT_ROWS.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_DELETE.getVaqueroPropName(),
                TsMetricsType.DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_DELETE.getVaqueroPropName(),
                TsMetricsType.DELETE_DELAY.offset(),
                TsMetricsType.DELETE_COUNT.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_DELETE.getVaqueroPropName(),
                TsMetricsType.MULTI_DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_MULTI_DELETE_ROWS.getVaqueroPropName(),
                TsMetricsType.MULTI_DELETE_ROWS.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.ROWS_MULTI_DELETE_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.MULTI_DELETE_ROWS.offset(),
                TsMetricsType.MULTI_DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_DELETE.getVaqueroPropName(),
                TsMetricsType.MULTI_DELETE_DELAY.offset(),
                TsMetricsType.MULTI_DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_MULTI_DELETE_PER_ROW.getVaqueroPropName(),
                TsMetricsType.MULTI_DELETE_DELAY.offset(),
                TsMetricsType.MULTI_DELETE_ROWS.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_RANGE_DELETE.getVaqueroPropName(),
                TsMetricsType.RANGE_DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_RANGE_DELETE_ROWS.getVaqueroPropName(),
                TsMetricsType.RANGE_DELETE_ROWS.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.ROWS_RANGE_DELETE_PER_COUNT.getVaqueroPropName(),
                TsMetricsType.RANGE_DELETE_ROWS.offset(),
                TsMetricsType.RANGE_DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_RANGE_DELETE.getVaqueroPropName(),
                TsMetricsType.RANGE_DELETE_DELAY.offset(),
                TsMetricsType.RANGE_DELETE_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_RANGE_DELETE_PER_ROW.getVaqueroPropName(),
                TsMetricsType.RANGE_DELETE_DELAY.offset(),
                TsMetricsType.RANGE_DELETE_ROWS.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_LOCK_ROW.getVaqueroPropName(),
                TsMetricsType.LOCK_ROW_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_LOCK_ROW.getVaqueroPropName(),
                TsMetricsType.LOCK_ROW_DELAY.offset(),
                TsMetricsType.LOCK_ROW_COUNT.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_LOCK_ROW.getVaqueroPropName(),
                TsMetricsType.LOCK_ROW_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_LOCK_ROW.getVaqueroPropName(),
                TsMetricsType.LOCK_ROW_DELAY.offset(),
                TsMetricsType.LOCK_ROW_COUNT.offset()));

        tabletUpdaters.add(new OpRate(
                TsMetricsVaqueroType.RATE_UNLOCK_ROW.getVaqueroPropName(),
                TsMetricsType.UNLOCK_ROW_COUNT.offset()));
        tabletUpdaters.add(new OpAvg(
                TsMetricsVaqueroType.DELAY_UNLOCK_ROW.getVaqueroPropName(),
                TsMetricsType.UNLOCK_ROW_DELAY.offset(),
                TsMetricsType.UNLOCK_ROW_COUNT.offset()));
    }

    private void initVaquero() {
        int lev = 0;
        TsMetricsVaqueroDraw draw = TsMetricsVaqueroDraw.INFO;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.NUM_TABLET.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.LOAD;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.SYSTEM_LOAD.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.LOAD_PER_PROCESSOR;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.SYSTEM_LOAD_PER_PROCESSOR.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.MEMORY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.MEMORY_INIT.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(TsMetricsVaqueroType.MEMORY_USED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                TsMetricsVaqueroType.MEMORY_COMMITTED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(TsMetricsVaqueroType.MEMORY_MAX.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.WRITE_BUFFER;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.WRITE_BUFFER_USED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                TsMetricsVaqueroType.WRITE_BUFFER_MAX.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.BLOOMFILTER;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.BLOOMFILTER_USED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                TsMetricsVaqueroType.BLOOMFILTER_MAX.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.INDEX_POOL;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.INDEX_POOL_USED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(TsMetricsVaqueroType.INDEX_POOL_MAX.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.BLOCK_CACHE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.BLOCK_CACHE_USED.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                TsMetricsVaqueroType.BLOCK_CACHE_MAX.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.HEARTBEAT_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_HEARTBEAT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.HEARTBEAT_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_HEARTBEAT.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.SSTABLE_SEEK_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_SSTABLE_SEEK.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.SSTABLE_SEEK_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_SSTABLE_SEEK.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.BLOCK_CACHE_CACHE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_CACHE.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.BLOCK_CACHE_GET_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_GET.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_GET_HIT.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.BLOCK_CACHE_EVICT_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_BLOCK_CACHE_EVICT.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.REQUEST_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_REQUEST.getVaqueroPropName(),
                draw.getDrawName());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_TIMEOUT_REQUEST.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.KEY_FIND_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_KEY_FIND.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.KEY_FIND_SIZE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_KEY_FIND_SIZE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.KEY_FIND_SIZE_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.SIZE_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.KEY_FIND_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.DELAY_KEY_FIND.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_KEY_FIND.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_ROWS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_KEY_FIND_ROWS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_SIZE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_KEY_FIND_SIZE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_ROWS_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.ROWS_MULTI_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_SIZE_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.SIZE_MULTI_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_KEY_FIND.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_KEY_FIND_PER_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_KEY_FIND_PER_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_RANGE_KEY_FIND.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_ROWS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_RANGE_KEY_FIND_ROWS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_SIZE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_RANGE_KEY_FIND_SIZE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_ROWS_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.ROWS_RANGE_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_SIZE_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.SIZE_RANGE_KEY_FIND_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_RANGE_KEY_FIND.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_KEY_FIND_PER_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_RANGE_KEY_FIND_PER_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.CONTAINS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_CONTAINS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.CONTAINS_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.DELAY_CONTAINS.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_CONTAINS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_CONTAINS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_CONTAINS_ROWS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_CONTAINS_ROWS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_CONTAINS_ROWS_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.ROWS_MULTI_CONTAINS_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_CONTAINS_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_CONTAINS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_CONTAINS_PER_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_CONTAINS_PER_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.INSERT_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_INSERT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.INSERT_SIZE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_INSERT_SIZE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.INSERT_SIZE_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.SIZE_INSERT_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.INSERT_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.DELAY_INSERT.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_INSERT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_ROWS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_INSERT_ROWS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_SIZE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_INSERT_SIZE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_ROWS_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.ROWS_MULTI_INSERT_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_SIZE_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.SIZE_MULTI_INSERT_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_INSERT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_INSERT_PER_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_INSERT_PER_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.DELETE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_DELETE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.DELETE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.DELAY_DELETE.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_DELETE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_DELETE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_DELETE_ROWS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_MULTI_DELETE_ROWS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_DELETE_ROWS_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.ROWS_MULTI_DELETE_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_DELETE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_DELETE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.MULTI_DELETE_PER_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_MULTI_DELETE_PER_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_DELETE_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_RANGE_DELETE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_DELETE_ROWS_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_RANGE_DELETE_ROWS.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_DELETE_ROWS_PER_COUNT;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.ROWS_RANGE_DELETE_PER_COUNT.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_DELETE_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_RANGE_DELETE.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.RANGE_DELETE_PER_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_RANGE_DELETE_PER_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.LOCK_ROW_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.RATE_LOCK_ROW.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.LOCK_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(TsMetricsVaqueroType.DELAY_LOCK_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.UNLOCK_ROW_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_UNLOCK_ROW.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.UNLOCK_ROW_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_UNLOCK_ROW.getVaqueroPropName(),
                draw.getDrawName());

        lev++;
        draw = TsMetricsVaqueroDraw.COMPARE_AND_SET_RATE;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.RATE_COMPARE_AND_SET.getVaqueroPropName(),
                draw.getDrawName());
        lev++;
        draw = TsMetricsVaqueroDraw.COMPARE_AND_SET_DELAY;
        mooee.addDraw(draw.getDrawName(), lev, draw.getDescription());
        mooee.addProp(
                TsMetricsVaqueroType.DELAY_COMPARE_AND_SET.getVaqueroPropName(),
                draw.getDrawName());
        mooee.moo();
    }

    public TsMetricsVaqueroReporter(long currentTime) {
        globalUpdaters = new ArrayList<Updater>();
        tabletUpdaters = new ArrayList<Updater>();
        initUpdater();
        ((ArrayList<Updater>) globalUpdaters).trimToSize();
        ((ArrayList<Updater>) tabletUpdaters).trimToSize();

        String addr = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_METRICS_VAQUERO_ADDR);
        String host = addr.split(":")[0];
        int port = Integer.parseInt(addr.split(":")[1]);
        String product = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_METRICS_VAQUERO_PRODUCT);
        mooee = new AnalyzerMooee(host, port, product, product + "_ts", "ts");
        initVaquero();

        prevTime = currentTime;
    }

    public void update(List<TsMetricsEntry> metricsEntries, long currentTime) {
        long[] globalMetricsRecords = new long[TsMetricsType.globalTypeCount()];
        long[] tabletMetricsRecords = new long[TsMetricsType.tabletTypeCount()];
        for (TsMetricsEntry metricsEntry: metricsEntries) {
            for (int i = 0; i < TsMetricsType.globalTypeCount(); i++) {
                globalMetricsRecords[i] += metricsEntry.getGlobalMetricsEntry().getMetricsRecords()[i];
            }
            for (TsTabletMetricsEntry tabletMetricsEntry: metricsEntry.getTabletMetricsEntries().values()) {
                for (int i = 0; i < TsMetricsType.tabletTypeCount(); i++) {
                    tabletMetricsRecords[i] += tabletMetricsEntry.getMetricsRecords()[i];
                }
            }
        }
        for (Updater globalUpdater: globalUpdaters) {
            globalUpdater.update(globalMetricsRecords, prevTime, currentTime);
            mooee.report(globalUpdater.getVaqueroPropName(),
                    globalUpdater.getValue());
        }
        for (Updater tableUpdater: tabletUpdaters) {
            tableUpdater.update(tabletMetricsRecords, prevTime, currentTime);
            mooee.report(tableUpdater.getVaqueroPropName(),
                    tableUpdater.getValue());
        }
        mooee.moo();
        prevTime = currentTime;
    }
}
