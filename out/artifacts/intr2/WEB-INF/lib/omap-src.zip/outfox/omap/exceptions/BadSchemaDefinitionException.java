package outfox.omap.exceptions;

public class BadSchemaDefinitionException extends RuntimeException {

    private static final long serialVersionUID = 6570195220406537654L;

    public BadSchemaDefinitionException(String message) {
        super(message);
    }

    public BadSchemaDefinitionException(String message, Throwable cause) {
        super(message, cause);
    }
}
