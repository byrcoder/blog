/**
 * @(#)OmapTs.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.Semaphore;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.LocalBackupManager;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.ClientInfo;
import odis.rpc2.RPC;
import odis.rpc2.RpcConstants;
import odis.rpc2.RpcException;
import odis.rpc2.UDPRpcServer;
import odis.serialize.lib.ByteArrayWritable;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.UnsafeHelper;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;

import outfox.omap.TsMasterProtocol;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.PermissionType;
import outfox.omap.client.protocol.Table;
import outfox.omap.common.ClientTsProtocol;
import outfox.omap.common.MasterTsProtocol;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConfig;
import outfox.omap.conf.OmapConstants;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyRange;
import outfox.omap.exceptions.TabletAlreadyExistsException;
import outfox.omap.exceptions.TabletNotFoundException;
import outfox.omap.master.Task;
import outfox.omap.metadata.KeyColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.metrics.ITsMetricsReport;
import outfox.omap.metrics.TsGlobalMetricsEntry;
import outfox.omap.metrics.TsMetricsCallListener;
import outfox.omap.metrics.TsMetricsEntry;
import outfox.omap.metrics.TsTabletMetricsEntry;
import outfox.omap.ts.OmapTsMetadataCache.MetaDataChangeListener;
import outfox.omap.ts.RowLockQueue.LockEntry;
import outfox.omap.ts.Tablet.SplitResult;
import outfox.omap.ts.insertlog.InsertLogEntry;
import outfox.omap.ts.insertlog.InsertLogger;
import outfox.omap.util.CloseableIterator;
import outfox.omap.util.NoActionWatcher;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.TabletReader;
import outfox.omap.util.ThroughputController;
import outfox.omap.util.WaitUtils;
import outfox.omap.walog.LogIterator;
import toolbox.misc.LogFormatter;
import toolbox.misc.concurrent.KeyLock;
import toolbox.misc.net.InetAddressUtils;
import toolbox.text.util.HexString;
import bsh.Interpreter;

/**
 * @author zhangduo
 */
public class OmapTs implements ClientTsProtocol, MasterTsProtocol,
        ITsMetricsReport, OmapConstants {
    private static final Logger LOG = LogFormatter.getLogger(OmapTs.class);

    public final String tabletDir;

    private final int maxSizePerRow = OmapConfig.getConfiguration().getInt(
            OmapConfig.NAME_MAX_BYTES_PER_ROW,
            OmapConfig.DEFAULT_MAX_BYTES_PER_ROW);

    final SSTableDataFileNativeCache sstableDataFileCache;

    final OmapTsMetadataCache metaCache;

    public OmapTsMetadataCache getMetaCache() {
        return metaCache;
    }

    final long nativeBufferPtr;

    final WriteBufferPool bufferPool;

    public WriteBufferPool getBufferPool() {
        return bufferPool;
    }

    final BloomFilterPool filterPool;

    public BloomFilterPool getFilterPool() {
        return filterPool;
    }

    final SparseIndexPool indexPool;

    public SparseIndexPool getIndexPool() {
        return indexPool;
    }

    final BlockCache blockCache;

    public BlockCache getBlockCache() {
        return blockCache;
    }

    /**
     * Listening port
     */
    private final int port;

    public int getPort() {
        return port;
    }

    /**
     * ts usage status
     */
    final TsUsageReport usageStat;

    public TsUsageReport getUsageStat() {
        return usageStat;
    }

    private final ConcurrentMap<Long, Tablet> tablets;

    public ConcurrentMap<Long, Tablet> getTablets() {
        return tablets;
    }

    /**
     * Prevents too many compactSS run at the same time
     */
    final Semaphore compactSSTablesMutex;

    final ThroughputController compactSSThroughputController;

    private final Map<Long, Task> ongoingtasks = new TreeMap<Long, Task>();

    /**
     * Write-ahead log file
     */
    private InsertLogger walog;

    public InsertLogger getInsertLogger() {
        return walog;
    }

    final FileSystem dfs;

    final IFileSystem localfs;

    /**
     * rpc server
     */
    private final AbstractRpcServer server;

    /**
     * udp server to receive master tasks.
     */
    private final UDPRpcServer udpServer;

    /**
     * for TS-wide critical tasks - heartbeat, clean cache, etc.
     */
    private final ScheduledThreadPoolExecutor backgroundtaskpool;

    /**
     * for per tablet checking threads - compact, check usage
     */
    final ScheduledThreadPoolExecutor perTabletTaskPool;

    final ThreadPoolExecutor tabletCheckpointTaskPool;

    /**
     * for running master tasks - split, close etc.
     */
    private final ExecutorService masterTaskPool;

    private volatile TsMasterProtocol master;

    private volatile boolean isShutdown = false;

    private final ZooKeeper zooKeeper;

    /**
     * heartbeat thread sets this bit to tablets_being_closedfalse each time WAL
     * truncate thread sets it to true in this way, these two threads can detect
     * each other's death.
     */
    private final AtomicBoolean heartbeatWALWatchDog = new AtomicBoolean(false);

    private static final int MIGRATE_HINTS_SIZE = 20;

    /**
     * records recently migrated tablets (for hint to client)
     */
    private final Map<Long, MigrationRecord> migratedTablets = new LinkedHashMap<Long, MigrationRecord>(
            20) {
        private static final long serialVersionUID = 432921271382122519L;

        @Override
        protected boolean removeEldestEntry(Entry<Long, MigrationRecord> eldest) {
            if (size() > MIGRATE_HINTS_SIZE) {
                return true;
            } else {
                return false;
            }
        }

    };

    private static class MigrationRecord {

        private String addr;

        private int port;

        private long timestamp;

        public MigrationRecord(String addr, int port, long timestamp) {
            this.addr = addr;
            this.port = port;
            this.timestamp = timestamp;
        }
    }

    final TsGlobalMetricsEntry globalMetricsEntry = new TsGlobalMetricsEntry();

    private final Path tsLocalRootPath;

    public Path getTsLocalRootPath() {
        return tsLocalRootPath;
    }

    /**
     * This constructor is meant for used by {@link TabletReader}. It won't work
     * as a service.
     * 
     * @throws IOException
     */
    public OmapTs(FileSystem dfs, String tabletDir) throws IOException {
        this.port = 3001;
        this.zooKeeper = null;
        this.usageStat = null;
        tsLocalRootPath = null;
        tsName = null;
        hostPortName = null;
        tablets = null;
        this.tabletDir = tabletDir;
        server = null;
        udpServer = null;
        this.perTabletTaskPool = null;
        tabletCheckpointTaskPool = null;
        masterTaskPool = null;
        localfs = null;
        splitBuffer = null;
        long sparseIndexPoolSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_SPARSE_INDEX_MAX_SIZE,
                OmapConfig.DEFAULT_SPARSE_INDEX_MAX_SIZE);
        long blockCacheSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_BLOCK_CACHE_MAX_SIZE,
                OmapConfig.DEFAULT_BLOCK_CACHE_MAX_SIZE);
        long bloomfilterPoolSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_BLOOM_FILTER_MAX_SIZE,
                OmapConfig.DEFAULT_BLOOM_FILTER_MAX_SIZE);
        long totalNativeBufferSize = sparseIndexPoolSize + blockCacheSize
                + bloomfilterPoolSize;
        nativeBufferPtr = UnsafeHelper.unsafe.allocateMemory(totalNativeBufferSize);
        long ptr = nativeBufferPtr;
        indexPool = new SparseIndexPool(ptr, sparseIndexPoolSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_SPARSE_INDEX_CHUNK_SIZE,
                        OmapConfig.DEFAULT_SPARSE_INDEX_CHUNK_SIZE));
        ptr += sparseIndexPoolSize;
        blockCache = new BlockCache(ptr, blockCacheSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_BLOCK_CACHE_CHUNK_SIZE,
                        OmapConfig.DEFAULT_BLOCK_CACHE_CHUNK_SIZE),
                globalMetricsEntry);
        ptr += blockCacheSize;
        filterPool = new BloomFilterPool(ptr, dfs, bloomfilterPoolSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_BLOOM_FILTER_CHUNK_SIZE,
                        OmapConfig.DEFAULT_BLOOM_FILTER_CHUNK_SIZE));
        this.dfs = dfs;
        compactSSTablesMutex = null;
        compactSSThroughputController = null;
        bufferPool = null;
        backgroundtaskpool = null;
        metaCache = new OmapTsMetadataCache();
        sstableDataFileCache = new SSTableDataFileNativeCache(dfs,
                backgroundtaskpool);
        expireQueue = null;
    }

    public OmapTs(int port, String tsLocalRoot) throws IOException {
        this(InetAddressUtils.getShortHostName(), port, tsLocalRoot);
    }

    private final String tsName;

    private final String hostPortName;

    public String getTsName() {
        return tsName;
    }

    public String getHostPortName() {
        return hostPortName;
    }

    private final NativeRamBuffer splitBuffer;

    /**
     * @param host
     * @param port
     *            the port server listens to
     * @throws IOException
     */
    public OmapTs(String host, int port, String tsLocalRoot) throws IOException {
        // find a consecutive unused ports to listen on
        this.port = OmapUtils.probeFreePort(port);

        // we may have several OmapTs in one process, so do not reuse the dfs 
        // instance, for we want to set different BlockCache path to them
        String fsName = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
        LOG.info("File system name: " + fsName);
        this.dfs = FileSystem.getNamed(fsName, false,
                OmapUtils.getDistributedFileSystemConfig());
        this.localfs = FileSystem.getNamed("local");
        this.tsLocalRootPath = new Path(tsLocalRoot);
        if (localfs.exists(tsLocalRootPath)) {
            if (!localfs.delete(tsLocalRootPath)) {
                throw new IOException("can not clean ts local root "
                        + tsLocalRootPath);
            }
        }
        localfs.mkdirs(tsLocalRootPath);

        int zkTsTimeout = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_ZOOKEEPER_TIMEOUT,
                OmapConfig.DEFAULT_TS_ZOOKEEPER_TIMEOUT);
        zooKeeper = new ZooKeeper(OmapConfig.getZkAddress(), zkTsTimeout,
                new NoActionWatcher());
        long timestamp = System.currentTimeMillis();
        // add ts address to zookeeper
        String addr = host + ":" + port + ":" + timestamp;
        tsName = "OMAPTS@" + addr;
        hostPortName = host + ":" + port;
        LOG.info("add address " + addr + " to ZooKeeper");
        int retryCount = 0;
        while (true) {
            try {
                zooKeeper.create(OmapConfig.getZkTsPath() + "/" + addr, null,
                        ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
                break;
            } catch (KeeperException e) {
                checkSessionExpired(e);
                LOG.log(Level.WARNING,
                        "can not add address to zookeeper, retryCount = "
                                + retryCount, e);
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "can not add address to zookeeper, retryCount = "
                                + retryCount, e);
            }
            WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(retryCount,
                    rand));
            retryCount++;
        }

        // init usage stat
        TsDesc tsDesc = new TsDesc(host, this.port, timestamp);
        LOG.info(tsDesc + " created");
        this.usageStat = new TsUsageReport(tsDesc);

        tabletDir = OmapConfig.getTsTabletDir();
        long writeBufferPoolSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_WRITE_BUFFER_TOTAL_SIZE,
                OmapConfig.DEFAULT_WRITE_BUFFER_TOTAL_SIZE);
        long sparseIndexPoolSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_SPARSE_INDEX_MAX_SIZE,
                OmapConfig.DEFAULT_SPARSE_INDEX_MAX_SIZE);
        long blockCacheSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_BLOCK_CACHE_MAX_SIZE,
                OmapConfig.DEFAULT_BLOCK_CACHE_MAX_SIZE);
        long bloomfilterPoolSize = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_BLOOM_FILTER_MAX_SIZE,
                OmapConfig.DEFAULT_BLOOM_FILTER_MAX_SIZE);
        long totalNativeBufferSize = writeBufferPoolSize + sparseIndexPoolSize
                + blockCacheSize + bloomfilterPoolSize;
        nativeBufferPtr = UnsafeHelper.unsafe.allocateMemory(totalNativeBufferSize);
        LOG.info("Create native buffer with size " + totalNativeBufferSize
                + ", mem offset " + HexString.longToPaddedHex(nativeBufferPtr));
        long ptr = nativeBufferPtr;
        bufferPool = new WriteBufferPool(ptr, writeBufferPoolSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_WRITE_BUFFER_CHUNK_SIZE,
                        OmapConfig.DEFAULT_WRITE_BUFFER_CHUNK_SIZE));
        ptr += writeBufferPoolSize;
        indexPool = new SparseIndexPool(ptr, sparseIndexPoolSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_SPARSE_INDEX_CHUNK_SIZE,
                        OmapConfig.DEFAULT_SPARSE_INDEX_CHUNK_SIZE));
        ptr += sparseIndexPoolSize;
        blockCache = new BlockCache(ptr, blockCacheSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_BLOCK_CACHE_CHUNK_SIZE,
                        OmapConfig.DEFAULT_BLOCK_CACHE_CHUNK_SIZE),
                globalMetricsEntry);
        ptr += blockCacheSize;
        filterPool = new BloomFilterPool(ptr, dfs, bloomfilterPoolSize,
                OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_BLOOM_FILTER_CHUNK_SIZE,
                        OmapConfig.DEFAULT_BLOOM_FILTER_CHUNK_SIZE));
        int expectedSplitBufferSize = 6 * OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_WAL_CHUNK_SIZE,
                OmapConfig.DEFAULT_WAL_CHUNK_SIZE) / 5;
        splitBuffer = new NativeRamBuffer(
                UnsafeHelper.unsafe.allocateMemory(expectedSplitBufferSize),
                expectedSplitBufferSize);

        int tabletCheckpointTaskPoolSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_TABLET_CHECKPOINT_TASK_POOL_SIZE,
                OmapConfig.DEFAULT_TS_TABLET_CHECKPOINT_TASK_POOL_SIZE);
        int backgroundTaskPoolCorePoolSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_BACKGROUND_TASK_POOL_CORE_POOL_SIZE,
                OmapConfig.DEFAULT_TS_BACKGROUND_TASK_POOL_CORE_POOL_SIZE);
        int perTabletTaskPoolCorePoolSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_PER_TABLET_TASK_POOL_CORE_POOL_SIZE,
                OmapConfig.DEFAULT_TS_PER_TABLET_TASK_POOL_CORE_POOL_SIZE);
        int masterTaskPoolCorePoolSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_MASTER_TASK_POOL_CORE_POOL_SIZE,
                OmapConfig.DEFAULT_TS_MASTER_TASK_POOL_CORE_POOL_SIZE);
        this.tabletCheckpointTaskPool = new ThreadPoolExecutor(1,
                tabletCheckpointTaskPoolSize, 60L, TimeUnit.SECONDS,
                new SynchronousQueue<Runnable>());
        this.backgroundtaskpool = (ScheduledThreadPoolExecutor) Executors.newScheduledThreadPool(backgroundTaskPoolCorePoolSize);
        this.perTabletTaskPool = (ScheduledThreadPoolExecutor) Executors.newScheduledThreadPool(perTabletTaskPoolCorePoolSize);
        this.masterTaskPool = new ThreadPoolExecutor(
                masterTaskPoolCorePoolSize, Integer.MAX_VALUE, 60L,
                TimeUnit.SECONDS, new SynchronousQueue<Runnable>());

        int rowLockQueueMaxCapacity = OmapConfig.getConfiguration().getInteger(
                OmapConfig.NAME_TS_ROW_LOCK_QUEUE_MAX_CAPACITY,
                OmapConfig.DEFAULT_TS_ROW_LOCK_QUEUE_MAX_CAPACITY);
        expireQueue = new RowLockQueue(rowLockQueueMaxCapacity);

        int compactMaxConcurreny = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_COMPACT_SS_MAX_CONCURRENCY,
                OmapConfig.DEFAULT_COMPACT_SS_MAX_CONCURRENCY);
        this.compactSSTablesMutex = new Semaphore(compactMaxConcurreny);

        this.tablets = new ConcurrentHashMap<Long, Tablet>();

        startWALogger();
        long mandatoryCheckpointTaskInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_MANDATORY_CHECKPOINT_TASK_INTERVAL,
                OmapConfig.DEFAULT_MANDATORY_CHECKPOINT_TASK_INTERVAL);
        this.backgroundtaskpool.scheduleWithFixedDelay(
                new MandatoryPeriodicalCheckpointTask(),
                mandatoryCheckpointTaskInterval,
                mandatoryCheckpointTaskInterval, TimeUnit.SECONDS);

        compactSSThroughputController = new ThroughputController(
                Double.MAX_VALUE);

        long tunerInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_COMPACTION_TUNER_INTERVAL,
                OmapConfig.DEFAULT_COMPACTION_TUNER_INTERVAL);
        this.backgroundtaskpool.scheduleWithFixedDelay(
                new CompactionThroughputTuner(), tunerInterval, tunerInterval,
                TimeUnit.SECONDS);

        metaCache = new OmapTsMetadataCache();
        sstableDataFileCache = new SSTableDataFileNativeCache(dfs,
                backgroundtaskpool);
        metaCache.addNewMetaDataListener(new MetaDataChangeListener() {

            @Override
            public void metaDataChanged(long schemaId, OmapMetadata oldMeta,
                    OmapMetadata newMeta) {

                String oldStringValue = Table.Property.DEFAUL_ENABLE_MEMORY_CACHE;
                String newStringValue = Table.Property.DEFAUL_ENABLE_MEMORY_CACHE;
                if (oldMeta != null) {
                    oldStringValue = oldMeta.getTableDesc().getProperty(
                            Table.Property.ENABLE_MEMORY_CACHE_NAME,
                            Table.Property.DEFAUL_ENABLE_MEMORY_CACHE);
                }

                if (newMeta != null) {
                    newStringValue = newMeta.getTableDesc().getProperty(
                            Table.Property.ENABLE_MEMORY_CACHE_NAME,
                            Table.Property.DEFAUL_ENABLE_MEMORY_CACHE);
                }
                boolean oldValue = Boolean.parseBoolean(oldStringValue);
                boolean newValue = Boolean.parseBoolean(newStringValue);

                if (oldValue && !newValue) {
                    String tabletFileDir = OmapUtils.getTabletFileDirByTableSchemaId(
                            tabletDir, schemaId);
                    sstableDataFileCache.releaseCache(new Path(tabletFileDir));
                } else {
                    // do nothing
                }
            }
        });
        watchMasterAddress();

        // initialize RPC server
        LOG.info("Starting TS server");
        int rpcHandlerCount = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_RPC_HANDLER_COUNT,
                OmapConfig.DEFAULT_TS_RPC_HANDLER_COUNT);
        int rpcQueueSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_RPC_QUEUE_SIZE, 10 * rpcHandlerCount);
        int rpcMaxConnPerClient = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_RPC_MAX_CONNECTION_PER_CLIENT,
                OmapConfig.DEFAULT_TS_RPC_MAX_CONNECTION_PER_CLIENT);
        int rpcClientDisconnectTime = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_TS_RPC_CLIENT_DISCONNECT_TIME,
                OmapConfig.DEFAULT_TS_RPC_CLIENT_DISCONNECT_TIME);
        List<Class<?>> protocols = new ArrayList<Class<?>>(2);
        protocols.add(ClientTsProtocol.class);
        protocols.add(ITsMetricsReport.class);
        List<Object> instances = new ArrayList<Object>(2);
        instances.add(this);
        instances.add(this);
        this.server = RPC.getNIOServer(
                protocols,
                instances,
                port,
                rpcHandlerCount,
                rpcQueueSize,
                rpcMaxConnPerClient,
                rpcClientDisconnectTime,
                2 * ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors(),
                2 * maxSizePerRow);
        this.server.setServerCallListener(new TsMetricsCallListener(tsName,
                globalMetricsEntry));
        LOG.info("TS server started");
        long heartBeatInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_HEARTBEAT_INTERVAL,
                OmapConfig.DEFAULT_HEARTBEAT_INTERVAL);
        this.backgroundtaskpool.scheduleAtFixedRate(new HeartBeatTask(), 0L,
                heartBeatInterval, TimeUnit.SECONDS);
        long cleanExpireLockInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_TS_CLEAN_EXPIRE_LOCK_INTERVAL,
                OmapConfig.DEFAULT_TS_CLEAN_EXPIRE_LOCL_INTERVAL);
        this.backgroundtaskpool.scheduleAtFixedRate(new CleanExpireLockTask(),
                cleanExpireLockInterval, cleanExpireLockInterval,
                TimeUnit.SECONDS);
        this.udpServer = RPC.getUDPServer(MasterTsProtocol.class, this, port);
        this.udpServer.start();

        // register a shutdown hook to notify Master when shut down
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                OmapUtils.safeClose(walog);
                OmapUtils.safeClose(dfs);
                OmapUtils.safeClose(zooKeeper);
                LOG.info("Shutdown hook: shutting down WALogger, FileSystem and ZooKeeper");
            }
        });
    }

    private boolean getMaster() throws UnsupportedEncodingException {
        byte[] data;
        int retryCount = 0;
        while (true) {
            try {
                data = zooKeeper.getData(OmapConfig.getZkActiveMasterPath(),
                        null, null);
                break;
            } catch (KeeperException e) {
                checkSessionExpired(e);
                if (e.code().equals(Code.NONODE)) {
                    LOG.log(Level.WARNING, "master znode not exists", e);
                    return false;
                }
                LOG.log(Level.WARNING,
                        "get master znode data failed, retryCount = "
                                + retryCount, e);
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "get master znode data failed, retryCount = "
                                + retryCount, e);
            }
            WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(retryCount,
                    rand));
            retryCount++;
        }
        String[] ss = new String(data, "UTF-8").split(":");
        InetSocketAddress addr = new InetSocketAddress(ss[0],
                Integer.parseInt(ss[1]));
        retryCount = 0;
        while (true) {
            try {
                LOG.info("set master address to " + addr);
                TsMasterProtocol oldMaster = master;
                TsMasterProtocol newMaster = (TsMasterProtocol) RPC.getProxy(
                        TsMasterProtocol.class, addr,
                        usageStat.getTsDesc().toString(), "", 0);
                if (oldMaster != null) {
                    RPC.close(oldMaster);
                }
                metaCache.setMaster(newMaster);
                master = newMaster;
                break;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "set master addr to " + addr
                        + "failed, retryCount = " + retryCount, e);
            }
            WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(retryCount,
                    rand));
            retryCount++;
        }
        return true;
    }

    private final Watcher masterAddressWatcher = new Watcher() {
        @Override
        public void process(WatchedEvent event) {
            if (isShutdown) {
                return;
            }
            try {
                checkSessionExpired(event);
                if (!event.getType().equals(EventType.NodeDeleted)
                        && !event.getType().equals(EventType.NodeCreated)) {
                    LOG.warning("unexpected event: " + event);
                }
                watchMasterAddress();
            } catch (Exception e) {
                LOG.log(Level.SEVERE,
                        "reset master address failed, I must kill myself", e);
                if (mainThread != null) {
                    mainThread.interrupt();
                } else {
                    shutdown(false);
                }
            }
        }
    };

    private void checkSessionExpired(WatchedEvent event) {
        if (!isShutdown && event.getState() == KeeperState.Expired) {
            LOG.severe("zookeeper connection expired, I must kill myself");
            if (mainThread != null) {
                mainThread.interrupt();
            } else {
                shutdown(false);
            }
        }
    }

    private void checkSessionExpired(KeeperException e) {
        if (!isShutdown && e.code().equals(Code.SESSIONEXPIRED)) {
            LOG.log(Level.SEVERE,
                    "zookeeper connection expired, I must kill myself", e);
            if (mainThread != null) {
                mainThread.interrupt();
            } else {
                shutdown(false);
            }
        }
    }

    private Random rand = new Random();

    private void watchMasterAddress() throws IOException {
        boolean exists;
        int retryCount = 0;
        while (true) {
            try {
                exists = zooKeeper.exists(OmapConfig.getZkActiveMasterPath(),
                        masterAddressWatcher) != null;
                break;
            } catch (KeeperException e) {
                checkSessionExpired(e);
                LOG.log(Level.WARNING, "failed to set watcher, retryCount = "
                        + retryCount, e);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "failed to set watcher, retryCount = "
                        + retryCount, e);
            }
            WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(retryCount,
                    rand));
            retryCount++;
        }
        if (exists) {
            if (!getMaster()) {
                LOG.info("maybe the master znode was deleted just now, "
                        + "left for watcher thread to solve");
            }
        }
    }

    /**
     * Start WALogger for a normal tablet server.
     * 
     * @throws IOException
     */
    public void startWALogger() throws IOException {
        if (this.walog != null) {
            throw new IllegalStateException("walogger already started");
        }
        Path walPath = new Path(OmapConfig.getWalPath(),
                usageStat.getTsDesc().getWALDirLastName());
        this.walog = new InsertLogger(walPath, this.getFs());
        LOG.info(this.toString() + " started WALogger in "
                + this.walog.getLogDir());

        long disassembleLogInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_DISASSEMBLE_WAL_INTERVAL,
                OmapConfig.DEFAULT_DISASSEMBLE_WAL_INTERVAL);
        this.backgroundtaskpool.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                try {
                    disassembleWALog();
                } catch (Throwable e) {
                    LOG.log(Level.SEVERE, "Failed to truncate logs", e);
                }
            }
        }, disassembleLogInterval, disassembleLogInterval, TimeUnit.SECONDS);
    }

    /**
     * This method should only be invoked by TestCase
     * 
     * @param checkpoint
     */
    public void shutdownForTestCase(boolean checkpoint) {
        if (isShutdown) {
            LOG.info(toString() + " already shutdown");
            return;
        }
        LOG.info("Shutting down " + this.toString() + " checkpoint="
                + checkpoint);
        isShutdown = true;
        if (checkpoint) {
            try {
                checkpointAllTablets();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Failed to checkpoint all tablets", e);
            }
        }
        server.stop();
        close();
    }

    public void shutdown(boolean checkpoint) {
        if (checkpoint) {
            try {
                checkpointAllTablets();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Failed to checkpoint all tablets", e);
            }
        }
        LOG.info("Shutdown is invoked, the process will exit directly.");
        //Stop current process directly
        System.exit(0);
    }

    public void close() {
        udpServer.stop();

        this.backgroundtaskpool.shutdownNow();
        this.backgroundtaskpool.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
        this.perTabletTaskPool.shutdownNow();
        this.perTabletTaskPool.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
        this.masterTaskPool.shutdownNow();
        for (Tablet t: this.tablets.values()) {
            try {
                t.setAbandoned();
                t.setToBeClosed();
                t.close();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception when shutting down Tablet "
                        + t + ", ignored", e);
            }
        }
        try {
            walog.close();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Exception when shutting WALogger, ignored",
                    e);
        }

        UnsafeHelper.unsafe.freeMemory(nativeBufferPtr);

        try {
            zooKeeper.close();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "close zookeeper failed", e);
        }
        if (master != null) {
            RPC.close(master);
        }
    }

    /**
     * start rpc server and offer service until the server is stopped.
     * 
     * @throws IOException
     */
    public void offerService() throws IOException {
        offerService(true);
    }

    /**
     * start rpc server and offer service.
     * 
     * @param join
     *            : if true, the server will wait until stopped then
     *            fastshutdown
     * @throws IOException
     */
    public void offerService(boolean join) throws IOException {
        this.server.start();
        if (join) {
            join();
        }

    }

    public void join() {
        try {
            this.server.join();
        } catch (InterruptedException ie) {
            LOG.log(Level.INFO, "Interrupted..  TS " + this.usageStat
                    + " exiting", ie);
            if (mainThread != null) {
                mainThread.interrupt();
            } else {
                shutdown(false);
            }
        }
        LOG.info(toString() + " ended");
    }

    // the main thread of OmapTs
    private static Thread mainThread;

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        OmapUtils.setupFileLogger("omapts");
        int port = 3001;
        if (args.length != 0) {
            port = Integer.parseInt(args[0]);
        }
        LocalBackupManager.setTempRoot(OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_FS_TEMP_ROOT, OmapConfig.DEFAULT_FS_TEMP_ROOT));
        LocalBackupManager.setUseFileBackup(true);
        List<String> tsLocalRoots = OmapConfig.getConfiguration().getList(
                OmapConfig.NAME_TS_LOCAL_ROOT);
        Interpreter interpreter = new Interpreter();
        OmapTs[] tses = new OmapTs[tsLocalRoots.size()];
        String host = null;
        try {
            host = InetAddressUtils.getShortHostName();
            for (int i = 0; i < tsLocalRoots.size(); i++) {
                String tsLocalRoot = tsLocalRoots.get(i);
                OmapTs ts = new OmapTs(host, port, tsLocalRoot);
                interpreter.set("ts" + ts.port, ts);
                ts.offerService(false);
                tses[i] = ts;
            }
            // start bean shell
            int bsPort = OmapConfig.getConfiguration().getInt(
                    OmapConfig.NAME_TS_BEANSHELL_PORT,
                    OmapConfig.DEFAULT_TS_BEANSHELL_PORT);
            LOG.info("Bean shell port: " + bsPort);
            interpreter.set("portnum", bsPort);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            mainThread = Thread.currentThread();
            mainThread.join();
        } catch (Exception e) {
            LOG.log(Level.SEVERE,
                    "main thread interrupted, process will exit directly.", e);
        }

        System.exit(0);
    }

    public IFileSystem getFs() {
        return this.dfs;
    }

    public IFileSystem getLocalFs() {
        return this.localfs;
    }

    /**
     * do check point to the tablet specified by tabletId
     * 
     * @param tabletId
     *            : the tablet that will do check point.
     */
    public void checkpoint(long tabletId) {
        LOG.info("Checkpointing tabletId="
                + HexString.longToPaddedHex(tabletId));
        Tablet tablet = this.tablets.get(tabletId);
        if (tablet == null) {
            LOG.log(Level.WARNING,
                    "Tablet " + HexString.longToPaddedHex(tabletId)
                            + " not found");
            return;
        }
        try {
            tablet.checkpoint();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Exception in OmapTs.checkpoint(), ignore",
                    e);
        }
    }

    public void addTablet(Tablet tablet) throws TabletAlreadyExistsException {
        LOG.info(this + " adding Tablet: " + tablet);
        long tabletId = tablet.getTabletId();
        synchronized (migratedTablets) {
            migratedTablets.remove(tabletId);
        }

        synchronized (tablets) {
            if (this.tablets.containsKey(tabletId)) {
                throw new TabletAlreadyExistsException("already has Tablet "
                        + HexString.longToPaddedHex(tabletId));
            }
            this.tablets.put(tabletId, tablet);
        }
        tablet.scheduleTasks();
    }

    /**
     * Closes a Tablet, and migrate it to another TS.
     * 
     * @param tabletId
     * @param migrate_to
     *            not null if this Tablet is going to be migrated
     * @return key range removed
     * @throws IOException
     */
    public KeyRange closeTabletForMigration(long tabletId, TsDesc migrate_to)
            throws IOException {
        LOG.info("Closing tablet: " + HexString.longToPaddedHex(tabletId)
                + " for migration to " + migrate_to);
        Tablet td = this.tablets.get(tabletId);
        if (td == null) {
            throw new RuntimeException("Tablet "
                    + HexString.longToPaddedHex(tabletId) + " not found");
        }
        if (td.hasStatusFlag(Tablet.STATUS_TO_BE_CLOSED)) {
            LOG.info(HexString.longToPaddedHex(tabletId)
                    + " already has STATUS_TO_BE_CLOSED");
        } else {
            td.checkpoint();
            td.setToBeClosed();
            boolean succ = false;
            try {
                td.checkpoint();
                succ = true;
            } finally {
                if (!succ) {
                    td.clearToBeClosed();
                }
            }
        }
        td.setAbandoned();
        closeTablet(td);
        synchronized (migratedTablets) {
            migratedTablets.put(
                    tabletId,
                    new MigrationRecord(migrate_to.getHost(),
                            migrate_to.getPort(), migrate_to.getTimestamp()));
        }
        return td.getKeyRange();
    }

    /**
     * Close (delete) the given Tablet
     * 
     * @param tabletId
     * @return
     */
    public KeyRange closeTablet(long tabletId) {
        LOG.info("Closing tablet: " + HexString.longToPaddedHex(tabletId));
        Tablet td = this.tablets.get(tabletId);
        if (td == null) {
            throw new TabletNotFoundException(tabletId);
        }
        td.setAbandoned();
        td.setToBeClosed();
        closeTablet(td);
        return td.getKeyRange();
    }

    private void closeTablet(Tablet tablet) {
        tablet.close();
        synchronized (tablets) {
            tablets.remove(tablet.getTabletId());
            long schemaId = tablet.getSchemaId();
            for (long tabletId: tablets.keySet()) {
                if (OmapUtils.tid2sid(tabletId) == schemaId) {
                    return;
                }
            }
            LOG.info("no tablet for " + HexString.longToPaddedHex(schemaId)
                    + ", clear meta cache");
            metaCache.clearMetadata(schemaId, false);
        }

    }

    /**
     * used for testcase only
     * 
     * @param tabletId
     */
    public void requestSplit(long tabletId) {
        Tablet tablet = tablets.get(tabletId);
        if (tablet == null) {
            LOG.warning("no tablet with id "
                    + HexString.longToPaddedHex(tabletId)
                    + " found, request split ignored");
        } else {
            requestSplit(tablet);
        }
    }

    public void requestSplit(Tablet tablet) {
        try {
            Task splitTask = master.requestSplit(tablet.getTabletId(),
                    usageStat.getTsDesc());
            if (splitTask != null) {
                LOG.info("Split requested "
                        + HexString.longToPaddedHex(tablet.getTabletId())
                        + ", get task " + splitTask);
                tablet.statusFlags.setFlag(Tablet.STATUS_SPLIT_REQUEST_PENDING);
                synchronized (ongoingtasks) {
                    ongoingtasks.put(splitTask.getTaskId(), splitTask);
                    masterTaskPool.execute(new MasterTaskTask(splitTask));
                }
            }
        } catch (Throwable t) {
            LOG.log(Level.WARNING,
                    "split request for "
                            + HexString.longToPaddedHex(tablet.getTabletId())
                            + " failed", t);
        }
    }

    /**
     * for different conditions, throw different exceptions
     */
    private void handleTabletNotFound(long tabletId) {
        // whether this tablet has just moved..
        MigrationRecord mig;
        synchronized (migratedTablets) {
            mig = migratedTablets.get(tabletId);
        }

        if (mig != null) {
            throw new TabletNotFoundException(tabletId, new TsDesc(mig.addr,
                    mig.port, mig.timestamp));
        }
        throw new TabletNotFoundException(tabletId);
    }

    private Tablet getTabletAndHandleTabletNotFound(long tabletId) {
        Tablet tablet = this.tablets.get(tabletId);
        if (tablet == null) {
            handleTabletNotFound(tabletId);
        }
        return tablet;
    }

    // make sure that only one heartbeat is going on at the same time
    private Lock heartbeatLock = new ReentrantLock();

    /**
     * Send heart beat to master
     */
    private void sendHeartBeat() {
        TsMasterProtocol master = this.master;
        if (master == null) {
            LOG.warning("master is not start yet, giveup heartbeat");
            return;
        }
        if (heartbeatLock.tryLock()) {
            try {
                usageStat.updateTsUsage(this);
                // send usage report
                long start = System.currentTimeMillis();
                Task[] tasks = master.tsHeartbeat(usageStat);
                globalMetricsEntry.heartbeat(System.currentTimeMillis() - start);
                usageStat.increaseHearBeatSeq();
                LOG.info(usageStat.getTsDesc() + " received :" + tasks.length
                        + " tasks on heartbeat " + usageStat.getHeartBeatSeq());
                if (tasks.length > 0) {
                    synchronized (ongoingtasks) {
                        for (Task task: tasks) {
                            if (ongoingtasks.containsKey(task.getTaskId())) {
                                LOG.info("duplicate task " + task.getTaskId());
                            } else {
                                ongoingtasks.put(task.getTaskId(), task);
                                LOG.info("scheduling task: " + task);
                                masterTaskPool.execute(new MasterTaskTask(task));
                            }
                        }
                    }
                }
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "Cannot connect to Master", t);
            } finally {
                heartbeatLock.unlock();
            }
        } else {
            LOG.warning("a heartbeat task is ongoing now, I will quit");
        }
    }

    @Override
    public void assignTask(Task[] tasks) throws RpcException {
        LOG.info("master assign " + tasks.length + " tasks");
        synchronized (ongoingtasks) {
            for (Task task: tasks) {
                if (ongoingtasks.containsKey(task.getTaskId())) {
                    LOG.info("duplicate task " + task.getTaskId());
                } else {
                    ongoingtasks.put(task.getTaskId(), task);
                    LOG.info("scheduling task: " + task);
                    masterTaskPool.execute(new MasterTaskTask(task));
                }
            }
        }
    }

    /**
     * for local use only
     * 
     * @param tabletId
     * @return
     * @throws IOException
     * @throws IOException
     */
    public CloseableIterator<ByteArrayWritable> getTabletIterator(long tabletId)
            throws IOException {
        Tablet tablet = this.tablets.get(tabletId);
        return tablet.iterator(true);
    }

    public CloseableIterator<ByteArrayWritable> getTabletIterator(
            long tabletId, KeyCell startKey) throws IOException {
        Tablet tablet = this.tablets.get(tabletId);
        return tablet.iterator(startKey, true);
    }

    /**
     * TSManagement Interface
     */
    public String listTablets() throws RpcException {
        Iterator<Entry<Long, Tablet>> iter = this.tablets.entrySet().iterator();
        StringBuffer sb = new StringBuffer();
        while (iter.hasNext()) {
            Entry<Long, Tablet> entry = iter.next();
            sb.append(entry.getKey()).append("::").append(entry.getValue()).append(
                    "\n");
        }
        return sb.toString();
    }

    public String tabletData(long tabletId, int limit) throws IOException {
        Tablet tablet = this.tablets.get(tabletId);
        StringBuffer sb = new StringBuffer();
        int cnt = 0;
        CloseableIterator<ByteArrayWritable> iter = tablet.iterator(false);
        try {
            ByteArrayWritable row = new ByteArrayWritable();
            DataRow dataRow = metaCache.getMetadata(OmapUtils.tid2sid(tabletId)).getTableDesc().borrowDataRow();
            while (iter.next(row) && cnt < limit) {
                OmapUtils.convertBytesToPIWritable(row.data(), dataRow);
                sb.append(dataRow).append("\n");
                cnt += 1;
            }
        } finally {
            iter.close();
        }
        sb.append("Total Number of Rows: ").append(tablet.getNumKeys()).append(
                "\n");
        sb.append("Number of SS_Tables: ").append(tablet.getValidSSCount()).append(
                "\n");
        sb.append("number of keys in writebuf: ").append(
                tablet.getWBNumKeysEsti()).append("\n");
        return sb.toString();
    }

    public String dumpWALog(int limit) throws IOException {
        LogIterator logi = walog.revIterator(true);
        StringBuffer sb = new StringBuffer();
        int cnt = 0;
        InsertLogEntry entry = new InsertLogEntry();
        while (logi.next(entry) && cnt++ < limit) {
            sb.append("W(R):").append(entry).append("\n");
            // System.out.println("W(R): " +e);
        }
        return sb.toString();
    }

    public void checkpointAllTablets() throws IOException {
        LOG.info(this + " checkpointing all tablets");
        synchronized (tablets) {
            for (Tablet tablet: tablets.values()) {
                checkpoint(tablet.getTabletId());
            }
        }
    }

    /**
     * Loosely checkpoint the Tablet with the largest write buffer and that
     * hasn't checkpointed for a pre-set time. This could help release write
     * buffers.
     * 
     * @author zhangkun
     */
    private class MandatoryPeriodicalCheckpointTask implements Runnable {

        private long lastMandatoryCheckpointTime = 0;

        private Tablet findTabletWithOldestCheckpointTime(long beforeTime) {
            long checkpointTime = beforeTime;
            Tablet t = null;
            for (Tablet tablet: tablets.values()) {
                if (tablet.getLastCheckpointTime() < checkpointTime) {
                    checkpointTime = tablet.getLastCheckpointTime();
                    t = tablet;
                }
            }
            return t;
        }

        public void run() {
            try {
                if (bufferPool.getAllocatedBufferSize() * 5 / 4 > bufferPool.getMaxBufferSize()) {
                    LOG.info("write buffer used rate is "
                            + String.format(
                                    "%.2f",
                                    (double) bufferPool.getAllocatedBufferSize()
                                            / bufferPool.getMaxBufferSize())
                            + ", need to checkpoint aggressively");
                    long currentTime = System.currentTimeMillis();
                    Tablet tablet = findTabletWithOldestCheckpointTime(currentTime);
                    if (tablet != null) {
                        LOG.info("Going to checkpoint "
                                + HexString.longToPaddedHex(tablet.getTabletId())
                                + " for write buffer is not enough");
                        tablet.checkpoint();
                    }
                } else {
                    long maxCheckpointInterval = OmapConfig.getConfiguration().getLong(
                            OmapConfig.NAME_CHECKPOINT_MAX_INTERVAL,
                            OmapConfig.DEFAULT_CHECKPOINT_MAX_INTERVAL) * 1000;
                    long mandatoryCheckpointInterval = OmapConfig.getConfiguration().getLong(
                            OmapConfig.NAME_MANDATORY_CHECKPOINT_TASK_CHECKPOINT_INTERVAL,
                            OmapConfig.DEFAULT_MANDATORY_CHECKPOINT_TASK_CHECKPOINT_INTERVAL) * 1000;
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastMandatoryCheckpointTime < mandatoryCheckpointInterval) {
                        return;
                    }
                    Tablet tablet = findTabletWithOldestCheckpointTime(currentTime
                            - maxCheckpointInterval);
                    if (tablet != null) {
                        LOG.info("Going to checkpoint "
                                + HexString.longToPaddedHex(tablet.getTabletId())
                                + " (mandatory periodical checkpoint)");
                        lastMandatoryCheckpointTime = currentTime;
                        tablet.checkpoint();
                    }
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING,
                        "Exception in MandatoryPeriodicalCheckpointTask", e);
            }
        }
    }

    private class CompactionThroughputTuner implements Runnable {
        public void run() {
            try {
                int maxCount = 0;
                for (Tablet tablet: tablets.values()) {
                    int count = tablet.getValidSSCount();
                    if (count > maxCount) {
                        maxCount = count;
                    }
                }
                int sstableCountLow = OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_SSTABLE_COUNT_LOW,
                        OmapConfig.DEFAULT_SSTABLE_COUNT_LOW);
                int sstableCountHigh = OmapConfig.getConfiguration().getInt(
                        OmapConfig.NAME_SSTABLE_COUNT_HIGH,
                        OmapConfig.DEFAULT_SSTABLE_COUNT_HIGH);
                long throughputHigh = OmapConfig.getConfiguration().getLong(
                        OmapConfig.NAME_COMPACT_SS_THROUGHPUT_HIGH,
                        OmapConfig.DEFAULT_COMPACT_SS_THROUGHPUT_HIGH);
                long throughputLow = OmapConfig.getConfiguration().getLong(
                        OmapConfig.NAME_COMPACT_SS_THROUGHPUT_LOW,
                        OmapConfig.DEFAULT_COMPACT_SS_THROUGHPUT_LOW);
                LOG.info("CompactionThroughputTuner: SSTable maxCount="
                        + maxCount);
                if (maxCount > sstableCountHigh) {
                    LOG.info("CompactionThroughputTuner: set unlimited throughput");
                    compactSSThroughputController.setMaxThroughput(Double.MAX_VALUE);
                } else if (maxCount < sstableCountLow) {
                    LOG.info("CompactionThroughputTuner: set throughput to lower bound ("
                            + throughputLow + ")");
                    compactSSThroughputController.setMaxThroughput(throughputLow);
                } else {
                    double limit;
                    if (sstableCountHigh <= sstableCountLow) {
                        limit = throughputHigh;
                    } else {
                        limit = throughputLow
                                + ((double) (throughputHigh - throughputLow))
                                * (maxCount - sstableCountLow)
                                / (sstableCountHigh - sstableCountLow);
                    }
                    LOG.info("CompactionThroughputTuner: set throughput to "
                            + limit);
                    compactSSThroughputController.setMaxThroughput(limit);
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING,
                        "Exception in CompactionThroughputTuner", e);
            }
        }
    }

    public void disassembleWALog() throws IOException {
        walog.disassembleAllChunks(this, splitBuffer);
    }

    private class HeartBeatTask implements Runnable {
        public void run() {
            heartbeatWALWatchDog.set(true);
            // heartbeat
            sendHeartBeat();
        }
    }

    private class MasterTaskTask implements Runnable {

        private Task task;

        public MasterTaskTask(Task task) {
            this.task = task;
        }

        public void run() {
            // detect duplicate task moved to sendHeartBeat method..
            try {
                this.task.recordStartTime();
                LOG.info("Running task: " + this.task);
                this.task.setReturnStatus(task.execTask(OmapTs.this));
                if (this.task.getReturnStatus() != 0) {
                    LOG.warning("Task failed.. " + this.task);
                } else {
                    LOG.info("Task done.. " + this.task);
                }
            } catch (Throwable ex) {
                task.setReturnStatus(-1);
                LOG.log(Level.SEVERE, "Error executing " + task, ex);
            } finally {
                // return result to master whether successful or not
                this.task.recordDoneTime();
                try {
                    Task[] newTasks = master.tsTaskDone(this.task,
                            usageStat.getTsDesc());
                    if (newTasks.length > 0) {
                        synchronized (ongoingtasks) {
                            for (Task task: newTasks) {
                                if (ongoingtasks.containsKey(task.getTaskId())) {
                                    LOG.info("duplicate task "
                                            + task.getTaskId());
                                } else {
                                    ongoingtasks.put(task.getTaskId(), task);
                                    LOG.info("scheduling task: " + task);
                                    masterTaskPool.execute(new MasterTaskTask(
                                            task));
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Failed to return task " + task, e);
                    if (task.getReturnStatus() >= 0) {
                        LOG.log(Level.INFO, "Rolling back " + task);
                        try {
                            this.task.rollbackTask(OmapTs.this);
                        } catch (Exception e1) {
                            LOG.log(Level.SEVERE,
                                    "rollback task failed, I must kill myself",
                                    e1);
                            if (mainThread != null) {
                                mainThread.interrupt();
                            } else {
                                shutdown(false);
                            }
                        }
                    }
                }
                synchronized (ongoingtasks) {
                    ongoingtasks.remove(task.getTaskId());
                }
            }
        }
    }

    public SplitResult splitTablet(long oldid, long newid1, long newid2)
            throws IOException, TabletAlreadyExistsException {
        final Tablet tablet = tablets.get(oldid);
        if (tablet == null) {
            throw new TabletNotFoundException(oldid);
        }
        SplitResult result = tablet.split(newid1, newid2);
        if (result != null) {
            this.addTablet(result.newTablet1);
            this.addTablet(result.newTablet2);

            closeTablet(tablet);
        }
        return result;
    }

    public String[] getOnGoingTasksDumped() {
        StringBuilder buffer = new StringBuilder();
        synchronized (ongoingtasks) {
            for (Task td: ongoingtasks.values()) {
                buffer.append(td.toString()).append("\n\n");
            }
        }
        return buffer.toString().split("\n");
    }

    public String toString() {
        return "[OmapTs TsDesc=" + usageStat.getTsDesc() + " tabletDir="
                + tabletDir + "]";
    }

    @Override
    public boolean contains(long tabletId, ByteArrayWritable key)
            throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.READ);
        boolean found = tablet.findKey(key) != null;
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.contains(delay);
        return found;
    }

    @Override
    public boolean[] contains(long tabletId, ByteArrayWritable[] keys)
            throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.READ);
        ByteArrayWritable[] vals = tablet.findKeys(keys);
        boolean[] founds = new boolean[vals.length];
        for (int i = 0; i < vals.length; i++) {
            founds[i] = vals[i] != null;
        }
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.multiContains(keys.length, delay);
        return founds;
    }

    @Override
    public ByteArrayWritable keyFind(long tabletId, ByteArrayWritable key)
            throws IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.READ);
        ByteArrayWritable ret = tablet.findKey(key);
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.keyFind(ret == null ? 0 : ret.size(), delay);
        return ret;
    }

    @Override
    public ByteArrayWritable[] keysFind(long tabletId, ByteArrayWritable key,
            int num) throws IOException {
        return keysFind(tabletId, key, null, num);
    }

    @Override
    public ByteArrayWritable[] keysFind(long tabletId,
            ByteArrayWritable startKeyw, ByteArrayWritable endKeyw, int num)
            throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.READ);
        long schemaId = OmapUtils.tid2sid(tabletId);
        KeyColumnDesc kcDesc = metaCache.getMetadata(schemaId).getTableDesc().getKey();
        KeyCell startKey = kcDesc.borrowKeyCell();
        OmapUtils.convertBytesToPIWritable(startKeyw.data(), startKey);
        KeyCell endKey;
        if (endKeyw != null) {
            endKey = kcDesc.borrowKeyCell();
            OmapUtils.convertBytesToPIWritable(endKeyw.data(), endKey);
        } else {
            endKey = null;
        }
        ByteArrayWritable[] rows;
        try {
            rows = tablet.findKeys(startKey, endKey, num);
        } finally {
            kcDesc.returnKeyCell(startKey);
            if (endKey != null) {
                kcDesc.returnKeyCell(endKey);
            }
        }
        long delay = System.currentTimeMillis() - start;
        int size = 0;
        for (ByteArrayWritable row: rows) {
            if (row != null) {
                size += row.size();
            }
        }
        tablet.metricsEntry.rangeKeyFind(rows.length, size, delay);
        return rows;
    }

    @Override
    public ByteArrayWritable[] keysFind(long tabletId, ByteArrayWritable[] keys)
            throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.READ);
        ByteArrayWritable[] rows = tablet.findKeys(keys);

        long delay = System.currentTimeMillis() - start;
        int size = 0;
        for (ByteArrayWritable row: rows) {
            if (row != null) {
                size += row.size();
            }
        }
        tablet.metricsEntry.multiKeyFind(rows.length, size, delay);
        return rows;
    }

    @Override
    public void insertRow(long tabletId, ByteArrayWritable row)
            throws IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.WRITE);
        insertRow(tablet, row, false);
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.insert(row.size(), delay);
    }

    // TODO: we can do it more efficiency
    @Override
    public void insertRows(long tabletId, ByteArrayWritable[] rows)
            throws IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.WRITE);
        for (ByteArrayWritable row: rows) {
            insertRow(tablet, row, false);
        }
        int size = 0;
        for (ByteArrayWritable row: rows) {
            size += row.size();
        }
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.multiInsert(rows.length, size, delay);
    }

    /**
     * Insert a Row to a Tablet
     * 
     * @param tabletId
     * @param row
     * @param recovering
     *            If true, will not write WALog. This is supposed to be only
     *            used in InsertLoggerRecoverHandler.
     * @throws IOException
     */
    public void insertRow(Tablet tablet, ByteArrayWritable row,
            boolean recovering) throws IOException {
        if (!recovering && row.getByteLength() > maxSizePerRow) {
            throw new IOException("row size (" + row.getByteLength()
                    + ") exceeds limit (" + maxSizePerRow + ")");
        }
        tablet.insert(row, recovering);
    }

    @Override
    public void deleteRow(long tabletId, ByteArrayWritable key)
            throws IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.WRITE);
        deleteRow(tablet, key, false);
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.delete(delay);
    }

    @Override
    public void deleteRows(long tabletId, ByteArrayWritable[] keys)
            throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.WRITE);
        for (ByteArrayWritable key: keys) {
            deleteRow(tablet, key, false);
        }
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.multiDelete(keys.length, delay);
    }

    @Override
    public int deleteRows(long tabletId, ByteArrayWritable startKeyInclusive,
            ByteArrayWritable endKeyExclusive) throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        tablet.getTableDesc().validatePermission(PermissionType.WRITE);
        long schemaId = OmapUtils.tid2sid(tabletId);
        OmapMetadata metadata = metaCache.getMetadata(schemaId);
        KeyColumnDesc kcDesc = metadata.getTableDesc().getKey();
        KeyCell startKeyCell = kcDesc.borrowKeyCell();
        OmapUtils.convertBytesToPIWritable(startKeyInclusive.data(),
                startKeyCell);
        KeyCell endKeyCell = kcDesc.borrowKeyCell();
        OmapUtils.convertBytesToPIWritable(endKeyExclusive.data(), endKeyCell);
        CloseableIterator<ByteArrayWritable> iter = null;
        ByteArrayWritable key = new ByteArrayWritable();
        ByteArrayWritable row = new ByteArrayWritable();
        KeyCell keyCell = kcDesc.borrowKeyCell();
        int count = 0;
        try {
            iter = tablet.iterator(startKeyCell, true);
            while (iter.next(row)) {
                DataRow.keyCellFromBinaryRow(keyCell, row.data());
                if (keyCell.compareTo(endKeyCell) >= 0) {
                    break;
                }
                key.set(OmapUtils.convertPIWritableToBytes(keyCell));
                tablet.remove(key, false);
                count++;
                // tablet iterator will hold the WriteBuffer lock
                // so we can not hold for a long time
                if (System.currentTimeMillis() - start > 1000) {
                    break;
                }
            }
            long delay = System.currentTimeMillis() - start;
            tablet.metricsEntry.rangeDelete(count, delay);
            return count;
        } finally {
            OmapUtils.safeClose(iter);
            kcDesc.returnKeyCell(keyCell);
            kcDesc.returnKeyCell(startKeyCell);
            kcDesc.returnKeyCell(endKeyCell);
        }
    }

    @Override
    public boolean compareAndSet(long tabletId, ByteArrayWritable key,
            String columnName, ByteArrayWritable columnValue,
            ByteArrayWritable update) throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        long schemaId = OmapUtils.tid2sid(tabletId);
        LockKey lockKey = new LockKey(schemaId, key);
        keyLock.lock(lockKey, getClientTimeout());
        try {
            ByteArrayWritable current = tablet.findKey(key);
            boolean pass;
            if (columnName == null) {
                pass = current == null;
            } else {
                if (current == null) {
                    pass = false;
                } else {
                    TableDesc td = metaCache.getMetadata(schemaId).getTableDesc();
                    DataRow dr = td.borrowDataRow();
                    DataRow.dataRowFromBinaryRow(dr, current.data(), 0,
                            current.size());
                    int columnIndex = td.getColumnIndex(columnName);
                    DataCell expected = td.getColumn(columnIndex).createDataCell();
                    OmapUtils.convertBytesToPIWritable(columnValue.data(), 0,
                            columnValue.size(), expected);
                    pass = expected.equals(dr.getColumn(columnIndex));
                    td.returnDataRow(dr);
                }
            }
            if (pass) {
                if (DataRow.isDeleted(update)) {
                    KeyColumnDesc kcd = metaCache.getMetadata(schemaId).getTableDesc().getKey();
                    KeyCell keyCell = kcd.borrowKeyCell();
                    DataRow.keyCellFromBinaryRow(keyCell, update.data(), 0,
                            update.size());
                    kcd.returnKeyCell(keyCell);
                    tablet.remove(key, false);
                } else {
                    tablet.insert(update, false);
                }
            }
            long delay = System.currentTimeMillis() - start;
            tablet.metricsEntry.compareAndSet(delay);
            return pass;
        } finally {
            keyLock.unlock(lockKey);
        }
    }

    public void deleteRow(Tablet tablet, ByteArrayWritable key,
            boolean recovering) throws IOException {
        tablet.remove(key, recovering);
    }

    static class LockKey {

        public final long schemaId;

        public final ByteArrayWritable key = new ByteArrayWritable();

        public LockKey(long schemaId, ByteArrayWritable key) {
            this.schemaId = schemaId;
            this.key.copyFields(key);
        }

        @Override
        public int hashCode() {
            return (int) schemaId ^ key.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            LockKey that = (LockKey) obj;
            return schemaId == that.schemaId && key.equals(that.key);
        }

        @Override
        public String toString() {
            return "LockKey [schemaId=" + schemaId + ", key=" + key + "]";
        }

    }

    private class CleanExpireLockTask implements Runnable {

        @Override
        public void run() {
            try {
                cleanExpireLock();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "clean expire lock failed", t);
            }
        }
    }

    private void cleanExpireLock() {
        long currentTime = System.currentTimeMillis();
        LockEntry lockEntry = expireQueue.peek();
        if (lockEntry == null || lockEntry.expiredTime > currentTime) {
            return;
        }
        LOG.info("begin clean expired lock, row lock queue size = "
                + expireQueue.size());
        while ((lockEntry = expireQueue.poll()) != null) {
            if (lockEntry.expiredTime > currentTime) {
                return;
            }
            LOG.warning("clean expired lock " + lockEntry);
            keyLock.unlock(lockEntry.key);
        }
    }

    private final KeyLock<LockKey> keyLock = new KeyLock<LockKey>();

    private final RowLockQueue expireQueue;

    private static final long MIN_EXPIRE_TIME = 1000;

    private AtomicLong lockCounter = new AtomicLong(0);

    private String getLockName(String lockName) {
        if (lockName != null && lockName.startsWith(tsName)) {
            return lockName;
        }
        long id;
        long nextId;
        do {
            id = lockCounter.get();
            nextId = id == Long.MAX_VALUE ? 0 : id + 1;
        } while (!lockCounter.compareAndSet(id, nextId));
        return tsName + "-" + id;
    }

    private long getClientTimeout() {
        ClientInfo info = RPC.getClientInfo();
        if (info != null) {
            return Long.parseLong(info.clientProps.get(RpcConstants.CLIENT_PROP_RPC_TIMEOUT));
        } else {
            return 0;
        }
    }

    @Override
    public String lockRow(long tabletId, ByteArrayWritable key,
            long expireTime, String lockName) throws RpcException, IOException {
        long start = System.currentTimeMillis();
        Tablet tablet = getTabletAndHandleTabletNotFound(tabletId);
        if (expireTime < MIN_EXPIRE_TIME) {
            expireTime = MIN_EXPIRE_TIME;
        }
        String newLockName = getLockName(lockName);
        long schemaId = OmapUtils.tid2sid(tabletId);
        LockKey lockKey = new LockKey(schemaId, key);
        if (expireQueue.add(newLockName, System.currentTimeMillis()
                + expireTime, lockKey)) {
            long clientTimeout = getClientTimeout();
            long lockTimeout = clientTimeout == 0 ? expireTime : Math.min(
                    clientTimeout, expireTime);
            keyLock.lock(lockKey, lockTimeout);
        }
        long delay = System.currentTimeMillis() - start;
        tablet.metricsEntry.lockRow(delay);
        return newLockName;
    }

    @Override
    public void unlockRow(long tabletId, String lockName) throws RpcException,
            IOException {
        long start = System.currentTimeMillis();
        LockEntry lockEntry = expireQueue.remove(lockName);
        if (lockEntry != null) {
            keyLock.unlock(lockEntry.key);
        } else {
            LOG.warning("no lock found with name " + lockName);
        }
        long delay = System.currentTimeMillis() - start;
        Tablet tablet = tablets.get(tabletId);
        if (tablet != null) {
            tablet.metricsEntry.unlockRow(delay);
        }
    }

    @Override
    public TsMetricsEntry getMetricsEntry() throws RpcException {
        TsGlobalMetricsEntry globalMetricsEntry = new TsGlobalMetricsEntry();
        this.globalMetricsEntry.copyToAndClear(globalMetricsEntry);
        globalMetricsEntry.updateSystemInfo(this);
        // do not need SortedMap here, it will be a SortedMap after client side readFields 
        Map<Long, TsTabletMetricsEntry> tabletMetricsEntries = new HashMap<Long, TsTabletMetricsEntry>();
        for (Tablet tablet: tablets.values()) {
            TsTabletMetricsEntry entry = new TsTabletMetricsEntry();
            tablet.metricsEntry.copyToAndClear(entry);
            tabletMetricsEntries.put(tablet.getTabletId(), entry);
        }
        globalMetricsEntry.setTabletNumber(tabletMetricsEntries.size());
        return new TsMetricsEntry(hostPortName, globalMetricsEntry,
                tabletMetricsEntries);
    }

}
