/**
 * @(#)TableBackupReplayer.java, 2011-8-18. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.backup;

import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.regex.Pattern;
import odis.cowork.GenericJobDef;
import odis.cowork.JobClient;
import odis.cowork.JobResult;
import odis.io.FSDataInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.io.IFileSystem.PathFilter;
import odis.tools.ToolContext;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.KeyRangeList;

/**
 * @author wangfk
 */
public class TableBackupReplayer {
    private static final String TIME_FORMAT = "yyyy.MM.dd-HH:mm:ss";

    public static final void usage(PrintStream out) {
        out.println("USAGE: <TableNameWithSpace> <ReplayToTime " + TIME_FORMAT
                + ">");
    }

    private static final String fsName = OmapConfig.getConfiguration().getString(
            OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);;

    private static final String backupRoot = OmapConfig.getConfiguration().getString(
            OmapConfig.NAME_BACKUP_ROOT_PATH,
            OmapConfig.DEFAULT_BACKUP_ROOT_PATH);

    private static final long deltaReplayStartTimeInMilli = 5L * 60 * 1000;

    private static final ToolContext toolContext = new ToolContext();

    private static IFileSystem fs;

    private static String tableName;

    private static Path tableBackupRoot;

    private static Path tableSnapshotRoot;

    private static Path tableWAlogRoot;

    private static Path tableReplayRoot;

    private static Path tableReplayTempRoot;

    private static Path selectedSnapshotPath;

    private static Path selectedSnapshotPathLinkPath;

    private static long relayStartTime;

    private static long relayEndTime;

    private static void init(String tableName, long replayToTimeStamp)
            throws IllegalArgumentException, IOException {
        TableBackupReplayer.tableName = tableName;
        tableBackupRoot = new Path(backupRoot).cat(tableName);
        tableSnapshotRoot = tableBackupRoot.cat(TableBackupConstant.SnapshotPath);
        tableWAlogRoot = tableBackupRoot.cat(TableBackupConstant.WALogPath);
        tableReplayRoot = tableBackupRoot.cat(TableBackupConstant.ReplayPath);
        tableReplayTempRoot = tableReplayRoot.cat(TableBackupConstant.TempPath);

        fs = FileSystem.getNamed(fsName);
        FileInfo[] listFiles = null;
        if (fs.exists(tableSnapshotRoot)) {
            listFiles = fs.listFiles(tableSnapshotRoot, new PathFilter() {
                @Override
                public boolean accept(Path path) {
                    return Pattern.matches("\\d+", path.getName());
                }
            });
        }
        if (listFiles == null || listFiles.length == 0) {
            throw new IllegalArgumentException(
                    "There are no table snapshot in path: " + fsName + ":"
                            + tableSnapshotRoot + ", can not replay.");
        }

        Arrays.sort(listFiles, new Comparator<FileInfo>() {
            @Override
            public int compare(FileInfo o1, FileInfo o2) {
                Long ts1 = Long.parseLong(o1.getPath().getName());
                Long ts2 = Long.parseLong(o2.getPath().getName());
                return ts2.compareTo(ts1);
            }
        });

        long earliestTime = 0;
        for (FileInfo fi: listFiles) {
            long timestamp = Long.parseLong(fi.getPath().getName());
            earliestTime = timestamp;
            if (timestamp > replayToTimeStamp) {
                continue;
            }
            relayStartTime = timestamp;
            selectedSnapshotPath = fi.getPath();
            break;
        }
        if (selectedSnapshotPath == null) {
            throw new IllegalArgumentException("Can not replay to time: "
                    + new Date(replayToTimeStamp)
                    + ", you can replay to time not earlier than "
                    + new Date(earliestTime));
        }
        relayStartTime -= deltaReplayStartTimeInMilli;
        relayEndTime = replayToTimeStamp;

        fs.mkdirs(tableReplayRoot);
        selectedSnapshotPathLinkPath = tableReplayRoot.cat(tableName + "_"
                + replayToTimeStamp);
        if (fs.exists(selectedSnapshotPathLinkPath)) {
            fs.delete(selectedSnapshotPathLinkPath);
        }
        fs.link(selectedSnapshotPath, selectedSnapshotPathLinkPath);
    }

    private static boolean replayByCowork() throws IOException {
        // read KeyRangeList
        KeyRangeList krl = new KeyRangeList();
        Path krlFile = selectedSnapshotPathLinkPath.cat("keyRangeList");
        FSDataInputStream krlStream = fs.open(krlFile);
        krl.readFields(krlStream);
        krlStream.close();

        int tabletCount = krl.getRangeList().size();
        GenericJobDef genericJob = toolContext.createGenericJob(
                "OmapReplayLog_"
                        + tableName.replace('$', '_').replace('-', '_'),
                Math.min(1024, tabletCount));
        genericJob.setTaskClass(WALogReplayCoworkTask.class);
        genericJob.setTaskNumber(tabletCount);
        genericJob.getConfig().setProperty(
                WALogReplayCoworkTask.CONF_REPLAY_LOG_PATH,
                tableWAlogRoot.getPath());
        genericJob.getConfig().setProperty(
                WALogReplayCoworkTask.CONF_REPLAY_TEMP_PATH,
                tableReplayTempRoot.getPath());
        genericJob.getConfig().setProperty(
                WALogReplayCoworkTask.CONF_SNAPSHOT_PATH,
                selectedSnapshotPathLinkPath.getPath());
        genericJob.getConfig().setProperty(
                WALogReplayCoworkTask.CONF_FILE_SYSTEM_NAME, fsName);
        genericJob.getConfig().setProperty(
                WALogReplayCoworkTask.CONF_REPLAY_START_TIME, relayStartTime);
        genericJob.getConfig().setProperty(
                WALogReplayCoworkTask.CONF_REPLAY_END_TIME, relayEndTime);

        JobResult result = JobClient.runJob(toolContext.getCoWork(), genericJob);
        return result.isSuccess();
    }

    public static void main(String args[]) throws Exception {
        if (args.length != 2) {
            usage(System.err);
            return;
        }
        String tableName = args[0];
        SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
        Date date = sdf.parse(args[1]);

        init(tableName, date.getTime());

        String message = "## Replay backup table " + tableName + " to time "
                + date + " ##";
        char[] cs = new char[message.length()];
        Arrays.fill(cs, '#');
        String separator = new String(cs); 
        System.err.println(separator);
        System.err.println(message);
        System.err.println(separator);
        System.err.println();
        System.err.println("Recover table to path: " + fsName + ":"
                + selectedSnapshotPathLinkPath);

        if (replayByCowork()) {
            System.err.println("DONE: " + fsName + ":"
                    + selectedSnapshotPathLinkPath
                    + ", please recover by import snapshot.");
        }
    }
}
