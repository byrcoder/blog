package outfox.omap.test.bench;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FileSystem;
import odis.io.Path;
import toolbox.misc.LogFormatter;

/**
 * A batch benchmark runner for OMap. A Bench consists of one or more Workloads
 * running simultaneously.
 * @author zhangkun
 */
public class OmapBench {
    FileSystem fs;
    Path outputDir;
    WorkloadRunner[] workloadRunners;
    private static final Logger LOG = LogFormatter.getLogger(OmapBench.class);
    /**
     * Construct an undefined bench set. Use <code>setXXX()</code> methods
     * to define the bench.
     */
    public OmapBench() {}
    public synchronized void setOutputFs(String outputFsName) throws IOException {
        if(fs != null) {
            throw new IllegalStateException("fs already set to " + fs);
        }
        fs = FileSystem.getNamed(outputFsName);
    }
    public synchronized void setOutputRoot(String outputRoot) throws IOException {
        if(outputDir != null) {
            throw new IllegalStateException("outputDir already set to " + outputDir);
        }
        // decide output subdir
        String dirPrefix = new SimpleDateFormat("yyyyMMdd").format(new Date()) + "-";
        int j = 0;
        while(true) {
            Path path = new Path(outputRoot, dirPrefix + j);
            if(!fs.exists(path)) {
                outputDir = path;
                break;
            }
            j ++;
        }
        LOG.info("Bench output dir: " + outputDir);
    }
    public synchronized void setWorkloads(List<WorkloadConfig> workloads) throws IOException {
        if(workloadRunners != null) {
            throw new IllegalStateException("workloads already set");
        }
        workloadRunners = new WorkloadRunner[workloads.size()];
        for(int i = 0; i < workloads.size(); i++) {
            workloadRunners[i] = new WorkloadRunner(workloads.get(i), this);
        }
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                LOG.info("Cleaning up running bench");
                OmapBench.this.stop();
            }
        });
    }
    /**
     * Construct a bench set
     * @param outputFs the file system to which the bench outputs
     * @param outputRoot the root dir of outputs
     * @param workloads workloads of this bench
     * @throws IOException
     */
    public OmapBench(FileSystem outputFs, Path outputRoot, WorkloadConfig[] workloads) throws IOException {
        this.fs = outputFs;
        setOutputRoot(outputRoot.getAbsolutePath());
        setWorkloads(Arrays.asList(workloads));
    }
    public void start() throws Exception {
        if(workloadRunners == null) {
            throw new IllegalStateException("workloads not set");
        }
        if(fs == null) {
            throw new IllegalStateException("outputFs not set");
        }
        if(outputDir == null) {
            throw new IllegalStateException("outputRoot not set");
        }
        // prepare environment
        for(WorkloadRunner runner : workloadRunners) {
            runner.prepareInitialEnvironment();
        }
        // start all workload runners
        for(WorkloadRunner runner : workloadRunners) {
            runner.start();
        }
    }
    public void join() throws InterruptedException {
        synchronized(workloadRunners) {
            workloadRunners.wait();
        }
    }
    public void stop() {
        for(WorkloadRunner runner : workloadRunners) {
            try {
                runner.stop(false);
            } catch(Exception e) {
                LOG.log(Level.WARNING, "Exception when stopping " + runner, e);
            }
        }
        synchronized(workloadRunners) {
            workloadRunners.notifyAll();
        }
    }
}
