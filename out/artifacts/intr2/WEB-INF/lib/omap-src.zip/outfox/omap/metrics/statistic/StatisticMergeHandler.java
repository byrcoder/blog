/**
 * @(#)StatisticMergeHandler.java, 2011-6-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.lib.LongWritable;
import outfox.omap.metrics.MetricsEntry;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class StatisticMergeHandler implements StatisticReaderHandler {

    private static final Logger LOG = LogFormatter.getLogger(StatisticMergeHandler.class);

    private final FileSystem fs;

    private final Path dir;

    private final Path file;

    private SequenceFile.Writer writer;

    public static final String MERGE_FILE_PREFIX = "MERGE_";

    public static final String COMMIT_MERGE_FILE_PREFIX = "COMMITMERGE_";

    private long entryMinTime = Long.MAX_VALUE;

    private long entryMaxTime = Long.MIN_VALUE;

    public StatisticMergeHandler(FileSystem fs, Path dir) {
        this.fs = fs;
        this.dir = dir;
        this.file = dir.cat(MERGE_FILE_PREFIX + System.currentTimeMillis());
    }

    @Override
    public void done(List<Path> processedFiles) {
        if (writer == null) {
            // just delete the processedFiles
            for (Path path: processedFiles) {
                OmapUtils.safeDelete(fs, path);
            }
            return;
        }
        try {
            writer.close();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "complete file " + file + " failed", e);
            OmapUtils.safeDelete(fs, file);
            return;
        }
        long startTime = StatisticReader.getStatFileTime(
                processedFiles.get(0).getName()).getFirst();
        long endTime = StatisticReader.getStatFileTime(
                processedFiles.get(processedFiles.size() - 1).getName()).getFirst();
        Path commitMergeFile = dir.cat(COMMIT_MERGE_FILE_PREFIX + startTime
                + "_" + endTime + "_" + entryMinTime + "_" + entryMaxTime);
        try {
            if (!fs.rename(file, commitMergeFile)) {
                LOG.warning("rename " + file + " to " + commitMergeFile
                        + " failed");
                OmapUtils.safeDelete(fs, file);
                return;
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "rename " + file + " to " + commitMergeFile
                    + " failed", e);
            OmapUtils.safeDelete(fs, file);
            return;
        }
        for (Path path: processedFiles) {
            OmapUtils.safeDelete(fs, path);
        }
        Path newFile = dir.cat(StatisticRecorder.STATISTIC_FILE_PREFIX
                + entryMinTime + "_" + entryMaxTime);
        try {
            if (!fs.rename(commitMergeFile, newFile)) {
                LOG.warning("rename " + commitMergeFile + " to " + newFile
                        + " failed, I will quit");
                System.exit(1000);
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING, "rename " + file + " to " + commitMergeFile
                    + " failed, I will quit", e);
            System.exit(1000);
        }
    }

    @Override
    public void fail() {
        if (writer != null) {
            OmapUtils.safeClose(writer);
            OmapUtils.safeDelete(fs, file);
        }
    }

    private LongWritable key;

    @Override
    public void handle(long time, MetricsEntry metricsEntry) throws IOException {
        if (time < entryMinTime) {
            entryMinTime = time;
        }
        if (time > entryMaxTime) {
            entryMaxTime = time;
        }
        if (writer == null) {
            writer = new SequenceFile.Writer(fs, file, LongWritable.class,
                    MetricsEntry.class);
            key = new LongWritable();
        }
        key.set(time);
        writer.write(key, metricsEntry);
    }
}
