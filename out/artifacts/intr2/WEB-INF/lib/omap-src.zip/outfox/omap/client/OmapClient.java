/**
 * @(#)OmapClient.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.query.IndexSchema;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryExecutor;
import outfox.omap.client.query.OmapQueryUtils;
import outfox.omap.common.ClientTsProtocol;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConstants;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.IPreInitializedWritable;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.exceptions.NoSuchSchemaException;
import outfox.omap.exceptions.NoSuchTsException;
import outfox.omap.exceptions.OmapException;
import outfox.omap.exceptions.OperationNotPermittedException;
import outfox.omap.exceptions.ServerUnavailableException;
import outfox.omap.exceptions.TableReadOnlyException;
import outfox.omap.exceptions.TabletNotFoundException;
import outfox.omap.exceptions.WriteBufferOverflowException;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.WaitUtils;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * Omap Client implementation One client provides access to a single table it
 * caches the key_range - ts resolution. client is also responsible for retry.
 * 
 * @author xuw
 */
public class OmapClient implements OmapConstants {

    /**
     * one client accesses a single table
     */
    private final String tableName;

    private volatile OmapMetadata metadata;

    private MasterWatcherAndClientConfig masterWatcher;

    // <indexTableName, omap client>
    private volatile Map<String, OmapClient> indexClients;

    private volatile OmapQueryExecutor queryExecutor;

    /**
     * Client cache of ts location and tablet_id for ranges Indexed by table
     * name in memory only
     */
    private KeyRangeList krlist;

    // used to protect krlist
    private final ReentrantReadWriteLock krlistlock = new ReentrantReadWriteLock();

    private static Logger LOG = LogFormatter.getLogger(OmapClient.class.getName());

    private final Random rand = new Random(System.currentTimeMillis());

    private final long timeout;

    private final String rpcUserName;

    private final String rpcDomain;

    private static String getRpcDomain(String tableName) {
        return tableName.replaceAll("\\$", ".");
    }

    public OmapClient(MasterWatcherAndClientConfig masterWatcher,
            String tableName, long timeout) throws IOException {
        this.masterWatcher = masterWatcher;
        this.rpcDomain = getRpcDomain(tableName);
        if (timeout <= 0) {
            timeout = Long.MAX_VALUE;
        }
        this.timeout = timeout;
        this.tableName = tableName;
        this.rpcUserName = masterWatcher.getConf().getString(
                ClientConfig.NAME_CLIENT_USER_NAME,
                ClientConfig.DEFAULT_CLIENT_USER_NAME);
        updateTableMeta(true);
    }

    public String getTableName() {
        return tableName;
    }

    public TableDesc getTableDesc() {
        return metadata.getTableDesc();
    }

    public OmapMetadata getMetadata() {
        return metadata;
    }

    private void updateTableMeta(boolean ignoreEx) throws IOException {
        try {
            OmapMetadata metadata = masterWatcher.getMetadataCache().findMetadata(
                    tableName);
            this.metadata = metadata;
            LOG.info("Found Meta Data for " + tableName);
            if (!OmapUtils.isIndexTable(tableName)) {
                // open clients for index tables
                Map<String, OmapClient> indexClients = new HashMap<String, OmapClient>();
                for (String idxTableName: metadata.getIndexes().values()) {
                    indexClients.put(idxTableName, new OmapClient(
                            masterWatcher, idxTableName, timeout));
                }
                this.indexClients = indexClients;
                queryExecutor = new OmapQueryExecutor(this);
            }
        } catch (NoSuchSchemaException e) {
            if (ignoreEx) {
                this.metadata = null;
                LOG.info("Table '" + tableName + "' not found");
            } else {
                throw e;
            }
        }
    }

    /**
     * This is invoked for update meta from master. <br>
     * Table meta may need to sync after some operation, such as <b>set table's
     * properties<b>.
     * 
     * @throws IOException
     */
    void updateTableMetaFromMaster() throws IOException {
        MetadataCache metadataCache = masterWatcher.getMetadataCache();
        metadataCache.clearTableInfo(tableName);
        OmapMetadata metadata = metadataCache.findMetadata(tableName);
        this.metadata = metadata;
        LOG.info("Found Meta Data for " + tableName);

        if (!OmapUtils.isIndexTable(tableName)) {
            // open clients for index tables
            Map<String, OmapClient> indexClients = new HashMap<String, OmapClient>();
            for (String idxTableName: metadata.getIndexes().values()) {
                indexClients.put(idxTableName, new OmapClient(masterWatcher,
                        idxTableName, timeout));
            }
            this.indexClients = indexClients;
            queryExecutor = new OmapQueryExecutor(this);
        }
    }

    /**
     * create one table; return NULL if failed.
     * 
     * @param table_descriptor
     * @return status
     */
    public synchronized void createTable(String fields, String types)
            throws OmapException {
        createTable(fields, types, null);
    }

    /**
     * create one table; return NULL if failed.
     * 
     * @param table_descriptor
     * @return status
     */
    public synchronized void createTable(String fields, String types,
            OmapQuery[] queries) throws OmapException {
        LOG.info("trying to create table " + this.tableName);
        try {
            masterWatcher.getNoTimeoutMaster().createTable(tableName, fields,
                    types, queries);
            LOG.info("Table created: " + this.tableName);
            masterWatcher.getMetadataCache().clearTableInfo(tableName);
            updateTableMeta(false);
        } catch (IOException ex) {
            throw new OmapException("Creating Table failed", ex);
        }
    }

    /**
     * delete a single table. if delete more than one, we can do it one by one
     * at client; Efficiency of delete is not much important.
     * 
     * @return integer status
     */
    public void deleteTable() throws OmapException {
        try {
            masterWatcher.getNoTimeoutMaster().deleteTable(this.tableName);
            masterWatcher.getMetadataCache().clearTableInfo(this.tableName);
        } catch (IOException e) {
            throw new OmapException(e);
        }

    }

    public DataRow createDataRow() {
        return getTableDesc().createDataRow();
    }

    /**
     * lookup: look for key in table
     * 
     * @param key
     * @param prefetch_hint
     *            is a hint to the master how many continuous keys will be
     *            fetched
     * @return a sorted list of keyrange to ts mappings.
     */
    private KeyRangeList lookupRangeTs(KeyCell key, int prefetch_hint)
            throws IOException {
        byte[] binaryKey = OmapUtils.convertPIWritableToBytes(key);
        ClientMasterProtocol master = masterWatcher.getMaster();
        KeyRangeList krl = master.lookupKey(this.tableName,
                new ByteArrayWritable(binaryKey), prefetch_hint);

        TableDesc td = metadata.getTableDesc();
        if (krl.first().getSchemaId() != td.getSchemaId()) {
            LOG.warning("maybe the table was deleted and created again, we should update the metadata");
            MetadataCache metadataCache = masterWatcher.getMetadataCache();
            metadataCache.clearTableInfo(td.getSchemaId(), tableName);
            updateTableMeta(false);
        }
        return krl;
    }

    private void clearKeyRange(KeyCell key) {
        krlistlock.writeLock().lock();
        try {
            krlist.delete(key.getKey());
        } finally {
            krlistlock.writeLock().unlock();
        }
    }

    private void refreshKeyRange(KeyCell key) throws IOException {
        KeyRangeList krlist = lookupRangeTs(key, 1);
        this.krlistlock.writeLock().lock();
        try {
            if (this.krlist == null) {
                this.krlist = krlist;
            } else {
                this.krlist.merge(krlist);
            }
        } finally {
            this.krlistlock.writeLock().unlock();
        }
    }

    protected KeyRange getKeyRange(KeyCell key) throws IOException {
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("Looking up KeyRange for " + key);
        }

        KeyRange kr = null;
        this.krlistlock.readLock().lock();
        try {
            if (krlist != null) {
                kr = krlist.lookup(key.getKey());
            }
        } finally {
            this.krlistlock.readLock().unlock();
        }

        if (kr != null) {
            return kr;
        }

        refreshKeyRange(key);

        this.krlistlock.readLock().lock();
        try {
            return this.krlist.lookup(key.getKey());
        } finally {
            this.krlistlock.readLock().unlock();
        }
    }

    private void handleTabletNotFound(TabletNotFoundException ex,
            long elapsedTime, int retryCount, KeyCell key, KeyRange originalKr)
            throws IOException {
        long expWaitTime = Math.min(WaitUtils.getExpWaitTime(retryCount, rand),
                timeout - elapsedTime);
        if (ex.getReason().equals(TabletNotFoundException.Reasons.JUST_MOVED)
                && ex.getHintTs() != null) { // hint (destination TS) provided
            TsDesc newts = ex.getHintTs();
            if (newts.equals(originalKr.getTsDesc())) {
                LOG.warning("Migration self-loop:" + ex.getHintTs());
            }
            this.krlistlock.writeLock().lock();
            try {
                // first see if krlist has already been updated by some other
                // thread
                KeyRange kr = this.krlist.lookup(key.getKey());
                if (kr != null) {
                    if (kr.getTabletId() != originalKr.getTabletId()) {
                        LOG.warning("TabletId for key="
                                + key
                                + " has changed from "
                                + HexString.longToPaddedHex(originalKr.getTabletId())
                                + " to "
                                + HexString.longToPaddedHex(kr.getTabletId()));
                    } else if (!kr.getTsDesc().equals(newts)) {
                        // key range not updated yet, update krlist using hint
                        // no need to wait to retry under this condition
                        this.krlist.delete(originalKr);
                        originalKr.setTsDesc(newts);
                        this.krlist.insert(originalKr);
                        WaitUtils.sleepIgnoreInterrupt(expWaitTime);
                        return;
                    }
                }
            } finally {
                this.krlistlock.writeLock().unlock();
            }
        }
        // wait a while and see if someone else has updated krlist
        long toWait = WaitUtils.getGaussianWaitTime(expWaitTime, rand);
        WaitUtils.sleepIgnoreInterrupt(toWait);
        if (krlistAlreadyUpdated(key.getKey(), originalKr)) {
            return;
        }
        refreshKeyRange(key);
    }

    private void handleTsUnavailableFailure(KeyCell key, long elapsedTime,
            int retryCount, KeyRange originalKeyRange) throws IOException {
        long expWaitTime = Math.min(WaitUtils.getExpWaitTime(retryCount, rand),
                timeout - elapsedTime);
        if (originalKeyRange == null) {
            WaitUtils.sleepIgnoreInterrupt(expWaitTime);
        } else {
            // see if already updated by someone else..
            long toWait = WaitUtils.getGaussianWaitTime(expWaitTime, rand);
            WaitUtils.sleepIgnoreInterrupt(toWait);
            if (krlistAlreadyUpdated(key.getKey(), originalKeyRange)) {
                return;
            }
            refreshKeyRange(key);
        }
    }

    private boolean krlistAlreadyUpdated(IWritableComparable key,
            KeyRange original_kr) {
        krlistlock.readLock().lock();
        try {
            KeyRange kr = this.krlist.lookup(key);
            if (kr != null
                    && (kr.getTabletId() != original_kr.getTabletId() || !kr.getTsDesc().equals(
                            original_kr.getTsDesc()))) {
                return true;
            }
        } finally {
            krlistlock.readLock().unlock();
        }
        return false;
    }

    private void handleDataAccessExceptions(KeyCell key, KeyRange keyRange,
            Throwable e, long elapsedTime, int retryCount) throws OmapException {
        LOG.log(Level.INFO, "data access exception for key=" + key + " on "
                + (keyRange == null ? "(KeyRange N/A)" : keyRange.getTsDesc())
                + ", elapsedTime=" + elapsedTime + ", retrying " + retryCount,
                e);
        if (elapsedTime >= timeout) {
            // when a ts machine is down, we will get a connection timeout, 
            // and will timeout at the first retry. if we do not check it here, 
            // the keyrange will not be updated until the ts machine is up, 
            // although the tablet is moved.
            if (e instanceof RpcException
                    && e.getCause() instanceof SocketTimeoutException) {
                clearKeyRange(key);
            }
            throw new OmapException("Retry exhausted, elapsedTime="
                    + elapsedTime + ", timeout=" + timeout, e);
        }
        if (e instanceof NoSuchSchemaException) {
            throw (NoSuchSchemaException) e;
        } else if (e instanceof OperationNotPermittedException) {
            throw (OperationNotPermittedException) e;
        }
        try {
            if (e instanceof ServerUnavailableException) {
                WaitUtils.sleepIgnoreInterrupt(Math.min(
                        WaitUtils.getExpWaitTime(retryCount, rand),
                        (timeout - elapsedTime)));
                refreshKeyRange(key);
            } else if (e instanceof TabletNotFoundException) {
                handleTabletNotFound((TabletNotFoundException) e, elapsedTime,
                        retryCount, key, keyRange);
            } else if (e instanceof TableReadOnlyException) {
                WaitUtils.sleepIgnoreInterrupt(Math.min(
                        WaitUtils.getExpWaitTime(retryCount, rand), timeout
                                - elapsedTime));
            } else if (e instanceof RpcException) {
                handleTsUnavailableFailure(key, elapsedTime, retryCount,
                        keyRange);
                refreshKeyRange(key);
            } else if (e instanceof NoSuchTsException) {
                handleTsUnavailableFailure(key, elapsedTime, retryCount,
                        keyRange);
                refreshKeyRange(key);
            } else if (e instanceof WriteBufferOverflowException) {
                handleTsUnavailableFailure(key, elapsedTime, retryCount,
                        keyRange);
            } else {
                WaitUtils.sleepIgnoreInterrupt(Math.min(
                        WaitUtils.getExpWaitTime(retryCount, rand), timeout
                                - elapsedTime));
                refreshKeyRange(key);
            }
        } catch (Exception ex) {
            LOG.log(Level.INFO, "handle data access exception for key=" + key
                    + ", elapsedTime=" + elapsedTime + ", retrying "
                    + retryCount, ex);
            if (ex instanceof NoSuchSchemaException) {
                throw (NoSuchSchemaException) ex;
            }
            WaitUtils.sleepIgnoreInterrupt(Math.min(
                    WaitUtils.getExpWaitTime(retryCount, rand), timeout
                            - elapsedTime));
        }
    }

    private ClientTsProtocol getTsNode(KeyRange kr) throws IOException {
        return masterWatcher.getTsConnManager().getRpcProxy(kr.getTsDesc(),
                rpcDomain, rpcUserName, timeout);
    }

    private static final Method TS_METHOD_MULTI_CONTAINS;

    private static final Method TS_METHOD_MULTI_KEYS_FIND;

    private static final Method TS_METHOD_MULTI_INSERT;

    private static final Method TS_METHOD_MULTI_DELETE;

    private static final Method TS_METHOD_DELETE_RANGE;

    static {
        try {
            TS_METHOD_MULTI_CONTAINS = ClientTsProtocol.class.getMethod(
                    "contains", long.class, ByteArrayWritable[].class);
            TS_METHOD_MULTI_KEYS_FIND = ClientTsProtocol.class.getMethod(
                    "keysFind", long.class, ByteArrayWritable[].class);
            TS_METHOD_MULTI_INSERT = ClientTsProtocol.class.getMethod(
                    "insertRows", long.class, ByteArrayWritable[].class);
            TS_METHOD_MULTI_DELETE = ClientTsProtocol.class.getMethod(
                    "deleteRows", long.class, ByteArrayWritable[].class);
            TS_METHOD_DELETE_RANGE = ClientTsProtocol.class.getMethod(
                    "deleteRows", long.class, ByteArrayWritable.class,
                    ByteArrayWritable.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean contains(KeyCell key) throws OmapException {
        ByteArrayWritable w = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) { // terminate on done or IOException
            KeyRange kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                return tsNode.contains(kr.getTabletId(), w);
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public boolean[] contains(KeyCell[] keys) throws OmapException {
        return new BatchRead<boolean[], boolean[]>(keys) {

            @Override
            protected Future<boolean[]> call(ClientTsProtocol tsNode,
                    long tabletId, ByteArrayWritable[] byteArrs)
                    throws RpcException {
                Future<boolean[]> future = RPC.asyncInvoke(tsNode,
                        TS_METHOD_MULTI_CONTAINS, tabletId, byteArrs);
                return future;
            }

            @Override
            protected void fillReturn(List<KeyCell> partition, boolean[] founds) {
                for (int i = 0; i < founds.length; i++) {
                    KeyCell keyCell = partition.get(i);
                    for (int j = 0; j < keys.length; j++) {
                        if (keyCell.equals(keys[j])) {
                            returnObj[j] = founds[i];
                        }
                    }
                }
            }

            @Override
            protected void initReturnObj() {
                returnObj = new boolean[keys.length];
            }

        }.exec();
    }

    public DataRow keyFind(KeyCell key) throws OmapException {
        ByteArrayWritable w = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));
        ByteArrayWritable ret = null;
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) { // terminate on done or IOException
            KeyRange kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                ret = tsNode.keyFind(kr.getTabletId(), w);
                break;
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
        if (ret == null) {
            return null;
        } else {
            DataRow row = getTableDesc().borrowDataRow();
            OmapUtils.convertBytesToPIWritable(ret.data(), row);
            return row;
        }
    }

    public DataRow[] keysFind(KeyCell[] keys) throws OmapException {
        final TableDesc td = getTableDesc();
        return new BatchRead<DataRow[], ByteArrayWritable[]>(keys) {

            @Override
            protected Future<ByteArrayWritable[]> call(ClientTsProtocol tsNode,
                    long tabletId, ByteArrayWritable[] byteArrs)
                    throws RpcException {
                Future<ByteArrayWritable[]> future = RPC.asyncInvoke(tsNode,
                        TS_METHOD_MULTI_KEYS_FIND, tabletId, byteArrs);
                return future;
            }

            @Override
            protected void fillReturn(List<KeyCell> partition,
                    ByteArrayWritable[] rows) {
                for (int i = 0; i < rows.length; i++) {
                    KeyCell keyCell = partition.get(i);
                    for (int j = 0; j < keys.length; j++) {
                        if (keyCell.equals(keys[j])) {
                            ByteArrayWritable row = rows[i];
                            if (row != null) {
                                DataRow dr = td.borrowDataRow();
                                DataRow.dataRowFromBinaryRow(dr, row.data());
                                returnObj[j] = dr;
                            } else {
                                returnObj[j] = null;
                            }
                        }
                    }
                }
            }

            @Override
            protected void initReturnObj() {
                returnObj = new DataRow[keys.length];
            }
        }.exec();
    }

    private abstract class BatchRead<K, V> {

        protected KeyCell[] keys;

        protected K returnObj;

        protected abstract void initReturnObj();

        protected abstract Future<V> call(ClientTsProtocol tsNode,
                long tabletId, ByteArrayWritable[] byteArrs)
                throws RpcException;

        protected abstract void fillReturn(List<KeyCell> partition,
                V partitionReturn);

        public BatchRead(KeyCell[] keys) {
            this.keys = keys;
            initReturnObj();
        }

        public K exec() throws OmapException {
            boolean[] success = new boolean[keys.length];
            int retryCount = 0;
            long startTime = System.currentTimeMillis();
            outer: while (true) {
                KeyCell curKey = null;
                KeyRange curKr = null;
                Map<KeyRange, Set<KeyCell>> partition = new HashMap<KeyRange, Set<KeyCell>>();
                // do partition
                for (int i = 0; i < keys.length; i++) {
                    KeyCell keyCell = keys[i];
                    if (success[i]) {
                        continue;
                    }
                    KeyRange kr = null;
                    try {
                        kr = getKeyRange(keyCell);
                    } catch (Exception e) {
                        retryCount++;
                        handleDataAccessExceptions(keyCell, kr, e,
                                System.currentTimeMillis() - startTime,
                                retryCount);
                        continue outer;
                    }
                    Set<KeyCell> list = partition.get(kr);
                    if (list == null) {
                        list = new HashSet<KeyCell>();
                        partition.put(kr, list);
                    }
                    list.add(keys[i]);
                }
                Throwable exc = null;
                List<Future<V>> futureList = new ArrayList<Future<V>>();
                List<List<KeyCell>> keyCellsList = new ArrayList<List<KeyCell>>();
                List<KeyRange> krList = new ArrayList<KeyRange>();

                for (Map.Entry<KeyRange, Set<KeyCell>> entry: partition.entrySet()) {
                    try {
                        KeyRange kr = entry.getKey();
                        List<KeyCell> keyCells = new ArrayList<KeyCell>(
                                entry.getValue());
                        ByteArrayWritable[] byteArrs = new ByteArrayWritable[keyCells.size()];
                        for (int i = 0; i < keyCells.size(); i++) {
                            byteArrs[i] = new ByteArrayWritable(
                                    OmapUtils.convertPIWritableToBytes(keyCells.get(i)));
                        }
                        ClientTsProtocol tsNode = getTsNode(kr);
                        Future<V> future = call(tsNode, kr.getTabletId(),
                                byteArrs);
                        futureList.add(future);
                        keyCellsList.add(keyCells);
                        krList.add(kr);
                    } catch (Exception e) {
                        exc = e;
                        curKr = entry.getKey();
                        curKey = entry.getValue().iterator().next();
                    }
                }
                for (int i = 0; i < futureList.size(); i++) {
                    try {
                        V partitionReturn = futureList.get(i).get();
                        List<KeyCell> keyCells = keyCellsList.get(i);
                        fillReturn(keyCells, partitionReturn);
                        for (KeyCell keyCell: keyCellsList.get(i)) {
                            for (int j = 0; j < keys.length; j++) {
                                if (keyCell.equals(keys[j])) {
                                    success[j] = true;
                                }
                            }
                        }
                    } catch (Exception e) {
                        if (e instanceof ExecutionException) {
                            exc = e.getCause();
                        } else {
                            exc = e;
                        }
                        curKr = krList.get(i);
                        curKey = keyCellsList.get(i).get(0);
                    }
                }
                if (exc != null) {
                    retryCount++;
                    handleDataAccessExceptions(curKey, curKr, exc,
                            System.currentTimeMillis() - startTime, retryCount);
                } else {
                    return returnObj;
                }
            }
        }
    }

    /**
     * keysFind: Find a continuous series of records >= key
     * 
     * @param key
     *            : the start key of these records
     * @param num
     *            : the number of records to find
     * @return: the records found. If key is found in the table, it will be
     *          included in the result. This function tries to find exactly num
     *          of keys, but does not guarantee it. It may return n (n<=num)
     *          records if it cannot find enough records. by wangyang
     */
    public DataRow[] keysFind(KeyCell key, int num) throws OmapException {
        return keysFind(key, null, num);
    }

    public DataRow[] keysFind(KeyCell startKeyInclusive,
            KeyCell endKeyExclusive, int num) throws OmapException {
        KeyCell currentKey = startKeyInclusive;

        ByteArrayWritable startBaw = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(startKeyInclusive));
        ByteArrayWritable endBaw;
        if (endKeyExclusive != null) {
            endBaw = new ByteArrayWritable(
                    OmapUtils.convertPIWritableToBytes(endKeyExclusive));
        } else {
            endBaw = null;
        }
        List<DataRow> result = new ArrayList<DataRow>(num);
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        int total = 0;

        while (true) { // terminate on done or IOException
            KeyRange kr = null;
            try {
                kr = getKeyRange(currentKey);
                ClientTsProtocol tsNode = getTsNode(kr);
                ByteArrayWritable[] rowsw = tsNode.keysFind(kr.getTabletId(),
                        startBaw, endBaw, num - total);
                int need = total + rowsw.length > num ? num - total
                        : rowsw.length;
                for (int i = 0; i < need; i++) {
                    DataRow dr = getTableDesc().borrowDataRow();
                    OmapUtils.convertBytesToPIWritable(rowsw[i].data(), dr);
                    result.add(dr);
                }
                total += need;

                if (total >= num
                        || (endKeyExclusive != null && kr.getKey2().compareTo(
                                endKeyExclusive.getKey()) >= 0)) {
                    return result.toArray(new DataRow[0]);
                }

                // next time start to find in the next keyrange
                currentKey = new KeyCell(kr.getKey2());

                if (KeyPair.MAX_WRITABLE.equals(currentKey.getKey())) {
                    return result.toArray(new DataRow[0]);
                }
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(currentKey, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public void insertRow(DataRow row) throws OmapException {
        ByteArrayWritable wrap = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(row));
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) {
            KeyRange kr = null;
            try {
                kr = this.getKeyRange(row.getKeyCell());
                ClientTsProtocol tsNode = getTsNode(kr);
                tsNode.insertRow(kr.getTabletId(), wrap);
                return;
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(row.getKeyCell(), kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public void insertRows(DataRow[] rows) throws OmapException {
        new BatchWrite<DataRow>(rows) {

            @Override
            protected Future<Object> call(ClientTsProtocol tsNode,
                    long tabletId, ByteArrayWritable[] byteArrs)
                    throws RpcException {
                Future<Object> future = RPC.asyncInvoke(tsNode,
                        TS_METHOD_MULTI_INSERT, tabletId, byteArrs);
                return future;
            }

            @Override
            protected KeyCell getKeyCell(DataRow obj) {
                return obj.getKeyCell();
            }

            @Override
            protected List<DataRow> makeList() {
                return new ArrayList<DataRow>();
            }
        }.exec();
    }

    public void deleteRow(KeyCell key) throws OmapException {
        ByteArrayWritable w = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));

        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) { // terminate on return or retry fail (IOException)
            KeyRange kr = null;
            try {
                kr = this.getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                tsNode.deleteRow(kr.getTabletId(), w);
                return;
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public void deleteRows(KeyCell[] keys) throws OmapException {
        new BatchWrite<KeyCell>(keys) {

            @Override
            protected Future<Object> call(ClientTsProtocol tsNode,
                    long tabletId, ByteArrayWritable[] byteArrs)
                    throws RpcException {
                Future<Object> future = RPC.asyncInvoke(tsNode,
                        TS_METHOD_MULTI_DELETE, tabletId, byteArrs);
                return future;
            }

            @Override
            protected KeyCell getKeyCell(KeyCell obj) {
                return obj;
            }

            @Override
            protected List<KeyCell> makeList() {
                return new ArrayList<KeyCell>();
            }
        }.exec();
    }

    private Map<KeyRange, Pair<KeyCell, KeyCell>> splitRange(
            KeyCell startKeyInclusive, KeyCell endKeyExcluesive)
            throws IOException {
        Map<KeyRange, Pair<KeyCell, KeyCell>> ret = new HashMap<KeyRange, Pair<KeyCell, KeyCell>>();
        KeyCell start = startKeyInclusive;
        while (true) {
            KeyRange kr = getKeyRange(start);
            if (kr.getKey2().compareTo(endKeyExcluesive.getKey()) >= 0) {
                Pair<KeyCell, KeyCell> pair = new Pair<KeyCell, KeyCell>(start,
                        endKeyExcluesive);
                ret.put(kr, pair);
                break;
            } else {
                KeyCell end = new KeyCell(kr.getKey2());
                Pair<KeyCell, KeyCell> pair = new Pair<KeyCell, KeyCell>(start,
                        end);
                ret.put(kr, pair);
                start = end;
            }
        }
        return ret;
    }

    public void deleteRows(KeyCell startKeyInclusive, KeyCell endKeyExcluesive)
            throws OmapException {
        Set<Pair<KeyCell, KeyCell>> pendingRanges = new HashSet<Pair<KeyCell, KeyCell>>();
        pendingRanges.add(new Pair<KeyCell, KeyCell>(startKeyInclusive,
                endKeyExcluesive));
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        outer: while (!pendingRanges.isEmpty()) {
            Map<KeyRange, Pair<KeyCell, KeyCell>> rangeMap = new HashMap<KeyRange, Pair<KeyCell, KeyCell>>();
            for (Pair<KeyCell, KeyCell> pair: pendingRanges) {
                try {
                    rangeMap.putAll(splitRange(pair.getFirst(),
                            pair.getSecond()));
                } catch (Exception e) {
                    retryCount++;
                    handleDataAccessExceptions(pair.getFirst(), null, e,
                            System.currentTimeMillis() - startTime, retryCount);
                    break outer;
                }
            }

            Throwable exc = null;
            KeyRange curKr = null;
            KeyCell curKey = null;
            List<Pair<KeyCell, KeyCell>> rangeList = new ArrayList<Pair<KeyCell, KeyCell>>();
            List<KeyRange> krList = new ArrayList<KeyRange>();
            List<Future<Integer>> futureList = new ArrayList<Future<Integer>>();
            pendingRanges.clear();

            for (Map.Entry<KeyRange, Pair<KeyCell, KeyCell>> entry: rangeMap.entrySet()) {
                KeyRange kr = entry.getKey();
                Pair<KeyCell, KeyCell> pair = entry.getValue();
                try {
                    ClientTsProtocol tsNode = getTsNode(kr);
                    Future<Integer> future = RPC.asyncInvoke(
                            tsNode,
                            TS_METHOD_DELETE_RANGE,
                            kr.getTabletId(),
                            new ByteArrayWritable(
                                    OmapUtils.convertPIWritableToBytes(pair.getFirst())),
                            new ByteArrayWritable(
                                    OmapUtils.convertPIWritableToBytes(pair.getSecond())));
                    futureList.add(future);
                    krList.add(kr);
                    rangeList.add(pair);
                } catch (Exception e) {
                    exc = e;
                    curKr = kr;
                    curKey = pair.getFirst();
                    pendingRanges.add(pair);
                }
            }

            for (int i = 0; i < futureList.size(); i++) {
                try {
                    int deleteCount = futureList.get(i).get();
                    if (deleteCount != 0) {
                        pendingRanges.add(rangeList.get(i));
                    }
                } catch (Exception e) {
                    if (e instanceof ExecutionException) {
                        exc = e.getCause();
                    } else {
                        exc = e;
                    }
                    curKr = krList.get(i);
                    curKey = rangeList.get(i).getFirst();
                    pendingRanges.add(rangeList.get(i));
                }
            }
            if (exc != null) {
                retryCount++;
                handleDataAccessExceptions(curKey, curKr, exc,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    private abstract class BatchWrite<T extends IPreInitializedWritable> {

        protected abstract KeyCell getKeyCell(T obj);

        protected abstract List<T> makeList();

        protected abstract Future<Object> call(ClientTsProtocol tsNode,
                long tabletId, ByteArrayWritable[] byteArrs)
                throws RpcException;

        protected T[] objs;

        public BatchWrite(T[] objs) {
            this.objs = objs;
        }

        public void exec() throws OmapException {
            Set<KeyCell> success = new HashSet<KeyCell>();
            int retryCount = 0;
            long startTime = System.currentTimeMillis();
            outer: while (true) { // terminate on return or retry fail (IOException)
                KeyCell curKey = null;
                KeyRange curKr = null;

                Map<KeyRange, List<T>> partition = new HashMap<KeyRange, List<T>>();

                // do partition
                for (int i = 0; i < objs.length; i++) {
                    T obj = objs[i];
                    KeyCell keyCell = getKeyCell(obj);
                    if (success.contains(keyCell)) {
                        continue;
                    }
                    KeyRange kr = null;
                    try {
                        kr = getKeyRange(keyCell);
                    } catch (Exception e) {
                        retryCount++;
                        handleDataAccessExceptions(keyCell, kr, e,
                                System.currentTimeMillis() - startTime,
                                retryCount);
                        continue outer;
                    }
                    // add this row to the partition
                    List<T> list = partition.get(kr);
                    if (list != null)
                        list.add(obj);
                    else {
                        list = makeList();
                        list.add(obj);
                        partition.put(kr, list);
                    }
                }
                // end partitioning
                Throwable exc = null;
                List<Future<Object>> futureList = new ArrayList<Future<Object>>();
                List<List<T>> objsList = new ArrayList<List<T>>();
                List<KeyRange> krList = new ArrayList<KeyRange>();
                // insert records for each tablet
                for (Map.Entry<KeyRange, List<T>> entry: partition.entrySet()) {
                    try {
                        KeyRange kr = entry.getKey();
                        List<T> list = entry.getValue();
                        ByteArrayWritable[] byteArrs = new ByteArrayWritable[list.size()];
                        for (int i = 0; i < list.size(); i++) {
                            byteArrs[i] = new ByteArrayWritable(
                                    OmapUtils.convertPIWritableToBytes(list.get(i)));
                        }
                        ClientTsProtocol tsNode = getTsNode(kr);
                        Future<Object> future = call(tsNode, kr.getTabletId(),
                                byteArrs);
                        futureList.add(future);
                        objsList.add(list);
                        krList.add(kr);
                    } catch (Exception e) {
                        exc = e;
                        curKr = entry.getKey();
                        curKey = getKeyCell(entry.getValue().get(0));
                    }
                }
                for (int i = 0; i < futureList.size(); i++) {
                    try {
                        futureList.get(i).get();
                        for (T obj: objsList.get(i)) {
                            success.add(getKeyCell(obj));
                        }
                    } catch (Exception e) {
                        if (e instanceof ExecutionException) {
                            exc = e.getCause();
                        } else {
                            exc = e;
                        }
                        curKr = krList.get(i);
                        curKey = getKeyCell(objsList.get(i).get(0));
                    }
                }
                if (exc != null) {
                    retryCount++;
                    handleDataAccessExceptions(curKey, curKr, exc,
                            System.currentTimeMillis() - startTime, retryCount);
                } else {
                    return;
                }
            }
        }
    }

    public boolean compareAndInsertRow(KeyCell key, String columnName,
            DataCell columnValue, DataRow row) throws OmapException {
        ByteArrayWritable binaryKey = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));
        ByteArrayWritable binaryColumn = columnName == null ? null
                : new ByteArrayWritable(
                        OmapUtils.convertPIWritableToBytes(columnValue));
        ByteArrayWritable binaryRow = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(row));
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        for (;;) { // terminate on done or IOException
            KeyRange kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                return tsNode.compareAndSet(kr.getTabletId(), binaryKey,
                        columnName, binaryColumn, binaryRow);
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public boolean compareAndDeleteRow(KeyCell key, String columnName,
            DataCell columnValue, KeyCell delete) throws OmapException {
        ByteArrayWritable binaryKey = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));
        ByteArrayWritable binaryColumn = columnName == null ? null
                : new ByteArrayWritable(
                        OmapUtils.convertPIWritableToBytes(columnValue));
        ByteArrayWritable binaryRow = new ByteArrayWritable(
                DataRow.createDeletedRow(OmapUtils.convertPIWritableToBytes(delete)));
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        for (;;) { // terminate on done or IOException
            KeyRange kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                return tsNode.compareAndSet(kr.getTabletId(), binaryKey,
                        columnName, binaryColumn, binaryRow);
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public void handleNoSuchSchemaFailure(OmapQuery query) throws OmapException {
        TableDesc td = metadata.getTableDesc();
        masterWatcher.getMetadataCache().clearTableInfo(td.getSchemaId(),
                td.getTableName());
        try {
            updateTableMeta(false);
        } catch (IOException e) {
            throw new OmapException("update table meta failed", e);
        }
        if (!metadata.getIndexes().containsKey(query.getIndexSchema())) {
            throw new OmapException("metadata do not contain IndexSchema = "
                    + query.getIndexSchema());
        }
    }

    /**
     * Execute a query
     * 
     * @param query
     *            the query object
     * @return A list of keys whose row match the query. If nothing found return
     *         an empty query.
     * @throws OmapException
     * @author xingjk
     */
    List<IWritable> doExecute(OmapQuery query) throws OmapException {
        while (true) {
            try {
                return queryExecutor.doExecute(query);
            } catch (NoSuchSchemaException e) {
                LOG.log(Level.WARNING, "metadata not correct, need refresh", e);
                handleNoSuchSchemaFailure(query);
            }
        }
    }

    public Map<String, OmapClient> getIndexClients() {
        return Collections.unmodifiableMap(indexClients);
    }

    public void setTableProperties(String[] properties) throws OmapException {
        try {
            masterWatcher.getNoTimeoutMaster().setTableProperties(
                    getTableDesc().getSchemaId(), properties);
        } catch (IOException e) {
            throw new OmapException(e);
        }
    }

    private static final long DEFAULT_LOCK_EXPIRE_TIME = 60000;

    public void insertRowWithQuery(DataRow row) throws OmapException {
        ByteArrayWritable binaryKey = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(row.getKeyCell()));
        ByteArrayWritable binaryRow = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(row));
        Map<String, OmapQuery> queryMap = metadata.getQueries();
        String lockName = null;
        KeyRange kr = null;
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) {
            kr = null;
            try {
                kr = getKeyRange(row.getKeyCell());
                ClientTsProtocol tsNode = getTsNode(kr);
                lockName = tsNode.lockRow(kr.getTabletId(), binaryKey,
                        DEFAULT_LOCK_EXPIRE_TIME, lockName);
                ByteArrayWritable originalBinaryRow = tsNode.keyFind(
                        kr.getTabletId(), binaryKey);
                if (originalBinaryRow == null) { // just insert
                    IWritableComparable[] values = OmapQueryUtils.convertDataRowToIWritableComparableArray(row);
                    for (OmapQuery query: queryMap.values()) {
                        IndexSchema is = metadata.getPreparedIndexSchema(query.getIndexSchema());
                        DataRow indexRow = is.createIndexRow(row.getKeyCell(),
                                values);
                        String indexTableName = metadata.getIndexes().get(is);
                        indexClients.get(indexTableName).insertRow(indexRow);
                    }
                } else { // delete, then insert
                    TableDesc td = metadata.getTableDesc();
                    DataRow originalRow = td.borrowDataRow();
                    OmapUtils.convertBytesToPIWritable(
                            originalBinaryRow.data(), 0,
                            originalBinaryRow.size(), originalRow);
                    IWritableComparable[] originalValues = OmapQueryUtils.convertDataRowToIWritableComparableArray(originalRow);
                    IWritableComparable[] values = OmapQueryUtils.convertDataRowToIWritableComparableArray(row);
                    for (OmapQuery query: queryMap.values()) {
                        IndexSchema is = metadata.getPreparedIndexSchema(query.getIndexSchema());
                        DataRow originalIndexRow = is.createIndexRow(
                                originalRow.getKeyCell(), originalValues);
                        DataRow indexRow = is.createIndexRow(row.getKeyCell(),
                                values);
                        if (!originalIndexRow.equals(indexRow)) {
                            String indexTableName = metadata.getIndexes().get(
                                    is);
                            OmapClient indexClient = indexClients.get(indexTableName);
                            indexClient.deleteRow(originalIndexRow.getKeyCell());
                            indexClient.insertRow(indexRow);
                        }
                    }
                }
                tsNode.insertRow(kr.getTabletId(), binaryRow);
                return;
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(row.getKeyCell(), kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            } finally {
                if (lockName != null && kr != null) {
                    try {
                        getTsNode(kr).unlockRow(kr.getTabletId(), lockName);
                    } catch (Throwable t) {
                        LOG.log(Level.WARNING, "unlock key failed", t);
                    }
                }
            }
        }
    }

    public void deleteRowWithQuery(KeyCell key) throws OmapException {
        ByteArrayWritable binaryKey = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));
        Map<String, OmapQuery> queryMap = metadata.getQueries();
        String lockName = null;
        KeyRange kr = null;
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) {
            kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                lockName = tsNode.lockRow(kr.getTabletId(), binaryKey,
                        DEFAULT_LOCK_EXPIRE_TIME, lockName);
                ByteArrayWritable originalBinaryRow = tsNode.keyFind(
                        kr.getTabletId(), binaryKey);
                if (originalBinaryRow != null) {
                    TableDesc td = metadata.getTableDesc();
                    DataRow originalRow = td.borrowDataRow();
                    OmapUtils.convertBytesToPIWritable(
                            originalBinaryRow.data(), 0,
                            originalBinaryRow.size(), originalRow);
                    IWritableComparable[] originalValues = OmapQueryUtils.convertDataRowToIWritableComparableArray(originalRow);
                    for (OmapQuery query: queryMap.values()) {
                        IndexSchema is = metadata.getPreparedIndexSchema(query.getIndexSchema());
                        DataRow originalIndexRow = is.createIndexRow(
                                originalRow.getKeyCell(), originalValues);
                        String indexTableName = metadata.getIndexes().get(is);
                        indexClients.get(indexTableName).deleteRow(
                                originalIndexRow.getKeyCell());
                    }
                }
                tsNode.deleteRow(kr.getTabletId(), binaryKey);
                return;
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            } finally {
                if (lockName != null && kr != null) {
                    try {
                        getTsNode(kr).unlockRow(kr.getTabletId(), lockName);
                    } catch (Throwable t) {
                        LOG.log(Level.WARNING, "unlock key failed", t);
                    }
                }
            }
        }
    }

    public String lockRow(KeyCell key, long expireTime, String prevLockName)
            throws OmapException {
        ByteArrayWritable binaryKey = new ByteArrayWritable(
                OmapUtils.convertPIWritableToBytes(key));
        KeyRange kr;
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) {
            kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                return tsNode.lockRow(kr.getTabletId(), binaryKey, expireTime,
                        prevLockName);
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }
    }

    public void unlockRow(KeyCell key, String lockName) throws OmapException {
        KeyRange kr;
        int retryCount = 0;
        long startTime = System.currentTimeMillis();
        while (true) {
            kr = null;
            try {
                kr = getKeyRange(key);
                ClientTsProtocol tsNode = getTsNode(kr);
                tsNode.unlockRow(kr.getTabletId(), lockName);
                return;
            } catch (Exception e) {
                retryCount++;
                handleDataAccessExceptions(key, kr, e,
                        System.currentTimeMillis() - startTime, retryCount);
            }
        }

    }
}
