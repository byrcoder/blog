package outfox.omap.exceptions;

public class ServerUnavailableException extends RuntimeException {

    private static final long serialVersionUID = 3298691825896049053L;

    public ServerUnavailableException() {
        super();
    }

    public ServerUnavailableException(String message) {
        super(message);
    }

    public ServerUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServerUnavailableException(Throwable cause) {
        super(cause);
    }
}
