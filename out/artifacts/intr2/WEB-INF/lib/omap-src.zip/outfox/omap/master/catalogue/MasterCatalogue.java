/**
 * @(#)CatalogueStore.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DistributedFileSystem;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongWritable;
import odis.util.MiscUtils;
import outfox.omap.client.OmapMetadata;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConfig;
import outfox.omap.conf.OmapConstants;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.exceptions.NoSuchSchemaException;
import outfox.omap.exceptions.TableExistException;
import outfox.omap.master.AssignTabletTask;
import outfox.omap.master.Task;
import outfox.omap.metadata.TableDesc;
import outfox.omap.metrics.MasterTableMetricsEntry;
import outfox.omap.ts.TsUsageReport;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.OmapUtils.TESTCASE_PREPENSE_EXCEPTION_TYPE;
import outfox.omap.util.WaitUtils;
import outfox.omap.walog.LogReader;
import outfox.omap.walog.WALogFile;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class MasterCatalogue implements Closeable, OmapConstants {

    private static final Logger LOG = LogFormatter.getLogger(MasterCatalogue.class);

    private FileSystem fs;

    private Store<LongWritable, OmapMetadata> metaStore;

    private Store<SchemaIdAndRange, TsDesc> rangeStore;

    private Store<LongWritable, AssignTabletTask> taskStore;

    private final Map<Long, OmapMetadata> tables = new TreeMap<Long, OmapMetadata>();

    private final Map<Long, KeyRangeList> keyranges = new TreeMap<Long, KeyRangeList>();

    private final Map<Long, MasterTableMetricsEntry> tableMetricsEntries = new HashMap<Long, MasterTableMetricsEntry>();

    private final Map<Long, Task> tasks = new TreeMap<Long, Task>();

    private final Map<String, Long> name2ids = new HashMap<String, Long>();

    private final Map<Long, TsDesc> tablet2ts = new TreeMap<Long, TsDesc>();

    private CatalogueLogger logger;

    private Object lock = new Object();

    private ScheduledFuture<?> checkpointTask;

    private ScheduledFuture<?> compactTask;

    private long nextSchemaId;

    private Path maxSchemaIdDir;

    private Random rand = new Random();

    private static final int DEFAULT_FATAL_ERROR_RETRY_COUNT = 10;

    private void recover(Path logDir) throws IOException {
        LOG.info("recover catalogue from log " + logDir);
        if (fs instanceof DistributedFileSystem) {
            for (;;) {
                Path[] unclosedLogs = ((DistributedFileSystem) fs).pendingFilesInDir(logDir);
                if (unclosedLogs != null && unclosedLogs.length > 0) {
                    LOG.severe("WALogs of master catalogue is not closed (files="
                            + Arrays.toString(unclosedLogs)
                            + ")."
                            + " This usually happens when Master hasn't completely shut down."
                            + " I cannot recover the catalogue until is completely shut down.");
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {}
                } else {
                    break;
                }
            }
        }
        CatalogueLogger loggerForRecover = new CatalogueLogger(logDir, fs, true);
        CatalogueRecoverHandler recoverHandler = new CatalogueRecoverHandler(
                metaStore, rangeStore, taskStore);
        LogReader logReader = new LogReader(loggerForRecover.getLogChunks(true,
                true), new CatalogueLogEntry(), recoverHandler);
        logReader.read();
        loggerForRecover.close();
        LOG.info("recover log end, checkpoint");
        metaStore.prepareForFlush();
        metaStore.flush();
        rangeStore.prepareForFlush();
        rangeStore.flush();
        taskStore.prepareForFlush();
        taskStore.flush();
        LOG.info("find max schema id");
        FileInfo[] maxSchemaIds = fs.listFiles(maxSchemaIdDir);
        if (maxSchemaIds == null || maxSchemaIds.length == 0) {
            nextSchemaId = FIRST_USER_SCHEMAID;
        } else {
            Arrays.sort(maxSchemaIds, new Comparator<FileInfo>() {

                @Override
                public int compare(FileInfo o1, FileInfo o2) {
                    long l1 = Long.parseLong(o1.getPath().getName());
                    long l2 = Long.parseLong(o2.getPath().getName());
                    return l1 > l2 ? 1 : l1 == l2 ? 0 : -1;
                }
            });
            for (int i = 0; i < maxSchemaIds.length - 1; i++) {
                fs.delete(maxSchemaIds[i].getPath());
            }
            nextSchemaId = Long.parseLong(maxSchemaIds[maxSchemaIds.length - 1].getPath().getName());
        }
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_RECOVERING_TASK);
        for (Path f: fs.listPaths(logDir)) {
            if (!fs.delete(f)) {
                LOG.warning("delete log file " + f + " failed");
            }
        }
        logger = new CatalogueLogger(logDir, fs, false);
        // load all data to memory
        LOG.info("Load meta to memory");
        LongWritable metaKey = new LongWritable();
        Store<LongWritable, OmapMetadata>.Value metaValue = metaStore.getValue();
        Cursor<LongWritable, Store<LongWritable, OmapMetadata>.Value> metaCursor = metaStore.getStoreCursor();
        int count = 0;
        try {
            while (metaCursor.next(metaKey, metaValue)) {
                LOG.fine("metaKey: " + metaKey + ", metaValue: " + metaValue);
                if (!metaValue.deleted) {
                    OmapMetadata metadata = new OmapMetadata();
                    metadata.copyFields(metaValue.value);
                    LOG.info("METADATA: " + metadata);
                    tables.put(metaKey.get(), metadata);
                    name2ids.put(metadata.getInternalTableName(), metaKey.get());
                    tableMetricsEntries.put(metaKey.get(),
                            new MasterTableMetricsEntry());
                    count++;
                }
            }
        } finally {
            MiscUtils.safeClose(metaCursor);
        }
        LOG.info("Load " + count + " metas");

        LOG.info("Load range to memory");
        SchemaIdAndRange rangeKey = new SchemaIdAndRange();
        Store<SchemaIdAndRange, TsDesc>.Value rangeValue = rangeStore.getValue();
        Cursor<SchemaIdAndRange, Store<SchemaIdAndRange, TsDesc>.Value> rangeCursor = rangeStore.getStoreCursor();
        count = 0;
        try {
            while (rangeCursor.next(rangeKey, rangeValue)) {
                LOG.fine("rangeKey: " + rangeKey + ", rangeValue: "
                        + rangeValue);
                if (!rangeValue.deleted) {
                    count++;
                    if (tables.get(rangeKey.getSchemaId()) == null) {
                        rangeStore.delete(rangeKey);
                        continue;
                    }
                    KeyRangeList krl = keyranges.get(rangeKey.getSchemaId());
                    if (krl == null) {
                        krl = new KeyRangeList();
                        keyranges.put(rangeKey.getSchemaId(), krl);
                    }
                    TsDesc tsDesc = new TsDesc();
                    tsDesc.copyFields(rangeValue.value);
                    KeyRange kr = new KeyRange(rangeKey.getRange().getKey1(),
                            rangeKey.getRange().getKey2(), tsDesc,
                            rangeKey.getTabletId());
                    Path tabletPath = new Path(
                            OmapUtils.getSSTableFileDirPath(
                                    OmapConfig.getTsTabletDir(),
                                    rangeKey.getTabletId()));
                    if (!fs.exists(tabletPath)) {
                        LOG.warning(kr + " tablet not exists, delete it");
                        deleteTablet(kr);
                    } else {
                        KeyRange oldKr = krl.lookup(kr.getKey1());
                        if (oldKr != null) {
                            LOG.warning(kr
                                    + " is overlaped with "
                                    + oldKr
                                    + ", master maybe crashed when splitting, delete it");
                            deleteTablet(kr);
                            fs.delete(tabletPath);
                        } else {
                            LOG.fine("KEYRANGE: " + kr);
                            krl.insert(kr);
                            if (tablet2ts.put(rangeKey.getTabletId(), tsDesc) != null) {
                                TableDesc td = tables.get(
                                        krl.first().getSchemaId()).getTableDesc();
                                String msg = HexString.longToPaddedHex(rangeKey.getTabletId())
                                        + " occured multi times";
                                LOG.warning(msg);
                                AlertUtils.alert(
                                        "Duplicated tablet id found for table "
                                                + td.getTableName(), msg,
                                        false, true);
                            }
                        }
                    }
                }
            }
        } finally {
            MiscUtils.safeClose(rangeCursor);
        }

        LOG.info("Load " + count + " ranges, do coverage check");
        StringBuilder sb = new StringBuilder();
        for (KeyRangeList krl: keyranges.values()) {
            sb.setLength(0);
            List<KeyRange> list = krl.getRangeList();
            if (list.get(0).getKey1() != null) {
                sb.append("Missing first range\n");
            }
            for (int i = 1; i < list.size(); i++) {
                KeyRange prev = list.get(i - 1);
                KeyRange cur = list.get(i);
                if (!prev.getKey2().equals(cur.getKey1())) {
                    sb.append("Missing range [" + prev.getKey2() + ", "
                            + cur.getKey1() + "]\n");
                }
            }
            if (list.get(list.size() - 1).getKey2() != KeyPair.MAX_WRITABLE) {
                sb.append("Missing last range\n");
            }
            if (sb.length() > 0) {
                TableDesc td = tables.get(krl.first().getSchemaId()).getTableDesc();
                LOG.info("Found incomplete range coverage for table " + td);
                AlertUtils.alert(
                        "Incomplete range coverage for table "
                                + td.getTableName() + "("
                                + HexString.longToPaddedHex(td.getSchemaId())
                                + ")", sb.toString(), false, true);
            }
        }
        LOG.info("load task to memory");
        LongWritable taskKey = new LongWritable();
        Store<LongWritable, AssignTabletTask>.Value taskValue = taskStore.getValue();
        Cursor<LongWritable, Store<LongWritable, AssignTabletTask>.Value> taskCursor = taskStore.getStoreCursor();
        try {
            while (taskCursor.next(taskKey, taskValue)) {
                LOG.fine("taskKey: " + taskKey + ", taskValue: " + taskValue);
                if (!taskValue.deleted) {
                    AssignTabletTask task = new AssignTabletTask();
                    task.copyFields(taskValue.value);
                    LOG.info("TASK: " + task);
                    tasks.put(taskKey.get(), task);
                }
            }
        } finally {
            MiscUtils.safeClose(taskCursor);
        }
    }

    private PriorityQueue<WALogFile> prepareCheckpoint() {
        LOG.info("Prepare checkpoint");
        PriorityQueue<WALogFile> logFiles;
        synchronized (lock) {
            metaStore.prepareForFlush();
            rangeStore.prepareForFlush();
            taskStore.prepareForFlush();
            logger.startNewChunkAndWait();
            try {
                logFiles = logger.getLogChunks(true, false);
            } catch (IOException e) {
                LOG.log(Level.WARNING, "get delete log files failed", e);
                logFiles = new PriorityQueue<WALogFile>(0);
            }
        }
        LOG.info("Got to be deleted log files " + logFiles);
        return logFiles;
    }

    private void checkpoint() throws IOException {
        int count = metaStore.flush();
        LOG.info("flush metaStore, write out " + count + " entries");
        count = rangeStore.flush();
        LOG.info("flush rangeStore, write out " + count + " entries");
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_CHECKPOINTING_CATALOGUE);
        count = taskStore.flush();
        LOG.info("flush taskStore, write out " + count + " entries");

    }

    private void compact() throws IOException {
        metaStore.compact();
        rangeStore.compact();
        taskStore.compact();
    }

    private class CheckpointTask implements Runnable {

        private long nextForceCheckpointTime;

        public CheckpointTask() {
            nextForceCheckpointTime = System.currentTimeMillis()
                    + OmapConfig.getConfiguration().getLong(
                            OmapConfig.NAME_MASTER_CATALOGUE_FORCE_CHECKPOINT_INTERVAL,
                            OmapConfig.DEFAULT_MASTER_CATALOGUE_FORCE_CHECKPOINT_INTERVAL)
                    * 1000;
        }

        @Override
        public void run() {
            boolean needCheckpoint;
            if (System.currentTimeMillis() > nextForceCheckpointTime) {
                needCheckpoint = true;
            } else {
                synchronized (lock) {
                    needCheckpoint = metaStore.needFlush()
                            || rangeStore.needFlush() || taskStore.needFlush();
                }
            }
            if (needCheckpoint) {
                PriorityQueue<WALogFile> logFiles = prepareCheckpoint();
                int retryCount = 0;
                while (true) {
                    try {
                        checkpoint();
                        nextForceCheckpointTime = System.currentTimeMillis()
                                + OmapConfig.getConfiguration().getLong(
                                        OmapConfig.NAME_MASTER_CATALOGUE_FORCE_CHECKPOINT_INTERVAL,
                                        OmapConfig.DEFAULT_MASTER_CATALOGUE_FORCE_CHECKPOINT_INTERVAL)
                                * 1000;
                        break;
                    } catch (Throwable t) {
                        LOG.log(Level.WARNING,
                                "checkpoint failed, retryCount = " + retryCount,
                                t);
                        if (retryCount > DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                            AlertUtils.alert(
                                    "Master catalogue checkpoint task failed",
                                    OmapUtils.getStackTrace(t), false, true);
                        }
                        WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                                retryCount, rand));
                        retryCount++;
                    }
                }
                LOG.info("Delete old log files " + logFiles);
                for (WALogFile file: logFiles) {
                    try {
                        if (!fs.delete(file.getFile())) {
                            LOG.warning("delete log file " + file + " failed");
                        }
                    } catch (IOException e) {
                        LOG.log(Level.WARNING, "delete log file " + file
                                + " failed", e);
                    }
                }
            }

        }
    }

    private class CompactTask implements Runnable {

        @Override
        public void run() {
            int retryCount = 0;
            while (true) {
                try {
                    compact();
                    break;
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "compact failed, retryCount = "
                            + retryCount, t);
                    if (retryCount > DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                        AlertUtils.alert(
                                "Master catalogue compact task failed",
                                OmapUtils.getStackTrace(t), false, true);
                    }
                    WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                            retryCount, rand));
                    retryCount++;
                }

            }
        }

    }

    public MasterCatalogue(FileSystem fs,
            ScheduledExecutorService backgroundTaskPool) throws IOException {
        boolean newService = false;
        this.fs = fs;
        Path catalogueDir = OmapConfig.getMasterCatalogueDataRoot();
        if (!fs.exists(catalogueDir)) {
            newService = true;
            fs.mkdirs(new Path(OmapConfig.getTsTabletDir()));
            fs.mkdirs(catalogueDir);
            fs.mkdirs(catalogueDir.cat("meta"));
            fs.mkdirs(catalogueDir.cat("range"));
            fs.mkdirs(catalogueDir.cat("task"));
            fs.mkdirs(catalogueDir.cat("log"));
            fs.mkdirs(catalogueDir.cat("maxSchemaId"));
        }
        maxSchemaIdDir = catalogueDir.cat("maxSchemaId");
        metaStore = new Store<LongWritable, OmapMetadata>(fs,
                catalogueDir.cat("meta"), LongWritable.class,
                OmapMetadata.class);
        rangeStore = new Store<SchemaIdAndRange, TsDesc>(fs,
                catalogueDir.cat("range"), SchemaIdAndRange.class, TsDesc.class);
        taskStore = new Store<LongWritable, AssignTabletTask>(fs,
                catalogueDir.cat("task"), LongWritable.class,
                AssignTabletTask.class);
        if (newService) {
            logger = new CatalogueLogger(catalogueDir.cat("log"), fs, false);
            nextSchemaId = FIRST_USER_SCHEMAID;
        } else {
            recover(catalogueDir.cat("log"));
        }
        LOG.info("SchemaId starts from "
                + HexString.longToPaddedHex(nextSchemaId));
        long checkpointInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_MASTER_CATALOGUE_CHECKPOINT_INTERVAL,
                OmapConfig.DEFAULT_MASTER_CATALOGUE_CHECKPOINT_INTERVAL);
        checkpointTask = backgroundTaskPool.scheduleAtFixedRate(
                new CheckpointTask(), checkpointInterval, checkpointInterval,
                TimeUnit.SECONDS);
        long compactInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_MASTER_CATALOGUE_COMPACT_INTERVAL,
                OmapConfig.DEFAULT_MASTER_CATALOGUE_COMPACT_INTERVAL);
        compactTask = backgroundTaskPool.scheduleAtFixedRate(new CompactTask(),
                compactInterval, compactInterval, TimeUnit.SECONDS);
    }

    public void addSchema(OmapMetadata metadata) throws IOException,
            TableExistException {
        long schemaId = metadata.getTableDesc().getSchemaId();
        String name = metadata.getInternalTableName();
        synchronized (lock) {
            if (tables.containsKey(schemaId)) {
                throw new TableExistException(
                        "Table already exists with schemaId "
                                + HexString.longToPaddedHex(schemaId));
            }
            if (name2ids.containsKey(name)) {
                throw new TableExistException(
                        "Table already exists with name '" + name + "'");
            }
            logger.writeSchemaLog(schemaId, false, metadata);
            metaStore.add(new LongWritable(schemaId), metadata);
            tables.put(schemaId, metadata);
            name2ids.put(metadata.getInternalTableName(), schemaId);
            keyranges.put(schemaId, new KeyRangeList());
            tableMetricsEntries.put(schemaId, new MasterTableMetricsEntry());
        }
    }

    public void deleteSchema(long schemaId, boolean removeKeyRange)
            throws IOException {
        synchronized (lock) {
            logger.writeSchemaLog(schemaId, true, null);
            metaStore.delete(new LongWritable(schemaId));
            OmapMetadata metadata = tables.remove(schemaId);
            if (metadata != null) {
                name2ids.remove(metadata.getInternalTableName());
            }
            if (removeKeyRange) {
                KeyRangeList krl = keyranges.remove(schemaId);
                if (krl != null) {
                    SchemaIdAndRange[] ranges = new SchemaIdAndRange[krl.size()];
                    int index = 0;
                    for (KeyRange kr: krl.getRangeSet().keySet()) {
                        ranges[index] = SchemaIdAndRange.createFromKeyRange(kr);
                        index++;
                    }
                    boolean[] deleted = new boolean[krl.size()];
                    Arrays.fill(deleted, true);
                    logger.writeRangeLog(ranges, deleted,
                            new TsDesc[krl.size()]);
                    for (SchemaIdAndRange range: ranges) {
                        rangeStore.delete(range);
                    }
                }
            }
        }
    }

    public void updateSchema(OmapMetadata metadata) throws IOException {
        long schemaId = metadata.getTableDesc().getSchemaId();
        synchronized (lock) {
            if (!tables.containsKey(schemaId)) {
                throw new NoSuchSchemaException("Table " + metadata
                        + " not found");
            }
            logger.writeSchemaLog(schemaId, false, metadata);
            metaStore.add(new LongWritable(schemaId), metadata);
            tables.put(schemaId, metadata);
            name2ids.put(metadata.getInternalTableName(), schemaId);
        }
    }

    public long changeTableName(String originName, String currName)
            throws IOException, TableExistException {
        synchronized (lock) {
            OmapMetadata metadata = findMetadata(originName);
            if (metadata == null) {
                throw new NoSuchSchemaException("Table named " + "'"
                        + originName + "'" + " does not exist.");
            }
            if (name2ids.containsKey(currName)) {
                throw new TableExistException("Table named " + "'" + currName
                        + "'" + " already exists.");
            }
            OmapMetadata newMeta = new OmapMetadata();
            newMeta.copyFields(metadata);
            newMeta.getTableDesc().setTableName(currName);
            long schemaId = metadata.getTableDesc().getSchemaId();
            logger.writeSchemaLog(schemaId, false, newMeta);
            metaStore.add(new LongWritable(schemaId), newMeta);
            tables.put(schemaId, newMeta);
            name2ids.remove(originName);
            name2ids.put(currName, schemaId);
            return schemaId;
        }
    }

    public void insertTask(AssignTabletTask task) throws IOException {
        int retryCount = 0;
        while (true) {
            try {
                synchronized (lock) {
                    TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_INSERT_TABLET);
                    logger.writeTaskLog(task.getTaskId(), false, task);
                    taskStore.add(new LongWritable(task.getTaskId()), task);
                    tasks.put(task.getTaskId(), task);
                    KeyRange kr = task.getKr();
                    rangeStore.add(SchemaIdAndRange.createFromKeyRange(kr),
                            kr.getTsDesc());
                    KeyRangeList krl = keyranges.get(kr.getSchemaId());
                    krl.insert(kr);
                    tablet2ts.put(kr.getTabletId(), kr.getTsDesc());
                    TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_INSERT_TABLET2);
                }
                break;
            } catch (IOException e) {
                if (retryCount >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                    LOG.log(Level.SEVERE, "insertTask " + task
                            + " retryCount reach MAX_RETRY_COUNT = "
                            + DEFAULT_FATAL_ERROR_RETRY_COUNT, e);
                    throw e;
                }
                LOG.log(Level.WARNING, "insertTask " + task
                        + " failed, retryCount = " + retryCount, e);
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
        }
    }

    public void deleteTask(AssignTabletTask task) throws IOException {
        int retryCount = 0;
        while (true) {
            try {
                synchronized (lock) {
                    logger.writeTaskLog(task.getTaskId(), true, null);
                    taskStore.delete(new LongWritable(task.getTaskId()));
                    tasks.remove(task.getTaskId());
                }
                break;
            } catch (IOException e) {
                if (retryCount >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                    LOG.log(Level.SEVERE, "deleteTask " + task
                            + " retryCount reach MAX_RETRY_COUNT = "
                            + DEFAULT_FATAL_ERROR_RETRY_COUNT, e);
                    throw e;
                }
                LOG.log(Level.WARNING, "deleteTask " + task
                        + " failed, retryCount = " + retryCount, e);
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
        }
    }

    public void insertTablet(KeyRange kr) throws IOException {
        SchemaIdAndRange range = SchemaIdAndRange.createFromKeyRange(kr);
        TsDesc tsDesc = kr.getTsDesc();
        int retryCount = 0;
        while (true) {
            try {
                synchronized (lock) {
                    logger.writeRangeLog(range, false, tsDesc);
                    rangeStore.add(range, tsDesc);
                    KeyRangeList krl = keyranges.get(kr.getSchemaId());
                    krl.insert(kr);
                    tablet2ts.put(kr.getTabletId(), kr.getTsDesc());
                    TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_INSERT_TABLET);
                }
                break;
            } catch (IOException e) {
                if (retryCount >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                    LOG.log(Level.SEVERE, "insertTablet " + kr
                            + " retryCount reach MAX_RETRY_COUNT = "
                            + DEFAULT_FATAL_ERROR_RETRY_COUNT, e);
                    throw e;
                }
                LOG.log(Level.WARNING, "insertTablet " + kr
                        + " failed, retryCount = " + retryCount, e);
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
        }
    }

    public void deleteTablet(KeyRange kr) throws IOException {
        SchemaIdAndRange range = SchemaIdAndRange.createFromKeyRange(kr);
        int retryCount = 0;
        while (true) {
            try {
                synchronized (lock) {
                    logger.writeRangeLog(range, true, null);
                    rangeStore.delete(range);
                    KeyRangeList krl = keyranges.get(kr.getSchemaId());
                    KeyRange ori = krl.lookup(kr.getKey1());
                    if (ori != null && ori.equals(kr)) {
                        krl.delete(kr);
                    }
                    tablet2ts.remove(kr.getTabletId());
                }
                break;
            } catch (IOException e) {
                if (retryCount >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                    LOG.log(Level.SEVERE, "deleteTablet " + kr
                            + " retryCount reach MAX_RETRY_COUNT = "
                            + DEFAULT_FATAL_ERROR_RETRY_COUNT, e);
                    throw e;
                }
                LOG.log(Level.WARNING, "deleteTablet " + kr
                        + " failed, retryCount = " + retryCount, e);
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
        }
    }

    public void splitTabletBegin(KeyRange newKr1, KeyRange newKr2)
            throws IOException {
        SchemaIdAndRange[] ranges = new SchemaIdAndRange[2];
        ranges[0] = SchemaIdAndRange.createFromKeyRange(newKr1);
        ranges[1] = SchemaIdAndRange.createFromKeyRange(newKr2);
        boolean[] deleted = new boolean[2];
        deleted[0] = false;
        deleted[1] = false;
        TsDesc[] tsDescs = new TsDesc[2];
        tsDescs[0] = newKr1.getTsDesc();
        tsDescs[1] = newKr2.getTsDesc();
        int retryCount = 0;
        while (true) {
            try {
                synchronized (lock) {
                    logger.writeRangeLog(ranges, deleted, tsDescs);
                }
                break;
            } catch (IOException e) {
                if (retryCount >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                    LOG.log(Level.SEVERE, "splitTabletBegin newKr1 = " + newKr1
                            + " newKr2 = " + newKr2
                            + " retryCount reach MAX_RETRY_COUNT = "
                            + DEFAULT_FATAL_ERROR_RETRY_COUNT, e);
                    throw e;
                }
                LOG.log(Level.WARNING, "splitTabletBegin newKr1 = " + newKr1
                        + " newKr2 = " + newKr2 + " failed, retryCount = "
                        + retryCount, e);
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
        }
    }

    public void splitTabletEnd(KeyRange oldKr, KeyRange newKr1, KeyRange newKr2)
            throws IOException {
        SchemaIdAndRange oldRange = SchemaIdAndRange.createFromKeyRange(oldKr);
        SchemaIdAndRange newRange1 = SchemaIdAndRange.createFromKeyRange(newKr1);
        SchemaIdAndRange newRange2 = SchemaIdAndRange.createFromKeyRange(newKr2);
        int retryCount = 0;
        while (true) {
            try {
                synchronized (lock) {
                    logger.writeRangeLog(oldRange, true, null);
                    rangeStore.delete(oldRange);
                    rangeStore.add(newRange1, newKr1.getTsDesc());
                    rangeStore.add(newRange2, newKr2.getTsDesc());
                    KeyRangeList krl = keyranges.get(oldKr.getSchemaId());
                    krl.delete(oldKr);
                    krl.insert(newKr1);
                    krl.insert(newKr2);
                    tablet2ts.remove(oldKr.getTabletId());
                    tablet2ts.put(newKr1.getTabletId(), newKr1.getTsDesc());
                    tablet2ts.put(newKr2.getTabletId(), newKr2.getTsDesc());
                }
                break;
            } catch (IOException e) {
                if (retryCount >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                    LOG.log(Level.SEVERE, "splitTabletEnd oldKr = " + oldKr
                            + " newKr1 = " + newKr1 + " newKr2 = " + newKr2
                            + " retryCount reach MAX_RETRY_COUNT = "
                            + DEFAULT_FATAL_ERROR_RETRY_COUNT, e);
                    throw e;
                }
                LOG.log(Level.WARNING, "splitTabletEnd oldKr = " + oldKr
                        + " newKr1 = " + newKr1 + " newKr2 = " + newKr2
                        + " failed, retryCount = " + retryCount, e);
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
                retryCount++;
            }
        }
    }

    public OmapMetadata findMetadata(long schemaId) {
        synchronized (lock) {
            return tables.get(schemaId);
        }
    }

    public Pair<OmapMetadata, MasterTableMetricsEntry> findMetadataAndMetricsEntry(
            long schemaId) {
        synchronized (lock) {
            OmapMetadata metadata = tables.get(schemaId);
            if (metadata == null) {
                return null;
            }
            return new Pair<OmapMetadata, MasterTableMetricsEntry>(metadata,
                    tableMetricsEntries.get(schemaId));
        }
    }

    public long getSchemaId(String tableName) {
        synchronized (lock) {
            Long schemaId = name2ids.get(tableName);
            if (schemaId == null) {
                throw new NoSuchSchemaException("tableName = " + tableName
                        + " not found");
            }
            return schemaId.longValue();
        }
    }

    public Pair<Long, MasterTableMetricsEntry> getSchemaIdAndMetricsEntry(
            String tableName) {
        synchronized (lock) {
            Long schemaId = name2ids.get(tableName);
            if (schemaId == null) {
                throw new NoSuchSchemaException("tableName = " + tableName
                        + " not found");
            }
            return new Pair<Long, MasterTableMetricsEntry>(schemaId,
                    tableMetricsEntries.get(schemaId));
        }
    }

    public OmapMetadata findMetadata(String tableName) {
        synchronized (lock) {
            return findMetadata(getSchemaId(tableName));
        }
    }

    public Pair<OmapMetadata, MasterTableMetricsEntry> findMetadataAndMetricsEntry(
            String tableName) {
        synchronized (lock) {
            long schemaId = getSchemaId(tableName);
            OmapMetadata metadata = tables.get(schemaId);
            if (metadata == null) {
                return null;
            }
            return new Pair<OmapMetadata, MasterTableMetricsEntry>(metadata,
                    tableMetricsEntries.get(schemaId));
        }
    }

    public List<KeyRange> getTablets(long schemaId) {
        synchronized (lock) {
            KeyRangeList krlist = keyranges.get(schemaId);
            if (krlist != null) {
                return krlist.getRangeList();
            } else {
                return new ArrayList<KeyRange>();
            }
        }
    }

    public KeyRange findKeyRange(long schemaId, IWritableComparable key) {
        synchronized (lock) {
            KeyRangeList krlist = keyranges.get(schemaId);
            if (krlist == null) {
                return null;
            }
            return krlist.lookup(key);
        }
    }

    public Pair<KeyRange, MasterTableMetricsEntry> findKeyRangeAndMetricsEntry(
            long schemaId, IWritableComparable key) {
        synchronized (lock) {
            KeyRangeList krlist = keyranges.get(schemaId);
            if (krlist == null) {
                return null;
            }
            return new Pair<KeyRange, MasterTableMetricsEntry>(
                    krlist.lookup(key), tableMetricsEntries.get(schemaId));
        }
    }

    public List<OmapMetadata> getTables() {
        List<OmapMetadata> ret;
        synchronized (lock) {
            ret = new ArrayList<OmapMetadata>(tables.values());
        }
        Collections.sort(ret, OmapMetadata.SCHEMA_ID_COMPARATOR);
        return ret;
    }

    public List<OmapMetadata> getTables(String tableSpaceName) {
        List<OmapMetadata> ret = new ArrayList<OmapMetadata>();
        synchronized (lock) {
            for (OmapMetadata meta: tables.values()) {
                if (meta.getTableSpaceName().equals(tableSpaceName)) {
                    ret.add(meta);
                }
            }
        }
        Collections.sort(ret, OmapMetadata.SCHEMA_ID_COMPARATOR);
        return ret;
    }

    public String[] getTableSpaces() {
        Set<String> ret = new HashSet<String>();
        synchronized (lock) {
            for (OmapMetadata meta: tables.values()) {
                ret.add(meta.getTableSpaceName());
            }
        }
        return ret.toArray(new String[0]);
    }

    public int getTableNum() {
        synchronized (lock) {
            return tables.size();
        }

    }

    public int getTabletNum() {
        synchronized (lock) {
            return tablet2ts.size();
        }
    }

    public Map<TsDesc, List<KeyRange>> groupTabletsByTs() {
        synchronized (lock) {
            Map<TsDesc, List<KeyRange>> ret = new HashMap<TsDesc, List<KeyRange>>();
            for (KeyRangeList krlist: keyranges.values()) {
                for (KeyRange kr: krlist.getRangeList()) {
                    List<KeyRange> l = ret.get(kr.getTsDesc());
                    if (l == null) {
                        l = new ArrayList<KeyRange>();
                    }
                    l.add(kr);
                    ret.put(kr.getTsDesc(), l);
                }
            }
            return ret;
        }

    }

    public Set<TsDesc> getTses() {
        synchronized (lock) {
            TsDesc dummyTsDesc = TsDesc.getDummyTsDesc();
            Set<TsDesc> ret = new HashSet<TsDesc>();
            synchronized (tablet2ts) {
                for (TsDesc tsDesc: tablet2ts.values()) {
                    if (!tsDesc.equals(dummyTsDesc)) {
                        ret.add(tsDesc);
                    }
                }
            }
            return ret;
        }
    }

    public Map<TsDesc, Collection<KeyRange>> groupTabletsByTable(long schemaId)
            throws IOException {
        synchronized (lock) {
            Map<TsDesc, Collection<KeyRange>> ret = new HashMap<TsDesc, Collection<KeyRange>>();
            KeyRangeList krlist = keyranges.get(schemaId);
            if (krlist != null) {
                for (KeyRange kr: krlist.getRangeList()) {
                    Collection<KeyRange> l = ret.get(kr.getTsDesc());
                    if (l == null) {
                        l = new ArrayList<KeyRange>();
                    }
                    l.add(kr);
                    ret.put(kr.getTsDesc(), l);
                }
            }
            return ret;
        }
    }

    public List<Task> getUnFinishedTasks() throws IOException {
        synchronized (lock) {
            List<Task> ret = new ArrayList<Task>(tasks.values());
            Collections.sort(ret, Task.ID_COMPATATOR);
            return ret;
        }
    }

    public List<KeyRange> getAllTablets() {
        synchronized (lock) {
            List<KeyRange> list = new ArrayList<KeyRange>();
            for (KeyRangeList krlist: keyranges.values()) {
                list.addAll(krlist.getRangeList());
            }
            return list;
        }
    }

    public TsDesc getTsDesc(long tabletId) {
        synchronized (lock) {
            return tablet2ts.get(tabletId);
        }
    }

    public Map<Long, TsDesc> checkTabletConsistency(TsUsageReport report) {
        Map<Long, TsDesc> ret = new HashMap<Long, TsDesc>();
        synchronized (lock) {
            for (long tabletId: report.getAllTabletsLoad().keySet()) {
                TsDesc actual = tablet2ts.get(tabletId);
                if (!report.getTsDesc().equals(actual)) {
                    ret.put(tabletId, actual);
                }
            }
        }
        return ret;
    }

    public long getNextSchemaIdAndIncrement() throws IOException {
        long schemaId;
        synchronized (maxSchemaIdDir) {
            schemaId = nextSchemaId;
            nextSchemaId++;
            fs.mkdirs(maxSchemaIdDir.cat(Long.toString(nextSchemaId)));
            TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.MASTER_PREPENSE_EXCEPTION_WHILE_GET_NEXT_SCHEMA_ID);
            fs.delete(maxSchemaIdDir.cat(Long.toString(schemaId)));
        }
        return schemaId;
    }

    public long getNextSchemaId() {
        synchronized (maxSchemaIdDir) {
            return nextSchemaId;
        }
    }

    public Map<Long, MasterTableMetricsEntry> getTableMetricsEntries() {
        Map<Long, MasterTableMetricsEntry> tableMetricsEntries = new TreeMap<Long, MasterTableMetricsEntry>();
        synchronized (lock) {
            Iterator<Map.Entry<Long, MasterTableMetricsEntry>> iter = this.tableMetricsEntries.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry<Long, MasterTableMetricsEntry> entry = iter.next();
                if (entry.getValue().isTableDeleted()) {
                    continue;
                }
                if (!tables.containsKey(entry.getKey())) {
                    entry.getValue().setTableDeleted(true);
                }
                MasterTableMetricsEntry tableMetricsEntry = new MasterTableMetricsEntry();
                entry.getValue().copyToAndClear(tableMetricsEntry);
                tableMetricsEntries.put(entry.getKey(), tableMetricsEntry);
            }
        }
        return tableMetricsEntries;
    }

    @Override
    public void close() {
        checkpointTask.cancel(true);
        compactTask.cancel(true);
        MiscUtils.safeClose(logger);
    }
}
