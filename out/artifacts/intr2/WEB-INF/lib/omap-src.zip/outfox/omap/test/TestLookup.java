package outfox.omap.test;

import java.util.Arrays;
import java.util.Date;
import java.util.Random;
import java.util.logging.Logger;

import junit.framework.TestCase;
import odis.io.FileSystem;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.LongWritable;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.conf.OmapConfig;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapLogFormatter;

public class TestLookup {
    static FileSystem nfs;

    int id;

    int count;

    int dataSize;

    WorkerThread workers[] = null;

    private static Logger LOG = OmapLogFormatter.getLogger(TestLookup.class.getName());

    private boolean stopOnNotFound = true;

    private boolean useCursor = false;

    public TestLookup(String[] args) throws Exception {
        for (int i = 0; i < args.length; i++)
            System.out.println(args[i]);

        id = Integer.parseInt(args[0]);
        count = Integer.parseInt(args[1]);

        workers = new WorkerThread[Integer.parseInt(args[2])];

        dataSize = Integer.parseInt(args[3]) - 8; //minus the size of the key
        if (args[4].equalsIgnoreCase("cursor")) {
            useCursor = true;
        }
        if (args[5].equalsIgnoreCase("false")) {
            stopOnNotFound = false;
        }
        this.exec();
    }

    public static void main(String[] args) throws Exception {
        new TestLookup(args);

    }

    public void exec() throws Exception {

        String tableName = "TestTable";
        long startTime = new Date().getTime();
        String[] colNames = new String[] {
            "key", "data"
        };
        String[] colTypes = new String[] {
            "LONG", "VINTBYTEARRAY"
        };
        MasterWatcherAndClientConfig mastetWatcher = new MasterWatcherAndClientConfig(
                new ClientConfig(OmapConfig.getConfiguration()));
        try {

            TableSpace tableSpace = new OmapTableSpace("test", mastetWatcher);
            Table testTable;
            if (tableSpace.findTable(tableName) != null) {
                LOG.info("find table");
                testTable = tableSpace.openTable(tableName);
            } else {
                LOG.info("Create table");
                testTable = tableSpace.createTable(tableName, colNames,
                        colTypes);
            }

            if (testTable == null) {
                System.out.println("testTable=null");
                return;
            }

            System.out.println("Lookup record...");
            // nfs=FileSystem.get();

            // initialize worker threads

            for (int i = 0; i < workers.length; i++) {
                workers[i] = new WorkerThread(testTable, (id << 8) + i, count
                        / workers.length);
            }

            // start worker threads
            for (int i = 0; i < workers.length; i++) {
                workers[i].start();
                LOG.info("thread " + i + " started");
            }
            long currentNum = 0;
            long lastNum = 0;
            // monitor worker threads
            while (true) {

                try {
                    Thread.sleep(5000);
                    boolean allEnd = true;
                    for (int i = 0; i < workers.length; i++)
                        if (workers[i].end == false) {
                            allEnd = false;
                            break;
                        }
                    if (allEnd)
                        break;
                    lastNum = currentNum;
                    currentNum = 0;
                    double periodResponseTime = 0.0;
                    for (int i = 0; i < workers.length; i++) {
                        System.out.println("Worker" + i + ":" + workers[i].num);
                        currentNum += workers[i].num;
                        periodResponseTime += workers[i].periodResponseTime;
                        workers[i].periodResponseTime = 0.0;
                    }
                    LOG.info("Total:" + currentNum);
                    LOG.info("Throughtput:" + (currentNum - lastNum));
                    LOG.info("periodResponseTime:" + periodResponseTime
                            / (double) (currentNum - lastNum));

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } finally {
            mastetWatcher.close();
            System.out.println("End");
            double totalResponseTime = 0.0;
            double maxResponseTime = 0.0;
            long totalNotFound = 0;
            for (int i = 0; i < workers.length; i++) {
                totalResponseTime += workers[i].totalResponseTime;
                totalNotFound += workers[i].notFound;
                if (workers[i].maxResponseTime > maxResponseTime)
                    maxResponseTime = workers[i].maxResponseTime;

            }
            long endTime = new Date().getTime();
            double totalTime = (double) (endTime - startTime) / 1000.0;
            LOG.info("Total time:" + totalTime);
            LOG.info("Throughtput:" + (double) count / totalTime);
            LOG.info("Average Response Time:" + totalResponseTime
                    / (double) count * 1000);
            LOG.info("Max Response Time:" + maxResponseTime);
            LOG.info("Not found:" + totalNotFound);
        }
        if (stopOnNotFound) {
            TestCase.assertFalse("All found", stopped);
        }
    }

    private boolean stopped = false;

    private void stop() {
        System.out.println("Stopping");
        stopped = true;
    }

    private class WorkerThread extends Thread {
        public int num = 0;

        public int notFound = 0;

        volatile boolean end = false;

        Random rand = new Random();

        int count;

        Table table;

        double totalResponseTime = 0.0;

        double maxResponseTime = 0.0;

        double periodResponseTime = 0.0;

        public WorkerThread(Table table, int seed, int count) {
            this.rand.setSeed(seed);
            this.count = count;
            this.table = table;
        }

        public void run() {
            ByteArrayWritable bytes = new ByteArrayWritable();
            LongWritable longWritable = new LongWritable();
            long key = rand.nextLong();
            Row row = null;
            try {
                row = table.newRow();
            } catch (OmapException e) {
                e.printStackTrace();
                return;
            }
            TableCursor cursor = null;
            long[] keys = null;
            if (useCursor) {
                try {
                    cursor = table.getTableCursor();
                } catch (Exception e) {
                    e.printStackTrace();
                    TestLookup.this.stop();
                }
                keys = new long[count];
                for (int i = 0; i < count; i++) {
                    keys[i] = key;
                    key = rand.nextLong();
                }
                Arrays.sort(keys);

            }
            long prevKey = key + 1;
            while (num < count && !stopped) {
                try {
                    Long start = new Date().getTime();
                    boolean found;
                    if (useCursor) {
                        key = keys[num];
                        if (key != prevKey) {
                            found = cursor.next(row);
                        } else {
                            found = true; // duplicate key, don't move the cursor
                        }
                        prevKey = key;
                    } else {
                        found = table.lookup(new LongWritable(key), row);
                    }
                    if (found) {
                        row.get("key", longWritable);
                        if (longWritable.get() != key) {
                            LOG.warning("Looked up key=" + key
                                    + ", but found key=" + longWritable.get()
                                    + ", i=" + num);
                            if (stopOnNotFound) {
                                TestLookup.this.stop();
                            }
                        }
                        row.get("data", bytes);
                        if (bytes.size() != dataSize) {
                            LOG.warning("Got data size=" + bytes.size()
                                    + ", but expected size=" + dataSize
                                    + ", i=" + num);
                            if (stopOnNotFound) {
                                TestLookup.this.stop();
                            }
                        }
                        byte expectedByte = (byte) (key & 0xFF);
                        if (bytes.getByte(0) != (byte) (key & 0xFF)) {
                            LOG.warning("Got first byte= " + bytes.getByte(0)
                                    + ", expected=" + expectedByte + ", i="
                                    + num);
                            if (stopOnNotFound) {
                                TestLookup.this.stop();
                            }
                        }
                    } else {
                        if (notFound == 0) {
                            LOG.warning("Key:" + key + " not found, i=" + num);
                        }
                        notFound++;
                        if (stopOnNotFound) {
                            TestLookup.this.stop();
                        }
                    }
                    Long end = new Date().getTime();

                    double time = (double) (end - start) / 1000.0;
                    if (time > this.maxResponseTime)
                        this.maxResponseTime = time;
                    this.totalResponseTime += time;
                    this.periodResponseTime += time;
                    num++;
                    if (!useCursor) {
                        key = rand.nextLong();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    TestLookup.this.stop();
                } catch (Error e) {
                    e.printStackTrace();
                    TestLookup.this.stop();
                }

            }

            end = true;
        }

    }

}
