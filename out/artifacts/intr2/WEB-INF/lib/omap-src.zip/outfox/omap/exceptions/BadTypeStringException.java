/**
 * @(#)BadTypeStringException, 2010-10-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author zhangduo
 */
public class BadTypeStringException extends OmapException {

    private static final long serialVersionUID = 9168323937192530096L;

    public BadTypeStringException() {
        super();
    }

    public BadTypeStringException(String msg) {
        super(msg);
    }

    public BadTypeStringException(String msg, Exception e) {
        super(msg, e);
    }
}
