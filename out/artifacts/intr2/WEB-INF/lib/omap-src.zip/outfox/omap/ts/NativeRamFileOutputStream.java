/**
 * @(#)NativeRamFileOutputStream.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.io.OutputStream;

import odis.io.nram.NativeRamFile;

/**
 *
 * @author wangfk
 *
 */
public class NativeRamFileOutputStream extends OutputStream {
    
    protected NativeRamFile buf;
    
    public NativeRamFileOutputStream(NativeRamFile file) throws IOException {
        this.buf = file;
        buf.seek(0);
    }
    
    @Override
    public void write(int b) throws IOException {
        byte[] tmp = new byte[1];
        tmp[0] = (byte) b;
        buf.write(tmp, 0, 1);
    }
    
    @Override
    public void close() {
    }
    
    @Override
    public void flush() {
    }
    
    public synchronized void setLength(long length) throws IOException {
        buf.setLength(length);
    }
    
    public synchronized void reset() throws IOException {
        buf.seek(0);
    }
    
    public synchronized long position() {
        return buf.getPosition();
    }

}
