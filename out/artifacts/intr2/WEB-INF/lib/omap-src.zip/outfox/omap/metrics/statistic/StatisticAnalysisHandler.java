/**
 * @(#)StatisticAnalysisHandler.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import odis.io.Path;
import outfox.omap.metrics.MasterMetricsEntry;
import outfox.omap.metrics.MasterTableMetricsEntry;
import outfox.omap.metrics.MetricsEntry;
import outfox.omap.metrics.TsMetricsEntry;
import outfox.omap.metrics.TsTabletMetricsEntry;
import outfox.omap.util.OmapUtils;
import toolbox.collections.Pair;

/**
 * @author zhangduo
 */
public class StatisticAnalysisHandler implements StatisticReaderHandler {

    private final MasterGlobalMetricsAnalyzer masterGlobalMetricsAnalyzer = new MasterGlobalMetricsAnalyzer();

    private final MasterTableMetricsAnalyzer masterTableMetricsAnalyzer = new MasterTableMetricsAnalyzer();

    private final TotalTsGlobalMetricsAnalyzer totalTsGlobalMetricsAnalyzer = new TotalTsGlobalMetricsAnalyzer();

    private final TsTabletMetricsAnalyzer totalTsTabletMetricsAnalyzer = new TsTabletMetricsAnalyzer();

    private final Map<String, Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer>> tsMetricsAnalyzers = new TreeMap<String, Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer>>();

    private final Map<Long, TableMetricsAnalyzer> tableMetricsAnalyzers = new TreeMap<Long, TableMetricsAnalyzer>();

    private TableMetricsAnalyzer getTableMetricsAnalyzer(long schemaId) {
        TableMetricsAnalyzer tableMetricsAnalyzer = tableMetricsAnalyzers.get(schemaId);
        if (tableMetricsAnalyzer == null) {
            tableMetricsAnalyzer = new TableMetricsAnalyzer();
            tableMetricsAnalyzers.put(schemaId, tableMetricsAnalyzer);
        }
        return tableMetricsAnalyzer;
    }

    private Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer> getTsMetricsAnalyzer(
            String tsName) {
        Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer> pair = tsMetricsAnalyzers.get(tsName);
        if (pair == null) {
            pair = new Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer>(
                    new TsGlobalMetricsAnalyzer(),
                    new TsTabletMetricsAnalyzer());
            tsMetricsAnalyzers.put(tsName, pair);
        }
        return pair;
    }

    @Override
    public void handle(long time, MetricsEntry metricsEntry) throws IOException {
        MasterMetricsEntry masterMetricsEntry = metricsEntry.getMasterMetricsEntry();
        masterGlobalMetricsAnalyzer.process(masterMetricsEntry.getGlobalMetricsEntry().getMetricsRecords());
        for (Map.Entry<Long, MasterTableMetricsEntry> entry: masterMetricsEntry.getTableMetricsEntries().entrySet()) {
            MasterTableMetricsEntry masterTableMetricsEntry = entry.getValue();
            masterTableMetricsAnalyzer.process(masterTableMetricsEntry.getMetricsRecords());
            TableMetricsAnalyzer tableMetricsAnalyzer = getTableMetricsAnalyzer(entry.getKey());
            tableMetricsAnalyzer.processMasterMetrics(masterTableMetricsEntry.getMetricsRecords());
        }

        for (TsMetricsEntry tsMetricsEntry: metricsEntry.getTsMetricsEntries()) {
            Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer> pair = getTsMetricsAnalyzer(tsMetricsEntry.getTsName());
            pair.getFirst().process(
                    tsMetricsEntry.getGlobalMetricsEntry().getMetricsRecords());
            totalTsGlobalMetricsAnalyzer.process(tsMetricsEntry.getGlobalMetricsEntry().getMetricsRecords());
            TsTabletMetricsAnalyzer tsTabletMetricsAnalyzer = pair.getSecond();
            for (Map.Entry<Long, TsTabletMetricsEntry> entry: tsMetricsEntry.getTabletMetricsEntries().entrySet()) {
                TsTabletMetricsEntry tsTabletMetricsEntry = entry.getValue();
                tsTabletMetricsAnalyzer.process(tsTabletMetricsEntry.getMetricsRecords());
                totalTsTabletMetricsAnalyzer.process(tsTabletMetricsEntry.getMetricsRecords());
                TableMetricsAnalyzer tableMetricsAnalyzer = getTableMetricsAnalyzer(OmapUtils.tid2sid(entry.getKey()));
                tableMetricsAnalyzer.processTsMetrics(tsTabletMetricsEntry.getMetricsRecords());
            }
        }
        totalTsGlobalMetricsAnalyzer.incCount();
    }

    @Override
    public void done(List<Path> processedFiles) {
        masterGlobalMetricsAnalyzer.done();
        masterTableMetricsAnalyzer.done();
        totalTsGlobalMetricsAnalyzer.done();
        totalTsTabletMetricsAnalyzer.done();
        for (Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer> pair: tsMetricsAnalyzers.values()) {
            pair.getFirst().done();
            pair.getSecond().done();
        }
        for (TableMetricsAnalyzer tableMetricsAnalyzer: tableMetricsAnalyzers.values()) {
            tableMetricsAnalyzer.done();
        }
    }

    @Override
    public void fail() {}

    public StatisticResult getStatisticResult() {
        Map<String, Pair<double[], double[]>> tsStatisticResults = new TreeMap<String, Pair<double[], double[]>>();
        for (Map.Entry<String, Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer>> entry: tsMetricsAnalyzers.entrySet()) {
            tsStatisticResults.put(entry.getKey(),
                    new Pair<double[], double[]>(
                            entry.getValue().getFirst().getStatisticResults(),
                            entry.getValue().getSecond().getStatisticResults()));
        }
        Map<Long, double[]> tableStatisticResults = new TreeMap<Long, double[]>();
        for (Map.Entry<Long, TableMetricsAnalyzer> entry: tableMetricsAnalyzers.entrySet()) {
            tableStatisticResults.put(entry.getKey(),
                    entry.getValue().getStatisticResults());
        }
        return new StatisticResult(new Pair<double[], double[]>(
                masterGlobalMetricsAnalyzer.getStatisitcResults(),
                masterTableMetricsAnalyzer.getStatisticResults()),
                new Pair<double[], double[]>(
                        totalTsGlobalMetricsAnalyzer.getStatisticResults(),
                        totalTsTabletMetricsAnalyzer.getStatisticResults()),
                tsStatisticResults, tableStatisticResults);
    }

    public MasterGlobalMetricsAnalyzer getMasterGlobalMetricsAnalyzer() {
        return masterGlobalMetricsAnalyzer;
    }

    public MasterTableMetricsAnalyzer getMasterTableMetricsAnalyzer() {
        return masterTableMetricsAnalyzer;
    }

    public Map<String, Pair<TsGlobalMetricsAnalyzer, TsTabletMetricsAnalyzer>> getTsMetricsAnalyzers() {
        return tsMetricsAnalyzers;
    }

    public Map<Long, TableMetricsAnalyzer> getTableMetricsAnalyzers() {
        return tableMetricsAnalyzers;
    }

}
