package outfox.omap.client.protocol;

import odis.serialize.IWritable;
import outfox.omap.exceptions.OmapException;

/**
 * A Table cursor iterators over a Table.
 * 
 * @author zhangkun
 */
public interface TableCursor {

    /**
     * Close this cursor
     * 
     * @throws OmapException
     */
    void close() throws OmapException;

    /**
     * Move to a specified key. You will need to call next() to get the row
     * after calling this method.
     * 
     * @param key
     * @param accurate
     * @return If key is found,then return true. If key is not found and
     *         accurate==true, return false. If key is not found and
     *         accurate==false, then move to the nearest row that has a bigger
     *         key and return true. If the given key is bigger than all the
     *         existing keys, return false. If the table is empty, return false.
     * @throws OmapException
     */
    boolean moveTo(IWritable key, boolean accurate) throws OmapException;

    /**
     * Return is this cursor has a next element.
     * 
     * @return if there is a next element, return true. Otherwise, return false.
     * @throws OmapException
     */
    @Deprecated
    boolean hasNext() throws OmapException;

    /**
     * Move the iterator forward, and copy the content of the current row to the
     * given row if the given row is not null.
     * 
     * @return if there is a next row, then return true. Otherwise, return
     *         false.
     * @throws OmapException
     */
    boolean next(Row row) throws OmapException;

    /**
     * Remove the current row of this cursor
     * 
     * @throws OmapException
     */
    void remove() throws OmapException;

    /**
     * Set the prefetch distance to improve the performance of {@link #next()}
     * call.
     * 
     * @param prefetchDistance
     * @throws OmapException
     */
    void setPrefetch(int prefetchDistance) throws OmapException;

    /**
     * Cursor will stop at the given endKey
     * 
     * @param endKey
     * @param include
     *            if the cursor should return endKey.
     */
    void setEndKey(IWritable endKeyExclusive);
    
    /**
     * Reset the cursor to the begin of the table
     */
    void reset();

}
