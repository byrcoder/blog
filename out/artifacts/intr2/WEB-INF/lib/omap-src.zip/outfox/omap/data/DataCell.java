/**
 * @(#)DataCell.java, 2006-3-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.data;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.BooleanWritable;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.BytesWritable;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.lib.VIntWritable;
import outfox.omap.exceptions.FieldNotInitializedException;
import outfox.omap.exceptions.NullDataException;
import outfox.omap.exceptions.UnInitializedDataCellException;
import outfox.omap.master.AssignTabletTask;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;

/**
 * <p>
 * A data cell, provides read and write methods to primitive types and Writable
 * interface. Use this wrapper instead of writable directly because we want to
 * handle NULL values in data cells.
 * </p>
 * <p>
 * A DataCell has a IWritable buffer that backs the cell.
 * </p>
 * <p>
 * A DataCell has 3 statuses:
 * <ul>
 * <li><b>NORMAL</b>: the cell is set to a valid value, buffer is not null</li>
 * <li><b>NULL</b>: the cell is set to NULL, buffer status unknown.</li>
 * <li><b>INVALID</b>: the buffer is not set, so that the type of this cell is
 * undecided. The cell is not set to NULL either.</li>
 * </ul>
 * </p>
 * 
 * @author xuw
 */
public class DataCell implements IWritable, IPreInitializedWritable {
    private static Logger LOG = LogFormatter.getLogger(DataCell.class.getName());

    /**
     * This DataCell is set to a value
     */
    public static final byte STATUS_NORMAL = 0;

    /**
     * This DataCell is set to NULL
     */
    public static final byte STATUS_NULL = 1;

    /**
     * The type of this DataCell is not determined, neither this cell is set to
     * NULL
     */
    public static final byte STATUS_INVALID = 2;

    /**
     * Lower 4 bits are used as status.
     */
    private byte flags;

    /**
     * Get the status of the DataCell.
     * 
     * @return
     */
    public byte getStatus() {
        return (byte) (flags & 0x0F);
    }

    protected void setStatus(byte status) {
        flags = (byte) ((flags & 0xF0) | (status & 0x0F));
    }

    /**
     * The buffer that backs the DataCell
     */
    protected IWritable buffer;

    /**
     * Client side type
     */
    protected String clientType;

    /**
     * Get the buffer that backs the DataCell.
     * 
     * @return
     * @see DataCell#isValid()
     */
    public IWritable getBuffer() {
        return buffer;
    }

    /**
     * Set the buffer that backs the DataCell. If the original status of the
     * cell is not {@link DataCell#STATUS_NULL}, will change its status
     * accordingly:
     * <ul>
     * <li>If buffer is not null, will gives the cell a value that comes along
     * with the buffer, and change status to {@link DataCell#STATUS_NORMAL}</li>
     * <li>If buffer is null, will change the status to
     * {@link DataCell#STATUS_INVALID}.</li>
     * </ul>
     * 
     * @param buffer
     */
    public void setBuffer(IWritable buffer) {
        this.buffer = buffer;
        if (getStatus() != STATUS_NULL) {
            if (buffer != null) {
                setStatus(STATUS_NORMAL);
            } else {
                setStatus(STATUS_INVALID);
            }
        }
    }

    /**
     * Construct a DataCell whose status is {@link DataCell#STATUS_INVALID}
     */
    public DataCell() {
        setStatus(STATUS_INVALID);
    }

    /**
     * Construct a DataCell whose status is
     * <ul>
     * <li>{@link DataCell#STATUS_INVALID}, if buffer is null</li>
     * <li>{@link DataCell#STATUS_NORMAL}, if buffer is not null</li>
     * </ul>
     * 
     * @param buffer
     *            the buffer that will back the DataCell
     */
    public DataCell(IWritable buffer) {
        this(buffer, STATUS_NORMAL);
    }

    public DataCell(IWritable buffer, byte initialStatus) {
        setStatus(initialStatus);
        setBuffer(buffer);
    }

    private void checkStatus() {
        if (getStatus() == STATUS_NULL) {
            throw new NullDataException();
        } else if (getStatus() == STATUS_INVALID) {
            throw new UnInitializedDataCellException();
        }
    }

    // readers for primitive types
    public int getInt() {
        this.checkStatus();
        return ((IntWritable) buffer).get();
    }

    public long getLong() {
        this.checkStatus();
        return ((LongWritable) buffer).get();
    }

    @Deprecated
    public String getString() {
        this.checkStatus();
        return ((UTF8Writable) buffer).get();
    }

    public String getText() {
        this.checkStatus();
        return ((StringWritable) buffer).get();
    }

    public boolean getBoolean() {
        this.checkStatus();
        return ((BooleanWritable) buffer).get();
    }

    public double getDouble() {
        this.checkStatus();
        return ((DoubleWritable) buffer).get();
    }

    public TableDesc getTableDesc() {
        this.checkStatus();
        return ((TableDesc) buffer);
    }

    public KeyPair getKeyPair() {
        return ((KeyPair) buffer);
    }

    public KeyRange getKeyRange() {
        return ((KeyRange) buffer);
    }

    public IWritable getIWritable() {
        if (getStatus() == STATUS_NORMAL) {
            return buffer;
        } else {
            return null;
        }
    }

    public boolean getCIWritable(IWritable value) throws IOException {
        if (getStatus() != STATUS_NORMAL) {
            return false;
        }
        if (this.clientType == null) {
            value.copyFields(buffer);
        } else {
            ByteArrayWritable baw = (ByteArrayWritable) buffer;
            ByteArrayInputStream bis = new ByteArrayInputStream(baw.data(), 0,
                    baw.size());
            CDataInputStream dis = new CDataInputStream(bis);
            try {
                value.readFields(dis);
            } finally {
                OmapUtils.safeClose(dis);
                OmapUtils.safeClose(bis);
            }
        }
        return true;
    }

    // //other get methods to be implemented

    public void setValue(double value) {
        if (buffer == null)
            buffer = new DoubleWritable();
        ((DoubleWritable) buffer).set(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(int value) {
        if (buffer == null)
            buffer = new IntWritable();
        if (buffer instanceof IntWritable) {
            ((IntWritable) buffer).set(value);
        } else {
            ((VIntWritable) buffer).set(value);
        }
        setStatus(STATUS_NORMAL);
    }

    public void setValue(long value) {
        if (buffer == null)
            buffer = new LongWritable();
        ((LongWritable) buffer).set(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(byte[] value) {
        if (buffer == null) {
            buffer = new BytesWritable();
        }
        ((BytesWritable) buffer).set(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(boolean value) {
        if (buffer == null)
            buffer = new BooleanWritable();
        ((BooleanWritable) buffer).set(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValueFixLen(byte[] value) {
        if (buffer == null)
            buffer = new FixedLengthBytesWritable();
        ((FixedLengthBytesWritable) buffer).set(value);
        setStatus(STATUS_NORMAL);
    }

    @Deprecated
    public void setValue(String value) {
        if (buffer == null)
            buffer = new UTF8Writable();
        if (buffer instanceof UTF8Writable) {
            ((UTF8Writable) buffer).set(value);
        } else {
            ((StringWritable) buffer).set(value);
        }
        setStatus(STATUS_NORMAL);
    }

    public void setValueText(String value) {
        if (buffer == null) {
            buffer = new StringWritable();
        }
        ((StringWritable) buffer).set(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(TableDesc value) {
        if (buffer == null)
            buffer = new TableDesc();
        ((TableDesc) this.buffer).copyFields(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(KeyRange value) {
        if (buffer == null)
            buffer = new KeyRange();
        ((KeyRange) this.buffer).copyFields(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(KeyPair value) {
        if (buffer == null)
            buffer = new KeyPair();
        ((KeyPair) this.buffer).copyFields(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(BytesWritable value) {
        if (buffer == null)
            buffer = new BytesWritable();
        ((BytesWritable) this.buffer).copyFields(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(VIntWritable value) {
        if (buffer == null)
            buffer = new VIntWritable();
        ((VIntWritable) this.buffer).copyFields(value);
        setStatus(STATUS_NORMAL);
    }

    public void setValue(AssignTabletTask value) {
        if (buffer == null)
            buffer = new AssignTabletTask();
        ((AssignTabletTask) this.buffer).copyFields(value);
        setStatus(STATUS_NORMAL);
    }

    /**
     * Copy the value of the given IWritable to the DataCell's buffer.<br>
     * XXX: this is unsafe
     */
    public void setIWritable(IWritable value) {
        // copy to buffer, instead of using obj. passed in
        try {
            if (this.buffer == null) {
                this.buffer = (IWritable) value.getClass().newInstance();
            }
            this.buffer.copyFields(value);
            setStatus(STATUS_NORMAL);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void setCIWritable(IWritable value) {
        if (this.clientType == null) {
            setIWritable(value);
        } else {
            ByteArrayOutputStream ostream = new ByteArrayOutputStream();
            CDataOutputStream dstream = new CDataOutputStream(ostream);
            try {
                value.writeFields(dstream);
                setIWritable(new ByteArrayWritable(ostream.toByteArray()));
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    dstream.close();
                    ostream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    // //other set methods to be implemented

    /**
     * Set the DataCell to NULL
     */
    public void setNull() {
        setStatus(STATUS_NULL);
    }

    /**
     * Set the DataCell to INVALID
     */
    public void setInvalid() {
        setStatus(STATUS_INVALID);
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            return this;
        }

        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }

        DataCell val = (DataCell) value;
        this.flags = val.flags;
        this.clientType = val.clientType;
        try {
            if (val.buffer != null) {
                if (this.buffer == null
                        || !buffer.getClass().equals(val.buffer.getClass())) {
                    // we do not have a type definition for this data cell
                    // first create a buffer accoring to the value's buffer
                    this.buffer = val.buffer.getClass().newInstance();
                }
                this.buffer.copyFields(val.buffer);
            } else {
                this.buffer = null;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        setStatus(in.readByte());
        if (getStatus() == STATUS_NORMAL) {
            String className = in.readUTF();
            if (buffer == null
                    || !buffer.getClass().getName().equals(className)) {
                try {
                    buffer = (IWritable) Class.forName(className).newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
            buffer.readFields(in);
        } else if (getStatus() >= 0x03) {
            throw new IllegalStateException("Found illegal status "
                    + Integer.toHexString(getStatus()));
        }
        this.clientType = in.readUTF();
        if (this.clientType.equals("NULL")) {
            this.clientType = null;
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(this.flags);
        if (getStatus() == STATUS_NORMAL) {
            out.writeUTF(buffer.getClass().getName());
            buffer.writeFields(out);
        }
        if (this.clientType == null) {
            out.writeUTF("NULL");
        } else {
            out.writeUTF(clientType);
        }
    }

    public String toString() {
        String ret;
        if (getStatus() == STATUS_NORMAL) {
            ret = buffer.toString();
        } else if (getStatus() == STATUS_INVALID) {
            ret = "INVALID";
        } else if (getStatus() == STATUS_NULL) {
            ret = "NULL";
        } else {
            ret = "unknown status: " + getStatus();
        }
        return ret;
    }

    @Override
    public int hashCode() {
        if (getStatus() != STATUS_NORMAL) {
            return getStatus();
        }
        if (buffer == null) {
            return 0;
        }
        return buffer.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        DataCell cell = (DataCell) obj;
        byte cellStatus = cell.getStatus();
        byte thisStatus = getStatus();
        if (cellStatus == STATUS_INVALID || thisStatus == STATUS_INVALID) {
            return true;
        }
        if (cellStatus == STATUS_NULL && thisStatus == STATUS_NULL) {
            return true;
        }
        if (thisStatus != cellStatus) {
            return false;
        }
        if (buffer == null) {
            return cell.buffer == null;
        }
        return buffer.equals(cell.buffer);
    }

    public void readPIFields(DataInput in) throws IOException {
        setStatus(in.readByte());
        if (getStatus() == STATUS_NORMAL) {
            if (buffer == null) {
                throw new FieldNotInitializedException(
                        "status is NORMAL, but buffer is null");
            }
            if (IPreInitializedWritable.class.isAssignableFrom(buffer.getClass())) {
                ((IPreInitializedWritable) buffer).readPIFields(in);
            } else {
                buffer.readFields(in);
            }
        } else if (getStatus() >= 0x03) {
            throw new IllegalStateException("Found illegal status "
                    + Integer.toHexString(getStatus()));
        }
    }

    public void writePIFields(DataOutput out) throws IOException {
        out.writeByte(this.flags);
        if (getStatus() == STATUS_NORMAL) {
            if (IPreInitializedWritable.class.isAssignableFrom(buffer.getClass())) {
                ((IPreInitializedWritable) buffer).writePIFields(out);
            } else {
                buffer.writeFields(out);
            }
        }
    }

    public static boolean isNull(byte[] data, int offset) {
        return data[offset] == STATUS_NULL;
    }

    public static boolean isInvalid(byte[] data, int offset) {
        return data[offset] == STATUS_INVALID;
    }

    public static boolean isNormal(byte[] data, int offset) {
        return data[offset] == STATUS_NORMAL;
    }
}
