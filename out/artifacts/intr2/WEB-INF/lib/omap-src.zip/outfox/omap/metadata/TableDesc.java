/**
 * @(#)TableDesc.java, 2010-8-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metadata;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import odis.rpc2.RPC;
import odis.serialize.IWritable;
import odis.serialize.lib.UTF8Writable;
import outfox.omap.client.protocol.IPermissionValidator;
import outfox.omap.client.protocol.PermissionType;
import outfox.omap.client.protocol.Table;
import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.BadSchemaDefinitionException;
import outfox.omap.util.PermissionValidator;
import toolbox.collections.ArrayQueue;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * <p>
 * A definition of a Table. The TableDesc consists of a KeyColumnDesc and an
 * array of ColumnDesc. The first column is called <b>key column</b>, which can
 * be used for look-ups.
 * </p>
 * <p>
 * A column can be accessed by either column name or index. The table has two
 * sets of column indexes:
 * <ul>
 * <li><b>normal index</b> is the natural index of the columns of the table's
 * own columns (i.e. not including the inherited columns of the subtables). The
 * index of the key column is 0, and other indexes are of non-key columns.
 * Normal index should <b>not</b> exceed 255, meaning that a table should not
 * have more than 255 columns, including the key column.</li>
 * <li><b>subtable index</b> is the index of inherited columns from subtables.
 * If table <b>A</b>'s index <code>i</code> column is a reference to a subtable
 * <b>B</b>, then <b>B</b>'s index <code>j</code> column will be referred by a
 * subtable index which equals <code>(i &lt;&lt; 8) | (j &amp; 0xFF)</code> in
 * table <b>A</b> (here you can see why normal index should not exceed 255)</li>
 * </ul>
 * <p>
 * <b>schemaID</b> is the unique identifier of the table version of the table
 * definition is encoded in the schemaID the upper 32-bit of schemaID is the ID
 * of the table (should be assigned by master), a function of tableName the
 * lower 32-bit is the version of the schema
 * </p>
 * <p>
 * There is a pool of DataRow in the TableDesc for reuse, use
 * {@link TableDesc#borrowDataRow()} and
 * {@link TableDesc#returnDataRow(DataRow)} to borrow and return a DataRow
 * object
 * </p>
 * 
 * @author zhangkun
 */
public class TableDesc implements IWritable {
    @SuppressWarnings("unused")
    private static Logger LOG = LogFormatter.getLogger(TableDesc.class.getName());

    private String tableName;

    /**
     * schemaID is the unique identifier of the table version of the table
     * definition is encoded in the schemaID the upper 32-bit of schemaID is the
     * ID of the table (should be assigned by master), a function of tableName
     * the lower 32-bit is the version of the schema
     */
    private long schemaId;

    /**
     * The ColumnDesc of the key field
     */
    private KeyColumnDesc key;

    /**
     * The ColumnDescs of all columns, excluding the key column
     */
    private ColumnDesc[] columns;

    private Boolean dataFileCacheEnabled = null;

    /**
     * Maps a column name to a column index
     */
    private HashMap<String, Integer> colnamemap = new LinkedHashMap<String, Integer>();

    private Map<String, String> properties = new HashMap<String, String>();

    /**
     * reuse data row instances
     */
    private ArrayQueue<WeakReference<DataRow>> dataRowPool;

    private Object dataRowPoolLock = new Object();

    /**
     * Construct an empty TableDesc, so that you can call readFields() later.
     */
    public TableDesc() {}

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setSchemaId(long schemaId) {
        this.schemaId = schemaId;
    }

    /**
     * Construct a TableDesc with the given column definition strings. The
     * numbers of column names must be equal to that of column types.
     * 
     * @param tableName
     * @param colName
     *            column names (including the key column, as the first one),
     *            separated by semicolons. e.g. "int1; int2; utf8; fixedbytes"
     * @param colType
     *            column type definitions (including the key column, as the
     *            first one), separated by semicoluns. e.g. "int;
     *            java.lang.Integer; java.lang.String; bytes:150"
     * @param schemaId
     * @see ColumnDesc#ColumnDesc(String, String) for type definitions
     */
    public TableDesc(String tableName, String colName, String colType,
            long schemaId) {
        this.tableName = tableName;
        this.schemaId = schemaId;
        initColumnDesc(colName, colType);
    }

    public TableDesc(String tableName, String colName, String colType,
            long schemaId, Map<String, String> properties) {
        this.tableName = tableName;
        this.schemaId = schemaId;
        this.properties = properties;
        clearPermissionValidator();
        initColumnDesc(colName, colType);
    }

    /**
     * Initialize the columns from the column definition strings. The first
     * column goes to KeyColumnDesc, while the rest of the columns are put in
     * the array <code>columns</code>.
     * 
     * @see TableDesc#TableDesc(String, String, String, long)
     */
    private void initColumnDesc(String col_names, String col_types) {

        StringTokenizer ntk = new StringTokenizer(col_names, ";");
        StringTokenizer ttk = new StringTokenizer(col_types, ";");

        int ncnt = ntk.countTokens();
        int tcnt = ttk.countTokens();
        if (ncnt != tcnt) {
            throw new BadSchemaDefinitionException("number of col. names "
                    + "must equal to number of types");
        }

        this.columns = new ColumnDesc[ncnt - 1]; // -1 because first column
        // is the key
        try {
            int i = 0;
            while (ntk.hasMoreElements()) {
                String col_name = ntk.nextToken().trim();
                String col_type = ttk.nextToken().trim();
                if (i != 0) { // not key
                    ColumnDesc currentColumn = new ColumnDesc(col_name,
                            col_type);
                    this.columns[i - 1] = currentColumn;
                    this.colnamemap.put(col_name, i);
                } else { // i=0 is the key column
                    this.key = new KeyColumnDesc(col_name, col_type);
                    this.colnamemap.put(col_name, 0);
                }
                i += 1;
            }
        } catch (Exception e) {
            throw new BadSchemaDefinitionException(
                    "buffer initialization failed", e);
        }
    }

    /**
     * Create an empty DataRow (object - no sharing) with type specified in
     * columns
     * 
     * @return
     */
    public DataRow createDataRow() {
        KeyCell key = this.createKeyCell();
        DataCell[] cells = new DataCell[this.columns.length];
        for (int i = 0; i < this.columns.length; i++) {
            cells[i] = this.columns[i].createDataCell();
        }
        return new DataRow(key, (DataCell[]) cells);
    }

    /**
     * Borrow a buffered DataRow object. It can be returned later for reuse.
     * 
     * @see TableDesc#returnDataRow(DataRow)
     * @return
     */
    public DataRow borrowDataRow() {
        synchronized (dataRowPoolLock) {
            if (dataRowPool == null) {
                return createDataRow();
            }
            WeakReference<DataRow> wr;
            while ((wr = dataRowPool.poll()) != null) {
                DataRow dr = wr.get();
                if (dr != null) {
                    return dr;
                }
            }
            return createDataRow();
        }
    }

    /**
     * Return a DataRow object to the TableDesc for reuse.
     * 
     * @see TableDesc#borrowDataRow()
     * @param row
     */
    public void returnDataRow(DataRow row) {
        if (row == null) {
            return;
        }
        synchronized (dataRowPoolLock) {
            if (dataRowPool == null) {
                dataRowPool = new ArrayQueue<WeakReference<DataRow>>(200);
            }
            dataRowPool.offer(new WeakReference<DataRow>(row));
        }
    }

    public KeyCell createKeyCell() {
        return (KeyCell) this.key.createDataCell();
    }

    public int getColumnIndex(String colname) {
        if (this.colnamemap.containsKey(colname)) {
            return this.colnamemap.get(colname);
        } else {
            return -1;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("[TableDesc name=");
        sb.append(this.tableName).append(" cols={");
        sb.append(this.key).append("(key)");
        for (int i = 0; i < this.columns.length; i++) {
            sb.append(',').append(this.columns[i]);
        }
        sb.append('}');
        sb.append(" properties={");
        if (properties.size() > 0) {
            Iterator<Map.Entry<String, String>> iter = properties.entrySet().iterator();
            Map.Entry<String, String> entry = iter.next();
            sb.append(entry.getKey()).append("->").append(entry.getValue());
            while (iter.hasNext()) {
                entry = iter.next();
                sb.append(',').append(entry.getKey()).append("->").append(
                        entry.getValue());
            }
        }
        sb.append('}');
        sb.append(" schemaId=").append(HexString.longToPaddedHex(this.schemaId)).append(
                "]");
        return sb.toString();
    }

    public String getKeyTypeString() {
        return key.getTypeString();
    }

    public ColumnDesc getColumn(int index) {
        if (index == 0) {
            return key;
        }
        return this.columns[index - 1];
    }

    public IWritable copyFields(IWritable value) {
        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }
        TableDesc val = (TableDesc) value;
        this.tableName = val.tableName; // tableName is a immutable string, no
        // need to copy
        this.schemaId = val.schemaId;
        this.key = new KeyColumnDesc();
        if (val.key != null)
            this.key.copyFields(val.key);
        if (val.columns != null) {
            this.columns = new ColumnDesc[val.columns.length];

            for (int i = 0; i < val.columns.length; i++) {
                this.columns[i] = new ColumnDesc();
                this.columns[i].copyFields(val.columns[i]);
            }
        }
        if (val.colnamemap != null) {
            this.colnamemap = new LinkedHashMap<String, Integer>(val.colnamemap);
        }

        if (val.properties != null) {
            this.properties = new HashMap<String, String>(val.properties);
        }
        clearPermissionValidator();
        return this;

    }

    public void readFields(DataInput in) throws IOException {
        this.tableName = in.readUTF();
        this.schemaId = in.readLong();
        this.key = new KeyColumnDesc();
        this.key.readFields(in);
        int sz = in.readInt();
        this.columns = new ColumnDesc[sz];
        for (int i = 0; i < sz; i++) {
            this.columns[i] = new ColumnDesc();
            this.columns[i].readFields(in);
        }
        sz = in.readInt();
        this.colnamemap = new LinkedHashMap<String, Integer>(sz);
        for (int i = 0; i < sz; i++) {
            String colname = in.readUTF();
            colnamemap.put(colname, in.readInt());
        }
        sz = in.readInt();
        properties = new HashMap<String, String>(sz);
        for (int i = 0; i < sz; i++) {
            String property = UTF8Writable.readString(in);
            properties.put(property, UTF8Writable.readString(in));
        }
        clearPermissionValidator();
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(this.tableName);
        out.writeLong(this.schemaId);
        this.key.writeFields(out);
        out.writeInt(this.columns.length); // length of columns array
        for (int i = 0; i < columns.length; i++) {
            this.columns[i].writeFields(out);
        }
        out.writeInt(this.colnamemap.size());
        for (Map.Entry<String, Integer> entry: colnamemap.entrySet()) {
            out.writeUTF(entry.getKey());
            out.writeInt(entry.getValue());
        }
        out.writeInt(properties.size());
        for (Map.Entry<String, String> entry: properties.entrySet()) {
            UTF8Writable.writeString(out, entry.getKey());
            UTF8Writable.writeString(out, entry.getValue());
        }
    }

    /**
     * @return a single array containing both key (at position 0) and values
     */
    public ColumnDesc[] getColumns() {
        ColumnDesc[] ret = new ColumnDesc[this.columns.length + 1];
        ret[0] = key;
        for (int i = 1; i < ret.length; i++) {
            ret[i] = this.columns[i - 1];
        }
        return ret;
    }

    public String getTableName() {
        return tableName;
    }

    public KeyColumnDesc getKey() {
        return this.key;
    }

    public long getSchemaId() {
        return this.schemaId;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public String getProperty(String propertyName, String defaultProperty) {
        String prop = properties.get(propertyName);
        if (prop != null) {
            return prop;
        } else {
            return defaultProperty;
        }
    }

    public void printAllColumnNames() {
        Iterator<String> iter = this.colnamemap.keySet().iterator();
        Iterator<Integer> iterv = this.colnamemap.values().iterator();
        while (iter.hasNext()) {
            String e = iter.next();
            int val = iterv.next();
            System.out.println(e + " : " + val);
        }
    }

    private IPermissionValidator permissionValidator;

    private Object permissionValidatorLock = new Object();

    /**
     * Create an IPermissionValidator, for ACL
     * 
     * @return
     */
    private IPermissionValidator getPermissionValidator() {
        synchronized (permissionValidatorLock) {
            if (permissionValidator == null) {
                permissionValidator = PermissionValidator.createValidator(
                        properties.get(Table.Property.ACL_OWNER_NAME),
                        getProperty(Table.Property.ACL_GROUP_NAME, ""),
                        properties.get(Table.Property.ACL_PERMISSION_NAME));
            }
            return permissionValidator;
        }
    }

    private void clearPermissionValidator() {
        synchronized (permissionValidatorLock) {
            permissionValidator = null;
        }
    }

    public void validatePermission(PermissionType type) {
        if (RPC.getClientInfo() != null) {
            getPermissionValidator().validatePermission(
                    RPC.getClientInfo().username, type);
        }
    }

    public boolean getBlockCacheEnabled() {
        return Boolean.parseBoolean(getProperty(
                Table.Property.USE_BLOCK_CACHE_NAME,
                Table.Property.DEFAULT_USE_BLOCK_CACHE));
    }

    public boolean getDataFileCacheEnabled() {
        if (dataFileCacheEnabled == null) {
            dataFileCacheEnabled = Boolean.parseBoolean(getProperty(
                    Table.Property.ENABLE_MEMORY_CACHE_NAME,
                    Table.Property.DEFAUL_ENABLE_MEMORY_CACHE));
        }
        return dataFileCacheEnabled;
    }
}
