package outfox.omap.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

import org.apache.commons.lang.NotImplementedException;

import outfox.omap.exceptions.FieldNotInitializedException;
import outfox.omap.util.GenericWritableComparator;

/**
 * A tuple key that consists of two keys.
 * 
 * @author zhangkun
 */
public class KeyPair implements IWritableComparable, IPreInitializedWritable {
    /**
     * Only used in KeyPair and its subclasses. KeyPair can handle it in
     * readFields() and writeFields().
     * 
     * @author zhangkun
     */
    public static class MaxWritable implements IWritableComparable {

        private MaxWritable() {}

        public void readFields(DataInput in) throws IOException {
            throw new NotImplementedException("should never be called");
        }

        public void writeFields(DataOutput out) throws IOException {
            throw new NotImplementedException("should never be called");
        }

        public IWritable copyFields(IWritable value) {
            return this;
        }

        public int compareTo(IWritable o) {
            if (o == null || !(o instanceof MaxWritable)) {
                return 1;
            }
            return 0;
        }

        public String toString() {
            return "MAX";
        }

        public boolean equals(Object o) {
            if (o instanceof MaxWritable) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            return Integer.MAX_VALUE;
        }
    }

    public static final MaxWritable MAX_WRITABLE = new MaxWritable();

    /**
     * Do not use this field directly for getting key1. Use {@link #getKey1()}
     * instead.
     */
    protected IWritableComparable k1;

    /**
     * Do not use this field directly for getting key2. Use {@link #getKey2()}
     * instead.
     */
    protected IWritableComparable k2;

    public KeyPair() {
        setKey1(null);
        setKey2(null);
    }

    /**
     * Copy the values of k1 and k2 to myself
     * 
     * @param k1
     * @param k2
     */
    public KeyPair(IWritableComparable k1, IWritableComparable k2) {
        setKey1(k1);
        setKey2(k2);
    }

    /**
     * Copy the value of the given KeyPair to myself
     * 
     * @param value
     */
    public void setValue(KeyPair value) {
        setKey1(value.getKey1());
        setKey2(value.getKey2());
    }

    /**
     * Copy the value of the given key to key1
     * 
     * @param k1
     */
    public void setKey1(IWritableComparable k1) {
        try {
            if (k1 == null) {
                flag = (FLAG_KEY1_NULL & 0x0F) | (flag & 0xF0);
            } else if (k1 instanceof MaxWritable) {
                flag = (FLAG_KEY1_MAX & 0x0F) | (flag & 0xF0);
            } else {
                flag = flag & 0xF0;
                if (this.k1 == null
                        || !this.k1.getClass().equals(k1.getClass())) {
                    this.k1 = k1.getClass().newInstance();
                }
                this.k1.copyFields(k1);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Copy the value of the given key to key2
     * 
     * @param k2
     */
    public void setKey2(IWritableComparable k2) {
        try {
            if (k2 == null) {
                flag = (FLAG_KEY2_NULL & 0xF0) | (flag & 0x0F);
            } else if (k2 instanceof MaxWritable) {
                flag = (FLAG_KEY2_MAX & 0xF0) | (flag & 0x0F);
            } else {
                flag = flag & 0x0F;
                if (this.k2 == null
                        || !this.k2.getClass().equals(k2.getClass())) {
                    this.k2 = k2.getClass().newInstance();
                }
                this.k2.copyFields(k2);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public IWritableComparable getKey1() {
        switch (flag & 0x0F) {
            case FLAG_KEY1_NULL:
                return null;
            case FLAG_KEY1_MAX:
                return MAX_WRITABLE;
            default:
                return k1;
        }
    }

    public IWritableComparable getKey2() {
        switch (flag & 0xF0) {
            case FLAG_KEY2_NULL:
                return null;
            case FLAG_KEY2_MAX:
                return MAX_WRITABLE;
            default:
                return k2;
        }
    }

    private static final int FLAG_KEY1_NULL = 1;

    private static final int FLAG_KEY1_MAX = 2;

    private static final int FLAG_KEY2_NULL = 1 << 4;

    private static final int FLAG_KEY2_MAX = 2 << 4;

    private static final int FLAG_MASK = 0x33;

    /**
     * Only the lowest byte is used, whose lower 4 bits are for key1, higher 4
     * bits are for key2.
     */
    protected int flag = 0;

    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(flag);
        if ((flag & 0x0F) == 0) {
            out.writeUTF(k1.getClass().getName());
            k1.writeFields(out);
        }
        if ((flag & 0xF0) == 0) {
            out.writeUTF(k2.getClass().getName());
            k2.writeFields(out);
        }
    }

    public void readFields(DataInput in) throws IOException {
        try {
            flag = in.readByte() & FLAG_MASK;
            if ((flag & 0x0F) == 0) {
                String className = in.readUTF();
                if (k1 == null || !k1.getClass().getName().equals(className)) {
                    k1 = (IWritableComparable) Class.forName(className).newInstance();
                }
                k1.readFields(in);
            } else if ((flag & 0x0F) >= 0x03) {
                throw new IllegalStateException("Found illegal flag "
                        + Integer.toHexString(flag & 0xFF));
            }
            if ((flag & 0xF0) == 0) {
                String className = in.readUTF();
                if (k2 == null || !k2.getClass().getName().equals(className)) {
                    k2 = (IWritableComparable) Class.forName(className).newInstance();
                }
                k2.readFields(in);
            } else if ((flag & 0xF0) >= 0x30) {
                throw new IllegalStateException("Found illegal flag "
                        + Integer.toHexString(flag & 0xFF));
            }
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public IWritable copyFields(IWritable value) {
        if (this == value) {
            return this;
        }
        if (!(value instanceof KeyPair)) {
            throw new RuntimeException("Cannot copy from a non-KeyPair object");
        }
        KeyPair v = (KeyPair) value;
        setValue(v);
        return this;
    }

    public int compareTo(IWritable o) {
        GenericWritableComparator comp = GenericWritableComparator.instance;
        if (o instanceof KeyPair) { // dictionary order
            KeyPair v = (KeyPair) o;
            int c1 = comp.compare(this.getKey1(), v.getKey1());
            if (c1 != 0)
                return c1;
            else {
                return comp.compare(this.getKey2(), v.getKey2());
            }
        }
        // if o is a key, just use k1
        return comp.compare(this.getKey1(), (IWritableComparable) o);
    }

    private static boolean keyEquals(IWritableComparable key1,
            IWritableComparable key2) {
        if (key1 == null) {
            if (key2 == null) {
                return true;
            } else {
                return false;
            }
        } else {
            if (key2 == null) {
                return false;
            } else {
                return key1.equals(key2);
            }
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!o.getClass().equals(getClass())) {
            return false;
        }
        IWritableComparable thisKey = getKey1();
        IWritableComparable thatKey = ((KeyPair) o).getKey1();
        if (!keyEquals(thisKey, thatKey)) {
            return false;
        }
        thisKey = getKey2();
        thatKey = ((KeyPair) o).getKey2();
        if (!keyEquals(thisKey, thatKey)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "{" + this.getKey1() + "," + this.getKey2() + "}";
    }

    public void readPIFields(DataInput in) throws IOException {
        flag = in.readByte() & FLAG_MASK;
        if ((flag & 0x0F) == 0) {
            if (k1 == null) {
                throw new FieldNotInitializedException("k1 is null");
            }
            if (IPreInitializedWritable.class.isAssignableFrom(k1.getClass())) {
                ((IPreInitializedWritable) k1).readPIFields(in);
            } else {
                k1.readFields(in);
            }
        } else if ((flag & 0x0F) >= 0x03) {
            throw new IllegalStateException("Found illegal flag "
                    + Integer.toHexString(flag & 0xFF));
        }
        if ((flag & 0xF0) == 0) {
            if (k2 == null) {
                throw new FieldNotInitializedException("k2 is null");
            }
            if (IPreInitializedWritable.class.isAssignableFrom(k2.getClass())) {
                ((IPreInitializedWritable) k2).readPIFields(in);
            } else {
                k2.readFields(in);
            }
        } else if ((flag & 0xF0) >= 0x30) {
            throw new IllegalStateException("Found illegal flag "
                    + Integer.toHexString(flag & 0xFF));
        }
    }

    public void writePIFields(DataOutput out) throws IOException {
        out.writeByte(flag);
        if ((flag & 0x0F) == 0) {
            if (IPreInitializedWritable.class.isAssignableFrom(k1.getClass())) {
                ((IPreInitializedWritable) k1).writePIFields(out);
            } else {
                k1.writeFields(out);
            }
        }
        if ((flag & 0xF0) == 0) {
            if (k2 == null) {
                throw new RuntimeException(
                        "flag for key2 is 0, but k2 is null; flag=" + flag);
            }
            if (IPreInitializedWritable.class.isAssignableFrom(k2.getClass())) {
                ((IPreInitializedWritable) k2).writePIFields(out);
            } else {
                k2.writeFields(out);
            }
        }
    }

    @Override
    public int hashCode() {
        int code = 0;
        IWritable k = getKey1();
        if (k != null) {
            code = k.hashCode();
        }
        k = getKey2();
        if (k != null) {
            code ^= k.hashCode();
        }
        return code;
    }

    public int test() {
        return super.hashCode();
    }

}
