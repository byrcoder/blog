package outfox.omap.test;

import java.util.Date;
import java.util.Random;
import java.util.logging.Logger;

import junit.framework.TestCase;
import odis.io.FileSystem;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.LongWritable;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryCondition;
import outfox.omap.util.OmapLogFormatter;

public class TestInsert {
    static FileSystem nfs;

    private String tableName;

    private int id;

    private int count;

    private int dataSize;

    private int rowsPerInsert = 1;

    private WorkerThread workers[] = null;

    private boolean deleteOldTable = false;

    private boolean testIndex = false;

    private String compressType;

    private static Logger LOG = OmapLogFormatter.getLogger(TestInsert.class.getName());

    public TestInsert(String[] args) throws Exception {
        if (args.length < 4) {
            System.err.println("Usage: TestInsert <id> <count> <num_workers> <data_size> [rows_per_insert] [deleteOldTable?true:false] [testIndex?true:false] [TableName] [CompressType]");
            return;
        }
        for (int i = 0; i < args.length; i++)
            System.out.println(args[i]);

        int i = 0;
        id = Integer.parseInt(args[i++]);
        count = Integer.parseInt(args[i++]);

        workers = new WorkerThread[Integer.parseInt(args[i++])];

        dataSize = Integer.parseInt(args[i++]);

        if (args.length > i) {
            rowsPerInsert = Integer.parseInt(args[i++]);
        }
        if (args.length > i && args[i++].equalsIgnoreCase("true")) {
            deleteOldTable = true;
        }
        if (args.length > i && args[i++].equalsIgnoreCase("true")) {
            testIndex = true;
        }

        if (args.length > i) {
            tableName = args[i++];
        } else {
            tableName = "TestTable";
        }
        if (args.length > i) {
            compressType = args[i++];
        } else {
            compressType = Table.Property.DEFAULT_COMPRESS;
        }
    }

    public static void main(String[] args) throws Exception {
        TestInsert t = new TestInsert(args);
        t.exec(new ClientConfig("omap.xml"));
    }

    private volatile boolean stopped = false;

    private void stop() {
        stopped = true;
    }

    private Query[] getQueries() {
        OmapQueryCondition qc = new OmapQueryCondition("data",
                QueryOperation.EQUAL);
        Query q = new OmapQuery("eq", new OmapQueryCondition[] {
            qc
        });
        return new Query[] {
            q
        };
    }

    public void exec(ClientConfig clientConfig) throws Exception {
        System.out.println("TestInsert");
        String[] colNames = new String[] {
            "key", "data"
        };
        String[] colTypes = new String[] {
            "LONG", "VINTBYTEARRAY"
        };
        Table testTable = null;
        MasterWatcherAndClientConfig masterWatcher = new MasterWatcherAndClientConfig(
                clientConfig);
        TableSpace tableSpace = new OmapTableSpace("test", masterWatcher);
        if (tableSpace.findTable(tableName) != null) {
            LOG.info("find table");
            if (deleteOldTable) {
                LOG.info("Delete old table");
                tableSpace.deleteTable(tableName);
            } else {
                testTable = tableSpace.openTable(tableName);
                if (testIndex && testTable.getQueryCount() == 0) {
                    throw new RuntimeException("no index exists");
                }
            }
        }
        if (testTable == null) {
            LOG.info("Create table");
            if (testIndex) {
                testTable = tableSpace.createTable(tableName, colNames,
                        colTypes, getQueries());
            } else {
                testTable = tableSpace.createTable(tableName, colNames,
                        colTypes);
            }
            Thread.sleep(10000);
        }

        if (testTable == null) {
            System.out.println("testTable=null");
            return;
        }
        testTable.setProperty(Table.Property.COMPRESS_NAME, compressType);

        long startTime = new Date().getTime();
        System.out.println("Insert record...");
        // nfs=FileSystem.get();

        // initialize worker threads

        for (int i = 0; i < workers.length; i++) {
            workers[i] = new WorkerThread(testTable, (id << 8) + i, count
                    / workers.length);
        }

        // start worker threads
        for (int i = 0; i < workers.length; i++) {
            workers[i].start();
            LOG.info("thread " + i + " started");
        }
        long currentNum = 0;
        long lastNum = 0;
        int zeroTimes = 0;
        // monitor worker threads
        while (true) {
            try {
                Thread.sleep(5000);
                boolean allEnd = true;
                for (int i = 0; i < workers.length; i++)
                    if (workers[i].end == false) {
                        allEnd = false;
                        break;
                    }
                if (allEnd)
                    break;
                lastNum = currentNum;
                currentNum = 0;
                double periodResponseTime = 0.0;
                for (int i = 0; i < workers.length; i++) {
                    System.out.println("Worker" + i + ":" + workers[i].num);
                    currentNum += workers[i].num;
                    periodResponseTime += workers[i].periodResponseTime;
                    workers[i].periodResponseTime = 0.0;
                }
                LOG.info("Total:" + currentNum);
                LOG.info("periodThroughput:" + (currentNum - lastNum));
                LOG.info("periodResponseTime:" + periodResponseTime
                        / (double) (currentNum - lastNum));
                if (currentNum - lastNum == 0) {
                    zeroTimes++;
                    if (zeroTimes >= 20) {
                        LOG.info("Long time zero");
                    }
                } else
                    zeroTimes = 0;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        masterWatcher.close();
        System.out.println("End");
        double totalResponseTime = 0.0;
        double totalResponseTime2 = 0.0;
        double maxResponseTime = 0.0;
        for (int i = 0; i < workers.length; i++) {
            totalResponseTime += workers[i].totalResponseTime;
            totalResponseTime2 += workers[i].totalResponseTime2;
            if (workers[i].maxResponseTime > maxResponseTime)
                maxResponseTime = workers[i].maxResponseTime;

        }
        long endTime = new Date().getTime();
        double totalTime = (double) (endTime - startTime) / 1000.0;
        LOG.info("Total time:" + totalTime);
        LOG.info("Average Throughput:" + (double) count / totalTime);
        LOG.info("Average Response Time:" + totalResponseTime / (double) count
                * 1000);
        LOG.info("Max Response Time:" + maxResponseTime);
        LOG.info("Theta="
                + Math.sqrt(totalResponseTime2 - totalResponseTime
                        * totalResponseTime / (double) count));
        TestCase.assertFalse("No failure", stopped);

    }

    private class WorkerThread extends Thread {
        public long num = 0;

        @SuppressWarnings("unused")
        public long dead = 0;

        volatile boolean end = false;

        Random rand = new Random();

        Random dataRand = new Random();

        @SuppressWarnings("unused")
        long currentKey;

        int count;

        Table table;

        double totalResponseTime = 0.0;

        double totalResponseTime2 = 0.0;

        double maxResponseTime = 0.0;

        double periodResponseTime = 0.0;

        public WorkerThread(Table table, int seed, int count) {
            this.rand.setSeed(seed);
            this.count = count;
            this.table = table;
        }

        public void run() {
            Row[] rows = new Row[rowsPerInsert];
            long key = rand.nextLong();
            // LOG.info(dataStr);
            while (num < count && !stopped) {
                try {
                    for (int i = 0; i < rowsPerInsert; i++) {
                        Row row = table.newRow();
                        byte data[] = new byte[dataSize - 8]; // minus the size of the key
                        data[0] = (byte) (key & 0xFF);
                        data[1] = (byte) (dataRand.nextInt() & 0xFF);
                        row.set(0, new LongWritable(key));
                        row.set(1, new ByteArrayWritable(data));
                        key = rand.nextLong();
                        rows[i] = row;
                    }
                    Long start = new Date().getTime();
                    currentKey = key;
                    table.update(rows);
                    Long end = new Date().getTime();
                    double time = (double) (end - start) / 1000.0;
                    if (time > this.maxResponseTime)
                        this.maxResponseTime = time;
                    this.totalResponseTime += time;
                    this.totalResponseTime2 += (time * time);
                    this.periodResponseTime += time;
                    num += rowsPerInsert;
                } catch (Exception e) {
                    e.printStackTrace();
                    TestInsert.this.stop();
                } catch (Error e) {
                    e.printStackTrace();
                    TestInsert.this.stop();
                }

            }

            end = true;
        }

    }

}
