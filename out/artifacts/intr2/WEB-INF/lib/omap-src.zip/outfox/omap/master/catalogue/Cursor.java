/**
 * @(#)Cursor.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.Closeable;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

/**
 * @author zhangduo
 */
public interface Cursor<K extends IWritableComparable, V extends IWritable>
        extends Closeable {

    boolean next(K key, V value) throws IOException;
}
