package outfox.omap.ts.insertlog;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.IFileSystem;
import odis.io.Path;
import outfox.omap.util.ThroughputController;
import outfox.omap.walog.WALogFile;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * Read the log and write logs for different Tablets to separate log files.<br/>
 * LOG file will be <code>outputDir/${HEXTabletId}/wal_${Long.MAX_VALUE}</code><br/>
 * After {@link #done}, the file will be changed to
 * <code>outputDir/${TabletId}/wal_${LastLSN}</code><br/>
 * 
 * @author wangfk, zhangkun
 */
public class InsertLoggerSplitHandler extends ReservableInsertLogReaderHandler {
    private static Logger LOG = LogFormatter.getLogger(InsertLoggerSplitHandler.class);

    private final Map<Long, WALogFile.Writer> output;

    private final Set<Long> tablets;

    private final LongLongHashMap lastLSNMap;

    private final LongLongHashMap lastTimeStampMap;

    private final Path outputDir;

    private final IFileSystem fs;

    private int writeCount = 0;

    private final ThroughputController throughputController;

    /**
     * Constructor
     * 
     * @param fs
     *            the output fs
     * @param outputDir
     *            the output dir
     * @param tablets
     *            tabletIds whose logs need to be output
     * @param speedLimit
     *            speed limit for output throughput, bytes per second. If
     *            speedLimit==0, means no limit
     * @throws IOException
     */
    public InsertLoggerSplitHandler(IFileSystem fs, Path outputDir,
            Set<Long> tablets, long speedLimit, LongLongHashMap checkpoints)
            throws IOException {
        super(checkpoints);
        this.outputDir = outputDir;
        this.fs = fs;
        this.tablets = new HashSet<Long>();
        this.tablets.addAll(tablets);

        this.output = new HashMap<Long, WALogFile.Writer>();
        this.lastLSNMap = new LongLongHashMap();
        this.lastTimeStampMap = new LongLongHashMap();

        if (speedLimit == 0) {
            this.throughputController = null;
        } else {
            this.throughputController = new ThroughputController(speedLimit);
        }
    }

    public void done() throws IOException {
        closeOutput(false);
        LOG.info("Finished splitting log, write=" + writeCount);
    }

    private void closeOutput(boolean failure) throws IOException {
        boolean ok = true;
        for (Entry<Long, WALogFile.Writer> entry: output.entrySet()) {
            try {
                entry.getValue().close();
                Path tmpPath = getLogFilePath(entry.getKey(), Long.MAX_VALUE);
                if (failure || lastLSNMap.get(entry.getKey(), -1) == -1) {
                    //failure or there is no log entry, delete the log file
                    if (fs.exists(tmpPath)) {
                        fs.delete(tmpPath);
                    }
                } else {
                    long tabletId = entry.getKey();
                    long lastLSN = lastLSNMap.get(tabletId, -1);
                    long lastTimeStamp = lastTimeStampMap.get(tabletId, -1);

                    if (tablets.contains(tabletId)) {
                        Path path = getLogFilePath(tabletId, lastLSN);
                        if (fs.exists(path)) {
                            fs.delete(path);
                        }
                        fs.link(tmpPath, path);
                        LOG.info("Splitted log files is created: " + path);
                    }

                    if(needReserveLog(tabletId)) {
                        Path logReserveFilePath = getLogReserveFilePath(
                                tabletId, lastLSN, lastTimeStamp);
                        if(!fs.exists(logReserveFilePath.getParentFile())) {
                            fs.mkdirs(logReserveFilePath.getParentFile());
                        }
                        fs.link(tmpPath, logReserveFilePath);
                        LOG.info("Reserve log file for backup, from: " + tmpPath
                                + ", to: " + logReserveFilePath);
                    }
                    fs.delete(tmpPath);
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Failed to close " + entry.getValue(), e);
                ok = false;
            }
        }

        if (!ok) {
            throw new IOException("Failed to close some output files");
        }
    }

    public void fail() throws IOException {
        closeOutput(true);
    }

    private Path getLogFilePath(long tabletId, long LSN) {
        Path dir = new Path(outputDir, HexString.longToPaddedHex(tabletId));
        return new Path(dir, WALogFile.FILE_PREFIX + Long.toString(LSN));
    }

    private void handle(long tabletId) throws IOException {
        WALogFile.Writer writer = output.get(tabletId);
        if (writer == null) {
            if (tablets.contains(tabletId) || needReserveLog(tabletId)) {
                Path dir = new Path(outputDir, HexString.longToPaddedHex(tabletId));
                LOG.info("Extract logs for " + HexString.longToPaddedHex(tabletId)
                        + " to " + dir);
                fs.mkdirs(dir);
                Path logPath = getLogFilePath(tabletId, Long.MAX_VALUE);
                if (fs.exists(logPath)) {
                    fs.delete(logPath);
                }
                WALogFile walFile = new WALogFile(fs, logPath);
                writer = walFile.createWriter(true);
                output.put(tabletId, writer);
            } else {
                return;
            }
        }
        writeCount++;
        long lastPos = writer.getPos();
        writer.write(entry);
        lastLSNMap.put(tabletId, entry.getLSN(), -1);
        lastTimeStampMap.put(tabletId, entry.getTimeStamp(), -1);
        if (throughputController != null) {
            try {
                throughputController.control(writer.getPos() - lastPos);
            } catch (InterruptedException e) {}
        };
    }

    @Override
    protected void handle(WALogInsert body) throws IOException {
        handle(body.getTabletId());
    }

    @Override
    protected void handle(WALogIndexInsert body) throws IOException {
        handle(body.getTabletId());
    }

    @Override
    protected void handle(WALogChkPt body) throws IOException {}
}
