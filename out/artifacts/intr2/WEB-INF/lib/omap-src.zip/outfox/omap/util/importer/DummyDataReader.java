/**
 * @(#)DummyDataReader.java, 2010-4-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.IOException;
import java.util.Properties;
import java.util.Random;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;

import odis.serialize.lib.ByteArrayWritable;

import outfox.omap.data.DataCell;
import outfox.omap.data.DataRow;
import outfox.omap.exceptions.BadSchemaDefinitionException;
import outfox.omap.util.TableConfig;

/**
 * DummyDataReader is used for create data row. Rows' keys are serial from 0L. <br>
 * Row is 'key:LONG;data:VINTBYTEARRAY' mode. Rows' count and size can be assigned. <br>
 * This reader is for testing and rapidly creating data.
 * @author wangfk
 *
 */
public class DummyDataReader implements IDataReader {
    
    private long rowCount = 0;
    private long rowSize = 0;
    
    private long iter = 0;
    
    private ThreadLocal<DataRow> tlDataRow = new ThreadLocal<DataRow>();
    private TableConfig tableConfig = null;
    
    private Random rand = new Random(System.currentTimeMillis());
    
    private boolean randValue = true;


    /* (non-Javadoc)
     * @see outfox.omap.util.importer.IDataReader#closeDataSouce()
     */
    @Override
    public void closeDataSouce() {
        iter = rowCount;
    }

    /* (non-Javadoc)
     * @see outfox.omap.util.importer.IDataReader#getNextRow()
     */
    @Override
    synchronized public DataRow getNextRow() {
        if(iter >= rowCount) {
            return null;
        }
        
        if(tlDataRow.get() == null) {
            tlDataRow.set(this.tableConfig.td.createDataRow());
        }
        
        DataRow dr = tlDataRow.get();
        DataCell[] columns = dr.getColumns();
        if(columns.length != 2) {
            throw new BadSchemaDefinitionException(
                    "Only 'key:LONG;data:VINTBYTEARRAY' mode can be accepted." );
        }
        
        long key = iter;
        columns[0].setValue(key);
        
        byte data[] = new byte[(int) (rowSize - 8)]; // minus the size of the key
        if(randValue) {
            rand.nextBytes(data);
        }
        data[0] = (byte) (key & 0xFF);
        ByteArrayWritable writable = new ByteArrayWritable();
        writable.set(data);
        columns[1].setBuffer(writable);
        
        ++ iter;
        return dr;
    }

    /* (non-Javadoc)
     * @see outfox.omap.util.importer.IDataReader#getRowCount()
     */
    @Override
    public long getRowCount() {
        return rowCount;
    }

    /* (non-Javadoc)
     * @see outfox.omap.util.importer.IDataReader#openDataSource()
     */
    @Override
    public void openDataSource() throws IOException {
        iter = 0;
    }

    /* (non-Javadoc)
     * @see outfox.omap.util.importer.IDataReader#setColNames(java.lang.String)
     */
    @Override
    public void setColNames(String colNames) {
        StringTokenizer ntk = new StringTokenizer(colNames, ";");
        
        if(ntk.countTokens() != 2) {
            throw new BadSchemaDefinitionException("Bad columns defines: " + 
                colNames + ". Only 'key:LONG;data:VINTBYTEARRAY' mode can be accepted." );
        }
        
    }

    /* (non-Javadoc)
     * @see outfox.omap.util.importer.IDataReader#setColTypes(java.lang.String)
     */
    @Override
    public void setColTypes(String colTypes) {
        StringTokenizer ntk = new StringTokenizer(colTypes, ";");
        boolean checkResult = true;
        
        if(ntk.countTokens() != 2) {
            checkResult = false;
        }else {
            String keyType = ntk.nextToken().trim();
            String valueType = ntk.nextToken().trim();
            
            if(!keyType.equals("LONG") || !valueType.equals("VINTBYTEARRAY")) {
                checkResult = false;
            }
        }
        
        if(!checkResult) {
            throw new BadSchemaDefinitionException("Bad columns types: " + 
                    colTypes + ". Only 'key:LONG;data:VINTBYTEARRAY' mode can be accepted." );
        }
    }

    @Override
    public void setProperties(Properties properties) {
        if(properties == null) {
            return;
        }
        
        String value;
        value = properties.getProperty("RowCount".toLowerCase());
        if(!StringUtils.isEmpty(value)) {
            this.setRowCount(Long.valueOf(value.trim()));
        }
        
        value = properties.getProperty("RowSize".toLowerCase());
        if(!StringUtils.isEmpty(value)) {
            this.setRowSize(Long.valueOf(value.trim()));
        }
        
        value = properties.getProperty("RandValue".toLowerCase());
        if(!StringUtils.isEmpty(value)) {
            this.setRandValue(Boolean.valueOf(value.trim()));
        }

    }

    @Override
    public void setTableConfig(TableConfig config) {
        this.tableConfig = config;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(long rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @param rowSize the rowSize to set
     */
    public void setRowSize(long rowSize) {
        this.rowSize = rowSize;
    }


    @Override
    public void setDataConvertor(int columnIndex, AbstractDataFormatConvertor convertor) {
        //Do nothing
    }

    /**
     * @param randValue the randValue to set
     */
    public void setRandValue(boolean randValue) {
        this.randValue = randValue;
    }
    
}
