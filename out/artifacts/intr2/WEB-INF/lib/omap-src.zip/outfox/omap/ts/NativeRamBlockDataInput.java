/**
 * @(#)NativeRamBlockDataInput.java, 2012-5-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import odis.util.unsafe.NativeRamBufferCDataInputStream;

/**
 * @author zhangduo
 */
public class NativeRamBlockDataInput extends NativeRamBufferCDataInputStream
        implements BlockDataInput {

    private final BlockCache.BlockCacheEntry cacheEntry;

    public NativeRamBlockDataInput(BlockCache.BlockCacheEntry cacheEntry,
            int chunkSize) {
        super(cacheEntry.buffers, chunkSize, cacheEntry.blockSize);
        this.cacheEntry = cacheEntry;
    }

    @Override
    public void dropBlock() {
        cacheEntry.drop();
    }

}
