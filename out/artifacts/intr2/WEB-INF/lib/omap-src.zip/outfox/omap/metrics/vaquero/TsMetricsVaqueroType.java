/**
 * @(#)TsMetricsVaqueroType.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public enum TsMetricsVaqueroType {
    NUM_TABLET("ts.num.tablet"),

    SYSTEM_LOAD("ts.system.load"),
    SYSTEM_LOAD_PER_PROCESSOR("ts.system.load.per.processor"),

    MEMORY_INIT("ts.memory.init"),
    MEMORY_USED("ts.memory.used"),
    MEMORY_COMMITTED("ts.memory.committed"),
    MEMORY_MAX("ts.memory.max"),
    
    WRITE_BUFFER_USED("ts.writebuffer.used"),
    WRITE_BUFFER_MAX("ts.writebuffer.max"),
    
    BLOOMFILTER_USED("ts.bloomfilter.used"),
    BLOOMFILTER_MAX("ts.bloomfilter.max"),
    
    INDEX_POOL_USED("ts.indexpool.used"),
    INDEX_POOL_MAX("ts.indexpool.max"),
    
    BLOCK_CACHE_USED("ts.blockcache.used"),
    BLOCK_CACHE_MAX("ts.blockcache.max"),
    
    RATE_HEARTBEAT("ts.rate.heartbeat"),
    DELAY_HEARTBEAT("ts.delay.heartbeat"),
    
    RATE_SSTABLE_SEEK("ts.rate.sstable.seek"),
    DELAY_SSTABLE_SEEK("ts.delay.sstable.seek"),
    
    RATE_BLOCK_CACHE_CACHE("ts.rate.blockcache.cache"),
    RATE_BLOCK_CACHE_GET("ts.rate.blockcache.get"),
    RATE_BLOCK_CACHE_GET_HIT("ts.rate.blockcache.gethit"),
    RATE_BLOCK_CACHE_EVICT("ts.rate.blockcache.evict"),

    RATE_REQUEST("ts.rate.request"),
    RATE_TIMEOUT_REQUEST("ts.rate.timeout.request"),
    
    RATE_KEY_FIND("rate.keyFind"),
    RATE_KEY_FIND_SIZE("rate.keyFind.size"),
    SIZE_KEY_FIND_PER_COUNT("size.keyFind.perCount"),
    DELAY_KEY_FIND("delay.keyFind"),
    
    RATE_MULTI_KEY_FIND("rate.multiKeyFind"),
    RATE_MULTI_KEY_FIND_ROWS("rate.multiKeyFind.rows"),
    RATE_MULTI_KEY_FIND_SIZE("rate.multiKeyFind.size"),
    ROWS_MULTI_KEY_FIND_PER_COUNT("rows.multiKeyFind.perCount"),
    SIZE_MULTI_KEY_FIND_PER_COUNT("size.multiKeyFind.perCount"),
    DELAY_MULTI_KEY_FIND("delay.multiKeyFind"),
    DELAY_MULTI_KEY_FIND_PER_ROW("delay.multiKeyFind.perRow"),
    
    RATE_RANGE_KEY_FIND("rate.rangeKeyFind"),
    RATE_RANGE_KEY_FIND_ROWS("rate.rangeKeyFind.rows"),
    RATE_RANGE_KEY_FIND_SIZE("rate.rangeKeyFind.size"),
    ROWS_RANGE_KEY_FIND_PER_COUNT("rows.rangeKeyFind.perCount"),
    SIZE_RANGE_KEY_FIND_PER_COUNT("size.rangeKeyFind.perCount"),
    DELAY_RANGE_KEY_FIND("delay.rangeKeyFind"),
    DELAY_RANGE_KEY_FIND_PER_ROW("delay.rangeKeyFind.perRow"),
    
    RATE_CONTAINS("rate.contains"),
    DELAY_CONTAINS("delay.contains"),
    
    RATE_MULTI_CONTAINS("rate.multiContains"),
    RATE_MULTI_CONTAINS_ROWS("rate.multiContains.rows"),
    ROWS_MULTI_CONTAINS_PER_COUNT("rows.multiContains.perCount"),
    DELAY_MULTI_CONTAINS("delay.multiContains"),
    DELAY_MULTI_CONTAINS_PER_ROW("delay.multiContains.perRow"),
    
    RATE_INSERT("rate.insert"),
    RATE_INSERT_SIZE("rate.insert.size"),
    SIZE_INSERT_PER_COUNT("size.insert.perCount"),
    DELAY_INSERT("delay.insert"),
    
    RATE_MULTI_INSERT("rate.multiInsert"),
    RATE_MULTI_INSERT_ROWS("rate.multiInsert.rows"),
    RATE_MULTI_INSERT_SIZE("rate.multiInsert.size"),
    ROWS_MULTI_INSERT_PER_COUNT("rows.multiInsert.perCount"),
    SIZE_MULTI_INSERT_PER_COUNT("size.multiInsert.perCount"),
    DELAY_MULTI_INSERT("delay.multiInsert"),
    DELAY_MULTI_INSERT_PER_ROW("delay.multiInsert.perRow"),
    
    RATE_DELETE("rate.delete"),
    DELAY_DELETE("delay.delete"),
    
    RATE_MULTI_DELETE("rate.multiDelete"),
    RATE_MULTI_DELETE_ROWS("rate.multiDelete.rows"),
    ROWS_MULTI_DELETE_PER_COUNT("rows.multiDelete.perCount"),
    DELAY_MULTI_DELETE("delay.multiDelete"),
    DELAY_MULTI_DELETE_PER_ROW("delay.multiDelete.perRow"),
    
    RATE_RANGE_DELETE("rate.rangeDelete"),
    RATE_RANGE_DELETE_ROWS("rate.rangeDelete.rows"),
    ROWS_RANGE_DELETE_PER_COUNT("rows.rangeDelete.perCount"),
    DELAY_RANGE_DELETE("delay.rangeDelete"),
    DELAY_RANGE_DELETE_PER_ROW("delay.rangeDelete.perRow"),
    
    RATE_COMPARE_AND_SET("rate.compareAndSet"),
    DELAY_COMPARE_AND_SET("delay.rate.compareAndSet"),
    
    RATE_LOCK_ROW("rate.lockRow"),
    DELAY_LOCK_ROW("delay.lockRow"),
    
    RATE_UNLOCK_ROW("rate.unlockRow"),
    DELAY_UNLOCK_ROW("delay.unlockRow");
    
    private final String vaqueroPropName;

    private TsMetricsVaqueroType(String vaqueroPropName) {
        this.vaqueroPropName = vaqueroPropName;
    }

    public String getVaqueroPropName() {
        return vaqueroPropName;
    }
}
