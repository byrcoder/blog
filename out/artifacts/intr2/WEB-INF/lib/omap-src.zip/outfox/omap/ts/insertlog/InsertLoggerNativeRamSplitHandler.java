/**
 * @(#)WALogNativeRamBufferHandler.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts.insertlog;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.IFileSystem;
import odis.io.Path;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferCDataInputStream;
import odis.util.unsafe.NativeRamBufferCDataOutputStream;
import outfox.omap.conf.OmapConfig;
import outfox.omap.util.OmapLogFormatter;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.ThroughputController;
import outfox.omap.util.WaitUtils;
import outfox.omap.util.OmapUtils.TESTCASE_PREPENSE_EXCEPTION_TYPE;
import outfox.omap.walog.WALogFile;
import outfox.omap.walog.WALogFile.Writer;
import toolbox.collections.primitive.IntegerArrayList;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.text.util.HexString;

/**
 * Read the log and write logs for different Tablets to separate log files.<br/>
 * Use native ram buffer to catch handled logs, so we can wrtie log files in
 * turn.<br/>
 * LOG file will be <code>outputDir/${HEXTabletId}/wal_${Long.MAX_VALUE}</code><br/>
 * After {@link #done}, the file will be changed to
 * <code>outputDir/${TabletId}/wal_${LastLSN}</code><br/>
 * 
 * @author wangfk
 */
public class InsertLoggerNativeRamSplitHandler extends
        ReservableInsertLogReaderHandler {
    private static final Logger LOG = OmapLogFormatter.getLogger(InsertLoggerNativeRamSplitHandler.class);

    private final int maxRetryCount = OmapConfig.getConfiguration().getInt(
            OmapConfig.NAME_DISASSEMBLE_WAL_RETRY_COUNT,
            OmapConfig.DEFAULT_DISASSEMBLE_WAL_RETRY_COUNT);

    private final NativeRamBuffer splitBuffer;

    private final NativeRamBufferCDataOutputStream splitBufferOut;

    private final HashMap<Long, IntegerArrayList> entryIndexesMap;

    private final Set<Long> tablets;

    private final Path outputDir;

    private final IFileSystem fs;

    private final ThroughputController throughputController;

    private int logItemCount;

    private final Random rand;

    public InsertLoggerNativeRamSplitHandler(IFileSystem fs, Path outputDir,
            Set<Long> tablets, NativeRamBuffer splitBuffer, long speedLimit,
            LongLongHashMap checkpoints, Random rand) throws IOException {
        super(checkpoints);
        this.outputDir = outputDir;
        this.fs = fs;
        this.logItemCount = 0;
        this.rand = rand;
        this.splitBuffer = splitBuffer;
        this.splitBufferOut = new NativeRamBufferCDataOutputStream(
                new NativeRamBuffer[] {
                    splitBuffer
                }, splitBuffer.getCapacity());

        this.entryIndexesMap = new HashMap<Long, IntegerArrayList>();
        this.tablets = new HashSet<Long>();
        this.tablets.addAll(tablets);

        if (speedLimit == 0) {
            this.throughputController = null;
        } else {
            this.throughputController = new ThroughputController(speedLimit);
        }
    }

    @Override
    public void done() throws IOException {
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.TS_PREPENSE_EXCEPTION_WHILE_SPLITTING_LOG_DONE);
        LOG.info("Disassemble log to NativeRamFile, size="
                + splitBuffer.getCapacity() + ", used="
                + splitBufferOut.getPos() + ", items count=" + logItemCount);

        LOG.info("Disassemble log, start to flush log, from NativeRamFile to tablet log files...");
        for (long tabletId: entryIndexesMap.keySet()) {
            for (int retryCount = 0;; retryCount++) {
                try {
                    flushToFileSystem(tabletId);
                    break;
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "flush data to tablet log file failure for tablet "
                                    + HexString.longToPaddedHex(tabletId)
                                    + ", retry=" + retryCount, e);
                    if (retryCount >= maxRetryCount) {
                        throw new IOException(
                                "flush data to tablet log file failure after retry "
                                        + retryCount + " times for tablet "
                                        + HexString.longToPaddedHex(tabletId),
                                e);
                    }
                }
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(
                        retryCount, rand));
            }
        }

        LOG.info("Disassemble log, finish log flush, from NativeRamFile to tablet log files");
    }

    @Override
    public void fail() throws IOException {
        LOG.warning("Failure to disassemble log to NativeRamFile, size="
                + splitBuffer.getCapacity() + ", used="
                + splitBufferOut.getPos() + ", items count=" + logItemCount);
    }

    private void flushToFileSystem(long tabletId) throws IOException {
        IntegerArrayList indexes = entryIndexesMap.get(tabletId);
        if (indexes.isEmpty()) {
            LOG.info("There is no log for tablet: "
                    + HexString.longToPaddedHex(tabletId));
            return;
        }

        Path tabletLogDir = new Path(outputDir,
                HexString.longToPaddedHex(tabletId));
        fs.mkdirs(tabletLogDir);
        Path tmpLogFilePath = new Path(tabletLogDir, WALogFile.FILE_PREFIX
                + Long.toString(Long.MAX_VALUE));
        fs.deprive(tmpLogFilePath);
        WALogFile logFile = new WALogFile(fs, tmpLogFilePath);
        Writer logFileWriter = logFile.createWriter(true);
        long lastLSN = 0;
        long lastTimeStamp = 0;
        try {
            NativeRamBufferCDataInputStream in = new NativeRamBufferCDataInputStream(
                    new NativeRamBuffer[] {
                        splitBuffer
                    }, splitBuffer.getCapacity(), splitBufferOut.getPos());
            InsertLogEntry entry = new InsertLogEntry();

            for (int i = 0; i < indexes.size(); i++) {
                int pos = indexes.get(i);
                in.seek(pos);
                entry.readFields(in);
                logFileWriter.write(entry);
                lastLSN = entry.getLSN();
                lastTimeStamp = entry.getTimeStamp();
            }
        } finally {
            OmapUtils.safeClose(logFileWriter);
        }

        if (tablets.contains(tabletId)) {
            Path logFilePath = new Path(tabletLogDir, WALogFile.FILE_PREFIX
                    + Long.toString(lastLSN));
            if (fs.exists(logFilePath)) {
                fs.delete(logFilePath);
            }
            if (!fs.link(tmpLogFilePath, logFilePath)) {
                throw new IOException("Failure to rename file from "
                        + tmpLogFilePath + " to " + logFilePath);
            }
            LOG.info("Finish log flush for tablet, id=" + tabletId
                    + ", log file=" + logFilePath + ", write keys="
                    + indexes.size());
        }

        if (needReserveLog(tabletId)) {
            Path logReserveFilePath = getLogReserveFilePath(tabletId, lastLSN,
                    lastTimeStamp);
            if (!fs.exists(logReserveFilePath.getParentFile())) {
                fs.mkdirs(logReserveFilePath.getParentFile());
            }
            fs.link(tmpLogFilePath, logReserveFilePath);
            LOG.info("Reserve log file for backup, from: " + tmpLogFilePath
                    + ", to: " + logReserveFilePath);
        }
        fs.delete(tmpLogFilePath);
    }

    private void handle(long tabletId) throws IOException {
        IntegerArrayList indexes = entryIndexesMap.get(tabletId);
        if (indexes == null) {
            if (tablets.contains(tabletId) || needReserveLog(tabletId)) {
                indexes = new IntegerArrayList();
                entryIndexesMap.put(tabletId, indexes);
            } else {
                return;
            }
        }
        int lastPos = (int) splitBufferOut.getPos();
        indexes.add(lastPos);
        entry.writeFields(splitBufferOut);
        ++logItemCount;
        if (throughputController != null) {
            try {
                throughputController.control(splitBufferOut.getPos() - lastPos);
            } catch (InterruptedException e) {}
        }
    }

    @Override
    protected void handle(WALogInsert body) throws IOException {
        handle(body.getTabletId());
    }

    @Override
    protected void handle(WALogIndexInsert body) throws IOException {
        handle(body.getTabletId());
    }

    @Override
    protected void handle(WALogChkPt body) throws IOException {}
}
