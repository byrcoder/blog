/**
 * @(#)FixSSTableOrderTool.java, 2011-9-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Comparator;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;

import odis.file.SequenceFile;
import odis.io.CDataInputStream;
import odis.io.FSDataInputStream;
import odis.io.FileSystem;
import odis.io.LzoCompression;
import odis.io.Path;
import odis.rpc2.RPC;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;

import org.apache.commons.lang.StringUtils;

import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.data.KeyCell;
import outfox.omap.metadata.KeyColumnDesc;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.SSTable;
import outfox.omap.ts.SSTableReader;
import outfox.omap.ts.SSTableWriter;

import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class FixSSTableOrderTool {

    private static final Logger LOG = LogFormatter.getLogger(FixSSTableOrderTool.class);

    private FileSystem fs;

    private Path inputDir;

    private Path outputDir;

    private long schemaId;

    private ClientMasterProtocol master;

    public void fix() throws IOException {
        FSDataInputStream metaIn = fs.open(inputDir.cat(SSTable.METADATA_FILE_NAME));
        Properties properties = new Properties();
        properties.load(metaIn);
        metaIn.close();

        CompressType compressType;
        String prop = properties.getProperty(SSTable.MetaData.NAME_COMPRESS_TYPE);
        if (!StringUtils.isEmpty(prop)) {
            compressType = CompressType.toType(prop);
        } else {
            compressType = CompressType.NULL;
        }

        SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                inputDir.cat(SSTable.DATA_FILE_NAME));
        IntWritable key = new IntWritable();
        ByteArrayWritable value = new ByteArrayWritable();
        OmapMetadata metadata = master.getMetadata(schemaId);
        final KeyColumnDesc kcd = metadata.getTableDesc().getKey();
        TreeMap<ByteArrayWritable, ByteArrayWritable> map = new TreeMap<ByteArrayWritable, ByteArrayWritable>(
                new Comparator<ByteArrayWritable>() {

                    private KeyCell key1 = kcd.createDataCell();

                    private KeyCell key2 = kcd.createDataCell();

                    @Override
                    public int compare(ByteArrayWritable o1,
                            ByteArrayWritable o2) {
                        OmapUtils.convertBytesToPIWritable(o1.data(), 0,
                                o1.size(), key1);
                        OmapUtils.convertBytesToPIWritable(o2.data(), 0,
                                o2.size(), key2);
                        return key1.compareTo(key2);
                    }

                });
        while (reader.next(key, value)) {
            int expectedLength = key.get();
            int actualLength;
            byte[] uncompressBuffer;
            CDataInputStream dis;
            switch (compressType) {
                case LZO:
                    uncompressBuffer = new byte[expectedLength];
                    actualLength = LzoCompression.uncompress(value.data(), 0,
                            value.getByteLength(), uncompressBuffer);
                    if (actualLength <= 0) {
                        throw new IOException(
                                "Error while uncompress lzo block. uncompress result: "
                                        + actualLength);
                    }
                    if (actualLength != expectedLength) {
                        throw new IOException(
                                "The actual length of block is not matched with discription of the key.");
                    }
                    dis = new CDataInputStream(new ByteArrayInputStream(
                            uncompressBuffer, 0, actualLength));
                    break;
                case GZIP:
                    uncompressBuffer = new byte[expectedLength];
                    GZIPInputStream gzipInputStream = new GZIPInputStream(
                            new ByteArrayInputStream(value.data(), 0,
                                    value.size()));
                    try {
                        actualLength = 0;
                        while (actualLength < expectedLength) {
                            int res = gzipInputStream.read(uncompressBuffer,
                                    actualLength, expectedLength - actualLength);
                            if (res <= 0) {
                                break;
                            }
                            actualLength += res;
                        }
                        if (actualLength != expectedLength) {
                            throw new IOException(
                                    "The actual length of block is not matched with discription of the key.");
                        }
                    } finally {
                        gzipInputStream.close();
                    }
                    dis = new CDataInputStream(new ByteArrayInputStream(
                            uncompressBuffer, 0, actualLength));
                    break;
                default:
                    dis = new CDataInputStream(new ByteArrayInputStream(
                            value.data(), 0, value.size()));
                    break;
            }
            ByteArrayWritable prevKey = null;
            while (dis.available() > 0) {
                try {
                    ByteArrayWritable actualKey = new ByteArrayWritable();
                    ByteArrayWritable actualValue = new ByteArrayWritable();
                    actualKey.readFields(dis);
                    actualValue.readFields(dis);
                    if (prevKey == null) {
                        prevKey = new ByteArrayWritable();
                    } else {
                        if (map.comparator().compare(prevKey, actualKey) >= 0) {
                            KeyCell prev = kcd.createDataCell();
                            KeyCell current = kcd.createDataCell();
                            OmapUtils.convertBytesToPIWritable(prevKey.data(),
                                    0, prevKey.size(), prev);
                            OmapUtils.convertBytesToPIWritable(
                                    actualKey.data(), 0, actualKey.size(),
                                    current);
                            LOG.warning("Found unordered key, prev = " + prev
                                    + ", current = " + current);
                        }
                    }
                    prevKey.copyFields(actualKey);
                    map.put(actualKey, actualValue);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "got error", e);
                }
            }
            dis.close();
        }
        reader.close();
        SSTableWriter writer = new SSTableWriter(fs, outputDir, map.size(),
                compressType);
        ByteArrayWritable prevKey = null;
        for (Map.Entry<ByteArrayWritable, ByteArrayWritable> entry: map.entrySet()) {
            ByteArrayWritable actualKey = entry.getKey();
            if (prevKey == null) {
                prevKey = new ByteArrayWritable();
            } else {
                if (map.comparator().compare(prevKey, actualKey) >= 0) {
                    KeyCell prev = kcd.createDataCell();
                    KeyCell current = kcd.createDataCell();
                    OmapUtils.convertBytesToPIWritable(prevKey.data(), 0,
                            prevKey.size(), prev);
                    OmapUtils.convertBytesToPIWritable(actualKey.data(), 0,
                            actualKey.size(), current);
                    LOG.warning("Still have unordered key, prev = " + prev
                            + ", current = " + current);
                }
            }
            prevKey.copyFields(actualKey);
            ByteArrayWritable nonKeyPart = entry.getValue();
            ByteArrayWritable actualValue = new ByteArrayWritable(
                    new byte[actualKey.size() + nonKeyPart.size()]);
            actualValue.data()[0] = nonKeyPart.data()[0];
            System.arraycopy(actualKey.data(), 0, actualValue.data(), 1,
                    actualKey.size());
            System.arraycopy(nonKeyPart.data(), 1, actualValue.data(),
                    actualKey.size() + 1, nonKeyPart.size() - 1);
            writer.write(actualKey, actualValue);
        }
        writer.close();
    }

    public void validate() throws IOException {
        FSDataInputStream metaIn = fs.open(inputDir.cat(SSTable.METADATA_FILE_NAME));
        Properties properties = new Properties();
        properties.load(metaIn);
        metaIn.close();

        CompressType compressType;
        String prop = properties.getProperty(SSTable.MetaData.NAME_COMPRESS_TYPE);
        if (!StringUtils.isEmpty(prop)) {
            compressType = CompressType.toType(prop);
        } else {
            compressType = CompressType.NULL;
        }

        SequenceFile.Reader dataReader = new SequenceFile.Reader(fs,
                inputDir.cat(SSTable.DATA_FILE_NAME));
        IntWritable dataKey = new IntWritable();
        ByteArrayWritable dataValue = new ByteArrayWritable();
        OmapMetadata metadata = master.getMetadata(schemaId);
        final KeyColumnDesc kcd = metadata.getTableDesc().getKey();

        SequenceFile.Reader indexReader = new SequenceFile.Reader(fs,
                inputDir.cat(SSTable.SPARSE_INDEX_FILE_NAME));
        ByteArrayWritable indexKey = new ByteArrayWritable();
        LongWritable indexValue = new LongWritable();
        while (indexReader.next(indexKey, indexValue)) {
            dataReader.seek(indexValue.get());
            dataReader.next(dataKey, dataValue);
            int expectedLength = dataKey.get();
            int actualLength;
            byte[] uncompressBuffer;
            CDataInputStream dis;
            switch (compressType) {
                case LZO:
                    uncompressBuffer = new byte[expectedLength];
                    actualLength = LzoCompression.uncompress(dataValue.data(),
                            0, dataValue.getByteLength(), uncompressBuffer);
                    if (actualLength <= 0) {
                        throw new IOException(
                                "Error while uncompress lzo block. uncompress result: "
                                        + actualLength);
                    }
                    if (actualLength != expectedLength) {
                        throw new IOException(
                                "The actual length of block is not matched with discription of the key.");
                    }
                    dis = new CDataInputStream(new ByteArrayInputStream(
                            uncompressBuffer, 0, actualLength));
                    break;
                case GZIP:
                    uncompressBuffer = new byte[expectedLength];
                    GZIPInputStream gzipInputStream = new GZIPInputStream(
                            new ByteArrayInputStream(dataValue.data(), 0,
                                    dataValue.size()));
                    try {
                        actualLength = 0;
                        while (actualLength < expectedLength) {
                            int res = gzipInputStream.read(uncompressBuffer,
                                    actualLength, expectedLength - actualLength);
                            if (res <= 0) {
                                break;
                            }
                            actualLength += res;
                        }
                        if (actualLength != expectedLength) {
                            throw new IOException(
                                    "The actual length of block is not matched with discription of the key.");
                        }
                    } finally {
                        gzipInputStream.close();
                    }
                    dis = new CDataInputStream(new ByteArrayInputStream(
                            uncompressBuffer, 0, actualLength));
                    break;
                default:
                    dis = new CDataInputStream(new ByteArrayInputStream(
                            dataValue.data(), 0, dataValue.size()));
                    break;
            }
            ByteArrayWritable prevKey = null;
            while (dis.available() > 0) {
                try {
                    ByteArrayWritable actualKey = new ByteArrayWritable();
                    ByteArrayWritable actualValue = new ByteArrayWritable();
                    actualKey.readFields(dis);
                    actualValue.readFields(dis);
                    if (prevKey == null) {
                        prevKey = new ByteArrayWritable();
                        KeyCell indexKeyCell = kcd.borrowKeyCell();
                        OmapUtils.convertBytesToPIWritable(indexKey.data(), 0,
                                indexKey.size(), indexKeyCell);
                        KeyCell firstKeyCell = kcd.borrowKeyCell();
                        OmapUtils.convertBytesToPIWritable(actualKey.data(), 0,
                                actualKey.size(), firstKeyCell);
                        if (indexKeyCell.compareTo(firstKeyCell) != 0) {
                            LOG.warning("Found logic error, index key "
                                    + indexKeyCell
                                    + " is not equal to first key in block "
                                    + firstKeyCell);
                        }
                        kcd.returnKeyCell(indexKeyCell);
                        kcd.returnKeyCell(firstKeyCell);
                    } else {
                        KeyCell prevKeyCell = kcd.borrowKeyCell();
                        KeyCell currentKeyCell = kcd.borrowKeyCell();
                        OmapUtils.convertBytesToPIWritable(prevKey.data(), 0,
                                prevKey.size(), prevKeyCell);
                        OmapUtils.convertBytesToPIWritable(actualKey.data(), 0,
                                actualKey.size(), currentKeyCell);
                        if (prevKeyCell.compareTo(currentKeyCell) >= 0) {
                            LOG.warning("Found unordered key, prev = "
                                    + prevKeyCell + ", current = "
                                    + currentKeyCell);
                        }
                        kcd.returnKeyCell(prevKeyCell);
                        kcd.returnKeyCell(currentKeyCell);
                    }
                    prevKey.copyFields(actualKey);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "got error", e);
                }
            }
        }
        indexReader.close();
        dataReader.close();
    }

    public void cursor() throws IOException {
        SSTable sstable = getSSTable();
        SSTableReader sstReader = sstable.borrowReader(false);

        ByteArrayWritable key = new ByteArrayWritable();
        ByteArrayWritable value = new ByteArrayWritable();
        int count = 0;
        if (sstReader.first(key, value)) {
            ++count;
        } else {
            LOG.warning("The sstable is empty?");
        }

        while (sstReader.next(key, value)) {
            ++count;
            if (count % 1000 == 0) {
                LOG.info("Items count: " + count);
            }
        }
        LOG.info("Items count: " + count);
    }

    private SSTable getSSTable() throws IOException {
        // /<tabletDir>/schameID/XXXXXX/XX/SS_XX -> /<tabletDir>/schameID/XXXXXX/XX
        Path SSTableFileDir = inputDir.getParentFile();
        String tabletIdStr = OmapUtils.getTabletIdBySSTableFileDirPath(SSTableFileDir.getAbsolutePath());
        long tabletId = HexString.paddedHexToLong(tabletIdStr);

        // /<tabletDir>/schameID/XXXXXX/XX -> /<tabletDir>
        String tabletDir = SSTableFileDir.getParentFile().getParentFile().getParentFile().getAbsolutePath();
        OmapTs omapTs = new OmapTs(fs, tabletDir);

        String sstableName = inputDir.getName();
        if (sstableName.indexOf("SS_") < 0) {
            throw new RuntimeException(
                    "This method can only handle normal sstable");
        }
        SSTable sstable = new SSTable(omapTs, tabletId,
                Long.parseLong(sstableName.substring(3)));
        return sstable;
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 5 && args.length != 6) {
            System.out.println("USAGE: FixSSTableOrderTool <omap master> <fs> <schema id> <sst dir> <out dir> [fix|cursor]");
            return;
        }
        ClientMasterProtocol master = RPC.getProxy(ClientMasterProtocol.class,
                InetAddressUtils.createSocketAddr(args[0]));
        FileSystem fs = FileSystem.getNamed(args[1]);
        long schemaId = Long.parseLong(args[2]);
        Path inputDir = new Path(args[3]);
        Path outputDir = new Path(args[4]);
        FixSSTableOrderTool tool = new FixSSTableOrderTool();
        tool.fs = fs;
        tool.master = master;
        tool.schemaId = schemaId;
        tool.inputDir = inputDir;
        tool.outputDir = outputDir;
        if (args.length > 5 && args[5].equals("fix")) {
            tool.fix();
        } else if (args.length > 5 && args[5].equals("cursor")) {
            tool.cursor();
        } else {
            tool.validate();
        }
    }
}
