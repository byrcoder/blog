/**
 * @(#)RowLockQueue.java, 2011-5-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import outfox.omap.exceptions.RowLockQueueFullException;
import outfox.omap.ts.OmapTs.LockKey;

/**
 * A priority queue ordered by expiredTime.
 * 
 * @author zhangduo
 */
class RowLockQueue {

    private static final int DEFAULT_INITIAL_CAPACITY = 11;

    static class LockEntry implements Comparable<LockEntry> {
        public final LockKey key;

        public final String lockName;

        public final long expiredTime;

        public LockEntry(LockKey key, String lockName, long expiredTime) {
            this.key = key;
            this.lockName = lockName;
            this.expiredTime = expiredTime;
        }

        @Override
        public int hashCode() {
            return lockName.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            LockEntry that = (LockEntry) obj;
            return lockName.equals(that.lockName);
        }

        @Override
        public int compareTo(LockEntry o) {
            LockEntry that = (LockEntry) o;
            if (expiredTime < that.expiredTime) {
                return -1;
            }
            if (expiredTime > that.expiredTime) {
                return 1;
            }
            return lockName.compareTo(that.lockName);
        }

        @Override
        public String toString() {
            return "LockEntry [key=" + key + ", lockName=" + lockName
                    + ", expiredTime=" + expiredTime + "]";
        }

    }

    private final int maxCapacity;

    private LockEntry[] queue;

    private int size;

    private Map<String, Integer> lockName2Index;

    public RowLockQueue(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        queue = new LockEntry[DEFAULT_INITIAL_CAPACITY];
        lockName2Index = new HashMap<String, Integer>(DEFAULT_INITIAL_CAPACITY);
    }

    private void grow(int minCapacity) {
        int oldCapacity = queue.length;
        // Double size if small; else grow by 50%
        int newCapacity = ((oldCapacity < 64) ? ((oldCapacity + 1) * 2)
                : ((oldCapacity / 2) * 3));
        if (newCapacity < 0 || newCapacity > maxCapacity) { // overflow
            newCapacity = maxCapacity;
        }
        if (newCapacity < minCapacity) {
            newCapacity = minCapacity;
        }
        queue = Arrays.copyOf(queue, newCapacity);
    }

    private void siftUp(int k, LockEntry entry) {
        while (k > 0) {
            int parent = (k - 1) >>> 1;
            LockEntry e = queue[parent];
            if (entry.compareTo(e) >= 0) {
                break;
            }
            queue[k] = e;
            lockName2Index.put(e.lockName, k);
            k = parent;
        }
        queue[k] = entry;
        lockName2Index.put(entry.lockName, k);
    }

    private void siftDown(int k, LockEntry entry) {
        int half = size >>> 1; // loop while a non-leaf
        while (k < half) {
            int child = (k << 1) + 1; // assume left child is least
            LockEntry c = queue[child];
            int right = child + 1;
            if (right < size && c.compareTo(queue[right]) > 0) {
                c = queue[child = right];
            }
            if (entry.compareTo(c) <= 0) {
                break;
            }
            queue[k] = c;
            lockName2Index.put(c.lockName, k);
            k = child;
        }
        queue[k] = entry;
        lockName2Index.put(entry.lockName, k);
    }

    /**
     * Return <code>true</code> iff the lock with same lockName is not contained
     * in the queue. Otherwise, return <code>false</code>.
     * 
     * @param lockName
     * @param expiredTime
     * @param lockKey
     * @return
     */
    public synchronized boolean add(String lockName, long expiredTime,
            LockKey lockKey) {
        LockEntry lockEntry = new LockEntry(lockKey, lockName, expiredTime);
        Integer index = lockName2Index.get(lockName);
        if (index == null) {
            if (size >= maxCapacity) {
                throw new RowLockQueueFullException(
                        "Row lock number reach limit " + maxCapacity);
            }
            int i = size;
            if (i >= queue.length) {
                grow(i + 1);
            }
            size = i + 1;
            if (i == 0) {
                queue[0] = lockEntry;
                lockName2Index.put(lockName, 0);
            } else {
                siftUp(i, lockEntry);
            }
            return true;
        } else {
            LockEntry originalLockEntry = queue[index.intValue()];
            if (originalLockEntry.expiredTime < expiredTime) { // normal case
                siftDown(index.intValue(), lockEntry);
            } else if (originalLockEntry.expiredTime > expiredTime) {
                siftUp(index.intValue(), lockEntry);
            }
            return false;
        }
    }

    public synchronized LockEntry peek() {
        if (size == 0) {
            return null;
        }
        return queue[0];
    }

    public synchronized LockEntry poll() {
        if (size == 0) {
            return null;
        }
        LockEntry result = queue[0];
        int s = --size;
        LockEntry x = queue[s];
        queue[s] = null;
        if (s != 0) {
            siftDown(0, x);
        }
        lockName2Index.remove(result.lockName);
        return result;
    }

    public synchronized LockEntry remove(String lockName) {
        Integer index = lockName2Index.remove(lockName);
        if (index == null) {
            return null;
        }
        int i = index.intValue();
        LockEntry result = queue[i];
        int s = --size;
        if (s == i) { // removed last element
            queue[i] = null;
        } else {
            LockEntry moved = queue[s];
            queue[s] = null;
            siftDown(i, moved);
            if (queue[i] == moved) {
                siftUp(i, moved);
            }
        }
        return result;
    }

    public synchronized int size() {
        return size;
    }
}
