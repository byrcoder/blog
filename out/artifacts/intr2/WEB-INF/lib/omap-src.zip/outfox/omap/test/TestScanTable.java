/**
 * @(#)TestScanTable.java, 2010-6-25. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.test;

import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapLogFormatter;

/** Scan tables without checking it's content, 
 * the number of keys will be logged.<br/>
 * <br/>
 * <b>USAGE:</b> <code> ./odis run outfox.omap.test.TestScanTable &lt;tablespace&gt; &lt;tablename&gt; [&lt;tablespace&gt; &lt;tablename&gt;] ...</code>
 *
 * @author wangfk
 *
 */
public class TestScanTable {
    
    Logger LOG = OmapLogFormatter.getLogger(TestScanTable.class);
    
    protected DataSource ds = null;
    private CursorThread[] threads;
    
    private TestScanTable(String[] args) throws OmapException {
        ds = DataSourceFactory.getNamed("OmapDataSource");
        
        threads = new CursorThread[args.length/2];
        
        for(int i = 0; i < args.length; i += 2) {
            threads[i/2] = new CursorThread(args[i], args[i+1]);
        }
    }
    
    private void startTest() throws InterruptedException {
        boolean flag = true;
        for(int i = 0; i < threads.length; ++ i) {
            new Thread(threads[i]).start();
        }
        
        while (flag) {
            Thread.sleep(1000);
            flag = false;
            for(int i = 0; i < threads.length; ++ i) {
                flag |= !threads[i].isEnd();
                LOG.info(threads[i].getStatus());
            }
        }
        
        LOG.info("  ====Row count of all tables====  ");
        for(int i = 0; i < threads.length; ++ i) {
            LOG.info(threads[i] + " : " + threads[i].getCount());
        }
    }

    private class CursorThread implements Runnable {
        private Table table;
        private String tableSpace; 
        private String tableName;
        private AtomicLong count = new AtomicLong(0);
        private volatile boolean end = false;

        public CursorThread(String space, String name) throws OmapException {
            tableSpace = space;
            tableName = name;
            table = ds.openTableSpace(space).openTable(name);
        }
        
        public void run() {
            try {
                TableCursor tableCursor = table.getTableCursor();
                tableCursor.setPrefetch(100);
                Row row = table.newRow();
                while(tableCursor.next(row)) {
                    count.incrementAndGet();
                }
                
            }catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                end = true;
            }
        }
        
        public long getCount() {
            return this.count.get();
        }
        
        public boolean isEnd() {
            return end;
        }
        
        public String getStatus() {
            return "Read" + this +", rows count = " + count;
        }
        
        public String toString() {
            return "Table[" + tableSpace + ":" +  tableName + "]";
        }
    }

    public static void main(String[] args) throws Exception {
        if(args.length == 0 || args.length % 2 != 0) {
            System.out.println(TestScanTable.class.getName() + " <tablespace> <tablename> [<tablespace> <tablename>] ...");
            return;
        }
        new TestScanTable(args).startTest();
    }

}
