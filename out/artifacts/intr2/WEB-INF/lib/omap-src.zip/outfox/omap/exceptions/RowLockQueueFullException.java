/**
 * @(#)RowLockQueueFullException.java, 2011-5-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author zhangduo
 */
public class RowLockQueueFullException extends RuntimeException {

    private static final long serialVersionUID = -1874236885919341113L;

    public RowLockQueueFullException() {
        super();
    }

    public RowLockQueueFullException(String message, Throwable cause) {
        super(message, cause);
    }

    public RowLockQueueFullException(String message) {
        super(message);
    }

    public RowLockQueueFullException(Throwable cause) {
        super(cause);
    }
}
