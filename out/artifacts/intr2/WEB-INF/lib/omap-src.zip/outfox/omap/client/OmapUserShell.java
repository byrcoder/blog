package outfox.omap.client;

import java.io.EOFException;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import odis.rpc2.RpcException;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;

import org.gnu.readline.Readline;
import org.gnu.readline.ReadlineLibrary;

import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.exceptions.OmapException;
import outfox.omap.metadata.ColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;

public class OmapUserShell {

    private static final int LEVEL_ROOT = 0;

    private static final int LEVEL_SPACE = 1;

    private static final int LEVEL_TABLE = 2;

    private boolean terminate = false;

    private MasterWatcherAndClientConfig masterWatcher;

    private int currentLevel;

    private TableSpace currentSpace;

    private String currentSpaceName;

    private Table currentTable;

    private String currentTableName;

    public OmapUserShell() throws OmapException {
        try {
            masterWatcher = new MasterWatcherAndClientConfig(new ClientConfig("omap.xml"));
        } catch (Exception e) {
            throw new OmapException("OmapTableSpaces initialize failed." + e);
        }
        currentLevel = LEVEL_ROOT;
    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        new OmapUserShell().ui();
    }

    private void ui() {
        try {
            Readline.load(ReadlineLibrary.GnuReadline);
        } catch (Exception e) {
            System.out.println("Error loading readline lib: " + e);
            System.out.println("Fall back to default Java console IO.");
        }
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                Readline.cleanup();
            }
        });
        while (!terminate) {
            try {
                String s = Readline.readline(constructPrefix());
                if (s == null)
                    continue;
                String[] cmds = OmapUtils.parseCmdLine(s);
                if (cmds.length == 0)
                    continue;
                if (cmds[0].equals("quit"))
                    return;
                exec(cmds, 0);
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (EOFException e) {
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String constructPrefix() {
        String sep = "/";
        String start = "OMAP";
        String end = ">";
        if (currentLevel == LEVEL_ROOT) {
            return start + sep + end;
        } else if (currentLevel == LEVEL_SPACE) {
            return start + sep + currentSpaceName + end;
        } else if (currentLevel == LEVEL_TABLE) {
            return start + sep + currentSpaceName + sep + currentTableName
                    + end;
        } else {
            return "ERROR" + end;
        }
    }

    private void list() {
        try {
            if (currentLevel == LEVEL_ROOT) {
                listSpaces();
            } else if (currentLevel == LEVEL_SPACE) {
                listTables();
            } else {
                System.out.println("Command list can not work in this level.");
            }
        } catch (OmapException e) {
            e.printStackTrace();
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void listSpaces() throws OmapException {
        try {
            OmapMetadata[] tables = masterWatcher.getMaster().getTables();
            TreeSet<String> spaces = new TreeSet<String>();
            for (OmapMetadata table: tables) {
                spaces.add(OmapUtils.parseTabelSpaceName(table.getTableDesc().getTableName()));
            }
            System.out.println("Found " + spaces.size()
                    + " none empty Table Spaces:");
            for (String space: spaces) {
                System.out.println(space);
            }
        } catch (RpcException e) {
            throw new OmapException(e);
        }
    }

    private void listTables() throws OmapException {
        Metadata[] tables = currentSpace.listTables();
        TreeMap<String, Metadata> result = new TreeMap<String, Metadata>();
        for (Metadata table: tables) {
            String tableName = table.getTableName();
            if (tableName.split("\\$").length == 1) {
                result.put(tableName, table);
            }
        }
        System.out.println("Found " + result.size() + " tables in space "
                + currentSpaceName + ":");
        for (Map.Entry<String, Metadata> entry : result.entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue());
        }
    }

    private void open(String[] args) {
        try {
            if (currentLevel == LEVEL_ROOT) {
                openSpace(args[0]);
            } else if (currentLevel == LEVEL_SPACE) {
                openTable(args[0]);
            } else {
                System.out.println("Command open can not work in this level.");
            }
        } catch (OmapException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void openSpace(String spaceName) throws OmapException {
        this.currentSpace = new OmapTableSpace(spaceName, masterWatcher);
        this.currentSpaceName = spaceName;
        this.currentLevel = LEVEL_SPACE;
    }

    private void openTable(String tableName) throws OmapException {
        this.currentTable = this.currentSpace.openTable(tableName);
        if (currentTable == null) {
            System.out.println("No such table.");
            return;
        }
        this.currentTableName = tableName;
        this.currentLevel = LEVEL_TABLE;
    }

    private void createTable(String tableName, String definition)
            throws OmapException {
        if (this.currentSpace != null) {
            this.currentSpace.createTable(tableName, definition);
        } else {
            System.out.println("Should open a Table Space before creating a Table");
        }
    }

    private static IWritable getWritableValue(Class<?> keyClass, String key) {
        IWritable keyWritable;
        if (keyClass.equals(UTF8Writable.class)) {
            keyWritable = new UTF8Writable(key);
        } else if (keyClass.equals(LongWritable.class)) {
            keyWritable = new LongWritable(Long.parseLong(key));
        } else if (keyClass.equals(IntWritable.class)) {
            keyWritable = new IntWritable(Integer.parseInt(key));
        } else if (keyClass.equals(StringWritable.class)) {
            keyWritable = new StringWritable(key);
        } else {
            System.out.println("Not a shell supported key type: " + keyClass);
            return null;
        }
        return keyWritable;
    }

    private void ret() {
        if (currentLevel == LEVEL_SPACE) {
            currentLevel = LEVEL_ROOT;
        } else if (currentLevel == LEVEL_TABLE) {
            currentLevel = LEVEL_SPACE;
        } else {
            currentLevel = LEVEL_ROOT;
        }
    }

    private void dump() {
        try {
            if (currentLevel == LEVEL_TABLE) {
                dumpTable();
            } else {
                System.out.println("Command dump can not work in this level.");
            }
        } catch (OmapException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void delete(String arg) {
        try {
            if (currentLevel == LEVEL_SPACE) {
                deleteTable(arg);
            } else if (currentLevel == LEVEL_TABLE) {
                deleteRow(arg);
            } else {
                System.out.println("Command delete connot work in this level.");
            }
        } catch (OmapException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void deleteTable(String tableName) throws OmapException {
        currentSpace.deleteTable(tableName);
    }

    private void deleteRow(String key) throws OmapException {
        if (currentTable == null) {
            System.out.println("No table is opened.");
            return;
        } else {
            Class<?> keyClass = currentTable.getMetadata().getColumnTypeClasses()[0];
            IWritable keyWritable = getWritableValue(keyClass, key);
            if (keyWritable == null) {
                return;
            }
            currentTable.delete(keyWritable);
        }
    }

    private void dumpTable() throws OmapException {
        if (currentTable == null) {
            System.out.println("No table is opened.");
            return;
        }
        TableCursor cursor = currentTable.getTableCursor();
        Row row = currentTable.newRow();
        while (cursor.next(row)) {
            System.out.println(row.toString());
        }
    }

    private void find(String key) {
        try {
            if (currentLevel == LEVEL_TABLE) {
                findInTable(key);
            } else {
                System.out.println("Command find cannot work in this level.");
            }
        } catch (OmapException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void findInTable(String key) throws OmapException {
        if (currentTable == null) {
            System.out.println("No table is opened.");
            return;
        } else {
            Class<?> keyClass = currentTable.getMetadata().getColumnTypeClasses()[0];
            IWritable keyWritable = getWritableValue(keyClass, key);
            if (keyWritable == null) {
                return;
            }
            Row row = currentTable.newRow();
            currentTable.lookup(keyWritable, row);
            System.out.println(row.toString());
        }
    }

    private void find(String key, String num) {
        try {
            if (currentLevel == LEVEL_TABLE) {
                findInTable(key, Integer.parseInt(num));
            } else {
                System.out.println("Command find cannot work in this level.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void findInTable(String key, int num) throws OmapException {
        if (currentTable == null) {
            System.out.println("No table is opened.");
            return;
        } else {
            int number = num;
            Class<?> keyClass = currentTable.getMetadata().getColumnTypeClasses()[0];
            IWritable keyWritable = getWritableValue(keyClass, key);
            if (keyWritable == null) {
                return;
            }
            TableCursor cursor = currentTable.getTableCursor();
            cursor.moveTo(keyWritable, false);
            Row row = currentTable.newRow();
            for (int i = 0; i < number; i++) {
                if (cursor.next(row)) {
                    System.out.println(row.toString());
                } else {
                    return;
                }
            }
        }
    }

    private void findRange(String startKey, String endKey) {
        try {
            if (currentLevel == LEVEL_TABLE) {
                findRangeInTable(startKey, endKey);
            } else {
                System.out.println("Command findr cannot work in this level.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void findRangeInTable(String startKey, String endKey)
            throws OmapException {
        if (currentTable == null) {
            System.out.println("No table is opened.");
            return;
        } else {
            Class<?> keyClass = currentTable.getMetadata().getColumnTypeClasses()[0];
            IWritable startKeyWritable = getWritableValue(keyClass, startKey);
            IWritable endKeyWritable = getWritableValue(keyClass, endKey);
            if (startKeyWritable == null || endKeyWritable == null) {
                return;
            }
            try {
                IWritable tmpKey = (IWritable) keyClass.newInstance();
                TableCursor cursor = currentTable.getTableCursor();
                cursor.moveTo(startKeyWritable, false);
                Row row = currentTable.newRow();
                while (cursor.next(row)) {
                    row.getKey(tmpKey);
                    if (((IWritableComparable) endKeyWritable).compareTo(tmpKey) < 0) {
                        break;
                    } else {
                        System.out.println(row.toString());
                    }
                }
            } catch (Exception e) {
                if (e instanceof RuntimeException) {
                    throw (RuntimeException) e;
                } else {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private void set(String args[]) {
        try {
            if (currentLevel == LEVEL_TABLE) {
                if (args.length >= 3) {
                    setInTable(args[0], args[1], args[2]);
                } else {
                    System.out.println("Not enough args.");
                }
            } else {
                System.out.println("Command set cannot work in this level.");
            }
        } catch (OmapException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void setInTable(String key, String columnName, String value)
            throws OmapException {
        if (currentTable == null) {
            System.out.println("No table is opened.");
            return;
        } else {
            Class<?> keyClass = currentTable.getMetadata().getColumnTypeClasses()[0];
            IWritable keyWritable = getWritableValue(keyClass, key);
            if (keyWritable == null) {
                return;
            }
            OmapUserRow row = (OmapUserRow) (currentTable.newRow());
            Class<?> valueClass = row.get(columnName).getClass();
            IWritable valueWritable = getWritableValue(valueClass, value);
            if (valueWritable == null) {
                return;
            }
            if (valueClass.equals(UTF8Writable.class)) {
                valueWritable = new UTF8Writable(value);
            } else if (valueClass.equals(LongWritable.class)) {
                valueWritable = new LongWritable(Long.parseLong(value));
            } else if (valueClass.equals(IntWritable.class)) {
                valueWritable = new IntWritable(Integer.parseInt(value));
            } else {
                System.out.println("Not a shell supported value type.");
                return;
            }
            row.setKey(keyWritable);
            row.set(columnName, valueWritable);
            currentTable.update(row);
        }
    }

    private void test() {
        System.out.println(currentTable.getMetadata().getColumnTypes().length);
        for (Class<?> c: currentTable.getMetadata().getColumnTypeClasses()) {
            System.out.println(c);
        }
        System.out.println(currentTable.getMetadata().getColumnNames().length);
        for (String s: currentTable.getMetadata().getColumnNames()) {
            System.out.println(s);
        }
        TableDesc td = ((OmapMetadata) currentTable.getMetadata()).getTableDesc();
        System.out.println(td.getColumns().length);
        for (ColumnDesc cd: td.getColumns()) {
            System.out.println(cd);
        }
        td.printAllColumnNames();
        try {
            OmapUserRow row = (OmapUserRow) (currentTable.newRow());
            System.out.println(row.get("content").getClass());
        } catch (Exception e) {

        }

    }

    private void snapshot(String tableName, String targetDir, boolean checkpoint)
            throws OmapException {
        if (currentLevel == LEVEL_SPACE) {
            currentSpace.snapshot(tableName, targetDir, checkpoint);
        } else {
            System.out.println("Command snapshot cannot work in this level.");
        }
    }

    private void importSnapshot(String tableName, String targetDir)
            throws OmapException {
        if (currentLevel == LEVEL_SPACE) {
            currentSpace.importSnapshot(tableName, targetDir);
        } else {
            System.out.println("Command import cannot work in this level.");
        }
    }

    private void usage() {
        if (currentLevel == LEVEL_ROOT) {
            System.out.println("=====================================================================================");
            System.out.println("list                                                    List table spaces");
            System.out.println("open <space name>                                       Open a table space");
            System.out.println("=====================================================================================");
        } else if (currentLevel == LEVEL_SPACE) {
            System.out.println("=====================================================================================");
            System.out.println("list                                                    List tables");
            System.out.println("create <table name> <definition>                        Create a table");
            System.out.println("open <table name>                                       Open a table");
            System.out.println("delete <table name>                                     Delete a table");
            System.out.println("snapshot <table name> <target dir>                      snapshot a table to the given dir");
            System.out.println("import <table name> <snapshot dir>                      import a table from the snapshot dir");
            System.out.println("ret                                                     return to the LEVEL_ROOT");
            System.out.println("=====================================================================================");
        } else if (currentLevel == LEVEL_TABLE) {
            System.out.println("=====================================================================================");
            System.out.println("open <family name> <key>                                Open a column family");
            System.out.println("dump                                                    Dump current table");
            System.out.println("find <key> [number]                                     find by key");
            System.out.println("findr <start key> <end key>                             find a range");
            System.out.println("set <key> <column name> <value>                         set a value of a record");
            System.out.println("delete <key>                                            delete a record");
            System.out.println("ret                                                     return to the LEVEL_SPACE");
            System.out.println("=====================================================================================");
        }
    }

    private void exec(String[] argv, int index) throws OmapException,
            IOException {
        int i = index;
        long starttime = System.currentTimeMillis();
        String cmd = argv[i++];
        if ("help".equals(cmd) || "h".equals(cmd)) {
            usage();
        } else if ("quit".equals(cmd) || "exit".equals(cmd)) {
            this.terminate = true;
        } else if ("open".equals(cmd)) {
            if (argv.length == 2) {
                this.open(new String[] {
                    argv[i++]
                });
            } else if (argv.length == 3) {
                this.open(new String[] {
                    argv[i++], argv[i++]
                });
            }
        } else if ("create".equals(cmd)) {
            if (argv.length == 3) {
                this.createTable(argv[i++], argv[i++]);
            } else {
                usage();
            }
        } else if ("delete".equals(cmd)) {
            if (argv.length == 2) {
                this.delete(argv[i++]);
            }
        } else if ("ret".equals(cmd)) {
            this.ret();
        } else if ("list".equals(cmd)) {
            this.list();
        } else if ("dump".equals(cmd)) {
            this.dump();
        } else if ("find".equals(cmd)) {
            if (argv.length == 2) {
                this.find(argv[i++]);
            } else if (argv.length == 3) {
                this.find(argv[i++], argv[i++]);
            } else {
                System.out.println("find <key> [num]");
                return;
            }
        } else if ("findr".equals(cmd)) {
            if (argv.length == 3) {
                this.findRange(argv[i++], argv[i++]);
            } else {
                System.out.println("findr <start key> <end key>");
                return;
            }
            // } else if ("findf".equals(cmd)) {
            // if (argv.length == 4) {
            // this.findInFamily(argv[i++], argv[i++], argv[i++]);
            // } else if (argv.length == 5) {
            // this.findInFamily(argv[i++], argv[i++], argv[i++], argv[i++]);
            // } else {
            // System.out
            // .println("findf <key> <column name> <column key> [num]");
            // return;
            // }
            // } else if ("findrf".equals(cmd)) {
            // if (argv.length == 5) {
            // this.findRangeInFamily(argv[i++], argv[i++], argv[i++],
            // argv[i++]);
            // } else {
            // System.out
            // .println("findrf <key> <column name> <column start key> <column
            // end key");
            // }
        } else if ("set".equals(cmd)) {
            if (argv.length == 3) {
                this.set(new String[] {
                    argv[i++], argv[i++]
                });
            } else if (argv.length == 4) {
                this.set(new String[] {
                    argv[i++], argv[i++], argv[i++]
                });
            }
        } else if ("snapshot".equals(cmd)) {
            if (argv.length >= 3) {
                if (argv.length > 3 && argv[3].equals("-nochkpt")) {
                    this.snapshot(argv[i++], argv[i++], false);
                } else {
                    this.snapshot(argv[i++], argv[i++], true);
                }
            }
        } else if ("import".equals(cmd)) {
            if (argv.length == 3) {
                this.importSnapshot(argv[i++], argv[i++]);
            }
        } else if ("test".equals(cmd)) {
            this.test();
        } else if (cmd == null) {
            // do nothing
        } else {
            System.out.println("Unknown command!!");
        }

        System.out.println("elapsed time: "
                + (System.currentTimeMillis() - starttime));
    }

}
