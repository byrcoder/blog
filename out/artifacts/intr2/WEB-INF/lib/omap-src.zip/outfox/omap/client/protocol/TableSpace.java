package outfox.omap.client.protocol;

import odis.serialize.IWritableComparable;
import outfox.omap.exceptions.OmapException;

/**
 * The Table Space is a flat name space to isolate the names of the Tables on a
 * OMAP instance. A Table must be within a Table Space.
 * 
 * @author yaming
 */
public interface TableSpace {

    /**
     * Get the name of the TableSpace
     * 
     * @return
     */
    public String getName();

    /**
     * Create a Table with the given tableName.
     * 
     * @param tableName
     * @param definition
     *            a string defines every column in the format: &quot;
     *            KEYCOLUMN_NAME:TYPE COLUMN1_NAME:TYPE COLUMN2_NAME:TYPE ...
     *            &quot;
     * @return
     * @throws outfox.omap.exceptions.OmapException
     */
    public Table createTable(String tableName, String definition)
            throws OmapException;

    /**
     * Create a Table with the given tableName, with queries.
     * 
     * @param tableName
     * @param definition
     *            a string defines every column in the format: &quot;
     *            KEYCOLUMN_NAME:TYPE COLUMN1_NAME:TYPE COLUMN2_NAME:TYPE ...
     *            &quot;
     * @param queries
     * @return
     * @throws outfox.omap.exceptions.OmapException
     */
    public Table createTable(String tableName, String definition,
            Query[] queries) throws OmapException;

    /**
     * Create a Table with the given tableName. Define the name and type of
     * every column. The first column is the key, by which the rows are sorted
     * in ascending order. The key can be also used in lookup.
     * 
     * @param tableName
     *            the name of the Table.
     * @param colNames
     *            The names of the columns.
     * @param colTypes
     *            The types of the columns. For types, see
     *            {@link outfox.omap.metadata.Types}
     * @throws OmapException
     */
    public Table createTable(String tableName, String colNames[],
            String colTypes[]) throws OmapException;

    /**
     * Create a Table with the given tableName. Define the name and type of
     * every column. The first column is the key, by which the rows are sorted
     * in ascending order. The key can be also used in lookup. The Queries will
     * be used to construct the index. More detail about Query can be found in
     * {@link outfox.omap.client.protocol.Query}
     * 
     * @param tableName
     *            the name of the Table
     * @param colNames
     *            the names of columns
     * @param colTypes
     *            the types of the columns. For types, see
     *            {@link outfox.omap.metadata.Types}
     * @param queries
     *            the queries to be supported by the new table
     * @throws OmapException
     * @return the valid table existed in the client
     * @author xingjk
     */
    public Table createTable(String tableName, String colNames[],
            String[] colTypes, Query[] queries) throws OmapException;

    /**
     * Return all the Metadatas of tables in this table space.
     * 
     * @return
     * @throws OmapException
     */
    public Metadata[] listTables() throws OmapException;

    /**
     * Return the table description if found, or null if not found. Find table
     * in this table space using the given tableName. Return the metadata of the
     * table if found.
     * 
     * @param tableName
     *            the name of the table
     * @return return the metadata of the table if the table if found in this
     *         table space, if not found, return null. See
     *         {@link outfox.omap.client.protocol.Metadata}
     * @throws OmapException
     */
    public Metadata findTable(String tableName) throws OmapException;

    /**
     * Delete the table with the given tableName in this table space.
     * 
     * @param tableName
     *            the name of the table
     * @throws OmapException
     */
    public void deleteTable(String tableName) throws OmapException;

    /**
     * Open the table with the given tableName in this tablespace, and return
     * it.
     * 
     * @param tableName
     *            the name of the table
     * @return the opened table as {@link outfox.omap.client.protocol.Table}
     * @throws OmapException
     */
    public Table openTable(String tableName) throws OmapException;

    /**
     * Open the table with the given tableName in this tablespace, and return
     * it.
     * 
     * @param tableName
     *            the name of the table;
     * @param timeout
     *            the operation timeout used by the returned Table
     * @return the opened table as {@link outfox.omap.client.protocol.Table}
     * @throws OmapException
     */
    public Table openTable(String tableName, long timeout) throws OmapException;

    /**
     * Snapshot a table of this table sapce to the targetDir of the file system
     * this omap used.
     * 
     * @param tableName
     *            the name of the table
     * @param targetDir
     *            the path of the directory store the snapshot data
     * @param checkpoint
     *            checkpoint before snapshot
     * @throws OmapException
     */
    public void snapshot(String tableName, String targetDir, boolean checkpoint)
            throws OmapException;

    /**
     * Import a table with the given table name from the snapshot data in
     * targetDir of the file system this omap used.
     * 
     * @param tableName
     *            the name of the table
     * @param targetDir
     *            the path of the directory of snapshot data.
     * @throws OmapException
     */
    public void importSnapshot(String tableName, String targetDir)
            throws OmapException;

    /**
     * Close this TableSpace.
     */
    public void close();

    /**
     * Create query condition
     */
    public QueryCondition createQueryCondition(String colName, QueryOperation op);

    public QueryCondition createQueryCondition(String colName,
            QueryOperation op, IWritableComparable para1);

    public QueryCondition createQueryCondition(String colName,
            QueryOperation op, IWritableComparable para1,
            IWritableComparable para2);

    /**
     * Create query
     */
    public Query createQuery(String queryName, QueryCondition[] conditions);

    public Query createQuery(String queryName, QueryCondition[] conditions,
            int offset);

    public Query createQuery(String queryName, QueryCondition[] conditions,
            int offset, int limit);

    /**
     * Rename a table in this namespace, index table can not be renamed.
     * 
     * @param originName
     *            table name without space
     * @param currName
     *            table name without space
     * @throws OmapException
     */
    public void renameTable(String originName, String currName)
            throws OmapException;
}
