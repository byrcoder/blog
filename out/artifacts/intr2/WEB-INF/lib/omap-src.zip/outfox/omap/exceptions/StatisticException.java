/**
 * @(#)StatisticException.java, 2010-10-14. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author wangfk
 */
public class StatisticException extends OmapException {

    private static final long serialVersionUID = 828917144054345364L;

    public StatisticException() {
        super();
    }

    public StatisticException(String message, Throwable cause) {
        super(message, cause);
    }

    public StatisticException(String message) {
        super(message);
    }

    public StatisticException(Throwable cause) {
        super(cause);
    }

}
