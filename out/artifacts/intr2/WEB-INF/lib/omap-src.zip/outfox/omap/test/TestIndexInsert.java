package outfox.omap.test;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.lib.IntWritable;
import outfox.omap.client.ClientConfig;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryCondition;
import toolbox.misc.LogFormatter;

public class TestIndexInsert {

    private static final Logger LOG = LogFormatter.getLogger(TestIndexInsert.class);

    private static final int COLUMN_MAX = 10;

    private static final String[] COLUMN_NAMES;

    private static final String[] COLUMN_TYPES;

    private static final String TABLE_NAME = "TestTable";

    private static final String TABLE_SPACE_NAME = "TestSpace";

    static {
        COLUMN_NAMES = new String[COLUMN_MAX];
        COLUMN_TYPES = new String[COLUMN_MAX];
        for (int i = 0; i < COLUMN_MAX; i++) {
            COLUMN_NAMES[i] = "COLUMN" + i;
            COLUMN_TYPES[i] = "INTEGER";
        }
    }

    private int seed;

    private int count;

    private WorkerThread[] initWorkers;

    private WorkerThread[] againWorkers;

    private int queryConditionCount;

    private int queryCount;

    public TestIndexInsert(int seed, int count, int workerNumber,
            int queryConditionCount, int queryCount) {
        if (queryConditionCount * queryCount >= COLUMN_MAX) {
            throw new IllegalArgumentException();
        }
        this.seed = seed;
        this.count = count;
        this.initWorkers = new WorkerThread[workerNumber];
        this.againWorkers = new WorkerThread[workerNumber];
        this.queryConditionCount = queryConditionCount;
        this.queryCount = queryCount;
    }

    private OmapQuery[] getQueries() {
        if (queryCount == 0 || queryConditionCount == 0) {
            return null;
        }
        OmapQuery[] queries = new OmapQuery[queryCount];
        for (int i = 0; i < queryCount; i++) {
            OmapQueryCondition[] qcs = new OmapQueryCondition[queryConditionCount];
            for (int j = 0; j < queryConditionCount; j++) {
                qcs[j] = new OmapQueryCondition(COLUMN_NAMES[i
                        * queryConditionCount + j + 1], QueryOperation.EQUAL);
            }
            queries[i] = new OmapQuery("QUERY" + i, qcs);
        }
        return queries;
    }

    private class WorkerThread extends Thread {
        private int id;

        private long totalResponseTime = 0;

        private long totalResponseTime2 = 0;

        private long maxResponseTime = 0;

        private AtomicLong periodResponseTime = new AtomicLong(0);

        private Table table;

        private Random keyRand = new Random();

        private Random dataRand = new Random();

        private AtomicInteger num = new AtomicInteger(0);

        public WorkerThread(int id, Table table, long seed) {
            this.id = id;
            this.table = table;
            keyRand.setSeed(seed);
        }

        @Override
        public void run() {
            LOG.info("Worker Thread " + id + " start");
            while (num.get() < count) {
                try {
                    int key = keyRand.nextInt();
                    Row row = table.newRow();
                    row.set(0, new IntWritable(key));
                    for (int i = 1; i < COLUMN_MAX; i++) {
                        row.set(i, new IntWritable(dataRand.nextInt()));
                    }
                    long start = System.currentTimeMillis();
                    table.update(row);
                    long end = System.currentTimeMillis();
                    long time = end - start;
                    if (time > maxResponseTime) {
                        maxResponseTime = time;
                    }
                    this.totalResponseTime += time;
                    this.totalResponseTime2 += time * time;
                    this.periodResponseTime.addAndGet(time);
                    num.incrementAndGet();
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "Worker Thread " + id
                            + " fail at round " + num, t);
                    System.exit(1);
                }
            }
            LOG.info("Worker Thread " + id + " end");
        }
    }

    private static class MonitorThread extends Thread {
        private WorkerThread[] workers;

        public MonitorThread(WorkerThread[] workers) {
            super("Monitor");
            this.workers = workers;
        }

        private volatile boolean stop = false;

        @Override
        public void run() {
            long currentNum = 0;
            long lastNum = 0;
            int zeroTimes = 0;
            while (!stop) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {}
                lastNum = currentNum;
                currentNum = 0;
                long periodResponseTime = 0;
                for (int i = 0; i < workers.length; i++) {
                    LOG.info("Worker" + i + ":" + workers[i].num.get());
                    currentNum += workers[i].num.get();
                    periodResponseTime += workers[i].periodResponseTime.getAndSet(0);
                }
                LOG.info("Total:" + currentNum);
                LOG.info("periodThroughput:" + (currentNum - lastNum));
                LOG.info("periodResponseTime:" + (double) periodResponseTime
                        / (currentNum - lastNum));
                if (currentNum - lastNum == 0) {
                    zeroTimes++;
                    if (zeroTimes >= 20) {
                        LOG.info("Long time zero");
                    }
                } else
                    zeroTimes = 0;
            }
        }
    }

    public void exec() throws Exception {
        TableSpace tableSpace = new OmapTableSpace(TABLE_SPACE_NAME,
                new MasterWatcherAndClientConfig(new ClientConfig("omap.xml")));
        if (tableSpace.findTable(TABLE_NAME) != null) {
            LOG.info("delete old table " + TABLE_NAME);
            tableSpace.deleteTable(TABLE_NAME);
        }
        LOG.info("create table " + TABLE_NAME + " with " + queryCount
                + " queries and " + queryConditionCount
                + " queryConditions for each query");
        Table table = tableSpace.createTable(TABLE_NAME, COLUMN_NAMES,
                COLUMN_TYPES, getQueries());
        Thread.sleep(10000);
        for (int i = 0; i < initWorkers.length; i++) {
            initWorkers[i] = new WorkerThread(i, table, (seed << 8 + i)
                    ^ (i << 16));
        }
        MonitorThread monitor = new MonitorThread(initWorkers);
        LOG.info("Start initial insert");
        long startTime = System.currentTimeMillis();
        for (WorkerThread worker: initWorkers) {
            worker.start();
        }
        LOG.info("Start Monitor Thread");
        monitor.start();
        for (WorkerThread worker: initWorkers) {
            worker.join();
        }
        long endTime = System.currentTimeMillis();
        LOG.info("End initial insert");
        LOG.info("Stop monitor Thread");
        monitor.stop = true;

        long totalResponseTime = 0;
        long totalResponseTime2 = 0;
        long maxResponseTime = 0;
        for (int i = 0; i < initWorkers.length; i++) {
            totalResponseTime += initWorkers[i].totalResponseTime;
            totalResponseTime2 += initWorkers[i].totalResponseTime2;
            if (initWorkers[i].maxResponseTime > maxResponseTime)
                maxResponseTime = initWorkers[i].maxResponseTime;

        }
        double totalTime = (double) (endTime - startTime) / 1000.0;
        LOG.info("Total time:" + totalTime);
        LOG.info("Average Throughput:" + (double) count * initWorkers.length
                / totalTime);
        LOG.info("Average Response Time:" + (double) totalResponseTime
                / (count * initWorkers.length));
        LOG.info("Max Response Time:" + (double) maxResponseTime / 1000.0);
        LOG.info("Theta="
                + Math.sqrt(totalResponseTime2 - (double) totalResponseTime
                        * totalResponseTime / (count * initWorkers.length))
                / 1000);

        for (int i = 0; i < againWorkers.length; i++) {
            againWorkers[i] = new WorkerThread(i, table, (seed << 8 + i)
                    ^ (i << 16));
        }
        monitor = new MonitorThread(againWorkers);
        LOG.info("Start insert again");
        startTime = System.currentTimeMillis();
        for (WorkerThread worker: againWorkers) {
            worker.start();
        }
        LOG.info("Start Monitor Thread");
        monitor.start();
        for (WorkerThread worker: againWorkers) {
            worker.join();
        }
        endTime = System.currentTimeMillis();
        LOG.info("end insert again");
        LOG.info("Stop monitor Thread");
        monitor.stop = true;
        totalResponseTime = 0;
        totalResponseTime2 = 0;
        maxResponseTime = 0;
        for (int i = 0; i < againWorkers.length; i++) {
            totalResponseTime += againWorkers[i].totalResponseTime;
            totalResponseTime2 += againWorkers[i].totalResponseTime2;
            if (againWorkers[i].maxResponseTime > maxResponseTime)
                maxResponseTime = againWorkers[i].maxResponseTime;

        }
        totalTime = (double) (endTime - startTime) / 1000.0;
        LOG.info("Total time:" + totalTime);
        LOG.info("Average Throughput:" + (double) count * againWorkers.length
                / totalTime);
        LOG.info("Average Response Time:" + (double) totalResponseTime
                / (count * againWorkers.length));
        LOG.info("Max Response Time:" + (double) maxResponseTime / 1000.0);
        LOG.info("Theta="
                + Math.sqrt(totalResponseTime2 - (double) totalResponseTime
                        * totalResponseTime / (count * againWorkers.length))
                / 1000);
    }

    public static void main(String[] args) throws Exception {
        new TestIndexInsert(Integer.parseInt(args[0]),
                Integer.parseInt(args[1]), Integer.parseInt(args[2]),
                Integer.parseInt(args[3]), Integer.parseInt(args[4])).exec();
    }

}
