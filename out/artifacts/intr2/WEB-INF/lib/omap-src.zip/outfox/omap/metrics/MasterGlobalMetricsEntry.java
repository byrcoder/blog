/**
 * @(#)MasterGlobalMetricsEntry.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.management.MemoryUsage;
import java.util.Arrays;

import outfox.omap.util.SystemInfoUtils;

import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class MasterGlobalMetricsEntry implements IWritable {

    private final long[] metricsRecords = new long[MasterMetricsType.globalTypeCount()];

    public synchronized void request() {
        metricsRecords[MasterMetricsType.GLOBAL_REQUEST_NUM.offset()]++;
    }

    public synchronized void requestTimeout() {
        metricsRecords[MasterMetricsType.GLOBAL_TIMEOUT_REQUEST_NUM.offset()]++;
    }

    public synchronized void getFsName(long delay) {
        metricsRecords[MasterMetricsType.GLOBAL_GET_FS_NAME_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GLOBAL_GET_FS_NAME_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.GLOBAL_LAST_GET_FS_NAME_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_FS_NAME_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void getTables(long delay) {
        metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.GLOBAL_LAST_GET_TABLES_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_TABLES_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void getTablesInSpace(long delay) {
        metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GLOBAL_GET_TABLES_IN_SPACE_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.GLOBAL_LAST_GET_TABLES_IN_SPACE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_TABLES_IN_SPACE_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void getTableSpaces(long delay) {
        metricsRecords[MasterMetricsType.GLOBAL_GET_TABLESPACES_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GLOBAL_GET_TABLESPACES_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.GLOBAL_LAST_GET_TABLESPACES_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_GET_TABLESPACES_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void createTable(long delay) {
        metricsRecords[MasterMetricsType.GLOBAL_CREATE_TABLE_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GLOBAL_CREATE_TABLE_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.GLOBAL_LAST_CREATE_TABLE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_CREATE_TABLE_COUNT.offset()
                + rangeOffset]++;
    }

    public synchronized void deleteTable(long delay) {
        metricsRecords[MasterMetricsType.GLOBAL_DELETE_TABLE_COUNT.offset()]++;
        metricsRecords[MasterMetricsType.GLOBAL_DELETE_TABLE_DELAY.offset()] += delay;

        metricsRecords[MasterMetricsType.GLOBAL_LAST_DELETE_TABLE_DELAY.offset()] = delay;

        int rangeOffset = TimeRangeUtils.getRangeOffset(delay);
        metricsRecords[MasterMetricsType.GLOBAL_TIME_RANGE_DELETE_TABLE_COUNT.offset()
                + rangeOffset]++;
    }
    
    public synchronized void copyToAndClear(MasterGlobalMetricsEntry entry) {
        entry.copyFields(this);
        Arrays.fill(metricsRecords, 0L);
    }

    public void updateSystemInfo() {
        metricsRecords[MasterMetricsType.GLOBAL_SYSTEM_LOAD.offset()] = (long) (SystemInfoUtils.getLoad() * 100);
        metricsRecords[MasterMetricsType.GLOBAL_PROCESSOR_NUM.offset()] = SystemInfoUtils.getProcessors();
        MemoryUsage memoryUsage = SystemInfoUtils.getMemoryUsage();
        metricsRecords[MasterMetricsType.GLOBAL_MEMORY_INIT.offset()] = memoryUsage.getInit();
        metricsRecords[MasterMetricsType.GLOBAL_MEMORY_USED.offset()] = memoryUsage.getUsed();
        metricsRecords[MasterMetricsType.GLOBAL_MEMORY_COMMITTED.offset()] = memoryUsage.getCommitted();
        metricsRecords[MasterMetricsType.GLOBAL_MEMORY_MAX.offset()] = memoryUsage.getMax();
    }

    public void setTableNumber(long number) {
        metricsRecords[MasterMetricsType.GLOBAL_TABLE_NUM.offset()] = number;
    }

    public void setTabletNumber(long number) {
        metricsRecords[MasterMetricsType.GLOBAL_TABLET_NUM.offset()] = number;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        MasterGlobalMetricsEntry that = (MasterGlobalMetricsEntry) value;
        System.arraycopy(that.metricsRecords, 0, metricsRecords, 0,
                metricsRecords.length);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        for (long metricsRecord: metricsRecords) {
            out.writeLong(metricsRecord);
        }

    }

    @Override
    public void readFields(DataInput in) throws IOException {
        for (int i = 0; i < metricsRecords.length; i++) {
            metricsRecords[i] = in.readLong();
        }
    }

    public long[] getMetricsRecords() {
        return metricsRecords;
    }

}
