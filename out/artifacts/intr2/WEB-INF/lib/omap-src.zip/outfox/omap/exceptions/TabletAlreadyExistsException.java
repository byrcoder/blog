/**
 * @(#)TabletAlreadyExistsException.java, 2009-3-30. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author zhangkun
 */
public class TabletAlreadyExistsException extends Exception {
    private static final long serialVersionUID = 6793242562109214541L;

    public TabletAlreadyExistsException(String msg) {
        super(msg);
    }
}
