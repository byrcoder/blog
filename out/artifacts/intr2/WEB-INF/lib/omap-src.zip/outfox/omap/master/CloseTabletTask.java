/**
 * @(#)CloseTabletTask.java, 2010-11-03. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master;

import outfox.omap.ts.LoadValue;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.Path;
import odis.serialize.IWritable;
import outfox.omap.common.TsDesc;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.KeyRange;
import outfox.omap.exceptions.TabletAlreadyExistsException;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.Tablet;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class CloseTabletTask extends Task {

    private static final Logger LOG = LogFormatter.getLogger(CloseTabletTask.class);

    long tabletId;

    TsDesc migrateFrom;

    TsDesc migrateTo;

    KeyRange kr;

    final LoadValue load = new LoadValue();

    boolean removeCatalogue;

    /**
     * Empty constructor, should only be used before copyFields() or
     * readFields()
     */
    public CloseTabletTask() {

    }

    public CloseTabletTask(long tabletId, TsDesc migrate_from,
            TsDesc migrate_to, LoadValue load, boolean removeCatalogue,
            String reason) {
        super(reason);
        this.tabletId = tabletId;
        this.migrateFrom = migrate_from;
        this.migrateTo = migrate_to;
        this.load.copyFields(load);
        this.removeCatalogue = removeCatalogue;
    }

    @Override
    public String getTaskDetail() {
        return "CLOSE: " + HexString.longToPaddedHex(this.tabletId)
                + ", MIGRATE: from " + this.migrateFrom + " to "
                + this.migrateTo;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        super.copyFields(value);
        CloseTabletTask v = (CloseTabletTask) value;
        tabletId = v.tabletId;
        if (v.migrateTo != null) {
            if (migrateTo == null)
                migrateTo = new TsDesc();
            migrateTo.copyFields(v.migrateTo);
        } else {
            migrateTo = null;
        }
        if (v.migrateFrom != null) {
            if (migrateFrom == null)
                migrateFrom = new TsDesc();
            migrateFrom.copyFields(v.migrateFrom);
        } else {
            migrateFrom = null;
        }
        kr = new KeyRange();
        kr.copyFields(v.kr);
        load.copyFields(v.load);
        removeCatalogue = v.removeCatalogue;
        return this;
    }

    @Override
    public int execTask(OmapTs ts) {
        if (this.migrateTo != null) {
            try {
                this.kr = ts.closeTabletForMigration(this.tabletId,
                        this.migrateTo);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "close tablet for migration failed", e);
                return -1;
            }
        } else {
            try {
                this.kr = ts.closeTablet(this.tabletId);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "close tablet for failed", e);
                return -1;
            }
        }
        return 0;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        this.tabletId = in.readLong();
        boolean hasMigrate = in.readBoolean();
        if (hasMigrate) {
            migrateTo = new TsDesc();
            migrateTo.readFields(in);
        } else {
            migrateTo = null;
        }

        migrateFrom = new TsDesc();
        migrateFrom.readFields(in);

        boolean hasKr = in.readBoolean();
        if (hasKr) {
            kr = new KeyRange();
            kr.readFields(in);
        } else {
            kr = null;
        }
        load.readFields(in);
        removeCatalogue = in.readBoolean();
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        out.writeLong(tabletId);
        out.writeBoolean(migrateTo != null); // has_migrate
        if (migrateTo != null) {
            migrateTo.writeFields(out);

        }
        migrateFrom.writeFields(out);
        out.writeBoolean(kr != null); // has_kr
        if (kr != null) {
            kr.writeFields(out);
        }
        load.writeFields(out);
        out.writeBoolean(removeCatalogue);
    }

    public void rollbackTask(OmapTs ts) throws IOException {
        if (kr != null) {
            LOG.info("Rollback: putting " + kr + " back");
            Path tabletPath = new Path(OmapUtils.getSSTableFileDirPath(
                    OmapConfig.getTsTabletDir(), kr.getTabletId()));
            if (!ts.getFs().exists(tabletPath)) {
                LOG.warning(kr + " is already deleted, no need to put back");
                return;
            }
            Tablet tablet = new Tablet(kr, ts, false);
            tablet.setLoadFromLoadValue(load);
            tablet.getLoadValue().copyFields(load);
            try {
                ts.addTablet(tablet);
            } catch (TabletAlreadyExistsException e) {
                LOG.log(Level.WARNING, kr + " exists, no need to add back", e);
            }
        } else {
            LOG.warning("keyrange is null, cannot put "
                    + HexString.longToPaddedHex(tabletId) + " back");
        }
    }

}
