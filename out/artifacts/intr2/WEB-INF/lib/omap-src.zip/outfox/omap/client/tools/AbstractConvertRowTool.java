/**
 * @(#)AbstractConvertRowTool.java, 2010-7-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.tools;

import outfox.omap.data.DataRow;
import outfox.omap.metadata.ColumnDesc;
import outfox.omap.metadata.TableDesc;

/**
 * @author zhangduo
 */
public abstract class AbstractConvertRowTool {

    protected TableDesc srcTableDesc;

    protected TableDesc dstTableDesc;

    protected DataRow dstDataRow;

    public void prepare(TableDesc srcTableDesc, TableDesc dstTableDesc) {
        this.srcTableDesc = srcTableDesc;
        this.dstTableDesc = dstTableDesc;
        dstDataRow = dstTableDesc.createDataRow();
    }

    private void fillExistRow(DataRow row) {
        ColumnDesc[] columns = srcTableDesc.getColumns();
        for (int i = 0; i < columns.length; i++) {
            int templateIndex = dstTableDesc.getColumnIndex(columns[i].getName());
            if (templateIndex >= 0) {
                dstDataRow.setIWritable(templateIndex, row.getIWritable(i));
            }
        }
    }

    public DataRow convert(DataRow row) {
        fillExistRow(row);
        fillNewColumn(row);
        return dstDataRow;
    }

    abstract protected void fillNewColumn(DataRow row);

}
