/**
 * @(#)TestDiff2.java, 2011-11-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.test;

import java.io.PrintWriter;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;
import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;

/**
 * @author wangfk
 */
public class TestDiff2 {

    public static void main(String[] args) throws Exception {
        if (args.length != 2 && args.length != 3) {
            System.err.println("USAGE: TestDiff2 <table1> <table2> [out file]");
            return;
        }
        DataSource dataSource = DataSourceFactory.getNamed(DataSourceFactory.NAME_OMAP_DATA_SOURCE);
        String tableSpace1 = args[0].split("\\$")[0];
        String tableSpace2 = args[1].split("\\$")[0];
        String tableName1 = args[0].split("\\$")[1];
        String tableName2 = args[1].split("\\$")[1];

        PrintWriter pw;
        if (args.length >= 3) {
            pw = new PrintWriter(args[2]);
        } else {
            pw = new PrintWriter(System.out);
        }

        Table table1 = dataSource.openTableSpace(tableSpace1).openTable(
                tableName1);
        Table table2 = dataSource.openTableSpace(tableSpace2).openTable(
                tableName2);

        TableCursor tableCursor1 = table1.getTableCursor();
        TableCursor tableCursor2 = table2.getTableCursor();

        IntWritable key1 = new IntWritable();
        IntWritable key2 = new IntWritable();
        StringWritable value1 = new StringWritable();
        StringWritable value2 = new StringWritable();

        tableCursor1.reset();
        tableCursor2.reset();
        tableCursor1.setPrefetch(20);
        tableCursor2.setPrefetch(20);

        Row row1 = table1.newRow();
        Row row2 = table2.newRow();

        boolean theEnd1 = !tableCursor1.next(row1);
        boolean theEnd2 = !tableCursor2.next(row2);

        while (!theEnd1 || !theEnd2) {
            row1.get(0, key1);
            row2.get(0, key2);
            row1.get(1, value1);
            row2.get(1, value2);
            int compareV = key1.compareTo(key2);
            if (compareV == 0) {
                theEnd1 = !tableCursor1.next(row1);
                theEnd2 = !tableCursor2.next(row2);
                if (value1.compareTo(value2) != 0) {
                    pw.println(key1.get() + "\t" + value1.get() + "\t"
                            + value2.get());
                }
            } else if (compareV < 0) {
                pw.println(key1.get() + "\t" + value1.get() + "\tNULL");
                theEnd1 = !tableCursor1.next(row1);

            } else if (compareV > 0) {
                pw.println(key2.get() + "\tNULL\t" + value2.get());
                theEnd2 = !tableCursor2.next(row2);
            }
            pw.flush();
        }

        if (args.length >= 3) {
            pw.close();
        }
    }

}
