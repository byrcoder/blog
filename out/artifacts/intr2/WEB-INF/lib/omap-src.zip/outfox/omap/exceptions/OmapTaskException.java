/**
 * @(#)OmapTaskException.java, 2011-5-24. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author zhangduo
 */
public class OmapTaskException extends OmapException {

    private static final long serialVersionUID = -2525298628019606064L;

    public OmapTaskException() {
        super();
    }

    public OmapTaskException(String message, Throwable cause) {
        super(message, cause);
    }

    public OmapTaskException(String message) {
        super(message);
    }

    public OmapTaskException(Throwable cause) {
        super(cause);
    }

}
