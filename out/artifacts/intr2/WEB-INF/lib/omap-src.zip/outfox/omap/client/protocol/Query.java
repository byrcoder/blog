/**
 * @(#)Query.java, Oct 7, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol;

/**
 * <p>
 * A Query contains a set of QueryConditions, behaving like the <i>where</i>
 * statement of SQL. The execution of Query has to be supported by index, which
 * is created during table's construction. The link between a collection of
 * Query objects and a Table object is immutable.
 * </p>
 * <p>
 * Because OMap is not a relational DB, the query have several limits. These
 * limits can be found in
 * {@link outfox.odis.omap.client.protocol.QueryCondition}. All the query
 * conditions are considered as being linked by "AND". Users should take the
 * union by themselves when they want "OR".
 * </p>
 * <p>
 * After the execution of a query, a set of rows representing query result are
 * returned, which are ordered in the index. As default, all the result rows are
 * sent to the users. However, the users can set offset and limit to get part of
 * rows.
 * </p>
 * 
 * @author xingjk
 */
public interface Query {

    /**
     * return the first condition.<br>
     * this is useful when Query contains only one QueryCondition.
     * 
     * @return
     */

    public QueryCondition getFirstCondition();

    /**
     * Get the query condition by its specified column name
     * 
     * @param colName
     */
    public QueryCondition getCondition(String colName);

    /**
     * Get query's name
     * 
     * @return the query's name
     */
    public String getName();

    /**
     * Set the query's offset
     * 
     * @param offset
     *            the offset
     * @return
     */
    public void setOffset(int offset);

    /**
     * Get the offset of this query
     */
    public int getOffset();

    /**
     * Set the limit of this query
     */
    public void setLimit(int limit);

    /**
     * Get the limit of this query
     */
    public int getLimit();

    /**
     * Check whether two queries are compitable
     * 
     * @param query
     *            another query
     * @return the check result
     */
    public boolean isCompitable(Query query);

}
