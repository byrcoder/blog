/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.client.protocol;

import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapUtils;

/**
 *
 * @author zhangkun
 */
public abstract class AbstractTableSpace implements TableSpace {
    public static final String NAME_TYPE_SEPARATOR = ":";
    public Table createTable(String tableName, String definition)
            throws OmapException {
        return createTable(tableName, definition, null);
    }

    public Table createTable(String tableName, String[] colNames,
            String[] colTypes) throws OmapException {
        return createTable(tableName, colNames, colTypes, null);
    }
    
    public Table createTable(String tableName, String definition,
            Query[] queries) throws OmapException {
        String[][] parsedDef = OmapUtils.parseTableDefinition(definition);
        return createTable(tableName, parsedDef[0], parsedDef[1], queries);
    }

}
