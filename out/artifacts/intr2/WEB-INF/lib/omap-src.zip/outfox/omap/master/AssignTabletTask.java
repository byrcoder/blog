package outfox.omap.master;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import outfox.omap.client.OmapMetadata;
import outfox.omap.common.TsDesc;
import outfox.omap.data.KeyRange;
import outfox.omap.ts.LoadValue;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.Tablet;
import outfox.omap.ts.insertlog.InsertLogger;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * Describe a task of assigning multiple tablets to a ts can optionally specify
 * a log file to recover writebuf from includes key range, schema.
 * 
 * @author jimmysu, xuw
 */
public class AssignTabletTask extends Task {

    private static Logger LOG = LogFormatter.getLogger(AssignTabletTask.class.getName());

    private OmapMetadata metadata;

    private KeyRange kr;

    private LoadValue tabletLoad;

    private String logRoot;

    private boolean recover = false;

    /**
     * Empty constructor, should only be used before copyFields() or
     * readFields()
     */
    public AssignTabletTask() {

    }

    public boolean needRecover() {
        return recover;
    }

    public OmapMetadata getMetadata() {
        return metadata;
    }

    public KeyRange getKr() {
        return kr;
    }

    public LoadValue getTabletLoad() {
        return tabletLoad;
    }

    public String getLogRoot() {
        return logRoot;
    }

    public boolean isRecover() {
        return recover;
    }

    /**
     * Assign a Tablet to a TS.
     * 
     * @param schemaId
     * @param kr
     * @param logRoot
     *            if not null, this should be the path of origin TS log root
     * @param reason
     */
    public AssignTabletTask(KeyRange kr, OmapMetadata metadata, String logRoot,
            LoadValue loadValue, String reason) {
        super(reason);
        this.metadata = metadata;
        this.kr = kr;
        this.logRoot = logRoot;
        if (logRoot != null) {
            this.recover = true;
        } else {
            this.recover = false;
        }
        this.tabletLoad = loadValue;
    }

    public TsDesc getAssignedTs() {
        return kr.getTsDesc();
    }

    public void reassignTs(TsDesc ts, String reason) {
        LOG.info("Reassigning to new TS: " + ts + ", reason=\"" + reason + "\"");
        kr.setTsDesc(ts);
        this.reason = reason;
        doneTime = -1;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        AssignTabletTask v = (AssignTabletTask) value;
        if (v.metadata == null) {
            metadata = null;
        } else {
            if (metadata == null) {
                metadata = new OmapMetadata();
            }
            metadata.copyFields(v.metadata);
        }
        if (v.kr == null) {
            kr = null;
        } else {
            if (kr == null) {
                kr = new KeyRange();
            }
            kr.copyFields(v.kr);
        }
        if (v.tabletLoad == null) {
            tabletLoad = null;
        } else {
            if (tabletLoad == null) {
                tabletLoad = new LoadValue();
            }
            tabletLoad.copyFields(v.tabletLoad);
        }
        logRoot = v.logRoot;
        recover = v.recover;
        return super.copyFields(value);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        super.readFields(in);
        if (metadata == null) {
            metadata = new OmapMetadata();
        }
        // this should not cause RPC calls as it should be cached everywhere..
        metadata.readFields(in);
        if (kr == null) {
            kr = new KeyRange();
        }
        kr.readFields(in);
        if (tabletLoad == null) {
            tabletLoad = new LoadValue();
        }
        tabletLoad.readFields(in);
        recover = in.readBoolean();
        if (recover) {
            logRoot = StringWritable.readString(in);
        }

    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        super.writeFields(out);
        metadata.writeFields(out);
        kr.writeFields(out);
        tabletLoad.writeFields(out);
        out.writeBoolean(recover);
        if (recover) {
            StringWritable.writeString(out, logRoot);
        }
    }

    // return 0 means success, return -1 means I was already managed this 
    // tablet, less than -1 means task failed.
    public int execTask(OmapTs ts) {
        ConcurrentMap<Long, Tablet> tablets = ts.getTablets();
        if (tablets.containsKey(kr.getTabletId())) {
            LOG.warning(kr + " is already managed by me");
            return -1;
        }
        Tablet tablet = null;
        try {
            ts.getMetaCache().addMetadata(metadata);
            tablet = new Tablet(kr, ts, recover);
            tablet.setLoadFromLoadValue(tabletLoad);
            ts.addTablet(tablet);
            if (recover) {
                recoverFromLog(ts);
            }
            tablet.doneRecovery();
            return 0;
        } catch (Throwable t) {
            LOG.log(Level.WARNING, "assign tablet failed", t);
            AlertUtils.alert(HexString.longToPaddedHex(kr.getTabletId())
                    + " assign to " + ts.getTsName() + " failed",
                    OmapUtils.getStackTrace(t), false, true);
            return -2;
        }
    }

    /**
     * Recover the TS from the given log
     * 
     * @param ts
     * @param log
     * @throws IOException
     */
    private void recoverFromLog(OmapTs ts) throws IOException {
        IFileSystem fs = ts.getFs();
        LOG.info("need to recover "
                + HexString.longToPaddedHex(kr.getTabletId()));
        boolean succ;
        InsertLogger logger = new InsertLogger(new Path(logRoot), fs, true);
        try {
            logger.recoverTablet(ts, kr.getTabletId());
            succ = true;
        } catch (IOException e) {
            LOG.warning("There are exceptions while recover tablet "
                    + HexString.longToPaddedHex(kr.getTabletId())
                    + ", may loss data");
            succ = false;
        }

        // check point new tablets.. this removes dependencies on the previous
        // logs
        LOG.info("checkpointing recovered tablet "
                + HexString.longToPaddedHex(kr.getTabletId()));
        ts.checkpoint(kr.getTabletId());
        // do not remove recovering log when recover failed
        // we may recover it manually
        if (succ) {
            //remove recovering log file
            logger.doneRecoverTablet(kr.getTabletId());
        }
    }

    @Override
    public String getTaskDetail() {
        return "ASSIGN: " + kr + " (" + logRoot + ") " + tabletLoad;
    }

    public void rollbackTask(OmapTs ts) {

    }

    public boolean hasIndexTablet() {
        return OmapUtils.isIndexTable(metadata.getInternalTableName());
    }
}
