/**
 * @(#)ClientMasterProtocol.java, 2011-1-12. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap;

import java.io.IOException;

import odis.rpc2.RpcException;
import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.exceptions.OmapException;
import outfox.omap.ts.LoadValue;
import outfox.omap.util.TableConfig;

/**
 * @author zhihua, xuw, zhangduo
 */
public interface ClientMasterProtocol {

    /**
     * The first step of importing sequence file to OMAP. Create a Table that is
     * ready to import data from sequence file.
     * 
     * @param tableName
     * @param col_name
     * @param col_type
     * @return
     * @throws OmapException
     * @throws RpcException
     * @throws IOException
     */
    TableConfig createImportedTable(String tableName, String col_name,
            String col_type, OmapQuery[] queries) throws OmapException,
            RpcException, IOException;

    /**
     * The second step of importing sequence file to OMAP. Create Tablets backed
     * by already created SSTableFiles, and assign them to TSes.
     * 
     * @param schemaId
     * @param keyRanges
     * @param waitForTabletsAssigned
     * @throws RpcException
     * @throws OmapException
     * @throws IOException
     */
    void assignTabletsForImportedTable(long schemaId, KeyRange[] keyRanges,
            boolean waitForTabletsAssigned) throws RpcException, OmapException,
            IOException;

    /**
     * create one table; return NULL if failed.
     * 
     * @param table
     *            name, string representation of column names, string
     *            representation of column types
     * @return void
     * @throws OmapException
     * @throws RpcException
     * @throws IOException
     */
    void createTable(String tableName, String col_name, String col_type,
            OmapQuery[] queries) throws OmapException, RpcException,
            IOException;

    /**
     * @param properties
     * @throws RpcException
     */
    void setTableProperties(long schemaId, String[] properties)
            throws RpcException, IOException;

    /**
     * delete a single table. if delete more than one, we can do it one by one
     * at client; Efficiency of delete is not much important.
     * 
     * @return integer status
     * @throws OmapException
     * @throws IOException
     */
    void deleteTable(String tableName) throws OmapException, RpcException,
            IOException;

    /**
     * Rename a Table
     * 
     * @param originName
     *            table origin name with namespace
     * @param currName
     *            table current name with namespace
     * @throws OmapException
     * @throws RpcException
     * @throws IOException
     */
    void renameTable(String originName, String currName) throws OmapException,
            RpcException, IOException;

    /**
     * Snapshot a Table, save the data of a Table at the moment to a directory
     * which can be used to restore the whole data of the Table in the future.
     * 
     * @param tableName
     *            the Table to be snapshot
     * @param targetDir
     * @param checkpoint
     *            if true, will checkpoint before snapshot
     * @throws IOException
     */
    void snapshot(String tableName, String targetDir, boolean checkpoint)
            throws IOException, RpcException;

    /**
     * Import a saved snapshot into OMAP. Will create a new Table and import the
     * data from the snapshot.
     * 
     * @param tableName
     *            the name of the created table
     * @param dir
     *            the snapshot dir
     * @throws OmapException
     */
    void importSnapshot(String tableName, String dir) throws OmapException,
            RpcException;

    /**
     * Return the name of the filesystem master used.
     */
    String getFsName() throws RpcException;

    /**
     * lookup: look for key in table
     * 
     * @param tablename
     * @param key
     * @param prefetch_hint
     *            is a hint to the master how many continuous keys will be
     *            fetched
     * @return a sorted list of keyrange to ts mappings.
     */
    KeyRangeList lookupKey(String tableName, ByteArrayWritable key,
            int prefetch_hint) throws RpcException, IOException;

    /**
     * list all tables
     * 
     * @return
     * @throws RpcException
     */
    OmapMetadata[] getTables() throws RpcException;

    /**
     * list all tables under table space.
     * 
     * @param tableSpaceName
     * @return
     * @throws RpcException
     */
    OmapMetadata[] getTables(String tableSpaceName) throws RpcException;

    /**
     * list all table spaces.
     * 
     * @return
     * @throws RpcException
     */
    String[] getTableSpaces() throws RpcException;

    /**
     * get metadata for given table
     * 
     * @param schemaId
     * @return
     * @throws RpcException
     */
    OmapMetadata getMetadata(long schemaId) throws RpcException;

    /**
     * get schemaid for given table
     * 
     * @param tableName
     * @return
     * @throws RpcException
     */
    long getSchemaId(String tableName) throws RpcException;

    /**
     * Get the current load value of a Table
     * 
     * @param tableName
     * @return
     */
    @Deprecated
    LoadValue getTableLoad(String tableName) throws RpcException;

    /**
     * Do not supported, use acl instead.
     * 
     * @param schemaId
     * @param readOnly
     * @throws RpcException
     */
    @Deprecated
    void setReadOnly(long schemaId, boolean readOnly) throws RpcException;

    /**
     * Get service config and ts information.
     * 
     * @return
     * @throws RpcException
     */
    String dumpServiceConfigurations() throws RpcException;

    /**
     * not implemented.
     */
    @Deprecated
    void invokeTsMethod(String methodName, IWritable[] parameters)
            throws RpcException;

    /**
     * Reserve WALog for incremental backup
     * 
     * @param tableName
     * @param targetDir
     *            the target dir for WALog Reserving
     * @throws RpcException
     * @throws IOException
     */
    void reserveTableWALog(String tableName, String targetDir)
            throws RpcException, IOException;

    void stopReserveTableWALog(String tableName) throws RpcException,
            IOException;
}
