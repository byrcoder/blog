/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

import java.util.ArrayList;
import java.util.Random;
import toolbox.text.util.HexString;

/**
 * Generates and manages record keys for workload.
 * 
 * @author zhangkun
 */
public class KeyGenerator {
    final long initialNumRecords;

    final ArrayList<String> writtenKeys;

    final Random rand = new Random(System.currentTimeMillis());

    private int maxWrittenKeysRecord;

    private boolean readNewRowOnly;

    public KeyGenerator(long initialNumRecords, int maxWrittenKeysRecord,
            boolean readNewRowOnly) {
        this.initialNumRecords = initialNumRecords;
        writtenKeys = new ArrayList<String>(maxWrittenKeysRecord);
        this.maxWrittenKeysRecord = maxWrittenKeysRecord;
        this.readNewRowOnly = readNewRowOnly;
    }

    public long getNumOfKeys() {
        return this.initialNumRecords + writtenKeys.size();
    }

    /**
     * Get a key that exists. If index &lt; initialNumRecords, an initial key
     * will be returned. Otherwise, a key that was generated and stored earlier
     * by {@link #getWorkloadKey(double, boolean)} will be returned.
     * 
     * @param index
     * @return
     */
    public synchronized String getExistingKey(long index, boolean getNewRowOnly) {
        if (index < 0 || index >= getNumOfKeys()) {
            throw new IndexOutOfBoundsException("key index " + index
                    + " out of bounds [0," + getNumOfKeys() + ")");
        }
        if (getNewRowOnly && !writtenKeys.isEmpty()) {
            return writtenKeys.get((int) (index % writtenKeys.size()));
        }
        if (index < initialNumRecords) {
            return HexString.longToPaddedHex(index);
        } else {
            return writtenKeys.get((int) (index - initialNumRecords));
        }
    }

    /**
     * Get a key for read or write.
     * 
     * @param hitRate
     *            the chance that the returned key is an existing key.
     * @param storeNewKey
     *            If a new key is returned and this is set to true, the new key
     *            will be added to the list of existing keys.
     * @return
     */
    public synchronized String getWorkloadKey(double hitRate, boolean read) {
        long numKeys = getNumOfKeys();
        long index = Math.abs(rand.nextLong()) % numKeys;
        if (index < 0) {
            index = 0;
        }
        if (rand.nextDouble() < hitRate) {
            // hit, choose a key that already exists
            return getExistingKey(index, read && readNewRowOnly);
        }
        // miss, generate a key evenly distributed in the existing keys
        return getExistingKey(index, false) + "#"
                + HexString.intToPaddedHex(rand.nextInt());
    }

    public synchronized void doneWorkloadKey(String key) {
        if (writtenKeys.size() == maxWrittenKeysRecord) {
            int index = rand.nextInt(maxWrittenKeysRecord);
            writtenKeys.set(index, key);
        } else {
            writtenKeys.add(key);
        }
    }
}
