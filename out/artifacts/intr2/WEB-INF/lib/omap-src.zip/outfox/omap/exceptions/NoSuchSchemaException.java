package outfox.omap.exceptions;

public class NoSuchSchemaException extends RuntimeException {

    private static final long serialVersionUID = -2773126384435202855L;

    public NoSuchSchemaException() {
        super();
    }

    public NoSuchSchemaException(String message) {
        super(message);
    }

}
