/**
 * @(#)StoreCursor.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.util.MiscUtils;

/**
 * @author zhangduo
 */
public class StoreCursor<K extends IWritableComparable, V extends IWritable>
        implements Cursor<K, Store<K, V>.Value> {

    private List<Cursor<K, Store<K, V>.Value>> cursors = new ArrayList<Cursor<K, Store<K, V>.Value>>();

    private static class PQElement<K extends IWritableComparable, V extends IWritable> {
        K key;

        Store<K, V>.Value value;

        int idx;

        public PQElement(K key, Store<K, V>.Value value, int idx) {
            this.key = key;
            this.value = value;
            this.idx = idx;
        }
    }

    private static class PQElementComparator<K extends IWritableComparable, V extends IWritable>
            implements Comparator<PQElement<K, V>>, Serializable {

        private static final long serialVersionUID = -7824869379854262344L;

        @Override
        public int compare(PQElement<K, V> o1, PQElement<K, V> o2) {
            int ret = o1.key.compareTo(o2.key);
            return ret == 0 ? o1.idx - o2.idx : ret;
        }

    }

    private PriorityQueue<PQElement<K, V>> pQueue;

    public void add(Cursor<K, Store<K, V>.Value> cursor) {
        cursors.add(cursor);
    }

    private void fillQueue(int idx, K key, Store<K, V>.Value value)
            throws IOException {
        Cursor<K, Store<K, V>.Value> cursor = cursors.get(idx);
        while (true) {
            if (cursor.next(key, value)) {
                pQueue.add(new PQElement<K, V>(key, value, idx));
            }
            break;
        }
    }

    public void init(List<K> keys, List<Store<K, V>.Value> values)
            throws IOException {
        pQueue = new PriorityQueue<PQElement<K, V>>(cursors.size(),
                new PQElementComparator<K, V>());
        for (int i = 0; i < cursors.size(); i++) {
            fillQueue(i, keys.get(i), values.get(i));
        }
    }

    public boolean next(K key, Store<K, V>.Value value) throws IOException {
        if (pQueue.isEmpty()) {
            return false;
        }

        PQElement<K, V> element = pQueue.poll();
        K k = element.key;
        Store<K, V>.Value v = element.value;
        key.copyFields(k);
        value.copyFields(v);
        fillQueue(element.idx, k, v);
        while (!pQueue.isEmpty() && pQueue.peek().key.compareTo(key) == 0) {
            PQElement<K, V> e = pQueue.poll();
            fillQueue(e.idx, e.key, e.value);
        }
        return true;
    }

    @Override
    public void close() throws IOException {
        for (Cursor<K, Store<K, V>.Value> cursor: cursors) {
            MiscUtils.safeClose(cursor);
        }
    }
}
