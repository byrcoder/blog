/**
 * @(#)TimeRangeUtils.java, 2011-6-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics;

import java.util.Arrays;

/**
 * An logarithmic time range with left include and right exclude.
 * 
 * @author zhangduo
 */
public class TimeRangeUtils {

    // do not use range [0,1) because it is useless.
    private static final long[] RANGE = new long[] {
        0, 10, 100, 1000, 10000
    };

    public static int rangeCount() {
        return RANGE.length;
    }

    public static int getRangeOffset(long value) {
        if (value < 0) {
            throw new IllegalArgumentException("value " + value
                    + " is less than 0");
        }
        int offset = Arrays.binarySearch(RANGE, value);
        if (offset >= 0) {
            return offset;
        }
        return -offset - 2;
    }
}
