/**
 * @(#)MasterTsProtocol.java, 2011-5-23. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.common;

import odis.rpc2.RpcException;
import outfox.omap.master.Task;

/**
 * The protocol master used to communicate with ts.
 * 
 * @author zhangduo
 */
public interface MasterTsProtocol {
    /**
     * Assign a task to ts.
     * <p>
     * <strong>NOTE:</strong> this method should return immediately. Ts should
     * execute the task in a background thread, and notify master using
     * {@link TsMasterProtocol#tsTaskDone(Task, TsDesc)} when the task is done.
     * </p>
     * 
     * @param task
     * @throws RpcException
     */
    void assignTask(Task[] tasks) throws RpcException;
}
