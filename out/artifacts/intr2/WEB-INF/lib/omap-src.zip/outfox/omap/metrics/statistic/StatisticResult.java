/**
 * @(#)StatisticResult.java, 2011-6-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.collections.Pair;

/**
 * @author zhangduo
 */
public class StatisticResult implements IWritable {

    private final Pair<double[], double[]> masterStatisticResults;

    private final Pair<double[], double[]> totalTsStatisticResults;

    private final Map<String, Pair<double[], double[]>> tsStatisticResults;

    private final Map<Long, double[]> tableStatisticResults;

    public StatisticResult() {
        masterStatisticResults = new Pair<double[], double[]>(
                new double[MasterGlobalStatisticType.getTypeCount()],
                new double[MasterTableStatisticType.getTypeCount()]);
        totalTsStatisticResults = new Pair<double[], double[]>(
                new double[TsGlobalStatisticType.getTypeCount()],
                new double[TsTabletStatisticType.getTypeCount()]);
        tsStatisticResults = new TreeMap<String, Pair<double[], double[]>>();
        tableStatisticResults = new TreeMap<Long, double[]>();
    }

    public StatisticResult(Pair<double[], double[]> masterStatisticResults,
            Pair<double[], double[]> totalTsStatisticResults,
            Map<String, Pair<double[], double[]>> tsStatisticResults,
            Map<Long, double[]> tableStatisticResults) {
        this.masterStatisticResults = masterStatisticResults;
        this.totalTsStatisticResults = totalTsStatisticResults;
        this.tsStatisticResults = tsStatisticResults;
        this.tableStatisticResults = tableStatisticResults;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        StatisticResult that = (StatisticResult) value;
        System.arraycopy(that.masterStatisticResults.getFirst(), 0,
                masterStatisticResults.getFirst(), 0,
                MasterGlobalStatisticType.getTypeCount());
        System.arraycopy(that.masterStatisticResults.getSecond(), 0,
                masterStatisticResults.getSecond(), 0,
                MasterTableStatisticType.getTypeCount());
        System.arraycopy(that.totalTsStatisticResults.getFirst(), 0,
                masterStatisticResults.getFirst(), 0,
                MasterGlobalStatisticType.getTypeCount());
        System.arraycopy(that.totalTsStatisticResults.getSecond(), 0,
                masterStatisticResults.getSecond(), 0,
                MasterTableStatisticType.getTypeCount());
        tsStatisticResults.clear();
        for (Map.Entry<String, Pair<double[], double[]>> entry: that.tsStatisticResults.entrySet()) {
            double[] tsGlobalStatisticResults = Arrays.copyOf(
                    entry.getValue().getFirst(),
                    TsGlobalStatisticType.getTypeCount());
            double[] tsTabletStatisticResults = Arrays.copyOf(
                    entry.getValue().getSecond(),
                    TsTabletStatisticType.getTypeCount());
            tsStatisticResults.put(entry.getKey(),
                    new Pair<double[], double[]>(tsGlobalStatisticResults,
                            tsTabletStatisticResults));
        }
        tableStatisticResults.clear();
        for (Map.Entry<Long, double[]> entry: that.tableStatisticResults.entrySet()) {
            tableStatisticResults.put(
                    entry.getKey(),
                    Arrays.copyOf(entry.getValue(),
                            TableStatisticType.getTypeCount()));
        }
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        for (double d: masterStatisticResults.getFirst()) {
            out.writeDouble(d);
        }
        for (double d: masterStatisticResults.getSecond()) {
            out.writeDouble(d);
        }
        for (double d: totalTsStatisticResults.getFirst()) {
            out.writeDouble(d);
        }
        for (double d: totalTsStatisticResults.getSecond()) {
            out.writeDouble(d);
        }
        CDataOutputStream.writeVInt(tsStatisticResults.size(), out);
        for (Map.Entry<String, Pair<double[], double[]>> entry: tsStatisticResults.entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            for (double d: entry.getValue().getFirst()) {
                out.writeDouble(d);
            }
            for (double d: entry.getValue().getSecond()) {
                out.writeDouble(d);
            }
        }
        CDataOutputStream.writeVInt(tableStatisticResults.size(), out);
        for (Map.Entry<Long, double[]> entry: tableStatisticResults.entrySet()) {
            out.writeLong(entry.getKey());
            for (double d: entry.getValue()) {
                out.writeDouble(d);
            }
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        for (int i = 0; i < MasterGlobalStatisticType.getTypeCount(); i++) {
            masterStatisticResults.getFirst()[i] = in.readDouble();
        }
        for (int i = 0; i < MasterTableStatisticType.getTypeCount(); i++) {
            masterStatisticResults.getSecond()[i] = in.readDouble();
        }
        for (int i = 0; i < TsGlobalStatisticType.getTypeCount(); i++) {
            totalTsStatisticResults.getFirst()[i] = in.readDouble();
        }
        for (int i = 0; i < TsTabletStatisticType.getTypeCount(); i++) {
            totalTsStatisticResults.getSecond()[i] = in.readDouble();
        }
        tsStatisticResults.clear();
        int sz = CDataInputStream.readVInt(in);
        for (int i = 0; i < sz; i++) {
            String tsName = StringWritable.readString(in);
            double[] tsGlobalStatisticResults = new double[TsGlobalStatisticType.getTypeCount()];
            for (int j = 0; j < TsGlobalStatisticType.getTypeCount(); j++) {
                tsGlobalStatisticResults[j] = in.readDouble();
            }
            double[] tsTabletStatisticResults = new double[TsTabletStatisticType.getTypeCount()];
            for (int j = 0; j < TsTabletStatisticType.getTypeCount(); j++) {
                tsTabletStatisticResults[j] = in.readDouble();
            }
            tsStatisticResults.put(tsName, new Pair<double[], double[]>(
                    tsGlobalStatisticResults, tsTabletStatisticResults));
        }
        tableStatisticResults.clear();
        sz = CDataInputStream.readVInt(in);
        for (int i = 0; i < sz; i++) {
            long schemaId = in.readLong();
            double[] tableStatisticResults = new double[TableStatisticType.getTypeCount()];
            for (int j = 0; j < TableStatisticType.getTypeCount(); j++) {
                tableStatisticResults[j] = in.readDouble();
            }
            this.tableStatisticResults.put(schemaId, tableStatisticResults);
        }
    }

    public Pair<double[], double[]> getMasterStatisticResults() {
        return masterStatisticResults;
    }

    public Pair<double[], double[]> getTotalTsStatisticResults() {
        return totalTsStatisticResults;
    }

    public Map<String, Pair<double[], double[]>> getTsStatisticResults() {
        return tsStatisticResults;
    }

    public Map<Long, double[]> getTableStatisticResults() {
        return tableStatisticResults;
    }
}
