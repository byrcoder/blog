/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import odis.io.FileSystem;
import odis.io.Path;
import toolbox.collections.primitive.LongLongPair;
import toolbox.collections.primitive.LongPriorityQueue;

/**
 * @author zhangkun
 */
public class BenchLogAnalyzer {
    public static void analyze(FileSystem fs, Path logDir, long period,
            long startTime, long endTime) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                fs.openRaw(new Path(logDir, "log"))));
        Writer out = new OutputStreamWriter(fs.create(new Path(logDir,
                "analysis-" + startTime + "-" + endTime + "@" + period)));
        out.write("# start=" + startTime + ", end=" + endTime + ", period="
                + period + "\n");
        out.write("# readThroughput readAvgDelay read99Delay readMaxDelay readErrors readMisses writeThroughput writeAvgDelay write99Delay writeMaxDelay writeErrors\n");
        String line;
        // period stats values
        long lastPeriodEnd = 0;
        long periodWriteThroughput = 0;
        long periodWriteDelaySum = 0;
        long periodReadThroughput = 0;
        long periodReadDelaySum = 0;
        long periodWriteErrors = 0;
        long periodReadErrors = 0;
        long periodReadMisses = 0;
        ArrayList<Long> periodReadDelays = new ArrayList<Long>();
        ArrayList<Long> periodWriteDelays = new ArrayList<Long>();

        while ((line = reader.readLine()) != null) {
            if (line.startsWith("#")) {
                continue;
            }
            String[] split = line.split(" ");
            long timeStamp = Long.parseLong(split[0]);
            String type = split[1];
            long delay = Long.parseLong(split[2]);
            String status = null;
            if (split.length > 3) {
                status = split[3];
            }
            if (timeStamp - lastPeriodEnd >= period) {
                Collections.sort(periodReadDelays);
                Collections.sort(periodWriteDelays);
                out.write(((double) periodReadThroughput / period * 1000)
                        + " "
                        + (periodReadThroughput > 0 ? (double) periodReadDelaySum
                                / periodReadThroughput
                                : -1)
                        + " "
                        + (periodReadThroughput > 0 ? periodReadDelays.get((int) (periodReadDelays.size() * 0.99))
                                : -1)
                        + " "
                        + (periodReadThroughput > 0 ? periodReadDelays.get(periodReadDelays.size() - 1)
                                : -1)
                        + " "
                        + periodReadErrors
                        + " "
                        + periodReadMisses
                        + " "
                        + ((double) periodWriteThroughput / period * 1000)
                        + " "
                        + (periodWriteThroughput > 0 ? (double) periodWriteDelaySum
                                / periodWriteThroughput
                                : -1)
                        + " "
                        + (periodWriteThroughput > 0 ? periodWriteDelays.get((int) (periodWriteDelays.size() * 0.99))
                                : -1)
                        + " "
                        + (periodWriteThroughput > 0 ? periodWriteDelays.get(periodWriteDelays.size() - 1)
                                : -1) + " " + periodWriteErrors + "\n");
                out.flush();
                lastPeriodEnd = timeStamp;
                periodWriteThroughput = 0;
                periodWriteDelaySum = 0;
                periodReadThroughput = 0;
                periodReadDelaySum = 0;
                periodWriteErrors = 0;
                periodReadErrors = 0;
                periodReadMisses = 0;
                periodReadDelays.clear();
                periodWriteDelays.clear();
            } else {
                if (type.equals("W")) {
                    periodWriteThroughput++;
                    periodWriteDelaySum += delay;
                    periodWriteDelays.add(delay);
                    if ("ERROR".equals(status)) {
                        periodWriteErrors++;
                    }
                } else if (type.equals("R")) {
                    periodReadThroughput++;
                    periodReadDelaySum += delay;
                    periodReadDelays.add(delay);
                    if ("ERROR".equals(status)) {
                        periodReadErrors++;
                    } else if ("MISS".equals(status)) {
                        periodReadMisses++;
                    }
                }
            }
        }
        out.close();
    }

    private static final int MAX_QUEUE_SIZE = 500000;

    private static void addToMaxQueue(LongPriorityQueue queue, long value) {
        if (queue.size() == MAX_QUEUE_SIZE) {
            if (queue.peek(0) < value) {
                queue.poll(0);
                queue.add(value);
            }
        } else {
            queue.add(value);
        }
    }

    private static LongLongPair get99AndMax(int totalCount,
            LongPriorityQueue queue) {
        LongLongPair ret = new LongLongPair();
        int index = (int) (queue.size() - totalCount * 0.01);
        for (int i = 0; i < index; i++) {
            queue.poll(0);
        }
        ret.setFirst(queue.poll(0));
        while (queue.size() > 0) {
            ret.setSecond(queue.poll(0));
        }
        return ret;
    }

    public static void analyzeAll(FileSystem fs, Path logDir, long startTime,
            long endTime) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                fs.openRaw(new Path(logDir, "log"))));
        Writer out = new OutputStreamWriter(fs.create(new Path(logDir,
                "analysisAll-" + startTime + "-" + endTime)));
        out.write("# start=" + startTime + ", end=" + endTime + "\n");
        out.write("# readThroughput readAvgDelay read99Delay readMaxDelay readErrors readMisses writeThroughput writeAvgDelay write99Delay writeMaxDelay writeErrors\n");
        long writeThroughput = 0;
        long writeDelaySum = 0;
        long readThroughput = 0;
        long readDelaySum = 0;
        long writeErrors = 0;
        long readErrors = 0;
        long readMisses = 0;
        LongPriorityQueue maxReadDelays = new LongPriorityQueue(MAX_QUEUE_SIZE);
        LongPriorityQueue maxWriteDelays = new LongPriorityQueue(MAX_QUEUE_SIZE);
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("#")) {
                continue;
            }
            String[] split = line.split(" ");
            long timeStamp = Long.parseLong(split[0]);
            if (timeStamp < startTime || timeStamp > endTime) {
                continue;
            }
            String type = split[1];
            long delay = Long.parseLong(split[2]);
            String status = null;
            if (split.length > 3) {
                status = split[3];
            }
            if (type.equals("W")) {
                writeThroughput++;
                writeDelaySum += delay;
                addToMaxQueue(maxWriteDelays, delay);
                if ("ERROR".equals(status)) {
                    writeErrors++;
                }
            } else {
                readThroughput++;
                readDelaySum += delay;
                addToMaxQueue(maxReadDelays, delay);
                if ("ERROR".equals(status)) {
                    readErrors++;
                } else if ("MISS".equals(status)) {
                    readMisses++;
                }
            }
        }
        long period = endTime - startTime;
        LongLongPair read99AndMax = get99AndMax((int) readThroughput,
                maxReadDelays);
        LongLongPair write99AndMax = get99AndMax((int) writeThroughput,
                maxWriteDelays);

        out.write((double) readThroughput / period * 1000 + " "
                + (double) readDelaySum / readThroughput + " "
                + read99AndMax.getFirst() + " " + read99AndMax.getSecond()
                + " " + readErrors + " " + readMisses + " "
                + (double) writeThroughput / period * 1000 + " "
                + (double) writeDelaySum / writeThroughput + " "
                + write99AndMax.getFirst() + " " + write99AndMax.getSecond()
                + " " + writeErrors + "\n");
        out.close();
    }

    public static void main(String[] args) throws Exception {
//                args = new String[] {
//                    "local", "D:/Work/omap/tweettimeline-write/", "1000", "9678", "1992727"
//                };
        if (args.length < 5) {
            System.err.println("Usage: BenchLogAnalyzer <FS> <DIR_OF_BENCH_LOG> <PERIOD_IN_MILLIS> <START_TIME> <END_TIME>");
            return;
        }
        long period = Long.parseLong(args[2]);
        if (period > 0) {
            analyze(FileSystem.getNamed(args[0]), new Path(args[1]), period,
                    Long.parseLong(args[3]), Long.parseLong(args[4]));
        } else {
            analyzeAll(FileSystem.getNamed(args[0]), new Path(args[1]),
                    Long.parseLong(args[3]), Long.parseLong(args[4]));
        }
    }
}
