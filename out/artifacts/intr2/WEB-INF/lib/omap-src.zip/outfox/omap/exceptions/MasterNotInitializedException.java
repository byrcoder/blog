/**
 * @(#)MasterNotInitializedException.java, 2009-8-23. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.exceptions;

/**
 * @author zhangduo
 */
public class MasterNotInitializedException extends RuntimeException {

    private static final long serialVersionUID = 3578727354541892701L;

    public MasterNotInitializedException() {
        super();
    }

    public MasterNotInitializedException(String message, Throwable cause) {
        super(message, cause);
    }

    public MasterNotInitializedException(String message) {
        super(message);
    }

    public MasterNotInitializedException(Throwable cause) {
        super(cause);
    }
}
