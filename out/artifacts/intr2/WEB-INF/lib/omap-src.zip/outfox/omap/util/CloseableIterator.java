package outfox.omap.util;

import java.io.Closeable;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * An Iterator that contains some resources (such as InputStream) that needs to
 * be released through the close operation.
 * 
 * @author zhangkun, zhangduo
 * @param <T>
 */
public interface CloseableIterator<T extends IWritable> extends Closeable {
    /**
     * get the next element.
     * 
     * @param value
     * @return true if there is a next value, otherwise false.
     * @throws IOException
     */
    boolean next(T value) throws IOException;
}
