/**
 * @(#)QueryCondition.java, Oct 7, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol;

import odis.serialize.IWritableComparable;

/**
 * The interface of a query condition, just as 
 * an item of <i>where</i> statement in SQL, e.g.
 * <code>name="John"</code>
 * @author xingjk
 *
 */
public interface QueryCondition {
    
    public String getColumnName();
    
    public QueryOperation getOperation();
    
    public IWritableComparable getPara();
    
    public void setPara(IWritableComparable para);
    
    /**
     * This method returns valid IWritable object only
     * when the query operation is RANGE operation.
     * @return
     */
    public IWritableComparable getPara2();
    
    /**
     * This method only takes effect only
     * when the query operation is RANGE operation.
     * @param para
     */
    public void setPara2(IWritableComparable para);
    
    /**
     * Check the parameters to indicate whether the condition
     * is valid to be executed.
     */
    public boolean isReadyToExecute();
    
    /**
     * Check whether the input is match this query condition
     * @param w
     * @return match or not
     */
    public boolean isMatch(IWritableComparable w);
}
