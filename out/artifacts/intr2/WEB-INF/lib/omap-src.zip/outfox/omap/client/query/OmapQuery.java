/**
 * @(#)OmapQuery.java, Oct 28, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.query;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.UTF8Writable;
import outfox.omap.client.protocol.Query;
import outfox.omap.client.protocol.QueryCondition;
import outfox.omap.client.protocol.QueryOperation;
import outfox.omap.exceptions.QueryInitializationException;
import toolbox.misc.LogFormatter;

/**
 * A query contains several conditions, which can be sorted according to
 * <ol>
 * <li>their query operation's priority</li>
 * <li>their column name's alphabetical order</li>
 * </ol>
 * This order represents an index schema (see
 * {@link outfox.omap.client.query.IndexSchema}), a collection of <colName,
 * query op> with above order. Different query objects are termed "compitable"
 * if and only if their query schema is identical. User can only execute the
 * queries which specified when the table is created, and the ones compitable to
 * them. <br>
 * The offset means the start record of the result to be presented to user. And
 * the limit refers to the maximal total length of result. If the total length
 * is less than the offset, an empty result shall be returned. If the total
 * length started from offest is less than the limit, all the result is
 * returned. The default offset is started from 0 and default limit is
 * max-query-result set in the omap configuration.
 * 
 * @author xingjk
 */
public class OmapQuery implements Query, IWritable {

    public static final int DEFAULT_OFFSET = 0;

    public static final int DEFAULT_LIMIT = 3000;

    @SuppressWarnings("unused")
    private static Logger LOG = LogFormatter.getLogger(OmapQuery.class);

    public OmapQuery() {} // only for serialization

    public OmapQuery(String name, OmapQueryCondition[] conditions) {
        this(name, conditions, DEFAULT_OFFSET);
    }

    public OmapQuery(String name, OmapQueryCondition[] conditions, int offset) {
        this(name, conditions, offset, DEFAULT_LIMIT);
    }

    public OmapQuery(String name, OmapQueryCondition[] conditions, int offset,
            int limit) {
        setQueryName(name);
        setConditions(conditions);
        setOffset(offset);
        setLimit(limit);
    }

    /**
     * A null or an empty name is disallowed
     * 
     * @param name
     */
    public void setQueryName(String name) {
        if (name == null || name.equals(""))
            throw new QueryInitializationException("Invalid query name");
        this.name = name;
    }

    /**
     * @param conditions
     */
    private void setConditions(OmapQueryCondition[] conditions) {
        if (conditions == null || conditions.length == 0)
            throw new QueryInitializationException("Invalid conditions");

        // check whether there is duplicated column names and only one
        // non-equality
        validateConditions(conditions);

        // duplicate the array to keep the array's order when conditions are set
        this.conditions = new OmapQueryCondition[conditions.length];
        System.arraycopy(conditions, 0, this.conditions, 0, conditions.length);
        Arrays.sort(this.conditions);
        indexSchema = new IndexSchema(this.conditions);
    }

    /**
     * Check whether the input conditions is valid. The conditions have to
     * confirm to:
     * <ol>
     * <li>One condition, one column. The case of multiple conditions for the
     * same column is not allowed.</li>
     * <li>Only one non-equality (LIRI, GREATER_THAN, INEQUAL or the like) is
     * allowed to appear in one query.</li>
     * </ol>
     * If some invalidation is detected, {@link QueryInitializationException} is
     * thrown.
     * 
     * @param conditions
     */
    private void validateConditions(OmapQueryCondition[] conditions) {

        boolean bNonEqualityExisted = false;
        HashSet<String> colNames = new HashSet<String>();
        for (OmapQueryCondition condition: conditions) {
            if (colNames.contains(condition.getColumnName()))
                throw new QueryInitializationException(
                        "A query can contain only one condition for one column");

            if (condition.getOperation().compareTo(QueryOperation.EQUAL) != 0) {
                if (bNonEqualityExisted == true)
                    throw new QueryInitializationException(
                            "A query can contain only one condition with non-equality operator");
                else
                    bNonEqualityExisted = true;
            }

            colNames.add(condition.getColumnName());
        }
    }

    private String name;

    private static final OmapQueryCondition[] EMPTY_CONDITIONS = new OmapQueryCondition[0];

    private OmapQueryCondition[] conditions = EMPTY_CONDITIONS;

    private IndexSchema indexSchema; // the ordered conditions

    private int offset;

    private int limit;

    public OmapQueryCondition[] getConditions() {
        return conditions;
    }

    public QueryCondition getCondition(String colName) {
        for (OmapQueryCondition condition: conditions) {
            if (colName.equals(condition.getColumnName()))
                return condition;
        }
        return null;
    }

    public int getLimit() {
        return limit;
    }

    public String getName() {
        return name;
    }

    public int getOffset() {
        return offset;
    }

    public void setLimit(int limit) {
        if (limit < -1)
            throw new QueryInitializationException("Invalid limit:" + limit);
        this.limit = limit;
    }

    public void setOffset(int offset) {
        if (offset < 0)
            throw new QueryInitializationException("Invalid offset:" + offset);

        this.offset = offset;
    }

    public void readFields(DataInput in) throws IOException {
        name = UTF8Writable.readString(in);
        offset = in.readInt();
        limit = in.readInt();
        int length = in.readInt();
        conditions = new OmapQueryCondition[length];
        for (int i = 0; i < length; i++) {
            conditions[i] = new OmapQueryCondition();
            conditions[i].readFields(in);
        }
        indexSchema = new IndexSchema(this.conditions);
    }

    public void writeFields(DataOutput out) throws IOException {
        UTF8Writable.writeString(out, name);
        out.writeInt(offset);
        out.writeInt(limit);
        out.writeInt(conditions.length);
        for (OmapQueryCondition condition: conditions) {
            condition.writeFields(out);
        }
    }

    public IWritable copyFields(IWritable value) {
        OmapQuery that = (OmapQuery) value;
        this.name = that.name;
        this.offset = that.offset;
        this.limit = that.limit;
        this.conditions = new OmapQueryCondition[that.conditions.length];
        for (int i = 0; i < that.conditions.length; i++) {
            this.conditions[i] = new OmapQueryCondition();
            this.conditions[i].copyFields(that.conditions[i]);
        }
        this.indexSchema = new IndexSchema(this.conditions);
        return this;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Query:");
        sb.append(name);
        sb.append(" off:" + offset);
        sb.append(" lim:" + limit);
        sb.append("\nconditions: ");
        for (int i = 0; i < conditions.length; i++) {
            sb.append(conditions[i].toString());
            if (i < conditions.length - 1) {
                sb.append(" and ");
            }
        }
        return sb.toString();
    }

    /**
     * Check whether two queries are compitable
     * 
     * @param query
     *            another query
     * @return the check result
     */
    public boolean isCompitable(Query query) {
        OmapQuery that = (OmapQuery) query;
        IndexSchema thatQuerySchema = that.getIndexSchema();
        IndexSchema thisQuerySchema = getIndexSchema();
        if (thisQuerySchema.compareTo(thatQuerySchema) != 0)
            return false;
        else
            return true;
    }

    public IndexSchema getIndexSchema() {
        return indexSchema;
    }

    @Override
    public QueryCondition getFirstCondition() {
        return conditions[0];
    }
}
