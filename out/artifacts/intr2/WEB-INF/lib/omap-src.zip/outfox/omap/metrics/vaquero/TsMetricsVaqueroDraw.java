/**
 * @(#)TsMetricsVaqueroDraw.java, 2011-6-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 *
 * @author zhangduo
 *
 */
public enum TsMetricsVaqueroDraw {
    INFO("ts.info", "basic information of omapts"), 
    LOAD("ts.load", "system load"),
    LOAD_PER_PROCESSOR("ts.load.per.processor", "system load per perocessor"),
    MEMORY("ts.memory", "heap memory usage, in GB"),
    WRITE_BUFFER("ts.writebuffer", "write buffer usage, in GB"),
    BLOOMFILTER("ts.bloomfilter", "bloomfilter usage, in GB"),
    INDEX_POOL("ts.indexpool", "indexpool usage, in GB"),
    BLOCK_CACHE("ts.blockcache", "blockcache usage, in GB"),
    
    BLOCK_CACHE_CACHE_RATE("ts.blockcache.cache.rate", "rate of blockcache cahe"),
    BLOCK_CACHE_GET_RATE("ts.blockcache.get.rate", "rate of blockcache get"),
    BLOCK_CACHE_EVICT_RATE("ts.blockcache.evict.rate", "rate of blockcache evict"),
    
    HEARTBEAT_RATE("ts.heartbeat.rate", "rate of heartbeat"),
    HEARTBEAT_DELAY("ts.heartbeat.delay", "delay of heartbeat"),
    
    SSTABLE_SEEK_RATE("ts.sstable.seek.rate", "rate of sstable seek"),
    SSTABLE_SEEK_DELAY("ts.sstable.seek.delay", "delay of sstable seek"),

    REQUEST_RATE("ts.request.rate", "rate of total request"),
    
    KEY_FIND_RATE("keyFind.rate", "rate of keyFind request"),
    KEY_FIND_SIZE_RATE("keyFind.size.rate", "rate of keyFind size, in MB/s"),
    KEY_FIND_SIZE_PER_COUNT("size.keyFind.perCount", "size of keyFind per request, in bytes"),
    KEY_FIND_DELAY("keyFind.delay", "delay of keyFind request"),
    
    MULTI_KEY_FIND_RATE("multiKeyFind.rate", "rate of multiKeyFind request"),
    MULTI_KEY_FIND_ROWS_RATE("multiKeyFind.rows.rate", "rate of multiKeyFind rows"),
    MULTI_KEY_FIND_SIZE_RATE("multiKeyFind.size.rate", "rate of multiKeyFind size, in MB/s"),
    MULTI_KEY_FIND_ROWS_PER_COUNT("multiKeyFind.rows.perCount", "rows of multiKeyFind per request"),
    MULTI_KEY_FIND_SIZE_PER_COUNT("multiKeyFind.size.perCount", "size of multiKeyFind per request, in bytes"),
    MULTI_KEY_FIND_DELAY("multiKeyFind.delay", "delay of multiKeyFind request"),
    MULTI_KEY_FIND_PER_ROW_DELAY("multiKeyFind.perRow.delay", "delay of multiKeyFind request per row"),
    
    RANGE_KEY_FIND_RATE("rangeKeyFind.rate", "rate of rangeKeyFind request"),
    RANGE_KEY_FIND_ROWS_RATE("rangeKeyFind.rows.rate", "rate of rangeKeyFind rows"),
    RANGE_KEY_FIND_SIZE_RATE("rangeKeyFind.size.rate", "rate if rangeKeyFind size, in MB/s"),
    RANGE_KEY_FIND_ROWS_PER_COUNT("rangeKeyFind.rows.perCount", "rows of rangeKeyFind per request"),
    RANGE_KEY_FIND_SIZE_PER_COUNT("rangeKeyFind.size.perCount", "size of rangeKeyFind per request, in bytes"),
    RANGE_KEY_FIND_DELAY("rangeKeyFind.delay", "delay of rangeKeyFind request"),
    RANGE_KEY_FIND_PER_ROW_DELAY("rangeKeyFind.perRow.delay", "delay of rangeKeyFind request per row"),
    
    CONTAINS_RATE("contains.rate", "rate of contains request"),
    CONTAINS_DELAY("contains.delay", "delay of contains request"),
    
    MULTI_CONTAINS_RATE("multiContains.rate", "rate of multiContains request"),
    MULTI_CONTAINS_ROWS_RATE("multiContains.rows.rate", "rate of multiContains rows"),
    MULTI_CONTAINS_ROWS_PER_COUNT("multiContains.rows.perCount", "rows of multiContains per request"),
    MULTI_CONTAINS_DELAY("multiContains.delay", "delay of multiContains request"),
    MULTI_CONTAINS_PER_ROW_DELAY("multiContains.perRow.delay", "delay of multiContains request per row"),
    
    INSERT_RATE("insert.rate", "rate of insert request"),
    INSERT_SIZE_RATE("insert.size.rate", "rate of insert size, in MB/s"),
    INSERT_SIZE_PER_COUNT("size.insert.perCount", "size of insert per request, in bytes"),
    INSERT_DELAY("insert.delay", "delay of insert request"),
    
    MULTI_INSERT_RATE("multiInsert.rate", "rate of multiInsert request"),
    MULTI_INSERT_ROWS_RATE("multiInsert.rows.rate", "rate of multiInsert rows"),
    MULTI_INSERT_SIZE_RATE("multiInsert.size.rate", "rate if multiInsert size, in MB/s"),
    MULTI_INSERT_ROWS_PER_COUNT("multiInsert.rows.perCount", "rows of multiInsert per request"),
    MULTI_INSERT_SIZE_PER_COUNT("multiInsert.size.perCount", "size of multiInsert per request, in bytes"),
    MULTI_INSERT_DELAY("multiInsert.delay", "delay of multiInsert request"),
    MULTI_INSERT_PER_ROW_DELAY("multiInsert.perRow.delay", "delay of multiInsert request per row"),
    
    DELETE_RATE("delete.rate", "rate of delete request"),
    DELETE_DELAY("delete.delay", "delay of delete request"),
    
    MULTI_DELETE_RATE("multiDelete.rate", "rate of multiDelete request"),
    MULTI_DELETE_ROWS_RATE("multiDelete.rows.rate", "rate of multiDelete rows"),
    MULTI_DELETE_ROWS_PER_COUNT("multiDelete.rows.perCount", "rows of multiDelete per request"),
    MULTI_DELETE_DELAY("multiDelete.delay", "delay of multiDelete request"),
    MULTI_DELETE_PER_ROW_DELAY("multiDelete.perRow.delay", "delay of multiDelete request per row"),
    
    RANGE_DELETE_RATE("rangeDelete.rate", "rate of rangeDelete request"),
    RANGE_DELETE_ROWS_RATE("rangeDelete.rows.rate", "rate of rangeDelete rows"),
    RANGE_DELETE_ROWS_PER_COUNT("rangeDelete.rows.perCount", "rows of rangeDelete per request"),
    RANGE_DELETE_DELAY("rangeDelete.delay", "delay of rangeDelete request"),
    RANGE_DELETE_PER_ROW_DELAY("rangeDelete.perRow.delay", "delay of rangeDelete request per row"),
    
    COMPARE_AND_SET_RATE("compareAndSet.rate", "rate of compareAndSet request"),
    COMPARE_AND_SET_DELAY("compareAndSet.delay", "delay of compareAndSet request"),
    
    LOCK_ROW_RATE("lockRow.rate", "rate of lockRow request"),
    LOCK_ROW_DELAY("lockRow.delay", "delay of lockRow request"),
    
    UNLOCK_ROW_RATE("unlockRow.rate", "rate of unlockRow request"),
    UNLOCK_ROW_DELAY("unlockRow.delay", "delay of unlockRow request");

    private final String drawName;

    private final String description;

    private TsMetricsVaqueroDraw(String drawName, String description) {
        this.drawName = drawName;
        this.description = description;
    }

    public String getDrawName() {
        return drawName;
    }

    public String getDescription() {
        return description;
    }
}
