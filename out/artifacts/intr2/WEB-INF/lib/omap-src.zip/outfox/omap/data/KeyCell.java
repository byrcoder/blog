package outfox.omap.data;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import outfox.omap.util.GenericWritableComparator;
import outfox.omap.util.OmapUtils;

/**
 * @author zhangkun
 */
public class KeyCell extends DataCell implements Comparable<KeyCell> {
    /**
     * Initial status is NULL
     */
    public KeyCell() {
        super(null, STATUS_NULL);
    }

    /**
     * Initial status is NORMAL
     * 
     * @param buffer
     */
    public KeyCell(IWritable buffer) {
        super(buffer, STATUS_NORMAL);
    }

    public KeyCell(IWritable buffer, byte initialStatus) {
        super(buffer, initialStatus);
    }

    /**
     * Set the first key and change the status to
     * {@value DataCell#STATUS_NORMAL}
     * 
     * @param k1
     */
    public void initializeForK1(IWritableComparable k1) {
        if (buffer instanceof KeyPair) {
            KeyPair keyPair = (KeyPair) buffer;
            keyPair.setKey1(k1);
            setStatus(STATUS_NORMAL);
        } else {
            throw new RuntimeException(
                    "this method should only be called when this KeyCell's value is a KeyPair");
        }
    }

    public int compareTo(KeyCell cell) {
        byte cellStatus = cell.getStatus();
        byte thisStatus = this.getStatus();
        if (cellStatus == STATUS_INVALID || thisStatus == STATUS_INVALID)
            throw new RuntimeException("cannot compare invalid values");
        return GenericWritableComparator.instance.compare(this.getKey(),
                cell.getKey());
    }

    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        KeyCell v = (KeyCell) o;
        return this.compareTo(v) == 0;
    }

    public int hashCode() {
        IWritableComparable key = getKey();
        if (key == null) {
            return 0;
        }
        return key.hashCode();
    }

    public IWritableComparable getKey() {
        if (getStatus() != STATUS_NORMAL) {
            return null;
        }
        return (IWritableComparable) buffer;
    }

    /**
     * Read and fill the KeyCell from a byte array representing a KeyCell. The
     * byte array is got by calling
     * {@link outfox.omap.data.KeyCell#writePIFields(java.io.DataOutput)}.
     * 
     * @param keyCell
     * @param key
     */
    public static void keyCellFromBinaryKey(KeyCell keyCell, byte[] key) {
        OmapUtils.convertBytesToPIWritable(key, keyCell);
    }
}
