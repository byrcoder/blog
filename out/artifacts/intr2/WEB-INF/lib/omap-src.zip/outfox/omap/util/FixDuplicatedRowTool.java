/**
 * @(#)FixDuplicatedRowTool.java, 2010-12-21. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import java.net.InetSocketAddress;
import java.util.logging.Logger;

import odis.io.FSDataInputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.rpc2.RPC;
import outfox.omap.ClientMasterProtocol;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.metadata.TableDesc;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class FixDuplicatedRowTool {
    private static final Logger LOG = LogFormatter.getLogger(FixDuplicatedRowTool.class);

    private String tableName;

    private String fsName;

    private String inputPath;

    private String outputPath;

    private CompressType compressType;

    public void run() throws Exception {
        ClientMasterProtocol master = (ClientMasterProtocol) RPC.getProxy(
                ClientMasterProtocol.class,
                new InetSocketAddress("nb109", 6190));
        TableDesc td = ((OmapMetadata) master.getMetadata(master.getSchemaId(tableName))).getTableDesc();
        RPC.close(master);
        FileSystem fs = FileSystem.getNamed(fsName);
        Path outputDir = new Path(outputPath);
        if (fs.exists(outputDir)) {
            throw new RuntimeException(outputDir + " already exists");
        }
        LOG.info("snapshot tablet " + tableName + ", output to " + fs + ":"
                + outputDir.getAbsolutePath());
        Path inputDir = new Path(inputPath);
        KeyRangeList krl = new KeyRangeList();
        FSDataInputStream dis = OmapUtils.createFSDataInputStream(fs,
                inputDir.cat("keyRangeList"), false);
        krl.readFields(dis);
        dis.close();

        for (KeyRange kr: krl.getRangeSet().keySet()) {
            LOG.info("fix " + kr);
            TabletReader reader = new TabletReader(fs,
                    inputDir.cat("ts").getAbsolutePath(), kr, td);
            TabletWriter writer = new TabletWriter(fs, new Path(
                    OmapUtils.getSSTableFileDirPath(
                            outputDir.cat("ts").getAbsolutePath(),
                            kr.getTabletId())), reader.getNumKeys(),
                    compressType);
            CloseableIterator<DataRow> iter = reader.iterator();
            DataRow dr = td.createDataRow();
            DataRow last = null;
            while (iter.next(dr)) {
                if (dr.isDeleted()) {
                    continue;
                }
                if (dr.hasInvalidCell()) {
                    LOG.warning("invalid dr " + dr);
                    continue;
                }
                if (last != null && dr.getKeyCell().equals(last.getKeyCell())) {
                    continue;
                }
                if (last == null) {
                    last = td.createDataRow();
                }
                last.copyFields(dr);
                writer.write(dr);
            }
            writer.close();
        }

    }

    public static void main(String[] args) throws Exception {
        FixDuplicatedRowTool tool = new FixDuplicatedRowTool();
        tool.tableName = args[0];
        tool.fsName = args[1];
        tool.inputPath = args[2];
        tool.outputPath = args[3];
        tool.compressType = CompressType.valueOf(args[4]);
        tool.run();
    }
}
