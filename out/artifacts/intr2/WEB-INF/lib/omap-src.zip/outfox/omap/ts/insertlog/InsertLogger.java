package outfox.omap.ts.insertlog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.ByteArrayWritable;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.UnsafeHelper;
import outfox.omap.client.protocol.Table;
import outfox.omap.conf.OmapConfig;
import outfox.omap.conf.OmapConstants;
import outfox.omap.ts.OmapTs;
import outfox.omap.ts.OmapTsMetadataCache;
import outfox.omap.util.AlertUtils;
import outfox.omap.util.OmapUtils;
import outfox.omap.util.OmapUtils.TESTCASE_PREPENSE_EXCEPTION_TYPE;
import outfox.omap.util.WaitUtils;
import outfox.omap.walog.LogIterator;
import outfox.omap.walog.LogReader;
import outfox.omap.walog.WALogFile;
import outfox.omap.walog.WALogger;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * This is for handling WALogs:<ui> <li>Write WA log</li> <li>Disasssemble WA
 * log</li> <li>delete useless log files and record checkpoint</li> <li>recover
 * tablets</li> </ui>
 * 
 * @author wangfk
 */
public class InsertLogger extends WALogger {
    private static Logger LOG = LogFormatter.getLogger(InsertLogger.class);

    private final long disassembleLogsMaxThroughput;

    private static final int DEFAULT_FATAL_ERROR_RETRY_COUNT = 5;

    private final boolean recoverMode;

    /**
     * the last log record of checkpointed records. It records [tabletId->LSN]
     * pairs.
     */
    private final LongLongHashMap checkpointMap;

    public InsertLogger(Path logDir, IFileSystem fs) throws IOException {
        this(logDir, fs, false);
    }

    public InsertLogger(Path logDir, IFileSystem dfs, boolean readonly)
            throws IOException {
        super(logDir, dfs, readonly, new InsertLogEntry());
        recoverMode = readonly;


        if (recoverMode) {
            //read checkpoint map from file
            LongLongHashMap checkpointMap = getLastDiskChkpt();
            if (checkpointMap == null) {
                checkpointMap = new LongLongHashMap();
            }
            this.checkpointMap = checkpointMap;
            //there is no speed limit while recover
            disassembleLogsMaxThroughput = 0;
        } else {
            startWriter();
            //the checkpoint map should be null while startup
            checkpointMap = new LongLongHashMap();
            //write empty map to checkpoint file
            writeChkPtLog(checkpointMap);
            disassembleLogsMaxThroughput = OmapConfig.getConfiguration().getLong(
                    OmapConfig.NAME_TRUNCATE_WAL_MAX_THROUGHPUT,
                    OmapConfig.DEFAULT_TRUNCATE_WAL_MAX_THROUGHPUT);
        }

    }

    public long writeInsertLog(long tabletId, ByteArrayWritable row)
            throws IOException {
        InsertLogEntry insbuf = new InsertLogEntry();
        insbuf.setBody(new WALogInsert(tabletId, row));
        return write(insbuf);
    }

    private final Random rand = new Random();

    /**
     * Disasssemble logs, and remove original log files
     * 
     * @param keepLogTablets
     *            set of valid tablets id
     * @param files
     *            log files queue for disasssemble
     * @throws IOException
     */
    public void disassembleAllChunks(Set<Long> keepLogTablets,
            PriorityQueue<WALogFile> files,
            HashMap<Long, String> logReservePathMap,
            OmapTsMetadataCache mataCache, NativeRamBuffer defaultSplitBuffer)
            throws IOException {
        if (files.isEmpty()) {
            return;
        }

        LongLongHashMap lastDiskChkpt;
        synchronized (checkpointMap) {
            lastDiskChkpt = new LongLongHashMap(checkpointMap.size());
            for (LongLongHashMap.Entry entry: checkpointMap) {
                lastDiskChkpt.put(entry.getKey(), entry.getValue(), -1);
            }
        }

        int maxNativeBufferSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_DISASSEMBLE_WAL_MAX_BUFFER_SIZE,
                OmapConfig.DEFAULT_DISASSEMBLE_WAL_MAX_BUFFER_SIZE);

        LOG.info("Start disassemble logs, Log filse=" + files + ", tablets="
                + keepLogTablets + ", checkpoints=" + lastDiskChkpt);

        //speed limit: ideal situation is to split two walog files one time,
        //the more files, the looser speedLimit
        //XXX more reasonable speedLimit?
        long speedLimit = disassembleLogsMaxThroughput
                * ((files.size() + 1) / 2);
        while (!files.isEmpty()) {
            WALogFile f = files.remove();
            PriorityQueue<WALogFile> pq = new PriorityQueue<WALogFile>();
            pq.add(f);

            NativeRamBuffer splitBuffer = defaultSplitBuffer;
            for (int retry = 0;; retry++) {
                try {
                    long walFileSize = fs.getLength(f.getFile());
                    ReservableInsertLogReaderHandler handler = null;
                    if (walFileSize < maxNativeBufferSize) {
                        if (walFileSize > splitBuffer.getCapacity()) {
                            splitBuffer = new NativeRamBuffer(
                                    UnsafeHelper.unsafe.allocateMemory(walFileSize),
                                    (int) walFileSize);
                        }
                        handler = new InsertLoggerNativeRamSplitHandler(fs,
                                logDir, keepLogTablets, splitBuffer,
                                speedLimit, lastDiskChkpt, rand);
                    } else {
                        handler = new InsertLoggerSplitHandler(fs, logDir,
                                keepLogTablets, speedLimit, lastDiskChkpt);
                    }
                    handler.setLogReservePathMap(logReservePathMap, mataCache);
                    LogReader logReader = new LogReader(pq,
                            new InsertLogEntry(), handler);
                    //do disassemble of one file
                    logReader.read();
                    if (splitBuffer != defaultSplitBuffer) {
                        UnsafeHelper.unsafe.freeMemory(splitBuffer.getPtr());
                    }
                    break;
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Exception while disassemble log "
                            + f + (recoverMode ? ", retry=" + retry : ""), e);
                    ++retry;
                    if (!recoverMode
                            || retry >= DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                        LOG.log(Level.SEVERE, "Disassemble log file failure: "
                                + f);
                        if (splitBuffer != defaultSplitBuffer) {
                            UnsafeHelper.unsafe.freeMemory(splitBuffer.getPtr());
                        }
                        throw new IOException("Disassemble log file failure: "
                                + f, e);
                    }
                }
                WaitUtils.sleepIgnoreInterrupt(WaitUtils.getExpWaitTime(retry,
                        rand));
            }
            if (!fs.delete(f.getFile())) {
                LOG.warning("Failure while removing log file: " + f.getFile());
            }
        }

        //XXX DO NOT remove old checkpoint here: may some old log is in current walog file
    }

    /**
     * Remove inexistent tablet's logs, disassemble finished log files
     * 
     * @param ts
     * @throws IOException
     */
    public void disassembleAllChunks(OmapTs ts,
            NativeRamBuffer defaultSplitBuffer) throws IOException {
        //tablet set must be gat after chunks, in case of log loss of new tablet
        //remove checkpoint of closed tablets here
        Set<Long> tabletSet = null;
        PriorityQueue<WALogFile> logChunks = null;
        synchronized (checkpointMap) {
            logChunks = this.getLogChunks(true, false);
            //snapshot for tablets
            tabletSet = new HashSet<Long>(ts.getTablets().keySet());
            Iterator<LongLongHashMap.Entry> iter = checkpointMap.iterator();
            while (iter.hasNext()) {
                LongLongHashMap.Entry entry = iter.next();
                if (!tabletSet.contains(entry.getKey())) {
                    iter.remove();
                }
            }
            writeChkPtLog(checkpointMap);
        }

        clearUselessSplitLogs(tabletSet);

        HashMap<Long, String> logReservePathMap = new HashMap<Long, String>();
        for (long tabletId: tabletSet) {
            long sid = OmapUtils.tid2sid(tabletId);
            if (logReservePathMap.containsKey(tabletId)) {
                continue;
            }
            String reservePath = ts.getMetaCache().getMetadata(sid).getTableDesc().getProperty(
                    Table.Property.RESERVE_WAL_PATH_NAME, null);
            if (reservePath != null && !reservePath.isEmpty()) {
                logReservePathMap.put(sid, reservePath);
            }
        }
        //do disassemble logs
        disassembleAllChunks(tabletSet, logChunks, logReservePathMap,
                ts.getMetaCache(), defaultSplitBuffer);
    }

    public void recoverTablet(OmapTs ts, long tabletId) throws IOException {
        int retry = 0;
        IOException exc = null;
        while (true) {
            try {
                LongLongHashMap checkpoints = null;
                synchronized (checkpointMap) {
                    long checkpointLSN = checkpointMap.get(tabletId, -1);
                    if (checkpointLSN != -1) {
                        removeFilesByCheckPoint(tabletId, checkpointLSN);
                        checkpoints = new LongLongHashMap();
                        checkpoints.put(tabletId, checkpointLSN, -1);
                    }
                }
                PriorityQueue<WALogFile> splitLogChunks = getSplitLogChunks(
                        tabletId, true);
                LogReader logReader = new LogReader(splitLogChunks,
                        new InsertLogEntry(), new InsertLoggerRecoverHandler(
                                ts, tabletId, checkpoints));
                logReader.read();
                break;
            } catch (IOException e) {
                ++retry;
                try {
                    LOG.log(Level.SEVERE,
                            "Failure while recover from WALog, "
                                    + "may loss data. Tablet id: " + tabletId
                                    + ", " + "Log files: "
                                    + Arrays.toString(listLogFiles(tabletId))
                                    + ", retry=" + retry, e);
                } catch (Throwable t) {}
                exc = e;
            }
            //XXX do not sleep here, recover should always be done imminently
            if (retry > DEFAULT_FATAL_ERROR_RETRY_COUNT) {
                break;
            }
        }
        if (exc != null) {
            AlertUtils.alert(
                    "error recover tablet "
                            + HexString.longToPaddedHex(tabletId),
                    OmapUtils.getStackTrace(exc), false, true);
            throw exc;
        }
    }

    /**
     * This method is invoked for remove useless log files
     * 
     * @param recoverTablets
     */
    public void doneRecoverTablet(long tabletId) {
        Path logPath = logDir.cat(HexString.longToPaddedHex(tabletId));
        LOG.info("Remove log file for recover: " + logPath);
        try {
            if (!fs.delete(logPath)) {
                LOG.warning("Failure to remove log file: " + logPath);
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING, "Remove files failure: " + logPath, e);
        }
        try {
            //Remove log path while it is empty, or has only 'checkpoint' file, or 'checkpoint.tmp' file
            Path[] listPaths = fs.listPaths(logDir);
            if (listPaths == null
                    || listPaths.length == 0
                    || (listPaths.length == 1 && listPaths[0].getName().equals(
                            OmapConstants.CHKPT_FILENAME))
                    || (listPaths.length == 2
                            && listPaths[0].getName().startsWith(
                                    OmapConstants.CHKPT_FILENAME) && listPaths[1].getName().startsWith(
                            OmapConstants.CHKPT_FILENAME))) {
                LOG.info("The log path is empty, may all the log was recovered, delete dir: "
                        + logDir);
                fs.delete(logDir);
            }
        } catch (Throwable t) {
            //do nothing
            LOG.log(Level.WARNING, "Remove log path failed", t);
        }
    }

    /**
     * This function will be invoked iff tablet do checkpoint successfully
     * 
     * @param tabletId
     * @param lastLSN
     * @return
     * @throws IOException
     */
    public synchronized long checkPoint(long tabletId, long lastLSN)
            throws IOException {
        removeFilesByCheckPoint(tabletId, lastLSN);
        synchronized (checkpointMap) {
            checkpointMap.put(tabletId, lastLSN, -1);
            return writeChkPtLog(checkpointMap);
        }
    }

    /**
     * remove inexistent tablet's log folders
     * 
     * @param existTabletSet
     *            exist tablet ids, the tablet files besides this set will be
     *            deleted
     * @throws IOException
     */
    private void clearUselessSplitLogs(Set<Long> existTabletSet)
            throws IOException {
        FileInfo[] listFiles = fs.listFiles(logDir);
        for (FileInfo fi: listFiles) {
            if (fi.isDir()) {
                long tabletId = HexString.paddedHexToLong(fi.getPath().getName());
                if (!existTabletSet.contains(tabletId)) {
                    fs.delete(fi.getPath());
                    LOG.info("Log file folder is removed: " + fi.getPath());
                }
            }
        }
    }

    /**
     * list all log files for tablet, forward sort<br>
     * visibility: default, for junit test
     * 
     * @param tabletId
     * @param include_current
     * @return
     * @throws IOException
     */
    PriorityQueue<WALogFile> getSplitLogChunks(long tabletId,
            boolean include_current) throws IOException {

        PriorityQueue<WALogFile> files;
        files = new PriorityQueue<WALogFile>(10, WALogFile.FORWARD_COMP);

        FileInfo[] logfiles = listLogFiles(tabletId);

        for (FileInfo file: logfiles) {
            String s = file.getPath().getName();
            if (!s.startsWith(WALogFile.FILE_PREFIX)) {
                // invalid log file name
                continue;
            }
            WALogFile wf = new WALogFile(fs, file.getPath());
            if (include_current
                    || (!include_current && wf.getFileNumber() < Long.MAX_VALUE)) {
                files.add(wf);
            }
        }
        return files;
    }

    private FileInfo[] listLogFiles(long tabletId) throws IOException {
        Path tabletLogPath = logDir.cat(HexString.longToPaddedHex(tabletId));
        if (!fs.exists(tabletLogPath)) {
            return new FileInfo[0];
        }
        return fs.listFiles(tabletLogPath);
    }

    private long getLSNByPath(Path path) {
        String name = path.getName();
        long logFileNumber = Long.parseLong(name.substring(WALogFile.FILE_PREFIX.length()));
        return logFileNumber;
    }

    /**
     * delete useless log files after tablet's check point
     * 
     * @param tabletId
     * @param checkPoint
     * @throws IOException
     */
    private void removeFilesByCheckPoint(long tabletId, long checkPoint)
            throws IOException {
        FileInfo[] logfiles = listLogFiles(tabletId);
        List<Path> toRemove = new ArrayList<Path>();
        for (FileInfo fi: logfiles) {
            long myLSN = getLSNByPath(fi.getPath());
            if (myLSN < checkPoint) {
                toRemove.add(fi.getPath());
            }
        }
        //sort: the older file should be deleted first
        Collections.sort(toRemove, new Comparator<Path>() {
            @Override
            public int compare(Path o1, Path o2) {
                long lsnByPath1 = getLSNByPath(o1);
                long lsnByPath2 = getLSNByPath(o2);
                if (lsnByPath1 == lsnByPath2) {
                    return 0;
                }
                return lsnByPath1 < lsnByPath2 ? -1 : 1;
            }
        });
        //remove useless log files
        for (Path path: toRemove) {
            if (!fs.delete(path)) {
                LOG.warning("Fail to remove useless log: " + path
                        + ", not big deal, will retry while next checkpoint");
                break;
            }
        }
    }

    private Object checkpointWRLock = new Object();

    /**
     * Try to find the last check point. If not found, return null.
     * 
     * @return
     */
    private LongLongHashMap getLastDiskChkpt() {
        // first try to read checkpoint directly
        Path file = logDir.cat(OmapConstants.CHKPT_FILENAME);
        try {
            if (!fs.exists(file)) {
                LOG.log(Level.INFO, "Checkpoint file " + file + " not found");
                return null;
            }
            WALogChkPt checkpoint = new WALogChkPt();
            synchronized (checkpointWRLock) {
                FSDataInputStream input = fs.open(file);
                checkpoint.readFields(input);
                input.close();
            }
            return checkpoint.getCheckpoint();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Failed to open checkpoint file: " + file
                    + ", this may cause data error while do recovering.", e);
        }
        // then to find checkpoint from logs, will be much slower
        try {
            InsertLogEntry entry = new InsertLogEntry();
            LogIterator logIter = revIterator(false);
            while (logIter.next(entry)) {
                if (entry.getBody() instanceof WALogChkPt) {
                    return ((WALogChkPt) entry.getBody()).getCheckpoint();
                }
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING, "finding checkpoint failed, "
                    + "this may cause tablet recover error", e);
            return null;
        }
        LOG.log(Level.INFO, "Cannot find a checkpoint in " + this.logDir);
        return null;
    }

    /**
     * Check point file can only be written by this function
     * 
     * @param checkpoints
     * @return
     * @throws IOException
     */
    private long writeChkPtLog(LongLongHashMap checkpoints) throws IOException {
        LOG.log(Level.FINE, "Writing a check point log");
        TESTCASE_PREPENSE_EXCEPTION_TYPE.prepenseException(TESTCASE_PREPENSE_EXCEPTION_TYPE.TS_PREPENSE_EXCEPTION_WHILE_WRITE_CHECKPOINT);

        InsertLogEntry chkbuf = new InsertLogEntry();
        WALogChkPt body = new WALogChkPt(checkpoints);
        chkbuf.setBody(body);

        long checkptlsn = write(chkbuf);
        Path checkpointFile = logDir.cat(OmapConstants.CHKPT_FILENAME);
        Path tmpCheckpointFile = logDir.cat(OmapConstants.CHKPT_FILENAME
                + ".tmp");
        FSDataOutputStream out = null;
        synchronized (checkpointWRLock) {
            boolean writeSucc = false;
            try {
                fs.deprive(checkpointFile);
                out = fs.create(tmpCheckpointFile, false);
                body.writeFields(out);
                out.close();
                writeSucc = true;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "write tmp checkpoint file failed", e);
            }
            if (writeSucc) {
                try {
                    fs.rename(tmpCheckpointFile, checkpointFile);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "rename tmp checkpoint file failed",
                            e);
                }
            } else {
                try {
                    fs.deprive(tmpCheckpointFile);
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "abandon tmp checkpoint file failed", e);
                }
            }
        }
        return checkptlsn;
    }
}
