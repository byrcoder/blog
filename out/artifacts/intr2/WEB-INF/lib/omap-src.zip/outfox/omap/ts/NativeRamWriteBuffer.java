/**
 * @(#)NativeRamWriteBuffer.java, 2012-5-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.ReusableByteArrayInputStream;
import odis.serialize.lib.ByteArrayWritable;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferCDataInputStream;
import odis.util.unsafe.UnsafeHelper;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.WriteBufferOverflowException;
import outfox.omap.metadata.KeyColumnDesc;
import outfox.omap.util.CloseableIterator;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class NativeRamWriteBuffer {

    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(NativeRamWriteBuffer.class);

    private volatile boolean closed;

    private final WriteBufferPool bufferPool;

    private volatile NativeRamBuffer[] buffers;

    private volatile int capacity;

    private volatile int writeOffset;

    private volatile int validSize;

    private final int indexOfBufferShift;

    private final int offsetInBufferMask;

    private final long tabletId;

    private final SkipListSet index;

    final KeyColumnDesc kcd;

    private void checkState() {
        if (closed) {
            throw new IllegalStateException("closed");
        }
    }

    public class KeyComparator {
        private final NativeRamBufferCDataInputStream input;

        private final ReusableByteArrayInputStream byteInput;

        private final CDataInputStream dataInput;

        public KeyComparator(NativeRamBufferCDataInputStream input) {
            this.input = input;
            this.byteInput = new ReusableByteArrayInputStream();
            this.dataInput = new CDataInputStream(byteInput);
        }

        public int compare(KeyCell keyCell, long l) throws IOException {
            return keyCell.compareTo(readKey(l));
        }

        public KeyCell getKey(ByteArrayWritable key) throws IOException {
            byteInput.setBuffer(key.data(), 0, key.size());
            KeyCell cell = kcd.borrowKeyCell();
            cell.readPIFields(dataInput);
            return cell;
        }

        public void returnKey(KeyCell keyCell) {
            kcd.returnKeyCell(keyCell);
        }

        public KeyCell readKey(long key) throws IOException {
            checkState();
            int offset = (int) (key >>> 32);
            KeyCell keyCell = kcd.borrowKeyCell();
            input.seek(offset + 1); // skip the flag of DataRow
            keyCell.readPIFields(input);
            return keyCell;
        }
    }

    public NativeRamWriteBuffer(long tabletId, WriteBufferPool bufferPool,
            KeyColumnDesc kcd) throws IOException {
        this.tabletId = tabletId;
        this.bufferPool = bufferPool;
        this.validSize = 0;
        this.kcd = kcd;
        this.buffers = new NativeRamBuffer[0];
        int chunkSize = bufferPool.getChunkSize();
        this.indexOfBufferShift = UnsafeHelper.log2(chunkSize);
        this.offsetInBufferMask = chunkSize - 1;
        this.index = new SkipListSet(new KeyComparator(
                new NativeRamBufferCDataInputStream(buffers,
                        bufferPool.getChunkSize(), 0)), bufferPool);
    }

    public boolean get(ByteArrayWritable key, ByteArrayWritable row)
            throws IOException {
        checkState();
        long entry = index.get(key);
        if (entry >= 0) {
            // found
            NativeRamBufferCDataInputStream bufferInput = index.comparator.input;
            bufferInput.seek((int) (entry >>> 32));
            row.readBytes(bufferInput, (int) entry);
            return true;
        } else {
            return false;
        }
    }

    private int bufferCapacity() {
        return capacity;
    }

    private int writeOffset() {
        return writeOffset;
    }

    public void put(ByteArrayWritable row) throws IOException {
        checkState();
        int rowLength = row.size();
        int capacity = bufferCapacity();
        if (rowLength + capacity < 0) {
            // int overflow
            throw new WriteBufferOverflowException("Write buffer of "
                    + HexString.longToPaddedHex(tabletId)
                    + " is about to overflow, current size " + capacity);
        }
        int writeOffset = writeOffset();
        int needBufferSize = rowLength - (capacity - writeOffset);
        if (needBufferSize > 0) {
            NativeRamBuffer[] allocatedBuffers = bufferPool.newBuffer(needBufferSize);
            int allocatedBufferSize = allocatedBuffers.length
                    * bufferPool.getChunkSize();
            if (allocatedBufferSize < needBufferSize) {
                bufferPool.releaseBuffer(allocatedBuffers);
                throw new WriteBufferOverflowException(
                        "Can not allocated enough write buffer for "
                                + HexString.longToPaddedHex(tabletId)
                                + ", current size " + writeOffset);
            }
            NativeRamBuffer[] oldBuffers = buffers;
            NativeRamBuffer[] newBuffers = Arrays.copyOf(oldBuffers,
                    oldBuffers.length + allocatedBuffers.length);
            System.arraycopy(allocatedBuffers, 0, newBuffers,
                    oldBuffers.length, allocatedBuffers.length);
            this.buffers = newBuffers;
            capacity = newBuffers.length * bufferPool.getChunkSize();
            this.capacity = capacity;
            index.comparator.input.resetBuffers(newBuffers,
                    bufferPool.getChunkSize(), capacity);
        }
        UnsafeHelper.write(row.data(), 0, rowLength, buffers, capacity,
                indexOfBufferShift, offsetInBufferMask, writeOffset, false);

        long newIndexEntry = (((long) writeOffset) << 32) | rowLength;
        long oldIndexEntry = index.put(newIndexEntry);
        int validSize = this.validSize;
        if (oldIndexEntry != Long.MIN_VALUE) {
            validSize -= (int) oldIndexEntry;
        }
        this.writeOffset = writeOffset + rowLength;
        this.validSize = validSize + rowLength;
    }

    public static interface WriteBufferIterator extends
            CloseableIterator<ByteArrayWritable> {
        /**
         * move cursor to the position before the first element.
         */
        void reset();
    }

    public class Iter implements WriteBufferIterator {

        private final int startNode;

        private int currentNode;

        public Iter(int node) {
            this.startNode = this.currentNode = node;
        }

        @Override
        public boolean next(ByteArrayWritable row) throws IOException {
            checkState();
            if (currentNode == -1) {
                return false;
            }
            long lengthAndOffset = index.lengthAndOffsetOf(currentNode, true);
            currentNode = index.nextOf(currentNode, true);
            int length = (int) lengthAndOffset;
            byte[] data = row.data();
            if (data.length < length) {
                data = new byte[length];
            }
            UnsafeHelper.readFully(data, 0, length, buffers, capacity,
                    indexOfBufferShift, offsetInBufferMask,
                    (int) (lengthAndOffset >>> 32), true);
            row.setBuffer(data, length);

            return true;
        }

        @Override
        public void close() {}

        @Override
        public void reset() {
            currentNode = startNode;
        }

    }

    public WriteBufferIterator iterator() throws IOException {
        return iterator(null);
    }

    public WriteBufferIterator iterator(ByteArrayWritable startKey)
            throws IOException {
        checkState();
        return new Iter(index.ceilingNode(startKey));
    }

    public int getNumKeys() {
        checkState();
        return index.getEntryCount();
    }

    public int getValidByteSize() {
        checkState();
        return validSize + index.actualByteSize();
    }

    public int getBufferSize() {
        checkState();
        return bufferCapacity() + index.getBufferSize();
    }

    public int getActualByteSize() {
        checkState();
        return writeOffset() + index.actualByteSize();
    }

    public void close() {
        closed = true;
        OmapUtils.safeClose(index);
        bufferPool.releaseBuffer(buffers);
        buffers = null;
    }
}
