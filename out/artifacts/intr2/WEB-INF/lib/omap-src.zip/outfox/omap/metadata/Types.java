/**
 * Copyright (c) 2001-2005, The HSQL Development Group All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer. Redistributions in binary
 * form must reproduce the above copyright notice, this list of conditions and
 * the following disclaimer in the documentation and/or other materials provided
 * with the distribution. Neither the name of the HSQL Development Group nor the
 * names of its contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission. THIS SOFTWARE
 * IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL HSQL DEVELOPMENT GROUP, HSQLDB.ORG, OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/**
 * @(#)Types.java, 2010-8-26. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metadata;

import java.nio.CharBuffer;
import java.util.HashMap;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.BooleanWritable;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.ByteWritable;
import odis.serialize.lib.BytesWritable;
import odis.serialize.lib.DoubleWritable;
import odis.serialize.lib.FloatWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.ShortWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.lib.VIntWritable;
import odis.serialize.lib.VLongWritable;
import outfox.omap.client.query.IndexSchema;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.data.FixedLengthBytesWritable;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.exceptions.BadTypeStringException;
import outfox.omap.exceptions.NoSuchTypeException;
import outfox.omap.master.AssignTabletTask;
import toolbox.misc.LogFormatter;

/**
 * <p>
 * Defines the codes of internal types, and methods to translate between type
 * codes, type names and aliases, and type classes.
 * </p>
 * <p>
 * Type names and their corresponding Writables supported by OMAP:
 * <table>
 * <tr>
 * <td>Type name</td>
 * <td>Writable class</td>
 * </tr>
 * <tr>
 * <td>BYTE</td>
 * <td>{@link odis.serializable.lib.ByteWritable}</td>
 * </tr>
 * <tr>
 * <td>BOOLEAN</td>
 * <td>{@link odis.serializable.lib.BooleanWritable}</td>
 * </tr>
 * <tr>
 * <td>SHORT</td>
 * <td>{@link odis.serializable.lib.ShortWritable}</td>
 * </tr>
 * <tr>
 * <td>INTEGER</td>
 * <td>{@link odis.serializable.lib.IntWritable}</td>
 * </tr>
 * <tr>
 * <td>LONG</td>
 * <td>{@link odis.serializable.lib.LongWritable}</td>
 * </tr>
 * <tr>
 * <td>FLOAT</td>
 * <td>{@link odis.serializable.lib.FloatWritable}</td>
 * </tr>
 * <tr>
 * <td>DOUBLE</td>
 * <td>{@link odis.serializable.lib.DoubleWritable}</td>
 * </tr>
 * <tr>
 * <td>STRING</td>
 * <td>{@link odis.serializable.lib.UTF8Writable} (Deprecated, recommend to use
 * TEXT instead)</td>
 * </tr>
 * <tr>
 * <td>VINT</td>
 * <td>{@link odis.serializable.lib.VIntWritable}</td>
 * </tr>
 * <tr>
 * <td>VLONG</td>
 * <td>{@link odis.serializable.lib.VLongWritable}</td>
 * </tr>
 * <tr>
 * <td>TEXT / VINTSTRING</td>
 * <td>{@link odis.serializable.lib.StringWritable}</td>
 * </tr>
 * <tr>
 * <td>BLOB / VINTBYTEARRAY</td>
 * <td>{@link odis.serializable.lib.ByteArrayWritable}</td>
 * </tr>
 * <tr>
 * <td>BYTEARRAY</td>
 * <td>{@link odis.serializable.lib.BytesWritable}</td>
 * </tr>
 * <tr>
 * <td>TPKEY</td>
 * <td>{@link outfox.data.KeyPair}</td>
 * </tr>
 * </table>
 * </p>
 * <p>
 * You may use either the type name or the Writable class name in
 * {@link outfox.omap.client.OmapTableSpace#createTable(String, String)}
 * </p>
 * 
 * @author zhangkun
 */
public class Types {
    private static final Logger LOG = LogFormatter.getLogger(Types.class);

    /**
     * Omap type enum
     */
    public static enum Type {
        CUSTOM, TPKEY, TABLEREF, NULL, BYTE, BOOLEAN, SHORT, INTEGER, LONG,
        FLOAT, DOUBLE, STRING, VINT, VLONG, TEXT, VINTSTRING, BLOB, VINTBYTEARRAY,
        BYTEARRAY, FIXEDLENBYTEARRAY, TABLEDESC, KEYRANGE, SCHEMAIDANDKEYRANGE,
        TASKDESC, OMAPQUERY, INDEXSCHEMA;
    }

    // lookup for types
    // boucherb@users - access changed for metadata 1.7.2
    private final static HashMap<String, Type> typeAliases;

    // static IntValueHashMap javaTypeNames;

    // boucherb@users - We can't handle method invocations in
    // Function.java whose number class is
    // narrower than the corresponding internal
    // wrapper
    // private static org.hsqldb.lib.HashSet illegalParameterClasses;

    static {
        typeAliases = new HashMap<String, Type>();
        for (Type type: Type.values()) {
            typeAliases.put(type.toString(), type);
        }
        typeAliases.put(getWritableName(Type.BYTE), Type.BYTE);
        typeAliases.put(getWritableName(Type.BOOLEAN), Type.BOOLEAN);
        typeAliases.put(getWritableName(Type.SHORT), Type.SHORT);
        typeAliases.put(getWritableName(Type.INTEGER), Type.INTEGER);
        typeAliases.put(getWritableName(Type.LONG), Type.LONG);
        typeAliases.put(getWritableName(Type.FLOAT), Type.FLOAT);
        typeAliases.put(getWritableName(Type.DOUBLE), Type.DOUBLE);
        typeAliases.put(getWritableName(Type.STRING), Type.STRING);
        typeAliases.put(getWritableName(Type.VINT), Type.VINT);
        typeAliases.put(getWritableName(Type.VLONG), Type.VLONG);
        typeAliases.put(getWritableName(Type.TEXT), Type.TEXT);
        typeAliases.put(getWritableName(Type.VINTSTRING), Type.VINTSTRING);
        typeAliases.put(getWritableName(Type.BLOB), Type.BLOB);
        typeAliases.put(getWritableName(Type.VINTBYTEARRAY), Type.VINTBYTEARRAY);
        typeAliases.put(getWritableName(Type.BYTEARRAY), Type.BYTEARRAY);
        typeAliases.put(getWritableName(Type.OMAPQUERY), Type.OMAPQUERY);
        typeAliases.put(getWritableName(Type.INDEXSCHEMA), Type.INDEXSCHEMA);
    }

    /**
     * Get the Writable class name corresponding to the given Type
     * 
     * @param type
     * @return
     * @throws NoSuchTypeException
     */
    public static String getWritableName(Type type) throws NoSuchTypeException {
        switch (type) {
            case BYTE:
                return ByteWritable.class.getName();

            case BOOLEAN:
                return BooleanWritable.class.getName();

            case SHORT:
                return ShortWritable.class.getName();

            case INTEGER:
                return IntWritable.class.getName();

            case LONG:
                return LongWritable.class.getName();

            case FLOAT:
                return FloatWritable.class.getName();

            case DOUBLE:
                return DoubleWritable.class.getName();

            case STRING:
                return UTF8Writable.class.getName();

            case VINT:
                return VIntWritable.class.getName();
            case VLONG:
                return VLongWritable.class.getName();

            case TEXT:
            case VINTSTRING:
                return StringWritable.class.getName();

            case BLOB:
            case VINTBYTEARRAY:
                return ByteArrayWritable.class.getName();

            case BYTEARRAY:
                return BytesWritable.class.getName();

            case FIXEDLENBYTEARRAY:
                return FixedLengthBytesWritable.class.getName();

            case TABLEDESC:
                return TableDesc.class.getName();

            case KEYRANGE:
                return KeyRange.class.getName();

            case TASKDESC:
                return AssignTabletTask.class.getName();

            case OMAPQUERY:
                return OmapQuery.class.getName();

            case INDEXSCHEMA:
                return IndexSchema.class.getName();

            case CUSTOM:
                return ByteArrayWritable.class.getName();
            case TPKEY:
                return KeyPair.class.getName();
            default:
                throw new NoSuchTypeException("unknown type code:" + type);
        }
    }

    public static IWritable getWritable(Type type) {
        switch (type) {
            case BYTE:
                return new ByteWritable();

            case BOOLEAN:
                return new BooleanWritable();

            case SHORT:
                return new ShortWritable();

            case INTEGER:
                return new IntWritable();

            case LONG:
                return new LongWritable();

            case FLOAT:
                return new FloatWritable();

            case DOUBLE:
                return new DoubleWritable();

            case STRING:
                return new UTF8Writable();

            case VINT:
                return new VIntWritable();
            case VLONG:
                return new VLongWritable();
            case TEXT:
            case VINTSTRING:
                return new StringWritable();

            case BLOB:
            case VINTBYTEARRAY:
                return new ByteArrayWritable();

            case BYTEARRAY:
                return new BytesWritable();

            case FIXEDLENBYTEARRAY:
                return new FixedLengthBytesWritable();

            case TABLEDESC:
                return new TableDesc();

            case KEYRANGE:
                return new KeyRange();

            case TASKDESC:
                return new AssignTabletTask();

            case OMAPQUERY:
                return new OmapQuery();

            case INDEXSCHEMA:
                return new IndexSchema();

            case CUSTOM:
                return new ByteArrayWritable();
            case TPKEY:
                return new KeyPair();
            default:
                throw new NoSuchTypeException("unknown type code:" + type);
        }
    }

    private static void printTypesSupported() {
        for (String alias: typeAliases.keySet()) {
            System.out.println(alias);
        }
    }

    public static Type getType(String definition) {
        CharBuffer inputBuffer = CharBuffer.wrap(definition);
        String typeName = readFirstToken(inputBuffer);
        return getTypeByName(typeName);
    }

    /**
     * Parse the type definition String and construct a IWritable corresponding
     * to the definition. A type definition String can be:
     * <ol>
     * <li>Simply the enum name of a simple type, e.g. <code>BOOLEAN</code> or
     * <code>STRING</code></li>
     * <li>A Tuple Key definition, e.g. <code>TPKEY(STRING LONG)</code> or
     * <code>TPKEY(STRING TPKEY(INTEGER LONG))</code></li>
     * <li>A fixed-length byte array, e.g. <code>FIXEDLENBYTEARRAY(50)</code></li>
     * <li>A custom IWritable type definition, e.g.
     * <code>CUSTOM(somepkg.SomeIWritable)</code>
     * </ol>
     * 
     * @param definition
     * @return
     * @throws BadTypeStringException
     */
    public static IWritable getIWritable(String definition)
            throws BadTypeStringException {
        CharBuffer inputBuffer = CharBuffer.wrap(definition);
        return getIWritableInternal(inputBuffer);
    }

    /**
     * Get the type corresponding to the given type name, which could be whether
     * a type alias or the class name.
     * 
     * @param typeName
     * @return
     */
    public static Type getTypeByName(String typeName) {
        Type type = typeAliases.get(typeName);
        if (type == Type.STRING) {
            LOG.warning("Deprecated type: 'STRING' (UTF8Writable) is deprecated. Recommend to use 'TEXT' (StringWritable)");
        }
        return type;
    }

    /**
     * Parse the definition String and construct a IWritable corresponding to
     * the definition.
     * 
     * @param definition
     * @return
     * @throws BadTypeStringException
     */
    private static IWritable getIWritableInternal(CharBuffer inputBuffer)
            throws BadTypeStringException {
        String typeName = readFirstToken(inputBuffer);
        Type type = getTypeByName(typeName);
        if (type == null) {
            throw new NoSuchTypeException(typeName);
        }
        try {
            switch (type) {
                case TPKEY:
                    readFirstTokenAndAssert(inputBuffer, "(");
                    IWritableComparable key1 = (IWritableComparable) getIWritableInternal(inputBuffer);
                    IWritableComparable key2 = (IWritableComparable) getIWritableInternal(inputBuffer);
                    readFirstTokenAndAssert(inputBuffer, ")");
                    return new KeyPair(key1, key2);
                case FIXEDLENBYTEARRAY:
                    readFirstTokenAndAssert(inputBuffer, "(");
                    String size = readFirstToken(inputBuffer);
                    readFirstTokenAndAssert(inputBuffer, ")");
                    return new FixedLengthBytesWritable(Integer.parseInt(size));
                case CUSTOM:
                    readFirstTokenAndAssert(inputBuffer, "(");
                    readFirstToken(inputBuffer);
                    readFirstTokenAndAssert(inputBuffer, ")");
                    // do not try to create any client type object, let user pass the actual object in.
                    return new ByteArrayWritable();
            }
            IWritable ret = (IWritable) (Class.forName(getWritableName(type)).newInstance());
            return ret;
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new BadTypeStringException(typeName, e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        }
    }

    private static void readFirstTokenAndAssert(CharBuffer input, String token)
            throws BadTypeStringException {
        String next = readFirstToken(input);
        if (!token.equals(next)) {
            throw new BadTypeStringException("Got '" + input.toString()
                    + "', '" + token + "' required");
        }
    }

    private static String readFirstToken(CharBuffer input) {
        StringBuilder buffer = new StringBuilder();
        while (input.hasRemaining()) {
            char next = input.charAt(0);
            if (next == '(' || next == ')') {
                if (buffer.length() == 0) {
                    buffer.append(next);
                    input.position(input.position() + 1);
                }
                break;
            } else if (next == ' ' || next == '\t' || next == '\n'
                    || next == '\r') {
                if (buffer.length() > 0) {
                    break;
                }
            } else {
                buffer.append(next);
            }
            input.position(input.position() + 1);
        }
        if (buffer.length() == 0) {
            return null;
        }
        return buffer.toString();
    }

    /**
     * @param typeString
     * @return
     * @throws BadTypeStringException
     */
    public static boolean isCustomType(String typeString)
            throws BadTypeStringException {
        String type = readFirstToken(CharBuffer.wrap(typeString));
        return Type.CUSTOM.toString().equals(type);
    }

    public static void main(String[] args) {
        printTypesSupported();
    }

}
