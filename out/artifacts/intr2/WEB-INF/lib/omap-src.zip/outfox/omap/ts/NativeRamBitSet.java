/**
 * @(#)NativeRamBitSet.java, 2012-5-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.UnsafeHelper;

/**
 * @author zhangduo
 */
class NativeRamBitSet {
    final NativeRamBuffer[] buffers;

    private final int bitSetSize;

    private final int indexOfBufferShift;

    private final int offsetInBufferMask;

    private static final int BIT_INDEX_IN_WORD_MASK = (1 << 6) - 1;

    NativeRamBitSet(NativeRamBuffer[] buffers, int bufferSize, byte[] bits,
            int bitSetSize) {
        for (NativeRamBuffer buffer: buffers) {
            if (buffer.getCapacity() != bufferSize) {
                throw new IllegalArgumentException();
            }
        }
        int size = (bitSetSize + 7) >> 3;
        if (size > bufferSize * buffers.length) {
            throw new IllegalArgumentException();
        }
        int indexOfBufferShift = 0;
        for (long tmp = bufferSize; tmp > 1; indexOfBufferShift++) {
            if ((tmp & 1) != 0) {
                throw new IllegalArgumentException();
            }
            tmp >>>= 1;
        }
        // the argument passed in is in bit, not in bytes, so we need to shift 
        // 3 bits more.
        this.indexOfBufferShift = indexOfBufferShift + 3;
        this.offsetInBufferMask = (bufferSize << 3) - 1;
        NativeRamBuffer.copyFromArray(buffers, bits, 0, size);
        this.bitSetSize = bitSetSize;
        this.buffers = buffers;
    }

    private int indexOfBuffer(int bitIndex) {
        return bitIndex >>> indexOfBufferShift;
    }

    private int offsetInBuffer(int bitIndex) {
        return bitIndex & offsetInBufferMask;
    }

    private int wordOffset(int bitIndex) {
        return ((bitIndex >> 6) << 3);
    }

    private int bitIndexInWord(int bitIndex) {
        return bitIndex & BIT_INDEX_IN_WORD_MASK;
    }

    public boolean get(int bitIndex) {
        NativeRamBuffer buffer = buffers[indexOfBuffer(bitIndex)];
        bitIndex = offsetInBuffer(bitIndex);
        int wordOffset = wordOffset(bitIndex);
        int bitIndexInWord = bitIndexInWord(bitIndex);
        return (UnsafeHelper.unsafe.getLong(buffer.getPtr() + wordOffset) & (1L << bitIndexInWord)) != 0;
    }

    /**
     * if all the bits are 1, return true, otherwise return false.
     * 
     * @param bitIndexs
     * @return
     */
    public boolean get(int[] bitIndexes) {
        for (int bitIndex: bitIndexes) {
            if (!get(bitIndex)) {
                return false;
            }
        }
        return true;
    }

    public int size() {
        return bitSetSize;
    }

    public int byteSize() {
        return (bitSetSize + 7) >> 3;
    }
}
