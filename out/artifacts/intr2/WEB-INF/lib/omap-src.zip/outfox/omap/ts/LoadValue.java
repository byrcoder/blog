/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.ts;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * The load values of a Tablet or a Table
 * 
 * @author zhangkun
 */
public class LoadValue implements IWritable {
    // spatial loads
    protected long memory = 0;

    protected long bloomFilterSize = 0;

    protected long writeBufferSize = 0;

    protected long numKeys = 0;

    protected long dataSize = 0;

    protected long originDataSize = 0;

    // access loads
    protected long readCount = 0;

    protected long writeCount = 0;

    // the following loads will decrease as time passes
    protected long readLoad = 0;

    protected long writeLoad = 0;

    public LoadValue add(LoadValue l) {
        memory += l.memory;
        bloomFilterSize += l.bloomFilterSize;
        writeBufferSize += l.writeBufferSize;
        numKeys += l.numKeys;
        dataSize += l.dataSize;
        originDataSize += l.originDataSize;
        readCount += l.readCount;
        writeCount += l.writeCount;
        readLoad += l.readLoad;
        writeLoad += l.writeLoad;
        return this;
    }

    public long getMemory() {
        return memory;
    }

    public void setMemory(long memory) {
        this.memory = memory;
    }

    public long getBloomFilterSize() {
        return bloomFilterSize;
    }

    public void setBloomFilterSize(long bloomFilterSize) {
        this.bloomFilterSize = bloomFilterSize;
    }

    public long getWriteBufferSize() {
        return writeBufferSize;
    }

    public void setWriteBufferSize(long writeBufferSize) {
        this.writeBufferSize = writeBufferSize;
    }

    public long getNumKeys() {
        return numKeys;
    }

    public void setNumKeys(long numKeys) {
        this.numKeys = numKeys;
    }

    public long getDataSize() {
        return dataSize;
    }

    public void setDataSize(long dataSize) {
        this.dataSize = dataSize;
    }

    public long getOriginDataSize() {
        return originDataSize;
    }

    public void setOriginDataSize(long originDataSize) {
        this.originDataSize = originDataSize;
    }

    public long getReadCount() {
        return readCount;
    }

    public void setReadCount(long readCount) {
        this.readCount = readCount;
    }

    public long getWriteCount() {
        return writeCount;
    }

    public void setWriteCount(long writeCount) {
        this.writeCount = writeCount;
    }

    public long getReadLoad() {
        return readLoad;
    }

    public void setReadLoad(long readLoad) {
        this.readLoad = readLoad;
    }

    public long getWriteLoad() {
        return writeLoad;
    }

    public void setWriteLoad(long writeLoad) {
        this.writeLoad = writeLoad;
    }

    public void decreaseLoad(double divider) {
        readLoad /= divider;
        writeLoad /= divider;
    }

    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVLong(memory, out);
        CDataOutputStream.writeVLong(bloomFilterSize, out);
        CDataOutputStream.writeVLong(writeBufferSize, out);
        CDataOutputStream.writeVLong(readLoad, out);
        CDataOutputStream.writeVLong(writeLoad, out);
        CDataOutputStream.writeVLong(readCount, out);
        CDataOutputStream.writeVLong(writeCount, out);
        CDataOutputStream.writeVLong(numKeys, out);
        CDataOutputStream.writeVLong(dataSize, out);
        CDataOutputStream.writeVLong(originDataSize, out);
    }

    public void readFields(DataInput in) throws IOException {
        memory = CDataInputStream.readVLong(in);
        bloomFilterSize = CDataInputStream.readVLong(in);
        writeBufferSize = CDataInputStream.readVLong(in);
        readLoad = CDataInputStream.readVLong(in);
        writeLoad = CDataInputStream.readVLong(in);
        readCount = CDataInputStream.readVLong(in);
        writeCount = CDataInputStream.readVLong(in);
        numKeys = CDataInputStream.readVLong(in);
        dataSize = CDataInputStream.readVLong(in);
        originDataSize = CDataInputStream.readVLong(in);
    }

    public IWritable copyFields(IWritable o) {
        LoadValue l = (LoadValue) o;
        memory = l.memory;
        bloomFilterSize = l.bloomFilterSize;
        writeBufferSize = l.writeBufferSize;
        readLoad = l.readLoad;
        writeLoad = l.writeLoad;
        readCount = l.readCount;
        writeCount = l.writeCount;
        numKeys = l.numKeys;
        dataSize = l.dataSize;
        originDataSize = l.originDataSize;
        return this;
    }

    @Override
    public String toString() {
        return "LoadValue [memory=" + memory + ", bloomFilterSize="
                + bloomFilterSize + ", writeBufferSize=" + writeBufferSize
                + ", numKeys=" + numKeys + ", dataSize=" + dataSize
                + ", originDataSize=" + originDataSize + ", readCount="
                + readCount + ", writeCount=" + writeCount + ", readLoad="
                + readLoad + ", writeLoad=" + writeLoad + "]";
    }

}
