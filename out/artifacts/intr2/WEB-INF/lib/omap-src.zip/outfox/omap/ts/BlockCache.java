/**
 * @(#)BlockCache.java, 2011-10-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferPool;
import outfox.omap.exceptions.LogicException;
import outfox.omap.metrics.TsGlobalMetricsEntry;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class BlockCache {

    private static final Logger LOG = LogFormatter.getLogger(BlockCache.class);

    private static final int DEFAULT_INITIAL_CAPACITY = 16;

    private static final float DEFAULT_LOAD_FACTOR = 0.75f;

    final class BlockCacheEntry {
        // one for hold in block cache and one for read acquire
        private final AtomicInteger ref = new AtomicInteger(2);

        public final NativeRamBuffer[] buffers;

        public final int blockSize;

        private BlockCacheEntry(NativeRamBuffer[] buffers, int blockSize) {
            this.buffers = buffers;
            this.blockSize = blockSize;
        }

        private boolean released = false;

        boolean drop() {
            if (ref.decrementAndGet() == 0) {
                synchronized (pool) {
                    if (released) {
                        throw new LogicException(
                                "Block cache released multiple times");
                    }
                    released = true;
                    pool.releaseBuffer(buffers);
                }
                return true;
            } else {
                return false;
            }
        }
    }

    private static final class Entry extends HashHelper.HashEntryBase<Entry> {

        private final Segment segment;

        private final int blockIndex;

        private BlockCacheEntry value;

        // used for LRU
        private Entry before, after;

        public Entry(int hash, Segment segment, int blockIndex,
                BlockCacheEntry value, Entry next) {
            super(hash);
            this.segment = segment;
            this.blockIndex = blockIndex;
            this.value = value;
            this.next = next;
        }

        private void addBefore(Entry existingEntry) {
            after = existingEntry;
            before = existingEntry.before;
            before.after = this;
            after.before = this;
        }

        private void remove() {
            before.after = after;
            after.before = before;
        }
    }

    private final class Segment extends HashHelper.HashEntryBase<Segment> {

        private final String sstableName;

        private int threshold;

        private Entry[] table;

        private int size;

        Segment(int hash, String sstableName, int capacity, Segment next) {
            super(hash);
            this.sstableName = sstableName;
            table = new Entry[capacity];
            threshold = (int) (capacity * loadFactor);
            this.next = next;
        }

        BlockCacheEntry get(int blockIndex) {
            int hash = blockIndex;
            for (Entry e = table[HashHelper.indexFor(hash, table.length)]; e != null; e = e.next) {
                if (e.blockIndex == blockIndex) {
                    e.remove();
                    e.addBefore(head);
                    if (e.value.ref.getAndIncrement() == 0) {
                        throw new RuntimeException("Fatal error: block cache "
                                + sstableName + "." + blockIndex
                                + " has ref count 0");
                    }
                    return e.value;
                }
            }
            return null;
        }

        private void resize(int newCapacity) {
            Entry[] newTable = new Entry[newCapacity];
            HashHelper.transfer(table, newTable);
            table = newTable;
            threshold = (int) (newCapacity * loadFactor);
        }

        private void addEntry(int hash, int blockIndex, BlockCacheEntry value,
                int bucketIndex) {
            Entry entryHead = table[bucketIndex];
            Entry e = new Entry(hash, this, blockIndex, value, entryHead);
            table[bucketIndex] = e;
            e.addBefore(head);
            if (size++ >= threshold) {
                resize(2 * table.length);
            }
        }

        private BlockCacheEntry toNative(byte[] block, int off, int len) {
            NativeRamBuffer[] buffers;
            synchronized (pool) {
                buffers = pool.newBuffer(len);
            }
            NativeRamBuffer.copyFromArray(buffers, block, off, len);
            return new BlockCacheEntry(buffers, len);
        }

        /**
         * If already exists, just return it. Otherwise, construct the
         * BlockCacheEntry, put it in this segment, and return it. If construct
         * failed, return null.
         * 
         * @param blockName
         * @return
         */
        BlockCacheEntry putIfAbsent(int blockIndex, byte[] block, int off,
                int len) {
            int hash = blockIndex;
            int i = HashHelper.indexFor(hash, table.length);
            for (Entry e = table[i]; e != null; e = e.next) {
                if (e.blockIndex == blockIndex) {
                    e.remove();
                    e.addBefore(head);
                    if (e.value.ref.getAndIncrement() == 0) {
                        throw new RuntimeException("Fatal error: block cache "
                                + sstableName + "." + blockIndex
                                + " has ref count 0");
                    }
                    return e.value;
                }
            }
            int evictCount = 0;
            while (pool.getAllocatedBufferSize() + len > pool.getMaxBufferSize()) {
                Entry toRemove = head.after;
                if (toRemove == head) {
                    globalMetricsEntry.blockCacheEvict(evictCount);
                    return null;
                }
                evictCount++;
                if (!toRemove.segment.remove(toRemove.blockIndex)) {
                    // This means the block cache is still held for read by 
                    // someone, so all the block cache after it may also be 
                    // held, give up.
                    globalMetricsEntry.blockCacheEvict(evictCount);
                    return null;
                }
            }
            globalMetricsEntry.blockCacheEvict(evictCount);
            BlockCacheEntry value = toNative(block, off, len);
            addEntry(hash, blockIndex, value, i);
            return value;
        }

        /**
         * Return whether the native ram is actually released.
         * 
         * @param blockName
         * @return
         */
        private boolean remove(int blockIndex) {
            int hash = blockIndex;
            int i = HashHelper.indexFor(hash, table.length);
            Entry prev = table[i];
            Entry current = prev;
            while (current != null) {
                Entry next = current.next;
                if (current.blockIndex == blockIndex) {
                    if (--size == 0) {
                        removeSegment(sstableName);
                    } else {
                        if (prev == current) {
                            table[i] = next;
                        } else {
                            prev.next = next;
                        }
                    }
                    current.remove();
                    return current.value.drop();
                }
                prev = current;
                current = next;
            }
            return false;
        }

        void clear() {
            for (Entry e: table) {
                while (e != null) {
                    e.remove();
                    e.value.drop();
                    e = e.next;
                }
            }
        }
    }

    private Segment[] segments;

    private final float loadFactor;

    private int threshold;

    private int segmentCount;

    // for LRU
    private final Entry head;

    private final NativeRamBufferPool pool;

    private final TsGlobalMetricsEntry globalMetricsEntry;

    BlockCache(long ptr, long maxSize, int chunkSize,
            TsGlobalMetricsEntry globalMetricsEntry) {
        if (maxSize > 0) {
            this.pool = new NativeRamBufferPool(ptr, maxSize, chunkSize);
            this.globalMetricsEntry = globalMetricsEntry;
            head = new Entry(0, null, 0, null, null);
            head.before = head.after = head;
            segments = new Segment[DEFAULT_INITIAL_CAPACITY];
            loadFactor = DEFAULT_LOAD_FACTOR;
            threshold = (int) (segments.length * loadFactor);
        } else {
            this.pool = null;
            this.loadFactor = 0.0f;
            this.head = null;
            this.globalMetricsEntry = null;
        }
        LOG.info("Create block cache with max size = " + maxSize
                + ", chunk size = " + chunkSize);
    }

    private void resize(int newCapacity) {
        Segment[] newSegments = new Segment[newCapacity];
        HashHelper.transfer(segments, newSegments);
        segments = newSegments;
        threshold = (int) (newCapacity * loadFactor);
    }

    private Segment addEntry(int hash, String sstableName, int bucketIndex) {
        Segment head = segments[bucketIndex];
        Segment seg = new Segment(hash, sstableName, DEFAULT_INITIAL_CAPACITY,
                head);
        segments[bucketIndex] = seg;
        if (segmentCount++ >= threshold) {
            resize(2 * segments.length);
        }
        return seg;
    }

    private Segment getSegment(String sstableName) {
        int hash = HashHelper.hash(sstableName.hashCode());
        int i = HashHelper.indexFor(hash, segments.length);
        for (Segment segment = segments[i]; segment != null; segment = segment.next) {
            String k;
            if (segment.hash == hash
                    && ((k = segment.sstableName) == sstableName || sstableName.equals(k))) {
                return segment;
            }
        }
        return null;
    }

    private Segment removeSegment(String sstableName) {
        int hash = HashHelper.hash(sstableName.hashCode());
        int i = HashHelper.indexFor(hash, segments.length);
        Segment prev = segments[i];
        Segment current = prev;
        while (current != null) {
            Segment next = current.next;
            String k;
            if (current.hash == hash
                    && ((k = current.sstableName) == sstableName || sstableName.equals(k))) {
                segmentCount--;
                if (prev == current) {
                    segments[i] = next;
                } else {
                    prev.next = next;
                }
                break;
            }
            prev = current;
            current = next;
        }
        return current;
    }

    BlockCacheEntry cacheBlock(SSTable sstable, int blockIndex, byte[] block,
            int off, int len) {
        if (pool == null || len > pool.getMaxBufferSize()) {
            return null;
        }
        globalMetricsEntry.blockCacheCache();
        String sstableName = sstable.getCacheKey();
        int hash = HashHelper.hash(sstableName.hashCode());
        synchronized (this) {
            int i = HashHelper.indexFor(hash, segments.length);
            Segment segment;
            for (segment = segments[i]; segment != null; segment = segment.next) {
                String k;
                if (segment.hash == hash
                        && ((k = segment.sstableName) == sstableName || sstableName.equals(k))) {
                    break;
                }
            }
            if (segment == null) {
                segment = addEntry(hash, sstableName, i);
            }
            return segment.putIfAbsent(blockIndex, block, off, len);
        }
    }

    BlockCacheEntry getBlock(SSTable sstable, int blockIndex) {
        if (pool == null) {
            return null;
        }
        BlockCacheEntry block = null;
        String sstableName = sstable.getCacheKey();
        synchronized (this) {
            Segment segment = getSegment(sstableName);
            if (segment != null) {
                block = segment.get(blockIndex);
            }
        }
        globalMetricsEntry.blockCacheGet(block != null);
        return block;
    }

    void evictBlock(SSTable sstable) {
        if (pool == null) {
            return;
        }
        String sstableName = sstable.getCacheKey();
        int evictCount;
        synchronized (this) {
            Segment segment = removeSegment(sstableName);
            if (segment == null) {
                return;
            }
            evictCount = segment.size;
            segment.clear();
        }
        globalMetricsEntry.blockCacheEvict(evictCount);
    }

    public long getUsedSize() {
        if (pool == null) {
            return 0;
        }
        synchronized (pool) {
            return pool.getAllocatedBufferSize();
        }
    }

    public int getChunkSize() {
        return pool == null ? 0 : (int) pool.getChunkSize();
    }

    public long getMaxSize() {
        return pool == null ? 0 : pool.getMaxBufferSize();
    }
}
