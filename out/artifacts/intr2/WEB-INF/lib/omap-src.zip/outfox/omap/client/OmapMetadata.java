package outfox.omap.client;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.lib.UTF8Writable;
import outfox.omap.client.protocol.Metadata;
import outfox.omap.client.query.IndexSchema;
import outfox.omap.client.query.OmapQuery;
import outfox.omap.client.query.OmapQueryUtils;
import outfox.omap.data.KeyCell;
import outfox.omap.metadata.ColumnDesc;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.OmapUtils;

public class OmapMetadata implements Metadata, IWritable {

    public static final Comparator<OmapMetadata> SCHEMA_ID_COMPARATOR = new Comparator<OmapMetadata>() {

        @Override
        public int compare(OmapMetadata o1, OmapMetadata o2) {
            long s1 = o1.desc.getSchemaId();
            long s2 = o2.desc.getSchemaId();
            return s1 > s2 ? 1 : s1 == s2 ? 0 : -1;
        }
    };

    private TableDesc desc;

    private Map<String, OmapQuery> queries;

    private Map<IndexSchema, String> indexMap;

    // a map between unprepared index schema to prepared index schema
    private Map<IndexSchema, IndexSchema> preparedIndexSchemaMap;

    // only used for readFields
    public OmapMetadata() {}

    public OmapMetadata(TableDesc desc) {
        this.desc = desc;
        this.queries = OmapQueryUtils.EMPTY_QUERY_MAP;
        this.indexMap = OmapQueryUtils.EMPTY_INDEX_MAP;
        this.preparedIndexSchemaMap = new HashMap<IndexSchema, IndexSchema>();
    }

    public OmapMetadata(TableDesc desc, OmapQuery[] queries,
            Map<IndexSchema, String> indexMap) {
        this.desc = desc;
        this.indexMap = indexMap;
        preparedIndexSchemaMap = new HashMap<IndexSchema, IndexSchema>();
        for (IndexSchema is: indexMap.keySet()) {
            preparedIndexSchemaMap.put(is, is);
        }

        this.queries = new HashMap<String, OmapQuery>(queries.length);
        for (OmapQuery query: queries) {
            this.queries.put(query.getName(), query);
        }
    }

    public OmapMetadata(TableDesc desc, Map<String, OmapQuery> queries,
            Map<IndexSchema, String> indexMap) {
        this.desc = desc;
        this.queries = queries;
        this.indexMap = indexMap;

        preparedIndexSchemaMap = new HashMap<IndexSchema, IndexSchema>();
        for (IndexSchema is: indexMap.keySet()) {
            preparedIndexSchemaMap.put(is, is);
        }
    }

    public KeyCell createKeyCell() {
        return desc.createKeyCell();
    }

    public String getAttributes() {
        return null;
    }

    public String[] getColumnNames() {
        ColumnDesc[] columns = desc.getColumns();
        String[] ret = new String[columns.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = columns[i].getName();
        }
        return ret;
    }

    public int getColumnNum() {
        return desc.getColumns().length;
    }

    public String[] getColumnTypes() {
        ColumnDesc[] columns = desc.getColumns();
        String[] ret = new String[columns.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = columns[i].getTypeString();
        }
        return ret;
    }

    public String getInternalTableName() {
        return desc.getTableName();
    }

    public String getTableName() {
        return OmapUtils.toOriginalTableName(desc.getTableName());
    }

    public String getTableSpaceName() {
        return OmapUtils.parseTabelSpaceName(desc.getTableName());
    }

    public int getColumnIndex(String colName) {
        return desc.getColumnIndex(colName);
    }

    public TableDesc getTableDesc() {
        return this.desc;
    }

    public String toString() {
        return "[OmapMetadata tableDesc=" + desc + " queries = " + queries
                + " indexMap = " + indexMap + "]";
    }

    public Class<?>[] getColumnTypeClasses() {
        ColumnDesc[] columns = desc.getColumns();
        Class<?>[] ret = new Class<?>[columns.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = columns[i].getBuffer().getClass();
        }
        return ret;
    }

    public Map<String, OmapQuery> getQueries() {
        return queries;
    }

    public Map<IndexSchema, String> getIndexes() {
        return indexMap;
    }

    /**
     * Given an unprepared schema, return its prepared edition
     * 
     * @param is
     * @return the prepared index schema returned by IndexMetaTable, or null if
     *         not found
     */
    public IndexSchema getPreparedIndexSchema(IndexSchema is) {
        return preparedIndexSchemaMap.get(is);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        desc = new TableDesc();
        desc.readFields(in);
        int sz = in.readInt();
        queries = new HashMap<String, OmapQuery>(sz);
        for (int i = 0; i < sz; i++) {
            OmapQuery value = new OmapQuery();
            value.readFields(in);
            queries.put(value.getName(), value);
        }
        sz = in.readInt();
        indexMap = new HashMap<IndexSchema, String>(sz);
        preparedIndexSchemaMap = new HashMap<IndexSchema, IndexSchema>(sz);
        for (int i = 0; i < sz; i++) {
            IndexSchema key = new IndexSchema();
            key.readFields(in);
            String value = UTF8Writable.readString(in);
            indexMap.put(key, value);
            preparedIndexSchemaMap.put(key, key);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        desc.writeFields(out);
        out.writeInt(queries.size());
        for (OmapQuery query: queries.values()) {
            query.writeFields(out);
        }
        out.writeInt(indexMap.size());
        for (Map.Entry<IndexSchema, String> entry: indexMap.entrySet()) {
            entry.getKey().writeFields(out);
            UTF8Writable.writeString(out, entry.getValue());
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        OmapMetadata v = (OmapMetadata) value;
        if (desc == null) {
            desc = new TableDesc();
        }
        desc.copyFields(v.desc);
        if (queries == null) {
            queries = new HashMap<String, OmapQuery>(v.queries.size());
        } else {
            queries.clear();
        }
        for (Map.Entry<String, OmapQuery> entry: v.queries.entrySet()) {
            OmapQuery query = new OmapQuery();
            query.copyFields(entry.getValue());
            queries.put(entry.getKey(), query);
        }

        if (indexMap == null) {
            indexMap = new HashMap<IndexSchema, String>(v.indexMap.size());
        } else {
            indexMap.clear();
        }

        if (preparedIndexSchemaMap == null) {
            preparedIndexSchemaMap = new HashMap<IndexSchema, IndexSchema>();
        } else {
            preparedIndexSchemaMap.clear();
        }

        for (Map.Entry<IndexSchema, String> entry: v.indexMap.entrySet()) {
            IndexSchema is = new IndexSchema();
            is.copyFields(entry.getKey());
            indexMap.put(is, entry.getValue());
            preparedIndexSchemaMap.put(is, is);
        }
        return this;
    }
}
