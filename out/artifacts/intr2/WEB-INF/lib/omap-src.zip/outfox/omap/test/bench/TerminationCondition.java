package outfox.omap.test.bench;

/**
 * Defines when a workload/bench should terminate
 * @author zhangkun
 */
public interface TerminationCondition {
    public boolean shouldTerminateWorkload(WorkloadRunner workloadRunner);
    public boolean shouldTerminateBench(WorkloadRunner workloadRunner);
    public void initialize(WorkloadRunner workloadRunner);
}
