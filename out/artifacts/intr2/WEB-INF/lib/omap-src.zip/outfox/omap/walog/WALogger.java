/**
 * @(#)WALogger.java, 2010-3-5. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.walog;

import java.io.Closeable;
import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import outfox.omap.conf.OmapConfig;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public abstract class WALogger implements Closeable {

    private static final Logger LOG = LogFormatter.getLogger(WALogger.class);

    private static final int MAX_QUEUE_SIZE = 200;

    public static final long BACKPT_START = -1;

    private BlockingQueue<WALogEntry> writeQueue;

    private BlockingQueue<WALogEntry> inprogressQueue;

    protected Path logDir;

    protected IFileSystem fs;

    private class LogWriter extends Thread {

        private WALogFile.Writer writer;

        private long lastStartNewChunkTime;

        private AtomicBoolean startNewChunkMark = new AtomicBoolean(false);

        // set this dog to System.currentTimeMillis() before write or flush operation
        // and set it to -1 after the opertion. This help the check Thread to find
        // out if this LogWriter is too slow
        private AtomicLong writeOrFlushDog = new AtomicLong();

        private AtomicBoolean ok = new AtomicBoolean(true);

        //let config variable be class field, so it can be modified by beanshell
        private int entriesPerFlush = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_WAL_ENTRIES_PER_FLUSH,
                OmapConfig.DEFAULT_WAL_ENTRIES_PER_FLUSH);

        private int sizePerFlush = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_WAL_SIZE_PER_FLUSH,
                OmapConfig.DEFAULT_WAL_SIZE_PER_FLUSH);

        private long newChunkMaxInterval = OmapConfig.getConfiguration().getLong(
                OmapConfig.NAME_WAL_NEWCHUNK_MAX_INTERVAL,
                OmapConfig.DEFAULT_WAL_NEWCHUNK_MAX_INTERVAL) * 1000;

        private int maxChunkSize = OmapConfig.getConfiguration().getInt(
                OmapConfig.NAME_WAL_CHUNK_SIZE,
                OmapConfig.DEFAULT_WAL_CHUNK_SIZE);

        public LogWriter() throws IOException {
            super("WALogger-" + logDir.getName());
            writer = new WALogFile(fs, logDir.cat(WALogFile.FILE_PREFIX
                    + curLogFileSeq.incrementAndGet())).createWriter();
            lastStartNewChunkTime = System.currentTimeMillis();
        }

        public boolean isOK() {
            return ok.get();
        }

        public void requestStartNewChunk() {
            startNewChunkMark.set(true);
        }

        public void requestStartNewChunkAndWait() {
            synchronized (startNewChunkMark) {
                startNewChunkMark.set(true);
                while (startNewChunkMark.get()) {
                    try {
                        startNewChunkMark.wait(5000);
                    } catch (InterruptedException e) {}
                }
            }

        }

        public void forceStartNewChunk() {
            if (startNewChunkMark.compareAndSet(false, true)) {
                interrupt();
                writeOrFlushDog.set(-1);
            }
        }

        private void startNewChunk() {
            try {
                writer.close();
            } catch (Exception e) {
                LOG.log(Level.SEVERE, "close log writer failed", e);
            }
            long fileSeq = curLogFileSeq.incrementAndGet();
            Path newChunk = logDir.cat(WALogFile.FILE_PREFIX + fileSeq);
            LOG.info("start new chunk " + newChunk);
            while (!shutdown) {
                try {
                    writer = new WALogFile(fs, newChunk).createWriter();
                    ok.set(true);
                    break;
                } catch (Exception e) {
                    ok.set(false);
                    LOG.log(Level.SEVERE, "create log writer failed", e);
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    LOG.log(Level.WARNING, "sleep interrupted", e);
                }
            }
            lastStartNewChunkTime = System.currentTimeMillis();
            LOG.info("start new chunk " + newChunk + " success at time "
                    + lastStartNewChunkTime);
            synchronized (startNewChunkMark) {
                startNewChunkMark.set(false);
                startNewChunkMark.notifyAll();
            }

        }

        @Override
        public void run() {
            LOG.info(getName() + " started");
            while (!shutdown) { // main loop
                boolean shouldStartNewChunk = false;
                if (startNewChunkMark.get()) {
                    LOG.info("start new chunk mark is set, we need to start new chunk");
                    shouldStartNewChunk = true;
                }
                if (!shouldStartNewChunk) {
                    long curChunkSize = writer.getBackptr();
                    if (curChunkSize >= maxChunkSize) {
                        LOG.info("chunk size is big enough for "
                                + ((double) curChunkSize / (1024 * 1024))
                                + "MB(max chunk size is "
                                + ((double) maxChunkSize / (1024 * 1024))
                                + "MB), we need to start new chunk");
                        shouldStartNewChunk = true;
                    }
                }
                if (!shouldStartNewChunk) {
                    long openedTime = System.currentTimeMillis()
                            - lastStartNewChunkTime;
                    if (openedTime >= newChunkMaxInterval) {
                        LOG.info("current chunk is open long enough for "
                                + (openedTime / 1000)
                                + "seconds(max interval is "
                                + (newChunkMaxInterval / 1000)
                                + "seconds), we need to start new chunk");
                        shouldStartNewChunk = true;
                    }
                }
                if (shouldStartNewChunk) {
                    startNewChunk();
                }
                WALogEntry entry;
                try {
                    // sometimes we need force start new chunk
                    // if we do not have timeout, and no log record in the writeQueue,
                    // requestStartNewChunkAndWait will block forever 
                    entry = writeQueue.poll(1, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    LOG.log(Level.WARNING, "take interrrupted", e);
                    continue;
                }
                if (entry == null) {
                    continue;
                }
                int writeCount = 0;
                long prevSize = writer.getBackptr();
                boolean writeOK = true;
                do {
                    entry.setLSN(maxLSN.incrementAndGet());
                    entry.setTimeStamp(System.currentTimeMillis());
                    try {
                        writeOrFlushDog.set(System.currentTimeMillis());
                        writer.write(entry);
                        writeOrFlushDog.set(-1);
                        writeCount++;
                    } catch (Exception e) {
                        LOG.log(Level.SEVERE, "write log failed", e);
                        inprogressQueue.add(entry);
                        writeOK = false;
                        writeCount++;
                        break;
                    }
                    inprogressQueue.add(entry);
                    if (writeCount >= entriesPerFlush
                            || writer.getBackptr() - prevSize > sizePerFlush) {
                        break;
                    }
                } while ((entry = writeQueue.poll()) != null); // write loop

                // do flush
                try {
                    writeOrFlushDog.set(System.currentTimeMillis());
                    writer.flush();
                    writeOrFlushDog.set(-1);
                } catch (Exception e) {
                    writeOK = false;
                    LOG.log(Level.SEVERE, "flush writer failed", e);
                }

                // notify
                WALogEntry wakeupEntry;
                WALogEntry.WRITE_STATUS writeStatus = writeOK ? WALogEntry.WRITE_STATUS.SUCCESS
                        : WALogEntry.WRITE_STATUS.FLUSH_ERROR;
                while ((wakeupEntry = inprogressQueue.poll()) != null) {
                    synchronized (wakeupEntry) {
                        wakeupEntry.setWriteStatus(writeStatus);
                        wakeupEntry.notifyAll();
                    }
                }
                if (!writeOK) {
                    requestStartNewChunk();
                }
            }
            startNewChunkMark.set(false);
            try {
                writer.close();
            } catch (IOException e) {
                LOG.log(Level.WARNING, "close log writer failed", e);
            }
            LOG.info(getName() + " ended");
        }
    }

    private class LogIteratorImpl implements LogIterator {
        private PriorityQueue<WALogFile> fileQueue;

        private LogIterator currentIterator = null;

        private long max_lsn = -1;

        public LogIteratorImpl(boolean includeCurrentChunk) throws IOException {
            fileQueue = getLogChunks(true, includeCurrentChunk);
        }

        public boolean next(WALogEntry entry) throws IOException {
            while (true) {
                if (currentIterator == null) {
                    if (fileQueue != null && fileQueue.size() > 0) {
                        WALogFile file = fileQueue.remove();
                        LOG.info("Iterate next chunk: " + file.getFile());
                        currentIterator = file.iterator();
                    } else {
                        return false;
                    }
                } else {
                    if (currentIterator.next(entry)) {
                        if (entry.getLSN() <= this.max_lsn)
                            continue;
                        this.max_lsn = entry.getLSN();
                        return true;
                    }
                    currentIterator.close();
                    currentIterator = null;
                }
            }
        }

        public void close() {
            if (currentIterator != null) {
                currentIterator.close();
                currentIterator = null;
            }
        }

        @Override
        public long getPos() throws IOException {
            throw new UnsupportedOperationException();
        }
    }

    private class ReverseLogIteratorImpl implements LogIterator {
        private PriorityQueue<WALogFile> fileQueue;

        private LogIterator currentIterator = null;

        private long min_lsn = Long.MAX_VALUE;

        public ReverseLogIteratorImpl(boolean includeCurrentChunk)
                throws IOException {
            fileQueue = getLogChunks(false, includeCurrentChunk);
        }

        public boolean next(WALogEntry entry) throws IOException {
            while (true) {
                if (currentIterator == null) {
                    if (fileQueue != null && fileQueue.size() > 0) {
                        WALogFile file = fileQueue.remove();
                        currentIterator = file.reverseIterator(entry);
                    } else {
                        return false;
                    }
                } else {
                    if (currentIterator.next(entry)) {
                        if (entry.getLSN() >= this.min_lsn)
                            continue;
                        this.min_lsn = entry.getLSN();
                        return true;
                    }
                    currentIterator.close();
                    currentIterator = null;
                }
            }
        }

        public void close() {
            if (currentIterator != null) {
                currentIterator.close();
                currentIterator = null;
            }
        }

        @Override
        public long getPos() throws IOException {
            throw new UnsupportedOperationException();
        }
    }

    private final LogWriter writer;

    private final AtomicLong maxLSN = new AtomicLong();

    private final AtomicLong curLogFileSeq = new AtomicLong();

    protected volatile boolean shutdown = false;

    private final ScheduledExecutorService logSlowCheckerExecutor;

    public long getCurrentLSN() {
        return maxLSN.get();
    }

    public WALogger(Path logDir, IFileSystem fs, boolean readonly,
            WALogEntry sampleEntry) throws IOException {
        this.logDir = logDir;
        this.fs = fs;
        if (!readonly) {
            writeQueue = new ArrayBlockingQueue<WALogEntry>(MAX_QUEUE_SIZE);
            inprogressQueue = new LinkedBlockingQueue<WALogEntry>(
                    Integer.MAX_VALUE);
            decideCurrentLogFileAndSetLSN(logDir, sampleEntry);
            writer = new LogWriter();
            logSlowCheckerExecutor = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {

                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "LogWriterSlowChecker-"
                            + WALogger.this.logDir.getName());
                    t.setDaemon(true);
                    return null;
                }
            });
            logSlowCheckerExecutor.scheduleAtFixedRate(new Runnable() {

                @Override
                public void run() {
                    long writeOrFlushStartTime = writer.writeOrFlushDog.get();
                    if (writeOrFlushStartTime > 0
                            && System.currentTimeMillis()
                                    - writeOrFlushStartTime > 1000) {
                        LOG.warning("LogWriter too slow, force start new chunk");
                        writer.forceStartNewChunk();
                    }
                }
            }, 1, 1, TimeUnit.SECONDS);
        } else {
            writer = null;
            logSlowCheckerExecutor = null;
            curLogFileSeq.set(Integer.MAX_VALUE);
        }
    }

    protected void startWriter() {
        writer.start();
    }

    /**
     * Iterator -- the iterator returns log entry one by one. The log Entries
     * are not reused. Does not support read while write ?? XXX xuw - I am not
     * sure about this.
     * 
     * @return
     */
    public LogIterator iterator(boolean includeCurrentChunk) throws IOException {
        return new LogIteratorImpl(includeCurrentChunk);
    }

    /**
     * scan the log in reverse order other specs are same as iterator()
     * 
     * @return
     */
    public LogIterator revIterator(boolean includeCurrentChunk)
            throws IOException {
        return new ReverseLogIteratorImpl(includeCurrentChunk);
    }

    public void startNewChunk() {
        writer.requestStartNewChunk();
    }

    public void startNewChunkAndWait() {
        writer.requestStartNewChunkAndWait();
    }

    public void close() {
        this.shutdown = true;
        if (writer != null) {
            writer.interrupt();
            logSlowCheckerExecutor.shutdown();
            try {
                writer.join(5000);
            } catch (InterruptedException e) {
                LOG.log(Level.WARNING, "join iterrupted");
            }
            while (writer.isAlive()) {
                LOG.info("Wait for a long time, interrupt thread again in case of deadlock.");
                writer.interrupt();
                try {
                    writer.join(5000);
                } catch (InterruptedException e) {
                    LOG.log(Level.WARNING, "join iterrupted");
                }
            }
        }
    }

    /**
     * Find the last numbered log file from the given log directory, return the
     * log file whose number is right after the last numbered log file, and set
     * {@link WALogger#maxLSN} to the first LSN in the returned log file.
     * 
     * @param walFilename
     * @return
     * @throws IOException
     */
    private void decideCurrentLogFileAndSetLSN(Path logDir,
            WALogEntry sampleEntry) throws IOException {
        IFileSystem nfs = this.fs;
        if (!nfs.exists(logDir)) {
            nfs.mkdirs(logDir);
        }
        while (true) {
            FileInfo[] logfiles = nfs.listFiles(logDir);

            // find the file with the largest file sequence number
            WALogFile maxNumberedFile = null;
            for (FileInfo file: logfiles) {
                String s = file.getPath().getName();
                LOG.info("Existing log file: " + s);
                if (!s.startsWith(WALogFile.FILE_PREFIX)) {
                    // not a valid name for log file
                    continue;
                }
                WALogFile wf = new WALogFile(fs, file.getPath());
                if (maxNumberedFile == null
                        || wf.getFileNumber() > maxNumberedFile.getFileNumber()) {
                    maxNumberedFile = wf;
                }
            }

            // no valid file found
            if (maxNumberedFile == null) {
                curLogFileSeq.set(-1);
                break;
            }

            Path lastlog = maxNumberedFile.getFile();

            if (nfs.getLength(lastlog) <= 0) {
                LOG.info(lastlog + " seems to be empty, deleting it");
                nfs.delete(lastlog);
                continue; // try again with next log file
            }

            // read last entry's LSN
            WALogFile lastLogFile = new WALogFile(fs, lastlog);
            LogIterator it = lastLogFile.reverseIterator(sampleEntry);
            if (it.next(sampleEntry)) {
                LOG.info("Setting maxLSN to " + sampleEntry.getLSN());
                maxLSN.set(sampleEntry.getLSN());
            }

            curLogFileSeq.set(maxNumberedFile.getFileNumber());
            break;
        }
    }

    /**
     * Get a queue containing of all log chunks, sorted by file number. Not
     * including the re-opened log.
     * 
     * @param forward
     * @param include_current
     *            if true, include the current in-use one; otherwise not.
     * @return
     * @throws IOException
     */
    public PriorityQueue<WALogFile> getLogChunks(boolean forward,
            boolean include_current) throws IOException {

        PriorityQueue<WALogFile> files;

        IFileSystem nfs = this.fs;
        if (!nfs.exists(logDir)) {
            nfs.mkdirs(logDir);
        }
        FileInfo[] logfiles = nfs.listFiles(logDir);
        Comparator<WALogFile> comp = forward ? WALogFile.FORWARD_COMP
                : WALogFile.BACKWARD_COMP;
        files = new PriorityQueue<WALogFile>(10, comp);

        for (FileInfo file: logfiles) {
            String s = file.getPath().getName();
            if (!s.startsWith(WALogFile.FILE_PREFIX)) {
                // invalid log file name
                continue;
            }
            WALogFile wf = new WALogFile(fs, file.getPath());
            if (include_current
                    && wf.getFileNumber() <= curLogFileSeq.get()
                    || (!include_current && wf.getFileNumber() < curLogFileSeq.get())) {
                files.add(wf);
            }
        }

        return files;
    }

    protected long write(WALogEntry logEntry) throws IOException {
        if (shutdown) {
            throw new IOException("WALogger already shutdown");
        }

        if (writer == null) {
            LOG.info("writer is null, maybe do log recover now, just return.");
            return 0;
        }
        if (!writer.isOK()) {
            throw new IOException(
                    "failed to write WALog because LogWriter is broken");
        }
        // delay setting LSN to this function to avoid race condition when
        // updating LSN
        // also avoid LSN and write occurs in different order
        synchronized (logEntry) {
            try {
                this.writeQueue.put(logEntry);
                while (logEntry.getWriteStatus() == null) {
                    logEntry.wait();
                }
            } catch (InterruptedException e) {
                throw new IOException("log write interrupted", e);
            }
            if (logEntry.getWriteStatus() != WALogEntry.WRITE_STATUS.SUCCESS) {
                throw new IOException("failed to write WALog, code="
                        + logEntry.getWriteStatus());
            }

        }
        return logEntry.getLSN();
    }

    public Path getLogDir() {
        return logDir;
    }

    // only used for test
    public WALogFile.Writer getWALogFileWriter() {
        return writer.writer;
    }

    public String toString() {
        return "[" + this.getClass().getSimpleName() + " dir=" + logDir + "]";
    }
}
