package outfox.omap.client;

import odis.serialize.IWritable;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.OmapException;
import outfox.omap.metadata.KeyColumnDesc;

public class OmapUserTableCursor implements TableCursor {

    private static final int BEFORE_ELEMENT = -1;

    private static final int NO_ELEMENT_AVAILABLE = -2;

    private static final int NOT_INIT = -3;

    private static final int DEFAULT_PREFETCH_DISTANCE = 5;

    protected OmapClient client;

    protected OmapMetadata metadata;

    private int prefetchDistance = DEFAULT_PREFETCH_DISTANCE;

    private DataRow[] prefetchQueue;

    private int curPoint;

    private KeyCell endKeyExclusive;

    public OmapUserTableCursor(OmapClient client) {
        this.client = client;
        this.metadata = client.getMetadata();
        this.curPoint = NOT_INIT;
    }

    public void close() throws OmapException {
        if (endKeyExclusive != null) {
            metadata.getTableDesc().getKey().returnKeyCell(endKeyExclusive);
        }
    }

    private void checkInit() throws OmapException {
        if (curPoint == NOT_INIT) {
            KeyColumnDesc kcDesc = metadata.getTableDesc().getKey();
            KeyCell startKey = kcDesc.borrowKeyCell();
            startKey.setNull();
            prefetchQueue = client.keysFind(startKey, endKeyExclusive,
                    prefetchDistance);
            kcDesc.returnKeyCell(startKey);
            if (prefetchQueue.length > 0) {
                curPoint = BEFORE_ELEMENT;
            } else {
                curPoint = NO_ELEMENT_AVAILABLE;
            }
        }
    }

    public void moveTo(KeyCell key) throws OmapException {
        prefetchQueue = client.keysFind(key, prefetchDistance);
        if (prefetchQueue.length > 0) {
            curPoint = BEFORE_ELEMENT;
        } else {
            curPoint = NO_ELEMENT_AVAILABLE;
        }
    }

    public boolean moveTo(IWritable key, boolean accurate) throws OmapException {
        KeyColumnDesc kcDesc = metadata.getTableDesc().getKey();
        KeyCell keyCell = kcDesc.borrowKeyCell();
        keyCell.setCIWritable(key);
        prefetchQueue = client.keysFind(keyCell, endKeyExclusive,
                prefetchDistance);
        if (prefetchQueue.length == 0) {
            kcDesc.returnKeyCell(keyCell);
            curPoint = NO_ELEMENT_AVAILABLE;
            return false;
        }
        if (accurate) {
            if (prefetchQueue[0].getKeyCell().compareTo(keyCell) != 0) {
                kcDesc.returnKeyCell(keyCell);
                prefetchQueue = new DataRow[0];
                curPoint = NO_ELEMENT_AVAILABLE;
                return false;
            }
        }
        curPoint = BEFORE_ELEMENT;
        return true;
    }

    public boolean hasNext() throws OmapException {
        checkInit();
        if (curPoint == NO_ELEMENT_AVAILABLE) {
            return false;
        }
        if (curPoint == prefetchQueue.length - 1) {
            curPoint = NO_ELEMENT_AVAILABLE;
            return false;
        }
        return true;
    }

    public boolean next(Row row) throws OmapException {
        DataRow dr = next();
        if (dr == null)
            return false;
        else {
            if (row instanceof OmapUserRow) {
                ((OmapUserRow) row).setDataRow(dr);
            } else {
                throw new OmapException(row + " is not a OmapUserRow.");
            }
        }
        return true;
    }

    public DataRow next() throws OmapException {
        checkInit();
        if (curPoint == NO_ELEMENT_AVAILABLE) {
            return null;
        }
        if (curPoint == prefetchQueue.length - 1) {
            curPoint = NO_ELEMENT_AVAILABLE;
            return null;
        } else if (curPoint == prefetchQueue.length - 2) {
            prefetchQueue = client.keysFind(
                    prefetchQueue[curPoint + 1].getKeyCell(), endKeyExclusive,
                    prefetchDistance);
            if (prefetchQueue.length == 0) {
                curPoint = NO_ELEMENT_AVAILABLE;
                return null;
            } else {
                curPoint = 0;
            }
        } else {
            curPoint++;
        }

        return prefetchQueue[curPoint];
    }

    public void remove() throws OmapException {
        if (curPoint < 0 || prefetchQueue[curPoint] == null) {
            throw new OmapException("Current row is not valid.");
        }
        client.deleteRow(prefetchQueue[curPoint].getKeyCell());
        prefetchQueue[curPoint] = null;
    }

    public void setPrefetch(int prefetchDistance) throws OmapException {
        if (prefetchDistance < 2) {
            this.prefetchDistance = 2;
        } else {
            this.prefetchDistance = prefetchDistance + 1;
        }
    }

    @Override
    public void setEndKey(IWritable endKeyExclusive) {
        this.endKeyExclusive = metadata.getTableDesc().getKey().borrowKeyCell();
        this.endKeyExclusive.setCIWritable(endKeyExclusive);
    }

    @Override
    public void reset() {
        curPoint = NOT_INIT;
    }

}
