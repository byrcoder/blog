/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package outfox.omap.test.bench;

import odis.io.FileSystem;
import odis.io.Path;
import outfox.omap.client.OmapTableSpace;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.test.bench.WorkloadRunner.AccessType;

/**
 *
 * @author zhangkun
 */
public class SampleBench {
    public static void main(String[] args) throws Exception {
        if(args.length < 1) {
            System.err.println("Usage: SampleBench <NULL|LZO|GZIP>");
            return;
        }
        TableSpace ts = DataSourceFactory.getNamed("OmapDataSource").openTableSpace("bench");
        WorkloadConfig w = new WorkloadConfig((OmapTableSpace)ts,
                "tweettimeline",
                881280000L,
                26 - 16,
                60*1000L, 60*1000L,
                0.0, 1.0, new TerminateOnTime(3600 * 1000 * 24 * 10, true), args[0], false, true, 1024*1024, false, false);
        w.setReadFlowController(new ConcurrencyFlowController(AccessType.READ, 2*50));
        w.setWriteFlowController(new ThroughputFlowController(AccessType.WRITE, 2*10200));
        OmapBench bench = new OmapBench(FileSystem.getNamed("local"), new Path("benchresults"), new WorkloadConfig[]{w});
        bench.start();
        bench.join();
    }
}
