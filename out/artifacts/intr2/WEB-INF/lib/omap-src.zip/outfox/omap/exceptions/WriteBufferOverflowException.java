package outfox.omap.exceptions;

public class WriteBufferOverflowException extends RuntimeException {
    private static final long serialVersionUID = -1027521745980270774L;

    public WriteBufferOverflowException(String msg) {
        super(msg);
    }
}
