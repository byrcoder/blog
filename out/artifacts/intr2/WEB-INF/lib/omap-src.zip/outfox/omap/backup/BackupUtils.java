/**
 * @(#)BackupUtils.java, 2011-8-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.backup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;

/**
 *
 * @author wangfk
 *
 */
public class BackupUtils {

    public static List<Path> recursiveListAllFiles(IFileSystem fileSystem,
            Path path, boolean includeDir)
            throws IOException {
        ArrayList<Path> result = new ArrayList<Path>();
        FileInfo[] listFiles = fileSystem.listFiles(path);
        
        for(FileInfo fi : listFiles) {
            if(fi.isDir()) {
                if(includeDir) {
                    result.add(fi.getPath());
                }
                result.addAll(recursiveListAllFiles(fileSystem, fi.getPath(), includeDir));
            } else {
                result.add(fi.getPath());
            }
        }
        return result;
    }
}
