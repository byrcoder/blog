/**
 * @(#)MergeSortTask.java, 2010-3-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util.importer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Vector;
import java.util.logging.Logger;

import odis.file.IRecordWriter;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.ByteArrayWritable;
import outfox.omap.common.TsDesc;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyPair;
import outfox.omap.data.KeyRange;
import outfox.omap.ts.SSTableWriter;
import outfox.omap.ts.Tablet;
import outfox.omap.util.OmapUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 *
 * @author wangfk
 *
 */
public class MergeSortTask extends AbstractImporterTask {
    private static Logger LOG = LogFormatter
        .getLogger(MergeSortTask.class.getName());
    
    private static final int DEFAULT_EXPECTED_ELEMENTS = 1000000;
   
    private MergeSortReader mergeSortReader;

    public MergeSortTask() {
        super();
        mergeSortReader = new MergeSortReader();
    }
    
    /**
     * This class is for creating multi-sstables in tablet
     * @author wangfk
     *
     */
    private class TabletWriter implements IRecordWriter<Object, Object> {
        private SSTableWriter[] writers = null;
        private FileSystem outputFs = null;
        private long tabletId = 0;
        
        private long ssTableRecords = 0;
        
        private long maxSSTableSize = 0;
        private long maxSSTableRecords = 0;
        
        private long totalRecord = 0;
        int index = 0;
        
        private TabletWriter(FileSystem outputFs, long tabletId, int sstableNumber, long maxSize, long maxRecords) {
            writers = new SSTableWriter[sstableNumber];
            this.outputFs = outputFs;
            this.tabletId = tabletId;
            this.maxSSTableSize = (maxSize+sstableNumber-1)/sstableNumber;
            this.maxSSTableRecords = (maxRecords+sstableNumber-1)/sstableNumber;
        }

        /* (non-Javadoc)
         * @see odis.file.IRecordWriter#close()
         */
        @SuppressWarnings("unchecked")
        @Override
        public void close() throws IOException {
            for(IRecordWriter writer: writers) {
                if(writer != null) {
                    writer.close();
                }
            }
        }

        /* (non-Javadoc)
         * @see odis.file.IRecordWriter#getSize()
         */
        @SuppressWarnings("unchecked")
        @Override
        public long getSize() throws IOException {
            long size = 0;
            for(IRecordWriter writer: writers) {
                if(writer != null) {
                    size += writer.getSize();
                }
            }
            return size;
        }

        /* (non-Javadoc)
         * @see odis.file.IRecordWriter#write(java.lang.Object, java.lang.Object)
         */
        @Override
        public void write(Object key, Object value) throws IOException {
            if(dataDistrib == DataDistrib.BLANCED) {
                index = (int) (totalRecord%writers.length);
            }else if (dataDistrib == DataDistrib.ORDINAL) {
                if(writers[index] != null && index+1 < writers.length &&
                        (writers[index].getSize() >= maxSSTableSize || ssTableRecords >= maxSSTableRecords)) {
                    ++ index;
                    ssTableRecords = 0;
                }
            }
            
            
            try {
                if(writers[index] == null) {
                    
                    writers[index] = new SSTableWriter(outputFs, new Path(
                            OmapUtils.getSSTableFileDirPath(tableConfig.path, tabletId) + "/"
                            + Tablet.SS_PREFIX + (2*index + 1)), DEFAULT_EXPECTED_ELEMENTS, 
                            compressType);
                }
                
                writers[index].write((ByteArrayWritable)key, (ByteArrayWritable)value);
                ++ ssTableRecords;
                ++ totalRecord;
            } catch (IOException e) {
                LOG.warning("Exception while create SSTable Writer");
                e.printStackTrace();
            }
        }

        
    }
    
    /* Output data to sstable
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        
        try {
            TabletWriter writer = null;
            long tabletId = OmapUtils.minTabletId(tableConfig.td.getSchemaId());
            FileSystem outputFs = FileSystem.getNamed(tableConfig.fs);
            ArrayList<KeyRange> tablets = new ArrayList<KeyRange>();
            ByteArrayWritable keyw = new ByteArrayWritable();
            ByteArrayWritable roww = new ByteArrayWritable();
            IWritableComparable startKey = null;
            IWritableComparable endKey = null;
            long tabletSize = 0;
            long tabletRecords = 0;
            long totalSize = 0;
            long totalRecords = 0;
            IWritableComparable key; 
    
            for(DataRow dr = mergeSortReader.nextRow(); dr != null; dr = mergeSortReader.nextRow()) {
                key = dr.getKeyCell().getKey(); 
                
                if (writer == null
                        || tabletSize >= tableConfig.maxTabletSize / 2
                        || tabletRecords+1 >= tableConfig.maxTabletRecords) {
                    
                    if (writer != null) {
                        endKey = key;
                        LOG.info("Done writing Tablet "
                                + HexString.longToPaddedHex(tabletId) + ", rows="
                                + tabletRecords + ", size=" + tabletSize
                                + ", startKey=" + startKey + ", endKey=" + endKey);
                        writer.close();
                        KeyRange keyRange = new KeyRange(startKey, endKey, TsDesc
                                .getDummyTsDesc(), tabletId);
                        tablets.add(keyRange);
                        if (startKey == null) {
                            try {
                                startKey = key.getClass().newInstance();
                            } catch (Exception e) {
                                if (e instanceof RuntimeException) {
                                    throw (RuntimeException) e;
                                } else {
                                    throw new RuntimeException(e);
                                }
                            }
                        }
                        startKey.copyFields(key);
                    }
                    tabletId++;
                    LOG.info("New Tablet: " + HexString.longToPaddedHex(tabletId));
                    tabletSize = 0;
                    tabletRecords = 0;
                    writer = new TabletWriter(
                            outputFs, tabletId, sstableNumber, 
                            tableConfig.maxTabletSize / 2, tableConfig.maxTabletRecords
                            );
                }
                
                keyw.set(OmapUtils.convertPIWritableToBytes(dr.getKeyCell()));
                roww.set(OmapUtils.convertPIWritableToBytes(dr));
                writer.write(keyw, roww);
                totalRecords++;
                tabletRecords++;
                long sizeDelta = writer.getSize() - tabletSize;
                tabletSize += sizeDelta;
                totalSize += sizeDelta;
            }
            if(writer != null) {
                writer.close();
            }
            
            LOG.info("Done writing SSTableFiles, written " + totalRecords
                    + " rows, total size=" + totalSize);
            
            endKey = KeyPair.MAX_WRITABLE;
            KeyRange keyRange = new KeyRange(startKey, endKey, TsDesc
                    .getDummyTsDesc(), tabletId);
            tablets.add(keyRange);
            
            // create and assign Tablets
            master.assignTabletsForImportedTable(tableConfig.td.getSchemaId(), tablets
                    .toArray(new KeyRange[tablets.size()]), true);
            LOG.info("Succesfully imported data from " + mergeSortReader + " to "
                    + tableConfig.td);
        } catch (Exception e) {
            LOG.warning("Exception while importing data");
            e.printStackTrace();
        } finally {
            mergeSortReader.closeAllReaders();
        }
    }
    
    public long getTotalRowCount() {
        return mergeSortReader.getTotalRowCount();
    }


    protected void addDataReaderInner(IDataReader reader) {
        mergeSortReader.addDataReader(reader);
    }


    /**
     * Read rows from dataReaders, merge sort them by key. 
     * @author wangfk
     *
     */
    private static class MergeSortReader {
        private Vector<IDataReader> dataReaders;
        private PriorityQueue<InnerElement> queue;

        public MergeSortReader() {
            super();
            dataReaders = new Vector<IDataReader>();
            queue = new PriorityQueue<InnerElement>();
        }

        private class InnerElement implements Comparable<InnerElement> {
            private int index;
            private DataRow dr;

            public InnerElement(int index) {
                super();
                this.index = index;
                dr = dataReaders.get(index).getNextRow();
            }

            @Override
            public int compareTo(InnerElement o) {
                return dr.getKeyCell().compareTo(o.dr.getKeyCell());
            }
            
            public DataRow next() {
                DataRow ret;
                if(dr == null) {
                    throw new RuntimeException("You should not be here.");
                }
                try {
                    ret = dr.getClass().newInstance();
                    ret.copyFields(dr);
                } catch (Exception e) {
                    throw new RuntimeException();
                }
                dr = dataReaders.get(index).getNextRow();
                return ret;
            }
            
            public boolean hasNext() {
                return dr != null;
            }
        }
        
        public void addDataReader(IDataReader reader) {
            dataReaders.add(reader);
            InnerElement e = new InnerElement(dataReaders.size()-1);
            queue.add(e);
        }
        
        public long getTotalRowCount() {
            long res = 0;
            for(IDataReader di : dataReaders) {
                res += di.getRowCount();
            }
            return res;
        }
        
        public DataRow nextRow() {
            InnerElement element = queue.poll();
            if(element == null) {
                return null;
            }
            DataRow dataRow = element.next();
            if(element.hasNext()) {
                queue.add(element);
            }
            return dataRow;
        }
        
        public void closeAllReaders() {
            if(dataReaders == null) {
                return;
            }
            for(IDataReader reader: dataReaders) {
                reader.closeDataSouce();
            }
        }
    }
}
