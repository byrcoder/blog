/**
 * @(#)IPermissionValidator.java, 2011-2-17. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client.protocol;

import outfox.omap.exceptions.OperationNotPermittedException;

/**
 *
 * @author wangfk
 *
 */
public interface IPermissionValidator {
    public void validatePermission(String user, PermissionType type)
            throws OperationNotPermittedException;
}
