/**
 * @(#)MetadataCache.java, 2011-1-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.client;

import java.net.InetSocketAddress;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import outfox.omap.ClientMasterProtocol;
import outfox.omap.walog.MetadataProvider;
import toolbox.collections.CacheHashMap;

/**
 * @author zhangduo
 */
public class MetadataCache implements MetadataProvider {

    private ReadWriteLock name2idLock = new ReentrantReadWriteLock();

    private ReadWriteLock metasLock = new ReentrantReadWriteLock();

    private CacheHashMap<String, Long> name2id = new CacheHashMap<String, Long>(
            128);

    private CacheHashMap<Long, OmapMetadata> metas = new CacheHashMap<Long, OmapMetadata>(
            128);

    private volatile ClientMasterProtocol master;

    public void setMaster(ClientMasterProtocol master) {
        this.master = master;
    }

    private OmapMetadata getAndCacheMetadata(long schemaId) throws RpcException {
        OmapMetadata metadata = master.getMetadata(schemaId);
        if (metadata == null) {
            return null;
        }
        metasLock.writeLock().lock();
        try {
            metas.put(new Long(schemaId), metadata);
        } finally {
            metasLock.writeLock().unlock();
        }
        return metadata;
    }

    public OmapMetadata findMetadata(long schemaId) throws RpcException {
        metasLock.readLock().lock();
        try {
            OmapMetadata metadata = metas.get(schemaId);
            if (metadata != null) {
                return metadata;
            }
        } finally {
            metasLock.readLock().unlock();
        }
        return getAndCacheMetadata(schemaId);
    }

    private long getAndCacheSchemaId(String tableName) throws RpcException {
        long schemaId = master.getSchemaId(tableName);
        name2idLock.writeLock().lock();
        try {
            name2id.put(tableName, schemaId);
        } finally {
            name2idLock.writeLock().unlock();
        }
        return schemaId;
    }

    public long findSchemaId(String tableName) throws RpcException {
        name2idLock.readLock().lock();
        try {
            Long schemaId = name2id.get(tableName);
            if (schemaId != null) {
                return schemaId.longValue();
            }
        } finally {
            name2idLock.readLock().unlock();
        }
        return getAndCacheSchemaId(tableName);
    }

    public OmapMetadata findMetadata(String tableName) throws RpcException {
        return findMetadata(findSchemaId(tableName));
    }

    public void clearTableInfo(String tableName) {
        Long schemaId;
        name2idLock.writeLock().lock();
        try {
            schemaId = name2id.remove(tableName);
        } finally {
            name2idLock.writeLock().unlock();
        }
        if (schemaId != null) {
            clearTableInfo(schemaId);
        }

    }

    public void clearTableInfo(long schemaId) {
        metasLock.writeLock().lock();
        try {
            metas.remove(schemaId);
        } finally {
            metasLock.writeLock().unlock();
        }
    }

    public void clearTableInfo(long schemaId, String tableName) {
        name2idLock.writeLock().lock();
        try {
            name2id.remove(tableName);
        } finally {
            name2idLock.writeLock().unlock();
        }
        metasLock.writeLock().lock();
        try {
            metas.remove(schemaId);
        } finally {
            metasLock.writeLock().unlock();
        }
    }

    @Override
    public OmapMetadata get(long schemaId) {
        try {
            return findMetadata(schemaId);
        } catch (RpcException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) throws Exception {
        ClientMasterProtocol p = RPC.getProxy(ClientMasterProtocol.class,
                new InetSocketAddress("nb109", 6190), "", "cloudstorage", 0);
        p.deleteTable("ynote-convert2$pc-message");
//        OmapMetadata[] metas = p.getTables("cube-latest");
//        for (OmapMetadata meta : metas) {
//            String tableName = meta.getInternalTableName();
//            System.out.println("Delete " + tableName);
//            p.deleteTable(meta.getInternalTableName());
//        }
//        p.deleteTable("silmaril-wangshuai$rest-coupon");
//        p.deleteTable("silmaril-wangshuai$realtime-update-rest");
//        p.deleteTable("silmaril-wangshuai$op-add-dish");
    }
}
