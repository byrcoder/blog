/**
 * @(#)TableBackManager.java, 2011-8-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.backup;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import outfox.omap.client.MasterWatcherAndClientConfig;
import outfox.omap.client.OmapDataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.conf.OmapConfig;
import outfox.omap.exceptions.OmapException;

/**
 *
 * @author wangfk
 *
 */
public final class TableBackManager {
    private static final String BACKUP_ROOT = OmapConfig.getConfiguration()
            .getString(OmapConfig.NAME_BACKUP_ROOT_PATH,
                    OmapConfig.DEFAULT_BACKUP_ROOT_PATH);

    private IFileSystem fileSystem;

    ArrayList<TableBackupTask> taskList;
    ArrayList<String> stopBackupTableList;
    
    private TableBackManager(String args[]) throws IOException, OmapException {
        String fsName = OmapConfig.getConfiguration().getString(
                OmapConfig.NAME_FS_NAME, OmapConfig.DEFAULT_FS_NAME);
        fileSystem = FileSystem.getNamed(fsName);

        String fileName = args[0];
        File file = new File(fileName);
        if(!file.exists()) {
            System.err.println(
                    "The config file does not exist, file name=" + fileName);
        }
        Properties props = new Properties();
        FileInputStream inStream = new FileInputStream(file);
        try {
            props.load(inStream);
        } finally {
            inStream.close();
        }

        taskList = new ArrayList<TableBackupTask>();
        stopBackupTableList = new ArrayList<String>();

        for(Map.Entry<Object, Object> entry : props.entrySet()) {
            String tableName = (String) entry.getKey();
            String value = (String) entry.getValue();

            boolean illegal = false;
            String[] split = value.split("\\x7c");
            if(split.length == 0) {
                illegal = true;
            } else if("START".equalsIgnoreCase(split[0]) && split.length == 3) {
                long backupPeriodInMilli = Long.parseLong(split[1]);
                long backupSecurePeriodInMilli = Long.parseLong(split[2]);
                taskList.add(new TableBackupTask(fileSystem, tableName,
                        BACKUP_ROOT, backupPeriodInMilli,
                        backupSecurePeriodInMilli));
            } else if("STOP".equalsIgnoreCase(split[0]) && split.length == 1) {
                stopBackupTableList.add(tableName);
            } else {
                illegal = true;
            }
            if(illegal) {
                throw new RuntimeException("Config file format error, Key="
                        + tableName + ", value=" + value);
            }
        }
    }

    public void doBackup() throws Exception {
        OmapDataSource datasource =
            (OmapDataSource) DataSourceFactory.getNamed("OmapDataSource");
        MasterWatcherAndClientConfig masterWatcher = datasource.getMasterWatcher();

        for(String tableName : stopBackupTableList) {
            System.err.println("Stop backup table: " + tableName);
            masterWatcher.getMaster().stopReserveTableWALog(tableName);
        }

        if(taskList==null || taskList.isEmpty()) {
            return;
        }
        ExecutorService fixedThreadPool = Executors.newFixedThreadPool(taskList.size());
        for(TableBackupTask task : taskList) {
            System.err.println("Start to backup table: " + task.tableName);
            fixedThreadPool.execute(task);
        }
        Thread.currentThread().join();
    }

    public static final void main(String[] args) throws Exception {
        if(args.length != 1) {
            printUsage(System.err);
            return;
        }
        new TableBackManager(args).doBackup();
    }

    public static final void printUsage(PrintStream out) {
        out.println("USAGE: " + TableBackManager.class.getName() + " <CONFIG FILE>");
        out.println("------------------------------");
        out.println("Config file format: ");
        out.println("<TABLE_NAME_WITH_SPACE>=<START>|<BACKUP_PERIOD>|<BACKUP_SECURE_PERIOD>");
        out.println("  OR  ");
        out.println("tableNameWithSpace=<STOP>");
        out.println("----");
        out.println("Each field means:");
        out.println("<START>: String of 'START'");
        out.println("<STOP>: String of 'STOP'");
        out.println("<BACKUP_PERIOD>: Time period in milli second. " +
                    "A backup period includes: an table snapshot and the next WALogs." +
                    "The WALogs would be increasing all the time, in order to cut down the WALogs, " +
                    "we need to start a new backup period after a long time span");
        out.println("<BACKUP_SECURE_PERIOD>: Time period in milli second. " + 
                    "We can not roll back to the time before <BACKUP_SECURE_PERIOD>." +
                    "It also means we can roll back the data to any time during the <BACKUP_SECURE_PERIOD>.");
    }
}