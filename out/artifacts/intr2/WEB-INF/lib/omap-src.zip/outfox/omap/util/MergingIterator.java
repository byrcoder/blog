package outfox.omap.util;

import java.io.IOException;
import java.io.Serializable;
import java.util.Comparator;
import java.util.PriorityQueue;

import odis.serialize.IWritable;

/**
 * MergingIterator is an Iterator whose resulting sequence is the merging of two
 * or more other sub-Iterators, every of which must return elements ordered in
 * the same ordering schema. sub-Iterators will get an index for each. If
 * multiple sub-Iterators contains the same element (by the means of equals()),
 * only the element of the iterator listed first in the argument list of the
 * constructor will be returned.
 * 
 * @author yaming, zhangduo
 * @param <E>
 */
public class MergingIterator<E extends IWritable> implements
        CloseableIterator<E> {

    private static class PQElement<T> {
        T obj;

        int idx;

        public PQElement(T obj, int idx) {
            this.obj = obj;
            this.idx = idx;
        }
    }

    private static class PQElementComparator<T> implements
            Comparator<PQElement<T>>, Serializable {

        private static final long serialVersionUID = 4346786709887409431L;

        private final Comparator<T> comparator;

        public PQElementComparator(Comparator<T> comparator) {
            this.comparator = comparator;
        }

        @Override
        public int compare(PQElement<T> o1, PQElement<T> o2) {
            int ret = comparator.compare(o1.obj, o2.obj);
            return ret == 0 ? o1.idx - o2.idx : ret;
        }

    }

    /**
     * the Comparator used to compare the elements from the subiterators. It
     * must be compatible with the ordering of the elements returned by each
     * subiterator.
     */
    private Comparator<E> comparator;

    /**
     * The subiterators
     */
    private CloseableIterator<E>[] iters;

    private PriorityQueue<PQElement<E>> pQueue;

    /**
     * Constructor.
     * 
     * @param comparator
     *            the Comparator used to compare the elements from the
     *            subiterators. It must be compatible with the ordering of the
     *            elements returned by each subiterator. the index of
     *            subiterators in arg of this constructor will be the
     *            subiterator's index.
     * @param iters
     *            the subiterators
     */
    public MergingIterator(Comparator<E> comparator,
            CloseableIterator<E>... iters) {
        this.comparator = comparator;
        this.iters = iters;
    }

    private void fillQueue(int idx, E value) throws IOException {
        while (true) {
            if (iters[idx].next(value)) {
                pQueue.add(new PQElement<E>(value, idx));
            }
            break;
        }
    }

    private void init(E value) throws IOException {
        pQueue = new PriorityQueue<PQElement<E>>(iters.length,
                new PQElementComparator<E>(comparator));
        try {
            for (int i = 0; i < iters.length; i++) {
                @SuppressWarnings("unchecked")
                E obj = (E) value.getClass().newInstance();
                fillQueue(i, obj);
            }
        } catch (IllegalAccessException e) {
            throw new IOException("newInstance failed for class "
                    + value.getClass(), e);
        } catch (InstantiationException e) {
            throw new IOException("newInstance failed for class "
                    + value.getClass(), e);
        }
    }

    @Override
    public boolean next(E value) throws IOException {
        if (iters.length == 0) {
            return false;
        }
        if (pQueue == null) {
            init(value);
        }
        if (pQueue.isEmpty()) {
            return false;
        }

        PQElement<E> element = pQueue.poll();
        E obj = element.obj;
        value.copyFields(obj);
        fillQueue(element.idx, obj);
        while ((!pQueue.isEmpty())
                && (comparator.compare(pQueue.peek().obj, value) == 0)) {
            PQElement<E> e = pQueue.poll();
            fillQueue(e.idx, e.obj);
        }
        return true;
    }

    public void close() {
        if (iters != null) {
            for (CloseableIterator<E> iter: iters) {
                OmapUtils.safeClose(iter);
            }
            iters = null;
        }

    }
}
