/**
 * @(#)CorruptedWALogEntryException.java, 2013-2-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.walog;

import java.io.IOException;

/**
 * @author zhangduo
 */
public class CorruptedWALogEntryException extends IOException {

    private static final long serialVersionUID = -5884727219923797360L;

    public CorruptedWALogEntryException() {
        super();
    }

    public CorruptedWALogEntryException(String message, Throwable cause) {
        super(message, cause);
    }

    public CorruptedWALogEntryException(String message) {
        super(message);
    }

    public CorruptedWALogEntryException(Throwable cause) {
        super(cause);
    }

}
