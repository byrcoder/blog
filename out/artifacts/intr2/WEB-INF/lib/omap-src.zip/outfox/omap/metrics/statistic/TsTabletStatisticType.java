/**
 * @(#)TsTabletStatisticType.java, 2011-6-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TimeRangeUtils;


/**
 * @author zhangduo
 */
public enum TsTabletStatisticType {
    
    KEY_FIND_COUNT(0),
    KEY_FIND_DELAY(KEY_FIND_COUNT.offset + 1),
    KEY_FIND_SIZE_PER_COUNT(KEY_FIND_DELAY.offset + 1),
    TIME_RANGE_KEY_FIND_COUNT(KEY_FIND_SIZE_PER_COUNT.offset + 1),
    
    MULTI_KEY_FIND_COUNT(TIME_RANGE_KEY_FIND_COUNT.offset + TimeRangeUtils.rangeCount()),
    MULTI_KEY_FIND_DELAY(MULTI_KEY_FIND_COUNT.offset + 1),
    MULTI_KEY_FIND_ROWS_PER_COUNT(MULTI_KEY_FIND_DELAY.offset + 1),
    MULTI_KEY_FIND_SIZE_PER_COUNT(MULTI_KEY_FIND_ROWS_PER_COUNT.offset + 1),
    MULTI_KEY_FIND_DELAY_PER_ROW(MULTI_KEY_FIND_SIZE_PER_COUNT.offset + 1),
    TIME_RANGE_MULTI_KEY_FIND_COUNT(MULTI_KEY_FIND_DELAY_PER_ROW.offset + 1),
    
    RANGE_KEY_FIND_COUNT(TIME_RANGE_MULTI_KEY_FIND_COUNT.offset + TimeRangeUtils.rangeCount()),
    RANGE_KEY_FIND_DELAY(RANGE_KEY_FIND_COUNT.offset + 1),
    RANGE_KEY_FIND_ROWS_PER_COUNT(RANGE_KEY_FIND_DELAY.offset + 1),
    RANGE_KEY_FIND_SIZE_PER_COUNT(RANGE_KEY_FIND_ROWS_PER_COUNT.offset + 1),
    RANGE_KEY_FIND_DELAY_PER_ROW(RANGE_KEY_FIND_SIZE_PER_COUNT.offset + 1),
    TIME_RANGE_RANGE_KEY_FIND_COUNT(RANGE_KEY_FIND_DELAY_PER_ROW.offset + 1),
    
    CONTAINS_COUNT(TIME_RANGE_RANGE_KEY_FIND_COUNT.offset + TimeRangeUtils.rangeCount()),
    CONTAINS_DELAY(CONTAINS_COUNT.offset + 1),
    TIME_RANGE_CONTAINS_COUNT(CONTAINS_DELAY.offset + 1),
    
    MULTI_CONTAINS_COUNT(TIME_RANGE_CONTAINS_COUNT.offset + TimeRangeUtils.rangeCount()),
    MULTI_CONTAINS_DELAY(MULTI_CONTAINS_COUNT.offset + 1),
    MULTI_CONTAINS_ROWS_PER_COUNT(MULTI_CONTAINS_DELAY.offset + 1),
    MULTI_CONTAINS_DELAY_PER_ROW(MULTI_CONTAINS_ROWS_PER_COUNT.offset + 1),
    TIME_RANGE_MULTI_CONTAINS_COUNT(MULTI_CONTAINS_DELAY_PER_ROW.offset + 1),
    
    INSERT_COUNT(TIME_RANGE_MULTI_CONTAINS_COUNT.offset + TimeRangeUtils.rangeCount()),
    INSERT_DELAY(INSERT_COUNT.offset + 1),
    INSERT_SIZE_PER_COUNT(INSERT_DELAY.offset + 1),
    TIME_RANGE_INSERT_COUNT(INSERT_SIZE_PER_COUNT.offset + 1),
    
    MULTI_INSERT_COUNT(TIME_RANGE_INSERT_COUNT.offset + TimeRangeUtils.rangeCount()),
    MULTI_INSERT_DELAY(MULTI_INSERT_COUNT.offset + 1),
    MULTI_INSERT_ROWS_PER_COUNT(MULTI_INSERT_DELAY.offset + 1),
    MULTI_INSERT_SIZE_PER_COUNT(MULTI_INSERT_ROWS_PER_COUNT.offset + 1),
    MULTI_INSERT_DELAY_PER_ROW(MULTI_INSERT_SIZE_PER_COUNT.offset + 1),
    TIME_RANGE_MULTI_INSERT_COUNT(MULTI_INSERT_DELAY_PER_ROW.offset + 1),
    
    DELETE_COUNT(TIME_RANGE_MULTI_INSERT_COUNT.offset + TimeRangeUtils.rangeCount()),
    DELETE_DELAY(DELETE_COUNT.offset + 1),
    TIME_RANGE_DELETE_COUNT(DELETE_DELAY.offset + 1),
    
    MULTI_DELETE_COUNT(TIME_RANGE_DELETE_COUNT.offset + TimeRangeUtils.rangeCount()),
    MULTI_DELETE_DELAY(MULTI_DELETE_COUNT.offset + 1),
    MULTI_DELETE_ROWS_PER_COUNT(MULTI_DELETE_DELAY.offset + 1),
    MULTI_DELETE_DELAY_PER_ROW(MULTI_DELETE_ROWS_PER_COUNT.offset + 1),
    TIME_RANGE_MULTI_DELETE_COUNT(MULTI_DELETE_DELAY_PER_ROW.offset + 1),
    
    RANGE_DELETE_COUNT(TIME_RANGE_MULTI_DELETE_COUNT.offset + TimeRangeUtils.rangeCount()),
    RANGE_DELETE_DELAY(RANGE_DELETE_COUNT.offset + 1),
    RANGE_DELETE_ROWS_PER_COUNT(RANGE_DELETE_DELAY.offset + 1),
    RANGE_DELETE_DELAY_PER_ROW(RANGE_DELETE_ROWS_PER_COUNT.offset + 1),
    TIME_RANGE_RANGE_DELETE_COUNT(RANGE_DELETE_DELAY_PER_ROW.offset + 1),
    
    COMPARE_AND_SET_COUNT(TIME_RANGE_RANGE_DELETE_COUNT.offset + TimeRangeUtils.rangeCount()),
    COMPARE_AND_SET_DELAY(COMPARE_AND_SET_COUNT.offset + 1),
    TIME_RANGE_COMPARE_AND_SET_COUNT(COMPARE_AND_SET_DELAY.offset + 1),
    
    LOCK_ROW_COUNT(TIME_RANGE_COMPARE_AND_SET_COUNT.offset + TimeRangeUtils.rangeCount()),
    LOCK_ROW_DELAY(LOCK_ROW_COUNT.offset + 1),
    TIME_RANGE_LOCK_ROW_COUNT(LOCK_ROW_DELAY.offset + 1),
    
    UNLOCK_ROW_COUNT(TIME_RANGE_LOCK_ROW_COUNT.offset + TimeRangeUtils.rangeCount()),
    UNLOCK_ROW_DELAY(UNLOCK_ROW_COUNT.offset + 1),
    TIME_RANGE_UNLOCK_ROW_COUNT(UNLOCK_ROW_DELAY.offset + 1),
    
    MAX_TYPE(TIME_RANGE_UNLOCK_ROW_COUNT.offset + TimeRangeUtils.rangeCount());
    
    private final int offset;

    private TsTabletStatisticType(int offset) {
        this.offset = offset;
    }

    public int offset() {
        return offset;
    }

    public static int getTypeCount() {
        return MAX_TYPE.offset;
    }
    
    public static void main(String[] args) {
        System.out.println(getTypeCount());
    }
}
