/**
 * @(#)ReservableInsertLogReaderHandler.java, 2011-8-12. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts.insertlog;

import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.Path;
import outfox.omap.client.OmapMetadata;
import outfox.omap.client.protocol.Table;
import outfox.omap.ts.OmapTsMetadataCache;
import outfox.omap.util.OmapUtils;
import outfox.omap.walog.WALogFile;
import toolbox.collections.primitive.LongLongHashMap;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author wangfk
 */
public abstract class ReservableInsertLogReaderHandler extends
        InsertLogReaderHandler {
    private static final Logger LOG = LogFormatter.getLogger(ReservableInsertLogReaderHandler.class);

    private HashMap<Long, String> logReservePathMap;

    private OmapTsMetadataCache metaCache;

    public ReservableInsertLogReaderHandler(LongLongHashMap checkpoints) {
        super(checkpoints);
    }

    /**
     * Set log reserve path for tables needing backup
     * 
     * @param logReservePathMap
     */
    public final void setLogReservePathMap(
            HashMap<Long, String> logReservePathMap,
            OmapTsMetadataCache metaCache) {
        this.logReservePathMap = logReservePathMap;
        this.metaCache = metaCache;
    }

    /**
     * @param tabletId
     * @param lastLSN
     * @param timestamp
     * @return &lt;Table Log Reserve Path&gt;/&lt;Hex Tablet
     *         Id&gt;/wal&lt;LSN&gt;-&lt;timestamp&gt;
     */
    protected Path getLogReserveFilePath(long tabletId, long lastLSN,
            long timestamp) {
        if (!needReserveLog(tabletId)) {
            throw new RuntimeException("Why here?");
        }
        String path = logReservePathMap.get(OmapUtils.tid2sid(tabletId));
        Path result = new Path(path);
        result = result.cat(HexString.longToPaddedHex(tabletId));
        result = result.cat(WALogFile.FILE_PREFIX + Long.toString(lastLSN)
                + "-" + Long.toString(timestamp));
        return result;
    }

    protected synchronized boolean needReserveLog(long tabletId) {
        long sid = OmapUtils.tid2sid(tabletId);
        if (logReservePathMap == null) {
            logReservePathMap = new HashMap<Long, String>();
        }

        if (!logReservePathMap.containsKey(sid)) {
            String reservePath = null;
            if (metaCache != null) {
                try {
                    OmapMetadata metadata = metaCache.getMetadata(sid);
                    if (metadata != null) {
                        reservePath = metadata.getTableDesc().getProperty(
                                Table.Property.RESERVE_WAL_PATH_NAME, null);
                    }
                } catch (IOException e) {
                    LOG.log(Level.WARNING, "Fail to get table meta", e);
                }
            }
            if (reservePath == null || reservePath.isEmpty()) {
                logReservePathMap.put(sid, "");
            }
        }
        String path = logReservePathMap.get(sid);
        if (path == null || path.isEmpty()) {
            return false;
        }
        return true;
    }

    @Override
    protected boolean checkEntryByLastLSN(long entryLSN, long tabletId) {
        return needReserveLog(tabletId)
                || super.checkEntryByLastLSN(entryLSN, tabletId);
    }
}
