/**
 * @(#)CatalogueLogEntry.java, 2010-8-27. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.master.catalogue;

import outfox.omap.walog.CorruptedWALogEntryException;
import outfox.omap.walog.WALogBody;
import outfox.omap.walog.WALogEntry;

/**
 * @author zhangduo
 */
public class CatalogueLogEntry extends WALogEntry {

    public static final int TYPE_SCHEMA = 0;

    public static final int TYPE_RANGE = 1;

    public static final int TYPE_TASK = 2;

    @Override
    protected void prepareLogBody(int logType)
            throws CorruptedWALogEntryException {
        switch (logType) {
            case TYPE_SCHEMA:
                if (!(body instanceof CatalogueLogSchema)) {
                    body = new CatalogueLogSchema();
                }
                break;
            case TYPE_RANGE:
                if (!(body instanceof CatalogueLogRange)) {
                    body = new CatalogueLogRange();
                }
                break;
            case TYPE_TASK:
                if (!(body instanceof CatalogueLogTask)) {
                    body = new CatalogueLogTask();
                }
                break;
            default:
                throw new CorruptedWALogEntryException("Unknown log type: "
                        + logType);
        }

    }

    @Override
    public void setBody(WALogBody body) throws CorruptedWALogEntryException {
        if (body instanceof CatalogueLogSchema) {
            logType = TYPE_SCHEMA;
        } else if (body instanceof CatalogueLogRange) {
            logType = TYPE_RANGE;
        } else if (body instanceof CatalogueLogTask) {
            logType = TYPE_TASK;
        } else {
            throw new CorruptedWALogEntryException(body.getClass()
                    + " doesn't correspond to a logType");
        }
        this.body = body;
    }

    @Override
    public String toString() {
        return "CatalogueLogEntry(type :" + this.logType + " body: " + body
                + ")";
    }
}
