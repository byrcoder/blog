package outfox.omap.exceptions;

public class FieldNotInitializedException extends RuntimeException {
    private static final long serialVersionUID = -7242553891268795944L;

    public FieldNotInitializedException(String msg) {
        super(msg);
    }

    public FieldNotInitializedException() {
        super();
    }
}
