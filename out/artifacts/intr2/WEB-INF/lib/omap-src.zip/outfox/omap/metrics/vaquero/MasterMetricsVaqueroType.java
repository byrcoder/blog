/**
 * @(#)MasterMetricsVaqueroType.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public enum MasterMetricsVaqueroType {

    NUM_TABLE("num.table"),
    NUM_TABLET("num.tablet"),
    
    SYSTEM_LOAD("system.load"),
    SYSTEM_LOAD_PER_PROCESSOR("system.load.per.processor"),
    
    MEMORY_INIT("memory.init"),
    MEMORY_USED("memory.used"),
    MEMORY_COMMITTED("memory.committed"),
    MEMORY_MAX("memory.max"),
    
    RATE_REQUEST("rate.request"),
    RATE_TIMEOUT_REQUEST("rate.timeout.request"),
    
    RATE_GET_FS_NAME("rate.getFsName"),
    DELAY_GET_FS_NAME("delay.getFsName"),
    
    RATE_GET_TABLES("rate.getTables"),
    DELAY_GET_TABLES("delay.getTables"),
    
    RATE_GET_TABLES_IN_SPACE("rate.getTablesInSpace"),
    DELAY_GET_TABLES_IN_SPACE("delay.getTablesInSpace"),
    
    RATE_GET_TABLESPACES("rate.getTableSpaces"),
    DELAY_GET_TABLESPACES("delay.getTableSpaces"),
    
    RATE_CREATE_TABLE("rate.createTable"),
    DELAY_CREATE_TABLE("delay.createTable"),
    
    RATE_DELETE_TABLE("rate.deleteTable"),
    DELAY_DELETE_TABLE("delay.deleteTable"),
    
    RATE_LOOKUP_KEY("rate.lookupKey"),
    DELAY_LOOKUP_KEY("delay.lookupKey"),
    
    RATE_RENAME_TABLE("rate.renameTable"),
    DELAY_RENAME_TABLE("delay.renameTable"),
    
    RATE_SET_TABLE_PROPERTIES("rate.setTableProperties"),
    DELAY_SET_TABLE_PROPERTIES("delay.setTableProperties"),
    
    RATE_GET_SCHEMA_ID("rate.getSchemaId"),
    DELAY_GET_SCHEMA_ID("delay.getSchemaId"),
    
    RATE_GET_METADATA("rate.getMetadata"),
    DELAY_GET_METADATA("delay.getMetadata"),
    
    RATE_SET_READ_ONLY("rate.setReadOnly"),
    DELAY_SET_READ_ONLY("delay.setReadOnly");

    private final String vaqueroPropName;

    private MasterMetricsVaqueroType(String vaqueroPropName) {
        this.vaqueroPropName = vaqueroPropName;
    }

    public String getVaqueroPropName() {
        return vaqueroPropName;
    }

}
