/**
 * @(#)OpNum.java, 2011-6-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.vaquero;

/**
 * @author zhangduo
 */
public class OpNum extends Updater {

    private final double normalizer;

    private final int metricsOpIndex;

    private double value;

    public OpNum(String vaqueroPropName, int metricsOpIndex) {
        this(vaqueroPropName, metricsOpIndex, 1.0);
    }

    public OpNum(String vaqueroPropName, int metricsOpIndex, double normalizer) {
        super(vaqueroPropName);
        this.metricsOpIndex = metricsOpIndex;
        this.normalizer = normalizer;
    }

    @Override
    public double getValue() {
        return value;
    }

    @Override
    public void update(long[] metricsRecords, long prevTime, long currentTime) {
        value = (double) metricsRecords[metricsOpIndex] / normalizer;
    }

}
