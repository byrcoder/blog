/**
 * @(#)WALogReplayCoworkTask.java, 2011-8-19. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.backup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.regex.Pattern;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.dfs.client.DFSClient;
import odis.io.CDataOutputStream;
import odis.io.FSDataInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem.PathFilter;
import odis.io.MyByteArrayOutputStream;
import odis.io.Path;
import odis.serialize.lib.ByteArrayWritable;
import odis.util.unsafe.UnsafeHelper;
import outfox.omap.client.protocol.CompressType;
import outfox.omap.client.protocol.Table;
import outfox.omap.conf.OmapConfig;
import outfox.omap.data.DataRow;
import outfox.omap.data.KeyCell;
import outfox.omap.data.KeyRange;
import outfox.omap.data.KeyRangeList;
import outfox.omap.metadata.TableDesc;
import outfox.omap.ts.NativeRamWriteBuffer;
import outfox.omap.ts.SSTableWriter;
import outfox.omap.ts.WriteBufferPool;
import outfox.omap.ts.insertlog.InsertLogEntry;
import outfox.omap.ts.insertlog.WALogInsert;
import outfox.omap.util.CloseableIterator;
import outfox.omap.util.OmapUtils;
import outfox.omap.walog.LogIterator;
import outfox.omap.walog.LogReader;
import outfox.omap.walog.LogReaderHandler;
import outfox.omap.walog.WALogEntry;
import outfox.omap.walog.WALogFile;
import toolbox.text.util.HexString;

/**
 * @author wangfk
 */

public class WALogReplayCoworkTask extends TaskRunnable {
    static final String CONF_SNAPSHOT_PATH = "snapshot_path";

    static final String CONF_REPLAY_LOG_PATH = "replay_log_path";

    static final String CONF_REPLAY_TEMP_PATH = "replay_temp_path";

    static final String CONF_REPLAY_START_TIME = "replay_start_time";

    static final String CONF_REPLAY_END_TIME = "replay_end_time";

    static final String CONF_FILE_SYSTEM_NAME = "file_system_name";

    static final String CONF_MAX_BUFFER_SIZE = "max_buffer_size";

    private KeyRangeList keyRangeList;

    private KeyRange tabletKeyRange;

    private TableDesc tableDesc;

    private FileSystem fileSystem;

    private Path snapshotPath;

    private Path replayTempPath;

    private Path replayLogPath;

    private long replayStartTimestamp;

    private long replayEndTimestamp;

    long count = 0;

    private LogReader logReader;

    @Override
    public void configure(JobDef def, TaskWorker tw) {
        snapshotPath = new Path(def.getConfig().getString(CONF_SNAPSHOT_PATH));
        replayLogPath = new Path(
                def.getConfig().getString(CONF_REPLAY_LOG_PATH));
        replayTempPath = new Path(def.getConfig().getString(
                CONF_REPLAY_TEMP_PATH));
        replayTempPath = replayTempPath.cat(Integer.toString(part));
        replayStartTimestamp = def.getConfig().getLong(CONF_REPLAY_START_TIME);
        replayEndTimestamp = def.getConfig().getLong(CONF_REPLAY_END_TIME);

        try {
            // get file system
            fileSystem = FileSystem.getNamed(def.getConfig().getString(
                    CONF_FILE_SYSTEM_NAME));

            // read KeyRangeList
            keyRangeList = new KeyRangeList();
            Path krlFile = snapshotPath.cat("keyRangeList");
            FSDataInputStream krlStream = fileSystem.open(krlFile);
            keyRangeList.readFields(krlStream);
            krlStream.close();
            tabletKeyRange = keyRangeList.getRangeList().get(part);

            // read OmapMetadata
            tableDesc = new TableDesc();
            Path tableDescFile = snapshotPath.cat("tableDesc");
            FSDataInputStream tdStream = fileSystem.open(tableDescFile);
            tableDesc.readFields(tdStream);
            tdStream.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        this.worker = tw;
        getCounter("testCounter");

        LOG.info("Task[part=" + part + "] configure finsihed"
                + ": snapshotPath=" + snapshotPath + ", replayLogPath="
                + replayLogPath + ", replayStartTimestamp="
                + replayStartTimestamp + ", replayEndTimestamp="
                + replayEndTimestamp + ", tableId="
                + tabletKeyRange.getTabletId());
    }

    @Override
    protected long cursor() {
        return count;
    }

    @Override
    public void run() {
        try {
            PriorityQueue<WALogFile> pq;
            try {
                List<Path> listReplayLogFiles = listReplayLogFiles();
                if (listReplayLogFiles.isEmpty()) {
                    LOG.info("There are no logs for relay, exist");
                    return;
                }
                LOG.info("Log files to replay: " + listReplayLogFiles);

                pq = new PriorityQueue<WALogFile>(listReplayLogFiles.size(),
                        WALogFile.FORWARD_COMP);
                for (Path p: listReplayLogFiles) {
                    pq.add(new WALogFile(fileSystem, generateTempLogFile(p)));
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            logReader = new LogReader(pq, new InsertLogEntry(),
                    new LogReplayHandler(), replayStartTimestamp,
                    replayEndTimestamp, false);
            try {
                logReader.read();
            } catch (IOException e) {
                throw new RuntimeException();
            }
            count += pq.size();
        } finally {
            try {
                fileSystem.delete(replayTempPath);
            } catch (IOException e) {}
        }
    }

    @Override
    public float getProgress() {
        if (logReader == null) {
            return 0.0f;
        }
        return logReader.getProgress();
    }

    private class LogReplayHandler implements LogReaderHandler {
        NativeRamWriteBuffer writeBuffer;

        long ptr;

        WriteBufferPool directBufferPool;

        int flushSize;

        boolean enableBloomFilter = OmapConfig.getConfiguration().getBoolean(
                OmapConfig.NAME_ENABLE_BLOOM_FILTER,
                OmapConfig.DEFAULT_ENABLE_BLOOM_FILTER);

        CompressType compressType = CompressType.toType(tableDesc.getProperty(
                Table.Property.COMPRESS_NAME, Table.Property.DEFAULT_COMPRESS));

        float bfFalseRate = Float.parseFloat(tableDesc.getProperty(
                Table.Property.BLOOMFILTER_FALSERATE_NAME,
                Table.Property.DEFAULT_BLOOMFILTER_FALSERATE));

        byte replication = Byte.parseByte(tableDesc.getProperty(
                Table.Property.REPLICATION_NAME,
                Table.Property.DEFAULT_REPLICATION));

        public LogReplayHandler() {
            try {
                int maxSize = (int) OmapConfig.getConfiguration().getLong(
                        OmapConfig.NAME_MAX_BYTES_PER_TABLET,
                        OmapConfig.DEFAULT_MAX_BYTES_PER_TABLET);
                ptr = UnsafeHelper.unsafe.allocateMemory(maxSize);
                directBufferPool = new WriteBufferPool(ptr, maxSize, maxSize);
                writeBuffer = new NativeRamWriteBuffer(
                        tabletKeyRange.getTabletId(), directBufferPool,
                        tableDesc.getKey());
                flushSize = maxSize / 10 * 9;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public void handle(WALogEntry entry) throws IOException {
            if (entry.getLogType() == InsertLogEntry.TYPE_INSERT) {
                WALogInsert body = (WALogInsert) entry.getBody();
                writeBuffer.put(body.getData());
                if (writeBuffer.getActualByteSize() > flushSize) {
                    flushWriteBufferToSSTable();
                }
            } else {
                throw new RuntimeException("Unknown log type: "
                        + entry.getLogType());
            }
        }

        @Override
        public void done() throws IOException {
            if (writeBuffer.getNumKeys() == 0) {
                writeBuffer.close();
            } else {
                flushWriteBufferToSSTable();
            }
            UnsafeHelper.unsafe.freeMemory(ptr);
        }

        @Override
        public void fail() throws IOException {
            writeBuffer.close();
            UnsafeHelper.unsafe.freeMemory(ptr);
        }

        private void flushWriteBufferToSSTable() throws IOException {
            Path tsPath = snapshotPath.cat("ts");
            Path ssTableFileDirPath = new Path(OmapUtils.getSSTableFileDirPath(
                    tsPath.getPath(), tabletKeyRange.getTabletId()));

            Path tempSSTablePath = ssTableFileDirPath.cat("SS_-1");
            if (fileSystem.exists(tempSSTablePath)) {
                LOG.warning("Remove unfinished sstable: " + tempSSTablePath);
                fileSystem.delete(tempSSTablePath);
            }

            int writeCount = 0;
            SSTableWriter sstWriter = new SSTableWriter(fileSystem,
                    tempSSTablePath, false, DFSClient.OS_NOLOCALBACKUP,
                    writeBuffer.getNumKeys(), enableBloomFilter, compressType,
                    bfFalseRate, replication);
            CloseableIterator<ByteArrayWritable> iter = writeBuffer.iterator();
            try {
                ByteArrayWritable row = new ByteArrayWritable();
                ByteArrayWritable key = new ByteArrayWritable();
                KeyCell keyCell = tableDesc.getKey().borrowKeyCell();
                MyByteArrayOutputStream bos = new MyByteArrayOutputStream();
                CDataOutputStream dos = new CDataOutputStream(bos);
                while (iter.next(row)) {
                    DataRow.keyCellFromBinaryRow(keyCell, row.data(), 0,
                            row.size());
                    bos.reset();
                    keyCell.writePIFields(dos);
                    key.setBuffer(bos.getData(), bos.size());
                    sstWriter.write(key, row);
                    ++writeCount;
                }
            } finally {
                OmapUtils.safeClose(iter);
                sstWriter.close();
            }
            if (writeCount != writeBuffer.getNumKeys()) {
                throw new RuntimeException("Bug: " + writeCount
                        + " keys flushed, while " + writeBuffer.getNumKeys()
                        + " exists");
            }

            FileInfo[] listFiles = fileSystem.listFiles(ssTableFileDirPath,
                    new PathFilter() {

                        @Override
                        public boolean accept(Path path) {
                            return path.getName().startsWith("SS_");
                        }
                    });
            int lastSSTableId = 1;
            for (FileInfo fi: listFiles) {
                int sstId = Integer.parseInt(fi.getPath().getName().substring(3));
                if (sstId > lastSSTableId) {
                    lastSSTableId = sstId;
                }
            }
            Path sstPath = ssTableFileDirPath.cat("SS_" + (lastSSTableId + 2));
            fileSystem.rename(tempSSTablePath, sstPath);

            writeBuffer.close();
            writeBuffer = new NativeRamWriteBuffer(
                    tabletKeyRange.getTabletId(), directBufferPool,
                    tableDesc.getKey());
        }

    }

    private List<Path> listReplayLogFiles() throws IOException {
        final long tabletId = tabletKeyRange.getTabletId();
        String hexTabletId = HexString.longToPaddedHex(tabletId);
        Path tabletLogPath = replayLogPath.cat(hexTabletId);
        ArrayList<Path> result = new ArrayList<Path>();

        if (fileSystem.exists(tabletLogPath)) {
            FileInfo[] listFiles = fileSystem.listFiles(tabletLogPath,
                    new PathFilter() {
                        @Override
                        public boolean accept(Path path) {
                            return Pattern.matches(
                                    TableBackupConstant.WALogFilePattern,
                                    path.getName())
                                    && checkLogTimestamp(path);
                        }
                    });
            if (listFiles != null) {
                for (FileInfo fi: listFiles) {
                    if (!fi.isDir()) {
                        result.add(fi.getPath());
                    }
                }
            }
        }

        final Set<Long> tablets = new HashSet<Long>();
        for (KeyRange kr: keyRangeList.getRangeList()) {
            tablets.add(kr.getTabletId());
        }

        FileInfo[] listFiles = fileSystem.listFiles(replayLogPath,
                new PathFilter() {

                    @Override
                    public boolean accept(Path path) {
                        long logTabletId = HexString.paddedHexToLong(path.getName());
                        try {
                            return !tablets.contains(logTabletId)
                                    && logTabletId > tabletId
                                    && checkLogKeyRange(path);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });

        if (listFiles != null) {
            for (FileInfo fi: listFiles) {
                if (fi.isDir()) {
                    FileInfo[] logFiles = fileSystem.listFiles(fi.getPath(),
                            new PathFilter() {

                                @Override
                                public boolean accept(Path path) {
                                    return checkLogTimestamp(path);
                                }
                            });
                    if (logFiles != null) {
                        for (FileInfo f: logFiles) {
                            result.add(f.getPath());
                        }
                    }
                }
            }
        }

        return result;
    }

    private boolean checkLogKeyRange(Path path) throws IOException {
        FileInfo[] listFiles = fileSystem.listFiles(path);
        if (listFiles == null || listFiles.length == 0) {
            return false;
        }

        WALogEntry entry = new InsertLogEntry();
        WALogFile walf = new WALogFile(fileSystem,
                generateTempLogFile(listFiles[0].getPath()));
        LogIterator iterator = walf.iterator();
        try {
            if (!iterator.next(entry)) {
                return false;
            }
            WALogInsert body = (WALogInsert) entry.getBody();
            ByteArrayWritable data = body.getData();
            DataRow dataRow = tableDesc.borrowDataRow();
            OmapUtils.convertBytesToPIWritable(data.data(), 0, data.size(),
                    dataRow);
            KeyCell keyCell = dataRow.getKeyCell();
            boolean result = tabletKeyRange.containsKey(keyCell.getKey());
            tableDesc.returnDataRow(dataRow);
            return result;
        } finally {
            iterator.close();
        }
    }

    private boolean checkLogTimestamp(Path path) {
        return replayStartTimestamp < getLogTimestamp(path);
    }

    private Path generateTempLogFile(Path logFile) throws IOException {
        String fileName = logFile.getName();
        fileName = WALogFile.FILE_PREFIX
                + fileName.substring(fileName.indexOf('-') + 1);
        Path tempLogParent = replayTempPath.cat(Long.toString(System.currentTimeMillis()));
        Path distFile = tempLogParent.cat(fileName);

        fileSystem.mkdirs(tempLogParent);
        fileSystem.link(logFile, distFile);

        return distFile;
    }

    private static long getLogTimestamp(Path path) {
        String fileName = path.getName();
        return Long.parseLong(fileName.substring(fileName.indexOf('-') + 1));
    }
}
