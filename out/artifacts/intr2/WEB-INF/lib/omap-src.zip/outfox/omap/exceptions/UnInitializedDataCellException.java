package outfox.omap.exceptions;

public class UnInitializedDataCellException extends RuntimeException {

    private static final long serialVersionUID = -4346763722495024650L;

    public UnInitializedDataCellException() {
        this("Trying to get data from an invalid (uninitialized) data cell");
    }

    public UnInitializedDataCellException(String message) {
        super(message);
    }

}
