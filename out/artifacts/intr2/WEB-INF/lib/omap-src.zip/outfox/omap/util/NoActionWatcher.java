/**
 * @(#)NoActionWatcher.java, 2011-5-24. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.util;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

/**
 * @author zhangduo
 */
public class NoActionWatcher implements Watcher {

    @Override
    public void process(WatchedEvent event) {}

}
