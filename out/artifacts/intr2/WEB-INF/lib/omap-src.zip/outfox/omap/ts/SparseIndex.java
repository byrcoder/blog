/**
 * @(#)SparseIndex.java, 2011-10-12. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.ts;

import java.io.EOFException;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.io.FSDataInputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.LongWritable;
import odis.util.unsafe.NativeRamBuffer;
import odis.util.unsafe.NativeRamBufferCDataInputStream;
import outfox.omap.data.KeyCell;
import outfox.omap.exceptions.LogicException;
import outfox.omap.metadata.KeyCellBinaryComparator;
import outfox.omap.metadata.TableDesc;
import outfox.omap.util.GenericWritableComparator;
import outfox.omap.util.OmapUtils;
import toolbox.collections.primitive.ByteArrayList;
import toolbox.collections.primitive.IntegerArrayList;
import toolbox.collections.primitive.LongArrayList;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class SparseIndex {

    private static final Logger LOG = LogFormatter.getLogger(SparseIndex.class);

    private final SparseIndexPool pool;

    final SSTable sstable;

    // This is used for top ref sstable. Data file will end at middle of actual
    // file instead of end of file.
    private final long dataFileEnd;

    // The layout is keys, keyOffsets, and offsets
    // key n will be in [keyOffsets[n], keyOffsets[n + 1])
    // the last key will be in [keyOffsets[keyOffsets.length - 1], keys.length)
    final NativeRamBuffer[] buffers;

    // we only record keys length here, because keyOffsets and offsets are 
    // fixed, we can calculate offsets offset by indexEntryCount.
    private final int keysLength;

    private final int indexEntryCount;

    private final ByteArrayWritable firstKey;

    private final ByteArrayWritable lastKey;

    private final ByteArrayWritable midKey;

    static class IndexStruct {
        /**
         * The key of the sparse index
         */
        public ByteArrayWritable key;

        /**
         * The offset the key
         */
        public long offset;

        /**
         * The size of the indexed block
         */
        public int size;

        /**
         * 表明是第几个IndexStruct，用于next
         */
        public int index;

        @Override
        public String toString() {
            return "IndexStruct [key=" + key + ", offset=" + offset + ", size="
                    + size + ", index=" + index + "]";
        }
    }

    SparseIndex(SSTable sstable, SparseIndexPool pool) throws IOException {
        FileSystem fs = sstable.ts.dfs;
        Path sparseIndexFile = sstable.path.cat(SSTable.SPARSE_INDEX_FILE_NAME);
        FSDataInputStream dataIn = fs.open(sparseIndexFile);
        SequenceFile.Reader reader = null;
        try {
            reader = new SequenceFile.Reader(fs, sparseIndexFile, dataIn);
        } finally {
            if (reader == null) {
                ReadWriteUtils.safeClose(dataIn);
            }
        }

        this.sstable = sstable;
        this.pool = pool;
        TableDesc tableDesc = sstable.ts.getMetaCache().getMetadata(
                OmapUtils.tid2sid(sstable.tabletId)).getTableDesc();
        int totalEntryCount = (int) sstable.metaData.getSparseIndexEntryCount();
        ByteArrayList keysList = new ByteArrayList((int) reader.getSize());
        IntegerArrayList keyOffsetList = new IntegerArrayList(totalEntryCount);
        LongArrayList offsetList = new LongArrayList(totalEntryCount);

        GenericWritableComparator comp = GenericWritableComparator.instance;
        KeyCell current = tableDesc.getKey().borrowKeyCell();
        KeyCell prev = null;

        ByteArrayWritable k = new ByteArrayWritable();
        LongWritable offset = new LongWritable();
        long dataFileEnd = -1L;
        try {
            for (int i = 0; i < totalEntryCount; ++i) {
                if (!reader.next(k, offset)) {
                    throw new IOException("Incomplete index from " + reader
                            + ", got " + i + ", expect " + totalEntryCount);
                }
                OmapUtils.convertBytesToPIWritable(k.data(), 0, k.size(),
                        current);
                // out of range, exit loop
                if (sstable.isTopRef()
                        && comp.compare(current.getKey(), sstable.middleKey) >= 0) {
                    dataFileEnd = offset.get();
                    break;
                }
                // skip the keys that not contains in KeyRange
                // we should keep the last "not contains" key unless we get a 
                // index key that just equal to middleKey
                if (sstable.isBottomRef()
                        && comp.compare(current.getKey(), sstable.middleKey) <= 0) {
                    keysList.clear();
                    keyOffsetList.clear();
                    offsetList.clear();
                    keyOffsetList.add(keysList.size());
                    keysList.addAll(k.data(), 0, k.size());
                    offsetList.add(offset.get());
                    continue;
                }
                if (prev != null) {
                    if (comp.compare(current.getKey(), prev.getKey()) <= 0) {
                        throw new IOException("unordered index key found for "
                                + sstable + ", prev is " + prev
                                + ", current is " + current);
                    }
                    if (offset.get() <= offsetList.get(offsetList.size() - 1)) {
                        throw new IOException("unordered offset found for "
                                + sstable + ", prev is "
                                + offsetList.get(offsetList.size() - 1)
                                + ", current is " + offset.get());
                    }
                    KeyCell tmp = prev;
                    prev = current;
                    current = tmp;
                } else {
                    prev = current;
                    current = tableDesc.getKey().borrowKeyCell();
                }
                keyOffsetList.add(keysList.size());
                keysList.addAll(k.data(), 0, k.size());
                offsetList.add(offset.get());
            }
            tableDesc.getKey().returnKeyCell(current);
            if (prev != null) {
                tableDesc.getKey().returnKeyCell(prev);
            }
            if (dataFileEnd < 0) {
                this.dataFileEnd = sstable.dataSize();
            } else {
                this.dataFileEnd = dataFileEnd;
            }
            DirectByteArrayOutputStream bos = new DirectByteArrayOutputStream(
                    keysList.size() + 4 * keyOffsetList.size() + 8
                            * offsetList.size());
            CDataOutputStream dos = new CDataOutputStream(bos);
            dos.write(keysList.getArray(), 0, keysList.size());
            for (int i = 0; i < keyOffsetList.size(); i++) {
                dos.writeInt(keyOffsetList.get(i));
            }
            for (int i = 0; i < offsetList.size(); i++) {
                dos.writeLong(offsetList.get(i));
            }
            dos.close();
            NativeRamBuffer[] buffers = pool.createBuffer(sstable,
                    bos.getBufferSize());
            NativeRamBuffer.copyFromArray(buffers, bos.getBuffer(), 0,
                    bos.getBufferSize());
            this.buffers = buffers;
            this.indexEntryCount = offsetList.size();
            this.keysLength = keysList.size();
            NativeRamBufferCDataInputStream in = createBufferInputStream();

            firstKey = new ByteArrayWritable(createBinaryKey(in, 0));
            int mid = indexEntryCount / 2;
            midKey = new ByteArrayWritable(createBinaryKey(in, mid));
            lastKey = new ByteArrayWritable(createBinaryKey(in,
                    indexEntryCount - 1));
        } finally {
            OmapUtils.safeClose(reader);
        }
    }

    private NativeRamBufferCDataInputStream createBufferInputStream() {
        return new NativeRamBufferCDataInputStream(buffers,
                buffers[0].getCapacity(), keysLength + indexEntryCount * 12);
    }

    private int getKeyOffset(NativeRamBufferCDataInputStream in, int index) {
        if (index == indexEntryCount) {
            return keysLength;
        }
        in.seek(keysLength + 4 * index);
        try {
            return in.readInt();
        } catch (EOFException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    private long getOffset(NativeRamBufferCDataInputStream in, int index) {
        if (index == indexEntryCount) {
            return dataFileEnd;
        }
        in.seek(keysLength + 4 * indexEntryCount + 8 * index);
        try {
            return in.readLong();
        } catch (EOFException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    private byte[] createBinaryKey(NativeRamBufferCDataInputStream in, int index) {
        int keyOffset = getKeyOffset(in, index);
        int keyLength = getKeyOffset(in, index + 1) - keyOffset;
        byte[] key = new byte[keyLength];
        in.seek(keyOffset);
        try {
            in.readFully(key);
        } catch (EOFException e) {
            // should not happen
            throw new RuntimeException(e);
        }
        return key;
    }

    private int binarySearch(ByteArrayWritable key, KeyCellBinaryComparator c,
            NativeRamBufferCDataInputStream in) throws IOException {
        int low = 0;
        int high = indexEntryCount - 1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            in.seek(getKeyOffset(in, mid));
            int cmp = c.compare(in, key.data(), 0);

            if (cmp < 0) {
                low = mid + 1;
            } else if (cmp > 0) {
                high = mid - 1;
            } else {
                return mid; // key found
            }
        }
        return -(low + 1); // key not found.
    }

    /**
     * Return found index, or max one of indexes smaller than the param.<br>
     * If all indexes are biger than the param, return the smallest one.
     * 
     * @param key
     * @return
     * @throws IOException
     */
    IndexStruct getIndex(ByteArrayWritable key,
            KeyCellBinaryComparator comparator) throws IOException {
        NativeRamBufferCDataInputStream in = createBufferInputStream();
        int index = binarySearch(key, comparator, in);

        //found in indexed key
        if (index <= 0) {
            index = -index - 2;
        }

        //before the first key, we will return the first key.
        //if 'seekNextWhenNotFound', this is useful
        if (index < 0) {
            index = 0;
        }

        IndexStruct result = new IndexStruct();
        result.index = index;
        result.key = new ByteArrayWritable(createBinaryKey(in, index));
        result.offset = getOffset(in, index);
        result.size = (int) (getOffset(in, index + 1) - result.offset);
        return result;
    }

    IndexStruct first() {
        NativeRamBufferCDataInputStream in = createBufferInputStream();
        IndexStruct result = new IndexStruct();
        result.index = 0;
        result.key = firstKey;
        result.offset = getOffset(in, 0);
        result.size = (int) (getOffset(in, 1) - result.offset);
        return result;
    }

    /**
     * If 'seekNextWhenNotFound', and key to find is not in current block, we
     * should return the first key of the next block.
     * 
     * @param currIndex
     * @return If currIndex is not a spare key or the last one, return null.
     * @throws IOException
     */
    IndexStruct getNextIndex(IndexStruct indexStruct) {
        int index = indexStruct.index;

        //currIndex is not in the keys or the last one
        if (index < 0 || index >= indexEntryCount - 1) {
            return null;
        } else {
            NativeRamBufferCDataInputStream in = createBufferInputStream();
            index++;
            IndexStruct result = new IndexStruct();
            result.index = index;
            result.key = new ByteArrayWritable(createBinaryKey(in, index));
            result.offset = getOffset(in, index);
            result.size = (int) (getOffset(in, index + 1) - result.offset);
            return result;
        }
    }

    long getIndexSize() {
        return keysLength + 12 * indexEntryCount;
    }

    ByteArrayWritable getFirstKey() {
        return firstKey;
    }

    ByteArrayWritable getLastKey() {
        return lastKey;
    }

    ByteArrayWritable getMidKey() {
        return midKey;
    }

    private final AtomicInteger ref = new AtomicInteger(2);

    void acquire() {
        ref.incrementAndGet();
    }

    private boolean released = false;

    boolean release() {
        if (ref.decrementAndGet() == 0) {
            synchronized (pool.pool) {
                if (released) {
                    throw new LogicException("SparseIndex for " + sstable
                            + " released multiple times");
                }
                released = true;
                pool.bufferPool.releaseBuffer(buffers);
                LOG.info("Unload sparseIndex for " + sstable
                        + ", index pool usage: "
                        + pool.bufferPool.getAllocatedBufferSize() + "/"
                        + pool.bufferPool.getMaxBufferSize());
            }
            return true;
        } else {
            return false;
        }
    }

}
