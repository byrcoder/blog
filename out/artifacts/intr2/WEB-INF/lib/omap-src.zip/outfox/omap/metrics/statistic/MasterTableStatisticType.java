/**
 * @(#)MasterTableStatisticType.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TimeRangeUtils;

/**
 *
 * @author zhangduo
 *
 */
public enum MasterTableStatisticType {
    LOOKUP_KEY_COUNT(0),
    LOOKUP_KEY_DELAY(LOOKUP_KEY_COUNT.offset + 1),
    TIME_RANGE_LOOKUP_KEY_COUNT(LOOKUP_KEY_DELAY.offset + 1),
    
    RENAME_TABLE_COUNT(TIME_RANGE_LOOKUP_KEY_COUNT.offset + TimeRangeUtils.rangeCount()),
    RENAME_TABLE_DELAY(RENAME_TABLE_COUNT.offset + 1),
    TIME_RANGE_RENAME_TABLE_COUNT(RENAME_TABLE_COUNT.offset + 1),
    
    SET_TABLE_PROPERTIES_COUNT(TIME_RANGE_RENAME_TABLE_COUNT.offset + TimeRangeUtils.rangeCount()),
    SET_TABLE_PROPERTIES_DELAY(SET_TABLE_PROPERTIES_COUNT.offset + 1),
    TIME_RANGE_SET_TABLE_PROPERTIES_COUNT(SET_TABLE_PROPERTIES_DELAY.offset + 1),
    
    GET_SCHEMA_ID_COUNT(TIME_RANGE_SET_TABLE_PROPERTIES_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_SCHEMA_ID_DELAY(GET_SCHEMA_ID_COUNT.offset + 1),
    TIME_RANGE_GET_SCHEMA_ID_COUNT(GET_SCHEMA_ID_DELAY.offset + 1),
    
    GET_METADATA_COUNT(TIME_RANGE_GET_SCHEMA_ID_COUNT.offset + TimeRangeUtils.rangeCount()),
    GET_METADATA_DELAY(GET_METADATA_COUNT.offset + 1),
    TIME_RANGE_GET_METADATA_COUNT(GET_METADATA_DELAY.offset + 1),
    
    SET_READ_ONLY_COUNT(TIME_RANGE_GET_METADATA_COUNT.offset + TimeRangeUtils.rangeCount()),
    SET_READ_ONLY_DELAY(SET_READ_ONLY_COUNT.offset + 1),
    TIME_RANGE_SET_READ_ONLY_COUNT(SET_READ_ONLY_DELAY.offset + 1),
    
    MAX_TYPE(TIME_RANGE_SET_READ_ONLY_COUNT.offset + TimeRangeUtils.rangeCount());
    
    private final int offset;

    private MasterTableStatisticType(int offset) {
        this.offset = offset;
    }

    public int offset() {
        return offset;
    }

    public static int getTypeCount() {
        return MAX_TYPE.offset;
    }
}
