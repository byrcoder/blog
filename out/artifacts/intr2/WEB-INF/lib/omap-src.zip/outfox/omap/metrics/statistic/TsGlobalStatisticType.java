/**
 * @(#)TsGlobalStatisticType.java, 2011-6-13. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.omap.metrics.statistic;

import outfox.omap.metrics.TimeRangeUtils;

/**
 *
 * @author zhangduo
 *
 */
public enum TsGlobalStatisticType {
    HEARTBEAT_COUNT(0),
    HEARTBEAT_DELAY(HEARTBEAT_COUNT.offset + 1),
    TIME_RANGE_HEARTBEAT_COUNT(HEARTBEAT_DELAY.offset + 1),
    
    SSTABLE_SEEK_COUNT(TIME_RANGE_HEARTBEAT_COUNT.offset + TimeRangeUtils.rangeCount()),
    SSTABLE_SEEK_DELAY(SSTABLE_SEEK_COUNT.offset + 1),
    TIME_RANGE_SSTABLE_SEEK_COUNT(SSTABLE_SEEK_DELAY.offset + 1),
    
    SYSTEM_LOAD(TIME_RANGE_SSTABLE_SEEK_COUNT.offset + TimeRangeUtils.rangeCount()),
    SYSTEM_LOAD_PER_PROCESSOR(SYSTEM_LOAD.offset + 1),
    
    MEMORY_INIT(SYSTEM_LOAD_PER_PROCESSOR.offset + 1),
    MEMORY_USED(MEMORY_INIT.offset + 1),
    MEMORY_COMMITTED(MEMORY_USED.offset + 1),
    MEMORY_MAX(MEMORY_COMMITTED.offset + 1),
    
    WRITE_BUFFER_USED(MEMORY_MAX.offset + 1),
    WRITE_BUFFER_MAX(WRITE_BUFFER_USED.offset + 1),
    
    BLOOMFILTER_USED(WRITE_BUFFER_MAX.offset + 1),
    BLOOMFILTER_MAX(BLOOMFILTER_USED.offset + 1),
    
    INDEX_POOL_USED(BLOOMFILTER_MAX.offset + 1),
    INDEX_POOL_MAX(INDEX_POOL_USED.offset + 1),
    
    BLOCK_CACHE_USED(INDEX_POOL_MAX.offset + 1),
    BLOCK_CACHE_MAX(BLOCK_CACHE_USED.offset + 1),
    BLOCK_CACHE_CACHE_COUNT(BLOCK_CACHE_MAX.offset + 1),
    BLOCK_CACHE_GET_COUNT(BLOCK_CACHE_CACHE_COUNT.offset + 1),
    BLOCK_CACHE_GET_HIT_COUNT(BLOCK_CACHE_GET_COUNT.offset + 1),
    BLOCK_CACHE_EVICT_COUNT(BLOCK_CACHE_GET_HIT_COUNT.offset + 1),
    
    REQUEST_COUNT(BLOCK_CACHE_EVICT_COUNT.offset + 1),
    TIMEOUT_REQUEST_COUNT(REQUEST_COUNT.offset + 1),
    
    MAX_TYPE(TIMEOUT_REQUEST_COUNT.offset + 1);
    
    private final int offset;

    private TsGlobalStatisticType(int offset) {
        this.offset = offset;
    }

    public int offset() {
        return offset;
    }

    public static int getTypeCount() {
       return MAX_TYPE.offset;
    }
}
