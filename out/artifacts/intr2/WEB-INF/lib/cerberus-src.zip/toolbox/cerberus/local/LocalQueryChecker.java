package toolbox.cerberus.local;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import toolbox.cerberus.IAddressRuleSet;
import toolbox.cerberus.IKeyWordRuleSet;
import toolbox.cerberus.IQueryChecker;
import toolbox.cerberus.IQueryInfo;
import toolbox.cerberus.IResultInfo;
import toolbox.cerberus.ISingleResultUnit;
import toolbox.cerberus.IUrlRuleSet;
import toolbox.cerberus.IWebPageUnit;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.TextObject;
import toolbox.cerberus.UrlSet;
import toolbox.cerberus.local.config.ConfigData;
import toolbox.cerberus.local.config.ConfigRuleSet;
import toolbox.cerberus.log.HitQueryLogger;
import toolbox.cerberus.log.HitSummaryLogger;
import toolbox.cerberus.log.LogStatus;
import toolbox.cerberus.log.LogType;
import toolbox.cerberus.log.LogUnit;
import toolbox.cerberus.log.UnHitQueryLogger;
import toolbox.cerberus.util.TextStringUtil;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.IpUtils;

/**
 * 基于配置文件的在当前应用中的本地QueryChecker实现，通过配置文件中的各种规则来进行过滤. 包含的规则有:
 * <ul>
 * <li>基于ip地址的规则</li>
 * <li>基于url的规则</li>
 * <li>基于查询关键字的规则</li>
 * <li>基于summary关键字的规则</li>
 * </ul>
 * 
 * @author likui
 */
public class LocalQueryChecker implements IQueryChecker {
    public static final Logger LOG = LogFormatter
            .getLogger(LocalQueryChecker.class);

    private IAddressRuleSet addressRuleSet; // 基于ip的规则列表

    private IUrlRuleSet urlRuleSet; // 基于url的规则列表

    private UrlSets urlSets;

    private IKeyWordRuleSet queryKeyWordRuleSet;

    private IKeyWordRuleSet summaryKeyWordRuleSet;

    // public static outlog.logging.Logger outLogger;

    private boolean empty = true;

    /**
     * 是否记录log
     */
    LogStatus logStatus;

    String logDeliter = "|";

    private String product;

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public boolean isEmpty() {
        return empty;
    }

    public void setEmpty(boolean empty) {
        this.empty = empty;
    }

    public IAddressRuleSet getAddressRuleSet() {
        return addressRuleSet;
    }

    public IKeyWordRuleSet getQueryKeywordRuleSet() {
        return queryKeyWordRuleSet;
    }

    public IKeyWordRuleSet getSummaryKeyWordRuleSet() {
        return summaryKeyWordRuleSet;
    }

    public IUrlRuleSet getUrlRuleSet() {
        return urlRuleSet;
    }

    // /////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * 根据QueryCheckResult中的urlSet的id填充对应的urlSet到result中.
     */
    private QueryCheckResult finishCheckResult(QueryCheckResult result) {
        if (result.getAction() != QueryCheckResult.Action.IN_SET) {
            // REJECT
            return result;
        }

        String urlSetId = result.getUrlSetId();
        UrlSet set = urlSets.getUrlSet(urlSetId);
        if (set == null && urlSetId != null) {
            // REJECT
            LOG.warning("cannot find url set " + urlSetId);
            result.setAction(QueryCheckResult.Action.REJECT);

        } else {
            // INSET
            result.setUrlSet(set);
        }
        return result;
    }

    /**
     * check logic:two functions 1:check user's query 2:check server's return
     * result
     */

    public QueryCheckResult checkQuery(IQueryInfo query) {
        try {
            return checkQueryImpl(query);
        } catch (Exception e) {
            LOG
                    .log(Level.WARNING,
                            "Cerberus occurs exception ,please check", e);
            return QueryCheckResult.NORMAL;
        }
    }

    /**
     * @param query
     * @return
     */
    private QueryCheckResult checkQueryImpl(IQueryInfo query) throws Exception {
        LOG.info("QBEGIN" + logDeliter + query.getQuery());
        String ipStr = IpUtils.formatIp(query.getIp());
        String normalizerQuery = TextStringUtil.normalizerQuery(query
                .getQuery());
        // first apply ip rules
        QueryCheckResult result = addressRuleSet.check(query.getIp());
        if (result.getAction() != QueryCheckResult.Action.NORMAL) {
            LOG.info("QEND" + logDeliter + normalizerQuery + logDeliter
                    + result.getAction() + logDeliter + result.getRuleId());
            // black ip hit
            if (result.getAction() == QueryCheckResult.Action.REJECT) {
                LogUnit unit = new LogUnit(LogType.IP_HIT, result.getRuleId(),
                        ipStr, normalizerQuery, null, null);
                if (logStatus.isLogMatched())
                    HitQueryLogger.logRecord(unit);
            } else if (result.getAction() == QueryCheckResult.Action.IN_SET) {
                /**
                 * 不支持ip黑名单站内搜索
                 */
                if (!logStatus.isIpInSet()) {
                    result.setAction(QueryCheckResult.Action.REJECT);
                    return result;
                }
            }
            finishCheckResult(result);
            return result;
        }

        // second apply text rules on query string
        TextObject queryText = new TextObject(normalizerQuery);
        result = queryKeyWordRuleSet.check(queryText);

        if (result.getAction() != QueryCheckResult.Action.NORMAL) {
            LOG.info("QEND" + logDeliter + normalizerQuery + logDeliter
                    + result.getAction() + logDeliter + result.getRuleId());

            if (!logStatus.isLogMatched()) {
                // not log.
            }
            // if reject | in set,log it
            else if (result.getAction() == QueryCheckResult.Action.REJECT) {
                LogUnit unit = new LogUnit(LogType.QUERY_HIT, result
                        .getRuleId(), ipStr, normalizerQuery, null, null);
                HitQueryLogger.logRecord(unit);
            } else if (result.getAction() == QueryCheckResult.Action.IN_SET) {
                /**
                 * 不支持限定站点搜索
                 */
                if (!logStatus.isInputInSet()) {
                    result.setAction(QueryCheckResult.Action.REJECT);
                    return result;
                }
                LogUnit unit = new LogUnit(LogType.LEVEL_HIT, result
                        .getRuleId(), ipStr, normalizerQuery, null, null);
                HitQueryLogger.logRecord(unit);
            }
            finishCheckResult(result);
            return result;
        }
        LOG.info("QEND" + logDeliter + normalizerQuery + logDeliter
                + result.getAction() + logDeliter + result.getRuleId());

        // Noraml,then log it
        LogUnit unit = new LogUnit("0", null, ipStr, normalizerQuery, null,
                null);
        if (logStatus.isLogSearch())
            UnHitQueryLogger.logRecord(unit);
        return QueryCheckResult.NORMAL;
    }

    public void filterResult(IQueryInfo query,
            QueryCheckResult queryCheckResult, IResultInfo resultInfo) {
        try {
            filterResultImpl(query, queryCheckResult, resultInfo);
        } catch (Exception e) {
            LOG
                    .log(Level.WARNING,
                            "Cerberus occurs exception ,please check", e);
        }
    }

    /**
     * @param query
     * @param queryCheckResult
     * @param resultInfo
     */
    private void filterResultImpl(IQueryInfo query,
            QueryCheckResult queryCheckResult, IResultInfo resultInfo)
            throws Exception {
        LOG.info("RBegin:[" + query.getQuery() + "]");
        String normalizerQuery = TextStringUtil.normalizerQuery(query
                .getQuery());

        // check green rule
        if (queryCheckResult.getAction() == QueryCheckResult.Action.GREEN) {
            LOG.info("All" + logDeliter + QueryCheckResult.Action.GREEN
                    + logDeliter + queryCheckResult.getRuleId());
            resultInfo.setAllPassed(true);
            LOG.info("REnd" + logDeliter + normalizerQuery);
            return;
        }

        // check reject rule
        if (queryCheckResult.getAction() == QueryCheckResult.Action.REJECT) {
            LOG.info("All" + logDeliter + QueryCheckResult.Action.REJECT
                    + logDeliter + queryCheckResult.getRuleId());
            resultInfo.setAllPassed(false);
            LOG.info("REnd:[" + normalizerQuery + "]");
            return;
        }

        // check level rule
        if (queryCheckResult.getAction() == QueryCheckResult.Action.IN_SET) {
            UrlSet set = queryCheckResult.getUrlSet();
            assert set != null: "Cannot find urlset when action is IN_SET";
            int resultCount = resultInfo.getSize();
            for (int i = 0; i < resultCount; i++) {
                boolean ret = set.match(resultInfo.getUrl(i));
                if (!ret) {
                    LOG.info("Results[" + i + "] " + logDeliter
                            + normalizerQuery + logDeliter
                            + QueryCheckResult.Action.REJECT + logDeliter
                            + "NOT_IN_SET" + logDeliter + resultInfo.getUrl(i)
                            + logDeliter + queryCheckResult.getRuleId());
                }
                resultInfo.setPassed(i, ret);
            }
            LOG.info("REnd:[" + normalizerQuery + "]");
            return;
        }
        String ipStr = IpUtils.formatIp(query.getIp());
        // check the result one by one
        int resultCount = resultInfo.getSize();
        for (int i = 0; i < resultCount; i++) {
            QueryCheckResult result = null;
            result = urlRuleSet.check(resultInfo.getUrl(i));
            if (result.getAction() == QueryCheckResult.Action.GREEN) {// green
                // url
                resultInfo.setPassed(i, true);
                LOG.info("Results[" + i + "] " + logDeliter + normalizerQuery
                        + logDeliter + QueryCheckResult.Action.GREEN
                        + logDeliter + result.getRuleId() + logDeliter
                        + resultInfo.getUrl(i));
                continue;
            } else if (result.getAction() == QueryCheckResult.Action.REJECT) {// black
                // black url
                resultInfo.setPassed(i, false);
                LOG.info("CBAND" + logDeliter + normalizerQuery + logDeliter
                        + QueryCheckResult.Action.REJECT + logDeliter
                        + result.getRuleId() + logDeliter
                        + resultInfo.getUrl(i) + logDeliter + "url"
                        + logDeliter + "Results[" + i + "]");
                LogUnit unit = new LogUnit(LogType.URL_HIT, result.getRuleId(),
                        ipStr, normalizerQuery, resultInfo.getUrl(i),
                        resultInfo.getSnippet(i));
                if (logStatus.isLogDiggest())
                    HitSummaryLogger.logRecord(unit);
                continue;
            }

            if (result.getAction() == QueryCheckResult.Action.NORMAL) {
                TextObject title = new TextObject(resultInfo.getTitle(i));
                result = summaryKeyWordRuleSet.check(title);
            } else {
                // invalid title.
                LOG.info("CBAND" + logDeliter + normalizerQuery + logDeliter
                        + QueryCheckResult.Action.REJECT + logDeliter
                        + result.getRuleId() + logDeliter
                        + resultInfo.getUrl(i) + logDeliter + "title"
                        + logDeliter + resultInfo.getTitle(i) + logDeliter
                        + "Results[" + i + "]");
            }

            if (result.getAction() == QueryCheckResult.Action.NORMAL) {
                TextObject digest = new TextObject(resultInfo.getSnippet(i));
                result = summaryKeyWordRuleSet.check(digest);
            }

            if (result != null) {
                boolean ret = (result.getAction() != QueryCheckResult.Action.REJECT);
                if (!ret) {
                    LOG.info("CBAND" + logDeliter + normalizerQuery
                            + logDeliter + QueryCheckResult.Action.REJECT
                            + logDeliter + result.getRuleId() + logDeliter
                            + resultInfo.getUrl(i) + logDeliter + "summary"
                            + logDeliter + resultInfo.getSnippet(i)
                            + logDeliter + "Results[" + i + "]");
                    // invalid diggest
                    LogUnit unit = new LogUnit(LogType.SUMMARY_HIT, result
                            .getRuleId(), ipStr, normalizerQuery, resultInfo
                            .getUrl(i), resultInfo.getSnippet(i));
                    if (logStatus.isLogDiggest())
                        HitSummaryLogger.logRecord(unit);
                }
                resultInfo.setPassed(i, ret);
            }
        }
        LOG.info("REnd" + logDeliter + normalizerQuery);
    }

    // ////////////////////////////////////////////////////////////////////////////////

    /**
     * update fuction if KeyWord rule is updated,related rule sets should be
     * rebuilt wholely.
     */

    private boolean initialize(ConfigRuleSet config, String product) {
        LOG.info("Begin to init local querychecher");
        this.product = product;
        LOG.info("initliazing address rule set.");
        AddressRuleSet addressRuleSet = new AddressRuleSet();
        addressRuleSet.init(config, product);
        this.addressRuleSet = addressRuleSet;

        LOG.info("initliazing url rule set.");
        UrlRuleSet urlRuleSet = new UrlRuleSet();
        urlRuleSet.init(config, product);
        this.urlRuleSet = urlRuleSet;

        LOG.info("initliazing input rule set.");
        InputKeyWordRuleSet inputRuleSet = new InputKeyWordRuleSet();
        // inputRuleSet.setRuleSetType(ConfigData.RuleSet.INPUT_ID);
        inputRuleSet.init(config, product);
        this.queryKeyWordRuleSet = inputRuleSet;

        LOG.info("initliazing output rule set.");
        SummaryKeyWordRuleSet outputRuleSet = new SummaryKeyWordRuleSet();
        outputRuleSet.setRuleSetType(ConfigData.RuleSet.OUTPUT_ID);
        boolean summaryRet = outputRuleSet.init(config, product);
        if (!summaryRet) {
            LOG.warning("Fail to update summary rule set.");
        }
        this.summaryKeyWordRuleSet = outputRuleSet;

        LOG.info("initliazing urlset rule.");
        UrlSets urlSets = new UrlSets();
        urlSets.init(config);
        this.urlSets = urlSets;

        if (summaryRet) {
            this.empty = false;
            LOG.info("Finish init local querycheck.");
            return true;
        } else {
            LOG.warning("Unable to Finish local querycheck.");
            this.empty = true;
            return false;
        }
    }

    /**
     * 初始化得到配置文件的元信息
     * 
     * @param document
     */
    void initLogStauts(Document document) {
        logStatus = new LogStatus();
        Element rootElem = document.getDocumentElement();
        String content = getElementContentByTagName(rootElem,
                ConfigData.TagName.LOG_SEARCH);
        if (content != null && content.equals("no")) {
            logStatus.setLogSearch(false);
        }
        content = getElementContentByTagName(rootElem,
                ConfigData.TagName.LOG_MATCH);
        if (content != null && content.equals("no")) {
            logStatus.setLogMatched(false);
        }

        content = getElementContentByTagName(rootElem,
                ConfigData.TagName.LOG_DIGEST);
        if (content != null && content.equals("no")) {
            logStatus.setLogDiggest(false);
        }

        content = getElementContentByTagName(rootElem,
                ConfigData.TagName.INPUT_INSET);
        if (content != null && content.equals("no")) {
            logStatus.setInputInSet(false);
        }

        content = getElementContentByTagName(rootElem,
                ConfigData.TagName.IP_INSET);
        if (content != null && content.equals("no")) {
            logStatus.setIpInSet(false);
        }

    }

    String getElementContentByTagName(Element elem, String tagName) {
        NodeList nodeList = elem.getElementsByTagName(tagName);
        if (nodeList == null || nodeList.getLength() == 0)
            return null;
        String content = ((Element) nodeList.item(0)).getTextContent();
        if (content.length() > 0)
            return content;
        return null;

    }

    /**
     * 根据传入的DOM树初始化.
     * 
     * @param document
     * @param product
     * @throws IOException
     */
    public boolean initialize(Document document, String product)
            throws IOException {
        ConfigRuleSet ruleSet = new ConfigRuleSet();
        initLogStauts(document);
        ruleSet.load(document);
        return initialize(ruleSet, product);
        // outLogger = LogFactory.getLogger("cerberus." + product);
    }

    /*
     * (non-Javadoc)
     * 
     * @see toolbox.cerberus.IQueryChecker#getUrlSet(java.lang.String)
     */
    public UrlSet getUrlSet(String setId) {
        return urlSets.getUrlSet(setId);
    }

    public UrlSet getBlackUrlSet() {
        return urlRuleSet.getBlackUrlSet();
    }

    /*
     * (non-Javadoc)
     * 
     * @see toolbox.cerberus.IQueryChecker#checkSingleResult(toolbox.cerberus.ISingleResultUnit)
     */
    public boolean checkSingleResult(ISingleResultUnit single) {
        try {
            return checkSingleResultImpl(single);
        } catch (Exception e) {
            LOG
                    .log(Level.WARNING,
                            "Cerberus occurs exception ,please check", e);
            return true;
        }
    }

    private boolean checkSingleResultImpl(ISingleResultUnit single)
            throws Exception {
        LOG.info("RBegin");
        /**
         * check url
         */
        QueryCheckResult result = null;
        result = urlRuleSet.check(single.getUrl());
        if (result.getAction() == QueryCheckResult.Action.GREEN) {// return
            // false;
            LOG.info("REND" + logDeliter + result.getAction() + logDeliter
                    + result.getRuleId() + logDeliter + single.getUrl());
            return true;
        } else if (result.getAction() == QueryCheckResult.Action.REJECT) {
            LOG.info("CBAND" + logDeliter + "" + logDeliter
                    + result.getAction() + logDeliter + result.getRuleId()
                    + logDeliter + single.getUrl() + logDeliter + "Content"
                    + logDeliter + single.getUrl());
            return false;
        }

        /**
         * check title
         */
        if (single.getTitle() != null) {
            result = summaryKeyWordRuleSet.check(new TextObject(single
                    .getTitle()));
            if (result.getAction() == QueryCheckResult.Action.REJECT) {
                LOG.info("CBAND" + logDeliter + "" + logDeliter
                        + result.getAction() + logDeliter + result.getRuleId()
                        + logDeliter + single.getUrl() + logDeliter + "title"
                        + logDeliter + single.getTitle());
                return false;
            }
        }

        /**
         * check content
         */
        if (single.getDiggest() != null)
            result = summaryKeyWordRuleSet.check(new TextObject(single
                    .getDiggest()));
        if (result.getAction() == QueryCheckResult.Action.REJECT) {
            LOG.info("CBAND" + logDeliter + "" + logDeliter
                    + result.getAction() + logDeliter + result.getRuleId()
                    + logDeliter + single.getUrl() + logDeliter + "Content"
                    + logDeliter + single.getDiggest());
            return false;
        }
        LOG.info("REnd" + logDeliter + "NORMAL");
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see toolbox.cerberus.IQueryChecker#checkSingleWebPage(toolbox.cerberus.IWebPageUnit)
     */
    public boolean checkSingleWebPage(IWebPageUnit page) {
        try {
            return checkSingleWebPageImpl(page);
        } catch (Exception e) {
            LOG
                    .log(Level.WARNING,
                            "Cerberus occurs exception ,please check", e);
            return true;
        }
    }

    /**
     * @param page
     * @return
     */
    private boolean checkSingleWebPageImpl(IWebPageUnit page) throws Exception {
        LOG.info("RBegin");
        /**
         * check ip
         */

        QueryCheckResult result = null;
        if (page.getIp() != 0) {
            result = addressRuleSet.check(page.getIp());
            if (result.getAction() == QueryCheckResult.Action.GREEN) {
                return true;
            }
            if (result != QueryCheckResult.NORMAL)
                return false;
        }
        /**
         * check url
         */

        result = urlRuleSet.check(page.getUrl());
        if (result.getAction() == QueryCheckResult.Action.GREEN) {// return
            // false;
            LOG.info("REND" + logDeliter + result.getAction() + logDeliter
                    + result.getRuleId() + logDeliter + page.getUrl());
            return true;
        } else if (result.getAction() == QueryCheckResult.Action.REJECT) {
            LOG.info("CBAND" + logDeliter + result.getAction() + logDeliter
                    + result.getRuleId() + logDeliter + page.getUrl()
                    + logDeliter + "url");
            return false;
        }

        /**
         * check title
         */
        if (page.getTitle() != null) {
            result = summaryKeyWordRuleSet
                    .check(new TextObject(page.getTitle()));
            if (result.getAction() == QueryCheckResult.Action.REJECT) {
                LOG.info("CBAND" + logDeliter + result.getAction() + logDeliter
                        + result.getRuleId() + logDeliter + page.getUrl()
                        + logDeliter + "Titile" + logDeliter + page.getTitle());
                return false;
            }
        }

        /**
         * check content
         */
        if (page.getContent() != null)
            result = summaryKeyWordRuleSet.check(new TextObject(page
                    .getContent()));
        if (result.getAction() == QueryCheckResult.Action.REJECT) {
            LOG.info("CBAND" + logDeliter + result.getAction() + logDeliter
                    + result.getRuleId() + logDeliter + page.getUrl()
                    + logDeliter + "Content" + logDeliter + page.getContent());
            return false;
        }
        LOG.info("REnd" + logDeliter + "NORMAL");
        return true;
    }

    @Override
    public QueryCheckResult checkText(TextObject text) {
        return summaryKeyWordRuleSet.check(text);
    }
}
