/**
 * @(#)FullQueryMatcher.java, 2007-5-30. Copyright 2007 Yodao, Inc. All rights
 *                            reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                            subject to license terms.
 */
package toolbox.cerberus.local;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import toolbox.cerberus.IKeyWordRuleSet;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.TextObject;
import toolbox.cerberus.local.config.BasicRule;
import toolbox.cerberus.local.config.ConfigData;
import toolbox.cerberus.local.config.ConfigRuleSet;
import toolbox.cerberus.util.TextStringUtil;
import toolbox.cerberus.wordcutter.BinaryCutWord;
import toolbox.cerberus.wordcutter.IWordCutter;
import toolbox.lang.TraditionToSimple;

/**
 * 检查用户查询是否和规则匹配
 * 
 * @author likui
 */
public class InputKeyWordRuleSet implements IKeyWordRuleSet {

    private List<BasicRule> list;

    private Map<String, List<Integer>> map;

    // terms after cut.
    private Map<String, List<Integer>> cutTermMap;

    private Map<String, Integer> exactMatchMap = new HashMap<String, Integer>();

    IWordCutter wordCutter = new BinaryCutWord();

    public QueryCheckResult check(TextObject text) {
        String checkText = text.getText();
        // 检查是否有匹配
        BasicRule result = checkQuery(checkText);
        if (result != null) {
            String urlSetId = result.getUrlSetId();
            if (urlSetId == null || urlSetId.equals(UrlSets.DEFAUlT_ID))
                return new QueryCheckResult(QueryCheckResult.Action.REJECT,
                        result.getId());
            else
                return new QueryCheckResult(QueryCheckResult.Action.IN_SET,
                        result.getId(), urlSetId);
        }

        return QueryCheckResult.NORMAL;
    }

    /**
     * 增加一条rule
     * 
     * @param rule
     */
    public void addRule(BasicRule rule) {
        list.add(rule);
        String[] contents = rule.getContents();
        String mode = rule.getMatchMode();
        // 默认是子串匹配
        boolean fullMatch = true;
        if (mode == null || mode.equals("") || mode.equals("1"))
            fullMatch = false;
        StringBuilder builder = null;
        /**
         * default: string match
         * "1":string match
         * "2":full match
         * "3":exact match
         */
        if ("3".equals(mode))
            builder = new StringBuilder();
        if (contents != null) {
            for (String content: contents) {
                // 繁简转换
                content = TraditionToSimple.convert(content.toLowerCase()
                        .trim());
                if (fullMatch) {// full match
                    if (mode.equals("3")) {
                        if (builder.length() > 0)
                            builder.append(" ");
                        builder.append(content);
                    } else {
                        if (map.containsKey(content)) {
                            List<Integer> indexList = map.get(content);
                            indexList.add(list.size() - 1);
                            map.put(content, indexList);
                        } else {
                            List<Integer> indexList = new ArrayList<Integer>();
                            indexList.add(list.size() - 1);
                            map.put(content, indexList);
                        }
                    }
                } else {// sub string match.
                    List<String> cutList = wordCutter.cutWord(content);
                    if (cutList != null) {
                        for (String term: cutList) {
                            if (cutTermMap.containsKey(term)) {
                                List<Integer> indexList = cutTermMap.get(term);
                                indexList.add(list.size() - 1);
                                cutTermMap.put(term, indexList);
                            } else {
                                List<Integer> indexList = new ArrayList<Integer>();
                                indexList.add(list.size() - 1);
                                cutTermMap.put(term, indexList);
                            }
                        }
                    }
                }
            }
            if ("3".equals(mode)) {
                exactMatchMap.put(builder.toString(), list.size() - 1);
            }
        }

    }

    /**
     * @param res
     * @return
     */
    private BasicRule checkCutMatch(String[] res) {
        if (res != null) {
            Set<Integer> cutIndexSet = new HashSet<Integer>();
            /**
             * find cut term match sets.
             */
            for (String item: res) {
                List<String> cutList = wordCutter.cutWord(item);
                if (cutList != null) {
                    for (String s: cutList)
                        if (cutTermMap.containsKey(s)) {
                            List<Integer> tmpList = cutTermMap.get(s);
                            for (Integer index: tmpList)
                                cutIndexSet.add(index);
                        }
                }
            }
            if (cutIndexSet.size() == 0)
                return null;
            Set<String> compareSet = new HashSet<String>();
            for (String s: res) {
                compareSet.add(s);
            }

            for (Integer index: cutIndexSet) {
                String[] contents = list.get(index).getContents();
                if (contents != null) {
                    if (isContains(compareSet, contents))
                        return list.get(index);
                }
            }
        }

        return null;
    }

    private BasicRule checkFullMatch(String[] res) {
        if (res != null) {
            Set<Integer> indexSet = new HashSet<Integer>();
            for (String s: res) {
                if (map.containsKey(s)) {
                    List<Integer> tmpList = map.get(s);
                    for (Integer index: tmpList)
                        indexSet.add(index);
                }
            }
            // 比较是否命中
            if (indexSet.size() == 0)
                return null;
            Set<String> compareSet = new HashSet<String>();
            for (String s: res) {
                compareSet.add(s);
            }

            for (Integer index: indexSet) {
                String[] contents = list.get(index).getContents();
                if (contents != null) {
                    if (isFullMatch(compareSet, contents)) {
                        return list.get(index);
                    }
                }
            }

        }
        return null;
    }

    BasicRule checkExactMatch(String query) {
        Integer index = exactMatchMap.get(query);
        if (index == null) {
            return null;
        }
        return list.get(index);
    }

    /**
     * 检查查询的状态
     * 
     * @param query
     * @return 返回命中的rule，不命中返回null
     */
    public BasicRule checkQuery(String query) {
        if (query != null) {
            //text繁简转换
            query = TraditionToSimple.convert(query.toLowerCase().trim());
            BasicRule rule = null;
            rule = checkExactMatch(query);
            if (rule != null) {
                return rule;
            }
            // 以空格分割查询
            String res[] = query.split("[  \t    ]");
            // res = normalizeQueryTerms(res);
            if (res != null) {
                // STEP 1:check full match first.
                rule = checkFullMatch(res);
                if (rule == null) {
                    // STEP 2: check sub string match.
                    rule = checkCutMatch(res);
                }
                return rule;
            }
        }
        return null;
    }

    /**
     * 对含英文单词的term进行合并，多个相连的英文单词算一个term。
     * 
     * @param terms
     * @return
     */
    String[] normalizeQueryTerms(String[] terms) {
        if (terms != null && terms.length > 0) {
            int count = 0;
            int emptyCount = 0;
            boolean flag = false;
            for (int i = 0; i < terms.length; i++) {
                if (terms[i].length() == 0) {
                    emptyCount++;
                    continue;
                }
                if (TextStringUtil.isEnglishOrNumStr(terms[i])) {
                    if (flag) {
                        count++;
                    } else
                        flag = true;
                } else {
                    if (flag) {
                        flag = false;
                    }
                }
            }
            if (count == 0) // no english term
                return terms;
            String[] newTerms = new String[terms.length - count - emptyCount];
            StringBuilder builder = new StringBuilder("");
            int index = 0;
            flag = false;
            for (int i = 0; i < terms.length; i++) {
                if (terms[i].length() == 0)
                    continue;
                if (TextStringUtil.isEnglishOrNumStr(terms[i])) {
                    if (flag) {
                        builder.append(" ");
                    } else
                        flag = true;
                    builder.append(terms[i]);
                } else {
                    if (flag) {
                        flag = false;
                        newTerms[index++] = builder.toString();
                        builder.delete(0, builder.length());
                    }
                    newTerms[index++] = terms[i];

                }
            }
            if (builder.length() > 0)
                newTerms[index] = builder.toString();
            return newTerms;
        }
        return null;
    }

    /**
     * 是否完全匹配or Exact Match
     * 
     * @param sets
     * @param contents
     * @return
     */
    private boolean isFullMatch(Set<String> sets, String[] contents) {
        if (sets.size() < contents.length)
            return false;
        int i = 0;
        for (; i < contents.length; i++) {
            if (!sets.contains(TraditionToSimple.convert(contents[i]
                    .toLowerCase())))
                break;
        }
        if (i == contents.length) {
            return true;
        }
        return false;
    }

    /**
     * check whether contains certain rule's contents.
     * 
     * @param sets
     * @param contents
     * @return
     */
    private boolean isContains(Set<String> sets, String[] contents) {
        // if (sets.size() < contents.length)
        // return false;
        int i = 0;
        for (; i < contents.length; i++) {
            String content = TraditionToSimple.convert(contents[i]
                    .toLowerCase());
            boolean match = false;
            Iterator<String> iter = sets.iterator();
            for (; iter.hasNext();) {
                String item = iter.next();
                if (item.contains(content))
                    match = true;
            }
            if (!match)
                return false;

        }
        if (i == contents.length)
            return true;
        return false;
    }

    public void init(ConfigRuleSet config, String product) {
        product = product.toLowerCase();
        list = new ArrayList<BasicRule>();
        map = new HashMap<String, List<Integer>>();
        cutTermMap = new HashMap<String, List<Integer>>();

        List<BasicRule> rules = config.getRules(product,
                ConfigData.RuleSet.INPUT_ID);
        if (rules != null) {
            for (BasicRule rule: rules) {
                addRule(rule);
            }
        }
    }
}
