package toolbox.cerberus;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import toolbox.cerberus.dummy.DummyQueryChecker;
import toolbox.cerberus.local.LocalQueryChecker;
import toolbox.cerberus.remote.RemoteQueryChecker;
import toolbox.misc.LogFormatter;
import toolbox.web.FileResource;
import toolbox.web.HttpResource;

/**
 * QueryChecker的创建管理器. QueryChecker本身是一个FileChangeListener，只有在被注册到指定的资源以后 通过
 * {@link #onFileChange(File)}的回调才能够load数据.
 *
 * @author river
 */
public class QueryCheckerFactory implements HttpResource.FileChangeListener {
    public static final String MODE_NAME = "mode";

    public static final Logger LOG = LogFormatter
            .getLogger(QueryCheckerFactory.class);

   /**
    * 工作方式:远程or本地
    */
    public static final int MODE_LOCAL = 0;

    public static final int MODE_REMOTE = 1;

    public static final String NAME_MODE_LOCAL = "local";

    public static final String NAME_MODE_REMOTE = "remote";
    /**
     * 监听配置的间隔时间，默认是30s
     */
    private int checkInterval = 30;

    private static final DummyQueryChecker DUMMY_CHECKER = DummyQueryChecker
            .getInstance();

    private int mode = MODE_LOCAL;

    private String product;

    private IQueryChecker queryChecker = DUMMY_CHECKER;

    private String confDir;

    private String remoteConfigUrl;

    /**
     * @return the confDir
     */
    public String getConfDir() {
        return confDir;
    }

    /**
     * @param confDir
     *            the confDir to set
     */
    public void setConfDir(String confDir) {
        this.confDir = confDir;
    }

    /**
     * @return the remoteConfigUrl
     */
    public String getRemoteConfigUrl() {
        return remoteConfigUrl;
    }

    /**
     * @param remoteConfigUrl
     *            the remoteConfigUrl to set
     */
    public void setRemoteConfigUrl(String remoteConfigUrl) {
        this.remoteConfigUrl = remoteConfigUrl;
    }

    public QueryCheckerFactory(String product) {
        this.product = product;
    }

    /**
     * 构造依赖于远程http配置文件的factory
     *
     * @param product
     *            产品名称
     * @param confDir
     *            配置文件本地目录
     * @param remoteConfigUrl
     *            远程配置文件地址
     */
    public QueryCheckerFactory(String product, String confDir,
            String remoteConfigUrl) {
        this.product = product;
        this.confDir = confDir;
        this.remoteConfigUrl = remoteConfigUrl;
        int interval = checkInterval * 1000;
        File confDirFile = new File(confDir);
        if(!confDirFile.exists()){
            boolean ret = confDirFile.mkdirs();
            if(!ret){
                LOG.warning("unable to make config dir:" + confDirFile.getAbsolutePath());
            }
        }
        HttpResource resource = new HttpResource(remoteConfigUrl, new File(
                confDirFile + "/local.xml"), interval);
        resource.registerListener(this);
    }

    /**
     * 构造依赖于File配置的factory
     * @param product
     * 产品名称
     * @param localConfigPath
     * 本地配置文件路径
     */
    public QueryCheckerFactory(String product, String localConfigPath) {
        this.product = product;
        int interval = 200;
        FileResource resource = new FileResource(new File(localConfigPath),
                interval);
        resource.registerListener(this);
    }

    /**
     * 返回当前的checker，这个方法直接返回目前生效的checker的实例，调用的开销很小. 在每次需要使用
     * QueryChecker以前调用这个方法，返回值并不需要缓存起来.
     *
     * @return
     */
    public IQueryChecker getChecker() {
        return queryChecker;
    }

    /**
     * 按照配置文件生成指定的query checker的实例，这个方法在 {@link #onFileChange(File)} 中被调用.
     * 也可以通过直接调用这个方法读取配置.
     *
     * @param product
     * @return
     */
    public synchronized void loadChecker(File file) throws IOException {
        DocumentBuilder builder;
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            LOG.log(Level.SEVERE, "initialize xml parser failed", e);
            throw new IOException("xml parser initialization failed");
        }

        Document document;
        try {
            document = builder.parse(file);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "parse xml file failed", e);
            throw new IOException("cannot parse xml file");
        }

        Element rootElement = document.getDocumentElement();
        Element modeElement = (Element) rootElement.getElementsByTagName(MODE_NAME).item(0);
        if (modeElement == null) {
            mode = MODE_LOCAL;
        } else {     
            mode = modeElement.getTextContent().toLowerCase().contains("remote") ? MODE_REMOTE
                    : MODE_LOCAL;
        }

        if (mode == MODE_LOCAL) {
            LocalQueryChecker checker = new LocalQueryChecker();
            //check whether local querychecker is updated succ. 
            boolean ret = checker.initialize(document, product.toLowerCase());
            if(ret){
                queryChecker = checker;
            }
            else {
                LOG.warning("Local querycheck update fail,then use the latest querychecker");
            }
        } else {
            RemoteQueryChecker remoteChecker = new RemoteQueryChecker();
            remoteChecker.initialize(document, product);
            queryChecker = remoteChecker;
        }
    }

    /**
     * 配置文件更新时候的回调函数.
     */
    public void onFileChange(File file) {
        try {
            loadChecker(file);
        } catch (IOException e) {
            LOG.log(Level.WARNING, "load configuration from config file "
                    + file.getAbsolutePath() + " failed", e);
        }
    }

    /**
     * @return the checkInterval
     */
    public int getCheckInterval() {
        return checkInterval;
    }

    /**
     * @param checkInterval the checkInterval to set
     */
    public void setCheckInterval(int checkInterval) {
        this.checkInterval = checkInterval;
    }

}
