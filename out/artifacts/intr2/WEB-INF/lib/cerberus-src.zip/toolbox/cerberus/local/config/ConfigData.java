package toolbox.cerberus.local.config;

/**
 * 指定xml规则配置文件的读取格式 *
 * 
 * @author likui
 */
public class ConfigData {
    // 规则集合的类别属性
    public final static String ID = "id";

    /**
     * 规则集类别名称 在配置文件中唯一标识规则集的类别
     * 
     * @author likui
     */
    public static class RuleSet {
        public final static String WHITEIP_ID = "whiteips";// ip白名单规则集

        public final static String BLACKIP_ID = "blackips";// ip黑名单

        public final static String WHITEURL_ID = "whiteurls";// 结果过滤url白名单

        public final static String BLACKURL_ID = "blackurls";// 结果过滤url黑名单

        public final static String INPUT_ID = "input";// 禁止查询关键字规则集

        public final static String OUTPUT_ID = "output";// 结果过滤关键字规则集

        public final static String URLSET_ID = "urlsets";// url白名单
    }

    /**
     * 配置文件中的元素名称
     * 
     * @author likui xml sample:
     *         <LI> <config> <ruleset> <rule> <content></content> </rule>
     *         </ruleset> </config> </LI>
     */
    public static class TagName {
        // 根元素
        public final static String ROOT = "config";

        // 规则集
        public final static String RULESET = "ruleset";

        // 规则
        public final static String RULE = "rule";

        // 规则的具体内容
        public final static String CONTENT = "content";

        //工作模式
        public final static String MODE = "mode";

        //配置的版本号
        public final static String VERSION = "version";

        public static final String LOG_SEARCH = "log_search";

        public static final String LOG_DIGEST = "log_digest";

        public static final String LOG_MATCH = "log_match";
        /**
         * 是否支持ip站内搜索
         */
        public static final String IP_INSET = "ip_whiteurl";
        /**
         * 是否支持禁查关键字站内搜索
         */
        public static final String INPUT_INSET = "input_whiteurl";
        
        public static final String KEYWORD_URL = "keywordUrl";

        public static final String RESULT_URL = "resultUrl";

        public static final String ENGINE_ID = "engineId";

    }

    /**
     * 规则适用的产品类型名称
     * 
     * @author likui
     */
    public static class ProductType {
        public final static String WEB = "WEB";

        public final static String IMG = "IMG";

        public final static String BLOG = "BLOG";
        
        public final static String PRODUCTS = "web:blog:image:news:music:dict:video:rts:wiki:webfanyi:all";
        
//        public final static String PRODUCTS = "dict:all";

    }

    /**
     * 基本规则的属性名称
     * 
     * @author likui
     */
    public static class Rule {
        // 唯一标该规则
        public final static String ID = "id";

        // 白名单集合ID
        public final static String URLSETID = "urlset_id";

        // 规则的匹配模式
        public final static String MODE = "mode";

        // 规则的类型:not used now.
        public final static String TYPE = "type";

        // 规则使用的产品类型
        public final static String PRODUCTS = "products";

        // 规则使用的产品类型
        public final static String NAME = "name";

        // 规则来源:区别规则来自远程或本地。默认(空)是本地
        public final static String SOURCE = "source";
    }

    /**
     * url白名单规则的属性名称
     * 
     * @author likui
     */
    public static class UrlSetRule {
        public final static String ID = "id";

        public final static String NAME = "name";

        public final static String SOURCE = "source";
    }

    public static class MatchMode {
        public final static String SUBMATCH = "1";

        public final static String OTHERMATCH = "2";
    }

}
