package toolbox.cerberus;

/**
 * 针对url的过滤规则.
 * @author river
 */
public interface IUrlRuleSet {
    
    /**
     * 过滤url.
     * @param url
     * @return
     */
    public QueryCheckResult check(String url);
    
    public UrlSet getBlackUrlSet();
}
