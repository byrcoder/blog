/**
 * @(#)UrlSets.java, 2007-5-14. Copyright 2007 Yodao, Inc. All rights reserved.
 *                   YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license
 *                   terms.
 */
package toolbox.cerberus.local;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import toolbox.cerberus.UrlSet;
import toolbox.cerberus.local.config.ConfigRuleSet;
import toolbox.cerberus.local.config.UrlSetRule;

/**
 * UrlSet的集合，定义多个UrlSet.
 * 
 * @author river,likui
 */
public class UrlSets {

    public static String DEFAUlT_ID = "none";

    private Map<String, UrlSet> sets = new HashMap<String, UrlSet>();

    public void addUrlSet(String id, UrlSet set) {
        sets.put(id, set);
    }

    public UrlSet getUrlSet(String id) {
        if(sets.containsKey(id))
            return sets.get(id);
        return null;
    }

    public void init(ConfigRuleSet config) {
        List<UrlSetRule> rules = config.getUrlSetRules();
        if (rules != null) {
            for (UrlSetRule rule: rules) {
                String ruleId = rule.getId();
                String[] urls = rule.getUrls();
                if (urls != null) {
                    UrlSet urlSet = new UrlSet(urls);
                    sets.put(ruleId, urlSet);
                }
            }
        }
    }

}
