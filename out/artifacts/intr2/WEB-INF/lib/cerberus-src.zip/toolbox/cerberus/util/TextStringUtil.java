package toolbox.cerberus.util;

import java.util.HashSet;
import java.util.Set;

/**
 * Text Word Tools,for tolower case string.
 * @author likui
 *
 */
public class TextStringUtil {
	public static boolean isEnglishOrNumChar(char c) {
		if (('a' <= c && 'z' >= c) || ('0' <= c && '9' >= 'c')) {
			return true;
		}
		return false;
	}

	public static boolean isEnglishChar(char c) {
		if (('a' <= c && 'z' >= c)) {
			return true;
		}
		return false;
	}
	
	public static boolean isEnglishOrNumStr(String str) {
		if (str != null && str.length() > 0) {
			for (int index = 0; index < str.length(); index++) {
				if (!isEnglishOrNumChar(str.charAt(index))) {
					return false;
				}
			}
			return true;
		}
		return false;
	}
	
	public static boolean isEnglishTerm(String str) {
		if (str != null && str.length() > 0) {
			for (int index = 0; index < str.length(); index++) {
				if (!isEnglishOrNumChar(str.charAt(index)) && str.charAt(index) != ' ') {
					return false;
				}
			}
			return true;
		}
		return false;
	}
	
	public static boolean isEnglishCharBeginOrEnd(String str){
		if (str != null && str.length() > 0) {
			if(isEnglishOrNumChar(str.charAt(0)) || isEnglishOrNumChar(str.charAt(str.length() -1)))
				return true;
		}
		return false;
	}
	
	public static String normalizeEnglishTerm(String term){
		if(term != null){
			term = term.trim();
			String[] ret = term.split(" ");
			if(ret == null || ret.length == 0)
			if(ret.length == 1)
				return term;
			StringBuilder s = new StringBuilder("");
			s.append(ret[0]);
			for(int i = 1 ; i < ret.length ;i++){
				s.append(" ");
				s.append(ret[i]);
			}
			return s.toString();
		}
		return null;
	}
	
	 
	// 需要处理的特殊字符：用于搜索结果的过滤
	private static String specialChars = "-~!@#$%^&*()_+?.,:><=;：'！@#￥%……&*—+，。、‘”\"\t\r\n";

	public static  String removeSpecialChars(String s){
		if(s == null)
			return null;
		StringBuilder builder = new StringBuilder("");
		String[] res = s.split("[" + specialChars + "]");
		if (res != null) {
			for (String elem : res)
				builder.append(elem);
		}
		return builder.toString();
	}

	/**
	 * get english or num terms in hashset form.
	 * 
	 * @param text
	 * @return
	 */
	public static Set<String> getEnglishOrNumTerm(String text) {
		if (text != null && text.length() > 0) {
			Set<String> list = new HashSet<String>(10);
			int begin = 0;
			boolean flag = false;
			for (int index = 0; index < text.length(); index++) {
			    if (isEnglishOrNumChar(text.charAt(index))) {// if english
			        // char
			        if (!flag) {// english word begin
			            begin = index;
			            flag = true;
			        }
			    } else {
			        if (flag) {// english word end
			            list.add(text.substring(begin, index));
			            flag = false;
			        }
			    }
			}

			/**
			 * if forget the last word, with rule 
			 * "天安门广场 tianmanmen square" will not apply for the 
			 * text "天安门广场 tianmanmen square"
			 * shenli 2012-05-14 fix this bug
			 */
			if (flag) {
                            list.add(text.substring(begin, text.length()));
                        }
			
			if (list.size() > 0) {
			    return list;
			}
		}

		return null;
	}
	
	public static boolean isEuqalInEnglishStr(String kw, String content) {
		if (kw != null && content != null && kw.length() > 0
				&& content.length() > 0) {
			int pos = 0;
			while ((pos = content.indexOf(kw, pos)) != -1) {
				if (pos > 0) {
					if (isEnglishOrNumChar(content.charAt(pos - 1))) {
						pos += kw.length();
						continue;
					}
				}
				if (pos + kw.length() < content.length() - 1) {
					if (isEnglishOrNumChar(content.charAt(pos + kw.length()))) {
						pos += kw.length();
						continue;
					}
				}
				return true;

			}
		}
		return false;
	}
	
    /*
     * 去掉多余的空格，将全角半角全装换成一个半角空格
     */
    public static String removeMoreSpaceQuery(String str) {
        if (str == null)
            return null;
        return str.replaceAll("(\\s|　)+", " ");
    }

    public static String normalizerQuery(String str) {
        if (str == null) {
            return null;
        }
        str = removeMoreSpaceQuery(str);
        str = str.trim();
        return str;
    }
}
