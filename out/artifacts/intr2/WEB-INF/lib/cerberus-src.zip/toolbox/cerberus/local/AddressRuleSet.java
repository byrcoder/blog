package toolbox.cerberus.local;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

import toolbox.cerberus.IAddressRuleSet;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.local.config.BasicRule;
import toolbox.cerberus.local.config.ConfigData;
import toolbox.cerberus.local.config.ConfigRuleSet;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.IpUtils;

/**
 * 基于ip的规则集合.
 * 
 * @author likui
 */
public class AddressRuleSet implements IAddressRuleSet {

    static int NOTFOUND = -1;

    private String product;

    public static String deliter = ":";
    
    public static final Logger LOG = LogFormatter
    .getLogger(AddressRuleSet.class);

    /**
     * IP段.
     * 
     * @author likui
     */
    public static class IpSection {
        int begin;

        int end;

        String ruleId;

        // url-set level,if not "0",search shoule be done in level-url set.
        String urlSetId;

        public static final Comparator<IpSection> COMPARATOR = new Comparator<IpSection>() {
            public int compare(IpSection first, IpSection second) {
                return ((Integer) first.begin).compareTo(second.begin);
            }
        };

        public int getBegin() {
            return begin;
        }

        public void setBegin(int begin) {
            this.begin = begin;
        }

        public int getEnd() {
            return end;
        }

        public void setEnd(int end) {
            this.end = end;
        }

        public String getRuleId() {
            return ruleId;
        }

        public void setRuleId(String ruleId) {
            this.ruleId = ruleId;
        }

        public String getUrlSetId() {
            return urlSetId;
        }

        public void setUrlSetId(String urlSetId) {
            this.urlSetId = urlSetId;
        }

    }

    public QueryCheckResult check(int ip) {

        // 先检查是否是在白名单中
        int ret = isHit(ip, whiteList);
        if (ret != NOTFOUND) {
            String ruleId = whiteList.get(ret).getRuleId();
            return new QueryCheckResult(QueryCheckResult.Action.GREEN, ruleId);
        }

        // 再检查是否在黑名单中
        ret = isHit(ip, blackList);
        if (ret != NOTFOUND) {
            String ruleId = blackList.get(ret).getRuleId();
            String urlSetId = blackList.get(ret).getUrlSetId();
            if (urlSetId.equals(UrlSets.DEFAUlT_ID))
                return new QueryCheckResult(QueryCheckResult.Action.REJECT,
                        ruleId);
            else
                return new QueryCheckResult(QueryCheckResult.Action.IN_SET,
                        ruleId, urlSetId);
        }

        // 返回预定义的默认返回值
        return QueryCheckResult.NORMAL;
    }

    private List<IpSection> blackList;

    private List<IpSection> whiteList;

    /**
     * @param ip
     * @param section
     * @return
     */
    int compare(int ip, IpSection section) {
        int begin = section.getBegin();
        if (ip == begin)
            return 0;
        int end = section.getEnd();
        if (begin > 0 && end < 0) {// cross
            if (ip > begin)
                return 0;
            if (ip <= end)
                return 0;
            return -1;
        }
        if (ip > begin && ip <= end)
            return 0;
        if (ip < begin)
            return -1;
        return 1;
    }

    /**
     * @param ip
     * @param list
     * @return
     */
    private int isHit(int ip, List<IpSection> list) {
        if (list == null || list.size() == 0)
            return NOTFOUND;
        int begin = 0;
        int end = list.size() - 1;
        int mid = 0;
        for (; begin <= end;) {
            mid = (begin + end) / 2;
            IpSection section = list.get(mid);
            int ret = compare(ip, section);
            if (ret == 0) {
                return mid;
            } else if (ret < 0)
                end = mid - 1;
            else
                begin = mid + 1;
        }
        if (mid == 0 && ip < 0) {
            int ret = compare(ip, list.get(list.size() - 1));
            if (ret == 0)
                return list.size() - 1;
        }
        return NOTFOUND;
    }

    /**
     * 初始化对于ip的配置.
     * 
     * @param config
     */
    public void init(ConfigRuleSet config, String product) {
        product = product.toLowerCase();
        this.product = product;
        whiteList = new ArrayList<IpSection>();
        blackList = new ArrayList<IpSection>();
        List<BasicRule> whiteIpRules = config.getRules(product,
                ConfigData.RuleSet.WHITEIP_ID);
        if (whiteIpRules != null) {
            for (BasicRule rule: whiteIpRules) {
                addRule(rule, whiteList);
            }
            Collections.sort(whiteList, IpSection.COMPARATOR);
        }
        List<BasicRule> blackIpRules = config.getRules(product,
                ConfigData.RuleSet.BLACKIP_ID);
        if (blackIpRules != null) {
            for (BasicRule rule: blackIpRules) {
                addRule(rule, blackList);
            }
            Collections.sort(blackList, IpSection.COMPARATOR);
        }
    }

    public static void addRule(BasicRule rule, List<IpSection> list) {
        String ruleId = rule.getId();
        String urlSetId = rule.getUrlSetId();
        String[] contents = rule.getContents();
        if (contents != null && contents.length > 0) {
            for (String content: contents) {
                String[] ret = content.split(deliter);
                if (ret != null && ret.length == 2) {
                    try {
                        int begin = IpUtils.parseIp(ret[0]);
                        int end = IpUtils.parseIp(ret[1]);
                        IpSection section = new IpSection();
                        section.setBegin(begin);
                        section.setEnd(end);
                        section.setRuleId(ruleId);
                        section.setUrlSetId(urlSetId);
                        list.add(section);
                    } catch (ParseException e) {
                    	LOG.warning("Parser IP Exception," + e.getMessage());
                    }
                }
            }
        }
    }

    public String getProduct() {
        return product;
    }
}
