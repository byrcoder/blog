/**
 * @(#)IQueryInfo.java, 2007-5-18. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus;

/**
 * 查询相关数据的接口，应用可以实现自己的数据结构，也可以采用这里提供的最简单的实现.
 * @see QueryInfo
 * @author river
 *
 */
public interface IQueryInfo {

    /**
     * 返回用户输入的查询.
     * @return
     */
    public String getQuery(); 
    
    /**
     * 返回用户的ip.
     * @return
     */
    public int getIp();
    
}
