package toolbox.cerberus.remote;

import java.util.logging.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import toolbox.cerberus.IQueryChecker;
import toolbox.cerberus.IQueryInfo;
import toolbox.cerberus.IResultInfo;
import toolbox.cerberus.ISingleResultUnit;
import toolbox.cerberus.IWebPageUnit;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.TextObject;
import toolbox.cerberus.UrlSet;
import toolbox.misc.LogFormatter;

/**
 * 远程的QueryChecker的实现，所有的查询都必须送到远程的服务器上进行检查.
 * 
 * @author river
 */
public class RemoteQueryChecker implements IQueryChecker {

    public static final Logger LOG = LogFormatter.getLogger(RemoteQueryChecker.class);

    private ResultCaller resultCaller;

    private RequestCaller requestCaller;

    /**
     * TODO: not implemented
     * 
     * @param config
     * @param product
     */
    public void initialize(Document document, String product) {
        resultCaller = new ResultCaller();
        requestCaller = new RequestCaller();

        //TODO:need specify remote url for request.
        Element rootElem = document.getDocumentElement();
        requestCaller.setRequestUrl(getRootAttrValue(rootElem, "keywordUrl"));
        resultCaller.setRequestUrl(getRootAttrValue(rootElem, "resultUrl"));
        LOG.info("keyword url is:" + requestCaller.getRequestUrl());
        LOG.info("result url is:" + resultCaller.getRequestUrl());
        String engineId = getRootAttrValue(rootElem, "engineId");
        if (engineId != null) {
            requestCaller.setEngineId(engineId);
            resultCaller.setEngineId(engineId);
        }
        requestCaller.setSearchType(product);
        resultCaller.setSearchType(product);

    }

    /**
     * get Root Elem 'text child content
     * 
     * @param rootElem
     * @param tagName
     * @return
     */
    String getRootAttrValue(Element rootElem, String tagName) {
        NodeList nodeList = rootElem.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            return ((Element) nodeList.item(0)).getTextContent();
        }
        return null;

    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IQueryChecker#checkQuery(toolbox.cerberus.QueryInfo)
     */
    public QueryCheckResult checkQuery(IQueryInfo query) {
        return requestCaller.checkReuslt(query);
    }

    public void filterResult(IQueryInfo query,
            QueryCheckResult queryCheckResult, IResultInfo result) {
        if (queryCheckResult.getAction() == QueryCheckResult.Action.GREEN) {
            result.setAllPassed(true);

        }
        resultCaller.filterResult(query, result);
    }

    public UrlSet getUrlSet(String setId) {
        return null;
    }

    public UrlSet getBlackUrlSet() {
        return null;
    }

    /**
     * @return the requestCaller
     */
    public RequestCaller getRequestCaller() {
        return requestCaller;
    }

    /**
     * @param requestCaller
     *            the requestCaller to set
     */
    public void setRequestCaller(RequestCaller requestCaller) {
        this.requestCaller = requestCaller;
    }

    /**
     * @return the resultCaller
     */
    public ResultCaller getResultCaller() {
        return resultCaller;
    }

    /**
     * @param resultCaller
     *            the resultCaller to set
     */
    public void setResultCaller(ResultCaller resultCaller) {
        this.resultCaller = resultCaller;
    }

    public boolean checkSingleResult(ISingleResultUnit single) {
        // TODO Auto-generated method stub
        return true;
    }

    public boolean checkSingleWebPage(IWebPageUnit page) {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public QueryCheckResult checkText(TextObject text) {
        // TODO Auto-generated method stub
        return null;
    }
}
