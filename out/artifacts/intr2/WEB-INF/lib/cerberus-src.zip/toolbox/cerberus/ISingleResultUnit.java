/**
 * @(#)ISingleResult.java, Jul 6, 2007. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus;

/**
 *
 * @author likui
 *
 */
public interface ISingleResultUnit {
	public String getUrl();
	public String getTitle();
	public String getDiggest();

}
