/**
 * @(#)CerberusException.java, 2009-2-18. Copyright 2009 Yodao, Inc. All rights
 *                             reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                             subject to license terms.
 */
package toolbox.cerberus.advance;

/**
 * @author blueboat
 */
public class CerberusException extends Exception {
    
    private static final long serialVersionUID = -7203064820329901496L;

    public CerberusException() {
        super();
    }

    public CerberusException(String message) {
        super(message);
    }

    public CerberusException(String message, Throwable cause) {
        super(message, cause);
    }

    public CerberusException(Throwable cause) {
        super(cause);
    }
}
