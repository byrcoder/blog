package toolbox.cerberus.dummy;

import toolbox.cerberus.IQueryChecker;
import toolbox.cerberus.IQueryInfo;
import toolbox.cerberus.IResultInfo;
import toolbox.cerberus.ISingleResultUnit;
import toolbox.cerberus.IWebPageUnit;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.TextObject;
import toolbox.cerberus.UrlSet;
import toolbox.misc.EmptyInstance;

/**
 * 空的QueryChecker的实现，这个是一个singleton.
 * 
 * @author river
 */
public class DummyQueryChecker implements IQueryChecker {
    private static final UrlSet EMPTY_SET = new UrlSet(EmptyInstance.STRINGS);

    private static final DummyQueryChecker instance = new DummyQueryChecker();

    /* (non-Javadoc)
     * @see toolbox.cerberus.IQueryChecker#filterResult(toolbox.cerberus.QueryInfo, toolbox.cerberus.QueryCheckResult, toolbox.cerberus.ResultInfo)
     */
    public void filterResult(IQueryInfo query,
            QueryCheckResult queryCheckResult, IResultInfo result) {
        result.setAllPassed(true);
    }

    /* 直接返回NORMAL.
     * @see toolbox.cerberus.IQueryChecker#checkQuery(toolbox.cerberus.QueryInfo)
     */
    public QueryCheckResult checkQuery(IQueryInfo query) {
        return QueryCheckResult.NORMAL;
    }

    /**
     * 保证这个是一个singleton实现.
     */
    private DummyQueryChecker() {}

    /**
     * 返回实例.
     * 
     * @return
     */
    public static DummyQueryChecker getInstance() {
        return instance;
    }

    /**
     * 返回一个空的urlset.
     */
    public UrlSet getUrlSet(String setId) {
        return EMPTY_SET;
    }

    public UrlSet getBlackUrlSet() {
        return EMPTY_SET;
    }

    public boolean checkSingleResult(ISingleResultUnit single) {
        return true;
    }

    public boolean checkSingleWebPage(IWebPageUnit page) {
        return true;
    }

    @Override
    public QueryCheckResult checkText(TextObject text) {
        return QueryCheckResult.NORMAL;
    }

}
