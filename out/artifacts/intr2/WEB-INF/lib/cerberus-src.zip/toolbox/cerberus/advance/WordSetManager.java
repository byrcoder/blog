/**
 * @(#)WordSetManager.java, 2009-2-18. Copyright 2009 Yodao, Inc. All rights
 *                          reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                          subject to license terms.
 */
package toolbox.cerberus.advance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import toolbox.cerberus.matcher.MultiRuleMatcher;
import toolbox.misc.LogFormatter;

/**
 * @author blueboat
 */
public class WordSetManager {

    public static final Logger LOG = LogFormatter
            .getLogger(WordSetManager.class);

    private String baseUrl;

    private List<String> wordFileList;

    private List<String> charFileList;

    private List<ForbiddenWordSet> wordSetList;

    private List<ForbiddenWordSet> charSetList;

    public final static char STAR = '*';

    public WordSetManager() {
        wordFileList = new ArrayList<String>();
        charFileList = new ArrayList<String>();
        wordSetList = new ArrayList<ForbiddenWordSet>();
        charSetList = new ArrayList<ForbiddenWordSet>();
    }

    public void init() {
        for (String fileName: wordFileList) {
            ForbiddenWordSet wordSet = new ForbiddenWordSet();
            wordSet.setBaseUrl(baseUrl);
            wordSet.setFileName(fileName);
            wordSet.setCharFormat(false);
            wordSet.init();
            wordSetList.add(wordSet);
        }

        for (String fileName: charFileList) {
            ForbiddenWordSet wordSet = new ForbiddenWordSet();
            wordSet.setBaseUrl(baseUrl);
            wordSet.setFileName(fileName);
            wordSet.setCharFormat(true);
            wordSet.init();
            charSetList.add(wordSet);
        }
    }

    private Set<String> unionSet(List<String> nameList, boolean charFormat) {
        Set<String> resultSet = new HashSet<String>();
        List<ForbiddenWordSet> setList = null;
        if (charFormat)
            setList = charSetList;
        else
            setList = wordSetList;
        for (ForbiddenWordSet wordSet: setList) {
            if (nameList.contains(wordSet.getFileName())
                    && wordSet.isCharFormat() == charFormat) {
                resultSet.addAll(wordSet.getWordSet());
            }
        }
        return resultSet;
    }

    /**
     * 检查str是否包含nameList中的文件内的封禁词， MatchType.EQUAL表示相等匹配，MatchType.SUB表示子串匹配
     * 
     * @param str
     * @param nameList
     * @param type
     * @return
     */
    public boolean check(String str, List<String> nameList, MatchType type) {
        if (str == null)
            return false;
        Set<String> resultSet = unionSet(nameList, false);
        str = str.trim().toLowerCase();
        switch (type) {
            case EQUAL:
                return checkByEqual(str, resultSet);
            case SUB:
                return checkBySub(str, resultSet);
            default:
                return false;
        }
    }

    private boolean checkByEqual(String str, Set<String> wordSet) {
        return wordSet.contains(str);
    }

    private boolean checkBySub(String str, Set<String> wordSet) {
        MultiRuleMatcher mrm = new MultiRuleMatcher();
        String[] result;
        mrm.setRuleStringSets(wordSet);
        if (mrm.init()) {
            result = mrm.getMatchedRules(str);
            if (result != null && result.length != 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 检查str,如果包含nameList中的文件内的封禁词， 则将封禁词用*组成的字符串代替，*个数和词的长度相等
     * 
     * @param str
     * @param nameList
     * @return
     */
    public String replace(String str, List<String> nameList) {
        return replace(str, nameList, STAR);
    }

    /**
     * 检查str,如果包含nameList中的文件内的封禁词， 则将封禁词用ch组成的字符串代替，ch个数和词的长度相等
     * 
     * @param str
     * @param nameList
     * @param ch
     * @return
     */
    public String replace(String str, List<String> nameList, char ch) {
        if (str == null)
            return "";
        Set<String> resultSet = unionSet(nameList, false);
        MultiRuleMatcher mrm = new MultiRuleMatcher();
        String[] result;
        mrm.setRuleStringSets(resultSet);
        if (mrm.init()) {
            result = mrm.getMatchedRules(str.toLowerCase());
            if (result != null && result.length != 0) {
                for (String rword: result) {
                    str = str.replaceAll("(?i)" + rword, repeatChar(ch, rword
                            .length()));
                }
            }
        }
        return str;
    }

    /**
     * 检查str是否包含nameList中的文件内的封禁单字， MatchType.EQUAL表示相等匹配，MatchType.SUB表示子串匹配
     * 
     * @param str
     * @param nameList
     * @param type
     * @return
     */
    public boolean checkChar(String str, List<String> nameList, MatchType type) {
        if (str == null)
            return false;
        Set<String> resultSet = unionSet(nameList, true);
        str = str.trim();
        switch (type) {
            case EQUAL:
                return checkByEqual(str, resultSet);
            case SUB:
                return checkCharBySub(str, resultSet);
            default:
                return false;
        }
    }

    private boolean checkCharBySub(String str, Set<String> wordSet) {
        for (String word: wordSet) {
            if (str.indexOf(word) > -1)
                return true;
        }
        return false;
    }

    /**
     * 检查str,如果包含nameList中的文件内的封禁单字， 则将封禁字用*代替
     * 
     * @param str
     * @param nameList
     * @return
     */
    public String replaceChar(String str, List<String> nameList) {
        return replaceChar(str, nameList, STAR);
    }

    /**
     * 检查str,如果包含nameList中的文件内的封禁单字， 则将封禁字用ch代替
     * 
     * @param str
     * @param nameList
     * @param ch
     * @return
     */
    public String replaceChar(String str, List<String> nameList, char ch) {
        if (str == null)
            return "";
        Set<String> resultSet = unionSet(nameList, true);
        for (String word: resultSet) {
            str.replaceAll(word, String.valueOf(ch));
        }
        return str;
    }

    private String repeatChar(char ch, int num) {
        String mosaic = String.valueOf(ch);
        if (num >= 2) {
            for (int i = 1; i < num; i++)
                mosaic += ch;
        }
        return mosaic;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public List<String> getWordFileList() {
        return Collections.unmodifiableList(wordFileList);
    }

    public void setWordFileList(List<String> wordFileList) {
        this.wordFileList = wordFileList;
    }

    public List<String> getCharFileList() {
        return Collections.unmodifiableList(charFileList);
    }

    public void setCharFileList(List<String> charFileList) {
        this.charFileList = charFileList;
    }

    public List<ForbiddenWordSet> getWordSetList() {
        return Collections.unmodifiableList(wordSetList);
    }

    public void setWordSetList(List<ForbiddenWordSet> wordSetList) {
        this.wordSetList = wordSetList;
    }

    public List<ForbiddenWordSet> getCharSetList() {
        return Collections.unmodifiableList(charSetList);
    }

    public void setCharSetList(List<ForbiddenWordSet> charSetList) {
        this.charSetList = charSetList;
    }
}
