/**
 * @(#)IWebPageUnit.java, 2007-9-11. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus;

/**
 *网页内容接口：包含检查网页内容需要的信息
 * @author likui
 *
 */
public interface IWebPageUnit {
    
    public int getIp();
    /**
     * 返回网页的URL
     * @return
     */
    public String getUrl();
    /**
     * 返回网页的标题
     * @return
     */
    public String getTitle();
    
    /**
     * 返回网页的文本内容
     * @return
     */
    public String getContent();
    
    
}
