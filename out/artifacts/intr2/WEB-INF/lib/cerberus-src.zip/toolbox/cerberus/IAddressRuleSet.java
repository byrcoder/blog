package toolbox.cerberus;

/**
 * 针对ip的过滤规则.
 * @author river
 */
public interface IAddressRuleSet {

    /**
     * 对指定的ip进行过滤，并且返回过滤的结果.
     * @param ip
     * @return
     */
    public QueryCheckResult check(int ip);
    
}
