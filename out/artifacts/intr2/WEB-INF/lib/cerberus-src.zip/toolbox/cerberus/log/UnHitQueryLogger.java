/**
 * @(#)UnHitQueryLogger.java, 2007-6-28. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.log;

import org.apache.log4j.Logger;

/**
 *记载未命中查询日志的logger
 * @author likui
 *
 */
public class UnHitQueryLogger {
    static Logger LOG = Logger.getLogger(UnHitQueryLogger.class);
    /**
     * 保存一条记录
     * @param unit
     */
    public static void logRecord(LogUnit unit) {
        if(unit.isLogFlag())
            LOG.debug(unit.toString());
    }
}
