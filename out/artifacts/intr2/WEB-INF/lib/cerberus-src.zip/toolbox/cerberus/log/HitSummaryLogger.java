/**
 * @(#)HitSummaryLogger.java, 2007-6-28. Copyright 2007 Yodao, Inc. All rights
 *                            reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                            subject to license terms.
 */
package toolbox.cerberus.log;

import org.apache.log4j.Logger;

/**
 * 记录Smmary命中日志
 * 
 * @author likui
 */
public class HitSummaryLogger {
    static Logger LOG = Logger.getLogger(HitSummaryLogger.class);

    public static void logRecord(LogUnit unit) {
        if(unit.isLogFlag())
            LOG.debug(unit.toString());
    }
}
