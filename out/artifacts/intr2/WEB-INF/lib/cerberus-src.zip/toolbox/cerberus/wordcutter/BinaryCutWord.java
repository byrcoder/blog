package toolbox.cerberus.wordcutter;

import java.util.ArrayList;
import java.util.List;

/**
 * 对词语进行二元切分的实现类
 * 
 * @author likui
 */
public class BinaryCutWord implements IWordCutter {

    private int minCutLength = 2;

    /**
     * 实现切分接口，采用二元切分，即每条词语被切成多个二元词组 只切分长度大于2的词
     * 
     * @param word:
     *            被切分的词语
     * @return 切分结果，字符串list
     */
    public List<String> cutWord(String word) {
        assert word != null;

        if (word.length() < minCutLength)
            return null;

        boolean isBegin = false;
        String englishWord = "";
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < word.length(); i++) {
            if (isEnglishChar(word.charAt(i))) {
                if (!isBegin) {
                    englishWord = "";
                    isBegin = true;
                }
                englishWord += word.charAt(i); // 抽取其中的英文单词，不切分
                continue;
            }
            if (word.charAt(i) == ' ') {
                if (englishWord.length() != 0)
                    list.add(englishWord);
                isBegin = false;
                continue;
            }
            // english char end.
            if (isBegin) {
                if (englishWord.length() == 1) {
                    list.add(englishWord.toLowerCase() + word.charAt(i));
                } else {
                    list.add(englishWord.toLowerCase());
                }
            }
            String elem = getElement(word, i, 2);
            if (elem != null) {
                list.add(elem);
            }
            isBegin = false;
        }
        if (isBegin && englishWord.length() > 1)
            list.add(englishWord.toLowerCase());
        adjustCutResult(list);
        return removeDupInList(list);
    }

    private List<String> removeDupInList(List<String> list) {
        if (list == null || list.size() == 0)
            return null;
        List<String> resultList = new ArrayList<String>();
        for (String s: list) {
            if (!resultList.contains(s))
                resultList.add(s);
        }
        return resultList;
    }

    boolean isEnglishChar(char c) {
        return ((c <= 'z' && c >= 'a') || (c <= 'Z' && c >= 'A') || (c >= '0' && c <= '9'));
    }

    boolean containsNoChars(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (isEnglishChar(s.charAt(i)))
                return false;
        }
        return true;
    }

    String getElement(String s, int start, int len) {
        String res = "";
        for (int i = start; i < start + len && i < s.length(); i++) {
                res += s.charAt(i);
            // else
            // break;
        }
        if (res.length() > 1)
            return res;
        else
            return null;
    }

    public int getMinCutLength() {
        return minCutLength;
    }

    public void setMinCutLenth(int minCutLenth) {
        this.minCutLength = minCutLenth;
    }

    /**
     * 切分碎片合成
     * 
     * @param list
     */
    public void adjustCutResult(List<String> list) {
        assert list != null;
        int len = list.size();
        if (len <= 1)
            return;
        for (int i = 0; i < len; i++) {
            if (i == len - 1) {
                list.add(list.get(i));
                break;
            }
            if (list.get(i).length() == 1 && list.get(i + 1).length() == 1) {
                list.add(list.get(i) + list.get(i + 1));
                i++;
            } else {
                list.add(list.get(i));
            }
        }
        for (int i = 0; i < len; i++) {
            list.remove(0);
        }
    }

    public static void main(String[] args) {

        testCut("tvb美女");
        testCut("中华人民共和国");
        testCut("excite中译日中译意义已一一一意义");
        testCut("傻bc洗澡");
        testCut("A片a图b");
        testCut("make love what and傻bc");
        testCut("david");
        testCut("josie maranyinren");

    }

    static void testCut(String word) {
        BinaryCutWord cut = new BinaryCutWord();
        List<String> list;
        list = cut.cutWord(word);
        for (String result: list) {
            System.out.print(" " + result);
        }
        System.out.println("");
    }
}
