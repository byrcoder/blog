/**
 * @(#)SingleResultUnit.java, Jul 6, 2007. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus;

/**
 *Single Result Unit
 * @author likui
 *
 */
public class SingleResultUnit implements ISingleResultUnit {
	
	String title;
	String url;
	String diggest;

	/* (non-Javadoc)
	 * @see toolbox.cerberus.ISingleResultUnit#getDiggest()
	 * 
	 */
	public String getDiggest() {
		return diggest;
	}

	/* (non-Javadoc)
	 * @see toolbox.cerberus.ISingleResultUnit#getTitle()
	 */
	public String getTitle() {
		return title;
	}

	/* (non-Javadoc)
	 * @see toolbox.cerberus.ISingleResultUnit#getUrl()
	 */
	public String getUrl() {
		return url;
	}
	public SingleResultUnit(String url,String title,String diggest){
		this.url = url;
		this.title = title;
		this.diggest = diggest;
	}

}
