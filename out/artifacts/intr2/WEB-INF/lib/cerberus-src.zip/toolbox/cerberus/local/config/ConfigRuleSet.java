package toolbox.cerberus.local.config;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.configuration.ConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import toolbox.misc.LogFormatter;

/**
 * 从配置文件中提取标准的配置记录，并且记录在map中便于读取.
 * 
 * @see BasicRule
 * @author likui
 */
public class ConfigRuleSet {
    public static final Logger LOG = LogFormatter
            .getLogger(ConfigRuleSet.class);

    private static final String DELIMITER = ":";

    private Map<String, List<BasicRule>> ruleMap = new HashMap<String, List<BasicRule>>();

    private List<UrlSetRule> urlSetRules = new ArrayList<UrlSetRule>();

    /**
     * 创建一个空的ConfigRuleSet，请使用{@link #load(File)}来 从xml配置文件中读取实际的数据.
     */
    public ConfigRuleSet() {}

    /**
     * 从xml文件中读取配置数据.
     * 
     * @param filename
     *            配置文件的文件名
     * @throws ConfigurationException
     */
    public void load(Document document) {
        NodeList ruleSetNodes = document
                .getElementsByTagName(ConfigData.TagName.RULESET);
        for (int i = 0; i < ruleSetNodes.getLength(); i++) {
            Element elem = (Element) ruleSetNodes.item(i);
            getCertainRules(elem);
            getUrlSets(elem);
        }
    }

    /**
     * 取得某种类型的全部配置项.
     * 
     * @param product
     * @param type
     * @return
     */
    public List<BasicRule> getRules(String product, String type) {
        assert (product != null && type != null);
        product = product.toLowerCase();
        String key = product + DELIMITER + type;
        if (ruleMap.containsKey(key))
            return ruleMap.get(key);
        return null;
    }

    /**
     * 取得全部的UrlSetRule.
     * 
     * @return
     */
    public List<UrlSetRule> getUrlSetRules() {
        return urlSetRules;
    }

    protected void addRule(BasicRule rule, String products, String type) {
        String[] rets = products.split(DELIMITER);
        if (rets != null) {
            for (String product: rets) {
                String key = product + DELIMITER + type;
                if (ruleMap.containsKey(key)) {
                    List<BasicRule> list = ruleMap.get(key);
                    list.add(rule);
                    ruleMap.put(key, list);
                } else {
                    List<BasicRule> list = new ArrayList<BasicRule>();
                    list.add(rule);
                    ruleMap.put(key, list);
                }
            }
        }
    }

    protected void addUrlSetRule(UrlSetRule rule) {
        urlSetRules.add(rule);
    }

    /**
     * 获取BasicRule集合
     * 
     * @param elem
     */
    private void getCertainRules(Element elem) {
        String id = elem.getAttribute(ConfigData.ID);
        if (id.equals(ConfigData.RuleSet.URLSET_ID))
            return;
        NodeList nodeList = elem.getElementsByTagName(ConfigData.TagName.RULE);
        if (nodeList != null) {
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element ruleNode = (Element) nodeList.item(i);
                String ruleId = ruleNode.getAttribute(ConfigData.Rule.ID);
                String urlSetId = ruleNode
                        .getAttribute(ConfigData.Rule.URLSETID);
                String matchMode = ruleNode.getAttribute(ConfigData.Rule.MODE);
                String products = ruleNode
                        .getAttribute(ConfigData.Rule.PRODUCTS).toLowerCase();
                NodeList childs = ruleNode
                        .getElementsByTagName(ConfigData.TagName.CONTENT);
                if (childs != null) {
                    String[] contents = new String[childs.getLength()];
                    for (int index = 0; index < childs.getLength(); index++) {
                        contents[index] = childs.item(index).getTextContent();
                    }
                    BasicRule rule = new BasicRule();
                    rule.setContents(contents);
                    rule.setId(ruleId);
                    if (urlSetId != null && urlSetId.length() > 0)
                        rule.setUrlSetId(urlSetId);
                    rule.setMatchMode(matchMode);
                    rule.setProducts(products);
                    addRule(rule, products, id);
                }
            }
        }
    }

    /**
     * 从相应的XML Element中获取所有的url白名单
     * 
     * @param elem
     *            XML element
     */
    private void getUrlSets(Element elem) {
        String id = elem.getAttribute(ConfigData.ID);
        if (!id.equals(ConfigData.RuleSet.URLSET_ID))
            return;
        NodeList nodeList = elem.getElementsByTagName(ConfigData.TagName.RULE);
        if (nodeList != null) {
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element ruleNode = (Element) nodeList.item(i);
                String setId = ruleNode.getAttribute(ConfigData.UrlSetRule.ID);
                String name = ruleNode.getAttribute(ConfigData.UrlSetRule.NAME);
                NodeList childs = ruleNode
                        .getElementsByTagName(ConfigData.TagName.CONTENT);
                if (childs != null) {
                    String[] contents = new String[childs.getLength()];
                    for (int index = 0; index < childs.getLength(); index++) {
                        String url = childs.item(index).getTextContent();
                        /**
                         * pre processing for url,delete "http://" prefix.
                         */
                        url = url.toLowerCase().trim();
                        if(url.startsWith("http://"))
                        	url = url.substring(7);
                        contents[index] = url;
                    }
                    UrlSetRule rule = new UrlSetRule();
                    rule.setUrls(contents);
                    rule.setId(setId);
                    rule.setName(name);
                    addUrlSetRule(rule);
                }
            }
        }
    }
}
