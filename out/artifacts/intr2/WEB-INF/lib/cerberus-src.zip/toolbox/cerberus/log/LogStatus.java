/**
 * @(#)LogStatus.java, Jul 17, 2007. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.log;

/**
 *
 * @author likui
 *
 */
public class LogStatus {
    private boolean logSearch = true;
    private boolean logDiggest = true;
    private boolean logMatched = true;
    /**
     * ip黑名单是否支持指定站点内搜索
     */
    private boolean ipInSet = true;
    /**
     * input禁查关键字是否支持指定站点内搜索
     */
    private boolean inputInSet = true;
    /**
     * @return the logDiggest
     */
    public boolean isLogDiggest() {
        return logDiggest;
    }
    /**
     * @param logDiggest the logDiggest to set
     */
    public void setLogDiggest(boolean logDiggest) {
        this.logDiggest = logDiggest;
    }
    /**
     * @return the logMatched
     */
    public boolean isLogMatched() {
        return logMatched;
    }
    /**
     * @param logMatched the logMatched to set
     */
    public void setLogMatched(boolean logMatched) {
        this.logMatched = logMatched;
    }
    /**
     * @return the logSearch
     */
    public boolean isLogSearch() {
        return logSearch;
    }
    /**
     * @param logSearch the logSearch to set
     */
    public void setLogSearch(boolean logSearch) {
        this.logSearch = logSearch;
    }
    /**
     * @return the inputInSet
     */
    public boolean isInputInSet() {
        return inputInSet;
    }
    /**
     * @param inputInSet the inputInSet to set
     */
    public void setInputInSet(boolean inputInSet) {
        this.inputInSet = inputInSet;
    }
    /**
     * @return the ipInSet
     */
    public boolean isIpInSet() {
        return ipInSet;
    }
    /**
     * @param ipInSet the ipInSet to set
     */
    public void setIpInSet(boolean ipInSet) {
        this.ipInSet = ipInSet;
    }
}
