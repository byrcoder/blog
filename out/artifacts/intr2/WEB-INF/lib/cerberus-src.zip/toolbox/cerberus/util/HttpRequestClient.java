/**
 * @(#)HttpRequest.java, 2007-5-30. Copyright 2007 Yodao, Inc. All rights
 *                       reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                       subject to license terms.
 */
package toolbox.cerberus.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

/**
 * 请求http资源类
 * @author likui
 */
public class HttpRequestClient {
    /**
     * 获取http请求的结果
     * @param url
     * @return
     * @throws IOException
     * 
     */
    public String requestUrl(String url) throws IOException {
        HttpClient client = new HttpClient();

        GetMethod method = new GetMethod(url);
        method.getParams().setSoTimeout(timeout);
        StringBuffer result = new StringBuffer("");
        //阻塞方法
        int code = client.executeMethod(method);
        if (code == 200) {
            try {
                InputStream is = method.getResponseBodyAsStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        is, encode));
                try {
                    char[] buf = new char[4096];
                    int len;
                    while ((len = br.read(buf)) > 0) {
                        String s = new String(buf, 0, len);
                        result.append(s);
                    }
                } finally {
                    is.close();
                }
            } finally {}
        }
        return result.toString();
    }

    //远程返回结果的编码方式,默认为utf8.
    private String encode = "utf8";

    /**
     * 超时时间(ms)
     */
    private int timeout = 1000;

    /**
     * @return the encode
     */
    public String getEncode() {
        return encode;
    }

    /**
     * @param encode the encode to set
     */
    public void setEncode(String encode) {
        this.encode = encode;
    }

    /**
     * @return the timeout
     */
    public int getTimeout() {
        return timeout;
    }

    /**
     * @param timeout the timeout to set
     */
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

}
