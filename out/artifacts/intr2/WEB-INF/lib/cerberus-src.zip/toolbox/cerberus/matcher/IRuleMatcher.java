package toolbox.cerberus.matcher;

public interface IRuleMatcher {

}
