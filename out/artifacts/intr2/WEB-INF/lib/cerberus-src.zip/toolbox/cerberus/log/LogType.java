/**
 * @(#)LogType.java, 2007-7-2. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.log;

/**
 *日志的类型
 * @author likui
 *
 */
public class LogType {
    /**
     * 查询未命中
     */
    public static String QUERY_UN_HIT = "0";
    /**
     * 查询命中
     */
    public static String QUERY_HIT = "1";
    /**
     * 指定集合查询命中
     */
    public static String LEVEL_HIT = "2";
    /**
     * URL黑名单命中
     */
    public static String URL_HIT = "3";
    /**
     * Summary命中
     */
    public static String SUMMARY_HIT = "4";
    /**
     * ip黑名单命中
     */
    public static String IP_HIT = "5";
    /**
     * 事件命中
     */
    public static String EVENT_HIT = "6";
}
