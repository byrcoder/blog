/**
 * @(#)ProtocolUtil.java, 2007-6-1. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.util;

/**
 *传输数据转换工具类
 * @author likui
 *
 */
public class ProtocolUtil {
    /**
     * 将整数字符串归一化
     * 
     * @param numStr
     * @param len
     *   存储空间大小（char）,不足位时左补'0'.
     * @return
     */
    public static String normalizeNumStr(String numStr, int len) {
        assert len > 0;
        int num = Integer.parseInt(numStr);
        int max = (int) Math.pow(10, len);
        if (numStr.length() > len || numStr.length() <= 0 || num >= max
                || num < 0)
            throw new RuntimeException("numStr is invalid about " + numStr
                    + ",for len:" + len);

        if (numStr.length() < len) {
            char[] addStr = new char[len - numStr.length()];
            for (int i = 0; i < addStr.length; i++) {
                addStr[i] = '0';
            }
            return new String(new String(addStr)  + numStr);
        } else
            return numStr;
    }

    /**
     * 归一化整数
     * 
     * @param num
     * @param len
     *    存储空间大小（char）,不足位时左补'0'.
     * @return
     */
    public static String normalizeNum(int num, int len) {
        assert len >= 0;
        if(len == 0)
            return Integer.toString(num);
        int max = (int) Math.pow(10, len);
        if (num >= max || num < 0)
            throw new RuntimeException("num is invalid about " + num
                    + ",for len:" + len);
        String numStr = Integer.toString(num);
        if (numStr.length() < len) {
            char[] addStr = new char[len - numStr.length()];
            for (int i = 0; i < addStr.length; i++) {
                addStr[i] = '0';
            }
            return new String(new String(addStr) + numStr);
        } else
            return numStr;
    }
    
    public static int getByteLenInUtf8(String s){
        if(s == null )
            return 0;
        try{
            return s.getBytes("UTF8").length;
        }catch(Exception e){
            
        }
        return 0;
    }
    /**
     * 将需要传输的数据组装成len-content的形式，其中len表示content的utf表示的字节长度
     * @param content
     * @param lenBytes
     * @return
     */
    public static String wrapContentForTransfer(String content,int lenBytes){
        if(content == null)
            return null;
        StringBuilder s = new StringBuilder("");
        String contentLenInBytes = normalizeNum(getByteLenInUtf8(content),lenBytes);
        s.append(contentLenInBytes);
        s.append(content);
        return s.toString();
    }

    public static void main(String[] args){
        System.out.println(normalizeNum(9,3));
        System.out.println(normalizeNumStr("009",3));
    }
}
