/**
 * @(#)ConfigMerger.java, 2007-6-1. Copyright 2007 Yodao, Inc. All rights
 *                        reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                        subject to license terms.
 */
package toolbox.cerberus.local.config;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import toolbox.cerberus.util.XmlUtils;
import toolbox.misc.LogFormatter;

/**
 * 更新现有配置文件
 *
 * @author likui
 */
public class ConfigUpdater {
    public static final Logger LOG = LogFormatter
            .getLogger(ConfigUpdater.class);

    private String configFileName;

    private boolean fullUpdate;

    /**
     * 更新目标配置文件
     *
     * @param file
     * @return
     */
    public boolean update(File file) {
        if (file != null && file.exists()) {
            try {
                File srcFile = new File(configFileName);
                Document newDoc = XmlUtils.parse(file);
                if (newDoc == null) {
                    LOG.info("new file contains nothing:"
                            + srcFile.getAbsolutePath());
                    return true;
                }
                if(!srcFile.exists()){
                    LOG.info("src target xml file doesn't exsit,directly write new file.");
                    XmlUtils.save(srcFile, newDoc);
                    LOG.info("succ to update xml config file:"
                            + srcFile.getAbsolutePath());
                    return true;
                }
                Document doc = XmlUtils.parse(srcFile);
                LOG.info("begin to update xml content");
                updateDoc(doc, newDoc);
                LOG.info("begin to write xml config file:"
                        + srcFile.getAbsolutePath());
                XmlUtils.save(srcFile, doc);
                LOG.info("succ to update xml config file:"
                        + srcFile.getAbsolutePath());
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                LOG.warning("fail to update xml config file:" + configFileName
                        + "," + e.getMessage());
            }
        }

        return false;
    }

    /**
     * 改变配置文件中的工作模式
     *
     * @param remote
     *            工作模式：true-应急状态;false-普通状态
     * @return
     */
    public boolean setRemote(boolean remote) {
        try {
            File srcFile = new File(configFileName);
            Document doc = XmlUtils.parse(srcFile);
            Element srcRootElem = doc.getDocumentElement();
            NodeList nodeList = srcRootElem
                    .getElementsByTagName(ConfigData.TagName.MODE);
            if (nodeList != null || nodeList.getLength() == 1) {
                Element modeElem = (Element) nodeList.item(0);
                if (remote)
                    modeElem.setTextContent("remote");
                else
                    modeElem.setTextContent("local");
                XmlUtils.save(srcFile, doc);
                return true;
            } else {
                LOG
                        .warning("wrong to set work mode in config,please check config file:"
                                + srcFile.getAbsolutePath());
            }
        } catch (Exception e) {
            LOG
                    .warning("wrong to set work mode in config,please check config file-"
                            + configFileName + "," + e.getMessage());
        }
        return false;
    }

    /**
     * 获得配置文件中的工作状态
     *
     * @return 0：正常模式 1: 应急模式 -1：错误
     */
    public int getStatus() {
        try {
            File srcFile = new File(configFileName);
            Document doc = XmlUtils.parse(srcFile);
            Element srcRootElem = doc.getDocumentElement();
            NodeList nodeList = srcRootElem
                    .getElementsByTagName(ConfigData.TagName.MODE);
            if (nodeList != null || nodeList.getLength() == 1) {
                Element modeElem = (Element) nodeList.item(0);
                String mode = modeElem.getTextContent();
                LOG.info("Status:" + mode);
                if (mode == null) {// 出错
                    return -1;
                }
                if (mode.equals("local"))// 常态模式
                    return 0;
                if (mode.equals("remote"))// 应急模式
                    return 1;
                else
                    LOG.warning("config xml foramt error,file-"
                            + srcFile.getAbsolutePath() + ",mode:" + mode);
            }
        } catch (Exception e) {
            LOG.warning("Read config xml foramt error,file-" + configFileName);
            e.printStackTrace();
        }

        return -1;
    }

    /**
     * 更新配置文件
     *
     * @param doc
     * @param newDoc
     */
    void updateDoc(Document doc, Document newDoc) {
        Element srcRootElem = doc.getDocumentElement();
        Element newRootElem = newDoc.getDocumentElement();
        /**
         * 更新工作模式
         */
        NodeList nodeList = newRootElem
                .getElementsByTagName(ConfigData.TagName.MODE);
        NodeList srcNodeList = srcRootElem
                .getElementsByTagName(ConfigData.TagName.MODE);
        Element srcModeElem = (Element) srcNodeList.item(0);
        Element newModeElem = (Element) nodeList.item(0);
        srcModeElem.setTextContent(newModeElem.getTextContent());


        /**
         * 更新版本号
         */
       nodeList = newRootElem
                .getElementsByTagName(ConfigData.TagName.VERSION);
       srcNodeList = srcRootElem
                .getElementsByTagName(ConfigData.TagName.VERSION);
       Element newVersionElem = (Element) nodeList.item(0);
       if(srcNodeList == null || srcNodeList.getLength() == 0){
           Element versionElem = (Element) doc.importNode(newVersionElem, true);
           srcRootElem.appendChild(versionElem);
       }else{
           Element versionElem = (Element) srcNodeList.item(0);
           versionElem.setTextContent(newVersionElem.getTextContent());
       }


        /**
         * 更新rulelist
         */
        updateRuleList(srcRootElem, newRootElem);

        delelteWhiteSpaceChild(srcRootElem);
    }

    /**
     * 更新rulelist的内容
     *
     * @param srcRootElem
     * @param newRootElem
     */
    void updateRuleList(Element srcRootElem, Element newRootElem) {
        NodeList srcRuleSet = srcRootElem
                .getElementsByTagName(ConfigData.TagName.RULESET);
        NodeList newRuleSet = newRootElem
                .getElementsByTagName(ConfigData.TagName.RULESET);
        Map<String, Element> ruleSetMap = new HashMap<String, Element>();

        /**
         * 合并配置文件
         */
        if (newRuleSet != null && newRuleSet.getLength() > 0) {
            /**
             * 保存源ruleset信息，得到id->ruleset的映射
             */
            if (srcRuleSet != null && srcRuleSet.getLength() > 0) {
                for (int index = 0; index < srcRuleSet.getLength(); index++) {
                    Element ruleList = (Element) srcRuleSet.item(index);
                    String id = ruleList.getAttribute(ConfigData.ID);
                    ruleSetMap.put(id, ruleList);
                }
            }

            /**
             * 依次合并ruleset元素
             */
            for (int index = 0; index < newRuleSet.getLength(); index++) {
                Element newRuleList = (Element) newRuleSet.item(index);
                String id = newRuleList.getAttribute(ConfigData.ID);
                if (ruleSetMap.containsKey(id)) {// 已有ruleset
                    Element srcRuleList = ruleSetMap.get(id);
                    NodeList ruleNodes = srcRuleList
                            .getElementsByTagName(ConfigData.TagName.RULE);
                    NodeList newRuleNodes = newRuleList
                            .getElementsByTagName(ConfigData.TagName.RULE);
                    Map<String, Element> ruleMap = new HashMap<String, Element>();
                    if (ruleNodes != null && ruleNodes.getLength() > 0) {
                        for (int i = 0; i < ruleNodes.getLength(); i++) {
                            Element ruleElem = (Element) ruleNodes.item(i);
                            String ruleId = ruleElem
                                    .getAttribute(ConfigData.Rule.ID);
                            String source = ruleElem
                                    .getAttribute(ConfigData.Rule.SOURCE);
                            if (fullUpdate && source.equals("remote")) {
                                srcRuleList.removeChild(ruleElem);
                                continue;
                            }
                            if (!ruleMap.containsKey(ruleId)) {
                                ruleMap.put(ruleId, ruleElem);
                            } else {
                                LOG
                                        .warning("Duplicate rule id found:"
                                                + ruleId);
                            }
                        }

                        // 依次合并rule元素
                        for (int i = 0; i < newRuleNodes.getLength(); i++) {
                            Element ruleElem = (Element) newRuleNodes.item(i);
                            String ruleId = ruleElem
                                    .getAttribute(ConfigData.Rule.ID);
                            // System.out.println(ruleElem.getAttribute("mode"));
                            // System.out.println(ruleId + ":" + i);
                            if (ruleMap.containsKey(ruleId)) {// 删除重复id元素
                                Element oldElem = ruleMap.get(ruleId);
                                srcRuleList.removeChild(oldElem);
                            }
                            Element append = (Element) srcRuleList
                                    .getOwnerDocument().importNode(ruleElem,
                                            true);
                            srcRuleList.appendChild(append);
                        }

                    }
                } else {// 原来对应ruleset为空，直接复制
                    Element append = (Element) srcRootElem.getOwnerDocument()
                            .importNode(newRuleList, true);
                    srcRootElem.appendChild(append);
                }

            }

        }

    }

    /**
     * 删除xml文档中的空白元素，使格式紧凑
     *
     * @param elem
     */
    void delelteWhiteSpaceChild(Element elem) {
        elem.normalize();
        NodeList nodeList = elem.getChildNodes();
        if (nodeList != null) {
            for (int index = nodeList.getLength() - 1; index >= 0; index--) {
                Node node = nodeList.item(index);
                if (node.getNodeName().equals("#text")) {
                    elem.removeChild(node);
                    continue;
                }
                NodeList childNodeList = node.getChildNodes();
                if(childNodeList != null){
                    for(int i = childNodeList.getLength() - 1; i >= 0 ;i--){
                        Node childNode = childNodeList.item(i);
                        if(childNode.getNodeName().equals("#text") && isSpaceString(childNode.getNodeValue())){//删除空白文本节点
                            node.removeChild(childNode);
                        }
                    }
                }

            }
        }
    }
    /**
     * 是否为空白字符
     * @param string
     * @return
     */
    boolean  isSpaceString(String string){
        String[] res = string.split("[ \t\r\n]");
        if(res.length == 0)
            return true;
        return false;
    }
    /**
     * @return the configFileName
     */
    public String getConfigFileName() {
        return configFileName;
    }

    /**
     * @param configFileName
     *            the configFileName to set
     */
    public void setConfigFileName(String configFileName) {
        this.configFileName = configFileName;
    }

    /**
     * @return the fullUpdate
     */
    public boolean isFullUpdate() {
        return fullUpdate;
    }

    /**
     * @param fullUpdate
     *            the fullUpdate to set
     */
    public void setFullUpdate(boolean fullUpdate) {
        this.fullUpdate = fullUpdate;
    }

    /**
     * 得到配置文件的版本号
     * @return
     *  返回版本号，-1：错误
     */
    public String getVersion(){
        try {
            File srcFile = new File(configFileName);
            Document doc = XmlUtils.parse(srcFile);
            Element srcRootElem = doc.getDocumentElement();
            NodeList nodeList = srcRootElem
                    .getElementsByTagName(ConfigData.TagName.VERSION);
            if (nodeList != null || nodeList.getLength() == 1) {
                Element elem = (Element) nodeList.item(0);
                String version = elem.getTextContent();
                if(version != null && version.length() > 0)
                    return version;
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOG.warning("Read config xml foramt error,file-" + configFileName + "," + e);
        }
        LOG.warning("Version not found:" + configFileName);
        return "-1";
    }
}
