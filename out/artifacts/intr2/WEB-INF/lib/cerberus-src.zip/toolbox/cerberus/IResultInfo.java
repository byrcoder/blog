/**
 * @(#)IResultInfo.java, 2007-5-18. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus;

/**
 * 查询结果数据接口，以及设置过滤结果的接口.
 * @author river
 *
 */
public interface IResultInfo {

    /**
     * Return the count of result entries. 
     * @return
     */
    public int getSize();
    
    /**
     * Return the url of result at given index.
     * @param index
     * @return
     */
    public String getUrl(int index);
    
    /**
     * Return the title of result at given index.
     * @param index
     * @return
     */
    public String getTitle(int index);
    
    /**
     * Return the snippet text of result at given index.
     * @param index
     * @return
     */
    public String getSnippet(int index);
    
    /**
     * Return if the result at given index is passed.
     * @param index
     * @return
     */
    public boolean isPassed(int index);
    
    /**
     * Set if the result at given index should be passed.
     * @param index
     */
    public void setPassed(int index, boolean value);
    
    /**
     * Set if all the result should be passed. 
     * @param value
     */
    public void setAllPassed(boolean value);
    
}
