/**
 * @(#)LogManager.java, 2007-7-2. Copyright 2007 Yodao, Inc. All rights
 *                      reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is subject
 *                      to license terms.
 */
package toolbox.cerberus.log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 
 * Cerberus日志管理器
 * @author likui
 */
public class LogManager {
    private Map<String, List<String>> listMap;

    /**
     * 目标日志的保存根目录
     */
    private String destDir;
    /**
     * 日志文件的保存目录
     */
    private String logPath = "log";
    /**
     * 日志文件的索引目录
     */
    private String listPath = "list";

    File logDir;

    File listDir;
    /**
     * 文件的最大长度
     */
    private long maxLen = 7 * 1024  * 1024;

    private String deliter = "\\.";

    /**
     * 内部类,保存文件的起始位置
     * 
     * @author likui
     */
    class IndexSection {
        int begin;

        int end; // not contain
    }

    /**
     * 判断是否是合适的log文件名称
     * 
     * @param name
     * @return
     */
    boolean isLogFileName(String name) {
        if (name.startsWith("0-") || name.startsWith("1-")
                || name.startsWith("2-"))
            return true;
        return false;
    }

    /**
     * 处理单个文件
     * @param file
     * @throws IOException
     */
    void procFile(File file) throws IOException {

        /**
         * get file's type by prefix name
         */
        String prefixName = null;
        String orignName = file.getName();
        String[] res = orignName.split(deliter);
        prefixName = res[0];
        //TODO:check file name.
        if(prefixName.length() < 10)
        	return;
        /**
         * read file content into list
         */
        List<String> lineList = new ArrayList<String>();
        FileInputStream fi = new FileInputStream(file);
        InputStreamReader is = new InputStreamReader(fi);
        BufferedReader br = new BufferedReader(is);
        String line;
        while ((line = br.readLine()) != null) {
            // System.out.println(line);
            line = line.trim();
            if (line.length() > 0)
                lineList.add(line);
        }
        br.close();

        /**
         * spilt file into limited-size parts.
         */
        List<IndexSection> indexList = new ArrayList<IndexSection>();
        List<String> nameList = null;
        List<String> tmpNameList = nameList = new ArrayList<String>();
        if (listMap.containsKey(prefixName)) {
            nameList = listMap.get(prefixName);
        } else {
            nameList = new ArrayList<String>();
        }
        int totalLen = 0;
        int begin = 0;
        for (int i = 0; i < lineList.size(); i++) {
            totalLen += lineList.get(i).length();
            if (totalLen >= maxLen) {
                IndexSection section = new IndexSection();
                section.begin = begin;
                section.end = i;
                indexList.add(section);
                String fileName = genFileName(prefixName, nameList.size());
                nameList.add(fileName);
                tmpNameList.add(fileName);
                begin = i;
                totalLen = 0;
                i--;
            }
        }
        if (totalLen > 0) {
            IndexSection section = new IndexSection();
            section.begin = begin;
            section.end = lineList.size();
            indexList.add(section);
            String fileName = genFileName(prefixName, nameList.size());
            nameList.add(fileName);
            tmpNameList.add(fileName);
        }
        if (nameList != null && nameList.size() > 0)
            listMap.put(prefixName, nameList);

        /**
         * dump content into part files
         */
        dumpFile(lineList, tmpNameList, indexList);

    }

    /**
     * dump 列表文件
     * 
     * @throws IOException
     */
    public void dumpList() throws IOException {
        if (listMap != null) {
            Set<String> listNames = listMap.keySet();
            if (listNames != null) {
                for (String name: listNames) {
                    File file = new File(listDir, name  + ".list");
                    List<String> contents = listMap.get(name);
                    if (contents != null && contents.size() > 0) {
                        FileOutputStream fo = new FileOutputStream(file);
                        OutputStreamWriter os = new OutputStreamWriter(fo,
                                "utf8");
                        BufferedWriter bw = new BufferedWriter(os);
                        for (String content: contents) {
                            bw.write("/" + logPath + "/" + content);
                            bw.write("\n");
                        }
                        bw.close();
                    }
                }
            }
        }
    }

    /**
     * 将拆分后的部门内容写入文件
     * 
     * @param lineList
     * @param nameList
     * @param indexList
     * @throws IOException
     */
    void dumpFile(List<String> lineList, List<String> nameList,
            List<IndexSection> indexList) throws IOException {
        for (int i = 0; i < nameList.size(); i++) {
            String fileName = nameList.get(i);
            IndexSection section = indexList.get(i);
            File f = new File(logDir, fileName);
            FileOutputStream fo = new FileOutputStream(f);
            OutputStreamWriter os = new OutputStreamWriter(fo, "utf8");
            BufferedWriter bw = new BufferedWriter(os);
            for (int j = section.begin; j < section.end; j++) {
                bw.write(lineList.get(j));
                bw.write("\n");
            }
            bw.close();
        }

    }

    /**
     * 得到拆分后的文件名称
     * 
     * @param size
     * @return
     */
    String genFileName(String prefix, int size) {
        StringBuilder s = new StringBuilder("");
        s.append(prefix);
        s.append("_");
        s.append(size);
        return s.toString();
    }

    /**
     * 处理一个目录下的所有文件，不递归
     * 
     * @param srcDir
     * @throws IOException
     */
    public void procDir(File srcDir) throws IOException {
        File[] srcFiles = srcDir.listFiles();
        for (int i = 0; i < srcFiles.length; i++) {
            if (srcFiles[i].isFile() && isLogFileName(srcFiles[i].getName())) {
                procFile(srcFiles[i]);
            }
        }
    }

    public void init() {
        File destDirFile = new File(destDir);
        if (!destDirFile.exists())
            destDirFile.mkdir();
        logDir = new File(destDirFile, logPath);
        if (!logDir.exists())
            logDir.mkdir();
        listDir = new File(destDirFile, listPath);
        if (!listDir.exists())
            listDir.mkdir();
        listMap = new HashMap<String, List<String>>();
    }

    /**
     * @return the destDir
     */
    public String getDestDir() {
        return destDir;
    }

    /**
     * @param destDir
     *            the destDir to set
     */
    public void setDestDir(String destDir) {
        this.destDir = destDir;
    }

    /**
     * @return the logPath
     */
    public String getLogPath() {
        return logPath;
    }

    /**
     * @param logPath
     *            the logPath to set
     */
    public void setLogPath(String logPath) {
        this.logPath = logPath;
    }

    public static void main(String[] args) throws IOException {
        LogManager manager = new LogManager();
        if(args == null){
        manager.setDestDir("./dest");
        manager.init();
        manager.procDir(new File("log"));
        manager.dumpList();
        }else{
        	if(args.length == 2){
        			manager.setDestDir(args[0]);
        	        manager.init();
        	        manager.procDir(new File(args[1]));
        	        manager.dumpList();
        	}
        }
        

    }

}
