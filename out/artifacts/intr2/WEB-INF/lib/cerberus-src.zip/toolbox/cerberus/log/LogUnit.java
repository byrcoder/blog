/**
 * @(#)LogUnit.java, 2007-6-27. Copyright 2007 Yodao, Inc. All rights reserved.
 *                   YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license
 *                   terms.
 */
package toolbox.cerberus.log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import toolbox.cerberus.util.ProtocolUtil;

/**
 * 基本的LOG单元，存储一条log记录
 * 
 * @author likui
 */
public class LogUnit {

        private boolean logFlag = true;
	static SimpleDateFormat outputFormat = new SimpleDateFormat(
			"yyyyMMddHHmmss", Locale.US);

	/**
	 * 表示内容长度所用的为byte数
	 */
	private static int DATA_BTYE_LEN = 3;

	/**
	 * 
	 */
	private String language = "01";

	/**
	 * 
	 */
	private String encode = "03";

	public String searchType = "02";

	/**
	 * 
	 */
	private static String engineId = "005";

	/**
	 * 
	 */
	private String ip;

	/**
	 * 
	 */
	private String query;

	/**
	 * 
	 */
	private String summary = "";

	/**
	 * 
	 */
	private String ruleId = "";

	/**
	 * 
	 */
	private String type;

	/**
	 * 
	 */
	private String time;

	/**
	 * 
	 */
	private String url;

	public LogUnit() {
		time = null;
	}

	/**
	 * 
	 * @param type
	 * @param ip
	 * @param query
	 * @param url
	 * @param summary
	 */
	public LogUnit(String type, String ruleId, String ip, String query,
			String url, String summary) {
		this.type = type;
		this.ruleId = ruleId;
		this.ip = ip;
		setQuery(query);
		setUrl(url);
		setSummary(summary);
		setRuleId(ruleId);
		/**
		 * 设置时间
		 */
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		this.time = outputFormat.format(cal.getTime());
	}

	/**
	 * @return the engineId
	 */
	public static String getEngineId() {
		return engineId;
	}

	/**
	 * @param engineId
	 *            the engineId to set
	 */
	public static void setEngineId(String engineId) {
		LogUnit.engineId = engineId;
	}

	/**
	 * @return the encode
	 */
	public String getEncode() {
		return encode;
	}

	/**
	 * @param encode
	 *            the encode to set
	 */
	public void setEncode(String encode) {
		this.encode = encode;
	}

	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}

	/**
	 * @param ip
	 *            the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language
	 *            the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the query
	 */
	public String getQuery() {
		return query;
	}

	/**
	 * @param query
	 *            the query to set
	 */
	public void setQuery(String query) {
		if (query != null) {
			this.query = ProtocolUtil.wrapContentForTransfer(query,
					DATA_BTYE_LEN);
		}
	}

	/**
	 * @return the ruleId
	 */
	public String getRuleId() {
		return ruleId;
	}

	/**
	 * @param ruleId
	 *            the ruleId to set
	 */
	public void setRuleId(String ruleId) {
                /**
                 * 只记录关于中心配置产生的log
                 */
                if(ruleId != null && ruleId.length() > 8){
                    this.logFlag = false;
                }
		try {
			int tmp = Integer.parseInt(ruleId);
			this.ruleId = ProtocolUtil.normalizeNum(tmp, 8);

		} catch (Exception e) {
//			this.ruleId = ruleId;
		}
	}

	/**
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * @param summary
	 *            the summary to set
	 */
	public void setSummary(String summary) {
		if (summary != null &&ProtocolUtil.getByteLenInUtf8(summary) < Math.pow(10, DATA_BTYE_LEN)){
			this.summary = ProtocolUtil.wrapContentForTransfer(summary,
					DATA_BTYE_LEN);
                }
                            
	}

	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time
	 *            the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		if (url != null)
			this.url = ProtocolUtil.wrapContentForTransfer(url, DATA_BTYE_LEN);
	}

	public String toString() {
		if (ip == null)
			return null;
		StringBuilder builder = new StringBuilder("");
		//ip
		builder.append(ip);
		builder.append("&");
		//engineId
		builder.append(engineId);
		//user's query
		builder.append(query);
		//supported language
		builder.append(language);
		//encode
		builder.append(encode);
		builder.append(searchType);
		//time
		builder.append(time);
		builder.append(type);
		if (ruleId != null)
			builder.append(ruleId);
		if (url != null)
			builder.append(url);
		if (summary != null)
			builder.append(summary);

		return builder.toString();

	}

	/**
	 * @return the searchType
	 */
	public String getSearchType() {
		return searchType;
	}

	/**
	 * @param searchType the searchType to set
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

    /**
     * @return the logFlag
     */
    public boolean isLogFlag() {
        return logFlag;
    }

    /**
     * @param logFlag the logFlag to set
     */
    public void setLogFlag(boolean logFlag) {
        this.logFlag = logFlag;
    }
}
