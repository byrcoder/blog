package toolbox.cerberus;

/**
 * 文本的容器，这里没有直接使用一个String来传递过滤文本的
 * 原因是：过滤的中间结果，例如分词的结果，应该保存起来，以备多次使用.
 * @author river
 *
 */
public class TextObject {
    private String text;
    
    public TextObject(String text) {
        this.text = text;
    }
    
    public String getText() {
        return text;
    }
    
    public String toString() { return text; }
}
