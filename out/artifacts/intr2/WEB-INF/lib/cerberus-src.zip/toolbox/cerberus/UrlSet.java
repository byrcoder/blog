/**
 * @(#)UrlSet.java, 2007-5-14. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus;

import java.util.Arrays;
import java.util.HashSet;
import java.util.logging.Logger;

import toolbox.misc.EmptyInstance;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.UrlUtils;

/**
 * Url集合. 我们可能会要求一个指定的查询在对应的url集合中完成.
 * 这里额外提供了一个 {@link #getSites()} 的接口，主要是便于查询服务器使用
 * 站内查询来预先处理查询结果.
 * 
 * @author river
 */
public class UrlSet {
	public static final Logger LOG = LogFormatter.getLogger(UrlSet.class);

	private String[] urls = EmptyInstance.STRINGS;

	private String[] sites = EmptyInstance.STRINGS;

	private String[] reverseSites = EmptyInstance.STRINGS;

	/**
	 * 创建一个包含指定的url列表的集合.
	 * @param urls
	 */
	public UrlSet(String[] urls) {
		if (urls == null)
			return;
		this.urls = urls;
		Arrays.sort(urls);
		// extract site list
		HashSet<String> set = new HashSet<String>();
		HashSet<String> reverseSet = new HashSet<String>();
		for (String s : urls) {
			String host = UrlUtils.getHostFromUrl(s);
			if (host.length() == 0) {
				LOG.warning("bad host found for url " + s);
				continue;
			}
			set.add(host);
			reverseSet.add(new StringBuilder(host).reverse().toString());
		}

		sites = set.toArray(new String[set.size()]);
		Arrays.sort(sites);
		reverseSites = reverseSet.toArray(new String[reverseSet.size()]);
		Arrays.sort(reverseSites);
	}

	/**
	 * 返回集合中的所有的url.
	 * @return
	 */
	public String[] getUrls() {
		return urls;
	}

	/**
	 * 返回集合中所有的站点.
	 * @return
	 */
	public String[] getSites() {
		return sites;
	}

	/**
	 * 
	 * @param url
	 * @return
	 */
	String removeUrlPrefix(String url) {
		if (url.startsWith("http://")) {
			url = url.substring(7);
		} else if (url.startsWith("https://")) {
			url = url.substring(8);
		}
		return url;
	}

        /**
         * not used now.
         * @param url
         * @return
         */
	public boolean match(String url) {
		if (url != null && url.length() > 0) {
			url = removeUrlPrefix(url);
			for (String pattern : urls) {
				if (isContainUrl(pattern, url))
					return true;
			}
		}
		return false;
	}

        /**
         * not used now.
         * @param pattern
         * @param url
         * @return
         */
	boolean isContainUrl(String pattern, String url) {
		url = url.toLowerCase();
		pattern = pattern.toLowerCase();
		//TODO:to be exactly implemented.
		if (url.contains(pattern)) {
			String[] parts1 = url.split("/");
			String[] parts2 = pattern.split("/");
			if (parts1[0].endsWith(parts2[0])) {
				if (parts1[0].length() > parts2[0].length()) {
					int pos = parts1[0].length() - parts2[0].length() - 1;
					if (parts1[0].charAt(pos) != '.')
						return false;
				}
				return true;
			}
		}
		return false;
	}

	/**前缀匹配
	 * @param url
	 * @param pattern
	 *            not contain "/" int the last char.
	 * @return
	 */
	boolean isMatch(String url, String pattern) {
		if (url == null || pattern == null || pattern.length() == 0)
			return false;
		if (url.length() < pattern.length())
			return false;
		int len = pattern.length();
		for (int i = 0; i < len; i++) {
			if (i >= url.length())
				return false;
			char tmp1 = pattern.charAt(i);
			char tmp2 = url.charAt(i);
			if (tmp1 != tmp2)
				return false;
		}
		// TODO:www.yahoo.com vs www.yahoo.com.cn
		if (len < url.length()) {
			char next = url.charAt(len);
			if (next != '/')
				return false;
		}

		return true;
	}

	/**
	 * Is site in the specified site set.
	 * @param site
	 * @return
	 */
	String findSiteInSet(String site) {
		String reverseSite = new StringBuilder(site).reverse().toString();
		int begin, end, mid;
		for (begin = 0, end = reverseSites.length - 1; begin <= end;) {
			mid = (begin + end) / 2;
			String curStr = reverseSites[mid];
			int len = Math.min(curStr.length(), site.length());
			int ret = curStr.substring(0, len).compareTo(reverseSite.substring(0,len));
			if (ret < 0) {
				begin = mid + 1;
                               
			}
                        else if (ret > 0)
				end = mid - 1;
			else {
				//TODO:应该检查得更仔细。
                                if(site.length() >= curStr.length())
                                    return site;
                                else
                                    return  new StringBuilder(curStr).reverse().toString();
			}

		}
		return null;
	}

	/**
	 * 求sites和指定Sites的交集
	 * @param sites
	 * @return
	 */

	public String[] getMatchedSites(String[] sites) {
		if (sites == null || sites.length == 0)
			return null;
		HashSet<String> set = new HashSet<String>();
                String result;
		for (String site : sites) {
                    
			if ((result = findSiteInSet(site)) != null) {
				set.add(result);
			}
		}
		if (set.size() == 0)
			return null;
		return set.toArray(new String[set.size()]);
	}
}
