package toolbox.cerberus;

/**
 * 过滤器的接口，包括对于查询词的过滤以及对于结果的过滤.
 * 
 * @author river
 */
public interface IQueryChecker {

    /**
     * 过滤查询词，返回过滤的结果.
     * 
     * @param query
     */
    public QueryCheckResult checkQuery(IQueryInfo query);

    /**
     * 过滤查询结果，过滤的结果直接在ResultInfo中标出来.
     * 
     * @see ResultInfo#setPassed(int, boolean)
     * @param query
     * @param queryCheckResult
     * @param result
     */
    public void filterResult(IQueryInfo query,
            QueryCheckResult queryCheckResult, IResultInfo result);

    /**
     * 检查单个结果的状态
     * 
     * @param single
     * @return
     */
    public boolean checkSingleResult(ISingleResultUnit single);

    /**
     * 检查单个网页的状态
     * 
     * @param page
     * @return
     */
    public boolean checkSingleWebPage(IWebPageUnit page);

    /**
     * 获得指定的url列表.
     * 
     * @param setId
     * @return
     */
    public UrlSet getUrlSet(String setId);

    /**
     * 获得url黑名单
     * 
     * @return
     */
    public UrlSet getBlackUrlSet();

    /**
     * 用过滤summary的规则对一段文本进行过滤
     * 
     * @param text
     * @return
     */
    public QueryCheckResult checkText(TextObject text);

}
