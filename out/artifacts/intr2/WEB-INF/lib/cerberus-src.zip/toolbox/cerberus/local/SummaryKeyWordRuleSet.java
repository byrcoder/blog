package toolbox.cerberus.local;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import toolbox.cerberus.IKeyWordRuleSet;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.TextObject;
import toolbox.cerberus.local.config.BasicRule;
import toolbox.cerberus.local.config.ConfigData;
import toolbox.cerberus.local.config.ConfigRuleSet;
import toolbox.cerberus.matcher.MultiRuleMatcher;
import toolbox.cerberus.util.TextStringUtil;
import toolbox.lang.TraditionToSimple;
import toolbox.misc.LogFormatter;

/**
 * Keyword rule set using wumanber-matcher：字串匹配器
 * 
 * @author likui
 */
public class SummaryKeyWordRuleSet implements IKeyWordRuleSet {
    private String product;

    public static final Logger LOG = LogFormatter
            .getLogger(SummaryKeyWordRuleSet.class);

    // 用于完全匹配的对象--for input.
    InputKeyWordRuleSet fullQueryMatcher;

    // 标记是否是input
    boolean input;

    public QueryCheckResult check(TextObject text) {
        // text繁简转换
        String checkText = null;
        // Set<String> englishWords = null;

        if (ruleSetType.equals(ConfigData.RuleSet.INPUT_ID)) {
            checkText = TraditionToSimple.convert(text.getText().toLowerCase());
        } else if (ruleSetType.equals(ConfigData.RuleSet.OUTPUT_ID)) {
            // 过滤text中的特殊字符

        }

        // 检查是否有完全匹配，仅对input有效
        if (input) {
            BasicRule result = fullQueryMatcher.checkQuery(checkText);
            if (result != null) {
                String urlSetId = result.getUrlSetId();
                if (urlSetId == null || urlSetId.equals(UrlSets.DEFAUlT_ID))
                    return new QueryCheckResult(QueryCheckResult.Action.REJECT,
                            result.getId());
                else
                    return new QueryCheckResult(QueryCheckResult.Action.IN_SET,
                            result.getId(), urlSetId);
            }
        }
        QueryCheckResult result = QueryCheckResult.NORMAL;
        String[] matchResults = null;
        checkText = TraditionToSimple.convert(text.toString().toLowerCase());
        if (ruleMatcher != null) {
            checkText = TextStringUtil.removeSpecialChars(checkText);
            matchResults = ruleMatcher.getMatchedRules(checkText);
            result = checkImpl(checkText, matchResults, wordRuleMap,
                    kwsCountMap, urlSetIdMap);
        }
        if (result == QueryCheckResult.NORMAL) {
            if (ruleMatcherSimple != null) {
                matchResults = ruleMatcherSimple.getMatchedRules(checkText);
                result = checkImpl(checkText, matchResults, wordRuleMapSimple,
                        kwsCountMapSimple, urlSetIdMapSimple);
            }
        }
        return result;
    }

    /**
     * @param checkText
     * @param matchResults
     * @param wordRuleMap
     * @param kwsCountMap
     * @param urlSetIdMap
     * @return
     */
    private QueryCheckResult checkImpl(String checkText, String[] matchResults,
            Map<String, Set<String>> wordRuleMap,
            Map<String, Integer> kwsCountMap, Map<String, String> urlSetIdMap) {
        // map id to word count.
        if (matchResults == null || matchResults.length == 0) {
            return QueryCheckResult.NORMAL;
        }
        Map<String, Integer> idCountMap = new HashMap<String, Integer>();
        Set<String> matchWords = new HashSet<String>();
        Set<String> englishWords = TextStringUtil
                .getEnglishOrNumTerm(checkText);
        for (String kw: matchResults) {
            if (englishWords != null) {// exisiting english words
                if (TextStringUtil.isEnglishOrNumStr(kw)
                        && !englishWords.contains(kw)) // English
                    continue;
            }
            if (TextStringUtil.isEnglishCharBeginOrEnd(kw)) {
                // kw begin or end with english char or num char. end with
                // eng|num char.
                if (!TextStringUtil.isEuqalInEnglishStr(kw, checkText))
                    continue;
            }
            if (!matchWords.contains(kw)) {
                matchWords.add(kw);
            } else
                continue;
            if (wordRuleMap.containsKey(kw)) {
                Set<String> idSet = wordRuleMap.get(kw);
                for (String id: idSet) {
                    if (idCountMap.containsKey(id)) {
                        idCountMap.put(id, idCountMap.get(id) + 1);
                    } else
                        idCountMap.put(id, 1);
                }
            }
        }

        // check if match:子串匹配
        Set<String> idSets = idCountMap.keySet();
        for (String id: idSets) {
            if (kwsCountMap.containsKey(id)) {
                if (kwsCountMap.get(id) == idCountMap.get(id)) {// found
                    String urlSetId = null;
                    if (urlSetIdMap.containsKey(id))
                        urlSetId = urlSetIdMap.get(id);
                    if (urlSetId == null || urlSetId.equals(UrlSets.DEFAUlT_ID))
                        return new QueryCheckResult(
                                QueryCheckResult.Action.REJECT, id);
                    else
                        return new QueryCheckResult(
                                QueryCheckResult.Action.IN_SET, id, urlSetId);
                }
            }
        }

        return QueryCheckResult.NORMAL;
    }

    private MultiRuleMatcher ruleMatcher;

    private String ruleSetType;

    // map keyword to rule id set
    private Map<String, Set<String>> wordRuleMap;

    // map rule id to keywords' count
    private Map<String, Integer> kwsCountMap;

    // map rule id to urlset id;
    private Map<String, String> urlSetIdMap;

    // for simple filter strategy,not remove special char.
    private MultiRuleMatcher ruleMatcherSimple;

    // map keyword to rule id set
    private Map<String, Set<String>> wordRuleMapSimple;

    // map rule id to keywords' count
    private Map<String, Integer> kwsCountMapSimple;

    // map rule id to urlset id;
    private Map<String, String> urlSetIdMapSimple;

    public boolean init(ConfigRuleSet config, String product) {
        product = product.toLowerCase();
        this.product = product;
        input = ruleSetType.equals(ConfigData.RuleSet.INPUT_ID);
        kwsCountMap = new HashMap<String, Integer>();
        urlSetIdMap = new HashMap<String, String>();
        wordRuleMap = new HashMap<String, Set<String>>();

        kwsCountMapSimple = new HashMap<String, Integer>();
        urlSetIdMapSimple = new HashMap<String, String>();
        wordRuleMapSimple = new HashMap<String, Set<String>>();

        if (input) {
            fullQueryMatcher = new InputKeyWordRuleSet();
        }

        // init wordRuleMap from config
        List<BasicRule> rules = config.getRules(product, ruleSetType);
        if (rules != null) {
            for (BasicRule rule: rules) {
                if (input) {
                    if (ConfigData.MatchMode.OTHERMATCH.equals(rule
                            .getMatchMode())) {
                        fullQueryMatcher.addRule(rule);
                    } else
                        // input默认为子串匹配
                        addRule(rule);
                } else {
                    // output默认为字串匹配
                    addRule(rule);
                }
            }
        }

        Set<String> tmpKws = wordRuleMap.keySet();
        if (tmpKws != null && tmpKws.size() > 0) {
            ruleMatcher = new MultiRuleMatcher();
            ruleMatcher.setRuleStringSets(tmpKws);
            boolean ret = ruleMatcher.init();
            if(!ret){
                return ret;
            }
        }

        tmpKws = wordRuleMapSimple.keySet();
        if (tmpKws != null && tmpKws.size() > 0) {
            ruleMatcherSimple = new MultiRuleMatcher();
            ruleMatcherSimple.setRuleStringSets(tmpKws);
            boolean ret = ruleMatcherSimple.init();
            if(!ret){
                return ret;
            }
        }
        return true;
    }

    protected void addRule(BasicRule rule) {
        if (rule != null) {
            String mode = rule.getMatchMode();
            if (mode.length() == 0 || mode.equals("1")) {
                // default match mode
                addRuleImpl(rule, wordRuleMap, kwsCountMap, urlSetIdMap);
            } else if (mode.equals("2")) {
                addRuleImpl(rule, wordRuleMapSimple, kwsCountMapSimple,
                        urlSetIdMapSimple);
            }
        }

    }

    /**
     * read rule content.
     * 
     * @param rule
     * @param wordRuleMap
     * @param kwsCountMap
     * @param urlSetIdMap
     */
    private void addRuleImpl(BasicRule rule,
            Map<String, Set<String>> wordRuleMap,
            Map<String, Integer> kwsCountMap, Map<String, String> urlSetIdMap) {
        String id = rule.getId();
        String[] contents = rule.getContents();
        if (contents != null && contents.length > 0) {
            Set<String> contentSet = new HashSet<String>();
            for (String kw: contents) {
                if (kw == null) {
                    LOG
                            .warning("summary keyword abnormal:some sub keyword is null,rule id is "
                                    + rule.getId());
                    continue;
                }
                kw = TraditionToSimple.convert(kw.toLowerCase().trim());
                if(kw.length() == 0){
                    LOG
                    .warning("summary keyword abnormal:some sub keyword is empty,rule id is "
                            + rule.getId());
                    continue;
                }
                contentSet.add(kw);
                if (kw.length() == 1) {// single char
                    continue;
                } 
                if (!wordRuleMap.containsKey(kw)) {
                    Set<String> idSets = new HashSet<String>();
                    idSets.add(id);
                    wordRuleMap.put(kw, idSets);

                } else {
                    Set<String> idSets = wordRuleMap.get(kw);
                    idSets.add(id);
                    wordRuleMap.put(kw, idSets);
                }

            }// end for
            urlSetIdMap.put(id, rule.getUrlSetId());
            kwsCountMap.put(id, contentSet.size());

        }// end if contents
    }

    public String getRuleSetType() {
        return ruleSetType;
    }

    public void setRuleSetType(String ruleSetType) {
        this.ruleSetType = ruleSetType;
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param product
     *            the product to set
     */
    public void setProduct(String product) {
        this.product = product;
    }

}
