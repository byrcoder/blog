package toolbox.cerberus.matcher;

import java.util.Set;

import toolbox.text.patternsearch.IPatternSearcher;
import toolbox.text.patternsearch.MatchCollectHandler;
import toolbox.text.patternsearch.PatternSearcherFactory;
import toolbox.text.patternsearch.MatchCollectHandler.MatchResult;

/**
 * Multi-Rules Macther using Wumanber Alogrithm implemneted in text-tools.
 * @author likui
 *
 */
public class MultiRuleMatcher implements IRuleMatcher {

    //rules's string set
    private Set<String> ruleStringSets;

    private IPatternSearcher searcher;

    public boolean init() {
        searcher = PatternSearcherFactory
                .createPatternSearcher(PatternSearcherFactory.WU_MANBER_SEARCHER);
       return searcher.compile(ruleStringSets);
    }

    public String[] getMatchedRules(String content) {
        if(ruleStringSets == null || ruleStringSets.size() == 0)
            return null;
        MatchCollectHandler handler = new MatchCollectHandler();
        searcher.setHandler(handler);
        searcher.search(content);
        MatchResult[] results = handler.getMatchResults();
        if (results == null || results.length == 0)
            return null;
        String[] matchedStrings = new String[results.length];
        int i = 0;
        for (MatchResult result: results) {
            matchedStrings[i++] = result.getMatchPattern();
        }
        return matchedStrings;
    }

    public Set<String> getRuleStringSets() {
        return ruleStringSets;
    }

    public void setRuleStringSets(Set<String> ruleStringSets) {
        this.ruleStringSets = ruleStringSets;
    }

}
