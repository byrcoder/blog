package toolbox.cerberus;

/**
 * 关键字过滤规则.
 * @author river
 */
public interface IKeyWordRuleSet {

    public QueryCheckResult check(TextObject text);
    
}
