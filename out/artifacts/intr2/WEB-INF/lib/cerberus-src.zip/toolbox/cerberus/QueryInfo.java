package toolbox.cerberus;

/**
 * 查询相关的信息，用于查询词过滤.
 * @author river
 */
public class QueryInfo implements IQueryInfo {
    private String query; // query string
    private int ip; // ip of the user
    
    public QueryInfo(String query, int ip) {
        this.query = query;
        this.ip = ip;
    }
    
    /**
     * 返回提交查询的客户端的ip地址.
     * @return
     */
    public int getIp() {
        return ip;
    }

    /**
     * 返回用户提交的查询.
     * @return
     */
    public String getQuery() {
        return query;
    }
    
}
