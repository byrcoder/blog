/**
 * @(#)ForbiddenWordSet.java, 2009-2-18. Copyright 2009 Yodao, Inc. All rights
 *                            reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                            subject to license terms.
 */
package toolbox.cerberus.advance;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import org.springframework.util.StringUtils;

import toolbox.misc.LogFormatter;
import toolbox.web.HttpResource;
import toolbox.web.HttpResource.FileChangeListener;

/**
 * @author blueboat
 */
public class ForbiddenWordSet {

    public static final Logger LOG = LogFormatter.getLogger(ForbiddenWordSet.class);

    private String baseUrl;

    private String fileName;

    private Set<String> wordSet;

    private boolean charFormat = false;

    private long checkInterval = DEFAULT_CHECK_INTERVAL;

    private static long DEFAULT_CHECK_INTERVAL = 60000;

    public void init() {

        HttpResource httpResource = new HttpResource(baseUrl + fileName,
                new File(fileName), checkInterval);
        httpResource.registerListener(new FileChangeListener() {
            public void onFileChange(File file) {
                updateWordSet(file);
            }
        });
    }

    private void updateWordSet(File file) {
        FileInputStream fis;
        BufferedReader reader;
        Set<String> tempSet = new HashSet<String>();
        try {
            fis = new FileInputStream(file);
            reader = new BufferedReader(new InputStreamReader(fis));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                if (StringUtils.hasText(line)) {
                    line = line.trim();
                    if (charFormat) {
                        if (line.length() == 1)
                            tempSet.add(line.toLowerCase());
                    } else {
                        if (line.length() >= 2)
                            tempSet.add(line.toLowerCase());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        wordSet = tempSet;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Set<String> getWordSet() {
        return Collections.unmodifiableSet(wordSet);
    }

    public void setWordSet(Set<String> wordSet) {
        this.wordSet = wordSet;
    }

    public long getCheckInterval() {
        return checkInterval;
    }

    public void setCheckInterval(long checkInterval) {
        this.checkInterval = checkInterval;
    }

    public boolean isCharFormat() {
        return charFormat;
    }

    public void setCharFormat(boolean charFormat) {
        this.charFormat = charFormat;
    }

}
