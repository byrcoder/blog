package toolbox.cerberus.local;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import toolbox.cerberus.IUrlRuleSet;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.UrlSet;
import toolbox.cerberus.local.config.BasicRule;
import toolbox.cerberus.local.config.ConfigData;
import toolbox.cerberus.local.config.ConfigRuleSet;
import toolbox.cerberus.matcher.MultiRuleMatcher;
import toolbox.cerberus.util.UrlUtils;
import toolbox.misc.LogFormatter;

/**
 * 针对url进行过滤的规则列表.
 * 
 * @author likui
 */
public class UrlRuleSet implements IUrlRuleSet {
    public static final Logger LOG = LogFormatter
    .getLogger(UrlRuleSet.class);
	static int NOTFOUND = -1;

	private String product;

	private UrlSet blackUrlSet = null;

	private MultiRuleMatcher whiteListMatcher;

	private MultiRuleMatcher blackListMatcher;

	public static class UrlInfo {
		String url;

		String ruleId;

		public String getRuleId() {
			return ruleId;
		}

		public void setRuleId(String ruleId) {
			this.ruleId = ruleId;
		}

		public String getUrl() {
			return url;
		}

		public void setUrl(String url) {
			this.url = url;
		}

		public static final Comparator<UrlInfo> COMPARATOR = new Comparator<UrlInfo>() {
			public int compare(UrlInfo first, UrlInfo second) {
				return first.getUrl().compareTo(second.getUrl());
			}
		};

	}

	List<UrlInfo> whiteUrlList;

	List<UrlInfo> blackUrlList;

	/**
	 * 检查url. FIXED: (river) 这个地方是不是应该用前缀匹配？ FIXED
	 */
	public QueryCheckResult check(String url) {
		if (url != null) {
                        url = UrlUtils.normalizeUrl(url);
			String[] matchSet = null;
			if (whiteListMatcher != null) {
				matchSet = whiteListMatcher.getMatchedRules(url);
				String ruleId = checkWhetherMatch(url, matchSet, whiteUrlList);
				if (ruleId != null)
					return new QueryCheckResult(QueryCheckResult.Action.GREEN,
							ruleId);
			}
			if (blackListMatcher != null) {
				matchSet = blackListMatcher.getMatchedRules(url);
				String ruleId = checkWhetherMatch(url, matchSet, blackUrlList);
				if (ruleId != null)
					return new QueryCheckResult(QueryCheckResult.Action.REJECT,
							ruleId);
			}
		}

		return QueryCheckResult.NORMAL;
	}

	/**
	 * check whteher url matches the patterns.
	 * eg "it.sohu.com" matchs "sohu.com" while "www.sohu.com.cn" doesn't 
	 * @param url
	 * @param matchSet
	 * @param urlList
	 * @return
	 *      ruleId
	 */
	String checkWhetherMatch(String url, String[] matchSet,
			List<UrlInfo> urlList) {
		if (matchSet != null && matchSet.length > 0) {
			for (String matchPattern : matchSet) {
				if (UrlUtils.isContainUrl(matchPattern, url)) {
					//get rule ID;
					return getRuleIdByUrl(matchPattern, urlList);
				}
			}
		}
		return null;
	}

	String getRuleIdByUrl(String url, List<UrlInfo> urlList) {
		for (int begin = 0, end = urlList.size() - 1, mid = 0; begin <= end;) {
			mid = (begin + end) / 2;
			String tmp = urlList.get(mid).getUrl();
			int ret = tmp.compareTo(url);
			if (ret == 0) {
				return urlList.get(mid).getRuleId();
			} else if (ret < 0) {
				begin = mid + 1;
			} else
				end = mid - 1;

		}
		return null;
	}

	public void init(ConfigRuleSet config, String product) {
                product = product.toLowerCase();
                this.product = product;
		whiteUrlList = new ArrayList<UrlInfo>();
		blackUrlList = new ArrayList<UrlInfo>();
		List<BasicRule> whiteUrlRules = config.getRules(product,
				ConfigData.RuleSet.WHITEURL_ID);
		if (whiteUrlRules != null) {
			for (BasicRule rule : whiteUrlRules) {
				addRule(rule, whiteUrlList);
			}
			Collections.sort(whiteUrlList, UrlInfo.COMPARATOR);
		}
		List<BasicRule> blackUrlRules = config.getRules(product,
				ConfigData.RuleSet.BLACKURL_ID);
		if (blackUrlRules != null) {
			for (BasicRule rule : blackUrlRules)
				addRule(rule, blackUrlList);
			Collections.sort(blackUrlList, UrlInfo.COMPARATOR);
		}
		if (blackUrlList.size() > 0) {
			String[] blackUrls = new String[blackUrlList.size()];
			for (int i = 0; i < blackUrlList.size(); i++) {
				blackUrls[i] = blackUrlList.get(i).getUrl();
			}
			blackUrlSet = new UrlSet(blackUrls);
		}
		initMatcher();

	}

	void initMatcher() {
		if (whiteUrlList != null && whiteUrlList.size() > 0) {
			whiteListMatcher = new MultiRuleMatcher();
			Set<String> sets = new HashSet<String>();
			for (UrlInfo url : whiteUrlList) {
				sets.add(url.getUrl().toLowerCase().trim());
			}
			whiteListMatcher.setRuleStringSets(sets);
			whiteListMatcher.init();
		}

		if (blackUrlList != null && blackUrlList.size() > 0) {
			blackListMatcher = new MultiRuleMatcher();
			Set<String> sets = new HashSet<String>();
			for (UrlInfo url : blackUrlList) {
				sets.add(url.getUrl().toLowerCase().trim());
			}
			blackListMatcher.setRuleStringSets(sets);
			blackListMatcher.init();
		}
	}

	private void addRule(BasicRule rule, List<UrlInfo> list) {
		String ruleId = rule.getId();
		String[] contents = rule.getContents();
		if (contents != null && contents.length > 0) {
			for (String content : contents) {
				if (content!= null && content.length() > 0) {
					UrlInfo info = new UrlInfo();
                                        //normalize url
					String url = UrlUtils.normalizeUrl(content);
                                        //check whether url is valid
                                        if(url != null && url.length() > 1){
                                            info.setUrl(url);
                                            info.setRuleId(ruleId);
                                            list.add(info);
                                        }else{
                                            LOG.warning("Url format is invalid,rule id is " + ruleId + "|" + content);
                                        }
				}
			}
		}
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	/**
	 * @return the blackUrlList
	 */
	public List<UrlInfo> getBlackUrlList() {
		return blackUrlList;
	}

	/**
	 * @param blackUrlList
	 *            the blackUrlList to set
	 */
	public void setBlackUrlList(List<UrlInfo> blackUrlList) {
		this.blackUrlList = blackUrlList;
	}

	/**
	 * @return the whiteUrlList
	 */
	public List<UrlInfo> getWhiteUrlList() {
		return whiteUrlList;
	}

	/**
	 * @param whiteUrlList
	 *            the whiteUrlList to set
	 */
	public void setWhiteUrlList(List<UrlInfo> whiteUrlList) {
		this.whiteUrlList = whiteUrlList;
	}

	/**
	 * @return the blackUrlSet
	 */
	public UrlSet getBlackUrlSet() {
		return blackUrlSet;
	}

	/**
	 * remove "http://" in url prefix.
	 * @param url
	 * @return
	 */
	String removeUrlPrefix(String url) {
		if (url.startsWith("http://")) {
			url = url.substring(7);
		} else if (url.startsWith("https://")) {
			url = url.substring(8);
		}
		return url;
	}
}
