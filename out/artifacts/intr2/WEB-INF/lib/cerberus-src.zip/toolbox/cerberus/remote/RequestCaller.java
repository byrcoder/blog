/**
 * @(#)RequestCaller.java, 2007-5-29. Copyright 2007 Yodao, Inc. All rights
 *                         reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                         subject to license terms.
 */
package toolbox.cerberus.remote;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import toolbox.cerberus.IQueryInfo;
import toolbox.cerberus.QueryCheckResult;
import toolbox.cerberus.QueryInfo;
import toolbox.cerberus.util.ProtocolUtil;
import toolbox.cerberus.util.TextStringUtil;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.IpUtils;

/**
 * 与安全管理系统的通信接口：查询用户query的状态
 * 
 * @author likui
 */
public class RequestCaller {
    String requestUrl;

    // 传输给远程接口的消息实体的参数名
    String messageName = "message-body";

    boolean available = true;

    public static final Logger LOG = LogFormatter
            .getLogger(RequestCaller.class);

    // 请求超时时间(s)
    private int timeout;

    private String encode = "utf8";

    private String engineId;

    private String searchType;

    private final static String INVALID_FORMART = "invalid";

    static IQueryInfo queryInfo;

    static String deliter = "&";

    public RequestCaller() {
        if (queryInfo == null) {
            try {
                queryInfo = new QueryInfo("check status", IpUtils
                        .parseIp("192.168.0.1"));
            } catch (Exception e) {

            }
        }
        /**
         * 检查系统状态
         */
        CheckStatusThread checkThread = new CheckStatusThread();
        checkThread.start();
    }

    static class ReturnResult {
        // 错误
        static final int invalid = -1;

        // 通过
        static final int pass = 0;

        // 拒绝
        static final int reject = 1;

        // ip白名单
        static final int whiteip = 2;

        // 远程请求丢失，不可达
        static final int miss = 3;
    };

    /**
     * 检查远端通迅接口的状态
     * 
     * @author likui
     */
    class CheckStatusThread extends Thread {
        public void run() {
            while (true) {
                if (!available) {
                    String result = sendRequst(queryInfo);
                    if (result != null && result.equals(INVALID_FORMART)) {
                        LOG
                                .info("[RequestCaller]: found remote interface availbale.");
                        available = true;
                    }
                }
                try {
                    Thread.sleep(10000);
                } catch (Exception e) {

                }
            }
        }
    }

    /**
     * 获得远端返回的原始结果字符串
     * @param queryInfo
     * @return
     */
    public String getResponseAsString(IQueryInfo queryInfo) {
        if (!available) {
            LOG.info("[RequestCaller]: remote interface is not availbale.");
            return "-1";
        }
        // 组装并发送请求
        return sendRequst(queryInfo);
    }

    /**
     * main function:向远端安全系统请求查询的状态
     * 
     * @param queryInfo
     * @return
     */
    public QueryCheckResult checkReuslt(IQueryInfo queryInfo) {
        if (!available) {
            LOG.info("[RequestCaller]: remote interface is not availbale.");
            return QueryCheckResult.NORMAL;
        }
        // 组装并发送请求
        String response = sendRequst(queryInfo);

        // 处理请求
        int ret = procResult(response);
        switch (ret) {
            case ReturnResult.invalid:
                LOG
                        .warning("[RequestCaller]: remote interface return err info,please check protocl. "
                                + response);
                return QueryCheckResult.NORMAL;
            case ReturnResult.pass:
                return QueryCheckResult.NORMAL;
            case ReturnResult.whiteip:
                return new QueryCheckResult(QueryCheckResult.Action.GREEN, "");
            case ReturnResult.reject:
                return new QueryCheckResult(QueryCheckResult.Action.REJECT, "");
            case ReturnResult.miss:
                return new QueryCheckResult(QueryCheckResult.Action.GREEN, "");
            default:
                LOG.warning("remote interface return error:" + ret);
                return QueryCheckResult.NORMAL;

        }
    }

    /**
     * TODO:处理返回结果
     * 
     * @param result
     * @return
     */
    private int procResult(String result) {
        if (result == null) {
            available = false;
            LOG.warning("[RequestCaller]: call remote interface fail.");
            return ReturnResult.miss;
        }
        if (result.equals(INVALID_FORMART)) {
            LOG.warning("[RequestCaller]: invalid query format.");
            return ReturnResult.reject;
        }
        int ret = ReturnResult.pass;
        try {
            ret = Integer.parseInt(result);
        } catch (Exception e) {
            LOG.warning("Remote interface return error:" + result);
        }
        return ret;
    }

    /**
     * 以约定格式包装请求数据，得到相应的post方法
     * 
     * @param queryInfo
     * @return
     */
    private PostMethod getPostMethod(IQueryInfo queryInfo) {
        LOG.info("request url|" + requestUrl);
        PostMethod post = new PostMethod(requestUrl);

        String messageBody = wrapRequestMessage(queryInfo);
        if (messageBody != null) {
            System.out.println(messageBody);
            try {
                StringRequestEntity requestBody = new StringRequestEntity(
                        messageBody, "text/xml", "UTF8");
                post.setRequestEntity(requestBody);
            } catch (Exception e) {
                LOG.warning("Request body encode error," + e);
            }

        }

        return post;
    }

    /**
     * 向远程请求检查用户查询的状态
     * 
     * @param queryInfo
     * @return 返回状态结果
     */
    private String sendRequst(IQueryInfo queryInfo) {
        HttpClient client = new HttpClient();
        PostMethod post = getPostMethod(queryInfo);
        if (post == null) {
            LOG
                    .warning("[RequestCaller]: query format err,fail to post it to remote,so return directly.");
            return INVALID_FORMART;
        }
        post.getParams().setSoTimeout(timeout);

        try {
            int code = client.executeMethod(post);
            if (code == 200) {
                try {
                    // String response = new
                    // String(post.getResponseBodyAsString()
                    // .getBytes(encode));
                    InputStream in = post.getResponseBodyAsStream();
                    byte[] responseBody = null;
                    if (in != null) {
                        byte[] tmp = new byte[4096];
                        int bytesRead = 0;
                        ByteArrayOutputStream buffer = new ByteArrayOutputStream(
                                1024);
                        while ((bytesRead = in.read(tmp)) != -1) {
                            buffer.write(tmp, 0, bytesRead);
                        }
                        responseBody = buffer.toByteArray();
                    }

                    return new String(responseBody, encode);
                } catch (IOException e) {
                    // TODO:
                } finally {
                    post.releaseConnection();
                }

            } else {
                return null;
            }
        } catch (IOException e) {

        }
        return null;
    }

    /**
     * 请求体格式：engineid&agentip&searchtype data_length data_buff
     * 
     * @param queryInfo
     * @return
     */
    private String wrapRequestMessage(IQueryInfo queryInfo) {
        if (queryInfo == null) {
            LOG.log(Level.WARNING,
                    "wrapRequestMessage() ocuurs null parameter.");
            return null;
        }
        String normalizerQuery = TextStringUtil.normalizerQuery(queryInfo
                .getQuery());
        StringBuilder buf = new StringBuilder("");
        buf.append(engineId + deliter);
        String agentIp = IpUtils.formatIp(queryInfo.getIp());
        buf.append(agentIp + deliter);
        buf.append(searchType);

        buf.append(ProtocolUtil.normalizeNum(ProtocolUtil
                .getByteLenInUtf8(normalizerQuery), 3));
        buf.append(normalizerQuery);
        return buf.toString();
    }

    /**
     * @return the encode
     */
    public String getEncode() {
        return encode;
    }

    /**
     * @param encode
     *            the encode to set
     */
    public void setEncode(String encode) {
        this.encode = encode;
    }

    /**
     * @return the requestUrl
     */
    public String getRequestUrl() {
        return requestUrl;
    }

    /**
     * @param requestUrl
     *            the requestUrl to set
     */
    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    /**
     * @return the timeout
     */
    public int getTimeout() {
        return timeout;
    }

    /**
     * @param timeout
     *            the timeout to set
     */
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getEngineId() {
        return engineId;
    }

    public void setEngineId(String engineId) {
        this.engineId = engineId;
    }

    public String getSearchType() {
        return searchType;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }
}
