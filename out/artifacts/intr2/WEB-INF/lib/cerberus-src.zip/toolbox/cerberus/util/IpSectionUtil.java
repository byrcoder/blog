/**
 * @(#)IpSectionUtil.java, Jul 4, 2007. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.util;

import toolbox.misc.net.IpUtils;

/**
 * computer ip section
 * 
 * @author likui
 * 
 */
public class IpSectionUtil {
	/**
	 * seperate char between begin and end ip
	 */
	public static String deliter = ":";
	/**
	 * convert
	 * @param str
	 * @return
	 */
	public static String convertIpMask(String str) {
		if (str != null) {
			String res[] = str.split("/");
			if (res.length == 2) {
				try {

					int begin = IpUtils.parseIp(res[0]);
					int netBits = Integer.parseInt(res[1]);
					if(0 < netBits && 32 >= netBits){
						int tmp = 32 - netBits;
						int diff = 0;
						if(tmp == 0){
							return res[0] + deliter + res[0];
						}
						diff = 1 << tmp;
						int end = begin | (diff - 1);
						return res[0] + deliter + IpUtils.formatIp(end);
					}

				} catch (Exception e) {
					System.out.println("Parse ip section error:" + str + e);
				}
			}
		}
		return null;
	}
	
	public static void main(String[] args){
//		System.out.println(IpSectionUtil.convert("10.0.1.1/32"));
		System.out.println(IpSectionUtil.convertIpMask("10.0.1.255/4"));
	}
}
