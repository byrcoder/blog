/**
 * @(#)ResultCaller.java, 2007-5-29. Copyright 2007 Yodao, Inc. All rights
 *                        reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                        subject to license terms.
 */
package toolbox.cerberus.remote;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import toolbox.cerberus.IQueryInfo;
import toolbox.cerberus.IResultInfo;
import toolbox.cerberus.QueryInfo;
import toolbox.cerberus.ResultInfo;
import toolbox.cerberus.util.ProtocolUtil;
import toolbox.cerberus.util.TextStringUtil;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.IpUtils;

/**
 * 与安全管理系统的通信接口：获得查询结果的状态
 * 
 * @author likui
 */
public class ResultCaller {
    // 请求地址
    String requestUrl;

    // 传输给远程接口的消息实体的参数名
    String messageName = "message-body";

    static String deliter = "&";

    // 请求远程接口超时时间
    private int timeout;

    private String engineId;

    private String encode = "utf8";

    private String searchType;

    // 请求失败
    private static String FAIL = "fail";

    // 远程接口是否正常
    boolean available = true;

    public static final Logger LOG = LogFormatter.getLogger(ResultCaller.class);

    static String LOG_PREFIX = ResultCaller.class.toString();

    /**
     * 测试样例
     */
    private static IQueryInfo queryInfo;

    private static IResultInfo resultInfo;

    /**
     * main fucntion:向远端安全系统请求查询结果的状态
     * 
     * @param queryInfo
     * @param resultInfo
     */
    public void filterResult(IQueryInfo queryInfo, IResultInfo resultInfo) {
        if (!available) {// 远程接口不可达
            resultInfo.setAllPassed(true);
            LOG.warning("[" + LOG_PREFIX + "] remote peer not avaible.");
            return;
        }

        // 组装并发送请求
        String response = sendRequst(queryInfo, resultInfo);
        LOG.info(response);

        // 处理请求
        Integer[] ret = procResult(response);
        if (ret == null) {// 放行
            resultInfo.setAllPassed(true);
        } else {
            for (Integer index: ret) {
                resultInfo.setPassed(index, false);
                LOG.info("[" + LOG_PREFIX + "] remote peer filter index "
                        + index + " in result" + ",about query"
                        + queryInfo.getQuery() + " from "
                        + IpUtils.formatIp(queryInfo.getIp()));
            }
        }
    }

    /**
     * 获得远端返回的原始结果字符串
     * 
     * @param queryInfo
     * @return
     */
    public String getResponseAsString(IQueryInfo queryInfo,
            IResultInfo resultInfo) {
        if (!available) {
            LOG.info("[ResultCaller]: remote interface is not availbale.");
            return "-1";
        }
        // 组装并发送请求
        return sendRequst(queryInfo, resultInfo);
    }

    public ResultCaller() {
        if (queryInfo == null) {
            try {
                queryInfo = new QueryInfo("check status", IpUtils
                        .parseIp("192.168.0.1"));
            } catch (Exception e) {

            }
        }
        if (resultInfo == null) {
            ResultInfo tmp = new ResultInfo(1);
            tmp.addEntry("www.sina.com.cn/", "新浪首页",
                    "拥有多家地区性网站，提供各类信息分类，以网络媒体为主要特征的综合门户。");
            resultInfo = tmp;

        }
        /**
         * 检测远程接口的状态
         */
        CheckStatusThread checkStatusThread = new CheckStatusThread();
        checkStatusThread.start();

    }

    /**
     * TODO:处理返回结果
     * 
     * @param result
     * @return
     */
    private Integer[] procResult(String result) {
        if (result == FAIL) {// 请求失败
            available = false;
            return null;
        }
        /**
         * 对返回结果进行解析处理
         */
        String[] res = result.split("&");
        int code = Integer.parseInt(res[0]);
        switch (code) {
            case -1:// 出错
                LOG.warning("[" + LOG_PREFIX
                        + "] remote peer reurns error,please check protocl:"
                        + result);
                return null;
            case 0:
                return null;              
            default:
                if (res.length < 2)
                    return null;
                Integer[] index = new Integer[res.length - 1];
                for (int i = 1; i < res.length; i++) {
                    index[i - 1] = Integer.parseInt(res[i]);
                }
                LOG.info("bad result size:" + index.length);
                return index;
//            default:
//                LOG.warning("[" + LOG_PREFIX
//                        + "] get bad code about check result:" + code + ","
//                        + result);
        }
//        return null;
    }

    /**
     * 包装请求头和请求消息体，得到响应的post方法
     * 
     * @param queryInfo
     * @param resultInfo
     * @return
     */
    private PostMethod getPostMethod(IQueryInfo queryInfo,
            IResultInfo resultInfo) {

        PostMethod post = new PostMethod(requestUrl);
        String messageBody = wrapRequestMessage(queryInfo, resultInfo);
        if (messageBody != null) {
            System.out.println(messageBody);
            try {
                StringRequestEntity requestBody = new StringRequestEntity(
                        messageBody, "text/xml", "UTF8");
                post.setRequestEntity(requestBody);
            } catch (Exception e) {
                LOG.warning("Request body encode error," + e);
            }
        }

        return post;
    }

    /**
     * 包装请求信息到消息体 消息体格式:agentId&resultNum&searchType&query'len query'content
     * {url'len url'content tilte'len title'content snippet'len snippet'content}
     * 
     * @param queryInfo
     * @param resultInfo
     * @return
     */
    private String wrapRequestMessage(IQueryInfo queryInfo,
            IResultInfo resultInfo) {
        if (queryInfo == null || resultInfo == null) {
            LOG.log(Level.WARNING,
                    "wrapRequestMessage() ocuurs null parameter.");
            return null;
        }
        String normalizerQuery = TextStringUtil.normalizerQuery(queryInfo
                .getQuery());
        StringBuilder buf = new StringBuilder("");
        buf.append(engineId + deliter);

        int resultNum = resultInfo.getSize();
        buf.append(Integer.toString(resultNum) + deliter);

        String agentIp = IpUtils.formatIp(queryInfo.getIp());
        buf.append(agentIp + deliter);

        buf.append(searchType);
        buf.append(ProtocolUtil.normalizeNum(ProtocolUtil
                .getByteLenInUtf8(normalizerQuery), 3));
        buf.append(normalizerQuery);
        for (int i = 0; i < resultNum; i++) {
            // append url
            buf.append(ProtocolUtil.normalizeNum(ProtocolUtil
                    .getByteLenInUtf8(resultInfo.getUrl(i)), 3));
            buf.append(resultInfo.getUrl(i));

            // append title
            buf.append(ProtocolUtil.normalizeNum(ProtocolUtil
                    .getByteLenInUtf8(resultInfo.getTitle(i)), 3));
            buf.append(resultInfo.getTitle(i));

            // append content
            buf.append(ProtocolUtil.normalizeNum(ProtocolUtil
                    .getByteLenInUtf8(resultInfo.getSnippet(i)), 3));
            buf.append(resultInfo.getSnippet(i));
        }

        return buf.toString();
    }

    /**
     * 发送搜索结果到远端管理系统检查
     * 
     * @param queryInfo
     * @param resultInfo
     * @return
     */
    private String sendRequst(IQueryInfo queryInfo, IResultInfo resultInfo) {
        HttpClient client = new HttpClient();
        PostMethod post = getPostMethod(queryInfo, resultInfo);
        post.getParams().setSoTimeout(timeout);
        try {
            int code = client.executeMethod(post);
            if (code == 200) {
                try {
                    // String response = new
                    // String(post.getResponseBodyAsString()
                    // .getBytes(encode));
                    InputStream in = post.getResponseBodyAsStream();
                    byte[] responseBody = null;
                    if (in != null) {
                        byte[] tmp = new byte[4096];
                        int bytesRead = 0;
                        ByteArrayOutputStream buffer = new ByteArrayOutputStream(
                                1024);
                        while ((bytesRead = in.read(tmp)) != -1) {
                            buffer.write(tmp, 0, bytesRead);
                        }
                        responseBody = buffer.toByteArray();
                    }

                    String response = new String(responseBody, encode);
                    return response;
                } catch (IOException e) {
                    // TODO:
                    LOG.warning("[" + LOG_PREFIX + "] http request fail,"
                            + e.getMessage());
                    return FAIL;
                } finally {
                    post.releaseConnection();
                }

            } else {
                LOG.warning("[" + LOG_PREFIX
                        + "] http request fail,return code:" + code);
                return FAIL;
            }
        } catch (IOException e) {
            LOG.warning("[" + LOG_PREFIX + "] http request fail,"
                    + e.getMessage());
        }
        return FAIL;
    }

    /**
     * @return the engineId
     */
    public String getEngineId() {
        return engineId;
    }

    /**
     * 检查远端通迅接口的状态
     * 
     * @author likui
     */
    class CheckStatusThread extends Thread {
        public void run() {
            while (true) {
                if (!available) {
                    String result = sendRequst(queryInfo, resultInfo);
                    if (result != FAIL) {
                        LOG.info("[" + LOG_PREFIX
                                + "]: found remote interface availbale.");
                        available = true;
                    }
                }
                try {
                    Thread.sleep(10000);
                } catch (Exception e) {

                }
            }
        }
    }

    /**
     * @param engineId
     *            the engineId to set
     */
    public void setEngineId(String engineId) {
        this.engineId = ProtocolUtil.normalizeNumStr(engineId, 3);
    }

    public String getSearchType() {
        return searchType;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }
}
