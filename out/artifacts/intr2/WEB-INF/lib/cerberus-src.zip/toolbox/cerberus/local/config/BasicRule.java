package toolbox.cerberus.local.config;

import toolbox.cerberus.local.UrlSets;

/**
 * 基本的规则配置项，可以保存"关键字", "ip黑白名单"等多种配置数据.
 * FIXME: 需要更多的javadoc，需要说明一个xml的文件是如何映射到ConfigRule的.
 * @author likui
 */
public class BasicRule {
    //rule class:input|output|blackurl|...
    private String ruleClass;
    
    /**
     *规则ID,唯一标识该规则 
     */
    private String id;
    
    /**
     *对应的urlset 的Id 
     */    
    private String urlSetId = UrlSets.DEFAUlT_ID;
    
    private String matchMode;
    
    private String products;
//  rule's access level
    private String secretLevel;
    
    //rule's contens
    private String[] contents;
    
    //rule's source
    private String source;
    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }

    public String[] getContents() {
        return contents;
    }
    
    public void setContents(String[] contents) {
        this.contents = contents;
    }
    
    public String getSecretLevel() {
        return secretLevel;
    }
    
    public void setSecretLevel(String secretLevel) {
        this.secretLevel = secretLevel;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    
    public String getRuleClass() {
        return ruleClass;
    }
    
    public void setRuleClass(String ruleClass) {
        this.ruleClass = ruleClass;
    }
    
    public String getUrlSetId() {
        return urlSetId;
    }
    
    public void setUrlSetId(String urlSetId) {
        this.urlSetId = urlSetId;
    }
    
    public String getMatchMode() {
        return matchMode;
    }
    
    public void setMatchMode(String matchMode) {
        this.matchMode = matchMode;
    }
    
    public String getProducts() {
        return products;
    }
    
    public void setProducts(String products) {
        this.products = products;
    }
}
