package toolbox.cerberus;

/**
 * The result of query check. The lowest 8bits store the action should be taken on this query,
 * and the higher 8bits store the data, such as query level.
 * @author river
 */
public class QueryCheckResult {
    
    /**
     * 预先定义的常见返回值.
     */
    public static final QueryCheckResult NORMAL = new QueryCheckResult(Action.NORMAL, "<none>");
    
    /**
     * 定义对于查询进行过滤的动作.
     * @author river
     */
    public static enum Action {
        NORMAL, //一般查询
        REJECT, //禁止查询
        GREEN, //没有任何后续的过滤
        IN_SET, //在指定的集合内查询
    };
    
    private Action action;
    private String ruleId; //匹配的规则的id
    private UrlSet urlSet = null;
    private String urlSetId = null;
    
    /**
     * 创建一个查询过滤结果.
     * @param action
     * @param ruleId
     */
    public QueryCheckResult(Action action, String ruleId) {
        this.action = action;
        assert (action != Action.IN_SET) : "Miss call to CheckResult constructor without UrlSet";
        this.ruleId = ruleId;
        this.urlSet = null;
    }
    
    public QueryCheckResult(Action action, String ruleId, String urlSetId) {
        this(action, ruleId, urlSetId, null);
    }
    
    public QueryCheckResult(Action action, String ruleId, String urlSetId, UrlSet set) {
        this.action = action;
        this.ruleId = ruleId;
        this.urlSetId = urlSetId;
        this.urlSet = set;
    }
    
    /**
     * 返回对于查询的动作.
     * @return
     */
    public Action getAction() {
        return action;
    }
    
    /**
     * 设置action的值，这个一般在过滤过程内部进行调用，应用程序不应该调用这个接口.
     * @param value
     */
    public void setAction(Action value) {
        this.action = value;
    }
    
    /**
     * 返回匹配的规则的id. 这个便于search engine进行日志记录.
     * @return
     */
    public String getRuleId() {
        return ruleId;
    }

    /**
     * 如果 {@link #getAction()} 返回的是 {@link Action#SET}，这里就会返回对应的
     * 集合的定义.
     * @return
     */
    public UrlSet getUrlSet() {
        return urlSet;
    }
    
    /**
     * 获取指定的urlSetId.
     * @return
     */
    public String getUrlSetId() {
        return urlSetId;
    }
    
    /**
     * 指定urlSet.
     * @param set
     */
    public void setUrlSet(UrlSet set) {
        this.urlSet = set;
    }
    
}
