package toolbox.cerberus.wordcutter;

import java.util.List;

public interface IWordCutter {
    public List<String> cutWord(String query);
}
