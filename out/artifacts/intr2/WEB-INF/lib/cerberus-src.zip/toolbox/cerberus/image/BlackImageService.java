/**
 * @(#)BlackImageService.java, Dec 21, 2009. Copyright 2009 Yodao, Inc. All
 *                             rights reserved. YODAO PROPRIETARY/CONFIDENTIAL.
 *                             Use is subject to license terms.
 */
package toolbox.cerberus.image;

import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.zip.CRC32;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import toolbox.cerberus.image.data.BlackImageUrl;
import toolbox.cerberus.image.data.BlackImageLoc;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.UrlUtils;

/**
 * A black image filter service. You can use it to filter black images.
 * 
 * @author lijiawen
 */
public class BlackImageService {

    public static final Logger LOG = LogFormatter
            .getLogger(BlackImageService.class);

    private SessionFactory factory;

    private long maxLastImgUrlId = 0;

    private long maxLastSiteId = 1;

    private Map<Long, Object> blackSites = new ConcurrentHashMap<Long, Object>();

    private Map<Long, Object> blackImgUrls = new ConcurrentHashMap<Long, Object>();

    /**
     * @param updateInterval
     *            update database interval in milliseconds
     */
    public BlackImageService(long updateInterval) {
        Configuration cfg = new Configuration()
                .configure("/hibernate_image.cfg.xml");
        factory = cfg.buildSessionFactory();
        updateDataBase();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                updateDataBase();
            }
        }, updateInterval, updateInterval);
    }

    private static final Object reused = new Object();

    private static ThreadLocal<CRC32> keyGenerator = new ThreadLocal<CRC32>() {
        protected synchronized CRC32 initialValue() {
            return new CRC32();
        }
    };

    private long getKey(String url) {
        CRC32 crc32 = keyGenerator.get();
        crc32.reset();
        crc32.update(url.getBytes());
        return crc32.getValue();
    }

    @SuppressWarnings("unchecked")
    private void updateDataBase() {
        long beginTime = System.currentTimeMillis();
        Session session = factory.openSession();
        List list = session.createQuery(
                "from BlackImageUrl where id >" + maxLastImgUrlId).list();
        for (Object o: list) {
            BlackImageUrl biu = (BlackImageUrl) o;
            if (biu.getId() > maxLastImgUrlId)
                maxLastImgUrlId = biu.getId();
            long key = getKey(biu.getUrl());
            blackImgUrls.put(key, reused);
        }

        list = session.createQuery(
                "from BlackImageLoc where id >" + maxLastSiteId).list();
        for (Object o: list) {
            BlackImageLoc bss = (BlackImageLoc) o;
            if (bss.getId() > maxLastSiteId)
                maxLastSiteId = bss.getId();
            long key = getKey(bss.getUrl());
            blackSites.put(key, reused);
        }
        LOG.info("Update data base take " + (System.currentTimeMillis() - beginTime) + " ms");
    }

    /**
     * Check the image need to be filtered
     * 
     * @param imgUrl
     * @return
     */
    public boolean checkImg(String imgUrl) {
        String host = UrlUtils.getHostFromUrl(imgUrl);
        long urlKey = getKey(imgUrl);
        long hostKey = getKey(host);
        return blackSites.containsKey(hostKey)
                || blackImgUrls.containsKey(urlKey);
    }

}
