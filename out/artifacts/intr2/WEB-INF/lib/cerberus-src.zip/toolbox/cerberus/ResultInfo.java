package toolbox.cerberus;

import java.util.Arrays;

import toolbox.collections.ArrayUtils;


/**
 * Information about query result needed by checker.
 * @author river
 *
 */
public class ResultInfo implements IResultInfo {
    private String [] urls;
    private String [] titles;
    private String [] snippets;
    private boolean [] pass;
    private int size;

    /**
     * Create result info with initial capacity.
     * @param initCapacity
     */
    public ResultInfo(int initCapacity) {
        urls = new String[initCapacity];
        titles = new String[initCapacity];
        snippets = new String[initCapacity];
        pass = new boolean[initCapacity];
        size = 0;
    }
    
    /**
     * Reset passed to true and clean all the result info.
     */
    public void clear() {
        Arrays.fill(urls, null);
        Arrays.fill(titles, null);
        Arrays.fill(snippets, null);
        Arrays.fill(pass, true);
        size = 0;
    }

    /**
     * Add one query result entry, the size of array should be doubled
     * if no more free space.
     * @param url
     * @param title
     * @param snippet
     */
    public void addEntry(String url, String title, String snippet) {
        if (urls.length <= size) {
            int newSize = urls.length << 1;
            urls = ArrayUtils.expand(urls, newSize);
            titles = ArrayUtils.expand(titles, newSize);
            snippets = ArrayUtils.expand(snippets, newSize);
            pass = ArrayUtils.expand(pass, newSize);
        }
        
        urls[size] = url;
        titles[size] = title;
        snippets[size] = snippet;
        pass[size] = true;
        size ++;
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#getSize()
     */
    public int getSize() {
        return size;
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#getSnippet(int)
     */
    public String getSnippet(int index) {
        return snippets[index];
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#getTitle(int)
     */
    public String getTitle(int index) {
        return titles[index];
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#getUrl(int)
     */
    public String getUrl(int index) {
        return urls[index];
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#isPassed(int)
     */
    public boolean isPassed(int index) {
        return pass[index];
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#setPassed(int)
     */
    public void setPassed(int index, boolean value) {
        pass[index] = value;
    }

    /* (non-Javadoc)
     * @see toolbox.cerberus.IResultInfo#setAllPassed(boolean)
     */
    public void setAllPassed(boolean value) {
        Arrays.fill(pass, value);
    }
    
}
