/**
 * @(#)XmlUtils.java, 2007-5-30. Copyright 2007 Yodao, Inc. All rights reserved.
 *                    YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license
 *                    terms.
 */
package toolbox.cerberus.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * 解析和保存xml的工具.
 * 
 * @author river
 */
public class XmlUtils {

    /**
     * 解析一个文件成为dom对象.
     * 
     * @param file
     * @return
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     */
    public static Document parse(File file)
            throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance()
                .newDocumentBuilder();
        return builder.parse(file);
    }

    /**
     * 保存一个dom对象到文件中.
     * 
     * @param file
     * @param doc
     * @throws TransformerConfigurationException
     * @throws TransformerException
     */
    public static void save(File file, Document doc)
            throws TransformerConfigurationException, TransformerException,
            IOException {
        TransformerFactory factory = TransformerFactory.newInstance();

        // BE CAREFUL:this function is only available in java version 1.5 or
        // later.
        // 设置缩进
//        factory.setAttribute("indent-number", new Integer(2));
        Transformer transformer = factory.newTransformer();
        String encode = "utf8";
        transformer.setOutputProperty(OutputKeys.ENCODING, encode);
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        doc.normalize();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file), encode)));
        transformer.transform(source, result);
        result.getWriter().close();

    }

    /**
     * Create an empty document
     * 
     * @return
     * @throws ParserConfigurationException
     */
    public static Document createEmptyDocument(String rootTagName) throws ParserConfigurationException {
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .newDocument();
        Element rootElem = doc.createElement(rootTagName);
        doc.appendChild(rootElem);
        return doc;

    }
    
    /**
     * get Root Elem 'text child content 
     * @param rootElem
     * @param tagName
     * @return
     */
    public static String  getRootAttrValue(Element rootElem, String tagName) {
            NodeList nodeList = rootElem.getElementsByTagName(tagName);
            if (nodeList != null && nodeList.getLength() > 0) {
                    return ((Element) nodeList.item(0)).getTextContent();
            }
            return null;

    }

}
