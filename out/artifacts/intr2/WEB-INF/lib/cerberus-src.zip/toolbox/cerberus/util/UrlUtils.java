/**
 * @(#)UrlUtils.java, Jul 12, 2007. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.util;

/**
 *
 * @author likui
 *
 */
public class UrlUtils {

	/**
	 * remove "http://" in url prefix.
	 * @param url
	 * @return
	 */
	public static String removeUrlPrefix(String url) {
		if(url == null)
			return null;
		if (url.startsWith("http://")) {
			url = url.substring(7);
		} else if (url.startsWith("https://")) {
			url = url.substring(8);
		}
		return url;
	}
	
	/**
	 * Is url contains url-pattern in meaning of site.
	 * eg "it.sohu.com" contians pattern "sohu.com",versa not. 
	 * @param pattern
	 * @param url
	 * @return
	 */
	public static boolean isContainUrl(String pattern, String url) {
		url = url.toLowerCase();
//		url = removeUrlPrefix(url);
		pattern = pattern.toLowerCase();
		if (url.contains(pattern)) {
			//compare host name.
			String[] parts1 = url.split("/");
			String[] parts2 = pattern.split("/");
			if (parts1[0].endsWith(parts2[0])) {
				if (parts1[0].length() > parts2[0].length()) {
					int pos = parts1[0].length() - parts2[0].length() - 1;
					if (parts1[0].charAt(pos) != '.')
						return false;
				}
				//TODO:to be exactly implemented.
				return true;
			}
		}
		return false;
	}

	/** 
	 * Normalize url:remove prefix and last '/' in url. 
	 * @param url
	 * @return
	 */
	public static String normalizeUrl(String url) {
		if (url == null || url.length() < 1)
			return url;
		url = url.toLowerCase().trim();
		url = removeUrlPrefix(url); 
                url = removeSpecialChar(url);
                if (url == null || url.length() < 1)
                        return url;
		if (url.charAt(url.length() - 1) == '/')
			return url.substring(0, url.length() - 1);
		return url;
	}
        
        public static String removeSpecialChar(String url){
           return url.replace("&amp;", "&");
        }
}
