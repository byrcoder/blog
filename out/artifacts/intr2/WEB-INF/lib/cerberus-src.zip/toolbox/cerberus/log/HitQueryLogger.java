/**
 * @(#)HitQueryLogger.java, 2007-6-28. Copyright 2007 Yodao, Inc. All rights
 *                          reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                          subject to license terms.
 */
package toolbox.cerberus.log;

import org.apache.log4j.Logger;

/**
 * 记录命中日志
 * @author likui
 */
public class HitQueryLogger {
    static Logger LOG = Logger.getLogger(HitQueryLogger.class);

    public static void logRecord(LogUnit unit) {
        if(unit.isLogFlag())
            LOG.debug(unit.toString());
    }

    public static void main(String[] args) {
        LogUnit unit = new LogUnit();
        unit.setIp("192.1.1.1");
        unit.setLanguage("1");
        unit.setType("1");
        unit.setRuleId("1");
        unit.setEncode("01");
        unit.setUrl("www.yodao.com");
        unit.setSummary("aaaa");
        unit.setQuery("test");
        unit.setTime("111");
        for (int i = 0; i < 10000; i++) {
            logRecord(unit);
            // UnHitQueryLogger.logRecord(unit);
            // HitSummaryLogger.logRecord(unit);
            try {
                Thread.sleep(40);
            } catch (Exception e) {

            }

        }
    }
}
