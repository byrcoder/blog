/**
 * @(#)MatchType.java, 2009-2-23. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.cerberus.advance;

/**
 *
 * @author blueboat
 *
 */
public enum MatchType {
    EQUAL, SUB 
}
