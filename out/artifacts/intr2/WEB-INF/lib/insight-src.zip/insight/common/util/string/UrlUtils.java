/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-20
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.normalizer.url.UrlNormalizer;

import insight.common.helper.LogHelper;

/**
 * url工具
 * <li>encode/decode</li>
 * <li>url的归一化处理</li>
 * <li>获得url中参数的值</li>
 */
public class UrlUtils extends toolbox.misc.net.UrlUtils {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(UrlUtils.class);

    //-- properties --//
    //-- constructors --//

    private static UrlUtils singleton = new UrlUtils();

    /** 获得singleton */
    public static UrlUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//

    private static String getParameter(String url, Pattern p) {
        Matcher m = p.matcher(url);

        if (m.find()) {
            int start = m.start(2);
            int end = m.end(2);
            return url.substring(start, end);
        } else {
            return null;
        }
    }

    //-- utils --//

    /** 编码, utf-8 */
    public static String getURLEncoded(String s) {
        return getURLEncoded(s, "UTF-8");
    }

    /** 编码, 指定字符集 */
    public static String getURLEncoded(String s, String charset) {
        try {
            return URLEncoder.encode(s, charset);
        } catch (UnsupportedEncodingException e) {
            LOG.warningThis("getURLEncoded failed: " + s);
            return s;
        }
    }

    /** 解码, utf-8 */
    public static String getURLDecoded(String s) {
        return getURLDecoded(s, "UTF-8");
    }

    /** 解码, 指定字符集 */
    public static String getURLDecoded(String s, String charset) {
        try {
            return URLDecoder.decode(s, charset);
        } catch (UnsupportedEncodingException e) {
            LOG.warningThis("getURLDecoded failed: " + s);
            return s;
        }
    }

    /**
     * URL归一化
     * <li>需要自行确保url确实是一个url</li>
     * <li>如果归一化失败, 会返回原字符串</li>
     */
    public static String getURLNormalized(String url) {
        try {
            return UrlNormalizer.normalizeUrl(url);
        } catch (MalformedURLException e) {
            LOG.warningThis("normalizeUrl failed: " + url);
            return url;
        }
    }

    /** 从一个url中获得key对应的参数 */
    public static String getParameter(String url, String key) {
        Pattern p = Pattern.compile("http://.*?/([^/]*?)[\\?&]" + key + "=([^&]*?)(&|$)", Pattern.CASE_INSENSITIVE);
        return getParameter(url, p);
    }

    public static final Pattern pKeyfrom =
        Pattern.compile("http://.*?/([^/]*?)[\\?&]keyfrom=([^&]*?)(&|$)", Pattern.CASE_INSENSITIVE);

    /** 从一个url中获得keyfrom参数 */
    public static String getKeyfrom(String url) {
        return getParameter(url, pKeyfrom);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
