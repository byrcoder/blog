/** MailInfoLite */
package insight.common.mail;

/** mail数据结构 */
class MailInfoLite {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private String fromName = null;
    private String fromEmail = null;
    private String toEmail = null;

    private String subject = null;
    private String body = null;
    private boolean isHtml = false;

    //-- constructors --//

    public MailInfoLite(
        String fromName, String fromEmail, String toEmail,
        String subject, String body, boolean isHtml) {

        setFromName(fromName);
        setFromEmail(fromEmail);
        setToEmail(toEmail);
        setSubject(subject);
        setBody(body);
        setHtml(isHtml);
    }

    //-- destructors --//
    //-- implements --//

    @Override
    public String toString() {
        return "mail ~ to: " + getToEmail() + ", subject: " + getSubject();
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//

    public String getFromEmail() {
        return fromEmail;
    }

    private void setFromEmail(String fromEmail) {
        this.fromEmail = fromEmail;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public String getBody() {
        return body;
    }

    private void setBody(String body) {
        this.body = body;
    }

    public boolean isHtml() {
        return isHtml;
    }

    private void setHtml(boolean isHtml) {
        this.isHtml = isHtml;
    }

    public String getSubject() {
        return subject;
    }

    private void setSubject(String subject) {
        this.subject = subject;
    }

    public String getToEmail() {
        return toEmail;
    }

    private void setToEmail(String toEmail) {
        this.toEmail = toEmail;
    }

    //-- iWritables --//
    //-- inner classes --//
}
