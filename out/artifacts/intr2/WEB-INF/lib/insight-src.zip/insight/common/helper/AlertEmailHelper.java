/** AlertEmailHelper */
package insight.common.helper;

import insight.common.mail.MailInfo;
import insight.common.mail.MailSender;

/**
 * 用于报警静态帮助类
 * <li>需要初始化: {@link #init(String, String)}</li>
 */
public class AlertEmailHelper {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private static String alertName = null;
    private static String alertAddress = null;

    private static MailSender mailSender = null;

    //-- constructors --//

    private AlertEmailHelper() {}

    /**
     * 初始化AlertEmailHelper
     * <li>address建议使用xxx@noreply.youdao.com, 以避免自动回复</li>
     * <li>多次初始化时, 以第一次init时的name和addr为准</li>
     * <li>初始化失败时可能会抛出RuntimeException</li>
     */
    public static void init(String name, String address) {
        if (mailSender == null) {
            alertName = name;
            alertAddress = address;
            initMailSender();
        }
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//

    private static void initMailSender() {
        mailSender = new MailSender();
        mailSender.init();
    }

    //-- utils --//

    /**
     * 报警, 非html
     *
     * @see #alert(String, String, String, boolean)
     */
    public static void alert(String to, String subject, String body) {
        alert(to, subject, body, false);
    }

    /** 报警, 可选是否html */
    public static void alert(String to, String subject, String body, boolean html) {
        MailInfo mail = new MailInfo(
            alertName, alertAddress, to,
            subject, body, html,
            null, null, null);
        mailSender.sendMail(mail);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
