/** AbstractRpcService */
package insight.common.rpc2;

import odis.rpc2.RpcException;

import insight.common.helper.LogHelper;
import insight.common.rpc2.report.AbstractRpcReport;

/**
 * RpcService抽象类
 * <p/>
 * 可以在shutdown时进行一些清理操作的抽象rpc服务:
 * <li>如果服务不能直接kill, 需要调用shutdown, 则需要在实例的init方法中调用addShutdownHook方法, 同时实现doShutdown方法</li>
 * <li>如果服务可以直接kill, 则不需要在实例的init方法中调用addShutdownHook方法, 同时将doShutdown方法设为空方法</li>
 */
public abstract class AbstractRpcService extends AbstractRpcReport implements IRpcService {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(AbstractRpcService.class);

    //-- properties --//

    private Thread shutdownHook = null;

    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    @Override
    public final void shutdown(String key) throws RpcException {
        tryShutdown();

        if (shutdownHook != null) {
            Runtime.getRuntime().removeShutdownHook(shutdownHook);
        }
        System.exit(0);
    }

    //-- un-implements --//

    /** 服务器被kill或shutdown时需要做的清理工作 */
    protected abstract void doShutdown() throws RpcException;

    //-- methods --//

    protected final void addShutdownHook() {
        shutdownHook = new ShutdownHook();
        Runtime.getRuntime().addShutdownHook(shutdownHook);
    }

    //-- functions --//

    private void tryShutdown() throws RpcException {
        try {
            doShutdown();
        } catch (RpcException e) {
            String message = "doShutdown failed with RpcException";
            LOG.warningThis(message, e);
            throw e;
        } catch (Exception e) {
            String message = "doShutdown failed with unknown Exception";
            LOG.warningThis(message, e);
            throw new RpcException(message, e);
        }
    }

    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//

    private class ShutdownHook extends Thread {
        @Override
        public void run() {
            try {
                tryShutdown();
            } catch (RpcException e) {
                // do nothing
            }
        }
    }
}
