/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-09-23
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.mail;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import insight.common.helper.LogHelper;
import insight.common.util.ArrayUtils;
import insight.common.util.StringUtils;
import insight.common.util.string.ValidateUtils;

/**
 * 同步发送邮件的MailSender(不带pool)
 * <li>同步是指, 直到邮件发送出去才返回</li>
 * <li>use163mail为true时, 使用公共smtp服务器</li>
 * <li>use163mail为false是, 使用smtpServer</li>
 */
public class MailSender {

    //-- public finals --//
    //-- private finals --//

    private final static LogHelper LOG = LogHelper.getLogger(MailSender.class);

    private final static String SERVER_163 = "10.169.0.237"; // 220.181.8.38的内网ip

    /*
    private final static String SERVER_YOUDAO = "soda.rd.netease.com";
    private final static String USERNAME_YOUDAO = "formula";
    private final static String PASSWORD_YOUDAO = "abc123";
    */

    //-- properties --//

    private boolean use163mail = true;

    private String smtpServer = null;
    private String username = null;
    private String password = null;

    private JavaMailSender sender = null;

    //-- constructors --//

    /** 初始化 */
    public void init() {
        if (use163mail) {
            sender = getSender(SERVER_163, null, null);
        } else {
            sender = getSender(smtpServer, username, password);
        }
    }

    private JavaMailSender getSender(
        String host, String username, String password) {

        JavaMailSenderImpl aSender = new JavaMailSenderImpl();

        aSender.setHost(host);
        Properties properties = new Properties();
        if (!StringUtils.isBlank(password)) {
            properties.put("mail.smtp.auth", "true");
            aSender.setUsername(username);
            aSender.setPassword(password);
        }
        aSender.setJavaMailProperties(properties);
        aSender.setDefaultEncoding("utf-8");

        return aSender;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//

    /** 发送邮件(同步) */
    public boolean sendMail(MailInfo mail) {
        try {
            doSend(mail);
            return true;
        } catch (Exception e) {
            LOG.warningThis("doSend failed", e);
            return false;
        }
    }

    //-- functions --//

    private void doSend(MailInfo mail) throws MessagingException, UnsupportedEncodingException {
        LOG.warningThis(mail.toString());

        MimeMessage mailMessage = sender.createMimeMessage();

        MimeMessageHelper messageHelper = null;

        if (StringUtils.isBlank(mail.getAttachment())) {
            messageHelper = new MimeMessageHelper(mailMessage, false);
            LOG.warningThis("no attachment");
        } else {
            messageHelper = new MimeMessageHelper(mailMessage, true);
            LOG.warningThis("attachment: " + mail.getAttachment());

            File file = new File(mail.getAttachment());
            messageHelper.addAttachment(file.getName(), file);
        }

        messageHelper.setTo(getEmails(mail.getToEmail()));
        if (!StringUtils.isBlank(mail.getCc())) {
            messageHelper.setCc(getEmails(mail.getCc()));
        }
        if (!StringUtils.isBlank(mail.getBcc())) {
            messageHelper.setBcc(getEmails(mail.getBcc()));
        }
        messageHelper.setFrom(mail.getFromEmail(), mail.getFromName());
        messageHelper.setSubject(mail.getSubject());
        messageHelper.setText(mail.getBody(), mail.isHtml());

        sender.send(mailMessage);
    }

    //-- utils --//

    /**
     * 获得用分号或逗号分隔的email
     * <li>连续的分隔符会被正处理(被忽略)</li>
     */
    public static String[] getEmails(String s) {
        if (StringUtils.isBlank(s)) {
            return null;
        }
        List<String> resultList = new ArrayList<String>();

        int start = 0;
        while (start < s.length()) {
            int end = start;
            // 找到一个分隔符(或字符串结尾)
            for (; end < s.length(); end++) {
                if (s.charAt(end) == ';' || s.charAt(end) == ',') {
                    break;
                }
            }
            if (start != end) {
                String email = s.substring(start, end);
                /** TODO: 使用{@link insight.common.util.string.ValidateUtils#isEmail(String)} */
                if (email.indexOf('@') != -1) {
                    resultList.add(email);
                    if (!ValidateUtils.isEmail(email)) {
                        LOG.warningThis("hidden invalid email: " + email);
                    }
                } else {
                    LOG.warningThis("invalid email: " + email);
                }
            }
            start = end + 1;
        }

        return ArrayUtils.list2Array(resultList);
    }

    //-- getters & setters --//

    public void setUse163mail(boolean use163mail) {
        this.use163mail = use163mail;
    }

    public void setSmtpServer(String smtpServer) {
        this.smtpServer = smtpServer;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    //-- iWritables --//
    //-- inner classes --//
}
