/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-07-13
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.rpc2;

import odis.rpc2.RpcException;

/** 用于关闭Rpc服务 */
public class Shutdown {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private Shutdown() {}

    //-- destructors --//
    //-- implements --//

    public static void main(String[] args) throws RpcException {
        String host = args[0];
        String sPort = args[1];
        int port = Integer.parseInt(sPort);

        IRpcService service = (IRpcService) RpcProxyFactory.getFactory().getProxy(IRpcService.class, host, port);
        service.shutdown(null);
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
