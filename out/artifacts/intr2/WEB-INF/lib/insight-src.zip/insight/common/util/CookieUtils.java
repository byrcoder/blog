/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-07-06
 * <p/>
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import toolbox.web.CookieUtil;

/**
 * cookie工具
 * <li>扩展了toolbox.web.CookieUtil</li>
 */
public class CookieUtils extends CookieUtil {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static CookieUtils singleton = new CookieUtils();

    /** 获得singleton */
    public static CookieUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 需要自行保证name的正确性
     * <li>当存在重名的cookie时, 返回第一个</li>
     */
    public static Cookie getCookie(HttpServletRequest request, String name) {
        return findCookie(request, name);
    }

    /**
     * 需要自行保证name和value的正确性
     * <li>value可以为null</li>
     * <li>domain为null时, 设置为当前domain; 为null时, testcase通不过但实际执行似乎没问题</li>
     * <li>path为null时, 设置为当前path; 注意: 这个path不是controller(servletPath)</li>
     * <li>age > 0 -> cookie, 单位为秒</li>
     * <li>age = 0 -> remove cookie</li>
     * <li>age < 0 -> session cookie</li>
     */
    public static void addCookie(HttpServletResponse response, String name, String value, String domain, String path, int age) {
        Cookie cookie = new Cookie(name, value);
        cookie.setDomain(domain);
        cookie.setPath(path);
        cookie.setMaxAge(age);
        response.addCookie(cookie);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
