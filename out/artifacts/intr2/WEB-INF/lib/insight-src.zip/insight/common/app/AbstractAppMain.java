/** AbstractAppMain */
package insight.common.app;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;

/**
 * AppMain抽象类
 * <li>调用AppMain实例中实现了的getOptions()</li>
 * <li>使用common-cli解析options和args, 生成cmdLine</li>
 * <li>调用AppMain实例中实现了的doMain(CommandLine cmdLine)</li>
 */
public abstract class AbstractAppMain implements IAppMain {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    @Override
    public final void doMain(String[] args) throws Exception {
        Options options = getOptions();
        if (options == null) {
            options = new Options();
        }

        CommandLineParser parser = new PosixParser();
        CommandLine cmdLine = parser.parse(options, args);
        doMain(cmdLine);
    }

    //-- un-implements --//

    protected abstract Options getOptions();

    protected abstract void doMain(CommandLine cmdLine) throws Exception;

    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
