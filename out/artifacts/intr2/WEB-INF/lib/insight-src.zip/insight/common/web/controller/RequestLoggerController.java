/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-09-29
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import insight.common.util.StringUtils;

/**
 * 用于记录log的url(rl.do)
 * <li>将页面传来的log发送到logsink</li>
 */
public class RequestLoggerController extends SprivelController {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    protected String category = null;

    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    @Override
    public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        sessionFromFilter(request, response);

        if (!StringUtils.isBlank(category)) {
            logger.log(category, request, response);
        }
        return null;
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//

    public void setCategory(String category) {
        this.category = category;
    }

    //-- iWritables --//
    //-- inner classes --//
}
