/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-20
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

import org.apache.commons.lang.StringEscapeUtils;
import org.json.simple.JSONValue;

/**
 * json工具
 * <li>escape/unescape</li>
 */
public class JsonUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static JsonUtils singleton = new JsonUtils();

    /** 获得singleton */
    public static JsonUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 没有使用{@link org.apache.commons.lang.StringEscapeUtils#escapeJavaScript(String)}, 因为它会转义中文
     *
     * @see org.json.simple.JSONValue#escape(String)
     */
    public static String escapeJson(String str) {
        return JSONValue.escape(str);
    }

    /** @see org.apache.commons.lang.StringEscapeUtils#unescapeJavaScript(String) */
    public static String unescapeJson(String str) {
        return StringEscapeUtils.unescapeJavaScript(str);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
