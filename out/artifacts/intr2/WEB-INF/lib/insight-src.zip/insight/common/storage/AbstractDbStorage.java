/** AbstractDbStorage */
package insight.common.storage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import insight.common.helper.LogHelper;

/** 抽象db存储类 */
public abstract class AbstractDbStorage {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(AbstractDbStorage.class);

    //-- properties --//

    protected DataSource dataSource = null;

    //-- constructors --//
    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//

    /** 获得连接 */
    public Connection getConnection() throws StorageException {
        try {
            return dataSource.getConnection();
        } catch (SQLException e) {
            String message = LOG.warningThis("getConnection failed", e);
            throw new StorageException(message, e);
        }
    }

    //-- functions --//
    //-- utils --//

    /** 关闭连接 */
    protected static void closeConnection(Connection conn) {
        MySqlUtils.closeConnection(conn);
    }

    /** 关闭statement */
    protected static void closeStatement(Statement stat) {
        MySqlUtils.closeStatement(stat);
    }

    /** 关闭resultset */
    protected static void closeResultSet(ResultSet rst) {
        MySqlUtils.closeResultSet(rst);
    }

    //-- getters & setters --//

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    //-- iWritables --//
    //-- inner classes --//
}
