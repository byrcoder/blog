/** DnsClientHelper */
package insight.common.helper;

import java.util.List;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;

import toolbox.misc.net.DnsClient;

import insight.common.util.ArrayUtils;

/**
 * 用于生成(获得)DnsClient的静态帮助类
 * <li>从配置文件(dns.xml)中得到一个DNSServer的地址列表, 并根据这个列表初始化一个DnsClient</li>
 */
public class DnsClientHelper {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(DnsClientHelper.class);

    private static final String CONFIG_FILE = "dns.xml";

    //-- properties --//

    private static DnsClient client = null;

    //-- constructors --//

    private DnsClientHelper() {}

    private static void init() {
        // 从config文件读取参数
        Configuration config = null;
        try {
            config = ConfigurationHelper.getConfig(CONFIG_FILE);
        } catch (ConfigurationException e) {
            throw new RuntimeException("getConfig failed", e);
        }

        @SuppressWarnings("unchecked")
        List<String> serverList = config.getList("servers");

        // 配置中找不到DNSServer地址列表时，使用操作系统配置的默认列表
        if (serverList.size() == 0) {
            LOG.warningThis("cannot find DNS in " + CONFIG_FILE + ", try loadSystemSetting");
            DnsClient.loadSystemSetting(serverList);
            // 如果操作系统配置的默认列表中也找不到
            if (serverList.size() == 0) {
                LOG.warningThis("cannot find DNS in loadSystemSetting");
                throw new RuntimeException("no DNS found");
            }
        }
        String[] serverArray = serverList.toArray(new String[serverList.size()]);

        long initialTimeout = config.getLong("initial-timeout", -1);
        int retries = config.getInt("retries", -1);

        // 打印DNS Server的信息和Client连接参数
        LOG.warningThis("DNS servers at " + ArrayUtils.toString(serverArray));
        LOG.warningThis("DNS initialTimeout is " + initialTimeout);
        LOG.warningThis("DNS retries is " + retries);

        // 初始化DNSClient
        client = new DnsClient(serverArray);
        if (initialTimeout > 0) {
            client.setInitialTimeout(initialTimeout);
        } if (retries > 0) {
            client.setRetries(retries);
        }
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//

    /**
     * 取得DNSClient
     * <li>如果不存在, 则根据dns.xml初始化一个</li>
     * <li>初始化时可能抛出RuntimeException</li>
     */
    public static DnsClient getDnsClient() {
        if (client == null) {
            init();
        }
        return client;
    }

    /** for test only */
    public static void setDnsClient(DnsClient client) {
        DnsClientHelper.client = client;
    }

    //-- iWritables --//
    //-- inner classes --//
}
