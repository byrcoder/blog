/** AbstractRpcReport */
package insight.common.rpc2.report;

import java.net.InetAddress;
import java.net.UnknownHostException;

import odis.rpc2.RpcException;

/**
 * RpcReport抽象类
 * <li>提供默认的report方法, 可以被重写; 重写时需要调用super.report()以获得包含name的RpcStatus</li>
 * <li>需要setPort, 因为该抽象类无法从实例中直接得到端口</li>
 */
public abstract class AbstractRpcReport implements IRpcReport {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private int port = 0;

    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    @Override
    public RpcStatus report() throws RpcException {
        RpcStatus rpcStatus = RpcStatus.createRunning();
        rpcStatus.addInfo("name", getName());

        return rpcStatus;
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//

    private String getName() {
        String desc = this.getClass().getSimpleName() + "@";
        try {
            desc += InetAddress.getLocalHost().getHostName() + ":" + port;
        } catch (UnknownHostException e) {
            desc += "unknown";
        }
        return desc;
    }

    //-- utils --//
    //-- getters & setters --//

    public final void setPort(int port) {
        this.port = port;
    }

    //-- iWritables --//
    //-- inner classes --//
}
