/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-10-10
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.mail;

import java.io.IOException;
import java.util.HashMap;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.ui.velocity.VelocityEngineFactory;

import insight.common.helper.LogHelper;

/**
 * 渲染邮件用的基类
 * <li>实际作用是渲染vm, 不仅限于邮件</li>
 */
public abstract class MailRender {

    //-- public finals --//
    //-- private finals --//

    private final static LogHelper LOG = LogHelper.getLogger(MailRender.class);

    //-- properties --//

    protected VelocityEngine engine = null;

    //-- constructors --//

    /**
     * @param vmPath vm文件所在路径
     * 如: System.getProperty(InsightDispatcherServlet.SERVLET_HOME) + "/vm/mail"
     */
    public void init(String vmPath) {
        VelocityEngineFactory factory = new VelocityEngineFactory();

        LOG.warningThis("vmPath: " + vmPath);
        factory.setResourceLoaderPath("file:" + vmPath);

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("input.encoding", "UTF-8");
        map.put("output.encoding", "UTF-8");
        map.put("directive.foreach.counter.initial.value", "0");
        factory.setVelocityPropertiesMap(map);

        try {
            engine = factory.createVelocityEngine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
