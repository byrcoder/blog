/** VaqueroHelper */
package insight.common.helper;

import insight.common.util.TimeUtils;

/** 输出vaquero-log的静态类 */
public class VaqueroHelper {

    //-- public finals --//

    public final static String PREFIX = "@@ANALYSIS@@";

    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(VaqueroHelper.class);

    //-- properties --//
    //-- constructors --//

    private VaqueroHelper() {}

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /** 输出log, 记录key=value */
    public static String log(String key, long value) {
        return LOG.warningThis(String.format("%s %s=%d", PREFIX, key, value));
    }

    /**
     * 输出log, 记录key=now-start
     * <li>主要用于计时(或仅用于计时)</li>
     */
    public static String logNow(String key, long start) {
        return log(key, TimeUtils.getTimeCost(start));
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
