/** LogLoader */
package insight.common.requestlog;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import odis.file.SequenceFile;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.TimeWritable;
import odis.serialize.lib.UTF8Writable;

import insight.common.helper.LogHelper;
import insight.common.helper.OdfsAdapter;
import insight.common.util.TimeUtils;

/**
 * 用于从ODFS读取request-log
 * <li>构造后需要初始化: {@link #init()}</li>
 * <li>读取的最小单位为1天</li>
 */
public class LogLoader {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(LogLoader.class);

    //-- properties --//

    private String odfsName = null;
    private int odfsPort = -1;

    /* 重写loadLog/loadFromLocal/loadFromOdfs时使用 */

    protected IFileSystem fs = null;

    protected String odfsPath = "/request-log/Product";
    protected String prefix = "Product.";
    protected String localPath = "request-log";
    protected String postfix = ".a";

    protected ILogProcessor processor = null;

    //-- constructors --//

    /** 仅用于构造bean */
    public LogLoader() {}

    /**
     * 读取tiger:7080/request-log/Product/ProductX.yyyyMMdd00~23
     *
     * @param odfsName 如tiger
     * @param odfsPort 如8080
     * @param odfsPath 如/request-log/Product
     * @param prefix 如ProductX
     * @param localPath 存放dump出来的的文件的位置, 如request-log
     * @param postfix 为dump出来的文件增加后缀
     * @param processor 处理log用的processor
     */
    public LogLoader(
        String odfsName, int odfsPort,
        String odfsPath, String prefix,
        String localPath, String postfix,
        ILogProcessor processor
    ) {
        setOdfsName(odfsName);
        setOdfsPort(odfsPort);
        setOdfsPath(odfsPath);
        setPrefix(prefix);
        setProcessor(processor);
        setLocalPath(localPath);
        setPostfix(postfix);
    }

    /** 初始化 */
    public void init() {
        fs = OdfsAdapter.getFs(odfsName, odfsPort);
        if (fs == null) {
            throw new RuntimeException("init failed ~ fs == null");
        }
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//

    /** 判断对象是否相等, 仅用于测试 */
    boolean equalTo(LogLoader loader) {
        return odfsName.equals(loader.odfsName) && odfsPort == loader.odfsPort
            && odfsPath.equals(loader.odfsPath) && prefix.equals(loader.prefix)
            && localPath.equals(loader.localPath) && postfix.equals(loader.postfix)
            && ((processor == null && loader.processor == null)
            || (processor != null && loader.processor != null));
    }

    /** @param simpleDate such as 20110101 */
    public void loadDayLog(String simpleDate) {
        if (fs == null) {
            throw new RuntimeException("loadDayLog failed ~ fs == null");
        }

        loadDayLog(fs, simpleDate);
    }

    /** 可以被重写, 以定制某些过滤条件 */
    protected void loadLog(IFileSystem fs, String time) throws IOException {

        String name = odfsPath + File.separator + prefix + time;
        Path file = new Path(name);

        String localName = localPath + File.separator + prefix + time + postfix;
        File localFile = new File(localName);

        File localFolder = new File(localPath);
        if (!localFolder.exists()) {
            if (!localFolder.mkdir()) {
                throw new RuntimeException("loadLog failed ~ create localFolder failed");
            }
        }

        if (localFile.exists()) {
            loadFromLocal(localFile);
        } else if (fs.exists(file)) {
            if (localFile.createNewFile()) {
                PrintWriter pw = new PrintWriter(localFile);
                loadFromOdfs(fs, file, pw);
                pw.close();
            } else {
                LOG.warningThis("create file failed: " + localName);
            }
        } else {
            LOG.warningThis("file does not exist: " + name);
        }
    }

    /** 可以被重写, 以定制某些过滤条件 */
    protected void loadFromLocal(File f) throws IOException {
        LOG.warningThis("now analyzing local: " + f.getAbsolutePath());
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String buffer = null;
        while ((buffer = br.readLine()) != null) {
            String[] elements = buffer.split(",", 2);
            processor.process(Long.parseLong(elements[0]), elements[1]);
        }
        br.close();
        fr.close();
    }

    /** 可以被重写, 以定制某些过滤条件 */
    protected void loadFromOdfs(IFileSystem fs, Path path, PrintWriter pw) throws IOException {
        LOG.warningThis("now analyzing odfs: " + path.getAbsolutePath());
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, path);
        TimeWritable time = new TimeWritable();
        UTF8Writable s = new UTF8Writable();
        while (reader.next(time, s)) {
            String log = s.get();
            long ts = time.get();
            processor.process(ts, log);
            if (pw != null) {
                pw.println(ts + "," + log);
            }
        }
        reader.close();
    }

    //-- functions --//

    private void loadDayLog(IFileSystem fs, String simpleDate) {
        for (int i = 0; i < 24; i++) {
            String hour = (i < 10) ? ("0" + i) : ("" + i);
            String time = simpleDate + hour;
            try {
                loadLog(fs, time);
            } catch (IOException e) {
                LOG.warningThis("load " + time + " failed");
            }
        }
    }

    //-- utils --//

    /**
     * 获得start到end之间(闭区间)的日期列表(SimpleDate)
     * <li>如20110101到20110104之间的列表为01/02/03/04</li>
     * <li>需要自行保证参数正确性: end在start之后</li>
     */
    public static List<String> getSimpleDates(String start, String end) {
        long time = TimeUtils.parseSimpleDate(start);
        long endTime = TimeUtils.parseSimpleDate(end);
        List<String> dates = new ArrayList<String>();
        while (time <= endTime) {
            dates.add(TimeUtils.getSimpleDate(time));
            time += TimeUtils.DAY_MILLIS;
        }
        return dates;
    }

    //-- getters & setters --//

    public void setOdfsName(String odfsName) {
        this.odfsName = odfsName;
    }

    public void setOdfsPort(int odfsPort) {
        this.odfsPort = odfsPort;
    }

    public void setOdfsPath(String odfsPath) {
        this.odfsPath = odfsPath;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    public void setPostfix(String postfix) {
        this.postfix = postfix;
    }

    public void setProcessor(ILogProcessor processor) {
        this.processor = processor;
    }

    //-- iWritables --//
    //-- inner classes --//
}
