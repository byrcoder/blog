/** RpcProxyFactory */
package insight.common.rpc2;

import java.net.InetSocketAddress;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;

import insight.common.helper.LogHelper;

/**
 * 用于生成连接RpcService的对象
 * <li>getProxy</li>
 */
public class RpcProxyFactory {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(RpcProxyFactory.class);

    //-- properties --//
    //-- constructors --//

    private static RpcProxyFactory factory = new RpcProxyFactory();

    public RpcProxyFactory() {}

    public static RpcProxyFactory getFactory() {
        return factory;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//

    public Object getProxy(String className, String host, int port) {
        return getProxy(className, host, port, 0);
    }

    public Object getProxy(String className, String host, int port, long rpcTimeout) {
        Class<?> protocol = null;
        try {
            protocol = Class.forName(className);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("load class " + className + " failed", e);
        }
        try {
            return getProxy(protocol, host, port, rpcTimeout);
        } catch (RpcException e) {
            throw new RuntimeException("getProxy failed", e);
        }
    }

    public Object getProxy(Class<?> protocol, String host, int port) {
        try {
            return getProxy(protocol, host, port, 0);
        } catch (RpcException e) {
            throw new RuntimeException("getProxy failed", e);
        }
    }

    public Object getProxy(Class<?> protocol, String host, int port, long rpcTimeout) throws RpcException {
        LOG.warningThis("get RPCProxy for " + protocol + " at " + host + ":" + port + " with timeout " + rpcTimeout);
        return RPC.getProxy(protocol, new InetSocketAddress(host, port), rpcTimeout);
    }

    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
