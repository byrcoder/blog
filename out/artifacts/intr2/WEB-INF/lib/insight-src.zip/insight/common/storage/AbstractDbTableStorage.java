/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-26
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import insight.common.datastructor.Page;

/**
 * 单个table的数据库存储
 * <p/>
 * 必须有的public finals:
 * <li>TABLE_NAME</li>
 * <li>TABLE_PROPERTY</li>
 *
 * @param <T> 存储于该表中的数据类型
 */
public abstract class AbstractDbTableStorage<T> extends AbstractDbStorage {

    //-- public finals --//

    /**
     * 由于存在hsqldb不存在的操作, 写TestCase需要用MySql
     * 为了避免和已有的表名冲突, 所以使tableName变成可更改的
     */
    protected String tableName = null;
    /**
     * 由于hsqldb的limit语法和MySql不同, 所以需要这个变量
     * 使用MySql时不需要设置, 使用hsqldb时需要设置为false
     */
    protected boolean limitMod = true;

    protected Map<String, Object> typeMap = null;
    protected Map<String, Object> mutableMap = null;

    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    /**
     * 必须init的参数:
     * <li>tableName - 必须set, set之后init</li>
     * <li>typeMap/mutableMap - 需要和TABLE_PROPERTY一致</li>
     */
    protected abstract void init();

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//

    /** 用resultset构造对象T, 用于各种get方法 */
    protected abstract T getObject(ResultSet rst) throws SQLException;

    //-- methods --//

    /** @param condition 需要包括where */
    protected final int count(String condition) throws StorageException {
        condition = (condition == null) ? "" : (" " + condition.trim());

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rst = null;

        try {
            conn = getConnection();
            pst = conn.prepareStatement("SELECT COUNT(*) FROM " + tableName + condition);
            rst = pst.executeQuery();

            if (rst.next()) {
                return rst.getInt(1);
            } else {
                throw new StorageException("[SQL] count(*) failed");
            }
        } catch (SQLException e) {
            throw new StorageException("count failed", e);
        } finally {
            closeResultSet(rst);
            closeStatement(pst);
            closeConnection(conn);
        }
    }

    /** 检查id是否存在 */
    protected final boolean exist(long id) throws StorageException {
        String condition = "WHERE id = " + id;
        int count = count(condition);

        if (count == 0) {
            return false;
        } else if (count == 1) {
            return true;
        } else {
            throw new StorageException("exist failed ~ count: " + count);
        }
    }

    /** 通过id获得对象, id不存在时返回null */
    protected final T getById(long id) throws StorageException {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rst = null;

        try {
            conn = getConnection();
            pst = conn.prepareStatement("SELECT * FROM " + tableName + " WHERE id = ?");
            pst.setLong(1, id);

            rst = pst.executeQuery();

            int count = 0;
            T object = null;
            while (rst.next()) {
                count++;
                object = getObject(rst);
            }

            if (count > 1) {
                throw new StorageException("[SQL] select failed ~ count: " + count);
            } else {
                return object;
            }
        } catch (SQLException e) {
            throw new StorageException("getById failed", e);
        } finally {
            closeResultSet(rst);
            closeStatement(pst);
            closeConnection(conn);
        }
    }

    /** @param condition 需要包括where */
    protected final List<T> getList(
        String condition, String orderBy, int pageSize, int pageIndex) throws StorageException {

        condition = (condition == null) ? "" : (" " + condition.trim());
        orderBy = (orderBy == null) ? "" : (" ORDER BY " + orderBy.trim());

        int startIndex = pageSize * (pageIndex - 1);
        if (limitMod) {
            String fullCondition = condition + orderBy
                + " LIMIT " + startIndex + ", " + pageSize;
            return getList(fullCondition);
        } else {
            String fullCondition = condition + orderBy;
            String limit = "LIMIT " + startIndex + " " + pageSize;
            return getList(fullCondition, limit);
        }
    }

    /** @param condition 需要包括where */
    protected final List<T> getList(String condition) throws StorageException {
        return getList(condition, null);
    }

    /** @param condition 需要包括where */
    protected final Page<T> getPage(String condition, String orderBy, int pageSize, int pageIndex) throws StorageException {
        int total = count(condition);
        // TODO: 根据total修正pageIndex

        List<T> list = getList(condition, orderBy, pageSize, pageIndex);
        return new Page<T>(total, pageSize, pageIndex, list);
    }

    /** @param condition 不需要包括where和and */
    @SuppressWarnings("unchecked")
    protected final void updateById(
        long id, JSONObject json, String condition, boolean check) throws StorageException {

        condition = (condition == null) ? "" :
            String.format(" AND (%s)", condition.trim());

        Connection conn = null;
        PreparedStatement pst = null;

        try {
            conn = getConnection();

            StringBuilder sb = new StringBuilder();
            sb.append("UPDATE ").append(tableName);
            sb.append(" SET ");
            int i = 0;
            for (Object o : json.keySet()) {
                if (!typeMap.containsKey(o.toString())) {
                    throw new StorageException(String.format("no such column: %s!", o));
                }
                if (check && !mutableMap.containsKey(o.toString())) {
                    throw new StorageException(String.format("column %s is immutable!", o));
                }
                if (i++ > 0) {
                    sb.append(", ");
                }
                sb.append(o).append(" = ?");
            }
            sb.append(" WHERE id = ").append(id);
            sb.append(condition);
            pst = conn.prepareStatement(sb.toString());

            int j = 1;
            for (Object o : json.entrySet()) {
                Map.Entry<String, Object> pair = (Map.Entry<String, Object>) o;
                if (typeMap.get(pair.getKey()) == Integer.class) {
                    pst.setInt(j, (Integer) pair.getValue());
                } else if (typeMap.get(pair.getKey()) == Long.class) {
                    pst.setLong(j, (Long) pair.getValue());
                } else if (typeMap.get(pair.getKey()) == String.class) {
                    pst.setString(j, pair.getValue().toString());
                } else if (typeMap.get(pair.getKey()) == Double.class) {
                    pst.setDouble(j, (Double) pair.getValue());
                } else {
                    throw new StorageException("invalid type: " + o.toString());
                }
                j++;
            }

            int count = pst.executeUpdate();
            if (count == 0) {
                throw new StorageException("no such id: " + id + " or invalid condition");
            } else if (count > 1) {
                throw new StorageException("[SQL] update failed ~ count: " + count);
            }
        } catch (SQLException e) {
            throw new StorageException("updateById failed", e);
        } finally {
            closeStatement(pst);
            closeConnection(conn);
        }
    }

    //-- functions --//

    /**
     * 由于hsqldb的limit语法和MySql不同, 所以需要这个函数
     * 使用MySql时不需要设置limit, 使用hsqldb时需要设置为非null
     *
     * @param condition 需要包括where
     */
    private List<T> getList(String condition, String limit) throws StorageException {
        condition = (condition == null) ? "" : (" " + condition.trim());

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rst = null;

        try {
            conn = getConnection();
            String statement = (limit == null)
                ? ("SELECT * FROM " + tableName + condition)
                : ("SELECT " + limit + " * FROM " + tableName + condition);
            pst = conn.prepareStatement(statement);

            rst = pst.executeQuery();

            List<T> list = new ArrayList<T>();
            while (rst.next()) {
                list.add(getObject(rst));
            }
            return list;
        } catch (SQLException e) {
            throw new StorageException("getList failed", e);
        } finally {
            closeResultSet(rst);
            closeStatement(pst);
            closeConnection(conn);
        }
    }

    //-- utils --//
    //-- getters & setters --//

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setLimitMod(boolean limitMod) {
        this.limitMod = limitMod;
    }

    //-- iWritables --//
    //-- inner classes --//
}
