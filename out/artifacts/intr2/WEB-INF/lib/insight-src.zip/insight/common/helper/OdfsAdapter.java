/** OdfsAdapter */
package insight.common.helper;

import java.io.IOException;

import odis.io.FileSystem;
import odis.io.IFileSystem;

/** ODFS相关静态函数集合 */
public class OdfsAdapter {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private OdfsAdapter() {}

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /** getFs("tiger", 8080) */
    public static IFileSystem getFs(String name, int port) {
        try {
            return FileSystem.getNamed(name + ":" + port);
        } catch (IOException e) {
            return null;
        }
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
