/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-20
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

import java.io.StringWriter;

import insight.common.util.element.Entities;

/**
 * html工具
 * <li>escape/unescape</li>
 */
public class HtmlUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static HtmlUtils singleton = new HtmlUtils();

    /** 获得singleton */
    public static HtmlUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#escapeHtml(String)}</p>
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#escapeHtml(java.io.Writer, String)}</p>
     * <li>用于向页面输出html源码, 或者防止html的不正当使用(XSS)</li>
     * <li>只escape最基本的4个Entity</li>
     */
    public static String escapeHtmlLite(String str) {
        if (str == null) {
            return null;
        }

        StringWriter writer = new StringWriter((int) (str.length() * 1.5));
        Entities.HTMLLite.escape(writer, str);

        return writer.toString();
    }

    /**
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#unescapeHtml(String)}</p>
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#unescapeHtml(java.io.Writer, String)}</p>
     * <li>只unescape最基本的4个Entity</li>
     * <li>但也处理&#XX之类的unicode字符</li>
     */
    public static String unescapeHtmlLite(String str) {
        if (str == null) {
            return null;
        }

        StringWriter writer = new StringWriter(str.length());
        Entities.HTMLLite.unescape(writer, str);

        return writer.toString();
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
