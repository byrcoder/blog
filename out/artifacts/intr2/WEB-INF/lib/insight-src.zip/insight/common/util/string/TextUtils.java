/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-20
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

import org.apache.commons.lang.StringUtils;

/**
 * 文章工具
 * <li>生成摘要</li>
 */
public class TextUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static TextUtils singleton = new TextUtils();

    /** 获得singleton */
    public static TextUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 获得带...的摘要, 不会切断单词
     * <li>没有考虑换行/tab等情况</li>
     *
     * @param s 文字
     * @param length 汉字的个数(用来代表长度)
     * @return 摘要
     */
    public static String getSummary(String s, int length) {
        if (StringUtils.isBlank(s)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();

        int charCount = 0;
        int lengthCount = 0;
        int lastSpace = -1;
        int lastSingle = -1; // 上一个可以独立存在的字符, 包括标点/汉字
        int start = 0;
        int end = 0;
        for (int i = 0, l = s.length(); lengthCount <= length * 2 && i < l; i++, end++) {
            char c = s.charAt(i);
            if (CharUtils.isAsciiPrintableExtend(c)) {
                if (!CharUtils.isAsciiAlphanumericExtend(c)) {
                    lastSingle = charCount;
                    if (CharUtils.isSpace(c)) {
                        lastSpace = charCount;
                    }
                }
                charCount++;
                lengthCount += 1;
            } else if (CharUtils.isAsciiExtend(c)) {
                if (start != end) {
                    sb.append(s.substring(start, end));
                }
                start = i + 1;
            } else {
                lastSingle = charCount;
                charCount++;
                lengthCount += 2;
            }
        }
        if (start != end) {
            sb.append(s.substring(start, end));
        }

        String result = sb.toString();
        if (lengthCount <= length * 2) {
            return result;
        }

        // 到这里的result一定是超长的, 从最后一个向前找
        // 如果是连续一串字母/数字, 则从最后一个前面截断
        // 如果最后一个不是字母/数字, 则从最后一个前面截断
        // 如果最后一个是字母/数字, 则继续向前找
        // 找到一个非字母/数字的字符截断
        if (lastSpace == -1 && lastSingle == -1) {
            result = result.substring(0, charCount - 1);
        } else if (!CharUtils.isAsciiExtend(result.charAt(charCount - 1))) {
            result = result.substring(0, charCount - 1);
        } else if (lastSpace >= lastSingle) {
            result = result.substring(0, lastSpace);
        } else {
            result = result.substring(0, lastSingle + 1);
        }
        return result + "...";
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
