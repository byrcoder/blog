/** InsightDispatcherServlet */
package insight.common.web;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.springframework.web.servlet.DispatcherServlet;

import insight.common.helper.LogHelper;

/**
 * servlet
 * <li>一些初始化的工作可以放在这里, 比如设置环境变量</li>
 */
public class InsightDispatcherServlet extends DispatcherServlet {

    //-- public finals --//

    public static final String ODIS_HOME = "odis.home";

    public static final String SERVLET_HOME = "insight.servlet.home";

    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(InsightDispatcherServlet.class);

    private static final long serialVersionUID = 1L;

    //-- properties --//
    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    @Override
    public void init(ServletConfig config) throws ServletException {

        String servletHome = config.getServletContext().getRealPath("WEB-INF");

        LOG.warningThis("odisHome = " + servletHome);
        System.setProperty(ODIS_HOME, servletHome);

        LOG.warningThis("servletHome = " + servletHome);
        System.setProperty(SERVLET_HOME, servletHome);

        String debug = config.getInitParameter("debug");
        LOG.warningThis("debugMode = " + debug);
        WebServiceConfig.getConfig().setDebugMode("on".equals(debug));

        super.init(config);
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
