/** IRpcReport */
package insight.common.rpc2.report;

import odis.rpc2.RpcException;

/** RpcReport接口类 */
public interface IRpcReport {

    /** report RpcStatus */
    public RpcStatus report() throws RpcException;
}
