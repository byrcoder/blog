/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-20
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

import java.io.StringWriter;

import insight.common.util.element.Entities;

/**
 * xml工具
 * <li>escape/unescape</li>
 */
public class XmlUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static XmlUtils singleton = new XmlUtils();

    /** 获得singleton */
    public static XmlUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#escapeXml(String)}</p>
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#escapeXml(java.io.Writer, String)}</p>
     * <li>没有使用{@link org.apache.commons.lang.StringEscapeUtils#escapeXml(String)}, 因为它会转义中文</li>
     */
    public static String escapeXml(String str) {
        if (str == null) {
            return null;
        }

        StringWriter writer = new StringWriter((int) (str.length() * 1.5));
        Entities.XML.escape(writer, str);

        return writer.toString();
    }

    /**
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#unescapeXml(String)}</p>
     * <p>copy from {@link org.apache.commons.lang.StringEscapeUtils#unescapeXml(java.io.Writer, String)}</p>
     */
    public static String unescapeXml(String str) {
        if (str == null) {
            return null;
        }

        StringWriter writer = new StringWriter(str.length());
        Entities.XML.unescape(writer, str);

        return writer.toString();
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
