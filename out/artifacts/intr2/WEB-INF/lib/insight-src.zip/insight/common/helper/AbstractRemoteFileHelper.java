/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-30
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.helper;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import toolbox.web.HttpResource;

import insight.common.langwrapper.LineReader;
import insight.common.util.StringUtils;
import insight.common.util.TimeUtils;

/**
 * 读取远程文件(主要是svn上的配置文件)用的基类
 * <li>原理是通过{@link toolbox.web.HttpResource}定期检查远程文件有无变化</li>
 * <li>为了解决同步问题, 通常需要设置一组实际变量和一组temp变量</li>
 * <li>先将文件内容读取至temp变量, 再一次性赋值给实际变量</li>
 */
public abstract class AbstractRemoteFileHelper {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(AbstractRemoteFileHelper.class);

    //-- properties --//

    protected ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    protected String remoteUrl = null; // 远程文件url
    protected String localFile = null; // 本地副本文件名
    protected int interval = 10; // 定期检查的时间间隔(分钟)

    //-- constructors --//
    //-- destructors --//
    //-- implements --//
    //-- un-implements --//

    /** 初始化temp变量 */
    protected abstract void setTempProperties();

    /** 将temp变量赋值给实际变量 */
    protected abstract void setRealProperties();

    /** 如何处理每一行, 将处理结果加入temp */
    protected abstract void handleLine(String line) throws Exception;

    //-- methods --//

    /**
     * 在继承类的init中调用,
     * 执行过程中, 先初始化temp变量({@link #setTempProperties()}),
     * 再{@link #loadRemoteFile(java.io.File)}, 将内容读取至temp变量,
     * 最后将temp变量赋值给实际变量({@link #setRealProperties()}
     */
    protected void initRemoteFile() {
        HttpResource httpResource = new HttpResource(
            remoteUrl, new File(localFile), TimeUtils.MINUTE_MILLIS * interval);
        httpResource.registerListener(new HttpResource.FileChangeListener() {
            @Override
            public void onFileChange(File file) {
                setTempProperties();
                try {
                    loadRemoteFile(file);
                    try {
                        lock.writeLock().lock();
                        setRealProperties();
                    } finally {
                        lock.writeLock().unlock();
                    }
                } catch (Exception e) {
                    LOG.warningThis("read remote file failed!", e);
                }
            }
        });
    }

    //-- functions --//

    /** 按行遍历file, 调用{@link #handleLine(String)} */
    private void loadRemoteFile(File file) throws IOException {
        LineReader lr = new LineReader(file);
        try {
            /* 处理第一行第一个字符为0xFEFF的问题 */
            String buffer = lr.getLine();
            if (!StringUtils.isBlank(buffer)) {
                if (buffer.charAt(0) == 0xFEFF) {
                    buffer = buffer.substring(1);
                }
                try {
                    handleLine(buffer);
                } catch (Exception e) {
                    LOG.warningThis("invalid line: " + buffer, e);
                }
            }
            while ((buffer = lr.getLine()) != null) {
                try {
                    handleLine(buffer);
                } catch (Exception e) {
                    LOG.warningThis("invalid line: " + buffer, e);
                }
            }
        } finally {
            lr.close();
        }
    }

    //-- utils --//
    //-- getters & setters --//

    public void setRemoteUrl(String remoteUrl) {
        this.remoteUrl = remoteUrl;
    }

    public void setLocalFile(String localFile) {
        this.localFile = localFile;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    //-- iWritables --//
    //-- inner classes --//
}
