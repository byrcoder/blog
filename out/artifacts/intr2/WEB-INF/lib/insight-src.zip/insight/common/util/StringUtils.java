/** StringUtils */
package insight.common.util;

import java.util.Map;

import insight.common.util.string.HtmlUtils;
import insight.common.util.string.JsonUtils;
import insight.common.util.string.UrlUtils;
import insight.common.util.string.XmlUtils;

/**
 * string工具
 * <li>扩展了org.apache.commons.lang.StringUtils</li>
 * <li>封装了html/xml/json的escape/unescape</li>
 * <li>封装了url的encode/decode</li>
 */
public class StringUtils extends org.apache.commons.lang.StringUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static StringUtils singleton = new StringUtils();

    /** 获得singleton */
    public static StringUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /* escape/unescape */

    /** use: {@link HtmlUtils#escapeHtmlLite} */
    @Deprecated
    public static String escapeHtmlLite(String s) {
        return HtmlUtils.escapeHtmlLite(s);
    }

    /** use: {@link HtmlUtils#unescapeHtmlLite} */
    @Deprecated
    public static String unescapeHtmlLite(String s) {
        return HtmlUtils.unescapeHtmlLite(s);
    }

    /** use: {@link XmlUtils#escapeXml} */
    @Deprecated
    public static String escapeXml(String s) {
        return XmlUtils.escapeXml(s);
    }

    /** use: {@link XmlUtils#unescapeXml} */
    @Deprecated
    public static String unescapeXml(String s) {
        return XmlUtils.unescapeXml(s);
    }

    /** use: {@link JsonUtils#escapeJson} */
    @Deprecated
    public static String escapeJson(String s) {
        return JsonUtils.escapeJson(s);
    }

    /** use: {@link JsonUtils#unescapeJson} */
    @Deprecated
    public static String unescapeJson(String s) {
        return JsonUtils.unescapeJson(s);
    }

    /* urlEncode/Decode */

    /** use: {@link UrlUtils#getURLEncoded} */
    @Deprecated
    public static String getURLEncoded(String s) {
        return UrlUtils.getURLEncoded(s, "UTF-8");
    }

    /** use: {@link UrlUtils#getURLEncoded} */
    @Deprecated
    public static String getURLEncoded(String s, String charset) {
        return UrlUtils.getURLEncoded(s, charset);
    }

    /** use: {@link UrlUtils#getURLDecoded} */
    @Deprecated
    public static String getURLDecoded(String s) {
        return UrlUtils.getURLDecoded(s, "UTF-8");
    }

    /** use: {@link UrlUtils#getURLDecoded} */
    @Deprecated
    public static String getURLDecoded(String s, String charset) {
        return UrlUtils.getURLDecoded(s, charset);
    }

    /* toString series */

    public static <K, V> String mapToString(Map<K, V> map) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");

        int i = 0;
        for (Map.Entry<K, V> entry : map.entrySet()) {
            if (i != 0) {
                sb.append(", ");
            }
            sb.append(entry.getKey().toString() + ": " + entry.getValue().toString());
            i++;
        }

        sb.append("}");
        return sb.toString();
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
