/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-09-23
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.mail;

/** mail数据结构 */
public class MailInfo extends MailInfoLite {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private String cc = null;
    private String bcc = null;
    private String attachment = null;

    //-- constructors --//

    /**
     * @param toEmail - 如果有多个, 可以用分号或逗号分割
     * @param cc - 如果有多个, 可以用分号或逗号分割
     * @param bcc - 如果有多个, 可以用分号或逗号分割
     */
    public MailInfo(
        String fromName, String fromEmail, String toEmail,
        String subject, String body, boolean isHtml,
        String cc, String bcc, String attachment) {

        super(fromName, fromEmail, toEmail, subject, body, isHtml);
        setCc(cc);
        setBcc(bcc);
        setAttachment(attachment);
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//

    public String getCc() {
        return cc;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getBcc() {
        return bcc;
    }

    public void setBcc(String bcc) {
        this.bcc = bcc;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    //-- iWritables --//
    //-- inner classes --//
}
