/** IAppMain */
package insight.common.app;

/** AppMain接口类 */
public interface IAppMain {

    public void doMain(String[] args) throws Exception;
}
