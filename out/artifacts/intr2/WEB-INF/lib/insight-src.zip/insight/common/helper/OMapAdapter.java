/** OMapAdapter */
package insight.common.helper;

import outfox.omap.client.protocol.DataSource;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.exceptions.OmapException;

/** OMap相关静态函数集合 */
public class OMapAdapter {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(OMapAdapter.class);

    private static final String DATA_SOURCE_NAME = "OmapDataSource";

    //-- properties --//
    //-- constructors --//

    private OMapAdapter() {}

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /** 失败时返回null */
    public static TableSpace getTableSpace(String tableSpaceName) {
        try {
            DataSource dataSource = DataSourceFactory.getNamed(DATA_SOURCE_NAME);
            return dataSource.openTableSpace(tableSpaceName);
        } catch (OmapException e) {
            LOG.warningThis("getTableSpace failed", e);
            return null;
        }
    }

    /** 失败时返回null */
    public static Table getTable(TableSpace tableSpace, String tableName) {
        try {
            return tableSpace.openTable(tableName);
        } catch (OmapException e) {
            LOG.warningThis("getTable failed", e);
            return null;
        }
    }

    /** 关闭tableSpace和table */
    public static void close(TableSpace tableSpace, Table table) {
        if (table != null) {
            table.close();
        }
        if (tableSpace != null) {
            tableSpace.close();
        }
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
