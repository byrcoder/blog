/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-07-22
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util;

import odis.serialize.lib.MD5Writable;

/**
 * id工具
 * <li>生成id</li>
 * <li>求余数</li>
 */
public class IdUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static IdUtils singleton = new IdUtils();

    /** 获得singleton */
    public static IdUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /* 生成id */

    /** 生成id, 不区分大小写(都转成了小写) */
    public static long generateId(String str) {
        return generateId(str, true);
    }

    /**
     * 生成id, 可以选择是否区分大小写
     * <li>不区分大小写时, 实际上是都转成了小写</li>
     */
    public static long generateId(String str, boolean ignoreCase) {
        if (ignoreCase) {
            return generateHashCode(str.toLowerCase());
        } else {
            return generateHashCode(str);
        }
    }

    /* 数据HASH */

    /** 根据字符串生成id, 区分大小写 */
    public static long generateHashCode(String str) {
        // MD5Writable.digest(str).halfDigest()是一样的
        return MD5Writable.halfDigest(str);
    }

    /** 根据字节数据生成id */
    public static long generateHashCode(byte[] data) {
        // MD5Writable.digest(data).halfDigest()是一样的
        return MD5Writable.halfDigest(data, 0, data.length);
    }

    /* 和id相关的计算 */

    /** 给定long, 求余数 */
    public static int mod(long key, int divisor) {
        int remainder = (int) (key % divisor);
        return (remainder < 0) ? (remainder + divisor) : remainder;
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
