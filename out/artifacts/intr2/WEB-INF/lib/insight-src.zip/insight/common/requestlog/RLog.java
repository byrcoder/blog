/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-10-15
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.requestlog;

/**
 * 构造request-log时使用的数据结构
 * <li>用于{@link outlog.logging.RemoteLogger#log(String)}</li>
 */
public class RLog {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private StringBuilder sb = new StringBuilder();

    //-- constructors --//

    /** 给定category */
    public RLog(String category) {
        sb.append(category);
    }

    //-- destructors --//
    //-- implements --//

    /** 生成request-log */
    @Override
    public String toString() {
        return sb.toString();
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /** 追加一对key-value */
    public void add(String key, String value) {
        sb.append("\t" + key + "=" + value);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
