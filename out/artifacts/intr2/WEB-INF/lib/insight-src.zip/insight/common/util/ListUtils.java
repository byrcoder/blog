/** ListUtils */
package insight.common.util;

import java.util.List;

/** {@link List}工具 */
public class ListUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static ListUtils singleton = new ListUtils();

    /** 获得singleton */
    public static ListUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 获得trim的结果, 如果size大于实际长度, 则返回原list
     * <li>返回的结果是一个copy, 修改结果list不影响原list("不影响"仅限于list本身)</li>
     * <li>但是由于不是deep-copy, list中的元素的修改还是会相互影响</li>
     */
    public static <T> List<T> getTrimmed(List<T> list, int size) {
        return list.subList(0, Math.min(size, list.size()));
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
