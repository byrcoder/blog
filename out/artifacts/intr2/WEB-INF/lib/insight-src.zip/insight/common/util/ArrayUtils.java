/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-07-06
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util;

import java.util.Arrays;
import java.util.List;

/**
 * array工具
 * <li>扩展了{@link org.apache.commons.lang.ArrayUtils}</li>
 * <li>封装了{@link java.util.Arrays}</li>
 */
public class ArrayUtils extends org.apache.commons.lang.ArrayUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static ArrayUtils singleton = new ArrayUtils();

    /** 获得singleton */
    public static ArrayUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /** @see java.util.Arrays#toString(int[]) */
    public static String toString(int[] array) {
        return Arrays.toString(array);
    }

    /** @see java.util.Arrays#toString(long[]) */
    public static String toString(long[] array) {
        return Arrays.toString(array);
    }

    /** @see java.util.Arrays#toString(char[]) */
    public static String toString(char[] array) {
        return Arrays.toString(array);
    }

    /** @see java.util.Arrays#toString(float[]) */
    public static String toString(float[] array) {
        return Arrays.toString(array);
    }

    /** @see java.util.Arrays#toString(double[]) */
    public static String toString(double[] array) {
        return Arrays.toString(array);
    }

    /** @see java.util.Arrays#toString(Object[]) */
    public static <T> String toString(T[] array) {
        return Arrays.toString(array);
    }

    /** @see List#toArray(Object[]) */
    public static Integer[] list2Array(List<Integer> list) {
        return list.toArray(new Integer[list.size()]);
    }

    /** @see List#toArray(Object[]) */
    public static Long[] list2Array(List<Long> list) {
        return list.toArray(new Long[list.size()]);
    }

    /** @see List#toArray(Object[]) */
    public static Double[] list2Array(List<Double> list) {
        return list.toArray(new Double[list.size()]);
    }

    /** @see List#toArray(Object[]) */
    public static String[] list2Array(List<String> list) {
        return list.toArray(new String[list.size()]);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
