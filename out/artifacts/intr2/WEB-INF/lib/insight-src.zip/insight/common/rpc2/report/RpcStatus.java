/** RpcStatus */
package insight.common.rpc2.report;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

import insight.common.util.StringUtils;

/**
 * RpcService的状态
 * <li>status(int): 状态</li>
 * <li>infoMap(HashMap): 详细描述</li>
 */
public class RpcStatus implements IWritable {

    //-- public finals --//

    /** means service's status is normal */
    public static final int RUNNING = 2;
    /** means service's status is not so good */
    public static final int NEED_ATTENTION = 1;
    /** means service already down */
    public static final int CRITICAL = 0;
    /** means exception while check service status */
    public static final int EXCEPTION = -1;

    //-- private finals --//

    private static Map<Integer, String> msgMap;

    static {
        msgMap = new HashMap<Integer, String>();
        msgMap.put(RUNNING, "RUNNING");
        msgMap.put(NEED_ATTENTION, "NEED_ATTENTION");
        msgMap.put(CRITICAL, "CRITICAL");
        msgMap.put(EXCEPTION, "EXCEPTION");
    }

    //-- properties --//

    private int status = RUNNING;
    private Map<String, String> infoMap = new HashMap<String, String>();

    //-- constructors --//

    private RpcStatus() {}

    //-- destructors --//
    //-- implements --//

    @Override
    public String toString() {
        return getStatusStr() + " ~ " + StringUtils.mapToString(infoMap);
    }

    //-- un-implements --//
    //-- methods --//

    public String getStatusStr() {
        return msgMap.get(status);
    }

    public void addInfo(String key, String value) {
        infoMap.put(key, value);
    }

    //-- functions --//

    private static RpcStatus create(int status) {
        RpcStatus s = new RpcStatus();
        s.setStatus(status);

        return s;
    }

    //-- utils --//

    public static RpcStatus createRunning() {
        return create(RUNNING);
    }

    public static RpcStatus createAttention() {
        return create(NEED_ATTENTION);
    }

    public static RpcStatus createCritical() {
        return create(CRITICAL);
    }

    //-- getters & setters --//

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    //-- iWritables --//

    public void readFields(DataInput in) throws IOException {
        status = in.readInt();
        int size = in.readInt();
        for (int i = 0; i < size; i++) {
            String key = StringWritable.readString(in);
            String val = StringWritable.readString(in);
            infoMap.put(key, val);
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(status);
        out.writeInt(infoMap.size());
        for (Map.Entry<String, String> entry : infoMap.entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            StringWritable.writeString(out, entry.getValue());
        }
    }

    public IWritable copyFields(IWritable value) {
        throw new UnsupportedOperationException();
    }

    //-- inner classes --//
}
