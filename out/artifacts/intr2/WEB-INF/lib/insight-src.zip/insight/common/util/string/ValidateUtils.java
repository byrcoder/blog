/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-13
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

import java.util.regex.Pattern;

import insight.common.util.StringUtils;

/**
 * 验证工具
 * <li>url/手机/电话/email</li>
 */
public class ValidateUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static ValidateUtils singleton = new ValidateUtils();

    /** 获得singleton */
    public static ValidateUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    public static final Pattern pUrl = Pattern.compile("^(https|http)://"
        + "("
        + "(0|[1-9][0-9]{0,2}\\.){3}(0|[1-9][0-9]{0,2})|" // IP
        + "([a-z0-9-]+\\.){0,4}" // 子域名, 最多4段, 如www.
        + "([a-z0-9][a-z0-9-]{0,61})?[a-z0-9]\\." // 二级域名, 最长63个字符
        + "[a-z]{2,6}" // 顶级域名, 如.cn或.museum
        + ")"
        + "(:[1-9][0-9]{1,4})?" // 端口- :80
        + "("
        + "/?|"
        + "(/[a-z0-9!\'()*._~#$&+,:;=?@%-]+)+/?"
        + ")$", Pattern.CASE_INSENSITIVE);

    public static boolean isUrl(String s) {
        if (StringUtils.isBlank(s)) {
            return false;
        } else {
            return pUrl.matcher(s).matches();
        }
    }

    public static final Pattern pMobile = Pattern.compile("^0*"
        + "(13|15|18)"
        + "("
        + "\\d{9}|" // 13800138000
        + "\\d-\\d{3}-\\d{5}|" // 138-001-38000
        + "\\d-\\d{4}-\\d{4}|" // 138-0013-8000
        + "\\d{2}-\\d{3}-\\d{4}|" // 1380-013-8000
        + "\\d{2}-\\d{4}-\\d{3}" // 1380-0138-000
        + ")$");

    public static boolean isMobile(String s) {
        if (StringUtils.isBlank(s)) {
            return false;
        } else if (s.length() < 8 || s.length() > 16) {
            return false;
        } else {
            return pMobile.matcher(s).matches();
        }
    }

    public static final Pattern pPhone = Pattern.compile("^"
        + "(("
        + "0*\\d{1,4}|" // 0086 或 86
        + "\\+\\d{1,4}|" // +86
        + "\\(\\d{1,4}\\)" // (86)
        + ")[ -]?)?"
        + "(\\d{2,4}[ -]?)?" // 010 或 010- 或 400 或 400- 或 4008
        + "\\d{3,4}[ -]?\\d{3,4}" // 82558163 或 8255-8163 或 8205555 或 820-5555 或 000000
        + "([ -]\\d{1,5})?" // 分机号 -8888
        + "$");

    public static boolean isPhone(String s) {
        if (StringUtils.isBlank(s)) {
            return false;
        } else if (s.length() < 8 || s.length() > 24) {
            return false;
        } else {
            return pPhone.matcher(s).matches();
        }
    }

    public static final Pattern pEmail = Pattern.compile("^"
        + "([a-z0-9_][a-z0-9_.-]*)?[a-z0-9_]"
        + "@"
        + "([a-z0-9-]+\\.){0,4}" // 子域名, 最多4段, 如www.
        + "([a-z0-9][a-z0-9-]{0,61})?[a-z0-9]\\." // 二级域名, 最长63个字符
        + "[a-z]{2,6}" // 顶级域名, 如.cn或.museum
        + "$", Pattern.CASE_INSENSITIVE);

    public static boolean isEmail(String s) {
        if (StringUtils.isBlank(s)) {
            return false;
        } else if (s.length() < 6 || s.length() > 32) {
            return false;
        } else {
            return pEmail.matcher(s).matches();
        }
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
