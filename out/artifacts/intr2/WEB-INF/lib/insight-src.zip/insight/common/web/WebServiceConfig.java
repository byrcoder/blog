/** WebServiceConfig */
package insight.common.web;

/**
 * 用于存储servlet配置的Singleton
 * <li>目前只有服务是否available的配置</li>
 *
 * @note 读取和写入配置没有用锁, 主要是因为写请求很快且不频繁
 */
public final class WebServiceConfig {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private boolean debugMode = false;

    private boolean serviceAvailable = true;

    //-- constructors --//

    private static WebServiceConfig config = new WebServiceConfig();

    private WebServiceConfig() {}

    public static WebServiceConfig getConfig() {
        return config;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//

    public boolean isDebugMode() {
        return debugMode;
    }

    public void setDebugMode(boolean debugMode) {
        this.debugMode = debugMode;
    }

    public boolean isServiceAvailable() {
        return serviceAvailable;
    }

    public void setServiceAvailable(boolean serviceAvailable) {
        this.serviceAvailable = serviceAvailable;
    }

    //-- iWritables --//
    //-- inner classes --//
}
