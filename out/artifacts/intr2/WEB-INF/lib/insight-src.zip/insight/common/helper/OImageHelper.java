/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-10-25
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.helper;

import insight.common.util.IdUtils;
import insight.common.util.RandomUtils;

/**
 * OImage相关静态函数集合
 * <li>生成形如oimagea1~c8.ydstatic.com的host</li>
 */
public class OImageHelper {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private static String name = "oimage";

    private static char[] prefix0 = {'a', 'b', 'c'};
    private static int prefix1 = 8;

    private static String domain = ".ydstatic.com";

    //-- constructors --//

    private OImageHelper() {}

    /**
     * 如果不初始化, 默认oimage/['a','b','c']/1~8,
     * 构造xue/['-']/1~4则生成xue-1~4.ydstatic.com
     */
    public static void init(String n, char[] p0, int p1) {
        name = n;
        prefix0 = p0.clone();
        prefix1 = p1;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    private static final int DIVIDER = (int) Math.pow(11, 6);

    /** 根据id生成host */
    public static String getHost(long id) {
        int x0 = IdUtils.mod(id, prefix0.length);
        int x1 = IdUtils.mod(id, DIVIDER) % prefix1 + 1;

        return name + prefix0[x0] + String.valueOf(x1) + domain;
    }

    /** 随机生成host */
    public static String getRandomHost() {
        int x0 = RandomUtils.generateInt(prefix0.length);
        int x1 = RandomUtils.generateInt(prefix1) + 1;

        return name + prefix0[x0] + String.valueOf(x1) + domain;
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
