/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-07-06
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common;

/**
 *
 */
public class Clean {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//
    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
