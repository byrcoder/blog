/** ConfigurationHelper */
package insight.common.helper;

import java.io.File;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;

/** 用于寻找配置文件的静态帮助类 */
public class ConfigurationHelper {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private static String rootPath = ".";

    //-- constructors --//

    private ConfigurationHelper() {}

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 按顺序在如下目录中寻找配置文件:
     * <li>./</li>
     * <li>./conf</li>
     * <li>../conf</li>
     */
    public static String probeConfigurationFilePath(String fileName) {
        if (new File(fileName).exists()) {
            return fileName;
        }
        String[] toProbe = {
            rootPath,
            rootPath + File.separatorChar + "conf",
            rootPath + File.separatorChar + ".." + File.separatorChar + "conf"
        };
        for (String probe : toProbe) {
            File file = new File(probe, fileName);
            if (file.exists()) {
                return probe + File.separatorChar + fileName;
            }
        }
        return null;
    }

    /**
     * 读取xml配置文件
     * <li>不存在则返回null</li>
     */
    public static Configuration getConfig(String fileName) throws ConfigurationException {
        String path = probeConfigurationFilePath(fileName);
        return (path == null) ? null : new XMLConfiguration(path);
    }

    //-- getters & setters --//

    public static void setRootPath(String rootPath) {
        ConfigurationHelper.rootPath = rootPath;
    }

    //-- iWritables --//
    //-- inner classes --//
}
