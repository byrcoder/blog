/** IRpcService */
package insight.common.rpc2;

import odis.rpc2.RpcException;

/**
 * RpcService接口类
 * <li>支持远程shutdown</li>
 */
public interface IRpcService {

    public void shutdown(String key) throws RpcException;
}
