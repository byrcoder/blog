/** ErrorPageController */
package insight.common.web.controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import toolbox.web.ViewUtils;

import insight.common.helper.LogHelper;
import insight.common.web.WebServiceConfig;

/**
 * 出错页面(error.do)
 * <li>处理500, 403, 404和其它错误</li>
 */
public class ErrorPageController extends SprivelController {

    //-- public finals --//

    public static final String TYPE = "type";

    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(ErrorPageController.class);

    //-- properties --//

    protected String errorView = "error";

    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    @Override
    public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {

        Map<String, Object> model = newModel();
        model.put("debug", WebServiceConfig.getConfig().isDebugMode());
        model.put("ViewUtils", ViewUtils.getInstance());

        int errorCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        model.put("errorCode", errorCode);
        String uri = (String) request.getAttribute("javax.servlet.error.request_uri");
        LOG.warningThis("uri: " + uri);

        if (errorCode == 500) {
            Throwable t = (Throwable) request.getAttribute("javax.servlet.error.exception");
            LOG.warningThis("servlet error ~ code: 500, request_uri: " + uri, t);
            // type
            model.put(TYPE, "exception");
            // stack-trace
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            model.put("stackTrace", sw.toString().replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;").replace("\n", "<br />"));
        } else {
            LOG.warningThis("servlet error ~ code: " + errorCode + ", request_uri: " + uri);
            if (errorCode == 403) {
                model.put(TYPE, "forbidden");
                model.put("request_uri", uri);
            } else if (errorCode == 404) {
                model.put(TYPE, "not_found");
                model.put("request_uri", uri);
            } else {
                model.put(TYPE, "unknown");
            }
        }

        return new ModelAndView(errorView, model);
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//

    public void setErrorView(String errorView) {
        this.errorView = errorView;
    }

    //-- iWritables --//
    //-- inner classes --//
}
