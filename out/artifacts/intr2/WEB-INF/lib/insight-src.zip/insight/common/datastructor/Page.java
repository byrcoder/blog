/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-23
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.datastructor;

import java.util.List;

/** 分页用数据结构 */
public class Page<T> {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//

    private int total = 0;
    private int pageSize = 0;
    private int currentPage = 0;

    private List<T> list = null;

    //-- constructors --//

    /** 需要自行保证参数的正确性 */
    public Page(int total, int pageSize, int currentPage, List<T> list) {
        this.total = total;
        if (pageSize <= 0) {
            throw new IllegalArgumentException("pageSize must greater than 0");
        }
        this.pageSize = pageSize;
        this.currentPage = currentPage;
        this.list = list;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 生成计算开始/结束
     * <li>pageIndex从1开始</li>
     * <li>需要自行保证参数的正确性</li>
     */
    public static int[] getStartEnd(int total, int pageSize, int pageIndex) {
        if (total < 0) {
            throw new IllegalArgumentException("total must be greater than or equal 0");
        }
        if (pageSize <= 0) {
            throw new IllegalArgumentException("pageSize must be greater than 0");
        }
        if (pageIndex <= 0) {
            throw new IllegalArgumentException("pageIndex must be greater than 0");
        }
        if (total == 0) {
            return new int[]{0, 0};
        }
        int pageCount = (total + pageSize - 1) / pageSize;
        if (pageIndex > pageCount) {
            pageIndex = pageCount;
        }
        int startIndex = pageSize * (pageIndex - 1);
        int endIndex = Math.min(total, pageSize * pageIndex);
        return new int[]{startIndex, endIndex};
    }

    //-- getters & setters --//

    public int getTotal() {
        return total;
    }

    public int getPageSize() {
        return pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getTotalPage() {
        return (total + pageSize - 1) / pageSize;
    }

    public List<T> getList() {
        return list;
    }

    //-- iWritables --//
    //-- inner classes --//
}
