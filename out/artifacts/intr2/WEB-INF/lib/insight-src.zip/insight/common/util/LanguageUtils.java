/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2012-01-11
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import toolbox.collections.Pair;

import insight.common.helper.LogHelper;
import insight.common.util.string.CharUtils;

/** 语言工具 */
public class LanguageUtils {

    //-- public finals --//

    public static final int LANG_UNKNOWN = 0;
    public static final int LANG_EN = 1;
    public static final int LANG_CN = 2;

    /** @see CharUtils#isBlank(char) */
    public static boolean isSpace(char c) {
        return CharUtils.isBlank(c);
    }

    /** @see toolbox.lang.ChnConstant */
    static final int[][] UTF_DELIMITER = {
        {'\'', '‘', '’'}, {'"', '“', '”'}, {',', '，'}, {'.', '。'},
        {';', '；'}, {':', '：'}, {'、'}, {'·'},
        {'/', '／'}, {'?', '？'}, {'\\', '＼'}, {'|', '｜'}, // 标点
        {'`'}, // before 1
        {'~', '～'}, {'!', '！'}, {'@', '＠'}, {'#', '＃'}, {'$', '＄'}, {'¥', '￥'}, // shift before 1 ~ 4
        {'%', '％'}, {'^', '＾', '…'}, {'&', '＆'}, // shift 5 ~ 7
        {'_'}, // shift after 0
        {'(', ')'}, {'（', '）'}, {'[', ']'}, {'［', '］'}, {'{', '}'}, {'<', '>'}, // 括号
        {'+', '＋'}, {'-', '－'}, {'*', '＊', '×'}, {'÷'}, {'=', '＝'} // 运算符
    };
    static final int[][] UTF_DELIMITER_EXT = {
        {0x275e, 0x300d, 0x300f, 0x301e, 0xff63}, // ❞」』〞｣
        {0x3011, 0x3015, 0x3017, 0x3019, 0x301b}, // 】〕〗〙〛
        {0x203a, 0x3009, 0x300b} // ›〉》
    };
    private static Set<Integer> delimiters = new HashSet<Integer>();

    static {
        for (int[] e : UTF_DELIMITER) {
            for (int f : e) {
                delimiters.add(f);
            }
        }
        for (int[] e : UTF_DELIMITER_EXT) {
            for (int f : e) {
                delimiters.add(f - 1);
                delimiters.add(f);
            }
        }
    }

    /** 是标点或分隔符 */
    public static boolean isDelimiter(char c) {
        return delimiters.contains(Integer.valueOf(c));
    }

    static final int[][] ASCII_DELIMITER = {
        {0x0021, 0x002F}, {0x003A, 0x0040}, {0x005B, 0x0060}, {0x007B, 0x007E}
    };

    /** 是ASCII标点或分隔符 */
    public static boolean isAsciiDelimiter(char c) {
        for (int[] e : ASCII_DELIMITER) {
            if (c >= e[0] && c <= e[1]) {
                return true;
            }
        }
        return false;
    }

    /** @see toolbox.lang.ChnConstant */
    static final int[] UTF_ASCII_DIGIT_RANGE = {0x0030, 0x0039}; // 0~9
    static final int[] UTF_FULL_WIDTH_DIGIT_RANGE = {0xff10, 0xff19}; // 0~9, UFF00.pdf

    /** 是阿拉伯数字 */
    public static boolean isArabicDigits(char c) {
        return (c >= UTF_ASCII_DIGIT_RANGE[0] && c <= UTF_ASCII_DIGIT_RANGE[1]) ||
            (c >= UTF_FULL_WIDTH_DIGIT_RANGE[0] && c <= UTF_FULL_WIDTH_DIGIT_RANGE[1]);
    }

    /** @see toolbox.lang.ChnConstant */
    static final int[] UTF_ALPHABET_UPPER_RANGE = {0x0041, 0x005a};   // A~Z
    static final int[] UTF_ALPHABET_LOWER_RANGE = {0x0061, 0x007a};   // a~z
    static final int[] UTF_FULL_WIDTH_UPPER_RANGE = {0xff21, 0xff3a}; // A~Z, UFF00.pdf
    static final int[] UTF_FULL_WIDTH_LOWER_RANGE = {0xff41, 0xff5a}; // a~z, UFF00.pdf

    /** 是英文字母 */
    public static boolean isEnglishAlphabet(char c) {
        return (c >= UTF_ALPHABET_UPPER_RANGE[0] && c <= UTF_ALPHABET_UPPER_RANGE[1]) ||
            (c >= UTF_ALPHABET_LOWER_RANGE[0] && c <= UTF_ALPHABET_LOWER_RANGE[1]) ||
            (c >= UTF_FULL_WIDTH_UPPER_RANGE[0] && c <= UTF_FULL_WIDTH_UPPER_RANGE[1]) ||
            (c >= UTF_FULL_WIDTH_LOWER_RANGE[0] && c <= UTF_FULL_WIDTH_LOWER_RANGE[1]);
    }

    /** @see toolbox.lang.ChnConstant */
    static final int[] UTF_CHN_CHAR_RANGE = {0x4e00, 0x9fff}; // U4E00.pdf
    static final int[] UTF_CHN_EXT_CHAR_RANGE = {0x3400, 0x4dbf}; // U3400.pdf
    static final int[] UTF_CHN_CPT_CHAR_RANGE = {0xf900, 0xfaff}; // UF900.pdf

    /** 是汉字 */
    public static boolean isChineseChar(char c) {
        return (c >= UTF_CHN_CHAR_RANGE[0] && c <= UTF_CHN_CHAR_RANGE[1]) ||
            (c >= UTF_CHN_EXT_CHAR_RANGE[0] && c <= UTF_CHN_EXT_CHAR_RANGE[1]) ||
            (c >= UTF_CHN_CPT_CHAR_RANGE[0] && c <= UTF_CHN_CPT_CHAR_RANGE[1]);
    }

    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(LanguageUtils.class);

    static {
        LOG.warningThis("init");
    }

    //-- properties --//
    //-- constructors --//

    private static LanguageUtils singleton = new LanguageUtils();

    /** 获得singleton */
    public static LanguageUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /** 返回值: 语言, 字数 */
    public static Pair<Integer, Integer> guessLanguage(String text) {
        if (StringUtils.isBlank(text)) {
            return new Pair<Integer, Integer>(LANG_UNKNOWN, 0);
        }

        List<String> englishList = new ArrayList<String>();
        List<String> numberList = new ArrayList<String>();

        int chineseChar = 0;
        int unknown = 0;
        int longWord = 0;

        int start = 0;
        boolean startEn = false; // 找到英文单词的开头
        boolean startNum = false; // 找到数字的开头
        for (int i = 0, l = text.length(); i < l; i++) {
            char c = text.charAt(i);
            boolean endOfEn = false; // 找到英文单词的结尾
            boolean endOfNum = false; // 找到数字的结尾
            if (isSpace(c) || isDelimiter(c)) {
                endOfEn = endOfNum = true;
            } else if (isEnglishAlphabet(c)) {
                if (!startEn) {
                    startEn = true;
                }
                endOfNum = true;
            } else if (isArabicDigits(c)) {
                if (!startNum) {
                    startNum = true;
                }
                endOfEn = true;
            } else if (isChineseChar(c)) {
                endOfEn = endOfNum = true;
                chineseChar++;
            } else {
                endOfEn = endOfNum = true;
                unknown++;
            }
            // 找到结尾
            if ((startEn && (endOfEn || i == l - 1))
                || (startNum && (endOfNum || i == l - 1))) {

                int end = i;
                if (end == l - 1) {
                    end = i + 1;
                }
                String word = text.substring(start, end);
                if (word.length() > 24) {
                    return new Pair<Integer, Integer>(LANG_UNKNOWN, 0);
                } else if (word.length() > 10) {
                    longWord++;
                }
                if (startEn) {
                    englishList.add(word);
                } else if (startNum) {
                    numberList.add(word);
                }
                //LOG.warningThis("word: " + word);

                // 如果这个结尾是英文/数字
                if (startEn || startNum) {
                    start = i;
                }

                startEn = false;
                startNum = false;
            }
            // 如果这个结尾不是英文/数字
            if (endOfEn && endOfNum) {
                start = i + 1;

                startEn = false;
                startNum = false;
            }
        }

        int number = numberList.size();
        int englishWord = englishList.size();
        int realLength = englishWord + chineseChar;
        int knownLength = realLength + number;
        if (realLength == 0) { // 特殊情况, 中文英文都没有
            englishWord = number;
            realLength = number;
            knownLength = number;
        }
        int costLength = knownLength + unknown;

        float un = (float) unknown / costLength;
        if (un >= 0.4F) {
            return new Pair<Integer, Integer>(LANG_UNKNOWN, 0);
        }

        float en = (float) englishWord / realLength;
        if (en >= 0.8F) {
            if ((float) longWord / englishWord >= 0.4F) {
                // 长单词比例过高, 一个可接受(两个单词, 一个过长)
                if (longWord >= 2) {
                    return new Pair<Integer, Integer>(LANG_UNKNOWN, 0);
                }
            }
            return new Pair<Integer, Integer>(LANG_EN, costLength);
        }

        float cn = (float) chineseChar / realLength;
        if (cn >= 0.8F) {
            return new Pair<Integer, Integer>(LANG_CN, costLength);
        }

        return new Pair<Integer, Integer>(LANG_UNKNOWN, 0);
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
