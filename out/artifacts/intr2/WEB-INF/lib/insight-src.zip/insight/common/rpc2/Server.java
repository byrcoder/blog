/** Server */
package insight.common.rpc2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;

import odis.rpc2.RPC;
import odis.rpc2.RpcServer;

import insight.common.app.AbstractAppMain;
import insight.common.helper.LogHelper;
import insight.common.rpc2.report.AbstractRpcReport;

/**
 * RPC服务框架
 * <li>一个可以用insight.common.app.Starter启动的应用程序</li>
 * <li>只要设置接口/对象/端口/并发数，就可以启动RPC服务</li>
 */
public class Server extends AbstractAppMain {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(Server.class);

    //-- properties --//

    private List<String> classNames = null;
    private Object handler = null;

    private int port = 0;
    private int concurrency = 0;

    private RpcServer server = null;

    //-- constructors --//

    public Server() {}

    //-- destructors --//
    //-- implements --//

    @Override
    protected final Options getOptions() {
        Options options = new Options();
        options.addOption("p", "port", true, "overwrite port number in config file");
        return options;
    }

    @Override
    protected final void doMain(CommandLine cmdLine) throws Exception {
        if (cmdLine.hasOption('p')) {
            port = Integer.parseInt(cmdLine.getOptionValue('p'));
        }
        start();
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//

    private void start() throws IOException {
        if (handler == null) {
            throw new RuntimeException("no service handler in configuration");
        }

        if (AbstractRpcReport.class.isInstance(handler)) {
            ((AbstractRpcReport) handler).setPort(port);
        }

        List<Class<?>> protocols = new ArrayList<Class<?>>();
        for (String className : classNames) {
            try {
                protocols.add(Class.forName(className));
            } catch (ClassNotFoundException e) {
                throw new RuntimeException("load class " + className + " failed", e);
            }
        }
        List<Object> instances = new ArrayList<Object>(protocols.size());
        for (int i = 0; i < protocols.size(); i++) {
            instances.add(handler);
        }

        this.server = RPC.getServer(protocols, instances, port, concurrency);
        this.server.start();
        try {
            this.server.join();
        } catch (InterruptedException e) {
            LOG.warningThis("server.join failed", e);
        }
    }

    //-- utils --//
    //-- getters & setters --//

    public void setClassNames(List<String> classNames) {
        this.classNames = classNames;
    }

    public void setHandler(Object handler) {
        this.handler = handler;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setConcurrency(int value) {
        this.concurrency = value;
    }

    //-- iWritables --//
    //-- inner classes --//
}
