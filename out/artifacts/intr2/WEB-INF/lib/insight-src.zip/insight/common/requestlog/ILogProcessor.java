/** ILogProcessor */
package insight.common.requestlog;

public interface ILogProcessor {

    /** 清理内部数据 */
    public void clear();

    /** 处理<时间, 字符串>对 */
    public void process(long time, String s);
}
