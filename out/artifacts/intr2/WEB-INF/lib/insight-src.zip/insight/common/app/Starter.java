/** Starter */
package insight.common.app;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import insight.common.helper.ConfigurationHelper;
import insight.common.helper.LogHelper;

/**
 * 用于启动IAppMain的工具类
 * <li>读取配置文件(Spring格式), 组装成一个应用程序</li>
 * <li>该应用程序必须是IAppMain的实例</li>
 * <li>该应用程序的名称(bean-id)是beanName</li>
 * <p/>
 * 使用方法: Starter beanName -conf configFile -a xxx -b yyy -c zzz...
 * <li>configFile: Starter使用的参数, 用于组装应用程序, 其中的main-bean必须是beanName</li>
 * <li>-a xxx -b yyy -c zzz ...: 应用程序使用的参数，由应用程序自行处理</li>
 */
public class Starter {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(Starter.class);

    //-- properties --//

    private static ApplicationContext context = null;

    //-- constructors --//

    private Starter() {}

    //-- destructors --//
    //-- implements --//

    public static void main(String[] args) throws Exception {
        String configFile = null;
        String mainBeanName = null;

        int argIndex = 0;
        ArrayList<String> argsList = new ArrayList<String>();

        // 获得参数
        while (argIndex < args.length) {
            String arg = args[argIndex];
            // 获得conf参数, 并initApplicationContext
            if (arg.equals("-conf")) {
                configFile = ConfigurationHelper.probeConfigurationFilePath(args[argIndex + 1]);
                if (configFile == null) {
                    LOG.warningThis("error: cannot find config-file");
                    return;
                } else {
                    initApplicationContext(new String[]{configFile});
                    argIndex++;
                }
                // 获得其它参数(key)
            } else if (arg.startsWith("-")) {
                argsList.add(arg);
            } else {
                // 获得main-bean name
                if (argIndex == 0) {
                    mainBeanName = arg;
                    // 获得其它参数(value)
                } else {
                    argsList.add(arg);
                }
            }
            argIndex++;
        }

        // 启动main-bain(带参数)
        if (mainBeanName == null) {
            LOG.warningThis("error: no main-bean specified");
        } else {
            if (argsList.size() > 0) {
                String[] appArgs = new String[argsList.size()];
                argsList.toArray(appArgs);
                run(mainBeanName, appArgs);
            } else {
                run(mainBeanName, new String[0]);
            }
        }
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//

    /** 根据配置文件初始化ApplicationContext */
    private static void initApplicationContext(String[] files) {
        context = new ClassPathXmlApplicationContext(files.clone());
    }

    /** 从ApplicationContext获得main-bean并启动 */
    private static void run(String mainBeanName, String[] args) throws Exception {
        if (context == null) {
            throw new RuntimeException("cannot find application context configuration");
        }
        IAppMain appMain = (IAppMain) context.getBean(mainBeanName);
        appMain.doMain(args);
    }

    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
