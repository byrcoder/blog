/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-09-28
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.helper;

import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/** 用于输出格式统一的log */
public class LogHelper {

    //-- public finals --//

    public static final String MSG_ERROR = "invalid parameter ~ should be class";

    //-- private finals --//
    //-- properties --//

    private String name = null;
    private Logger logger = null;

    //-- constructors --//

    @SuppressWarnings("unused")
    private LogHelper() {}

    @SuppressWarnings("rawtypes")
    private LogHelper(Object o) {
        name = ((Class) o).getSimpleName();
        logger = LogFormatter.getLogger(o);
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//

    /** 输出log并返回message */
    public String warningThis(String message) {
        return warningThis(message, true);
    }

    /** 输出log并返回message */
    public String warningThis(String message, boolean log) {
        return logThis(Level.WARNING, message, log);
    }

    /** 输出log并返回message */
    public String warningThis(String message, Throwable t) {
        return warningThis(message, t, true);
    }

    /** 输出log并返回message */
    public String warningThis(String message, Throwable t, boolean log) {
        return logThis(Level.WARNING, message, log);
    }

    /** 输出log并返回message */
    public String logThis(Level level, String message) {
        return logThis(level, message, true);
    }

    /** 输出log并返回message */
    public String logThis(Level level, String message, boolean log) {
        if (log) {
            logger.log(level, "[" + name + "] " + message);
        }
        return message;
    }

    /** 输出log并返回message */
    public String logThis(Level level, String message, Throwable t) {
        return logThis(level, message, t, true);
    }

    /** 输出log并返回message */
    public String logThis(Level level, String message, Throwable t, boolean log) {
        if (log) {
            logger.log(level, "[" + name + "] " + message, t);
        }
        return message;
    }

    //-- functions --//
    //-- utils --//

    /** 调用该方法生成LOG对象 */
    public static LogHelper getLogger(Object o) {
        if (o instanceof Class) {
            return new LogHelper(o);
        } else {
            throw new RuntimeException(MSG_ERROR);
        }
    }

    //-- getters & setters --//

    public String getName() {
        return name;
    }

    //-- iWritables --//
    //-- inner classes --//
}
