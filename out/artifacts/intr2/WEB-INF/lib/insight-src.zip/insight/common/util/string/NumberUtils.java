/**
 * Created by IntelliJ IDEA.
 * User: liqiang
 * Date: 2011-11-20
 *
 * Copyright 2008 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package insight.common.util.string;

/**
 * 数字工具
 * <li>数字转unicode/hex</li>
 */
public class NumberUtils {

    //-- public finals --//
    //-- private finals --//
    //-- properties --//
    //-- constructors --//

    private static NumberUtils singleton = new NumberUtils();

    /** 获得singleton */
    public static NumberUtils getInstance() {
        return singleton;
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /**
     * 输出整数的unicode进制表示\uFFFF, 大写
     * <li>i必须是大于等于0的整数</li>
     */
    public static String intToUnicode(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("i must be positive");
        }

        StringBuilder sb = new StringBuilder("\\uFFFF".length());
        String s = Integer.toHexString(i).toUpperCase();
        sb.append("\\u");
        for (int k = 0; k < "FFFF".length() - s.length(); k++) {
            sb.append('0');
        }
        sb.append(s);

        return sb.toString();
    }

    /**
     * 输出整数的unicode进制表示\uFFFF, 可以选择是否大写
     *
     * @see #intToUnicode(int)
     */
    public static String intToUnicode(int i, boolean lowerCase) {
        if (lowerCase) {
            return intToUnicode(i).toLowerCase();
        } else {
            return intToUnicode(i);
        }
    }

    /**
     * 输出整数的16进制表示0xFFFF, 大写
     * <li>i必须是大于等于0的整数</li>
     */
    public static String intToHex(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("i must be positive");
        }

        StringBuilder sb = new StringBuilder("0xFFFF".length());
        String s = Integer.toHexString(i).toUpperCase();
        sb.append("0x");
        for (int k = 0; k < "FFFF".length() - s.length(); k++) {
            sb.append('0');
        }
        sb.append(s);

        return sb.toString();
    }

    /**
     * 输出整数的16进制表示0XFFFF, 可以选择是否大写
     *
     * @see #intToHex(int)
     */
    public static String intToHex(int i, boolean lowerCase) {
        if (lowerCase) {
            return intToHex(i).toLowerCase();
        } else {
            return intToHex(i);
        }
    }

    /**
     * 输出整数的16进制表示0xFF, 大写
     * <li>i必须是大于等于0, 小于256的整数</li>
     */
    public static String shortToHex(int i) {
        if (i < 0 || i > 0xFF) {
            throw new IllegalArgumentException("i must be positive and less than 256");
        }

        StringBuilder sb = new StringBuilder("0xFF".length());
        String s = Integer.toHexString(i).toUpperCase();
        if (i > 0x0F) {
            sb.append("0x").append(s);
        } else {
            sb.append("0x0").append(s);
        }

        return sb.toString();
    }

    /**
     * 输出整数的16进制表示0XFF, 可以选择是否大写
     *
     * @see #intToHex(int)
     */
    public static String shortToHex(int i, boolean lowerCase) {
        if (lowerCase) {
            return shortToHex(i).toLowerCase();
        } else {
            return shortToHex(i);
        }
    }

    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
