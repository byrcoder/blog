/** SprivelController */
package insight.common.web.controller;

import java.io.IOException;
import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import toolbox.web.ViewUtils;

import account.app.CheckFilter;
import insight.common.helper.LogHelper;
import insight.common.util.CookieUtils;
import insight.common.util.StringUtils;
import insight.common.util.string.UrlUtils;
import outlog.http.RequestLogger;

/**
 * controller基类
 * <li>提供用于Spring-Velocity的各种ModelAndView支持, 含ViewUtils</li>
 * <li>提供用于Spring-Velocity的各种render支持</li>
 * <li>提供获取用户名的工具: getEmail, getTrialId</li>
 * <li>提供系统工具: getControllerAlias, sessionFromFilter, p3pFilter, isInWhiteList</li>
 *
 * @author liqiang
 */
public abstract class SprivelController extends MultiActionController {

    //-- public finals --//

    public static final String IN_FLAG_WHITELIST = "inFlagFilterWhiteList";

    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(SprivelController.class);

    //-- properties --//

    protected String methodName = "method";

    /** logger, 用于记录用户操作 */
    protected RequestLogger logger = null;
    /** controllerLogger, 用于记录controller调用 */
    protected RequestLogger controllerLogger = null;

    //-- constructors --//
    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//

    /* getParameter series */

    protected static int getInt(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (StringUtils.isBlank(value)) {
            throw new NumberFormatException(name + " is blank");
        } else {
            return Integer.parseInt(value);
        }
    }

    protected static int getInt(HttpServletRequest request, String name, int defaultValue) {
        try {
            return getInt(request, name);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected static boolean getIntBool(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (StringUtils.isBlank(value)) {
            throw new InvalidParameterException(name + " is blank");
        } else if ("0".equals(value)) {
            return false;
        } else if ("1".equals(value)) {
            return true;
        } else {
            throw new InvalidParameterException(name + ": " + value);
        }
    }

    protected static boolean getIntBool(HttpServletRequest request, String name, boolean defaultValue) {
        try {
            return getIntBool(request, name, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected static boolean getBool(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (StringUtils.isBlank(value)) {
            throw new InvalidParameterException(name + " is blank");
        } else if ("TRUE".equals(value.toUpperCase())) {
            return true;
        } else if ("FALSE".equals(value.toUpperCase())) {
            return false;
        } else {
            throw new InvalidParameterException(name + ": " + value);
        }
    }

    protected static boolean getBool(HttpServletRequest request, String name, boolean defaultValue) {
        try {
            return getBool(request, name);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected static long getLong(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (StringUtils.isBlank(value)) {
            throw new NumberFormatException(name + " is blank");
        } else {
            return Long.parseLong(value);
        }
    }

    protected static long getLong(HttpServletRequest request, String name, int defaultValue) {
        try {
            return getLong(request, name);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected static String getString(HttpServletRequest request, String name) {
        return request.getParameter(name);
    }

    protected static String getString(HttpServletRequest request, String name, String defaultValue) {
        String result = getString(request, name);
        if (StringUtils.isBlank(result)) {
            return defaultValue;
        } else {
            return result;
        }
    }

    /* createModelAndView series */

    // protected static用于那些需要被继承, 又不应该被重写的方法
    protected static ModelAndView createModelAndView(String view) {
        Map<String, Object> model = newModel();
        return createModelAndView(view, model);
    }

    protected static ModelAndView createModelAndView(String view, Object... values) {
        Map<String, Object> model = newModel();
        assert (values.length % 2) == 0;

        for (int i = 0; i < values.length; i++) {
            String paramName = (String) values[i++];
            model.put(paramName, values[i]);
        }
        return createModelAndView(view, model);
    }

    protected static ModelAndView createModelAndView(String view, Map<String, Object> model) {
        model.put("ViewUtils", ViewUtils.getInstance());
        return buildModelAndView(view, model);
    }

    protected static Map<String, Object> newModel() {
        return new HashMap<String, Object>();
    }

    protected static ModelAndView buildModelAndView(String view, Map<String, Object> model) {
        return new ModelAndView(view, model);
    }

    /* renderText series */

    /**
     * 将content的内容写入response
     * <li>事实上不需要, 也不会返回ModelAndView, 返回值只是为了和返回ModelAndView的方法统一</li>
     */
    protected static ModelAndView renderText(HttpServletResponse response, String content) {
        response.setContentType("text/plain;charset=utf-8");
        try {
            response.getWriter().write(content);
            return null;
        } catch (IOException e) {
            String message = "renderText failed";
            LOG.warningThis(message + ": " + content, e);
            throw new RuntimeException(message, e);
        }
    }

    protected static ModelAndView renderHtml(HttpServletResponse response, String content) {
        response.setContentType("text/html;charset=utf-8");
        try {
            response.getWriter().write(content);
            return null;
        } catch (IOException e) {
            String message = "renderText failed";
            LOG.warningThis(message + ": " + content, e);
            throw new RuntimeException(message, e);
        }
    }

    /** {"msg": 0} */
    @SuppressWarnings("unchecked")
    protected static ModelAndView renderMessage(HttpServletResponse response, int type) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg", type);
        return renderJson(response, jsonObject);
    }

    /** {"msg": "abc"} */
    @SuppressWarnings("unchecked")
    protected static ModelAndView renderMessage(HttpServletResponse response, String message) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg", message);
        return renderJson(response, jsonObject);
    }

    protected static ModelAndView renderJson(HttpServletResponse response, JSONObject json) {
        return renderJsonString(response, json.toJSONString());
    }

    protected static ModelAndView renderJsonString(HttpServletResponse response, String jsonString) {
        response.setContentType("application/json;charset=utf-8");
        try {
            response.getWriter().write(jsonString);
            return null;
        } catch (IOException e) {
            String message = "renderJson failed";
            LOG.warningThis(message + ": " + jsonString, e);
            throw new RuntimeException(message, e);
        }
    }

    /* username相关 */

    protected static String getEmail(HttpServletRequest request) {
        // 如果在白名单中, 则可以通过构造URL进行HTTP请求, 即getParameter
        if (isInWhiteList(request)) {
            String email = request.getParameter(CheckFilter.EMAIL_ATTR);
            if (!StringUtils.isBlank(email)) {
                return email;
            }
        }
        Object emailObj = request.getAttribute(CheckFilter.EMAIL_ATTR);
        return (emailObj == null) ? null : emailObj.toString();
    }

    protected static String getTrialId(HttpServletRequest request) {
        // 如果在白名单中, 则可以通过构造URL进行HTTP请求, 即getParameter
        if (isInWhiteList(request)) {
            String trial = request.getParameter(CheckFilter.TRIAL_ATTR);
            if (!StringUtils.isBlank(trial)) {
                return trial;
            }
        }
        Object trialObj = request.getAttribute(CheckFilter.TRIAL_ATTR);
        return (trialObj == null) ? null : trialObj.toString();
    }

    /* 其它 */

    /** 获取被请求的controller的别名, 比如/servlet/user.do?id=abc -> user */
    protected static String getControllerAlias(HttpServletRequest request) {
        // TODO: 使用servletPath
        String servletPath = request.getServletPath();
        LOG.warningThis("path: " + servletPath);
        String uri = request.getRequestURI();
        LOG.warningThis("uri: " + uri);

        // 截取最后一段path
        // 如果是root, 则返回default, 否则uri=最后一段path
        int i = uri.lastIndexOf('/');
        if (i == uri.length() - 1) {
            return "default";
        } else {
            uri = uri.substring(i + 1);
        }
        // 处理user.do
        i = uri.indexOf('.');
        if (i > 0) {
            return uri.substring(0, i);
        }
        // 处理user?id=abc
        i = uri.indexOf('?');
        if (i > 0) {
            return uri.substring(0, i);
        }

        // 其它
        return uri;
    }

    public static final String KEYFROM = "keyfrom";
    public static final String SESSION_FROM = "sessionFrom";
    public static final String SESSION_FROM_COOKIE = "SESSION_FROM_COOKIE";

    public static final String UNKNOWN = "unknown";

    /**
     * 如果有keyfrom, 则取得keyfrom
     * 如果没有keyfrom, 且请求来自当前服务的host之外, 则将refererHost作为keyfrom, 否则为null
     * 从cookie中取出sessionFrom, 根据keyfrom和这个sessionFrom的情况设置新的sessionFrom:
     * 1) 如果keyfrom为空
     * 1.1) 如果sessionFrom为空, 则为用户不带keyfrom首次访问, sessionFrom设为unknown
     * 1.2) 如果sessionFrom不为空, 则为用户不带keyfrom再次访问, sessionFrom保持不变
     * 2) 如果keyfrom不为空
     * 2.1) 如果keyfrom和sessionFrom一致, 则为用户带旧keyfrom再次访问, sessionFrom保持不变
     * 2.2) 如果keyfrom和sessionFrom不一致, 则为用户带新keyfrom再次访问呢, sessionFrom设为keyfrom
     */
    protected static void sessionFromFilter(HttpServletRequest request, HttpServletResponse response) {
        String thisHost = request.getHeader("Host");
        // keyfrom
        String keyfrom = request.getParameter(KEYFROM);
        keyfrom = filterKeyfrom(keyfrom);
        // keyfrom为空时, 用refererHost修正keyfrom
        if (StringUtils.isBlank(keyfrom)) {
            String referer = request.getHeader("Referer");
            String refererHost = StringUtils.isBlank(referer) ? null : UrlUtils.getHostFromUrl(referer);
            // 如果refererHost为空或者reg.163.com,
            // 或者refererHost为有道内部机群的机器域名,
            // 或者refererHost为当前服务的host, 则keyfrom=null
            keyfrom = StringUtils.isBlank(refererHost)
                || refererHost.equals("reg.163.com")
                || refererHost.equals("reg.youdao.com")
                || refererHost.endsWith("x.corp.youdao.com")
                || refererHost.equals(thisHost) ? null : refererHost;
        }
        // 从cookie中取出sessionFrom
        Cookie sessionFromCookie = CookieUtils.getCookie(request, SESSION_FROM_COOKIE);
        String sessionFrom = (sessionFromCookie == null) ? null : sessionFromCookie.getValue();
        // 根据情况设置新的sessionFrom
        if (StringUtils.isBlank(keyfrom)) {
            if (StringUtils.isBlank(sessionFrom)) { // 1.1
                sessionFrom = UNKNOWN;
                // 实际运行中domain可以为null, 但测试用例中不可以, 由于TestCookieUtils中调用了该函数...
                CookieUtils.addCookie(response, SESSION_FROM_COOKIE, sessionFrom, thisHost, "/", -1);
            }
        } else {
            if (!keyfrom.equals(sessionFrom)) { // 2.2
                sessionFrom = keyfrom;
                // 实际运行中domain可以为null, 但测试用例中不可以, 由于TestCookieUtils中调用了该函数...
                CookieUtils.addCookie(response, SESSION_FROM_COOKIE, sessionFrom, thisHost, "/", -1);
            }
        }

        // for request-logger
        request.setAttribute(SESSION_FROM, sessionFrom);
    }

    /**
     * 为response增加P3P头
     * <li>适用于有ocookie的项目</li>
     */
    protected static void p3pFilter(HttpServletRequest request, HttpServletResponse response) {
        // add p3p header
        response.addHeader("P3P", "CP=\" OTI DSP COR CURa OUR IND UNI COM \"");

        String userid = null;
        Cookie[] cookies = request.getCookies();
        // 如果有cookie, request-log就不会产生cookie了
        //  * 如果有一个cookie, 以此为准写跨域cookie
        //  * 如果有多个cookie, 以第一个为准写跨域cookie(和request-log的逻辑一致)
        //  * 事实上, 不管有多少个cookie, 都会被清掉(除非是ocookie刚写的cookie), 然后写跨域cookie
        // 如果没有cookie, 这里不会执行, request-log会产生cookie
        //  * ocookie写了这个cookie, 所以一定会执行
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("OUTFOX_SEARCH_USER_ID")) {
                    Cookie clear = new Cookie("OUTFOX_SEARCH_USER_ID", null);
                    clear.setMaxAge(0);
                    response.addCookie(clear);

                    if (userid == null) {
                        userid = cookie.getValue();
                    }
                }
            }
        }
        // 如果ocookie可以写到path=/且p3p对于之前的set-cookie起作用, 则可以不用再add?
        // 不行, 因为可能从别的地方带cookie进来, 这时ocookie是不会重写cookie到path=/的, 于是还是需要add(写到path=/)
        // 不过如果ocookie写到了path=/, 这两次写就会完全相同, 这样就不会出现两个cookie的情况
        // 而从别的地方带cookie进来的情况, 都会清除后重写, 也不会出现两个cookie的情况
        if (userid != null) {
            Cookie add = new Cookie("OUTFOX_SEARCH_USER_ID", "");
            add.setValue(userid);
            add.setDomain("youdao.com");
            add.setPath("/");
            add.setMaxAge(Integer.MAX_VALUE);
            response.addCookie(add);
        }
    }

    protected static boolean isInWhiteList(HttpServletRequest request) {
        return "true".equals(request.getAttribute(IN_FLAG_WHITELIST));
    }

    public static final Pattern pKeyfrom =
        Pattern.compile("^[a-z0-9][a-z0-9-\\.]{0,22}[a-z0-9]$", Pattern.CASE_INSENSITIVE);

    protected static String filterKeyfrom(String keyfrom) {
        if (StringUtils.isBlank(keyfrom)) {
            return null;
        } else if (pKeyfrom.matcher(keyfrom).matches()) {
            return keyfrom;
        } else {
            return null;
        }
    }

    //-- getters & setters --//

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public void setLogger(RequestLogger logger) {
        this.logger = logger;
    }

    public void setControllerLogger(RequestLogger controllerLogger) {
        this.controllerLogger = controllerLogger;
    }

    //-- iWritables --//
    //-- inner classes --//
}
