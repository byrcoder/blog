/** InsightBaseController */
package insight.common.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import insight.common.helper.LogHelper;
import insight.common.helper.VaqueroHelper;
import insight.common.web.WebServiceConfig;

/**
 * controller基类
 * <li>加入了user/uri/method的log, service-available的支持, analyzer(vaquero)的支持</li>
 * <li>内部处理函数internalHandleRequest可以被重写</li>
 *
 * @author liqiang
 */
public abstract class InsightBaseController extends SprivelController {

    //-- public finals --//
    //-- private finals --//

    private static final LogHelper LOG = LogHelper.getLogger(InsightBaseController.class);

    private static final String VIEW_SERVICE_NOT_AVAILABLE = "serviceNotAvailableView";

    //-- properties --//
    //-- constructors --//
    //-- destructors --//
    //-- implements --//

    /** 请求处理函数, 不能被重写, 调用内部处理函数internalHandleRequest */
    @Override
    protected final ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String controller = getControllerAlias(request);
        String method = request.getParameter(methodName);

        LOG.warningThis("handleRequestInternal ~ "
            + "user: " + getEmail(request)
            + ", controller: " + controller
            + ", " + methodName + ": " + method);

        if (WebServiceConfig.getConfig().isServiceAvailable()) {
            sessionFromFilter(request, response);

            boolean exception = false;
            long startTime = System.currentTimeMillis();
            try {
                return internalHandleRequest(request, response);
            } catch (Exception e) {
                exception = true;
                LOG.warningThis("internalHandleRequest failed", e);

                throw e;
            } finally {
                long executeTime = exception ? -1L : (System.currentTimeMillis() - startTime);
                // 记录controller调用记录
                if (controllerLogger != null) {
                    controllerLogger.log(controller, request, response);
                }
                // 记录vaquero需要的响应时间数据
                VaqueroHelper.log(controller + "." + method, executeTime);
            }
        } else {
            return createModelAndView(VIEW_SERVICE_NOT_AVAILABLE);
        }
    }

    /** 内部处理函数, 可以被重写 */
    protected ModelAndView internalHandleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        return super.handleRequestInternal(request, response);
    }

    //-- un-implements --//
    //-- methods --//
    //-- functions --//
    //-- utils --//
    //-- getters & setters --//
    //-- iWritables --//
    //-- inner classes --//
}
