package odis.tools.misc;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.channels.Selector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockInfo;
import odis.io.FSInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.TimeUtils;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.text.util.StringUtils;

/**
 * A multi thread download tool for downloading files from odfs.
 * 
 * @author yaming
 */
public class DownloadMultiThread implements ITool {

    private static final Logger LOG = LogFormatter.getLogger(DownloadMultiThread.class);

    private final Options options;

    private static final int BUFFER_SIZE = 64 * 1024;

    private FileSystem fs;

    private ExecutorService executor;

    private AtomicLong bytesDownloaded = new AtomicLong(0);

    public DownloadMultiThread() {
        options = new Options();
        options.withOption("fs", "filesystem", "zkPath@zkAddr").hasDefault();
        options.withOption("m", "thread number",
                "set the max threads used to download");
        options.addParam("srcFile", "source file").addParam("dstFile",
                "destination file").setMinimalParamCount(2);
    }

    private class DownloadTask implements Runnable {

        private final Path srcFile;

        private final File dstFile;

        private final long off;

        private final int len;

        public DownloadTask(Path srcFile, File dstFile, long off, int len) {
            this.srcFile = srcFile;
            this.dstFile = dstFile;
            this.off = off;
            this.len = len;
        }

        @Override
        public void run() {
            LOG.info("Start download section [" + off + ", " + (off + len)
                    + ") " + srcFile.getAbsolutePath() + "-->"
                    + dstFile.getAbsolutePath());
            FSInputStream in = null;
            RandomAccessFile out = null;
            try {
                in = fs.openRaw(srcFile);
                in.seek(off);
                out = new RandomAccessFile(dstFile, "rw");
                out.seek(off);
                byte[] buf = new byte[BUFFER_SIZE];
                for (int remaining = len; remaining > 0;) {
                    int read = in.read(buf);
                    if (read < 0) {
                        LOG.log(Level.SEVERE,
                                "Got unexpected EOF when downloading "
                                        + srcFile.getPath() + " off=" + off
                                        + " len=" + len + " failed");
                        LOG.info("Exit...");
                        System.exit(1);
                    }
                    remaining -= read;
                    out.write(buf, 0, read);
                }
                out.close();
                LOG.info("Successfully downloaded section [" + off + ", "
                        + (off + len) + ") " + srcFile.getAbsolutePath()
                        + "-->" + dstFile.getAbsolutePath());
            } catch (Exception e) {
                LOG.log(Level.SEVERE, "downloading " + srcFile.getPath()
                        + " off=" + off + " len=" + len + " failed", e);
                LOG.info("Exit...");
                System.exit(1);
            } finally {
                ReadWriteUtils.safeClose(in);
                ReadWriteUtils.safeClose(out);
            }
        }
    }

    private void downloadMT(Path srcFile, File dstFile) throws IOException {
        if (dstFile.exists()) {
            if (!dstFile.isDirectory()) {
                throw new IOException("Target " + dstFile + " already exists");
            } else {
                dstFile = new File(dstFile, srcFile.getName());
                if (dstFile.exists()) {
                    throw new IOException("Target " + dstFile
                            + " already exists");
                }
            }
        }
        if (fs.isDirectory(srcFile)) {
            if (!dstFile.mkdirs()) {
                throw new IOException("Create dir " + dstFile + " failed");
            }
            FileInfo contents[] = fs.listFiles(srcFile);
            for (int i = 0; i < contents.length; i++) {
                downloadMT(contents[i].getPath(), new File(dstFile,
                        contents[i].getPath().getName()));
            }
        } else {
            // touch the dst file
            new RandomAccessFile(dstFile, "rws").close();
            BlockInfo[] blocks = fs.getFileBlocksInfo(srcFile);
            if (blocks.length == 1 && blocks[0].getLength() == 0) {
                LOG.info("Skip file with no size: " + fs.getName()
                        + srcFile.getAbsolutePath() + "-->"
                        + dstFile.getAbsolutePath());
                return;
            }
            long off = 0;
            for (BlockInfo block: blocks) {
                executor.execute(new DownloadTask(srcFile, dstFile, off,
                        (int) block.getLength()));
                off += block.getLength();
            }
        }
    }

    public void download(Path srcFile, File dstFile, int threadNum)
            throws IOException {
        executor = Executors.newFixedThreadPool(threadNum, new ThreadFactory() {

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "Download-Worker");
                t.setDaemon(true);
                return t;
            }
        });
        bytesDownloaded.set(0);
        long startTime = System.currentTimeMillis();
        downloadMT(srcFile, dstFile);
        executor.shutdown();
        for (;;) {
            try {
                if (executor.awaitTermination(5, TimeUnit.MINUTES)) {
                    break;
                }
            } catch (InterruptedException e) {
                continue;
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            LOG.info("Waiting termination, elapsed " + elapsedTime + "ms, "
                    + bytesDownloaded.get() + " bytes downloaded");
        }
        long elapsedTime = System.currentTimeMillis() - startTime;
        LOG.info("Download finished, total elapsed time: " + elapsedTime
                + " ms (" + TimeUtils.getTime(elapsedTime) + ")");
        long bytesDownloaded = this.bytesDownloaded.get();
        LOG.info("Total bytes downloaded: " + bytesDownloaded + "("
                + StringUtils.byteDesc(bytesDownloaded) + "). Throughput: "
                + (bytesDownloaded / 1024.d / 1024.d / elapsedTime) + " MB/s");
    }

    public void setFileSystem(FileSystem fs) {
        this.fs = fs;
    }

    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "mtget");
    }

    public boolean exec(String[] args) throws IOException {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            usage(out);
            return false;
        }
        String fsName = options.getStringOpt("fs");
        fs = fsName == null ? FileSystem.get() : FileSystem.getNamed(fsName);
        int threadNum = options.getIntOpt("m");
        Path srcFile = new Path(options.getRemains()[0]);
        File dstFile = new File(options.getRemains()[1]);

        // jdk's bug, see: http://bugs.sun.com/view_bug.do?bug_id=6427854
        Selector selector = Selector.open();
        selector.close();
        download(srcFile, dstFile, threadNum);
        return true;
    }

    public static void download(String fsName, String srcFile, String dstFile,
            int threadNum) throws IOException {
        download(fsName, new Path(srcFile), new File(dstFile), threadNum);
    }

    public static void download(String fsName, Path srcFile, File dstFile,
            int threadNum) throws IOException {
        FileSystem fs = fsName == null ? FileSystem.get()
                : FileSystem.getNamed(fsName);
        download(fs, srcFile, dstFile, threadNum);
    }

    public static void download(FileSystem fs, Path srcFile, File dstFile,
            int threadNum) throws IOException {
        DownloadMultiThread dmt = new DownloadMultiThread();
        dmt.setFileSystem(fs);
        dmt.download(srcFile, dstFile, threadNum);
    }

    public String comment() {
        return "Download(multi thread) file from odfs to local filesystem.";
    }
}
