package odis.tools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import toolbox.collections.ArrayUtils;
import toolbox.misc.ClassUtils;

/**
 * Helper to build testcase for cowork jobs.
 * 
 * @author river
 */
public class ToolTestHelper {

    /**
     * Create sequence file with given objects.
     * 
     * @param fs
     * @param file
     * @param keys
     * @param vals
     * @param ordered
     * @throws IOException
     */
    public static void createSequenceFile(FileSystem fs, File file,
            Object[] keys, Object[] vals, boolean ordered) throws IOException {
        assert keys.length > 0;
        assert keys.length == vals.length;
        if (ordered)
            ArrayUtils.sortArrays(new Object[] {
                keys, vals
            });
        SequenceFile.Writer writer = new SequenceFile.Writer(fs,
                new Path(file), keys[0].getClass(), vals[0].getClass());
        try {
            int len = keys.length;
            for (int i = 0; i < len; i++) {
                writer.write((IWritable) keys[i], (IWritable) vals[i]);
            }
        } finally {
            writer.close();
        }
    }

    /**
     * Create indexed file with given objects.
     * 
     * @param fs
     * @param file
     * @param keys
     * @param vals
     * @throws IOException
     */
    public static void createIndexedFile(FileSystem fs, File file,
            Object[] keys, Object[] vals) throws IOException {
        assert keys.length > 0;
        assert keys.length == vals.length;
        ArrayUtils.sortArrays(new Object[] {
            keys, vals
        });
        IndexedFile.Writer writer = new IndexedFile.Writer(fs, new Path(file),
                keys[0].getClass(), vals[0].getClass());
        try {
            int len = keys.length;
            for (int i = 0; i < len; i++) {
                writer.write((IWritable) keys[i], (IWritable) vals[i]);
            }
        } finally {
            writer.close();
        }
    }

    /**
     * Check if the given sequence file includes specified keys and values.
     * 
     * @param fs
     * @param file
     * @param keys
     * @param vals
     * @throws IOException
     */
    public static void checkSequenceFile(FileSystem fs, File file,
            Object[] keys, Object[] vals) throws IOException {
        Map<Object, Object> map = new HashMap<Object, Object>();
        for (int i = 0; i < keys.length; i++) {
            if (vals != null && vals.length > i)
                map.put(keys[i], vals[i]);
            else
                map.put(keys[i], null);
        }
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, new Path(file));
        try {
            IWritable key = ClassUtils.newInstance(reader.getKeyClass());
            IWritable value = ClassUtils.newInstance(reader.getValueClass());
            while (!map.isEmpty()) {
                assertTrue(reader.next(key, value));
                assertTrue(map.containsKey(key));
                Object o = map.remove(key);
                if (o != null)
                    assertEquals(o, value);
            }
            assertFalse(reader.next(key, value));
        } finally {
            reader.close();
        }
    }

    /**
     * Create a map<String, String[]> by given "String[][]" data, the first
     * string in each "String[]" is key.
     * 
     * @param data
     * @return
     */
    public static Map<String, String[]> createMap(String[][] data) {
        HashMap<String, String[]> result = new HashMap<String, String[]>();
        for (String[] entry: data) {
            result.put(entry[0], entry);
        }
        return result;
    }

}
