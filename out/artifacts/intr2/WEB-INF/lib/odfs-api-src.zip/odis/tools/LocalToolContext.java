package odis.tools;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Properties;

import odis.conf.OdisClientContext;
import odis.dfs.client.DFSClientContext;

import odis.io.FileSystem;
import odis.io.FullPath;
import odis.io.Path;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.FileUtils;
import toolbox.misc.cli.ArgumentProcessor;

/**
 * Environment for local tools.
 * 
 * @author river, David
 */
public class LocalToolContext extends OdisClientContext {

    public static final String APP_DFS_ROOT = "dfs.root";

    public static final String APP_DFS_TEMP = "dfs.temp";

    public static final String APP_TASK_LOGLEVEL = "task.debug-level";

    public static final String APP_TASK_HEAPSIZE = "task.heap-size";

    protected String instanceName;

    protected int instanceIdx;

    public LocalToolContext() {
        this(getConfig().getString("app.default"));
    }

    /**
     * Create a context given instance name
     * 
     * @param instance
     *            instance must exist and not be null
     */
    public LocalToolContext(String instance) {
        setApp(instance);
    }

    private void setApp(String instance) {
        if (instance == null || instance.equals("null")) {
            this.instanceName = null;
            this.instanceIdx = -1;
        } else {
            this.instanceName = instance;
            Integer idx = instanceMap.get(instance);
            if (idx != null)
                this.instanceIdx = idx;
            else
                throw new RuntimeException("Cannot find instance " + instance);
        }
    }

    /**
     * Set the cowork address of this environment.
     * 
     * @param cwAddr
     */
    public void setCoWork(String cwAddr) {
        getConfig().setProperty(APP_COWORK, cwAddr);
    }

    public String getApp() {
        return instanceName;
    }

    /**
     * @return cowork service address to be used by cowork applications
     */
    public InetSocketAddress getCoWork() {
        return getDefaultCoWork();
    }

    public String getCwAddress() {
        return getConfig().getString(APP_COWORK, "local");
    }

    /**
     * @return file system to be used by cowork applications
     * @throws IOException
     */
    public FileSystem getFileSystem() throws IOException {
        return DFSClientContext.getNamed(instanceName, true);
    }

    /**
     * Get the filesystem name of an application
     * 
     * @return the file system name, i.e. host:port
     */
    public String getAppFs() {
        return instanceIdx < 0 ? "local" : getFsName(instanceIdx, "local");
    }

    public String getAppRoot() {
        return getAppString(APP_DFS_ROOT, "/");
    }

    public String getAppTemp() {
        return concatPath(getAppRoot(), getAppString(APP_DFS_TEMP, "temp")).getPath();
    }

    private Path concatPath(String root, String... names) {
        if (root == null) {
            throw new RuntimeException("cannot find root/temp path setting");
        }

        StringBuilder buf = new StringBuilder();
        for (String s: names) {
            buf.append(s).append(File.separator);
        }
        if (buf.length() > 0) {
            buf.setLength(buf.length() - 1);
        }
        String filename = buf.toString();
        if (FileUtils.isAbsolutePath(filename)) {
            return new Path(filename);
        } else {
            return new Path(root, filename);
        }
    }

    /**
     * Create a path under the root.
     * 
     * @param names
     * @return
     */
    public Path path(String... names) {
        return concatPath(getAppRoot(), names);
    }

    /**
     * Create a full-path under the root.
     * 
     * @param names
     * @return
     */
    public FullPath fullpath(String... names) {
        return new FullPath(getAppFs(), concatPath(getAppRoot(), names));
    }

    /**
     * Concat the path and return the file under root.
     * 
     * @param names
     * @return
     */
    public File file(String... names) {
        return path(names).asFile();
    }

    /**
     * Return the temporary directory path.
     * 
     * @param names
     * @return
     */
    public Path tempPath(String... names) {
        return concatPath(getAppTemp(), names);
    }

    /**
     * Return the temporary directory as file.
     * 
     * @param names
     * @return
     */
    public File tempFile(String... names) {
        return tempPath(names).asFile();
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("[app=" + instanceName);
        sb.append(",fs=" + getAppFs());
        sb.append(",cw=" + getCwAddress() + "]");
        return sb.toString();
    }

    String[] displayArguments() {
        return new String[] {
            "-ap application - application name. DEFAULT: " + instanceName,
            "-cw cowork - address of cowork service. DEFAULT: "
                    + getCwAddress()
        };
    }

    void setToArguments(ArgumentProcessor p) {
        p.addArguments("ap", 1, "DEF:" + instanceName, "cw", 1, "DEF:"
                + getCwAddress());
    }

    void getFromArguments(ArgumentProcessor p) {
        String appName = p.isOptSet("ap") ? p.getStringOpt("ap") : null;
        String cwAddr = p.isOptSet("cw") ? p.getStringOpt("cw") : null;
        if (appName != null)
            setApp(appName);
        if (cwAddr != null)
            setCoWork(cwAddr);
    }

    ///////////////////////////////////////////////////////////////////////////
    // Access Method
    ///////////////////////////////////////////////////////////////////////////

    public boolean getAppBoolean(String name, boolean defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getBoolean(appName, defaultValue);
    }

    public byte getAppByte(String name, byte defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getByte(appName, defaultValue);
    }

    public boolean getBoolean(String name, boolean defaultValue) {
        return getConfig().getBoolean(name, defaultValue);
    }

    public short getAppShort(String name, short defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getShort(appName, defaultValue);
    }

    public int getAppInt(String name, int defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getInt(appName, defaultValue);
    }

    public long getAppLong(String name, long defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getLong(appName, defaultValue);
    }

    public float getAppFloat(String name, float defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getFloat(appName, defaultValue);
    }

    public double getAppDouble(String name, double defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getDouble(appName, defaultValue);
    }

    public String getAppString(String name, String defaultValue) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getString(appName, defaultValue);
    }

    public String[] getAppStringArray(String name) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getStringArray(appName);
    }

    public Properties getAppProperties(String name) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        return getConfig().getProperties(appName);
    }

    public Configuration getAppSubConfig(String prefix) {
        String appPrefix = "app.instance(" + instanceIdx + ")." + prefix;
        return getConfig().subset(appPrefix);
    }

    /**
     * @deprecated Only use this method in testcases.
     */
    @Deprecated
    public void setAppInt(String name, int value) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        getConfig().setProperty(appName, value + "");
    }

    /**
     * @deprecated Only use this method in testcases.
     */
    @Deprecated
    public void setAppLong(String name, long value) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        getConfig().setProperty(appName, value + "");
    }

    /**
     * @deprecated Only use this method in testcases.
     */
    @Deprecated
    public void setAppFloat(String name, float value) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        getConfig().setProperty(appName, value + "");
    }

    /**
     * @deprecated Only use this method in testcases.
     */
    @Deprecated
    public void setAppString(String name, String value) {
        String appName = "app.instance(" + instanceIdx + ")." + name;
        getConfig().setProperty(appName, value);
    }

    @Deprecated
    public static void addApp(String app, String fs, String root) {
        int idx = instanceMap.size();
        instanceMap.put(app, idx);
        getConfig().setProperty("app.instance(" + idx + ")." + APP_DFS, fs);
        getConfig().setProperty("app.instance(" + idx + ")." + APP_DFS_ROOT,
                root);
    }

    ///////////////////////////////////////////////////////////////////////////
    // backward compatibility
    ///////////////////////////////////////////////////////////////////////////

    /**
     * @deprecated Use {@link #getFileSystem()} instead
     */
    @Deprecated
    public FileSystem getDbFs() throws IOException {
        return getFileSystem();
    }

    /**
     * @deprecated Use {@link #getCoWork()} instead
     * @return
     */
    @Deprecated
    public InetSocketAddress getJobAddr() {
        return getCoWork();
    }
}
