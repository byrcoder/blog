/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package odis.tools.misc;

import java.io.PrintWriter;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSFileStatus;
import odis.io.FileSystem;
import odis.io.Path;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.collections.primitive.IntegerArrayList;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Look for files with missing blocks
 * 
 * @author zhangkun
 */
public class PrintBlockMissingFilesTool implements ITool {

    private final Options options;

    public PrintBlockMissingFilesTool() {
        options = new Options();
        options.withOption("fs", "filesystem", "zkPath@zkAddr");
        options.withOption("dir", "directory", "the directory to be checked");
    }

    public void usage(PrintWriter out) {
        options.printHelpInfo(System.out, "chkblkmiss");
    }

    private static final DateTimeFormatter DATE_FORMATER = DateTimeFormat.forPattern("yyyyMMdd-HHmmss");

    private static String getFileInfo(DFSFileStatus info) {
        return DATE_FORMATER.print(info.getLastModified()) + " "
                + info.getContentsLength() + " " + info.getPath();
    }

    public static void check(DFSClient fs, DFSFileStatus info) throws Exception {
        if (info == null) {
            return;
        }
        String path = info.getPath();
        if (info.isDir()) {
            DFSFileStatus[] files = fs.listFiles(path);
            if (files != null) {
                for (DFSFileStatus file: files) {
                    check(fs, file);
                }
            }
        } else {
            // is file
            BlockSizeLocationWithDataPath[] blocks = null;
            try {
                blocks = fs.getFileBlockLocations(path);
            } catch (Exception e) {
                System.out.println(getFileInfo(info)
                        + " failed in getFileBlockLocations");
                return;
            }

            if (blocks == null) {
                System.out.println(getFileInfo(info) + " got null info");
                return;
            }
            IntegerArrayList missingBlocks = new IntegerArrayList();
            for (int i = 0; i < blocks.length; i++) {
                if (blocks[i].getLocations().length == 0) {
                    missingBlocks.add(i);
                }
            }
            if (!missingBlocks.isEmpty()) {
                System.out.print(getFileInfo(info) + " missing blocks:");
                for (int i = 0; i < missingBlocks.size(); i++) {
                    int blockIndex = missingBlocks.get(i);
                    System.out.print(" " + blocks[blockIndex].getBlock() + "("
                            + blockIndex + ")");
                    if (blockIndex == blocks.length - 1) {
                        System.out.print("(LAST)");
                    }
                }
                System.out.println();
            }
        }
    }

    public boolean exec(String[] args) throws Exception {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e1) {
            usage(out);
            return false;
        }

        String fsName = options.getStringOpt("fs");
        String dirName = options.getStringOpt("dir");
        DistributedFileSystem fs = (DistributedFileSystem) FileSystem.getNamed(fsName);
        try {
            DFSFileStatus info = fs.getFileStatus(new Path(dirName));
            check(fs.getDFSClient(), info);
        } finally {
            fs.close();
        }
        return true;
    }

    public String comment() {
        return "Look for files with missing blocks";
    }

}
