/**
 * @(#)XferTool.java, 2013-1-7. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.tools.misc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.DataNodeRequest;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.util.DfsUtils;
import odis.io.CDataOutputStream;
import odis.io.FileSystem;
import odis.io.InterruptibleSocket;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import odis.util.ThreadLocalRandomData;
import toolbox.misc.LogFormatter;
import toolbox.misc.TimeUtils;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.text.util.StringUtils;

/**
 * @author zhangduo
 */
public class XferTool implements ITool {

    private static final Logger LOG = LogFormatter.getLogger(XferTool.class);

    private final Options options;

    private DistributedFileSystem srcFs;

    private Path srcPath;

    private DistributedFileSystem dstFs;

    private Path dstPath;

    private boolean increment;

    private ExecutorService executor;

    private int parallel = 4;

    private int replication = FSConstants.NUM_REPLICAS_INHERITED;

    private long timeout = 600000L;

    private final AtomicLong bytesTransferred = new AtomicLong(0);

    private final ConcurrentLinkedQueue<Path> failed = new ConcurrentLinkedQueue<Path>();

    public XferTool() {
        options = new Options();
        options.withOption("srcfs", "source filesystem", "zkPath@zkAddr");
        options.withOption("dstfs", "destination filesystem", "zkPath@zkAddr");
        options.withSharedOption("m", "thread number",
                "set the max threads used to xfer").setDefault(4);
        options.withSharedOption("r", "replication number").setDefault(
                FSConstants.NUM_REPLICAS_INHERITED);
        options.withSharedOption("inc", "set the xfer to be increment");
        options.withSharedOption("t", "timeout",
                "timeout for waiting one block xfer down(in milliseconds)").setDefault(
                600000L);
        options.addParam("srcPath", "source path").addParam("dstPath",
                "destination path").setMinimalParamCount(2);
    }

    public void setSrcFs(DistributedFileSystem srcFs) {
        this.srcFs = srcFs;
    }

    public void setSrcPath(Path srcPath) {
        this.srcPath = srcPath;
    }

    public void setDstFs(DistributedFileSystem dstFs) {
        this.dstFs = dstFs;
    }

    public void setDstPath(Path dstPath) {
        this.dstPath = dstPath;
    }

    public void setIncrement(boolean increment) {
        this.increment = increment;
    }

    public void setParallel(int parallel) {
        this.parallel = parallel;
    }

    public void setReplication(int replication) {
        this.replication = replication;
    }

    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }

    private int xferBlock(String dataNode, long srcBlock,
            BlockLocationWithDataPath dstBlock) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        CDataOutputStream dos = new CDataOutputStream(bos);
        DataNodeRequest req = new DataNodeRequest(
                DataNodeRequest.Op.TRANSFER_BLOCK);
        DataNodeRequest.TransferBlockBody reqBody = (DataNodeRequest.TransferBlockBody) req.getBody();
        reqBody.setSrcBlock(srcBlock);
        reqBody.setDestBlock(dstBlock.getBlock());
        reqBody.setTargets(dstBlock.getLocations());
        req.writeFields(dos);
        InterruptibleSocket socket = new InterruptibleSocket(
                new InetSocketAddress(
                        BlockLocationWithDataPath.getHostFromLocation(dataNode),
                        BlockLocationWithDataPath.getPortFromLocation(dataNode)),
                timeout);
        try {
            bos.writeTo(socket.getOutputStream());
            return socket.getInputStream().read();
        } finally {
            ReadWriteUtils.safeClose(socket);
        }
    }

    private BlockLocationWithDataPath addBlock(String srcFile,
            DFSClient dstClient, String dstFile, int blockIndex)
            throws IOException {
        for (int retry = 0;; retry++) {
            try {
                return dstClient.addBlock(dstFile, blockIndex);
            } catch (FSException e) {
                if (e.getCode() != FSException.NOT_ENOUGH_RESOURCE
                        && e.getCode() != FSException.NOT_ENOUGH_REPLICATION) {
                    throw e;
                }
                LOG.log(Level.WARNING, "Xfer " + srcFile + " -> " + dstFile
                        + ", allocated " + blockIndex
                        + "th block failed, retry=" + (retry + 1), e);
                DfsUtils.waitExpTime(retry);
            }
        }
    }

    private void complete(String srcFile, DFSClient dstClient, String dstFile)
            throws IOException {
        for (int retry = 0;; retry++) {
            try {
                dstClient.complete(dstFile);
                return;
            } catch (FSException e) {
                if (e.getCode() != FSException.NOT_ENOUGH_RESOURCE
                        && e.getCode() != FSException.NOT_ENOUGH_REPLICATION) {
                    throw e;
                }
                LOG.log(Level.WARNING, "Xfer " + srcFile + " -> " + dstFile
                        + ", complete failed, retry=" + (retry + 1), e);
                DfsUtils.waitExpTime(retry);
            }
        }
    }

    private void xferFile(Path src, Path dst) throws IOException {
        String srcFile = srcFs.getPath(src);
        String dstFile = dstFs.getPath(dst);
        LOG.info("Start xfer " + srcFile + " -> " + dstFile);
        DFSClient srcClient = srcFs.getDFSClient();
        DFSFileStatus srcStatus = srcClient.getFileStatus(srcFile);
        BlockSizeLocationWithDataPath[] blocks = srcClient.getFileBlockLocations(srcFile);
        DFSClient dstClient = dstFs.getDFSClient();
        outer: for (int i = 0; i < blocks.length; i++) {
            BlockSizeLocationWithDataPath srcBlock = blocks[i];
            String[] dataNodes = srcBlock.getLocations();
            for (int j = 0; j < dataNodes.length; j++) {
                // switch dst block every time because previous block may 
                // being written at this time.
                BlockLocationWithDataPath dstBlock;
                if (i == 0) {
                    dstBlock = dstClient.createRaw(dstFile, true, true,
                            replication, (int) dstFs.getBlockSize(),
                            srcStatus.getPermission());
                } else {
                    dstBlock = addBlock(srcFile, dstClient, dstFile, i);
                }
                String dataNode = dataNodes[ThreadLocalRandomData.current().nextInt(
                        dataNodes.length - j)];
                try {
                    LOG.info("Xfer " + srcFile + " -> " + dstFile + ", xfer "
                            + i + "th block " + srcBlock + " as "
                            + dstBlock.getBlock() + " from " + dataNode
                            + " to " + Arrays.toString(dstBlock.getLocations()));
                    int successCount = xferBlock(dataNode, srcBlock.getBlock(),
                            dstBlock);
                    if (successCount <= 0) {
                        LOG.warning("Xfer " + srcFile + " -> " + dstFile
                                + ", xfer " + i
                                + "th block failed to write to any targets");
                    } else {
                        if (successCount < dstBlock.getLocations().length) {
                            LOG.info("Only successfully written "
                                    + dstBlock.getBlock() + " to "
                                    + successCount
                                    + " datanodes (intended targets are "
                                    + dstBlock.getLocations().length);
                        } else {
                            LOG.info("Successfully written "
                                    + dstBlock.getBlock() + " to "
                                    + successCount + " datanodes.");
                        }
                        bytesTransferred.addAndGet(srcBlock.getLen());
                        continue outer;
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "xfer " + srcFile + " -> " + dstFile
                            + ", xfer " + i + "th block failed", e);
                }
                if (i == 0) {
                    dstClient.abandonFileInProgress(dstFile);
                } else {
                    dstClient.abandonBlock(dstFile, i);
                }
                DfsUtils.waitExpTime(j);
                DfsUtils.swap(dataNodes, j, dataNodes.length - j - 1);
            }
            throw new IOException("Xfer " + srcFile + " -> " + dstFile
                    + ", xfer " + i + "th block " + srcBlock + " failed "
                    + dataNodes.length + " times, no datanode available.");
        }
        complete(srcFile, dstClient, dstFile);
    }

    private void doXferMT(final Path src, final Path dst) throws IOException {
        DFSFileStatus srcStatus = srcFs.getFileStatus(src);
        DFSFileStatus dstStatus = dstFs.getFileStatus(dst);
        if (!increment && dstStatus != null) {
            throw new IOException("Destination " + dst + " already exists");
        }
        if (srcStatus.isDir()) {
            if (dstStatus == null) {
                dstFs.mkdirs(dst, replication, srcStatus.getPermission());
            }
            for (Path path: srcFs.listPaths(src)) {
                doXferMT(path, dst.cat(path.getName()));
            }
        } else {
            if (increment) {
                if (dstStatus != null) {
                    if (srcStatus.getContentsLength() == dstStatus.getContentsLength()) {
                        LOG.info("Skip dst " + dst + " for it already exists.");
                        return;
                    } else {
                        LOG.info("Dst "
                                + dst
                                + " needs to be retransferred for its content length is wrong.");
                    }
                }
            }
            executor.execute(new Runnable() {

                @Override
                public void run() {
                    try {
                        xferFile(src, dst);
                    } catch (Exception e) {
                        LOG.log(Level.WARNING, "xfer " + src + " -> " + dst
                                + " failed", e);
                        failed.add(src);
                    }
                }
            });

        }
    }

    public boolean xfer() throws IOException, InterruptedException {
        executor = Executors.newFixedThreadPool(parallel, new ThreadFactory() {

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "Xfer-Worker");
                t.setDaemon(true);
                return t;
            }
        });
        this.bytesTransferred.set(0);
        long startTime = System.currentTimeMillis();
        doXferMT(srcPath, dstPath);
        executor.shutdown();
        while (!executor.awaitTermination(5, TimeUnit.MINUTES)) {
            long elapsedTime = System.currentTimeMillis() - startTime;
            LOG.info("Waiting termination, elapsed " + elapsedTime + "ms");
        }
        long elapsedTime = System.currentTimeMillis() - startTime;
        LOG.info("Total elapsed time: " + elapsedTime + " ms ("
                + TimeUtils.getTime(elapsedTime) + ")");
        long bytesTransferred = this.bytesTransferred.get();
        LOG.info("Total bytes transferred: " + bytesTransferred + "("
                + StringUtils.byteDesc(bytesTransferred) + "). Throughput: "
                + (bytesTransferred / 1024.d / 1024.d / elapsedTime) + " MB/s");
        if (!failed.isEmpty()) {
            LOG.info("Total " + failed.size() + " tasks failed");
            for (Path f: failed) {
                LOG.info("\t" + f);
            }
        }
        LOG.info("Xfer completed");
        return failed.isEmpty();
    }

    @Override
    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "xfer");
    }

    @Override
    public String comment() {
        return "Transfer directory(multi threaded) from one odfs to another";
    }

    @Override
    public boolean exec(String[] args) throws IOException, InterruptedException {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            usage(out);
            return false;
        }
        DistributedFileSystem srcFs = (DistributedFileSystem) FileSystem.getNamed(options.getStringOpt("srcfs"));
        DistributedFileSystem dstFs = (DistributedFileSystem) FileSystem.getNamed(options.getStringOpt("dstfs"));
        try {
            setSrcFs(srcFs);
            setDstFs(dstFs);
            setIncrement(options.isOptSet("inc"));
            setParallel(options.getIntOpt("m"));
            setReplication(options.getIntOpt("r"));
            setTimeout(options.getLongOpt("t"));
            setSrcPath(new Path(options.getRemains()[0]));
            setDstPath(new Path(options.getRemains()[1]));
            return xfer();
        } finally {
            srcFs.close();
            dstFs.close();
        }
    }
}
