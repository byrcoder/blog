package odis.tools.misc;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.LocalJournalManager;
import odis.dfs.journal.qjournal.client.QuorumJournalManager;
import odis.dfs.metrics.QjmMetricsItem;
import odis.dfs.util.DfsUtils;

import org.apache.commons.configuration.Configuration;

import toolbox.maintain.alarm.Emailer;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.text.util.StringUtils;

public class QjmTestTool {
    static Logger LOG = LogFormatter.getLogger(QjmTestTool.class);
    
    private static final Options options;

    static {
        options = new Options();
        options.withOption("logSize", "max log file size(M)").setDefault(150);
        options.withOption("buf", "buf size(byte)").setDefault(1024);
        options.withOption("h", "help");
        options.withOption("l", "log to file");
        options.withOption("m", "print metrics");
    }
    
    LogChecker logChecker;

    Thread logCheckerThread;
    
    LinkedList<Long> logToCheck = new LinkedList<Long>();

    Map<Long, Integer> failedTimes = new HashMap<Long, Integer>();

    static String sendEmail = "postmaster@rd.netease.com";

    static String reportEmail = "chenxi@rd.netease.com";
    
    static long logFileSize = 100 * 1024 * 1024; // 100M
    
    static long minLogFileSize = 30 * 1024 * 1024; //30M
    
    static int bufSize = 1024;
    
    static boolean printMetrics = false;

    static Emailer mailer = new Emailer();
    
    static Random rand = new Random();
    
    boolean running = true;
    
    boolean isOpen = false;
    
    long currentSN = Long.MAX_VALUE;
    
    QuorumJournalManager qjmWriter = null;
    LocalJournalManager ljmWriter = null;

    QuorumJournalManager qjmReader = null;
    LocalJournalManager ljmReader = null;

    public void run() {
        LOG.info("Using logFileSize=" + logFileSize);
        LOG.info("Using bufSzie=" + bufSize);
        
        startLogChecker();
        
        long nextSleep = 60 * 1000; //1 min
        
        while (running) {
            try {
                writeLog();
            } catch (IOException e) {
                isOpen = false;
                LOG.warning("write log exception: " + e.getMessage()
                        + DfsUtils.getStrackTrace(e));
            } finally {
                printMetrics("write log", qjmWriter);
            }
            
            try {
                Thread.sleep(nextSleep);
            } catch (InterruptedException ie) {}
            if (!logCheckerThread.isAlive()) {
                LOG.info("Log checker thread is down, trying to restart log checker...");
                logChecker.stop();
                startLogChecker();
            }
        }
    }
    
    public void stop() {
        running = false;
    }
    
    private void startLogChecker() {
        logChecker = new LogChecker();
        logCheckerThread = new Thread(logChecker);
        logCheckerThread.setDaemon(true);
        logCheckerThread.start();
        
        LOG.info("Starting log checker as  daemon...");
    }
    
    private void createJournalManager() throws IOException {
        LOG.info("Starting create journal manager...");
        Configuration conf = DFSConfig.conf();
        if (null != qjmWriter) {
            qjmWriter.close();
        }
        if (null != ljmWriter) {
            ljmWriter.close();
        }
        qjmWriter = new QuorumJournalManager(conf);
        ljmWriter = new LocalJournalManager(conf);
    }
    
    private void writeLog() throws IOException {
        LOG.info("Starting write log...");
        if (!isOpen) {
            createJournalManager();
            qjmWriter.recoverUnfinalizedSegmentAndStartNewSegment(0);
            ljmWriter.recoverUnfinalizedSegmentAndStartNewSegment(0);
        } 
        
        // 检查当前打开的segment是否正确
        // 如果不正确尝试恢复，恢复不了报错
        long qjmSN = qjmWriter.currentOpenedSegmentSN();
        long ljmSN = ljmWriter.currentOpenedSegmentSN();
        if (qjmSN != ljmSN) {
            LOG.warning("Different sn in qjm=" + qjmSN + " vs ljm=" + ljmSN);
            long miniSN = Math.max(qjmSN, ljmSN) + 1;
            
            this.createJournalManager();
            
            qjmWriter.recoverUnfinalizedSegmentAndStartNewSegment(miniSN);
            ljmWriter.recoverUnfinalizedSegmentAndStartNewSegment(miniSN);
            
            qjmSN = qjmWriter.currentOpenedSegmentSN();
            ljmSN = ljmWriter.currentOpenedSegmentSN();
            if (qjmSN != ljmSN) {
                String errMsg = "Qjm and LJM opened to different SN even after error handling";
                reportError(errMsg);
                throw new IOException(errMsg);
            }
        }
        
        //开始写数据
        synchronized (logToCheck) {
            logToCheck.addLast(qjmSN);
        }
        currentSN = qjmSN;
        long byteToWrite = minLogFileSize + Math.abs(rand.nextLong())
                % logFileSize;
        LOG.info("write segment sn=" + qjmSN + ", fileSize=" + byteToWrite);

        byte[] record = new byte[bufSize];
        while (byteToWrite > 0) {
            rand.nextBytes(record);
            ljmWriter.write(record);
            qjmWriter.write(record);
            byteToWrite -= bufSize;
        }
        
        qjmWriter.finalizeSegmentAndStartNewSegment();
        ljmWriter.finalizeSegmentAndStartNewSegment();
        LOG.info("write segment sucesss. sn=" + qjmSN);
        isOpen = true;
        currentSN += 1;
    }
    
    static void reportError(String errMsg) {
        LOG.severe(errMsg);
        mailer.sendEmail(sendEmail, reportEmail, "QjmTestError", errMsg, null);
    }
    
    private class LogChecker implements Runnable {
        private boolean shouldRun = true;

        private long expiryInterval = 1 * 60 * 1000; // 3min

        private long nextSleep = expiryInterval / 3;
        
        byte[] qjmBuf = new byte[bufSize];

        
        public void run() {
            while (shouldRun) {
                try {
                    Thread.sleep(nextSleep);
                } catch (InterruptedException ie) {}
                try {
                    checkLog();
                } catch (Exception e) {
                    LOG.warning("Exception in checkLog:" + e.getMessage()
                            + DfsUtils.getStrackTrace(e));
                } finally {
                    printMetrics("read log", qjmReader);
                }
            }
        }

        private void checkLog() throws IOException {
            LOG.info("Starting check log..."  + logToCheck.size());
            if (null == qjmReader) {
                Configuration conf = DFSConfig.conf();
                qjmReader = new QuorumJournalManager(conf);
                ljmReader = new LocalJournalManager(conf);
            }

            long sn = 0;
            synchronized (logToCheck) {
                if (logToCheck.isEmpty()) {
                    LOG.info("No log to check...");
                    return;
                }
                sn = logToCheck.removeFirst();
            }
            LOG.info("Checking log sn=" + sn + ", curWritenSN=" + currentSN);

            InputStream qjmInput = null;
            InputStream localInput = null;
            qjmInput = qjmReader.openFinalizedSegment(sn);
            localInput = ljmReader.openFinalizedSegment(sn);
            if (null == qjmInput) {
                if (currentSN <= sn) {
                    synchronized (logToCheck) {
                        logToCheck.addFirst(sn);
                    }
                    return;
                } else {
                    throw new IOException("Can't open log with sn=" + sn);
                }
            }

            try {
                long qjmLen;
                byte localIn;
                while (true) {
                    qjmLen = qjmInput.read(qjmBuf);
                    if (-1 == qjmLen) {
                        break;
                    }
                    // 读取qjm数据在buf里，然后一个byte一个byte读取本地数据比较
                    // 如果比较出错，把sn加入等待检查队列末尾，等待下次check。
                    // 如果3次检查log都失败，那么放弃检查sn抛出异常。
                    for (int i = 0; i < qjmLen; ++i) {
                        localIn = (byte) localInput.read();
                        if (localIn != qjmBuf[i]) {
                            throw new IOException(
                                    "local input and qjm input is different at sn="
                                            + sn);

                        }
                    }
                }
            } catch (IOException e) {
                int failed = 0;
                if (failedTimes.containsKey(sn)) {
                    failed = failedTimes.get(sn);
                }
                ++failed;
                if (failed >= 3) {
                    String errMsg = "Failed to check sn=" + sn;
                    reportError(errMsg);
                    throw new IOException(errMsg);
                }

                failedTimes.put(sn, failed);
                synchronized (logToCheck) {
                    logToCheck.addFirst(sn);
                }
                throw e;
            }
            
            LOG.info("Check log sucesss with sn=" + sn);
            qjmReader.deleteSegmentBefore(sn);
            ljmReader.deleteSegmentBefore(sn);
        }
        
        public void stop() {
            shouldRun = false;
        }
    }
    
    void printMetrics(String msg, QuorumJournalManager qjm) {
        if (!printMetrics) {
            return;
        }
        if (null == qjm) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        long[] metrics = qjm.getQjmMetricsRecords();
        for (QjmMetricsItem item: QjmMetricsItem.values()) {
            sb.append(item.getPrintName() + ": ");
            String value;
            if (item.name().endsWith("_BYTES")) {
                long size = metrics[item.offset()];
                value = Long.toString(size) + "(" + StringUtils.byteDesc(size)
                        + ")";
            } else if (item.name().endsWith("_DELAY")) {
                value = metrics[item.offset()] + "ms";
            } else {
                value = String.valueOf(metrics[item.offset()]);
            }
            sb.append(value);
            sb.append("\n");
        }
        LOG.info("[QjmMetrics]: " + msg + "\n" + sb.toString());
    }
    
    public static void main(String[] args) {
        try {
            PrintWriter out = new PrintWriter(System.out, true);
            try {
                options.parse(args);
            } catch (OptionParseException e) {
                usage(out);
                return;
            }
            logFileSize = options.getLongOpt("logSize") * 1024 * 1024;
            if (logFileSize < minLogFileSize) {
                logFileSize = 1;
            } else {
                logFileSize -= minLogFileSize;
            }
            bufSize = options.getIntOpt("buf");
            if (options.isOptSet("h")) {
                usage(out);
                return;
            }
            
            printMetrics = options.isOptSet("m");

            String[] nodes = DFSConfig.conf().getStringArray(
                    DFSConfig.DFS_QJOURNAL_JOURNAL_NODES);
            System.out.println("Start qjm test: " + Arrays.deepToString(nodes));

            // set logger
            boolean logToFile = options.isOptSet("l");
            if (logToFile) {
                File logDir = new File(DFSConfig.getLogDir(), "QjmTestTool");
                if (!logDir.exists() && !logDir.mkdirs()) {
                    reportError("Qjm can't create logDir " + logDir);
                    System.exit(1);
                }
                LogFormatter.clearLoggerHandlers("");
                LogFormatter.setRotateFileLogger(
                        "",
                        logDir.getPath(),
                        "qjm-test-tool.log",
                        DFSConfig.conf().getInt(DFSConfig.LOG_FILE_LIMIT,
                                DFSConfig.DEFAULT_LOG_FILE_LIMIT),
                        DFSConfig.conf().getInt(DFSConfig.LOG_FILE_COUNT,
                                DFSConfig.DEFAULT_LOG_FILE_COUNT),
                        DFSConfig.conf().getBoolean(DFSConfig.LOG_APPEND,
                                DFSConfig.DEFAULT_LOG_APPEND));
            }
            LogFormatter.setLogLevel(DFSConfig.getLogLevel(), Level.INFO);

            QjmTestTool qjmTestTool = new QjmTestTool();
            qjmTestTool.run();
        } catch (Throwable e) {
            reportError("QJM test exit:" + DfsUtils.getStrackTrace(e));
        }
    }

    public static void usage(PrintWriter out) {
        options.printHelpInfo(out, "QjmTestTool");
    }
}
