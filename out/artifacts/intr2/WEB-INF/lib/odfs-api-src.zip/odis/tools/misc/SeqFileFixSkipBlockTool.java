/**
 * @(#)SeqFileFixSkipBlockTool.java, 2011-11-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.tools.misc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockInfo;
import odis.dfs.common.FSException;
import odis.file.IRecordWriter;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.BadObjectException;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.toolkit.LazyWritable;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.NamedThreadFactory;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * @author guodd
 */
public class SeqFileFixSkipBlockTool implements ITool {
    private static final Logger LOG = LogFormatter.getLogger(SeqFileFixTool.class);

    private final Options options;

    public SeqFileFixSkipBlockTool() {
        options = new Options();
        options.withOption("fs", "filesystem", "hostname:port");
        options.withOption("f", "file_or_dir_to_fix",
                "The file or dir to be fixed");
        options.withOption("o", "file_or_dir_repaired",
                "Objective repaired file or dir");

        options.withSharedOption("c", "Whether to compress the repaired file");
        options.withSharedOption("r", "retry_number", "Block finding retries").hasDefault();
        options.withSharedOption(
                "h",
                "header_provider",
                "a good file with the same header as the corrupted one, useful"
                        + "when the header is missing (usually when the first block is missing)").hasDefault();
        options.withSharedOption("t", "threads_number",
                "The threads number to fix files under one dir.").hasDefault();
    }

    public static class Fixer {
        public static final long DEFAULT_SEARCH_DISTANCE = 5 * 1024 * 1024;

        private DistributedFileSystem fs;

        private Path file;

        private Path fixedFile;

        private Path headerFile;

        private boolean isIndexedFile;

        private boolean compress;

        BlockInfo[] locations;

        public Fixer(DistributedFileSystem fs, Path file, Path output,
                Path headerFile) throws IOException {
            this.fs = fs;
            this.file = file;
            this.fixedFile = output;
            this.headerFile = headerFile;
            fs.getConf().setProperty("dfs.client.max-block-acquire-failures", 4);
        }

        public void setCompress(boolean value) {
            compress = value;
        }

        public void setBlockFindingRetries(int retries) {
            fs.getConf().setProperty("dfs.client.max-block-acquire-failures",
                    retries);
        }

        private boolean skipBadBlock(SequenceFile.Reader reader, long length) {
            long pos;
            try {
                pos = reader.getPosition();
                while (pos < length) {
                    LOG.info("pos " + pos);
                    pos = getNextPos(pos);
                    LOG.info("next pos " + pos);
                    try {
                        reader.sync(pos);
                        LOG.log(Level.INFO,
                                "recovered at pos " + reader.getPos());
                        return true;
                    } catch (Throwable ex) {}
                }
                return false;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        private long getNextPos(long curr) throws IOException {
            if (locations == null)
                throw new IOException("file locatios is null");
            long start = 0;
            int currIndex = -1;
            for (int i = 0; i < locations.length; i++) {
                long end = start + locations[i].getLength();
                if (curr >= start && curr < end) {
                    currIndex = i;
                    break;
                }
                start += locations[i].getLength();
            }
            if (currIndex < 0)
                throw new IOException("can not find the current block index");
            for (int j = currIndex; j < locations.length; j++) {
                if (j > currIndex) {
                    if (locations[j].getLocations() != null
                            && locations[j].getLocations().length > 0) {
                        return start;
                    } else {
                        LOG.info("skip block " + locations[j].getBlockID());
                    }
                }
                start += locations[j].getLength();
            }
            throw new IOException("can not find next seek");
        }

        @SuppressWarnings({
            "unchecked", "rawtypes"
        })
        public void fix() throws IOException, FSException {
            if (fixedFile.equals(file)) {
                throw new IOException(
                        "source file and fixed file should not be the same");
            }
            if (fs.isDirectory(file)) {
                throw new IOException("can not fix directory");
            }

            Path dataFile = file;

            SequenceFile.Reader reader;

            locations = fs.getFileBlocksInfo(dataFile);

            if (headerFile != null) {
                reader = new SequenceFile.Reader(fs, dataFile, headerFile);
            } else {
                reader = new SequenceFile.Reader(fs, dataFile);
            }
            long length = fs.getLength(dataFile);

            IRecordWriter<IWritable, IWritable> writer;
            if (isIndexedFile) {
                writer = (IRecordWriter) new IndexedFile.Writer(fs, fixedFile,
                        reader.getKeyClass(), reader.getValueClass());
            } else if (compress) {
                writer = (IRecordWriter) new SequenceFile.CompressedWriter(fs,
                        fixedFile, reader.getKeyClass(), reader.getValueClass());
            } else {
                writer = (IRecordWriter) new SequenceFile.Writer(fs, fixedFile,
                        reader.getKeyClass(), reader.getValueClass());
            }

            try {
                IWritable key = ClassUtils.newInstance(reader.getKeyClass());
                IWritable value = ClassUtils.newInstance(reader.getValueClass());

                while (true) {
                    try {
                        if (!reader.next(key, value))
                            break;
                        try {
                            if (value instanceof LazyWritable) {
                                // make sure the compressed data is ok
                                ((LazyWritable) value).decode();
                            }
                        } catch (Exception e) {
                            throw new BadObjectException(
                                    "decode object failed", e);
                        }

                        writer.write(key, value);
                    } catch (Throwable e) {
                        LOG.log(Level.WARNING,
                                "read failed at pos " + reader.getPosition()
                                        + ", try to recover.", e);
                        if (!skipBadBlock(reader, length)) {
                            break;
                        }
                    }
                }
                reader.close();
            } finally {
                writer.close();
            }
        }

    }

    public void usage(PrintWriter out) {
        options.printHelpInfo(System.out, "seqblockfix");
    }

    public boolean exec(String[] args) throws IOException, InterruptedException {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e1) {
            usage(out);
            return false;
        }

        String fsName = options.getStringOpt("fs");
        String filename = options.getStringOpt("f");
        String fixedName = options.getStringOpt("o");

        if (fsName == null || filename == null || fixedName == null) {
            usage(out);
            return false;
        }

        DistributedFileSystem fs = (DistributedFileSystem) FileSystem.getNamed(fsName);
        Path brokenFile = new Path(filename);
        Path fixedFile = new Path(fixedName);
        if (fs.exists(fixedFile)) {
            throw new IOException("Fixed file " + fixedName + "already exists.");
        }
        if (fs.isFile(brokenFile)) {
            return fixOneFile(fs, brokenFile, fixedFile, out);
        } else if (fs.isDirectory(brokenFile)) {
            return fixFilesInDir(fs, brokenFile, fixedFile, out);
        }

        out.println("error: broken file " + filename + " must be file or dir.");
        return false;
    }

    private boolean fixOneFile(DistributedFileSystem fs, Path brokenFile,
            Path fixedFile, PrintWriter out) {
        String headerFileName = options.getStringOpt("h");
        Fixer fixer;
        try {
            fixer = new Fixer(fs, brokenFile, fixedFile,
                    headerFileName != null ? new Path(headerFileName) : null);
        } catch (IOException e) {
            e.printStackTrace(out);
            return false;
        }

        boolean needCompress = options.isOptSet("c");
        fixer.setCompress(needCompress);

        if (options.isOptSet("r")) {
            int retries = options.getIntOpt("r", -1);
            if (retries < 1) {
                out.println("error: retries should be smaller than 1");
                return false;
            }
            fixer.setBlockFindingRetries(retries);
        }

        out.println(new Date() + " Start to fix file " + brokenFile.getName()
                + " ...");
        try {
            fixer.fix();
        } catch (Exception e) {
            out.println(new Date() + " Failed to fix.");
            e.printStackTrace(out);
            return false;
        }
        return true;
    }

    private boolean fixFilesInDir(final DistributedFileSystem fs,
            Path brokenDir, Path fixedDir, final PrintWriter out)
            throws IOException, InterruptedException {
        out.println(new Date() + " Start to fix dir "
                + brokenDir.getAbsolutePath() + " ...");

        int threadNum = 10;
        if (options.isOptSet("t")) {
            threadNum = options.getIntOpt("t");
            if (threadNum <= 0) {
                throw new IllegalArgumentException("Thread number can't be "
                        + threadNum);
            }
        }

        // make the dir for fixed files.
        fs.mkdirs(fixedDir);

        ThreadPoolExecutor executor = new ThreadPoolExecutor(threadNum,
                threadNum, 60, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(), new NamedThreadFactory(
                        "seqfix-thread", true));
        List<Future<?>> futureList = new ArrayList<Future<?>>();
        FileInfo[] subFiles = fs.listFiles(brokenDir);
        for (FileInfo fileInfo: subFiles) {
            // make sure it's a file.
            if (fileInfo.isDir() || fileInfo.isSLink()) {
                continue;
            }
            String name = fileInfo.getPath().getName();
            final Path brokenFile = new Path(brokenDir, name);
            final Path fixedFile = new Path(fixedDir, name);

            // if the file system is DFS, check the file blocks.
            boolean isBroken = false;
            BlockInfo[] blocks = fs.getFileBlocksInfo(brokenFile);
            for (BlockInfo block: blocks) {
                if (block.getLocations().length == 0) {
                    isBroken = true;
                    break;
                }
            }
            if (!isBroken) {
                fs.link(brokenFile, fixedFile);
                continue;
            }

            // fix it with a new thread.
            Future<?> future = executor.submit(new Runnable() {
                @Override
                public void run() {
                    fixOneFile(fs, brokenFile, fixedFile, out);
                }
            });
            futureList.add(future);
        }

        // wait until all the future are done.
        for (Future<?> future: futureList) {
            while (!future.isDone()) {
                Thread.sleep(10000);
            }
        }
        out.println(new Date() + " Fixed dir " + brokenDir.getAbsolutePath()
                + ".");
        return true;
    }

    public String comment() {
        return "Fix sequence file at the time of ODFS block lost";
    }

    /**
     * Sends a notification mail to developers about the seqfix invocation
     * 
     * @param files
     *            files fixed
     * @return
     */
    /*
    protected static void sendNotification(String fs, String tool,
            List<String> files) {
        try {
            Emailer emailer = new Emailer();
            String userName = System.getProperty("user.name");
            StringBuilder content = new StringBuilder();
            content.append("User: " + userName + "<br>");
            content.append("Time: " + new Date() + "<br>");
            content.append("FS: " + fs + "<br>");
            content.append("Tool: " + tool + "<br>");
            content.append("Fixed files:<br>");
            for (String file: files) {
                content.append(file + "<br>");
            }
            emailer.sendEmail("postmaster@rd.netease.com",
                    "infra@rd.netease.com", "[SEQ-FIX]" + tool + " used on "
                            + fs, content.toString(), null);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Failed to send email notification", e);
        }
    }
    */

}
