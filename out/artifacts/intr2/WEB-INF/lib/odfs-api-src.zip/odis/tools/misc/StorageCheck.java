package odis.tools.misc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.logging.Logger;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSFileStatus;
import odis.io.FileSystem;
import odis.io.Path;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.text.util.StringUtils;

public class StorageCheck implements ITool {
    private static final Logger LOG = LogFormatter.getLogger(StorageCheck.class);

    private final Options options;

    private DFSClient client;

    private Path[] path;

    HashMap<Path, HashMap<Long, HashSet<String>>> pathMap = new HashMap<Path, HashMap<Long, HashSet<String>>>();

    HashMap<Long, HashSet<String>> globalLinkSet = new HashMap<Long, HashSet<String>>();

    public StorageCheck() {
        options = new Options();
        options.withOption("fs", "filesystem", "zkPath@zkAddr").hasDefault();
        options.addParam("path_to_check").etcParam().setMinimalParamCount(1);
    }

    public void find() throws Exception {
        for (Path p: path) {
            DFSFileStatus status = client.getFileStatus(p.getPath());
            if (status != null && status.isDir()) {
                LOG.info("Checking path " + p);
                HashMap<Long, HashSet<String>> selfLinkSet = new HashMap<Long, HashSet<String>>();
                pathMap.put(p, selfLinkSet);
                DFSFileStatus[] subFiles = client.listFiles(p.getPath());
                for (DFSFileStatus subFile: subFiles) {
                    findLink(subFile, selfLinkSet);
                }
                LOG.info("Check finished.");
            } else {
                LOG.warning("Path " + p
                        + " is not a directory or does not exist.");
            }
        }
        print();
    }

    public void findLink(DFSFileStatus path,
            HashMap<Long, HashSet<String>> selfLinkSet) throws Exception {
        if (!path.isDir() || isSingleUnit(path)) {
            Long unitId = unitId(path);
            if (unitId != null) {
                HashSet<String> set = globalLinkSet.get(unitId);
                if (set == null) {
                    set = new HashSet<String>();
                    globalLinkSet.put(unitId, set);
                }
                set.add(path.getPath());
                set = selfLinkSet.get(unitId);
                if (set == null) {
                    set = new HashSet<String>();
                    selfLinkSet.put(unitId, set);
                }
                set.add(path.getPath());
            }
        } else {
            DFSFileStatus[] files = client.listFiles(path.getPath());
            for (DFSFileStatus file: files) {
                findLink(file, selfLinkSet);
            }
        }
    }

    public boolean isSingleUnit(DFSFileStatus file) throws Exception {
        DFSFileStatus[] subFiles = client.listFiles(file.getPath());
        if (subFiles.length > 0) {
            if (subFiles[0].getName().startsWith("part-")) {
                return true;
                // } else if (file.getPath().matches(pattern1)) {
                // return true;
            }
        }
        return false;
    }

    public Long unitId(DFSFileStatus file) throws Exception {
        if (file.isDir()) {
            DFSFileStatus[] files = client.listFiles(file.getPath());
            if (files.length > 0) {
                return unitId(files[0]);
            } else {
                return null;
            }
        } else {
            BlockSizeLocationWithDataPath[] blocks = client.getFileBlockLocations(file.getPath());
            if (blocks.length > 0) {
                return blocks[0].getBlock();
            } else {
                return null;
            }
        }
    }

    public void print() throws IOException {
        for (Long id: globalLinkSet.keySet()) {
            if (globalLinkSet.get(id).size() > 1) {
                System.out.print("Found link: ");
                for (String path: globalLinkSet.get(id)) {
                    System.out.print(path + ",");
                }
                System.out.println();
            }
        }
        for (Path p: path) {
            System.out.println("======================== " + p.getPath()
                    + "=======================");
            long[] sizes = calLinkSetSize(p);
            DFSFileStatus status = client.getFileStatus(p.getPath());
            long totalSize = status == null ? 0 : status.getContentsLength();
            System.out.println("Du size: " + StringUtils.byteDesc(totalSize));
            System.out.println("Size with out link: "
                    + StringUtils.byteDesc(totalSize - sizes[0]));
            System.out.println("Self link only size: "
                    + StringUtils.byteDesc(sizes[1]));
            System.out.println("Global link size: "
                    + StringUtils.byteDesc(sizes[2]));
            System.out.println("Summary: "
                    + StringUtils.byteDesc(totalSize - sizes[0] + sizes[1])
                    + " + " + StringUtils.byteDesc(sizes[2]) + "(globalLink)");
        }
        System.out.println("==================================================");
    }

    private long[] calLinkSetSize(Path p) throws IOException {
        long linkVirtSize = 0;
        long selfLinkOnlySize = 0;
        long globalLinkSize = 0;
        HashMap<Long, HashSet<String>> selfLinkSet = pathMap.get(p);
        for (Map.Entry<Long, HashSet<String>> entry: selfLinkSet.entrySet()) {
            Long unitId = entry.getKey();
            if (globalLinkSet.get(unitId).size() - entry.getValue().size() > 0) {
                DFSFileStatus status = client.getFileStatus(entry.getValue().iterator().next());
                long size = status == null ? 0 : status.getContentsLength();
                globalLinkSize += size;
                linkVirtSize += size * entry.getValue().size();
            } else if (entry.getValue().size() > 1) {
                DFSFileStatus status = client.getFileStatus(entry.getValue().iterator().next());
                long size = status == null ? 0 : status.getContentsLength();
                selfLinkOnlySize += size;
                linkVirtSize += size * entry.getValue().size();
            }
        }
        return new long[] {
            linkVirtSize, selfLinkOnlySize, globalLinkSize
        };
    }

    public boolean exec(String[] args) throws Exception {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            usage(out);
            return false;
        }
        String fsName = options.getStringOpt("fs");
        DistributedFileSystem fs = (DistributedFileSystem) (fsName == null ? FileSystem.get()
                : FileSystem.getNamed(fsName));

        this.client = fs.getDFSClient();
        this.path = new Path[options.getRemains().length];
        for (int i = 0; i < options.getRemains().length; i++) {
            this.path[i] = new Path(options.getRemains()[i]);
        }
        this.find();
        return true;
    }

    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "storagecheck");
    }

    public String comment() {
        return "Check paths on odfs to see actual size of them.";
    }
}
