package odis.tools;

import java.io.PrintWriter;

import toolbox.misc.cli.ITool;

/**
 * The abstract local tool class.
 * 
 * @author david
 */
public abstract class AbstractLocalTool implements ITool {

    protected LocalToolContext context;

    protected PrintWriter out;

    /**
     * Sets the environment.
     * 
     * @param context
     *            the tool's context
     * @param out
     *            a PrintWriter instance.
     * @return true if success, false otherwise.
     */
    public boolean setEnv(LocalToolContext context, PrintWriter out) {
        this.context = context;
        this.out = out;
        return true;
    }

}
