package odis.tools;

import java.io.IOException;

import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;

/**
 * Some utility methods for IFileSystem related operations.
 * 
 * @author david
 */
public class FsUtils {
    /**
     * Locks the folder and link it.
     * <p>
     * Read IFileSystem.link for more comments.
     * </p>
     * <strong>NOTE</strong>: locking before linking is essential since
     * otherwise an empty folder could be linked.
     * 
     * @param src
     *            the source path
     * @param dst
     *            the destination to be linked to
     * @return true if success, false otherwise
     * @throws IOException
     *             if an I/O exceptio occurs
     */
    public static boolean lockLink(IFileSystem fs, Path src, Path dst)
            throws IOException {
        fs.getLock(src, FileSystem.SHARED_LOCK);
        try {
            return fs.link(src, dst);
        } finally {
            fs.releaseLock(src);
        }
    }

    /**
     * Replaces the target folder with new content safely. Safe here means
     * unless the replacement was successfully performed, neither old nor new
     * data will be removed.
     * <p>
     * The algorithm goes in this way:<br>
     * <code>
     *   1) remove <newPath>.replaced_old if any
     *   2) rename <target> to <newPath>.replaced_old
     *   3) rename <newPath> to <target>
     *   4) remove <newPath>.replaced_old
     * </code>
     * </p>
     * NOTE: add an EXCLUSIVE_LOCK on target before calling this method
     * 
     * @param fs
     *            the file-system instance
     * @param target
     *            the target folder to be replaced to.
     * @param newPath
     *            the folder containing new data.
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void replace(IFileSystem fs, Path target, Path newPath)
            throws IOException {
        replace(fs, target, newPath, new Path(newPath.getPath()
                + ".replaced_old"), false);
    }

    /**
     * Replaces the target folder with new content safely. Safe here means
     * unless the replacement was successfully performed, neither old nor new
     * data will be removed.
     * <p>
     * The algorithm goes in this way:<br>
     * <code>
     *   1) remove <tmpPath> if any
     *   2) rename <target> to <tmpPath>
     *   3) rename <newPath> to <target>
     *   4) remove <tmpPath>
     * </code>
     * </p>
     * <p>
     * Replace the contents of path with newFile in an atomic action. The action
     * is taken in the following order: 1) delete newfile.replaced_old 2) ren
     * path newfile.replaced_old 3) ren newfile path 4) delete
     * newfile.replaced_old
     * </p>
     * <strong>NOTE</strong>: add an EXCLUSIVE_LOCK on target before calling
     * this method
     * 
     * @param fs
     *            the file-system instance
     * @param target
     *            the target folder to be replaced to.
     * @param newPath
     *            the folder containing new data.
     * @param tmpPath
     *            the temporary path name. The file with this path will be
     *            removed.
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void replace(IFileSystem fs, Path target, Path newPath,
            Path tmpPath, boolean keepTmp) throws IOException {
        if (!fs.exists(newPath))
            throw new IOException("cannot find new file " + newPath);

        if (fs.exists(tmpPath) && !fs.delete(tmpPath))
            throw new IOException("cannot remove tmp file " + tmpPath
                    + " during replace");

        // create the parent directory for target
        if (target.getParentFile() != null
                && !fs.exists(target.getParentFile())) {
            fs.mkdirs(target.getParentFile());
        }

        boolean restore = fs.exists(target);

        if (fs.exists(target) && !fs.rename(target, tmpPath))
            throw new IOException("cannot rename old file " + target
                    + " to tmp file " + tmpPath);

        if (!fs.rename(newPath, target))
            if (restore) {
                System.err.println("Cannot rename new file " + newPath
                        + " to file " + target
                        + ", restoring the old one from " + tmpPath);
                if (!fs.rename(tmpPath, target))
                    throw new IOException("Cannot restore " + target + " from "
                            + tmpPath);
            } else
                throw new IOException("Cannot rename new file " + newPath
                        + " to file " + target);

        if (!keepTmp)
            if (fs.exists(tmpPath) && !fs.delete(tmpPath))
                throw new IOException("cannot clean tmp file after replace "
                        + "finished");
    }
}
