package odis.tools;

import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.IFileSystem;
import odis.io.Path;
import toolbox.misc.LogFormatter;

/**
 * Container to manage the files to be deleted when system quits.
 * 
 * @author river
 */
public class ToDelete {
    private static final Logger LOG = LogFormatter.getLogger(ToDelete.class);

    private static class Entry {
        private IFileSystem fs;

        private Path path;

        public Entry(IFileSystem fs, Path path) {
            this.fs = fs;
            this.path = path;
        }
    }

    static {
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            public void run() {
                ToDelete.deleteAll();
            }
        }, "ToDeleteThread"));
    }

    private static List<Entry> entries = new LinkedList<Entry>();

    /**
     * Register one file to be deleted later(automatically deleted on jvm
     * shutdown or manually later sometime).
     * 
     * @param fs
     *            Filesystem
     * @param path
     *            Path to be deleted
     */
    public synchronized static void toDelete(IFileSystem fs, Path path) {
        entries.add(new Entry(fs, path));
    }

    /**
     * Register one file to be deleted later.
     * 
     * @deprecated Use {@link #toDelete(IFileSystem, Path)} instead.
     * @param fs
     * @param file
     */
    public synchronized static void toDelete(IFileSystem fs, File file) {
        entries.add(new Entry(fs, new Path(file)));
    }

    /**
     * Delete all the files registered manually.
     */
    public synchronized static void deleteAll() {
        for (Entry entry: entries) {
            try {
                if (entry.fs.exists(entry.path)) {
                    entry.fs.delete(entry.path);
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "cannot remove file " + entry.fs + "://"
                        + entry.path, e);
            }
        }
        entries.clear();
    }

    /**
     * Delete the specified file and remove it from to_delete_queue.
     * 
     * @param fs
     * @param file
     */
    public synchronized static void delete(IFileSystem fs, Path file) {
        for (Iterator<Entry> it = entries.iterator(); it.hasNext();) {
            Entry entry = it.next();
            if (entry.fs == fs && entry.path.equals(file)) {
                try {
                    if (entry.fs.exists(entry.path)) {
                        entry.fs.delete(entry.path);
                    }
                } catch (Throwable e) {
                    LOG.log(Level.WARNING, "cannot remove file " + entry.fs
                            + "://" + entry.path, e);
                }
                it.remove();
                break;
            }
        }
    }

    /**
     * Delete the specified file and remove it from to_delete_queue.
     * 
     * @deprecated Use {@link #delete(IFileSystem, Path)} instead.
     * @param fs
     * @param file
     */
    public synchronized static void delete(IFileSystem fs, File file) {
        delete(fs, new Path(file));
    }

}
