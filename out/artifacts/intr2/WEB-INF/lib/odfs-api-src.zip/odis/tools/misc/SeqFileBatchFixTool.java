/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package odis.tools.misc;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockInfo;
import odis.dfs.common.DFSClientConfig;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import odis.tools.misc.SeqFileFixTool.Fixer;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * @author zhangkun
 */
public class SeqFileBatchFixTool implements ITool {
    private static final Logger LOG = LogFormatter.getLogger(SeqFileBatchFixTool.class);

    private final Options options;

    private DistributedFileSystem fs;

    public SeqFileBatchFixTool() {
        options = new Options();
        options.withOption("fs", "filesystem", "zkPath@zkAddr");
        options.withOption("l", "file_list",
                "A local file listing the files to be fixed");

        options.withSharedOption("s", "Whether to sync always");
        options.withSharedOption("f",
                "always redo fixing even if it seems to have been fixed");
        options.withSharedOption("c", "Whether to compress the repaired file");
        options.withSharedOption("d", "search_distance",
                "Search distance in Mb").hasDefault();
        options.withSharedOption("r", "retry_number", "Block finding retries").hasDefault();
        options.withSharedOption(
                "h",
                "header_provider",
                "a good file with the same header as the corrupted one, useful"
                        + "when the header is missing (usually when the first block is missing)").hasDefault();
    }

    public boolean exec(String[] args) throws Exception {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e1) {
            usage(out);
            return false;
        }

        String listFileName = options.getStringOpt("l");
        String fsName = options.getStringOpt("fs");

        String headerFileName = options.getStringOpt("h");
        boolean syncAlways = options.isOptSet("s");
        boolean redo = options.isOptSet("f");
        boolean needCompress = options.isOptSet("c");
        long searchDistance;
        if (options.isOptSet("d")) {
            searchDistance = options.getLongOpt("d", -1);
            if (searchDistance < 1) {
                out.println("error : search distance should not be smaller than 1M");
                return false;
            }
            searchDistance = searchDistance * 1024 * 1024;
        } else {
            searchDistance = Fixer.DEFAULT_SEARCH_DISTANCE;
        }
        int retries;
        if (options.isOptSet("r")) {
            retries = options.getIntOpt("r", -1);
            if (retries < 1) {
                out.println("error: retries should be smaller than 1");
                return false;
            }
        } else {
            retries = DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME_DEFAULT_VALUE;
        }

        fs = (DistributedFileSystem) FileSystem.getNamed(fsName);
        BufferedReader listReader = null;
        try {
            listReader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(listFileName)));
            List<String> files = new ArrayList<String>();
            for (String fileName; (fileName = listReader.readLine()) != null;) {
                if (fileName.trim().length() == 0) {
                    continue;
                }
                Path file = new Path(fileName);
                files.add(file.toString());
                LOG.info("Fixing " + file);
                Path backupFile = new Path(file + ".seqfixbackup");
                if (fs.exists(backupFile)) {
                    LOG.info("Backup file " + backupFile + " exists");
                    if (fs.exists(file)) {
                        if (redo) {
                            LOG.info(file
                                    + " exists, seems it has been fixed, refixing it");
                            fs.delete(file);
                        } else {
                            LOG.info(file
                                    + " exists, seems it has been fixed, skipping it");
                            continue;
                        }
                    }
                } else {
                    if (fs.exists(file)) {
                        LOG.info("Backup " + file + " to " + backupFile);
                        fs.rename(file, backupFile);
                    }
                }
                Path headerFile = (headerFileName != null ? new Path(
                        headerFileName) : null);
                if (!firstBlockGood(backupFile) && headerFile == null) {
                    if (file.getName().startsWith("part-")) {
                        Path parentDir = new Path(file.getParent());
                        FileInfo[] otherFiles = fs.listFiles(parentDir);
                        for (FileInfo otherFile: otherFiles) {
                            Path otherFilePath = otherFile.getPath();
                            if (otherFilePath.getName().startsWith("part-")
                                    && firstBlockGood(otherFilePath)) {
                                headerFile = otherFilePath;
                                break;
                            }
                        }
                        if (headerFile != null) {
                            LOG.info(file + "'s first block is missing, using "
                                    + headerFile + "'s header");
                        }
                    }
                }
                try {
                    Fixer fixer = new Fixer(fs, backupFile, file, headerFile);
                    fixer.setSyncAlways(syncAlways);
                    fixer.setCompress(needCompress);
                    fixer.setSearchDistance(searchDistance);
                    fixer.setBlockFindingRetries(retries);
                    fixer.fix();
                    LOG.log(Level.INFO, "Fixed " + file);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Failed to fix " + file, e);
                }
            }
        } finally {
            ReadWriteUtils.safeClose(listReader);
        }
        return true;

    }

    private boolean firstBlockGood(Path path) throws Exception {
        BlockInfo[] blocks = fs.getFileBlocksInfo(path);
        return blocks != null && blocks.length > 0
                && blocks[0].getLocations().length > 0;
    }

    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "seqbatchfix");
    }

    public String comment() {
        return "Fix many sequence files at a time";
    }
}
