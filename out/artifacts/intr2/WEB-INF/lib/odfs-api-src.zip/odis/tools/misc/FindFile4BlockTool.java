/**
 * @(#)FindFile4BlockTool.java, 2012-11-2. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.tools.misc;

import java.io.IOException;
import java.io.PrintWriter;

import odis.dfs.common.BlockInfo;
import odis.io.FileSystem;
import odis.io.Path;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Iterate recursively under the given dir to find the owner file of the given
 * block.
 * 
 * @author zhangduo
 */
public class FindFile4BlockTool implements ITool {
    private final Options options;

    public FindFile4BlockTool() {
        options = new Options();
        options.withOption("fs", "filesystem", "zkPath@zkAddr");
        options.withOption("dir", "directory", "the directory to be scanned");
        options.withOption("blk", "block", "the block to find");
    }

    @Override
    public String comment() {
        return "find file of the given block";
    }

    private boolean find(FileSystem fs, Path path, long block)
            throws IOException {
        if (fs.isFile(path)) {
            BlockInfo[] binfos = fs.getFileBlocksInfo(path);
            if (binfos != null) {
                for (BlockInfo binfo: binfos) {
                    if (binfo.getBlockID() == block) {
                        System.out.println(path.getAbsolutePath()
                                + " contains " + binfo);
                        return true;
                    }
                }
            }
            return false;
        }
        Path[] sub = fs.listPaths(path);
        if (sub != null) {
            for (Path p: sub) {
                if (find(fs, p, block)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean exec(String[] args) throws Exception {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            usage(out);
            return false;
        }

        String fsName = options.getStringOpt("fs");
        String dirName = options.getStringOpt("dir");
        long block = options.getLongOpt("blk");

        find(FileSystem.getNamed(fsName), new Path(dirName), block);
        return true;
    }

    @Override
    public void usage(PrintWriter out) {
        options.printHelpInfo(out, "findfile4blk");
    }

}
