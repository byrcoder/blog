package odis.tools.misc;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockInfo;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.FSException;
import odis.file.IRecordWriter;
import odis.file.IndexedFile;
import odis.file.SequenceFile;
import odis.io.BadObjectException;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.toolkit.LazyWritable;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.NamedThreadFactory;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 * Fix the sequence file when block lost.
 * 
 * @author river
 */
public class SeqFileFixTool implements ITool {
    private static final Logger LOG = LogFormatter.getLogger(SeqFileFixTool.class);

    private final Options options;

    public SeqFileFixTool() {
        options = new Options();
        options.withOption("fs", "filesystem", "hostname:port");
        options.withOption("f", "file_or_dir_to_fix",
                "The file or dir to be fixed");
        options.withOption("o", "file_or_dir_repaired",
                "Objective repaired file or dir");

        options.withSharedOption("s", "Whether to sync always");
        options.withSharedOption("c", "Whether to compress the repaired file");
        options.withSharedOption("d", "search_distance",
                "Search distance in Mb").hasDefault();
        options.withSharedOption("r", "retry_number", "Block finding retries").hasDefault();
        options.withSharedOption("k", "p1;p2;p3...",
                "The positions to skip, seperated with semicolons").hasDefault();
        options.withSharedOption(
                "h",
                "header_provider",
                "a good file with the same header as the corrupted one, useful"
                        + "when the header is missing (usually when the first block is missing)").hasDefault();
        options.withSharedOption("t", "threads_number",
                "The threads number to fix files under one dir.").hasDefault();
    }

    public static class Fixer {
        public static final long DEFAULT_SEARCH_DISTANCE = 5 * 1024 * 1024;

        private IFileSystem fs;

        private Path file;

        private Path fixedFile;

        private Path headerFile;

        private boolean isIndexedFile;

        private boolean syncAlways;

        private boolean compress;

        private long searchDistance = DEFAULT_SEARCH_DISTANCE;

        private Set<Long> skips;

        public Fixer(IFileSystem fs, Path file, Path output, Path headerFile) {
            this.fs = fs;
            this.file = file;
            this.fixedFile = output;
            this.headerFile = headerFile;
            if (fs instanceof DistributedFileSystem) {
                ((DistributedFileSystem) fs).getConf().setProperty(
                        DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME, 4);
            }
            syncAlways = false;
        }

        @Deprecated
        public Fixer(FileSystem fs, File file, File output) {
            this(fs, new Path(file), new Path(output), null);
        }

        public void setSyncAlways(boolean value) {
            syncAlways = value;
        }

        public void setCompress(boolean value) {
            compress = value;
        }

        public void setSearchDistance(long value) {
            this.searchDistance = value;
        }

        public void setBlockFindingRetries(int retries) {
            if (fs instanceof DistributedFileSystem) {
                ((DistributedFileSystem) fs).getConf().setProperty(
                        DFSClientConfig.OPEN_DATANODE_MAX_RETRY_TIME, 4);
            }
        }

        public void setSkipPositions(long[] skips) {
            this.skips = new HashSet<Long>();
            for (long s: skips) {
                this.skips.add(s);
            }
        }

        private boolean skipBadBlock(SequenceFile.Reader reader, long fromPos,
                long length) {
            long pos = fromPos;
            if (pos >= length) {
                return false;
            }

            while (pos < length) {
                try {
                    reader.sync(pos);
                    return true;
                } catch (Throwable ex) {}
                pos += searchDistance;
            }
            return false;
        }

        public void fix() throws IOException {
            if (fixedFile.equals(file)) {
                throw new IOException(
                        "source file and fixed file should not be the same");
            }
            isIndexedFile = fs.isDirectory(file);
            if (isIndexedFile)
                LOG.info("source file is indexed file");
            Path dataFile = isIndexedFile ? file.cat("data") : file;

            SequenceFile.Reader reader;
            if (headerFile != null) {
                reader = new SequenceFile.Reader(fs, dataFile, headerFile);
            } else {
                reader = new SequenceFile.Reader(fs, dataFile);
            }
            long length = fs.getLength(dataFile);
            IRecordWriter<Object, Object> writer;
            if (isIndexedFile) {
                writer = new IndexedFile.Writer(fs, fixedFile,
                        reader.getKeyClass(), reader.getValueClass());
            } else if (compress) {
                writer = new SequenceFile.CompressedWriter(fs, fixedFile,
                        reader.getKeyClass(), reader.getValueClass());
            } else {
                writer = new SequenceFile.Writer(fs, fixedFile,
                        reader.getKeyClass(), reader.getValueClass());
            }

            try {
                IWritable key = ClassUtils.newInstance(reader.getKeyClass());
                IWritable value = ClassUtils.newInstance(reader.getValueClass());

                double lastPercent = -1;

                while (true) {
                    long lastPos = reader.getPos();

                    if (skips != null && skips.contains(lastPos)) {
                        if (!skipBadBlock(reader, lastPos + 1, length)) {
                            break;
                        } else {
                            continue;
                        }
                    }
                    if (length > 0) {
                        double percent = (double) lastPos / length * 100;
                        if (percent > lastPercent) {
                            lastPercent = percent;
                        }
                    }

                    try {
                        if (!reader.next(key, value))
                            break;
                        try {
                            if (value instanceof LazyWritable) {
                                // make sure the compressed data is ok
                                ((LazyWritable) value).decode();
                            }
                        } catch (Exception e) {
                            throw new BadObjectException(
                                    "decode object failed", e);
                        }

                        writer.write(key, value);
                    } catch (BadObjectException e) {
                        if (reader.getPos() > lastPos && !syncAlways) {
                            reader.sync(reader.getPos());
                            continue;
                        } else {
                            if (!skipBadBlock(reader, lastPos, length)) {
                                break;
                            }
                        }
                    } catch (Throwable e) {
                        if (reader.getPos() > lastPos) {
                            try {
                                reader.sync(reader.getPos());
                            } catch (Throwable ex) {
                                if (!skipBadBlock(reader, lastPos, length)) {
                                    break;
                                }
                            }
                        } else {
                            if (!skipBadBlock(reader, lastPos, length)) {
                                break;
                            }
                        }
                    }
                }
                reader.close();
            } finally {
                writer.close();
            }
        }

    }

    public void usage(PrintWriter out) {
        options.printHelpInfo(System.out, "seqfix");
    }

    public boolean exec(String[] args) throws IOException, InterruptedException {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e1) {
            usage(out);
            return false;
        }

        String fsName = options.getStringOpt("fs");
        String filename = options.getStringOpt("f");
        String fixedName = options.getStringOpt("o");

        if (fsName == null || filename == null || fixedName == null) {
            usage(out);
            return false;
        }

        FileSystem fs = FileSystem.getNamed(fsName);
        Path brokenFile = new Path(filename);
        Path fixedFile = new Path(fixedName);
        if (fs.exists(fixedFile)) {
            throw new IOException("Fixed file " + fixedName + "already exists.");
        }
        if (fs.isFile(brokenFile)) {
            return fixOneFile(fs, brokenFile, fixedFile, out);
        } else if (fs.isDirectory(brokenFile)) {
            return fixFilesInDir(fs, brokenFile, fixedFile, out);
        }

        out.println("error: broken file " + filename + " must be file or dir.");
        return false;
    }

    private boolean fixOneFile(FileSystem fs, Path brokenFile, Path fixedFile,
            PrintWriter out) {
        String headerFileName = options.getStringOpt("h");
        Fixer fixer = new Fixer(fs, brokenFile, fixedFile,
                headerFileName != null ? new Path(headerFileName) : null);

        boolean syncAlways = options.isOptSet("s");
        boolean needCompress = options.isOptSet("c");
        fixer.setSyncAlways(syncAlways);
        fixer.setCompress(needCompress);

        if (options.isOptSet("d")) {
            long searchDistance = options.getLongOpt("d", -1);
            if (searchDistance < 1) {
                out.println("error : search distance should not be smaller than 1M");
                return false;
            }
            fixer.setSearchDistance(searchDistance * 1024 * 1024);
        }

        if (options.isOptSet("r")) {
            int retries = options.getIntOpt("r", -1);
            if (retries < 1) {
                out.println("error: retries should be smaller than 1");
                return false;
            }
            fixer.setBlockFindingRetries(retries);
        }

        if (options.isOptSet("k")) {
            String[] positions = options.getStringOpt("k").split(";");
            long[] skips = new long[positions.length];
            for (int i = positions.length - 1; i >= 0; i--) {
                skips[i] = Long.parseLong(positions[i]);
            }
            fixer.setSkipPositions(skips);
        }

        out.println(new Date() + " Start to fix file " + brokenFile.getName()
                + " ...");
        try {
            fixer.fix();
        } catch (IOException e) {
            out.println(new Date() + " Failed to fix.");
            e.printStackTrace(out);
            return false;
        }
        out.println(new Date() + " Fixed file " + brokenFile.getName() + ".");
        return true;
    }

    private boolean fixFilesInDir(final FileSystem fs, Path brokenDir,
            Path fixedDir, final PrintWriter out) throws IOException,
            InterruptedException, FSException {
        out.println(new Date() + " Start to fix dir "
                + brokenDir.getAbsolutePath() + " ...");

        int threadNum = 10;
        if (options.isOptSet("t")) {
            threadNum = options.getIntOpt("t");
            if (threadNum <= 0) {
                throw new IllegalArgumentException("Thread number can't be "
                        + threadNum);
            }
        }

        // make the dir for fixed files.
        fs.mkdirs(fixedDir);

        ThreadPoolExecutor executor = new ThreadPoolExecutor(threadNum,
                threadNum, 60, TimeUnit.SECONDS,
                new SynchronousQueue<Runnable>(), new NamedThreadFactory(
                        "seqfix-thread", true));
        List<Future<?>> futureList = new ArrayList<Future<?>>();
        FileInfo[] subFiles = fs.listFiles(brokenDir);
        for (FileInfo fileInfo: subFiles) {
            // make sure it's a file.
            if (fileInfo.isDir() || fileInfo.isSLink()) {
                continue;
            }
            String name = fileInfo.getPath().getName();
            final Path brokenFile = new Path(brokenDir, name);
            final Path fixedFile = new Path(fixedDir, name);

            // if the file system is DFS, check the file blocks.
            boolean isBroken = false;
            if (fs instanceof DistributedFileSystem) {
                BlockInfo[] blocks = fs.getFileBlocksInfo(brokenFile);
                for (BlockInfo block: blocks) {
                    if (block.getLocations().length == 0) {
                        isBroken = true;
                        break;
                    }
                }
            }
            if (!isBroken) {
                fs.link(brokenFile, fixedFile);
                continue;
            }

            // fix it with a new thread.
            Future<?> future = executor.submit(new Runnable() {
                @Override
                public void run() {
                    fixOneFile(fs, brokenFile, fixedFile, out);
                }
            });
            futureList.add(future);
        }

        // wait until all the future are done.
        for (Future<?> future: futureList) {
            while (!future.isDone()) {
                Thread.sleep(10000);
            }
        }
        out.println(new Date() + " Fixed dir " + brokenDir.getAbsolutePath()
                + ".");
        return true;
    }

    public String comment() {
        return "Fix sequence file when it is broken(data error, block lost, etc.)";
    }

    /**
     * Sends a notification mail to developers about the seqfix invocation
     * 
     * @param files
     *            files fixed
     * @return
     */
    /*
    protected static void sendNotification(String fs, String tool,
            List<String> files) {
        try {
            Emailer emailer = new Emailer();
            String userName = System.getProperty("user.name");
            StringBuilder content = new StringBuilder();
            content.append("User: " + userName + "<br>");
            content.append("Time: " + new Date() + "<br>");
            content.append("FS: " + fs + "<br>");
            content.append("Tool: " + tool + "<br>");
            content.append("Fixed files:<br>");
            for (String file: files) {
                content.append(file + "<br>");
            }
            emailer.sendEmail("postmaster@rd.netease.com",
                    "infra@rd.netease.com", "[SEQ-FIX]" + tool + " used on "
                            + fs, content.toString(), null);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Failed to send email notification", e);
        }
    }
    */
}
