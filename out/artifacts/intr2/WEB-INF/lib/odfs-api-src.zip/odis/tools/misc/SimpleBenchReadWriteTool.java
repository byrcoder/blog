/**
 * @(#)SimpleBenchReadWriteTool.java, 2013-2-25. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.tools.misc;

import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import odis.dfs.client.DFSClient;
import odis.dfs.client.DFSInputStream;
import odis.dfs.client.DFSOutputStream;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.client.DistributedFileSystem.DFSFileInfoImpl;
import odis.dfs.common.FSConstants;
import odis.io.FileSystem;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.util.ThreadLocalRandomData;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.misc.net.InetAddressUtils;

/**
 * @author zhangduo
 */
public class SimpleBenchReadWriteTool implements ITool {

    private final Options options;

    public SimpleBenchReadWriteTool() {
        options = new Options();
        options.withOption("fs", "filesystem", "zkPath@zkAddr");
        options.setMinimalParamCount(1);
    }

    @Override
    public void usage(PrintWriter out) {
        out.println("Use: DFSBench -fs zkPath@zkAddr {write|read|seek|stress} [options]\n");
        out.println("  write [buf] [bytes] [replication]");
        out.println("      Write a file `bytes' long for read and seek test");
        out.println("  read [buf] [flags]");
        out.println("      Read the file created by `write'");
        out.println("  seek [flags]");
        out.println("      Seek randomly with the file created by `write'");
        out.println("  seekmt <threads> [flags]");
        out.println("      Seek randomly with the file created by `write' by multithread");
        out.println("  stress <file_count> <max_file_size_in_MB> <files_per_dir> <dir_level>");
        out.println("     `stress' creates <file_count> files (each sized randomly\n "
                + "     1MB-<max_file_size_in_MB>) in many directories each with <files_per_dir>\n"
                + "     files. Every directory has a depth of <dir_level> counting from the root \n"
                + "     of the test dir. It then read through them, and then delete all of them");
    }

    @Override
    public String comment() {
        return "Simple benchmark of ODFS";
    }

    private int getFlagsBits(String[] args, int start) throws Exception {
        int bits = 0;
        for (int i = start; i < args.length; i++) {
            Field flagField = DFSClient.class.getField(args[i]);
            int flag = flagField.getInt(null);
            bits |= flag;
        }
        return bits;
    }

    private void write(DistributedFileSystem dfs, String machineName,
            int bufSize, long totalSize, int replication) throws IOException {
        Random rand = new Random();
        byte[] buf = new byte[bufSize];
        rand.nextBytes(buf);
        Path file = new Path("/ndfsBenchmark/IOTest/write_" + machineName);
        DFSOutputStream out = dfs.createRaw(file, true, true, 0, replication,
                (int) dfs.getBlockSize(), new FsPermission(00777));
        long startTime = System.currentTimeMillis();
        long finishTime;
        long total = 0;
        try {
            for (int i = 0; i < totalSize / bufSize; i++) {
                out.write(buf);
                total += buf.length;
            }
            finishTime = System.currentTimeMillis();
        } finally {
            out.close();
        }
        System.out.println("Write file test on " + machineName + " finished.");
        System.out.println("Totally write " + total + " to file "
                + file.toString() + " .");
        System.out.println("File " + file.toString() + " has a size of "
                + dfs.getLength(file) + " .");
        System.out.println("Start at : " + startTime);
        System.out.println("Finish at : " + finishTime);
        System.out.println("Speed: " + total / (finishTime - startTime)
                + "KBps.");
    }

    private void read(DistributedFileSystem dfs, String machineName,
            int bufsize, int flags) throws IOException {
        Path file = new Path("/ndfsBenchmark/IOTest/write_" + machineName);
        byte[] buf = new byte[bufsize];
        DFSInputStream in = dfs.openRaw(file, flags);
        long startTime = System.currentTimeMillis();
        long total = 0;
        long finishTime;
        try {
            for (int c; (c = in.read(buf)) != -1;) {
                total += c;
            }
            finishTime = System.currentTimeMillis();
        } finally {
            ReadWriteUtils.safeClose(in);
        }

        System.out.println("Read file test on " + machineName + " finished.");
        System.out.println("File " + file.toString() + " has a size of "
                + dfs.getLength(file) + " .");
        System.out.println("Actually read " + total + " bytes.");
        System.out.println("Start at : " + startTime);
        System.out.println("Finish at : " + finishTime);
        System.out.println("Speed: " + total / (finishTime - startTime)
                + "KBps.");
    }

    private void seek(DistributedFileSystem dfs, String machineName, int flags)
            throws IOException {
        Path file = new Path("/ndfsBenchmark/IOTest/write_" + machineName);
        long size = dfs.getLength(file);
        int readSize = 1024;
        byte[] buf = new byte[readSize];
        int count = 1000;
        long startTime = System.currentTimeMillis();
        DFSInputStream in = dfs.openRaw(file, flags);
        try {
            for (int i = 0; i < count; i++) {
                in.seek(ThreadLocalRandomData.current().nextLong(
                        size - readSize));
                if (in.read(buf) < 0) {
                    throw new EOFException();
                }
            }
        } finally {
            ReadWriteUtils.safeClose(in);
        }
        long finishTime = System.currentTimeMillis();

        System.out.println("Seek test on " + machineName + " finished.");
        System.out.println("File " + file.toString() + " has a size of "
                + dfs.getLength(file) + " .");
        System.out.println("Performed " + count + " seeks and read " + readSize
                + " bytes each time in " + (finishTime - startTime) + " ms.");
        System.out.println("Average delay: " + (finishTime - startTime)
                / (double) count + " ms.");
    }

    private void seekMultiThread(final DistributedFileSystem dfs,
            String machineName, int threads, final int flags) throws Exception {
        final Path file = new Path("/ndfsBenchmark/IOTest/write_" + machineName);
        final long size = dfs.getLength(file);
        final int readSize = 1024;
        final int count = 1000;
        final AtomicLong totalTime = new AtomicLong(0);
        Thread[] workers = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            workers[i] = new Thread() {
                public void run() {
                    try {
                        long startTime = System.currentTimeMillis();
                        DFSInputStream in = dfs.openRaw(file, flags);
                        try {
                            byte[] buf = new byte[readSize];
                            for (int i = 0; i < count; i++) {
                                in.seek(ThreadLocalRandomData.current().nextLong(
                                        size - readSize));
                                if (in.read(buf) < 0) {
                                    throw new EOFException();
                                }
                            }
                        } finally {
                            ReadWriteUtils.safeClose(in);
                        }
                        long finishTime = System.currentTimeMillis();
                        totalTime.addAndGet(finishTime - startTime);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            };
            workers[i].start();
        }
        for (int i = 0; i < threads; i++) {
            workers[i].join();
        }
        System.out.println("Seek test on " + machineName + " finished.");
        System.out.println("File " + file.toString() + " has a size of "
                + dfs.getLength(file) + " .");
        System.out.println(threads + " threads performed " + count
                + " seeks each, and read " + readSize + " bytes each time in "
                + totalTime + " ms.");
        System.out.println("Average delay: " + totalTime.get()
                / (double) (count * threads) + " ms ");
    }

    /**
     * traverse a directory recursively and read all files inside
     */
    private long traverse(DistributedFileSystem dfs, Path root, byte[] buf)
            throws IOException {
        DFSFileInfoImpl[] files = dfs.listFiles(root);
        long total = 0;
        for (DFSFileInfoImpl file: files) {
            if (file.isDir()) {
                total += traverse(dfs, file.getPath(), buf);
            } else {
                DFSInputStream in = dfs.openRaw(file.getPath());
                try {
                    for (int c; (c = in.read(buf)) != -1;) {
                        total += c;
                    }
                } finally {
                    ReadWriteUtils.safeClose(in);
                }
            }
        }
        return total;
    }

    private void stress(DistributedFileSystem dfs, String machineName,
            int nrFiles, int maxSizeMB, int filesPerDir, int dirLevels)
            throws IOException {
        Path root = new Path("/ndfsBenchmark/IOTest/stress_" + machineName);
        for (int i = 0; i < dirLevels - 1; i++) {
            root = root.cat(i + "");
        }
        Random rand = new Random();
        byte[] buf = new byte[1024 * 1024];
        rand.nextBytes(buf);

        System.out.printf("%15s: working in %s%n", machineName, root);
        // create all files
        long totalMB = 0;
        long writeStart = System.currentTimeMillis();
        for (int i = 0; i < nrFiles; i++) {
            Path dir = root.cat((i / filesPerDir) + "");
            // create a file
            int mb = rand.nextInt(maxSizeMB) + 1;
            totalMB += mb;
            DFSOutputStream out = dfs.createRaw(dir.cat(i + ""), true, true);
            try {
                for (int j = 0; j < mb; j++) {
                    out.write(buf);
                }
            } finally {
                out.close();
            }
        }
        long writeDone = System.currentTimeMillis();
        System.out.printf(
                "%15s: written %5d files, %10dMB in %10dms, %7.2fMB/s%n",
                machineName, nrFiles, totalMB, writeDone - writeStart, 1000.0
                        * totalMB / (writeDone - writeStart));

        // read all files
        long bytes = traverse(dfs, root, buf);
        long traverseDone = System.currentTimeMillis();
        System.out.printf(
                "%15s:    read %5d files, %10dMB in %10dms, %7.2fMB/s%n",
                machineName, nrFiles, bytes / 1024 / 1024, traverseDone
                        - writeDone, bytes / 1000.0
                        / (traverseDone - writeDone));

        // delete all files
        dfs.delete(root);
        long deleteDone = System.currentTimeMillis();
        System.out.printf("%15s: deleted all files in %10dms%n", machineName,
                deleteDone - traverseDone);
    }

    @Override
    public boolean exec(String[] args) throws Exception {
        PrintWriter out = new PrintWriter(System.out, true);
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            usage(out);
            return false;
        }
        args = options.getRemains();
        DistributedFileSystem dfs = (DistributedFileSystem) FileSystem.getNamed(options.getStringOpt("fs"));
        String machineName = InetAddressUtils.getShortHostName();
        try {
            if (args[0].equals("write")) {
                int bufSize = Integer.parseInt(args[1]);
                // 1G by default
                long bytes = args.length > 2 ? Long.parseLong(args[2])
                        : 1024L * 1024 * 1024;
                int replication = args.length > 3 ? Integer.parseInt(args[3])
                        : FSConstants.NUM_REPLICAS_INHERITED;
                write(dfs, machineName, bufSize, bytes, replication);
            } else if (args[0].equals("read")) {
                int bufSize = Integer.parseInt(args[1]);
                read(dfs, machineName, bufSize, getFlagsBits(args, 2));
            } else if (args[0].equals("seek")) {
                seek(dfs, machineName, getFlagsBits(args, 1));
            } else if (args[0].equals("seekmt")) {
                int threads = Integer.parseInt(args[1]);
                seekMultiThread(dfs, machineName, threads,
                        getFlagsBits(args, 2));
            } else if (args[0].equals("stress")) {
                stress(dfs, machineName, Integer.parseInt(args[1]),
                        Integer.parseInt(args[2]), Integer.parseInt(args[3]),
                        Integer.parseInt(args[4]));
            } else {
                out.println("Unknown command.");
                return false;
            }
        } finally {
            dfs.close();
        }
        return true;
    };
}
