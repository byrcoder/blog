package odis.io.ramfs;

/**
 * hold info data of RAMFile
 * <p>
 * <code>
 *      isDir           boolean         Whether is a File or a Directory
 *      path            String          Abstract path, begins with "/", e.g. "/a/b/c.txt"
 *      lastModified    long            The last modified time of the File or Dir
 *      contentsLen     long            The size of file data
 * </code>
 * </p>
 * 
 * @author why
 * @since 2007-2-6
 */
public class RAMFileInfo {
    private boolean isDir;

    private String path;

    private long lastModified;

    private long contentsLen;

    public RAMFileInfo() {}

    public RAMFileInfo(boolean isDir, String path, long contentsLen,
            long lastModified) {
        this.isDir = isDir;
        this.path = path;
        this.contentsLen = contentsLen;
        this.lastModified = lastModified;
    }

    public long lastModified() {
        return lastModified;
    }

    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public String getName() {
        if (RAMFileSystem.ROOT_PATH.equals(path)) {
            return RAMFileSystem.ROOT_PATH;
        }

        String name = path;
        int idx = path.lastIndexOf(RAMFileSystem.SEPERATOR);
        if (idx >= 0) {
            name = path.substring(idx + 1);
        }
        return name;
    }

    public boolean isDir() {
        return isDir;
    }

    public long getContentsLen() {
        return contentsLen;
    }

    public void setContentsLen(long contentsLen) {
        this.contentsLen = contentsLen;
    }

}
