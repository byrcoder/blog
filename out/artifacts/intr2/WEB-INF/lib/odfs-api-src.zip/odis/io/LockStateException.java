/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

/**
 * Exception thrown when the lock in question is not in the correct state.
 * 
 * @author river
 * @see FileSystem#promoteLock(java.io.File)
 */
public class LockStateException extends Exception {

    private static final long serialVersionUID = -1091303306086411997L;

    /**
     * Constructs a new runtime exception with <code>null</code> as its default
     * message
     */
    public LockStateException() {}

    /**
     * Constructs a new runtime exception with <code>null</code> as its
     * specified message
     * 
     * @param message
     *            the detail message
     */
    public LockStateException(String msg) {
        super(msg);
    }
}
