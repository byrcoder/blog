package odis.io.ramfs;

/**
 * represent a file object in the memory
 * <p>
 * Fields:<br>
 * <code>
 *      data    byte[]  The file data
 * </code>
 * </p>
 * 
 * @author why
 * @since 2007-2-5
 */
public class RAMFileNode extends RAMFSNode {

    public static final byte[] EMPTY_DATA = new byte[0];

    private byte[] data = EMPTY_DATA;

    public RAMFileNode(RAMDirNode parent, String name) {
        super(parent, false, name);
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data, long contentsLen) {
        assert contentsLen <= data.length;

        this.data = data;
        setContentsLen(contentsLen);
        setLastModified(System.currentTimeMillis());
    }

    public void reset() {
        this.data = EMPTY_DATA;
        setContentsLen(0);
        setLastModified(System.currentTimeMillis());
    }

}
