package odis.io;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.FileLock;
import java.nio.channels.Selector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.zookeeper.ZooKeeper;

import odis.rpc2.AbstractRpcServer;
import odis.rpc2.UDPRpcServer;
import odis.serialize.IWritable;
import odis.util.DF;
import toolbox.misc.LogFormatter;
import toolbox.misc.sys.NativeCodeInvoker;

/**
 * Some utilities related to read/write.
 * 
 * @author david
 */
public class ReadWriteUtils {
    private static final Logger LOG = LogFormatter.getLogger(ReadWriteUtils.class);

    /**
     * Writes an int array to a DataOutput.
     * 
     * @param out
     *            the DataOutput instance.
     * @param vl
     *            the int array. Can be null.
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void writeIntArray(DataOutput out, int[] vl)
            throws IOException {
        if (vl == null)
            CDataOutputStream.writeVInt(-1, out);
        else {
            CDataOutputStream.writeVInt(vl.length, out);
            for (int i = 0; i < vl.length; i++)
                out.writeInt(vl[i]);
        } // else
    }

    /**
     * Reads an int array from the DataInput.
     * 
     * @param in
     *            the DataInput instance
     * @return the read int array
     * @throws IOException
     *             if an I/O error occurs
     */
    public static int[] readIntArray(DataInput in) throws IOException {
        int len = CDataInputStream.readVInt(in);
        if (len < 0)
            return null;
        else {
            int[] res = new int[len];
            for (int i = 0; i < len; i++)
                res[i] = in.readInt();

            return res;
        } // else
    }

    /**
     * Reads an array of floats from the DataInput.
     * 
     * @param in
     *            the DataInput instance
     * @param res
     *            the output float array
     * @return the read int array
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void readFloatArray(DataInput in, float[] res)
            throws IOException {
        for (int i = 0; i < res.length; i++)
            res[i] = in.readFloat();
    }

    /**
     * @deprecated use the one using IFileSystem and Path
     */
    @Deprecated
    public static String readTextFile(FileSystem fs, File filename,
            String encoding) throws IOException {
        return readTextFile(fs, new Path(filename), encoding);
    }

    /**
     * Reads a text file as a string.
     * 
     * @param fs
     *            the file-system
     * @param filename
     *            the name of the text-file
     * @param encoding
     *            the encoding of the text-file
     * @return the string
     * @throws IOException
     *             if an I/O error occurs
     */
    public static String readTextFile(IFileSystem fs, Path filename,
            String encoding) throws IOException {
        InputStream is = fs.open(filename);
        try {
            StringBuilder ans = new StringBuilder();
            BufferedReader reader;
            if (encoding == null)
                reader = new BufferedReader(new InputStreamReader(is));
            else
                reader = new BufferedReader(new InputStreamReader(is, encoding));
            try {
                while (true) {
                    String line = reader.readLine();
                    if (line == null)
                        break;
                    ans.append(line).append('\n');
                } // while
                return ans.toString();
            } finally {
                reader.close();
            }
        } finally {
            is.close();
        }
    }

    /**
     * @deprecated use the one using IFileSystem and Path
     */
    @Deprecated
    public static void readWritableFromFile(FileSystem fs, File fn,
            IWritable... w) throws IOException {
        readWritableFromFile(fs, new Path(fn), w);
    }

    /**
     * Reads a serials of writable from a file
     * 
     * @param fs
     *            the file-system
     * @param fn
     *            the file-name
     * @param w
     *            the IWritable objects
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void readWritableFromFile(FileSystem fs, Path fn,
            IWritable... w) throws IOException {
        CDataInputStream in = new CDataInputStream(fs.open(fn));
        try {
            for (int i = 0; i < w.length; i++)
                w[i].readFields(in);
        } finally {
            in.close();
        }
    }

    /**
     * @deprecated use the one using IFileSystem and Path
     */
    @Deprecated
    public static void saveWritableToFile(FileSystem fs, File fn,
            IWritable... w) throws IOException {
        saveWritableToFile(fs, new Path(fn), w);
    }

    /**
     * Saves a serials of writable to a file
     * 
     * @param fs
     *            the file-system
     * @param fn
     *            the file-name
     * @param w
     *            the IWritable objects
     * @throws IOException
     *             if an I/O error occurs
     */
    public static void saveWritableToFile(FileSystem fs, Path fn,
            IWritable... w) throws IOException {
        CDataOutputStream out = new CDataOutputStream(fs.create(fn));
        try {
            for (int i = 0; i < w.length; i++)
                w[i].writeFields(out);
        } finally {
            out.close();
        }
    }

    /**
     * Delete a local directory and all its contents. If we return false, the
     * directory may be partially-deleted.
     */
    public static boolean fullyDelete(File dir) throws IOException {
        return FileSystem.getNamed("local").delete(new Path(dir));
    }

    /**
     * Copies a file and/or directory and all its contents (including files and
     * file in sub-dirs)
     * 
     * @param fs
     *            the file-system
     * @param src
     *            the source path
     * @param dst
     *            the destination path
     * @param overwrite
     *            whether overwrite existing file. If specified false, and the
     *            destination file exits, an exception is thrown.
     * @return whether a target file was overwritten
     * @throws IOException
     *             if an I/O error occurs
     */
    public static boolean copyContents(FileSystem fs, File src, File dst,
            boolean overwrite) throws IOException {
        return copyContents(fs, new Path(src), new Path(dst), overwrite);
    }

    /**
     * Copies a file and/or directory and all its contents (including files and
     * file in sub-dirs)
     * 
     * @param fs
     *            the file-system
     * @param src
     *            the source path
     * @param dst
     *            the destination path
     * @param overwrite
     *            whether overwrite existing file. If specified false, and the
     *            destination file exits, an exception is thrown.
     * @return whether a target file was overwritten
     * @throws IOException
     *             if an I/O error occurs
     */
    public static boolean copyContents(FileSystem nfs, Path src, Path dst,
            boolean overwrite) throws IOException {
        if (nfs.exists(dst) && !overwrite)
            return false;

        Path dstParent = dst.getParentFile();
        if (dstParent != null && !nfs.exists(dstParent)) {
            nfs.mkdirs(dstParent);
        }

        if (nfs.isFile(src)) {
            InputStream in = nfs.open(src);
            try {
                OutputStream out = nfs.create(dst, true);
                byte buf[] = new byte[2048];
                try {
                    int readBytes = in.read(buf);
                    while (readBytes >= 0) {
                        out.write(buf, 0, readBytes);
                        readBytes = in.read(buf);
                    }
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        } else {
            nfs.mkdirs(dst);
            FileInfo contents[] = nfs.listFiles(src);
            if (contents != null)
                for (int i = 0; i < contents.length; i++) {
                    Path newDst = dst.cat(contents[i].getPath().getName());
                    if (!copyContents(nfs, contents[i].getPath(), newDst,
                            overwrite))
                        return false;
                }
        }
        return true;
    }

    /**
     * Create local link dst to local file src. We do hard link in linux if src
     * and dst in same mount point, and do copy in windows or src and dst in
     * different mount point. No overwrite.
     * 
     * @param src
     * @param dst
     * @return
     */
    public static void localHardLink(Path src, Path dst) throws IOException {
        if (!src.asFile().exists()) {
            throw new IOException("source " + src + " non-exists");
        }
        if (dst.asFile().exists()) {
            throw new IOException("dst " + dst + " exists");
        }

        String srcPath = src.asFile().getCanonicalPath();
        String dstPath = dst.asFile().getCanonicalPath();

        String OS = System.getProperty("os.name");
        if (OS.toLowerCase().startsWith("linux")) {
            DF df = new DF(srcPath);
            String mountPoint = df.getMount();
            if (dstPath.startsWith(mountPoint)) {
                // same mount point
                int exitValue = NativeCodeInvoker.execute(
                        "ln " + srcPath + " " + dstPath, new File(".")).getExitValue();
                if (exitValue != 0) {
                    throw new IOException("create hard link failed : "
                            + exitValue);
                }
                return;
            }
        }

        if (!copyContents(FileSystem.getNamed("local"), src, dst, false)) {
            throw new IOException("copy content from " + src + " to " + dst
                    + " failed");
        }

    }

    @Deprecated
    public static long getDirSize(FileSystem fs, File dir) throws IOException {
        return getDirSize(fs, new Path(dir));
    }

    /**
     * Gets size of a directory (including all files and files in sub-dirs)
     * 
     * @param fs
     *            the file-system
     * @param path
     *            the path of the directory
     * @throws IOException
     */
    public static long getDirSize(IFileSystem fs, Path dir) throws IOException {
        long res = 0;
        for (FileInfo f: fs.listFiles(dir)) {
            if (fs.isFile(f.getPath()))
                res += fs.getLength(f.getPath());
            else
                res += getDirSize(fs, f.getPath());
        }
        return res;
    }

    /**
     * 关闭一个Closeable并且保证不抛出任何Throwable.
     */
    public static void safeClose(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Exception when closing " + c, e);
            }
        }
    }

    /**
     * 关闭一个Socket并且保证不抛出任何Throwable.
     */
    public static void safeCloseSocket(Socket s) {
        if (s != null) {
            try {
                s.close();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Exception when closing " + s, e);
            }
        }
    }

    /**
     * 关闭一个ServerSocket并且保证不抛出任何Throwable.
     */
    public static void safeCloseServerSocket(ServerSocket ss) {
        if (ss != null) {
            try {
                ss.close();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Exception when closing " + ss, e);
            }
        }
    }

    /**
     * 关闭一个Selector并且保证不抛出任何Throwable.
     */
    public static void safeCloseSelector(Selector selector) {
        if (selector != null) {
            try {
                selector.close();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Exception when closing " + selector, e);
            }
        }
    }

    /**
     * 停止一个RpcServer并且保证不抛出任何Throwable.
     */
    public static void safeStopRpcServer(AbstractRpcServer server) {
        if (server != null) {
            try {
                server.stop();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Exception when stopping " + server, e);
            }
        }
    }

    /**
     * 停止一个UDPRpcServer并且保证不抛出任何Throwable.
     */
    public static void safeStopUDPRpcServer(UDPRpcServer server) {
        if (server != null) {
            try {
                server.stop();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Exception when stopping " + server, e);
            }
        }
    }

    public static void safeReleaseFileLock(FileLock lock) {
        if (lock != null) {
            try {
                lock.release();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "Exception when releasing " + lock, t);
            }
        }
    }

    /**
     * Find a free port that cound be bind start from the <code>fromPort</code>.
     * 
     * @param fromPort
     * @return
     */
    public static int probeFreePort(int fromPort) {
        int port = fromPort;
        while (true) {
            ServerSocket ss = null;
            try {
                ss = new ServerSocket(port);
                ss.setReuseAddress(true);
                return port;
            } catch (IOException e) {
                LOG.log(Level.INFO, "try to bind to port " + port
                        + " failed, try next", e);
            } finally {
                safeCloseServerSocket(ss);
            }
            port++;
        }
    }

    public static void safeCloseZooKeeper(ZooKeeper zk) {
        if (zk != null) {
            try {
                zk.close();
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "Exception when closing " + zk, t);
            }
        }
    }

}
