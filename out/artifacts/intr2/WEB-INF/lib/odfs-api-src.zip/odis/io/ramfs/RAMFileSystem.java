package odis.io.ramfs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FSInputStream;
import odis.io.FSOutputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.LockStateException;
import odis.io.Path;
import odis.io.permission.FsPermission;
import toolbox.misc.FileUtils;
import toolbox.misc.LogFormatter;

/**
 * A File System in the Memory.
 * 
 * @author why
 * @since 2007-2-5
 */
public class RAMFileSystem extends FileSystem {
    private static final Logger LOG = LogFormatter.getLogger(RAMFileSystem.class.getName());

    public static final int BLOCK_SIZE = 32 * 1024 * 1024; // 32M

    private RAMFSNode root = new RAMDirNode();

    private String name = "ram";

    public static final String PARENT_PATH = "..";

    public static final String CURRENT_PATH = ".";

    public static final String PARENT_PATH_SEP = "../";

    public static final String CURRENT_PATH_SEP = "./";

    public static final String ROOT_PATH = "/";

    public static final String SEPERATOR = "/";

    public RAMFileSystem() {}

    public RAMFileSystem(String name) {
        this.name = name;
    }

    protected void closeInternal() {
        root = null;
    }

    public void completeLocalInput(File localFile) throws IOException {}

    public void completeLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {}

    public void copyFromLocalFile(File src, Path dst) throws IOException {
        doFromLocalFile(src, dst, false);
    }

    public void moveFromLocalFile(File src, Path dst) throws IOException {
        doFromLocalFile(src, dst, true);
    }

    public void copyToLocalFile(Path src, File dst) throws IOException {
        if (dst.exists()) {
            if (!dst.isDirectory()) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new File(dst, src.getName());
                if (dst.exists()) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }
        dst = dst.getCanonicalFile();

        if (isDirectory(src)) {
            if (!dst.mkdirs()) {
                throw new IOException("Cannot create target dir " + dst);
            }
            FileInfo contents[] = listFiles(src);
            for (int i = 0; i < contents.length; i++) {
                copyToLocalFile(contents[i].getPath(), new File(dst,
                        contents[i].getPath().getName()));
            }
        } else {
            DataInfo data = directOpen(src);
            OutputStream out = FileSystem.getNamed("local").create(
                    new Path(dst));
            try {
                out.write(data.getBuf(), 0, (int) data.getLength());
            } finally {
                out.close();
            }
        }
    }

    /**
     * put local file to RAMFileSystem, and delete local file if deleteSource is
     * true.
     * 
     * @param src
     * @param dst
     * @param deleteSource
     * @throws IOException
     */
    private void doFromLocalFile(File src, Path dst, boolean deleteSource)
            throws IOException {
        if (exists(dst)) {
            if (!isDirectory(dst)) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new Path(dst, src.getName());
                if (exists(dst)) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }

        if (src.isDirectory()) {
            mkdirs(dst);
            File contents[] = src.listFiles();
            for (int i = 0; i < contents.length; i++) {
                doFromLocalFile(contents[i],
                        new Path(dst, contents[i].getName()), deleteSource);
            }
        } else {
            int fileSize = (int) src.length(); // XXX: 有没有可能截断long？
            byte[] buf = new byte[fileSize];
            InputStream in = new FileInputStream(src);
            int left = fileSize;
            LOG.info("doFromLocalFile: fileSize=" + fileSize);
            try {
                int bytesRead = in.read(buf);
                left -= bytesRead;
                LOG.info("doFromLocalFile: bytesRead=" + bytesRead + " left="
                        + left);
                while (bytesRead >= 0 && left > 0) {
                    left -= bytesRead;
                    bytesRead = in.read(buf, fileSize - left, left);
                    LOG.info("doFromLocalFile: bytesRead=" + bytesRead
                            + " left=" + left);
                }
                directCreate(dst, buf, fileSize);
            } finally {
                in.close();
            }

        }
        if (deleteSource && !FileUtils.fullyDelete(src)) {
            throw new IOException("Delete source " + src + " failed");
        }
    }

    /**
     * FileSystem.create(File f) 调用了FileSystem.create(File f, boolean overwrite,
     * int bufferSize)，而该函数返回的FSOutputStream是又加了一层缓冲的OutputStream。
     * 因为缓冲是在内存里，最终数据放置的位置又是在内存里，因此实际上进行了两次数据拷贝。
     * <p>
     * 这里实现的就是直接把缓冲区data数据赋给File，避免了数据二次拷贝的成本。
     * </p>
     * 2007-2-27
     * 
     * @param f
     *            file to create in RAMFileSystem
     * @param data
     *            data to set to file, user must ensure the data will not be
     *            reuse after this call.
     * @param contentsLen
     *            file size
     */
    public void directCreate(Path f, byte[] data, int contentsLen)
            throws IOException {
        RAMDirNode parent = getParentNodeWithDirCreated(f);
        if (parent.hasChild(f.getName())) {
            throw new IOException(" file " + f + " already exist");
        }
        RAMFileNode file;
        if (parent.hasChild(f.getName())) {
            file = parent.resetFile(f.getName());
        } else {
            file = parent.newFile(f.getName());
        }

        file.setData(data, contentsLen);
    }

    /**
     * 用于 directOpen()函数返回File的数据缓冲区位置和长度信息
     * 
     * @since 2007-2-27
     */
    public static class DataInfo {
        private byte[] buf;

        private long length;

        public DataInfo(byte[] buf, long length) {
            this.buf = buf;
            this.length = length;
        }

        public byte[] getBuf() {
            return buf;
        }

        public long getLength() {
            return length;
        }

    }

    /**
     * 直接返回f的data buffer
     * 
     * @param f
     * @throws IOException
     */
    public DataInfo directOpen(Path f) throws IOException {
        RAMFSNode node = getNode(f);
        if (node == null) {
            throw new IOException("file " + f.getAbsolutePath() + " not exist");
        }
        if (node.isDirectory()) {
            throw new IOException("dir object cannot be open ");
        }

        RAMFileNode file = (RAMFileNode) node;
        byte[] dataBuf = file.getData();
        long len = file.getContentsLen();
        return new DataInfo(dataBuf, len);
    }

    public FSOutputStream createRaw(Path f, boolean overwrite)
            throws IOException {
        return this.createRaw(f, overwrite, false);
    }

    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent) throws IOException {
        RAMDirNode parent = getParentNodeWithDirCreated(f);
        if (parent.hasChild(f.getName()) && !overwrite) {
            throw new IOException(" file " + f + " already exist");
        }
        RAMFileNode file;
        if (parent.hasChild(f.getName())) {
            file = parent.resetFile(f.getName());
        } else {
            file = parent.newFile(f.getName());
        }

        return new RAMFSOutputStream(file);
    }

    public boolean delete(Path f) throws IOException {
        return delete(f, true);

    }

    @Override
    public boolean delete(Path f, boolean recursive) throws IOException {
        RAMDirNode parent = getParentNode(f);
        if (parent == null) {
            // root cannot delete
            return false;
        }
        RAMFSNode child = parent.getChild(f.getName());
        if (child == null) {
            return false;
        }
        if (!recursive && child instanceof RAMDirNode) {
            throw new IOException("Cannot delete " + f
                    + " when recursive is false because it is a directory.");
        }
        parent.delete(f.getName());
        return true;
    }

    public boolean deprive(Path f) throws IOException {
        RAMDirNode parent = getParentNode(f);
        if (parent == null) {
            // root cannot deprive
            return false;
        }
        if (!parent.hasChild(f.getName())) {
            throw new IOException(" file not exist " + f.getAbsolutePath());
        }
        RAMFSNode node = parent.getChild(f.getName());
        if (node.isDirectory()) {
            throw new IOException("Can only deprive a file");
        }

        parent.delete(f.getName());
        return true;
    }

    public boolean exists(Path f) throws IOException {
        try {
            RAMDirNode parent = getParentNode(f);
            if (parent != null) {
                return parent.hasChild(f.getName());
            } else {
                // root always exist
                return true;
            }
        } catch (IOException e) {
            return false;
        }
    }

    public long getBlockSize() {
        return BLOCK_SIZE;
    }

    public long getLength(Path f) throws IOException {
        RAMFSNode node = null;
        try {
            node = getNode(f);
            if (node == null || node == root) {
                return 0;
            }
            return node.getContentsLen();

        } catch (IOException e) {
            LOG.log(Level.WARNING, "get length failed", e);
            return 0; // non exist file
        }

    }

    public long getLengthRecursive(Path f) throws IOException {
        RAMFSNode node = null;
        try {
            node = getNode(f);
            if (node == null || node == root) {
                return 0;
            }
            return node.getContentsLen();

        } catch (IOException e) {
            LOG.log(Level.WARNING, "get length recursive failed", e);
            return 0; // non exist file
        }
    }

    private FileSystem cachedLocalFileSystem = null;

    private FileSystem getLocalFileSystem() {
        if (cachedLocalFileSystem == null) {
            try {
                cachedLocalFileSystem = FileSystem.getNamed("local");
            } catch (IOException e) {
                throw new RuntimeException("cannot acquire local filesystem", e);
            }
        }
        return cachedLocalFileSystem;
    }

    public void getLock(Path file, int type) throws IOException {
        getLocalFileSystem().getLock(file, type);
    }

    public String getLockState(Path file) throws IOException {
        return getLocalFileSystem().getLockState(file);
    }

    public void promoteLock(Path file) throws LockStateException, IOException {
        getLocalFileSystem().promoteLock(file);
    }

    public void releaseLock(Path file) throws IOException {
        getLocalFileSystem().releaseLock(file);
    }

    @Override
    public String getName() {
        return name;
    }

    public boolean isDirectory(Path f) throws IOException {
        RAMFSNode node = getNode(f);

        return node.isDirectory();
    }

    public long lastModified(Path f) throws IOException {
        RAMFSNode node = getNode(f);
        if (node == null) {
            throw new IOException(f.getAbsolutePath() + " not exist");
        }

        return node.getLastModified();
    }

    private void linkNode(RAMFSNode srcNode, RAMDirNode dstParNode, String name)
            throws IOException {
        if (srcNode.isFile()) {
            RAMFileNode nd = dstParNode.newFile(name);
            nd.setData(((RAMFileNode) srcNode).getData(),
                    srcNode.getContentsLen());
        } else {
            dstParNode.newDir(name);
            RAMDirNode dstNode = (RAMDirNode) dstParNode.getChild(name);
            Collection<RAMFSNode> children = ((RAMDirNode) srcNode).getChildren();
            for (RAMFSNode child: children) {
                linkNode(child, dstNode, child.getName());
            }
        } // else
    }

    public boolean link(Path src, Path dst) throws IOException {
        RAMFSNode srcNode = getNode(src);
        if (srcNode == null)
            return false;
        RAMFSNode dstParNode = getNode(dst.getParentFile());
        if (dstParNode == null || !dstParNode.isDirectory())
            return false;

        linkNode(srcNode, (RAMDirNode) dstParNode, dst.getName());

        return true;
    }

    public FileInfo[] listFiles(Path f) throws IOException {
        RAMFSNode node = getNode(f);
        if (node == null || !node.isDirectory()) {
            throw new IOException(" path not exist " + f.getAbsolutePath());
        }

        ArrayList<FileInfo> lists = new ArrayList<FileInfo>();
        Collection<RAMFSNode> children = ((RAMDirNode) node).getChildren();
        for (RAMFSNode child: children) {
            final RAMFileInfo info = child.getFileInfo();
            lists.add(new FileInfo(new Path(info.getPath())) {
                @Override
                public long getLastModified() {
                    return info.lastModified();
                }

                @Override
                public long getLength() {
                    return info.getContentsLen();
                }

                @Override
                public Path getTarget() {
                    return path;
                }

                @Override
                public boolean isDir() {
                    return info.isDir();
                }

                @Override
                public boolean isSLink() {
                    return false;
                }
            });
        } // for child

        return lists.toArray(new FileInfo[lists.size()]);
    }

    public void mkdirs(Path f) throws IOException {
        RAMDirNode parent = getParentNodeWithDirCreated(f);
        parent.newDir(f.getName());
    }

    public FSInputStream openRaw(Path f) throws IOException {
        RAMFSNode node = getNode(f);
        if (node == null) {
            throw new IOException("file " + f.getAbsolutePath() + " not exist");
        }
        if (node.isDirectory()) {
            throw new IOException("dir object cannot be open ");
        }

        RAMFileNode file = (RAMFileNode) node;
        byte[] dataBuf = file.getData();
        long len = file.getContentsLen();
        return new RAMFSInputStream(dataBuf, len);
    }

    public static String normalizeName(String name) {
        int start = 0;
        int end = name.length();
        if (name.startsWith(RAMFileSystem.CURRENT_PATH_SEP)) {
            start = 2;
        }
        if (name.endsWith(RAMFileSystem.ROOT_PATH)) {
            end--;
        }
        if (start > 0 || end < name.length()) {
            name = name.substring(start, end);
        }
        return name;
    }

    public static String normalizePath(String parent, String name) {
        String nname = normalizeName(name);
        if (parent.equals(RAMFileSystem.ROOT_PATH)) {
            return parent + nname;
        } else {
            return parent + RAMFileSystem.SEPERATOR + nname;
        }
    }

    public boolean rename(Path src, Path dst) throws IOException {
        return rename(src, dst, true);
    }

    @Override
    public boolean rename(Path src, Path dst, boolean overwrite)
            throws IOException {
        if (src.equals(dst)) {
            return false;
        }

        if (src.getName().equals(RAMFileSystem.ROOT_PATH)
                || dst.getName().equals(RAMFileSystem.ROOT_PATH)) {
            throw new IOException("root dir cannot rename");
        }

        RAMDirNode dstParent = getParentNode(dst);
        if (dstParent.hasChild(dst.getName())) {
            throw new IOException(" dst file " + dst.getAbsolutePath()
                    + " already exist");
        }

        RAMDirNode srcParent = getParentNode(src);
        if (!srcParent.hasChild(src.getName())) {
            throw new IOException(" src file " + src.getAbsolutePath()
                    + " not exist");
        }

        RAMFSNode srcNode = srcParent.delete(src.getName());
        srcNode.rename(normalizePath(dstParent.getPath(), dst.getName()));
        dstParent.addChild(srcNode);

        return true;
    }

    public File startLocalInput(Path fsInputFile, File tmpLocalFile)
            throws IOException {
        return null;
    }

    public File startLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        return null;
    }

    /*
     * get parent RAMDirNode of File
     *
     * @return null means f is root file
     */
    private RAMDirNode getParentNode(Path f) throws IOException {

        Path parent = f.getParentFile();
        if (parent == null) {
            // root's parent is null
            return null;
        }

        Stack<String> paths = new Stack<String>();
        while (parent != null) {
            paths.push(parent.getName());
            parent = parent.getParentFile();
        }

        paths.pop(); // pop root
        RAMDirNode pos = (RAMDirNode) root;
        while (!paths.isEmpty()) {
            String name = paths.pop();
            if (!pos.hasChild(name) || pos.getChild(name).isFile()) {
                throw new IOException("path error");
                //return null;
            }
            pos = (RAMDirNode) pos.getChild(name);
        }
        return pos;
    }

    private RAMDirNode getParentNodeWithDirCreated(Path f) throws IOException {
        Stack<String> paths = new Stack<String>();

        Path parent = f.getParentFile();
        while (parent != null) {
            paths.push(parent.getName());
            parent = parent.getParentFile();
        }

        paths.pop(); // pop root
        RAMDirNode pos = (RAMDirNode) root;
        while (!paths.isEmpty()) {
            String name = paths.pop();
            if (pos.hasChild(name) && pos.getChild(name).isFile()) {
                throw new IOException("already has a file named (" + name
                        + ") in path");
            }
            if (!pos.hasChild(name)) {
                pos.newDir(name);
            }
            pos = (RAMDirNode) pos.getChild(name);
        }

        return pos;
    }

    /*
     * get RAMFSNode of File
     *
     * @return null means error occurs
     */
    private RAMFSNode getNode(Path f) throws IOException {
        RAMDirNode parent;
        try {
            parent = getParentNode(f);
        } catch (IOException e) {
            throw new IOException("file " + f.getAbsolutePath() + " not exist");
        }
        if (parent != null) {
            RAMFSNode node = parent.getChild(f.getName());
            if (node == null) {
                throw new IOException("file " + f.getAbsolutePath()
                        + " not exist");
            }
            return node;
        } else {
            return root;
        }
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags) throws IOException {
        return createRaw(f, overwrite, createParent);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int blockSize) throws IOException {
        return createRaw(f, overwrite, createParent);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission) throws IOException {
        return createRaw(f, overwrite, createParent);
    }

    @Override
    public FSInputStream openRaw(Path f, int flags) throws IOException {
        return openRaw(f);
    }

    @Override
    public void mkdirs(Path f, int replication, FsPermission permission)
            throws IOException {
        mkdirs(f);
    }

}
