/**
 * @(#)NamedPermitException.java, 2008-7-31. Copyright 2008 Yodao, Inc. All
 *                                           rights reserved. YODAO
 *                                           PROPRIETARY/CONFIDENTIAL. Use is
 *                                           subject to license terms.
 */
package odis.io;

/**
 * Exception thrown in named permit operations.
 * 
 * @author river
 */
public class NamedPermitException extends Exception {

    private static final long serialVersionUID = -3416225219421429901L;

    /**
     * construct a <code>NamedPermitException</code> with the given message
     * 
     * @param message
     *            the given message
     */
    public NamedPermitException(String message) {
        super(message);
    }

}
