/**
 * @(#)NativeRamFileSystem.java, 2007-10-17. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io.nram;

import java.io.IOException;
import java.util.HashMap;

import odis.io.FSInputStream;
import odis.io.LocalFileSystem;
import odis.io.Path;

/**
 * NativeRamFileSystem is the same to LocalFileSystem, exception that file
 * opened should be read into memory first before accessed.
 * {@link odis.io.nram.NativeRamFile} is used to hold the file in memory.
 * <p>
 * Use {@code FileSystem.getNamed(FileSystem.RAMLOCAL)} to acquire one instance
 * of NativeRamFileSystem.
 * </p>
 * </p> <strong>Remember to close the input stream returned by
 * {@link #openRaw(Path)}, or it leads to severe memory leak.</strong> </p>
 * 
 * @see odis.io.FileSystem#getNamed(String)
 * @see NativeRamFile
 * @author river
 */
public class NativeRamFileSystem extends LocalFileSystem {
    private HashMap<String, CacheItem> cache = new HashMap<String, CacheItem>();

    public NativeRamFileSystem() throws IOException {
        super();
        initializeCounters();
    }

    /**
     * Mirror the file at local into memory and return the inputstream based on
     * the memory.
     */
    @Override
    public FSInputStream openRaw(Path f) throws IOException {
        return new NativeRamFileInputStream(openNativeRamFile(f));
    }

    @Override
    public String getName() {
        return RAMLOCAL;
    }

    /**
     * Return the cache item or create new one if the file is not opened
     * previously.
     * 
     * @param f
     * @return
     * @throws IOException
     */
    private CacheItem openNativeRamFile(Path f) throws IOException {
        synchronized (cache) {
            String key = f.asFile().getCanonicalPath();

            // load from cache
            CacheItem cacheItem = cache.get(key);
            if (cacheItem != null) {
                cacheItem.incRef();
                return cacheItem;
            }

            // create new native ram file
            NativeRamFile nf = new NativeRamFile();
            boolean good = false;
            try {
                nf.mirrorLocalFile(f.getAbsolutePath());
                good = true;
            } finally {
                if (!good) {
                    nf.close();
                }
            }

            if (good) {
                cacheItem = new CacheItem(key, nf); // initialized ref count is 1
                cache.put(key, cacheItem);
                return cacheItem;
            } else {
                // we should be goes here
                throw new IOException("open native ram file " + f + " failed");
            }
        }

    }

    /**
     * Decrease the reference count, and close the native ram file if reference
     * count is zero.
     * 
     * @param item
     */
    private void closeNativeRamFile(CacheItem item) {
        synchronized (cache) {
            int ref = item.decRef();
            if (ref == 0) {
                cache.remove(item.key);
                item.file.close();
            }
        }
    }

    /**
     * Return the size of cache.
     * 
     * @return
     */
    int cacheSize() {
        return cache.size();
    }

    /**
     * {@link NativeRamFile} with reference count.
     * 
     * @author river
     */
    private static final class CacheItem {
        private String key;

        private NativeRamFile file;

        private int ref;

        /**
         * Create cache item with reference count initialized to 1.
         * 
         * @param key
         * @param f
         */
        public CacheItem(String key, NativeRamFile f) {
            this.key = key;
            this.file = f;
            this.ref = 1;
        }

        /**
         * Increase the reference count.
         * 
         * @return
         */
        public int incRef() {
            this.ref++;
            return ref;
        }

        /**
         * Decrease the reference count.
         * 
         * @return
         */
        public int decRef() {
            this.ref--;
            return ref;
        }
    }

    /**
     * {@link FSInputStream} implementation based on {@link NativeRamFile}.
     * Because several inputstream instance could hold one same
     * {@link NativeRamFile} copy, the read state should not be stored in
     * {@link NativeRamFile}, so we save the position and length in inputstream
     * instance.
     * 
     * @author river
     */
    private final class NativeRamFileInputStream extends FSInputStream {
        private final CacheItem cacheItem;

        private final byte[] singleBuf = new byte[1];

        private final long length;

        private long position;

        /**
         * Create the input stream instance from native ram file.
         * 
         * @param cacheItem
         */
        public NativeRamFileInputStream(CacheItem cacheItem) {
            this.cacheItem = cacheItem;
            this.length = cacheItem.file.length();
            this.position = 0;
        }

        /**
         * Return the read position.
         */
        @Override
        public long getPos() throws IOException {
            return position;
        }

        /**
         * Seek to the position. This method won't affect the read pointer in
         * native ram file.
         */
        @Override
        public void seek(long pos) throws IOException {
            if (pos < 0) {
                this.position = 0;
            } else if (pos > length) {
                this.position = length;
            } else {
                this.position = pos;
            }
        }

        /**
         * Read on byte out. Refer to {@link #read(byte[], int, int)}.
         */
        @Override
        public int read() throws IOException {
            if (read(singleBuf, 0, 1) < 0) {
                return -1;
            }
            readCounter.addAndGet(1);
            return singleBuf[0] & 0xff;
        }

        /**
         * Return the available bytes.
         */
        public int available() throws IOException {
            return (int) Math.min(this.length - this.position,
                    Integer.MAX_VALUE);
        }

        /**
         * Release the native ram file.
         */
        @Override
        public void close() throws IOException {
            closeNativeRamFile(this.cacheItem);
        }

        /**
         * Call {@link NativeRamFile#get(long, byte[], int, int)}.
         */
        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int count = cacheItem.file.get(position, b, off, len);
            if (count > 0) {
                position += count;
            }
            readCounter.addAndGet(count);
            return count;
        }

        /**
         * Skip n bytes, this method call {@link #seek(long)} actually.
         */
        @Override
        public long skip(long n) throws IOException {
            long oldPos = this.position;
            this.seek(oldPos + n);
            return this.position - oldPos;
        }

        @Override
        public long getLength() {
            return length;
        }

    }
}
