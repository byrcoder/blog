/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import odis.io.permission.FsPermission;

/**
 * A null file system that does nothing.
 * 
 * @author river
 */
public class NullFileSystem extends FileSystem {

    public NullFileSystem() {}

    @Override
    public String getName() {
        return "NULFS";
    }

    @Override
    public FSInputStream openRaw(Path f) throws IOException {
        throw new IOException("Not implemented");
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent) throws IOException {
        return createRaw(f, overwrite);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite)
            throws IOException {
        return new FSOutputStream() {
            private long pos = 0;

            private Random rand = new Random();

            @Override
            public long getPos() throws IOException {
                return pos;
            }

            @SuppressWarnings("unused")
            private void timeCost(int size) {
                int t = size / 100;
                if (t < 3)
                    t = rand.nextInt(3);
                else
                    t = rand.nextInt(t);

                try {
                    Thread.sleep(t);
                } catch (InterruptedException e) {}
            }

            @Override
            public void write(int b) throws IOException {
                pos++;
                //        timeCost(1);
            }

            @Override
            public void write(byte[] b) throws IOException {
                pos += b.length;
                //        timeCost(b.length);
            }

            @Override
            public void write(byte[] buf, int offset, int length)
                    throws IOException {
                pos += length;
                //        timeCost(length);
            }

        };
    }

    @Override
    public boolean rename(Path src, Path dst) throws IOException {
        return true;
    }

    @Override
    public boolean rename(Path src, Path dst, boolean overwrite)
            throws IOException {
        return true;
    }

    @Override
    public boolean link(Path src, Path dst) throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public boolean delete(Path f) throws IOException {
        return true;
    }

    @Override
    public boolean delete(Path f, boolean recursive) throws IOException {
        return true;
    }

    @Override
    public boolean deprive(Path f) throws IOException {
        return true;
    }

    @Override
    public boolean exists(Path f) throws IOException {
        return false;
    }

    @Override
    public boolean isDirectory(Path f) throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public long getLength(Path f) throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public long getLengthRecursive(Path f) throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public long lastModified(Path f) throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public FileInfo[] listFiles(Path f) throws IOException {
        return null;
    }

    @Override
    public void mkdirs(Path f) throws IOException {
        throw new IOException("not implemented");

    }

    @Override
    public void getLock(Path f, int lock) throws IOException {}

    @Override
    public void promoteLock(Path f) throws IOException {}

    @Override
    public String getLockState(Path f) throws IOException {
        return null;
    }

    @Override
    public void releaseLock(Path f) throws IOException {}

    @Override
    public void copyFromLocalFile(File src, Path dst) throws IOException {}

    @Override
    public void moveFromLocalFile(File src, Path dst) throws IOException {}

    @Override
    public void copyToLocalFile(Path src, File dst) throws IOException {}

    @Override
    public File startLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public void completeLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        throw new IOException("not implemented");

    }

    @Override
    public File startLocalInput(Path fsInputFile, File tmpLocalFile)
            throws IOException {
        throw new IOException("not implemented");
    }

    @Override
    public void completeLocalInput(File localFile) throws IOException {
        throw new IOException("not implemented");

    }

    @Override
    protected void closeInternal() {}

    @Override
    public long getBlockSize() {
        return 1;
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags) throws IOException {
        return createRaw(f, overwrite);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int blockSize) throws IOException {
        return createRaw(f, overwrite);
    }

    @Override
    public FSInputStream openRaw(Path f, int flags) throws IOException {
        return openRaw(f);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission) throws IOException {
        return createRaw(f, overwrite);
    }

    @Override
    public void mkdirs(Path f, int replication, FsPermission permission)
            throws IOException {
        mkdirs(f);
    }
}
