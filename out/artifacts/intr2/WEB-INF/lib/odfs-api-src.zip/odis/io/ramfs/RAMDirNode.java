package odis.io.ramfs;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * represent a directory object in the memory
 * <p>
 * Fields:<br>
 * <code>
 *      children  Map<String,RAMFSNode>  The children of a dir node in the directory tree.
 *                                       a map of ([name] -> [node])
 * </code>
 * </p>
 * 
 * @author why, David
 * @since 2007-2-5
 */
public class RAMDirNode extends RAMFSNode {

    private Map<String, RAMFSNode> children = new HashMap<String, RAMFSNode>();

    public RAMDirNode() {
        super();
    }

    public RAMDirNode(RAMDirNode parent, String name) {
        super(parent, true, name);
    }

    public void addChild(RAMFSNode child) throws IOException {
        if (children.containsKey(child.getName())) {
            throw new IOException("file " + child.getName() + " alread exist");
        }

        children.put(child.getName(), child);
    }

    public RAMFileNode newFile(String name) throws IOException {
        if (hasChild(name)) {
            throw new IOException(this.getPath() + "/" + name
                    + " already exist");
        }

        RAMFileNode fileNode = new RAMFileNode(this, name);
        children.put(name, fileNode);
        return fileNode;
    }

    public void newDir(String name) {
        if (hasChild(name)) {
            // ignore this
            return;
        } // if

        RAMDirNode dirNode = new RAMDirNode(this, name);
        children.put(name, dirNode);
    }

    public RAMFileNode resetFile(String name) throws IOException {
        if (!hasChild(name)) {
            throw new IOException(name + " not exist");
        }
        RAMFSNode node = children.get(name);
        if (!node.isFile()) {
            throw new IOException(name + " is not a file");
        }
        RAMFileNode file = (RAMFileNode) node;
        file.reset();
        return file;
    }

    public RAMFSNode delete(String name) throws IOException {
        if (!hasChild(name)) {
            throw new IOException(name + " not exist");
        }
        return children.remove(name);
    }

    public boolean hasChild(String name) {
        return children.containsKey(name);
    }

    public RAMFSNode getChild(String name) {
        return children.get(name);
    }

    public Collection<RAMFSNode> getChildren() {
        return children.values();
    }
}
