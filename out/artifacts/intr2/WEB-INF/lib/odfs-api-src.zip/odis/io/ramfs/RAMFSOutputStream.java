package odis.io.ramfs;

import java.io.IOException;

import odis.io.DataOutputBuffer;
import odis.io.FSOutputStream;

/**
 * @author why
 * @since 2007-2-6
 */
public class RAMFSOutputStream extends FSOutputStream {
    private long filePos = 0;

    private boolean closed = false;

    private RAMFileNode fileNode;

    private DataOutputBuffer buffer = new DataOutputBuffer();

    public RAMFSOutputStream(RAMFileNode fileNode) {
        this.fileNode = fileNode;
    }

    @Override
    public long getPos() throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }
        return filePos;
    }

    @Override
    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }
        buffer.write(b);
        filePos++;
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        buffer.write(b, off, len);
        filePos += len;
    }

    @Override
    public void flushBlock() throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }
        // ?? what should i do ?
    }

    @Override
    public void close() throws IOException {
        closed = true;
        fileNode.setData(buffer.getData(), filePos);
        buffer.reset();
    }

}
