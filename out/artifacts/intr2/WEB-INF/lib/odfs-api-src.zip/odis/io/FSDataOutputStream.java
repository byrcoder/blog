/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package odis.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;

/**
 * Utility that wraps a {@link FSOutputStream} in a {@link CDataOutputStream},
 * buffers output through a {@link BufferedOutputStream} and creates a checksum
 * file.
 * <p>
 * river (2006-10-31) Remove the flushBlock() method.
 */
public class FSDataOutputStream extends CDataOutputStream {

    private static final class Buffer extends BufferedOutputStream {
        public Buffer(FSOutputStream out, int bufferSize) {
            super(out, bufferSize);
        }

        public long getPos() throws IOException {
            return ((FSOutputStream) out).getPos() + this.count;
        }

        // optimized version of write(int)
        @Override
        public void write(int b) throws IOException {
            if (count >= buf.length) {
                super.write(b);
            } else {
                buf[count++] = (byte) b;
            }
        }

    }

    @Deprecated
    public FSDataOutputStream(FileSystem fs, File file, boolean overwrite,
            int bufferSize) throws IOException {
        this(fs.createRaw(file, overwrite), bufferSize);
    }

    @Deprecated
    public FSDataOutputStream(FileSystem fs, Path file, boolean overwrite,
            int bufferSize) throws IOException {
        this(fs.createRaw(file, overwrite), bufferSize);
    }

    @Deprecated
    public FSDataOutputStream(FileSystem fs, File file, boolean overwrite,
            int bufferSize, boolean persistent) throws IOException {
        this(fs.createRaw(file, overwrite, persistent), bufferSize);
    }

    @Deprecated
    public FSDataOutputStream(FileSystem fs, Path file, boolean overwrite,
            int bufferSize, boolean persistent) throws IOException {
        this(fs.createRaw(file, overwrite, persistent), bufferSize);
    }

    @Deprecated
    public FSDataOutputStream(FileSystem fs, Path file, boolean overwrite,
            int bufferSize, boolean persistent, int fileBlockSize)
            throws IOException {
        this(fs.createRaw(file, overwrite, persistent, 0, fileBlockSize),
                bufferSize);
    }

    public FSDataOutputStream(FSOutputStream fsOut) {
        this(fsOut, FileSystem.DEFAULT_WRITE_BUFFER_SIZE);
    }

    public FSDataOutputStream(FSOutputStream fsOut, int bufferSize) {
        super(new Buffer(fsOut, bufferSize));
    }

    public long getPos() throws IOException {
        return ((Buffer) out).getPos();
    }

}
