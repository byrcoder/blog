package odis.io.ramfs;

/**
 * a file system node in the RAMFileSystem which constitute the directory tree
 * structure. Fields: info RAMFileInfo File Information data parent RAMFSNode
 * Parent Node in the Directory Tree
 * 
 * @author why
 * @since 2007-2-6
 */
public abstract class RAMFSNode {
    private RAMFileInfo info;

    private RAMFSNode parent;

    // only for root dir node
    public RAMFSNode() {
        info = new RAMFileInfo(true, "/", 0, System.currentTimeMillis());
        this.parent = null;
    }

    public RAMFSNode(RAMFSNode parent, boolean isDir, String name) {
        String path = RAMFileSystem.normalizePath(parent.getPath(), name);
        info = new RAMFileInfo(isDir, path, 0, System.currentTimeMillis());
        this.parent = parent;
    }

    public boolean isDirectory() {
        return info.isDir();
    }

    public boolean isFile() {
        return !info.isDir();
    }

    public String getName() {
        return info.getName();
    }

    public String getPath() {
        return info.getPath();
    }

    public RAMFSNode getParent() {
        return parent;
    }

    public long getLastModified() {
        return info.lastModified();
    }

    public void setLastModified(long lastModified) {
        info.setLastModified(lastModified);
    }

    public void rename(String newPath) {
        info.setPath(newPath);
    }

    public RAMFileInfo getFileInfo() {
        return info;
    }

    public void setContentsLen(long contentsLen) {
        info.setContentsLen(contentsLen);
    }

    public long getContentsLen() {
        return info.getContentsLen();
    }

    //    protected abstract int getFsType();

}
