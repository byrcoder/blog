/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.permission.FsPermission;
import odis.net.DataClient;
import odis.net.DataClient.ConcurrentLimitException;
import odis.util.ThreadLocalRandomData;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

/**
 * Simple read-only "remote" file system through TCP connection to another
 * machine.
 * 
 * @author river
 */
public class RemoteFileSystem extends FileSystem {
    public static final Logger LOG = LogFormatter.getLogger(RemoteFileSystem.class);

    static long RETRY_IDLE_TIME = UnitUtils.SECOND * 5;

    private static final int MAX_RETRIES = 3;

    private static final int DEFAULT_IO_TIMEOUT = (int) (2 * UnitUtils.MINUTE);

    private String name;

    private String host;

    private int port;

    private int timeout = DEFAULT_IO_TIMEOUT;

    class RemoteNFSInputStream extends FSInputStream {
        private DataClient client;

        private InputStream is;

        private long pos = 0;

        private long size;

        public RemoteNFSInputStream(String host, int port, String path)
                throws IOException {
            client = new DataClient(host, port, path, timeout);
            is = null;
            pos = 0;
            reconnect();
            this.size = client.size();
        }

        public void seek(long pos) throws IOException {
            if (pos == this.pos)
                return;
            if (pos > size)
                pos = size;

            if (pos > this.pos)
                this.pos += skip(pos - this.pos);
            else {
                is.close();
                is = client.open(pos);
                this.pos = pos;
            }
        }

        public long getPos() throws IOException {
            return pos;
        }

        public int available() throws IOException {
            return (int) (size - pos);
        }

        public void close() throws IOException {
            if (is != null) {
                is.close();
            }
        }

        public boolean markSupport() {
            return false;
        }

        public int read() throws IOException {
            if (pos >= size) {
                return -1; // end of file
            }

            int retry = 0;
            while (retry < MAX_RETRIES) {
                try {
                    int r = is.read();
                    if (r >= 0) {
                        pos++;
                        readCounter.addAndGet(1);
                    }
                    return r;
                } catch (SocketTimeoutException e) {
                    LOG.log(Level.WARNING, "read data from " + client.getHost()
                            + ":" + client.getPort() + " timeout(" + timeout
                            + "), retries = " + retry);
                    reconnect();
                    retry++;
                } catch (NoRouteToHostException e) {
                    LOG.log(Level.WARNING, "NoRouteToHostException caught "
                            + "when read data from " + client.getHost() + ":"
                            + client.getPort() + ", retries=" + retry);
                    reconnect();
                    retry++;
                }
            } // while
            throw new IOException("read data from " + client.getHost() + ":"
                    + client.getPort() + " failed after retry for "
                    + MAX_RETRIES + " times");
        }

        public int read(byte[] b) throws IOException {
            return read(b, 0, b.length);
        }

        /**
         * 断开当前的连接，创建新的连接到服务器.
         * 
         * @throws IOException
         */
        private void reconnect() throws IOException {
            int retries = 0;
            ThreadLocalRandomData rand = ThreadLocalRandomData.current();

            while (retries < MAX_RETRIES) {
                try {
                    try {
                        if (is != null) {
                            is.close();
                            is = null;
                        }
                    } catch (IOException e) {
                        LOG.log(Level.WARNING, "close connection failed", e);
                    }
                    is = client.open(pos);
                    break;
                } catch (ConcurrentLimitException e) {
                    // reach the concurrent limit, just wait and retry
                    // don't wait concurrent limit, throw it, it will be handle in upper level tuqc
                    LOG.log(Level.WARNING,
                            "concurrent limit for " + client.getHost() + ":"
                                    + client.getPort() + ":" + client.getPath()
                                    + ", retry " + retries);
                    retries++;
                } catch (SocketTimeoutException e) {
                    retries++;
                    LOG.log(Level.WARNING, "connect and send command to "
                            + client.getHost() + ":" + client.getPort()
                            + " timeout, will retry", e);
                } catch (NoRouteToHostException e) {
                    retries++;
                    LOG.log(Level.WARNING,
                            "NoRouteToHostException caught " + "connect to "
                                    + client.getHost() + ":" + client.getPort()
                                    + ", will retry", e);
                } catch (IOException e) {
                    if (e.getMessage().startsWith("Connection reset by peer")) {
                        // This exception could be raised due to network problem
                        // and may retry
                        LOG.log(Level.WARNING,
                                "Connection reset by peer exception caught "
                                        + " when connecting "
                                        + client.getHost() + ":"
                                        + client.getPort() + ", retries="
                                        + retries + ".");
                        retries++;
                    } else {
                        throw e;
                    }
                }

                try {
                    Thread.sleep(RETRY_IDLE_TIME
                            + rand.nextInt((int) RETRY_IDLE_TIME));
                } catch (InterruptedException e) {}
            } // while

            if (is == null) {
                throw new IOException("connect and send command to "
                        + client.getHost() + ":" + client.getPort()
                        + " failed after " + retries + " retries");
            }
        }

        public int read(byte[] b, int off, int len) throws IOException {
            if (pos >= size) {
                return -1; // end of file
            }

            int retry = 0;
            while (retry < MAX_RETRIES) {
                try {
                    long toRead = size - pos;
                    if (toRead > len)
                        toRead = len;
                    int r = is.read(b, off, (int) toRead);
                    if (r > 0) {
                        readCounter.addAndGet(r);
                        pos += r;
                    }
                    return r;
                } catch (SocketTimeoutException e) {
                    LOG.log(Level.WARNING, "read data from " + client.getHost()
                            + ":" + client.getPort() + " timeout(" + timeout
                            + "), retries = " + retry);
                    reconnect();
                    retry++;
                } catch (NoRouteToHostException e) {
                    LOG.log(Level.WARNING, "NoRouteToHostException caught "
                            + "when reading data from " + client.getHost()
                            + ":" + client.getPort() + ", retries=" + retry);
                    reconnect();
                    retry++;
                } catch (IOException e) {
                    if (e.getMessage().startsWith("Connection reset by peer")) {
                        // This exception could be raised due to network problem
                        // and may retry
                        LOG.log(Level.WARNING,
                                "Connection reset by peer exception caught "
                                        + " when reading data from "
                                        + client.getHost() + ":"
                                        + client.getPort() + ", retries="
                                        + retry + ".");
                        reconnect();
                        retry++;
                    } else {
                        throw e;
                    }
                }
            }
            throw new IOException("read data from " + client.getHost() + ":"
                    + client.getPort() + " failed after retry for "
                    + MAX_RETRIES + " times");
        }

        public long skip(long n) throws IOException {
            long r = is.skip(n);
            if (r > 0)
                pos += r;
            return r;
        }

        @Override
        public long getLength() {
            return size;
        }
    }

    public RemoteFileSystem(String name) throws IOException {
        this.name = name;
        String[] parts = name.split(":");

        if (parts.length != 3 || !parts[0].equals("remote")) {
            throw new IOException("bad filesystem name : " + name);
        }
        host = parts[1];
        port = Integer.parseInt(parts[2]);
        initializeCounters();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public FSInputStream openRaw(Path f) throws IOException {
        return new RemoteNFSInputStream(host, port, f.getPath());
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite)
            throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean rename(Path src, Path dst) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean link(Path src, Path dst) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean delete(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean delete(Path f, boolean recursive) throws IOException {
        throw new AbstractMethodError("not implemented");
    }

    @Override
    public boolean deprive(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean exists(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean isDirectory(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public long lastModified(Path f) throws IOException {
        throw new UnsupportedOperationException(" not implemented");
    }

    @Override
    public long getLength(Path f) throws IOException {
        DataClient client = new DataClient(host, port, f.getPath(), timeout);
        int retries = 0;
        while (retries < MAX_RETRIES) {
            try {
                return client.size();
            } catch (SocketTimeoutException e) {
                LOG.log(Level.WARNING, "send command to " + client.getHost()
                        + ":" + client.getPort() + " timeout(getLength()), "
                        + "should retry.");
                retries++;
            } catch (NoRouteToHostException e) {
                // NoRouteToHostException could be raised when the network 
                // bandwidth is full
                LOG.log(Level.WARNING,
                        "NoRouteToHostException caught " + " when connect to "
                                + client.getHost() + ":" + client.getPort()
                                + ", should retry.");
                retries++;
            } catch (IOException e) {
                if (e.getMessage().startsWith("Connection reset by peer")) {
                    // This exception could be raised due to network problem
                    // and may retry
                    LOG.log(Level.WARNING,
                            "Connection reset by peer exception caught "
                                    + " when connect to " + client.getHost()
                                    + ":" + client.getPort()
                                    + ", should retry.");
                    retries++;
                } else {
                    throw e;
                }
            }
        }

        throw new IOException("send command to " + client.getHost() + ":"
                + client.getPort() + " failed after " + retries + " retries.");
    }

    @Override
    public long getLengthRecursive(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public FileInfo[] listFiles(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void mkdirs(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void getLock(Path f, int lock) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void promoteLock(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void releaseLock(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public String getLockState(Path f) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void copyFromLocalFile(File src, Path dst) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void moveFromLocalFile(File src, Path dst) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    /**
     * copy remote file(not dir) to local disk current can't confirm src path is
     * dir or file, treat it as file
     * 
     * @author tuqc
     */
    @Override
    public void copyToLocalFile(Path src, File dst) throws IOException {
        if (dst.exists()) {
            if (!dst.isDirectory()) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new File(dst, src.getName());
                if (dst.exists()) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }
        dst = dst.getCanonicalFile();

        //        if (isDirectory(src)) {
        //            dst.mkdirs();
        //            FileInfo contents[] = listFiles(src);
        //            for (int i = 0; i < contents.length; i++) {
        //                copyToLocalFile(contents[i].getPath(), new File(dst,
        //                        contents[i].getPath().getName()));
        //            }
        //        }
        byte buf[] = new byte[FileSystem.DEFAULT_READ_BUFFER_SIZE];
        InputStream in = openRaw(src);
        try {
            OutputStream out = FileSystem.getNamed("local").create(
                    new Path(dst));
            try {
                int bytesRead = in.read(buf);
                while (bytesRead >= 0) {
                    out.write(buf, 0, bytesRead);
                    bytesRead = in.read(buf);
                }
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }

    @Override
    public File startLocalOutput(Path nfsOutputFile, File tmpLocalFile)
            throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void completeLocalOutput(Path nfsOutputFile, File tmpLocalFile)
            throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public File startLocalInput(Path nfsInputFile, File tmpLocalFile)
            throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void completeLocalInput(File localFile) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    protected void closeInternal() throws IOException {}

    @Override
    public long getBlockSize() {
        // zf: what's this?
        return 32 * 1024 * 1024;
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent, int flags) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean persistent, int flags, int blockSize) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public FSInputStream openRaw(Path f, int flags) throws IOException {
        return openRaw(f);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission) throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public boolean rename(Path src, Path dst, boolean overwrite)
            throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

    @Override
    public void mkdirs(Path f, int replication, FsPermission permission)
            throws IOException {
        throw new UnsupportedOperationException("not implemented");
    }

}
