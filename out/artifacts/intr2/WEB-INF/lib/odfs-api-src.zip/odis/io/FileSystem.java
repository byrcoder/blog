/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 11, 2006
 */
package odis.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DFSClientContext;
import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockInfo;
import odis.dfs.common.DFSClientConfig;
import odis.io.nram.NativeRamFileSystem;
import odis.io.permission.FsPermission;
import odis.io.ramfs.RAMFileSystem;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.mutable.MutableInt;

import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

/**
 * An abstract base class for a fairly generic filesystem. It may be implemented
 * as a distributed filesystem, or as a "local" one that reflects the
 * locally-connected disk. The local version exists for testing.
 * <p>
 * All user code that may potentially use the Outfox Distributed File System
 * should be written to use a FileSystem object. The DFS is a multi-machine
 * system that appears as a single disk. It's useful because of its fault
 * tolerance and potentially very large capacity.
 * <p>
 * The local implementation is {@link LocalFileSystem} and distributed
 * implementation is odis.dfs.client.DistributedFileSystem.
 * 
 * @author Mike Cafarella, Feng Zhou, David
 */
public abstract class FileSystem implements IFileSystem {

    private static final Logger LOG = LogFormatter.getLogger(FileSystem.class);

    public static final String LOCAL = "local";

    public static final String RAMLOCAL = "ramlocal";

    public static final String DEFAULT_CUID = "default";

    public static final int DEFAULT_OPEN_BUFFER_SIZE = 16 * 1024;

    public static final int DEFAULT_READ_BUFFER_SIZE = 64 * 1024;

    public static final int DEFAULT_WRITE_BUFFER_SIZE = 64 * 1024;

    private static final String ALIAS_FILE_NAME = "fsname.alias";

    private static final Map<String, String> FS_NAME_ALIAS;

    static {
        Enumeration<URL> aliasFiles;
        try {
            aliasFiles = FileSystem.class.getClassLoader().getResources(
                    "META-INF/" + ALIAS_FILE_NAME);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "load fs name alias failed", e);
            aliasFiles = Collections.enumeration(Collections.<URL>emptyList());
        }
        Map<String, String> fsNameAlias = new HashMap<String, String>();
        while (aliasFiles.hasMoreElements()) {
            URL url = aliasFiles.nextElement();
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new InputStreamReader(
                        url.openStream()));
                for (String line; (line = reader.readLine()) != null;) {
                    if (StringUtils.isBlank(line)) {
                        continue;
                    }
                    String[] ss = line.trim().split("=");
                    fsNameAlias.put(ss[0], ss[1]);
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING, "loading fs name alias failed", e);
            } finally {
                ReadWriteUtils.safeClose(reader);
            }
        }
        FS_NAME_ALIAS = Collections.unmodifiableMap(fsNameAlias);
        LOG.info("fs name alias: " + FS_NAME_ALIAS);
    }

    protected static final Map<String, Pair<FileSystem, MutableInt>> NAME_TO_FS = new HashMap<String, Pair<FileSystem, MutableInt>>();

    /**
     * <p>
     * The counters are left null on purpose, so that subclasses have the choice
     * not to support any of these counters. Lefting them null makes
     * {@link #getCounterValue(int) } returns -1, so that invokers could know the
     * counter is not supported. Otherwise, the invoker may be confused by the
     * forever 0 value returned.
     * </p>
     * <p>
     * Subclasses should initialize the counters by either
     * {@link #initializeCounters()} or
     * {@link #inheritCounters(odis.io.FileSystem)} before starting to use them.
     * </p>
     */
    protected AtomicLong writeCounter;

    protected AtomicLong readCounter;

    /**
     * Inherit counters from the other FileSystem, i.e., replace the counters of
     * this FileSystem with those of the other FileSystem.
     * 
     * @param fs
     */
    protected void inheritCounters(FileSystem fs) {
        this.writeCounter = fs.writeCounter;
        this.readCounter = fs.readCounter;
    }

    /**
     * Initialize counters.
     */
    protected void initializeCounters() {
        this.writeCounter = new AtomicLong();
        this.readCounter = new AtomicLong();
    }

    public long getCounterValue(int counter) {
        switch (counter) {
            case COUNTER_READ_BYTES:
                if (readCounter == null) {
                    return -1;
                }
                return readCounter.get();
            case COUNTER_WRITE_BYTES:
                if (writeCounter == null) {
                    return -1;
                }
                return writeCounter.get();
            default:
                return -1;
        }
    }

    /** Returns the default filesystem implementation. */
    public static FileSystem get() throws IOException {
        return DFSClientContext.getDefaultFileSystem();
    }

    @Override
    public String getCUID() {
        return DEFAULT_CUID;
    }

    /**
     * Get a file-system by a name.
     * <p>
     * Currently supported systems includes:<br>
     * <code>
     *   local          the LocalFileSystem<br>
     *   remote         the RemoteFileSystem<br>
     *   ram[:<id>]     the RAMFileSystem<br>
     *   <host>:<port>  the DistributedFileSystem<br>
     *   ob:[local|remote|ram[:<id>]|<host>:<port>]
     *                  the OarBackedFileSystem with specified Underlying FS<br>
     * </code>
     * </p>
     * 
     * @param name
     * @return
     * @throws IOException
     */
    public static FileSystem getNamed(String name) throws IOException {
        return getNamed(name, true);
    }

    private static FileSystem createByName(String name) throws IOException {
        return createByName(name, null);
    }

    private static FileSystem createByName(String name, Configuration conf)
            throws IOException {
        if (LOCAL.equals(name)) {
            return new LocalFileSystem();
        } else if (RAMLOCAL.equals(name)) {
            return new NativeRamFileSystem();
        } else if (name.startsWith("remote")) {
            return new RemoteFileSystem(name);
        } else if (name.equals("ram") || name.startsWith("ram:")) {
            return new RAMFileSystem(name);
        } else {
            String[] ss = name.split("@");
            try {
                return new DistributedFileSystem(ss[1], ss[0],
                        conf == null ? new DFSClientConfig()
                                : new DFSClientConfig(conf));
            } catch (InterruptedException e) {
                throw new IOException(
                        "Create DistributedFileSystem interrupted", e);
            }
        }
    }

    /**
     * Get a file-system by a name.
     * <p>
     * Currently supported systems includes:<br>
     * <code>
     *   local          the LocalFileSystem<br>
     *   remote         the RemoteFileSystem<br>
     *   ram[:<id>]     the RAMFileSystem<br>
     *   <host>:<port>  the DistributedFileSystem<br>
     *   ob:[local|remote|ram[:<id>]|<host>:<port>]
     *                  the OarBackedFileSystem with specified Underlying FS<br>
     * </code>
     * </p>
     * 
     * @param name
     * @param reuse
     *            reuse FileSystem instance
     * @return
     * @throws IOException
     */
    public static FileSystem getNamed(String name, boolean reuse,
            Configuration conf) throws IOException {
        String aliasName = FS_NAME_ALIAS.get(name);
        if (aliasName != null) {
            name = aliasName;
        }
        if (!reuse) {
            return createByName(name, conf);
        }
        FileSystem fs;
        synchronized (NAME_TO_FS) {
            Pair<FileSystem, MutableInt> pair = NAME_TO_FS.get(name + ".reuse");
            if (pair == null) {
                pair = new Pair<FileSystem, MutableInt>(
                        createByName(name, conf), new MutableInt(0));
                NAME_TO_FS.put(name + ".reuse", pair);
            }
            pair.getSecond().increment();
            fs = pair.getFirst();
        }
        return fs;
    }

    public static FileSystem getNamed(String name, boolean reuse)
            throws IOException {
        String aliasName = FS_NAME_ALIAS.get(name);
        if (aliasName != null) {
            name = aliasName;
        }
        if (!reuse) {
            return createByName(name);
        }
        FileSystem fs;
        synchronized (NAME_TO_FS) {
            Pair<FileSystem, MutableInt> pair = NAME_TO_FS.get(name + ".reuse");
            if (pair == null) {
                pair = new Pair<FileSystem, MutableInt>(createByName(name),
                        new MutableInt(0));
                NAME_TO_FS.put(name + ".reuse", pair);
            }
            pair.getSecond().increment();
            fs = pair.getFirst();
        }
        return fs;
    }

    abstract protected void closeInternal() throws IOException;

    @Override
    public final void close() throws IOException {
        synchronized (NAME_TO_FS) {
            Pair<FileSystem, MutableInt> pair = NAME_TO_FS.get(getName()
                    + ".reuse");
            if (pair != null) {
                pair.getSecond().decrement();
                if (pair.getSecond().intValue() > 0) {
                    return;
                }
                NAME_TO_FS.remove(getName() + ".reuse");
            }
        }
        closeInternal();
    }

    // /////////////////////////////////////////////////////////////
    // FileSystem
    // /////////////////////////////////////////////////////////////
    /**
     * Returns a name for this filesystem, suitable to pass to
     * {@link FileSystem#getNamed(String)}.
     */
    @Override
    public abstract String getName();

    protected FileSystem() {}

    /**
     * Return a 2D array of size 1x1 or greater, containing hostnames where
     * portions of the given file can be found. For a nonexistent file or
     * regions, null will be returned. This call is most helpful with DFS, where
     * it returns hostnames of machines that contain the given file. The
     * FileSystem will simply return an elt containing 'localhost'.
     */
    // public abstract String[][] getFileCacheHints(File f, long start, long
    // len) throws IOException;
    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public FSDataInputStream open(File f, int bufferSize) throws IOException {
        return open(new Path(f), bufferSize);
    }

    /**
     * The default implementation will throw an
     * {@link UnsupportedOperationException}
     */
    @Override
    public BlockInfo[] getFileBlocksInfo(Path f) throws IOException {
        throw new UnsupportedOperationException();
    }

    /**
     * Opens an FSDataInputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param bufferSize
     *            the size of the buffer to be used.
     * @return the FSDataInputStream instance for the opened file.
     * @throws IOException
     *             if an I/O error occurs
     */
    @Override
    public FSDataInputStream open(Path f, int bufferSize) throws IOException {
        FSInputStream in = this.openRaw(f);
        boolean succ = false;
        try {
            FSDataInputStream result = new FSDataInputStream(in, bufferSize);
            succ = true;
            return result;
        } finally {
            if (!succ) {
                ReadWriteUtils.safeClose(in);
            }
        }
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public FSDataInputStream open(File f) throws IOException {
        return open(new Path(f));
    }

    /**
     * Opens an FSDataInputStream at the indicated File with default bufferSize.
     * 
     * @param f
     *            the file to open
     * @return the FSDataInputStream instance for the opened file
     * @throws IOException
     *             if an I/O error occurs
     */
    @Override
    public FSDataInputStream open(Path f) throws IOException {
        return open(f, DEFAULT_OPEN_BUFFER_SIZE);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public FSInputStream openRaw(File f) throws IOException {
        return openRaw(new Path(f));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public FSDataOutputStream create(File f) throws IOException {
        return create(new Path(f), true, DEFAULT_WRITE_BUFFER_SIZE);
    }

    @Override
    public FSDataOutputStream create(Path f) throws IOException {
        return create(f, true, DEFAULT_WRITE_BUFFER_SIZE);
    }

    @Deprecated
    public FSDataOutputStream create(File f, boolean overwrite)
            throws IOException {
        return create(new Path(f), overwrite);
    }

    @Override
    public FSDataOutputStream create(Path f, boolean overwrite)
            throws IOException {
        return create(f, overwrite, DEFAULT_WRITE_BUFFER_SIZE);
    }

    @Deprecated
    public FSDataOutputStream create(File f, boolean overwrite, int bufferSize)
            throws IOException {
        return create(new Path(f), overwrite, bufferSize);
    }

    /**
     * Opens an FSDataOutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if the file with this name already exists, then if true, the
     *            file will be overwritten, and if false, an exception is thrown
     * @param bufferSize
     *            the size of the buffer to be used
     */
    @Override
    public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize)
            throws IOException {
        if (bufferSize <= 0) {
            throw new IllegalArgumentException("Buffer size " + bufferSize
                    + " <= 0");
        }
        return new FSDataOutputStream(createRaw(f, overwrite), bufferSize);
    }

    @Deprecated
    public FSDataOutputStream create(File f, boolean overwrite,
            boolean createParent) throws IOException {
        return create(new Path(f), overwrite, DEFAULT_WRITE_BUFFER_SIZE,
                createParent);
    }

    @Override
    public FSDataOutputStream create(Path f, boolean overwrite,
            boolean createParent) throws IOException {
        return create(f, overwrite, DEFAULT_WRITE_BUFFER_SIZE, createParent);
    }

    @Deprecated
    public FSDataOutputStream create(File f, boolean overwrite, int bufferSize,
            boolean createParent) throws IOException {
        return create(new Path(f), overwrite, bufferSize, createParent);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize,
            boolean createParent) throws IOException {
        if (bufferSize <= 0) {
            throw new IllegalArgumentException("Buffer size " + bufferSize
                    + " <= 0");
        }
        return new FSDataOutputStream(createRaw(f, overwrite, createParent),
                bufferSize);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public FSDataOutputStream create(Path f, boolean overwrite, int bufferSize,
            boolean createParent, int blockSize) throws IOException {
        if (bufferSize <= 0) {
            throw new IllegalArgumentException("Buffer size " + bufferSize
                    + " <= 0");
        }
        return new FSDataOutputStream(createRaw(f, overwrite, createParent, 0,
                blockSize), bufferSize);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public FSOutputStream createRaw(File f, boolean overwrite)
            throws IOException {
        return createRaw(new Path(f), overwrite);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public FSOutputStream createRaw(File f, boolean overwrite,
            boolean createParent) throws IOException {
        return createRaw(new Path(f), overwrite, createParent);
    }

    @Override
    public QuorumFSOutputStream createQuorum(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission, Executor workerExecutor)
            throws IOException {
        final FSOutputStream out = createRaw(f, overwrite, createParent, flags,
                replication, blockSize, permission);
        return new QuorumFSOutputStream(blockSize, 1) {

            @Override
            public void write(byte[] b, int off, int len) throws IOException {
                if (out.getPos() + len > blockSize) {
                    throw new CompleteException("reach file limit " + blockSize
                            + ", pos=" + out.getPos() + " len=" + len);
                }
                out.write(b, off, len);
                out.flush();
            }

            @Override
            public void close() throws IOException {
                out.close();
            }

            @Override
            public long getPos() {
                try {
                    return out.getPos();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean link(File src, File dst) throws IOException {
        return link(new Path(src), new Path(dst));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean rename(File src, File dst) throws IOException {
        return rename(new Path(src), new Path(dst));
    }

    @Override
    public boolean rename(Path src, Path dst) throws IOException {
        return rename(src, dst, true);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean delete(File f) throws IOException {
        return delete(new Path(f));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean deprive(File f) throws IOException {
        return deprive(new Path(f));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean exists(File f) throws IOException {
        return exists(new Path(f));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean isDirectory(File f) throws IOException {
        return isDirectory(new Path(f));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public long lastModified(File f) throws IOException {
        return lastModified(new Path(f));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public boolean isFile(File f) throws IOException {
        return isFile(new Path(f));
    }

    @Override
    public boolean isFile(Path f) throws IOException {
        if (exists(f) && !isDirectory(f)) {
            return true;
        } else {
            return false;
        } // else
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public long getLength(File f) throws IOException {
        return getLength(new Path(f));
    }

    @Override
    public Path[] listPaths(Path f) throws IOException {
        FileInfo[] files = this.listFiles(f);
        if (files == null)
            return null;

        Path[] paths = new Path[files.length];
        for (int i = 0; i < files.length; i++)
            paths[i] = files[i].getPath();

        return paths;
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public File[] listFiles(File f) throws IOException {
        FileInfo[] files = listFiles(new Path(f));
        File[] res = new File[files.length];
        for (int i = 0; i < files.length; i++)
            res[i] = files[i].getPath().asFile();

        return res;
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public File[] listFiles(File f, FileFilter filter) throws IOException {
        List<File> results = new ArrayList<File>();
        FileInfo listing[] = listFiles(new Path(f));
        if (listing != null) {
            for (int i = 0; i < listing.length; i++) {
                if (filter.accept(listing[i].getPath().asFile())) {
                    results.add(listing[i].getPath().asFile());
                } // if
            } // for i
            return (File[]) results.toArray(new File[results.size()]);
        } else
            return null;
    }

    @Override
    public FileInfo[] listFiles(Path f, PathFilter filter) throws IOException {
        List<FileInfo> results = new ArrayList<FileInfo>();
        FileInfo listing[] = listFiles(f);
        if (listing != null) {
            for (int i = 0; i < listing.length; i++) {
                if (filter.accept(listing[i].getPath())) {
                    results.add(listing[i]);
                } // if
            } // for i
            return (FileInfo[]) results.toArray(new FileInfo[results.size()]);
        } else
            return null;
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void mkdirs(File f) throws IOException {
        mkdirs(new Path(f));
    }

    /**
     * Return 1. Sub-class should override it if it has a replication option.
     */
    @Override
    public int getReplication(Path f) throws IOException {
        return 1;
    }

    /**
     * Does nothing. Sub-class should override it if it has a replication
     * option.
     */
    @Override
    public void setReplication(Path f, int replication, boolean recursive)
            throws IOException {}

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void copyFromLocalFile(File src, File dst) throws IOException {
        copyFromLocalFile(src, new Path(dst));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void moveFromLocalFile(File src, File dst) throws IOException {
        moveFromLocalFile(src, new Path(dst));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void copyToLocalFile(File src, File dst) throws IOException {
        copyToLocalFile(new Path(src), dst);
    }

    /**
     * the same as copyToLocalFile(File src, File dst), except that the source
     * is removed afterward.
     */
    // not implemented yet
    // public abstract void moveToLocalFile(File src, File dst) throws
    // IOException;
    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public File startLocalOutput(File fsOutputFile, File tmpLocalFile)
            throws IOException {
        return startLocalOutput(new Path(fsOutputFile), tmpLocalFile);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void completeLocalOutput(File fsOutputFile, File tmpLocalFile)
            throws IOException {
        completeLocalOutput(new Path(fsOutputFile), tmpLocalFile);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public File startLocalInput(File fsInputFile, File tmpLocalFile)
            throws IOException {
        return startLocalInput(new Path(fsInputFile), tmpLocalFile);
    }

    // /////////////////////////////////////
    // Advisory Locking
    // /////////////////////////////////////
    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void getLock(File file, int type) throws IOException {
        getLock(new Path(file), type);
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void promoteLock(File file) throws LockStateException, IOException {
        promoteLock(new Path(file));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public void releaseLock(File file) throws IOException {
        releaseLock(new Path(file));
    }

    /**
     * Use the version in {@link IFileSystem} instead.
     */
    @Deprecated
    public String getLockState(File file) throws IOException {
        return getLockState(new Path(file));
    }

    // //////////////////////////////
    // Util methods
    // //////////////////////////////
    /**
     * Copy a file's contents to a new location. Returns whether a target file
     * was overwritten
     */
    public static boolean copyContents(FileSystem fs, Path src, Path dst,
            boolean overwrite) throws IOException {
        if (fs.exists(dst) && !overwrite) {
            return false;
        } //if

        Path dstParent = dst.getParentFile();
        if ((dstParent != null) && (!fs.exists(dstParent))) {
            fs.mkdirs(dstParent);
        } // if

        if (fs.isFile(src)) {
            FSInputStream in = fs.openRaw(src);
            try {
                FSOutputStream out = fs.createRaw(dst, true);
                byte buf[] = new byte[DEFAULT_READ_BUFFER_SIZE];
                try {
                    int readBytes = in.read(buf);

                    while (readBytes >= 0) {
                        out.write(buf, 0, readBytes);
                        readBytes = in.read(buf);
                    } // while
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        } else {
            fs.mkdirs(dst);
            FileInfo contents[] = fs.listFiles(src);
            if (contents != null) {
                for (int i = 0; i < contents.length; i++) {
                    Path newDst = dst.cat(contents[i].getPath().getName());
                    if (!copyContents(fs, contents[i].getPath(), newDst,
                            overwrite)) {
                        return false;
                    } // if
                } // for i
            } // if
        } // else
        return true;
    }
}
