/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 11, 2006
 */
package odis.io;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;

/**
 * Utility that wraps a {@link FSInputStream} in a {@link CDataInputStream} and
 * buffers input through a {@link BufferedInputStream}.
 */
public class FSDataInputStream extends CDataInputStream {

    /** Buffer input. This improves performance significantly. */
    private static final class Buffer extends BufferedInputStream {
        public Buffer(FSInputStream in, int bufferSize) throws IOException {
            super(in, bufferSize);
        }

        public void seek(long desired) throws IOException {
            FSInputStream in = (FSInputStream) this.in;
            long end = in.getPos();
            long start = end - this.count;
            if (desired >= start && desired < end) {
                this.pos = (int) (desired - start); // can position within buffer
            } else {
                this.count = 0; // invalidate buffer
                this.pos = 0;
                in.seek(desired);
            }
        }

        public long getPos() throws IOException { // adjust for buffer
            return ((FSInputStream) in).getPos() - (this.count - this.pos);
        }

        public long getLength() throws IOException {
            return ((FSInputStream) in).getLength();
        }

        // optimized version of read()
        @Override
        public int read() throws IOException {
            if (pos >= count) {
                return super.read();
            }
            return buf[pos++] & 0xff;
        }
    }

    /**
     * Use the constructor with Path as the type of the file instead.
     * 
     * @param fs
     * @param file
     * @param bufferSize
     * @throws IOException
     */
    @Deprecated
    public FSDataInputStream(FileSystem fs, File file, int bufferSize)
            throws IOException {
        this(fs, new Path(file), bufferSize);
    }

    /**
     * Use the constructor with Path as the type of the file instead.
     * 
     * @param fs
     * @param file
     * @throws IOException
     */
    @Deprecated
    public FSDataInputStream(FileSystem fs, File file) throws IOException {
        this(fs, file, FileSystem.DEFAULT_OPEN_BUFFER_SIZE);
    }

    @Deprecated
    public FSDataInputStream(FileSystem fs, Path file) throws IOException {
        this(fs, file, FileSystem.DEFAULT_OPEN_BUFFER_SIZE);
    }

    @Deprecated
    public FSDataInputStream(IFileSystem fs, Path file, int bufferSize)
            throws IOException {
        super(null);
        this.in = new Buffer(fs.openRaw(file), bufferSize);
    }

    /** Construct without checksums. */
    public FSDataInputStream(FSInputStream in) throws IOException {
        this(in, FileSystem.DEFAULT_OPEN_BUFFER_SIZE);
    }

    /** Construct without checksums. */
    public FSDataInputStream(FSInputStream in, int bufferSize)
            throws IOException {
        super(null);
        this.in = new Buffer(in, bufferSize);
    }

    public void seek(long desired) throws IOException {
        ((Buffer) in).seek(desired);
    }

    public long getPos() throws IOException {
        return ((Buffer) in).getPos();
    }

    public long getLength() throws IOException {
        return ((Buffer) in).getLength();
    }

}
