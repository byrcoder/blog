/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package odis.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.dfs.common.BlockInfo;
import odis.dfs.util.DfsUtils;
import odis.io.permission.FsPermission;
import toolbox.misc.LogFormatter;

/**
 * Implement the FileSystem API for the native local filesystem.
 */
public class LocalFileSystem extends FileSystem {

    private static final Logger LOG = LogFormatter.getLogger(LocalFileSystem.class);

    private Map<String, NamedLock<String>> locks = new HashMap<String, NamedLock<String>>();

    // by default use copy/delete instead of rename
    boolean useCopyForRename = true;

    public static final int COMPLETE_SUCCESS = 2;

    /** Construct a local filesystem client. */
    public LocalFileSystem() throws IOException {
        // if you find an OS which reliably supports non-POSIX
        // rename(2) across filesystems / volumes, you can
        // uncomment this.
        // String os = System.getProperty("os.name");
        // if (os.toLowerCase().indexOf("os-with-super-rename") != -1)
        //     useCopyForRename = false;
        initializeCounters();
    }

    /**
     * Return 1x1 'localhost' cell if the file exists. Return null if otherwise.
     */
    public String[][] getFileCacheHints(File f, long start, long len)
            throws IOException {
        if (!f.exists()) {
            return null;
        } else {
            String result[][] = new String[1][];
            result[0] = new String[1];
            result[0][0] = "localhost";
            return result;
        }
    }

    /**
     * A file from a LocalFileSystem contains one block, which has the same
     * length as the file, block ID 0 and location "localhost"
     */
    @Override
    public BlockInfo[] getFileBlocksInfo(Path f) throws IOException {
        File file = f.asFile();
        if (!file.exists()) {
            throw new FileNotFoundException(file.toString());
        }
        if (!file.isFile()) {
            throw new FileNotFoundException(file.toString() + " is not a file");
        }
        return new BlockInfo[] {
            new BlockInfo(0, getLength(f), new String[] {
                "localhost"
            }, 0)
        };
    }

    @Override
    public String getName() {
        return LOCAL;
    }

    /*******************************************************
     * For open()'s FSInputStream
     *******************************************************/
    class LocalFSFileInputStream extends FSInputStream {
        FileInputStream fis;

        public LocalFSFileInputStream(File f) throws IOException {
            this.fis = new FileInputStream(f);
        }

        @Override
        public void seek(long pos) throws IOException {
            fis.getChannel().position(pos);
        }

        @Override
        public long getPos() throws IOException {
            return fis.getChannel().position();
        }

        /*
         * Just forward to the fis
         */
        @Override
        public int available() throws IOException {
            return fis.available();
        }

        @Override
        public void close() throws IOException {
            fis.close();
        }

        @Override
        public boolean markSupported() {
            return false;
        }

        @Override
        public int read() throws IOException {
            int ret = fis.read();
            if (ret >= 0) {
                readCounter.addAndGet(1);
            }
            return ret;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int ret = fis.read(b, off, len);
            if (ret > 0) {
                readCounter.addAndGet(ret);
            }
            return ret;
        }

        @Override
        public long skip(long n) throws IOException {
            return fis.skip(n);
        }

        @Override
        public long getLength() throws IOException {
            return fis.getChannel().size();
        }
    }

    @Override
    public FSInputStream openRaw(Path f) throws IOException {
        if (!f.asFile().exists()) {
            throw new FileNotFoundException(f.toString());
        } // if
        return new LocalFSFileInputStream(f.asFile());
    }

    /*********************************************************
     * For create()'s FSOutputStream.
     *********************************************************/
    class LocalFSFileOutputStream extends FSOutputStream {
        FileOutputStream fos;

        public LocalFSFileOutputStream(File f) throws IOException {
            this.fos = new FileOutputStream(f);
        }

        @Override
        public long getPos() throws IOException {
            return fos.getChannel().position();
        }

        /*
         * Just forward to the fos
         */
        @Override
        public void close() throws IOException {
            fos.close();
        }

        @Override
        public void flush() throws IOException {
            fos.flush();
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            writeCounter.addAndGet(len);
            fos.write(b, off, len);
        }

        @Override
        public void write(int b) throws IOException {
            writeCounter.addAndGet(1);
            fos.write(b);
        }
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite)
            throws IOException {
        return createRaw(f, overwrite, true);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent) throws IOException {
        if (f.asFile().exists() && !overwrite) {
            throw new IOException("File already exists:" + f);
        }
        Path parent = f.getParentFile();
        if (parent != null) {
            if (!parent.asFile().exists()) {
                if (!createParent) {
                    throw new IOException("File parent not exists:" + parent);
                } else if (!parent.asFile().mkdirs()) {
                    throw new IOException("Create parent failed: " + parent);
                }
            }
        }
        return new LocalFSFileOutputStream(f.asFile());
    }

    @Override
    public boolean rename(Path src, Path dst) throws IOException {
        return rename(src, dst, true);
    }

    @Override
    public boolean rename(Path src, Path dst, boolean overwrite)
            throws IOException {
        if (!src.asFile().exists()) {
            return false;
        }
        if (isDirectory(dst)) {
            String name = src.getName();
            String dstStr = dst.getAbsolutePath() + "/" + name;
            dst = new Path(dstStr);
        }
        if (dst.asFile().exists() && !overwrite) {
            return false;
        }
        if (useCopyForRename) {
            if (!src.asFile().renameTo(dst.asFile())) {
                FileSystem.copyContents(this, src, dst, true);
                return fullyDelete(src.asFile());
            } else {
                return true;
            }
        } else {
            return src.asFile().renameTo(dst.asFile());
        }
    }

    @Override
    public boolean link(Path src, Path dst) throws IOException {
        if (dst.asFile().exists())
            return false;

        if (src.asFile().isDirectory()) {
            if (!dst.asFile().mkdirs())
                return false;
            for (String name: src.asFile().list()) {
                if (!link(new Path(src, name), new Path(dst, name))) {
                    return false;
                }
            }
        } else {
            ReadWriteUtils.localHardLink(src, dst);
        }

        return true;
    }

    @Override
    public boolean delete(Path f) throws IOException {
        return delete(f, true);
    }

    @Override
    public boolean delete(Path f, boolean recursive) throws IOException {
        if (f.asFile().isDirectory()) {
            if (recursive) {
                return fullyDelete(f.asFile());
            } else {
                throw new IOException("Cannot delete " + f
                        + " when recursive is false because it is a directory.");
            }
        } else {
            return f.asFile().delete();
        }
    }

    @Override
    public boolean deprive(Path f) throws IOException {
        if (f.asFile().exists() && f.asFile().isDirectory())
            throw new IOException("Can only deprive a file, but not " + f);
        return f.asFile().delete();
    }

    @Override
    public boolean exists(Path f) throws IOException {
        return f.asFile().exists();
    }

    @Override
    public boolean isDirectory(Path f) throws IOException {
        return f.asFile().isDirectory();
    }

    @Override
    public long getLength(Path f) throws IOException {
        return f.asFile().length();
    }

    @Override
    public long getLengthRecursive(Path f) throws IOException {
        if (!f.asFile().exists()) {
            return 0;
        } else if (f.asFile().isDirectory()) {
            long len = 0;
            for (File sf: listFiles(f.asFile())) {
                len += getLengthRecursive(new Path(sf));
            }
            return len;
        } else {
            return f.asFile().length();
        }
    }

    @Override
    public long lastModified(Path f) throws IOException {
        return f.asFile().lastModified();
    }

    @Override
    public File[] listFiles(File f) throws IOException {
        return f.listFiles();
    }

    @Override
    public FileInfo[] listFiles(Path f) throws IOException {
        File[] files = f.asFile().listFiles();
        if (files == null)
            return null;
        FileInfo[] res = new FileInfo[files.length];
        for (int i = 0; i < files.length; i++) {
            res[i] = new FileInfo(new Path(files[i])) {
                @Override
                public long getLastModified() {
                    return path.asFile().lastModified();
                }

                @Override
                public long getLength() {
                    return path.asFile().length();
                }

                @Override
                public Path getTarget() {
                    return path;
                }

                @Override
                public boolean isDir() {
                    return path.asFile().isDirectory();
                }

                @Override
                public boolean isSLink() {
                    return false;
                }
            };
        } // for i

        return res;
    }

    @Override
    public void mkdirs(Path f) throws IOException {
        File dir = f.asFile();
        if (dir.isFile()) {
            throw new IOException("Cannot mkdirs " + f
                    + " because it is already exists and is a file");
        }
        if (!dir.mkdirs()) {
            if (dir.isDirectory()) { // maybe someone else create it.
                return;
            } else {
                throw new IOException("Cannot mkdirs " + f);
            }
        }
    }

    /**
     * Obtain a filesystem lock at File f.
     */
    @Override
    public synchronized void getLock(Path f, int lock) throws IOException {
        String lockname = f.asFile().getCanonicalPath();
        NamedLock<String> namedlock = locks.get(lockname);
        if (namedlock == null) {
            namedlock = new NamedLock<String>(lockname);
            locks.put(lockname, namedlock);
        }

        String holder = "thread-" + Thread.currentThread().hashCode();
        long start = System.currentTimeMillis();
        for (int retry = 0;; retry++) {
            switch (lock) {
                case SHARED_LOCK:
                    if (namedlock.sharedLock(holder)) {
                        return;
                    }
                    break;
                case UPDATE_LOCK:
                    if (namedlock.updateLock(holder)) {
                        return;
                    }
                    break;
                case EXCLUSIVE_LOCK:
                    if (namedlock.exclusiveLock(holder) == 2) {
                        return;
                    }
                    break;
            }
            long elapsedTime = System.currentTimeMillis() - start;
            if (elapsedTime > 2000) {
                LOG.info("Waiting to retry lock(" + NamedLock.LOCK_NAME(lock)
                        + ") on + " + f + " for " + elapsedTime + " ms.");
            }
            long waitTime = DfsUtils.getExpWaitTime(retry);
            try {
                this.wait(waitTime);
            } catch (InterruptedException e) {}
        }
    }

    /**
     * Obtain a filesystem lock at File f.
     */
    @Override
    public synchronized void promoteLock(Path f) throws LockStateException,
            IOException {
        String lockname = f.asFile().getCanonicalPath();
        NamedLock<String> namedlock = locks.get(lockname);
        if (namedlock == null) {
            namedlock = new NamedLock<String>(lockname);
            locks.put(lockname, namedlock);
        }
        long start = System.currentTimeMillis();
        String holder = "thread-" + Thread.currentThread().hashCode();
        for (int retry = 0; namedlock.promote(holder) != COMPLETE_SUCCESS; retry++) {
            long elapsedTime = System.currentTimeMillis() - start;
            if (elapsedTime > 2000) {
                LOG.info("Waiting to retry promote lock on " + f + " for "
                        + elapsedTime + " ms.");
            }
            long waitTime = DfsUtils.getExpWaitTime(retry);
            try {
                this.wait(waitTime);
            } catch (InterruptedException e) {}
        }
    }

    @Override
    public synchronized String getLockState(Path f) throws IOException {
        String lockName = f.asFile().getCanonicalPath();
        NamedLock<String> namedlock = locks.get(lockName);
        if (namedlock == null) {
            return NamedLock.LOCK_NAME(NamedLock.FREE);
        } else {
            return namedlock.toString();
        }
    }

    /**
     * Release a held lock
     */
    @Override
    public synchronized void releaseLock(Path f) throws IOException {
        String lockname = f.asFile().getCanonicalPath();
        NamedLock<String> namedlock = locks.get(lockname);
        if (namedlock == null) {
            return;
        }
        String holder = "thread-" + Thread.currentThread().hashCode();
        namedlock.unlock(holder);
    }

    // In the case of the local filesystem, we can just rename the file.
    @Override
    public void moveFromLocalFile(File src, Path dst) throws IOException {
        if (exists(dst)) {
            if (!isDirectory(dst)) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new Path(dst, src.getName());
                if (exists(dst)) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }
        if (!src.equals(dst.asFile())) {
            if (useCopyForRename) {
                FileSystem.copyContents(this, new Path(src), dst, true);
                fullyDelete(src);
            } else {
                if (!src.renameTo(dst.asFile())) {
                    throw new IOException("Rename from " + src + " to " + dst
                            + " failed");
                }
            }
        }
    }

    // Similar to moveFromLocalFile(), except the source is kept intact.
    @Override
    public void copyFromLocalFile(File src, Path dst) throws IOException {
        if (exists(dst)) {
            if (!isDirectory(dst)) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new Path(dst, src.getName());
                if (exists(dst)) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }
        if (!src.equals(dst.asFile())) {
            FileSystem.copyContents(this, new Path(src), dst, true);
        }
    }

    // We can't delete the src file in this case.  Too bad.
    @Override
    public void copyToLocalFile(Path src, File dst) throws IOException {
        if (dst.exists()) {
            if (!dst.isDirectory()) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new File(dst, src.getName());
                if (dst.exists()) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }
        if (!src.asFile().equals(dst)) {
            FileSystem.copyContents(this, src, new Path(dst), true);
        }
    }

    // We can write output directly to the final location
    @Override
    public File startLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        return fsOutputFile.asFile();
    }

    // It's in the right place - nothing to do.
    @Override
    public void completeLocalOutput(Path fsWorkingFile, File tmpLocalFile)
            throws IOException {}

    // We can read directly from the real local fs.
    @Override
    public File startLocalInput(Path fsInputFile, File tmpLocalFile)
            throws IOException {
        return fsInputFile.asFile();
    }

    // We're done reading.  Nothing to clean up.
    @Override
    public void completeLocalInput(File localFile) throws IOException {
        // Ignore the file, it's at the right destination!
    }

    @Override
    protected void closeInternal() {}

    @Override
    public String toString() {
        return "LocalFS";
    }

    /**
     * Implement our own version instead of using the one in FileUtil, to avoid
     * infinite recursion.
     * 
     * @param dir
     * @return
     * @throws IOException
     */
    private boolean fullyDelete(File dir) throws IOException {
        File contents[] = dir.listFiles();
        if (contents != null) {
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].isFile()) {
                    if (!contents[i].delete()) {
                        return false;
                    }
                } else {
                    if (!fullyDelete(contents[i])) {
                        return false;
                    }
                }
            }
        }
        return dir.delete();
    }

    @Override
    public long getBlockSize() {
        // default to 32MB: large enough to minimize the impact of seeks
        // TODO: constantize
        return 32 * 1024 * 1024;
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags) throws IOException {
        return createRaw(f, overwrite, createParent);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int blockSize) throws IOException {
        return createRaw(f, overwrite, createParent);
    }

    @Override
    public FSInputStream openRaw(Path f, int flags) throws IOException {
        return openRaw(f);
    }

    @Override
    public FSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission) throws IOException {
        return createRaw(f, overwrite, createParent);
    }

    @Override
    public void mkdirs(Path f, int replication, FsPermission permission)
            throws IOException {
        mkdirs(f);
    }

}
