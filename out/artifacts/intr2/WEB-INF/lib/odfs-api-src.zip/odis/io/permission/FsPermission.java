/**
 * @(#)FsPermission.java, 2012-2-1. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io.permission;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class FsPermission implements IWritable {
    //POSIX permission style
    private FsAction useraction = null;

    private FsAction groupaction = null;

    private FsAction otheraction = null;

    private boolean stickyBit = false;

    public static FsPermission createImmutable(int permission) {
        return new FsPermission(permission) {
            @Override
            public FsPermission applyUMask(FsPermission umask) {
                throw new UnsupportedOperationException();
            }

            @Override
            public void readFields(DataInput in) throws IOException {
                throw new UnsupportedOperationException();
            }
        };
    }

    public FsPermission() {}

    /**
     * Construct by the given {@link FsAction}.
     * 
     * @param u
     *            user action
     * @param g
     *            group action
     * @param o
     *            other action
     */
    public FsPermission(FsAction u, FsAction g, FsAction o) {
        this(u, g, o, false);
    }

    public FsPermission(FsAction u, FsAction g, FsAction o, boolean sb) {
        set(u, g, o, sb);
    }

    /**
     * Construct by the given mode.
     * 
     * @param mode
     * @see #toShort()
     */
    public FsPermission(int mode) {
        fromShort(mode);
    }

    /**
     * Copy constructor
     * 
     * @param other
     *            other permission
     */
    public FsPermission(FsPermission other) {
        this.useraction = other.useraction;
        this.groupaction = other.groupaction;
        this.otheraction = other.otheraction;
    }

    /** Return user {@link FsAction}. */
    public FsAction getUserAction() {
        return useraction;
    }

    /** Return group {@link FsAction}. */
    public FsAction getGroupAction() {
        return groupaction;
    }

    /** Return other {@link FsAction}. */
    public FsAction getOtherAction() {
        return otheraction;
    }

    public boolean getStickyBit() {
        return stickyBit;
    }

    private void set(FsAction u, FsAction g, FsAction o, boolean sb) {
        useraction = u;
        groupaction = g;
        otheraction = o;
        stickyBit = sb;
    }

    public void fromShort(int n) {
        FsAction[] v = FsAction.values();

        set(v[(n >>> 6) & 7], v[(n >>> 3) & 7], v[n & 7],
                (((n >>> 9) & 1) == 1));
    }

    /**
     * Encode the object to a short.
     */
    public int toShort() {
        int s = (stickyBit ? 1 << 9 : 0) | (useraction.ordinal() << 6)
                | (groupaction.ordinal() << 3) | otheraction.ordinal();

        return s;
    }

    /** Apply a umask to this permission and return a new one */
    public FsPermission applyUMask(FsPermission umask) {
        return new FsPermission(useraction.and(umask.useraction.not()),
                groupaction.and(umask.groupaction.not()),
                otheraction.and(umask.otheraction.not()));
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof FsPermission) {
            FsPermission that = (FsPermission) obj;
            return this.useraction == that.useraction
                    && this.groupaction == that.groupaction
                    && this.otheraction == that.otheraction
                    && this.stickyBit == that.stickyBit;
        }
        return false;
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return toShort();
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        String str = useraction.SYMBOL + groupaction.SYMBOL
                + otheraction.SYMBOL;
        if (stickyBit) {
            StringBuilder str2 = new StringBuilder(str);
            str2.replace(str2.length() - 1, str2.length(),
                    otheraction.implies(FsAction.EXECUTE) ? "t" : "T");
            str = str2.toString();
        }

        return str;
    }

    /** Get the default permission. */
    public static FsPermission getDefault() {
        return new FsPermission(00777);
    }

    /**
     * Create a FsPermission from a Unix symbolic permission string
     * 
     * @param unixSymbolicPermission
     *            e.g. "-rw-rw-rw-"
     */
    public static FsPermission valueOf(String unixSymbolicPermission) {
        if (unixSymbolicPermission == null) {
            return null;
        } else if (unixSymbolicPermission.length() != 10) {
            throw new IllegalArgumentException(
                    "length != 10(unixSymbolicPermission="
                            + unixSymbolicPermission + ")");
        }

        int n = 0;
        for (int i = 1; i < unixSymbolicPermission.length(); i++) {
            n = n << 1;
            char c = unixSymbolicPermission.charAt(i);
            n += (c == '-' || c == 'T' || c == 'S') ? 0 : 1;
        }

        // Add sticky bit value if set
        if (unixSymbolicPermission.charAt(9) == 't'
                || unixSymbolicPermission.charAt(9) == 'T')
            n += 01000;

        return new FsPermission((short) n);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        FsPermission other = (FsPermission) value;

        this.useraction = other.useraction;
        this.groupaction = other.groupaction;
        this.otheraction = other.otheraction;

        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeShort(toShort());
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        fromShort(in.readUnsignedShort());
    }
}
