/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 11, 2006
 */
package odis.io;

import java.io.IOException;
import java.io.InputStream;

/**
 * FSInputStream is a generic old InputStream with a little bit of
 * random-access-file-style seek ability.
 */
public abstract class FSInputStream extends InputStream implements Seekable {
    /**
     * Seek to the given offset from the start of the file. The next read() will
     * be from that location. Can't seek past the end of the file.
     */
    public abstract void seek(long pos) throws IOException;

    /**
     * Return the current offset from the start of the file
     */
    public abstract long getPos() throws IOException;

    /**
     * Return the file length.
     * 
     * @return
     * @throws IOException
     */
    public abstract long getLength() throws IOException;

    /**
     * The read length hint tells the stream the probable size of data being
     * read after each seek. The stream can use this information in network
     * transmission optimization. The default implementation does nothing.
     * 
     * @param lengthHint
     */
    public void setReadLengthHint(int lengthHint) {
        // DO NOTHING
    }

    /**
     * Mark this stream as temporarily idle, so that the implementor can do
     * things like releasing underlying server connections. The stream should be
     * still readable after invocation of this method. The default
     * implementation does nothing.
     */
    public void setIdleHint() {
        // DO NOTHING
    }

    /**
     * Set read timeout. This is useful for some application(such as OMap) for
     * which latency is very very important. The implementor should do their
     * best to make this call return in timeout.
     * 
     * @param timeout
     *            in milliseconds
     */
    public void setTimeout(long timeout) {
        // DO NOTHING
    }

    /**
     * Set the timeout policy.
     * <p>
     * <code>RESPONSE_IN_TIME</code> means if we can not get a response within
     * the given timeout, we should generate a timeout exception.<br>
     * <code>COMPLETE_IN_TIME</code> means if we can not finish a request within
     * the given timeout, we should generate a timeout exception.
     * 
     * @param timeoutPolicy
     */
    public void setTimeoutPolicy(TimeoutPolicy timeoutPolicy) {
        // DO NOTHING
    }

    /**
     * If set to true, we will try to read data from the datanode which is
     * started at the same machine first instead of random select one.
     */
    public void setReadFromLocalHost(boolean readFromLocalHost) {
        // DO NOTHING
    }
}
