/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

/**
 * Exception thrown when one holder try to acquire the same lock while it holds
 * the lock already.
 * 
 * @author river
 */
public class LockReentrantException extends RuntimeException {
    private static final long serialVersionUID = 8228578997076383674L;

    /**
     * Constructs a new runtime exception with <code>null</code> as its default
     * message
     */
    public LockReentrantException() {}

    /**
     * Constructs a new runtime exception with <code>null</code> as its
     * specified message
     * 
     * @param message
     *            the detail message
     */
    public LockReentrantException(String message) {
        super(message);
    }
}
