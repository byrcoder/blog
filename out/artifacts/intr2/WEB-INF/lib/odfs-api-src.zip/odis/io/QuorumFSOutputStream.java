/**
 * @(#)QuorumFSOutputStream.java, 2013-1-10. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

import java.io.IOException;
import java.io.OutputStream;

import odis.dfs.common.FSConstants;

/**
 * An FSOutputStream that write to several datanodes at the same time.
 * <p>
 * This class is design for writing write-ahead log on odfs. We do a flush
 * immediately after a write operation to confirm data is written to some
 * datanodes. You can control the flush operation by setting
 * {@link #flushOption} and {@link #flushMinSuccess}.
 * <p>
 * The target file will have only one block, so if a write operation make the
 * file size larger than blockSize, an CompleteException will be thrown. You
 * should call close if you catch a CompleteException. Notice that a
 * CompleteException means we have not written your data, any exception other
 * than CompleteException means the write is failed.
 * 
 * @author zhangduo
 */
public abstract class QuorumFSOutputStream extends OutputStream {

    public static final class CompleteException extends IOException {

        private static final long serialVersionUID = -1694007830261461962L;

        public CompleteException(String message) {
            super(message);
        }

        @Override
        public synchronized Throwable fillInStackTrace() {
            return this;
        }

    }

    protected final int blockSize;

    protected final int replication;

    protected int flushOption;

    protected int flushMinSuccess;

    protected QuorumFSOutputStream(int blockSize, int replication) {
        this.blockSize = blockSize;
        this.replication = replication;
    }

    public int getBlockSize() {
        return blockSize;
    }

    public int getReplication() {
        return replication;
    }

    public int getFlushOption() {
        return flushOption;
    }

    /**
     * Set flush option. <tt>flushOption</tt> could be:
     * <ul>
     * <li>{@link FSConstants#CHUNK_SIZE_FLUSH_WITH_RESPONSE}</li>
     * <li>{@link FSConstants#CHUNK_SIZE_SYNC_WITH_RESPONSE}</li>
     * <li>{@link FSConstants#CHUNK_SIZE_SYNC_ASYNC_WITH_RESPONSE}</li>
     * <li>{@link FSConstants#CHUNK_SIZE_SYNC_WITHOUT_RESPONSE}</li>
     * </ul>
     * <p>
     * {@link FSConstants#CHUNK_SIZE_FLUSH_WITHOUT_RESPONSE} is not used because
     * we use SocketChannel to write data, data will be flushed to system buffer
     * immediately after the write method called.
     * 
     * @param flushOption
     */
    public void setFlushOption(int flushOption) {
        this.flushOption = flushOption;
    }

    public int getFlushMinSuccess() {
        return flushMinSuccess;
    }

    /**
     * Set minimum success count for flush operation.
     * 
     * @param flushMinSuccess
     */
    public void setFlushMinSuccess(int flushMinSuccess) {
        if (flushMinSuccess <= 0) {
            this.flushMinSuccess = 1;
        } else {
            this.flushMinSuccess = Math.min(flushMinSuccess, replication);
        }
    }

    /**
     * Return the current offset from the start of the file
     * 
     * @return the current offset of file
     */
    public abstract long getPos();

    /**
     * Always throw <tt>UnsupportedOperationException}</tt>.
     * <p>
     * We do a flush immediately after write method called. The flush operation
     * is expensive, so the write single byte method is disabled. You should
     * write <strong>SOME</strong> bytes once at least.
     */
    @Override
    public void write(int b) throws UnsupportedOperationException {
        throw new UnsupportedOperationException(
                "Do not write a single byte with a flush");
    }

    /**
     * We do a flush immediately after write method called, so call to flush
     * directly will do nothing.
     */
    @Override
    public void flush() {}

}
