package odis.io.ramfs;

import java.io.IOException;

import odis.io.DataInputBuffer;
import odis.io.FSInputStream;

/**
 * @author why
 * @since 2007-2-6
 */
public class RAMFSInputStream extends FSInputStream {
    private DataInputBuffer input;

    public RAMFSInputStream(byte[] data, long contentsLen) {
        input = new DataInputBuffer(data, 0, (int) contentsLen);
    }

    @Override
    public long getPos() throws IOException {
        return input.getPosition();
    }

    @Override
    public void seek(long pos) throws IOException {
        int curpos = input.getPosition();
        int offset = (int) pos - curpos;
        input.skip(offset);
    }

    @Override
    public void close() throws IOException {
        input.reset();
    }

    @Override
    public int read() throws IOException {
        return input.readByte();
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException();
        } // if
        if (len == 0) {
            return 0;
        } // if

        int left = input.getSize();
        if (left == 0) {
            return -1;
        } // if

        int bytesRead = len <= left ? len : left;
        input.readFully(b, off, bytesRead);

        return bytesRead;
    }

    @Override
    public long getLength() {
        return input.getLimit();
    }
}
