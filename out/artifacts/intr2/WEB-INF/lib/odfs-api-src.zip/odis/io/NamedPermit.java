/**
 * @(#)NamedPermit.java, 2008-7-31. Copyright 2008 Yodao, Inc. All rights
 *                                  reserved. YODAO PROPRIETARY/CONFIDENTIAL.
 *                                  Use is subject to license terms.
 */
package odis.io;

import java.util.HashMap;
import java.util.Map;

/**
 * {@link NamedPermit} acts like semaphone, it is used in {@link FileSystem}.
 * Refer to {@link IFileSystem#createPermit(String, int)},
 * {@link IFileSystem#acquirePermit(String, int)}, etc., to find out how to use
 * it.
 * 
 * @author river
 */
public class NamedPermit {

    private String name;

    private int totalPermit;

    private int availablePermit;

    private Map<String, Integer> holders;

    /**
     * Create one named permit with intial capacity. The capacity should not be
     * changed later.
     * 
     * @param name
     * @param permit
     */
    public NamedPermit(String name, int permit) {
        this.name = name;
        this.totalPermit = permit;
        this.availablePermit = totalPermit;
        holders = new HashMap<String, Integer>();
    }

    /**
     * Return the name of permit.
     * 
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Try to acquire some permits. If the requested permit number is negative,
     * return false; if the requested permit number is zero, return true;
     * otherwise, return if there's enough permits remained.
     * 
     * @param holder
     * @param request
     * @return
     */
    public synchronized boolean acquire(String holder, int request) {
        if (request < 0)
            return false;
        if (request == 0)
            return true;

        if (availablePermit >= request) {
            Integer p = holders.get(holder);
            if (p != null) {
                holders.put(holder, p + request);
            } else {
                holders.put(holder, request);
            }
            availablePermit -= request;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Release some permits of the holder.
     * 
     * @param holder
     * @param permit
     */
    public synchronized void release(String holder, int permit) {
        if (permit <= 0)
            return;

        Integer p = holders.get(holder);
        if (p != null) {
            if (p > permit) {
                holders.put(holder, p - permit);
                availablePermit += permit;
            } else {
                holders.remove(holder);
                availablePermit += p;
            }
        }
    }

    /**
     * Release all the permits of one holder.
     * 
     * @param holder
     */
    public synchronized void release(String holder) {
        Integer p = holders.remove(holder);
        if (p != null) {
            availablePermit += p;
        }
    }

}
