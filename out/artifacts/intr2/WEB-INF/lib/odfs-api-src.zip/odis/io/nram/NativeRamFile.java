/**
 * @(#)NativeRamFile.java, 2007-10-16. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io.nram;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;

import odis.io.BufferOverflowException;
import odis.io.ReadWriteUtils;
import odis.util.unsafe.UnsafeHelper;
import sun.nio.ch.DirectBuffer;

/**
 * NativeRamFile is the interface to create, read and write buffer in memory by
 * jni. We use jni to manage the buffer in order to avoid slowing jvm full gc.
 * It also supports mirror one local file into the buffer by one call to
 * {@link #mirrorLocalFile(String)}.
 * <p>
 * Below code gives the sample to mirror one local file and read the first 3
 * bytes. <blockquote>
 * 
 * <pre>
 * NativeRamFile nf = new NativeRamFile();
 * try {
 *     nf.mirrorLocalFile(&quot;./test.txt&quot;);
 *     byte[] buf = new byte[3];
 *     nf.seek(0);
 *     nf.read(buf, 0, buf.length);
 * } finally {
 *     nf.close();
 * }
 * </pre>
 * 
 * </blockquote>
 * </p>
 * <strong> You must close the instance by put "close()" in finally block after
 * instance created, or it leads to severe memory leak.</strong>
 * 
 * @see odis.io.nram.NativeRamFileSystem
 * @author river
 */
public class NativeRamFile {

    private long fd;

    private long capacity;

    private long pos;

    /**
     * Return current length of ram file.
     * 
     * @return
     */
    public long length() {
        return capacity;
    }

    /**
     * Return the current read/write position.
     * 
     * @return
     */
    public long getPosition() {
        return pos;
    }

    /**
     * Seek to the given pos from begining in ram buffer. You can seek to the
     * position larger than current size, and the buffer should be expanded when
     * {@link #write(byte[], int, int)} called.
     * 
     * @param pos
     * @return
     */
    public long seek(long pos) throws IOException {
        if (pos < 0) {
            throw new IllegalArgumentException();
        }
        this.pos = pos;
        return pos;
    }

    private void bufferCheck(byte[] buffer, int offset, int length) {
        if (offset < 0 || length < 0 || offset + length < 0
                || buffer.length < offset + length) {
            throw new IllegalArgumentException("bad buffer : buffer_size = "
                    + buffer.length + ",offset=" + offset + ",length=" + length);
        }
    }

    /**
     * Read in data.
     * 
     * @param buffer
     * @param offset
     * @param length
     * @return
     */
    public int read(byte[] buffer, int offset, int length) throws IOException {
        int copied = get(pos, buffer, offset, length);
        pos += copied;
        return copied;
    }

    /**
     * Read data into buffer from position, the rw-pointer is not changed.
     * 
     * @param position
     * @param buffer
     * @param offset
     * @param length
     * @return
     */
    public int get(long position, byte[] buffer, int offset, int length)
            throws IOException {
        bufferCheck(buffer, offset, length);
        if (position < 0) {
            throw new IllegalArgumentException();
        }
        if (position >= capacity) {
            return -1;
        }
        int toCopy = (int) Math.min(length, capacity - position);
        UnsafeHelper.copyToArray(fd + position, buffer, offset, toCopy);
        return toCopy;
    }

    private void ensureCapacity(long size) {
        if (capacity < size) {
            fd = UnsafeHelper.unsafe.reallocateMemory(fd, size);
            capacity = size;
        }
    }

    /**
     * Write data to ram file. The buffer should be enlarged when buffer is not
     * enough.
     * 
     * @param buffer
     * @param offset
     * @param length
     */
    public void write(byte[] buffer, int offset, int length) throws IOException {
        bufferCheck(buffer, offset, length);
        ensureCapacity(pos + length);
        UnsafeHelper.copyFromArray(fd + pos, buffer, offset, length);
        pos += length;
    }

    /**
     * Write data into buffer from position, the rw-pointer is not changed. This
     * method differs from {@link #write(byte[], int, int)} that size of ramfile
     * is not changed in this method. If the buffer is not enough to hold the
     * data, exception should be raised.
     * 
     * @param position
     * @param buffer
     * @param offset
     * @param length
     * @throws IOException
     */
    public void put(long position, byte[] buffer, int offset, int length)
            throws IOException {
        bufferCheck(buffer, offset, length);
        if (position < 0) {
            throw new IllegalArgumentException();
        }
        if (position + length > capacity) {
            throw new BufferOverflowException();
        }
        UnsafeHelper.copyFromArray(fd + position, buffer, offset, length);
    }

    /**
     * Set the length of file in ram.
     * 
     * @param length
     */
    public void setLength(long length) throws IOException {
        if (length < 0) {
            throw new IllegalArgumentException();
        }
        fd = UnsafeHelper.unsafe.reallocateMemory(fd, length);
        capacity = length;
        if (pos > length) {
            pos = length;
        }
    }

    /**
     * Mirror file in disk into ram, the length of buf will be the exact size of
     * local file.
     * 
     * @param filename
     */
    public void mirrorLocalFile(String filename) throws IOException {
        FileInputStream fis = new FileInputStream(filename);
        try {
            FileChannel fc = fis.getChannel();
            long fileSize = fc.size();
            ensureCapacity(fileSize);
            for (long position = 0; position < fileSize;) {
                int toMap = (int) Math.min(1024 * 1024 * 1024, fileSize
                        - position);
                MappedByteBuffer mapped = fc.map(MapMode.READ_ONLY, position,
                        toMap);
                DirectBuffer db = (DirectBuffer) mapped;
                UnsafeHelper.unsafe.copyMemory(db.address(), fd + position,
                        toMap);
                db.cleaner().clean();
                position += toMap;
            }

        } finally {
            ReadWriteUtils.safeClose(fis);
        }
    }

    /**
     * Close the ram file, release the buffer.
     */
    public void close() {
        if (fd != 0) {
            UnsafeHelper.unsafe.freeMemory(fd);
        }
        fd = 0;
        capacity = 0;
    }

    @Override
    protected void finalize() throws Throwable {
        close();
    }

}
