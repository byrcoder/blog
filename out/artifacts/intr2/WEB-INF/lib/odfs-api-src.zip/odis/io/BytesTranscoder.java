/**
 * @(#)BytesTranscoder.java, 2012-12-25. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.io;

/**
 * @author zhangduo
 */
public interface BytesTranscoder<T> {
    byte[] encode(T obj);

    T decode(byte[] data);
}
