package odis.io;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Executor;

import odis.dfs.common.BlockInfo;
import odis.io.permission.FsPermission;

/**
 * The interface for a file-system. The path in the FS is represented as a Path
 * object, while the path in local file-system as a File object.
 * 
 * @author David
 */
public interface IFileSystem {
    // lock types
    /**
     * Shared lock type. Many clients can hold shared locks over the same object
     * at the same type, but cannot mix with exclusive locks.
     */
    public static final int SHARED_LOCK = 1;

    /**
     * Update lock type that can be promoted to exclusive with
     * {@link #promoteLock(File)}. Update locks can be held with as many shared
     * locks as needed at the same time. However there can be at most one update
     * lock on an object at the same moment and it cannot mix with exclusive
     * locks.
     */
    public static final int UPDATE_LOCK = 2;

    /**
     * Exclusive lock type that cannot be held with any other locks over the
     * same object.
     */
    public static final int EXCLUSIVE_LOCK = 3;

    /**
     * The counter counting the total bytes that has been written to this file
     * system since initialized.
     */
    public static final int COUNTER_WRITE_BYTES = 1;

    /**
     * The counter counting the total bytes that has been read from this file
     * system since initialized.
     */
    public static final int COUNTER_READ_BYTES = 2;

    /**
     * Returns a name for this filesystem, suitable to pass to
     * {@link FileSystem#getNamed(String)}.
     * 
     * @return the name for this file-system
     */
    String getName();

    /**
     * Returns the Computing Unit ID that reflects the Computing Unit this file
     * system belongs to.
     * 
     * @return the Computing Unit ID
     */
    String getCUID();

    /**
     * Returns the value of a internal counter. The coutners are per IFileSystem
     * instance.
     * 
     * @param counter
     *            the current value of the requested counter; -1 if the counter
     *            is not defined.
     * @return
     */
    long getCounterValue(int counter);

    /**
     * Returns the locations of blocks of the file
     * 
     * @param f
     *            the file
     * @return
     * @throws IOException
     */
    BlockInfo[] getFileBlocksInfo(Path f) throws IOException;

    /**
     * Opens an FSDataInputStream at the indicated File with default bufferSize.
     * 
     * @param f
     *            the file to open
     * @return the FSDataInputStream instance for the opened file
     * @throws IOException
     *             if an I/O error occurs. An
     *             {@link java.io.FileNotFoundException} will be thrown if the
     *             speicified file does not exist.
     */
    FSDataInputStream open(Path f) throws IOException;

    /**
     * Opens an FSDataInputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param bufferSize
     *            the size of the buffer to be used.
     * @return the FSDataInputStream instance for the opened file.
     * @throws IOException
     *             if an I/O error occurs. An
     *             {@link java.io.FileNotFoundException} will be thrown if the
     *             speicified file does not exist.
     */
    FSDataInputStream open(Path f, int bufferSize) throws IOException;

    /**
     * Opens an FSInputStream for the indicated File.
     * 
     * @param f
     *            the path to the file to be opened
     * @return the FSInputStream instance for the opened file
     * @throws IOException
     *             if an I/O error occurs. An
     *             {@link java.io.FileNotFoundException} will be thrown if the
     *             speicified file does not exist.
     */
    FSInputStream openRaw(Path f) throws IOException;

    /**
     * Opens an FSInputStream for the indicated File.
     * 
     * @param f
     *            the path to the file to be opened
     * @param flags
     *            optional flags defined by the implementation
     * @return
     * @throws IOException
     */
    FSInputStream openRaw(Path f, int flags) throws IOException;

    /**
     * Opens an FSDataOutputStream at the indicated File. The file is
     * overwritten by default.
     * 
     * @param f
     *            the path to the file to be created
     * @return the FSDataOutputStream for the opened file for writing in
     * @throws IOException
     *             if an I/O error occurs
     */
    FSDataOutputStream create(Path f) throws IOException;

    /**
     * Opens an FSDataOutputStream at the indicated File. bufferSize are used
     * default.
     * 
     * @param f
     *            the path to the file to be opened
     * @param overwrite
     *            if the file with this name already exists, then if true, the
     *            file will be overwritten, and if false, an exception is thrown
     * @return the FSDataOutputStream for the opened file for writing in
     * @throws IOException
     *             if an I/O error occurs
     */
    FSDataOutputStream create(Path f, boolean overwrite) throws IOException;

    /**
     * Opens an FSDataOutputStream at the indicated File. bufferSize are used
     * with default value.
     * 
     * @param f
     *            the file to be created
     * @param overwrite
     *            if the file with this name already exists, then if true, the
     *            file will be overwritten, and if false, an exception is thrown
     * @param createParent
     *            whether to create non-exist parent directories.
     * @return the opened FSDataOutputStream instance for the created file
     * @throws IOException
     *             if an I/O error occurs
     */
    FSDataOutputStream create(Path f, boolean overwrite, boolean createParent)
            throws IOException;

    /**
     * Opens an FSDataOutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if the file with this name already exists, then if true, the
     *            file will be overwritten, and if false, an exception is thrown
     * @param bufferSize
     *            the size of the buffer to be used
     */
    FSDataOutputStream create(Path f, boolean overwrite, int bufferSize)
            throws IOException;

    /**
     * Opens an FSDataOutputStream at the indicated File. using the default
     * block size.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     * @param createParent
     *            whether to create non-exist parent directories.
     * @param bufferSize
     *            the size of the buffer to be used.
     */
    FSDataOutputStream create(Path f, boolean overwrite, int bufferSize,
            boolean createParent) throws IOException;

    /**
     * Opens an FSDataOutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     * @param createParent
     *            whether to create non-exist parent directories.
     * @param bufferSize
     *            the size of the buffer to be used.
     * @param blockSize
     *            the size of each block for the file
     */
    FSDataOutputStream create(Path f, boolean overwrite, int bufferSize,
            boolean createParent, int blockSize) throws IOException;

    /**
     * Opens an OutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     */
    FSOutputStream createRaw(Path f, boolean overwrite) throws IOException;

    /**
     * Opens an OutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     * @param createParent
     *            whether to create non-exist parent directories.
     */
    FSOutputStream createRaw(Path f, boolean overwrite, boolean createParent)
            throws IOException;

    /**
     * Opens an OutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     * @param createParent
     *            whether to create non-exist parent directories.
     * @param flags
     *            optional flags defined by the implementation
     */
    FSOutputStream createRaw(Path f, boolean overwrite, boolean createParent,
            int flags) throws IOException;

    /**
     * Opens an OutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     * @param createParent
     *            whether to create non-exist parent directories.
     * @param flags
     *            optional flags defined by the implementation
     * @param blockSize
     *            the size of each block for the file
     */
    FSOutputStream createRaw(Path f, boolean overwrite, boolean createParent,
            int flags, int blockSize) throws IOException;

    /**
     * Opens an OutputStream at the indicated File.
     * 
     * @param f
     *            the file name to open
     * @param overwrite
     *            if a file with this name already exists, then if true, the
     *            file will be overwritten, and if false an error will be
     *            thrown.
     * @param createParent
     *            whether to create non-exist parent directories.
     * @param flags
     *            optional flags defined by the implementation * @param
     *            replication the replication of each block for the file
     * @param blockSize
     *            the size of each block for the file
     * @param permission
     *            the permission for the file
     * @return
     * @throws IOException
     */
    FSOutputStream createRaw(Path f, boolean overwrite, boolean createParent,
            int flags, int replication, int blockSize, FsPermission permission)
            throws IOException;

    /**
     * Opens an {@link QuorumFSOutputStream} at the indicated File.
     * 
     * @param f
     * @param overwrite
     * @param createParent
     * @param flags
     * @param replication
     * @param blockSize
     * @param permission
     * @param workerExecutor
     * @return
     * @throws IOException
     */
    QuorumFSOutputStream createQuorum(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission, Executor workerExecutor) throws IOException;

    /**
     * Make a hard-linked of src. Semantically it is just a copy operation (any
     * changes to src in the future will not affect the content of dst.). The
     * underlying implementation will try to share the space for the two copies.
     * 
     * @param src
     *            the file/directory that already exists
     * @param dst
     *            dst will become a linked-copy to src. it should not exists
     *            before the call to link()
     * @return whether this link is successfully created
     * @throws IOException
     *             if an I/O error occurs
     */
    boolean link(Path src, Path dst) throws IOException;

    /**
     * Renames src (file or directory) to dst. Can take place on local fs or
     * remote DFS. The source and destination could be in different directories.
     * But the caller should ensure that the parent directory of the destination
     * exists before doing the rename.
     * <p>
     * If the dst exists before moving and is a folder, the <src> is moved as a
     * sub-folder of dst. If dst is a file, it will be overwritten.
     * </p>
     * 
     * @param src
     *            the source file
     * @param dst
     *            the destination file
     * @return whether the rename operation is success
     * @throws IOException
     *             if an I/O error occurs
     */
    boolean rename(Path src, Path dst) throws IOException;

    /**
     * @param src
     *            the source file
     * @param dst
     *            the destination file
     * @param overwrite
     *            whether we can overwrite destination file if it exists
     * @return whether the rename operation is success
     * @throws IOException
     */
    boolean rename(Path src, Path dst, boolean overwrite) throws IOException;

    /**
     * Deletes a file or directory. Deletion is recursive.
     * <p>
     * If the file/directory does not exits, no exception is thrown and false is
     * returned.
     * </p>
     * 
     * @param f
     *            the file to be deleted
     * @return whether this file is deleted
     * @throws IOException
     *             if an I/O error occurs
     */
    boolean delete(Path f) throws IOException;

    /**
     * Deletes a file or directory.
     * <p>
     * if not recursive and f is a directory, an exception will be thrown.
     * 
     * @param f
     * @param recursive
     * @return
     * @throws IOException
     */
    boolean delete(Path f, boolean recursive) throws IOException;

    /**
     * Deprives file: this might currently being opening and creating by others.
     * This methods deprives the ownership and delete the current file.
     * 
     * @param f
     *            File to be deprived, cannot be a directory.
     * @return <tt>false</tt> means we can not deprive the given path(usually
     *         because the path is a directory)
     */
    boolean deprive(Path f) throws IOException;

    /**
     * Check if a file/directory exists.
     * 
     * @param f
     *            the file to be checked
     * @return true iff the specified file exists
     * @throws IOException
     *             if an I/O error occurs
     */
    boolean exists(Path f) throws IOException;

    /**
     * True iff the named path is a directory.
     * 
     * @param f
     *            the path to be checked
     * @return true iff the path exists and is a directory
     * @throws IOException
     *             if an I/O error occurs
     */
    boolean isDirectory(Path f) throws IOException;

    /**
     * Return the time of the last modified file/folder.
     * <p>
     * <strong>NOTE</strong>: according to the implementation of the file
     * system, the last modified time for a folder could be different.
     * </p>
     * 
     * @param f
     *            the name of the file to be checked
     * @return the last-modified time if this file exists, -1 otherwise
     * @throws IOException
     *             if an I/O error occurs
     */
    long lastModified(Path f) throws IOException;

    /**
     * True iff the named path is a regular file.
     * 
     * @param f
     *            the file to be checked
     * @return true iff the named path exists and is a regular file
     * @throws IOException
     *             if an I/O error occurs
     */
    boolean isFile(Path f) throws IOException;

    /**
     * Get the size of a file.
     * 
     * @return length of file in bytes. returns 0 if the file does not exist.
     *         length of a directory is unspecified.
     */
    long getLength(Path f) throws IOException;

    /**
     * Get the size of a path recursively.
     * 
     * @return if the path is a file, return the size of the file; if the path
     *         is a directory, return the total size of its files and sub
     *         directories recursively.
     */
    long getLengthRecursive(Path f) throws IOException;

    /**
     * Returns an array of abstract pathnames denoting the files in the
     * directory denoted by this abstract pathname. If this abstract pathname
     * does not denote a directory, then this method returns null. Otherwise an
     * array of File objects is returned, one for each file or directory in the
     * directory. Pathnames denoting the directory itself and the directory's
     * parent directory are not included in the result. Each resulting abstract
     * pathname is constructed from this abstract pathname using the File(File,
     * String) constructor. Therefore if this pathname is absolute then each
     * resulting pathname is absolute; if this pathname is relative then each
     * resulting pathname will be relative to the same directory.
     * <p>
     * There is no guarantee that the name strings in the resulting array will
     * appear in any specific order; they are not, in particular, guaranteed to
     * appear in alphabetical order.
     * </p>
     * 
     * @param f
     *            the path of the file
     * @return An array of abstract pathnames denoting the files and directories
     *         in the directory denoted by this abstract pathname. The array
     *         will be empty if the directory is empty. Returns null if this
     *         abstract pathname does not exist or denote a directory.
     * @throws IOException
     *             if an I/O error occurs
     */
    FileInfo[] listFiles(Path f) throws IOException;

    /**
     * The interface of a path-filter.
     * 
     * @author david
     */
    public static interface PathFilter {
        /**
         * Returns whether a given path is acceptable.
         * 
         * @param path
         *            the path to be checked
         * @return true if the path is acceptable, false otherwise.
         */
        public boolean accept(Path path);
    }

    /**
     * Returns an array of abstract pathnames denoting the files and directories
     * in the directory denoted by this abstract pathname that satisfy the
     * specified filter. The behavior of this method is the same as that of the
     * listFiles() method, except that the pathnames in the returned array must
     * satisfy the filter. If the given filter is null then all pathnames are
     * accepted. Otherwise, a pathname satisfies the filter if and only if the
     * value true results when the FilenameFilter.accept(java.io.File,
     * java.lang.String) method of the filter is invoked on this abstract
     * pathname and the name of a file or directory in the directory that it
     * denotes.
     * 
     * @param f
     *            the path to the folder
     * @param filter
     *            the filter
     * @return the listed files as an array
     * @throws IOException
     *             if an I/O error occurs
     */
    FileInfo[] listFiles(Path f, PathFilter filter) throws IOException;

    /**
     * Returns an array of abstract pathnames denoting the files in the
     * directory denoted by this abstract pathname. If this abstract pathname
     * does not denote a directory, then this method returns null. Otherwise an
     * array of File objects is returned, one for each file or directory in the
     * directory. Pathnames denoting the directory itself and the directory's
     * parent directory are not included in the result. Each resulting abstract
     * pathname is constructed from this abstract pathname using the File(File,
     * String) constructor. Therefore if this pathname is absolute then each
     * resulting pathname is absolute; if this pathname is relative then each
     * resulting pathname will be relative to the same directory.
     * <p>
     * There is no guarantee that the name strings in the resulting array will
     * appear in any specific order; they are not, in particular, guaranteed to
     * appear in alphabetical order.
     * </p>
     * 
     * @param f
     *            the path of the file
     * @return An array of abstract pathnames denoting the files and directories
     *         in the directory denoted by this abstract pathname. The array
     *         will be empty if the directory is empty. Returns null if this
     *         abstract pathname does not exist or denote a directory.
     * @throws IOException
     *             if an I/O error occurs
     */
    Path[] listPaths(Path f) throws IOException;

    /**
     * Make the given file and all non-existent parents into directories. If the
     * folder has existed, this method does nothing.
     * 
     * @param f
     *            the path to the folder to be created
     * @throws IOException
     *             if an I/O error occurs
     */
    void mkdirs(Path f) throws IOException;

    /**
     * Make the given file and all non-existent parents into directories. If the
     * folder has existed, this method does nothing.
     * 
     * @param f
     *            the path to the folder to be created
     * @param replication
     *            the replication for the given folder.
     * @param permission
     *            the permission for the given folder.
     * @throws IOException
     */
    void mkdirs(Path f, int replication, FsPermission permission)
            throws IOException;

    /**
     * Get the desired replication number of the given file or directory
     * 
     * @param f
     * @return
     * @throws IOException
     */
    int getReplication(Path f) throws IOException;

    /**
     * Set the desired replication number of the given file or directory
     * 
     * @param f
     * @param replication
     * @param recursive
     * @throws IOException
     */
    void setReplication(Path f, int replication, boolean recursive)
            throws IOException;

    /**
     * The src file is on the local disk. Add it to FS at the given dst name and
     * the source is kept intact afterwards.
     * <p>
     * If the destination file/directory exists, the behavior of this method is
     * as if the local file was firstly copied to a temprary file, and then
     * moved to <dst>.
     * </p>
     * 
     * @param src
     *            the path source file on the local disk
     * @param dst
     *            the path to the destination file on the FS
     * @throws IOException
     *             if an I/O error occurs
     */
    void copyFromLocalFile(File src, Path dst) throws IOException;

    /**
     * The src file is on the local disk. Add it to FS at the given dst name,
     * removing the source afterwards.
     * <p>
     * If the destination file/directory exists, the behavior of this method is
     * as if the local file was firstly moved to a temprary file, and then moved
     * to <dst>.
     * </p>
     * 
     * @param src
     *            the path source file on the local disk
     * @param dst
     *            the path to the destination file on the FS
     * @throws IOException
     *             if an I/O error occurs
     */
    void moveFromLocalFile(File src, Path dst) throws IOException;

    /**
     * The src file is under FS, and the dst is on the local disk. Copy it from
     * FS control to the local dst name.
     * 
     * @param src
     *            the path to the source file on FS
     * @param dst
     *            the path to the destination file on local file system
     * @throws IOException
     *             if I/O error occurs
     */
    void copyToLocalFile(Path src, File dst) throws IOException;

    /**
     * Returns a local File that the user can write output to. The caller
     * provides both the eventual FS target name and the local working file. If
     * the FS is local, we write directly into the target. If the FS is remote,
     * we write into the tmp local area.
     */
    File startLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException;

    /**
     * Called when we're all done writing to the target. A local FS will do
     * nothing, because we've written to exactly the right place. A remote FS
     * will copy the contents of tmpLocalFile to the correct target at
     * fsOutputFile.
     */
    void completeLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException;

    /**
     * Returns a local File that the user can read from. The caller provides
     * both the eventual FS target name and the local working file. If the FS is
     * local, we read directly from the source. If the FS is remote, we write
     * data into the tmp local area.
     * 
     * @param fsInputFile
     * @param tmpLocalFile
     * @return
     * @throws IOException
     */
    File startLocalInput(Path fsInputFile, File tmpLocalFile)
            throws IOException;

    /**
     * Called when we're all done writing to the target. A local FS will do
     * nothing, because we've written to exactly the right place. A remote FS
     * will copy the contents of tmpLocalFile to the correct target at
     * fsOutputFile.
     */
    void completeLocalInput(File localFile) throws IOException;

    /**
     * No more filesystem operations are needed. Will release any held locks.
     */
    void close() throws IOException;

    /**
     * Return the number of bytes that large input files should be optimally be
     * split into to minimize i/o time.
     */
    long getBlockSize();

    /**
     * Obtain an advisory lock of the given type on the specified File. The lock
     * is "advisory" meaning that the other accessors of the file have to also
     * call {@link #getLock(File, int)} to ensure mutual exclusive access to the
     * file. The file system would not stop others from acessing the file if
     * they do not call {@link #getLock(File, int)}. The lock operation blocks
     * when the desired lock is not currently available. When this method
     * returns, the lock has been acquired.
     * <p>
     * The granularity of the lock holder is no coarser than the current VM. The
     * implementation can choose to use a finer-grained lock holder model.
     * Currently the local file system uses a per-thread holder model, and the
     * distributed file system uses a per DFS-client holder mode (roughly
     * equivalent to per-VM).
     * </p>
     * 
     * @param file
     *            the file to lock
     * @param type
     *            type of the lock, one of {@link #EXCLUSIVE_LOCK},
     *            {@link #SHARED_LOCK} or {@link #UPDATE_LOCK}.
     * @see #releaseLock(File)
     * @see #promoteLock(File)
     * @see #getLockState(File)
     */
    void getLock(Path file, int type) throws IOException;

    /**
     * Promote the lock on the specified file from an update lock to an
     * exclusive lock. The lock has to be currently an {@link #UPDATE_LOCK}.
     * 
     * @throws LockStateException
     *             if the lock on the specified file is not an
     *             {@link #UPDATE_LOCK}.
     * @see #getLock(File, int)
     */
    void promoteLock(Path file) throws LockStateException, IOException;

    /**
     * Release the lock on the specified file, if the current lock holder holds
     * the lock, and do nothing otherwise.
     * 
     * @see #getLock(File, int)
     */
    void releaseLock(Path file) throws IOException;

    /**
     * Get the current lock state on the file as a string. Note that due to the
     * concurrent nature of locking, the answer returned is always inaccurate as
     * the lock state could already have changed when this returns. So use this
     * at most as a debugging measure.
     */
    String getLockState(Path file) throws IOException;
}
