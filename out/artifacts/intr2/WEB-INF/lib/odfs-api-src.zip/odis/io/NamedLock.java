package odis.io;

import static odis.io.IFileSystem.EXCLUSIVE_LOCK;
import static odis.io.IFileSystem.SHARED_LOCK;
import static odis.io.IFileSystem.UPDATE_LOCK;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import odis.serialize.lib.StringWritable;

// zf: this class is put in odis.dfs.common because LocalFileSystem depends 
// on it.
/**
 * Named lock implementation. See {@link FileSystem#getLock(java.io.File, int)}
 * for API.
 * 
 * @author river
 */
public class NamedLock<T> {

    public static final int FREE = 0;

    private static final int EXCLUSIVE_WAITING = 4;

    public static String LOCK_NAME(int lockType) {
        switch (lockType) {
            case SHARED_LOCK:
                return "SHARED_LOCK";
            case UPDATE_LOCK:
                return "UPDATE_LOCK";
            case EXCLUSIVE_LOCK:
                return "EXCLUSIVE_LOCK";
            case EXCLUSIVE_WAITING:
                return "EXCLUSIVE_WAITING";
            case FREE:
                return "FREE";
            default:
                return "UNKNOWN_LOCK";
        }
    }

    public static class LockHolder<E> {
        private E holder;

        private int type;

        public LockHolder(E holder, int type) {
            this.holder = holder;
            this.type = type;
        }

        public int getType() {
            return type;
        }

        public E getHolder() {
            return holder;
        }

        public String toString() {
            return "<" + LOCK_NAME(type) + ":" + holder + ">";
        }
    }

    private final String name;

    private final Map<T, LockHolder<T>> holders;

    private int state;

    public NamedLock(String name) {
        this.name = name;
        this.state = FREE;
        this.holders = new HashMap<T, LockHolder<T>>();
    }

    public String getName() {
        return name;
    }

    public synchronized boolean isFree() {
        return holders.size() == 0;
    }

    /**
     * Acquire shared lock.
     * 
     * @param holder
     * @return true if lock granted
     */
    public synchronized boolean sharedLock(T holder) {
        if (holders.containsKey(holder)) {
            throw new LockReentrantException("re-acquire shared lock while "
                    + holders.get(holder) + " exists.");
        }

        switch (state) {
            case FREE:
                state = SHARED_LOCK;
            case SHARED_LOCK:
            case UPDATE_LOCK:
                holders.put(holder, new LockHolder<T>(holder, SHARED_LOCK));
                return true;

            case EXCLUSIVE_WAITING:
            case EXCLUSIVE_LOCK:
                return false;

            default:
                throw new RuntimeException("bad lock state : " + state);
        }
    }

    /**
     * Acquire update lock.
     * 
     * @param holder
     * @return true if lock granted
     */
    public synchronized boolean updateLock(T holder) {
        if (holders.containsKey(holder)) {
            throw new LockReentrantException("re-acquire update lock while "
                    + holders.get(holder) + " exists.");
        }

        switch (state) {
            case FREE:
            case SHARED_LOCK:
                state = UPDATE_LOCK;
                holders.put(holder, new LockHolder<T>(holder, UPDATE_LOCK));
                return true;

            case UPDATE_LOCK:
            case EXCLUSIVE_WAITING:
            case EXCLUSIVE_LOCK:
                return false;

            default:
                throw new RuntimeException("bad lock state : " + state);
        }
    }

    /**
     * Equivalent to "[release update lock & acquire exclusive lock]", but it is
     * primitive, which cannot be disturbed by others.
     * 
     * @param holder
     * @return 0 for failure(never happens), 1 for waiting, 2 for success
     */
    public synchronized int promote(T holder) throws LockStateException {
        LockHolder<T> lockHolder = holders.get(holder);
        if (lockHolder == null
                || (lockHolder.type != UPDATE_LOCK && lockHolder.type != EXCLUSIVE_WAITING)) {
            throw new LockStateException(
                    "update lock should exists before promote");
        }

        if (holders.size() == 1) {
            lockHolder.type = EXCLUSIVE_LOCK;
            state = EXCLUSIVE_LOCK;
            return 2;
        } else {
            lockHolder.type = EXCLUSIVE_WAITING;
            state = EXCLUSIVE_WAITING;
            return 1;
        }
    }

    /**
     * Acquire exclusive lock.
     * 
     * @param holder
     * @return 0 for failure, 1 for waiting, 2 for success.
     */
    public synchronized int exclusiveLock(T holder) {
        LockHolder<T> lockHolder = holders.get(holder);

        if (lockHolder != null && lockHolder.type != EXCLUSIVE_WAITING)
            throw new LockReentrantException("re-acquire shared lock while "
                    + holders.get(holder) + " exists.");

        switch (state) {
            case FREE:
                state = EXCLUSIVE_LOCK;
                holders.put(holder, new LockHolder<T>(holder, EXCLUSIVE_LOCK));
                return 2;

            case EXCLUSIVE_WAITING:
                if (lockHolder != null) {
                    if (holders.size() == 1) {
                        lockHolder.type = EXCLUSIVE_LOCK;
                        state = EXCLUSIVE_LOCK;
                        return 2;
                    } else {
                        return 1;
                    }
                } else {
                    return 0;
                }

            case SHARED_LOCK:
                state = EXCLUSIVE_WAITING;
                holders.put(holder,
                        new LockHolder<T>(holder, EXCLUSIVE_WAITING));
                return 1;

            case UPDATE_LOCK:
            case EXCLUSIVE_LOCK:
                return 0;

            default:
                throw new RuntimeException("bad lock state : " + state);
        }
    }

    /**
     * Downgrade the exclusive lock to shared lock.
     * 
     * @param holder
     */
    public synchronized void downgrade(T holder) throws LockStateException {
        LockHolder<T> lockHolder = holders.get(holder);
        if (lockHolder == null) {
            throw new LockStateException("downgrade lock not exists");
        }
        if (lockHolder.type != EXCLUSIVE_LOCK) {
            throw new LockStateException("downgrade lock which in "
                    + LOCK_NAME(lockHolder.type));
        }
        lockHolder.type = SHARED_LOCK;
        state = SHARED_LOCK;
    }

    /**
     * Release the lock hold by holder.
     * 
     * @param holder
     */
    public synchronized void unlock(T holder) {
        LockHolder<T> lockHolder = holders.remove(holder);
        if (lockHolder == null)
            return;

        switch (lockHolder.type) {
            case SHARED_LOCK:
                if (state == SHARED_LOCK) {
                    state = holders.size() == 0 ? FREE : SHARED_LOCK;
                }
                break;

            case UPDATE_LOCK:
            case EXCLUSIVE_WAITING:
            case EXCLUSIVE_LOCK:
                state = holders.size() == 0 ? FREE : SHARED_LOCK;
                break;
            default:
                throw new RuntimeException("bad lock state : " + state);
        }
    }

    public synchronized T[] holders(T[] arr) {
        return holders.keySet().toArray(arr);
    }

    public synchronized byte[] encode(BytesTranscoder<T> transcoder) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        CDataOutputStream dos = new CDataOutputStream(bos);
        try {
            StringWritable.writeString(dos, name);
            dos.writeInt(state);
            dos.writeInt(holders.size());
            for (LockHolder<T> holder: holders.values()) {
                byte[] bytes = transcoder.encode(holder.holder);
                dos.writeInt(bytes.length);
                dos.write(bytes);
                dos.writeInt(holder.type);
            }
            dos.close();
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
        return bos.toByteArray();
    }

    private NamedLock(String name, int state, Map<T, LockHolder<T>> holders) {
        this.name = name;
        this.state = state;
        this.holders = holders;
    }

    public static <T> NamedLock<T> decode(byte[] data,
            BytesTranscoder<T> transcoder) {
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        CDataInputStream dis = new CDataInputStream(bis);
        try {
            String name = StringWritable.readString(dis);
            int state = dis.readInt();
            Map<T, LockHolder<T>> holders = new HashMap<T, NamedLock.LockHolder<T>>();
            int size = dis.readInt();
            for (int i = 0; i < size; i++) {
                byte[] bytes = new byte[dis.readInt()];
                dis.readFully(bytes);
                T holder = transcoder.decode(bytes);
                int type = dis.readInt();
                holders.put(holder, new LockHolder<T>(holder, type));
            }
            return new NamedLock<T>(name, state, holders);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        } finally {
            ReadWriteUtils.safeClose(dis);
        }
    }

    public synchronized String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(LOCK_NAME(state)).append(":[");
        Iterator<LockHolder<T>> iter = holders.values().iterator();
        if (iter.hasNext()) {
            builder.append(iter.next().toString());
            while (iter.hasNext()) {
                builder.append(',').append(iter.next().toString());
            }
        }
        builder.append(']');
        return builder.toString();
    }

}
