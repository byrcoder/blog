package odis.io.ramfs;

import java.io.File;

/**
 * imitate DFSFile definition
 * 
 * @author why
 * @since 2007-2-6
 */
@Deprecated
public class RAMFile extends File {

    private static final long serialVersionUID = 3322258696001706790L;

    private transient RAMFileInfo info;

    public RAMFile(RAMFileInfo info) {
        super(info.getPath());
        this.info = info;
    }

    /**
     * A number of File methods are unsupported in this subclass
     */
    public boolean canRead() {
        return false;
    }

    public boolean canWrite() {
        return false;
    }

    public boolean createNewFile() {
        return false;
    }

    public boolean delete() {
        return false;
    }

    public void deleteOnExit() {}

    public boolean isHidden() {
        return false;
    }

    /**
     * We need to reimplement some of them
     */
    public boolean isDirectory() {
        return info.isDir();
    }

    public boolean isFile() {
        return !info.isDir();
    }

    public long length() {
        return info.getContentsLen();
    }

    public long lastModified() {
        return info.lastModified();
    }

    //    /**
    //     * And add a few extras
    //     */
    //    public long getContentsLength() {
    //        return info.getDataSize();
    //    }

    @Override
    public String getName() {
        return info.getName();
    }

    /**
     * Retrieving parent path from FS path string
     * 
     * @param path
     *            - DFS path
     * @return - parent path of FS path, or null if no parent exist.
     */
    public static String getFSParent(String path) {
        if (path == null)
            return null;
        if (RAMFileSystem.ROOT_PATH.equals(path))
            return null;
        int index = path.lastIndexOf(RAMFileSystem.SEPERATOR);
        if (index == -1)
            return null;
        if (index == 0)
            return RAMFileSystem.SEPERATOR;
        return path.substring(0, index);
    }
}
