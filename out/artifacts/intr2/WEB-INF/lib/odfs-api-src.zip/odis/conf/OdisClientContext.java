package odis.conf;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.HashMap;

import odis.io.FileSystem;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;

/**
 * The context for odis client application
 * 
 * @author zhangduo
 */
public abstract class OdisClientContext {

    public static final String APP_COWORK = "cowork.address";

    public static final String APP_DFS = "dfs.address";

    // system wide configurations for the project, including all different
    // instances and everything else.    
    protected static final HashMap<String, Integer> instanceMap = new HashMap<String, Integer>();

    static {
        OdisLibConfig.load("-default.xml");
        String[] instances = OdisLibConfig.conf().getStringArray(
                "app.instance.name");
        for (int i = 0; i < instances.length; i++) {
            instanceMap.put(instances[i], i);
        }
    }

    public static Configuration getConfig() {
        return OdisLibConfig.conf();
    }

    /**
     * Get default application name
     * 
     * @return the default application name
     */
    public static String getDefaultApp() {
        String instance = OdisLibConfig.conf().getString("app.default");
        if (instance == null) {
            throw new RuntimeException("Cannot find default application");
        }
        return instance;
    }

    /**
     * Check if the application exists.
     * 
     * @param s
     * @return
     */
    public static boolean isAppExists(String s) {
        return instanceMap.containsKey(s);
    }

    public static String getAppHome() {
        return OdisLibConfig.getHomeDir().getPath();
    }

    public static File getAppConfFile(String conf) {
        return new File(OdisLibConfig.getConfigDir(), conf);
    }

    /**
     * Return the default file system setting in configuration.
     * 
     * @return the default file system instance
     * @throws IOException
     */
    @Deprecated
    public static FileSystem getDefaultFileSystem() throws IOException {
        String instance = getDefaultApp();
        Integer idx = instanceMap.get(instance);
        if (idx == null) {
            throw new RuntimeException("Cannot find instance " + instance);
        }
        return FileSystem.getNamed(getFsName(idx, "local"));
    }

    protected static InetSocketAddress getDefaultCoWork() {
        return OdisLibConfig.getAddress(getConfig().getString(APP_COWORK,
                "local"));
    }

    @SuppressWarnings("rawtypes")
    protected static String getFsName(int idx, String def) {
        Object fsNameProp = OdisLibConfig.conf().getProperty(
                "app.instance(" + idx + ")." + APP_DFS);
        if (fsNameProp == null) {
            return def;
        } else if (fsNameProp instanceof Collection) {
            return StringUtils.join((Collection) fsNameProp, ',');
        } else {
            return (String) fsNameProp;
        }
    }

}
