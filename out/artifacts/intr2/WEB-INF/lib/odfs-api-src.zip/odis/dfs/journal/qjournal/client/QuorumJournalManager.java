package odis.dfs.journal.qjournal.client;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.JournalManager;
import odis.dfs.journal.qjournal.IQJournalProtocol.ExistResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.GetJournalStateResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.PrepareRecoveryResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.SegmentState;
import odis.dfs.journal.qjournal.client.AsyncLogger.State;
import odis.dfs.metrics.QjmMetrics;
import odis.dfs.metrics.QjmMetricsItem;
import odis.dfs.util.DfsUtils;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;

/**
 * A JournalManager that writes to a set of remote JournalNodes, requiring a
 * quorum of nodes to ack each write.
 * 
 * @author chenxi
 */
public class QuorumJournalManager implements JournalManager {

    private static final Logger LOG = LogFormatter
            .getLogger(QuorumJournalManager.class);

    private String clusterId;

    private final AsyncLoggerSet loggers;
    
    private long currentSN = 0;
    
    private long currentLogLength;
    
    private final Adler32 adler32 = new Adler32();

    // Timeouts for which the QJM will wait for each of the following actions.
    private final int getJournalStateTimeoutMs;

    private final int newEpochTimeoutMs;

    private final int startSegmentTimeoutMs;
    
    private final int finalizeSegmentTimeoutMs;

    private final int prepareRecoveryTimeoutMs;

    private final int acceptRecoveryTimeoutMs;
    
    private final int writeJournalTimeoutMs;
    
    private final int openInputStreamTimeoutMs;
    
    final QjmMetrics metrics = new QjmMetrics();

    public QuorumJournalManager(Configuration conf) throws IOException {
        this(conf, RpcLoggerChannel.FACTORY);
    }

    public QuorumJournalManager(Configuration conf,
            AsyncLogger.Factory loggerFactory) throws IOException {
        this.clusterId = conf.getString(DFSConfig.ZOOKEEPER_ROOT) + "@"
                + conf.getString(DFSConfig.ZOOKEEPER_ADDR);
        LOG.info("Creating quorum journal manager for cluster: " + clusterId);
        String[] journalNodes = conf
                .getStringArray(DFSConfig.DFS_QJOURNAL_JOURNAL_NODES);
        this.loggers = new AsyncLoggerSet(createLoggers(journalNodes,
                loggerFactory));

        this.getJournalStateTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_GET_JOURNAL_STATE_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_GET_JOURNAL_STATE_TIMEOUT_DEFAULT);
        this.newEpochTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_NEW_EPOCH_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_NEW_EPOCH_TIMEOUT_DEFAULT);
        this.startSegmentTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_START_SEGMENT_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_START_SEGMENT_TIMEOUT_DEFAULT);
        this.finalizeSegmentTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_FINALIZE_SEGMENT_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_FINALIZE_SEGMENT_TIMEOUT_DEFAULT);
        this.prepareRecoveryTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_PREPARE_RECOVERY_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_PREPARE_RECOVERY_TIMEOUT_DEFAULT);
        this.acceptRecoveryTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_ACCEPT_RECOVERY_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_ACCEPT_RECOVERY_TIMEOUT_DEFAULT);
        this.writeJournalTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_WRITE_JOURNAL_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_WRITE_JOURNAL_TIMEOUT_DEFAULT);
        this.openInputStreamTimeoutMs = conf.getInt(
                DFSConfig.DFS_QJOURNAL_OPEN_INPUTSTREAM_TIMEOUT_KEY,
                DFSConfig.DFS_QJOURNAL_OPEN_INPUTSTREAM_TIMEOUT_DEFAULT);
        LOG.info("Creating quorum journal manager success...");

    }

    private List<AsyncLogger> createLoggers(String[] journalNodes,
            AsyncLogger.Factory loggerFactory) throws IOException {
        List<AsyncLogger> ret = Lists.newArrayList();
        for (String journalNode: journalNodes) {
            String[] nodes = journalNode.split(":");
            InetSocketAddress addr = new InetSocketAddress(nodes[0],
                    Integer.parseInt(nodes[1]));
            AsyncLogger asyncLogger = loggerFactory.createLogger(clusterId,
                    addr);
            ret.add(asyncLogger);
        }
        return ret;
    }
    
    public long[] getQjmMetricsRecords() {
        long[] qjmMetricsRecords = new long[QjmMetricsItem.totalItems()];
        metrics.fillMetricsRecords(qjmMetricsRecords);
        return qjmMetricsRecords;
    }

    @Override
    public void recoverUnfinalizedSegmentAndStartNewSegment(long minimumSN)
            throws IOException {
        // Fencing writers
        LOG.info("Starting recovery process for unclosed journal segments...");
        Map<AsyncLogger, Long> lastSegmentNumbers = createNewUniqueEpoch();
        LOG.info("Successfully started new epoch " + loggers.getEpoch());

        // Recover unfinalized Segment
        long mostRecentSn = Long.MIN_VALUE;
        for (Long lastSn: lastSegmentNumbers.values()) {
            mostRecentSn = Math.max(mostRecentSn, lastSn);
        }
        LOG.info("Starting recovery process for segment " + mostRecentSn);
        if (Long.MIN_VALUE != mostRecentSn) {
            recoverUnclosedSegment(mostRecentSn);
        }
        LOG.info("Recover segment " + mostRecentSn + " success");
        currentSN = mostRecentSn;
        
        // Start new Segment
        this.startNewSegment(minimumSN);
    }

    /**
     * Fence any previous writers, and obtain a unique epoch number for
     * write-access to the journal nodes.
     * 
     * @return The last Segment Number of each JournalNode
     */
    public Map<AsyncLogger, Long> createNewUniqueEpoch() throws IOException {
        long start = System.currentTimeMillis();
        Map<AsyncLogger, GetJournalStateResponse> lastPromises = loggers
                .waitForWriteQuorum(loggers.getJournalState(),
                        getJournalStateTimeoutMs, "getJournalState()");
        long elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.GET_JOURNAL_STATE_COUNT);
        metrics.add(QjmMetricsItem.GET_JOURNAL_STATE_DELAY, elapsed);

        long maxPromised = Long.MIN_VALUE;
        for (GetJournalStateResponse resp: lastPromises.values()) {
            maxPromised = Math.max(maxPromised, resp.getLastPromisedEpoch());
        }
        assert maxPromised >= 0;

        long myEpoch = maxPromised + 1;
        
        start = System.currentTimeMillis();
        Map<AsyncLogger, Long> resps = loggers.waitForWriteQuorum(
                loggers.newEpoch(clusterId, myEpoch), newEpochTimeoutMs,
                "newEpoch(" + myEpoch + ")");
        elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.NEW_EPOCH_COUNT);
        metrics.add(QjmMetricsItem.NEW_EPOCH_DELAY, elapsed);

        loggers.setEpoch(myEpoch);
        return resps;
    }

    @Override
    public void write(byte[] buf) throws IOException {
        this.write(buf, 0, buf.length);
    }

    @Override
    public void write(byte[] buf, int off, int len) throws IOException {
        long start = System.currentTimeMillis();
        byte[] localBuf = Arrays.copyOfRange(buf, off, off + len); 
        QuorumCall<AsyncLogger, Integer> journalCall = loggers.journal(
                currentSN, localBuf, (int) this.adler32.getValue());
        loggers.waitForWriteQuorum(journalCall, writeJournalTimeoutMs,
                "journal(" + currentSN + ", buf, " + off + ", " + len + ")");
        long elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.WRITE_JOURNAL_COUNT);
        metrics.add(QjmMetricsItem.WRITE_JOURNAL_DELAY, elapsed);
        metrics.add(QjmMetricsItem.WRITE_JOURNAL_BYTES, len);
        
        this.adler32.update(buf, off, len);
        this.currentLogLength += len;
    }

    @Override
    public void finalizeSegmentAndStartNewSegment() throws IOException {
        this.finalizeSegment(currentSN, currentLogLength);
        this.startNewSegment(currentSN + 1);
    }

    @Override
    public InputStream openFinalizedSegment(long sn) throws IOException {
        // It's always ok to read segment if some logger is ok.

        // But How to handle the recovry when the some logger is down,
        // and the segment is not in quorum alive logger

        // TODO: handle situation find segment not in
        // quorum logger when open segment
        long start = System.currentTimeMillis();
        QuorumCall<AsyncLogger, ExistResponse> isFinalized = loggers.exist(sn);
        Map<AsyncLogger, ExistResponse> resps = loggers.waitForReadQuorum(
                isFinalized, openInputStreamTimeoutMs, "isFinalized(" + sn
                        + ")");
        long elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.OPEN_INPUTSTREAM_COUNT);
        metrics.add(QjmMetricsItem.OPEN_INPUTSTREAM_DELAY, elapsed);
        
        List<InputStream> streams = new ArrayList<InputStream>();
        List<URL> urls = new ArrayList<URL>();
        int existJournal = 0;
        for (Entry<AsyncLogger, ExistResponse> entry: resps.entrySet()) {
            AsyncLogger logger = entry.getKey();
            ExistResponse existResps = entry.getValue();
            if (existResps.isExist()) {
                ++ existJournal;
                URL url = logger.buildURLToFetchLogs(sn);
                LOG.info("Open inputStream from url: " + url);
                try {
                    InputStream stream = DfsUtils.buildInputStreamFromURL(url);
                    streams.add(stream);
                    urls.add(url);
                } catch (IOException e) {
                    LOG.warning("Failed to open inputStream from url: " + url);
                }
            }
        }
        if (0 == existJournal) {
            return null;
        }
        
        LOG.info("Open redundant inputstream for sn=" + sn);
        RedundantInputStream inputStream = new RedundantInputStream(streams, urls);
        return inputStream;
    }

    @Override
    public void deleteSegmentBefore(long sn) throws IOException {
        // This purges asynchronously -- there's no need to wait for a quorum
        // here, because it's always OK to fail.
        LOG.info("Delete remote journals before sn=" + sn);
        loggers.deleteSegmentBefore(sn);
    }

    @Override
    public long currentOpenedSegmentSN() {
        return this.currentSN;
    }

    @Override
    public void close() {
        this.loggers.close();
    }

    @VisibleForTesting
    AsyncLoggerSet getLoggerSetForTests() {
        return loggers;
    }

    @Override
    public String toString() {
        int errorLogger = 0;
        for (AsyncLogger logger: loggers.getLoggers()) {
            if (logger.getState() == State.ERROR) {
                ++ errorLogger;
            }
        }
        return "QJM Infos:[errorLogger=" + errorLogger + "]\n" + loggers;
    }
    
    private void startNewSegment(long minimumSN) throws IOException {
        minimumSN = Math.max(minimumSN, currentSN + 1);
        LOG.info("Starting new segment minimumSn=" + minimumSN);
        
        long start = System.currentTimeMillis();
        QuorumCall<AsyncLogger, Long> q = loggers.startLogSegment(minimumSN);
        Map<AsyncLogger, Long> currentSNs = loggers.waitForWriteQuorum(q,
                startSegmentTimeoutMs, "startLogSegment(" + minimumSN + ")");
        long elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.START_SEGMENT_COUNT);
        metrics.add(QjmMetricsItem.START_SEGMENT_DELAY, elapsed);
        
        //check start segment with the same sn
        long currentSN = -1;
        for (Long sn: currentSNs.values()) {
            if (-1 == currentSN) {
                currentSN = sn;
            } else if (currentSN != sn) {
                throw new IOException(
                        "!BUG: start new segment in different sn:\n"
                                + QuorumCall.mapToString(currentSNs));
            }
        }
        this.currentSN = currentSN;
        this.currentLogLength = 0;
        this.adler32.reset();
        LOG.info("Starting new segment " + currentSN + " success");
    }
    
    /**
     * Run recovery/synchronization for a specific segment. Postconditions:
     * <ul>
     * <li>This segment will be finalized on a majority of nodes.</li>
     * <li>All nodes which contain the finalized segment will agree on the
     * length.</li>
     * </ul>
     * 
     * @param segmentTxId
     *            the starting txid of the segment
     * @throws IOException
     */
    private void recoverUnclosedSegment(long sn) throws IOException {
        if (0 >= sn) {
            //No segment to recover
            return;
        }
        LOG.info("Beginning recovery of unclosed segment " + sn);

        // Step 1. Prepare recovery
        long start = System.currentTimeMillis();
        QuorumCall<AsyncLogger, PrepareRecoveryResponse> prepare = loggers
                .prepareRecovery(sn);
        Map<AsyncLogger, PrepareRecoveryResponse> prepareResponses = loggers
                .waitForWriteQuorum(prepare, prepareRecoveryTimeoutMs,
                        "prepareRecovery(" + sn + ")");
        long elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.PREPARE_RECOVERY_COUNT);
        metrics.add(QjmMetricsItem.PREPARE_RECOVERY_DELAY, elapsed);
        LOG.info("Recovery prepare phase complete. Responses:\n"
                + QuorumCall.mapToString(prepareResponses));

        // Determine the logger who either:
        // a) Has already accepted a previous proposal that's higher than any
        // other
        //
        // OR, if no such logger exists:
        //
        // b) Has the longest log starting at this transaction ID

        // TODO: we should collect any "ties" and pass the URL for all of them
        // when syncing, so we can tolerate failure during recovery better.
        Entry<AsyncLogger, PrepareRecoveryResponse> bestEntry = Collections
                .max(prepareResponses.entrySet(),
                        SegmentRecoveryComparator.INSTANCE);
        AsyncLogger bestLogger = bestEntry.getKey();
        PrepareRecoveryResponse bestResponse = bestEntry.getValue();

        // Log the above decision, check invariants.
        if (bestResponse.getAcceptedInEpoch() != -1) {
            LOG.info("Using already-accepted recovery for segment " + sn + ": "
                    + bestEntry);
        } else if (bestResponse.getSegmentState() != null) {
            LOG.info("Using longest log: " + bestEntry);
        } else {
            // None of the responses to prepareRecovery() had a segment at the
            // given
            // txid. This can happen for example in the following situation:
            // - 3 JNs: JN1, JN2, JN3
            // - writer starts segment 101 on JN1, then crashes before
            // writing to JN2 and JN3
            // - during newEpoch(), we saw the segment on JN1 and decide to
            // recover segment 101
            // - before prepare(), JN1 crashes, and we only talk to JN2 and JN3,
            // neither of which has any entry for this log.
            // In this case, it is allowed to do nothing for recovery, since the
            // segment wasn't started on a quorum of nodes.

            // Sanity check: we should only get here if none of the responses
            // had
            // a log. This should be a postcondition of the recovery comparator,
            // but a bug in the comparator might cause us to get here.
            for (PrepareRecoveryResponse resp: prepareResponses.values()) {
                assert null == resp.getSegmentState(): "One of the loggers had a response, but no best logger "
                        + "was found.";
            }

            LOG.info("None of the responders had a log to recover: "
                    + QuorumCall.mapToString(prepareResponses));
            return;
        }

        SegmentState logToSync = bestResponse.getSegmentState();
        assert sn == logToSync.getSn();
        if (0 == logToSync.getContentLength()) {
            LOG.info("No need to recovery since all log segments is empty");
            return;
        }

        URL syncFromUrl = bestLogger.buildURLToFetchLogs(sn);

        start = System.currentTimeMillis();
        QuorumCall<AsyncLogger, Long> accept = loggers.acceptRecovery(
                logToSync, syncFromUrl.toString());
        Map<AsyncLogger, Long> acceptResps = loggers.waitForWriteQuorum(accept,
                acceptRecoveryTimeoutMs, "acceptRecovery(" + logToSync + ")");
        elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.ACCEPT_RECOVERY_COUNT);
        metrics.add(QjmMetricsItem.ACCEPT_RECOVERY_DELAY, elapsed);
        LOG.info("Finish accept recovery for log segment sn=" + sn + "\n"
                + QuorumCall.mapToString(acceptResps));

        // If one of the loggers above missed the synchronization step above,
        // but
        // we send a finalize() here, that's OK. It validates the log before
        // finalizing. Hence, even if it is not "in sync", it won't incorrectly
        // finalize.
        this.finalizeSegment(sn, logToSync.getContentLength());
    }
    
    private void finalizeSegment(long sn, long logLen) throws IOException {
        LOG.info("Begin to finalize log segment for recovery sn=" + sn);
        long start = System.currentTimeMillis();
        QuorumCall<AsyncLogger, Integer> finalize = loggers.finalizeLogSegment(
                sn, logLen);
        Map<AsyncLogger, Integer> resps = loggers.waitForWriteQuorum(finalize,
                finalizeSegmentTimeoutMs, "finalizeLogSegment(" + currentSN
                        + ")");
        long elapsed = System.currentTimeMillis() - start;
        metrics.increment(QjmMetricsItem.FINALIZE_SEGMENT_COUNT);
        metrics.add(QjmMetricsItem.FINALIZE_SEGMENT_DELAY, elapsed);
        
        int checksum = 1;
        int i = 0;
        StringBuilder sb = new StringBuilder();
        boolean conflict = false;
        for (Integer curChecksum: resps.values()) {
            if (0 == i) {
                checksum = curChecksum;
                sb.append(curChecksum);
            } else {
                sb.append(" ," + curChecksum);
                if (checksum != curChecksum) {
                    conflict = true;
                }
            }
            ++i;
        }
        if (conflict) {
            throw new IOException(
                    "BUG: acked to different checksum length when finalize log\n ContentLengths: "
                            + sb.toString());
        }
        LOG.info("Finalize log segment success. responses: \n"
                + QuorumCall.mapToString(resps));
    }

    @Override
    public long maxFinalizedSegmentSN() throws IOException {
        Map<AsyncLogger, Long> resps = loggers.waitForWriteQuorum(
                loggers.maxFinalizedSegmentSN(), newEpochTimeoutMs,
                "maxFinalizedSegmentSN()");
        long maxFinalizedSN = Long.MIN_VALUE;
        for (Long maxSn: resps.values()) {
            maxFinalizedSN = Math.max(maxFinalizedSN, maxSn);
        }
        return maxFinalizedSN;
    }
}
