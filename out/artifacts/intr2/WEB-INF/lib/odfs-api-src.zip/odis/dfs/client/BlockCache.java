/**
 * @(#)BlockCache.java, 2012-12-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.util.DfsUtils;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import odis.io.TimeoutPolicy;
import odis.util.ThreadLocalRandomData;
import toolbox.collections.primitive.LongCompactHashSet;
import toolbox.misc.FileUtils;
import toolbox.misc.LogFormatter;

/**
 * Cache block data in local dir.
 * 
 * @author zhangduo
 */
class BlockCache {
    private static final Logger LOG = LogFormatter.getLogger(BlockCache.class);

    private final File dir;

    private static final class CacheEntry {
        int refCount;

        final BitSet bitSet = new BitSet();
    }

    private final Map<String, CacheEntry> fileCaches = new HashMap<String, CacheEntry>();

    private static final class WaitingBlock {

        final BlockSizeLocationWithDataPath block;

        final String fileId;

        final long offset;

        final int blockIndex;

        WaitingBlock(BlockSizeLocationWithDataPath block, String fileId,
                int blockIndex, long offset) {
            this.block = block;
            this.fileId = fileId;
            this.offset = offset;
            this.blockIndex = blockIndex;
        }

        @Override
        public String toString() {
            return "[WaitingBlock block=" + block + ", fileId=" + fileId
                    + ", offset=" + offset + ", blockIndex=" + blockIndex + "]";
        }
    }

    private final LinkedHashMap<Long, WaitingBlock> waitingBlocks = new LinkedHashMap<Long, WaitingBlock>();

    private final LongCompactHashSet downloadingBlocks = new LongCompactHashSet();

    private final class Downloader extends Thread {

        private final byte[] buffer = new byte[bufferSize];

        Downloader() {
            super("BlockCache-Downloader");
            setDaemon(true);
        }

        @Override
        public void run() {
            while (running) {
                WaitingBlock wb;
                synchronized (waitingBlocks) {
                    while (waitingBlocks.isEmpty()) {
                        try {
                            waitingBlocks.wait();
                        } catch (InterruptedException e) {
                            continue;
                        }
                    }
                    Iterator<WaitingBlock> iter = waitingBlocks.values().iterator();
                    wb = iter.next();
                    iter.remove();
                    downloadingBlocks.add(wb.block.getBlock());
                }
                try {
                    download(wb, buffer);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Download " + wb + " failed", e);
                }
                synchronized (waitingBlocks) {
                    downloadingBlocks.remove(wb.block.getBlock());
                }
            }
        }
    }

    private final Downloader[] downloaders;

    private final long downloadTimeout;

    private final int bufferSize;

    private final Future<?> gcTask;

    private volatile boolean running = true;

    BlockCache(File dir, int downloadConcurrency, long downloadTimeout,
            int bufferSize, ScheduledExecutorService gcTaskPool, long gcInterval) {
        this.dir = dir;
        if (dir.exists()) {
            FileUtils.fullyDelete(dir);
        }
        if (!dir.mkdirs()) {
            throw new RuntimeException("Create block cache dir "
                    + dir.getAbsolutePath() + " failed");
        }
        this.downloadTimeout = downloadTimeout;
        this.bufferSize = bufferSize;
        downloaders = new Downloader[downloadConcurrency];
        for (int i = 0; i < downloadConcurrency; i++) {
            downloaders[i] = new Downloader();
            downloaders[i].start();
        }
        gcTask = gcTaskPool.scheduleAtFixedRate(new Runnable() {

            @Override
            public void run() {
                try {
                    gc();
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "unexpected exception caught when block cache gc",
                            e);
                }
            }
        }, gcInterval, gcInterval, TimeUnit.MILLISECONDS);
    }

    private void download(WaitingBlock wb, byte[] buf) throws IOException {
        LOG.info("Start downloading " + wb);
        File cacheFile = new File(dir, wb.fileId);
        String[] locs = wb.block.getLocations();
        ThreadLocalRandomData rand = ThreadLocalRandomData.current();
        RandomAccessFile cacheOut = new RandomAccessFile(cacheFile, "rw");
        try {
            for (int i = locs.length - 1; i >= 0; i--) {
                cacheOut.seek(wb.offset);
                int chosenIndex = rand.nextInt(i + 1);
                String dataNode = locs[chosenIndex];
                SequentialBlockInputStream in;
                try {
                    in = new SequentialBlockInputStream(wb.block.getBlock(),
                            wb.blockIndex, wb.offset, wb.offset
                                    + wb.block.getLen(), dataNode,
                            downloadTimeout, TimeoutPolicy.RESPONSE_IN_TIME, 0,
                            0);
                } catch (IOException e) {
                    LOG.log(Level.WARNING, "open connection to " + dataNode
                            + " failed", e);
                    DfsUtils.swap(locs, chosenIndex, i);
                    continue;
                }
                for (int remaining = wb.block.getLen(); remaining > 0;) {
                    int read;
                    try {
                        read = in.read(buf, 0, Math.min(remaining, buf.length));
                    } catch (IOException e) {
                        LOG.log(Level.WARNING, "read " + wb.block.getBlock()
                                + " from " + dataNode + " failed", e);
                        ReadWriteUtils.safeClose(in);
                        DfsUtils.swap(locs, chosenIndex, i);
                        continue;
                    }
                    boolean succ = false;
                    try {
                        cacheOut.write(buf, 0, read);
                        succ = true;
                    } finally {
                        if (!succ) {
                            ReadWriteUtils.safeClose(in);
                        }
                    }
                    remaining -= read;
                }
                ReadWriteUtils.safeClose(in);
                LOG.info("Successfully download " + wb.block.getBlock()
                        + " from " + dataNode);
                synchronized (waitingBlocks) {
                    CacheEntry cache = fileCaches.get(wb.fileId);
                    if (cache != null) {
                        cache.bitSet.set(wb.blockIndex);
                    } else {
                        if (cacheFile.exists() && !cacheFile.delete()) {
                            LOG.warning("Failed to delete cache file "
                                    + cacheFile.getAbsolutePath()
                                    + " when download unregistered file");
                        }
                    }
                }
            }
        } finally {
            ReadWriteUtils.safeClose(cacheOut);
        }
    }

    private void gc() {
        synchronized (waitingBlocks) {
            for (Iterator<Map.Entry<String, CacheEntry>> iter = fileCaches.entrySet().iterator(); iter.hasNext();) {
                Map.Entry<String, CacheEntry> entry = iter.next();
                if (entry.getValue().refCount <= 0) {
                    iter.remove();
                    LOG.info("Cache file " + entry.getKey()
                            + " is expired, delete it");
                    File toDelete = new File(dir, entry.getKey());
                    if (!toDelete.delete()) {
                        LOG.warning("Failed to delete cache file "
                                + toDelete.getAbsolutePath() + " when gc");
                    }
                }
            }
            LOG.info("BlockCache status: cachedFiles=" + fileCaches.size()
                    + ", waitingBlocks=" + waitingBlocks.size()
                    + ", downloadingBlocks=" + downloadingBlocks.size()
                    + ", cacheDir=" + dir.getAbsolutePath());
        }
    }

    File cacheDir() {
        return dir;
    }

    void registerReader(String fileId) {
        synchronized (waitingBlocks) {
            CacheEntry cache = fileCaches.get(fileId);
            if (cache == null) {
                cache = new CacheEntry();
                fileCaches.put(fileId, cache);
            }
            cache.refCount++;
        }
    }

    // called by DFSOutputStream when DFSClient.OS_WRITETOCACHE set
    void registerCachedFile(String fileId, int blockNum) {
        CacheEntry cache = new CacheEntry();
        cache.bitSet.set(0, blockNum);
        synchronized (waitingBlocks) {
            fileCaches.put(fileId, cache);
        }
    }

    void cancelReader(String fileId) {
        synchronized (waitingBlocks) {
            CacheEntry cache = fileCaches.get(fileId);
            if (cache != null) {
                cache.refCount--;
            }
        }
    }

    void scheduleBlock(BlockSizeLocationWithDataPath block, int blockIndex,
            String fileId, long offsetInFile) {
        WaitingBlock wb = new WaitingBlock(block, fileId, blockIndex,
                offsetInFile);
        synchronized (waitingBlocks) {
            CacheEntry cache = fileCaches.get(fileId);
            if (cache == null) {
                return;
            }
            if (cache.bitSet.get(blockIndex)) {
                return;
            }
            if (!downloadingBlocks.contains(block.getBlock())) {
                waitingBlocks.put(block.getBlock(), wb);
                waitingBlocks.notifyAll();
            }
        }
    }

    boolean cached(String fileId, int blockIndex) {
        synchronized (waitingBlocks) {
            CacheEntry cache = fileCaches.get(fileId);
            return cache != null && cache.bitSet.get(blockIndex);
        }
    }

    RandomAccessFile openBlockCache(String fileId) throws FileNotFoundException {
        return new RandomAccessFile(new File(dir, fileId), "r");
    }

    void shutdown() {
        running = false;
        for (Downloader downloader: downloaders) {
            downloader.interrupt();
        }
        gcTask.cancel(true);
    }

    static String getBlockCacheFileId(String path,
            BlockSizeLocationWithDataPath[] blocks) {
        if (blocks.length < 1) {
            return path.replace(Path.separator, "$");
        } else {
            return Long.toString(blocks[0].getBlock());
        }
    }
}
