/**
 * @(#)EarliestAncestorNormalizer.java, 2012-12-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.File;

import org.apache.commons.configuration.Configuration;

/**
 * @author zhangduo
 */
class EarliestAncestorNormalizer implements OfflineDiskPathNormalizer {

    EarliestAncestorNormalizer(Configuration conf) {}

    @Override
    public String getPrefix(String path) {
        int colon = path.indexOf(File.separatorChar, 1);
        return path.substring(0, colon);
    }

}
