/**
 * @(#)BlockTransferManager.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.common.IDataToNameProtocol;
import odis.dfs.common.ReplicateCommand;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.io.DirectByteBufferPool;
import odis.util.DaemonTracker;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableInt;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class BlockTransferManager {

    private static final Logger LOG = LogFormatter.getLogger(BlockTransferManager.class);

    private final ReplicationQueue queue = new ReplicationQueue();

    private final DataNode dataNode;

    private final TransferWorker[] workers;

    private final long maxWorkInterval;

    private final DirectByteBufferPool directByteBufferPool;

    BlockTransferManager(Configuration conf, DataNode dataNode,
            DirectByteBufferPool directByteBufferPool) {
        this.dataNode = dataNode;
        this.directByteBufferPool = directByteBufferPool;
        this.maxWorkInterval = conf.getLong(
                DFSConfig.DATANODE_TRANSFER_MAX_WORK_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_TRANSFER_MAX_WORK_INTERVAL);
        int workerCount = conf.getInt(DFSConfig.DATANODE_MAX_TRANSFER_COUNT,
                DFSConfig.DEFAULT_DATANODE_MAX_TRANSFER_COUNT);
        workers = new TransferWorker[workerCount];
        for (int i = 0; i < workerCount; i++) {
            workers[i] = new TransferWorker(i);
        }
    }

    private volatile boolean running = true;

    void schedule(ReplicateCommand cmd) {
        queue.putIfAbsent(cmd);
    }

    void start() {
        for (TransferWorker worker: workers) {
            worker.start();
        }
    }

    void shutdown() {
        running = false;
        for (TransferWorker worker: workers) {
            worker.interrupt();
        }
    }

    void awaitTermination() throws InterruptedException {
        for (TransferWorker worker: workers) {
            worker.join();
        }
    }

    private class TransferWorker extends Thread {

        private Queue<BlockSizeLocationWithDataPath> unreportedBlocks = new ArrayDeque<BlockSizeLocationWithDataPath>();

        private void replicationDone() {
            if (unreportedBlocks.isEmpty()) {
                return;
            }
            IDataToNameProtocol[] nameNodes = dataNode.getNameNodes();
            while (!unreportedBlocks.isEmpty()) {
                BlockSizeLocationWithDataPath lblock = unreportedBlocks.peek();
                for (IDataToNameProtocol nameNode: nameNodes) {
                    try {
                        nameNode.replicationDone(dataNode.fullName, lblock);
                    } catch (Exception e) {
                        LOG.log(Level.WARNING, dataNode.fullName
                                + " report replicationDone for " + lblock
                                + " failed", e);
                        return;
                    }
                }
                unreportedBlocks.poll();
                queue.replicationDone(lblock.getBlock());
            }
        }

        @Override
        public void run() {
            DaemonTracker tr = new DaemonTracker();
            while (running)
                try {
                    BlockLocationWithDataPath lblock;
                    try {
                        if ((lblock = queue.take(maxWorkInterval)) == null) {
                            continue;
                        }
                    } catch (InterruptedException e) {
                        continue;
                    }
                    int successCount = 0;
                    MutableInt blockLength = new MutableInt(-1);
                    dataNode.metrics.increment(DataNodeMetricsItem.CONCURRENT_REPLICATION);
                    ByteBuffer bb = null;
                    try {
                        bb = directByteBufferPool.allocate();
                        successCount = dataNode.transferBlock(
                                lblock.getBlock(), lblock.getBlock(),
                                lblock.getLocations(), ReportCond.NEVER,
                                blockLength, bb);
                    } catch (Exception e) {
                        LOG.log(Level.WARNING,
                                "replicate block "
                                        + lblock.getBlock()
                                        + " to "
                                        + Arrays.toString(lblock.getLocations())
                                        + " failed", e);
                    } finally {
                        if (bb != null) {
                            directByteBufferPool.release(bb);
                        }
                        dataNode.metrics.decrement(DataNodeMetricsItem.CONCURRENT_REPLICATION);
                    }
                    // prepare return value, lblock.locations should contain
                    // actual nodes transfered to
                    String[] locs = successCount < lblock.getLocations().length ? Arrays.copyOf(
                            lblock.getLocations(), successCount)
                            : lblock.getLocations();
                    BlockSizeLocationWithDataPath slblock = new BlockSizeLocationWithDataPath(
                            lblock.getBlock(), blockLength.intValue(), locs);
                    unreportedBlocks.offer(slblock);
                    replicationDone();
                } catch (Throwable e) {
                    tr.gotThrowable(e);
                }
        }

        public TransferWorker(int index) {
            super(dataNode.fullName + "-Transfer-Worker-" + index);
            setDaemon(true);
        }
    }
}
