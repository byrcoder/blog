/**
 * @(#)BackupFSEditLogger.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.JournalManager;
import odis.dfs.util.DfsUtils;

import org.apache.commons.configuration.Configuration;

/**
 * @author zhangduo
 */
class BackupFSEditLogger extends AbstractFSEditLogger {

    BackupFSEditLogger(Configuration conf) {
        super(DfsUtils.createFromConf(conf.getString(
                DFSConfig.JOURNAL_MANAGER_CLASS,
                DFSConfig.DEFAULT_JOURNAL_MANAGER_CLASS), conf,
                JournalManager.class));
    }
}
