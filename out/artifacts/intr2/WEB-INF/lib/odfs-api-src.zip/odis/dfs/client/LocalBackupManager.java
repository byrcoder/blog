/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar, 2006
 */
package odis.dfs.client;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * A process-wide Manager for the local backups. MemoryLocalBackups will be used
 * first. Up to a configurable maximum number (see
 * {@link #setMaxMemoryBackup(int)}) of MemoryLocalBackups can be used at the
 * same time, then FileLocalBackups will be used.
 * 
 * @author river
 */
public class LocalBackupManager {
    private static LocalBackupManager instance = new LocalBackupManager();

    public static final int DEFAULT_MAX_MEMORY_BACKUP = 2;

    private static volatile int MAX_MEMORY_BACKUP = DEFAULT_MAX_MEMORY_BACKUP;

    private static volatile boolean useFileBackup = false;

    private static String tempRoot = null;

    private final List<WeakReference<MemoryLocalBackup>> cache = new LinkedList<WeakReference<MemoryLocalBackup>>();

    private final List<WeakReference<MemoryLocalBackup>> workSpace = new LinkedList<WeakReference<MemoryLocalBackup>>();

    public static LocalBackupManager getInstance() {
        return instance;
    }

    private LocalBackupManager() {}

    public static void setTempRoot(String value) {
        tempRoot = value;
    }

    /**
     * Set the maximum allowable memory backups. Default value is
     * {@link #DEFAULT_MAX_MEMORY_BACKUP}.
     * 
     * @param value
     */
    public static void setMaxMemoryBackup(int value) {
        MAX_MEMORY_BACKUP = value;
    }

    /**
     * Set to true to disable memory backup and use file backup only.
     * 
     * @param value
     */
    public static void setUseFileBackup(boolean value) {
        useFileBackup = value;
    }

    public static void resetTempRoot() {
        useFileBackup = false;
        tempRoot = null;
    }

    private LocalBackup createFileBackup() throws IOException {
        File dir = (tempRoot == null ? null : new File(tempRoot));
        if (dir != null) {
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IOException("Cannot create tmp dir : "
                        + dir.getAbsolutePath());
            }
        }
        return new FileLocalBackup(dir);
    }

    /**
     * Acquire one backup object.
     * 
     * @return the new backup object
     * @throws IOException
     */
    public synchronized LocalBackup getBackup() throws IOException {
        if (useFileBackup) {
            return createFileBackup();
        }
        MemoryLocalBackup backup = null, temp;
        WeakReference<MemoryLocalBackup> ref = null;

        for (Iterator<WeakReference<MemoryLocalBackup>> it = cache.iterator(); it.hasNext();) {
            ref = it.next();
            temp = ref.get();
            if (temp == null) {
                it.remove();
            } else {
                if (backup == null) {
                    backup = temp;
                    it.remove();
                    break;
                }
            }
        }

        if (backup != null) {
            workSpace.add(ref);
            return backup;
        }

        for (Iterator<WeakReference<MemoryLocalBackup>> it = workSpace.iterator(); it.hasNext();) {
            if (it.next().get() == null) {
                it.remove();
            }
        }

        if (workSpace.size() >= MAX_MEMORY_BACKUP) {
            return createFileBackup();
        } else {
            backup = new MemoryLocalBackup();
            workSpace.add(new WeakReference<MemoryLocalBackup>(backup));
            return backup;
        }
    }

    /**
     * Release one backup object.
     * 
     * @param backup
     * @throws IOException
     */
    public synchronized void releaseBackup(LocalBackup backup)
            throws IOException {
        backup.discard();
        if (useFileBackup) {
            return;
        }

        WeakReference<MemoryLocalBackup> ref;
        for (Iterator<WeakReference<MemoryLocalBackup>> it = workSpace.iterator(); it.hasNext();) {
            ref = it.next();
            if (ref.get() == backup) {
                it.remove();
                cache.add(ref);
                return;
            } else if (ref.get() == null) {
                it.remove();
            }
        }

        if (backup instanceof MemoryLocalBackup) {
            cache.add(new WeakReference<MemoryLocalBackup>(
                    (MemoryLocalBackup) backup));
        }

    }

    public synchronized void clear() {
        cache.clear();
        workSpace.clear();
    }

}
