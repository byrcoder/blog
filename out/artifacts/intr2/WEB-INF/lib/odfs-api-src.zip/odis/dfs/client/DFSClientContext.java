/**
 * @(#)DFSClientContext.java, 2011-8-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import odis.conf.OdisClientContext;
import odis.conf.OdisLibConfig;
import odis.io.FileSystem;

import org.apache.commons.configuration.BaseConfiguration;
import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;

/**
 * Helper class for loading dfs client configuration from xxx-site.xml.
 * 
 * @author zhangduo
 */
public class DFSClientContext extends OdisClientContext {

    private static final class DFSClientTransferConfig extends
            CompositeConfiguration {

        private String instanceName;

        private int instanceIdx;

        public DFSClientTransferConfig(Configuration conf, String instanceName,
                int instanceIdx) {
            super(conf);
            this.instanceName = instanceName;
            this.instanceIdx = instanceIdx;
        }

        @Override
        protected void addPropertyDirect(String key, Object value) {
            super.addPropertyDirect("app.instance(" + instanceIdx + ").dfs."
                    + key, value);
        }

        @Override
        public Object getProperty(String key) {
            return super.getProperty("app.instance(" + instanceIdx + ").dfs."
                    + key);
        }

        @Override
        public String toString() {
            return "DFSClientConfig [instanceName=" + instanceName
                    + ", instanceIdx=" + instanceIdx + "]";
        }

    }

    private static final Map<String, FileSystem> NAME_TO_FS = new ConcurrentHashMap<String, FileSystem>();

    static Configuration getConf(String instanceName) {
        if (instanceName == null || instanceName.equals("null")) {
            return new BaseConfiguration();
        }
        Integer instanceIdx = instanceMap.get(instanceName);
        if (instanceIdx == null) {
            return new BaseConfiguration();
        }
        return new DFSClientTransferConfig(OdisLibConfig.conf(), instanceName,
                instanceIdx);
    }

    /**
     * Return the default file system setting in configuration.
     * 
     * @return the default file system instance
     * @throws IOException
     */
    public static FileSystem getDefaultFileSystem() throws IOException {
        return getNamed(getDefaultApp(), true);
    }

    public static FileSystem getNamed(String instanceName, boolean reuse)
            throws IOException {
        FileSystem fs = reuse ? NAME_TO_FS.get(instanceName) : null;
        if (fs == null) {
            Configuration conf = getConf(instanceName);
            String fsName = conf.getString("address", "local");
            fs = FileSystem.getNamed(fsName, false, conf);
            NAME_TO_FS.put(instanceName, fs);
        }
        return fs;

    }
}
