package odis.dfs.journal.qjournal.server;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.dfs.metrics.JournalNodeMetricsItem;

import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.apache.velocity.tools.view.VelocityViewServlet;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.collections.Pair;
import toolbox.text.util.StringUtils;

public class JournalNodeInspectorServlet extends VelocityViewServlet {

    private static final long serialVersionUID = -2390101058500714108L;

    static JournalNode jn;

    private static enum RequestType {
        HOME, JN_METRICS
    }

    private final DateTimeFormatter fullDateTimeFormatter = DateTimeFormat
            .fullDateTime();

    private RequestType getRequestType(HttpServletRequest request) {
        String cmd = request.getServletPath();
        if (cmd == null) {
            return RequestType.HOME;
        }
        cmd = org.apache.commons.lang.StringUtils.strip(cmd, "/");
        if (cmd.endsWith("jn_metrics.s")) {
            return RequestType.JN_METRICS;
        } else {
            return RequestType.HOME;
        }
    }

    private void doHome(Context ctx, HttpServletRequest req) {
        long currentTime = System.currentTimeMillis();
        ctx.put("systime", fullDateTimeFormatter.print(currentTime));
        
        ctx.put("rpcPort", jn.getRpcPort());
        ctx.put("httpPort", jn.getHttpPort());
        ctx.put("baseDir", jn.getBaseDir());
        
        try {
            ctx.put("lastPromisedEpoch", jn.getLastPromisedEpoch());
        } catch (Exception e) {
            ctx.put("lastPromisedEpoch", "N/A");
        }
        try {
            ctx.put("lastWriterEpoch", jn.getLastWriterEpoch());
        } catch (Exception e) {
            ctx.put("lastWriterEpoch", "N/A");
        }
        
        ctx.put("currentSN", jn.getFileJM().getCurrentSN());
        ctx.put("isSegOpen", jn.getFileJM().isSegmentOpened());
        
        ctx.put("content", "home.vm");
    }

    private void doJournalNodeMetrics(Context ctx, HttpServletRequest req) {
        ctx.put("jnname", jn.toString());
        long[] metricsRecords = jn.getJournalNodeMetricsRecords();
        List<Pair<JournalNodeMetricsItem, String>> metrics = new ArrayList<Pair<JournalNodeMetricsItem, String>>(
                metricsRecords.length);
        for (JournalNodeMetricsItem item: JournalNodeMetricsItem.values()) {
            String value;
            if (item == JournalNodeMetricsItem.SYSTEM_LOAD) {
                value = String.format("%.2f",
                        (double) metricsRecords[item.offset()] / 100);
            } else if (item.name().startsWith("HEAP_")
                    || item.name().startsWith("NON_HEAP_")
                    || item.name().endsWith("_SIZE")
                    || item.name().endsWith("_BYTES")) {
                long size = metricsRecords[item.offset()];
                value = Long.toString(size) + "(" + StringUtils.byteDesc(size)
                        + ")";
            } else if (item.name().endsWith("_DELAY")) {
                value = metricsRecords[item.offset()] + "ms";
            } else {
                value = Long.toString(metricsRecords[item.offset()]);
            }
            metrics.add(new Pair<JournalNodeMetricsItem, String>(item, value));
        }
        ctx.put("metrics", metrics);
        ctx.put("content", "jn-metrics.vm");
    }

    @Override
    protected void fillContext(Context context, HttpServletRequest request) {
        RequestType reqType = getRequestType(request);
        context.put("cmd", reqType.name());
        switch (reqType) {
            case HOME:
                doHome(context, request);
                break;
            case JN_METRICS:
                doJournalNodeMetrics(context, request);
                break;
        }
    }

    @Override
    protected Template getTemplate(HttpServletRequest request,
            HttpServletResponse response) {
        return getTemplate("template.vm");
    }
}
