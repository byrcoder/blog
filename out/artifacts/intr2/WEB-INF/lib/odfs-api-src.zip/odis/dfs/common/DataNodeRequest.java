/**
 * @(#)DataNodeRequest.java, 2008-12-17. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * Now only WRITE_BLOCK, READ_BLOCK and TRANSFER_BLOCK is used.
 * <p>
 * READ_BLOCK request will have a ReadBlockBody, there are two situations: <br>
 * 1. maxLength = 0, this means we will read all the block data start from
 * offset, we will use a thread to handle the request.<br>
 * 2. maxLength > 0, this means we only read maxLength bytes start from offset.
 * You can only send request of this type to DataRandomAccessWorker's port.
 * <p>
 * WRITE_BLOCK request will have a WriteBlockBody, there are three situations: <br>
 * 1. reportCond=ALWAYS, always report the block to namenode unless checksum
 * error. This is used for persistent files. Persistent file usually used as log
 * file, so you should not use local backup, you should close the old file and
 * open a new file if error occurred(consider this situation: datanode crash,
 * client abandon the block, and before client recover using local backup,
 * client crash.)<br>
 * 2. reportCond=ON_COMPLETION, report the block to namenode only if we have got
 * completed data. This is the common situation, client will abandon an
 * uncompleted block and recover using local backup.Inter-DFS transfer also use
 * this reportCond.<br>
 * 3. reportCond=NEVER, never report the block to namenode. This is used when
 * doing replication, the source datanode will report block locations to
 * namenode using replicationDone.
 * <p>
 * TRANSFER_BLOCK request will have a TransferBlockBody body.
 * 
 * @author zhangkun, zhangduo
 */
public class DataNodeRequest implements IWritable {
    // Client-DataNode protocol version 2 is used on ODFS 4.0 and later
    public static final int VERSION = 2;

    public static enum Op {
        // Write a block.
        WRITE_BLOCK((byte) 70, WriteBlockBody.class),
        // Read a block
        READ_BLOCK((byte) 71, ReadBlockBody.class),
        // Read block from local an replicate it to some other datanodes.
        // This is only used at cross odfs block transfer.
        TRANSFER_BLOCK((byte) 72, TransferBlockBody.class);

        private final byte code;

        public final Class<? extends Body> bodyClass;

        private static final Map<Byte, Op> codeMap = new HashMap<Byte, Op>();

        private Op(byte code, Class<? extends Body> bodyClass) {
            this.code = code;
            this.bodyClass = bodyClass;
        }

        static {
            for (Op op: Op.values()) {
                codeMap.put(op.code, op);
            }
        }

        public static Op valueOf(int code) {
            return codeMap.get((byte) code);
        }
    }

    public static enum ReportCond {
        NEVER((byte) 1), ON_COMPLETION((byte) 2), ALWAYS((byte) 3);
        private final byte code;

        private ReportCond(byte code) {
            this.code = code;
        }

        private static final Map<Byte, ReportCond> codeMap = new HashMap<Byte, ReportCond>();
        static {
            for (ReportCond cond: ReportCond.values()) {
                codeMap.put(cond.code, cond);
            }
        }

        public static ReportCond valueOf(int code) {
            return codeMap.get((byte) code);
        }
    }

    protected Op op;

    protected Body body;

    public DataNodeRequest() {}

    public DataNodeRequest(Op op) {
        this.op = op;
        try {
            this.body = op.bodyClass.newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Body getBody() {
        return body;
    }

    public Op getOp() {
        return op;
    }

    @Override
    public int hashCode() {
        if (body == null) {
            return op.hashCode();
        } else {
            return op.hashCode() ^ body.hashCode();
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DataNodeRequest other = (DataNodeRequest) o;
        if (this.op != other.op) {
            return false;
        }
        if (this.body == null) {
            if (other.body != null) {
                return false;
            }
        } else {
            if (!this.body.equals(other.body)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Read and check the version byte from input
     * 
     * @param in
     * @return
     */
    public int readVersionByte(DataInput in) throws IOException {
        return in.readByte() & 0xFF;
    }

    /**
     * Read the main fields (excluding the version byte) from input
     * 
     * @param in
     * @throws IOException
     */
    public void readMainFields(DataInput in) throws IOException {
        int opCode = in.readByte() & 0xFF;
        op = Op.valueOf(opCode);
        if (op == null) {
            throw new IOException("Faulty op code: " + opCode);
        }
        if (body == null || !body.getClass().equals(op.bodyClass)) {
            try {
                body = op.bodyClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        body.readFields(in);
    }

    public void readFields(DataInput in) throws IOException {
        int ver = readVersionByte(in);
        if (ver != VERSION) {
            throw new IOException("Incompatible version, read " + ver
                    + ", expected " + VERSION);
        }
        readMainFields(in);
    }

    public void writeFields(DataOutput out) throws IOException {
        out.write(VERSION);
        out.write(op.code);
        body.writeFields(out);
    }

    public IWritable copyFields(IWritable value) {
        DataNodeRequest src = (DataNodeRequest) value;
        this.op = src.op;
        if (body == null || !body.getClass().equals(op.bodyClass)) {
            try {
                body = op.bodyClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        body.copyFields(src.body);
        return this;
    }

    @Override
    public String toString() {
        return "[" + DataNodeRequest.class.getSimpleName() + " op=" + op
                + " body=" + body + "]";
    }

    /**
     * The request body contains request-specific information
     * 
     * @author zhangkun
     */
    public static interface Body extends IWritable {
    }

    public static class ReadBlockBody implements Body {
        private long block;

        private int offset;

        private int maxLength = 0;

        /**
         * version(1) + op(1) + block(8) + offset(4) + maxLength(4)
         * 
         * @return
         */
        public static int writableByteLength() {
            return 18;
        }

        public void setBlock(long block) {
            this.block = block;
        }

        public void setOffset(int offset) {
            this.offset = offset;
        }

        /**
         * To tell DataNode the maximum length of data that the client needs.
         * DataNode will not send more than the given length (but may be less).
         * equal to or less than 0 means unlimited.
         * 
         * @param length
         */
        public void setMaxLength(int length) {
            this.maxLength = length;
        }

        public int getMaxLength() {
            return maxLength;
        }

        public long getBlock() {
            return block;
        }

        public int getOffset() {
            return offset;
        }

        public void readFields(DataInput in) throws IOException {
            block = in.readLong();
            offset = in.readInt();
            maxLength = in.readInt();
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(block);
            out.writeInt(offset);
            out.writeInt(maxLength);
        }

        public IWritable copyFields(IWritable value) {
            ReadBlockBody src = (ReadBlockBody) value;
            this.block = src.block;
            this.offset = src.offset;
            this.maxLength = src.maxLength;
            return this;
        }

        public void readFields(ByteBuffer buffer) {
            block = buffer.getLong();
            offset = buffer.getInt();
            maxLength = buffer.getInt();
        }

        @Override
        public int hashCode() {
            return (int) (block ^ (block >>> 32)) ^ maxLength ^ offset;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            ReadBlockBody other = (ReadBlockBody) o;
            return this.block == other.block && this.offset == other.offset
                    && this.maxLength == other.maxLength;
        }

        @Override
        public String toString() {
            return "[" + ReadBlockBody.class.getSimpleName() + " block="
                    + block + " offset=" + offset + " maxLength=" + maxLength
                    + "]";
        }
    }

    public static class WriteBlockBody implements Body {
        private long block;

        private String[] targets;

        private ReportCond reportCond;

        public void setReportCond(ReportCond cond) {
            this.reportCond = cond;
        }

        public void setBlock(long block) {
            this.block = block;
        }

        public void setTargets(String[] targets) {
            this.targets = targets;
        }

        public ReportCond getReportCond() {
            return this.reportCond;
        }

        public long getBlock() {
            return block;
        }

        public String[] getTargets() {
            return targets;
        }

        public void readFields(DataInput in) throws IOException {
            int reportCondCode = in.readByte() & 0xFF;
            reportCond = ReportCond.valueOf(reportCondCode);
            if (reportCond == null) {
                throw new IOException("invalid ReportCond code "
                        + reportCondCode);
            }
            block = in.readLong();
            int numTargets = in.readInt();
            if (numTargets > FSConstants.MAX_BLOCK_TARGET_NUM) {
                throw new IOException(
                        "Mislabelled incoming datastream. numTargets = "
                                + numTargets);
            }
            targets = new String[numTargets];
            for (int i = 0; i < numTargets; i++) {
                targets[i] = StringWritable.readString(in);
            }
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeByte(reportCond.code);
            out.writeLong(block);
            out.writeInt(targets.length);
            for (String target: targets) {
                StringWritable.writeString(out, target);
            }
        }

        public IWritable copyFields(IWritable value) {
            WriteBlockBody src = (WriteBlockBody) value;
            this.reportCond = src.reportCond;
            this.block = src.block;
            this.targets = new String[src.targets.length];
            System.arraycopy(src.targets, 0, this.targets, 0,
                    this.targets.length);
            return this;
        }

        @Override
        public String toString() {
            return "[" + WriteBlockBody.class.getSimpleName() + " block="
                    + block + " targets=" + Arrays.toString(targets)
                    + " reportCond=" + reportCond + "]";
        }

        @Override
        public int hashCode() {
            return (int) (block ^ (block >>> 32)) ^ Arrays.hashCode(targets)
                    ^ reportCond.hashCode();
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            WriteBlockBody other = (WriteBlockBody) o;
            return this.block == other.block
                    && this.reportCond == other.reportCond
                    && Arrays.equals(this.targets, other.targets);
        }
    }

    public static class TransferBlockBody implements Body {
        private long srcBlock;

        private long destBlock;

        private String[] targets;

        public void setSrcBlock(long block) {
            this.srcBlock = block;
        }

        public void setDestBlock(long block) {
            this.destBlock = block;
        }

        public void setTargets(String[] targets) {
            this.targets = targets;
        }

        public long getSrcBlock() {
            return srcBlock;
        }

        public long getDestBlock() {
            return destBlock;
        }

        public String[] getTargets() {
            return targets;
        }

        public void readFields(DataInput in) throws IOException {
            srcBlock = in.readLong();
            destBlock = in.readLong();
            int numTargets = in.readInt();
            if (numTargets > FSConstants.MAX_BLOCK_TARGET_NUM) {
                throw new IOException(
                        "Mislabelled incoming datastream. numTargets = "
                                + numTargets);
            }
            targets = new String[numTargets];
            for (int i = 0; i < numTargets; i++) {
                targets[i] = StringWritable.readString(in);
            }
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(srcBlock);
            out.writeLong(destBlock);
            out.writeInt(targets.length);
            for (String target: targets) {
                StringWritable.writeString(out, target);
            }
        }

        public IWritable copyFields(IWritable value) {
            TransferBlockBody src = (TransferBlockBody) value;
            this.srcBlock = src.srcBlock;
            this.destBlock = src.destBlock;
            this.targets = new String[src.targets.length];
            System.arraycopy(src.targets, 0, this.targets, 0,
                    this.targets.length);
            return this;
        }

        @Override
        public String toString() {
            return "[" + TransferBlockBody.class.getSimpleName() + " srcBlock="
                    + srcBlock + " destBlock=" + destBlock + " targets="
                    + Arrays.toString(targets) + "]";
        }

        @Override
        public int hashCode() {
            long xor = srcBlock ^ destBlock;
            return (int) (xor ^ (xor >>> 32)) ^ Arrays.hashCode(targets);
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            TransferBlockBody other = (TransferBlockBody) o;
            return this.destBlock == other.destBlock
                    && this.srcBlock == other.srcBlock
                    && Arrays.equals(this.targets, other.targets);
        }
    }
}
