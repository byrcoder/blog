/**
 * @(#)DelayedCheckBlockQueue.java, 2012-12-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.Arrays;

import toolbox.collections.primitive.LongIntegerCompactHashMap;

/**
 * @author zhangduo
 */
class DelayedCheckBlockQueue {

    private static final int DEFAULT_INITIAL_CAPACITY = 11;

    private static final int INDEX_NOT_EXISTS = -1;

    private int size;

    private long[] blocks = new long[DEFAULT_INITIAL_CAPACITY];

    private long[] checkTimes = new long[DEFAULT_INITIAL_CAPACITY];

    private final LongIntegerCompactHashMap block2Index = new LongIntegerCompactHashMap(
            DEFAULT_INITIAL_CAPACITY);

    private void grow(int minCapacity) {
        int oldCapacity = blocks.length;
        // Double size if small; else grow by 50%
        int newCapacity = ((oldCapacity < 64) ? ((oldCapacity + 1) * 2)
                : ((oldCapacity / 2) * 3));
        if (newCapacity < minCapacity) {
            newCapacity = minCapacity;
        }
        blocks = Arrays.copyOf(blocks, newCapacity);
        checkTimes = Arrays.copyOf(checkTimes, newCapacity);
    }

    private int compare(long block1, long checkTime1, long block2,
            long checkTime2) {
        if (checkTime1 < checkTime2) {
            return -1;
        }
        if (checkTime1 > checkTime2) {
            return 1;
        }
        return block1 < block2 ? -1 : block1 == block2 ? 0 : 1;
    }

    private void siftUp(int k, long block, long checkTime) {
        while (k > 0) {
            int parent = (k - 1) >>> 1;
            long block2 = blocks[parent];
            long checkTime2 = checkTimes[parent];
            if (compare(block, checkTime, block2, checkTime2) >= 0) {
                break;
            }
            blocks[k] = block2;
            checkTimes[k] = checkTime2;
            block2Index.put(block2, k, INDEX_NOT_EXISTS);
            k = parent;
        }
        blocks[k] = block;
        checkTimes[k] = checkTime;
        block2Index.put(block, k, INDEX_NOT_EXISTS);
    }

    private void siftDown(int k, long block, long checkTime) {
        int half = size >>> 1; // loop while a non-leaf
        while (k < half) {
            int child = (k << 1) + 1; // assume left child is least
            long block2 = blocks[child];
            long checkTime2 = checkTimes[child];
            int right = child + 1;
            if (right < size
                    && compare(block2, checkTime2, blocks[right],
                            checkTimes[right]) > 0) {
                child = right;
                block2 = blocks[child];
                checkTime2 = checkTimes[child];
            }
            if (compare(block, checkTime, block2, checkTime2) <= 0) {
                break;
            }
            blocks[k] = block2;
            checkTimes[k] = checkTime2;
            block2Index.put(block2, k, INDEX_NOT_EXISTS);
            k = child;
        }
        blocks[k] = block;
        checkTimes[k] = checkTime;
        block2Index.put(block, k, INDEX_NOT_EXISTS);
    }

    void addIfAbsent(long block, long checkTime) {
        int index = block2Index.get(block, INDEX_NOT_EXISTS);
        if (index != INDEX_NOT_EXISTS) {
            return;
        }
        int i = size;
        if (i >= blocks.length) {
            grow(i + 1);
        }
        size = i + 1;
        if (i == 0) {
            blocks[0] = block;
            checkTimes[0] = checkTime;
            block2Index.put(block, 0, INDEX_NOT_EXISTS);
        } else {
            siftUp(i, block, checkTime);
        }
    }

    void remove(long block) {
        int index = block2Index.remove(block, INDEX_NOT_EXISTS);
        if (index == INDEX_NOT_EXISTS) {
            return;
        }
        int s = --size;
        if (s == index) { // remove last element
            return;
        }
        long movedBlock = blocks[s];
        long movedCheckTime = checkTimes[s];
        siftDown(index, movedBlock, movedCheckTime);
        if (blocks[index] == movedBlock) {
            siftUp(index, movedBlock, movedCheckTime);
        }
    }

    static class CheckEntry {
        long block;

        long checkTime;
    }

    boolean peek(CheckEntry entry) {
        if (size == 0) {
            return false;
        }
        entry.block = blocks[0];
        entry.checkTime = checkTimes[0];
        return true;
    }

    void removeHead() {
        block2Index.remove(blocks[0], INDEX_NOT_EXISTS);
        int s = --size;
        if (s != 0) {
            long movedBlock = blocks[s];
            long movedCheckTime = checkTimes[s];
            siftDown(0, movedBlock, movedCheckTime);
        }
    }

    int size() {
        return size;
    }

}
