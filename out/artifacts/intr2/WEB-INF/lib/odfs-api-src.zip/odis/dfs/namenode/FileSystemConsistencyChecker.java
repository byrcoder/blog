/**
 * @(#)FileSystemConsistencyChecker.java, 2012-12-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import odis.io.ReadWriteUtils;
import odis.util.KeyValueIterator;
import toolbox.collections.primitive.LongCompactHashSet;

/**
 * @author zhangduo
 */
class FileSystemConsistencyChecker<FSB extends AbstractFSBlockStore> {

    private final AbstractFSDirectory<FSB> dir;

    private final FSB bstore;

    private final File reportFile;

    private final LongCompactHashSet visitedBlocks = new LongCompactHashSet();

    private final Set<String> checkedLinkFiles = new HashSet<String>();

    private PrintWriter writer;

    private long dirCount;

    private long fileCount;

    private long missingBlockFileCount;

    private long missingBlockCount;

    private long garbageBlockCount;

    private long[] blockCountsWithDifferentReplications = new long[4];

    FileSystemConsistencyChecker(AbstractFSDirectory<FSB> dir, FSB bstore,
            File reportFile) {
        this.dir = dir;
        this.bstore = bstore;
        this.reportFile = reportFile;
    }

    private void checkINode(StringBuilder parentPath, String name, INode node) {
        if (parentPath.length() == 1) {
            parentPath.append(name);
        } else {
            parentPath.append(INode.SEP).append(name);
        }
        if (node instanceof DirectoryINode) {
            dirCount++;
            for (KeyValueIterator<UTF8String, INode> iter = ((DirectoryINode) node).iterator(); iter.hasNext();) {
                iter.next();
                checkINode(parentPath, iter.getKey().toString(),
                        iter.getValue());
            }
        } else if (node instanceof FileINode) {
            if (node.getRefCount() > 1
                    && !checkedLinkFiles.add(parentPath.toString())) {
                return;
            }
            fileCount++;
            boolean error = false;
            for (long block: ((FileINode) node).getBlocks()) {
                visitedBlocks.add(block);
                PlacedBlock pb = bstore.activeBlocks.get(block);
                if (pb != null && pb.getLocs().length > 0) {
                    continue;
                }
                if (!error) {
                    writer.println("MISSING BLOCK FILE: " + parentPath);
                    missingBlockFileCount++;
                    error = true;
                }
                missingBlockCount++;
                writer.print("\t" + block);
                if (pb == null) {
                    writer.println("(not found)");
                } else {
                    writer.println("(orphan)");
                }
            }
        }
        parentPath.setLength(Math.max(1, parentPath.length() - name.length()
                - 1));
    }

    private void checkFiles() {
        StringBuilder path = new StringBuilder("/");
        for (KeyValueIterator<UTF8String, INode> iter = dir.rootDir.iterator(); iter.hasNext();) {
            iter.next();
            checkINode(path, iter.getKey().toString(), iter.getValue());
        }
    }

    private void checkBlocks() {
        for (PlacedBlock pb: bstore.activeBlocks.values()) {
            if (!visitedBlocks.contains(pb.getId())) {
                garbageBlockCount++;
                writer.println("GARBAGE BLOCK: " + pb.getId());
            }
            blockCountsWithDifferentReplications[Math.min(pb.getLocs().length,
                    3)]++;
        }
    }

    private void outputSummary() {
        writer.println("-------------- Summary --------------");
        writer.println("Directories: " + dirCount);
        writer.println("Files: " + fileCount);
        writer.println("Missing block files: " + missingBlockFileCount);
        writer.println("Active blocks: " + bstore.activeBlocks.size());
        writer.println("\tGarbage blocks: " + garbageBlockCount);
        writer.println("\tMissing blocks: " + missingBlockCount);
        for (int i = 0; i < blockCountsWithDifferentReplications.length; i++) {
            writer.println("Blocks with "
                    + i
                    + (i == blockCountsWithDifferentReplications.length - 1 ? " or more"
                            : "") + " replica(s): "
                    + blockCountsWithDifferentReplications[i]);
        }
    }

    void fsck() throws IOException {
        writer = new PrintWriter(reportFile);
        try {
            checkFiles();
            checkBlocks();
            outputSummary();
        } finally {
            ReadWriteUtils.safeClose(writer);
        }
    }
}
