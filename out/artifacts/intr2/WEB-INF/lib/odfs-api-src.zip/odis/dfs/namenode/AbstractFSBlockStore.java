/**
 * @(#)AbstractFSBlockStore.java, 2012-12-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.Closeable;
import java.util.Map;

/**
 * @author zhangduo
 */
abstract class AbstractFSBlockStore implements Closeable {

    protected final Map<Long, PlacedBlock> blockMap;

    protected final Map<Long, PlacedBlock> activeBlocks;

    protected AbstractFSBlockStore(Map<Long, PlacedBlock> blockMap,
            Map<Long, PlacedBlock> activeBlocks) {
        this.blockMap = blockMap;
        this.activeBlocks = activeBlocks;
    }

    void addActiveBlock(long block, int len, int desiredReplications) {
        PlacedBlock pb = new PlacedBlock(block, len, desiredReplications);
        activeBlocks.put(block, pb);
    }

    void addBlock(long block, int len, int desiredReplications) {
        PlacedBlock pb = new PlacedBlock(block, len, desiredReplications);
        blockMap.put(block, pb);
    }

    void activateBlock(long block) throws IllegalStateException {
        PlacedBlock pb = blockMap.remove(block);
        if (pb == null) {
            throw new IllegalStateException("Block " + block
                    + " not found when trying to active it.");
        }
        activeBlocks.put(block, pb);
    }

    void removeBlock(long blockId) {
        if (activeBlocks.remove(blockId) == null) {
            blockMap.remove(blockId);
        }
    }

    /**
     * Only used when save image.
     * 
     * @param blockId
     * @return
     */
    int getBlockLen(long blockId) {
        PlacedBlock pb = activeBlocks.get(blockId);
        if (pb != null) {
            return pb.getLen();
        }
        pb = blockMap.get(blockId);
        return pb != null ? pb.getLen() : 0;
    }

    abstract void changeReplication(long[] blocks, int replications);

    public abstract void close();
}
