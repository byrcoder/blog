/**
 * @(#)BackupFSBlockStore.java, 2012-12-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import odis.dfs.common.BlockSize;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.DataNodeExpireException;
import odis.dfs.common.FSConstants;
import odis.dfs.namenode.ActiveFSBlockStore.PendingBlockChecker;

import org.apache.commons.configuration.Configuration;

import toolbox.collections.Pair;
import toolbox.collections.primitive.LongArrayList;

/**
 * @author zhangduo
 */
class BackupFSBlockStore extends AbstractPrimaryFSBlockStore {

    BackupFSBlockStore(long volume) {
        super(volume, new HashMap<Long, PlacedBlock>(),
                new HashMap<Long, PlacedBlock>(),
                new HashMap<String, String>(),
                new ConcurrentHashMap<String, DatanodeInfo>(),
                new ConcurrentHashMap<String, DatanodeInfo>());
    }

    ActiveFSBlockStore upgrade(Configuration conf,
            PendingBlockChecker pendingBlockChecker) {
        return new ActiveFSBlockStore(conf, pendingBlockChecker, volume,
                blockMap, activeBlocks, datanodeHBMap, datanodeMap,
                deadDatanodeMap);
    }

    @Override
    void addBlock(long block, int len, int desiredReplications) {
        synchronized (blockMap) {
            PlacedBlock pb = blockMap.get(block);
            if (pb != null) {
                // datanode may report block before we loadFSEdits
                synchronized (pb) {
                    if (len > 0) {
                        pb.setLen(len);
                    }
                    pb.setDesiredReplication(desiredReplications);
                }
                return;
            }
            blockMap.put(block,
                    new PlacedBlock(block, len, desiredReplications));
        }
    }

    @Override
    protected DataNodeCommand[] getDataNodeCommands(DatanodeInfo dinfo) {
        return DataNodeCommand.EMPTY_ARRAY;
    }

    @Override
    protected void datanodeAdded(DatanodeInfo dinfo) {}

    @Override
    protected void datanodeDied(DatanodeInfo dinfo) {
        long[] deadBlocks = dinfo.getBlocks();
        for (long block: deadBlocks) {
            PlacedBlock pb = getBlock(block);
            if (pb != null) {
                synchronized (pb) {
                    pb.removeLoc(dinfo);
                }
            }
        }
    }

    private PlacedBlock getOrCreatePlaceBlock(long block, int len) {
        PlacedBlock pb;
        synchronized (blockMap) {
            pb = activeBlocks.get(block);
            if (pb == null) {
                pb = blockMap.get(block);
            }
            if (pb == null) {
                pb = new PlacedBlock(block, len,
                        FSConstants.DEFAULT_NUM_REPLICAS);
                blockMap.put(block, pb);
            }
            return pb;
        }
    }

    @Override
    void datanodeBlockReport(String datanodeFullName, BlockSize[] blocks) {
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo = datanodeMap.get(datanodeName);
        if (dinfo == null) {
            throw new DataNodeExpireException(
                    "Your information is expired, please reconnect");
        }
        Pair<List<BlockSize>, LongArrayList> pair = dinfo.getDiff(blocks);
        // new blocks
        for (BlockSize block: pair.getFirst()) {
            PlacedBlock pb = getOrCreatePlaceBlock(block.getBlock(),
                    block.getLen());
            synchronized (pb) {
                pb.addLoc(dinfo);
            }
            dinfo.addBlock(block.getBlock());
        }
        // missed block
        long[] missedBlocks = pair.getSecond().toArray();
        dinfo.removeBlocks(missedBlocks);
        for (long block: missedBlocks) {
            PlacedBlock pb = getBlock(block);
            if (pb != null) {
                synchronized (pb) {
                    pb.removeLoc(dinfo);
                }
            }
        }
    }

    @Override
    void datanodeReportBlockReceivedOrDeleted(String datanodeFullName,
            BlockSize[] received, long[] deleted) {
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo = datanodeMap.get(datanodeName);
        if (dinfo == null) {
            throw new DataNodeExpireException(
                    "Your information is expired, please reconnect");
        }
        for (BlockSize block: received) {
            PlacedBlock pb = getOrCreatePlaceBlock(block.getBlock(),
                    block.getLen());
            synchronized (pb) {
                pb.addLoc(dinfo);
            }
            dinfo.addBlock(block.getBlock());
        }
        dinfo.removeBlocks(deleted);
    }

    @Override
    void datanodeReplicationDone(String datanodeFullName,
            BlockSizeLocationWithDataPath lblock) {
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo = datanodeMap.get(datanodeName);
        if (dinfo == null) {
            throw new DataNodeExpireException(
                    "Your information is expired, please reconnect");
        }
        String[] locs = lblock.getLocations();
        if (lblock.getLen() == -1) {
            // this means the datanode do not have this block.
            return;
        }
        PlacedBlock pb = getOrCreatePlaceBlock(lblock.getBlock(),
                lblock.getLen());
        synchronized (pb) {
            pb.addLoc(dinfo);
        }
        synchronized (pb) {
            for (String loc: locs) {
                DatanodeInfo target = datanodeMap.get(DatanodeInfo.getDatanodeNameFromFullName(loc));
                if (target != null) {
                    pb.addLoc(target);
                }
            }
        }
    }

    @Override
    void changeReplication(long[] blocks, int replications) {
        for (long block: blocks) {
            PlacedBlock pb = getBlock(block);
            if (pb != null) {
                synchronized (pb) {
                    pb.setDesiredReplication(replications);
                }
            }
        }
    }

    @Override
    public void close() {}
}
