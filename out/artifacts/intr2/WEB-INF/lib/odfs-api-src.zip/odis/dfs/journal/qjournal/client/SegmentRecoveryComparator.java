package odis.dfs.journal.qjournal.client;

import java.util.Comparator;
import java.util.Map.Entry;

import odis.dfs.journal.qjournal.IQJournalProtocol.PrepareRecoveryResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.SegmentState;

import com.google.common.primitives.Booleans;
import com.google.common.primitives.Longs;

/**
 * Compares responses to the prepareRecovery RPC. This is responsible for
 * determining the correct length to recover.
 */
public class SegmentRecoveryComparator implements
        Comparator<Entry<AsyncLogger, PrepareRecoveryResponse>> {
    static final SegmentRecoveryComparator INSTANCE = new SegmentRecoveryComparator();

    @Override
    public int compare(Entry<AsyncLogger, PrepareRecoveryResponse> o1,
            Entry<AsyncLogger, PrepareRecoveryResponse> o2) {
        PrepareRecoveryResponse r1 = o1.getValue();
        PrepareRecoveryResponse r2 = o2.getValue();

        // A response that has data for a segment is always better than one
        // that doesn't.
        if (r1.hasSegmentState() != r2.hasSegmentState()) {
            return Booleans.compare(r1.hasSegmentState(), r2.hasSegmentState());
        }

        if (!r1.hasSegmentState()) {
            // Neither has a segment, so neither can be used for recover.
            // Call them equal.
            return 0;
        }

        // They both have a segment.
        SegmentState r1Seg = r1.getSegmentState();
        SegmentState r2Seg = r2.getSegmentState();

        if (r1Seg.getSn() != r2Seg.getSn()) {
            throw new IllegalArgumentException(
                    "Should only be called with response for corresponding segments: "
                            + r1 + "" + r2
                            + " do not have the same segment number");
        }

        // If one is in-progress but the other is finalized,
        // the finalized one is greater.
        if (r1Seg.isInProgress() != r2Seg.isInProgress()) {
            return Booleans.compare(!r1Seg.isInProgress(),
                    !r2Seg.isInProgress());
        }

        if (!r1Seg.isInProgress()) {
            // If both are finalized, they should match lengths
            if (r1Seg.getContentLength() != r2Seg.getContentLength()) {
                throw new IllegalStateException(
                        "finalized segs with different lengths: " + r1 + ", "
                                + r2);
            }
            return 0;
        }

        // Both are in-progress.
        long r1SeenEpoch = Math.max(r1.getAcceptedInEpoch(),
                r1.getLastWriterEpoch());
        long r2SeenEpoch = Math.max(r2.getAcceptedInEpoch(),
                r2.getLastWriterEpoch());

        if (r1SeenEpoch != r2SeenEpoch) {
            return Longs.compare(r1SeenEpoch, r2SeenEpoch);
        }

        return Longs
                .compare(r1Seg.getContentLength(), r2Seg.getContentLength());
    }
}
