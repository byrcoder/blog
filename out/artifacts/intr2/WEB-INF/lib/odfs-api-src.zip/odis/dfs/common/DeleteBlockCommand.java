/**
 * @(#)DeleteBlockCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.dfs.datanode.DataNode;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * Schedule deletion of some blocks. Namenode would never touch these blocks
 * after scheduled this command. No reads of these blocks will be directed to
 * this datanode anymore.
 * 
 * @author zhangduo
 */
public class DeleteBlockCommand extends DataNodeCommand {

    private long[] blocks;

    public DeleteBlockCommand() {}

    public DeleteBlockCommand(long[] blocks) {
        this.blocks = blocks;
    }

    public long[] getBlocks() {
        return blocks;
    }

    public void setBlocks(long[] blocks) {
        this.blocks = blocks;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(blocks.length, out);
        for (long block: blocks) {
            out.writeLong(block);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int sz = CDataInputStream.readVInt(in);
        blocks = new long[sz];
        for (int i = 0; i < sz; i++) {
            blocks[i] = in.readLong();
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        DeleteBlockCommand that = (DeleteBlockCommand) value;
        blocks = Arrays.copyOf(that.blocks, that.blocks.length);
        return this;
    }

    @Override
    public void execute(DataNode dataNode) {
        dataNode.scheduleBlockDeletion(blocks);
    }
}
