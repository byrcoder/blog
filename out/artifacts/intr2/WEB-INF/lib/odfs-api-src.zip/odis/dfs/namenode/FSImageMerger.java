/**
 * @(#)FSImageMerger.java, 2013-7-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.dfs.common.FSConstants;
import odis.dfs.util.DfsUtils;
import odis.io.CDataInputStream;
import odis.io.permission.FsPermission;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.mutable.MutableLong;

import toolbox.misc.LinearCongruentialGenerator;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class FSImageMerger implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(FSImageMerger.class);

    private static final class FSBlockStore extends AbstractFSBlockStore {

        FSBlockStore() {
            super(new HashMap<Long, PlacedBlock>(),
                    new HashMap<Long, PlacedBlock>());
        }

        private long blockIdGeneratorSeed = System.currentTimeMillis();

        private long chooseBlockId() {
            long blockId = LinearCongruentialGenerator.nextLong(blockIdGeneratorSeed);
            while ((blockId >= RESERVED_BLOCK_LOWER && blockId < RESERVED_BLOCK_UPPER)
                    || activeBlocks.containsKey(blockId)) {
                blockId = LinearCongruentialGenerator.nextLong(blockId);
            }
            blockIdGeneratorSeed = blockId;
            return blockId;
        }

        long addActiveBlockAndRenameConflict(long block, int len,
                int desiredReplications) {
            if (activeBlocks.containsKey(block)) {
                long newBlock = chooseBlockId();
                System.out.println("CONFLICT BLOCK: " + block + " -> "
                        + newBlock);
                block = newBlock;
            }
            super.addActiveBlock(block, len, desiredReplications);
            return block;
        }

        @Override
        void changeReplication(long[] blocks, int replications) {}

        @Override
        public void close() {}

    }

    private static final class FSDirectory extends
            AbstractFSDirectory<FSBlockStore> {

        FSDirectory(FSBlockStore bstore, File imageFile) throws IOException {
            super(bstore, imageFile, new FsPermission(00777), "kaiwoo",
                    "infraop", new HashMap<String, FileINodeUC>(),
                    new HashMap<Long, String[]>(), new MutableLong());
        }

        @Override
        protected INode loadINode(CDataInputStream in, String path,
                Map<Long, INode> ctx) throws IOException {
            int type = in.read();
            if (type == ENTRY_FILE_REF) {
                long id = in.readVLong();
                INode node = ctx.get(id);
                if (node == null) {
                    throw new IOException(
                            "File corrupted. Cannot find node with ID " + id);
                }
                // increase reference
                node.incRefCount();
                // return directly, no need to set lastModified etc
                return node;
            }

            long lastAccess = in.readLong();
            long lastModified = in.readLong();
            int desiredReplications = in.readUnsignedByte();
            String user = StringWritable.readString(in);
            String group = StringWritable.readString(in);
            int mode = in.readUnsignedShort();
            INode node;
            if (type == ENTRY_DIR) {
                int nr = in.readVInt();
                SortedArrayChildren children = new SortedArrayChildren(nr);
                long contentsLength = 0;
                long subDirNum = 0;
                long subFileNum = 0;
                for (int i = 0; i < nr; i++) {
                    String name = StringWritable.readString(in);
                    String subPath = (path == null ? INode.STR_SEP : path
                            + INode.SEP)
                            + name;
                    INode subNode = loadINode(in, subPath, ctx);
                    contentsLength += subNode.getContentsLength();
                    subDirNum += subNode.getSubDirNum();
                    subFileNum += subNode.getSubFileNum();
                    if (subNode instanceof DirectoryINode) {
                        subDirNum++;
                    } else if (subNode instanceof FileINode) {
                        subFileNum++;
                    }
                    children.put(UTF8String.create(name), subNode);
                }
                node = new DirectoryINode(children, desiredReplications,
                        lastAccess, lastModified);
                node.setContentsLength(contentsLength);
                node.setSubDirNum(subDirNum);
                node.setSubFileNum(subFileNum);
            } else if (type == ENTRY_FILE) {
                long id = in.readVLong();
                int nr = in.readVInt();
                long contentsLength;
                if (nr == 1) {
                    long block = in.readLong();
                    int len = in.readVInt();
                    contentsLength = len;
                    block = bstore.addActiveBlockAndRenameConflict(block, len,
                            desiredReplications);
                    node = new TinyFileINode(block, desiredReplications,
                            lastAccess, lastModified);
                } else {
                    long[] blocks = new long[nr];
                    contentsLength = 0;
                    for (int i = 0; i < nr; i++) {
                        long block = in.readLong();
                        int len = in.readVInt();
                        contentsLength += len;
                        block = bstore.addActiveBlockAndRenameConflict(block,
                                len, desiredReplications);
                        blocks[i] = block;
                    }
                    node = new NormalFileINode(blocks, desiredReplications,
                            lastAccess, lastModified);
                }
                if (id != 0) {
                    ctx.put(id, node);
                }
                distinctFileNum++;
                distinctFileSize += contentsLength;
                node.setContentsLength(contentsLength);
            } else if (type == ENTRY_FILE_UC) {
                String holder = StringWritable.readString(in);
                int fileBlockSize = in.readVInt();
                FileINodeUC nodeUC = new FileINodeUC(holder,
                        desiredReplications, fileBlockSize, lastAccess,
                        lastModified);
                for (int count = in.readVInt(); count > 0; count--) {
                    BlockWithSize bs = new BlockWithSize();
                    bs.readFields(in);
                    nodeUC.blocks.add(bs);
                    bstore.addBlock(bs.block, bs.size, desiredReplications);
                }
                node = nodeUC;
            } else {
                throw new IOException("Wrong file format. Unknown entry type: "
                        + type);
            }
            node.setUser(ugMgr.getUserSerialNumber(user));
            node.setGroup(ugMgr.getGroupSerialNumber(group));
            node.setFsPermission(mode);
            return node;
        }

    }

    public void merge(File image, File guestImage, String guestDirName,
            File destImage) throws IOException {
        FSBlockStore bstore = new FSBlockStore();
        LOG.info("Start to loading host directory from "
                + image.getAbsolutePath());
        FSDirectory dir = new FSDirectory(bstore, image);
        LOG.info("Start to loading guest directory from "
                + guestImage.getAbsolutePath());
        FSDirectory guestDir = new FSDirectory(bstore, guestImage);
        LOG.info("Add guest directory under " + guestDirName);
        dir.rootDir.addChild(guestDirName, guestDir.rootDir,
                System.currentTimeMillis());
        LOG.info("Start saving new image to " + destImage.getAbsolutePath());
        int adler32 = dir.saveFSImage(destImage,
                new HashMap<String, FileINodeUC>(),
                new HashMap<Long, String[]>(), 0L);
        DfsUtils.writeChecksum(
                new File(destImage.getParentFile(), destImage.getName()
                        + ".adler32"), adler32);
        LOG.info("Done saving new image to " + destImage.getAbsolutePath()
                + ", adler32 is " + HexString.intToPaddedHex(adler32));
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 4) {
            System.out.println("Usage: [image] [guestImage] [guestDirName] [destImage]");
            System.exit(1);
        }
        File image = new File(args[0]);
        File guestImage = new File(args[1]);
        String guestDirName = args[2];
        File destImage = new File(args[3]);
        new FSImageMerger().merge(image, guestImage, guestDirName, destImage);
    }
}
