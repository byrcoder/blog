/**
 * @(#)JournalManager.java, 2012-11-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.journal;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

/**
 * A JournalManager is responsible for managing a single place of storing edit
 * logs.
 * <p>
 * We only allow one opened segment at a time, so we do not have an
 * "OutputStream", just use the JournalManager to write journal.
 * <p>
 * Notice that, namenode will quit if IOException is thrown from JournalManager.
 * <p>
 * The implements need not to be thread safe.
 * 
 * @author zhangduo
 */
public interface JournalManager extends Closeable {

    /**
     * Recover segment which have not been finalized, and then, open a new
     * segment for write.
     * 
     * @param minimumSN
     *            the new segment's SN should be larger than or equal to the
     *            minimumSN
     * @throws IOException
     */
    void recoverUnfinalizedSegmentAndStartNewSegment(long minimumSN)
            throws IOException;

    /**
     * Return the current segment's sn that opened for write
     * 
     * @return
     */
    long currentOpenedSegmentSN();

    /**
     * Write journal data to the current opened segment.
     * 
     * @param buf
     * @throws IOException
     */
    void write(byte[] buf) throws IOException;

    /**
     * Write journal data to the current opened segment.
     * 
     * @param buf
     * @param off
     * @param len
     * @throws IOException
     */
    void write(byte[] buf, int off, int len) throws IOException;

    /**
     * Close the current opened segment, and then, open a new segment for write.
     * 
     * @throws IOException
     */
    void finalizeSegmentAndStartNewSegment() throws IOException;

    /**
     * Open segment with the given sn to read.
     * 
     * @param sn
     * @return
     * @throws IOException
     */
    InputStream openFinalizedSegment(long sn) throws IOException;

    /**
     * Delete segments which sn smaller than the given sn.
     * 
     * @param sn
     * @throws IOException
     */
    void deleteSegmentBefore(long sn) throws IOException;

    /**
     * release resources.
     * <p>
     * Do <strong>NOT</strong> throw any exception.
     */
    void close();
    
    /**
     * Return the max sn for  finalized segment
     * 
     * @return
     * @throws IOException 
     */
    long maxFinalizedSegmentSN() throws IOException;
}
