/**
 * @(#)UserGroupManager.java, 2012-2-1. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.lib.StringWritable;

/**
 * Manage name-to-serial-number maps for users and groups.
 * 
 * @author zhangduo
 */
class UserGroupManager {

    private final SerialNumberMap<String> userMap = new SerialNumberMap<String>();

    private final SerialNumberMap<String> groupMap = new SerialNumberMap<String>();

    private final Map<String, Set<String>> groupUsers = new HashMap<String, Set<String>>();

    UserGroupManager() {
        getUserSerialNumber(null);
        getGroupSerialNumber(null);
    }

    int getUserSerialNumber(String u) {
        return userMap.get(u);
    }

    int getGroupSerialNumber(String g) {
        return groupMap.get(g);
    }

    String getUser(int n) {
        return userMap.get(n);
    }

    String getGroup(int n) {
        return groupMap.get(n);
    }

    void addGroupUser(String group, String user) {
        getUserSerialNumber(user);
        getGroupSerialNumber(group);
        synchronized (groupUsers) {
            Set<String> users = groupUsers.get(group);
            if (users == null) {
                users = new LinkedHashSet<String>();
                groupUsers.put(group, users);
            }
            users.add(user);
        }
    }

    void removeGroupUser(String group, String user) {
        synchronized (groupUsers) {
            Set<String> users = groupUsers.get(group);
            if (users != null) {
                users.remove(user);
            }
        }
    }

    void removeGroup(String group) {
        synchronized (groupUsers) {
            groupUsers.remove(group);
        }
    }

    boolean inGroup(String group, String user) {
        synchronized (groupUsers) {
            Set<String> users = groupUsers.get(group);
            return users == null ? false : users.contains(user);
        }
    }

    void saveGroupsToImage(CDataOutputStream out) throws IOException {
        Map<String, Set<String>> copy = new HashMap<String, Set<String>>();
        synchronized (groupUsers) {
            for (Map.Entry<String, Set<String>> entry: groupUsers.entrySet()) {
                copy.put(entry.getKey(),
                        new LinkedHashSet<String>(entry.getValue()));
            }
        }
        out.writeVInt(copy.size());
        for (Map.Entry<String, Set<String>> entry: copy.entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            Set<String> users = entry.getValue();
            out.writeVInt(users.size());
            for (String user: users) {
                StringWritable.writeString(out, user);
            }
        }
    }

    public void loadGroupsFromImage(CDataInputStream in) throws IOException {
        Map<String, Set<String>> buffer = new HashMap<String, Set<String>>();
        for (int groupCount = in.readVInt(); groupCount > 0; groupCount--) {
            String group = StringWritable.readString(in);
            Set<String> users = new LinkedHashSet<String>();
            for (int sz = in.readVInt(); sz > 0; sz--) {
                users.add(StringWritable.readString(in));
            }
            buffer.put(group, users);
        }
        synchronized (groupUsers) {
            groupUsers.clear();
            groupUsers.putAll(buffer);
        }
    }

    void saveGroupsToTextFile(PrintWriter writer) {
        Map<String, Set<String>> copy = new HashMap<String, Set<String>>();
        synchronized (groupUsers) {
            for (Map.Entry<String, Set<String>> entry: groupUsers.entrySet()) {
                copy.put(entry.getKey(),
                        new LinkedHashSet<String>(entry.getValue()));
            }
        }
        writer.print("Groups:");
        for (Map.Entry<String, Set<String>> entry: copy.entrySet()) {
            writer.println();
            writer.print(entry.getKey());
            writer.print(':');
            Iterator<String> iter = entry.getValue().iterator();
            if (iter.hasNext()) {
                writer.print(iter.next());
                while (iter.hasNext()) {
                    writer.print(',');
                    writer.print(iter.next());
                }
            }
        }
    }

    private static final class SerialNumberMap<T> {
        private int max = 0;

        private int nextSerialNumber() {
            return max++;
        }

        private Map<T, Integer> t2i = new HashMap<T, Integer>();

        private Map<Integer, T> i2t = new HashMap<Integer, T>();

        synchronized int get(T t) {
            Integer sn = t2i.get(t);
            if (sn == null) {
                sn = nextSerialNumber();
                t2i.put(t, sn);
                i2t.put(sn, t);
            }
            return sn;
        }

        synchronized T get(int i) {
            if (!i2t.containsKey(i)) {
                throw new IllegalStateException("!i2t.containsKey(" + i
                        + "), this=" + this);
            }
            return i2t.get(i);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            return "max=" + max + ",\n  t2i=" + t2i + ",\n  i2t=" + i2t;
        }
    }
}
