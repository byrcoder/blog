/**
 * @(#)InspectorServlet.java, 2013-2-9. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.metrics.NameNodeMetricsItem;
import odis.dfs.namenode.ActiveFSDirectory.DirectoryStatInfo;

import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.apache.velocity.tools.view.VelocityViewServlet;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.collections.Pair;
import toolbox.collections.primitive.LongCompactHashSet;
import toolbox.text.util.StringUtils;

/**
 * @author zhangduo
 */
public class InspectorServlet extends VelocityViewServlet {

    private static final long serialVersionUID = -2390101058500714108L;

    static PrimaryNameNode nn;

    private static final long DN_QUOTA_VALID_FACTOR = 20;

    private static final long QUOTA_VALID_FACTOR = 20;

    private static enum RequestType {
        HOME, NAMENODE_METRICS, DATANODE_METRICS, DATANODES, DATANODE, QUOTAS
    }

    private final DateTimeFormatter fullDateTimeFormatter = DateTimeFormat.fullDateTime();

    private final DateTimeFormatter mediumDateTimeFormatter = DateTimeFormat.mediumDateTime();

    private RequestType getRequestType(HttpServletRequest request) {
        String cmd = request.getServletPath();
        if (cmd == null) {
            return RequestType.HOME;
        }
        cmd = org.apache.commons.lang.StringUtils.strip(cmd, "/");
        if (cmd.equals("namenode_metrics.s")) {
            return RequestType.NAMENODE_METRICS;
        } else if (cmd.equals("datanode_metrics.s")) {
            return RequestType.DATANODE_METRICS;
        } else if (cmd.equals("datanodes.s")) {
            return RequestType.DATANODES;
        } else if (cmd.equals("datanode.s")) {
            return RequestType.DATANODE;
        } else if (cmd.equals("quotas.s")) {
            return RequestType.QUOTAS;
        } else {
            return RequestType.HOME;
        }
    }

    private static class ReservedBlockNum {
        private volatile long num;

        private volatile long time = 0;
    }

    // update every one minute(no update if no request)
    private final ReservedBlockNum reservedBlockNum = new ReservedBlockNum();

    private long getReservedBlockNum(ActiveFSBlockStore bstore) {
        long time = System.currentTimeMillis();
        if (time - reservedBlockNum.time > 60 * 1000) {
            synchronized (reservedBlockNum) {
                if (time - reservedBlockNum.time > 60 * 1000) {
                    reservedBlockNum.time = time;
                    LongCompactHashSet set = new LongCompactHashSet();
                    for (DatanodeInfo dinfo: bstore.datanodeMap.values()) {
                        dinfo.getReservations(set);
                    }
                    reservedBlockNum.num = set.size();
                }
            }
        }
        return reservedBlockNum.num;
    }

    private void doHome(Context ctx, HttpServletRequest req) {
        long currentTime = System.currentTimeMillis();
        ctx.put("systime", fullDateTimeFormatter.print(currentTime));
        ctx.put("zkaddr", nn.zkAddr);
        ctx.put("zkroot", nn.zkRoot);
        ctx.put("hostport", nn.host + ":" + nn.port);
        ctx.put("cuid", nn.cuid);
        ctx.put("starttime", fullDateTimeFormatter.print(nn.startTime));
        long uptime = currentTime - nn.startTime;
        long days = uptime / (24L * 60 * 60 * 1000);
        uptime %= 24L * 60 * 60 * 1000;
        long hours = uptime / (60L * 60 * 1000);
        uptime %= 60L * 60 * 1000;
        long minutes = uptime / (60L * 1000);
        uptime %= 60L * 1000;
        long seconds = uptime / 1000L;
        ctx.put("uptime", days + " days " + hours + " hours " + minutes
                + " minutes " + seconds + " seconds");
        AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem = nn.nameSystem;
        boolean active = nameSystem instanceof ActiveFSNameSystem;
        ctx.put("mode", active ? "ACTIVE" : "BACKUP");
        ctx.put("ready", nameSystem.isReady());
        ctx.put("journal", nameSystem.getFSEditLogger().journalMgr.toString());
        AbstractPrimaryFSBlockStore bstore = nameSystem.getFSBlockStore();
        long capacity = bstore.totalCapacity();
        long remaining = bstore.totalRemaining();
        long used = capacity - remaining;
        ctx.put("totalcapacity",
                capacity + "(" + StringUtils.byteDesc(capacity) + ")");
        ctx.put("totalused", used + "(" + StringUtils.byteDesc(used) + ")");
        ctx.put("totalremaining",
                remaining + "(" + StringUtils.byteDesc(remaining) + ')');
        ctx.put("usedpercent",
                String.format("%.2f", (double) used / capacity * 100) + "%");
        ctx.put("datanodes", bstore.datanodeNumber());
        ctx.put("memoryMXBean", ManagementFactory.getMemoryMXBean());
        ctx.put("operatingSystemMXBean",
                ManagementFactory.getOperatingSystemMXBean());
        ctx.put("clientrpcqueuelength", nn.clientRpcServer.getPendingCalls());
        ctx.put("dnrpcqueuelength", nn.systemRpcServer.getPendingCalls());

        DirectoryStatInfo dirStatInfo = nameSystem.getFSDirectory().getStatInfo();
        ctx.put("dirnum", dirStatInfo.dirNum);
        ctx.put("filenum", dirStatInfo.fileNum);
        ctx.put("distinctfilenum", dirStatInfo.distinctFileNum);
        ctx.put("filesize",
                dirStatInfo.fileSize + "("
                        + StringUtils.byteDesc(dirStatInfo.fileSize) + ")");
        ctx.put("distinctfilesize", dirStatInfo.distinctFileSize + "("
                + StringUtils.byteDesc(dirStatInfo.distinctFileSize) + ")");

        ctx.put("inactiveblocks", bstore.inactiveBlockNumber());
        ctx.put("activeblocks", bstore.activeBlockNumber());
        if (active) {
            ActiveFSBlockStore activeBStore = (ActiveFSBlockStore) bstore;
            ctx.put("reservedblocks", getReservedBlockNum(activeBStore));
            ctx.put("toreplicateblocks", activeBStore.toReplicateSize());
            ctx.put("replicatingblocks", activeBStore.replicatingSize());
            ActiveFSNameSystem activeNameSystem = (ActiveFSNameSystem) nameSystem;
            ctx.put("clients", activeNameSystem.leaseCount());
            synchronized (nameSystem.pendingCreates) {
                ctx.put("pendingfiles", nameSystem.pendingCreates.size());
                ctx.put("pendingblocks",
                        nameSystem.pendingCreateLastBlocks.size());
            }
        } else {
            ctx.put("reservedblocks", "N/A");
            ctx.put("toreplicateblocks", "N/A");
            ctx.put("replicatingblocks", "N/A");
            ctx.put("clients", "N/A");
            ctx.put("pendingfiles", "N/A");
            ctx.put("pendingblocks", "N/A");
        }
        ctx.put("content", "home.vm");
    }

    private void doNameNodeMetrics(Context ctx, HttpServletRequest req) {
        ctx.put("nnname", nn.host + ":" + nn.port);
        long[] nnMetricsRecords = nn.getNameNodeMetricsRecords();
        List<Pair<NameNodeMetricsItem, String>> metrics = new ArrayList<Pair<NameNodeMetricsItem, String>>(
                nnMetricsRecords.length);
        for (NameNodeMetricsItem item: NameNodeMetricsItem.values()) {
            String value;
            if (item == NameNodeMetricsItem.SYSTEM_LOAD) {
                value = String.format("%.2f",
                        (double) nnMetricsRecords[item.offset()] / 100);
            } else if (item.name().startsWith("HEAP_")
                    || item.name().startsWith("NON_HEAP_")
                    || item.name().endsWith("_SIZE")
                    || item.name().endsWith("_BYTES")) {
                long size = nnMetricsRecords[item.offset()];
                value = Long.toString(size) + "(" + StringUtils.byteDesc(size)
                        + ")";
            } else if (item.name().endsWith("_DELAY")) {
                value = nnMetricsRecords[item.offset()] + "ms";
            } else {
                value = Long.toString(nnMetricsRecords[item.offset()]);
            }
            metrics.add(new Pair<NameNodeMetricsItem, String>(item, value));
        }
        ctx.put("metrics", metrics);
        ctx.put("content", "namenode-metrics.vm");
    }

    private void doDataNodeMetrics(Context ctx, HttpServletRequest req) {
        ctx.put("nnname", nn.host + ":" + nn.port);
        long[] dnMetricsRecords = nn.getDataNodeMetricsRecords();
        List<Pair<DataNodeMetricsItem, String>> metrics = new ArrayList<Pair<DataNodeMetricsItem, String>>(
                dnMetricsRecords.length);
        for (DataNodeMetricsItem item: DataNodeMetricsItem.values()) {
            String value;
            if (item == DataNodeMetricsItem.SYSTEM_LOAD) {
                value = String.format("%.2f",
                        (double) dnMetricsRecords[item.offset()] / 100);
            } else if (item.name().startsWith("HEAP_")
                    || item.name().startsWith("NON_HEAP_")
                    || item.name().endsWith("_SIZE")
                    || item.name().endsWith("_BYTES")) {
                long size = dnMetricsRecords[item.offset()];
                value = Long.toString(size) + "(" + StringUtils.byteDesc(size)
                        + ")";
            } else if (item.name().endsWith("_DELAY")) {
                value = dnMetricsRecords[item.offset()] + "ms";
            } else {
                value = Long.toString(dnMetricsRecords[item.offset()]);
            }
            metrics.add(new Pair<DataNodeMetricsItem, String>(item, value));
        }
        ctx.put("metrics", metrics);
        ctx.put("content", "datanode-metrics.vm");
    }

    private void doDataNodeList(Context ctx, HttpServletRequest req) {
        // two columns on one page
        ArrayList<HashMap<String, Object>> dn1 = new ArrayList<HashMap<String, Object>>();
        ArrayList<HashMap<String, Object>> dn2 = new ArrayList<HashMap<String, Object>>();
        ArrayList<HashMap<String, Object>> ddn1 = new ArrayList<HashMap<String, Object>>();
        ArrayList<HashMap<String, Object>> ddn2 = new ArrayList<HashMap<String, Object>>();
        AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem = nn.nameSystem;
        DatanodeInfo[] dninfos = nameSystem.getFSBlockStore().datanodeReport();
        Arrays.sort(dninfos, DatanodeInfo.HOST_PORT_COMPARATOR);
        int count = 0;
        for (DatanodeInfo dninfo: dninfos) {
            HashMap<String, Object> props = new HashMap<String, Object>();
            props.put("name", dninfo.getFullName());
            props.put(
                    "capacity",
                    dninfo.getCapacity() + "("
                            + StringUtils.byteDesc(dninfo.getCapacity()) + ")");
            props.put(
                    "remaining",
                    dninfo.getRemaining() + "("
                            + StringUtils.byteDesc(dninfo.getRemaining()) + ")");
            props.put(
                    "usedpercent",
                    String.format(
                            "%.2f",
                            (double) (dninfo.getCapacity() - dninfo.getRemaining())
                                    / dninfo.getCapacity() * 100)
                            + "%");
            if (dninfo.getRemaining() < dninfo.getCapacity()
                    / DN_QUOTA_VALID_FACTOR) {
                props.put("invalidQuota", true);
            }

            if (count % 2 == 0) {
                dn1.add(props);
            } else {
                dn2.add(props);
            }
            count++;
        }
        if (dn1.size() > 0) {
            ctx.put("datanodes1", dn1);
        }
        if (dn2.size() > 0) {
            ctx.put("datanodes2", dn2);
        }
        count = 0;
        DatanodeInfo[] ddninfos = nameSystem.getFSBlockStore().deadDatanodeReport();
        Arrays.sort(ddninfos, DatanodeInfo.LAST_UPDATE_COMPARATOR);
        for (DatanodeInfo dninfo: ddninfos) {
            HashMap<String, Object> props = new HashMap<String, Object>();
            props.put("name", dninfo.getFullName());
            props.put("lastupdate",
                    mediumDateTimeFormatter.print(dninfo.lastUpdate()));
            if (count % 2 != 0) {
                ddn2.add(props);
            } else {
                ddn1.add(props);
            }
            count++;
        }
        if (dn1.size() > 0) {
            ctx.put("datanodes1", dn1);
        }
        if (dn2.size() > 0) {
            ctx.put("datanodes2", dn2);
        }
        if (ddn1.size() > 0) {
            ctx.put("deaddatanodes1", ddn1);
        }
        if (ddn2.size() > 0) {
            ctx.put("deaddatanodes2", ddn2);
        }
        ctx.put("totaldatanodes", dninfos.length);
        ctx.put("deaddatanodes", ddninfos.length);
        ctx.put("content", "datanodes.vm");
    }

    private void doDataNodeDetail(Context ctx, HttpServletRequest req) {
        String dnFullName = req.getParameter("name");
        if (dnFullName == null) {
            error(ctx, "你没有向这个页面输入需要查看的数据节点.");
            return;
        }
        String dnName = DatanodeInfo.getDatanodeNameFromFullName(dnFullName);
        AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem = nn.nameSystem;
        DatanodeInfo dninfo = nameSystem.getFSBlockStore().getDatanode(dnName);
        if (dninfo == null) {
            error(ctx, "找不到你需要查看的数据节点: " + dnName);
            return;
        }
        ctx.put("content", "datanode.vm");
        ctx.put("nav", "Dn Details");
        ctx.put("name", dnName);
        ctx.put("lastupdate",
                mediumDateTimeFormatter.print(dninfo.lastUpdate()));
        ctx.put("blocks", dninfo.getBlocks().length);
        ctx.put("capacity",
                dninfo.getCapacity() + "("
                        + StringUtils.byteDesc(dninfo.getCapacity()) + ")");
        ctx.put("remaining",
                dninfo.getRemaining() + "("
                        + StringUtils.byteDesc(dninfo.getRemaining()) + ")");
        ctx.put("used",
                (dninfo.getCapacity() - dninfo.getRemaining())
                        + "("
                        + StringUtils.byteDesc(dninfo.getCapacity()
                                - dninfo.getRemaining()) + ")");
        ctx.put("usedpercent",
                String.format("%.2f",
                        (double) (dninfo.getCapacity() - dninfo.getRemaining())
                                / dninfo.getCapacity() * 100)
                        + "%");
        ctx.put("reservedblocks", dninfo.getReservedBlockCount());
        ctx.put("reserved",
                dninfo.getReserved() + "("
                        + StringUtils.byteDesc(dninfo.getReserved()) + ")");
        long repSize = dninfo.getReplicationQueueSize();
        ctx.put("repsize", repSize);

        String dnHBName = DatanodeInfo.getDatanodeHBKeyFromFullName(dnFullName);
        long[] dnMetrics = nn.datanodeMetricsMap.get(dnHBName);
        List<Pair<DataNodeMetricsItem, String>> metrics = new ArrayList<Pair<DataNodeMetricsItem, String>>(
                dnMetrics.length);
        for (DataNodeMetricsItem item: DataNodeMetricsItem.values()) {
            String value;
            if (item == DataNodeMetricsItem.SYSTEM_LOAD) {
                value = String.format("%.2f",
                        (double) dnMetrics[item.offset()] / 100);
            } else if (item.name().startsWith("HEAP_")
                    || item.name().startsWith("NON_HEAP_")
                    || item.name().endsWith("_SIZE")
                    || item.name().endsWith("_BYTES")) {
                long size = dnMetrics[item.offset()];
                value = Long.toString(size) + "(" + StringUtils.byteDesc(size)
                        + ")";
            } else if (item.name().endsWith("_DELAY")) {
                value = dnMetrics[item.offset()] + "ms";
            } else {
                value = Long.toString(dnMetrics[item.offset()]);
            }
            metrics.add(new Pair<DataNodeMetricsItem, String>(item, value));
        }
        ctx.put("metrics", metrics);
    }

    private void doQuotas(Context ctx, HttpServletRequest req) {
        AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem = nn.nameSystem;
        List<String> quotaList = nameSystem.getFSDirectory().fsDirPropMgr.getAllQuotaedDirList();
        List<Map<String, Object>> validDir = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> invalidDir = new ArrayList<Map<String, Object>>();
        for (String dir: quotaList) {
            Map<String, Object> props = new HashMap<String, Object>();
            props.put("name", dir);
            long quota = nameSystem.getFSDirectory().fsDirPropMgr.getSpaceQuota(dir);
            long nameQuota = nameSystem.getFSDirectory().fsDirPropMgr.getNameQuota(dir);
            INodeInfo info = nameSystem.getFSDirectory().getINodeInfo(dir);
            boolean valid = true;
            if (quota > 0) {
                props.put("quota", quota + "(" + StringUtils.byteDesc(quota)
                        + ")");
                long used = info != null ? info.contentsLength : 0;
                props.put("used", used + "(" + StringUtils.byteDesc(used) + ")");
                if (quota - used < quota / QUOTA_VALID_FACTOR) {
                    valid = false;
                }
            } else {
                props.put("quota", "N/A");
                props.put("used", "N/A");
            }
            if (nameQuota > 0) {
                props.put("namequota", nameQuota);
                long nameUsed = info != null ? info.subDirNum + info.subFileNum
                        : 0;
                props.put("nameused", nameUsed);
                if (nameQuota - nameUsed < quota / QUOTA_VALID_FACTOR) {
                    valid = false;
                }
            } else {
                props.put("namequota", "N/A");
                props.put("nameused", "N/A");
            }
            if (valid) {
                validDir.add(props);
            } else {
                invalidDir.add(props);
            }
        }
        if (validDir.size() > 0) {
            ctx.put("validdir", validDir);
        }
        if (invalidDir.size() > 0) {
            ctx.put("invaliddir", invalidDir);
        }
        ctx.put("validdirs", validDir.size());
        ctx.put("deaddirs", invalidDir.size());
        ctx.put("content", "quotas.vm");
    }

    @Override
    protected void fillContext(Context context, HttpServletRequest request) {
        RequestType reqType = getRequestType(request);
        context.put("cmd", reqType.name());
        context.put("title", "ODFS [" + nn.host + ":" + nn.host + "]");
        switch (reqType) {
            case HOME:
                doHome(context, request);
                break;
            case NAMENODE_METRICS:
                doNameNodeMetrics(context, request);
                break;
            case DATANODE_METRICS:
                doDataNodeMetrics(context, request);
                break;
            case DATANODES:
                doDataNodeList(context, request);
                break;
            case DATANODE:
                doDataNodeDetail(context, request);
                break;
            case QUOTAS:
                doQuotas(context, request);
                break;
        }
    }

    @Override
    protected Template getTemplate(HttpServletRequest request,
            HttpServletResponse response) {
        return getTemplate("template.vm");
    }

    private void error(Context ctx, String message) {
        ctx.put("nav", "出错");
        ctx.put("error", message);
        ctx.put("content", "message.vm");
    }
}
