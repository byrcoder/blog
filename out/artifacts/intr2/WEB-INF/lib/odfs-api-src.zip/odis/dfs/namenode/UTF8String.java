/*
 * Copyright (c) 2008, Outfox Team.
 *
 * Created on 2008-2-1
 */
package odis.dfs.namenode;

import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import java.util.regex.Pattern;

import odis.dfs.common.DFSConfig;

/**
 * A String-like object that stores content using UTF8 encoding in memory, in
 * order to save memory. Also a more compact format is automatically used for
 * strings occupying less than 8 bytes. Limitation: current implementation does
 * not support the "null character" (\0).
 * 
 * @author zf
 * @since 3.5
 */
abstract class UTF8String implements Comparable<UTF8String> {
    private static Pattern internPattern = Pattern.compile(DFSConfig.conf().getString(
            DFSConfig.FILE_NAME_INTERN_PATTERN,
            DFSConfig.DEFAULT_FILE_NAME_INTERN_PATTERN));

    private static final WeakHashMap<UTF8String, WeakReference<UTF8String>> internMap = new WeakHashMap<UTF8String, WeakReference<UTF8String>>();

    abstract int byteLength();

    /**
     * <p>
     * Returns a canonical representation for the UTF8String object.
     * </p>
     * <p>
     * A pool of UTF8Strings, initially empty, is maintained privately by the
     * class <code>UTF8String</code>.
     * </p>
     * <p>
     * When the intern method is invoked, if the pool already contains a string
     * equal to this <code>UTF8String</code> object as determined by the
     * {@link #equals(Object)} method, then the string from the pool is
     * returned. Otherwise, this <code>UTF8String</code> object is added to the
     * pool and a reference to this <code>UTF8String</code> object is returned.
     * </p>
     * <p>
     * It follows that for any two strings <code>s</code> and <code>t</code>,
     * <code>s.intern() == t.intern()</code> is <code>true</code> if and only if
     * <code>s.equals(t)</code> is <code>true</code>.
     * </p>
     * 
     * @return a string that has the same contents as this string, but is
     *         guaranteed to be from a pool of unique strings.
     */
    UTF8String intern() {
        // Put freuquently used file names in a map for reuse to save memory.
        synchronized (internMap) {
            WeakReference<UTF8String> ref = internMap.get(this);
            if (ref != null) {
                UTF8String referred = ref.get();
                if (referred != null) {
                    return referred;
                }
            }
            internMap.put(this, new WeakReference<UTF8String>(this));
            return this;
        }
    }

    abstract byte get(int i);

    public int compareTo(UTF8String o) {
        int len = this.byteLength();
        int len2 = o.byteLength();
        for (int i = 0; i < len && i < len2; i++) {
            int v = get(i) & 0xff;
            int v2 = o.get(i) & 0xff;
            if (v != v2) {
                return v - v2;
            }
        }
        return len - len2;
    }

    @Override
    public int hashCode() {
        int l = byteLength();
        int hash = 1;
        for (int i = 0; i < l; i++) {
            hash = (31 * hash) + (int) get(i);
        }
        return hash;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (this == o) {
            return true;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        UTF8String that = (UTF8String) o;
        int thisLen = byteLength();
        int thatLen = that.byteLength();
        if (thisLen != thatLen) {
            return false;
        }
        for (int i = 0; i < thisLen; i++) {
            if (get(i) != that.get(i)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public final String toString() {
        int byteLength = byteLength();
        StringBuilder buffer = new StringBuilder(byteLength);
        for (int i = 0; i < byteLength;) {
            byte b = get(i++);
            if ((b & 0x80) == 0) {
                buffer.append((char) (b & 0x7F));
            } else if ((b & 0xE0) != 0xE0) {
                buffer.append((char) (((b & 0x1F) << 6) | (get(i++) & 0x3F)));
            } else {
                buffer.append((char) (((b & 0x0F) << 12)
                        | ((get(i++) & 0x3F) << 6) | (get(i++) & 0x3F)));
            }
        }
        return buffer.toString();
    }

    /**
     * UTF8String of less than or equal to 8 bytes.
     */
    private static final class UTF8String8 extends UTF8String {

        private long b;

        private UTF8String8(String s) {
            int charLength = s.length();
            long l = 0;
            for (int i = 0, pos = 0; i < charLength; i++) {
                char c = s.charAt(i);
                if ((c >= 0x0000) && (c <= 0x007F)) {
                    l |= (c & 0xFFL) << ((pos++) * Byte.SIZE);
                } else if (c > 0x07FF) {
                    l |= ((0xE0 | ((c >> 12) & 0x0F)) & 0xFFL) << ((pos++) * Byte.SIZE);
                    l |= ((0x80 | ((c >> 6) & 0x3F)) & 0xFFL) << ((pos++) * Byte.SIZE);
                    l |= ((0x80 | ((c >> 0) & 0x3F)) & 0xFFL) << ((pos++) * Byte.SIZE);
                } else {
                    l |= ((0xC0 | ((c >> 6) & 0x1F)) & 0xFFL) << ((pos++) * Byte.SIZE);
                    l |= ((0x80 | ((c >> 0) & 0x3F)) & 0xFFL) << ((pos++) * Byte.SIZE);
                }
            }
            this.b = l;
        }

        @Override
        int byteLength() {
            return 8 - Long.numberOfLeadingZeros(b) / Byte.SIZE;
        }

        @Override
        byte get(int i) {
            return (byte) (b >>> (i * Byte.SIZE));
        }
    }

    /**
     * UTF8String of less than or equal to 16 bytes but larger than 8 bytes.
     */
    private static final class UTF8String16 extends UTF8String {
        private long b1;

        private long b2;

        private UTF8String16(String s) {
            int charLength = s.length();
            long l = 0;
            for (int i = 0, pos = 0; i < charLength; i++) {
                char c = s.charAt(i);
                if ((c >= 0x0000) && (c <= 0x007F)) {
                    l |= (c & 0xFFL) << ((pos++ & 7L) * Byte.SIZE);
                    if (pos == 8) {
                        this.b1 = l;
                        l = 0;
                    }
                } else if (c > 0x07FF) {
                    l |= ((0xE0 | ((c >> 12) & 0x0F)) & 0xFFL) << ((pos++ & 7L) * Byte.SIZE);
                    if (pos == 8) {
                        this.b1 = l;
                        l = 0;
                    }
                    l |= ((0x80 | ((c >> 6) & 0x3F)) & 0xFFL) << ((pos++ & 7L) * Byte.SIZE);
                    if (pos == 8) {
                        this.b1 = l;
                        l = 0;
                    }
                    l |= ((0x80 | ((c >> 0) & 0x3F)) & 0xFFL) << ((pos++ & 7L) * Byte.SIZE);
                    if (pos == 8) {
                        this.b1 = l;
                        l = 0;
                    }
                } else {
                    l |= ((0xC0 | ((c >> 6) & 0x1F)) & 0xFFL) << ((pos++ & 7L) * Byte.SIZE);
                    if (pos == 8) {
                        this.b1 = l;
                        l = 0;
                    }
                    l |= ((0x80 | ((c >> 0) & 0x3F)) & 0xFFL) << ((pos++ & 7L) * Byte.SIZE);
                    if (pos == 8) {
                        this.b1 = l;
                        l = 0;
                    }
                }
            }
            this.b2 = l;
        }

        @Override
        int byteLength() {
            return 16 - Long.numberOfLeadingZeros(b2) / Byte.SIZE;
        }

        @Override
        byte get(int i) {
            if (i < 8) {
                return (byte) (b1 >>> (i * Byte.SIZE));
            } else {
                return (byte) (b2 >>> ((i - 8) * Byte.SIZE));
            }
        }
    }

    /**
     * UTF8String of any length.
     */
    private static final class UTF8StringVar extends UTF8String {
        byte[] b;

        private UTF8StringVar(String s, int byteLength) {
            int charLength = s.length();
            byte[] b = new byte[byteLength];
            for (int i = 0, pos = 0; i < charLength; i++) {
                char c = s.charAt(i);
                if ((c >= 0x0000) && (c <= 0x007F)) {
                    b[pos++] = (byte) c;
                } else if (c > 0x07FF) {
                    b[pos++] = (byte) (0xE0 | ((c >> 12) & 0x0F));
                    b[pos++] = (byte) (0x80 | ((c >> 6) & 0x3F));
                    b[pos++] = (byte) (0x80 | ((c >> 0) & 0x3F));
                } else {
                    b[pos++] = (byte) (0xC0 | ((c >> 6) & 0x1F));
                    b[pos++] = (byte) (0x80 | ((c >> 0) & 0x3F));
                }
            }
            this.b = b;
        }

        @Override
        int byteLength() {
            return b.length;
        }

        @Override
        byte get(int i) {
            return b[i];
        }
    }

    static UTF8String create(String s) {
        int charLength = s.length();
        int byteLength = 0;
        for (int i = 0; i < charLength; i++) {
            char c = s.charAt(i);
            if ((c >= 0x0000) && (c <= 0x007F)) {
                byteLength++;
            } else if (c > 0x07FF) {
                byteLength += 3;
            } else {
                byteLength += 2;
            }
        }
        UTF8String ret;
        if (byteLength <= 8) {
            ret = new UTF8String8(s);
        } else if (byteLength <= 16) {
            ret = new UTF8String16(s);
        } else {
            ret = new UTF8StringVar(s, byteLength);
        }
        if (internPattern.matcher(s).matches()) {
            return ret.intern();
        } else {
            return ret;
        }
    }
}
