/**
 * @(#)DataNodeExpireException.java, 2011-8-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

/**
 *
 * @author zhangduo
 *
 */
public class DataNodeExpireException extends IllegalStateException {

    private static final long serialVersionUID = 5926732701711436100L;

    public DataNodeExpireException() {
        super();
    }

    public DataNodeExpireException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataNodeExpireException(String s) {
        super(s);
    }

    public DataNodeExpireException(Throwable cause) {
        super(cause);
    }

}
