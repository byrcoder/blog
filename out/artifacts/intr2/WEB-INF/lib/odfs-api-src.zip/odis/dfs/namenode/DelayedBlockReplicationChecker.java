/**
 * @(#)DelayedBlockReplicationChecker.java, 2012-12-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import odis.util.DaemonTracker;

import org.apache.commons.configuration.Configuration;

/**
 * @author zhangduo
 */
class DelayedBlockReplicationChecker extends Thread {

    private final ActiveFSBlockStore bstore;

    private final DelayedCheckBlockQueue queue = new DelayedCheckBlockQueue();

    private final Lock lock = new ReentrantLock();

    private final Condition available = lock.newCondition();

    DelayedBlockReplicationChecker(ActiveFSBlockStore bstore, Configuration conf) {
        super("Delayed-Block-Replication-Checker");
        setDaemon(true);
        this.bstore = bstore;
    }

    void add(long block, long checkTime) {
        lock.lock();
        try {
            boolean wakeUp = queue.size() == 0;
            queue.addIfAbsent(block, checkTime);
            if (wakeUp) {
                available.signalAll();
            }
        } finally {
            lock.unlock();
        }
    }

    void remove(long block) {
        lock.lock();
        try {
            queue.remove(block);
        } finally {
            lock.unlock();
        }
    }

    void close() {
        closed = true;
        interrupt();
    }

    private volatile boolean closed = false;

    @Override
    public void run() {
        DaemonTracker tr = new DaemonTracker();
        DelayedCheckBlockQueue.CheckEntry entry = new DelayedCheckBlockQueue.CheckEntry();
        outer: while (!closed) {
            try {
                lock.lock();
                try {
                    for (;;) {
                        if (!queue.peek(entry)) {
                            try {
                                available.await();
                            } catch (InterruptedException e) {
                                continue outer;
                            }
                        } else {
                            long time = System.currentTimeMillis();
                            if (entry.checkTime > time) {
                                try {
                                    available.await(time - entry.checkTime,
                                            TimeUnit.MILLISECONDS);
                                } catch (InterruptedException e) {}
                                continue outer;
                            }
                            queue.removeHead();
                            break;
                        }
                    }
                } finally {
                    lock.unlock();
                }
                PlacedBlock pb = bstore.getBlock(entry.block);
                if (pb == null) {
                    continue;
                }
                synchronized (pb) {
                    if (pb.replicationCount() < pb.getDesiredReplication()) {
                        bstore.replicator.requestReplication(entry.block,
                                pb.replicationCount());
                    } else if (pb.replicationCount() > pb.getDesiredReplication()) {
                        bstore.reduceReplication(pb);
                    }
                }

            } catch (Throwable t) {
                tr.gotThrowable(t);
            }
        }
    }

}
