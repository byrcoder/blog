/**
 * @(#)DFSClient.java, 2012-12-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.common.IClientProtocolV3;
import odis.dfs.util.DfsUtils;
import odis.io.ConnectionPool;
import odis.io.InterruptibleSocket;
import odis.io.LockStateException;
import odis.io.NamedLock;
import odis.io.permission.FsPermission;
import odis.rpc2.RPC;
import odis.util.ProcessUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class DFSClient implements FSConstants, Closeable {

    private static final Logger LOG = LogFormatter.getLogger(DFSClient.class);

    private static final AtomicInteger CLIENT_ID = new AtomicInteger();

    /**
     * Tell the DFSInputStream to use local block cache
     */
    public static final int IS_BLOCKCACHE = 1;

    /**
     * Tell the DFSInputStream to use a fine-grained DataNode protocol which is
     * optimized for random-access reads.
     */
    public static final int IS_RANDOMREAD = 2;

    /**
     * Tell the DFSOutputStream to disable local backup, e.g., for
     * failure-tolerable tasks. This will save memory or disk I/O.
     */
    public static final int OS_NOLOCALBACKUP = 1;

    /**
     * Tell the {@link DFSOutputStream} to also write data to the local block
     * cache. When this option is enabled, the file appears in block cache as
     * soon as it is completed, if {@link #IS_BLOCKCACHE} is enabled.
     */
    public static final int OS_WRITETOCACHE = 2;

    private static final String USERNAME = DFSClientUsername.username;

    private static final Method REMOVE_LEASE_METHOD;

    static {
        try {
            REMOVE_LEASE_METHOD = IClientProtocolV3.class.getMethod(
                    "removeLease", String.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    private final DFSClientConfig conf;

    private final String clientName;

    private final String localHost;

    private final String username;

    private final String cuid;

    private final long leasePeriod;

    private final Future<?> leaseChecker;

    private volatile BlockCache blockCache;

    private final ScheduledExecutorService bgTaskPool;

    private final ConnectionPool<InterruptibleSocket> randomAccessConnectionPool;

    private final IdleInputStreamTracker idleInputStreamTracker;

    private final AtomicLong writeCounter = new AtomicLong(0);

    private final AtomicLong readCounter = new AtomicLong(0);

    private final NameNodeWatcher nameNodeWatcher;

    public DFSClient(String zkAddr, String zkRoot, DFSClientConfig conf)
            throws InterruptedException, IOException {
        this(zkAddr, zkRoot, USERNAME, conf);
    }

    private String generateClientName() {
        return username
                + "@"
                + localHost
                + "-"
                + ProcessUtils.getPid()
                + "-"
                + HexString.longToPaddedHex(((long) getClass().getClassLoader().hashCode() << 32)
                        | (CLIENT_ID.incrementAndGet() & 0xFFFFFFFFL));
    }

    private long lastRenewed;

    private void checkLease() {
        long now = System.currentTimeMillis();
        if (now - lastRenewed > leasePeriod / 2) {
            try {
                nameNodeWatcher.getNameNode().renewLease(clientName);
                lastRenewed = now;
            } catch (Exception e) {
                LOG.log(Level.WARNING, clientName + " renew lease failed", e);
            }
        }
    }

    DFSClient(String zkAddr, String zkRoot, String username,
            DFSClientConfig conf) throws InterruptedException, IOException {
        this.nameNodeWatcher = new NameNodeWatcher(zkAddr,
                conf.getZooKeeperTimeout(), zkRoot, username,
                conf.getNamenodeRpcTimeout());
        this.conf = conf;
        this.username = username;
        this.localHost = InetAddressUtils.getShortHostName();
        this.clientName = generateClientName();
        this.cuid = nameNodeWatcher.getNameNode().getCUID(clientName);
        this.leasePeriod = nameNodeWatcher.getNameNode().getLeasePeriod(
                clientName);
        this.lastRenewed = System.currentTimeMillis();
        this.bgTaskPool = Executors.newScheduledThreadPool(2,
                new ThreadFactory() {

                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, clientName + "-bg-task");
                        t.setDaemon(true);
                        return t;
                    }
                });
        this.leaseChecker = bgTaskPool.scheduleAtFixedRate(new Runnable() {

            @Override
            public void run() {
                checkLease();
            }
        }, leasePeriod / 4, leasePeriod / 4, TimeUnit.MILLISECONDS);
        this.randomAccessConnectionPool = new ConnectionPool<InterruptibleSocket>(
                conf.getRandomAccessPoolCoreSize(),
                conf.getRandomAccessPoolMaxSize(),
                conf.getRandomAccessConnectionMaxIdleTime(),
                new ConnectionPool.ConnectionValidator<InterruptibleSocket>() {

                    @Override
                    public boolean isValid(InterruptibleSocket conn) {
                        return conn.valid();
                    }

                }, bgTaskPool);
        this.idleInputStreamTracker = new IdleInputStreamTracker(bgTaskPool,
                conf.getBlockInputMaxIdleTime());
        this.nameNodeWatcher.start();
    }

    public AtomicLong getWriteCounter() {
        return writeCounter;
    }

    public AtomicLong getReadCounter() {
        return readCounter;
    }

    public DFSClientConfig getConf() {
        return conf;
    }

    private final Object blockCacheGuard = new Object();

    public void setBlockCacheProps(File cacheDir, int numOfDownloaders) {
        synchronized (blockCacheGuard) {
            if (blockCache == null) {
                blockCache = new BlockCache(cacheDir, numOfDownloaders,
                        conf.getBlockCacheDownloadTimeout(),
                        conf.getBlockCacheDownloadBufferSize(), bgTaskPool,
                        conf.getBlockCacheGCInterval());
            } else {
                throw new IllegalStateException(
                        "BlockCache is already initialized");
            }
        }
    }

    public String getClientName() {
        return clientName;
    }

    public InetSocketAddress getNameNodeAddr() {
        return nameNodeWatcher.getNameNodeAddr();
    }

    NameNodeWatcher getNameNodeWatcher() {
        return nameNodeWatcher;
    }

    public String getCUID() {
        return cuid;
    }

    public void setReady() throws IOException {
        nameNodeWatcher.getNameNode().setReady(clientName);
    }

    public String fsck() throws IOException {
        return nameNodeWatcher.getNameNode().consistencyCheck(clientName);
    }

    public BlockVerifyResult verifyBlock(long block) throws IOException {
        return nameNodeWatcher.getNameNode().verifyBlock(clientName, block);
    }

    public BlockSizeLocationWithDataPath[] getFileBlockLocations(String file)
            throws IOException {
        return nameNodeWatcher.getNameNode().getFileBlockLocations(clientName,
                file);
    }

    public DFSInputStream open(String file, int flags) throws IOException {
        return new DFSInputStream(nameNodeWatcher, file, flags, clientName,
                localHost, idleInputStreamTracker, blockCache,
                randomAccessConnectionPool, readCounter, conf);
    }

    private String wrapperText(boolean on, String text) {
        StringBuilder sb = new StringBuilder(" ");
        sb.append('(');
        if (!on) {
            sb.append("not ");
        }
        return sb.append(text).append(')').toString();
    }

    public BlockLocationWithDataPath createRaw(String file, boolean overwrite,
            boolean createParent, int replication, int blockSize,
            FsPermission permission) throws IOException {
        LOG.info(clientName + " creating raw file " + file
                + wrapperText(overwrite, "overwrite")
                + wrapperText(createParent, "createParent") + " replication="
                + replication + " blockSize=" + blockSize + " permission="
                + permission);
        return nameNodeWatcher.getNameNode().create(clientName, file,
                overwrite, createParent, replication, blockSize, permission);
    }

    public BlockLocationWithDataPath addBlock(String file, int blockIndex)
            throws IOException {
        return nameNodeWatcher.getNameNode().addBlock(clientName, file,
                blockIndex);
    }

    public void abandonBlock(String file, int blockIndex) throws IOException {
        nameNodeWatcher.getNameNode().abandonBlock(clientName, file, blockIndex);
    }

    public boolean complete(String file) throws IOException {
        return nameNodeWatcher.getNameNode().complete(clientName, file);
    }

    public DFSOutputStream create(String file, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission) throws IOException {
        LOG.info(clientName + " creating file " + file
                + wrapperText(overwrite, "overwrite")
                + wrapperText(createParent, "createParent") + " flags=" + flags
                + " replication=" + replication + " blockSize=" + blockSize
                + " permission=" + permission);
        return new DFSOutputStream(nameNodeWatcher, file, overwrite,
                createParent, flags, blockSize, replication, permission,
                clientName, blockCache, writeCounter, conf);
    }

    public QuorumDFSOutputStream createQuorum(String file, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission, Executor workerExecutor)
            throws IOException {
        return new QuorumDFSOutputStream(nameNodeWatcher, file, overwrite,
                createParent, flags, blockSize, replication, permission,
                clientName, writeCounter, workerExecutor, conf);
    }

    public void rename(String src, String dst, boolean overwrite)
            throws IOException {
        nameNodeWatcher.getNameNode().rename(clientName, src, dst, overwrite);
    }

    public void link(String src, String dst) throws IOException {
        nameNodeWatcher.getNameNode().snapshot(clientName, src, dst);
    }

    public boolean delete(String path, boolean recursive, boolean permanently)
            throws IOException {
        return nameNodeWatcher.getNameNode().delete(clientName, path,
                recursive, permanently);
    }

    public DFSFileStatus[] listFiles(String path) throws IOException {
        return nameNodeWatcher.getNameNode().getListing(clientName, path);
    }

    public String[] pendingFilesInDir(String path) throws IOException {
        return nameNodeWatcher.getNameNode().pendingFilesInDir(clientName, path);
    }

    public int getReplication(String path) throws IOException {
        return nameNodeWatcher.getNameNode().getReplicationNumber(clientName,
                path);
    }

    public void setReplication(String path, int replication, boolean recursive)
            throws IOException {
        nameNodeWatcher.getNameNode().setReplicationNumber(clientName, path,
                replication, recursive);
    }

    public void mkdirs(String dir, int replication, FsPermission permission)
            throws IOException {
        nameNodeWatcher.getNameNode().mkdirs(clientName, dir, replication,
                permission);
    }

    public void recoverTrash(String trash, String dst) throws IOException {
        nameNodeWatcher.getNameNode().recoverTrash(clientName, trash, dst);
    }

    public void deleteTrash(String trash) throws IOException {
        nameNodeWatcher.getNameNode().deleteTrash(trash, trash);
    }

    public boolean isRecoverable(String path) throws IOException {
        return nameNodeWatcher.getNameNode().isRecoverable(clientName, path);
    }

    public void setRecoverable(String path, boolean on) throws IOException {
        nameNodeWatcher.getNameNode().setRecoverable(clientName, path, on);
    }

    public boolean isProtect(String path) throws IOException {
        return nameNodeWatcher.getNameNode().isProtect(clientName, path);
    }

    public void setProtect(String path, boolean on) throws IOException {
        nameNodeWatcher.getNameNode().setProtect(clientName, path, on);
    }

    public long getSpaceQuota(String path) throws IOException {
        return nameNodeWatcher.getNameNode().getSpaceQuota(clientName, path);
    }

    public void setSpaceQuota(String path, long quota) throws IOException {
        nameNodeWatcher.getNameNode().setSpaceQuota(clientName, path, quota);
    }

    public long getNameQuota(String path) throws IOException {
        return nameNodeWatcher.getNameNode().getNameQuota(clientName, path);
    }

    public void setNameQuota(String path, long quota) throws IOException {
        nameNodeWatcher.getNameNode().setNameQuota(clientName, path, quota);
    }

    public boolean deprive(String file) throws IOException {
        return nameNodeWatcher.getNameNode().deprive(clientName, file);
    }

    public boolean exists(String path) throws IOException {
        return nameNodeWatcher.getNameNode().exists(clientName, path);
    }

    public DFSFileStatus getFileStatus(String path) throws IOException {
        return nameNodeWatcher.getNameNode().getFileStatus(clientName, path);
    }

    public boolean isPending(String file) throws IOException {
        return nameNodeWatcher.getNameNode().isPending(clientName, file);
    }

    public void abandonFileInProgress(String file) throws IOException {
        nameNodeWatcher.getNameNode().abandonFileInProgress(clientName, file);
    }

    public void computeContentsLengthAndSubItemNum() throws IOException {
        nameNodeWatcher.getNameNode().computeContentsLengthAndSubItemNum(
                clientName);
    }

    public String printDirProperties() throws IOException {
        return nameNodeWatcher.getNameNode().printDirProperties(clientName);
    }

    public void setOwner(String path, boolean recursive, String owner,
            String group) throws IOException {
        nameNodeWatcher.getNameNode().setOwner(clientName, path, recursive,
                owner, group);
    }

    public void setPermission(String path, boolean recursive,
            FsPermission permission) throws IOException {
        nameNodeWatcher.getNameNode().setPermission(clientName, path,
                recursive, permission);
    }

    public void addGroupUser(String group, String user) throws IOException {
        nameNodeWatcher.getNameNode().addGroupUser(clientName, group, user);
    }

    public void removeGroupUser(String group, String user) throws IOException {
        nameNodeWatcher.getNameNode().removeGroupUser(clientName, group, user);
    }

    public void removeGroup(String group) throws IOException {
        nameNodeWatcher.getNameNode().removeGroup(clientName, group);
    }

    public String printGroups() throws IOException {
        return nameNodeWatcher.getNameNode().printGroups(clientName);
    }

    public void lock(String name, int lock) throws IOException {
        long start = System.currentTimeMillis();
        for (int retry = 0; nameNodeWatcher.getNameNode().obtainLock(
                clientName, name, lock) != COMPLETE_SUCCESS; retry++) {
            long elapsedTime = System.currentTimeMillis() - start;
            if (elapsedTime > 5000) {
                LOG.info("Waiting to retry lock(" + NamedLock.LOCK_NAME(lock)
                        + ") on " + name + " for " + elapsedTime + " ms.");
            }
            DfsUtils.waitExpTime(retry);
        }
    }

    public String lockState(String name) throws IOException {
        return nameNodeWatcher.getNameNode().lockState(clientName, name);
    }

    public void promote(String name) throws LockStateException, IOException {
        long start = System.currentTimeMillis();
        for (int retry = 0; nameNodeWatcher.getNameNode().promote(clientName,
                name) != COMPLETE_SUCCESS; retry++) {
            long elapsedTime = System.currentTimeMillis() - start;
            if (elapsedTime > 5000) {
                LOG.info("Waiting to retry promote lock on " + name + " for "
                        + elapsedTime + " ms.");
            }
            DfsUtils.waitExpTime(retry);
        }
    }

    public void release(String name) throws IOException {
        nameNodeWatcher.getNameNode().releaseLock(clientName, name);
    }

    @Override
    public void close() {
        leaseChecker.cancel(true);
        randomAccessConnectionPool.close();
        synchronized (blockCacheGuard) {
            if (blockCache != null) {
                blockCache.shutdown();
            }
        }
        bgTaskPool.shutdownNow();
        try {
            RPC.asyncInvoke(nameNodeWatcher.getNameNode(), REMOVE_LEASE_METHOD,
                    clientName);
        } catch (Exception e) {
            LOG.log(Level.WARNING, clientName + " remove lease failed", e);
        }
        nameNodeWatcher.shutdown();
    }

    static void completeFile(NameNodeWatcher nameNodeWatcher,
            String clientName, String file, long completeFileRetryTimeout)
            throws IOException {
        long startTime = System.currentTimeMillis();
        for (int retry = 0;; retry++) {
            LOG.info("Completing file " + file + ", retry = " + retry);
            try {
                if (nameNodeWatcher.getNameNode().complete(clientName, file)) {
                    LOG.info("Done completing file " + file + ".");
                    break;
                }
            } catch (FSException e) {
                // FSException means that namenode can not complete file due to 
                // some unrecoverable error(i.e., file is not pending at all),
                // so we just throw the exception and give up retrying.
                LOG.log(Level.WARNING, "Could not complete file " + file, e);
                throw e;
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "Complete file in namenode failed, will retry later", e);
            }
            if (completeFileRetryTimeout > 0) {
                long maxWaitTime = completeFileRetryTimeout
                        - (System.currentTimeMillis() - startTime);
                if (maxWaitTime <= 0) {
                    throw new IOException("Complete file " + file
                            + " retry timeout(" + completeFileRetryTimeout
                            + "ms)");
                }
                DfsUtils.waitExpTime(retry, maxWaitTime);
            } else {
                DfsUtils.waitExpTime(retry);
            }
        }
    }

    @Override
    public String toString() {
        return "[DFSClient " + clientName + ", NameNodeAddr="
                + nameNodeWatcher.getNameNodeAddr() + "]";
    }

}
