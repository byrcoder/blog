/**
 * @(#)BackupFSDirectory.java, 2012-12-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import odis.dfs.common.DFSConfig;
import odis.io.CDataInputStream;
import odis.io.permission.FsPermission;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableLong;

/**
 * @author zhangduo
 */
class BackupFSDirectory extends AbstractPrimaryFSDirectory<BackupFSBlockStore> {

    BackupFSDirectory(Configuration conf, BackupFSBlockStore bstore,
            File imageFile, Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            MutableLong maxLoadedLogSN) throws IOException {
        super(bstore, imageFile, new FsPermission(conf.getInt(
                DFSConfig.NAMENODE_DEFAULT_PERMISSION,
                DFSConfig.DEFAULT_NAMENODE_DEFAULT_PERMISSION)),
                conf.getString(DFSConfig.NAMENODE_DEFAULT_GROUP,
                        DFSConfig.DEFAULT_NAMENODE_DEFAULT_GROUP),
                conf.getString(DFSConfig.NAMENODE_ADMIN,
                        DFSConfig.DEFAULT_NAMENODE_ADMIN), pendingCreates,
                pendingCreateLastBlocks, maxLoadedLogSN);
    }

    ActiveFSDirectory upgrade(ActiveFSBlockStore bstore) {
        return new ActiveFSDirectory(bstore, defaultPermission, defaultGroup,
                admin, rootDir, fsDirPropMgr, ugMgr, permissionChecker);
    }

    @Override
    long loadFSEdits(CDataInputStream in, Map<String, FileINodeUC> fileUCs,
            Map<Long, String[]> pendingBlocks, MutableLong maxLoadedLogSN)
            throws IOException {
        nodeTreeLock.writeLock().lock();
        try {
            return super.loadFSEdits(in, fileUCs, pendingBlocks, maxLoadedLogSN);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }
}
