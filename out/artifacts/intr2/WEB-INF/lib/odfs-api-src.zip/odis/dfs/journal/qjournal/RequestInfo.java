package odis.dfs.journal.qjournal;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

public class RequestInfo implements IWritable {
    private String clusterId;

    private long epoch;

    private long rpcSerialNumber;

    public RequestInfo() {}
    
    public RequestInfo(String clusterId, long epoch, long rpcSerialNumber) {
        super();
        this.clusterId = clusterId;
        this.epoch = epoch;
        this.rpcSerialNumber = rpcSerialNumber;
    }

    public String getClusterId() {
        return clusterId;
    }
    
    public void setClusterId(String clusterId) {
        this.clusterId = clusterId;
    }
    
    public long getEpoch() {
        return epoch;
    }

    public void setEpoch(long epoch) {
        this.epoch = epoch;
    }

    public long getRpcSerialNumber() {
        return rpcSerialNumber;
    }

    public void setRpcSerialNumber(long rpcSerialNumber) {
        this.rpcSerialNumber = rpcSerialNumber;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        RequestInfo that = (RequestInfo)value;
        this.clusterId = that.clusterId;
        this.epoch = that.epoch;
        this.rpcSerialNumber = that.rpcSerialNumber;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(clusterId);
        out.writeLong(epoch);
        out.writeLong(rpcSerialNumber);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        this.clusterId = in.readUTF();
        this.epoch = in.readLong();
        this.rpcSerialNumber = in.readLong();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("RequestInfo: {");
        sb.append("[clusterId=" + this.clusterId);
        sb.append("], [epoch=" + this.epoch);
        sb.append("], [rpcSerialNumber=" + this.rpcSerialNumber);
        sb.append("]}");
        return sb.toString();
    }
}
