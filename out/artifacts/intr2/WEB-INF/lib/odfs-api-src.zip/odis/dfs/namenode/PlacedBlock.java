package odis.dfs.namenode;

import java.util.Arrays;

/**
 * A class wrapping around a {@link Block} and an array of {@link DatanodeInfo}.
 * This is similar to {@link BlockLocation} but stores {@link DatanodeInfo}
 * directly. So using PlacedBlock saves the lookups. The main purpose of this
 * class is to be used as the value class in several of the mappings maintained
 * in {@link FSBlockStore}. The mappings used to map {@link Block} to things
 * like <code>List<DatanodeInfo></code> etc. The problem is, we often receive
 * the Block from the network (e.g. client report) and it misses some key
 * information (e.g. desiredReplication, length, etc.) that is already contained
 * in a Block object that we create (via e.g. FSBlockStore.allocateBlock).
 * However, since Block is used as key in the mappings, there isn't an efficient
 * way to retrieve the Block object we created so retrieving the missing
 * information has been awkward. Now we store the Block object in PlacedBlock
 * and make the mappings from blockId to PlacedBlock. This allows us to find our
 * Block object quickly.
 * 
 * @author ET 04/06/2006, zhangduo
 */
class PlacedBlock {

    private final long id;

    private int len;

    private byte desiredReplication = 0;

    private DatanodeInfo[] locs = DatanodeInfo.EMPTY_ARRAY;

    PlacedBlock(long blockId) {
        this.id = blockId;
    }

    PlacedBlock(long blockId, int len, int desiredReplication) {
        this.id = blockId;
        this.len = len;
        this.desiredReplication = (byte) desiredReplication;
    }

    long getId() {
        return id;
    }

    int getLen() {
        return len;
    }

    void setLen(int len) {
        this.len = len;
    }

    int getDesiredReplication() {
        return desiredReplication & 0xFF;
    }

    void setDesiredReplication(int desiredReplication) {
        this.desiredReplication = (byte) desiredReplication;
    }

    DatanodeInfo[] getLocs() {
        return locs;
    }

    void setLocs(DatanodeInfo[] locs) {
        this.locs = locs;
    }

    boolean containsLoc(DatanodeInfo loc) {
        for (DatanodeInfo dinfo: locs) {
            if (dinfo.equals(loc)) {
                return true;
            }
        }
        return false;
    }

    void addLoc(DatanodeInfo loc) {
        if (containsLoc(loc)) {
            return;
        }
        DatanodeInfo[] newLocs = new DatanodeInfo[locs.length + 1];
        if (locs.length > 0) {
            System.arraycopy(locs, 0, newLocs, 0, locs.length);
        }
        newLocs[locs.length] = loc;
        locs = newLocs;
    }

    boolean removeLoc(DatanodeInfo loc) {
        for (int i = 0; i < locs.length; i++) {
            if (locs[i].equals(loc)) {
                if (locs.length == 1) {
                    locs = DatanodeInfo.EMPTY_ARRAY;
                } else {
                    DatanodeInfo[] newLocs = new DatanodeInfo[locs.length - 1];
                    if (i > 0) {
                        System.arraycopy(locs, 0, newLocs, 0, i);
                    }
                    if (i < locs.length - 1) {
                        System.arraycopy(locs, i + 1, newLocs, i, locs.length
                                - i - 1);
                    }
                    locs = newLocs;
                }
                return true;
            }
        }
        return false;
    }

    void clearLocs() {
        locs = DatanodeInfo.EMPTY_ARRAY;
    }

    int replicationCount() {
        return locs.length;
    }

    @Override
    public String toString() {
        return "[PlacedBlock id=" + id + ", len=" + len
                + ", desiredReplication=" + desiredReplication + ", locs="
                + Arrays.toString(locs) + "]";
    }

}
