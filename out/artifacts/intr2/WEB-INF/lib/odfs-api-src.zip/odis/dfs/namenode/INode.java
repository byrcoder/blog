/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package odis.dfs.namenode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

import odis.io.CDataOutputStream;
import odis.io.permission.FsPermission;
import odis.serialize.lib.StringWritable;
import odis.util.KeyValueIterator;

/**
 * This class is an in-memory representation of the file/block hierarchy. It
 * keeps information about a file or directory. This class has been changed from
 * the original design in Nutch. We added reference count in this class. When
 * there is a link from 'link' to 'target', the parent of 'link' will have an
 * entry in its <code>children</code> field mapping 'link' to 'target''s
 * <code>INode</code>. An <code>INode</code> can have multiple paths/names as
 * well as multiple parents due to links. Therefore we don't keep a
 * <code>name</code> fields any more. Instead the name and path of an INode is
 * determined by the parent in the context. An INode should be accessible via
 * its parent's map, the <code>children</code> field (the corresponding key the
 * map should be the name for this node). Since we always arrive at an INode
 * from the root, traversing down the dir tree, we can always uniquely determine
 * an INode's name when we need to.
 * <p>
 * The keys in the TreeMap children are relative names. That is, they are just
 * the last names in the pathname's name sequence.
 * </p>
 * <p>
 * Each INode has a unique ID. This is mainly for saving and loading the
 * filesystem image. Because each INode may be encountered multiple times when
 * traversing the dir tree due to the existence of links, we need to bookkeep
 * which nodes have been processed.
 * </p>
 * <p>
 * CHANGED: The parent field has been removed.
 * </p>
 * 
 * @author ET
 */
// Changelog:
//  08-1-26 (zf) Created a class hierarchy to save memory.. 
//               Removed the ID field because it is needed only for loading/saving.
abstract class INode {
    public static final char SEP = '/';

    public static final String STR_SEP = Character.toString(SEP);

    protected long lastAccess;

    protected long lastModified;

    protected byte desiredReplications;

    protected long permission;

    protected long contentsLength;

    private static enum PermissionStatusFormat {
        MODE(0, 16), GROUP(MODE.OFFSET + MODE.LENGTH, 25), USER(GROUP.OFFSET
                + GROUP.LENGTH, 23);

        final int OFFSET;

        final int LENGTH; //bit length

        final long MASK;

        PermissionStatusFormat(int offset, int length) {
            OFFSET = offset;
            LENGTH = length;
            MASK = ((-1L) >>> (64 - LENGTH)) << OFFSET;
        }

        long retrieve(long record) {
            return (record & MASK) >>> OFFSET;
        }

        long combine(long bits, long record) {
            return (record & ~MASK) | (bits << OFFSET);
        }
    }

    INode(int desiredReplications, long lastAccess, long lastModified) {
        this.desiredReplications = (byte) desiredReplications;
        this.lastAccess = lastAccess;
        this.lastModified = lastModified;
        this.contentsLength = 0;
    }

    long getContentsLength() {
        return contentsLength;
    }

    void setContentsLength(long contentsLength) {
        if (contentsLength > 0) {
            this.contentsLength = contentsLength;
        } else {
            this.contentsLength = 0;
        }
    }

    long getSubDirNum() {
        return 0;
    }

    void setSubDirNum(long subDirNum) {}

    long getSubFileNum() {
        return 0;
    }

    void setSubFileNum(long subFileNum) {}

    int getRefCount() {
        return 0;
    }

    void setRefCount(int ref) {}

    void incRefCount() {}

    void decRefCount() {}

    void setDesiredReplications(int r) {
        desiredReplications = (byte) r;
    }

    int getDesiredReplications() {
        return desiredReplications & 0xFF;
    }

    long getLastAccess() {
        return lastAccess;
    }

    void setLastAccess(long lastAccess) {
        this.lastAccess = lastAccess;
    }

    long getLastModified() {
        return lastModified;
    }

    void setLastModified(long t) {
        this.lastModified = t;
    }

    int getUser() {
        return (int) PermissionStatusFormat.USER.retrieve(permission);
    }

    void setUser(int user) {
        permission = PermissionStatusFormat.USER.combine(user, permission);
    }

    int getGroup() {
        return (int) PermissionStatusFormat.GROUP.retrieve(permission);
    }

    void setGroup(int group) {
        permission = PermissionStatusFormat.GROUP.combine(group, permission);
    }

    int getFsPermission() {
        return (int) PermissionStatusFormat.MODE.retrieve(permission);
    }

    void setFsPermission(int mode) {
        permission = PermissionStatusFormat.MODE.combine(mode, permission);
    }

    abstract void saveImage(CDataOutputStream out, ImageSaveContext ctx)
            throws IOException;

    /**
     * Write a prologue to on-disk image of this INode containing common fields.
     */
    protected void savePrologue(CDataOutputStream out, ImageSaveContext ctx)
            throws IOException {
        out.writeLong(lastAccess);
        out.writeLong(lastModified);
        out.writeByte(desiredReplications);
        String user = ctx.ugMgr.getUser((int) PermissionStatusFormat.USER.retrieve(permission));
        StringWritable.writeString(out, user);
        String group = ctx.ugMgr.getGroup((int) PermissionStatusFormat.GROUP.retrieve(permission));
        StringWritable.writeString(out, group);
        int mode = (int) PermissionStatusFormat.MODE.retrieve(permission);
        out.writeShort(mode);
    }
}

abstract class FileINode extends INode {

    public static final FsPermission UMASK = FsPermission.createImmutable(00111);

    private short refCount = 1; // refCount is incremented by ln command (only for hard links) 

    FileINode(int desiredReplications, long lastAccess, long lastModified) {
        super(desiredReplications, lastAccess, lastModified);
    }

    abstract long[] getBlocks();

    abstract void setBlocks(long[] blocks);

    abstract int blockCount();

    // File INode can be reference multiple times in memory due to hard links
    @Override
    int getRefCount() {
        return refCount & 0xFFFF;
    }

    @Override
    void setRefCount(int ref) {
        this.refCount = (short) ref;
    }

    @Override
    void incRefCount() {
        setRefCount(getRefCount() + 1);
    }

    @Override
    void decRefCount() {
        int refCount = getRefCount();
        if (refCount > 0) {
            setRefCount(refCount - 1);
        }
    }

    @Override
    void saveImage(CDataOutputStream out, ImageSaveContext ctx)
            throws IOException {
        Long _id = ctx.saved.get(this);
        if (_id != null) {
            out.write(AbstractFSDirectory.ENTRY_FILE_REF);
            out.writeVLong(_id);
            return;
        }

        out.write(AbstractFSDirectory.ENTRY_FILE);
        savePrologue(out, ctx);
        // write file INode ID
        if (refCount > 1) {
            // if reference > 1 times, then we need to record this as already saved
            long id = ctx.maxId++;
            ctx.saved.put(this, id);
            out.writeVLong(id);
        } else {
            out.writeVLong(0);
        }
        // write blocks
        long[] blocks = getBlocks();
        if (blocks == null) {
            out.writeVInt(0);
        } else {
            out.writeVInt(blocks.length);
            for (int i = 0; i < blocks.length; i++) {
                out.writeLong(blocks[i]);
                out.writeVInt(ctx.getBlockLen(blocks[i]));
            }
        }

    }
}

final class NormalFileINode extends FileINode {
    private long[] blocks;

    NormalFileINode(long[] blocks, int desiredReplications, long lastAccess,
            long lastModified) {
        super(desiredReplications, lastAccess, lastModified);
        this.blocks = blocks;
    }

    @Override
    long[] getBlocks() {
        return blocks;
    }

    @Override
    void setBlocks(long[] blocks) {
        this.blocks = blocks;
    }

    @Override
    int blockCount() {
        return blocks.length;
    }
}

/**
 * A file with only a single block.
 */
final class TinyFileINode extends FileINode {
    private long block;

    TinyFileINode(long block, int desiredReplications, long lastAccess,
            long lastModified) {
        super(desiredReplications, lastAccess, lastModified);
        this.block = block;
    }

    long[] getBlocks() {
        return new long[] {
            block
        };
    }

    long getBlock() {
        return block;
    }

    @Override
    void setBlocks(long[] blocks) {
        if (blocks.length == 1) {
            block = blocks[0];
        } else {
            throw new IllegalArgumentException(
                    "Number of blocks is not exact 1. Got: " + blocks.length);
        }
    }

    @Override
    int blockCount() {
        return 1;
    }
}

class FileINodeUC extends INode {

    // lease holder
    final String holder;

    final int fileBlockSize;

    final List<BlockWithSize> blocks = new ArrayList<BlockWithSize>();

    FileINodeUC(String holder, int desiredReplications, int fileBlockSize,
            long lastAccess, long lastModified) {
        super(desiredReplications, lastAccess, lastModified);
        this.holder = holder;
        this.fileBlockSize = fileBlockSize;
    }

    @Override
    void saveImage(CDataOutputStream out, ImageSaveContext ctx)
            throws IOException {
        out.write(AbstractFSDirectory.ENTRY_FILE_UC);
        savePrologue(out, ctx);
        StringWritable.writeString(out, holder);
        out.writeVInt(fileBlockSize);
        out.writeVInt(blocks.size());
        for (BlockWithSize bs: blocks) {
            bs.writeFields(out);
        }
    }
}

final class DirectoryINode extends INode {

    private long subDirNum;

    private long subFileNum;

    private SortedArrayChildren children;

    /**
     * Create a DirectoryINode
     * 
     * @param children
     *            if not null and not empty, it will be used directly (not
     *            copied) as the children map
     * @param desiredReplications
     */
    DirectoryINode(SortedArrayChildren children, int desiredReplications,
            long lastAccess, long lastModified) {
        super(desiredReplications, lastAccess, lastModified);
        if (children != null && children.size() > 0) {
            KeyValueIterator<UTF8String, INode> iter = children.iterator();
            while (iter.hasNext()) {
                iter.next();
                this.contentsLength += iter.getValue().getContentsLength();
            }
            this.children = children;
        }
    }

    /**
     * Adds the given name to this directory.
     */
    void addChild(String name, INode node, long time) {
        if (children == null) {
            children = new SortedArrayChildren();
        }
        UTF8String nameString = UTF8String.create(name);
        if (children.containsKey(nameString)) {
            throw new IllegalStateException(name
                    + " already exists in children");
        }
        children.put(nameString, node);
        lastModified = time; // Change lastModified field for dir
    }

    private static final KeyValueIterator<UTF8String, INode> EMPTY_KEY_VALUE_ITER = new KeyValueIterator<UTF8String, INode>() {

        @Override
        public boolean hasNext() {
            return false;
        }

        @Override
        public void next() {
            throw new NoSuchElementException();
        }

        @Override
        public UTF8String getKey() {
            throw new IllegalStateException();
        }

        @Override
        public INode getValue() {
            throw new IllegalStateException();
        }

        @Override
        public void remove() {
            throw new IllegalStateException();
        }

    };

    /**
     * Return an iterator over all entries in the directory.
     */
    KeyValueIterator<UTF8String, INode> iterator() {
        return children == null ? EMPTY_KEY_VALUE_ITER : children.iterator();
    }

    /**
     * Remove a child of the directory.
     * 
     * @param time
     *            current time to be recorded as last modified time of the dir
     * @return the removed inode
     */
    INode removeChild(String name, long time) {
        INode removed = null;
        if (children != null) {
            removed = children.remove(UTF8String.create(name));
            if (removed != null) {
                lastModified = time;
            }
        }
        return removed;
    }

    /**
     * Return the number of children of this directory.
     * 
     * @return
     */
    int size() {
        return children == null ? 0 : children.size();
    }

    boolean hasChild() {
        return size() > 0;
    }

    void removeAllChildren(long time) {
        if (children != null && children.size() > 0) {
            children.clear();
            children = null;
            lastModified = time;
        }
    }

    @Override
    void saveImage(CDataOutputStream out, ImageSaveContext ctx)
            throws IOException {
        out.write(AbstractFSDirectory.ENTRY_DIR);
        savePrologue(out, ctx);
        if (children == null) {
            out.writeVInt(0);
        } else {
            out.writeVInt(children.size());
            KeyValueIterator<UTF8String, INode> iter = children.iterator();
            while (iter.hasNext()) {
                iter.next();
                // First save the child's path since the child doesn't know it
                String childName = iter.getKey().toString();
                StringWritable.writeString(out, childName);
                if (childName.equals("data")) {
                    out.flush();
                }
                INode child = iter.getValue();
                child.saveImage(out, ctx);
            }
        }
    }

    /**
     * Find a return a child.
     */
    INode getChild(String childName) {
        if (children == null) {
            return null;
        }
        return children.get(UTF8String.create(childName));
    }

    @Override
    long getSubDirNum() {
        return subDirNum;
    }

    @Override
    void setSubDirNum(long subDirNum) {
        this.subDirNum = subDirNum;
    }

    @Override
    long getSubFileNum() {
        return subFileNum;
    }

    @Override
    void setSubFileNum(long subFileNum) {
        this.subFileNum = subFileNum;
    }

}

class ImageSaveContext {
    HashMap<INode, Long> saved = new HashMap<INode, Long>();

    long maxId = 1;

    UserGroupManager ugMgr;

    AbstractFSBlockStore bstore;

    void clear() {
        saved.clear();
    }

    int getBlockLen(long block) {
        return bstore.getBlockLen(block);
    }

    ImageSaveContext(AbstractFSBlockStore bstore, UserGroupManager ugMgr) {
        this.bstore = bstore;
        this.ugMgr = ugMgr;
    }
}

final class INodeInfo {

    final long lastAccess;

    final long lastModified;

    final int desiredReplications;

    final long contentsLength;

    final long subDirNum;

    final long subFileNum;

    final int refCount;

    final String user;

    final String group;

    final FsPermission permission;

    INodeInfo(long lastAccess, long lastModified, int desiredReplications,
            long contentsLength, long subDirNum, long subFileNum, int refCount,
            String user, String group, FsPermission permission) {
        this.lastAccess = lastAccess;
        this.lastModified = lastModified;
        this.desiredReplications = desiredReplications;
        this.contentsLength = contentsLength;
        this.subDirNum = subDirNum;
        this.subFileNum = subFileNum;
        this.refCount = refCount;
        this.user = user;
        this.group = group;
        this.permission = permission;
    }

    static INodeInfo create(INode node, UserGroupManager ugMgr) {
        return new INodeInfo(node.getLastAccess(), node.getLastModified(),
                node.getDesiredReplications(), node.getContentsLength(),
                node.getSubDirNum(), node.getSubFileNum(), node.getRefCount(),
                ugMgr.getUser(node.getUser()), ugMgr.getGroup(node.getGroup()),
                new FsPermission(node.getFsPermission()));
    }

    @Override
    public String toString() {
        return "INodeInfo [lastAccess=" + lastAccess + ", lastModified="
                + lastModified + ", desiredReplications=" + desiredReplications
                + ", contentsLength=" + contentsLength + ", subDirNum="
                + subDirNum + ", subFileNum=" + subFileNum + ", refCount="
                + refCount + ", user=" + user + ", group=" + group
                + ", permission=" + permission + "]";
    }

}
