/**
 * @(#)DFSOutputStream.java, 2012-12-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.DataNodeRequest;
import odis.dfs.common.DataNodeRequest.Op;
import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.util.DfsUtils;
import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.io.FSOutputStream;
import odis.io.InterruptibleSocket;
import odis.io.ReadWriteUtils;
import odis.io.TimeoutPolicy;
import odis.io.permission.FsPermission;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * FSOutputStream that writing file data to ODFS.
 * 
 * @author zhangduo
 */
public class DFSOutputStream extends FSOutputStream implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(DFSOutputStream.class);

    private final AtomicLong counter;

    private final NameNodeWatcher nameNodeWatcher;

    private final String file;

    private final boolean overwrite;

    private final boolean createParent;

    private final int flags;

    private final int fileBlockSize;

    private final int replication;

    private final FsPermission permission;

    private final String clientName;

    private final Adler32 blockChecksum = new Adler32();

    private final long timeout;

    private final long createBlockRetryTimeout;

    private final int recoverBufferSize;

    private final int recoverMaxRetryCount;

    private final long completeFileRetryTimeout;

    private int currentBlockIndex;

    private int currentBlockSize;

    private BlockLocationWithDataPath firstBlock;

    private BlockLocationWithDataPath lblock;

    private InterruptibleSocket socket;

    private LocalBackup localBackup;

    private OutputStream localBackupOutput;

    private final BlockCache blockCache;

    private RandomAccessFile blockCacheOutput;

    DFSOutputStream(NameNodeWatcher nameNodeWatcher, String file,
            boolean overwrite, boolean createParent, int flags,
            int fileBlockSize, int replication, FsPermission permission,
            String clientName, BlockCache blockCache, AtomicLong writeCounter,
            DFSClientConfig conf) throws IOException {
        this.nameNodeWatcher = nameNodeWatcher;
        this.file = file;
        this.overwrite = overwrite;
        this.createParent = createParent;
        this.flags = flags;
        this.fileBlockSize = fileBlockSize;
        this.replication = replication;
        this.permission = permission;
        this.clientName = clientName;
        this.counter = writeCounter;
        this.timeout = conf.getBlockWriteTimeout();
        this.createBlockRetryTimeout = conf.getCreateBlockWriteRetryTimeout();
        this.recoverBufferSize = conf.getRecoverBufferSize();
        this.recoverMaxRetryCount = conf.getRecoverBlockMaxRetryCount();
        this.completeFileRetryTimeout = conf.getCompleteFileRetryTimeout();
        this.blockCache = blockCache;
        createBlockCacheOutput();
        openBlock(true);
        newLocalBackup();
    }

    private boolean useLocalBackup() {
        return (flags & DFSClient.OS_NOLOCALBACKUP) == 0;
    }

    private void newLocalBackup() {
        if (!useLocalBackup()) {
            return;
        }
        LocalBackupManager manager = LocalBackupManager.getInstance();
        try {
            localBackup = manager.getBackup();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "create local backup failed", e);
            return;
        }
        try {
            localBackupOutput = localBackup.getOutputStream();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "create local backup output failed", e);
        }
    }

    private void releaseLocalBackup() {
        if (localBackupOutput != null) {
            ReadWriteUtils.safeClose(localBackupOutput);
            localBackupOutput = null;
        }
        if (localBackup != null) {
            LocalBackupManager manager = LocalBackupManager.getInstance();
            try {
                manager.releaseBackup(localBackup);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "release backup failed", e);
            }
            localBackup = null;
        }
    }

    private void writeToLocalBackup(byte[] b, int off, int len) {
        if (localBackupOutput == null) {
            return;
        }
        try {
            localBackupOutput.write(b, off, len);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "write to local backup failed", e);
            releaseLocalBackup();
        }
    }

    private void createBlockCacheOutput() {
        if ((flags & DFSClient.OS_WRITETOCACHE) == 0) {
            return;
        }
        String tempFileId = BlockCache.getBlockCacheFileId(file,
                new BlockSizeLocationWithDataPath[0]);
        try {
            blockCacheOutput = new RandomAccessFile(new File(
                    blockCache.cacheDir(), tempFileId), "rw");
        } catch (Exception e) {
            LOG.log(Level.WARNING, "create block cache output failed", e);
        }
    }

    private void writeToBlockCacheOutput(byte[] b, int off, int len) {
        if (blockCacheOutput == null) {
            return;
        }
        try {
            blockCacheOutput.write(b, off, len);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "write to block cache failed", e);
            ReadWriteUtils.safeClose(blockCacheOutput);
            blockCacheOutput = null;
            String tempFileId = BlockCache.getBlockCacheFileId(file,
                    new BlockSizeLocationWithDataPath[0]);
            if (!new File(blockCache.cacheDir(), tempFileId).delete()) {
                LOG.warning("Clean broken block cache file " + tempFileId
                        + " failed");
            }
        }
    }

    private void closeBlockSocket() {
        ReadWriteUtils.safeClose(socket);
        socket = null;
    }

    private void abandonBlock(boolean firstBlock) {
        if (firstBlock) {
            try {
                nameNodeWatcher.getNameNode().abandonFileInProgress(clientName,
                        file);
                this.firstBlock = null;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "abandon file " + file + " failed", e);
            }
        } else {
            try {
                nameNodeWatcher.getNameNode().abandonBlock(clientName, file,
                        currentBlockIndex);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "abandon " + currentBlockIndex
                        + "th block of file " + file + " failed", e);
            }
        }
    }

    private void openBlockRetryWait(long startTime, int retry)
            throws IOException {
        if (createBlockRetryTimeout <= 0) {
            DfsUtils.waitExpTime(retry);
            return;
        }
        long maxWaitTime = createBlockRetryTimeout
                - (System.currentTimeMillis() - startTime);
        if (maxWaitTime <= 0) {
            throw new IOException("Open block for file " + file + " timeout("
                    + createBlockRetryTimeout + "ms)");
        }
        DfsUtils.waitExpTime(retry, maxWaitTime);
    }

    private final DirectByteArrayOutputStream bufRawOut = new DirectByteArrayOutputStream();

    private final CDataOutputStream bufDataOut = new CDataOutputStream(
            bufRawOut);

    private void openBlock(boolean firstBlock) throws IOException {
        long startTime = System.currentTimeMillis();
        for (int retry = 0;; retry++) {
            BlockLocationWithDataPath lblock;
            try {
                if (firstBlock) {
                    LOG.info("Asking for the first block for " + file);
                    lblock = nameNodeWatcher.getNameNode().create(clientName,
                            file, overwrite, createParent, replication,
                            fileBlockSize, permission);
                } else {
                    LOG.info("Asking for the " + currentBlockIndex
                            + "th block for " + file);
                    lblock = nameNodeWatcher.getNameNode().addBlock(clientName,
                            file, currentBlockIndex);
                }
            } catch (IllegalArgumentException e) {
                throw e;
            } catch (FSException e) {
                if (e.getCode() == FSException.INVALID_BLOCK_INDEX) {
                    // this usually because we failed to abandon block, try 
                    // abandon it again.
                    abandonBlock(false);
                } else if (e.getCode() != FSException.NOT_ENOUGH_RESOURCE
                        && e.getCode() != FSException.NOT_ENOUGH_REPLICATION) {
                    throw e;
                }

                LOG.log(Level.WARNING, "open block failed, retry = "
                        + (retry + 1), e);
                openBlockRetryWait(startTime, retry);
                continue;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "open block failed, retry = "
                        + (retry + 1), e);
                openBlockRetryWait(startTime, retry);
                continue;
            }

            try {
                socket = DfsUtils.createConnection(lblock.getLocations()[0],
                        timeout, TimeoutPolicy.RESPONSE_IN_TIME);
                DataNodeRequest req = new DataNodeRequest(Op.WRITE_BLOCK);
                DataNodeRequest.WriteBlockBody reqBody = (DataNodeRequest.WriteBlockBody) req.getBody();
                reqBody.setBlock(lblock.getBlock());
                reqBody.setReportCond(useLocalBackup() ? ReportCond.ON_COMPLETION
                        : ReportCond.ALWAYS);
                reqBody.setTargets(lblock.getLocations());
                bufRawOut.reset();
                req.writeFields(bufDataOut);
                bufRawOut.writeTo(socket.getOutputStream());
                LOG.info("Allocated " + currentBlockIndex + "th block "
                        + lblock.getBlock() + " of file " + file + " on "
                        + Arrays.toString(lblock.getLocations()));
                this.lblock = lblock;
                if (firstBlock) {
                    this.firstBlock = lblock;
                }
                break;
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "Connecting to datanode failed when write "
                                + currentBlockIndex + "th block "
                                + lblock.getBlock() + " of file " + file
                                + ", retry = " + (retry + 1), e);
                closeBlockSocket();
                abandonBlock(firstBlock);
                openBlockRetryWait(startTime, retry);
            }
        }
    }

    @Override
    public long getPos() throws IOException {
        return (long) currentBlockIndex * fileBlockSize + currentBlockSize;
    }

    private final byte[] singleByte = new byte[1];

    @Override
    public void write(int b) throws IOException {
        singleByte[0] = (byte) b;
        write(singleByte);
    }

    private void endBlock() throws IOException {
        bufRawOut.reset();
        bufDataOut.writeInt(CHUNK_SIZE_END_OF_BLOCK);
        bufDataOut.writeLong(blockChecksum.getValue());
        bufRawOut.writeTo(socket.getOutputStream());
        int successCount = socket.getInputStream().read();
        if (successCount <= 0) {
            throw new IOException("Write block " + lblock.getBlock()
                    + " to datanodes " + Arrays.toString(lblock.getLocations())
                    + " failed(successCount = " + successCount + ")");
        }
        String[] successTargets = successCount == lblock.getLocations().length ? lblock.getLocations()
                : Arrays.copyOf(lblock.getLocations(), successCount);
        LOG.info("Finished block " + lblock.getBlock() + ". Have written to "
                + Arrays.toString(successTargets));
        ReadWriteUtils.safeClose(socket);
        socket = null;
        releaseLocalBackup();
    }

    // return bytes written
    private int writeInternal(byte[] b, int off, int len) throws IOException {
        if (socket == null) {
            // open new block first
            currentBlockIndex++;
            currentBlockSize = 0;
            blockChecksum.reset();
            openBlock(false);
            newLocalBackup();
        }
        int toWrite = Math.min(len, fileBlockSize - currentBlockSize);
        bufRawOut.reset();
        bufDataOut.writeInt(toWrite);
        bufRawOut.writeTo(socket.getOutputStream());
        socket.getOutputStream().write(b, off, toWrite);
        counter.addAndGet(toWrite);
        writeToLocalBackup(b, off, toWrite);
        blockChecksum.update(b, off, toWrite);
        currentBlockSize += toWrite;
        return toWrite;
    }

    // return false means write block to datanode failed
    // throw exception means read backup failed
    private boolean recoverUsingLocalBackup(byte[] buf, Adler32 adler32)
            throws IOException {
        InputStream in = localBackup.getInputStream();
        try {
            CDataOutputStream.writeInt(currentBlockSize, buf, 0);
            try {
                socket.getOutputStream().write(buf, 0, 4);
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "write data length to datanode failed when recovering",
                        e);
                return false;
            }
            for (int remaining = currentBlockSize; remaining > 0;) {
                int read = in.read(buf);
                if (read < 0) {
                    throw new EOFException(
                            "Got unexpected EOF when read data from backup");
                }
                try {
                    socket.getOutputStream().write(buf, 0, read);
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "write data to datanode failed when recovering", e);
                    return false;
                }
                adler32.update(buf, 0, read);
                remaining -= read;
            }
            if (adler32.getValue() != blockChecksum.getValue()) {
                throw new IOException(
                        "Checksum mismatch when recovering "
                                + currentBlockIndex
                                + "th block of file "
                                + file
                                + ", expected "
                                + HexString.intToPaddedHex((int) blockChecksum.getValue())
                                + ", actual "
                                + HexString.intToPaddedHex((int) adler32.getValue()));
            }
            return true;
        } finally {
            ReadWriteUtils.safeClose(in);
        }
    }

    private void recoverUsingLocalBackup() throws IOException {
        LOG.info("Recovering " + currentBlockIndex + "th block of file " + file
                + " using local backup");
        byte[] buf = new byte[recoverBufferSize];
        Adler32 adler32 = new Adler32();
        for (int retry = 0;; retry++) {
            boolean firstBlock = currentBlockIndex == 0;
            abandonBlock(firstBlock);
            openBlock(firstBlock);
            adler32.reset();
            boolean backupFailed = true;
            try {
                if (recoverUsingLocalBackup(buf, adler32)) {
                    backupFailed = false;
                    break;
                } else {
                    backupFailed = false;
                    if (recoverMaxRetryCount >= 0
                            && retry >= recoverMaxRetryCount) {
                        throw new IOException("recover " + currentBlockIndex
                                + "th block of file " + file
                                + " failed after retry " + (retry + 1)
                                + " times");
                    }
                    LOG.warning("recover " + currentBlockIndex
                            + "th block of file " + file + " failed, retry = "
                            + (retry + 1));
                    DfsUtils.waitExpTime(retry);
                }
            } finally {
                if (backupFailed) {
                    releaseLocalBackup();
                }
            }
        }
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        assertOpen();
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        } else if (len == 0) {
            return;
        }
        trouble = true;
        writeToBlockCacheOutput(b, off, len);
        while (len > 0) {
            try {
                int written = writeInternal(b, off, len);
                len -= written;
                off += written;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "write to datanode for file " + file
                        + " failed", e);
                closeBlockSocket();
                if (currentBlockSize == 0) {
                    // we have not write any data to the new block, so just
                    // abandon it and open a new one
                    boolean firstBlock = currentBlockIndex == 0;
                    abandonBlock(firstBlock);
                    openBlock(firstBlock);
                    continue;
                }
                if (localBackup == null) {
                    // no local backup available, give up
                    throw new IOException(
                            "No local backup available, can not recover", e);
                }
                recoverUsingLocalBackup();
            }
            if (currentBlockSize == fileBlockSize) {
                for (;;) {
                    try {
                        endBlock();
                        break;
                    } catch (Exception e) {
                        LOG.log(Level.WARNING,
                                "finish block on datanode for file " + file
                                        + " failed", e);
                        if (localBackup == null) {
                            // no local backup available, give up
                            throw new IOException(
                                    "No local backup available, can not recover",
                                    e);
                        }
                        recoverUsingLocalBackup();
                    }
                }
            }
        }
        trouble = false;
    }

    private boolean trouble = false;

    private boolean closed = false;

    private boolean closingDown = false;

    private void assertOpen() throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        if (trouble) {
            throw new IOException("Stream is broken");
        }
    }

    @Override
    public void flush() throws IOException {
        assertOpen();
        if (socket == null) {
            return;
        }
        trouble = true;
        bufRawOut.reset();
        bufDataOut.writeInt(CHUNK_SIZE_FLUSH_WITHOUT_RESPONSE);
        try {
            bufRawOut.writeTo(socket.getOutputStream());
        } catch (Exception e) {
            LOG.log(Level.WARNING, "flush for file " + file + " failed", e);
            if (localBackup == null) {
                throw new IOException(
                        "No local backup available, can not recover", e);
            }
            recoverUsingLocalBackup();
        }
        trouble = false;
    }

    @Override
    public void close() throws IOException {
        if (closingDown) {
            return;
        }
        closed = true;
        if (blockCacheOutput != null) {
            // register it anyway, if we fail to complete, block cache gc will
            // delete it eventually
            ReadWriteUtils.safeClose(blockCacheOutput);
            String tempFileId = BlockCache.getBlockCacheFileId(file,
                    new BlockSizeLocationWithDataPath[0]);
            File tempCacheFile = new File(blockCache.cacheDir(), tempFileId);
            if (firstBlock != null) {
                String targetFileId = BlockCache.getBlockCacheFileId(
                        file,
                        new BlockSizeLocationWithDataPath[] {
                            new BlockSizeLocationWithDataPath(
                                    firstBlock.getBlock(), 0,
                                    firstBlock.getLocations())
                        });
                if (!tempCacheFile.renameTo(new File(blockCache.cacheDir(),
                        targetFileId))) {
                    LOG.warning("Rename block cache from " + tempFileId
                            + " to " + targetFileId + " failed");
                    if (tempCacheFile.exists() && !tempCacheFile.delete()) {
                        LOG.warning("Delete unused block cache file "
                                + tempFileId + " failed");
                    }
                } else {
                    blockCache.registerCachedFile(targetFileId,
                            currentBlockIndex + 1);
                }
            } else {
                if (tempCacheFile.exists() && !tempCacheFile.delete()) {
                    LOG.warning("Delete unused block cache file " + tempFileId
                            + " failed");
                }
            }
        }
        if (socket != null) {
            for (;;) {
                try {
                    endBlock();
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "finish block on datanode for file "
                            + file + " when complete failed", e);
                    if (localBackup != null) {
                        try {
                            recoverUsingLocalBackup();
                            continue;
                        } catch (Exception ex) {
                            LOG.log(Level.WARNING, "recover block for file "
                                    + file + " when complete failed", ex);
                        }
                    }
                }
                // fall through to complete the file anyway.
                break;
            }
        }
        DFSClient.completeFile(nameNodeWatcher, clientName, file,
                completeFileRetryTimeout);
        closingDown = true;
    }
}
