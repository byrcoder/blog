package odis.dfs.journal.qjournal.client;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.logging.Logger;

import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

/**
 * A merged input stream that handles failover between different edit logs.
 *
 * We will currently try each edit log stream exactly once.  In other words, we
 * don't handle the "ping pong" scenario where different edit logs contain a
 * different subset of the available edits.
 * 
 * @author chenxi
 */
public class RedundantInputStream extends InputStream {
    private static final Logger LOG = LogFormatter
            .getLogger(RedundantInputStream.class);

    static private enum State {
        /** We need to skip curByte */
        SKIP_UNTIL,
        /** We're ready to read out of the current stream */
        OK,
        /** The current stream has failed. */
        STREAM_FAILED,
    }
    private State state;
    
    private IOException prevException;
    
    private InputStream[] streams;
    
    private URL[] urls;

    private int curIdx;

    private long curByte;

    public RedundantInputStream(List<InputStream> streams, List<URL> urls)
            throws IOException {
        if (streams.isEmpty()) {
            throw new IOException("No valid input stream to read");
        }
        this.state = State.OK;
        this.streams = new InputStream[streams.size()];
        this.streams = streams.toArray(new InputStream[0]);
        this.urls = urls.toArray(new URL[0]);
        curIdx = 0;
        curByte = 0;
    }

    private void skipUtil() throws IOException {
        InputStream stream = streams[curIdx];
        long skiped = stream.skip(curByte);
        if (skiped != curByte) {
            throw new IOException("Failed to skip " + curByte + " in stream "
                    + urls[curIdx]);
        }
    }
    
    @Override
    public int read() throws IOException{
        while (true) {
            switch (state) {
                case SKIP_UNTIL:
                    try {
                        LOG.info("Fast-forwarding stream '" + urls[curIdx]
                                + "' to byte ID " + curByte);
                        this.skipUtil();
                    } catch (IOException e) {
                        prevException = e;
                        state = State.STREAM_FAILED;
                    }
                    state = State.OK;
                    break;
                case OK:
                    try {
                        int res = streams[curIdx].read();
                        ++ curByte;
                        return res;
                    } catch (IOException e) {
                        prevException = e;
                        state = State.STREAM_FAILED;
                    }
                    break;
                case STREAM_FAILED:
                    if (curIdx + 1 == streams.length) {
                        throw prevException;
                    }
                    curIdx++;
                    LOG.warning("failing over to edit log " + urls[curIdx]);
                    state = State.SKIP_UNTIL;
                    break;
            }
        }
    }
    
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        while (true) {
            switch (state) {
                case SKIP_UNTIL:
                    try {
                        LOG.info("Fast-forwarding stream '" + urls[curIdx]
                                + "' to byte ID " + curByte);
                        this.skipUtil();
                    } catch (IOException e) {
                        prevException = e;
                        state = State.STREAM_FAILED;
                    }
                    state = State.OK;
                    break;
                case OK:
                    try {
                        int byteRead = streams[curIdx].read(b, off, len);
                        curByte += byteRead;
                        return byteRead;
                    } catch (IOException e) {
                        prevException = e;
                        state = State.STREAM_FAILED;
                    }
                    break;
                case STREAM_FAILED:
                    if (curIdx + 1 == streams.length) {
                        throw prevException;
                    }
                    curIdx++;
                    LOG.warning("failing over to edit log " + urls[curIdx]);
                    state = State.SKIP_UNTIL;
                    break;
            }
        }
    }

    @Override
    public void close() throws IOException {
        for (InputStream stream: streams) {
            ReadWriteUtils.safeClose(stream);
        }
    }
}
