/**
 * @(#)BlockCheckResult.java, 2009-2-16. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;

/**
 * @author zhangkun
 */
public class BlockCheckResult implements IWritable {

    public static final BlockCheckResult RESULT_BLOCK_READ_ERROR = new BlockCheckResult(
            Result.BLOCK_READ_ERROR, FSConstants.CHECKUM_NA,
            FSConstants.CHECKUM_NA);

    private long originalChecksum = FSConstants.CHECKUM_NA;

    private long calculatedChecksum = FSConstants.CHECKUM_NA;

    private Result result;

    public BlockCheckResult() {}

    public BlockCheckResult(Result result, long originalChecksum,
            long calculatedChecksum) {
        this.result = result;
        this.originalChecksum = originalChecksum;
        this.calculatedChecksum = calculatedChecksum;
    }

    public static enum Result {
        MATCH((byte) 1), // OC (original checksum) and CC (calculated checksum) match
        MISMATCH((byte) 2), // OC and CC doesn't match
        BLOCK_READ_ERROR((byte) 3), // failed to read block data
        ORIGINAL_CHECKSUM_READ_ERROR((byte) 4), // block data is read and got CC; OC exists but failed to read
        ORIGINAL_CHECKSUM_NOT_EXIST((byte) 5); // block data is read and got CC, but OC doesn't exist
        private final byte code;

        private static final Map<Byte, Result> codeMap = new HashMap<Byte, Result>();

        private Result(byte code) {
            this.code = code;
        }

        static {
            for (Result result: Result.values()) {
                codeMap.put(result.code, result);
            }
        }

        public static Result valueOf(byte code) {
            return codeMap.get(code);
        }
    }

    public void readFields(DataInput in) throws IOException {
        byte resultCode = in.readByte();
        result = Result.valueOf(resultCode);
        if (result == null) {
            throw new IOException("Unknown result code: " + resultCode);
        }
        originalChecksum = in.readLong();
        calculatedChecksum = in.readLong();
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(result.code);
        out.writeLong(originalChecksum);
        out.writeLong(calculatedChecksum);
    }

    public IWritable copyFields(IWritable value) {
        BlockCheckResult other = (BlockCheckResult) value;
        this.result = other.result;
        this.originalChecksum = other.originalChecksum;
        this.calculatedChecksum = other.calculatedChecksum;
        return this;
    }

    public long getOriginalChecksum() {
        return originalChecksum;
    }

    public long getCalculatedChecksum() {
        return calculatedChecksum;
    }

    public Result getResult() {
        return result;
    }

    @Override
    public String toString() {
        return "["
                + result
                + " OC="
                + ((originalChecksum == FSConstants.CHECKUM_NA) ? "NA"
                        : originalChecksum)
                + " CC="
                + ((calculatedChecksum == FSConstants.CHECKUM_NA) ? "NA"
                        : calculatedChecksum) + "]";
    }

    public void setOriginalChecksum(long originalChecksum) {
        this.originalChecksum = originalChecksum;
    }

    public void setCalculatedChecksum(long calculatedChecksum) {
        this.calculatedChecksum = calculatedChecksum;
    }

    public void setResult(Result result) {
        this.result = result;
    }
}
