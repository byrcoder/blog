package odis.dfs.journal.qjournal.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import com.google.common.base.Joiner;

/**
 * Exception thrown when too many exceptions occur while gathering responses to
 * a quorum call.
 */
public class QuorumException extends IOException {

    private static final long serialVersionUID = 1L;
    
    /**
     * Create a QuorumException instance with a descriptive message detailing
     * the underlying exceptions, as well as any successful responses which were
     * returned.
     * 
     * @param <K>
     *            the keys for the quorum calls
     * @param <V>
     *            the success response type
     * @param successes
     *            any successful responses returned
     * @param exceptions
     *            the exceptions returned
     */
    public static <K, V> QuorumException create(String simpleMsg,
            Map<K, V> successes, Map<K, Throwable> exceptions) {
        if (exceptions.isEmpty()) {
            throw new RuntimeException( "Must pass exceptions");
        }

        StringBuilder msg = new StringBuilder();
        msg.append(simpleMsg).append(". ");
        if (!successes.isEmpty()) {
            msg.append(successes.size()).append(" successful responses:\n");

            Joiner.on("\n").useForNull("null [success]")
                    .withKeyValueSeparator(": ").appendTo(msg, successes);
            msg.append("\n");
        }

        msg.append(exceptions.size() + " exceptions thrown:\n");
        boolean isFirst = true;

        for (Map.Entry<K, Throwable> e: exceptions.entrySet()) {
            if (!isFirst) {
                msg.append("\n");
            }
            isFirst = false;

            msg.append(e.getKey()).append(": ");

            if (e.getValue() instanceof RuntimeException) {
                msg.append(stringifyException(e.getValue()));
            } else if (e.getValue().getLocalizedMessage() != null) {
                msg.append(e.getValue().getLocalizedMessage());
            } else {
                msg.append(stringifyException(e.getValue()));
            }
        }
        return new QuorumException(msg.toString());
    }

    private QuorumException(String msg) {
        super(msg);
    }

    /**
     * Make a string representation of the exception.
     * @param e The exception to stringify
     * @return A string with exception name and call stack.
     */
    public static String stringifyException(Throwable e) {
      StringWriter stm = new StringWriter();
      PrintWriter wrt = new PrintWriter(stm);
      e.printStackTrace(wrt);
      wrt.close();
      return stm.toString();
    }
}
