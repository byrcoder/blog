/**
 * @(#)BlockPlacementPolicy.java, 2011-12-25. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import odis.dfs.common.FSException;

/**
 * This is an abstract interface to describe the block reserve policy.
 * 
 * @author zhangduo
 */
interface BlockPlacementPolicy {

    /**
     * Add a datanode for placement
     * 
     * @param dinfo
     */
    void addDatanode(DatanodeInfo dinfo);

    /**
     * Remove a datanode from placement candidate.
     * 
     * @param dinfo
     */
    void removeDatanode(DatanodeInfo dinfo);

    /**
     * Reserve a block on some datanodes.
     * <p>
     * Note the return array's length may be less than replicas -
     * alreadyChosenNodes.size(), but never be zero length or null. We will
     * throw FSException if we can not get at least one datanode to reserve for
     * the block.
     * 
     * @param block
     *            the block id
     * @param replicas
     *            the total replication count(i.e., your block has
     *            DesiredReplication as 3, and 2 datanodes already contains it,
     *            then you should pass 3, not 1 here)
     * @param alreadyChosen
     *            the datanodes already contains the given block.
     * @param expectedBlockSize
     *            the block size
     * @return the datanodes that reserve space for the block
     * @throws FSException
     *             if we can not get at lease one datanode to reserve
     */
    DatanodeInfo[] chooseTargets(String srcHost, long block, int replicas,
            DatanodeInfo[] alreadyChosenNodes, int expectedBlockSize)
            throws FSException;

    /**
     * Calculate to deleted replications for over-replicated blocks.
     * <p>
     * This method should have a determinate result, which means for the same
     * datanodes and desiredRelication, the returned to deleted locations should
     * be same. This can reduce the hurt of bug 37046(block missing).
     * 
     * @param datanodes
     * @param desiredRelication
     * @return the datanodes which you should delete replications on it.
     * @see https://dev.corp.youdao.com/bugs/show_bug.cgi?id=37046
     */
    DatanodeInfo[] calcToDeletedLocations(DatanodeInfo[] datanodes,
            int desiredReplication);

}
