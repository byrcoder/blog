/**
 * @(#)DataXceiveServer.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.IOException;
import java.nio.ByteOrder;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.io.DirectByteBufferPool;
import odis.io.ReadWriteUtils;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class DataXceiveServer extends Thread {

    private static final Logger LOG = LogFormatter.getLogger(DataXceiveServer.class);

    private static final long SELECT_TIMEOUT = 1000;

    private final Selector selector;

    private final DataXceiveWorker[] workers;

    final DirectByteBufferPool directByteBufferPool;

    private int nextWorker = 0;

    private static enum Op {
        REGISTER, CANCEL
    }

    private static final class WaitingEntry {
        final DataNode dataNode;

        final Op op;

        boolean finished = false;

        WaitingEntry(DataNode dataNode, Op op) {
            this.dataNode = dataNode;
            this.op = op;
        }
    }

    private final List<WaitingEntry> waitingList = new ArrayList<WaitingEntry>();

    private volatile boolean running = true;

    DataXceiveServer(Configuration conf) throws IOException {
        super("DataXceiveServer");
        setDaemon(true);
        selector = Selector.open();
        int workerCount = conf.getInt(
                DFSConfig.DATANODE_DATAXCEIVE_WORKER_COUNT,
                DFSConfig.DEFAULT_DATANODE_DATAXCEIVE_WORKER_COUNT);
        workers = new DataXceiveWorker[workerCount];
        for (int i = 0; i < workerCount; i++) {
            workers[i] = new DataXceiveWorker();
        }
        this.directByteBufferPool = new DirectByteBufferPool(
                conf.getInt(DFSConfig.DATANODE_DIRECT_BYTE_BUFFER_SIZE,
                        DFSConfig.DEFAULT_DATANODE_DIRECT_BYTE_BUFFER_SIZE),
                conf.getInt(
                        DFSConfig.DATANODE_DIRECT_BYTE_BUFFER_CHUNK_SIZE,
                        DFSConfig.DEFAULT_DATANODE_DIRECT_BYTE_BUFFER_CHUNK_SIZE),
                ByteOrder.LITTLE_ENDIAN);
    }

    private void doSelection() throws IOException {
        int count = selector.select(SELECT_TIMEOUT);
        if (count > 0) {
            Set<SelectionKey> keys = selector.selectedKeys();
            for (SelectionKey key: keys) {
                try {
                    if (key.isAcceptable()) {
                        DataNode dataNode = (DataNode) key.attachment();
                        SocketChannel socket = dataNode.socket.accept();
                        socket.configureBlocking(false);
                        socket.socket().setTcpNoDelay(true);
                        LOG.info("Connection " + socket + " started");
                        DataXceiveWorker worker = workers[nextWorker];
                        nextWorker = (nextWorker + 1) % workers.length;
                        Connection conn = new Connection(socket, worker,
                                dataNode, directByteBufferPool);
                        worker.register(conn);
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "got exception when accept " + key,
                            e);
                }
            }
            keys.clear();
        }
    }

    private void doRegistry(DataNode dataNode) {
        SelectionKey k = dataNode.socket.keyFor(selector);
        try {
            if (k == null) {
                dataNode.socket.register(selector, SelectionKey.OP_ACCEPT,
                        dataNode);
            }
        } catch (ClosedChannelException e) {
            LOG.log(Level.WARNING, dataNode.fullName + " already closed", e);
        }
    }

    private void doCancellation(DataNode dataNode) {
        SelectionKey key = dataNode.socket.keyFor(selector);
        if (key != null) {
            key.cancel();
        }
        ReadWriteUtils.safeClose(dataNode.socket);
    }

    private void doRegistryOrCancellation() {
        synchronized (waitingList) {
            for (WaitingEntry entry: waitingList) {
                switch (entry.op) {
                    case REGISTER:
                        doRegistry(entry.dataNode);
                        break;
                    case CANCEL:
                        doCancellation(entry.dataNode);
                        break;
                    default:
                        LOG.warning("DataXceiveServer found unknown op: "
                                + entry.op);
                }
                synchronized (entry) {
                    entry.finished = true;
                    entry.notifyAll();
                }
            }
            waitingList.clear();
        }
    }

    private void addToWaitingList(WaitingEntry entry, boolean join) {
        boolean needWakeup = false;
        synchronized (waitingList) {
            if (waitingList.isEmpty()) {
                needWakeup = true;
            }
            waitingList.add(entry);
        }
        if (needWakeup) {
            selector.wakeup();
        }
        if (join) {
            synchronized (entry) {
                while (!entry.finished) {
                    try {
                        entry.wait();
                    } catch (InterruptedException e) {}
                }
            }
        }
    }

    void register(DataNode dataNode, boolean join) {
        addToWaitingList(new WaitingEntry(dataNode, Op.REGISTER), join);
    }

    void cancel(DataNode dataNode, boolean join) {
        addToWaitingList(new WaitingEntry(dataNode, Op.CANCEL), join);
    }

    void startServer() {
        start();
        for (DataXceiveWorker worker: workers) {
            worker.start();
        }
    }

    @Override
    public void run() {
        LOG.info("DataXceiveServer started");
        while (running) {
            try {
                doSelection();
            } catch (Throwable t) {
                LOG.log(Level.SEVERE, "unexpected throwable caught", t);
            }
            try {
                doRegistryOrCancellation();
            } catch (Throwable t) {
                LOG.log(Level.SEVERE, "unexpected throwable caught", t);
            }
        }
        LOG.info("DataXceiveServer ended");
    }

    void shutdown() {
        running = false;
        ReadWriteUtils.safeCloseSelector(selector);
        for (DataXceiveWorker worker: workers) {
            worker.shutdown();
        }
    }
}
