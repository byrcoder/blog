/**
 * @(#)FSDataSet.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockCheckResult.Result;
import odis.dfs.common.BlockSize;
import odis.dfs.common.FSConstants;
import odis.dfs.metrics.DataNodeMetrics;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.util.DfsUtils;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.ReadWriteUtils;
import toolbox.collections.Pair;
import toolbox.collections.primitive.IntegerLongPair;
import toolbox.collections.primitive.LongIntegerCompactHashMap;
import toolbox.collections.primitive.LongIntegerKeyValueIterator;
import toolbox.misc.LogFormatter;
import toolbox.text.util.Digits;

/**
 * @author zhangduo
 */
class FSDataSet implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(FSDataSet.class);

    private final File dir;

    private final LongIntegerCompactHashMap blockMap = new LongIntegerCompactHashMap();

    private long totalBlockSize;

    private final DataNodeMetrics metrics;

    private static final int BLOCK_LEN_NOT_EXISTS = -1;

    private void loadAllBlocks() throws IOException {
        char[] buf = new char[2];
        for (int i = 0; i <= 0xFF; i++) {
            buf[0] = Digits.charDigit((i >>> 4) & 0x0F);
            buf[1] = Digits.charDigit(i & 0x0F);
            String prefix = String.valueOf(buf);
            File prefixDir = new File(dir, prefix);
            if (!prefixDir.exists()) {
                if (!prefixDir.mkdirs()) {
                    throw new IOException("Cannot create prefix dir "
                            + prefixDir.getAbsolutePath());
                }
                continue;
            }
            for (File f: prefixDir.listFiles()) {
                String name = f.getName();
                if (".".equals(name) || "..".equals(name)) {
                    continue;
                }
                if (!f.isFile()
                        || !(name.endsWith(BLOCK_FILE_SUFFIX) || name.endsWith(CHECKSUM_FILE_SUFFIX))) {
                    throw new IOException("Rogue file in data directory: " + f
                            + " in " + prefixDir);
                }
                if (name.endsWith(BLOCK_FILE_SUFFIX)) {
                    long len = f.length();
                    long id = DfsUtils.blockFile2BlockId(f);
                    if (len > Integer.MAX_VALUE) {
                        throw new IOException("block " + id + " size " + len
                                + " is larger than Integer.MAX_VALUE");
                    }
                    blockMap.put(id, (int) len, BLOCK_LEN_NOT_EXISTS);
                    totalBlockSize += len;
                }
            }
        }
    }

    FSDataSet(File dir, DataNodeMetrics metrics) throws IOException {
        this.dir = dir;
        this.metrics = metrics;
        loadAllBlocks();
    }

    Pair<File, Integer> getBlockFile(long blockId, int off) throws IOException {
        File blockFile = DfsUtils.blockId2File(dir, blockId, BLOCK_FILE_SUFFIX);
        int len;
        synchronized (blockMap) {
            len = blockMap.get(blockId, BLOCK_LEN_NOT_EXISTS);
        }
        if (len == BLOCK_LEN_NOT_EXISTS) {
            throw new IOException("Block " + blockFile.getAbsolutePath()
                    + " not exists when read");
        }
        if (off > len) {
            throw new IOException("offset too large when read "
                    + blockFile.getAbsolutePath() + ", len=" + len
                    + " but off=" + off);
        }
        return new Pair<File, Integer>(blockFile, len - off);
    }

    BlockInputStream openBlock(long blockId, int off) throws IOException {
        File blockFile = DfsUtils.blockId2File(dir, blockId, BLOCK_FILE_SUFFIX);
        int len;
        synchronized (blockMap) {
            len = blockMap.get(blockId, BLOCK_LEN_NOT_EXISTS);
        }
        if (len == BLOCK_LEN_NOT_EXISTS) {
            throw new IOException("Block " + blockFile.getAbsolutePath()
                    + " not exists when read");
        }
        if (off > len) {
            throw new IOException("offset too large when read "
                    + blockFile.getAbsolutePath() + ", len=" + len
                    + " but off=" + off);
        }
        long adler32 = CHECKUM_NA;
        if (off == 0) {
            try {
                adler32 = readChecksum(blockId);
            } catch (IOException e) {
                LOG.warning("Failed to read checksum for "
                        + blockFile.getAbsolutePath());
            }
        }
        return new BlockInputStream(blockFile, len, off, adler32);
    }

    BlockOutputStream createBlock(long blockId) throws IOException {
        synchronized (blockMap) {
            if (blockMap.containsKey(blockId)) {
                throw new IOException("Cannot overwrite existing block "
                        + blockId);
            }
        }
        return new BlockOutputStream(DfsUtils.blockId2File(dir, blockId,
                BLOCK_FILE_SUFFIX));
    }

    /**
     * write the given block checksum file
     * 
     * @param blockId
     *            the block id
     * @param checksum
     *            the given checksum
     * @throws DataNodeFatalException
     *             fatal error like disk error
     * @throws IOException
     *             any I/O error occur
     */
    void writeChecksum(long blockId, long checksum) throws IOException {
        byte[] buf = new byte[8];
        CDataOutputStream.writeLong(checksum, buf, 0);
        File file = DfsUtils.blockId2File(dir, blockId, CHECKSUM_FILE_SUFFIX);
        FileOutputStream out = new FileOutputStream(file);
        try {
            out.write(buf);
        } finally {
            ReadWriteUtils.safeClose(out);
        }
    }

    long readChecksum(long blockId) throws IOException {
        File file = DfsUtils.blockId2File(dir, blockId, CHECKSUM_FILE_SUFFIX);
        byte[] buf = new byte[8];
        FileInputStream in = new FileInputStream(file);
        try {
            CDataInputStream.readFully(buf, in);
        } finally {
            ReadWriteUtils.safeClose(in);
        }
        return CDataInputStream.readLong(buf, 0);
    }

    void addBlock(long block, int len) {
        synchronized (blockMap) {
            blockMap.put(block, len, BLOCK_LEN_NOT_EXISTS);
            totalBlockSize += len;
        }
    }

    boolean deleteBlock(long block) {
        int len;
        synchronized (blockMap) {
            len = blockMap.remove(block, BLOCK_LEN_NOT_EXISTS);
            if (len == BLOCK_LEN_NOT_EXISTS) {
                return false;
            }
            totalBlockSize -= len;
        }
        metrics.increment(DataNodeMetricsItem.DELETE_COUNT);
        metrics.add(DataNodeMetricsItem.DELETE_BYTES, len);
        File blockFile = DfsUtils.blockId2File(dir, block, BLOCK_FILE_SUFFIX);
        if (!blockFile.delete()) {
            LOG.warning("Cannot delete " + blockFile.getAbsolutePath()
                    + " when delete block");
        }
        File checksumFile = DfsUtils.blockId2File(dir, block,
                CHECKSUM_FILE_SUFFIX);
        if (checksumFile.exists() && !checksumFile.delete()) {
            LOG.warning("Cannot delete " + checksumFile.getAbsolutePath()
                    + " when delete block");
        }
        return true;
    }

    /**
     * get the total BlockSize[]
     * 
     * @return the ArrayList of BlockSize[]
     */
    BlockSize[] getAllBlocks() {
        synchronized (blockMap) {
            BlockSize[] allBlocks = new BlockSize[blockMap.size()];
            LongIntegerKeyValueIterator iter = blockMap.iterator();
            for (int i = 0; i < blockMap.size(); i++) {
                iter.next();
                allBlocks[i] = new BlockSize(iter.getKey(), iter.getValue());

            }
            return allBlocks;
        }
    }

    IntegerLongPair blockNumberAndSize() {
        synchronized (blockMap) {
            return new IntegerLongPair(blockMap.size(), totalBlockSize);
        }
    }

    long totalSize() {
        synchronized (blockMap) {
            return totalBlockSize + blockMap.size() * 8;
        }
    }

    private static final int READ_BUFFER_SIZE = 8 * 1024;

    BlockCheckResult checkBlockConsistency(long block) {
        int len;
        synchronized (blockMap) {
            if ((len = blockMap.get(block, BLOCK_LEN_NOT_EXISTS)) == BLOCK_LEN_NOT_EXISTS) {
                return BlockCheckResult.RESULT_BLOCK_READ_ERROR;
            }
        }
        File blockFile = DfsUtils.blockId2File(dir, block, BLOCK_FILE_SUFFIX);
        byte[] buf = new byte[READ_BUFFER_SIZE];
        Adler32 adler32 = new Adler32();
        FileInputStream in = null;
        try {
            in = new FileInputStream(blockFile);
            while (len > 0) {
                int read = in.read(buf);
                if (read < 0) {
                    LOG.warning("Unexpected EOF got when check consistency for "
                            + blockFile.getAbsolutePath());
                    return BlockCheckResult.RESULT_BLOCK_READ_ERROR;
                }
                adler32.update(buf, 0, read);
                len -= read;
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING,
                    "read block failed when check consistency for "
                            + blockFile.getAbsolutePath(), e);
            return BlockCheckResult.RESULT_BLOCK_READ_ERROR;
        } finally {
            ReadWriteUtils.safeClose(in);
        }
        long cc = adler32.getValue();
        long oc;
        try {
            oc = readChecksum(block);
        } catch (FileNotFoundException e) {
            LOG.log(Level.WARNING,
                    "origin checksum not found when check consistency for "
                            + block, e);
            return new BlockCheckResult(Result.ORIGINAL_CHECKSUM_NOT_EXIST,
                    CHECKUM_NA, cc);
        } catch (Exception e) {
            LOG.log(Level.WARNING,
                    "read origin checksum failed when check consistency for "
                            + block, e);
            return new BlockCheckResult(Result.ORIGINAL_CHECKSUM_READ_ERROR,
                    CHECKUM_NA, cc);
        }
        return new BlockCheckResult(oc == cc ? Result.MATCH : Result.MISMATCH,
                oc, cc);

    }
}
