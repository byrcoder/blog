/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.dfs.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Interface for backup data, which holds one block during transfering of data
 * to datanode.
 * 
 * @author river
 */
public interface LocalBackup {

    /**
     * Get the OutputStream for this backup, no inputstream at the same time.
     * 
     * @return outputStream for this backup
     * @throws IOException
     */
    public OutputStream getOutputStream() throws IOException;

    /**
     * Get the InputStream for this backup, no inputstream at the same time.
     * 
     * @return inputStream for this backup
     * @throws IOException
     */
    public InputStream getInputStream() throws IOException;

    /**
     * release all the resource associated with this backup.
     * 
     * @throws IOException
     */
    public void discard() throws IOException;

}
