/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package odis.dfs.common;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Shared or configurable constants for ODFS
 * 
 * @author zhangduo
 */
public interface FSConstants {

    // the special chunk size that means the end of data, which is followed by the CRC checksum
    public static final int CHUNK_SIZE_END_OF_BLOCK = -1;

    // the special chunk size that means client flush all data on datanode and wait datanode's response
    public static final int CHUNK_SIZE_FLUSH_WITH_RESPONSE = -2;

    // datanode send to client means all data received has been flushed
    public static final int DATANODE_FLUSH_RESPONSE = CHUNK_SIZE_FLUSH_WITH_RESPONSE;

    // the special chunk size that means client flush all data on datanode
    public static final int CHUNK_SIZE_FLUSH_WITHOUT_RESPONSE = -3;

    public static final int CHUNK_SIZE_SYNC_WITH_RESPONSE = -4;

    public static final int DATANODE_SYNC_RESPONSE = CHUNK_SIZE_SYNC_WITH_RESPONSE;

    public static final int CHUNK_SIZE_SYNC_ASYNC_WITH_RESPONSE = -5;

    public static final int DATANODE_SYNC_ASYNC_RESPONSE = CHUNK_SIZE_SYNC_ASYNC_WITH_RESPONSE;

    public static final int CHUNK_SIZE_SYNC_WITHOUT_RESPONSE = -6;

    public static final int MAX_BLOCK_TARGET_NUM = 16;

    // Return codes for file create
    public static final int OPERATION_FAILED = 0;

    public static final int FAIL_WAITING = 0;

    public static final int CONT_WAITING = 1;

    public static final int COMPLETE_SUCCESS = 2;

    // default number of replicas
    public static final int DEFAULT_NUM_REPLICAS = 3;

    public static final int NUM_REPLICAS_INHERITED = -1;

    public static int ODFS_CURRENT_PROTOCOL = 4;

    public static Set<Integer> ODFS_SERVER_SUPPORTED_PROTOCOL = new HashSet<Integer>(
            Arrays.asList(new Integer[] {
                4
            }));

    public static String ODFS_VERSION = "5.5";

    // Reserved blocks
    public static final long RESERVED_BLOCK_UPPER = 100;

    public static final long RESERVED_BLOCK_LOWER = 0;

    // Namenode types
    public static final String NAMENODE_MODE_PRIMARY = "primary";

    public static final String NAMENODE_MODE_SECONDARY = "secondary";

    public static final long IMAGE_FILE_START_SN = 1;

    public static final String FS_PROPERTIES_FILE = "properties";

    public static final String FS_IMAGE_DIR = "image";

    public static final String FS_REPORT_DIR = "report";

    public static final int DATA_VERSION = 4;

    public static final String ACTIVE_NAMENODE_ZNODE = "active_nn";

    public static final String NAMENODE_ADDR_ZK_DIR = "nn_addr";

    public static final String TRASHCAN_ROOT = "/trash";

    public static final String[] SYSTEM_DIRECTORYS = new String[] {
        TRASHCAN_ROOT
    };

    public static final String BLOCK_FILE_SUFFIX = ".blk";

    public static final String CHECKSUM_FILE_SUFFIX = ".adler32";

    public static final String MSG_NO_SPACE_LEFT_ON_DEVICE = "No space left on device";

    public static final String MSG_CONNECTION_RESET_BY_PEER = "Connection reset by peer";

    // all checksum used in our system is 32bit(i.e., adler32, crc32), so a long
    // with high 32bit not zero is invalid.
    public static final long CHECKUM_NA = 1L << 32;

    public static final int DATANODE_DELTA_PORT_INCREASE = 1;

    public static final long VOLUME_NA = -1L;

    public static final String DATANODE_VOLUME_FILE_NAME = "volume";

    public static final String NAMENODE_ZNODE_ADDR_CHARSET = "UTF-8";

    public static final String CLIENT_RPC_DOMAIN = "client";

    public static final String FILE_SYSTEM_LOCK_ZK_DIR = "lock";

    public static final int SYSTEM_RPC_PORT_DELTA = 10;
}
