/**
 * @(#)QuorumDFSOutputStream.java, 2013-1-24. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.DataNodeRequest;
import odis.dfs.common.DataNodeRequest.Op;
import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.io.InterruptibleSocket;
import odis.io.QuorumFSOutputStream;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import toolbox.collections.LinkedTransferQueue;
import toolbox.misc.LogFormatter;

/**
 * QuorumFSOutputStream that writing file data to ODFS.
 * 
 * @author zhangduo
 */
public class QuorumDFSOutputStream extends QuorumFSOutputStream implements
        FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(QuorumDFSOutputStream.class);

    private final AtomicLong counter;

    private final NameNodeWatcher nameNodeWatcher;

    private final String file;

    private final String clientName;

    private final long timeout;

    private final long completeFileRetryTimeout;

    private final BlockLocationWithDataPath lblock;

    private final Set<Worker> workers = new HashSet<Worker>();

    private final List<String> failedWorkers = new ArrayList<String>();

    private final Adler32 adler32 = new Adler32();

    private static final class Entry {
        final int flushOption;

        final byte[] buf;

        final int totalCount;

        int successCount;

        int failedCount;

        Entry(int flushOption, byte[] buf, int totalCount) {
            this.flushOption = flushOption;
            this.buf = buf;
            this.totalCount = totalCount;
        }

    }

    private final class Worker implements Runnable {

        private final String datanode;

        private final InterruptibleSocket socket;

        private final LinkedTransferQueue<Entry> queue = new LinkedTransferQueue<Entry>();

        private final byte[] buf = new byte[12];

        public Worker(String datanode, InterruptibleSocket socket) {
            this.datanode = datanode;
            this.socket = socket;
        }

        public void offer(Entry entry) {
            queue.add(entry);
        }

        private void cleanUp(Entry entry) {
            ReadWriteUtils.safeClose(socket);
            synchronized (QuorumDFSOutputStream.this) {
                workers.remove(this);
                failedWorkers.add(datanode);
                do {
                    entry.failedCount++;
                    if (entry.failedCount + entry.successCount == replication) {
                        QuorumDFSOutputStream.this.notifyAll();
                    }
                } while ((entry = queue.poll()) != null);
            }
        }

        private void finishBlock(Entry entry) {
            try {
                CDataOutputStream.writeInt(CHUNK_SIZE_END_OF_BLOCK, buf, 0);
                CDataOutputStream.writeLong(adler32.getValue(), buf, 4);
                socket.getOutputStream().write(buf, 0, 12);
                int successCount = socket.getInputStream().read();
                if (successCount != 1) {
                    LOG.warning("Finish block "
                            + lblock.getBlock()
                            + " of file "
                            + file
                            + " on datanode "
                            + datanode
                            + " failed, expected written to 1 datanode but actual "
                            + successCount);
                } else {
                    synchronized (QuorumDFSOutputStream.this) {
                        entry.successCount++;
                        QuorumDFSOutputStream.this.notifyAll();
                    }
                    return;
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Finish block " + lblock.getBlock()
                        + " of file " + file + " on datanode " + datanode
                        + " failed", e);
            } finally {
                ReadWriteUtils.safeClose(socket);
            }
            synchronized (QuorumDFSOutputStream.this) {
                entry.failedCount++;
                if (entry.successCount == 0
                        && entry.failedCount == entry.totalCount) {
                    QuorumDFSOutputStream.this.notifyAll();
                }
            }
        }

        private void write(Entry entry) throws IOException {
            CDataOutputStream.writeInt(entry.buf.length, buf, 0);
            socket.getOutputStream().write(buf, 0, 4);
            socket.getOutputStream().write(entry.buf);
            CDataOutputStream.writeInt(entry.flushOption, buf, 0);
            socket.getOutputStream().write(buf, 0, 4);
            if (entry.flushOption == CHUNK_SIZE_FLUSH_WITH_RESPONSE
                    || entry.flushOption == CHUNK_SIZE_SYNC_WITH_RESPONSE
                    || entry.flushOption == CHUNK_SIZE_SYNC_ASYNC_WITH_RESPONSE) {
                CDataInputStream.readFully(buf, 0, 4, socket.getInputStream());
                int res = CDataInputStream.readInt(buf, 0);
                if (res != entry.flushOption) {
                    throw new IOException(
                            "Unexpected flush response got: expected "
                                    + entry.flushOption + ", actual " + res);
                }
            }
        }

        @Override
        public void run() {
            String originThreadName = Thread.currentThread().getName();
            Thread.currentThread().setName(
                    "QuorumWriter-" + file + "-" + datanode);
            try {
                for (;;) {
                    Entry entry;
                    try {
                        entry = queue.take();
                    } catch (InterruptedException e) {
                        continue;
                    }
                    if (entry.buf == null) {
                        finishBlock(entry);
                        return;
                    }
                    try {
                        write(entry);
                    } catch (Exception e) {
                        LOG.log(Level.WARNING,
                                "write block " + lblock.getBlock()
                                        + " of file " + file + " to datanode "
                                        + datanode + " failed", e);
                        cleanUp(entry);
                        return;
                    }
                    synchronized (QuorumDFSOutputStream.this) {
                        entry.successCount++;
                        if (entry.successCount >= flushMinSuccess
                                || entry.successCount + entry.failedCount == entry.totalCount) {
                            QuorumDFSOutputStream.this.notifyAll();
                        }
                    }
                }
            } finally {
                Thread.currentThread().setName(originThreadName);
            }
        }

        @Override
        public String toString() {
            return "[QuorumWorker datanode=" + datanode + ", socket=" + socket
                    + "]";
        }
    }

    private int pos;

    private void safeAbandon() {
        try {
            nameNodeWatcher.getNameNode().abandonFileInProgress(clientName,
                    file);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "abandon file " + file + " failed", e);
        }
    }

    private void cleanUp() {
        for (Worker worker: workers) {
            ReadWriteUtils.safeClose(worker.socket);
        }
        safeAbandon();
    }

    public QuorumDFSOutputStream(NameNodeWatcher nameNodeWatcher, String file,
            boolean overwrite, boolean createParent, int flags, int blockSize,
            int replication, FsPermission permission, String clientName,
            AtomicLong writeCounter, Executor workerExecutor,
            DFSClientConfig conf) throws IOException {
        super(blockSize, replication);
        this.nameNodeWatcher = nameNodeWatcher;
        this.file = file;
        this.clientName = clientName;
        BlockLocationWithDataPath lblock = nameNodeWatcher.getNameNode().create(
                clientName, file, overwrite, createParent, replication,
                blockSize, permission);
        if (lblock.getLocations().length < replication) {
            safeAbandon();
            throw new FSException(FSException.NOT_ENOUGH_REPLICATION, file
                    + " expected " + replication
                    + " replications but actual is "
                    + lblock.getLocations().length);
        }
        this.timeout = conf.getQuorumWriteTimeout();
        DataNodeRequest req = new DataNodeRequest(Op.WRITE_BLOCK);
        DataNodeRequest.WriteBlockBody reqBody = (DataNodeRequest.WriteBlockBody) req.getBody();
        reqBody.setBlock(lblock.getBlock());
        reqBody.setReportCond(ReportCond.ALWAYS);
        DirectByteArrayOutputStream bufRawOut = new DirectByteArrayOutputStream();
        CDataOutputStream bufDataOut = new CDataOutputStream(bufRawOut);
        for (String datanode: lblock.getLocations()) {
            InterruptibleSocket socket;
            boolean succ = false;
            try {
                socket = new InterruptibleSocket(
                        BlockLocationWithDataPath.getSocketAddressFromLocation(datanode),
                        timeout);
                succ = true;
            } finally {
                if (!succ) {
                    cleanUp();
                }
            }
            succ = false;
            try {
                reqBody.setTargets(new String[] {
                    datanode
                });
                req.writeFields(bufDataOut);
                bufRawOut.writeTo(socket.getOutputStream());
                bufRawOut.reset();
                succ = true;
            } finally {
                if (!succ) {
                    ReadWriteUtils.safeClose(socket);
                    cleanUp();
                }
            }
            workers.add(new Worker(datanode, socket));
        }
        this.lblock = lblock;
        this.counter = writeCounter;
        this.completeFileRetryTimeout = conf.getQuorumCompleteFileRetryTimeout();
        for (Worker worker: workers) {
            workerExecutor.execute(worker);
        }
    }

    @Override
    public synchronized void write(byte[] b, int off, int len)
            throws IOException {
        if (b == null) {
            throw new NullPointerException();
        } else if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException("length=" + b.length + " off="
                    + off + " len=" + len);
        } else if (len == 0) {
            return;
        }
        if (pos + len > blockSize) {
            throw new CompleteException("reach file limit " + blockSize
                    + ", pos=" + pos + " len=" + len);
        }
        if (!failedWorkers.isEmpty()) {
            throw new CompleteException("OutputStream to " + failedWorkers
                    + " already failed");
        }
        if (workers.isEmpty()) {
            throw new IOException("Stream is closed");
        }
        // must make a copy here because we may return before some worker
        // finish written.
        Entry entry = new Entry(flushOption, Arrays.copyOfRange(b, off, off
                + len), replication);
        for (Worker worker: workers) {
            worker.offer(entry);
        }
        adler32.update(b, off, len);
        do {
            try {
                wait();
            } catch (InterruptedException e) {}
            if (entry.successCount >= flushMinSuccess) {
                counter.addAndGet(len);
                pos += len;
                return;
            }
        } while (entry.successCount + entry.failedCount < replication);
        throw new IOException(failedWorkers + " write failed");
    }

    @Override
    public synchronized long getPos() {
        return pos;
    }

    private boolean closingDown = false;

    @Override
    public synchronized void close() throws IOException {
        if (closingDown) {
            return;
        }
        int aliveWorker = workers.size();
        if (aliveWorker > 0) {
            Entry entry = new Entry(flushOption, null, aliveWorker);
            for (Worker worker: workers) {
                worker.offer(entry);
            }
            workers.clear();
            for (;;) {
                try {
                    wait();
                } catch (InterruptedException e) {}
                if (entry.successCount > 0 || entry.failedCount == aliveWorker) {
                    break;
                }
            }
        }
        DFSClient.completeFile(nameNodeWatcher, clientName, file,
                completeFileRetryTimeout);
        closingDown = true;
    }

    @Override
    public synchronized String toString() {
        return "QuorumDFSOutputStream [file=" + file + ", clientName="
                + clientName + ", timeout=" + timeout + ", block="
                + lblock.getBlock() + ", workers=" + workers + ", pos=" + pos
                + "]";
    }

}
