/**
 * @(#)SecondaryImageFileKeepPolicy.java, 2013-4-18. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;

/**
 * @author zhangduo
 */
interface SecondaryImageFileKeepPolicy {

    long clean(File root);
}
