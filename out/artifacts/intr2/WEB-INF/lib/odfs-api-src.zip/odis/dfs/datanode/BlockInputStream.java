/**
 * @(#)BlockInputStream.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import odis.dfs.common.FSConstants;
import odis.dfs.util.DfsUtils;
import odis.io.ReadWriteUtils;
import odis.util.unsafe.UnsafeHelper;
import sun.nio.ch.DirectBuffer;

/**
 * @author zhangduo
 */
class BlockInputStream implements Closeable {

    private final File file;

    private final FileInputStream in;

    private final FileChannel channel;

    private final long expectedAdler32;

    private final int len;

    private int remaining;

    private int adler32;

    BlockInputStream(File file, int len, int off, long expectedAdler32)
            throws IOException {
        this.file = file;
        this.expectedAdler32 = expectedAdler32;
        this.in = new FileInputStream(file);
        boolean succ = false;
        try {
            this.channel = this.in.getChannel();
            if (off > 0) {
                channel.position(off);
            }
            succ = true;
        } catch (IOException e) {
            throw new DataNodeFatalException(e);
        } finally {
            if (!succ) {
                ReadWriteUtils.safeClose(this.in);
            }
        }
        this.len = len;
        this.remaining = len - off;
        this.adler32 = 1;
    }

    int getRemaining() {
        return remaining;
    }

    long getAdler32() {
        return expectedAdler32;
    }

    int getLen() {
        return len;
    }

    File getBlockFile() {
        return file;
    }

    int read(ByteBuffer bb) throws IOException {
        if (remaining == 0) {
            return -1;
        }
        int read;
        try {
            do {
                read = channel.read(bb);
            } while (read == 0);
        } catch (IOException e) {
            throw new DataNodeFatalException(e);
        }
        if (read < 0) {
            throw new EOFException("Unexpected EOF, should have " + remaining
                    + " bytes remaining");
        }
        remaining -= read;
        if (expectedAdler32 != FSConstants.CHECKUM_NA) {
            adler32 = UnsafeHelper.adler32(adler32,
                    ((DirectBuffer) bb).address() + bb.position() - read, read);
            if (remaining == 0 && adler32 != (int) expectedAdler32) {
                throw new BlockChecksumMismatchException(
                        DfsUtils.blockFile2BlockId(file), expectedAdler32,
                        adler32 & 0xFFFFFFFFL);
            }
        }
        return read;
    }

    @Override
    public void close() {
        ReadWriteUtils.safeClose(channel);
        ReadWriteUtils.safeClose(in);
    }
}
