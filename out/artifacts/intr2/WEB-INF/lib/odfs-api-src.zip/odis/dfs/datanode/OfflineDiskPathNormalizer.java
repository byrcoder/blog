/**
 * @(#)OfflineDiskPathNormalizer.java, 2012-12-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

/**
 * @author zhangduo
 */
interface OfflineDiskPathNormalizer {

    String getPrefix(String path);
}
