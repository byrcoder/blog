/**
 * @(#)BlockWithSize.java, 2012-2-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
class BlockWithSize implements IWritable {
    long block;

    int size;

    public BlockWithSize() {}

    public BlockWithSize(long block, int size) {
        this.block = block;
        this.size = size;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        BlockWithSize that = (BlockWithSize) value;
        block = that.block;
        size = that.size;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(block);
        CDataOutputStream.writeVInt(size, out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        block = in.readLong();
        size = CDataInputStream.readVInt(in);
    }

    @Override
    public String toString() {
        return "[block=" + block + ", size=" + size + "]";
    }

}
