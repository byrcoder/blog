/**
 * @(#)AbstractReserveByCapacityPolicy.java, 2012-4-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.Arrays;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import odis.util.ThreadLocalRandomData;

/**
 * @author zhangduo
 */
public abstract class AbstractReserveByCapacityPolicy implements
        BlockPlacementPolicy {
    protected final SortedSet<DatanodeInfo> datanodes = new TreeSet<DatanodeInfo>(
            DatanodeInfo.HOST_PORT_COMPARATOR);

    protected final int maxReplicationPerTime;

    public AbstractReserveByCapacityPolicy(int maxReplicationPerTime) {
        this.maxReplicationPerTime = maxReplicationPerTime;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addDatanode(DatanodeInfo dinfo) {
        synchronized (datanodes) {
            datanodes.add(dinfo);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void removeDatanode(DatanodeInfo dinfo) {
        synchronized (datanodes) {
            datanodes.remove(dinfo);
        }
    }

    /**
     * Finds one datanode from the given nodes randomly by capacity.
     */
    protected int findRandomDatanode(List<DatanodeInfo> candidateNodes,
            long totalCapacity) {
        if (candidateNodes.isEmpty()) {
            return -1;
        }
        ThreadLocalRandomData rand = ThreadLocalRandomData.current();
        long targetCapacity = rand.nextLong(totalCapacity);
        long c = 0;
        for (int i = 0; i < candidateNodes.size(); i++) {
            c += candidateNodes.get(i).getCapacity();
            if (c > targetCapacity) {
                return i;
            }
        }
        // In fact this should not happen...
        return -1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DatanodeInfo[] calcToDeletedLocations(DatanodeInfo[] datanodes,
            int desiredReplication) {
        if (datanodes.length <= desiredReplication) {
            return DatanodeInfo.EMPTY_ARRAY;
        }
        DatanodeInfo[] copy = Arrays.copyOf(datanodes, datanodes.length);
        Arrays.sort(copy, DatanodeInfo.HOST_PORT_COMPARATOR);
        StringBuilder sb = new StringBuilder();
        for (DatanodeInfo dinfo: copy) {
            sb.append(dinfo.getName());
        }
        int idx = sb.toString().hashCode() % copy.length;
        idx = idx == Integer.MIN_VALUE ? 0 : Math.abs(idx);
        DatanodeInfo[] ret = new DatanodeInfo[datanodes.length
                - desiredReplication];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = copy[(idx + i) % copy.length];
        }
        return ret;
    }

}
