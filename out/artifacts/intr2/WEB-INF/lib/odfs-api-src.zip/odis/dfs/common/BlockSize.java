/*
 * Copyright (c) 2007, Outfox Team.
 *
 * Created on 2007-10-3
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * Immutable (blockID, size) tuple.
 * 
 * @author zf
 */
public class BlockSize implements IWritable {

    static { // register a ctor
        WritableRegistry.registerAlias(BlockSize.class, "BlockSize");
    }

    private long block;

    private int len;

    public BlockSize() {}

    public BlockSize(long b, int len) {
        this.block = b;
        this.len = len;
    }

    /**
     * Get this block's ID.
     */
    public long getBlock() {
        return block;
    }

    /**
     * Get number of bytes in this block.
     */
    public int getLen() {
        return len;
    }

    // /////////////////////////////////////////
    // Writable
    // /////////////////////////////////////////
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(block);
        out.writeInt(len);
    }

    public void readFields(DataInput in) throws IOException {
        block = in.readLong();
        len = in.readInt();
    }

    public IWritable copyFields(IWritable value) {
        BlockSize lb = (BlockSize) value;
        block = lb.block;
        return this;
    }

    @Override
    public String toString() {
        return "[BlockSize block=" + block + ", len=" + len + "]";
    }
}
