/**
 * @(#)DFSClientUserName.java, 2011-6-10. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

/**
 * This class is used for cowork to set TaskWorker's username.
 * <p>
 * You should set this username before DFSClient's class being loaded. After
 * DFSClient's class being loaded, change this username will have no effect.
 * </p>
 * 
 * @author zhangduo
 */
final class DFSClientUsername {
    static String username = System.getProperty("user.name", "");
}
