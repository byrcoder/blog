/**
 * @(#)ForceCompleteBlockCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.dfs.datanode.DataNode;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * Force completion of a block by closing its client connection. It is used when
 * NameNode found the client's lease is expired and going to close the file. In
 * that condition, this method should be used so that this block can be reported
 * to NameNode before file closing.
 * 
 * @author zhangduo
 */
public class ForceCompleteBlockCommand extends DataNodeCommand {

    private long[] blocks;

    public ForceCompleteBlockCommand() {}

    public ForceCompleteBlockCommand(long[] blocks) {
        this.blocks = blocks;
    }

    public long[] getBlocks() {
        return blocks;
    }

    public void setBlocks(long[] blocks) {
        this.blocks = blocks;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(blocks.length, out);
        for (long block: blocks) {
            out.writeLong(block);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int size = CDataInputStream.readVInt(in);
        blocks = new long[size];
        for (int i = 0; i < size; i++) {
            blocks[i] = in.readLong();
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        ForceCompleteBlockCommand that = (ForceCompleteBlockCommand) value;
        blocks = Arrays.copyOf(that.blocks, that.blocks.length);
        return this;
    }

    @Override
    public void execute(DataNode dataNode) {
        dataNode.scheduleBlockForceCompletion(blocks);
    }

}
