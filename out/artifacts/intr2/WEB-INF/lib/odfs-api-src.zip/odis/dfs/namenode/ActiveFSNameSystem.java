/**
 * @(#)ActiveFSNameSystem.java, 2012-12-15. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSize;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.FSException;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.namenode.ActiveFSBlockStore.PendingBlockChecker;
import odis.io.CDataInputStream;
import odis.io.FileSystem;
import odis.io.LockStateException;
import odis.io.NamedLock;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.rpc2.AsyncRpcCallEntry;
import odis.util.DaemonTracker;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableLong;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

/**
 * FSNamesystem handles the namenode's interactions with the DFS client. This
 * includes file opening, file creation, lease management, etc. It's also the
 * connecting point between the directory module and the block store module.
 * <p>
 * Locking schema:
 * <ul>
 * <li>pendingCreates protect create and complete file related operations and
 * fields.</li>
 * <li>leases protect leases field and Lease object inside it.</li>
 * <li>If you want to lock both of them, first lock pendingCreates, then lock
 * leases.</li>
 * <li>ActiveFSBlockStore will only call back to ActiveFSNameSystem when
 * checking reservations with no lock held, so you can call its method
 * everywhere if you want without worrying about dead lock. ActiveFSBlockStore
 * has its own locking schema.</li>
 * <li>ActiveFSDirectory will not call back to ActiveFSNameSystem, so you can
 * call its method everywhere if you want without worrying about dead lock.
 * ActiveFSDirectory has its own locking schema.
 * </ul>
 * 
 * @author zf, zhangduo
 */
class ActiveFSNameSystem
        extends
        AbstractFSNameSystem<ActiveFSBlockStore, ActiveFSDirectory, ActiveFSEditLogger>
        implements PendingBlockChecker {

    private static final Logger LOG = LogFormatter.getLogger(ActiveFSNameSystem.class);

    final ActiveFSBlockStore bstore;

    final ActiveFSDirectory dir;

    final ActiveFSEditLogger editLogger;

    private final AsyncFSEditExecutor asyncExecutor;

    private static final class Lease {
        final String holder;

        long lastUpdate;

        final Set<String> creates = new HashSet<String>();

        final Set<String> locks = new HashSet<String>();

        Lease(String holder) {
            this.holder = holder;
            this.lastUpdate = System.currentTimeMillis();
        }

        void create(String file) {
            creates.add(file);
        }

        void complete(String file) {
            creates.remove(file);
        }

        void obtain(String lock) {
            locks.add(lock);
        }

        void release(String lock) {
            locks.remove(lock);
        }

        @Override
        public String toString() {
            return "[Lease holder=" + holder + ", lastUpdate=" + lastUpdate
                    + ", creates=" + creates + ", locks=" + locks + "]";
        }

    }

    private final LinkedHashMap<String, Lease> leases = new LinkedHashMap<String, ActiveFSNameSystem.Lease>(
            16, 0.75f, true);

    private final int maxBlockSize;

    private final int minBlockSize;

    private final long trashCheckPeriod;

    private final long trashLifeSpan;

    private final ScheduledExecutorService backgroundTaskPool = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "ActiveFSNameSystem-Background-Task");
            t.setDaemon(true);
            return t;
        }
    });

    private void loadFSEdits(long startSN, long endSN,
            Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            MutableLong maxLoadedLogSN) throws IOException {
        for (long sn = startSN; sn < endSN; sn++) {
            LOG.info("Start loading edit log with sn " + sn);
            InputStream in = editLogger.openFSEditLog(sn);
            if (in == null) {
                LOG.info("Segment " + sn + " doesn't exist, skip it");
                continue;
            }
            CDataInputStream dataIn = new CDataInputStream(
                    new BufferedInputStream(in));
            long loadedEdits;
            try {
                loadedEdits = dir.loadFSEdits(dataIn, pendingCreates,
                        pendingCreateLastBlocks, maxLoadedLogSN);
            } finally {
                ReadWriteUtils.safeClose(dataIn);
            }
            LOG.info("Done loading edit log with sn " + sn + ", " + loadedEdits
                    + " edits loaded");
        }
    }

    private void recoverLeases(Map<String, FileINodeUC> fileUCs) {
        for (Map.Entry<String, FileINodeUC> entry: fileUCs.entrySet()) {
            String holder = entry.getValue().holder;
            Lease lease = leases.get(holder);
            if (lease == null) {
                lease = new Lease(holder);
                leases.put(holder, lease);
            }
            lease.creates.add(entry.getKey());
        }
    }

    private void recoverLocks() throws FSException {
        List<Pair<String, NamedLock<String>>> allLocks = lockStore.getAll();
        LOG.info("Recover locks " + allLocks);
        for (Pair<String, NamedLock<String>> pair: allLocks) {
            String lockName = toOriginName(pair.getFirst());
            NamedLock<String> lock = pair.getSecond();
            if (lock.isFree()) {
                lockStore.delete(pair.getFirst());
                continue;
            }
            String[] holders = lock.holders(new String[0]);
            for (String holder: holders) {
                Lease lease = touchLease(holder, true);
                lease.obtain(lockName);
            }
            locks.put(lockName, lock);
        }
    }

    private void expireLease(Lease lease) {
        LOG.info("Expiring lease " + lease + ", leases remaining: "
                + leases.size());
        for (String file: lease.creates) {
            asyncExecutor.schedule(new AsyncForceCompleteExecutiveEntry(null,
                    file));
        }
        lease.creates.clear();
        try {
            for (Iterator<String> iter = lease.locks.iterator(); iter.hasNext();) {
                String lock = iter.next();
                internalReleaseLock(lock, lease.holder);
                iter.remove();
            }
        } catch (FSException e) {
            LOG.log(Level.WARNING, "release lock for " + lease.holder
                    + " failed", e);
            // put lease back for later processing again.
            lease.lastUpdate = 0L;
            leases.put(lease.holder, lease);
        }
    }

    private void checkLease() {
        long currentTime = System.currentTimeMillis();
        synchronized (pendingCreates) {
            synchronized (locks) {
                synchronized (leases) {
                    for (Iterator<Lease> iter = leases.values().iterator(); iter.hasNext();) {
                        Lease top = iter.next();
                        if (currentTime - top.lastUpdate < leasePeriod) {
                            break;
                        }
                        iter.remove();
                        expireLease(top);
                    }
                }
            }
        }
    }

    private void scheduleBackgroundTasks(Configuration conf) {
        long leaseCheckInterval = leasePeriod / 10;
        if (leaseCheckInterval < 1000) {
            leaseCheckInterval = 1000;
        }
        backgroundTaskPool.scheduleAtFixedRate(new Runnable() {

            private final DaemonTracker tr = new DaemonTracker();

            @Override
            public void run() {
                try {
                    checkLease();
                } catch (Exception e) {
                    tr.gotThrowable(e);
                }
            }
        }, leaseCheckInterval, leaseCheckInterval, TimeUnit.MILLISECONDS);

        backgroundTaskPool.scheduleAtFixedRate(new Runnable() {
            private final DaemonTracker tr = new DaemonTracker();

            @Override
            public void run() {
                try {
                    checkTrash();
                } catch (Exception e) {
                    tr.gotThrowable(e);
                }
            }
        }, trashCheckPeriod, trashCheckPeriod, TimeUnit.MILLISECONDS);
    }

    ActiveFSNameSystem(Configuration conf,
            ZooKeeperStore<NamedLock<String>> lockStore) throws IOException {
        super(new HashMap<String, FileINodeUC>(),
                new HashMap<Long, String[]>(), conf);
        this.maxBlockSize = conf.getInt(DFSConfig.BLOCK_MAX_SIZE,
                DFSConfig.DEFAULT_BLOCK_MAX_SIZE);
        this.minBlockSize = conf.getInt(DFSConfig.BLOCK_MIN_SIZE,
                DFSConfig.DEFAULT_BLOCK_MIN_SIZE);
        this.trashCheckPeriod = conf.getLong(
                DFSConfig.NAMENODE_TRASH_CHECK_PERIOD,
                DFSConfig.DEFAULT_NAMENODE_TRASH_CHECK_PERIOD);
        this.trashLifeSpan = conf.getLong(DFSConfig.NAMENODE_TRASH_LIFE_SPAN,
                DFSConfig.DEFAULT_NAMENODE_TRASH_LIFE_SPAN);
        File imageRoot = new File(namenodeRoot, FS_IMAGE_DIR);
        File imageFile = ImageManager.getNewestImageFile(imageRoot, false);
        long imageSN = imageFile == null ? IMAGE_FILE_START_SN
                : ImageManager.getSN(imageFile);
        this.editLogger = new ActiveFSEditLogger(conf, imageSN + 1);
        this.bstore = new ActiveFSBlockStore(conf, this, fsProps.volume);

        MutableLong maxLoadedLogSN = new MutableLong(Long.MIN_VALUE);
        this.dir = new ActiveFSDirectory(conf, bstore, imageFile,
                pendingCreates, pendingCreateLastBlocks, maxLoadedLogSN);
        loadFSEdits(imageSN + 1, editLogger.currentLogFileSN(), pendingCreates,
                pendingCreateLastBlocks, maxLoadedLogSN);
        recoverLeases(pendingCreates);
        this.lockStore = lockStore;
        recoverLocks();
        this.asyncExecutor = new AsyncFSEditExecutor(conf, this);
        asyncExecutor.start();
        scheduleBackgroundTasks(conf);
    }

    ActiveFSNameSystem(Configuration conf, File namenodeRoot, String admin,
            long leasePeriod, FSProperties fsProps, BackupFSBlockStore bstore,
            BackupFSDirectory dir, Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            ActiveFSEditLogger editLogger,
            ZooKeeperStore<NamedLock<String>> lockStore) throws FSException {
        super(pendingCreates, pendingCreateLastBlocks, namenodeRoot, admin,
                leasePeriod, fsProps);
        this.maxBlockSize = conf.getInt(DFSConfig.BLOCK_MAX_SIZE,
                DFSConfig.DEFAULT_BLOCK_MAX_SIZE);
        this.minBlockSize = conf.getInt(DFSConfig.BLOCK_MIN_SIZE,
                DFSConfig.DEFAULT_BLOCK_MIN_SIZE);
        this.trashCheckPeriod = conf.getLong(
                DFSConfig.NAMENODE_TRASH_CHECK_PERIOD,
                DFSConfig.DEFAULT_NAMENODE_TRASH_CHECK_PERIOD);
        this.trashLifeSpan = conf.getLong(DFSConfig.NAMENODE_TRASH_LIFE_SPAN,
                DFSConfig.DEFAULT_NAMENODE_TRASH_LIFE_SPAN);
        this.bstore = bstore.upgrade(conf, this);
        this.dir = dir.upgrade(this.bstore);
        this.editLogger = editLogger;
        recoverLeases(pendingCreates);
        this.lockStore = lockStore;
        recoverLocks();
        this.asyncExecutor = new AsyncFSEditExecutor(conf, this);
        asyncExecutor.start();
        scheduleBackgroundTasks(conf);
    }

    private void checkTrash() throws FSException {
        long currentTime = System.currentTimeMillis();
        for (DFSFileStatus dateDir: dir.getListing(TRASHCAN_ROOT, null)) {
            boolean toBeDeleted;
            try {
                long trashDirTime = TRASH_DIR_DATE_FORMAT.parseMillis(dateDir.getName());
                toBeDeleted = currentTime - trashDirTime > trashLifeSpan;
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "Parsing dir "
                                + dateDir.getPath()
                                + " to trashed time failed, and it's going to be deleted.");
                toBeDeleted = true;
            }

            // delete the overtime paths
            if (toBeDeleted) {
                LOG.info("Trash " + dateDir.getPath() + " is to be deleted.");
                asyncExecutor.schedule(new AsyncDeleteExecutiveEntry(null,
                        dateDir.getPath(), true, null));
            }
        }
    }

    @Override
    public void recoverInconsistentBlock(long block, String initiatingDataNode,
            BlockCheckResult result) throws IOException {
        bstore.recoverInconsistentBlock(block, initiatingDataNode, result);
    }

    @Override
    public void reportConsistencyCheckResult(long block,
            String datanodeFullName, BlockCheckResult result)
            throws IOException {
        bstore.reportConsistencyCheckResult(block, datanodeFullName, result);
    }

    @Override
    public DataNodeCommand connect(String sender, BlockSize[] blocks,
            long capacity, long remaining, long volume) throws IOException {
        return bstore.datanodeConnect(sender, blocks, capacity, remaining,
                volume);
    }

    @Override
    public void disconnect(String sender) throws IOException {
        bstore.datanodeDisconnect(sender);
    }

    @Override
    public void blockReport(String sender, BlockSize[] blocks)
            throws IOException {
        bstore.datanodeBlockReport(sender, blocks);
    }

    @Override
    public DataNodeCommand[] sendHeartbeat(String sender, long remaining,
            long[] metricsRecord) throws IOException {
        int xmitsInProgress = (int) metricsRecord[DataNodeMetricsItem.CONCURRENT_REPLICATION.offset()];
        return bstore.datanodeHeartbeat(sender, remaining, xmitsInProgress,
                ready.get());
    }

    @Override
    public void reportBlockReceivedOrDeleted(String sender,
            BlockSize[] received, long[] deleted) throws IOException {
        bstore.datanodeReportBlockReceivedOrDeleted(sender, received, deleted);
    }

    @Override
    public void replicationDone(String sender,
            BlockSizeLocationWithDataPath lblock) throws IOException {
        bstore.datanodeReplicationDone(sender, lblock);
    }

    @Override
    protected void internalSetReady() {
        bstore.setReady();
    }

    @Override
    ActiveFSBlockStore getFSBlockStore() {
        return bstore;
    }

    @Override
    ActiveFSDirectory getFSDirectory() {
        return dir;
    }

    @Override
    ActiveFSEditLogger getFSEditLogger() {
        return editLogger;
    }

    @Override
    String consistencyCheck(String user) throws IOException {
        checkAdmin(user);
        File reportFile = getReportFile("fsck");
        new FileSystemConsistencyChecker<ActiveFSBlockStore>(dir, bstore,
                reportFile).fsck();
        return reportFile.getAbsolutePath();
    }

    @Override
    BlockVerifyResult verifyBlock(AsyncRpcCallEntry rpcCallEntry, long block)
            throws FSException {
        bstore.verifyBlock(rpcCallEntry, block);
        return null;
    }

    @Override
    void computeContentsLengthAndSubItemNum(String user) throws FSException {
        checkAdmin(user);
        dir.computeContentsLengthAndSubItemNum();
    }

    private void checkSystemDirAccess(String path) throws FSException {
        for (String systemDir: SYSTEM_DIRECTORYS) {
            if (DirUtils.underOrIsDir(systemDir, path)) {
                throw new FSException(FSException.PERMISSION_DENIED,
                        "Can not access path under system directory "
                                + systemDir);
            }
        }
    }

    private void checkProtectedDirAccess(String path) throws FSException {
        if (dir.fsDirPropMgr.isProtect(path)) {
            throw new FSException(FSException.PERMISSION_DENIED,
                    "Cannot delete protected path " + path);
        }
    }

    @Override
    BlockLocationWithDataPath create(AsyncRpcCallEntry rpcCallEntry,
            String file, boolean overwrite, boolean createParent,
            FsPermission permission, int replication, int fileBlockSize,
            String user, String clientMachine, String clientName)
            throws IOException {
        checkReady();
        file = DirUtils.normalizePath(file);
        if (file.length() == 1) {
            // can not write root node
            throw new FSException(FSException.ILLEGAL_PARAM,
                    "Can not start file with name " + file);
        }
        if (fileBlockSize > maxBlockSize || fileBlockSize < minBlockSize) {
            throw new FSException(FSException.ILLEGAL_PARAM, "block size "
                    + fileBlockSize + " out of limits");
        }
        checkSystemDirAccess(file);
        LOG.info(clientName + " create file=" + file + ", overwrite="
                + overwrite + ", createParent=" + createParent
                + ", permission=" + permission + ", replication=" + replication
                + ", fileBlockSize=" + fileBlockSize + ", user=" + user
                + ", clientMachine=" + clientMachine);
        asyncExecutor.schedule(new AsyncCreateExecutiveEntry(rpcCallEntry,
                file, overwrite, createParent, permission, replication,
                fileBlockSize, user, clientMachine, clientName));
        return null;
    }

    @Override
    void abandonBlock(AsyncRpcCallEntry rpcCallEntry, String file,
            int blockIndex, String clientName) throws IOException {
        checkReady();
        file = DirUtils.normalizePath(file);
        LOG.info(clientName + " abandonBlock file=" + file + ", blockIndex="
                + blockIndex);
        asyncExecutor.schedule(new AsyncAbandonBlockExecutiveEntry(
                rpcCallEntry, file, blockIndex, clientName));
    }

    @Override
    BlockLocationWithDataPath addBlock(AsyncRpcCallEntry rpcCallEntry,
            String file, int blockIndex, String clientMachine, String clientName)
            throws IOException {
        checkReady();
        file = DirUtils.normalizePath(file);
        LOG.info(clientName + " addBlock file=" + file + ", blockIndex="
                + blockIndex + ", clientMachine=" + clientMachine);
        asyncExecutor.schedule(new AsyncAppendBlockExecutiveEntry(rpcCallEntry,
                file, blockIndex, clientMachine, clientName));
        return null;
    }

    @Override
    void abandonFileInProgress(AsyncRpcCallEntry rpcCallEntry, String file,
            String user, String clientName) throws IOException {
        checkReady();
        file = DirUtils.normalizePath(file);
        LOG.info(clientName + " abandonFileInProgress file=" + file + ", user="
                + user);
        asyncExecutor.schedule(new AsyncAbandonExecutiveEntry(rpcCallEntry,
                file, user));
    }

    @Override
    boolean complete(AsyncRpcCallEntry rpcCallEntry, String file,
            String clientName) throws IOException {
        checkReady();
        file = DirUtils.normalizePath(file);
        LOG.info(clientName + " complete file=" + file);
        asyncExecutor.schedule(new AsyncCompleteExecutiveEntry(rpcCallEntry,
                file, clientName));
        return false;
    }

    @Override
    boolean deprive(AsyncRpcCallEntry rpcCallEntry, String file, String user,
            String clientName) throws IOException {
        checkReady();
        file = DirUtils.normalizePath(file);
        LOG.info(clientName + " deprive file=" + file + ", user=" + user);
        asyncExecutor.schedule(new AsyncDepriveExecutiveEntry(rpcCallEntry,
                file, user));
        return false;
    }

    @Override
    boolean isPending(String file, String user) throws FSException {
        file = DirUtils.normalizePath(file);
        synchronized (pendingCreates) {
            return pendingCreates.containsKey(file);
        }

    }

    @Override
    String[] pendingFilesInDir(String path, String user) throws FSException {
        synchronized (pendingCreates) {
            path = DirUtils.normalizePath(path);
            List<String> result = new ArrayList<String>();
            for (String file: pendingCreates.keySet()) {
                if (DirUtils.underDir(path, file)) {
                    result.add(file);
                }
            }
            return result.toArray(new String[0]);
        }
    }

    @Override
    BlockSizeLocationWithDataPath[] getFileBlockLocations(String file,
            String user) throws FSException {
        checkReady();
        file = DirUtils.normalizePath(file);
        long[] blocks = dir.getFileBlocks(file, user);
        if (blocks == null) {
            return null;
        }
        BlockSizeLocationWithDataPath[] r = new BlockSizeLocationWithDataPath[blocks.length];
        for (int i = 0; i < blocks.length; i++) {
            PlacedBlock pb = bstore.getBlock(blocks[i]);
            DatanodeInfo[] containingNodes;
            int len;
            synchronized (pb) {
                containingNodes = pb.getLocs();
                len = pb.getLen();
            }

            if (containingNodes.length == 0) {
                LOG.warning("cannot find datanodes for block " + blocks[i]
                        + " in file " + file);
                // Client can handle missing blocks.
            }
            r[i] = new BlockSizeLocationWithDataPath(blocks[i], len,
                    DatanodeInfo.toLocationsWithDataPath(containingNodes));
        }
        return r;
    }

    @Override
    DFSFileStatus getFileStatus(String file, String user) throws FSException {
        file = DirUtils.normalizePath(file);
        return dir.getFileStatus(file, user);
    }

    @Override
    void mkdirs(AsyncRpcCallEntry rpcCallEntry, String dir, int replication,
            FsPermission permission, String user, String clientName)
            throws FSException {
        checkReady();
        dir = DirUtils.normalizePath(dir);
        checkSystemDirAccess(dir);
        LOG.info(clientName + " mkdirs dir=" + dir + ", replication="
                + replication + ", permission=" + permission + ", user=" + user);
        asyncExecutor.schedule(new AsyncMkdirExecutiveEntry(rpcCallEntry, dir,
                replication, permission, user));
    }

    @Override
    DFSFileStatus[] getListing(String dir, String user) throws FSException {
        dir = DirUtils.normalizePath(dir);
        return this.dir.getListing(dir, user);
    }

    @Override
    void rename(AsyncRpcCallEntry rpcCallEntry, String src, String dst,
            boolean overwrite, String user, String clientName)
            throws IOException {
        checkReady();
        src = DirUtils.normalizePath(src);
        checkSystemDirAccess(src);
        checkProtectedDirAccess(src);
        dst = DirUtils.normalizePath(dst);
        checkSystemDirAccess(dst);
        // But we allow rename to /, rename to / means create a file or 
        // directory under root, not overwrite root. 
        if (src.length() == 1) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot rename "
                    + src);
        }
        if (DirUtils.underOrIsDir(src, dst)) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot rename "
                    + src + " to its sub directory " + dst);
        }
        LOG.info(clientName + " rename src=" + src + ", dst=" + dst
                + ", overwrite=" + overwrite + ", user=" + user);
        asyncExecutor.schedule(new AsyncRenameExecutiveEntry(rpcCallEntry, src,
                dst, overwrite, user));
    }

    @Override
    void snapshot(AsyncRpcCallEntry rpcCallEntry, String src, String dst,
            String user, String clientName) throws IOException {
        checkReady();
        src = DirUtils.normalizePath(src);
        checkSystemDirAccess(src);
        dst = DirUtils.normalizePath(dst);
        checkSystemDirAccess(dst);
        if (dst.length() == 1) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot link to /");
        }
        if (DirUtils.underOrIsDir(src, dst)) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot link "
                    + src + " to its child " + dst);
        }
        LOG.info(clientName + " snapshot src=" + src + ", dst=" + dst
                + ", user=" + user);
        asyncExecutor.schedule(new AsyncSnapshotExecutiveEntry(rpcCallEntry,
                src, dst, user));
    }

    private static final DateTimeFormatter TRASH_DIR_DATE_FORMAT = DateTimeFormat.forPattern("yyyy.MM.dd:HH");

    private String getTrashPath(String path) {
        long time = System.currentTimeMillis();
        return TRASHCAN_ROOT + INode.SEP + TRASH_DIR_DATE_FORMAT.print(time)
                + INode.SEP + path.substring(1).replace(INode.SEP, '.');
    }

    @Override
    boolean delete(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, boolean permanently, String user,
            String clientName) throws IOException {
        checkReady();
        path = DirUtils.normalizePath(path);
        // no one can delete /
        if (path.length() == 1) {
            throw new FSException(FSException.PERMISSION_DENIED,
                    "Deleting / is not allowed");
        }
        checkSystemDirAccess(path);
        checkProtectedDirAccess(path);
        LOG.info(clientName + " delete path=" + path + ", recursive="
                + recursive + ", permanently=" + permanently + ", user=" + user);
        if (permanently && !dir.fsDirPropMgr.isRecoverable(path)) {
            asyncExecutor.schedule(new AsyncDeleteExecutiveEntry(rpcCallEntry,
                    path, recursive, user));
        } else {
            asyncExecutor.schedule(new AsyncTrashExecutiveEntry(rpcCallEntry,
                    path, getTrashPath(path), recursive, user));
        }
        return false;
    }

    private boolean underTrash(String path) {
        return DirUtils.underDir(TRASHCAN_ROOT, path);
    }

    @Override
    void recoverTrash(AsyncRpcCallEntry rpcCallEntry, String trash, String dst,
            String user, String clientName) throws IOException {
        checkReady();
        trash = DirUtils.normalizePath(trash);
        if (!underTrash(trash)) {
            throw new FSException(FSException.ILLEGAL_PARAM, trash
                    + " is not under " + TRASHCAN_ROOT);
        }
        dst = DirUtils.normalizePath(dst);
        checkSystemDirAccess(dst);
        LOG.info(clientName + " recoverTrash trash=" + trash + ", dst=" + dst
                + ", user=" + user);
        asyncExecutor.schedule(new AsyncRenameExecutiveEntry(rpcCallEntry,
                trash, dst, false, user));
    }

    @Override
    boolean deleteTrash(AsyncRpcCallEntry rpcCallEntry, String path,
            String user, String clientName) throws IOException {
        checkReady();
        checkAdmin(user);
        path = DirUtils.normalizePath(path);
        if (!underTrash(path)) {
            throw new FSException(FSException.ILLEGAL_PARAM, path
                    + " is not under " + TRASHCAN_ROOT);
        }
        LOG.info(clientName + " deleteTrash path=" + path + ", user=" + user);
        asyncExecutor.schedule(new AsyncDeleteExecutiveEntry(rpcCallEntry,
                path, true, null));
        return false;
    }

    @Override
    int getReplicationNumber(String path, String user) throws FSException {
        path = DirUtils.normalizePath(path);
        return dir.getDesiredReplications(path, user);
    }

    @Override
    void setReplicationNumber(AsyncRpcCallEntry rpcCallEntry, String path,
            int replication, boolean recursive, String user, String clientName)
            throws IOException {
        checkReady();
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setReplicationNumber path=" + path
                + ", replication=" + replication + ", recursive=" + recursive
                + ", user=" + user);
        asyncExecutor.schedule(new AsyncReplicateExecutiveEntry(rpcCallEntry,
                path, replication, recursive, user));
    }

    @Override
    void setOwner(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, String owner, String group, String user,
            String clientName) throws IOException {
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setOwner path=" + path + ", recursive="
                + recursive + ", owner=" + owner + ", group=" + group
                + ", user=" + user);
        asyncExecutor.schedule(new AsyncChownExecutiveEntry(rpcCallEntry, path,
                owner, group, recursive, user));
    }

    @Override
    void setPermission(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, FsPermission permission, String user,
            String clientName) throws IOException {
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setPermission path=" + path + ", recursive="
                + recursive + ", permission=" + permission + ", user=" + user);
        asyncExecutor.schedule(new AsyncChmodExecutiveEntry(rpcCallEntry, path,
                permission, recursive, user));
    }

    @Override
    void setProtect(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean protect, String user, String clientName) throws IOException {
        checkAdmin(user);
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setProtect path=" + path + ", protect="
                + protect + ", user=" + user);
        asyncExecutor.schedule(new AsyncSetProtectExecutiveEntry(rpcCallEntry,
                path, protect));
    }

    @Override
    boolean isProtect(String path) {
        path = DirUtils.normalizePath(path);
        return dir.fsDirPropMgr.isProtect(path);
    }

    @Override
    void setRecoverable(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recoverable, String user, String clientName)
            throws IOException {
        checkAdmin(user);
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setRecoverable path=" + path + ", recoverable="
                + recoverable + ", user=" + user);
        asyncExecutor.schedule(new AsyncSetRecoverableExecutiveEntry(
                rpcCallEntry, path, recoverable));
    }

    @Override
    boolean isRecoverable(String path) {
        path = DirUtils.normalizePath(path);
        return dir.fsDirPropMgr.isRecoverable(path);
    }

    @Override
    void setSpaceQuota(AsyncRpcCallEntry rpcCallEntry, String path, long quota,
            String user, String clientName) throws IOException {
        checkAdmin(user);
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setSpaceQuota path=" + path + ", quota="
                + quota + ", user=" + user);
        asyncExecutor.schedule(new AsyncSetSpaceQuotaExecutiveEntry(
                rpcCallEntry, path, quota));
    }

    @Override
    long getSpaceQuota(String path) {
        path = DirUtils.normalizePath(path);
        return dir.fsDirPropMgr.getSpaceQuota(path);
    }

    @Override
    void setNameQuota(AsyncRpcCallEntry rpcCallEntry, String path, long quota,
            String user, String clientName) throws IOException {
        checkAdmin(user);
        path = DirUtils.normalizePath(path);
        LOG.info(clientName + " setNameQuota path=" + path + ", quota=" + quota
                + ", user=" + user);
        asyncExecutor.schedule(new AsyncSetNameQuotaExecutiveEntry(
                rpcCallEntry, path, quota));
    }

    @Override
    long getNameQuota(String path) {
        path = DirUtils.normalizePath(path);
        return dir.fsDirPropMgr.getNameQuota(path);
    }

    @Override
    String printDirProperties() throws IOException {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        dir.fsDirPropMgr.saveToTextFile(pw);
        pw.close();
        return sw.toString();
    }

    @Override
    void addGroupUser(AsyncRpcCallEntry rpcCallEntry, String group,
            String user, String opUser, String clientName) throws IOException {
        checkAdmin(opUser);
        LOG.info(clientName + " addGroupUser group=" + group + ", user=" + user
                + ", opUser=" + opUser);
        asyncExecutor.schedule(new AsyncAddGroupUserExecutiveEntry(
                rpcCallEntry, group, user));
    }

    @Override
    void removeGroupUser(AsyncRpcCallEntry rpcCallEntry, String group,
            String user, String opUser, String clientName) throws IOException {
        checkAdmin(opUser);
        LOG.info(clientName + " removeGroupUser group=" + group + ", user="
                + user + ", opUser=" + opUser);
        asyncExecutor.schedule(new AsyncRemoveGroupUserExecutiveEntry(
                rpcCallEntry, group, user));
    }

    @Override
    void removeGroup(AsyncRpcCallEntry rpcCallEntry, String group,
            String opUser, String clientName) throws IOException {
        checkAdmin(opUser);
        LOG.info(clientName + " removeGroup group=" + group + ", opUser="
                + opUser);
        asyncExecutor.schedule(new AsyncRemoveGroupExecutiveEntry(rpcCallEntry,
                group));
    }

    @Override
    String printGroups() {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        dir.ugMgr.saveGroupsToTextFile(pw);
        pw.close();
        return sw.toString();
    }

    // should be called with leases synchronized
    private Lease touchLease(String clientName, boolean renew) {
        Lease lease = leases.get(clientName);
        if (lease == null) {
            if (!renew) {
                return null;
            }
            lease = new Lease(clientName);
            leases.put(clientName, lease);
        } else if (renew) {
            lease.lastUpdate = System.currentTimeMillis();
        }
        return lease;

    }

    @Override
    void renewLease(String clientName) throws FSException {
        synchronized (leases) {
            touchLease(clientName, true);
        }
    }

    @Override
    void removeLease(String clientName) {
        synchronized (pendingCreates) {
            synchronized (locks) {
                synchronized (leases) {
                    Lease lease = leases.remove(clientName);
                    if (lease != null) {
                        expireLease(lease);
                    }
                }
            }
        }
    }

    void addLeaseCreate(String clientName, String file) {
        synchronized (leases) {
            Lease lease = touchLease(clientName, true);
            lease.create(file);
        }
    }

    void removeLeaseCreate(String clientName, String file, boolean renew) {
        synchronized (leases) {
            Lease lease = touchLease(clientName, renew);
            if (lease != null) {
                lease.complete(file);
            }
        }
    }

    int leaseCount() {
        synchronized (leases) {
            return leases.size();
        }
    }

    ///////////////////////////////////////
    // Lock and Permit Operation         //
    ///////////////////////////////////////

    private final ZooKeeperStore<NamedLock<String>> lockStore;

    private final Map<String, NamedLock<String>> locks = new HashMap<String, NamedLock<String>>();

    private String toZkName(String originName) {
        return originName.replace("/", "$@");
    }

    private String toOriginName(String zkName) {
        return zkName.replace("$@", "/");
    }

    @Override
    int obtainLock(String lockName, int lock, String clientName)
            throws FSException {
        checkReady();
        int result;
        String zkLockName = toZkName(lockName);
        synchronized (locks) {
            NamedLock<String> namedLock = locks.get(lockName);
            if (namedLock == null) {
                namedLock = new NamedLock<String>(lockName);
                lockStore.add(zkLockName, namedLock);
                locks.put(lockName, namedLock);
            }
            switch (lock) {
                case FileSystem.SHARED_LOCK:
                    if (namedLock.sharedLock(clientName)) {
                        lockStore.set(zkLockName, namedLock);
                        result = COMPLETE_SUCCESS;
                    } else {
                        result = FAIL_WAITING;
                    }
                    break;
                case FileSystem.UPDATE_LOCK:
                    if (namedLock.updateLock(clientName)) {
                        lockStore.set(zkLockName, namedLock);
                        result = COMPLETE_SUCCESS;
                    } else {
                        result = FAIL_WAITING;
                    }
                    break;
                case FileSystem.EXCLUSIVE_LOCK:
                    int rv = namedLock.exclusiveLock(clientName);
                    if (rv == 2) {
                        lockStore.set(zkLockName, namedLock);
                        result = COMPLETE_SUCCESS;
                    } else if (rv == 1) {
                        lockStore.set(zkLockName, namedLock);
                        result = CONT_WAITING;
                    } else {
                        result = FAIL_WAITING;
                    }
                    break;
                default:
                    throw new RuntimeException("try to obtain bad lock : "
                            + lock);
            }
            if (result == COMPLETE_SUCCESS || result == CONT_WAITING) {
                synchronized (leases) {
                    Lease lease = touchLease(clientName, true);
                    lease.obtain(lockName);
                }
            }
        }
        return result;
    }

    @Override
    String lockState(String lockName, String clientName) throws FSException {
        checkReady();
        synchronized (locks) {
            NamedLock<String> namedlock = locks.get(lockName);
            if (namedlock == null) {
                return NamedLock.LOCK_NAME(NamedLock.FREE);
            } else {
                return namedlock.toString();
            }
        }
    }

    @Override
    int promote(String lockName, String clientName) throws FSException,
            LockStateException {
        checkReady();
        synchronized (locks) {
            NamedLock<String> namedLock = locks.get(lockName);
            if (namedLock == null) {
                throw new LockStateException("try to promote non-exists lock: "
                        + lockName);
            }
            int rv = namedLock.promote(clientName);
            lockStore.set(toZkName(lockName), namedLock);
            return rv == 1 ? CONT_WAITING : COMPLETE_SUCCESS;
        }
    }

    @Override
    void downgrade(String lockName, String clientName) throws FSException,
            LockStateException {
        checkReady();
        synchronized (locks) {
            NamedLock<String> namedLock = locks.get(lockName);
            if (namedLock == null) {
                throw new LockStateException("try to downgrade non-exists lock");
            }
            namedLock.downgrade(clientName);
            lockStore.set(toZkName(lockName), namedLock);
        }
    }

    private boolean internalReleaseLock(String lockName, String clientName)
            throws FSException {
        NamedLock<String> namedlock = locks.get(lockName);
        if (namedlock != null) {
            namedlock.unlock(clientName);
            if (namedlock.isFree()) {
                lockStore.delete(toZkName(lockName));
                locks.remove(lockName);
            } else {
                lockStore.set(toZkName(lockName), namedlock);
            }
            return true;
        } else {
            return false;
        }
    }

    @Override
    void releaseLock(String lockName, String clientName) throws FSException {
        checkReady();
        synchronized (locks) {
            if (internalReleaseLock(lockName, clientName)) {
                synchronized (leases) {
                    Lease lease = touchLease(clientName, false);
                    if (lease != null) {
                        lease.release(lockName);
                    }
                }
            }
        }
    }

    @Override
    public void close() {
        asyncExecutor.close();
        try {
            asyncExecutor.join();
        } catch (InterruptedException e) {}
        editLogger.close();
        bstore.close();
    }

    @Override
    public boolean isBlockPending(long block) {
        synchronized (pendingCreates) {
            return pendingCreateLastBlocks.containsKey(block);
        }
    }
}
