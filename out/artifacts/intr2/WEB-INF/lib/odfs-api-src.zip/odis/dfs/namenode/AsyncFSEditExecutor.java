/**
 * @(#)AsyncFSEditExecutor.java, 2012-12-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;

import org.apache.commons.configuration.Configuration;

import toolbox.collections.LinkedTransferQueue;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class AsyncFSEditExecutor extends Thread implements Closeable,
        AsyncExecutiveEntryVisitor, FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(AsyncFSEditExecutor.class);

    private final LinkedTransferQueue<AsyncExecutiveEntry> queue = new LinkedTransferQueue<AsyncExecutiveEntry>();

    private final ActiveFSNameSystem nameSystem;

    private final int maxBatchElements;

    private final long maxWaitTime;

    private final long editLogRollingInterval;

    private long nextRollingTime;

    private volatile boolean closed = false;

    AsyncFSEditExecutor(Configuration conf, ActiveFSNameSystem nameSystem) {
        super("Async-FSEdit-Executor");
        setDaemon(true);
        this.nameSystem = nameSystem;
        this.maxBatchElements = conf.getInt(
                DFSConfig.NAMENODE_ASYNC_MAX_BATCH_ELEMENTS,
                DFSConfig.DEFAULT_NAMENODE_ASYNC_MAX_BATCH_ELEMENTS);
        this.maxWaitTime = conf.getLong(DFSConfig.NAMENODE_ASYNC_MAX_WAIT_TIME,
                DFSConfig.DEFAULT_NAMENODE_ASYNC_MAX_WAIT_TIME);
        this.editLogRollingInterval = conf.getLong(
                DFSConfig.NAMENODE_EDIT_LOG_ROLLING_INTERVAL,
                DFSConfig.DEFAULT_NAMENODE_EDIT_LOG_ROLLING_INTERVAL);
        this.nextRollingTime = System.currentTimeMillis()
                + editLogRollingInterval;
    }

    private void finishWithError(AsyncExecutiveEntry entry, Throwable error) {
        entry.setError(error);
        entry.finish();
    }

    private final class LeaseRelatedEntryPreProcessor extends
            NoActionAsyncExecutiveEntryVisitor {

        private final Set<String> processedFiles = new HashSet<String>();

        void visitBegin() {
            processedFiles.clear();
        }

        void visitEnd() {
            processedFiles.clear();
        }

        @Override
        public void visit(AsyncCreateExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            synchronized (nameSystem.pendingCreates) {
                FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
                if (fileUC != null) {
                    finishWithError(
                            entry,
                            new FSException(
                                    FSException.ILLEGAL_PARAM,
                                    "Cannot create "
                                            + entry.file
                                            + " because it is already pending(holder is "
                                            + fileUC.holder + ")"));
                    return;
                }
                try {
                    int replication = entry.replication;
                    if (replication == NUM_REPLICAS_INHERITED) {
                        replication = nameSystem.dir.getDesiredReplications(
                                entry.file, entry.user);
                    }
                    entry.firstBlock = nameSystem.bstore.allocateBlock(
                            entry.clientMachine, replication,
                            entry.fileBlockSize);
                } catch (Exception e) {
                    finishWithError(entry, e);
                    return;
                }
            }
            processedFiles.add(entry.file);
        }

        @Override
        public void visit(AsyncAppendBlockExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            synchronized (nameSystem.pendingCreates) {
                FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
                if (fileUC == null) {
                    finishWithError(entry, new FSException(
                            FSException.ILLEGAL_PARAM,
                            "Can not append block to " + entry.file
                                    + " because it is not pending"));
                    return;
                }
                if (!fileUC.holder.equals(entry.clientName)) {
                    finishWithError(entry, (new FSException(
                            FSException.ILLEGAL_PARAM,
                            "Can not append block to " + entry.file
                                    + " because " + entry.clientName
                                    + " is not its owner(owner is "
                                    + fileUC.holder + ")")));
                    return;
                }
                if (entry.blockIndex != fileUC.blocks.size()) {
                    finishWithError(entry, new FSException(
                            FSException.INVALID_BLOCK_INDEX,
                            "Cannot append block to " + entry.file
                                    + " because next block index should be "
                                    + fileUC.blocks.size() + ", not "
                                    + entry.blockIndex));
                    return;
                }
                // check previous block
                if (!fileUC.blocks.isEmpty()) {
                    BlockWithSize prevBlock = fileUC.blocks.get(fileUC.blocks.size() - 1);
                    PlacedBlock pb = nameSystem.bstore.getBlock(prevBlock.block);
                    if (pb != null) {
                        int len;
                        int replications;
                        synchronized (pb) {
                            len = pb.getLen();
                            replications = pb.getLocs().length;
                        }
                        if (len > 0) {
                            prevBlock.size = len;
                        }
                        if (replications == 0) {
                            finishWithError(entry, new FSException(
                                    FSException.NOT_ENOUGH_REPLICATION,
                                    "Cannot append block to " + entry.file
                                            + " because previous block "
                                            + prevBlock.block
                                            + "'s replication is not enough"));
                            return;
                        }
                    } else {
                        finishWithError(entry, new FSException(
                                FSException.NOT_ENOUGH_REPLICATION,
                                "Cannot append block to " + entry.file
                                        + " because previous block "
                                        + prevBlock.block + " is not exists"));
                        return;
                    }
                    entry.prevBlock = prevBlock;
                } else {
                    entry.prevBlock = null;
                }
                try {
                    entry.nextBlock = nameSystem.bstore.allocateBlock(
                            entry.clientMachine,
                            fileUC.getDesiredReplications(),
                            fileUC.fileBlockSize);
                } catch (FSException e) {
                    finishWithError(entry, e);
                    return;
                }
            }
            processedFiles.add(entry.file);
        }

        @Override
        public void visit(AsyncAbandonBlockExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            synchronized (nameSystem.pendingCreates) {
                FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
                if (fileUC == null) {
                    finishWithError(entry, new FSException(
                            FSException.ILLEGAL_PARAM,
                            "Can not abandon block of " + entry.file
                                    + " because it is not pending"));
                    return;
                }
                if (!fileUC.holder.equals(entry.clientName)) {
                    finishWithError(entry, new FSException(
                            FSException.PERMISSION_DENIED,
                            "Can not abandon block of " + entry.file
                                    + " because " + entry.clientName
                                    + " is not its owner(owner is "
                                    + fileUC.holder + ")"));
                    return;
                }
                if (fileUC.blocks.isEmpty()) {
                    finishWithError(entry, new FSException(
                            FSException.ILLEGAL_STATE, "Cannot abandon "
                                    + entry.blockIndex + "th block of "
                                    + entry.file + " because it has no block"));
                    return;
                }
                int expectedIndex = fileUC.blocks.size() - 1;
                if (entry.blockIndex != expectedIndex) {
                    finishWithError(entry, new FSException(
                            FSException.INVALID_BLOCK_INDEX, "Cannot abandon "
                                    + entry.blockIndex + "th block of "
                                    + entry.file
                                    + " because it is last block index is "
                                    + expectedIndex + ", not "
                                    + entry.blockIndex));
                    return;
                }
            }
            processedFiles.add(entry.file);
        }

        @Override
        public void visit(AsyncCompleteExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            synchronized (nameSystem.pendingCreates) {
                FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
                if (fileUC == null) {
                    finishWithError(entry,
                            new FSException(FSException.ILLEGAL_PARAM,
                                    "Can not complete " + entry.file
                                            + " because it is not pending"));
                    return;
                }
                if (!fileUC.holder.equals(entry.clientName)) {
                    finishWithError(entry, new FSException(
                            FSException.PERMISSION_DENIED, "Can not complete "
                                    + entry.file + " because "
                                    + entry.clientName
                                    + " is not its owner(owner is "
                                    + fileUC.holder + ")"));
                    return;
                }
                if (fileUC.blocks.isEmpty()) {
                    finishWithError(entry, new FSException(
                            FSException.ILLEGAL_STATE, "Cannot complete "
                                    + entry.file + " because it has no block"));
                    return;
                }
                // check last block
                BlockWithSize lastBlock = fileUC.blocks.get(fileUC.blocks.size() - 1);
                PlacedBlock pb = nameSystem.bstore.getBlock(lastBlock.block);
                if (pb != null) {
                    int len;
                    int replications;
                    synchronized (pb) {
                        len = pb.getLen();
                        replications = pb.getLocs().length;
                    }
                    if (len > 0) {
                        lastBlock.size = len;
                    }
                    if (replications == 0) {
                        entry.setReturnValue(false);
                        entry.finish();
                        return;
                    }
                } else {
                    finishWithError(entry, new FSException(
                            FSException.NOT_ENOUGH_REPLICATION,
                            "Cannot complete " + entry.file
                                    + " because last block " + lastBlock.block
                                    + " is not exists"));
                    return;
                }
                entry.lastBlock = lastBlock;
            }
            processedFiles.add(entry.file);
        }

        @Override
        public void visit(AsyncAbandonExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            synchronized (nameSystem.pendingCreates) {
                FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
                if (fileUC == null) {
                    entry.finish();
                    return;
                }
            }
            processedFiles.add(entry.file);
        }

        @Override
        public void visit(AsyncForceCompleteExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            synchronized (nameSystem.pendingCreates) {
                FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
                if (fileUC == null) {
                    entry.finish();
                    return;
                }
                if (fileUC.blocks.isEmpty()) {
                    return;
                }
                BlockWithSize lastBlock = fileUC.blocks.get(fileUC.blocks.size() - 1);
                PlacedBlock pb = nameSystem.bstore.getBlock(lastBlock.block);
                if (pb != null) {
                    synchronized (pb) {
                        lastBlock.size = pb.getLen();
                    }
                }
                entry.lastBlock = lastBlock;
            }
            processedFiles.add(entry.file);
        }

        @Override
        public void visit(AsyncDepriveExecutiveEntry entry) {
            if (processedFiles.contains(entry.file)) {
                entry.delayed = true;
                return;
            }
            processedFiles.add(entry.file);
        }

    }

    private final LeaseRelatedEntryPreProcessor leaseRelatedPreProcessVisitor = new LeaseRelatedEntryPreProcessor();

    private void poll(List<AsyncExecutiveEntry> leaseRelatedEntries,
            List<AsyncExecutiveEntry> otherEntries) throws InterruptedException {
        long startTime = System.currentTimeMillis();
        for (; leaseRelatedEntries.size() + otherEntries.size() < maxBatchElements;) {
            long toWaitTime = maxWaitTime
                    - (System.currentTimeMillis() - startTime);
            if (toWaitTime <= 0) {
                break;
            }
            AsyncExecutiveEntry entry = queue.poll(toWaitTime,
                    TimeUnit.MILLISECONDS);
            if (entry == null) {
                break;
            }
            if (entry.leaseRelated()) {
                leaseRelatedEntries.add(entry);
            } else {
                otherEntries.add(entry);
            }
        }
    }

    private boolean preProcessAndLogEdits(long time,
            List<AsyncExecutiveEntry> leaseRelatedEntries,
            List<AsyncExecutiveEntry> otherEntries,
            List<AsyncExecutiveEntry> delayedLeaseRelatedEntries)
            throws IOException {
        leaseRelatedPreProcessVisitor.visitBegin();
        for (int i = 0, n = leaseRelatedEntries.size(); i < n; i++) {
            AsyncExecutiveEntry entry = leaseRelatedEntries.get(i);
            entry.time = time;
            entry.accept(leaseRelatedPreProcessVisitor);
            if (entry.finished) {
                leaseRelatedEntries.set(i, null);
            } else if (entry.delayed) {
                leaseRelatedEntries.set(i, null);
                entry.delayed = false;
                delayedLeaseRelatedEntries.add(entry);
            } else {
                entry.accept(nameSystem.editLogger);
            }
        }
        for (AsyncExecutiveEntry entry: otherEntries) {
            entry.time = time;
            entry.accept(nameSystem.editLogger);
        }
        leaseRelatedPreProcessVisitor.visitEnd();
        return nameSystem.editLogger.hasBufferedLogs();
    }

    // return false if we are closed
    private boolean syncLog() throws IOException {
        for (int retry = 0;; retry++) {
            try {
                nameSystem.editLogger.sync();
                return true;
            } catch (IOException e) {
                LOG.log(Level.WARNING, "sync log failed, retry = " + retry, e);
            }
            if (closed) {
                return false;
            }
            nameSystem.editLogger.nextLogFile(true);
        }
    }

    private void applyEditsAndFinishCall(long time,
            List<AsyncExecutiveEntry> leaseRelatedEntries,
            List<AsyncExecutiveEntry> otherEntries) {
        for (AsyncExecutiveEntry entry: leaseRelatedEntries) {
            if (entry == null) {
                continue;
            }
            entry.accept(this);
        }
        for (AsyncExecutiveEntry entry: otherEntries) {
            if (entry == null) {
                continue;
            }
            entry.accept(this);
        }
    }

    @Override
    public void run() {
        List<AsyncExecutiveEntry> leaseRelatedEntries = new ArrayList<AsyncExecutiveEntry>(
                maxBatchElements);
        List<AsyncExecutiveEntry> otherEntries = new ArrayList<AsyncExecutiveEntry>(
                maxBatchElements);
        List<AsyncExecutiveEntry> delayedLeaseRelatedEntries = new ArrayList<AsyncExecutiveEntry>();
        while (!closed) {
            try {
                if (System.currentTimeMillis() > nextRollingTime) {
                    try {
                        nameSystem.editLogger.nextLogFile(false);
                    } catch (IOException e) {
                        LOG.warning("Open next log file failed,"
                                + "try to recover and start new log file");
                        nameSystem.editLogger.nextLogFile(true);
                    }
                    nextRollingTime += editLogRollingInterval;
                }
                leaseRelatedEntries.clear();
                leaseRelatedEntries.addAll(delayedLeaseRelatedEntries);
                delayedLeaseRelatedEntries.clear();
                otherEntries.clear();
                try {
                    poll(leaseRelatedEntries, otherEntries);
                } catch (InterruptedException e) {
                    for (AsyncExecutiveEntry entry: leaseRelatedEntries) {
                        entry.setError(e);
                        entry.finish();
                    }
                    for (AsyncExecutiveEntry entry: otherEntries) {
                        entry.setError(e);
                        entry.finish();
                    }
                    continue;
                }
                if (leaseRelatedEntries.isEmpty() && otherEntries.isEmpty()) {
                    continue;
                }
                long time = System.currentTimeMillis();
                if (preProcessAndLogEdits(time, leaseRelatedEntries,
                        otherEntries, delayedLeaseRelatedEntries)) {
                    if (!syncLog()) {
                        break;
                    }
                    applyEditsAndFinishCall(time, leaseRelatedEntries,
                            otherEntries);
                }
            } catch (Throwable t) {
                LOG.log(Level.SEVERE,
                        "fatal error occured when process edit logs, I must kill myself",
                        t);
                System.exit(1);
            }
        }
    }

    void schedule(AsyncExecutiveEntry entry) {
        queue.add(entry);
    }

    @Override
    public void close() {
        closed = true;
        interrupt();
    }

    private void finishCreateWithError(AsyncCreateExecutiveEntry entry,
            Throwable error) {
        nameSystem.bstore.unreserveBlock(entry.firstBlock.getBlock(),
                entry.firstBlock.getLocations());
        finishWithError(entry, error);
    }

    @Override
    public void visit(AsyncCreateExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            FileINodeUC fileUC;
            try {
                fileUC = nameSystem.dir.addFileUC(entry.time, entry.file,
                        entry.overwrite, entry.createParent, entry.permission,
                        entry.replication, entry.fileBlockSize,
                        entry.clientName, entry.user);
            } catch (Exception e) {
                finishCreateWithError(entry, e);
                return;
            }
            fileUC.blocks.add(new BlockWithSize(entry.firstBlock.getBlock(), 0));
            nameSystem.pendingCreates.put(entry.file, fileUC);
            nameSystem.pendingCreateLastBlocks.put(entry.firstBlock.getBlock(),
                    entry.firstBlock.getLocations());
            nameSystem.bstore.addBlock(entry.firstBlock.getBlock(), 0,
                    fileUC.getDesiredReplications());
            nameSystem.addLeaseCreate(entry.clientName, entry.file);
            entry.setReturnValue(entry.firstBlock);
            entry.finish();
        }
    }

    @Override
    public void visit(AsyncAppendBlockExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            if (entry.prevBlock != null) {
                String[] locs = nameSystem.pendingCreateLastBlocks.remove(entry.prevBlock.block);
                if (locs != null) {
                    nameSystem.bstore.unreserveBlock(entry.prevBlock.block,
                            locs);
                }
            }
            nameSystem.pendingCreateLastBlocks.put(entry.nextBlock.getBlock(),
                    entry.nextBlock.getLocations());
            FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
            nameSystem.bstore.addBlock(entry.nextBlock.getBlock(), 0,
                    fileUC.getDesiredReplications());
            fileUC.blocks.add(new BlockWithSize(entry.nextBlock.getBlock(), 0));
            entry.setReturnValue(entry.nextBlock);
            entry.finish();
        }
    }

    @Override
    public void visit(AsyncAbandonBlockExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            FileINodeUC fileUC = nameSystem.pendingCreates.get(entry.file);
            BlockWithSize bs = fileUC.blocks.remove(entry.blockIndex);
            String[] locs = nameSystem.pendingCreateLastBlocks.remove(bs.block);
            if (locs != null) {
                nameSystem.bstore.unreserveBlock(bs.block, locs);
            }
            nameSystem.bstore.trashBlocks(new long[] {
                bs.block
            }, "Client " + entry.clientName + " abandon block " + bs.block
                    + " of file " + entry.file);
            entry.finish();
        }
    }

    private long[] getBlockIds(List<BlockWithSize> blocks) {
        long[] blockIds = new long[blocks.size()];
        for (int i = 0; i < blockIds.length; i++) {
            blockIds[i] = blocks.get(i).block;
        }
        return blockIds;
    }

    @Override
    public void visit(AsyncCompleteExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            FileINodeUC fileUC = nameSystem.pendingCreates.remove(entry.file);
            BlockWithSize lastBlock = fileUC.blocks.get(fileUC.blocks.size() - 1);
            String[] locs = nameSystem.pendingCreateLastBlocks.remove(lastBlock.block);
            if (locs != null) {
                nameSystem.bstore.unreserveBlock(lastBlock.block, locs);
            }
            if (!nameSystem.dir.completeFile(entry.time, entry.file)) {
                long[] blocks = getBlockIds(fileUC.blocks);
                nameSystem.bstore.trashBlocks(blocks, "Complete file "
                        + entry.file + " that already being deleted");
            }
            nameSystem.removeLeaseCreate(entry.clientName, entry.file, true);
            entry.setReturnValue(true);
            entry.finish();
        }
    }

    @Override
    public void visit(AsyncAbandonExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            try {
                nameSystem.dir.abandonFileUC(entry.time, entry.file, entry.user);
            } catch (Exception e) {
                finishWithError(entry, e);
                return;
            }
            FileINodeUC fileUC = nameSystem.pendingCreates.remove(entry.file);
            if (!fileUC.blocks.isEmpty()) {
                long[] blocks = getBlockIds(fileUC.blocks);
                long lastBlock = blocks[blocks.length - 1];
                String[] locs;
                synchronized (nameSystem.pendingCreates) {
                    locs = nameSystem.pendingCreateLastBlocks.remove(lastBlock);
                }
                if (locs != null) {
                    nameSystem.bstore.unreserveBlock(lastBlock, locs);
                }
                nameSystem.bstore.trashBlocks(blocks, "Abandon file "
                        + entry.file);
            }
            nameSystem.removeLeaseCreate(fileUC.holder, entry.file, false);
            entry.finish();
        }
    }

    @Override
    public void visit(AsyncForceCompleteExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            FileINodeUC fileUC = nameSystem.pendingCreates.remove(entry.file);
            if (fileUC.blocks.isEmpty()) {
                try {
                    nameSystem.dir.abandonFileUC(entry.time, entry.file, null);
                } catch (FSException e) {
                    // should not happen
                    throw new RuntimeException(e);
                }
            } else {
                BlockWithSize lastBlock = fileUC.blocks.get(fileUC.blocks.size() - 1);
                String[] locs;
                synchronized (nameSystem.pendingCreates) {
                    locs = nameSystem.pendingCreateLastBlocks.remove(lastBlock.block);
                }
                if (locs != null) {
                    nameSystem.bstore.forceCompleteBlock(lastBlock.block, locs);
                }
                if (!nameSystem.dir.completeFile(entry.time, entry.file)) {
                    long[] blocks = getBlockIds(fileUC.blocks);
                    nameSystem.bstore.trashBlocks(blocks, "Complete file "
                            + entry.file + " that already being deleted");
                }
            }
            entry.finish();
        }
    }

    @Override
    public void visit(AsyncDepriveExecutiveEntry entry) {
        synchronized (nameSystem.pendingCreates) {
            try {
                entry.setReturnValue(nameSystem.dir.deprive(entry.time,
                        entry.file, entry.user));
            } catch (FSException e) {
                finishWithError(entry, e);
                return;
            }
            FileINodeUC fileUC = nameSystem.pendingCreates.remove(entry.file);
            if (fileUC == null) {
                entry.finish();
                return;
            }
            if (!fileUC.blocks.isEmpty()) {
                long[] blocks = getBlockIds(fileUC.blocks);
                long lastBlock = blocks[blocks.length - 1];
                String[] locs;
                synchronized (nameSystem.pendingCreates) {
                    locs = nameSystem.pendingCreateLastBlocks.remove(lastBlock);
                }
                if (locs != null) {
                    nameSystem.bstore.unreserveBlock(lastBlock, locs);
                }
                nameSystem.bstore.trashBlocks(blocks, "Abandon file "
                        + entry.file);
            }
            nameSystem.removeLeaseCreate(fileUC.holder, entry.file, false);
            entry.finish();
        }
    }

    @Override
    public void visit(AsyncRenameExecutiveEntry entry) {
        try {
            nameSystem.dir.renameTo(entry.time, entry.src, entry.dst,
                    entry.overwrite, entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.finish();
    }

    @Override
    public void visit(AsyncDeleteExecutiveEntry entry) {
        boolean succ;
        try {
            succ = nameSystem.dir.delete(entry.time, entry.path,
                    entry.recursive, entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.setReturnValue(succ);
        entry.finish();
    }

    @Override
    public void visit(AsyncTrashExecutiveEntry entry) {
        String trashPath;
        try {
            trashPath = nameSystem.dir.mkdirsAndRenameToWithoutCheckQuota(
                    entry.time, entry.path, entry.trashPath, entry.recursive,
                    entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.setReturnValue(trashPath != null);
        entry.finish();
    }

    @Override
    public void visit(AsyncMkdirExecutiveEntry entry) {
        boolean succ;
        try {
            succ = nameSystem.dir.mkdirs(entry.time, entry.dir,
                    entry.replication, entry.permission, entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.setReturnValue(succ);
        entry.finish();
    }

    @Override
    public void visit(AsyncSnapshotExecutiveEntry entry) {
        try {
            nameSystem.dir.snapshot(entry.time, entry.src, entry.dst,
                    entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.finish();
    }

    @Override
    public void visit(AsyncReplicateExecutiveEntry entry) {
        try {
            nameSystem.dir.changeReplication(entry.time, entry.path,
                    entry.replication, entry.recursive, entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.finish();
    }

    @Override
    public void visit(AsyncChownExecutiveEntry entry) {
        try {
            nameSystem.dir.setOwnerAndGroup(entry.path, entry.owner,
                    entry.group, entry.recursive, entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.finish();
    }

    @Override
    public void visit(AsyncChmodExecutiveEntry entry) {
        try {
            nameSystem.dir.setPermission(entry.path, entry.permission,
                    entry.recursive, entry.user);
        } catch (FSException e) {
            finishWithError(entry, e);
            return;
        }
        entry.finish();
    }

    @Override
    public void visit(AsyncAddGroupUserExecutiveEntry entry) {
        nameSystem.dir.ugMgr.addGroupUser(entry.group, entry.user);
        entry.finish();
    }

    @Override
    public void visit(AsyncRemoveGroupUserExecutiveEntry entry) {
        nameSystem.dir.ugMgr.removeGroupUser(entry.group, entry.user);
        entry.finish();
    }

    @Override
    public void visit(AsyncRemoveGroupExecutiveEntry entry) {
        nameSystem.dir.ugMgr.removeGroup(entry.group);
        entry.finish();
    }

    @Override
    public void visit(AsyncSetSpaceQuotaExecutiveEntry entry) {
        nameSystem.dir.fsDirPropMgr.setSpaceQuota(entry.path, entry.quota);
        entry.finish();
    }

    @Override
    public void visit(AsyncSetNameQuotaExecutiveEntry entry) {
        nameSystem.dir.fsDirPropMgr.setNameQuota(entry.path, entry.quota);
        entry.finish();
    }

    @Override
    public void visit(AsyncSetProtectExecutiveEntry entry) {
        nameSystem.dir.fsDirPropMgr.setProtect(entry.path, entry.protect);
        entry.finish();
    }

    @Override
    public void visit(AsyncSetRecoverableExecutiveEntry entry) {
        nameSystem.dir.fsDirPropMgr.setRecoverable(entry.path,
                entry.recoverable);
        entry.finish();
    }

}
