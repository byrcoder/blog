/**
 * @(#)DataXceiveWorker0.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.IOException;
import java.net.SocketException;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.FSConstants;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class DataXceiveWorker extends Thread {

    private static final Logger LOG = LogFormatter.getLogger(DataXceiveWorker.class);

    private static final long SELECT_TIMEOUT = 1000;

    private volatile boolean running = true;

    private final Selector selector;

    private static enum Op {
        REGISTER, CANCEL
    }

    private static final class WaitingEntry {
        final Connection conn;

        final Op op;

        WaitingEntry(Connection conn, Op op) {
            this.conn = conn;
            this.op = op;
        }

    }

    private final List<WaitingEntry> waitingList = new ArrayList<WaitingEntry>();

    DataXceiveWorker() throws IOException {
        super("DataXceiveWorker");
        setDaemon(true);
        selector = Selector.open();
    }

    private void closeKey(SelectionKey key, Connection conn) {
        key.cancel();
        conn.cleanUp();
    }

    private void doSelection() throws IOException {
        int count = selector.select(SELECT_TIMEOUT);
        if (count > 0) {
            Set<SelectionKey> keys = selector.selectedKeys();
            for (SelectionKey key: keys) {
                Connection conn = (Connection) key.attachment();
                try {
                    if (key.isReadable()) {
                        conn.onRead();
                    } else if (key.isWritable()) {
                        conn.onWrite();
                    } else {
                        LOG.warning("unexpected interest op: "
                                + key.interestOps());
                    }
                } catch (UnexpectedEOFException e) {
                    LOG.info("Closing " + key.attachment() + " on " + e
                            + " after "
                            + (System.currentTimeMillis() - conn.initTime)
                            + "ms");
                    closeKey(key, conn);
                } catch (SocketException e) {
                    LOG.info("Closing " + key.attachment() + " on " + e
                            + " after "
                            + (System.currentTimeMillis() - conn.initTime)
                            + "ms");
                    closeKey(key, conn);
                } catch (UnsupportedProtocolVersionException e) {
                    LOG.warning("Closing " + key.attachment() + " on " + e
                            + " after "
                            + (System.currentTimeMillis() - conn.initTime)
                            + "ms");
                    closeKey(key, conn);
                } catch (RequestTooLargeException e) {
                    LOG.warning("Closing " + key.attachment() + " on " + e
                            + " after "
                            + (System.currentTimeMillis() - conn.initTime)
                            + "ms");
                    closeKey(key, conn);
                } catch (IOException e) {
                    if (e.getMessage().equals(
                            FSConstants.MSG_CONNECTION_RESET_BY_PEER)) {
                        LOG.warning("Closing " + key.attachment() + " on " + e
                                + " after "
                                + (System.currentTimeMillis() - conn.initTime)
                                + "ms");
                    } else {
                        LOG.log(Level.WARNING,
                                "Closing "
                                        + key.attachment()
                                        + " on error after "
                                        + (System.currentTimeMillis() - conn.initTime)
                                        + "ms", e);
                    }
                    closeKey(key, conn);
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "Closing " + key.attachment()
                            + " on error after "
                            + (System.currentTimeMillis() - conn.initTime)
                            + "ms", t);
                    closeKey(key, conn);
                }
            }
            keys.clear();
        }
    }

    private void doRegistry(Connection conn) {
        SelectionKey k = conn.socket.keyFor(selector);
        try {
            if (k == null || !k.isValid()) {
                conn.socket.register(selector, conn.interestOps, conn);
            } else {
                k.interestOps(conn.interestOps);
            }
        } catch (ClosedChannelException e) {
            LOG.log(Level.WARNING, conn + " already closed", e);
        } catch (CancelledKeyException e) {
            LOG.log(Level.WARNING, "SelectionKey for " + conn
                    + " already canceled", e);
        }
    }

    private void doCancellation(Connection conn) {
        SelectionKey key = conn.socket.keyFor(selector);
        if (key != null) {
            key.cancel();
        }
        conn.cleanUp();
    }

    private void doRegistryOrCancellation() {
        synchronized (waitingList) {
            for (WaitingEntry entry: waitingList) {
                switch (entry.op) {
                    case REGISTER:
                        doRegistry(entry.conn);
                        break;
                    case CANCEL:
                        doCancellation(entry.conn);
                        break;
                    default:
                        LOG.warning("DataXceiveWorker found unknown op: "
                                + entry.op);
                }
            }
            waitingList.clear();
        }
    }

    private void addToWaitingList(WaitingEntry entry) {
        boolean needWakeup = false;
        synchronized (waitingList) {
            if (waitingList.isEmpty()) {
                needWakeup = true;
            }
            waitingList.add(entry);
        }
        if (needWakeup) {
            selector.wakeup();
        }
    }

    void register(Connection conn) {
        addToWaitingList(new WaitingEntry(conn, Op.REGISTER));
    }

    void cancel(Connection conn) {
        addToWaitingList(new WaitingEntry(conn, Op.CANCEL));
    }

    void cancelWithoutCleanUpDirectly(Connection conn) {
        SelectionKey key = conn.socket.keyFor(selector);
        if (key != null) {
            key.cancel();
        }
    }

    @Override
    public void run() {
        LOG.info(getName() + " started");
        while (running) {
            try {
                doSelection();
            } catch (Throwable t) {
                LOG.log(Level.SEVERE, "unexpected throwable caught", t);
            }

            try {
                doRegistryOrCancellation();
            } catch (Throwable t) {
                LOG.log(Level.SEVERE, "unexpected throwable caught", t);
            }
        }
        LOG.info(getName() + " ended");
    }

    void shutdown() {
        running = false;
        ReadWriteUtils.safeCloseSelector(selector);
    }
}
