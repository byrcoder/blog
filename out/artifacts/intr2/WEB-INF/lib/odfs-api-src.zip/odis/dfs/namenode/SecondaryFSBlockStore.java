/**
 * @(#)SecondaryFSBlockStore.java, 2012-12-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.HashMap;

/**
 * @author zhangduo
 */
public class SecondaryFSBlockStore extends AbstractFSBlockStore {

    SecondaryFSBlockStore() {
        super(new HashMap<Long, PlacedBlock>(),
                new HashMap<Long, PlacedBlock>());
    }

    @Override
    void changeReplication(long[] blocks, int replications) {}

    @Override
    public void close() {}

}
