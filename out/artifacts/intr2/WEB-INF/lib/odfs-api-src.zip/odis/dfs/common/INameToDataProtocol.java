/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 5, 2006
 */
package odis.dfs.common;

import odis.rpc2.RpcException;

/**
 * Protocol that namenode uses to talk to datanodes.
 * <p>
 * We use an udp client to send command to datanode. It is not reliable, so this
 * only makes the command run <strong>FASTER</strong>, not run
 * <strong>CORRECT</strong>. If send failed, we consider that datanode will get
 * this command eventually by heartbeat if it is still alive.
 * 
 * @author zhangduo
 */
public interface INameToDataProtocol {

    /**
     * Send commands to datanode
     * 
     * @param cmds
     * @throws RpcException
     */
    void sendCommand(DataNodeCommand[] cmds) throws RpcException;
}
