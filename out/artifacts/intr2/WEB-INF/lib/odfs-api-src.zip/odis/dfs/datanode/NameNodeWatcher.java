/**
 * @(#)NameNodeWatcher.java, 2012-12-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.common.IDataToNameProtocol;
import odis.dfs.util.DfsUtils;
import odis.dfs.util.NoActionWatcher;
import odis.io.ReadWriteUtils;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;

import org.apache.commons.configuration.Configuration;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class NameNodeWatcher implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(NameNodeWatcher.class);

    private final ZooKeeper zk;

    private final String addrPath;

    private final int zkMaxRetryCount;

    private final long rpcTimeout;

    private final long maxCheckInterval;

    private final Map<String, Integer> addr2Index = new HashMap<String, Integer>();

    private volatile IDataToNameProtocol[] nameNodes;

    private long nextCheckTime;

    private boolean addrChanged = false;

    private final Watcher addrWatcher = new Watcher() {

        @Override
        public void process(WatchedEvent event) {
            synchronized (NameNodeWatcher.this) {
                addrChanged = true;
                NameNodeWatcher.this.notify();
            }
        }
    };

    private void setNameNodes() throws KeeperException, InterruptedException {
        List<String> addrs;
        for (int retry = 0;; retry++) {
            try {
                addrs = zk.getChildren(addrPath, addrWatcher);
                break;
            } catch (KeeperException e) {
                if (Code.CONNECTIONLOSS.equals(e.code())) {
                    if (zkMaxRetryCount >= 0 && retry >= zkMaxRetryCount) {
                        throw e;
                    }
                    retry++;
                    LOG.log(Level.WARNING, "get namenode addr failed, retry = "
                            + retry, e);
                    DfsUtils.waitExpTime(retry - 1);
                } else {
                    throw e;
                }
            }
        }
        List<IDataToNameProtocol> nameNodes = new ArrayList<IDataToNameProtocol>();
        Map<String, Integer> addr2Index = new HashMap<String, Integer>();
        for (String addr: addrs) {
            addr2Index.put(addr, nameNodes.size());
            Integer index = this.addr2Index.get(addr);
            if (index != null) {
                nameNodes.add(this.nameNodes[index]);
            } else {
                String[] ss = addr.split(":");
                IDataToNameProtocol nameNode;
                try {
                    nameNode = RPC.getProxy(
                            IDataToNameProtocol.class,
                            new InetSocketAddress(ss[0],
                                    Integer.parseInt(ss[1])
                                            + SYSTEM_RPC_PORT_DELTA),
                            "datanode", System.getProperty("user.name", ""),
                            rpcTimeout);
                } catch (RpcException e) {
                    // should not happen
                    throw new RuntimeException(e);
                }
                nameNodes.add(nameNode);
            }
        }
        IDataToNameProtocol[] oldNameNodes = this.nameNodes;
        this.nameNodes = nameNodes.toArray(new IDataToNameProtocol[0]);
        for (Map.Entry<String, Integer> entry: this.addr2Index.entrySet()) {
            if (!addr2Index.containsKey(entry.getKey())) {
                RPC.close(oldNameNodes[entry.getValue()]);
            }
        }
        this.addr2Index.clear();
        this.addr2Index.putAll(addr2Index);
        nextCheckTime = System.currentTimeMillis() + maxCheckInterval;
        LOG.info("Set namenode to " + Arrays.toString(this.nameNodes));
    }

    NameNodeWatcher(Configuration conf) throws IOException, KeeperException,
            InterruptedException {
        String zkAddr = DfsUtils.getZkAddr(conf);
        String zkRoot = conf.getString(DFSConfig.ZOOKEEPER_ROOT);
        int zkTimeout = conf.getInt(DFSConfig.ZOOKEEPER_TIMEOUT,
                DFSConfig.DEFAULT_ZOOKEEPER_TIMEOUT);
        this.zkMaxRetryCount = conf.getInt(
                DFSConfig.DATANODE_ZK_MAX_RETRY_COUNT,
                DFSConfig.DEFAULT_DATANODE_ZK_MAX_RETRY_COUNT);
        long heartbeatInterval = conf.getLong(
                DFSConfig.DATANODE_HEARTBEAT_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_HEARTBEAT_INTERVAL);
        this.rpcTimeout = conf.getLong(DFSConfig.DATANODE_HEARTBEAT_EXPIRE,
                10 * heartbeatInterval) / 2;
        this.maxCheckInterval = conf.getLong(
                DFSConfig.DATANODE_CHECK_NAMENODE_ADDR_MAX_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_CHECK_NAMENODE_ADDR_MAX_INTERVAL);
        zk = new ZooKeeper(zkAddr, zkTimeout, NoActionWatcher.getWatcher());
        addrPath = zkRoot + "/" + NAMENODE_ADDR_ZK_DIR;
        synchronized (this) {
            setNameNodes();
        }
    }

    IDataToNameProtocol[] getNameNodes() {
        return nameNodes;
    }

    private boolean closed = false;

    synchronized void checkAddr() throws KeeperException, InterruptedException {
        while (!closed) {
            long toWaitTime = nextCheckTime - System.currentTimeMillis();
            if (addrChanged || toWaitTime <= 0) {
                setNameNodes();
                addrChanged = false;
                continue;
            }
            wait(toWaitTime);
        }
    }

    synchronized void shutdown() {
        closed = true;
        ReadWriteUtils.safeCloseZooKeeper(zk);
        notifyAll();
    }

}
