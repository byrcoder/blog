/**
 * @(#)SequentialReadBlockTask.java, 2012-12-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockCheckResult.Result;
import odis.dfs.datanode.Connection.ICallback;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class SequentialReadBlockTask implements Runnable {

    private static final Logger LOG = LogFormatter.getLogger(SequentialReadBlockTask.class);

    private final Connection conn;

    private final long blockId;

    private final int off;

    private final ByteBuffer bb;

    SequentialReadBlockTask(Connection conn, long blockId, int off,
            ByteBuffer bb) {
        this.conn = conn;
        this.blockId = blockId;
        this.off = off;
        this.bb = bb;
    }

    private boolean initialized = false;

    private BlockInputStream in;

    private long startTime;

    private int bytesSent;

    private void finishMetrics() {
        long delay = System.currentTimeMillis() - startTime;
        conn.dataNode.metrics.increment(DataNodeMetricsItem.NORMAL_READ_COUNT);
        conn.dataNode.metrics.add(DataNodeMetricsItem.NORMAL_READ_BYTES,
                bytesSent);
        conn.dataNode.metrics.add(DataNodeMetricsItem.NORMAL_READ_DELAY, delay);
        conn.dataNode.metrics.decrement(DataNodeMetricsItem.CONCURRENT_READ);
    }

    private void cleanUpWithoutCloseConn() {
        conn.directByteBufferPool.release(bb);
        finishMetrics();
        ReadWriteUtils.safeClose(in);
    }

    private void cleanUp() {
        cleanUpWithoutCloseConn();
        ReadWriteUtils.safeClose(conn);
        Thread.currentThread().setName("Idle-DataXceiver");
    }

    @Override
    public void run() {
        Thread.currentThread().setName(
                "SRB-" + conn.dataNode.getFullName() + "-" + blockId + "-"
                        + conn.socket.socket().getRemoteSocketAddress());
        try {
            bb.clear();
            if (!initialized) {
                startTime = System.currentTimeMillis();
                conn.dataNode.metrics.increment(DataNodeMetricsItem.CONCURRENT_READ);
                in = conn.dataNode.dataSet.openBlock(blockId, this.off);
                bb.putInt(in.getRemaining());
                initialized = true;
            }
            while (in.getRemaining() > 0) {
                int read;
                conn.dataNode.diskReadGuard.acquire();
                try {
                    read = in.read(bb);
                } finally {
                    conn.dataNode.diskReadGuard.release();
                }
                bytesSent += read;
                bb.flip();
                for (int i = 0; bb.hasRemaining()
                        && i < Connection.WRITE_MAX_SPINS; i++) {
                    conn.socket.write(bb);
                }
                if (bb.hasRemaining()) {
                    conn.asyncWrite(bb, new ICallback() {

                        @Override
                        public void operationSucceeded() {
                            conn.dataNode.executeTask(SequentialReadBlockTask.this);
                        }

                        @Override
                        public void operationFailed() {
                            cleanUpWithoutCloseConn();
                            // this call means connection is broken and is 
                            // already closed, so we do not need to close 
                            // connection again
                        }
                    });
                    Thread.currentThread().setName("Idle-DataXceiver");
                    return;
                } else {
                    bb.clear();
                }
            }
            cleanUpWithoutCloseConn();
            Thread.currentThread().setName("Idle-DataXceiver");
        } catch (BlockChecksumMismatchException e) {
            conn.dataNode.recoverInconsistentBlock(blockId,
                    new BlockCheckResult(Result.MISMATCH, e.oc, e.cc));
            LOG.log(Level.WARNING, conn.remoteAddr() + " read "
                    + in.getBlockFile().getAbsolutePath() + " failed", e);
            cleanUp();
        } catch (ClosedChannelException e) {
            // just clean up.
            cleanUp();
        } catch (Exception e) {
            if (in == null) {
                LOG.log(Level.WARNING, "open block " + blockId + " failed", e);
            } else {
                LOG.log(Level.WARNING, conn.remoteAddr() + " read "
                        + in.getBlockFile().getAbsolutePath() + " failed", e);
            }
            cleanUp();
        }
    }
}
