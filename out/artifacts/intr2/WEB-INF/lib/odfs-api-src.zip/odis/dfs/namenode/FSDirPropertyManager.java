package odis.dfs.namenode;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import odis.dfs.common.FSException;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.lib.StringWritable;
import toolbox.collections.Pair;

/**
 * FSDirPropertyManager manage the property of FSDirectory include the
 * persistent files, recoverable files, temp dirs the space quota and namequota
 * of a dir, the access control list of a dir.<br>
 * Because of performance issue, we do not check some read operation's such as
 * exists, isDir, etc.
 * 
 * @author xuyang
 */
class FSDirPropertyManager {

    /**
     * This class is "thread safe". But this "thread safe" only means you will
     * not get exception when do something, not means all things will go right.
     * But we think this it not hurt a lot because dir property can only be
     * modified by the administrator, the concurrency level is very low and we
     * can fix the problem manually.
     * 
     * @author zhangduo
     */
    private static class DirProperty {

        private final String path;

        private volatile long spaceQuota;

        private volatile long nameQuota;

        private volatile boolean recoverable = false;

        private volatile boolean protect = false;

        DirProperty(String path) {
            this.path = path;
        }

        String getPath() {
            return path;
        }

        long getSpaceQuota() {
            return spaceQuota;
        }

        void setSpaceQuota(long quota) {
            this.spaceQuota = quota;
        }

        long getNameQuota() {
            return nameQuota;
        }

        void setNameQuota(long nameQuota) {
            this.nameQuota = nameQuota;
        }

        boolean isRecoverable() {
            return recoverable;
        }

        void setRecoverable(boolean recoverable) {
            this.recoverable = recoverable;
        }

        boolean isProtect() {
            return protect;
        }

        void setProtected(boolean protect) {
            this.protect = protect;
        }

        boolean isUseLess() {
            return spaceQuota == 0 && nameQuota == 0 && !recoverable
                    && !protect;
        }

        @Override
        public String toString() {
            return "[DirProperty path=" + path + " spacequota=" + spaceQuota
                    + " namequota=" + nameQuota + " protected=" + protect
                    + " recoverable=" + recoverable + "]";
        }
    }

    private ConcurrentMap<String, DirProperty> propertyMap = new ConcurrentHashMap<String, DirProperty>();

    /**
     * check whether a path is out of name quota
     * 
     * @param path
     * @param curItemNum
     * @return
     */
    boolean outOfNameQuota(String path, long curItemNum) {
        long quota = getNameQuota(path);
        return quota > 0 && quota < curItemNum;
    }

    /**
     * get namequota value of a path
     * 
     * @param path
     * @return
     */
    long getNameQuota(String path) {
        DirProperty prop = propertyMap.get(path);
        if (prop == null) {
            return 0;
        } else {
            return prop.getNameQuota();
        }
    }

    /**
     * set a new namequota value to a path you can not set quota to a temp
     * dir(and its subdir)
     * 
     * @param path
     * @param newQuota
     * @param dirop
     *            : used for the caller to log edit
     * @return
     * @throws FSException
     */
    void setNameQuota(String path, long newQuota) {
        DirProperty prop = propertyMap.get(path);
        if (prop == null) {
            if (newQuota == 0) {
                return;
            }
            prop = new DirProperty(path);
            propertyMap.put(path, prop);
        }
        prop.setNameQuota(newQuota);
        if (prop.isUseLess()) {
            propertyMap.remove(path);
        }

    }

    /**
     * check if a dir is out of space quota(quota<current size)
     * 
     * @param the
     *            path that is being check
     * @return true(out of quota, can not add any new file or dir) false(not out
     *         of quota, can add new file or dir)
     */
    boolean outOfSpaceQuota(String path, long contentLength) {
        long quota = getSpaceQuota(path);
        return quota > 0 && quota < contentLength;
    }

    /**
     * get a dir's current space quota value
     * 
     * @param path
     * @return
     */
    long getSpaceQuota(String path) {
        DirProperty prop = propertyMap.get(path);
        if (prop == null) {
            return 0;
        } else {
            return prop.getSpaceQuota();
        }
    }

    /**
     * set space quota for a path you can not set quota to a temp dir(and its
     * subdir)
     * 
     * @param path
     * @param newQuota
     * @param dirop
     *            : used for the caller to log edit
     * @return
     * @throws FSException
     */
    void setSpaceQuota(String path, long newQuota) {
        DirProperty prop = propertyMap.get(path);
        if (prop == null) {
            if (newQuota == 0) {
                return;
            }
            prop = new DirProperty(path);
            propertyMap.put(path, prop);
        }
        prop.setSpaceQuota(newQuota);
        if (prop.isUseLess()) {
            propertyMap.remove(path);
        }

    }

    /**
     * get all dir thar had been set quota, used in web monitor
     * 
     * @return list of all temp dir
     */

    List<String> getAllQuotaedDirList() {
        ArrayList<String> quotaedDirList = new ArrayList<String>();
        for (DirProperty prop: propertyMap.values()) {
            if (prop.getSpaceQuota() > 0 || prop.getNameQuota() > 0) {
                quotaedDirList.add(prop.getPath());
            }
        }
        return quotaedDirList;
    }

    /**
     * check whether a path is protected a protected path can not be deleted
     * 
     * @param npath
     * @return
     */
    boolean isProtect(String npath) {
        DirProperty prop = propertyMap.get(npath);
        if (prop == null) {
            return false;
        }
        return prop.isProtect();
    }

    /**
     * set a path to protect or not
     * 
     * @param path
     * @param protect
     * @param dirop
     *            : used for the caller to log edit
     */
    void setProtect(String path, boolean protect) {
        DirProperty prop = propertyMap.get(path);
        if (prop == null) {
            if (!protect) {
                return;
            }
            prop = new DirProperty(path);
            propertyMap.put(path, prop);
        }
        prop.setProtected(protect);
        if (prop.isUseLess()) {
            propertyMap.remove(path);
        }
    }

    /**
     * check whether a path is recoverable when deleted, a recoverable path will
     * be move to trash first
     * 
     * @param npath
     * @return
     */
    boolean isRecoverable(String path) {
        while (path != null) {
            DirProperty prop = propertyMap.get(path);
            if (prop != null && prop.isRecoverable()) {
                return true;
            }
            path = DirUtils.getParent(path);
        }
        return false;
    }

    /**
     * set a path to recoverable or not
     * 
     * @param path
     * @param recoverable
     * @param dirop
     *            : used for the caller to log edit
     */
    void setRecoverable(String path, boolean recoverable) {
        DirProperty prop = propertyMap.get(path);
        if (prop == null) {
            if (!recoverable) {
                return;
            }
            prop = new DirProperty(path);
            propertyMap.put(path, prop);
        }
        prop.setRecoverable(recoverable);
        if (prop.isUseLess()) {
            propertyMap.remove(path);
        }
    }

    /**
     * used when save image in fsdir
     * 
     * @param out
     * @throws IOException
     */
    /**
     * used when save image in fsdir
     * 
     * @param out
     * @throws IOException
     */
    void saveToImage(CDataOutputStream out) throws IOException {
        saveProtectList(out);
        saveRecoverableList(out);
        saveQuotaList(out);
        saveNameQuotaList(out);
    }

    /**
     * used in load fsimage in fsdir
     * 
     * @param in
     * @throws IOException
     */
    void loadFromImage(CDataInputStream in) throws IOException {
        loadProtectList(in);
        loadRecoverableList(in);
        loadQuotaList(in);
        loadNameQuotaList(in);
    }

    private void loadProtectList(CDataInputStream in) throws IOException {
        for (int sz = in.readVInt(); sz > 0; sz--) {
            String path = StringWritable.readString(in);
            DirProperty prop = propertyMap.get(path);
            if (prop == null) {
                prop = new DirProperty(path);
                propertyMap.put(path, prop);
            }
            prop.setProtected(true);
        }
    }

    private void saveProtectList(CDataOutputStream out) throws IOException {
        if (!propertyMap.isEmpty()) {
            List<String> protectList = new ArrayList<String>();
            for (DirProperty item: propertyMap.values()) {
                if (item.isProtect()) {
                    protectList.add(item.getPath());
                }
            }
            out.writeVInt(protectList.size());
            for (String s: protectList) {
                StringWritable.writeString(out, s);
            }
        } else {
            out.writeVInt(0);
        }

    }

    private void loadRecoverableList(CDataInputStream in) throws IOException {
        for (int sz = in.readVInt(); sz > 0; sz--) {
            String path = StringWritable.readString(in);
            DirProperty prop = propertyMap.get(path);
            if (prop == null) {
                prop = new DirProperty(path);
                propertyMap.put(path, prop);
            }
            prop.setRecoverable(true);
        }
    }

    private void saveRecoverableList(CDataOutputStream out) throws IOException {
        if (!propertyMap.isEmpty()) {
            List<String> recoverableList = new ArrayList<String>();
            for (DirProperty item: propertyMap.values()) {
                if (item.isRecoverable()) {
                    recoverableList.add(item.getPath());
                }
            }
            out.writeVInt(recoverableList.size());
            for (String s: recoverableList) {
                StringWritable.writeString(out, s);
            }
        } else {
            out.writeVInt(0);
        }
    }

    private void loadQuotaList(CDataInputStream in) throws IOException {
        for (int sz = in.readVInt(); sz > 0; sz--) {
            String path = StringWritable.readString(in);
            DirProperty prop = propertyMap.get(path);
            if (prop == null) {
                prop = new DirProperty(path);
                propertyMap.put(path, prop);
            }
            long quota = in.readLong();
            prop.setSpaceQuota(quota);
        }
    }

    private void saveQuotaList(CDataOutputStream out) throws IOException {
        if (!propertyMap.isEmpty()) {
            List<Pair<String, Long>> quotaList = new ArrayList<Pair<String, Long>>(
                    propertyMap.size());
            for (DirProperty item: propertyMap.values()) {
                if (item.getSpaceQuota() > 0) {
                    quotaList.add(new Pair<String, Long>(item.getPath(),
                            item.getSpaceQuota()));
                }
            }
            out.writeVInt(quotaList.size());
            for (Pair<String, Long> pair: quotaList) {
                StringWritable.writeString(out, pair.getFirst());
                out.writeLong(pair.getSecond());
            }
        } else {
            out.writeVInt(0);
        }
    }

    private void loadNameQuotaList(CDataInputStream in) throws IOException {
        for (int sz = in.readVInt(); sz > 0; sz--) {
            String path = StringWritable.readString(in);
            DirProperty prop = propertyMap.get(path);
            if (prop == null) {
                prop = new DirProperty(path);
                propertyMap.put(path, prop);
            }
            long quota = in.readLong();
            prop.setNameQuota(quota);
        }
    }

    private void saveNameQuotaList(CDataOutputStream out) throws IOException {
        if (!propertyMap.isEmpty()) {
            List<Pair<String, Long>> nameQuotaList = new ArrayList<Pair<String, Long>>(
                    propertyMap.size());
            for (DirProperty item: propertyMap.values()) {
                if (item.getNameQuota() > 0) {
                    nameQuotaList.add(new Pair<String, Long>(item.getPath(),
                            item.getNameQuota()));
                }
            }
            out.writeVInt(nameQuotaList.size());
            for (Pair<String, Long> pair: nameQuotaList) {
                StringWritable.writeString(out, pair.getFirst());
                out.writeLong(pair.getSecond());
            }
        } else {
            out.writeVInt(0);
        }
    }

    void saveToTextFile(PrintWriter writer) throws IOException {
        List<DirProperty> props = new ArrayList<FSDirPropertyManager.DirProperty>(
                propertyMap.values());
        writer.println("SpaceQuota:");
        for (DirProperty prop: props) {
            long quota = prop.spaceQuota;
            if (quota > 0) {
                writer.println("\t" + prop.path + ": " + quota);
            }
        }
        writer.println("NameQuota:");
        for (DirProperty prop: props) {
            long nameQuota = prop.nameQuota;
            if (nameQuota > 0) {
                writer.println("\t" + prop.path + ": " + nameQuota);
            }
        }
        writer.println("Recoverable:");
        for (DirProperty prop: props) {
            if (prop.recoverable) {
                writer.println("\t" + prop.path);
            }
        }
        writer.print("Protected:");
        for (DirProperty prop: props) {
            if (prop.protect) {
                writer.println();
                writer.print("\t" + prop.path);
            }
        }
    }
}
