/**
 * @(#)DfsUtils.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.client.DistributedFileSystem;
import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.DFSConfig;
import odis.io.ConnectionPool;
import odis.io.InterruptibleSocket;
import odis.io.ReadWriteUtils;
import odis.io.TimeoutPolicy;
import odis.util.ThreadLocalRandomData;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import toolbox.text.util.Digits;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class DfsUtils {
    private static Logger LOG = LogFormatter.getLogger(DfsUtils.class);

    public static void setupFileLogger(File logDir, String serviceType,
            Configuration conf) throws IOException {
        if (!logDir.exists()) {
            if (!logDir.mkdirs()) {
                throw new IOException("Create log dir " + logDir + " failed");
            }
        }
        String hostname = InetAddressUtils.getShortHostName();
        LogFormatter.clearLoggerHandlers("");
        LogFormatter.setRotateFileLogger("", logDir.getAbsolutePath(),
                serviceType + "-" + hostname + ".log", conf.getInt(
                        DFSConfig.LOG_FILE_LIMIT,
                        DFSConfig.DEFAULT_LOG_FILE_LIMIT), conf.getInt(
                        DFSConfig.LOG_FILE_COUNT,
                        DFSConfig.DEFAULT_LOG_FILE_COUNT), conf.getBoolean(
                        DFSConfig.LOG_APPEND, DFSConfig.DEFAULT_LOG_APPEND));
        LogFormatter.setLogLevel(conf.getProperties(DFSConfig.LOG_LEVEL),
                Level.INFO);
    }

    public static <T> T createFromConf(String className, Configuration conf,
            Class<T> protocol) {
        try {
            Constructor<? extends T> c = Class.forName(className).asSubclass(
                    protocol).getDeclaredConstructor(Configuration.class);
            c.setAccessible(true);
            return c.newInstance(conf);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    public static void writeChecksum(File checksumFile, int checksum)
            throws IOException {
        FileOutputStream checksumRawOut = null;
        PrintStream checksumOut = null;
        try {
            checksumRawOut = new FileOutputStream(checksumFile);
            checksumOut = new PrintStream(checksumRawOut);
            checksumOut.println(HexString.intToPaddedHex(checksum));
            if (checksumOut.checkError()) {
                throw new IOException("Write checksum to "
                        + HexString.intToPaddedHex(checksum) + " to "
                        + checksumFile.getAbsolutePath() + " failed");
            }
            checksumRawOut.getFD().sync();
        } finally {
            ReadWriteUtils.safeClose(checksumOut);
            ReadWriteUtils.safeClose(checksumRawOut);
        }
    }

    public static int readChecksum(File checksumFile) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(checksumFile));
        try {
            String line = br.readLine();
            return HexString.paddedHexToInt(line);
        } finally {
            ReadWriteUtils.safeClose(br);
        }
    }

    private static final int[] POWERS = {
        1, 2, 4, 8, 16, 32, 64, 128, 256
    };

    public static long getExpWaitTime(int retry) {
        int salt = ThreadLocalRandomData.current().nextInt(100);
        if (retry < POWERS.length) {
            return 50 * POWERS[retry] + salt;
        } else {
            return 50 * POWERS[POWERS.length - 1] + salt;
        }
    }

    public static void waitExpTime(int retry) {
        waitExpTime(retry, Integer.MAX_VALUE);
    }

    public static void waitExpTime(int retry, long maxWaitTime) {
        long waitTime = Math.min(getExpWaitTime(retry), maxWaitTime);
        try {
            Thread.sleep(waitTime);
        } catch (InterruptedException e) {}
    }

    public static File blockId2File(File rootDir, long blockId, String suffix) {
        char[] prefix = new char[2];
        prefix[0] = Digits.charDigit((int) (blockId >>> 60));
        prefix[1] = Digits.charDigit((int) (blockId >>> 56) & 0xF);
        File prefixDir = new File(rootDir, new String(prefix));
        return new File(prefixDir, HexString.longToPaddedHex(blockId) + suffix);
    }

    private static long valueOf(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        } else {
            return c - 'a' + 10;
        }
    }

    public static long blockFile2BlockId(File blockFile) {
        String name = blockFile.getName();
        long blockId = 0L;
        for (int i = 0; i < 16; i++) {
            int shift = 60 - i * 4;
            blockId |= valueOf(name.charAt(i)) << shift;
        }
        return blockId;
    }

    public static InterruptibleSocket createConnection(String dataNode,
            long timeout, TimeoutPolicy timeoutPolicy) throws IOException {
        InetSocketAddress addr = BlockLocationWithDataPath.getSocketAddressFromLocation(dataNode);
        InterruptibleSocket conn = new InterruptibleSocket(addr, timeout);
        conn.setTimeoutPolicy(timeoutPolicy);
        boolean succ = false;
        try {
            conn.setTcpNoDelay(true);
            succ = true;
        } finally {
            if (!succ) {
                ReadWriteUtils.safeClose(conn);
            }
        }
        return conn;
    }

    public static InterruptibleSocket getConnection(
            ConnectionPool<InterruptibleSocket> connPool, String dataNode,
            long timeout, TimeoutPolicy timeoutPolicy) throws IOException {
        InterruptibleSocket conn = connPool.getConnection(dataNode);
        if (conn != null) {
            conn.setTimeout(timeout);
            conn.setTimeoutPolicy(timeoutPolicy);
        } else {
            conn = createConnection(dataNode, timeout, timeoutPolicy);
        }
        return conn;
    }

    public static <T> void swap(T[] arr, int i, int j) {
        T o = arr[i];
        arr[i] = arr[j];
        arr[j] = o;
    }

    private static void addComponent(List<String> components, StringBuilder sb) {
        int j = sb.length() - 1;
        for (; j >= 0; j--) {
            if (sb.charAt(j) != ' ') {
                break;
            }
        }
        if (j >= 0) {
            String component = sb.substring(0, j + 1);
            if (component.equals("..")) {
                if (!components.isEmpty()) {
                    components.remove(components.size() - 1);
                }
            } else if (!component.equals(".")) {
                components.add(component);
            }

        }
        sb.setLength(0);
    }

    public static String canonicalize(String path) {
        StringBuilder sb = new StringBuilder();
        List<String> components = new ArrayList<String>();
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == DistributedFileSystem.FILE_SEPARATOR_CHAR) {
                addComponent(components, sb);
            } else {
                if (c == ' ' && sb.length() == 0) {
                    continue;
                }
                sb.append(c);
            }
        }
        addComponent(components, sb);
        if (components.isEmpty()) {
            return DistributedFileSystem.FILE_SEPARATOR;
        } else {
            for (String component: components) {
                sb.append(DistributedFileSystem.FILE_SEPARATOR_CHAR).append(
                        component);
            }
            return sb.toString();
        }
    }

    // should be canonicalized and normalized before called
    public static String getParent(String path, char separatorChar,
            String separator) {
        if (path.length() == 1) {
            return null;
        }
        int lastSeparator = path.lastIndexOf(separatorChar);
        return lastSeparator == 0 ? separator
                : path.substring(0, lastSeparator);
    }

    public static String getName(String path, char separatorChar,
            String separator) {
        if (path.length() == 1) {
            return separator;
        }
        return path.substring(path.lastIndexOf(separatorChar) + 1);
    }

    public static String[] parseCmd(String cmd) {
        cmd = cmd.trim();
        boolean quoted = false;
        List<String> args = new ArrayList<String>();
        StringBuilder token = new StringBuilder();
        for (int i = 0; i < cmd.length();) {
            char c = cmd.charAt(i);
            switch (c) {
                case '\\':
                    i++;
                    if (i < cmd.length()) {
                        token.append(cmd.charAt(i));
                    }
                    i++;
                    break;
                case '"':
                    quoted = !quoted;
                    i++;
                    break;
                case ' ':
                case '\t':
                    if (quoted) {
                        token.append(c);
                        i++;
                    } else {
                        args.add(token.toString());
                        token.setLength(0);
                        i++;
                        // skip remaining space if any
                        while (i < cmd.length()) {
                            char space = cmd.charAt(i);
                            if (space != ' ' && space != '\t') {
                                break;
                            }
                            i++;
                        }
                    }
                    break;
                default:
                    token.append(c);
                    i++;
            }
        }
        if (quoted) {
            throw new IllegalArgumentException("unterminated double quote: "
                    + cmd);
        }
        if (token.length() > 0) {
            args.add(token.toString());
        }
        return args.toArray(new String[0]);
    }

    public static String getZkAddr(Configuration conf) {
        String[] addrs = conf.getStringArray(DFSConfig.ZOOKEEPER_ADDR);
        StringBuilder sb = new StringBuilder(addrs[0]);
        for (int i = 1; i < addrs.length; i++) {
            sb.append(',').append(addrs[i]);
        }
        return sb.toString();
    }

    public static String getStrackTrace(Throwable e) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        StackTraceElement[] elems = e.getStackTrace();
        for (StackTraceElement elem: elems) {
            sb.append(elem.toString()).append("\n");
        }
        return sb.toString();
    }

    public static <T> String toString(T[] arr, int off, int len) {
        int iMax = off + len - 1;
        if (iMax < off) {
            return "[]";
        }
        StringBuilder b = new StringBuilder();
        b.append('[');
        for (int i = off;; i++) {
            b.append(arr[i]);
            if (i == iMax) {
                return b.append(']').toString();
            }
            b.append(", ");
        }
    }

    private static final int UNIT_CONNECT_TIMEOUT = 2 * 60 * 1000;

    private static int readTimeout = DFSConfig.conf().getInt(
            DFSConfig.DFS_QJOURNAL_READ_TIMEOUT_KEY,
            DFSConfig.DFS_QJOURNAL_READ_TIMEOUT_DEFAULT);;

    private static int connectionTimeout = DFSConfig.conf().getInt(
            DFSConfig.DFS_QJOURNAL_DOWNLOAD_FILE_TIMEOUT_KEY,
            DFSConfig.DFS_QJOURNAL_DOWNLOAD_FILE_TIMEOUT_DEFAULT);

    public static InputStream buildInputStreamFromURL(URL url)
            throws IOException {
        boolean connectSucceeded = false;

        try {
            URLConnection connection = url.openConnection();

            connection.setReadTimeout(readTimeout);
            DfsUtils.connect(connection, connectionTimeout);
            connectSucceeded = true;
            return connection.getInputStream();
        } finally {
            if (!connectSucceeded) {
                return null;
            }
        }
    }

    /**
     * The connection establishment is attempted multiple times and is given up
     * only on the last failure. Instead of connecting with a timeout of X, we
     * try connecting with a timeout of x < X but multiple times.
     */
    public static void connect(URLConnection connection, int connectionTimeout)
            throws IOException {
        int unit = 0;
        if (connectionTimeout < 0) {
            throw new IOException("Invalid timeout " + "[timeout = "
                    + connectionTimeout + " ms]");
        } else if (connectionTimeout > 0) {
            unit = Math.min(UNIT_CONNECT_TIMEOUT, connectionTimeout);
        }
        // set the connect timeout to the unit-connect-timeout
        connection.setConnectTimeout(unit);
        while (true) {
            try {
                connection.connect();
                break;
            } catch (IOException ioe) {
                // update the total remaining connect-timeout
                connectionTimeout -= unit;

                // throw an exception if we have waited for timeout amount of
                // time
                // note that the updated value if timeout is used here
                if (connectionTimeout == 0) {
                    throw ioe;
                }

                // reset the connect timeout for the last try
                if (connectionTimeout < unit) {
                    unit = connectionTimeout;
                    // reset the connect time out for the final connect
                    connection.setConnectTimeout(unit);
                }
            }
        }
    }

    /**
     * Find a free port that cound be bind start from the <code>fromPort</code>.
     * 
     * @param fromPort
     * @param step
     * @return free port
     */
    public static int probeFreePort(int fromPort, int step) {
        int port = fromPort;
        while (true) {
            ServerSocket ss = null;
            try {
                ss = new ServerSocket(port);
                ss.setReuseAddress(true);
                return port;
            } catch (IOException e) {
                LOG.log(Level.INFO, "try to bind to port " + port
                        + " failed, try next", e);
            } finally {
                ReadWriteUtils.safeCloseServerSocket(ss);
            }
            port += step;
        }
    }

    public static void main(String[] args) {
        System.out.println(HexString.intToPaddedHex(-1609895445));
    }
}
