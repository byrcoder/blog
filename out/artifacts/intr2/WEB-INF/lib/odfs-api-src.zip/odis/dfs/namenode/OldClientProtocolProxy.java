/**
 * @(#)OldClientProtocolProxy.java, 2013-2-17. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.IOException;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSException;
import odis.dfs.common.IClientProtocolV2;
import odis.io.LockStateException;
import odis.io.NamedPermitException;
import odis.io.permission.FsPermission;
import odis.rpc2.ClientInfo;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;

/**
 * @author zhangduo
 */
@SuppressWarnings("deprecation")
public class OldClientProtocolProxy implements IClientProtocolV2 {

    private final PrimaryNameNode nameNode;

    public OldClientProtocolProxy(PrimaryNameNode nameNode) {
        this.nameNode = nameNode;
    }

    private String getClientRPCName() {
        ClientInfo info = RPC.getClientInfo();
        if (info == null) {
            return null;
        }
        return info.clientName;
    }

    @Override
    public String getLocalName() throws RpcException {
        return nameNode.host + ":" + nameNode.port;
    }

    @Override
    public String getCUID() throws RpcException {
        return nameNode.getCUID(getClientRPCName());
    }

    @Override
    public void setReady(boolean ready) throws RpcException, FSException {
        nameNode.setReady(getClientRPCName());
    }

    @Override
    public long[] getStats() throws RpcException {
        return new long[2];
    }

    @Override
    public long[] getBlockSummary() throws RpcException, FSException {
        return new long[2];
    }

    @Override
    public String consistencyCheck() throws RpcException, FSException,
            IOException {
        return nameNode.consistencyCheck(getClientRPCName());
    }

    @Override
    @Deprecated
    public void checkAndRecoverInconsistentBlock(long block)
            throws RpcException, FSException {
        nameNode.verifyBlock(getClientRPCName(), block);
    }

    @Override
    public BlockVerifyResult verifyBlock(long block) throws RpcException,
            FSException {
        return nameNode.verifyBlock(getClientRPCName(), block);
    }

    @Override
    public void computeContentsLengthAndSubItemNum() throws RpcException,
            FSException {
        nameNode.computeContentsLengthAndSubItemNum(getClientRPCName());
    }

    @Override
    public BlockLocationWithDataPath create(String file, boolean overwrite,
            boolean persistent, boolean createParent, int replication,
            int blockSize, FsPermission permission) throws RpcException,
            FSException, IOException {
        return nameNode.create(getClientRPCName(), file, overwrite,
                createParent, replication, blockSize, permission);
    }

    @Override
    public void abandonBlock(long b, String file, int blockIndex)
            throws RpcException, FSException {
        try {
            nameNode.abandonBlock(getClientRPCName(), file, blockIndex);
        } catch (FSException e) {
            throw e;
        } catch (IOException e) {
            throw new FSException(FSException.UNKNOWN, "", e);
        }
    }

    @Override
    public BlockLocationWithDataPath addBlock(String file, int blockIndex)
            throws RpcException, FSException, IOException {
        return nameNode.addBlock(getClientRPCName(), file, blockIndex);
    }

    @Override
    public void abandonFileInProgress(String file) throws RpcException,
            FSException, IOException {
        nameNode.abandonFileInProgress(getClientRPCName(), file);
    }

    @Override
    public boolean complete(String file) throws RpcException, FSException,
            IOException {
        return nameNode.complete(getClientRPCName(), file);
    }

    @Override
    public void renewLease(int protocol) throws RpcException, FSException {
        nameNode.renewLease(getClientRPCName());
    }

    @Override
    public void removeLease() throws RpcException, FSException {
        nameNode.removeLease(getClientRPCName());
    }

    @Override
    public long getLeasePeriod() throws RpcException {
        try {
            return nameNode.getLeasePeriod(getClientRPCName());
        } catch (FSException e) {
            throw new RpcException(e);
        }
    }

    @Override
    public boolean isPending(String src) throws RpcException, FSException {
        return nameNode.isPending(getClientRPCName(), src);
    }

    @Override
    public String[] pendingFilesInDir(String path) throws RpcException,
            FSException {
        return nameNode.pendingFilesInDir(getClientRPCName(), path);
    }

    @Override
    public boolean exists(String path) throws RpcException, FSException {
        return nameNode.exists(getClientRPCName(), path);
    }

    @Override
    public BlockSizeLocationWithDataPath[] open(String file)
            throws RpcException, FSException {
        return nameNode.getFileBlockLocations(getClientRPCName(), file);
    }

    @Override
    public void closeFile(String file) throws RpcException, FSException {}

    @Override
    public boolean rename(String src, String dst) throws RpcException,
            FSException, IOException {
        RPC.getAsyncRpcCallEntry().setReturnValue(true);
        nameNode.rename(getClientRPCName(), src, dst, true);
        return true;
    }

    @Override
    public boolean link(String src, String dst, boolean symbolic)
            throws RpcException, FSException, IOException {
        RPC.getAsyncRpcCallEntry().setReturnValue(true);
        nameNode.snapshot(getClientRPCName(), src, dst);
        return true;
    }

    @Override
    public boolean delete(String path, boolean recursive, boolean permanently)
            throws RpcException, FSException, IOException {
        return nameNode.delete(getClientRPCName(), path, recursive, permanently);
    }

    @Override
    public boolean recoverTrash(String trash, String dst) throws RpcException,
            FSException, IOException {
        RPC.getAsyncRpcCallEntry().setReturnValue(true);
        nameNode.recoverTrash(getClientRPCName(), trash, dst);
        return true;
    }

    @Override
    public boolean deleteTrash(String path) throws RpcException, FSException,
            IOException {
        return nameNode.deleteTrash(getClientRPCName(), path);
    }

    @Override
    public boolean isDir(String path) throws RpcException, FSException {
        DFSFileStatus status = getFileStatus(path);
        return status != null && status.isDir();
    }

    @Override
    public boolean mkdirs(String dir, int replications, FsPermission permission)
            throws RpcException, FSException, IOException {
        RPC.getAsyncRpcCallEntry().setReturnValue(true);
        nameNode.mkdirs(getClientRPCName(), dir, replications, permission);
        return true;
    }

    @Override
    public BlockSizeLocationWithDataPath[] getFileBlockLocations(String file)
            throws RpcException, FSException {
        return nameNode.getFileBlockLocations(getClientRPCName(), file);
    }

    @Override
    public DFSFileStatus getFileStatus(String file) throws RpcException,
            FSException {
        return nameNode.getFileStatus(getClientRPCName(), file);
    }

    @Override
    public DFSFileStatus[] getListing(String dir) throws RpcException,
            FSException {
        return nameNode.getListing(getClientRPCName(), dir);
    }

    @Override
    public int getReplicationNumber(String path) throws RpcException,
            FSException {
        return nameNode.getReplicationNumber(getClientRPCName(), path);
    }

    @Override
    public void setReplicationNumber(String path, int replication,
            boolean recursive) throws RpcException, FSException, IOException {
        nameNode.setReplicationNumber(getClientRPCName(), path, replication,
                recursive);
    }

    @Override
    public void setOwner(String path, boolean recursive, String owner,
            String group) throws IOException {
        nameNode.setOwner(getClientRPCName(), path, recursive, owner, group);
    }

    @Override
    public void setPermission(String path, boolean recursive,
            FsPermission permission) throws IOException {
        nameNode.setPermission(getClientRPCName(), path, recursive, permission);
    }

    @Override
    public String[][] getHints(String file, long start, long len)
            throws RpcException, FSException, IOException {
        // TODO: not implemented yet
        return null;
    }

    @Override
    public void setProtect(String path, boolean protect) throws RpcException,
            FSException, IOException {
        nameNode.setProtect(getClientRPCName(), path, protect);
    }

    @Override
    public boolean isProtected(String path) throws RpcException {
        try {
            return nameNode.isProtect(getClientRPCName(), path);
        } catch (FSException e) {
            throw new RpcException(e);
        }
    }

    @Override
    public void setRecoverable(String path, boolean recoverable)
            throws RpcException, FSException, IOException {
        nameNode.setRecoverable(getClientRPCName(), path, recoverable);
    }

    @Override
    public boolean isRecoverable(String path) throws RpcException {
        try {
            return nameNode.isRecoverable(getClientRPCName(), path);
        } catch (FSException e) {
            throw new RpcException(e);
        }
    }

    @Override
    public boolean setQuota(String path, long newQuotaValue, boolean isNameQuota)
            throws RpcException, FSException, IOException {
        if (isNameQuota) {
            nameNode.setNameQuota(getClientRPCName(), path, newQuotaValue);
        } else {
            nameNode.setSpaceQuota(getClientRPCName(), path, newQuotaValue);
        }
        return true;
    }

    @Override
    public long getQuota(String path, boolean isNameQuota) throws RpcException,
            FSException {
        if (isNameQuota) {
            return nameNode.getNameQuota(getClientRPCName(), path);
        } else {
            return nameNode.getSpaceQuota(getClientRPCName(), path);
        }
    }

    @Override
    public String dumpDirProperties() throws RpcException, IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void addGroupUser(String group, String user) throws RpcException,
            FSException, IOException {
        nameNode.addGroupUser(getClientRPCName(), group, user);
    }

    @Override
    public void removeGroupUser(String group, String user) throws RpcException,
            FSException, IOException {
        nameNode.removeGroupUser(getClientRPCName(), group, user);
    }

    @Override
    public void removeGroup(String group) throws RpcException, FSException,
            IOException {
        nameNode.removeGroup(getClientRPCName(), group);
    }

    @Override
    public String printGroups() throws RpcException {
        try {
            return nameNode.printGroups(getClientRPCName());
        } catch (FSException e) {
            throw new RpcException(e);
        }
    }

    @Override
    public int obtainLock(String src, int lock) throws RpcException,
            IOException {
        return nameNode.obtainLock(getClientRPCName(), src, lock);
    }

    @Override
    public String lockState(String src) throws RpcException, IOException {
        return nameNode.lockState(getClientRPCName(), src);
    }

    @Override
    public int promote(String src) throws LockStateException, RpcException,
            IOException {
        return nameNode.promote(getClientRPCName(), src);
    }

    @Override
    public void downgrade(String src) throws RpcException, IOException,
            LockStateException {
        nameNode.downgrade(getClientRPCName(), src);
    }

    @Override
    public void releaseLock(String src) throws RpcException, IOException {
        nameNode.releaseLock(getClientRPCName(), src);
    }

    @Override
    public void createPermit(String name, int p, boolean detached)
            throws NamedPermitException, RpcException, IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void removePermit(String name) throws NamedPermitException,
            RpcException, IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean acquirePermit(String name, int request)
            throws NamedPermitException, RpcException, IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void releasePermit(String name, int p) throws RpcException,
            IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void releasePermit(String name) throws RpcException, IOException {
        throw new UnsupportedOperationException();
    }

}
