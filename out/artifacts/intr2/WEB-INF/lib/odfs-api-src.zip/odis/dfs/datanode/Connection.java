/**
 * @(#)Connection.java, 2012-12-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.dfs.common.DataNodeRequest;
import odis.dfs.common.DataNodeRequest.Op;
import odis.dfs.common.DataNodeRequest.ReadBlockBody;
import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.common.DataNodeRequest.TransferBlockBody;
import odis.dfs.common.DataNodeRequest.WriteBlockBody;
import odis.dfs.common.FSConstants;
import odis.io.DirectByteBufferPool;
import odis.io.ReadWriteUtils;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class Connection implements Closeable {

    private static final Logger LOG = LogFormatter.getLogger(Connection.class);

    private static final UnexpectedEOFException EOF = new UnexpectedEOFException();

    private static final RequestTooLargeException RTL = new RequestTooLargeException();

    private static final UnsupportedProtocolVersionException UPV = new UnsupportedProtocolVersionException();

    static final int WRITE_MAX_SPINS = 16;

    final long initTime = System.currentTimeMillis();

    final DataNode dataNode;

    private final DataXceiveWorker worker;

    final SocketChannel socket;

    int interestOps = SelectionKey.OP_READ;

    final DirectByteBufferPool directByteBufferPool;

    Connection(SocketChannel socket, DataXceiveWorker worker,
            DataNode dataNode, DirectByteBufferPool directByteBufferPool) {
        this.socket = socket;
        this.worker = worker;
        this.dataNode = dataNode;
        this.directByteBufferPool = directByteBufferPool;
        dataNode.conns.put(this, this);
    }

    private ByteBuffer bb;

    private void prepareByteBuffer() {
        if (bb == null) {
            bb = directByteBufferPool.allocate();
        }
    }

    private boolean readFully() throws IOException {
        while (bb.hasRemaining()) {
            int read = socket.read(bb);
            if (read == -1) {
                throw EOF;
            } else if (read == 0) {
                return false;
            }
        }
        return true;
    }

    private boolean readAndVerifyVersion() throws IOException {
        if (bb.position() == 0) {
            bb.limit(1);
            if (!readFully()) {
                return false;
            }
        }
        int version = bb.get(0) & 0xFF;
        if (version != DataNodeRequest.VERSION) {
            LOG.warning("Got pre-4.0 client request from "
                    + socket.socket().getRemoteSocketAddress());
            throw UPV;
        }
        return true;
    }

    private Op readOpType() throws IOException {
        if (bb.position() == 1) {
            bb.limit(2);
            if (!readFully()) {
                return null;
            }
        }
        Op op = Op.valueOf(bb.get(1) & 0xFF);
        if (op == null) {
            throw UPV;
        }
        return op;
    }

    /**
     * version(1) + op(1) + block(8) + offset(4) + maxLength(4)
     */
    private static final int READ_REQUEST_SIZE = 18;

    private DataNodeRequest readReadRequest() throws IOException {
        if (bb.position() < READ_REQUEST_SIZE) {
            bb.limit(READ_REQUEST_SIZE);
            if (!readFully()) {
                return null;
            }
        }
        DataNodeRequest req = new DataNodeRequest(Op.READ_BLOCK);
        ReadBlockBody body = (ReadBlockBody) req.getBody();
        body.setBlock(bb.getLong(2));
        body.setOffset(bb.getInt(10));
        body.setMaxLength(bb.getInt(14));
        return req;
    }

    private String[] readTargets(int off, int numTargets) throws IOException {
        String[] targets = new String[numTargets];
        for (int i = 0; i < numTargets; i++) {
            // read length
            int length = 0;
            int shift = 0;
            for (;;) {
                if (bb.position() <= off) {
                    if (off + 1 > bb.capacity()) {
                        throw RTL;
                    }
                    bb.limit(off + 1);
                    if (!readFully()) {
                        return null;
                    }
                }
                int b = bb.get(off++) & 0xFF;
                length |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) {
                    break;
                }
                shift += 7;
            }
            int end = off + length;
            if (end > bb.capacity()) {
                throw RTL;
            }
            if (bb.position() < end) {
                bb.limit(end);
                if (!readFully()) {
                    return null;
                }
            }
            StringBuilder sb = new StringBuilder();
            while (off < end) {
                byte b = bb.get(off++);
                if ((b & 0x80) == 0) {
                    sb.append((char) (b & 0x7F));
                } else if ((b & 0xE0) != 0xE0) {
                    sb.append((char) (((b & 0x1F) << 6) | (bb.get(off++) & 0x3F)));
                } else {
                    sb.append((char) (((b & 0x0F) << 12)
                            | ((bb.get(off++) & 0x3F) << 6) | (bb.get(off++) & 0x3F)));
                }
            }
            targets[i] = sb.toString();
        }
        return targets;
    }

    /**
     * version(1) + op(1) + reportCond(1) + block(8) + numTargets(4)
     */
    private static final int WRITE_REQUEST_HEADER_SIZE = 15;

    private DataNodeRequest readWriteRequest() throws IOException {
        if (bb.position() < WRITE_REQUEST_HEADER_SIZE) {
            bb.limit(WRITE_REQUEST_HEADER_SIZE);
            if (!readFully()) {
                return null;
            }
        }
        int numTargets = bb.getInt(11);
        if (numTargets > FSConstants.MAX_BLOCK_TARGET_NUM) {
            throw UPV;
        }
        String[] targets = readTargets(WRITE_REQUEST_HEADER_SIZE, numTargets);
        if (targets == null) {
            return null;
        }
        DataNodeRequest req = new DataNodeRequest(Op.WRITE_BLOCK);
        WriteBlockBody body = (WriteBlockBody) req.getBody();
        ReportCond reportCond = ReportCond.valueOf(bb.get(2) & 0xFF);
        if (reportCond == null) {
            throw UPV;
        }
        body.setReportCond(reportCond);
        body.setBlock(bb.getLong(3));
        body.setTargets(targets);
        return req;
    }

    /**
     * version(1) + op(1) + srcBlock(8) + destBlock(8) + numTargets(4)
     */
    private static final int TRANSFER_REQUEST_HEADER_SIZE = 22;

    private DataNodeRequest readTransferRequest() throws IOException {
        if (bb.position() < TRANSFER_REQUEST_HEADER_SIZE) {
            bb.limit(TRANSFER_REQUEST_HEADER_SIZE);
            if (!readFully()) {
                return null;
            }
        }
        int numTargets = bb.getInt(18);
        if (numTargets > FSConstants.MAX_BLOCK_TARGET_NUM) {
            throw UPV;
        }
        String[] targets = readTargets(TRANSFER_REQUEST_HEADER_SIZE, numTargets);
        if (targets == null) {
            return null;
        }
        DataNodeRequest req = new DataNodeRequest(Op.TRANSFER_BLOCK);
        TransferBlockBody body = (TransferBlockBody) req.getBody();

        body.setSrcBlock(bb.getLong(2));
        body.setDestBlock(bb.getLong(10));
        body.setTargets(targets);
        return req;
    }

    private DataNodeRequest readRequest() throws IOException {
        prepareByteBuffer();
        if (!readAndVerifyVersion()) {
            return null;
        }
        Op op = readOpType();
        if (op == null) {
            return null;
        }
        switch (op) {
            case WRITE_BLOCK:
                return readWriteRequest();
            case READ_BLOCK:
                return readReadRequest();
            case TRANSFER_BLOCK:
                return readTransferRequest();
            default:
                throw UPV;
        }
    }

    void onRead() throws IOException {
        DataNodeRequest req = readRequest();
        if (req == null) {
            return;
        }
        switch (req.getOp()) {
            case READ_BLOCK: {
                ReadBlockBody body = (ReadBlockBody) req.getBody();
                if (body.getMaxLength() > 0) {
                    // Do not log here to avoid log being flooded.
                    Pair<File, Integer> pair = dataNode.dataSet.getBlockFile(
                            body.getBlock(), body.getOffset());
                    dataNode.executeTask(new RandomReadBlockTask(this,
                            pair.getFirst(), body.getOffset(), Math.min(
                                    pair.getSecond(), body.getMaxLength()), bb));
                } else {
                    LOG.info("Got " + req + " from " + remoteAddr() + " after "
                            + (System.currentTimeMillis() - initTime) + "ms");
                    dataNode.executeTask(new SequentialReadBlockTask(this,
                            body.getBlock(), body.getOffset(), bb));
                }
                break;
            }
            case WRITE_BLOCK: {
                LOG.info("Got " + req + " from " + remoteAddr() + " after "
                        + (System.currentTimeMillis() - initTime) + "ms");
                DataNodeRequest.WriteBlockBody body = (DataNodeRequest.WriteBlockBody) req.getBody();
                String[] targets = body.getTargets();
                String curTarget = targets[0];
                if (!dataNode.fullName.equals(curTarget)) {
                    throw new IOException(
                            "I am not the right target! curTarget: "
                                    + curTarget + ", I am " + dataNode.fullName);
                }
                interestOps = 0;
                worker.cancelWithoutCleanUpDirectly(this);
                dataNode.conns.remove(this);
                socket.configureBlocking(true);
                WriteBlockTask task = new WriteBlockTask(dataNode, socket,
                        body.getBlock(), Arrays.copyOfRange(targets, 1,
                                targets.length), body.getReportCond(),
                        directByteBufferPool, bb, initTime);
                if (dataNode.writingBlocks.putIfAbsent(body.getBlock(), task) == null) {
                    boolean reject = true;
                    try {
                        dataNode.executeTask(task);
                        reject = false;
                    } finally {
                        if (reject) {
                            dataNode.writingBlocks.remove(body.getBlock());
                        }
                    }
                } else {
                    throw new IOException("Block " + body.getBlock()
                            + " is already being written");
                }
                break;
            }
            case TRANSFER_BLOCK: {
                LOG.info("Got " + req + " from " + remoteAddr() + " after "
                        + (System.currentTimeMillis() - initTime) + "ms");
                TransferBlockBody body = (TransferBlockBody) req.getBody();
                dataNode.executeTask(new TransferBlockTask(this,
                        body.getSrcBlock(), body.getDestBlock(),
                        body.getTargets(), bb));
                break;
            }
            default:
                throw UPV;
        }
        bb = null;
    }

    interface ICallback {
        void operationSucceeded();

        void operationFailed();
    }

    private Pair<ByteBuffer, ICallback> writeRequest;

    void asyncWrite(ByteBuffer buffer, ICallback callback) {
        synchronized (this) {
            if (closed) {
                return;
            }
            writeRequest = new Pair<ByteBuffer, Connection.ICallback>(buffer,
                    callback);
            interestOps |= SelectionKey.OP_WRITE;
            worker.register(this);
        }
    }

    void onWrite() throws IOException {
        synchronized (this) {
            ByteBuffer buffer = writeRequest.getFirst();
            if (buffer != null) {
                for (int i = 0; i < WRITE_MAX_SPINS && buffer.hasRemaining(); i++) {
                    socket.write(buffer);
                }
            }
            if (buffer == null || !buffer.hasRemaining()) {
                interestOps &= ~SelectionKey.OP_WRITE;
                worker.register(this);
                ICallback callback = writeRequest.getSecond();
                writeRequest = null;
                if (callback != null) {
                    callback.operationSucceeded();
                }
            }
        }

    }

    private boolean closed = false;

    void cleanUp() {
        synchronized (this) {
            if (closed) {
                return;
            }
            closed = true;
            ReadWriteUtils.safeClose(socket);
            if (writeRequest != null) {
                ICallback callback = writeRequest.getSecond();
                if (callback != null) {
                    callback.operationFailed();
                }
            }
            dataNode.conns.remove(this);
        }
        if (bb != null) {
            directByteBufferPool.release(bb);
            bb = null;
        }
    }

    SocketAddress remoteAddr() {
        return socket.socket().getRemoteSocketAddress();
    }

    @Override
    public String toString() {
        return socket.toString();
    }

    @Override
    public void close() {
        worker.cancel(this);
    }

}
