/**
 * @(#)DFSClientConfig.java, 2012-2-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.ConfigUtils;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;

import toolbox.misc.LogFormatter;

/**
 * the configuration for the odfs client
 * 
 * @author guodd
 */
public final class DFSClientConfig extends CompositeConfiguration {
    private static final Logger LOG = LogFormatter.getLogger(DFSClientConfig.class);

    private static File home;

    static {
        String home = System.getProperty("odis.home");
        if (home == null) {
            home = System.getenv("ODIS_HOME");
        }
        if (home == null) {
            home = ".";
        }
        DFSClientConfig.home = new File(home);
        System.setProperty("odis.home", DFSClientConfig.home.getAbsolutePath());
    }

    private void dumpProperties() {
        for (Iterator<String> iter = this.getKeys(); iter.hasNext();) {
            String key = iter.next();
            LOG.info(key + "=" + this.getProperty(key));
        }
    }

    public DFSClientConfig() {
        File confDir = new File(home, "conf");
        try {
            File[] files = confDir.listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.endsWith("-client.xml");
                }
            });
            if (files != null && files.length > 0) {
                if (files.length > 1) {
                    throw new RuntimeException(
                            "Expect one *-client.xml, but got " + files.length);
                }
                String[] names = new String[files.length];
                for (int i = 0; i < files.length; i++) {
                    names[i] = files[i].getName().toString();
                }
                this.addConfiguration(ConfigUtils.parseXmlConfig(confDir, names));
                LOG.info("Load configuration from "
                        + files[0].getAbsolutePath());
                dumpProperties();
            }
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "parse odfs client configuration failed", e);
            throw new RuntimeException(
                    "parse odfs client configuration failed", e);
        }
    }

    public DFSClientConfig(String file) {
        File confDir = new File(home, "conf");
        try {
            this.addConfiguration(ConfigUtils.parseXmlConfig(confDir,
                    new String[] {
                        file
                    }));
            LOG.info("Load configuration from "
                    + new File(confDir, file).getAbsolutePath());
            dumpProperties();
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "parse odfs client configuration failed", e);
            throw new RuntimeException(
                    "parse odfs client configuration failed", e);
        }
    }

    public DFSClientConfig(Configuration conf) {
        this.addConfiguration(conf);
        LOG.info("Load configuration from " + conf.getClass().getSimpleName());
        dumpProperties();
    }

    public File getHome() {
        return home;
    }

    public int getDefaultBlockSize() {
        return this.getInt(DEFAULT_BLOCK_SIZE, DEFAULT_BLOCK_SIZE_DEFAULT_VALUE);
    }

    public int getDefaultCreatePermission() {
        return this.getInt(DEFAULT_CREATE_PERMISSION,
                DEFAULT_CREATE_PERMISSION_DEFAULT_VALUE);
    }

    public long getNamenodeRpcTimeout() {
        return this.getLong(NAMENODE_PRC_TIMEOUT,
                NAMENODE_PRC_TIMEOUT_DEFAULT_VALUE);
    }

    public int getZooKeeperTimeout() {
        return this.getInt(ZOOKEEPER_TIMEOUT, ZOOKEEPER_TIMEOUT_DEFAULT_VALUE);
    }

    public int getRandomAccessPoolCoreSize() {
        return this.getInt(CLIENT_RANDOM_ACCESS_CONNECTION_POOL_CORE_SIZE,
                CLIENT_RANDOM_ACCESS_CONNECTION_POOL_CORE_SIZE_DEFAULT_VALUE);
    }

    public int getRandomAccessPoolMaxSize() {
        return this.getInt(CLIENT_RANDOM_ACCESS_CONNECTION_POOL_MAX_SIZE,
                CLIENT_RANDOM_ACCESS_CONNECTION_POOL_MAX_SIZE_DEFAULT_VALUE);
    }

    public long getRandomAccessConnectionMaxIdleTime() {
        return this.getLong(CLIENT_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME,
                CLIENT_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME_DEFAULT_VALUE);
    }

    public long getDatanodeReadTimeout() {
        return this.getLong(DATANODE_BLOCK_READ_TIMEOUT,
                DATANODE_BLOCK_READ_TIMEOUT_DEFAULT_VALUE);
    }

    public int getOpenMaxRetryTime() {
        return this.getInt(OPEN_DATANODE_MAX_RETRY_TIME,
                OPEN_DATANODE_MAX_RETRY_TIME_DEFAULT_VALUE);
    }

    public int getRecoverBufferSize() {
        return this.getInt(WRITE_BLOCK_RECOVER_BUFFER_SIZE,
                WRITE_BLOCK_RECOVER_BUFFER_SIZE_DEFAULT_VALUE);
    }

    public long getBlockWriteTimeout() {
        return this.getLong(CLIENT_BLOCK_WRITE_TIMEOUT,
                CLIENT_BLOCK_WRITE_TIMEOUT_DEFAULT_VALUE);
    }

    public long getQuorumWriteTimeout() {
        return this.getLong(CLIENT_QUORUM_WRITE_TIMEOUT,
                CLIENT_QUORUM_WRITE_TIMEOUT_DEFAULT_VALUE);
    }

    public long getQuorumCompleteFileRetryTimeout() {
        return this.getLong(CLIENT_QUORUM_COMPLETE_FILE_RETRY_TIMEOUT,
                CLIENT_QUORUM_COMPLETE_FILE_RETRY_TIMEOUT_DEFAULT_VALUE);
    }

    public int getDatanodeBlockflushRetryCount() {
        return this.getInt(DATANODE_FLUSH_MAX_RETRY_COUNT,
                DATANODE_FLUSH_MAX_RETRY_COUNT_DEFAULT_VALUE);
    }

    public int getRecoverBlockMaxRetryCount() {
        return this.getInt(RECOVER_BLOCK_MAX_RETRY_COUNT,
                RECOVER_BLOCK_MAX_RETRY_COUNT_DEFAULT_VALUE);
    }

    public long getCompleteFileRetryTimeout() {
        return this.getLong(COMPLETE_FILE_RETRY_TIMEOUT,
                COMPLETE_FILE_RETRY_TIME_DEFAULT_VALUE);
    }

    public long getCreateBlockWriteRetryTimeout() {
        return this.getLong(DATANODE_CREATE_BLOCK_WRITE_STREAM_RETRY_TIMEOUT,
                DATANODE_CREATE_BLOCK_WRITE_STREAM_RETRY_TIMEOUT_DEFAULT_VALUE);
    }

    public int getSequentialReaderMaxSkip() {
        return this.getInt(SEQUENTIAL_READER_MAX_SKIP,
                SEQUENTIAL_READER_MAX_SKIP_DEFAULT_VALUE);
    }

    public int getRandomReadLengthHint() {
        return this.getInt(RANDOM_READ_LENGTH_HINT,
                RANDOM_READ_LENGTH_HINT_DEFAULT_VALUE);
    }

    public long getBlockCacheDownloadTimeout() {
        return this.getLong(BLOCK_CACHE_DOWNLOADER_READ_TIMEOUT,
                BLOCK_CACHE_DOWNLOADER_READ_TIMEOUT_DEFAULT_VALUE);
    }

    public int getBlockCacheDownloadBufferSize() {
        return this.getInt(BLOCK_CACHE_DOWNLOADER_BUFFER_SIZE,
                BLOCK_CACHE_DOWNLOADER_BUFFER_SIZE_DEFAULT_VALUE);
    }

    public long getBlockCacheGCInterval() {
        return this.getLong(BLOCK_CACHE_GC_INTERVAL,
                BLOCK_CACHE_GC_INTERVAL_DEFAULT_VALUE);
    }

    public long getBlockInputMaxIdleTime() {
        return this.getLong(BLOCK_INPUT_MAX_IDLE_TIME,
                BLOCK_INPUT_MAX_IDLE_TIME_DEFAULT_VALUE);
    }

    public static final String DEFAULT_BLOCK_SIZE = "dfs.client.default-block-size";

    public static final int DEFAULT_BLOCK_SIZE_DEFAULT_VALUE = 64 * 1024 * 1024;

    public static final String DEFAULT_CREATE_PERMISSION = "dfs.client.default-create-permission";

    public static final int DEFAULT_CREATE_PERMISSION_DEFAULT_VALUE = ((7 << 6)
            | (7 << 3) | 7);

    public static final String NAMENODE_PRC_TIMEOUT = "dfs.client.namenode-rpc-timeout";

    public static final long NAMENODE_PRC_TIMEOUT_DEFAULT_VALUE = 0L;

    public static final String ZOOKEEPER_TIMEOUT = "dfs.client.zookeeper-timeout";

    public static final int ZOOKEEPER_TIMEOUT_DEFAULT_VALUE = 30000;

    public static final String CLIENT_RANDOM_ACCESS_CONNECTION_POOL_CORE_SIZE = "dfs.client.random-access-connection-pool-core-size";

    public static final int CLIENT_RANDOM_ACCESS_CONNECTION_POOL_CORE_SIZE_DEFAULT_VALUE = 1;

    public static final String CLIENT_RANDOM_ACCESS_CONNECTION_POOL_MAX_SIZE = "dfs.client.random-access-connection-pool-max-size";

    public static final int CLIENT_RANDOM_ACCESS_CONNECTION_POOL_MAX_SIZE_DEFAULT_VALUE = 1024;

    public static final String CLIENT_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME = "dfs.client.random-access-connection-max-idle-time";

    public static final long CLIENT_RANDOM_ACCESS_CONNECTION_MAX_IDLE_TIME_DEFAULT_VALUE = 60L * 1000;

    public static final String DATANODE_BLOCK_READ_TIMEOUT = "dfs.client.block-read-timeout";

    public static final long DATANODE_BLOCK_READ_TIMEOUT_DEFAULT_VALUE = 10L * 60 * 1000;

    public static final String OPEN_DATANODE_MAX_RETRY_TIME = "dfs.client.max-open-block-retry-times";

    public static final int OPEN_DATANODE_MAX_RETRY_TIME_DEFAULT_VALUE = 10;

    public static final String WRITE_BLOCK_RECOVER_BUFFER_SIZE = "dfs.client.recover-buffer-size";

    public static final int WRITE_BLOCK_RECOVER_BUFFER_SIZE_DEFAULT_VALUE = 16 * 1024;

    public static final String CLIENT_BLOCK_WRITE_TIMEOUT = "dfs.client.block-write-timeout";

    public static final long CLIENT_BLOCK_WRITE_TIMEOUT_DEFAULT_VALUE = 30L * 1000;

    public static final String CLIENT_QUORUM_WRITE_TIMEOUT = "dfs.client.quorum-write-timeout";

    public static final long CLIENT_QUORUM_WRITE_TIMEOUT_DEFAULT_VALUE = 5L * 1000;

    public static final String CLIENT_QUORUM_COMPLETE_FILE_RETRY_TIMEOUT = "dfs.client.quorum-complete-file-retry-timeout";

    public static final long CLIENT_QUORUM_COMPLETE_FILE_RETRY_TIMEOUT_DEFAULT_VALUE = 10L * 1000;

    public static final String DATANODE_FLUSH_MAX_RETRY_COUNT = "dfs.client.datanode-flush-max-retry-count";

    public static final int DATANODE_FLUSH_MAX_RETRY_COUNT_DEFAULT_VALUE = 5;

    public static final String RECOVER_BLOCK_MAX_RETRY_COUNT = "dfs.client.recover-block-max-retry-count";

    public static final int RECOVER_BLOCK_MAX_RETRY_COUNT_DEFAULT_VALUE = 10;

    public static final String COMPLETE_FILE_RETRY_TIMEOUT = "dfs.client.complete-file-retry-timeout";

    public static final long COMPLETE_FILE_RETRY_TIME_DEFAULT_VALUE = 60L * 1000;

    public static final String DATANODE_CREATE_BLOCK_WRITE_STREAM_RETRY_TIMEOUT = "dfs.client.create-write-block-stream-retry-timeout";

    public static final long DATANODE_CREATE_BLOCK_WRITE_STREAM_RETRY_TIMEOUT_DEFAULT_VALUE = 60L * 1000;

    public static final String SEQUENTIAL_READER_MAX_SKIP = "dfs.client.sequential-reader-max-skip";

    public static final int SEQUENTIAL_READER_MAX_SKIP_DEFAULT_VALUE = 4 * 1024;

    public static final String BLOCK_CACHE_DOWNLOADER_READ_TIMEOUT = "dfs.client.block-cache-downloader-read-timeout";

    public static final long BLOCK_CACHE_DOWNLOADER_READ_TIMEOUT_DEFAULT_VALUE = 10L * 60 * 1000;

    public static final String BLOCK_CACHE_DOWNLOADER_BUFFER_SIZE = "dfs.client.block-cache-downloader-buffer-size";

    public static final int BLOCK_CACHE_DOWNLOADER_BUFFER_SIZE_DEFAULT_VALUE = 32 * 1024;

    public static final String BLOCK_CACHE_GC_INTERVAL = "dfs.client.block-cache-gc-interval";

    public static final long BLOCK_CACHE_GC_INTERVAL_DEFAULT_VALUE = 60L * 60 * 1000;

    public static final String BLOCK_INPUT_MAX_IDLE_TIME = "dfs.client.block-input-max-idle-time";

    public static final long BLOCK_INPUT_MAX_IDLE_TIME_DEFAULT_VALUE = 5L * 60 * 1000;

    public static final String RANDOM_READ_LENGTH_HINT = "dfs.client.random-read-length-hint";

    public static final int RANDOM_READ_LENGTH_HINT_DEFAULT_VALUE = 4 * 1024;
}
