/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 11, 2006
 */
package odis.dfs.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

import odis.dfs.common.BlockInfo;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.io.FSInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.LockStateException;
import odis.io.Path;
import odis.io.permission.FsPermission;
import toolbox.misc.FileUtils;

/**
 * Implementation of the abstract FileSystem for the DFS system. This object is
 * the way end-user code interacts with a DFS.
 * 
 * @author Mike Cafarella, Feng Zhou, zhangduo
 */
public class DistributedFileSystem extends FileSystem {

    public static final String FILE_SEPARATOR = "/";

    public static final char FILE_SEPARATOR_CHAR = '/';

    public static String getDFSParent(String path) {
        if (path == null) {
            return null;
        }
        if (FILE_SEPARATOR.equals(path)) {
            return null;
        }
        int index = path.lastIndexOf(FILE_SEPARATOR_CHAR);
        if (index == -1) {
            return null;
        }
        if (index == 0) {
            return FILE_SEPARATOR;
        }
        return path.substring(0, index);
    }

    private String workingDir = "/home/" + System.getProperty("user.name");

    private final FsPermission defaultPermission;

    private volatile int defaultBlockSize;

    private final String name;

    private final DFSClient dfs;

    public DistributedFileSystem(String zkAddr, String zkRoot,
            DFSClientConfig conf) throws IOException, InterruptedException {
        this.dfs = new DFSClient(zkAddr, zkRoot, conf);
        this.defaultPermission = new FsPermission(
                conf.getDefaultCreatePermission());
        this.defaultBlockSize = conf.getDefaultBlockSize();
        // substitute the FileSystem's own counters with DFSClient's
        // because it's DFSClient who actually does the counting.
        this.readCounter = dfs.getReadCounter();
        this.writeCounter = dfs.getWriteCounter();
        this.name = zkRoot + "@" + zkAddr;
    }

    public String getName() {
        return name;
    }

    public DFSClientConfig getConf() {
        return dfs.getConf();
    }

    public DFSClient getDFSClient() {
        return dfs;
    }

    /**
     * get the cuid of this ODFS, used in cowork now
     */

    public String getCUID() {
        return dfs.getCUID();
    }

    public String getPath(Path file) {
        if (file.getPath().trim().length() == 0) {
            return workingDir;
        }
        List<String> l = new ArrayList<String>();
        l.add(file.getName());
        Path parent = file.getParentFile();
        while (parent != null) {
            l.add(parent.getName());
            parent = parent.getParentFile();
        }
        StringBuilder path = new StringBuilder();
        path.append(l.get(l.size() - 1));
        for (int i = l.size() - 2; i >= 0; i--) {
            path.append(FILE_SEPARATOR).append(l.get(i));
        }
        if (path.length() == 0) {// This is the root 
            path.append(FILE_SEPARATOR);
        }
        String p = path.toString();
        if (!p.startsWith(FILE_SEPARATOR)) {
            return workingDir + FILE_SEPARATOR + p;
        } else {
            return p;
        }
    }

    @Override
    public BlockInfo[] getFileBlocksInfo(Path f) throws IOException {
        String file = getPath(f);
        BlockSizeLocationWithDataPath[] blocks = dfs.getFileBlockLocations(file);
        if (blocks == null) {
            throw new FileNotFoundException(file);
        }
        BlockInfo[] blockInfos = new BlockInfo[blocks.length];
        long offset = 0;
        for (int i = 0; i < blocks.length; i++) {
            BlockSizeLocationWithDataPath b = blocks[i];
            blockInfos[i] = new BlockInfo(b.getBlock(), b.getLen(),
                    b.getLocations(), offset);
            offset += b.getLen();
        }
        return blockInfos;
    }

    @Override
    public DFSInputStream openRaw(Path f) throws IOException {
        return openRaw(f, 0);
    }

    @Override
    public DFSInputStream openRaw(Path f, int flags) throws IOException {
        return dfs.open(getPath(f), flags);
    }

    public void setClientBlockCacheProps(File cacheDir, int numOfDownloaders) {
        dfs.setBlockCacheProps(cacheDir, numOfDownloaders);
    }

    /**
     * Override the built-in default block size (
     * {@link FSConstants#DEFAULT_BLOCK_SIE}), and use the given block size when
     * creating a file without specifying its block size.
     * 
     * @param blockSize
     */
    public void setDefaultBlockSize(int blockSize) {
        this.defaultBlockSize = blockSize;
    }

    public FsPermission getDefaultPermission() {
        return defaultPermission;
    }

    @Override
    public DFSOutputStream createRaw(Path f, boolean overwrite)
            throws IOException {
        return this.createRaw(f, overwrite, true);
    }

    @Override
    public DFSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent) throws IOException {
        return this.createRaw(f, overwrite, createParent, 0);
    }

    @Override
    public DFSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags) throws IOException {
        return this.createRaw(f, overwrite, createParent, flags,
                defaultBlockSize);
    }

    @Override
    public DFSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int fileBlockSize)
            throws IOException {
        return this.createRaw(f, overwrite, createParent, flags,
                FSConstants.NUM_REPLICAS_INHERITED, fileBlockSize,
                defaultPermission);
    }

    @Override
    public DFSOutputStream createRaw(Path f, boolean overwrite,
            boolean createParent, int flags, int replication,
            int fileBlockSize, FsPermission permission) throws IOException {
        return dfs.create(getPath(f), overwrite, createParent, flags,
                replication, fileBlockSize, permission);
    }

    @Override
    public QuorumDFSOutputStream createQuorum(Path f, boolean overwrite,
            boolean createParent, int flags, int replication, int blockSize,
            FsPermission permission, Executor workerExecutor)
            throws IOException {
        return dfs.createQuorum(getPath(f), overwrite, createParent, flags,
                replication, blockSize, permission, workerExecutor);
    }

    @Override
    public boolean rename(Path src, Path dst, boolean overwrite)
            throws IOException {
        dfs.rename(getPath(src), getPath(dst), overwrite);
        return true;
    }

    /**
     * Create link.
     */
    @Override
    public boolean link(Path src, Path dst) throws IOException {
        dfs.link(getPath(src), getPath(dst));
        return true;
    }

    /**
     * Get rid of File f, whether a true file or dir.
     */
    @Override
    public boolean delete(Path f) throws IOException {
        return delete(f, true);
    }

    @Override
    public boolean delete(Path f, boolean recursive) throws IOException {
        return delete(f, recursive, true);
    }

    public boolean delete(Path f, boolean recursive, boolean permanently)
            throws IOException {
        return dfs.delete(getPath(f), recursive, permanently);
    }

    @Override
    public DFSFileInfoImpl[] listFiles(Path f) throws IOException {
        DFSFileStatus[] status = dfs.listFiles(getPath(f));
        if (status == null) {
            return null;
        }
        DFSFileInfoImpl[] results = new DFSFileInfoImpl[status.length];
        for (int i = 0; i < status.length; i++) {
            results[i] = new DFSFileInfoImpl(new Path(status[i].getPath()),
                    status[i]);
        } // for i
        return results;
    }

    @Override
    public void mkdirs(Path f) throws IOException {
        mkdirs(f, FSConstants.NUM_REPLICAS_INHERITED, defaultPermission);
    }

    @Override
    public void mkdirs(Path f, int replication, FsPermission permission)
            throws IOException {
        dfs.mkdirs(getPath(f), replication, permission);
    }

    /**
     * Recover the trash to the dst.
     */
    public void recoverTrash(Path trash, Path dst) throws IOException {
        dfs.recoverTrash(getPath(trash), getPath(dst));
    }

    /**
     * Delete the path under trash can. ONLY used for management.
     */
    public void deleteTrash(Path f) throws IOException {
        dfs.deleteTrash(getPath(f));
    }

    /**
     * Get the desired replication number of the given file or directory
     * 
     * @param path
     * @return
     * @throws java.io.IOException
     */
    @Deprecated
    public byte getReplicationNumber(String path) throws IOException {
        return (byte) dfs.getReplication(path);
    }

    /**
     * Set the desired replication number of the given file or directory
     * 
     * @param path
     * @param replication
     * @param recursive
     * @throws java.io.IOException
     */
    @Deprecated
    public void setReplicationNumber(String path, byte replication,
            boolean recursive) throws IOException {
        dfs.setReplication(path, replication, recursive);
    }

    /**
     * Get the desired replication number of the given file or directory
     * 
     * @param path
     * @return
     * @throws java.io.IOException
     */
    @Override
    public int getReplication(Path path) throws IOException {
        return dfs.getReplication(getPath(path));
    }

    /**
     * Set the desired replication number of the given file or directory
     * 
     * @param path
     * @param replication
     * @param recursive
     * @throws java.io.IOException
     */
    @Override
    public void setReplication(Path path, int replication, boolean recursive)
            throws IOException {
        dfs.setReplication(getPath(path), replication, recursive);
    }

    /**
     * Judge whether the path is recoverable.
     */
    public boolean isRecoverable(Path f) throws IOException {
        return dfs.isRecoverable(getPath(f));
    }

    /**
     * Set the path to be recoverable or not.
     */
    public void setRecoverable(Path f, boolean recoverable) throws IOException {
        dfs.setRecoverable(getPath(f), recoverable);
    }

    /**
     * Judge whether the path is protect.
     */
    public boolean isProtect(Path f) throws IOException {
        return dfs.isProtect(getPath(f));
    }

    /**
     * Set the path to be protect or not.
     */
    public void setProtect(Path f, boolean on) throws IOException {
        dfs.setProtect(getPath(f), on);
    }

    /**
     * Get the current space quota value of a path in ODFS
     * 
     * @param f
     * @return
     * @throws IOException
     */
    public long getSpaceQuota(Path f) throws IOException {
        return dfs.getSpaceQuota(getPath(f));
    }

    /**
     * Set a new space quota to a path in ODFS
     * 
     * @param f
     * @param quota
     * @throws IOException
     */
    public void setSpaceQuota(Path f, long quota) throws IOException {
        dfs.setSpaceQuota(getPath(f), quota);
    }

    /**
     * Get the current name quota value of a path in ODFS
     * 
     * @param f
     * @return
     * @throws IOException
     */
    public long getNameQuota(Path f) throws IOException {
        return dfs.getNameQuota(getPath(f));
    }

    /**
     * Set a new name quota to a path in ODFS
     * 
     * @param f
     * @param quota
     * @throws IOException
     */
    public void setNameQuota(Path f, long quota) throws IOException {
        dfs.setNameQuota(getPath(f), quota);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean deprive(Path f) throws IOException {
        return dfs.deprive(getPath(f));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean exists(Path f) throws IOException {
        return dfs.exists(getPath(f));
    }

    /**
     * Get file status on ODFS.
     * 
     * @param path
     * @return
     * @throws IOException
     */
    public DFSFileStatus getFileStatus(Path path) throws IOException {
        return dfs.getFileStatus(getPath(path));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isDirectory(Path f) throws IOException {
        DFSFileStatus fileStatus = getFileStatus(f);
        return fileStatus != null && fileStatus.isDir();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getLength(Path f) throws IOException {
        DFSFileStatus fileStatus = getFileStatus(f);
        if (fileStatus != null && !fileStatus.isDir()) {
            return fileStatus.getContentsLength();
        } else {
            return 0L;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getLengthRecursive(Path f) throws IOException {
        DFSFileStatus fileStatus = getFileStatus(f);
        return fileStatus != null ? fileStatus.getContentsLength() : 0L;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long lastModified(Path f) throws IOException {
        DFSFileStatus fileStatus = getFileStatus(f);
        return fileStatus != null ? fileStatus.getLastModified() : -1L;
    }

    public Path[] pendingFilesInDir(Path path) throws IOException {
        String[] files = dfs.pendingFilesInDir(getPath(path));
        Path[] paths = new Path[files.length];
        for (int i = 0; i < files.length; i++) {
            paths[i] = new Path(files[i]);
        }
        return paths;
    }

    /**
     * Check if some client is writing the given file.
     */
    public boolean isPending(Path path) throws IOException {
        return dfs.isPending(getPath(path));
    }

    /**
     * Abandon a pending file.
     * 
     * @param path
     * @throws IOException
     */
    public void abandonFile(Path path) throws IOException {
        dfs.abandonFileInProgress(getPath(path));
    }

    /**
     * recalculate every Contents Length of ODFS, this maybe use very long time,
     * after recalculate, each content(dir or file) has a new length, when we du
     * it, we only get the length, need not calculate.
     * 
     * @return
     * @throws IOException
     */
    public void computeContentsLengthAndSubItemNum() throws IOException {
        dfs.computeContentsLengthAndSubItemNum();
    }

    /**
     * Print dir properties to a file on namenode.
     * 
     * @return
     * @throws IOException
     * @throws FSException
     */
    public String printDirProperties() throws IOException {
        return dfs.printDirProperties();
    }

    /**
     * change the owner and group for path
     * 
     * @throws IOException
     */
    public void setOwner(Path path, boolean recursive, String owner,
            String group) throws IOException {
        dfs.setOwner(getPath(path), recursive, owner, group);
    }

    /**
     * change the permission for path
     * 
     * @throws IOException
     */
    public void setPermission(Path path, boolean recursive,
            FsPermission permission) throws IOException {
        dfs.setPermission(getPath(path), recursive, permission);
    }

    public void addGroupUser(String group, String user) throws IOException {
        dfs.addGroupUser(group, user);
    }

    public void removeGroupUser(String group, String user) throws IOException {
        dfs.removeGroupUser(group, user);
    }

    public void removeGroup(String group) throws IOException {
        dfs.removeGroup(group);
    }

    public String printGroups() throws IOException {
        return dfs.printGroups();
    }

    @Override
    public void getLock(Path f, int lock) throws IOException {
        dfs.lock(getPath(f), lock);
    }

    @Override
    public void promoteLock(Path f) throws LockStateException, IOException {
        dfs.promote(getPath(f));
    }

    @Override
    public void releaseLock(Path f) throws IOException {
        dfs.release(getPath(f));
    }

    @Override
    public String getLockState(Path f) throws IOException {
        return dfs.lockState(getPath(f));
    }

    @Override
    public void moveFromLocalFile(File src, Path dst) throws IOException {
        doFromLocalFile(src, dst, true);
    }

    @Override
    public void copyFromLocalFile(File src, Path dst) throws IOException {
        doFromLocalFile(src, dst, false);
    }

    private void doFromLocalFile(File src, Path dst, boolean deleteSource)
            throws IOException {
        if (exists(dst)) {
            if (!isDirectory(dst)) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new Path(dst, src.getName());
                if (exists(dst)) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }

        if (src.isDirectory()) {
            mkdirs(dst);
            File contents[] = src.listFiles();
            for (int i = 0; i < contents.length; i++) {
                doFromLocalFile(contents[i],
                        new Path(dst, contents[i].getName()), deleteSource);
            }
        } else {
            byte buf[] = new byte[FileSystem.DEFAULT_READ_BUFFER_SIZE];
            InputStream in = new FileInputStream(src);
            try {
                OutputStream out = create(dst);
                try {
                    int bytesRead = in.read(buf);
                    while (bytesRead >= 0) {
                        out.write(buf, 0, bytesRead);
                        bytesRead = in.read(buf);
                    }
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        }
        if (deleteSource && !FileUtils.fullyDelete(src)) {
            throw new IOException("Delete source " + src + " failed");
        }
    }

    public void copyToLocalFile(Path src, File dst) throws IOException {
        if (dst.exists()) {
            if (!dst.isDirectory()) {
                throw new IOException("Target " + dst + " already exists");
            } else {
                dst = new File(dst, src.getName());
                if (dst.exists()) {
                    throw new IOException("Target " + dst + " already exists");
                }
            }
        }
        dst = dst.getCanonicalFile();

        if (isDirectory(src)) {
            if (!dst.mkdirs()) {
                throw new IOException("Cannot create target dir " + dst);
            }
            FileInfo contents[] = listFiles(src);
            for (int i = 0; i < contents.length; i++) {
                copyToLocalFile(contents[i].getPath(), new File(dst,
                        contents[i].getPath().getName()));
            }
        } else {
            byte buf[] = new byte[FileSystem.DEFAULT_READ_BUFFER_SIZE];
            InputStream in = open(src);
            try {
                OutputStream out = FileSystem.getNamed("local").create(
                        new Path(dst));
                try {
                    int bytesRead = in.read(buf);
                    while (bytesRead >= 0) {
                        out.write(buf, 0, bytesRead);
                        bytesRead = in.read(buf);
                    }
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        }
    }

    public File startLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        if (exists(fsOutputFile)) {
            copyToLocalFile(fsOutputFile, tmpLocalFile);
        }
        return tmpLocalFile;
    }

    /**
     * Move completed local data to DFS destination
     */
    public void completeLocalOutput(Path fsOutputFile, File tmpLocalFile)
            throws IOException {
        moveFromLocalFile(tmpLocalFile, fsOutputFile);
    }

    /**
     * Fetch remote DFS file, place at tmpLocalFile
     */
    public File startLocalInput(Path fsInputFile, File tmpLocalFile)
            throws IOException {
        copyToLocalFile(fsInputFile, tmpLocalFile);
        return tmpLocalFile;
    }

    /**
     * We're done with the local stuff, so delete it
     */
    public void completeLocalInput(File localFile) throws IOException {
        // Get rid of the local copy - we don't need it anymore.
        getNamed("local").delete(new Path(localFile));
    }

    @Override
    protected void closeInternal() {
        dfs.close();
    }

    public String toString() {
        return "DFS[" + dfs + "]";
    }

    public void reportChecksumFailure(File f, FSInputStream in, long start,
            long length, int crc) {

        // ignore for now, causing task to fail, and hope that when task is
        // retried it gets a different copy of the block that is not corrupt.

        // FIXME: we should move the bad block(s) involved to a bad block
        // directory on their datanode, and then re-replicate the blocks, so
        // that
        // no data is lost. a task may fail, but on retry it should succeed.
    }

    /**
     * Returns the default block size of the underlying DFSClient
     */
    public long getBlockSize() {
        return defaultBlockSize;
    }

    public static class DFSFileInfoImpl extends FileInfo {

        private long lastModified;

        private long lastAccess;

        private long length;

        private Path target;

        private boolean isDirectory;

        private boolean isSLink;

        private String owner;

        private String group;

        private FsPermission permission;

        private int replication;

        public DFSFileInfoImpl(Path p, DFSFileStatus info) {
            super(p);
            this.lastModified = info.getLastModified();
            this.length = info.getContentsLength();
            String tmp = info.getTarget();
            this.target = (tmp == null) ? null : new Path(tmp);
            this.isDirectory = info.isDir();
            this.isSLink = info.isSymlink();
            this.group = info.getGroup();
            this.owner = info.getOwner();
            this.permission = info.getPermission();
            this.lastAccess = info.getLastAccess();
            this.replication = info.getReplication();
        }

        @Override
        public long getLastModified() {
            return lastModified;
        }

        @Override
        public long getLength() {
            return length;
        }

        @Override
        public Path getTarget() {
            return target;
        }

        @Override
        public boolean isDir() {
            return isDirectory;
        }

        @Override
        public boolean isSLink() {
            return isSLink;
        }

        public String getGroup() {
            return group;
        }

        public String getOwner() {
            return owner;
        }

        public FsPermission getPermission() {
            return permission;
        }

        public long getLastAccess() {
            return lastAccess;
        }

        public int getReplication() {
            return replication;
        }
    }

    public String getWorkingDir() {
        return workingDir;
    }

    public void setWokringDir(Path path) {
        workingDir = getPath(path);
    }
}
