/**
 * @(#)IDataToNameProtocolMethods.java, 2012-12-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.lang.reflect.Method;

/**
 * @author zhangduo
 */
public final class IDataToNameProtocolMethods {

    public static final Method RECOVER_INCONSISTENT_BLOCK;

    public static final Method REPORT_CONSISTENCY_CHECK_RESULT;

    public static final Method CONNECT;

    public static final Method DISCONNECT;

    public static final Method BLOCK_REPORT;

    public static final Method SEND_HEARTBEAT;

    public static final Method REPORT_BLOCK_RECEIVED_OR_DELETED;

    public static final Method REPLICATION_DONE;

    static {
        try {
            RECOVER_INCONSISTENT_BLOCK = IDataToNameProtocol.class.getMethod(
                    "recoverInconsistentBlock", long.class, String.class,
                    BlockCheckResult.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        try {
            REPORT_CONSISTENCY_CHECK_RESULT = IDataToNameProtocol.class.getMethod(
                    "reportConsistencyCheckResult", long.class, String.class,
                    BlockCheckResult.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        try {
            CONNECT = IDataToNameProtocol.class.getMethod("connect",
                    String.class, BlockSize[].class, long.class, long.class,
                    long.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        try {
            DISCONNECT = IDataToNameProtocol.class.getMethod("disconnect",
                    String.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        try {
            BLOCK_REPORT = IDataToNameProtocol.class.getMethod("blockReport",
                    String.class, BlockSize[].class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }

        try {
            SEND_HEARTBEAT = IDataToNameProtocol.class.getMethod(
                    "sendHeartbeat", String.class, long.class, long[].class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        try {
            REPORT_BLOCK_RECEIVED_OR_DELETED = IDataToNameProtocol.class.getMethod(
                    "reportBlockReceivedOrDeleted", String.class,
                    BlockSize[].class, long[].class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        try {
            REPLICATION_DONE = IDataToNameProtocol.class.getMethod(
                    "replicationDone", String.class,
                    BlockSizeLocationWithDataPath.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }
}
