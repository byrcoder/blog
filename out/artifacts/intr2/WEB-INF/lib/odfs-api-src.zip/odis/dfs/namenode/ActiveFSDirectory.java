/**
 * @(#)ActiveFSDirectory.java, 2012-12-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSException;
import odis.io.permission.FsAction;
import odis.io.permission.FsPermission;
import odis.util.KeyValueIterator;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableLong;

import toolbox.collections.Pair;

/**
 * ActiveFSDirectory stores file system directory state. It handles loading and
 * storing images, loading fs edit log, reading and writing to directory, etc.
 * <p>
 * Notice, ActiveFSDirectory will delete blocks directly by calling
 * <tt>trashBlocks</tt> method in <tt>ActiveFSBlockStore</tt> when file being
 * deleted or overwrite. But when creating file, ActiveFSDirectory will only
 * call <tt>activeBlock</tt>, ActiveFSNameSystem should call <tt>addBlock</tt>
 * before calling <tt>completeFile</tt>. And when creating failed,
 * ActiveFSNameSystem should handle the unused blocks.
 * <p>
 * Be careful with FileINodeUC. Method other than <tt>addFileUC</tt>,
 * <tt>abandonFileUC</tt>, <tt>completeFile</tt> should not modify its internal
 * field because it is protect by ActiveFSNameSystem.this lock.
 * 
 * @author zhangduo
 */
class ActiveFSDirectory extends AbstractPrimaryFSDirectory<ActiveFSBlockStore> {

    ActiveFSDirectory(Configuration conf, ActiveFSBlockStore bstore,
            File imageFile, Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            MutableLong maxLoadedLogSN) throws IOException {
        super(bstore, imageFile, new FsPermission(conf.getInt(
                DFSConfig.NAMENODE_DEFAULT_PERMISSION,
                DFSConfig.DEFAULT_NAMENODE_DEFAULT_PERMISSION)),
                conf.getString(DFSConfig.NAMENODE_DEFAULT_GROUP,
                        DFSConfig.DEFAULT_NAMENODE_DEFAULT_GROUP),
                conf.getString(DFSConfig.NAMENODE_ADMIN,
                        DFSConfig.DEFAULT_NAMENODE_ADMIN), pendingCreates,
                pendingCreateLastBlocks, maxLoadedLogSN);
    }

    ActiveFSDirectory(ActiveFSBlockStore bstore,
            FsPermission defaultPermission, String defaultGroup, String admin,
            DirectoryINode rootDir, FSDirPropertyManager fsDirPropMgr,
            UserGroupManager ugMgr, FsPermissionChecker permissionChecker) {
        super(bstore, defaultPermission, defaultGroup, admin, rootDir,
                fsDirPropMgr, ugMgr, permissionChecker);
    }

    private void unprotectedComputeContentsLengthAndSubItemNum(INode node,
            IdentityHashMap<FileINode, FileINode> alreadyCalculatedLinkedFiles,
            MutableLong distinctFileNum, MutableLong distinctFileSize) {
        if (node instanceof FileINode) {
            FileINode fileNode = (FileINode) node;
            long[] blocks = fileNode.getBlocks();
            long contentsLength = 0;
            for (long block: blocks) {
                contentsLength += bstore.getActiveBlockLen(block);
            }
            node.setContentsLength(contentsLength);
            if (node.getRefCount() > 1) {
                if (alreadyCalculatedLinkedFiles.put(fileNode, fileNode) == null) {
                    distinctFileNum.increment();
                    distinctFileSize.add(contentsLength);
                }
            } else {
                distinctFileNum.increment();
                distinctFileSize.add(contentsLength);
            }
        } else if (node instanceof DirectoryINode) {
            DirectoryINode dirNode = (DirectoryINode) node;
            long contentsLength = 0;
            long subDirNum = 0;
            long subFileNum = 0;
            for (KeyValueIterator<UTF8String, INode> iter = dirNode.iterator(); iter.hasNext();) {
                iter.next();
                INode subNode = iter.getValue();
                unprotectedComputeContentsLengthAndSubItemNum(subNode,
                        alreadyCalculatedLinkedFiles, distinctFileNum,
                        distinctFileSize);
                contentsLength += subNode.getContentsLength();
                subDirNum += subNode.getSubDirNum();
                subFileNum += subNode.getSubFileNum();
                if (subNode instanceof FileINode) {
                    subFileNum++;
                } else if (subNode instanceof DirectoryINode) {
                    subDirNum++;
                }
            }
            node.setContentsLength(contentsLength);
            node.setSubDirNum(subDirNum);
            node.setSubFileNum(subFileNum);
        }
    }

    private final Object computeContentsLengthAndSubItemNumLock = new Object();

    void computeContentsLengthAndSubItemNum() {
        nodeTreeLock.readLock().lock();
        try {
            synchronized (computeContentsLengthAndSubItemNumLock) {
                MutableLong distinctFileNum = new MutableLong(0);
                MutableLong distinctFileSize = new MutableLong(0);
                IdentityHashMap<FileINode, FileINode> alreadyCalculatedLinkedFiles = new IdentityHashMap<FileINode, FileINode>();
                unprotectedComputeContentsLengthAndSubItemNum(rootDir,
                        alreadyCalculatedLinkedFiles, distinctFileNum,
                        distinctFileSize);
                this.distinctFileNum = distinctFileNum.longValue();
                this.distinctFileSize = distinctFileSize.longValue();
            }
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }

    /**
     * Add a {@link FileINodeUC} into node tree and return it.
     * 
     * @param time
     * @param file
     * @param overwrite
     * @param createParent
     *            whether to create parent folder recursively
     * @param replication
     * @param permisson
     * @param holder
     *            lease holder
     * @param user
     * @return
     * @throws IOException
     */
    FileINodeUC addFileUC(long time, String file, boolean overwrite,
            boolean createParent, FsPermission permission, int replication,
            int fileBlockSize, String holder, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            Pair<FileINodeUC, FileINode> pair = unprotectedAddFileUC(time,
                    file, overwrite, createParent, permission, replication,
                    fileBlockSize, holder, user);
            FileINode deletedNode = pair.getSecond();
            if (deletedNode != null) {
                bstore.trashBlocks(deletedNode.getBlocks(), "Create file "
                        + file + " overwrite");
            }
            return pair.getFirst();
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Remove FileINodeUC from node tree.
     * 
     * @param time
     * @param file
     * @param user
     * @throws FSException
     */
    void abandonFileUC(long time, String file, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            unprotectedAbandonFileUC(time, file, user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Return false means the FileINodeUC for this file is not exists(i.e., the
     * parent directory has been deleted), and we do not add the file into the
     * node tree.
     * 
     * @param time
     * @param file
     * @return
     */
    boolean completeFile(long time, String file) {
        nodeTreeLock.writeLock().lock();
        try {
            return unprotectedCompleteFile(time, file);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    boolean deprive(long time, String file, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            Pair<Boolean, FileINode> pair = unprotectedDeprive(time, file, user);
            if (pair.getSecond() != null) {
                bstore.trashBlocks(pair.getSecond().getBlocks(),
                        "Client deprive " + file);
            }
            return pair.getFirst();
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Get the blocks associated with the file
     * 
     * @param file
     * @param user
     * @return
     * @throws FSException
     */
    long[] getFileBlocks(String file, String user) throws FSException {
        nodeTreeLock.readLock().lock();
        try {
            Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(file);
            permissionChecker.check(file, pair.getFirst(), pair.getSecond(),
                    null, null, FsAction.READ, null, null, user);
            INode node = pair.getSecond()[pair.getSecond().length - 1];
            if (node instanceof FileINode) {
                node.setLastAccess(System.currentTimeMillis());
                return ((FileINode) node).getBlocks();
            } else {
                return null;
            }
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }

    /**
     * Change a file or directory's name, or move it to another place.
     * 
     * @param time
     * @param src
     * @param dst
     * @param overwrite
     * @param user
     * @throws FSException
     */
    void renameTo(long time, String src, String dst, boolean overwrite,
            String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            FileINode deletedNode = unprotectedRenameTo(time, src, dst,
                    overwrite, user);
            if (deletedNode != null) {
                bstore.trashBlocks(deletedNode.getBlocks(), "Rename file "
                        + src + " to " + dst + " overwrite");
            }
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Create a snapshot from src to dst.
     * <p>
     * We snapshot file using hard link, and snapshot directory using copy.
     * Unfinised file will not be linked.
     * 
     * @param time
     * @param src
     * @param dst
     * @param user
     * @throws FSException
     */
    void snapshot(long time, String src, String dst, String user)
            throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            unprotectedSnapshot(time, src, dst, user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Delete the given path.
     * 
     * @param time
     * @param path
     * @param recursive
     *            if false, do not delete if the src is a directory.
     * @param user
     * @return return false if the node not exists. Otherwise, we will throw an
     *         exception if we can not delete it.
     * @throws IOException
     */
    boolean delete(long time, String path, boolean recursive, String user)
            throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            List<FileINode> deletedNodes = unprotectedDelete(time, path,
                    recursive, user);
            if (deletedNodes == null) {
                return false;
            }
            for (FileINode deletedNode: deletedNodes) {
                bstore.trashBlocks(deletedNode.getBlocks(), "Client delete "
                        + path);
            }
            return true;
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Used for move INode to system directory such as trash.
     * <p>
     * we will append .x(x is an positive integer) if the original node is
     * already exists.
     * 
     * @param time
     * @param src
     * @param dst
     * @param recursive
     *            if false, do not rename if the src is a non-empty directory
     * @param user
     * @return
     * @throws FSException
     */
    String mkdirsAndRenameToWithoutCheckQuota(long time, String src,
            String dst, boolean recursive, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            return unprotectedMkdirsAndRenameToWithoutCheckQuota(time, src,
                    dst, recursive, user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Create directory entries for every item.
     * 
     * @param time
     * @param dir
     * @param replications
     * @param permission
     * @param user
     * @return
     * @throws FSException
     */
    boolean mkdirs(long time, String dir, int replications,
            FsPermission permission, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            return unprotectedMkdirs(time, dir, replications, permission, user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Get file status for the given file or directory.
     * 
     * @param file
     * @param user
     * @return
     * @throws FSException
     */
    DFSFileStatus getFileStatus(String file, String user) throws FSException {
        nodeTreeLock.readLock().lock();
        try {
            Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(file);
            INode[] nodes = pair.getSecond();
            permissionChecker.check(file, pair.getFirst(), nodes, null, null,
                    FsAction.READ, null, null, user);
            INode node = nodes[nodes.length - 1];
            if (node == null || node instanceof FileINodeUC) {
                return null;
            }
            return new DFSFileStatus(file, null, node.getContentsLength(),
                    node instanceof DirectoryINode, node.getRefCount(),
                    node.getDesiredReplications(), node.getLastModified(),
                    node.getLastAccess(), new FsPermission(
                            node.getFsPermission()),
                    ugMgr.getUser(node.getUser()),
                    ugMgr.getGroup(node.getGroup()), node.getSubDirNum(),
                    node.getSubFileNum());
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }

    /**
     * If the given path is a directory, then return all its sub items' file
     * status. If the given path is a file, then return its file status.
     * 
     * @param path
     * @param user
     * @return
     * @throws FSException
     */
    DFSFileStatus[] getListing(String path, String user) throws FSException {
        nodeTreeLock.readLock().lock();
        try {
            Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(path);
            String[] components = pair.getFirst();
            INode[] nodes = pair.getSecond();
            INode node = nodes[nodes.length - 1];
            if (node instanceof DirectoryINode) {
                node.setLastAccess(System.currentTimeMillis());
                permissionChecker.check(path, components, nodes, null, null,
                        FsAction.READ_EXECUTE, null, null, user);
                DirectoryINode dirNode = (DirectoryINode) nodes[nodes.length - 1];
                List<DFSFileStatus> list = new ArrayList<DFSFileStatus>(
                        dirNode.size());
                for (KeyValueIterator<UTF8String, INode> iter = dirNode.iterator(); iter.hasNext();) {
                    iter.next();
                    INode childNode = iter.getValue();
                    if (childNode instanceof FileINodeUC) {
                        continue;
                    }

                    String subPath = (path.length() == 1 ? INode.SEP : path
                            + INode.SEP)
                            + iter.getKey().toString();
                    list.add(new DFSFileStatus(subPath, null,
                            childNode.getContentsLength(),
                            childNode instanceof DirectoryINode,
                            childNode.getRefCount(),
                            childNode.getDesiredReplications(),
                            childNode.getLastModified(),
                            childNode.getLastAccess(), new FsPermission(
                                    childNode.getFsPermission()),
                            ugMgr.getUser(childNode.getUser()),
                            ugMgr.getGroup(childNode.getGroup()),
                            childNode.getSubDirNum(), childNode.getSubFileNum()));
                }
                return list.toArray(new DFSFileStatus[0]);
            } else {
                // just check traverse
                permissionChecker.check(path, components, nodes, null, null,
                        null, null, null, user);
                if (!(node instanceof FileINode)) {
                    return null;
                }
                return new DFSFileStatus[] {
                    new DFSFileStatus(path, null, node.getContentsLength(),
                            false, node.getRefCount(),
                            node.getDesiredReplications(),
                            node.getLastModified(), node.getLastAccess(),
                            new FsPermission(node.getFsPermission()),
                            ugMgr.getUser(node.getUser()),
                            ugMgr.getGroup(node.getGroup()), 0, 0)
                };
            }
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }

    /**
     * Return the desired replications for this file/directory. If it doesn't
     * exist, return its parent's value.
     * 
     * @param path
     * @param user
     * @return
     * @throws FSException
     */
    int getDesiredReplications(String path, String user) throws FSException {
        nodeTreeLock.readLock().lock();
        try {
            Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(path);
            permissionChecker.check(path, pair.getFirst(), pair.getSecond(),
                    null, null, FsAction.READ, null, null, user);
            INode[] nodes = pair.getSecond();
            for (int i = nodes.length - 1; i > 0; i--) {
                if (nodes[i] != null && !(nodes[i] instanceof FileINodeUC)) {
                    return nodes[i].getDesiredReplications();
                }
            }
            return rootDir.getDesiredReplications();
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }

    /**
     * Make the replications of the path to be the given value
     * 
     * @param time
     * @param path
     * @param replications
     *            whether to change sub item replications recursively.
     * @param recursive
     * @param user
     * @throws FSException
     */
    void changeReplication(long time, String path, int replications,
            boolean recursive, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            unprotectedChangeReplication(time, path, replications, recursive,
                    user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    /**
     * Change owner and group of the given file/directory.
     * <p>
     * Blank owner or group means use original one.
     * 
     * @param path
     * @param recursive
     *            whether to change owner of the sub items recursively
     * @param owner
     * @param group
     * @param user
     * @throws FSException
     */
    void setOwnerAndGroup(String path, String owner, String group,
            boolean recursive, String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            unprotectedSetOwnerAndGroup(path, owner, group, recursive, user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    void setPermission(String path, FsPermission permission, boolean recursive,
            String user) throws FSException {
        nodeTreeLock.writeLock().lock();
        try {
            unprotectedSetPermission(path, permission, recursive, user);
        } finally {
            nodeTreeLock.writeLock().unlock();
        }
    }

    static final class DirectoryStatInfo {
        public final long dirNum;

        public final long fileNum;

        public final long distinctFileNum;

        public final long fileSize;

        public final long distinctFileSize;

        DirectoryStatInfo(long dirNum, long fileNum, long distinctFileNum,
                long fileSize, long distinctFileSize) {
            this.dirNum = dirNum;
            this.fileNum = fileNum;
            this.distinctFileNum = distinctFileNum;
            this.fileSize = fileSize;
            this.distinctFileSize = distinctFileSize;
        }

        @Override
        public String toString() {
            return "DirectoryStatInfo [dirNum=" + dirNum + ", fileNum="
                    + fileNum + ", distinctFileNum=" + distinctFileNum
                    + ", fileSize=" + fileSize + ", distinctFileSize="
                    + distinctFileSize + "]";
        }
    }
}
