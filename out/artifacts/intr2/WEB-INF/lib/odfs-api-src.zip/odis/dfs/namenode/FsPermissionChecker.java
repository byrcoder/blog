/**
 * @(#)FsPermissionChecker.java, 2012-2-6. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import odis.dfs.common.FSException;
import odis.io.permission.FsAction;
import odis.io.permission.FsPermission;
import odis.util.KeyValueIterator;

/**
 * @author zhangduo
 */
class FsPermissionChecker {

    private final UserGroupManager ugMgr;

    FsPermissionChecker(UserGroupManager ugMgr) {
        this.ugMgr = ugMgr;
    }

    void checkINode(String path, String name, INode node, FsAction access,
            String user) throws FSException {
        // do not check permission when user is null
        if (user == null) {
            return;
        }
        FsPermission mode = new FsPermission(node.getFsPermission());
        if (user.equals(ugMgr.getUser(node.getUser()))) {
            if (mode.getUserAction().implies(access)) {
                return;
            }
        } else if (ugMgr.inGroup(ugMgr.getGroup(node.getGroup()), user)) {
            if (mode.getGroupAction().implies(access)) {
                return;
            }
        } else {
            if (mode.getOtherAction().implies(access)) {
                return;
            }
        }
        throw new FSException(FSException.PERMISSION_DENIED,
                "Permission denied for " + path + ": user=" + user
                        + ", access=" + access + ", inode=\"" + name + "\" "
                        + ugMgr.getUser(node.getUser()) + ":"
                        + ugMgr.getGroup(node.getGroup()) + ":" + mode);
    }

    private void checkTraverse(String path, String[] components, INode[] nodes,
            int last, String user) throws FSException {
        for (int i = 0; i <= last; i++) {
            String name = i == 0 ? INode.STR_SEP : components[i - 1];
            checkINode(path, name, nodes[i], FsAction.EXECUTE, user);
        }
    }

    private void checkChild(String path, DirectoryINode dir,
            FsAction dirAccess, FsAction fileAccess, String user)
            throws FSException {
        for (KeyValueIterator<UTF8String, INode> iter = dir.iterator(); iter.hasNext();) {
            iter.next();
            String childName = iter.getKey().toString();
            String childPath = (path.length() == 1 ? "/" : path + "/")
                    + childName;
            INode childNode = iter.getValue();
            if (childNode instanceof DirectoryINode) {
                checkINode(childPath, childName, childNode, dirAccess, user);
                checkChild(childPath, (DirectoryINode) childNode, dirAccess,
                        fileAccess, user);
            } else {
                checkINode(childPath, childName, childNode, fileAccess, user);
            }
        }
    }

    /**
     * Check permissions.
     * <p>
     * The different between ancestor and parent is, for example, for a mkdirs
     * operation, you need to create all the directory that is not exists on the
     * path, so you should check the first exists ancestor's permission, but for
     * a delete, you should only check its parent access.
     * 
     * @param path
     *            the access path
     * @param components
     *            path split by '/'
     * @param nodes
     *            inode associate with component. Notice that nodes[0] is
     *            rootDir, nodes[i] is associate with components[i - 1]
     * @param ancestorAccess
     *            required access for the first exists ancestor inode
     * @param parentAccess
     *            required access for parent inode.
     * @param access
     *            required access for inode
     * @param childDirAccess
     *            required access for sub directories.
     * @param childFileAccess
     *            required access for sub files
     * @param user
     *            the user who want to access
     * @throws FSException
     */
    void check(String path, String[] components, INode[] nodes,
            FsAction ancestorAccess, FsAction parentAccess, FsAction access,
            FsAction childDirAccess, FsAction childFileAccess, String user)
            throws FSException {
        // do not check permission when user is null
        if (user == null) {
            return;
        }
        int ancestorIndex = nodes.length - 2;
        for (; ancestorIndex >= 0 && nodes[ancestorIndex] == null; ancestorIndex--);

        // check if we have "x" permission for parent directory
        checkTraverse(path, components, nodes, ancestorIndex, user);
        if (ancestorAccess != null && nodes.length > 1) {
            String name = ancestorIndex == 0 ? INode.STR_SEP
                    : components[ancestorIndex - 1];
            checkINode(path, name, nodes[ancestorIndex], ancestorAccess, user);
        }
        if (parentAccess != null && nodes.length > 1
                && nodes[nodes.length - 2] != null) {
            String name = nodes.length == 2 ? INode.STR_SEP
                    : components[nodes.length - 3];
            checkINode(path, name, nodes[nodes.length - 2], parentAccess, user);
        }
        if (access != null && nodes[nodes.length - 1] != null) {
            String name = nodes.length == 1 ? INode.STR_SEP
                    : components[nodes.length - 2];
            checkINode(path, name, nodes[nodes.length - 1], access, user);
        }
        if ((childDirAccess != null || childFileAccess != null)
                && nodes[nodes.length - 1] instanceof DirectoryINode) {
            checkChild(path, (DirectoryINode) nodes[nodes.length - 1],
                    childDirAccess, childFileAccess, user);
        }
    }

    private void checkOwner(String path, INode node, String user)
            throws FSException {
        String owner = ugMgr.getUser(node.getUser());
        if (!owner.equals(user)) {
            throw new FSException(FSException.PERMISSION_DENIED,
                    "Permission denied: " + user + " is not the owner of "
                            + path + ", owner is " + owner);
        }
    }

    private void checkChildOwner(String path, String name, DirectoryINode dir,
            String user) throws FSException {
        checkOwner(path, dir, user);
        checkINode(path, name, dir, FsAction.READ_EXECUTE, user);
        for (KeyValueIterator<UTF8String, INode> iter = dir.iterator(); iter.hasNext();) {
            iter.next();
            String childName = iter.getKey().toString();
            String childPath = (path.length() == 1 ? "/" : path + "/")
                    + childName;
            INode childNode = iter.getValue();
            if (childNode instanceof DirectoryINode) {
                checkChildOwner(childPath, childName,
                        (DirectoryINode) childNode, user);
            } else {
                checkOwner(childPath, childNode, user);
            }
        }
    }

    void checkOwner(String path, String[] components, INode[] nodes,
            boolean checkChild, String user) throws FSException {
        // do not check permission when user is null
        if (user == null) {
            return;
        }
        int ancestorIndex = nodes.length - 2;
        for (; ancestorIndex >= 0 && nodes[ancestorIndex] == null; ancestorIndex--);
        // check if we have "x" permission for parent directory
        checkTraverse(path, components, nodes, ancestorIndex, user);
        if (nodes[nodes.length - 1] != null) {
            checkOwner(path, nodes[nodes.length - 1], user);
        }

        if (checkChild && nodes[nodes.length - 1] instanceof DirectoryINode) {
            checkChildOwner(path, components.length == 0 ? INode.STR_SEP
                    : components[components.length - 1],
                    (DirectoryINode) nodes[nodes.length - 1], user);
        }
    }
}
