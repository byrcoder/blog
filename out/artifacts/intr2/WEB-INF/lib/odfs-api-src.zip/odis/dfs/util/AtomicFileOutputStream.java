package odis.dfs.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.util.MiscUtils;

import toolbox.misc.LogFormatter;

/**
 * A FileOutputStream that has the property that it will only show up at its
 * destination once it has been entirely written and flushed to disk.
 * <p>
 * While being written, it will use a .tmp suffix. When the output stream is
 * closed, it is flushed, fsynced, and will be moved into place, overwriting any
 * file that already exists at that location.
 */
public class AtomicFileOutputStream extends FilterOutputStream {

    private static final String TMP_EXTENSION = ".tmp";

    private final static Logger LOG = LogFormatter
            .getLogger(AtomicFileOutputStream.class);

    private final File origFile;

    private final File tmpFile;

    public AtomicFileOutputStream(File f) throws FileNotFoundException {
        // Code unfortunately must be duplicated below since we can't assign
        // anything
        // before calling super
        super(new FileOutputStream(new File(f.getParentFile(), f.getName()
                + TMP_EXTENSION)));
        origFile = f.getAbsoluteFile();
        tmpFile = new File(f.getParentFile(), f.getName() + TMP_EXTENSION)
                .getAbsoluteFile();
    }

    @Override
    public void close() throws IOException {
        boolean triedToClose = false, success = false;
        try {
            flush();
            ((FileOutputStream) out).getChannel().force(true);

            triedToClose = true;
            super.close();
            success = true;
        } finally {
            if (success) {
                boolean renamed = tmpFile.renameTo(origFile);
                if (!renamed) {
                    // On windows, renameTo does not replace.
                    if (!origFile.delete() || !tmpFile.renameTo(origFile)) {
                        throw new IOException(
                                "Could not rename temporary file " + tmpFile
                                        + " to " + origFile);
                    }
                }
            } else {
                if (!triedToClose) {
                    // If we failed when flushing, try to close it to not leak
                    // an FD
                    MiscUtils.safeClose(out);
                    out.close();
                }
                // close wasn't successful, try to delete the tmp file
                if (!tmpFile.delete()) {
                    LOG.warning("Unable to delete tmp file " + tmpFile);
                }
            }
        }
    }

    /**
     * Close the atomic file, but do not "commit" the temporary file on top of
     * the destination. This should be used if there is a failure in writing.
     */
    public void abort() {
        try {
            super.close();
        } catch (IOException ioe) {
            LOG.warning("Unable to abort file " + tmpFile
                    + Arrays.toString(ioe.getStackTrace()));
        }
        if (!tmpFile.delete()) {
            LOG.warning("Unable to delete tmp file during abort " + tmpFile);
        }
    }
}
