/**
 * @(#)UnexpectedEOFException.java, 2012-12-31. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.IOException;

/**
 * @author zhangduo
 */
class UnexpectedEOFException extends IOException {

    private static final long serialVersionUID = -3832171058680104578L;

    @Override
    public UnexpectedEOFException fillInStackTrace() {
        return this;
    }

    @Override
    public String toString() {
        return "UnexpectedEOFException";
    }

}
