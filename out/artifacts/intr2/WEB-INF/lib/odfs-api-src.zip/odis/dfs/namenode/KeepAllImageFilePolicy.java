/**
 * @(#)KeepAllImageFilePolicy.java, 2013-4-18. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;

import org.apache.commons.configuration.Configuration;

import odis.dfs.common.FSConstants;

/**
 * @author zhangduo
 */
class KeepAllImageFilePolicy implements SecondaryImageFileKeepPolicy {

    KeepAllImageFilePolicy(Configuration conf) {}

    @Override
    public long clean(File root) {
        return FSConstants.IMAGE_FILE_START_SN - 1;
    }

}
