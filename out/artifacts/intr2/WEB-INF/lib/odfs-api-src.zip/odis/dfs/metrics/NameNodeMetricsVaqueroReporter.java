/**
 * @(#)NameNodeMetricsVaqueroReporter.java, 2012-4-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

import java.net.UnknownHostException;
import java.util.Arrays;

import odis.dfs.common.DFSConfig;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;

import toolbox.misc.net.InetAddressUtils;
import vaquero.client.udp.AnalyzerMooee;

/**
 * @author zhangduo
 */
public class NameNodeMetricsVaqueroReporter {

    private final AnalyzerMooee mooee;

    private void initVaqueroDraw() {
        int lev = 0;
        String drawName = "load";
        mooee.addDraw(drawName, lev, "system load", "GAUGE");
        mooee.addProp(NameNodeMetricsItem.SYSTEM_LOAD.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.PROCESSOR_NUM.name(), drawName);

        lev++;
        drawName = "heap";
        mooee.addDraw(drawName, lev, "heap memory usage", "GAUGE");
        mooee.addProp(NameNodeMetricsItem.HEAP_INIT.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.HEAP_USED.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.HEAP_COMMITTED.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.HEAP_MAX.name(), drawName);

        lev++;
        drawName = "non heap";
        mooee.addDraw(drawName, lev, "non heap memory usage", "GAUGE");
        mooee.addProp(NameNodeMetricsItem.NON_HEAP_INIT.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.NON_HEAP_USED.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.NON_HEAP_COMMITTED.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.NON_HEAP_MAX.name(), drawName);

        lev++;
        drawName = "total number";
        mooee.addDraw(drawName, lev, "total dir number and file number",
                "GAUGE");
        mooee.addProp(NameNodeMetricsItem.DIR_NUM.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.FILE_NUM.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.DISTINCT_FILE_NUM.name(), drawName);

        lev++;
        drawName = "total size";
        mooee.addDraw(drawName, lev, "total file size", "GAUGE");
        mooee.addProp(NameNodeMetricsItem.FILE_SIZE.name(), drawName);
        mooee.addProp(NameNodeMetricsItem.DISTINCT_FILE_SIZE.name(), drawName);

        for (NameNodeMetricsItem item: NameNodeMetricsItem.values()) {
            if (item.offset() <= NameNodeMetricsItem.DISTINCT_FILE_SIZE.offset()) {
                continue;
            }
            lev++;
            drawName = item.name().toLowerCase();
            String dsType = item.name().endsWith("_DELAY") ? "GAUGE"
                    : "COUNTER";
            mooee.addDraw(drawName, lev, item.name(), dsType);
            mooee.addProp(item.name(), drawName);
        }
        mooee.moo();
    }

    public NameNodeMetricsVaqueroReporter(Configuration conf)
            throws UnknownHostException {
        String vaqueroAddr = conf.getString(DFSConfig.METRICS_VAQUERO_ADDR);
        if (StringUtils.isBlank(vaqueroAddr)) {
            mooee = null;
        } else {
            String[] ss = vaqueroAddr.split(":");
            String product = conf.getString(DFSConfig.METRICS_VAQUERO_PRODUCT);
            mooee = new AnalyzerMooee(ss[0], Integer.parseInt(ss[1]), product,
                    "namenode", InetAddressUtils.getShortHostName());
            initVaqueroDraw();
        }
    }

    private long[] prevMetrics = null;

    public void report(long[] metrics) {
        if (mooee == null) {
            return;
        }
        for (NameNodeMetricsItem item: NameNodeMetricsItem.values()) {
            double value;
            if (item.name().endsWith("_DELAY")) {
                if (prevMetrics == null) {
                    value = Double.NaN;
                } else {
                    long countDelta = metrics[item.offset() - 1]
                            - prevMetrics[item.offset() - 1];
                    if (countDelta <= 0) {
                        value = Double.NaN;
                    } else {
                        long delayDelta = metrics[item.offset()]
                                - prevMetrics[item.offset()];
                        value = (double) delayDelta / countDelta / 1000;
                    }
                }
            } else {
                value = metrics[item.offset()];
                if (item == NameNodeMetricsItem.SYSTEM_LOAD) {
                    value /= 100;
                }
            }
            mooee.report(item.name(), value);
        }
        mooee.moo();
        if (prevMetrics == null) {
            prevMetrics = Arrays.copyOf(metrics, metrics.length);
        } else {
            System.arraycopy(metrics, 0, prevMetrics, 0, metrics.length);
        }
    }
}
