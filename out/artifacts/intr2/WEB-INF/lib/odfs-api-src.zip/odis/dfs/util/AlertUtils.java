/**
 * @(#)AlertUtils.java, 2011-12-1. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import toolbox.maintain.alarm.Emailer;
import toolbox.maintain.alarm.SmsSender;
import toolbox.misc.LogFormatter;

/**
 * Utils to send alert sms and email.
 * 
 * @author zhangduo
 */
public class AlertUtils {

    private static final Logger LOG = LogFormatter.getLogger(AlertUtils.class);

    private static final long ALERT_INTERVAL = 5 * 60 * 1000L;

    private static final Emailer EMAILER = new Emailer();

    private static class AlertEntry {
        public final String subject;

        public final String content;

        public final boolean sms;

        public final boolean email;

        public AlertEntry(String subject, String content, boolean sms,
                boolean email) {
            this.subject = subject;
            this.content = content;
            this.sms = sms;
            this.email = email;
        }

    }

    private static final AtomicLong lastAlertTime = new AtomicLong(0);

    private static final BlockingQueue<AlertEntry> alertQueue = new ArrayBlockingQueue<AlertUtils.AlertEntry>(
            10);

    private static final Thread alertThread = new Thread() {

        @Override
        public void run() {
            for (;;) {
                try {
                    AlertEntry entry = alertQueue.take();
                    if (DFSConfig.isEmailAlertEnabled() && entry.email) {
                        EMAILER.sendEmail(DFSConfig.getAlertFromEmail(),
                                DFSConfig.getAlertToEmail(), entry.subject,
                                entry.content, null);
                    }
                    if (DFSConfig.isSmsAlertEnabled() && entry.sms) {
                        SmsSender.send(new String[] {
                            DFSConfig.getAlertSmsGroup()
                        }, entry.subject + ";" + entry.content);
                    }
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "alert failed", e);
                }
            }
        }

    };

    static {
        alertThread.setDaemon(true);
        alertThread.setName("Alert Thread");
        alertThread.start();
    }

    public static void sendEmail(String subject, String content) {
        EMAILER.sendEmail(DFSConfig.getAlertFromEmail(),
                DFSConfig.getAlertToEmail(), subject, content, null);
    }

    private static final AtomicLong alertQueueFullCounter = new AtomicLong(0);

    private static boolean shouldWarning(long times) {
        for (;;) {
            if (times < 10) {
                return true;
            }
            if (times % 10 != 0) {
                return false;
            }
            times /= 10;
        }
    }

    public static void alert(String subject, String content, boolean sms,
            boolean email) {
        long lastTime = lastAlertTime.get();
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastTime < ALERT_INTERVAL) {
            return;
        }
        lastAlertTime.set(currentTime);
        if (!alertQueue.offer(new AlertEntry(subject, content, sms, email))) {
            long queueFullTimes = alertQueueFullCounter.incrementAndGet();
            if (shouldWarning(queueFullTimes)) {
                LOG.warning("Alert queue full for " + queueFullTimes + " times");
            }
        }
    }
}
