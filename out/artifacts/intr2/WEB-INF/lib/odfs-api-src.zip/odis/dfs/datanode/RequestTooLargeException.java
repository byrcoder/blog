/**
 * @(#)RequestTooLargeException.java, 2012-12-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.IOException;

/**
 * @author zhangduo
 */
class RequestTooLargeException extends IOException {

    private static final long serialVersionUID = -1337096688965392168L;

    @Override
    public RequestTooLargeException fillInStackTrace() {
        return this;
    }

    @Override
    public String toString() {
        return "RequestTooLargeException";
    }

}
