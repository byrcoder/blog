/**
 * @(#)SecondaryNameNode.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.util.DfsUtils;
import odis.io.CDataInputStream;
import odis.io.ReadWriteUtils;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableLong;

import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;
import bsh.EvalError;
import bsh.Interpreter;

/**
 * @author zhangduo
 */
public class SecondaryNameNode implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(SecondaryNameNode.class);

    private final SecondaryFSBlockStore bstore;

    private final SecondaryFSDirectory dir;

    private final ImageManager imageMgr;

    private final SecondaryFSEditLogger editLogger;

    private final Map<String, FileINodeUC> pendingCreates;

    private final Map<Long, String[]> pendingCreateLastBlocks;

    private long currentEditLogSN;

    private long lastSavedImageSN;

    private MutableLong maxLoadedLogSN = new MutableLong(Long.MIN_VALUE);

    private final long workInterval;

    private final long imageSaveInterval;

    private final long imageTransferInterval;

    private long nextSaveImageTime;

    private long nextTransferImageTime;

    public SecondaryNameNode(Configuration conf) throws IOException {
        bstore = new SecondaryFSBlockStore();
        imageMgr = new ImageManager(conf);
        pendingCreates = new HashMap<String, FileINodeUC>();
        pendingCreateLastBlocks = new HashMap<Long, String[]>();
        File imageFile = ImageManager.getNewestImageFile(
                imageMgr.getImageRoot(), true);
        if (imageFile == null) {
            lastSavedImageSN = IMAGE_FILE_START_SN;
        } else {
            lastSavedImageSN = ImageManager.getSN(imageFile);
        }
        currentEditLogSN = lastSavedImageSN + 1;
        dir = new SecondaryFSDirectory(conf, bstore, imageFile, pendingCreates,
                pendingCreateLastBlocks, maxLoadedLogSN);
        editLogger = new SecondaryFSEditLogger(conf);
        workInterval = conf.getLong(DFSConfig.NAMENODE_SECONDARY_WORK_INTERVAL,
                DFSConfig.DEFAULT_NAMENODE_SECONDARY_WORK_INTERVAL);
        imageSaveInterval = conf.getLong(
                DFSConfig.NAMENODE_SECONDARY_IMAGE_SAVE_INTERVAL,
                DFSConfig.DEFAULT_NAMENODE_SECONDARY_IMAGE_SAVE_INTERVAL);
        imageTransferInterval = conf.getLong(
                DFSConfig.NAMENODE_SECONDARY_IMAGE_TRANSFER_INTERVAL,
                DFSConfig.DEFAULT_NAMENODE_SECONDARY_IMAGE_TRANSFER_INTERVAL);
    }

    private volatile boolean running = true;

    private void tryLoadEdits() throws IOException {
        long maxFinalizedSegmentSN = editLogger.maxFinalizedSegmentSN();
        for (; currentEditLogSN <= maxFinalizedSegmentSN; currentEditLogSN++) {
            LOG.info("Start loading edit log with sn " + currentEditLogSN);
            InputStream in = editLogger.openFSEditLog(currentEditLogSN);
            if (null == in) {
                LOG.info("Segment " + currentEditLogSN
                        + " doesn't exist, skip it");
                continue;
            }
            long loadedEdits;
            CDataInputStream dataIn = new CDataInputStream(in);
            try {
                loadedEdits = dir.loadFSEdits(dataIn, pendingCreates,
                        pendingCreateLastBlocks, maxLoadedLogSN);
            } finally {
                ReadWriteUtils.safeClose(dataIn);
            }
            LOG.info("Done loading edit log with sn " + currentEditLogSN + ", "
                    + loadedEdits + " edits loaded");
        }
    }

    private void trySaveImage() throws IOException {
        if (System.currentTimeMillis() > nextSaveImageTime
                && currentEditLogSN > lastSavedImageSN + 1) {
            File imageFile = imageMgr.createCheckpointImageFile();
            LOG.info("Start saving image to file "
                    + imageFile.getAbsolutePath());
            int adler32;
            adler32 = dir.saveFSImage(imageFile, pendingCreates,
                    pendingCreateLastBlocks, maxLoadedLogSN.longValue());
            LOG.info("Done saving image to file " + imageFile.getAbsolutePath()
                    + ", file size = " + imageFile.length() + ", adler32 = "
                    + HexString.intToPaddedHex(adler32));
            lastSavedImageSN = currentEditLogSN - 1;
            imageMgr.addNewImage(imageFile, adler32, lastSavedImageSN);
            nextSaveImageTime += imageSaveInterval;
        }
    }

    private void tryTransferImageAndCleanImageAndLog() throws IOException {
        if (System.currentTimeMillis() > nextTransferImageTime) {
            LOG.info("Start transfer image to primaries");
            imageMgr.transferNewestImageToPrimaries();
            LOG.info("Done transfer image to primaries");
            nextTransferImageTime += imageTransferInterval;
            long oldestSN = imageMgr.cleanImageRoots();
            editLogger.deleteOldFSEditLog(oldestSN);
        }
    }

    public void start() throws IOException {
        LOG.info("Secondary namenode start to work");
        long currentTime = System.currentTimeMillis();
        nextSaveImageTime = currentTime + imageSaveInterval;
        nextTransferImageTime = currentTime + imageTransferInterval;
        while (running) {
            tryLoadEdits();
            trySaveImage();
            tryTransferImageAndCleanImageAndLog();
            try {
                Thread.sleep(workInterval);
            } catch (InterruptedException e) {}
        }
    }

    private static void startBeanShell(SecondaryNameNode nameNode)
            throws EvalError {
        int bshPort = DFSConfig.conf().getInt(DFSConfig.NAMENODE_BSH_PORT,
                DFSConfig.DEFAULT_NAMENODE_BSH_PORT);
        Interpreter interpreter = new Interpreter();
        interpreter.set("namenode", nameNode);
        interpreter.set("portnum", bshPort);
        interpreter.eval("setAccessibility(true)");
        interpreter.eval("server(portnum)");

        LOG.info("Bean shell was started on port " + bshPort);
    }

    public void stop() {
        running = false;
    }

    public static void main(String[] args) throws IOException, EvalError {
        DfsUtils.setupFileLogger(DFSConfig.getNamenodeLogDir(), "snn",
                DFSConfig.conf());
        SecondaryNameNode snn = new SecondaryNameNode(DFSConfig.conf());
        startBeanShell(snn);
        snn.start();
    }
}
