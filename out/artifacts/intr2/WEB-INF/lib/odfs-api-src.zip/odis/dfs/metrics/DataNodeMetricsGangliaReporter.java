/**
 * @(#)DataNodeMetricsGangliaReporter.java, 2012-6-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class DataNodeMetricsGangliaReporter {

    private static final Logger LOG = LogFormatter.getLogger(DataNodeMetricsGangliaReporter.class);

    private static final String FLOAT = "float";

    private static final String UINT32 = "uint32";

    private static final int BUFFER_SIZE = 1500; // as per libgmond.c

    private final String host;

    private final byte[] buffer;

    private int offset;

    private final DatagramSocket datagramSocket;

    private final InetSocketAddress gangliaAddr;

    private final int tMax;

    private final int dMax = 0;

    /**
     * ganglia slope values which equal the ordinal.
     * <p>
     * <tt>positive</tt> means rrd "COUNTER" type, <tt>both</tt> means rrd
     * "GAUGE" type.
     * 
     * @author zhangduo
     */
    public enum GangliaSlope {
        zero, positive, negative, both
    };

    public DataNodeMetricsGangliaReporter(Configuration conf, String host)
            throws SocketException {
        String gangliaAddr = conf.getString(DFSConfig.METRICS_GANGLIA_GMETAD_ADDR);
        if (StringUtils.isEmpty(gangliaAddr)) {
            this.host = null;
            this.buffer = null;
            this.datagramSocket = null;
            this.gangliaAddr = null;
            this.tMax = 0;
        } else {
            this.host = host;
            String[] ss = gangliaAddr.split(":");
            this.gangliaAddr = new InetSocketAddress(ss[0],
                    Integer.parseInt(ss[1]));
            this.datagramSocket = new DatagramSocket();
            this.buffer = new byte[BUFFER_SIZE];
            this.tMax = (int) conf.getLong(DFSConfig.METRICS_REPORT_INTERVAL,
                    DFSConfig.DEFAULT_METRICS_REPORT_INTERVAL) / 1000 * 5;
        }
    }

    /**
     * Puts a string into the buffer by first writing the size of the string as
     * an int, followed by the bytes of the string, padded if necessary to a
     * multiple of 4.
     * 
     * @param s
     *            the string to be written to buffer at offset location
     */
    private void xdr_string(String s) {
        byte[] bytes = s.getBytes();
        int len = bytes.length;
        xdr_int(len);
        System.arraycopy(bytes, 0, buffer, offset, len);
        offset += len;
        pad();
    }

    /**
     * Pads the buffer with zero bytes up to the nearest multiple of 4.
     */
    private void pad() {
        int newOffset = ((offset + 3) / 4) * 4;
        while (offset < newOffset) {
            buffer[offset++] = 0;
        }
    }

    /**
     * Puts an integer into the buffer as 4 bytes, big-endian.
     */
    private void xdr_int(int i) {
        buffer[offset++] = (byte) ((i >> 24) & 0xff);
        buffer[offset++] = (byte) ((i >> 16) & 0xff);
        buffer[offset++] = (byte) ((i >> 8) & 0xff);
        buffer[offset++] = (byte) (i & 0xff);
    }

    /**
     * Sends Ganglia Metrics to the configured hosts
     * 
     * @throws IOException
     */
    private void emitToGangliaHosts() {
        try {
            DatagramPacket packet = new DatagramPacket(buffer, offset,
                    gangliaAddr);
            datagramSocket.send(packet);
        } catch (Exception e) {
            LOG.log(Level.WARNING,
                    "emit metrics to " + gangliaAddr + " failed", e);
        } finally {
            // reset the buffer for the next metric to be built
            offset = 0;
        }
    }

    private void emitMetrics(String group, String name, String type,
            String value, GangliaSlope slope) {
        // The following XDR recipe was done through a careful reading of
        // gm_protocol.x in Ganglia 3.1 and carefully examining the output of
        // the gmetric utility with strace.

        // First we send out a metadata message
        xdr_int(128); // metric_id = metadata_msg
        xdr_string(host); // hostname
        xdr_string(name); // metric name
        xdr_int(0); // spoof = False
        xdr_string(type); // metric type
        xdr_string(name); // metric name
        xdr_string(""); // units
        xdr_int(slope.ordinal()); // slope
        xdr_int(tMax); // tmax, the maximum time between metrics
        xdr_int(dMax); // dmax, the maximum data value
        xdr_int(1); /*Num of the entries in extra_value field for
                      Ganglia 3.1.x*/
        xdr_string("GROUP"); /*Group attribute*/
        xdr_string(group); /*Group value*/

        // send the metric to Ganglia hosts
        emitToGangliaHosts();

        // Now we send out a message with the actual value.
        // Technically, we only need to send out the metadata message once for
        // each metric, but I don't want to have to record which metrics we did and
        // did not send.
        xdr_int(133); // we are sending a string value
        xdr_string(host); // hostName
        xdr_string(name); // metric name
        xdr_int(0); // spoof = False
        xdr_string("%s"); // format field
        xdr_string(value); // metric value

        // send the metric to Ganglia hosts
        emitToGangliaHosts();
    }

    public void reportGlobal(long[] metrics) {
        if (datagramSocket == null) {
            return;
        }
        String group = "DN_HEAP";
        emitMetrics(group, DataNodeMetricsItem.HEAP_INIT.name(), FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.HEAP_INIT.offset()]),
                GangliaSlope.both);
        emitMetrics(group, DataNodeMetricsItem.HEAP_USED.name(), FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.HEAP_USED.offset()]),
                GangliaSlope.both);
        emitMetrics(
                group,
                DataNodeMetricsItem.HEAP_COMMITTED.name(),
                FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.HEAP_COMMITTED.offset()]),
                GangliaSlope.both);
        emitMetrics(group, DataNodeMetricsItem.HEAP_MAX.name(), FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.HEAP_MAX.offset()]),
                GangliaSlope.both);
        group = "DN_NON_HEAP";
        emitMetrics(
                group,
                DataNodeMetricsItem.NON_HEAP_INIT.name(),
                FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.NON_HEAP_INIT.offset()]),
                GangliaSlope.both);
        emitMetrics(
                group,
                DataNodeMetricsItem.NON_HEAP_USED.name(),
                FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.NON_HEAP_USED.offset()]),
                GangliaSlope.both);
        emitMetrics(
                group,
                DataNodeMetricsItem.NON_HEAP_COMMITTED.name(),
                FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.NON_HEAP_COMMITTED.offset()]),
                GangliaSlope.both);
        emitMetrics(
                group,
                DataNodeMetricsItem.NON_HEAP_MAX.name(),
                FLOAT,
                Long.toString(metrics[DataNodeMetricsItem.NON_HEAP_MAX.offset()]),
                GangliaSlope.both);
    }

    private Map<String, long[]> prevMetricsMap = new HashMap<String, long[]>();

    public void report(String dataDir, long[] metrics) {
        if (datagramSocket == null) {
            return;
        }
        String dataDirNoSlash = dataDir.replace('/', '_');
        long[] prevMetrics = prevMetricsMap.get(dataDir);
        for (DataNodeMetricsItem item: DataNodeMetricsItem.values()) {
            if (item.offset() < DataNodeMetricsItem.BLOCK_NUM.offset()) {
                continue;
            }
            if (item.offset() < DataNodeMetricsItem.CONCURRENT_READ.offset()) {
                emitMetrics(dataDir, dataDirNoSlash + "-" + item.name(), FLOAT,
                        Float.toString(metrics[item.offset()]),
                        GangliaSlope.both);
            } else if (item.offset() < DataNodeMetricsItem.NORMAL_READ_COUNT.offset()) {
                emitMetrics(dataDir, dataDirNoSlash + "-" + item.name(),
                        UINT32, Long.toString(metrics[item.offset()]),
                        GangliaSlope.both);
            } else if (item.name().endsWith("_DELAY")) {
                if (prevMetrics == null) {
                    continue;
                } else {
                    long countDelta = metrics[item.offset() - 2]
                            - prevMetrics[item.offset() - 2];
                    if (countDelta <= 0) {
                        continue;
                    } else {
                        long delayDelta = metrics[item.offset()]
                                - prevMetrics[item.offset()];
                        float value = (float) delayDelta / countDelta / 1000;
                        emitMetrics(dataDir,
                                dataDirNoSlash + "-" + item.name(), FLOAT,
                                Float.toString(value), GangliaSlope.both);
                    }
                }
            } else {
                emitMetrics(dataDir, dataDirNoSlash + "-" + item.name(),
                        UINT32,
                        Long.toString(metrics[item.offset()] & 0xFFFFFFFFL),
                        GangliaSlope.positive);
            }
        }

        if (prevMetrics == null) {
            prevMetricsMap.put(dataDir, Arrays.copyOf(metrics, metrics.length));
        } else {
            System.arraycopy(metrics, 0, prevMetrics, 0, metrics.length);
        }
    }
}
