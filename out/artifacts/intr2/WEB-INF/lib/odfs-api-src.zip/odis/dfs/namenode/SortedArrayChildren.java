/**
 * @(#)SortedArrayChildren.java, 2011-9-5. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.Arrays;
import java.util.NoSuchElementException;

import odis.util.KeyValueIterator;

/**
 * @author zhangduo
 */
class SortedArrayChildren {

    private static final UTF8String[] EMPTY_KEYS = new UTF8String[0];

    private static final INode[] EMPTY_VALUES = new INode[0];

    private static final int STEP = 2 << 2;

    private UTF8String[] keys;

    private INode[] values;

    private int size;

    SortedArrayChildren() {
        keys = EMPTY_KEYS;
        values = EMPTY_VALUES;
    }

    SortedArrayChildren(int capacity) {
        // capacity should be a multiple of STEP
        int reminder = capacity & (STEP - 1);
        if (reminder != 0) {
            capacity += STEP - reminder;
        }
        keys = new UTF8String[capacity];
        values = new INode[capacity];
    }

    boolean containsKey(UTF8String key) {
        return Arrays.binarySearch(keys, 0, size, key) >= 0;
    }

    INode get(UTF8String key) {
        int pos = Arrays.binarySearch(keys, 0, size, key);
        if (pos >= 0) {
            return values[pos];
        } else {
            return null;
        }
    }

    INode put(UTF8String key, INode value) {
        int pos = Arrays.binarySearch(keys, 0, size, key);
        if (pos >= 0) {
            INode oldValue = values[pos];
            values[pos] = value;
            return oldValue;
        } else {
            pos = -pos - 1;
            if (size == keys.length) {
                UTF8String[] newKeys = new UTF8String[size + STEP];
                INode[] newValues = new INode[size + STEP];
                if (pos > 0) {
                    System.arraycopy(keys, 0, newKeys, 0, pos);
                    System.arraycopy(values, 0, newValues, 0, pos);
                }
                newKeys[pos] = key;
                newValues[pos] = value;
                if (pos < size) {
                    System.arraycopy(keys, pos, newKeys, pos + 1, size - pos);
                    System.arraycopy(values, pos, newValues, pos + 1, size
                            - pos);
                }
                keys = newKeys;
                values = newValues;
            } else {
                if (pos < size) {
                    System.arraycopy(keys, pos, keys, pos + 1, size - pos);
                    System.arraycopy(values, pos, values, pos + 1, size - pos);
                }
                keys[pos] = key;
                values[pos] = value;
            }
            size++;
            return null;
        }
    }

    private INode removeAt(int pos) {
        INode oldValue = values[pos];
        if (keys.length - size - 1 >= STEP) {
            UTF8String[] newKeys = new UTF8String[keys.length - STEP];
            INode[] newValues = new INode[values.length - STEP];
            if (pos > 0) {
                System.arraycopy(keys, 0, newKeys, 0, pos);
                System.arraycopy(values, 0, newValues, 0, pos);
            }
            if (pos < size - 1) {
                System.arraycopy(keys, pos + 1, newKeys, pos, size - pos - 1);
                System.arraycopy(values, pos + 1, newValues, pos, size - pos
                        - 1);
            }
            keys = newKeys;
            values = newValues;
        } else {
            if (pos < size - 1) {
                System.arraycopy(keys, pos + 1, keys, pos, size - pos - 1);
                System.arraycopy(values, pos + 1, values, pos, size - pos - 1);
            }
            keys[size - 1] = null;
            values[size - 1] = null;
        }
        size--;
        return oldValue;
    }

    INode remove(UTF8String key) {
        int pos = Arrays.binarySearch(keys, 0, size, key);
        if (pos >= 0) {
            return removeAt(pos);
        } else {
            return null;
        }
    }

    KeyValueIterator<UTF8String, INode> iterator() {
        return new KeyValueIterator<UTF8String, INode>() {
            private int pos = -1;

            private boolean removed = false;

            @Override
            public boolean hasNext() {
                return pos < size - 1;
            }

            @Override
            public void next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                pos++;
                removed = false;
            }

            @Override
            public UTF8String getKey() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return keys[pos];
            }

            @Override
            public INode getValue() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return values[pos];
            }

            @Override
            public void remove() {
                if (pos < 0 || removed) {
                    throw new IllegalStateException();
                }
                removeAt(pos);
                pos--;
                removed = true;
            }

        };
    }

    int size() {
        return size;
    }

    void clear() {
        keys = EMPTY_KEYS;
        values = EMPTY_VALUES;
        size = 0;
    }

    @Override
    public String toString() {
        int iMax = size - 1;
        if (iMax == -1) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (int i = 0;; i++) {
            sb.append(keys[i]).append('=').append(values[i]);
            if (i == iMax) {
                return sb.append(']').toString();
            }
            sb.append(", ");
        }
    }
}
