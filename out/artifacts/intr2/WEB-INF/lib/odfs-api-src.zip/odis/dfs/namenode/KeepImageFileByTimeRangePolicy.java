/**
 * @(#)KeepImageFileByTimeRangePolicy.java, 2013-4-19. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.util.BitSet;

import odis.dfs.common.FSConstants;

import org.apache.commons.configuration.Configuration;
import org.joda.time.DateTime;
import org.joda.time.Period;

/**
 * Using different policy in different time range.
 * <ul>
 * <li>Keep all image files which generated today.</li>
 * <li>Keep one image per day for image files which generated within a week.</li>
 * <li>Keep one image per week for image files which generated within a month(4
 * weeks actually).</li>
 * <li>Delete all images which generated a month before.</li>
 * </ul>
 * 
 * @author zhangduo
 */
class KeepImageFileByTimeRangePolicy implements SecondaryImageFileKeepPolicy {

    private static final class ImageFileInfo {
        public final String name;

        public final long lastModified;

        public ImageFileInfo(String name, long lastModified) {
            this.name = name;
            this.lastModified = lastModified;
        }
    }

    private ImageFileInfo[] convertToImageFileInfo(File[] imageFiles) {
        ImageFileInfo[] imageFileInfos = new ImageFileInfo[imageFiles.length];
        File imageFile = imageFiles[imageFiles.length - 1];
        imageFileInfos[imageFiles.length - 1] = new ImageFileInfo(
                imageFile.getName(), imageFile.lastModified());
        for (int i = imageFiles.length - 2; i >= 0; i--) {
            imageFile = imageFiles[i];
            // image with small sn should have small lastModifiedTime
            long lastModified = imageFile.lastModified();
            if (lastModified >= imageFileInfos[i + 1].lastModified) {
                lastModified = imageFileInfos[i + 1].lastModified - 1;
            }
            imageFileInfos[i] = new ImageFileInfo(imageFile.getName(),
                    lastModified);
        }
        return imageFileInfos;
    }

    private int locateLastModifiedAfterTime(ImageFileInfo[] infos, long time,
            int scanFrom) {
        for (int i = scanFrom; i >= 0; i--) {
            if (infos[i].lastModified < time) {
                return i + 1;
            }
        }
        return 0;
    }

    @Override
    public long clean(File root) {
        File[] imageFiles = ImageManager.listImageFiles(root, true);
        if (imageFiles.length == 0) {
            return FSConstants.IMAGE_FILE_START_SN - 1;
        }
        ImageFileInfo[] infos = convertToImageFileInfo(imageFiles);
        DateTime dt = DateTime.now().withTimeAtStartOfDay();
        // images after this index will be kept
        int lastModifiedTodayStartIndex = locateLastModifiedAfterTime(infos,
                dt.getMillis(), infos.length - 1);
        if (lastModifiedTodayStartIndex == 0) {
            return ImageManager.getSN(infos[0].name);
        }
        // images in this range will kept per day.
        dt = dt.minusDays(7);
        int lastModifiedWithInWeekStartIndex = locateLastModifiedAfterTime(
                infos, dt.getMillis(), lastModifiedTodayStartIndex - 1);
        BitSet kept = new BitSet(7);
        for (int i = lastModifiedWithInWeekStartIndex; i < lastModifiedTodayStartIndex; i++) {
            int daysAfter = new Period(dt.getMillis(), infos[i].lastModified).getDays();
            if (kept.get(daysAfter)) {
                ImageManager.cleanImageAndChecksumFile(root, infos[i].name);
            } else {
                kept.set(daysAfter);
            }
        }
        if (lastModifiedWithInWeekStartIndex == 0) {
            return ImageManager.getSN(infos[0].name);
        }

        // images in this range will be kept per week.
        dt = dt.minusDays(21);
        int lastModifiedWithInMonthStartIndex = locateLastModifiedAfterTime(
                infos, dt.getMillis(), lastModifiedWithInWeekStartIndex - 1);
        kept.clear();
        for (int i = lastModifiedWithInMonthStartIndex; i < lastModifiedWithInWeekStartIndex; i++) {
            int weeksAfter = new Period(dt.getMillis(), infos[i].lastModified).getWeeks();
            if (kept.get(weeksAfter)) {
                ImageManager.cleanImageAndChecksumFile(root, infos[i].name);
            } else {
                kept.set(weeksAfter);
            }
        }

        // image before a month will be deleted
        for (int i = lastModifiedWithInMonthStartIndex - 1; i >= 0; i--) {
            ImageManager.cleanImageAndChecksumFile(root, infos[i].name);
        }
        return ImageManager.getSN(infos[lastModifiedWithInMonthStartIndex].name);
    }

    KeepImageFileByTimeRangePolicy(Configuration conf) {}
}
