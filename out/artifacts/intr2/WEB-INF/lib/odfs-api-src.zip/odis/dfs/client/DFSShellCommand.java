/**
 * @(#)DFSShellCommand.java, 2013-1-9. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import jline.console.ConsoleReader;
import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.common.IClientProtocolV3;
import odis.dfs.util.DfsUtils;
import odis.file.WildCardFilter;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.LocalFileSystem;
import odis.io.Path;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.rpc2.RPC;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.collections.Pair;
import toolbox.misc.cli.Options;
import toolbox.text.util.StringUtils;

/**
 * Base class for all commands.
 * 
 * @author zhangduo
 */
public abstract class DFSShellCommand {

    /**
     * The context when executing command.
     * <p>
     * if <tt>console</tt> is not null, use <tt>console</tt> to read from
     * terminal and print to terminal. Otherwise, use <tt>in</tt>, <tt>out</tt>,
     * and <tt>err</tt>.
     * 
     * @author zhangduo
     */
    public static final class Context {
        public final DistributedFileSystem dfs;

        public final InputStream in;

        public final PrintStream out;

        public final PrintStream err;

        public final ConsoleReader console;

        public Context(DistributedFileSystem dfs, InputStream in,
                PrintStream out, PrintStream err, ConsoleReader console) {
            this.dfs = dfs;
            this.in = in;
            this.out = out;
            this.err = err;
            this.console = console;
        }

        public String getCurrentPath() {
            return dfs.getWorkingDir();
        }

        public String getPath(String path) throws IOException {
            if (path.startsWith(DistributedFileSystem.FILE_SEPARATOR)) {
                return path;
            } else {
                return DfsUtils.canonicalize(dfs.getWorkingDir()
                        + DistributedFileSystem.FILE_SEPARATOR + path);
            }
        }

        public String readLine(String prompt) throws IOException {
            if (console != null) {
                return console.readLine(prompt);
            } else {
                out.println(prompt);
                return new BufferedReader(new InputStreamReader(in)).readLine();
            }
        }

        public void print(String s) throws IOException {
            if (console != null) {
                if (s == null) {
                    console.print("null");
                } else {
                    console.print(s);
                }
            } else {
                out.print(s);
            }
        }

        public void flush() throws IOException {
            if (console != null) {
                console.flush();
            } else {
                out.flush();
            }
        }

        public void println(String s) throws IOException {
            if (console != null) {
                if (s == null) {
                    console.println("null");
                } else {
                    console.println(s);
                }
            } else {
                out.println(s);
            }
        }

        public void println() throws IOException {
            if (console != null) {
                console.println();
            } else {
                out.println();
            }
        }
    }

    /**
     * Return 0 means success.
     * 
     * @param ctx
     * @param args
     * @return
     * @throws Exception
     */
    public abstract int exec(Context ctx, String[] args) throws Exception;

    protected boolean isWildcard(String pattern) {
        int asterisk = pattern.indexOf('*');
        if (asterisk < 0) {
            return false;
        }
        int lastSlash = pattern.lastIndexOf(DistributedFileSystem.FILE_SEPARATOR_CHAR);
        if (lastSlash > asterisk) {
            throw new IllegalArgumentException("Unsupport wildcard pattern "
                    + pattern + ", we only support * in the name part");
        }
        return true;
    }

    protected DFSFileStatus[] filterWithWildcard(DistributedFileSystem dfs,
            String pattern) throws IOException {
        int lastSlash = pattern.lastIndexOf(DistributedFileSystem.FILE_SEPARATOR_CHAR);
        String path = pattern.substring(0, lastSlash);
        DFSFileStatus[] files = dfs.getDFSClient().listFiles(path);
        if (files == null) {
            return null;
        }
        List<DFSFileStatus> results = new ArrayList<DFSFileStatus>();
        WildCardFilter filter = new WildCardFilter(
                pattern.substring(lastSlash + 1));
        for (DFSFileStatus file: files) {
            if (filter.accept(null, file.getName())) {
                results.add(file);
            }
        }
        return results.toArray(new DFSFileStatus[0]);
    }
}

@Retention(RetentionPolicy.RUNTIME)
@interface DFSShellCommandName {
    String[] value();
}

@DFSShellCommandName({
    "ls", "ll"
})
final class ListCommand extends DFSShellCommand {

    private static final DateTimeFormatter FORMATTER = DateTimeFormat.forPattern("MM/dd/yy HH:mm:ss");

    private static final Comparator<DFSFileStatus> NAME_COMPARATOR = new Comparator<DFSFileStatus>() {

        @Override
        public int compare(DFSFileStatus o1, DFSFileStatus o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };

    private static final Comparator<DFSFileStatus> LAST_MODIFIED_COMPARATOR = new Comparator<DFSFileStatus>() {

        @Override
        public int compare(DFSFileStatus o1, DFSFileStatus o2) {
            long l1 = o1.getLastModified();
            long l2 = o2.getLastModified();
            return l1 < l2 ? 1 : l1 == l2 ? 0 : -1;
        }
    };

    private final Options options;

    public ListCommand() {
        options = new Options();
        options.withSharedOption("r", "reverse sort");
        options.withSharedOption("t", "sort by modification time");
        options.withSharedOption("c",
                "set to display desired replication number");
        options.addParam("path");
    }

    private Comparator<DFSFileStatus> getComparator() {
        final Comparator<DFSFileStatus> cmp = options.isOptSet("t") ? LAST_MODIFIED_COMPARATOR
                : NAME_COMPARATOR;
        if (options.isOptSet("r")) {
            return new Comparator<DFSFileStatus>() {

                @Override
                public int compare(DFSFileStatus o1, DFSFileStatus o2) {
                    return -cmp.compare(o1, o2);
                }

            };
        } else {
            return cmp;
        }
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        boolean showReplication = options.isOptSet("c");
        String path = options.getRemains().length == 0 ? ctx.getCurrentPath()
                : ctx.getPath(options.getRemains()[0]);
        DFSFileStatus[] items;
        if (isWildcard(path)) {
            items = filterWithWildcard(ctx.dfs, path);
        } else {
            items = ctx.dfs.getDFSClient().listFiles(path);
        }
        if (items == null) {
            ctx.err.println("Could not get listing for " + path);
            return 2;
        }
        ctx.println("Found " + items.length + " items");
        int maxOwnerWidth = 0;
        int maxGroupWidth = 0;
        int maxNameWidth = 0;
        int maxLengthWidth = 0;
        for (DFSFileStatus item: items) {
            if (item.getOwner().length() > maxOwnerWidth) {
                maxOwnerWidth = item.getOwner().length();
            }
            if (item.getGroup().length() > maxGroupWidth) {
                maxGroupWidth = item.getGroup().length();
            }
            if (item.getName().length() > maxNameWidth) {
                maxNameWidth = item.getName().length();
            }
            int lengthWidth = item.isDir() ? 5 : Long.toString(
                    item.getContentsLength()).length();
            if (lengthWidth > maxLengthWidth) {
                maxLengthWidth = lengthWidth;
            }
        }

        Comparator<DFSFileStatus> cmp = getComparator();
        Arrays.sort(items, cmp);
        for (DFSFileStatus item: items) {
            ctx.print(item.getPermission() + " ");
            ctx.print(String.format("%-" + maxOwnerWidth + "s ",
                    item.getOwner()));
            ctx.print(String.format("%-" + maxGroupWidth + "s ",
                    item.getGroup()));
            ctx.print(FORMATTER.print(item.getLastModified()) + " ");
            ctx.print(String.format("%-" + maxNameWidth + "s ", item.getName()));
            ctx.print(String.format(
                    "%-" + maxLengthWidth + "s",
                    item.isDir() ? "<dir>"
                            : Long.toString(item.getContentsLength())));
            if (showReplication) {
                ctx.print(" " + item.getReplication());
            }
            ctx.println();
        }
        return 0;
    }
}

@DFSShellCommandName("stat")
final class StatCommand extends DFSShellCommand {
    private final Options options;

    public StatCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    private static final DateTimeFormatter FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS Z");

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        DFSFileStatus status = ctx.dfs.getDFSClient().getFileStatus(path);
        if (status == null) {
            ctx.err.println("cannot stat '" + path
                    + "': No such file or directory");
            return 1;
        }
        ctx.println("  File: '" + status.getName() + "'");
        if (status.isDir()) {
            ctx.println("  Size: 0\tRep: " + status.getReplication());
        } else {
            int blockCount = ctx.dfs.getDFSClient().getFileBlockLocations(path).length;
            ctx.println("  Size: " + status.getContentsLength() + "\tRep: "
                    + status.getReplication() + "\tRef: "
                    + status.getRefCount() + "\tBlk: " + blockCount);
        }
        FsPermission permission = status.getPermission();
        ctx.println("Access: (" + String.format("%04o", permission.toShort())
                + "/" + permission.toString() + ")\tOwner: "
                + status.getOwner() + "\tGroup: " + status.getGroup());
        ctx.println("Access: " + FORMATTER.print(status.getLastAccess()));
        ctx.println("Modify: " + FORMATTER.print(status.getLastModified()));
        return 0;
    }
}

@DFSShellCommandName("cd")
final class ChdirCommand extends DFSShellCommand {

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        if (args.length == 0) {
            ctx.dfs.setWokringDir(new Path("/"));
            return 0;
        }
        String dir = ctx.getPath(args[0]);
        DFSFileStatus status = ctx.dfs.getDFSClient().getFileStatus(dir);
        if (status == null || !status.isDir()) {
            ctx.err.println("Error: " + dir
                    + " does not exist or is not directory.");
            return 1;
        }
        ctx.dfs.setWokringDir(new Path(dir));
        return 0;
    }
}

@DFSShellCommandName("du")
final class DiskUsageCommand extends DFSShellCommand {
    private static final DateTimeFormatter FORMATTER = DateTimeFormat.forPattern("MM/dd/yy HH:mm:ss");

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        String path = args.length == 0 ? ctx.getCurrentPath()
                : ctx.getPath(args[0]);
        DFSFileStatus[] items = ctx.dfs.getDFSClient().listFiles(path);
        if (items == null) {
            ctx.err.println("Could not get listing for " + path);
            return 1;
        }
        ctx.println("Found " + items.length + " items");
        int maxPathWidth = 0;
        int maxLengthWidth = 0;
        for (DFSFileStatus item: items) {
            maxPathWidth = Math.max(maxPathWidth, item.getPath().length());
            maxLengthWidth = Math.max(maxLengthWidth,
                    Long.toString(item.getContentsLength()).length());
        }
        long totalSize = 0L;
        for (DFSFileStatus item: items) {
            ctx.println(String.format("%-20s  %-" + maxPathWidth + "s %"
                    + maxLengthWidth + "d %s",
                    FORMATTER.print(item.getLastModified()), item.getPath(),
                    item.getContentsLength(),
                    "(" + StringUtils.byteDesc(item.getContentsLength()) + ")"));
            totalSize += item.getContentsLength();
        }
        ctx.println("Total " + totalSize + " bytes ("
                + StringUtils.byteDesc(totalSize) + ")");
        return 0;
    }
}

@DFSShellCommandName("nu")
final class NameUsageCommand extends DFSShellCommand {
    private static final DateTimeFormatter FORMATTER = DateTimeFormat.forPattern("MM/dd/yy HH:mm:ss");

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        String path = args.length == 0 ? ctx.getCurrentPath()
                : ctx.getPath(args[0]);
        DFSFileStatus[] items = ctx.dfs.getDFSClient().listFiles(path);
        if (items == null) {
            ctx.err.println("Could not get listing for " + path);
            return 1;
        }
        ctx.println("Found " + items.length + " items");
        int maxPathWidth = 0;
        int maxSubDirNumWidth = 0;
        int maxSubFileNumWidth = 0;
        for (DFSFileStatus item: items) {
            maxPathWidth = Math.max(maxPathWidth, item.getPath().length());
            maxSubDirNumWidth = Math.max(maxSubDirNumWidth,
                    Long.toString(item.getSubDirNumber()).length());
            maxSubFileNumWidth = Math.max(maxSubFileNumWidth,
                    Long.toString(item.getSubFileNumber()).length());
        }
        long totalDirNum = 0L;
        long totalFileNum = 0L;
        for (DFSFileStatus item: items) {
            ctx.println(String.format("%-20s  %-" + maxPathWidth + "s %"
                    + maxSubDirNumWidth + "d %s %" + maxSubFileNumWidth
                    + "d %s", FORMATTER.print(item.getLastModified()),
                    item.getPath(), item.getSubDirNumber(),
                    "(" + StringUtils.byteDesc(item.getSubDirNumber()) + ")",
                    item.getSubFileNumber(),
                    "(" + StringUtils.byteDesc(item.getSubFileNumber()) + ")"));
            totalDirNum += item.getSubDirNumber();
            totalFileNum += item.getSubFileNumber();
            if (item.isDir()) {
                totalDirNum++;
            } else {
                totalFileNum++;
            }
        }
        ctx.println("Total " + totalDirNum + " dirs ("
                + StringUtils.byteDesc(totalDirNum) + ")");
        ctx.println("Total " + totalFileNum + " files ("
                + StringUtils.byteDesc(totalFileNum) + ")");
        long totalNum = totalDirNum + totalFileNum;
        ctx.println("Total " + totalNum + " items ("
                + StringUtils.byteDesc(totalNum) + ")");
        return 0;
    }
}

@DFSShellCommandName("find")
final class FindCommand extends DFSShellCommand {
    private final Options options;

    public FindCommand() {
        options = new Options();
        options.withOption("d", "depth", "search max depth").setDefault(0);
        options.addParam("path");
    }

    private void find(Context ctx, String path, int depth) throws IOException {
        DFSFileStatus[] items = ctx.dfs.getDFSClient().listFiles(path);
        if (items == null) {
            ctx.err.println("Could not get listing for " + path);
        } else {
            ctx.println(path);
            if (depth < 0) {
                return;
            } else if (depth == 1) {
                depth = -1;
            } else if (depth >= 2) {
                depth--;
            }
            for (DFSFileStatus item: items) {
                if (item.isDir()) {
                    find(ctx, item.getPath(), depth);
                } else {
                    ctx.println(item.getPath());
                }
            }
        }
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        int depth = options.getIntOpt("d");
        if (depth < 0) {
            throw new IllegalArgumentException("negative search depth " + depth);
        }
        String path = options.getRemains().length == 0 ? ctx.getCurrentPath()
                : ctx.getPath(options.getRemains()[0]);
        find(ctx, path, depth);
        return 0;
    }
}

@DFSShellCommandName("cat")
final class CatCommand extends DFSShellCommand {
    private final Options options;

    public CatCommand() {
        options = new Options();
        options.addParam("file").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        DFSInputStream in = ctx.dfs.getDFSClient().open(path, 0);
        try {
            byte[] buf = new byte[4096];
            for (int len; (len = in.read(buf)) != -1;) {
                ctx.out.write(buf, 0, len);
            }
            ctx.out.flush();
        } finally {
            ReadWriteUtils.safeClose(in);
        }
        return 0;
    }
}

@DFSShellCommandName("mv")
final class RenameCommand extends DFSShellCommand {
    private final Options options;

    public RenameCommand() {
        options = new Options();
        options.addParam("src").addParam("dst").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String src = ctx.getPath(options.getRemains()[0]);
        String dst = ctx.getPath(options.getRemains()[1]);
        ctx.dfs.getDFSClient().rename(src, dst, true);
        return 0;
    }
}

@DFSShellCommandName("cp")
final class CopyCommand extends DFSShellCommand {
    private final Options options;

    public CopyCommand() {
        options = new Options();
        options.addParam("src").addParam("dst").setMinimalParamCount(2);
    }

    private final byte[] buf = new byte[FileSystem.DEFAULT_READ_BUFFER_SIZE];

    private void copy(Context ctx, DFSFileStatus src, String dst)
            throws IOException {
        DFSInputStream in = null;
        DFSOutputStream out = null;
        try {
            in = ctx.dfs.getDFSClient().open(src.getPath(), 0);
            out = ctx.dfs.getDFSClient().create(dst, true, false, 0,
                    FSConstants.NUM_REPLICAS_INHERITED,
                    (int) ctx.dfs.getBlockSize(), src.getPermission());
            for (int read; (read = in.read(buf)) > 0;) {
                out.write(buf, 0, read);
            }
        } finally {
            ReadWriteUtils.safeClose(in);
            ReadWriteUtils.safeClose(out);
        }
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String src = ctx.getPath(options.getRemains()[0]);
        DFSFileStatus[] items;
        if (isWildcard(src)) {
            items = filterWithWildcard(ctx.dfs, src);
        } else {
            DFSFileStatus item = ctx.dfs.getDFSClient().getFileStatus(src);
            if (item != null) {
                items = new DFSFileStatus[] {
                    item
                };
            } else {
                items = null;
            }
        }
        if (items == null || items.length == 0) {
            ctx.err.println(src + ": file does not exist.");
            return 1;
        }
        String dst = ctx.getPath(options.getRemains()[1]);
        DFSFileStatus dstStatus = ctx.dfs.getDFSClient().getFileStatus(dst);
        if (items.length == 1) {
            if (dstStatus != null && dstStatus.isDir()) {
                copy(ctx, items[0],
                        dst + DistributedFileSystem.FILE_SEPARATOR_CHAR
                                + items[0].getName());
            } else {
                copy(ctx, items[0], dst);
            }
        } else {
            if (dstStatus == null || !dstStatus.isDir()) {
                ctx.err.println(dst
                        + ": specified destination directory does not exist.");
                return 2;
            }
            for (DFSFileStatus item: items) {
                copy(ctx, item, dst + DistributedFileSystem.FILE_SEPARATOR_CHAR
                        + item.getName());
            }
        }
        return 0;
    }
}

@DFSShellCommandName("ln")
final class LinkCommand extends DFSShellCommand {
    private final Options options;

    public LinkCommand() {
        options = new Options();
        options.addParam("src").addParam("dst").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String src = ctx.getPath(options.getRemains()[0]);
        String dst = ctx.getPath(options.getRemains()[1]);
        ctx.dfs.getDFSClient().link(src, dst);
        return 0;
    }
}

@DFSShellCommandName("rm")
final class RemoveCommand extends DFSShellCommand {

    private final Options options;

    public RemoveCommand() {
        options = new Options();
        options.withSharedOption("r",
                "delete the src directory and its contents recursively");
        options.withSharedOption("f", "delete the src directly without prompt");
        options.withSharedOption("p", "delete the src permanently");
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        boolean recursively = options.isOptSet("r");
        boolean forcely = options.isOptSet("f");
        boolean permanently = options.isOptSet("p");
        String path = ctx.getPath(options.getRemains()[0]);
        DFSFileStatus[] files;
        if (isWildcard(path)) {
            files = filterWithWildcard(ctx.dfs, path);
        } else {
            DFSFileStatus file = ctx.dfs.getDFSClient().getFileStatus(path);
            if (file != null) {
                files = new DFSFileStatus[] {
                    file
                };
            } else {
                files = null;
            }
        }
        if (files == null || files.length == 0) {
            return 1;
        }
        ctx.println("The following files/directories will be deleted:");
        for (DFSFileStatus file: files) {
            ctx.println("\t" + file.getPath());
        }
        ctx.println("Total " + files.length + " items.");
        if (!forcely) {
            ctx.println();
            String yes = ctx.readLine("Are you sure you want to proceed?"
                    + " Input ``YES'' to continue:");
            if (!"YES".equals(yes)) {
                ctx.println("Action cancelled!");
                return 2;
            }
        }
        ctx.println("Deleting " + files.length + " items"
                + (permanently ? " permanently." : "."));
        for (DFSFileStatus file: files) {
            if (permanently) {
                ctx.print("Deleting " + file.getPath() + " ... ");
                ctx.flush();
            } else {
                ctx.print("Trashing " + file.getPath() + " ... ");
                ctx.flush();
            }
            try {
                ctx.dfs.getDFSClient().delete(file.getPath(), recursively,
                        permanently);
                ctx.println("Done.");
            } catch (FSException e) {
                ctx.println("Failed to delete " + file.getPath() + ": "
                        + e.getMessage());
            }
        }
        return 0;
    }
}

@DFSShellCommandName("chown")
final class ChownCommand extends DFSShellCommand {
    private final Options options;

    public ChownCommand() {
        options = new Options();
        options.withSharedOption("r", "recursively");
        options.addParam("owner").addParam("group").addParam("path").setMinimalParamCount(
                3);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        boolean recursive = options.isOptSet("r");
        String owner = options.getRemains()[0];
        String group = options.getRemains()[1];
        String path = ctx.getPath(options.getRemains()[2]);
        ctx.dfs.getDFSClient().setOwner(path, recursive, owner, group);
        return 0;
    }
}

@DFSShellCommandName("chmod")
final class ChmodCommand extends DFSShellCommand {
    private final Options options;

    public ChmodCommand() {
        options = new Options();
        options.withSharedOption("r", "recursively");
        options.addParam("permission").addParam("path").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        boolean recursive = options.isOptSet("r");
        int mode = Integer.parseInt(options.getRemains()[0], 8) & (00777);
        FsPermission permission = new FsPermission(mode);
        String path = ctx.getPath(options.getRemains()[1]);
        ctx.dfs.getDFSClient().setPermission(path, recursive, permission);
        return 0;
    }
}

@DFSShellCommandName("setreplication")
final class SetReplicationCommand extends DFSShellCommand {
    private final Options options;

    public SetReplicationCommand() {
        options = new Options();
        options.withSharedOption("r", "recursively");
        options.addParam("path").addParam("rep").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        boolean recursive = options.isOptSet("r");
        String path = ctx.getPath(options.getRemains()[0]);
        int replication = Integer.parseInt(options.getRemains()[1]);
        ctx.dfs.getDFSClient().setReplication(path, replication, recursive);
        return 0;
    }
}

@DFSShellCommandName("getreplication")
final class GetReplicationCommand extends DFSShellCommand {
    private final Options options;

    public GetReplicationCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        ctx.println(Integer.toString(ctx.dfs.getDFSClient().getReplication(path)));
        return 0;
    }
}

@DFSShellCommandName("recover")
final class RecoverCommand extends DFSShellCommand {
    private final Options options;

    public RecoverCommand() {
        options = new Options();
        options.addParam("trash").addParam("dst").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String trash = ctx.getPath(options.getRemains()[0]);
        String dst = ctx.getPath(options.getRemains()[1]);
        ctx.dfs.getDFSClient().recoverTrash(trash, dst);
        return 0;
    }
}

@DFSShellCommandName("rcvstate")
final class IsRcvCommand extends DFSShellCommand {
    private final Options options;

    public IsRcvCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        if (ctx.dfs.getDFSClient().isRecoverable(path)) {
            ctx.println(path + " is recoverable.");
        } else {
            ctx.println(path + " is NOT recoverable.");
        }
        return 0;
    }
}

@DFSShellCommandName("protectstate")
final class IsProtectCommand extends DFSShellCommand {
    private final Options options;

    public IsProtectCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        if (ctx.dfs.getDFSClient().isProtect(path)) {
            ctx.println(path + " is protected.");
        } else {
            ctx.println(path + " is NOT protected.");
        }
        return 0;
    }
}

@DFSShellCommandName("getspacequota")
final class GetSpaceQuotaCommand extends DFSShellCommand {
    private final Options options;

    public GetSpaceQuotaCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        long quota = ctx.dfs.getDFSClient().getSpaceQuota(path);
        if (quota == 0) {
            ctx.println("Space quota not set.");
        } else {
            ctx.println("Space quota of " + path + " is " + quota + "("
                    + StringUtils.byteDesc(quota) + ").");
        }
        return 0;
    }
}

@DFSShellCommandName("getnamequota")
final class GetNameQuotaCommand extends DFSShellCommand {
    private final Options options;

    public GetNameQuotaCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        long quota = ctx.dfs.getDFSClient().getNameQuota(path);
        if (quota == 0) {
            ctx.println("Name quota not set.");
        } else {
            ctx.println("Name quota of " + path + " is " + quota + "("
                    + StringUtils.byteDesc(quota) + ").");
        }
        return 0;
    }
}

@DFSShellCommandName("put")
final class PutCommand extends DFSShellCommand {
    private final Options options;

    public PutCommand() {
        options = new Options();
        options.addParam("localsrc").addParam("dst").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String src = options.getRemains()[0];
        String dst = options.getRemains().length == 1 ? new File(src).getName()
                : options.getRemains()[1];
        ctx.dfs.copyFromLocalFile(new File(src), new Path(ctx.getPath(dst)));
        return 0;
    }
}

@DFSShellCommandName("get")
final class GetCommand extends DFSShellCommand {
    private final Options options;

    public GetCommand() {
        options = new Options();
        options.addParam("localsrc").addParam("dst").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String src = ctx.getPath(options.getRemains()[0]);
        File dst = options.getRemains().length == 1 ? new File(new File(
                options.getRemains()[0]).getName()) : new File(
                options.getRemains()[1]);
        ctx.dfs.copyToLocalFile(new Path(src), dst);
        return 0;
    }
}

@DFSShellCommandName("mput")
final class MultiPutCommand extends DFSShellCommand {
    private final Options options;

    public MultiPutCommand() {
        options = new Options();
        options.addParam("pattern").addParam("dst").setMinimalParamCount(1);
    }

    private File[] filterWithWildcard(String pattern) {
        int lastSlash = Math.max(pattern.lastIndexOf(File.separatorChar),
                pattern.lastIndexOf(DistributedFileSystem.FILE_SEPARATOR_CHAR));
        String path = pattern.substring(0, lastSlash);
        WildCardFilter filter = new WildCardFilter(
                pattern.substring(lastSlash + 1));
        return new File(path).listFiles(filter);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String pattern = options.getRemains()[0];
        String dstDir = options.getRemains().length > 1 ? ctx.getPath(options.getRemains()[1])
                : ctx.getCurrentPath();
        File[] items;
        if (isWildcard(pattern)) {
            items = filterWithWildcard(pattern);
        } else {
            File item = new File(pattern);
            if (item.exists()) {
                items = new File[] {
                    item
                };
            } else {
                items = null;
            }
        }
        if (items == null || items.length == 0) {
            ctx.err.println(pattern + ": file does not exist.");
            return 1;
        }
        for (File item: items) {
            if (item.isDirectory()) {
                ctx.println(item.getAbsolutePath()
                        + " is a directory. Skipping.");
            } else {
                ctx.println("Uploading " + item.getAbsolutePath());
                ctx.dfs.copyFromLocalFile(item,
                        new Path(dstDir, item.getName()));
            }
        }
        return 0;
    }
}

@DFSShellCommandName("mget")
final class MultiGetCommand extends DFSShellCommand {
    private final Options options;

    public MultiGetCommand() {
        options = new Options();
        options.addParam("pattern").addParam("dst").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String pattern = ctx.getPath(options.getRemains()[0]);
        String dstDir = options.getRemains().length > 1 ? options.getRemains()[1]
                : ".";
        DFSFileStatus[] items;
        if (isWildcard(pattern)) {
            items = filterWithWildcard(ctx.dfs, pattern);
        } else {
            DFSFileStatus item = ctx.dfs.getDFSClient().getFileStatus(pattern);
            if (item != null) {
                items = new DFSFileStatus[] {
                    item
                };
            } else {
                items = null;
            }
        }
        if (items == null || items.length == 0) {
            ctx.err.println(pattern + ": file does not exist.");
            return 1;
        }
        for (DFSFileStatus item: items) {
            if (item.isDir()) {
                ctx.println(item.getPath() + " is a directory. Skipping.");
            } else {
                ctx.println("Downloading " + item.getPath());
                ctx.dfs.copyToLocalFile(new Path(item.getPath()), new File(
                        dstDir, item.getName()));
            }
        }
        return 0;
    }
}

@DFSShellCommandName("mkdir")
final class MkdirCommand extends DFSShellCommand {
    private final Options options;

    public MkdirCommand() {
        options = new Options();
        options.withSharedOption("n", "nrep", "replication number").setDefault(
                FSConstants.NUM_REPLICAS_INHERITED);
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        int replication = options.getIntOpt("n");
        String path = ctx.getPath(options.getRemains()[0]);
        ctx.dfs.getDFSClient().mkdirs(path, replication,
                ctx.dfs.getDefaultPermission());
        return 0;
    }
}

@DFSShellCommandName("mirror")
final class MirrorCommand extends DFSShellCommand {
    private final Options options;

    public MirrorCommand() {
        options = new Options();
        options.withSharedOption("R", "reverse");
        options.addParam("dir").addParam("dst").setMinimalParamCount(1);
    }

    private void mirror(Context ctx, LocalFileSystem lfs, Path src, Path dst,
            boolean reverse) throws IOException {
        FileInfo[] files;
        if (reverse) {
            files = lfs.listFiles(src);
            ctx.dfs.mkdirs(dst);
        } else {
            files = ctx.dfs.listFiles(src);
            lfs.mkdirs(dst);
        }
        for (FileInfo file: files) {
            if (file.isDir()) {
                mirror(ctx, lfs, file.getPath(),
                        dst.cat(file.getPath().getName()), reverse);
            } else {
                if (reverse) {
                    ctx.println("Uploading "
                            + file.getPath().asFile().getAbsolutePath());
                    ctx.dfs.copyFromLocalFile(file.getPath().asFile(),
                            dst.cat(file.getPath().getName()));
                } else {
                    ctx.println("Downloading "
                            + file.getPath().getAbsolutePath());
                    ctx.dfs.copyToLocalFile(file.getPath(),
                            new File(dst.asFile(), file.getPath().getName()));
                }
            }
        }
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        boolean reverse = options.isOptSet("R");
        Path src;
        if (reverse) {
            src = new Path(options.getRemains()[0]);
        } else {
            src = new Path(ctx.getPath(options.getRemains()[0]));
        }
        Path dst;
        if (options.getRemains().length > 1) {
            if (reverse) {
                dst = new Path(options.getRemains()[1]);
            } else {
                dst = new Path(ctx.getPath(options.getRemains()[1]));
            }
        } else {
            if (reverse) {
                dst = new Path(ctx.getPath(src.getName()));
            } else {
                dst = new Path(src.getName());
            }
        }
        mirror(ctx, new LocalFileSystem(), src, dst, reverse);
        return 0;
    }
}

@DFSShellCommandName("lockstate")
final class LockStateCommand extends DFSShellCommand {
    private final Options options;

    public LockStateCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        ctx.println(ctx.dfs.getDFSClient().lockState(options.getRemains()[0]));
        return 0;
    }
}

@DFSShellCommandName("blkinfo")
final class BlockInfoCommand extends DFSShellCommand {
    private final Options options;

    public BlockInfoCommand() {
        options = new Options();
        options.addParam("file").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String file = ctx.getPath(options.getRemains()[0]);
        BlockSizeLocationWithDataPath[] blocks = ctx.dfs.getDFSClient().getFileBlockLocations(
                file);
        if (blocks == null) {
            ctx.err.println("Cound not get block info of " + file);
            return 1;
        }
        ctx.println("Blocks info for file: " + file);
        for (int i = 0; i < blocks.length; i++) {
            String[] nodes = blocks[i].getLocations();
            long length = blocks[i].getLen();
            ctx.println();
            ctx.println("Block " + blocks[i].getBlock() + " contains " + length
                    + " bytes (" + StringUtils.byteDesc(length) + ") data");
            ctx.println("Machines containing this block:");
            if (nodes.length == 0) {
                ctx.println("BLOCK MISSED!");
                continue;
            }
            for (String node: nodes) {
                ctx.println("\t" + node);
            }
        }
        return 0;
    }
}

@DFSShellCommandName("checkfile")
final class CheckFileCommand extends DFSShellCommand {

    private static final Method VERIFY_BLOCK_METHOD;

    static {
        try {
            VERIFY_BLOCK_METHOD = IClientProtocolV3.class.getMethod(
                    "verifyBlock", String.class, long.class);
        } catch (SecurityException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    private final Options options;

    public CheckFileCommand() {
        options = new Options();
        options.addParam("file").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String file = ctx.getPath(options.getRemains()[0]);
        BlockSizeLocationWithDataPath[] blocks = ctx.dfs.getDFSClient().getFileBlockLocations(
                file);
        NameNodeWatcher nameNodeWatcher = ctx.dfs.getDFSClient().getNameNodeWatcher();
        String clientName = ctx.dfs.getDFSClient().getClientName();
        List<Pair<BlockSizeLocationWithDataPath, Future<BlockVerifyResult>>> results = new ArrayList<Pair<BlockSizeLocationWithDataPath, Future<BlockVerifyResult>>>();
        for (BlockSizeLocationWithDataPath block: blocks) {
            Future<BlockVerifyResult> future = RPC.asyncInvoke(
                    nameNodeWatcher.getNameNode(), VERIFY_BLOCK_METHOD,
                    clientName, block.getBlock());
            results.add(new Pair<BlockSizeLocationWithDataPath, Future<BlockVerifyResult>>(
                    block, future));
        }
        for (Pair<BlockSizeLocationWithDataPath, Future<BlockVerifyResult>> pair: results) {
            BlockVerifyResult result;
            try {
                result = pair.getSecond().get();
            } catch (InterruptedException e) {
                ctx.println("Check " + pair.getFirst().getBlock() + " failed");
                e.printStackTrace(ctx.err);
                continue;
            } catch (ExecutionException e) {
                ctx.println("Check " + pair.getFirst().getBlock() + " failed");
                e.printStackTrace(ctx.err);
                continue;
            }
            ctx.println("BLOCK " + pair.getFirst().getBlock() + ", LENGTH "
                    + pair.getFirst().getLen() + "("
                    + StringUtils.byteDesc(pair.getFirst().getLen()) + "): ");
            ctx.println("\tERROR: " + (result.isError() ? "YES" : "NO")
                    + ", FIXED: " + (result.isFixed() ? "YES" : "NO"));
            for (Map.Entry<String, BlockCheckResult> entry: result.getResults().entrySet()) {
                ctx.println("\t" + entry.getKey() + ": " + entry.getValue());
            }
        }
        return 0;
    }
}

@DFSShellCommandName("checkblock")
final class CheckBlockCommand extends DFSShellCommand {

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException();
        }
        long block = Long.parseLong(args[0]);
        BlockVerifyResult result = ctx.dfs.getDFSClient().verifyBlock(block);
        if (result == null) {
            ctx.println(null);
        } else {
            ctx.println(result.toString());
        }
        return 0;
    }
}

@DFSShellCommandName("fsck")
final class FsckCommand extends DFSShellCommand {
    private final Options options = new Options();

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String reportFile = ctx.dfs.getDFSClient().fsck();
        InetSocketAddress addr = ctx.dfs.getDFSClient().getNameNodeAddr();
        if (addr != null) {
            ctx.println("The report file can be found in " + reportFile
                    + " on " + addr.getHostName());
        } else {
            ctx.println("The report file can be found in " + reportFile
                    + " on namenode");
        }
        return 0;
    }
}

@DFSShellCommandName("setsvrready")
final class SetSvrReadyCommand extends DFSShellCommand {
    private final Options options;

    public SetSvrReadyCommand() {
        options = new Options();
        options.addParam("host:port");
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        if (options.getRemains().length == 0) {
            ctx.dfs.getDFSClient().setReady();
        } else {
            String[] ss = options.getRemains()[0].split(":");
            IClientProtocolV3 proxy = RPC.getProxy(IClientProtocolV3.class,
                    new InetSocketAddress(ss[0], Integer.parseInt(ss[1])),
                    FSConstants.CLIENT_RPC_DOMAIN, DFSClientUsername.username,
                    0);
            try {
                proxy.setReady(ctx.dfs.getDFSClient().getClientName());
            } finally {
                RPC.close(proxy);
            }
        }
        return 0;
    }
}

@DFSShellCommandName("setspacequota")
final class SetSpaceQuotaCommand extends DFSShellCommand {
    private final Options options;

    public SetSpaceQuotaCommand() {
        options = new Options();
        options.addParam("dir").addParam("quota").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String dir = ctx.getPath(options.getRemains()[0]);
        long quota = Long.parseLong(options.getRemains()[1]);
        ctx.dfs.getDFSClient().setSpaceQuota(dir, quota);
        return 0;
    }
}

@DFSShellCommandName("setnamequota")
final class SetNameQuotaCommand extends DFSShellCommand {
    private final Options options;

    public SetNameQuotaCommand() {
        options = new Options();
        options.addParam("dir").addParam("quota").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String dir = ctx.getPath(options.getRemains()[0]);
        long quota = Long.parseLong(options.getRemains()[1]);
        ctx.dfs.getDFSClient().setNameQuota(dir, quota);
        return 0;
    }
}

@DFSShellCommandName("setrcv")
final class SetRcvCommand extends DFSShellCommand {
    private final Options options;

    public SetRcvCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        ctx.dfs.getDFSClient().setRecoverable(path, true);
        return 0;
    }
}

@DFSShellCommandName("unsetrcv")
final class UnsetRcvCommand extends DFSShellCommand {
    private final Options options;

    public UnsetRcvCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        ctx.dfs.getDFSClient().setRecoverable(path, false);
        return 0;
    }
}

@DFSShellCommandName("protect")
final class ProtectCommand extends DFSShellCommand {
    private final Options options;

    public ProtectCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        ctx.dfs.getDFSClient().setProtect(path, true);
        return 0;
    }
}

@DFSShellCommandName("unprotect")
final class UnprotectCommand extends DFSShellCommand {
    private final Options options;

    public UnprotectCommand() {
        options = new Options();
        options.addParam("path").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String path = ctx.getPath(options.getRemains()[0]);
        ctx.dfs.getDFSClient().setProtect(path, false);
        return 0;
    }
}

@DFSShellCommandName("computecontentslengthandsubitemnum")
final class ComputeContentsLengthAndSubItemNumCommand extends DFSShellCommand {

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        ctx.dfs.getDFSClient().computeContentsLengthAndSubItemNum();
        return 0;
    }
}

@DFSShellCommandName("removetrash")
final class RemoveTrashCommand extends DFSShellCommand {
    private final Options options;

    public RemoveTrashCommand() {
        options = new Options();
        options.addParam("trash").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String trash = ctx.getPath(options.getRemains()[0]);
        DFSFileStatus[] files;
        if (isWildcard(trash)) {
            files = filterWithWildcard(ctx.dfs, trash);
        } else {
            DFSFileStatus file = ctx.dfs.getDFSClient().getFileStatus(trash);
            if (file != null) {
                files = new DFSFileStatus[] {
                    file
                };
            } else {
                files = null;
            }
        }
        if (files == null || files.length == 0) {
            return 1;
        }
        ctx.println("The following files/directories will be deleted:");
        for (DFSFileStatus file: files) {
            ctx.println("\t" + file.getPath());
        }
        ctx.println("Total " + files.length + " items.");
        ctx.println();
        String yes = ctx.readLine("Are you sure you want to proceed?"
                + " Input ``YES'' to continue:");
        if (!"YES".equals(yes)) {
            ctx.println("Action cancelled!");
            return 2;
        }

        ctx.println("Deleting " + files.length + " items.");
        for (DFSFileStatus file: files) {
            ctx.print("Deleting " + file.getPath() + " ... ");
            ctx.flush();
            try {
                ctx.dfs.getDFSClient().deleteTrash(file.getPath());
                ctx.println("Done.");
            } catch (FSException e) {
                ctx.println("Failed to delete " + file.getPath() + ": "
                        + e.getMessage());
            }
        }
        return 0;
    }
}

@DFSShellCommandName("groups")
final class PrintGroupsCommand extends DFSShellCommand {

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        ctx.println(ctx.dfs.getDFSClient().printGroups());
        return 0;
    }
}

@DFSShellCommandName("groupadd")
final class AddGroupCommand extends DFSShellCommand {
    private final Options options;

    public AddGroupCommand() {
        options = new Options();
        options.addParam("group").addParam("user").setMinimalParamCount(2);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String group = options.getRemains()[0];
        String user = options.getRemains()[1];
        ctx.dfs.getDFSClient().addGroupUser(group, user);
        return 0;
    }
}

@DFSShellCommandName("groupdel")
final class DeleteGroupCommand extends DFSShellCommand {
    private final Options options;

    public DeleteGroupCommand() {
        options = new Options();
        options.addParam("group").addParam("user").setMinimalParamCount(1);
    }

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        options.parse(args);
        String group = options.getRemains()[0];
        if (options.getRemains().length > 1) {
            String user = options.getRemains()[1];
            ctx.dfs.getDFSClient().removeGroupUser(group, user);
        } else {
            ctx.dfs.getDFSClient().removeGroup(group);
        }
        return 0;
    }
}

@DFSShellCommandName("dirproperties")
final class PrintDirPropertiesCommand extends DFSShellCommand {

    @Override
    public int exec(Context ctx, String[] args) throws Exception {
        ctx.println(ctx.dfs.getDFSClient().printDirProperties());
        return 0;
    }
}
