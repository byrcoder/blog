package odis.dfs.journal.qjournal.client;

import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.qjournal.IQJournalProtocol;
import odis.dfs.journal.qjournal.IQJournalProtocol.ExistResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.GetJournalStateResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.PrepareRecoveryResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.SegmentState;
import odis.dfs.journal.qjournal.RequestInfo;
import odis.dfs.journal.qjournal.server.GetJournalEditServlet;
import odis.dfs.journal.qjournal.server.JNException;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;

import org.mortbay.log.Log;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.common.util.concurrent.UncaughtExceptionHandlers;

/**
 * Channel to a remote JournalNode using Rpc. All of the calls are run on a
 * separate thread, and return {@link ListenableFuture} instances to wait for
 * their result. This allows calls to be bound together using the
 * {@link QuorumCall} class.
 * 
 * @author chenxi
 */
public class RpcLoggerChannel implements AsyncLogger {

    private ListeningExecutorService executor;

    /**
     * the rpc address of the JournalNode
     */
    private final InetSocketAddress serverAddr;

    private IQJournalProtocol journalNode;

    /**
     * the cluster id of the odfs cluster. eg. tiger:6080
     */
    private String clusterId;

    /**
     * the epoch number used to make calls to JournalNode
     */
    private long epoch = DFSConfig.INVALID_EPOCH;

    /**
     * the httpPort which JournalNode serve datas
     */
    private int httpPort = DFSConfig.INVALID_HTTP_PORT;

    /**
     * the rpc serial number to make sure rpc calls in order in rpc unexpected
     * bugs
     */
    private long rpcSerial = 0;
    
    private State state;

    public static final Factory FACTORY = new AsyncLogger.Factory() {
        @Override
        public AsyncLogger createLogger(String clusterId, InetSocketAddress addr)
                throws IllegalLoggerException {
            try {
                return new RpcLoggerChannel(clusterId, addr);
            } catch (RpcException e) {
                throw new IllegalLoggerException(
                        "Can't create logger with port " + addr.getPort(), e);
            }
        }
    };

    public RpcLoggerChannel(String clusterId, InetSocketAddress serverAddr)
            throws RpcException {
        Log.info("Creating RpcLogger for " + clusterId + " at port: "
                + serverAddr.getPort());
        this.serverAddr = serverAddr;
        this.clusterId = clusterId;
        this.journalNode = RPC.getProxy(IQJournalProtocol.class,
                this.serverAddr);
        executor = MoreExecutors.listeningDecorator(createExecutor());
        this.state = State.OK;
    }

    private synchronized RequestInfo createReqInfo() throws IllegalLoggerException {
        if (epoch <= 0) {
            throw new IllegalLoggerException("bad epoch: " + epoch);
        }
        return new RequestInfo(clusterId, epoch, rpcSerial++);
    }

    protected ExecutorService createExecutor() {
        return Executors.newSingleThreadExecutor(new ThreadFactoryBuilder()
                .setDaemon(true)
                .setNameFormat("Logger channel to " + serverAddr)
                .setUncaughtExceptionHandler(
                        UncaughtExceptionHandlers.systemExit()).build());
    }

    @Override
    public synchronized void setEpoch(long epoch) {
        this.epoch = epoch;
    }
    
    @Override
    public URL buildURLToFetchLogs(long sn) {
        if (sn <= 0) {
            throw new IllegalArgumentException("Invalid segment number: " + sn);
        }
        if (-1 == httpPort) {
            throw new IllegalStateException("HTTP port not set yet");
        }
        String path = GetJournalEditServlet.buildPath(sn);
        try {
            return new URL("http", serverAddr.getHostName(), httpPort, path);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ListenableFuture<GetJournalStateResponse> getJournalState() {
        return executor.submit(new Callable<GetJournalStateResponse>() {
            @Override
            public GetJournalStateResponse call() throws Exception {
                try {
                    GetJournalStateResponse ret = journalNode
                            .getJournalState(clusterId);
                    httpPort = ret.getHttpPort();
                    return ret;
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Long> newEpoch(final long epoch) {
        return executor.submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {
                try {
                    return journalNode.newEpoch(clusterId, epoch);
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Long> startLogSegment(final long minimumSN) {
        return executor.submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {
                try {
                    RequestInfo reqInfo = createReqInfo();
                    long res = journalNode.startLogSegment(reqInfo, minimumSN);
                    state = State.OK;
                    return res;
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Integer> journal(final long currentSN,
            final byte[] records, final int checksum) {
        return executor.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                if (State.OK != state) {
                    throw new JNException("failed this time, wait next segment");
                }
                RequestInfo reqInfo = createReqInfo();
                try {
                    return journalNode.journal(reqInfo, currentSN, records,
                            checksum);
                } catch (Exception e) {
                    if (State.OK == state) {
                        state = State.WAIT_NEXT_ROUND;
                    }
                    throw e;
                }
            }
        });
    }
    

    @Override
    public ListenableFuture<Integer> journal(final long currentSN,
            final byte[] records, final int off, final int len,
            final int checksum) {
        return executor.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                if (State.OK != state) {
                    throw new JNException("failed this time, wait next segment");
                }
                RequestInfo reqInfo = createReqInfo();
                try {
                    return journalNode.journal(reqInfo, currentSN, records,
                            off, len, checksum);
                } catch (Exception e) {
                    if (State.OK == state) {
                        state = State.WAIT_NEXT_ROUND;
                    }
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Integer> finalizeLogSegment(final long sn,
            final long logLength) {
        return executor.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                RequestInfo reqInfo = createReqInfo();
                return journalNode.finalizeLogSegment(reqInfo, sn, logLength);
            }
        });
    }

    @Override
    public ListenableFuture<PrepareRecoveryResponse> prepareRecovery(
            final long sn) {
        return executor.submit(new Callable<PrepareRecoveryResponse>() {
            @Override
            public PrepareRecoveryResponse call() throws Exception {
                RequestInfo reqInfo = createReqInfo();
                try {
                    return journalNode.prepareRecovery(reqInfo, sn);
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Long> acceptRecovery(
            final SegmentState stateToAccept, final String fromUrl) {
        return executor.submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {
                RequestInfo reqInfo = createReqInfo();
                try {
                    return journalNode.acceptRecovery(reqInfo, stateToAccept,
                            fromUrl);
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Long> deleteSegmentBefore(final long sn) {
        return executor.submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {
                try {
                    return journalNode.deleteSegmentBefore(sn);
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }
    
    @Override
    public ListenableFuture<ExistResponse> exist(final long sn) {
        return executor.submit(new Callable<ExistResponse>() {
            @Override
            public ExistResponse call() throws Exception {
                try {
                    ExistResponse res = journalNode.exist(sn);
                    httpPort = res.getHttpPort();
                    return res;
                } catch (Exception e) {
                    state = State.ERROR;
                    throw e;
                }
            }
        });
    }

    @Override
    public ListenableFuture<Long> maxFinalizedSegmentSN() {
        return executor.submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {
                return journalNode.maxFinalizedSegmentSN();
            }
        });
    }
    
    @Override
    public void close() {
        this.executor.shutdownNow();
    }

    @Override
    public void waitForAllPendingCalls() throws InterruptedException {
        try {
            executor.submit(new Runnable() {
                @Override
                public void run() {}
            }).get();
        } catch (ExecutionException e) {
            // This can't happen!
            throw new AssertionError(e);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{RpcLogger: ");
        sb.append("[serverAddr=" + this.serverAddr.getHostName());
        sb.append("], [rpcPort=" + this.serverAddr.getPort());
        sb.append("], [httpPort=" + this.httpPort);
        sb.append("], [epoch=" + this.epoch);
        sb.append("], [state=" + this.state);
        sb.append("]}");
        return sb.toString();
    }

    @Override
    public State getState() {
        return state;
    }
}
