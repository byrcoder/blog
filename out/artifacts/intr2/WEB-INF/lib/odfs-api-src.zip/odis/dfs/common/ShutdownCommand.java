/**
 * @(#)ShutdownCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Logger;

import odis.dfs.datanode.DataNode;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.LogFormatter;

/**
 * Tell the datanode you should shutdown for the given reason.
 * 
 * @author zhangduo
 */
public class ShutdownCommand extends DataNodeCommand {

    private static final Logger LOG = LogFormatter.getLogger(ShutdownCommand.class);

    private String reason;

    public ShutdownCommand() {}

    public ShutdownCommand(String reason) {
        this.reason = reason;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, reason);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        reason = StringWritable.readString(in);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        ShutdownCommand that = (ShutdownCommand) value;
        reason = that.reason;
        return this;
    }

    @Override
    public void execute(DataNode dataNode) {
        LOG.info("Namenode told " + dataNode.getFullName()
                + " to shutdown because of " + reason + ". Exiting ...");
        System.exit(1);
    }

}
