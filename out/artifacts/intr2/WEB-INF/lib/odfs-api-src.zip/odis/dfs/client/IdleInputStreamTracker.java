/**
 * @(#)IdleInputStreamTracker.java, 2012-12-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import odis.io.FSInputStream;

import org.apache.commons.lang.mutable.MutableLong;

import toolbox.misc.LogFormatter;

/**
 * Tracks all DFSInputStream and close the BlockStream of idle DFSInputStreams,
 * in order to spare DataNode threads that otherwise will be occupied by
 * long-term-but-idle-most-of-the-time DFSInputStreams.
 * 
 * @author zhangkun, zhangduo
 */
class IdleInputStreamTracker {

    private static final Logger LOG = LogFormatter.getLogger(IdleInputStreamTracker.class);

    private final LinkedHashMap<FSInputStream, MutableLong> ttl = new LinkedHashMap<FSInputStream, MutableLong>(
            16, 0.75f, true);

    private final long maxIdleTime;

    private final Future<?> checkIdleTask;

    private void checkIdle() {
        List<FSInputStream> toBeClosed = new ArrayList<FSInputStream>();
        synchronized (this) {
            long currentTime = System.currentTimeMillis();
            for (Iterator<Map.Entry<FSInputStream, MutableLong>> iter = ttl.entrySet().iterator(); iter.hasNext();) {
                Map.Entry<FSInputStream, MutableLong> entry = iter.next();
                if (entry.getValue().longValue() > currentTime) {
                    break;
                }
                toBeClosed.add(entry.getKey());
                iter.remove();
            }
        }
        for (FSInputStream in: toBeClosed) {
            LOG.info("Mark " + in + " as idle");
            in.setIdleHint();
        }
    }

    IdleInputStreamTracker(ScheduledExecutorService taskPool, long maxIdleTime) {
        this.maxIdleTime = maxIdleTime;
        long checkInterval = maxIdleTime / 10;
        if (checkInterval < 1000) {
            checkInterval = 1000;
        }
        checkIdleTask = taskPool.scheduleAtFixedRate(new Runnable() {

            @Override
            public void run() {
                checkIdle();
            }
        }, checkInterval, checkInterval, TimeUnit.MILLISECONDS);
    }

    synchronized void updateTTL(FSInputStream in) {
        MutableLong expireTime = ttl.get(in);
        if (expireTime == null) {
            expireTime = new MutableLong();
            ttl.put(in, expireTime);
        }
        expireTime.setValue(System.currentTimeMillis() + maxIdleTime);
    }

    synchronized void remove(FSInputStream in) {
        ttl.remove(in);
    }

    void shutdown() {
        checkIdleTask.cancel(true);
    }
}
