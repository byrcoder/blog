package odis.dfs.namenode;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.util.DfsUtils;
import odis.io.CDataOutputStream;
import odis.io.ReadWriteUtils;
import odis.util.ChecksumOutputStream;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

public class FSImage5To6Transfer {
    private static Logger LOG = LogFormatter
            .getLogger(FSImage5To6Transfer.class);

    public static void transfer(File imageFile)
            throws IOException, SecurityException, NoSuchFieldException,
            IllegalArgumentException, IllegalAccessException {
        Adler32 checker = new Adler32();
        File checksumFile = new File(imageFile.getAbsolutePath()
                + ImageManager.CHECKSUM_FILE_SUFFIX);
        int adler32 = DfsUtils.readChecksum(checksumFile);
        Field adler32Value = Adler32.class.getDeclaredField("adler");
        adler32Value.setAccessible(true);
        adler32Value.set(checker, adler32);
        LOG.info("Image file checksum=" + adler32 + ", checker="
                + (int) checker.getValue());

        FileOutputStream rawOut = null;
        ChecksumOutputStream checksumOut = null;
        CDataOutputStream out = null;
        try {
            rawOut = new FileOutputStream(imageFile, true);
            
            checksumOut = new ChecksumOutputStream(rawOut);
            Field checkerFiled = ChecksumOutputStream.class.getDeclaredField("checker");
            checkerFiled.setAccessible(true);
            checkerFiled.set(checksumOut, checker);

            out = new CDataOutputStream(new BufferedOutputStream(checksumOut));
            out.writeVInt(0);
            out.writeVInt(0);
            out.writeLong(0);
            out.flush();
            rawOut.getFD().sync();
        } finally {
            ReadWriteUtils.safeClose(out);
            ReadWriteUtils.safeClose(checksumOut);
            ReadWriteUtils.safeClose(rawOut);
        }

        adler32 = (int) checksumOut.getChecksum();
        LOG.info("Done saving image to file " + imageFile.getAbsolutePath()
                + ", file size = " + imageFile.length() + ", adler32 = "
                + HexString.intToPaddedHex(adler32));

        DfsUtils.writeChecksum(checksumFile, adler32);
        LOG.info("Done saving checksum to file "
                + checksumFile.getAbsolutePath() + ", adler32 = "
                + HexString.intToPaddedHex(adler32));
    }

    public static void main(String[] args) throws IOException,
            SecurityException, IllegalArgumentException, NoSuchFieldException,
            IllegalAccessException {
        if (args.length < 1) {
            System.out.println("Usage: [imageFile]");
            System.out.println("!!Note: transfered image file is the same as imageFile");
            System.out
                    .println("eg: ./bin/odis.sh run odis.dfs.namenode.FSImage5To6Transfer"
                            + " /disk2/odfs/namenode/image/fsimage.256");
            System.exit(1);
        }
        File imageFile = new File(args[0]);
        FSImage5To6Transfer.transfer(imageFile);
    }
}
