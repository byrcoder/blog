package odis.dfs.journal.qjournal.client;

import java.net.InetSocketAddress;
import java.net.URL;

import odis.dfs.journal.qjournal.IQJournalProtocol.ExistResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.GetJournalStateResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.PrepareRecoveryResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.SegmentState;

import com.google.common.util.concurrent.ListenableFuture;

/**
 * Interface for a remote log which is only communicated with asynchronously.
 * This is a async wrapper of calling JournalNode by IQJournalProtocol
 * <ul>
 * <li>All methods return {@link ListenableFuture}s instead of synchronous
 * objects.</li>
 * </ul>
 * This class is a wraper for IQJournalProtocal to make quorum call
 * 
 * @author chenxi
 */
public interface AsyncLogger {
    static enum State {
        OK, // start log segment ok
        WAIT_NEXT_ROUND, // journal call failed
        ERROR, // if rpc call failed(except journal & finalizeSegment)
    }

    interface Factory {
        AsyncLogger createLogger(String clusterId, InetSocketAddress addr)
                throws IllegalLoggerException;
    }

    /**
     * Begin writing a new log segment.
     * 
     * @param minimumSN
     *            the new segment's SN should be larger than or equal to the
     *            minimumSN
     */
    // public ListenableFuture<Void> startLogSegment(long minimumSN);

    /**
     * Set the epoch number used for all future calls.
     */
    public void setEpoch(long e);
    
    /**
     * Build an HTTP URL to fetch the log segment with the given sn.
     */
    public URL buildURLToFetchLogs(long sn);
    
    public void close();
    
    public State getState();
    

    /**
     * @return the state of the last epoch on the target node.
     */
    public ListenableFuture<GetJournalStateResponse> getJournalState();

    public ListenableFuture<Long> newEpoch(long epoch);

    public ListenableFuture<Long> startLogSegment(long minimumSN);

    public ListenableFuture<Integer> journal(long currentSN, byte[] records,
            int checksum);
    
    public ListenableFuture<Integer> journal(long currentSN, byte[] records,
            int off, int len, int checksum);

    public ListenableFuture<Integer> finalizeLogSegment(long sn, long logLength);

    public ListenableFuture<PrepareRecoveryResponse> prepareRecovery(long sn);

    public ListenableFuture<Long> acceptRecovery(SegmentState stateToAccept,
            String fromUrl);
    
    public ListenableFuture<Long> deleteSegmentBefore(long sn);
    
    public ListenableFuture<ExistResponse> exist(long sn);
    
    public ListenableFuture<Long> maxFinalizedSegmentSN();
    
    public void waitForAllPendingCalls() throws InterruptedException;
}
