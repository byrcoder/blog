/**
 * @(#)IClientProtocol2.java, 2012-2-2. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.IOException;

import odis.io.LockStateException;
import odis.io.NamedPermitException;
import odis.io.permission.FsPermission;
import odis.rpc2.RpcException;

/**
 * RPC interface used by {@link DFSClient} to talk to the namenode, for hdfs
 * adaptor
 * 
 * @author guodd
 */
@Deprecated
public interface IClientProtocolV2 {

    /**
     * Get the local name (host:port) of the NameNode. It can be used to get the
     * MetricsRecord of the NameNode.
     */
    public String getLocalName() throws RpcException;

    /**
     * Returns the Computing Unit ID of this ODFS instance. The ID is assigned
     * by the config 'dfs.cuid' in NameNode's config file.
     * 
     * @return
     * @throws odis.rpc2.RpcException
     */
    public String getCUID() throws RpcException;

    /**
     * Set the service ready or not to accept requests. ONLY used for
     * management.
     */
    public void setReady(boolean ready) throws RpcException, FSException;

    /**
     * Get a set of statistics about the filesystem. Right now, only two values
     * are returned. [0] contains the total storage capacity of the system, in
     * bytes. [1] contains the available storage of the system, in bytes.
     */
    public long[] getStats() throws RpcException;

    /**
     * Get a summary of the number of blocks and total number of copies in the
     * system.
     * 
     * @throws FSException
     */
    public long[] getBlockSummary() throws RpcException, FSException;

    /**
     * Do a fsck-style consistency check of the file system, and return the path
     * to the report on NameNode
     */
    public String consistencyCheck() throws RpcException, FSException,
            IOException;

    /**
     * Schedule a consistency check for the specified block
     * 
     * @param block
     * @throws RpcException
     * @throws IOException
     */
    @Deprecated
    public void checkAndRecoverInconsistentBlock(long block)
            throws RpcException, FSException;

    /**
     * Schedule a consistency check for the specified block and return check
     * result.
     * 
     * @param block
     * @return
     * @throws RpcException
     * @throws FSException
     */
    public BlockVerifyResult verifyBlock(long block) throws RpcException,
            FSException;

    /**
     * Compute size and sub item number for all directories.
     * 
     * @throws RpcException
     * @throws FSException
     */
    public void computeContentsLengthAndSubItemNum() throws RpcException,
            FSException;

    /**
     * Create a new file. Get back block and datanode info, which describes
     * where the first block should be written.
     * 
     * @param file
     *            the full path of the file to be created
     * @param overwrite
     *            if a file with the same name already exists, overwrite=true
     *            will delete the older file before creation, overwrite=false
     *            will cause an Exception
     * @param persistent
     *            if true, the file should live even if the Namenode crashes
     *            before the client finishes writing.
     * @param blockSize
     *            the expected block size other than the default value
     * @param masked
     *            the created file masked
     * @return
     * @throws RpcException
     * @throws IOException
     * @throws FSException
     */
    public BlockLocationWithDataPath create(String file, boolean overwrite,
            boolean persistent, boolean createParent, int replication,
            int blockSize, FsPermission permission) throws RpcException,
            FSException, IOException;

    /**
     * If the client has not yet called reportWrittenBlock(), it can give up on
     * it by calling abandonBlock(). The client can then either obtain a new
     * block, or complete or abandon the file. Any partial writes to the block
     * will be garbage-collected.
     */
    public void abandonBlock(long b, String file, int blockIndex)
            throws RpcException, FSException;

    /**
     * A client that wants to write an additional block to the indicated
     * filename (which must currently be open for writing) should call
     * addBlock(). addBlock() returns block and datanode info, just like the
     * initial call to create(). A null response means the NameNode could not
     * allocate a block, and that the caller should try again.
     * 
     * @param file
     *            the file name
     * @param blockIndex
     *            the sequence number of the new block in the file (0-based)
     */
    public BlockLocationWithDataPath addBlock(String file, int blockIndex)
            throws RpcException, FSException, IOException;

    /**
     * A client that wants to abandon writing to the current file should call
     * abandonFileInProgress(). After this call, any client can call create() to
     * obtain the filename. Any blocks that have been written for the file will
     * be garbage-collected.
     */
    public void abandonFileInProgress(String file) throws RpcException,
            FSException, IOException;

    /**
     * The client is done writing data to the given filename, and would like to
     * complete it. The function returns whether the file has been closed
     * successfully. If the function returns false, the caller should try again.
     * A call to complete() will not return true until all the file's blocks
     * have been replicated the minimum number of times. Thus, DataNode failures
     * may cause a client to call complete() several times before succeeding.
     * 
     * @throws FSException
     */
    public boolean complete(String file) throws RpcException, FSException,
            IOException;

    /**
     * Client programs can cause stateful changes in the NameNode that affect
     * other clients. A client may obtain a file and neither abandon nor
     * complete it. A client might hold a series of locks that prevent other
     * clients from proceeding. Clearly, it would be bad if a client held a
     * bunch of locks that it never gave up. This can happen easily if the
     * client dies unexpectedly. So, the NameNode will revoke the locks and live
     * file-creates for clients that it thinks have died. A client tells the
     * NameNode that it is still alive by periodically calling renewLease(). If
     * a certain amount of time passes since the last call to renewLease(), the
     * NameNode assumes the client has died.
     * 
     * @param protocol
     *            version number of the protocol that the client speaks
     * @throws FSException
     *             protocol mismatch
     */
    public void renewLease(int protocol) throws RpcException, FSException;

    /**
     * This call means client have done his work and will disconnect
     * immediately.
     * <p>
     * The rpc's clientDisconnect is not reliable because it only means all the
     * connections from one client is closed. This maybe caused by network
     * error, and client will reconnect later.
     * 
     * @throws RpcException
     * @throws FSException
     */
    public void removeLease() throws RpcException, FSException;

    /**
     * Get lease update period required by this dfs.
     */
    public long getLeasePeriod() throws RpcException;

    /**
     * Check if some client is writing the given file.
     */
    public boolean isPending(String src) throws RpcException, FSException;

    /**
     * Return an array of all pending files under the given path. It also
     * removes expired records under the path from the pending list before
     * returning.
     */
    public String[] pendingFilesInDir(String path) throws RpcException,
            FSException;

    /**
     * Check whether the given file/dir exists
     */
    public boolean exists(String path) throws RpcException, FSException;

    /**
     * Open an existing file, at the given name. Returns block all blocks of the
     * file. The client will then have to contact each indicated DataNode to
     * obtain the actual data. The caller should call {@link #closeFile(String)}
     * when he has finished reading the file.
     * 
     * @return all blocks of the file
     */
    public BlockSizeLocationWithDataPath[] open(String file)
            throws RpcException, FSException;

    /**
     * The client has finished reading and wants to close the file. The namenode
     * should delete the file if there are pending deletes.
     * 
     * @throws FSException
     */
    public void closeFile(String file) throws RpcException, FSException;

    /**
     * Rename an item in the fs namespace
     */
    public boolean rename(String src, String dst) throws RpcException,
            FSException, IOException;

    /**
     * Create link named dst linked to src.
     * 
     * @param src
     * @param dst
     * @return whether link is ok
     * @throws IOException
     * @throws FSException
     */
    public boolean link(String src, String dst, boolean symbolic)
            throws RpcException, FSException, IOException;

    /**
     * Delete the path permanently or not. If permanently==true, the path will
     * be removed permanently no matter whether it's recoverable. But protected
     * paths wouldn't be removed in any case. Paths under trash can "/trash"
     * can't be removed by this method.
     */
    public boolean delete(String path, boolean recursive, boolean permanently)
            throws RpcException, FSException, IOException;

    /**
     * Recover the trash to the not-trash dst.
     */
    public boolean recoverTrash(String trash, String dst) throws RpcException,
            FSException, IOException;

    /**
     * Delete the path from trash can which means its data would be removed
     * permanently. Paths not under trash can't be removed by this method. ONLY
     * used for management.
     */
    public boolean deleteTrash(String path) throws RpcException, FSException,
            IOException;

    /**
     * Check whether the given filename is a directory or not.
     */
    public boolean isDir(String path) throws RpcException, FSException;

    /**
     * Creates a directory with specified replication number.
     * 
     * @param dir
     *            the path
     * @param replications
     *            the number of replications for all the files under this folder
     * @param permission
     * @return true if success, false otherwise.
     * @throws RpcException
     *             if an error occurs
     */
    public boolean mkdirs(String dir, int replications, FsPermission permission)
            throws RpcException, FSException, IOException;

    /**
     * Get the locations of blocks of an existing file, without opening the
     * file.
     * 
     * @param file
     * @return all blocks of the file. null if file doesn't exist
     * @throws RpcException
     * @throws IOException
     * @throws FSException
     */
    public BlockSizeLocationWithDataPath[] getFileBlockLocations(String file)
            throws RpcException, FSException;

    /**
     * Get the file status, like contentsLength, modified time and so on.
     * 
     * @param file
     * @return DFSFileInfo {link DFSFileInfo}
     * @throws RpcException
     * @throws FSException
     */
    public DFSFileStatus getFileStatus(String file) throws RpcException,
            FSException;

    /**
     * Get a listing of the indicated directory
     */
    public DFSFileStatus[] getListing(String dir) throws RpcException,
            FSException;

    /**
     * Get the desired replication number for the given file or directory
     * 
     * @param path
     * @return
     * @throws odis.rpc2.RpcException
     * @throws java.io.IOException
     */
    public int getReplicationNumber(String path) throws RpcException,
            FSException;

    /**
     * Set the desired replication number for the given file or directory.
     * 
     * @param path
     * @param replication
     *            the replication number, must be no less than 1
     * @param recursive
     *            if true, all the files and directories under the path will be
     *            affected
     * @throws odis.rpc2.RpcException
     * @throws java.io.IOException
     */
    public void setReplicationNumber(String path, int replication,
            boolean recursive) throws RpcException, FSException, IOException;

    /**
     * Set owner of a path (i.e. a file or a directory). The parameters owner
     * and group cannot both be null.
     * <p>
     * Only the original owner or admin can do this operation.
     * 
     * @param path
     * @param recursive
     * @param owner
     *            If it is null, the original owner remains unchanged.
     * @param group
     *            If it is null, the original group remains unchanged.
     */
    public void setOwner(String path, boolean recursive, String owner,
            String group) throws IOException;

    /**
     * Set permissions for an existing file/directory.
     * <p>
     * Only the owner or admin can do this operation.
     * 
     * @param path
     * @param recursive
     * @param permission
     * @throws IOException
     */
    public void setPermission(String path, boolean recursive,
            FsPermission permission) throws IOException;

    /**
     * getHints() returns a list of hostnames that store data for a specific
     * file region. It returns a set of hostnames for every block within the
     * indicated region. This function is very useful when writing code that
     * considers data-placement when performing operations. For example, the
     * MapReduce system tries to schedule tasks on the same machines as the
     * data-block the task processes.
     */
    public String[][] getHints(String file, long start, long len)
            throws RpcException, FSException, IOException;

    /**
     * Set path to be protect or not, if protect == true, the path is protected.
     * It cannot be deleted or renamed.
     */
    public void setProtect(String path, boolean protect) throws RpcException,
            FSException, IOException;

    /**
     * Check whether the given path is under protection or not.
     */
    public boolean isProtected(String path) throws RpcException;

    /**
     * Set the path to be recoverable. If recoverable==true, the directories or
     * files under the path will be put into trash can when they are deleted.
     */
    public void setRecoverable(String path, boolean recoverable)
            throws RpcException, FSException, IOException;

    /**
     * Check whether the given path is recoverable or not.
     */
    public boolean isRecoverable(String path) throws RpcException;

    /**
     * update quota of a exist directory
     * 
     * @param path
     * @param newQuotaValue
     * @param isNameQuota
     * @return
     * @throws IOException
     * @throws FSException
     */
    public boolean setQuota(String path, long newQuotaValue, boolean isNameQuota)
            throws RpcException, FSException, IOException;

    /**
     * Get quota of a exist directory
     * 
     * @param path
     * @return
     * @throws IOException
     */

    public long getQuota(String path, boolean isNameQuota) throws RpcException,
            FSException;

    /**
     * Dump dir properties to given file on namenode.
     * 
     * @return the file path on namenode.
     * @throws RpcException
     * @throws IOException
     * @throws FSException
     */
    public String dumpDirProperties() throws RpcException, IOException;

    /**
     * Add a user to a group. We will create the group if it is not exists.
     * <p>
     * Only admin can do this operation.
     * 
     * @param group
     * @param user
     * @throws RpcException
     * @throws FSException
     * @throws IOException
     */
    public void addGroupUser(String group, String user) throws RpcException,
            FSException, IOException;

    /**
     * Remove a user from a group.
     * <p>
     * Only admin can do this operation.
     * 
     * @param group
     * @param user
     * @throws RpcException
     * @throws FSException
     * @throws IOException
     */
    public void removeGroupUser(String group, String user) throws RpcException,
            FSException, IOException;

    /**
     * Remove a group. Note that we will only remove the group<->user mapping,
     * you can also see a file's group is this group(but the group permission is
     * useless because no user belongs to the group).
     * 
     * @param group
     * @throws RpcException
     * @throws FSException
     * @throws IOException
     */
    public void removeGroup(String group) throws RpcException, FSException,
            IOException;

    /**
     * Print group users.
     * 
     * @return
     * @throws RpcException
     */
    public String printGroups() throws RpcException;

    ///////////////////////////////////////
    // Lock and Permit Operation         //
    ///////////////////////////////////////

    /**
     * The client is trying to obtain a lock. Return whether the lock has been
     * seized correctly (true), or whether the client should try again (false).
     */
    public int obtainLock(String src, int lock) throws RpcException,
            IOException;

    /**
     * Print the lock state.
     * 
     * @param src
     * @return the local state string
     * @throws IOException
     */
    public String lockState(String src) throws RpcException, IOException;

    /**
     * Promote the given UPDATE_LOCK.
     * 
     * @param src
     * @return codes for file create
     * @throws IOException
     */
    public int promote(String src) throws LockStateException, RpcException,
            IOException;

    /**
     * Downgrade the given EXCLUSIVE_LOCK.
     * 
     * @param src
     * @throws IOException
     * @throws LockStateException
     */
    public void downgrade(String src) throws RpcException, IOException,
            LockStateException;

    /**
     * The client wants to release a held lock. Return whether the lock was
     * correctly released (true), or whether the client should wait and try the
     * call again (false).
     */
    public void releaseLock(String src) throws RpcException, IOException;

    /**
     * Create one named permit.
     * 
     * @param name
     * @param p
     * @param detached
     * @throws NamedPermitException
     *             thrown if the permit is perviously created or the initial
     *             value is illegal(zero or negarive)
     */
    public void createPermit(String name, int p, boolean detached)
            throws NamedPermitException, RpcException, IOException;

    /**
     * Remove one named permit.
     * 
     * @param name
     * @throws NamedPermitException
     */
    public void removePermit(String name) throws NamedPermitException,
            RpcException, IOException;

    /**
     * Acquire some permits from the named permit.
     * 
     * @param name
     * @param request
     * @return true if the request is finished, false if not
     * @throws NamedPermitException
     *             thrown if the named permit is not exist
     */
    public boolean acquirePermit(String name, int request)
            throws NamedPermitException, RpcException, IOException;

    /**
     * Release some permits into the named permit.
     * 
     * @param name
     * @param p
     */
    public void releasePermit(String name, int p) throws RpcException,
            IOException;

    /**
     * Release all the permit previously acquired.
     * 
     * @param name
     */
    public void releasePermit(String name) throws RpcException, IOException;

}
