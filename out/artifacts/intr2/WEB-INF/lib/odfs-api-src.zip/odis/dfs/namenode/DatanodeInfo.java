/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package odis.dfs.namenode;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import odis.dfs.common.BlockSize;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.INameToDataProtocol;
import odis.dfs.common.ReplicateCommand;
import odis.dfs.common.WriteChecksumCommand;
import odis.serialize.IWritable;
import toolbox.collections.Pair;
import toolbox.collections.primitive.LongArrayList;
import toolbox.collections.primitive.LongClosedHashSet;
import toolbox.collections.primitive.LongCompactHashSet;
import toolbox.collections.primitive.LongHashSet;
import toolbox.collections.primitive.LongIntegerClosedHashMap;
import toolbox.collections.primitive.LongIntegerKeyValueIterator;
import toolbox.collections.primitive.LongLongClosedHashMap;
import toolbox.collections.primitive.LongLongKeyValueIterator;

/**
 * DatanodeInfo tracks stats on a given DataNode, such as available storage
 * capacity, last update time, etc.
 * <p>
 * Implements IWritable only for compatible.
 * <p>
 * We use getAndClear for <code>toBeDeletedBlocks</code> and
 * <code>toBeReplicatedBlocks</code>, and do not have a deleteDone. Because at
 * most time, a datanode can not receive a heartbeat only when it is done, and
 * then all its blocks will be checked when it is expired. And now we have a
 * reportAllBlock method, datanode will sync with namenode every few times, so
 * all the blocks in the system could be checked eventully. For
 * replicationQueue, we need to do some load balance work, so we need a
 * pendingReplication field and a replicationDone method.
 * 
 * @author Mike Cafarella, Feng Zhou
 */
public class DatanodeInfo implements IWritable {

    public static final DatanodeInfo[] EMPTY_ARRAY = new DatanodeInfo[0];

    public static final Comparator<DatanodeInfo> HOST_PORT_COMPARATOR = new Comparator<DatanodeInfo>() {

        @Override
        public int compare(DatanodeInfo o1, DatanodeInfo o2) {
            int ret = o1.host.compareTo(o2.host);
            if (ret != 0) {
                return ret;
            }
            return o1.port < o2.port ? -1 : o1.port == o2.port ? 0 : 1;
        }
    };

    public static final Comparator<DatanodeInfo> LAST_UPDATE_COMPARATOR = new Comparator<DatanodeInfo>() {

        @Override
        public int compare(DatanodeInfo o1, DatanodeInfo o2) {
            long l1 = o1.lastUpdate;
            long l2 = o2.lastUpdate;
            return l1 < l2 ? 1 : l1 == l2 ? 0 : -1;
        }
    };

    private final String name;

    private final String host;

    private final int port;

    private final String dataDir;

    private volatile long capacity;

    private volatile long remaining;

    private volatile long lastUpdate;

    private volatile long reserved;

    private final LongClosedHashSet blocks = new LongClosedHashSet();

    private final LongIntegerClosedHashMap reservedBlocks = new LongIntegerClosedHashMap();

    private final LongLongClosedHashMap reservedTimes = new LongLongClosedHashMap();

    private final LongArrayList toBeDeletedBlocks = new LongArrayList();

    private final Map<Long, ReplicateCommand> toBeReplicatedBlocks = new LinkedHashMap<Long, ReplicateCommand>();

    private final LongArrayList forceCompleteBlocks = new LongArrayList();

    private final LongArrayList checkConsistencyBlocks = new LongArrayList();

    private final List<WriteChecksumCommand> writeChecksumBlocks = new ArrayList<WriteChecksumCommand>();

    private final INameToDataProtocol proxy;

    public DatanodeInfo(String datanodeFullName, long capacity, long remaining,
            INameToDataProtocol proxy) {
        this.name = getDatanodeNameFromFullName(datanodeFullName);
        this.host = getHostFromFullName(datanodeFullName);
        this.port = getPortFromFullName(datanodeFullName);
        this.dataDir = getDirFromFullName(datanodeFullName);
        this.capacity = capacity;
        this.remaining = remaining;
        this.reserved = 0;
        this.proxy = proxy;
        updateHeartbeat();
    }

    public void addBlock(long b) {
        synchronized (blocks) {
            blocks.add(b);
        }
    }

    /**
     * add block to toBeDeletedBlocks
     * 
     * @param b
     */
    public void removeAndPrepareToDeleteBlock(long b) {
        unreserve(b);
        synchronized (blocks) {
            blocks.remove(b);
        }
        synchronized (toBeDeletedBlocks) {
            toBeDeletedBlocks.add(b);
        }
    }

    public void removeAndPrepareToDeleteBlocks(long[] blocks) {
        synchronized (reservedBlocks) {
            for (long b: blocks) {
                unreserveWithoutLock(b);
            }
        }
        synchronized (this.blocks) {
            for (long b: blocks) {
                this.blocks.remove(b);
            }
        }
        synchronized (toBeDeletedBlocks) {
            for (long b: blocks) {
                toBeDeletedBlocks.add(b);
            }
        }
    }

    public void removeBlocks(long[] blocks) {
        synchronized (reservedBlocks) {
            for (long b: blocks) {
                unreserveWithoutLock(b);
            }
        }
        synchronized (this.blocks) {
            for (long block: blocks) {
                this.blocks.remove(block);
            }
        }
    }

    public long[] getAndClearToBeDeletedBlocks() {
        long[] blocks;
        synchronized (toBeDeletedBlocks) {
            blocks = toBeDeletedBlocks.toArray();
            toBeDeletedBlocks.clear();
        }
        return blocks;
    }

    public void reserve(long block, int blockSize) {
        synchronized (reservedBlocks) {
            if (reservedBlocks.containsKey(block)) {
                return;
            }
            reservedBlocks.put(block, blockSize, -1);
            reserved += blockSize;
            reservedTimes.put(block, System.currentTimeMillis(), -1);
        }
    }

    private void unreserveWithoutLock(long b) {
        // It could be possible when we cannot find block in reservedBlocks, 
        // for example, this datanode has just been lost for late-heartbeat
        int blockSize = reservedBlocks.remove(b, -1);
        if (blockSize > 0) {
            reserved -= blockSize;
        }
        reservedTimes.remove(b, -1);
    }

    public void unreserve(long block) {
        synchronized (reservedBlocks) {
            unreserveWithoutLock(block);
        }
    }

    public long[] getReservationsBeforeTime(long time) {
        LongArrayList list = new LongArrayList();
        synchronized (reservedBlocks) {
            for (LongLongKeyValueIterator iter = reservedTimes.iterator(); iter.hasNext();) {
                iter.next();
                long reservedTime = iter.getValue();
                if (reservedTime < time) {
                    list.add(iter.getKey());
                }
            }
        }
        return list.toArray();
    }

    public void getReservations(LongCompactHashSet set) {
        synchronized (reservedBlocks) {
            for (LongIntegerKeyValueIterator iter = reservedBlocks.iterator(); iter.hasNext();) {
                iter.next();
                set.add(iter.getKey());
            }
        }
    }

    public int getReservedBlockCount() {
        synchronized (reservedBlocks) {
            return reservedBlocks.size();
        }
    }

    public long getReserved() {
        return reserved;
    }

    public void updateHeartbeat() {
        this.lastUpdate = System.currentTimeMillis();
    }

    /**
     * @return hostname:port:dirStr
     */

    public String getFullName() {
        return name + ":" + dataDir;
    }

    /**
     * @return hostname:portNumber
     */
    public String getName() {
        return name;
    }

    /**
     * @return hostname and no :portNumber as UTF8 object.
     */
    public String getHost() {
        int colon = name.indexOf(":");
        if (colon < 0) {
            return name;
        } else {
            return name.substring(0, colon);
        }
    }

    public int getPort() {
        int colon = name.indexOf(":");
        return Integer.parseInt(name.substring(colon + 1));
    }

    public long[] getBlocks() {
        synchronized (blocks) {
            return blocks.toArray();
        }
    }

    public int getBlockNum() {
        synchronized (blocks) {
            return blocks.size();
        }
    }

    public boolean contains(long block) {
        synchronized (blocks) {
            return blocks.contains(block);
        }
    }

    public long getCapacity() {
        return capacity;
    }

    public void setCapacity(long capacity) {
        this.capacity = capacity;
    }

    public long getRemaining() {
        return remaining;
    }

    public void setRemaining(long remaining) {
        this.remaining = remaining;
    }

    public long lastUpdate() {
        return lastUpdate;
    }

    public int getReplicationQueueSize() {
        synchronized (toBeReplicatedBlocks) {
            return toBeReplicatedBlocks.size();
        }
    }

    /**
     * Put the block into this datanode's replication queue.
     * 
     * @param block
     * @param emergency
     */
    public void replicateBlock(long block, String[] targets, boolean immediate) {
        synchronized (toBeReplicatedBlocks) {
            toBeReplicatedBlocks.put(block, new ReplicateCommand(block,
                    targets, immediate));
        }
    }

    public void getReplicationCommands(List<DataNodeCommand> cmds) {
        synchronized (toBeReplicatedBlocks) {
            cmds.addAll(toBeReplicatedBlocks.values());
        }
    }

    public String[] replicationDone(long block) {
        synchronized (toBeReplicatedBlocks) {
            ReplicateCommand cmd = toBeReplicatedBlocks.remove(block);
            return cmd != null ? cmd.getTargets() : null;
        }
    }

    public void addForceCompleteBlock(long block) {
        unreserve(block);
        synchronized (forceCompleteBlocks) {
            forceCompleteBlocks.add(block);
        }
    }

    public long[] getAndClearForceCompleteBlocks() {
        long[] blocks;
        synchronized (forceCompleteBlocks) {
            blocks = forceCompleteBlocks.toArray();
            forceCompleteBlocks.clear();
        }
        return blocks;
    }

    public void addCheckConsistencyBlock(long block) {
        synchronized (checkConsistencyBlocks) {
            checkConsistencyBlocks.add(block);
        }
    }

    public long[] getAndClearCheckConsistencyBlocks() {
        long[] blocks;
        synchronized (checkConsistencyBlocks) {
            blocks = checkConsistencyBlocks.toArray();
            checkConsistencyBlocks.clear();
        }
        return blocks;
    }

    public void addWriteChecksumBlock(WriteChecksumCommand cmd) {
        synchronized (writeChecksumBlocks) {
            writeChecksumBlocks.add(cmd);
        }
    }

    public void getAndClearWriteChecksumBlocks(List<DataNodeCommand> cmds) {
        synchronized (writeChecksumBlocks) {
            cmds.addAll(writeChecksumBlocks);
            writeChecksumBlocks.clear();
        }
    }

    /**
     * Find diff between recorded blocks and reported blocks. The first value in
     * the pair is blocks that have not record yet, the second value in the pair
     * is blocks that have missed in the reported blocks.
     * 
     * @param blocks
     * @return
     */
    public Pair<List<BlockSize>, LongArrayList> getDiff(BlockSize[] blocks) {
        synchronized (this.blocks) {
            // when datanode connect
            if (this.blocks.isEmpty()) {
                return new Pair<List<BlockSize>, LongArrayList>(
                        Arrays.asList(blocks), new LongArrayList(0));
            }
            List<BlockSize> added = new ArrayList<BlockSize>();
            LongArrayList missed = new LongArrayList();
            LongHashSet visited = new LongHashSet(this.blocks.size());
            for (BlockSize block: blocks) {
                if (this.blocks.contains(block.getBlock())) {
                    visited.add(block.getBlock());
                } else {
                    added.add(block);
                }
            }
            for (long block: this.blocks) {
                if (!visited.contains(block)) {
                    missed.add(block);
                }
            }
            return new Pair<List<BlockSize>, LongArrayList>(added, missed);
        }
    }

    public int getRpcPort() {
        return getPort() + 2;
    }

    public INameToDataProtocol getProxy() {
        return proxy;
    }

    /**
     * Compute hash code only on name so that duplicate DatanodeInfo can be
     * eliminated when they are stored in a HashSet.
     */
    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public boolean equals(Object nodeInfo) {
        if (!(nodeInfo instanceof DatanodeInfo)) {
            return false;
        }
        DatanodeInfo other = (DatanodeInfo) nodeInfo;
        return (this.name.equals(other.name));
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IWritable copyFields(IWritable value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        throw new UnsupportedOperationException();
    }

    public static InetSocketAddress createSocketAddrFromFullName(
            String datanodeFullName) {
        int colon = datanodeFullName.indexOf(':');
        int colon2 = datanodeFullName.indexOf(':', colon + 1);
        return new InetSocketAddress(datanodeFullName.substring(0, colon),
                Integer.parseInt(datanodeFullName.substring(colon + 1, colon2)));
    }

    public static String getHostFromFullName(String datanodeFullName) {
        int colon = datanodeFullName.indexOf(':');
        return datanodeFullName.substring(0, colon);
    }

    public static int getPortFromFullName(String datanodeFullName) {
        int colon = datanodeFullName.indexOf(':');
        int colon2 = datanodeFullName.indexOf(':', colon + 1);
        return Integer.parseInt(datanodeFullName.substring(colon + 1, colon2));

    }

    public static String getDirFromFullName(String datanodeFullName) {
        int colon = datanodeFullName.indexOf(':');
        colon = datanodeFullName.indexOf(':', colon + 1);
        return datanodeFullName.substring(colon + 1);
    }

    public static String getDatanodeNameFromFullName(String datanodeFullName) {
        int colon = datanodeFullName.indexOf(':');
        colon = datanodeFullName.indexOf(':', colon + 1);
        return datanodeFullName.substring(0, colon);
    }

    public static String getDatanodeHBKeyFromFullName(String datanodeFullName) {
        int colon = datanodeFullName.indexOf(':');
        int colon2 = datanodeFullName.indexOf(':', colon + 1);
        return datanodeFullName.substring(0, colon).concat(
                datanodeFullName.substring(colon2));
    }

    public static String[] toLocationsWithDataPath(DatanodeInfo[] targets) {
        if (targets == null) {
            return new String[0];
        }
        String[] r = new String[targets.length];
        for (int i = 0; i < targets.length; i++) {
            r[i] = targets[i].getFullName();
        }
        return r;
    }

    public static String[] toLocationsWithDataPath(List<DatanodeInfo> targets) {
        if (targets == null) {
            return new String[0];
        }
        String[] r = new String[targets.size()];
        for (int i = 0; i < r.length; i++) {
            r[i] = targets.get(i).getFullName();
        }
        return r;
    }

    /**
     * Convert an array of DatanodeInfo to a list of the datanodes' locations
     * (names).
     */
    public static String[] toLocations(DatanodeInfo[] targets) {
        if (targets == null) {
            return null;
        }
        String[] r = new String[targets.length];
        for (int i = 0; i < targets.length; i++) {
            r[i] = targets[i].getName();
        }
        return r;
    }
}
