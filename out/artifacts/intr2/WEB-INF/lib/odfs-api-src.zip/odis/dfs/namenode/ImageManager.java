/**
 * @(#)ImageManager.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.util.DfsUtils;
import odis.io.ReadWriteUtils;

import org.apache.commons.configuration.Configuration;

import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * Primary NameNodes(both active and backup) need not to manager images. They
 * only load the newest image when start up. So use a static method to do it.
 * <p>
 * Secondary NameNode will do the image saving and transferring work.
 * 
 * @author zhangduo
 */
class ImageManager implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(ImageManager.class);

    static final String IMAGE_FILE_PREFIX = "fsimage.";

    static final String CHECKPOINT_FILE_SUFFIX = "checkpoint";

    static final String CHECKSUM_FILE_SUFFIX = ".adler32";

    private final File imageRoot;

    private final File[] primaryImageRoots;

    private final int primaryMaxImageNumber;

    private final SecondaryImageFileKeepPolicy imageKeepPolicy;

    ImageManager(Configuration conf) throws IOException {
        imageRoot = new File(conf.getString(DFSConfig.NAMENODE_ROOT,
                DFSConfig.DEFAULT_NAMENODE_ROOT), FS_IMAGE_DIR);
        String[] primaryRoots = conf.getStringArray(DFSConfig.NAMENODE_PRIMARY_ROOTS);
        primaryImageRoots = new File[primaryRoots.length];
        for (int i = 0; i < primaryRoots.length; i++) {
            primaryImageRoots[i] = new File(primaryRoots[i], FS_IMAGE_DIR);
        }
        if (!imageRoot.exists()) {
            if (!imageRoot.mkdirs()) {
                throw new IOException("Can not create image root "
                        + imageRoot.getAbsolutePath());
            }
        }
        primaryMaxImageNumber = conf.getInt(DFSConfig.NAMENODE_MAX_IMAGE_NUM,
                DFSConfig.DEFAULT_NAMENODE_MAX_IMAGE_NUM);
        String className = conf.getString(
                DFSConfig.NAMENODE_SECONDARY_IMAGE_KEEP_POLICY_CLASS,
                DFSConfig.DEFAULT_NAMENODE_SECONDARY_IMAGE_KEEP_POLICY_CLASS);
        imageKeepPolicy = DfsUtils.createFromConf(className, conf,
                SecondaryImageFileKeepPolicy.class);
    }

    static long getSN(String name) {
        return Long.parseLong(name.substring(IMAGE_FILE_PREFIX.length()));
    }

    static long getSN(File imageFile) {
        return getSN(imageFile.getName());
    }

    private static final Comparator<File> IMAGE_FILE_SN_COMPARATOR = new Comparator<File>() {

        @Override
        public int compare(File o1, File o2) {
            long sn1 = getSN(o1);
            long sn2 = getSN(o2);
            return sn1 > sn2 ? 1 : sn1 == sn2 ? 0 : -1;
        }
    };

    static File[] listImageFiles(File imageRoot, boolean removeInvalid) {
        File[] imageFiles = imageRoot.listFiles(new FilenameFilter() {

            @Override
            public boolean accept(File dir, String name) {
                return name.startsWith(IMAGE_FILE_PREFIX)
                        && !name.endsWith(CHECKSUM_FILE_SUFFIX)
                        && !name.endsWith(CHECKPOINT_FILE_SUFFIX);
            }
        });
        List<File> validImageFiles = new ArrayList<File>();
        for (File imageFile: imageFiles) {
            File checksumFile = new File(imageRoot, imageFile.getName()
                    + CHECKSUM_FILE_SUFFIX);
            if (!checksumFile.exists()) {
                if (removeInvalid) {
                    LOG.warning("Image file " + imageFile.getAbsolutePath()
                            + " has no checksum file, delete it");
                    if (!imageFile.delete()) {
                        LOG.warning("Delete invalid image file "
                                + imageFile.getAbsolutePath() + " failed");
                    }
                }
            } else {
                validImageFiles.add(imageFile);
            }
        }
        File[] ret = validImageFiles.toArray(new File[0]);
        Arrays.sort(ret, IMAGE_FILE_SN_COMPARATOR);
        return ret;
    }

    static File getNewestImageFile(File imageRoot, boolean removeInvalid) {
        File[] imageFiles = listImageFiles(imageRoot, removeInvalid);
        if (imageFiles.length != 0) {
            return imageFiles[imageFiles.length - 1];
        } else {
            return null;
        }
    }

    File getImageRoot() {
        return imageRoot;
    }

    File createCheckpointImageFile() {
        return new File(imageRoot, IMAGE_FILE_PREFIX + CHECKPOINT_FILE_SUFFIX);
    }

    void addNewImage(File imageFile, int adler32, long sn) throws IOException {
        File targetImageFile = new File(imageRoot, IMAGE_FILE_PREFIX + sn);
        if (!imageFile.renameTo(targetImageFile)) {
            throw new IOException("Cannot rename "
                    + imageFile.getAbsolutePath() + " to "
                    + targetImageFile.getAbsolutePath());
        }
        File checksumFile = new File(imageRoot, IMAGE_FILE_PREFIX + sn
                + CHECKSUM_FILE_SUFFIX);
        DfsUtils.writeChecksum(checksumFile, adler32);
        LOG.info("New image file " + targetImageFile.getAbsolutePath()
                + " created");
    }

    private static final int TRANSFER_BUFFER_SIZE = 64 * 1024;

    private void transfer(File imageFile, List<File> primaryImageRoots)
            throws IOException {
        long sn = getSN(imageFile);
        int adler32Checksum = DfsUtils.readChecksum(new File(imageRoot,
                imageFile.getName() + CHECKSUM_FILE_SUFFIX));
        LOG.info("Start transfer " + imageFile.getAbsolutePath()
                + " with adler32 checksum "
                + HexString.intToPaddedHex(adler32Checksum) + " to "
                + primaryImageRoots);
        FileInputStream in = new FileInputStream(imageFile);
        List<Pair<File, FileOutputStream>> outs = new ArrayList<Pair<File, FileOutputStream>>(
                primaryImageRoots.size());
        for (File primaryImageRoot: primaryImageRoots) {
            File primaryImageFile = new File(primaryImageRoot,
                    IMAGE_FILE_PREFIX + sn);
            try {
                FileOutputStream fos = new FileOutputStream(primaryImageFile);
                outs.add(new Pair<File, FileOutputStream>(primaryImageRoot, fos));
            } catch (IOException e) {
                LOG.log(Level.WARNING,
                        "create output of "
                                + primaryImageFile.getAbsolutePath()
                                + " failed", e);
            }
        }
        if (outs.isEmpty()) {
            ReadWriteUtils.safeClose(in);
            LOG.warning("Failed to transfer " + imageFile.getAbsolutePath()
                    + " to any of " + primaryImageRoots);
            return;
        }
        Adler32 adler32 = new Adler32();
        byte[] buf = new byte[TRANSFER_BUFFER_SIZE];
        for (;;) {
            int len = 0;
            try {
                len = in.read(buf);
            } finally {
                if (len == 0) {
                    // read never return 0, so this means a read error occurred
                    ReadWriteUtils.safeClose(in);
                }
            }
            if (len < 0) {
                break;
            }
            adler32.update(buf, 0, len);
            for (Iterator<Pair<File, FileOutputStream>> iter = outs.iterator(); iter.hasNext();) {
                Pair<File, FileOutputStream> out = iter.next();
                try {
                    out.getSecond().write(buf, 0, len);
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "Transfer " + imageFile.getAbsolutePath() + " to "
                                    + out.getFirst().getAbsolutePath()
                                    + " failed", e);
                    ReadWriteUtils.safeClose(out.getSecond());
                    iter.remove();
                    if (outs.isEmpty()) {
                        ReadWriteUtils.safeClose(in);
                        LOG.warning("Failed to transfer "
                                + imageFile.getAbsolutePath() + " to any of "
                                + primaryImageRoots);
                        return;
                    }
                }
            }
        }
        ReadWriteUtils.safeClose(in);
        for (Iterator<Pair<File, FileOutputStream>> iter = outs.iterator(); iter.hasNext();) {
            Pair<File, FileOutputStream> out = iter.next();
            try {
                out.getSecond().getFD().sync();
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "Transfer " + imageFile.getAbsolutePath() + " to "
                                + out.getFirst().getAbsolutePath() + " failed",
                        e);
                ReadWriteUtils.safeClose(out.getSecond());
                iter.remove();
                if (outs.isEmpty()) {
                    ReadWriteUtils.safeClose(in);
                    LOG.warning("Failed to transfer "
                            + imageFile.getAbsolutePath() + " to any of "
                            + primaryImageRoots);
                    return;
                }
            } finally {
                ReadWriteUtils.safeClose(out.getSecond());
            }
        }
        if ((int) adler32.getValue() != adler32Checksum) {
            throw new IOException("Checksum mismatch when transfer "
                    + imageFile.getAbsolutePath() + ", expected "
                    + HexString.intToPaddedHex(adler32Checksum) + ", actual "
                    + HexString.intToPaddedHex((int) adler32.getValue()));
        }
        for (Iterator<Pair<File, FileOutputStream>> iter = outs.iterator(); iter.hasNext();) {
            File primaryImageRoot = iter.next().getFirst();
            File checksumFile = new File(primaryImageRoot, imageFile.getName()
                    + CHECKSUM_FILE_SUFFIX);
            try {
                DfsUtils.writeChecksum(checksumFile, adler32Checksum);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "failed to write checksum file "
                        + checksumFile.getAbsolutePath());
                iter.remove();
            }
        }
        if (outs.isEmpty()) {
            LOG.warning("Failed to transfer " + imageFile.getAbsolutePath()
                    + " to any of " + primaryImageRoots);
            return;
        }
        List<File> succeeded = new ArrayList<File>(outs.size());
        for (Pair<File, FileOutputStream> out: outs) {
            succeeded.add(out.getFirst());
        }
        LOG.info("Done image transfer, successfully transferred to "
                + succeeded);
    }

    void transferNewestImageToPrimaries() throws IOException {
        File newestImageFile = getNewestImageFile(imageRoot, true);
        if (newestImageFile == null) {
            return;
        }
        long newestSN = getSN(newestImageFile);
        List<File> toTransfer = new ArrayList<File>();
        for (File primaryImageRoot: primaryImageRoots) {
            File primaryNewestImageFile = getNewestImageFile(primaryImageRoot,
                    true);
            if (primaryNewestImageFile != null) {
                long primaryNewestSN = getSN(primaryNewestImageFile);
                if (newestSN > primaryNewestSN) {
                    toTransfer.add(primaryImageRoot);
                }
            } else {
                toTransfer.add(primaryImageRoot);
            }
        }
        if (!toTransfer.isEmpty()) {
            transfer(newestImageFile, toTransfer);
        }
    }

    static void cleanImageAndChecksumFile(File imageRoot, String name) {
        File imageFile = new File(imageRoot, name);
        LOG.info("Clean old image file " + imageFile.getAbsolutePath());
        if (!imageFile.delete()) {
            LOG.warning("Clean old image file " + imageFile.getAbsolutePath()
                    + " failed");
        }
        File checksumFile = new File(imageRoot, name + CHECKSUM_FILE_SUFFIX);
        if (!checksumFile.delete()) {
            LOG.warning("Clean old image checksum file "
                    + checksumFile.getAbsolutePath() + " failed");
        }
    }

    private void cleanPrimaryImageRoot(File imageRoot) {
        File[] imageFiles = listImageFiles(imageRoot, true);
        for (int i = 0, n = imageFiles.length - primaryMaxImageNumber; i < n; i++) {
            cleanImageAndChecksumFile(imageRoot, imageFiles[i].getName());
        }
    }

    /**
     * Return the oldest image SN which will be used to delete old log files.
     * 
     * @return
     * @throws IOException
     */
    long cleanImageRoots() {
        for (File primaryImageRoot: primaryImageRoots) {
            cleanPrimaryImageRoot(primaryImageRoot);
        }
        return imageKeepPolicy.clean(imageRoot);
    }
}
