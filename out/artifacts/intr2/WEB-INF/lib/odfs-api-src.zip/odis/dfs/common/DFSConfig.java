/**
 * @(#)DFSConfig.java, 2012-2-15. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.ConfigUtils;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public final class DFSConfig {

    private static final Logger LOG = LogFormatter.getLogger(DFSConfig.class);

    private static Configuration conf;

    private static File home;

    static {
        String home = System.getProperty("odis.home");
        if (home == null) {
            home = System.getenv("ODIS_HOME");
        }
        if (home == null) {
            home = ".";
        }
        DFSConfig.home = new File(home);
        System.setProperty("odis.home", DFSConfig.home.getAbsolutePath());

        File confDir = new File(home, "conf");
        try {
            conf = ConfigUtils.parseXmlConfig(confDir, new String[] {
                "service.xml"
            });
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "parse odfs configuration failed", e);
            throw new RuntimeException("parse odfs configuration failed", e);
        }

        String local = System.getProperty("odis.local");
        if (local == null) {
            local = System.getenv("ODIS_LOCAL");
        }
        if (local == null) {
            local = ".";
        }
        conf.setProperty("odis.local", local);
    }

    public static Configuration conf() {
        return conf;
    }

    public static File getHome() {
        return home;
    }

    public static File getNamenodeWebCtxPath() {
        return new File(home, "web_namenode");
    }

    public static Properties getLogLevel() {
        return conf.getProperties(LOG_LEVEL);
    }

    public static File getLogDir() {
        return new File(conf.getString("odis.local"), "log" + File.separator
                + "odfs");
    }

    public static File getTmpDir() {
        return new File(conf.getString("odis.local"), "tmp");
    }

    public static File getNamenodeLogDir() {
        return new File(getLogDir(), "namenode");
    }

    public static File getDatanodeLogDir() {
        return new File(getLogDir(), "datanode");
    }

    public static final String CUID = "dfs.cuid";

    public static final String LOG_LEVEL = "dfs.log.level";

    public static final String LOG_FILE_LIMIT = "dfs.log.file_limit";

    public static final int DEFAULT_LOG_FILE_LIMIT = 10 * 1024 * 1024;

    public static final String LOG_FILE_COUNT = "dfs.log.file_count";

    public static final int DEFAULT_LOG_FILE_COUNT = 100;

    public static final String LOG_APPEND = "dfs.log.append";

    public static final boolean DEFAULT_LOG_APPEND = true;

    public static final String ALERT_FROM_EMAIL = "dfs.alert.from_email";

    public static final String DEFAULT_ALERT_FROM_EMAIL = "postmaster@rd.netease.com";

    public static final String ALERT_TO_EMAIL = "dfs.alert.to_email";

    public static final String DEFAULT_ALERT_TO_EMAIL = "infra@rd.netease.com";

    public static final String ALERT_SMS_GROUP = "dfs.alert.sms_group";

    public static final String DEFAULT_ALERT_SMS_GROUP = "ODFS";

    public static final String ALERT_ENABLE_EMAIL = "dfs.alert.enable_email";

    public static final boolean DEFAULT_ALERT_ENABLE_EMAIL = false;

    public static final String ALERT_ENABLE_SMS = "dfs.alert.enable_sms";

    public static final boolean DEFAULT_ALERT_ENABLE_SMS = false;

    public static String getAlertFromEmail() {
        return conf.getString(ALERT_FROM_EMAIL, DEFAULT_ALERT_FROM_EMAIL);
    }

    public static String getAlertToEmail() {
        return conf.getString(ALERT_TO_EMAIL, DEFAULT_ALERT_TO_EMAIL);
    }

    public static String getAlertSmsGroup() {
        return conf.getString(ALERT_SMS_GROUP, DEFAULT_ALERT_SMS_GROUP);
    }

    public static boolean isEmailAlertEnabled() {
        return conf.getBoolean(ALERT_ENABLE_EMAIL, DEFAULT_ALERT_ENABLE_EMAIL);
    }

    public static boolean isSmsAlertEnabled() {
        return conf.getBoolean(ALERT_ENABLE_SMS, DEFAULT_ALERT_ENABLE_SMS);
    }

    public static final String ZOOKEEPER_ADDR = "dfs.zookeeper.addr";

    public static final String ZOOKEEPER_ROOT = "dfs.zookeeper.root";

    public static final String ZOOKEEPER_TIMEOUT = "dfs.zookeeper.timeout";

    public static final int DEFAULT_ZOOKEEPER_TIMEOUT = 30000;

    public static final String NAMENODE_ROOT = "dfs.namenode.root";

    public static final String DEFAULT_NAMENODE_ROOT = "${odis.local}/namenode";

    public static final String NAMENODE_ZK_MAX_RETRY_COUNT = "dfs.namenode.zk_max_retry_count";

    public static final int DEFAULT_NAMENODE_ZK_MAX_RETRY_COUNT = 10;

    public static final String NAMENODE_BACKUP_FOLLOW_UP_INTERVAL = "dfs.namenode.backup_follow_up_interval";

    public static final long DEFAULT_NAMENODE_BACKUP_FOLLOW_UP_INTERVAL = 5L * 1000;

    public static final String NAMENODE_PRIMARY_ROOTS = "dfs.namenode.primary_roots";

    public static final String NAMENODE_HOST_PORT = "dfs.namenode.hostport";

    public static final String NAMENODE_RPC_PORT = "dfs.namenode.port";

    public static final String NAMENODE_OLD_PROXY_RPC_PORT = "dfs.namenode.oldproxyport";

    public static final String NAMENODE_WEB_PORT = "dfs.namenode.web_port";

    public static final int DEFAULT_NAMENODE_WEB_PORT = 4000;

    public static final String NAMENODE_BSH_PORT = "dfs.namenode.bshport";

    public static final int DEFAULT_NAMENODE_BSH_PORT = 1234;

    public static final String NAMENODE_ADMIN = "dfs.namenode.admin";

    public static final String DEFAULT_NAMENODE_ADMIN = System.getProperty("user.name");

    public static final String NAMENODE_RPC_HANDLER = "dfs.namenode.num_handlers";

    public static final int DEFAULT_NAMENODE_RPC_HANDLER = 5;

    public static final String NAMENODE_RPC_QUEUE_SIZE = "dfs.namenode.rpc_queue_size";

    public static final String NAMENODE_SYSTEM_RPC_HANDLER = "dfs.namenode.system_num_handlers";

    public static final int DEFAULT_NAMENODE_SYSTEM_RPC_HANDLER = 5;

    public static final String NAMENODE_SYSTEM_RPC_QUEUE_SIZE = "dfs.namenode.system_rpc_queue_size";

    public static final String NAMENODE_TRASH_CHECK_PERIOD = "dfs.namenode.trash_check_period";

    public static final long DEFAULT_NAMENODE_TRASH_CHECK_PERIOD = 24L * 60 * 60 * 1024;

    public static final String NAMENODE_TRASH_LIFE_SPAN = "dfs.namenode.trash_life_span";

    public static final long DEFAULT_NAMENODE_TRASH_LIFE_SPAN = 3L * 24 * 60
            * 60 * 1000;

    public static final String NAMENODE_SECONDARY_WORK_INTERVAL = "dfs.namenode.secondary_work_interval";

    public static final long DEFAULT_NAMENODE_SECONDARY_WORK_INTERVAL = 60L * 1000;

    public static final String NAMENODE_SECONDARY_IMAGE_SAVE_INTERVAL = "dfs.namenode.secondary_image_save_interval";

    public static final long DEFAULT_NAMENODE_SECONDARY_IMAGE_SAVE_INTERVAL = 60L * 60 * 1000;

    public static final String NAMENODE_SECONDARY_IMAGE_TRANSFER_INTERVAL = "dfs.namenode.secondary_image_transfer_interval";

    public static final long DEFAULT_NAMENODE_SECONDARY_IMAGE_TRANSFER_INTERVAL = 24L * 60 * 60 * 1000;

    public static final String NAMENODE_SECONDARY_IMAGE_KEEP_POLICY_CLASS = "dfs.namenode.secondary_image_keep_policy";

    public static final String DEFAULT_NAMENODE_SECONDARY_IMAGE_KEEP_POLICY_CLASS = "odis.dfs.namenode.KeepAllImageFilePolicy";

    public static final String NAMENODE_MAX_IMAGE_NUM = "dfs.namenode.max_image_num";

    public static final int DEFAULT_NAMENODE_MAX_IMAGE_NUM = 3;

    public static final String NAMENODE_EDIT_LOG_ROLLING_INTERVAL = "dfs.namenode.edit_log_rolling_interval";

    public static final long DEFAULT_NAMENODE_EDIT_LOG_ROLLING_INTERVAL = 60L * 60 * 1000;

    public static final String NAMENODE_DEFAULT_PERMISSION = "dfs.namenode.default_permission";

    public static final int DEFAULT_NAMENODE_DEFAULT_PERMISSION = 00777;

    public static final String NAMENODE_DEFAULT_GROUP = "dfs.namenode.default_group";

    public static final String DEFAULT_NAMENODE_DEFAULT_GROUP = "kaiwoo";

    public static final String NAMENODE_MAX_PATH_LENGTH = "dfs.namenode.max_path_length";

    public static final int DEFAULT_NAMENODE_MAX_PATH_LENGTH = 8000;

    public static final String NAMENODE_MAX_PATH_DEPTH = "dfs.namenode.max_path_depth";

    public static final int DEFAULT_NAMENODE_MAX_PATH_DEPTH = 1000;

    public static final String NAMENODE_ASYNC_MAX_BATCH_ELEMENTS = "dfs.namenode.async_max_batch_elements";

    public static final int DEFAULT_NAMENODE_ASYNC_MAX_BATCH_ELEMENTS = 100;

    public static final String NAMENODE_ASYNC_MAX_WAIT_TIME = "dfs.namenode.async_max_wait_time";

    public static final long DEFAULT_NAMENODE_ASYNC_MAX_WAIT_TIME = 10;

    public static final String NAMENODE_LEASE_PERIOD = "dfs.ping.lease_period";

    public static final long DEFAULT_NAMENODE_LEASE_PERIOD = 10L * 60 * 1000;

    public static final String RESERVATION_MONITOR_INTERVAL = "dfs.reservation.monitor_interval";

    public static final long DEFAULT_RESERVATION_MONITOR_INTERVAL = 60L * 60 * 1000;

    public static final String RESERVATION_PERIOD_MAX = "dfs.reservation.max_period";

    public static final long DEFAULT_RESERVATION_PERIOD_MAX = 24L * 60 * 60 * 1000;

    public static final String REPLICATION_PERIOD_MAX = "dfs.replication.max_period";

    public static final long DEFAULT_REPLICATION_PERIOD_MAX = 60L * 60 * 1000;

    public static final String REPLICATION_SCHEDULE_INTERVAL = "dfs.replication.schedule_interval";

    public static final long DEFAULT_REPLICATION_SCHEDULE_INTERVAL = 5000;

    public static final String REPLICATION_MIN_DATANODE = "dfs.replication.min_datanode";

    public static final int DEFAULT_REPLICATION_MIN_DATANODE = 3;

    public static final String NEW_BLOCK_CHECK_REPLICATION_DELAY = "dfs.replication.new_block_check_delay";

    // 1 minute
    public static final long DEFAULT_NEW_BLOCK_CHECK_REPLICATION_DELAY = 60L * 1000;

    public static final String MAX_REPLICATION_PER_TIME = "dfs.replication.max_count_per_time";

    public static final int DEFAULT_MAX_REPLICATION_PER_TIME = 8;

    public static final String BLOCK_PLACEMENT_POLICY_CLASS = "dfs.replication.placement_policy_class";

    public static final String DEFAULT_BLOCK_PLACEMENT_POLICY_CLASS = "odis.dfs.namenode.SegmentedReserveByCapacityPolicy";

    public static final String BLOCK_MIN_SIZE = "dfs.block.min_size";

    public static final int DEFAULT_BLOCK_MIN_SIZE = 64 * 1024 * 1024;

    public static final String BLOCK_MAX_SIZE = "dfs.block.max_size";

    public static final int DEFAULT_BLOCK_MAX_SIZE = 1024 * 1024 * 1024;

    public static final String BLOCK_MIN_REPLICATION = "dfs.block.min_replication";

    public static final int DEFAULT_BLOCK_MIN_REPLICATION = 1;

    public static final String JOURNAL_MANAGER_CLASS = "dfs.journal.class";

    public static final String DEFAULT_JOURNAL_MANAGER_CLASS = "odis.dfs.journal.LocalJournalManager";

    public static final String JOURNAL_ROOT_DIR = "dfs.journal.root_dir";

    public static final String DATANODE_DIRS = "dfs.datanode.dirs";

    public static final String DATANODE_MACHINE_UNAVAILABLE_FILE = "dfs.datanode.machine-unavailable-file";

    public static final String DEFAULT_DATANODE_MACHINE_UNAVAILABLE_FILE = "/var/lock/unavailable";

    public static final String DATANODE_OFFLINE_DISKS_FILE = "dfs.datanode.offlinedisks_file";

    public static final String DEFAULT_DATANODE_OFFLINE_DISKS_FILE = "/var/odis/offlinedisks";

    public static final String DATANODE_OFFLINE_DISKS_CHECK_INTERVAL = "dfs.datanode.offlinedisks_check_interval";

    public static final long DEFAULT_DATANODE_OFFLINE_DISKS_CHECK_INTERVAL = 60L * 1000;

    public static final String DATANODE_RESERVE = "dfs.datanode.reserve";

    public static final long DEFAULT_DATANODE_RESERVE = 10L * 1024 * 1024 * 1024;

    public static final String DATANODE_PORT = "dfs.datanode.port";

    public static final int DEFAULT_DATANODE_PORT = 7000;

    public static final String DATANODE_ZK_MAX_RETRY_COUNT = "dfs.datanode.zk_max_retry_count";

    public static final int DEFAULT_DATANODE_ZK_MAX_RETRY_COUNT = 10;

    public static final String DATANODE_CHECK_NAMENODE_ADDR_MAX_INTERVAL = "dfs.datanode.check_namenode_addr_max_interval";

    public static final long DEFAULT_DATANODE_CHECK_NAMENODE_ADDR_MAX_INTERVAL = 5L * 60 * 1000;

    public static final String DATANODE_HEARTBEAT_INTERVAL = "dfs.ping.heartbeat_interval";

    public static final long DEFAULT_DATANODE_HEARTBEAT_INTERVAL = 60 * 1000L;

    public static final String DATANODE_HEARTBEAT_EXPIRE = "dfs.ping.heartbeat_expire";

    public static final String DATANODE_BLOCK_REPORT_INTERVAL = "dfs.ping.blockreport_interval";

    public static final long DEFAULT_DATANODE_BLOCK_REPORT_INTERVAL = 60L * 60 * 1000;

    public static final String DATANODE_MAX_TRANSFER_COUNT = "dfs.datanode.max_transfer_count";

    public static final int DEFAULT_DATANODE_MAX_TRANSFER_COUNT = 2;

    public static final String DATANODE_TRANSFER_MAX_WORK_INTERVAL = "dfs.datanode.transfer_max_work_interval";

    public static final long DEFAULT_DATANODE_TRANSFER_MAX_WORK_INTERVAL = 15L * 1000;

    public static final String DATANODE_THREAD_POOL_CORE_SIZE = "dfs.datanode.threadpool_coresize";

    public static final int DEFAULT_DATANODE_THREAD_POOL_CORE_SIZE = 16;

    public static final String DATANODE_THREAD_POOL_MAX_SIZE = "dfs.datanode.threadpool_maxsize";

    public static final int DEFAULT_DATANODE_THREAD_POOL_MAX_SIZE = 32;

    public static final String DATANODE_THREAD_POOL_KEEPALIVE = "dfs.datanode.threadpool_keepalive";

    public static final long DEFAULT_DATANODE_THREAD_POOL_KEEPALIVE = 60L * 1000;

    public static final String DATANODE_THREAD_STACKSIZE = "dfs.datanode.thread_stacksize";

    public static final long DEFAULT_DATANODE_THREAD_STACKSIZE = 64L * 1024;

    public static final String DATANODE_THREAD_POOL_MAX_QUEUE_SIZE = "dfs.datanode.threadpool_maxqueuesize";

    public static final int DEFAULT_DATANODE_THREAD_POOL_MAX_QUEUE_SIZE = 256;

    public static final String DATANODE_REPORT_BLOCK_RECEIVED_AND_DELETED_MAX_RETRY_COUNT = "dfs.datanode.report_block_receiced_and_deleted_max_retry_count";

    public static final int DEFAULT_DATANODE_REPORT_BLOCK_RECEIVED_AND_DELETED_MAX_RETRY_COUNT = 3;

    public static final String DATANODE_OFFLINE_DISK_PATH_NORMALIZER_CLASS = "dfs.datanode.offline_disk_path_normalizer_class";

    public static final String DEFAULT_DATANODE_OFFLINE_DISK_PATH_NORMALIZER_CLASS = "odis.dfs.datanode.EarliestAncestorNormalizer";

    public static final String DATANODE_DATAXCEIVE_WORKER_COUNT = "dfs.datanode.dataxceive_worker_count";

    public static final int DEFAULT_DATANODE_DATAXCEIVE_WORKER_COUNT = 2 * ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors();

    public static final String DATANODE_DISK_READ_MAX_CONCURRENCY = "dfs.datanode.disk_read_max_concurrency";

    public static final String DATANODE_WRITE_CHAIN_TIMEOUT = "dfs.datanode.write_chain_timeout";

    public static final long DEFAULT_DATANODE_WRITE_CHAIN_TIMEOUT = DFSClientConfig.CLIENT_BLOCK_WRITE_TIMEOUT_DEFAULT_VALUE;

    public static final int DEFAULT_DATANODE_DISK_READ_MAX_CONCURRENCY = 4;

    public static final String DATANODE_DIRECT_BYTE_BUFFER_CHUNK_SIZE = "dfs.datanode.direct_byte_buffer_chunk_size";

    public static final int DEFAULT_DATANODE_DIRECT_BYTE_BUFFER_CHUNK_SIZE = 64 * 1024 * 1024;

    public static final String DATANODE_DIRECT_BYTE_BUFFER_SIZE = "dfs.datanode.direct_byte_buffer_size";

    public static final int DEFAULT_DATANODE_DIRECT_BYTE_BUFFER_SIZE = 16 * 1024;

    public static final String DATANODE_BSH_PORT = "dfs.datanode.bshport";

    public static final int DEFAULT_DATANODE_BSH_PORT = 2234;

    public static final String DATANODE_BACKGROUND_TASK_POOL_SIZE = "dfs.datanode.background_task_pool_size";

    public static final int DEFAULT_DATANODE_BACKGROUND_TASK_POOL_SIZE = 4;

    public static final String METRICS_REPORT_INTERVAL = "dfs.metrics.report_interval";

    public static final long DEFAULT_METRICS_REPORT_INTERVAL = 60L * 1000;

    public static final String METRICS_VAQUERO_ADDR = "dfs.metrics.vaquero_addr";

    public static final String METRICS_VAQUERO_PRODUCT = "dfs.metrics.vaquero_product";

    public static final String METRICS_GANGLIA_GMETAD_ADDR = "dfs.metrics.ganglia_gmetad_addr";

    public static final String FILE_NAME_INTERN_PATTERN = "dfs.namenode.file_name_intern_pattern";

    public static final String DEFAULT_FILE_NAME_INTERN_PATTERN = "part-\\d+";

    /**
     * QJM configs
     */
    public static final long INVALID_EPOCH = -1;

    public static final int INVALID_HTTP_PORT = -1;

    public static final long INVALID_SN = -1;

    public static final String DFS_QJOURNAL_GET_JOURNAL_STATE_TIMEOUT_KEY = "dfs.qjournal.get_journal_state";

    public static final int DFS_QJOURNAL_GET_JOURNAL_STATE_TIMEOUT_DEFAULT = 120000;

    public static final String DFS_QJOURNAL_NEW_EPOCH_TIMEOUT_KEY = "dfs.qjournal.new_epoch_timeout";

    public static final int DFS_QJOURNAL_NEW_EPOCH_TIMEOUT_DEFAULT = 120000;

    public static final String DFS_QJOURNAL_START_SEGMENT_TIMEOUT_KEY = "dfs.qjournal.start_segment_timeout";

    public static final int DFS_QJOURNAL_START_SEGMENT_TIMEOUT_DEFAULT = 20000;

    public static final String DFS_QJOURNAL_FINALIZE_SEGMENT_TIMEOUT_KEY = "dfs.qjournal.finalize_segment_timeout";

    public static final int DFS_QJOURNAL_FINALIZE_SEGMENT_TIMEOUT_DEFAULT = 120000;

    public static final String DFS_QJOURNAL_PREPARE_RECOVERY_TIMEOUT_KEY = "dfs.qjournal.prepare_recovery_timeout";

    public static final int DFS_QJOURNAL_PREPARE_RECOVERY_TIMEOUT_DEFAULT = 120000;

    public static final String DFS_QJOURNAL_ACCEPT_RECOVERY_TIMEOUT_KEY = "dfs.qjournal.accept_recovery_timeout";

    public static final int DFS_QJOURNAL_ACCEPT_RECOVERY_TIMEOUT_DEFAULT = 120000;

    public static final String DFS_QJOURNAL_WRITE_JOURNAL_TIMEOUT_KEY = "dfs.qjournal.write_journal_timeout";

    public static final int DFS_QJOURNAL_WRITE_JOURNAL_TIMEOUT_DEFAULT = 20000;

    public static final String DFS_QJOURNAL_DOWNLOAD_FILE_TIMEOUT_KEY = "dfs.qjournal.download_file_timeout";

    public static final int DFS_QJOURNAL_DOWNLOAD_FILE_TIMEOUT_DEFAULT = 3 * 60 * 1000;

    public static final String DFS_QJOURNAL_READ_TIMEOUT_KEY = "dfs.qjournal.read_timeout";

    public static final int DFS_QJOURNAL_READ_TIMEOUT_DEFAULT = 3 * 60 * 1000;

    public static final String DFS_QJOURNAL_OPEN_INPUTSTREAM_TIMEOUT_KEY = "dfs.qjournal.open_inputstream_timeout";

    public static final int DFS_QJOURNAL_OPEN_INPUTSTREAM_TIMEOUT_DEFAULT = 20000;

    public static final String DFS_QJOURNAL_CHECK_SERVER_INTERVAL_KEY = "dfs.qjournal.check_server_interval";

    public static final long DFS_QJOURNAL_CHECK_SERVER_INTERVAL_DEFAULT = 60L * 1000;

    public static final String DFS_QJOURNAL_SERVER_PORT = "dfs.qjournal.server_port";

    public static final String DFS_JOURNALNODE_EDITS_DIR_KEY = "dfs.journalnode.edits_dir";

    public static final String DFS_JOURNALNODE_EDITS_DIR_DEFAULT = "/tmp/odfs/journalnode/";

    public static final String DFS_QJOURNAL_JOURNAL_NODES = "dfs.qjournal.journal_nodes";
}
