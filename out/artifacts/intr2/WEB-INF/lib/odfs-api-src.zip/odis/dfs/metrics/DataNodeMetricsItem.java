/**
 * @(#)DataNodeMetricsItem.java, 2012-4-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

/**
 * DataNode metrics items.
 * 
 * @author zhangduo
 */
public enum DataNodeMetricsItem {
    SYSTEM_LOAD(0, "系统负载"),
    PROCESSOR_NUM(SYSTEM_LOAD.offset + 1, "CPU个数"),
    
    HEAP_INIT(PROCESSOR_NUM.offset + 1, "初始堆内存"),
    HEAP_USED(HEAP_INIT.offset + 1, "已用堆内存"),
    HEAP_COMMITTED(HEAP_USED.offset + 1, "提交堆内存"),
    HEAP_MAX(HEAP_COMMITTED.offset + 1, "最大堆内存"),
    
    NON_HEAP_INIT(HEAP_MAX.offset + 1, "初始非堆内存"),
    NON_HEAP_USED(NON_HEAP_INIT.offset + 1, "已用非堆内存"),
    NON_HEAP_COMMITTED(NON_HEAP_USED.offset + 1, "提交非堆内存"),
    NON_HEAP_MAX(NON_HEAP_COMMITTED.offset + 1, "最大非堆内存"),
    
    BLOCK_NUM(NON_HEAP_MAX.offset + 1, "数据块总数"),
    BLOCK_SIZE(BLOCK_NUM.offset + 1, "数据块总大小"),
    
    CONCURRENT_READ(BLOCK_SIZE.offset + 1, "读取并发"),
    CONCURRENT_WRITE(CONCURRENT_READ.offset + 1, "写入并发"),
    CONCURRENT_REPLICATION(CONCURRENT_WRITE.offset + 1, "复制并发"),
    
    NORMAL_READ_COUNT(CONCURRENT_REPLICATION.offset + 1, "读取次数"),
    NORMAL_READ_BYTES(NORMAL_READ_COUNT.offset + 1, "读取字节"),
    NORMAL_READ_DELAY(NORMAL_READ_BYTES.offset + 1, "读取时间"),
    
    RANDOM_READ_COUNT(NORMAL_READ_DELAY.offset + 1, "随机读取次数"),
    RANDOM_READ_BYTES(RANDOM_READ_COUNT.offset + 1, "随机读取字节"),
    RANDOM_READ_DELAY(RANDOM_READ_BYTES.offset + 1, "随机读取时间"),
    
    REPLICATION_COUNT(RANDOM_READ_DELAY.offset + 1, "复制次数"),
    REPLICATION_BYTES(REPLICATION_COUNT.offset + 1, "复制字节"),
    REPLICATION_DELAY(REPLICATION_BYTES.offset + 1, "复制时间"),
    
    WRITE_COUNT(REPLICATION_DELAY.offset + 1, "写入次数"),
    WRITE_BYTES(WRITE_COUNT.offset + 1, "写入字节"),
    WRITE_DELAY(WRITE_BYTES.offset + 1, "写入时间"),
    
    WRITE_PARTIAL_COUNT(WRITE_DELAY.offset + 1, "不完整写入次数"),
    
    DELETE_COUNT(WRITE_PARTIAL_COUNT.offset + 1, "删除次数"),
    DELETE_BYTES(DELETE_COUNT.offset + 1, "删除字节");
    
    private final int offset;

    private final String printName;

    private DataNodeMetricsItem(int offset, String printName) {
        this.offset = offset;
        this.printName = printName;
    }

    public int offset() {
        return offset;
    }

    public String getPrintName() {
        return printName;
    }

    public static int systemInfoItems() {
        return BLOCK_SIZE.offset + 1;
    }

    public static int totalItems() {
        return DELETE_BYTES.offset + 1;
    }
}
