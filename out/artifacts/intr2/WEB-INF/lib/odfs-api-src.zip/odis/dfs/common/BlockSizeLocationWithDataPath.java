/**
 * @(#)BlockSizeLocationWithDataPath.java, 2012-2-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * @author zhangduo
 */
public class BlockSizeLocationWithDataPath implements IWritable {
    private long block;

    private int len;

    private String[] locations;

    public BlockSizeLocationWithDataPath() {}

    public BlockSizeLocationWithDataPath(long block, int len, String[] locations) {
        this.block = block;
        this.len = len;
        this.locations = locations;
    }

    public long getBlock() {
        return block;
    }

    public int getLen() {
        return len;
    }

    public String[] getLocations() {
        return locations;
    }

    public void setLocations(String[] locations) {
        this.locations = locations;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (block ^ (block >>> 32));
        result = prime * result + len;
        result = prime * result + Arrays.hashCode(locations);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        BlockSizeLocationWithDataPath other = (BlockSizeLocationWithDataPath) obj;
        return block == other.block && len == other.len
                && Arrays.equals(locations, other.locations);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        BlockSizeLocationWithDataPath that = (BlockSizeLocationWithDataPath) value;
        block = that.block;
        len = that.len;
        locations = Arrays.copyOf(that.locations, that.locations.length);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(block);
        CDataOutputStream.writeVInt(len, out);
        CDataOutputStream.writeVInt(locations.length, out);
        for (String location: locations) {
            StringWritable.writeString(out, location);
        }

    }

    @Override
    public void readFields(DataInput in) throws IOException {
        block = in.readLong();
        len = CDataInputStream.readVInt(in);
        int sz = CDataInputStream.readVInt(in);
        locations = new String[sz];
        for (int i = 0; i < sz; i++) {
            locations[i] = StringWritable.readString(in);
        }
    }

    @Override
    public String toString() {
        return "[BlockSizeLocationWithDataPath block=" + block + ", len=" + len
                + ", locations=" + Arrays.toString(locations) + "]";
    }

}
