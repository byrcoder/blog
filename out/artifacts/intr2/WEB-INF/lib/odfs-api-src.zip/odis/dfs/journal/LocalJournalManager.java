/**
 * @(#)LocalJournalManager.java, 2012-11-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.journal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileLock;
import java.util.Arrays;
import java.util.Comparator;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.common.DFSConfig;
import odis.dfs.util.DfsUtils;
import odis.io.ReadWriteUtils;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class LocalJournalManager implements JournalManager {

    private static final Logger LOG = LogFormatter.getLogger(LocalJournalManager.class);

    private static final String LOCK_FILE_NAME = ".lock";

    private static final String JOURNAL_FILE_PREFIX = "fsedit.";

    private static final String UNFINALIZED_JOURNAL_FILE_SUFFIX = ".new";

    private static final String CHECKSUM_FILE_SUFFIX = ".adler32";

    private final File dir;

    private final Adler32 adler32 = new Adler32();

    public LocalJournalManager(Configuration conf) throws IOException {
        this.dir = new File(conf.getString(DFSConfig.JOURNAL_ROOT_DIR));
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Can not create journal root "
                    + dir.getAbsolutePath());
        }
    }

    private static long getSN(String name) {
        int firstDot = name.indexOf('.');
        int secondDot = name.indexOf('.', firstDot + 1);
        if (secondDot < 0) {
            return Long.parseLong(name.substring(firstDot + 1));
        } else {
            return Long.parseLong(name.substring(firstDot + 1, secondDot));
        }
    }

    private static final FilenameFilter JOURNAL_FILTER = new FilenameFilter() {

        @Override
        public boolean accept(File dir, String name) {
            return name.startsWith(JOURNAL_FILE_PREFIX)
                    && !name.endsWith(CHECKSUM_FILE_SUFFIX);
        }
    };

    private static final Comparator<File> SN_COMPARATOR = new Comparator<File>() {

        @Override
        public int compare(File o1, File o2) {
            long sn1 = getSN(o1.getName());
            long sn2 = getSN(o2.getName());
            return sn1 > sn2 ? 1 : sn1 == sn2 ? 0 : -1;
        }
    };

    private FileOutputStream lockFileOut;

    private FileLock fileLock;

    private FileOutputStream out;

    private long currentSN;

    private void startNewSegment() throws FileNotFoundException {
        File newSegment = new File(dir, JOURNAL_FILE_PREFIX + currentSN
                + UNFINALIZED_JOURNAL_FILE_SUFFIX);
        LOG.info("Start new journal segment " + newSegment.getAbsolutePath());
        out = new FileOutputStream(newSegment);
        adler32.reset();
    }

    @Override
    public void recoverUnfinalizedSegmentAndStartNewSegment(long minimumSN)
            throws IOException {
        File lockFile = new File(dir, LOCK_FILE_NAME);
        lockFileOut = new FileOutputStream(lockFile);
        if ((fileLock = lockFileOut.getChannel().tryLock()) == null) {
            ReadWriteUtils.safeClose(lockFileOut);
            throw new IOException("Can not get file lock "
                    + lockFile.getAbsolutePath());
        }
        File[] journals = dir.listFiles(JOURNAL_FILTER);
        if (journals.length > 0) {
            Arrays.sort(journals, SN_COMPARATOR);
            if (journals[journals.length - 1].getName().endsWith(
                    UNFINALIZED_JOURNAL_FILE_SUFFIX)) {
                File unfinalizedJournal = journals[journals.length - 1];
                byte[] buf = new byte[8 * 1024];
                FileInputStream in = new FileInputStream(unfinalizedJournal);
                adler32.reset();
                try {
                    for (int r; (r = in.read(buf)) > 0;) {
                        adler32.update(buf, 0, r);
                    }
                } finally {
                    ReadWriteUtils.safeClose(in);
                }
                String prefix = unfinalizedJournal.getName().substring(
                        0,
                        unfinalizedJournal.getName().length()
                                - UNFINALIZED_JOURNAL_FILE_SUFFIX.length());
                File checksumFile = new File(dir, prefix + CHECKSUM_FILE_SUFFIX);
                DfsUtils.writeChecksum(checksumFile, (int) adler32.getValue());
                File finalizedJournal = new File(dir, prefix);
                if (!unfinalizedJournal.renameTo(finalizedJournal)) {
                    throw new IOException("Cannot rename "
                            + unfinalizedJournal.getAbsolutePath() + " to "
                            + finalizedJournal.getAbsolutePath());
                }
                currentSN = Math.max(minimumSN, getSN(prefix) + 1);
            } else {
                currentSN = Math.max(minimumSN,
                        getSN(journals[journals.length - 1].getName()) + 1);
            }
        } else {
            currentSN = minimumSN;
        }
        startNewSegment();
    }

    @Override
    public long currentOpenedSegmentSN() {
        return currentSN;
    }

    @Override
    public void write(byte[] buf) throws IOException {
        write(buf, 0, buf.length);
    }

    @Override
    public void write(byte[] buf, int off, int len) throws IOException {
        out.write(buf, off, len);
        out.getFD().sync();
        adler32.update(buf, off, len);
    }

    @Override
    public void finalizeSegmentAndStartNewSegment() throws IOException {
        out.close();
        File checksumFile = new File(dir, JOURNAL_FILE_PREFIX + currentSN
                + CHECKSUM_FILE_SUFFIX);
        DfsUtils.writeChecksum(checksumFile, (int) adler32.getValue());
        File unfinalizedJournal = new File(dir, JOURNAL_FILE_PREFIX + currentSN
                + UNFINALIZED_JOURNAL_FILE_SUFFIX);
        File finalizedJournal = new File(dir, JOURNAL_FILE_PREFIX + currentSN);
        if (!unfinalizedJournal.renameTo(finalizedJournal)) {
            throw new IOException("Cannot rename "
                    + unfinalizedJournal.getAbsolutePath() + " to "
                    + finalizedJournal.getAbsolutePath());
        }
        currentSN++;
        startNewSegment();
    }

    @Override
    public InputStream openFinalizedSegment(long sn) throws IOException {
        File journalFile = new File(dir, JOURNAL_FILE_PREFIX + sn);
        if (journalFile.exists()) {
            return new FileInputStream(journalFile);
        } else {
            return null;
        }
    }

    @Override
    public void deleteSegmentBefore(long sn) throws IOException {
        File[] journals = dir.listFiles(JOURNAL_FILTER);
        if (journals.length > 0) {
            Arrays.sort(journals);
            for (File journal: journals) {
                long jsn = getSN(journal.getName());
                if (jsn > sn
                        || journal.getName().endsWith(
                                UNFINALIZED_JOURNAL_FILE_SUFFIX)) {
                    break;
                }
                if (!journal.delete()) {
                    LOG.warning("Delete " + journal.getAbsolutePath()
                            + " failed");
                }
                File checksumFile = new File(dir, JOURNAL_FILE_PREFIX + jsn
                        + CHECKSUM_FILE_SUFFIX);
                if (!checksumFile.delete()) {
                    LOG.warning("Delete " + checksumFile.getAbsolutePath()
                            + " failed");
                }
            }
        }
    }

    public void close() {
        ReadWriteUtils.safeClose(out);
        ReadWriteUtils.safeReleaseFileLock(fileLock);
        ReadWriteUtils.safeClose(lockFileOut);
    }

    @Override
    public String toString() {
        return "LocalJournalManager " + dir.getAbsolutePath();
    }

    @Override
    public long maxFinalizedSegmentSN() {
        File[] journals = dir.listFiles(JOURNAL_FILTER);
        if (journals.length > 0) {
            Arrays.sort(journals, SN_COMPARATOR);
            if (journals[journals.length - 1].getName().endsWith(
                    UNFINALIZED_JOURNAL_FILE_SUFFIX)) {
                File unfinalizedJournal = journals[journals.length - 1];
                return getSN(unfinalizedJournal.getName()) - 1;
            } else {
                File finalizedJournal = journals[journals.length - 1];
                return getSN(finalizedJournal.getName());
            }
        }
        
        return 0;
    }
}
