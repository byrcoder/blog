/**
 * @(#)AbstractPrimaryFSBlockStore.java, 2012-12-11. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.AssignVolumeCommand;
import odis.dfs.common.BlockSize;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.DataNodeExpireException;
import odis.dfs.common.FSConstants;
import odis.dfs.common.INameToDataProtocol;
import odis.dfs.common.ShutdownCommand;
import odis.rpc2.RPC;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
abstract class AbstractPrimaryFSBlockStore extends AbstractFSBlockStore {

    private static final Logger LOG = LogFormatter.getLogger(AbstractPrimaryFSBlockStore.class);

    // host:dataDir to host:port
    protected final Map<String, String> datanodeHBMap;

    // host:port to datanode
    protected final ConcurrentMap<String, DatanodeInfo> datanodeMap;

    // host:dataDir to datanode
    protected final ConcurrentMap<String, DatanodeInfo> deadDatanodeMap;

    // Status on overall usage
    protected final AtomicLong totalCapacity = new AtomicLong(0);

    protected final AtomicLong totalRemaining = new AtomicLong(0);

    protected final long volume;

    AbstractPrimaryFSBlockStore(long volume, Map<Long, PlacedBlock> blockMap,
            Map<Long, PlacedBlock> activeBlocks,
            Map<String, String> datanodeHBMap,
            ConcurrentMap<String, DatanodeInfo> datanodeMap,
            ConcurrentMap<String, DatanodeInfo> deadDatanodeMap) {
        super(blockMap, activeBlocks);
        this.volume = volume;
        this.datanodeHBMap = datanodeHBMap;
        this.datanodeMap = datanodeMap;
        this.deadDatanodeMap = deadDatanodeMap;
    }

    protected abstract DataNodeCommand[] getDataNodeCommands(DatanodeInfo dinfo);

    protected abstract void datanodeAdded(DatanodeInfo dinfo);

    protected abstract void datanodeDied(DatanodeInfo dinfo);

    @Override
    void activateBlock(long block) throws IllegalStateException {
        synchronized (blockMap) {
            super.activateBlock(block);
        }
    }

    PlacedBlock getBlock(long block) {
        synchronized (blockMap) {
            PlacedBlock pb = activeBlocks.get(block);
            return pb != null ? pb : blockMap.get(block);
        }
    }

    abstract void datanodeBlockReport(String datanodeFullName,
            BlockSize[] blocks);

    abstract void datanodeReportBlockReceivedOrDeleted(String datanodeFullName,
            BlockSize[] received, long[] deleted);

    abstract void datanodeReplicationDone(String datanodeFullName,
            BlockSizeLocationWithDataPath lblock);

    /**
     * Connection of a new datanode along with all its blocks.
     * 
     * @param datanodeFullName
     * @param blocks
     * @param capacity
     * @param remaining
     * @param vol
     * @return a ShutdownCommand or an AssignVolumeCommand or null.
     */
    DataNodeCommand datanodeConnect(String datanodeFullName,
            BlockSize[] blocks, long capacity, long remaining, long volume) {
        if (volume != FSConstants.VOLUME_NA && volume != this.volume) {
            LOG.warning("Datanode connected with the wrong volume: "
                    + HexString.longToPaddedHex(volume) + ", expected "
                    + HexString.longToPaddedHex(this.volume));
            return new ShutdownCommand("Wrong volume "
                    + HexString.longToPaddedHex(volume) + ", expected "
                    + HexString.longToPaddedHex(this.volume));
        }
        boolean alreadyExists = false;
        DatanodeInfo dinfo = null;
        String datanodeHBKey = DatanodeInfo.getDatanodeHBKeyFromFullName(datanodeFullName);
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        String datanodeDir = DatanodeInfo.getDirFromFullName(datanodeFullName);
        synchronized (datanodeHBMap) {
            String datanodeMapKey = datanodeHBMap.get(datanodeHBKey);
            if (datanodeMapKey != null) {
                if (datanodeMapKey.equals(datanodeName)) {
                    LOG.info("Datanode " + datanodeFullName
                            + " already exists!"
                            + " This connect will be ignored.");
                    alreadyExists = true;
                    dinfo = datanodeMap.get(datanodeName);
                    // reset the capacity and remaining
                    // This may happen when a datanode restart quickly
                    totalCapacity.addAndGet(capacity - dinfo.getCapacity());
                    totalRemaining.addAndGet(remaining - dinfo.getRemaining());
                    dinfo.setCapacity(capacity);
                    dinfo.setRemaining(remaining);
                } else {
                    LOG.log(Level.WARNING,
                            "Datanode "
                                    + datanodeFullName
                                    + " connect again but its port changed! old port is :"
                                    + datanodeMapKey);
                    datanodeDisconnect(datanodeMapKey + ":" + datanodeDir);
                }
            }
            if (!alreadyExists) {
                dinfo = datanodeMap.get(datanodeName);
                if (dinfo != null) {
                    LOG.warning("Datanode "
                            + dinfo.getFullName()
                            + " must be disconnect because another datanode use its port now :"
                            + datanodeFullName);
                    datanodeDisconnect(dinfo.getFullName());
                }
                INameToDataProtocol proxy = RPC.getUDPProxy(
                        INameToDataProtocol.class,
                        new InetSocketAddress(
                                DatanodeInfo.getHostFromFullName(datanodeFullName),
                                DatanodeInfo.getPortFromFullName(datanodeFullName)));
                dinfo = new DatanodeInfo(datanodeFullName, capacity, remaining,
                        proxy);
                LOG.info("Incoming datanode: " + datanodeFullName + " with "
                        + blocks.length + " blocks, capcity=" + capacity
                        + ", remaining=" + remaining + ", reserved="
                        + dinfo.getReserved());
                datanodeHBMap.put(datanodeHBKey, datanodeName);
                datanodeMap.put(datanodeName, dinfo);
            }
        }
        if (alreadyExists) {
            datanodeBlockReport(datanodeFullName, blocks);
            return null;
        }
        totalCapacity.addAndGet(capacity);
        totalRemaining.addAndGet(remaining);
        datanodeBlockReport(datanodeFullName, blocks);
        datanodeAdded(dinfo);

        DatanodeInfo deadInfo = deadDatanodeMap.remove(datanodeHBKey);
        if (deadInfo != null) {
            LOG.info("The incomming Datanode " + datanodeHBKey + " died "
                    + (System.currentTimeMillis() - deadInfo.lastUpdate())
                    + " ms ago.");
        }
        if (volume == FSConstants.VOLUME_NA) {
            return new AssignVolumeCommand(this.volume);
        } else {
            return null;
        }
    }

    /**
     * Process the disconnection of a datanode. This involves removing all its
     * blocks from our data structures and the trigerring of replication if
     * needed. Note that this method can be called from two places: the
     * heartbeat monitor and the namenode connection listener. In the first case
     * the caller is iterating through heartbeats so we should not remove the
     * datanode here otherwise a ConcurrentModificationException will be thrown.
     * In the second case it is our responsibility to remove the node since the
     * caller won't.
     */
    void datanodeDisconnect(String datanodeFullName) {
        LOG.info("Datanode " + datanodeFullName + " disconnect");
        DatanodeInfo dinfo;
        int liveNodes = 0;

        String datanodeHBKey = DatanodeInfo.getDatanodeHBKeyFromFullName(datanodeFullName);
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        synchronized (datanodeHBMap) {
            datanodeHBMap.remove(datanodeHBKey);
            dinfo = datanodeMap.remove(datanodeName);
            if (dinfo == null) {
                return;
            }
            liveNodes = datanodeMap.size();
        }
        RPC.closeUDPProxy(dinfo.getProxy());
        deadDatanodeMap.put(datanodeHBKey, dinfo);
        LOG.info("Datanode disconnected: " + dinfo + ", there are " + liveNodes
                + " live datanodes left.");
        totalCapacity.addAndGet(-dinfo.getCapacity());
        totalRemaining.addAndGet(-dinfo.getRemaining());

        datanodeDied(dinfo);
        LOG.info("Done processing disconnected datanode " + datanodeFullName);
    }

    DataNodeCommand[] datanodeHeartbeat(String datanodeFullName,
            long remaining, int xmitsInProgress, boolean getCmds) {
        String datanodeHBKey = DatanodeInfo.getDatanodeHBKeyFromFullName(datanodeFullName);
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo;
        synchronized (datanodeHBMap) {
            String expectedDataNodeName = datanodeHBMap.get(datanodeHBKey);
            if (!datanodeName.equals(expectedDataNodeName)) {
                LOG.info("Got heartbeat from unknown datanode " + datanodeName
                        + ". Tell datanode to reconnect.");
                throw new DataNodeExpireException(
                        "Your information is expired. Please reconnect.");
            }

            dinfo = datanodeMap.get(datanodeName);
            if (dinfo == null) {
                throw new DataNodeExpireException(
                        "Your information is expired. Please reconnect.");
            }
        }

        if (dinfo.getRemaining() != remaining) {
            totalRemaining.addAndGet(remaining - dinfo.getRemaining());
            dinfo.setRemaining(remaining);
        }
        dinfo.updateHeartbeat();
        return getCmds ? getDataNodeCommands(dinfo)
                : DataNodeCommand.EMPTY_ARRAY;
    }

    DatanodeInfo getDatanode(String name) {
        return datanodeMap.get(name);
    }

    int datanodeNumber() {
        return datanodeMap.size();
    }

    DatanodeInfo[] datanodeReport() {
        return datanodeMap.values().toArray(new DatanodeInfo[0]);
    }

    DatanodeInfo[] deadDatanodeReport() {
        return deadDatanodeMap.values().toArray(new DatanodeInfo[0]);
    }

    long inactiveBlockNumber() {
        synchronized (blockMap) {
            return blockMap.size();
        }
    }

    long activeBlockNumber() {
        synchronized (blockMap) {
            return activeBlocks.size();
        }
    }

    long totalCapacity() {
        return totalCapacity.get();
    }

    long totalRemaining() {
        return totalRemaining.get();
    }
}
