/**
 * @(#)ActiveFSBlockStore.java, 2012-12-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSize;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.CheckConsistencyCommand;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.DataNodeExpireException;
import odis.dfs.common.DeleteBlockCommand;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.common.ForceCompleteBlockCommand;
import odis.dfs.common.WriteChecksumCommand;
import odis.dfs.util.DfsUtils;
import odis.rpc2.AsyncRpcCallEntry;
import odis.util.DaemonTracker;

import org.apache.commons.configuration.Configuration;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.collections.Pair;
import toolbox.collections.primitive.LongArrayList;
import toolbox.misc.LinearCongruentialGenerator;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class ActiveFSBlockStore extends AbstractPrimaryFSBlockStore implements
        FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(ActiveFSBlockStore.class);

    final BlockPlacementPolicy blockPlacementPolicy;

    final BlockReplicator replicator;

    private final DelayedBlockReplicationChecker delayedReplicationChecker;

    /**
     * For background check tasks such as heartbeat check and reservation check.
     */
    private final ScheduledExecutorService backgroundTaskPool;

    private final BlockConsistencyChecker blockConsistencyChecker;

    static interface PendingBlockChecker {
        boolean isBlockPending(long block);
    }

    private final PendingBlockChecker pendingBlockChecker;

    //
    // Timeout constants
    //
    private final long reservationMonitorInterval;

    private final long reservationPeriodMax;

    private final long heartbeatInterval;

    private final long newBlockCheckReplicationDelay;

    private final long expireInterval;

    private long blockIdGeneratorSeed = System.currentTimeMillis();

    private long chooseBlockId() {
        long blockId = LinearCongruentialGenerator.nextLong(blockIdGeneratorSeed);
        synchronized (blockMap) {
            while ((blockId >= RESERVED_BLOCK_LOWER && blockId < RESERVED_BLOCK_UPPER)
                    || activeBlocks.containsKey(blockId)
                    || blockMap.containsKey(blockId)) {
                blockId = LinearCongruentialGenerator.nextLong(blockId);
            }
            blockIdGeneratorSeed = blockId;
        }
        return blockId;
    }

    private final DateTimeFormatter dtf = DateTimeFormat.mediumDateTime();

    private void heartbeatCheck() {
        long currentTime = System.currentTimeMillis();
        for (DatanodeInfo dinfo: datanodeMap.values()) {
            long lastHeartbeat = dinfo.lastUpdate();
            if (lastHeartbeat < currentTime - expireInterval) {
                String fullName = dinfo.getFullName();
                LOG.info("Lost heartbeat for " + fullName
                        + ", last heartbeat at " + dtf.print(lastHeartbeat));
                datanodeDisconnect(fullName);
            }
        }
    }

    private void reservationCheck() {
        LOG.info("Checking reservations...");
        for (DatanodeInfo dinfo: datanodeMap.values()) {
            long[] longTimeReservations = dinfo.getReservationsBeforeTime(System.currentTimeMillis()
                    - reservationPeriodMax);
            for (long block: longTimeReservations) {
                if (!replicator.isRelicating(block)
                        && !pendingBlockChecker.isBlockPending(block)) {
                    LOG.info("unreserve " + block + " from " + dinfo
                            + " for it is pending for a long time");
                    dinfo.unreserve(block);
                }
            }
        }
    }

    void reduceReplication(PlacedBlock pb) {
        replicator.cancelReplication(pb.getId());
        DatanodeInfo[] toDeleted = blockPlacementPolicy.calcToDeletedLocations(
                pb.getLocs(), pb.getDesiredReplication());
        LOG.info("Delete block " + pb.getId() + " from "
                + Arrays.toString(toDeleted)
                + " becasue of over-replicated(desired "
                + pb.getDesiredReplication() + ", actual "
                + pb.replicationCount() + ")");
        for (DatanodeInfo dinfo: toDeleted) {
            pb.removeLoc(dinfo);
            dinfo.removeAndPrepareToDeleteBlock(pb.getId());
        }
    }

    ActiveFSBlockStore(Configuration conf,
            PendingBlockChecker pendingBlockChecker, long volume) {
        this(conf, pendingBlockChecker, volume,
                new HashMap<Long, PlacedBlock>(),
                new HashMap<Long, PlacedBlock>(),
                new HashMap<String, String>(),
                new ConcurrentHashMap<String, DatanodeInfo>(),
                new ConcurrentHashMap<String, DatanodeInfo>());

    }

    ActiveFSBlockStore(Configuration conf,
            PendingBlockChecker pendingBlockChecker, long volume,
            Map<Long, PlacedBlock> blockMap,
            Map<Long, PlacedBlock> activeBlocks,
            Map<String, String> datanodeHBMap,
            ConcurrentMap<String, DatanodeInfo> datanodeMap,
            ConcurrentMap<String, DatanodeInfo> deadDatanodeMap) {
        super(volume, blockMap, activeBlocks, datanodeHBMap, datanodeMap,
                deadDatanodeMap);
        this.pendingBlockChecker = pendingBlockChecker;
        this.heartbeatInterval = conf.getLong(
                DFSConfig.DATANODE_HEARTBEAT_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_HEARTBEAT_INTERVAL);
        this.expireInterval = conf.getLong(DFSConfig.DATANODE_HEARTBEAT_EXPIRE,
                10 * heartbeatInterval);
        this.reservationMonitorInterval = conf.getLong(
                DFSConfig.RESERVATION_MONITOR_INTERVAL,
                DFSConfig.DEFAULT_RESERVATION_MONITOR_INTERVAL);
        this.reservationPeriodMax = conf.getLong(
                DFSConfig.RESERVATION_PERIOD_MAX,
                DFSConfig.DEFAULT_RESERVATION_PERIOD_MAX);
        this.newBlockCheckReplicationDelay = conf.getLong(
                DFSConfig.NEW_BLOCK_CHECK_REPLICATION_DELAY,
                DFSConfig.DEFAULT_NEW_BLOCK_CHECK_REPLICATION_DELAY);
        blockPlacementPolicy = DfsUtils.createFromConf(conf.getString(
                DFSConfig.BLOCK_PLACEMENT_POLICY_CLASS,
                DFSConfig.DEFAULT_BLOCK_PLACEMENT_POLICY_CLASS), conf,
                BlockPlacementPolicy.class);
        for (DatanodeInfo dinfo: datanodeMap.values()) {
            blockPlacementPolicy.addDatanode(dinfo);
        }
        backgroundTaskPool = Executors.newScheduledThreadPool(1,
                new ThreadFactory() {

                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, "Background-Task");
                        t.setDaemon(true);
                        return t;
                    }
                });
        backgroundTaskPool.scheduleAtFixedRate(new Runnable() {

            private DaemonTracker tr = new DaemonTracker();

            @Override
            public void run() {
                try {
                    heartbeatCheck();
                } catch (Throwable t) {
                    tr.gotThrowable(t);
                }

            }
        }, heartbeatInterval, heartbeatInterval, TimeUnit.MILLISECONDS);
        backgroundTaskPool.scheduleAtFixedRate(new Runnable() {

            private DaemonTracker tr = new DaemonTracker();

            @Override
            public void run() {
                try {
                    reservationCheck();
                } catch (Throwable t) {
                    tr.gotThrowable(t);
                }
            }
        }, reservationMonitorInterval, reservationMonitorInterval,
                TimeUnit.MILLISECONDS);
        replicator = new BlockReplicator(this, conf);
        delayedReplicationChecker = new DelayedBlockReplicationChecker(this,
                conf);
        blockConsistencyChecker = new BlockConsistencyChecker(this);
        // Backup FSBlockStore do not check replication, it only receive block
        // add and delete message from datanode and change replication. So here
        // we schedule a delayed check if a block's replication number is not 
        // correct
        verifyReplication(activeBlocks.values());
        verifyReplication(blockMap.values());
    }

    private void verifyReplication(Collection<PlacedBlock> pbs) {
        long currentTime = System.currentTimeMillis();
        for (PlacedBlock pb: pbs) {
            if (pb.replicationCount() != pb.getDesiredReplication()) {
                delayedReplicationChecker.add(pb.getId(), currentTime
                        + heartbeatInterval * 2);
            }
        }
    }

    void setReady() {
        replicator.start();
        delayedReplicationChecker.start();
    }

    @Override
    void addBlock(long block, int len, int desiredReplications) {
        synchronized (blockMap) {
            super.addBlock(block, len, desiredReplications);
        }
    }

    private void checkReplication(PlacedBlock pb) {
        long block = pb.getId();
        int replicationCount = pb.replicationCount();
        int desiredReplication = pb.getDesiredReplication();
        if (replicationCount > desiredReplication) {
            reduceReplication(pb);
        } else if (replicationCount == desiredReplication) {
            replicator.cancelReplication(block);
        } else {
            replicator.requestReplication(block, replicationCount);
        }
    }

    /**
     * Add a replication for the given PlacedBlock.
     * 
     * @param pb
     * @param len
     * @param dinfo
     */
    private void blockReplicaAdded(PlacedBlock pb, int len, DatanodeInfo dinfo) {
        long block = pb.getId();
        dinfo.unreserve(block);
        if (pb.getLen() > len) {
            LOG.info("Deleting block " + block + " from " + dinfo
                    + " because block size is invalid(expected " + pb.getLen()
                    + ", actual " + len);
            dinfo.removeAndPrepareToDeleteBlock(block);
            pb.removeLoc(dinfo);
        } else {
            if (pb.getLen() < len) {
                DatanodeInfo[] locations = pb.getLocs();
                for (DatanodeInfo loc: locations) {
                    LOG.info("Deleting block " + block + " from " + loc
                            + " because block size is invalid(origin is "
                            + pb.getLen() + ", new reported from " + dinfo
                            + " is " + len + ").");
                    loc.removeAndPrepareToDeleteBlock(block);
                }
                pb.clearLocs();
                pb.setLen(len);
            }
            pb.addLoc(dinfo);
            dinfo.addBlock(block);
        }
    }

    /**
     * Remove a replication for the given PlacedBlock.
     * 
     * @param pb
     * @param dinfo
     * @param checkReplication
     */
    private void blockReplicaRemoved(PlacedBlock pb, DatanodeInfo dinfo,
            boolean checkReplication) {
        synchronized (pb) {
            if (!pb.removeLoc(dinfo)) {
                LOG.warning("No machine mapping found for block " + pb
                        + ", which should be at node " + dinfo);
            }
            if (checkReplication) {
                checkReplication(pb);
            }
        }
    }

    @Override
    void datanodeBlockReport(String datanodeFullName, BlockSize[] blocks) {
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo = datanodeMap.get(datanodeName);
        if (dinfo == null) {
            throw new DataNodeExpireException(
                    "Your information is expired, please reconnect");
        }
        Pair<List<BlockSize>, LongArrayList> pair = dinfo.getDiff(blocks);
        LongArrayList toInvalidate = new LongArrayList();
        // new blocks
        for (BlockSize block: pair.getFirst()) {
            PlacedBlock pb = getBlock(block.getBlock());
            if (pb != null) {
                synchronized (pb) {
                    blockReplicaAdded(pb, block.getLen(), dinfo);
                    if (pb.replicationCount() > pb.getDesiredReplication()
                            && pb.containsLoc(dinfo)) {
                        // always delete newly added location to prevent data 
                        // loss(maybe the block is already deleted after 
                        // datanode generating block report data).
                        pb.removeLoc(dinfo);
                        toInvalidate.add(block.getBlock());
                    }
                    checkReplication(pb);
                }
            } else {
                toInvalidate.add(block.getBlock());
            }
        }
        // missed block
        long[] missedBlocks = pair.getSecond().toArray();
        dinfo.removeBlocks(missedBlocks);
        for (long block: missedBlocks) {
            PlacedBlock pb = getBlock(block);
            if (pb != null) {
                blockReplicaRemoved(pb, dinfo, true);
            }
        }

        if (!toInvalidate.isEmpty()) {
            dinfo.removeAndPrepareToDeleteBlocks(toInvalidate.toArray());
        }
    }

    @Override
    void datanodeReportBlockReceivedOrDeleted(String datanodeFullName,
            BlockSize[] received, long[] deleted) {
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo = datanodeMap.get(datanodeName);
        if (dinfo == null) {
            throw new DataNodeExpireException(
                    "Your information is expired, please reconnect");
        }
        LongArrayList toInvalidate = new LongArrayList();
        for (BlockSize block: received) {
            PlacedBlock pb = getBlock(block.getBlock());
            if (pb != null) {
                synchronized (pb) {
                    blockReplicaAdded(pb, block.getLen(), dinfo);
                    if (pb.replicationCount() < pb.getDesiredReplication()) {
                        delayedReplicationChecker.add(pb.getId(),
                                System.currentTimeMillis()
                                        + newBlockCheckReplicationDelay);
                    } else {
                        delayedReplicationChecker.remove(pb.getId());
                        if (pb.replicationCount() > pb.getDesiredReplication()) {
                            reduceReplication(pb);
                        }
                    }
                }
            } else {
                toInvalidate.add(block.getBlock());
            }
        }
        for (long id: deleted) {
            PlacedBlock pb = getBlock(id);
            if (pb != null) {
                synchronized (pb) {
                    // this may happen when we upgrade from backup just now.
                    if (pb.removeLoc(dinfo)) {
                        delayedReplicationChecker.remove(id);
                        checkReplication(pb);
                    }
                }
            }
        }
        if (!toInvalidate.isEmpty()) {
            dinfo.removeAndPrepareToDeleteBlocks(toInvalidate.toArray());
        }
    }

    /**
     * Callback from datanode reporting finish of a replication
     */
    @Override
    void datanodeReplicationDone(String datanodeFullName,
            BlockSizeLocationWithDataPath lblock) {
        long block = lblock.getBlock();
        DatanodeInfo dinfo = datanodeMap.get(DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName));
        if (dinfo == null) {
            throw new DataNodeExpireException(
                    "Your information is expired, please reconnect");
        }
        replicator.replicationDone(block);
        String[] reservedLocs = dinfo.replicationDone(block);
        if (reservedLocs != null) {
            unreserveBlock(block, reservedLocs);
        }
        String[] locs = lblock.getLocations();
        PlacedBlock pb = getBlock(block);
        // replication failed
        if (locs.length == 0) {
            if (pb == null) {
                LOG.warning("Cannot find record for " + block);
                return;
            }
            synchronized (pb) {
                checkReplication(pb);
            }
            return;
        }
        if (pb == null) {
            for (String loc: locs) {
                DatanodeInfo target = datanodeMap.get(DatanodeInfo.getDatanodeNameFromFullName(loc));
                if (target == null) {
                    LOG.warning("Cannot find target datanode for " + loc
                            + " when report replication");
                    continue;
                }
                LOG.warning("Cannot find record for " + lblock.getBlock());
                dinfo.removeAndPrepareToDeleteBlock(block);
            }
            return;
        }
        synchronized (pb) {
            for (String loc: locs) {
                DatanodeInfo target = datanodeMap.get(DatanodeInfo.getDatanodeNameFromFullName(loc));
                if (target == null) {
                    LOG.warning("Cannot find target datanode for " + loc
                            + " when report replication");
                    continue;
                }
                blockReplicaAdded(pb, pb.getLen(), target);
            }
            checkReplication(pb);
        }
    }

    @Override
    protected void datanodeAdded(DatanodeInfo dinfo) {
        blockPlacementPolicy.addDatanode(dinfo);
    }

    @Override
    protected DataNodeCommand[] getDataNodeCommands(DatanodeInfo dinfo) {
        List<DataNodeCommand> cmds = new ArrayList<DataNodeCommand>();
        long[] toBeDeletedBlocks = dinfo.getAndClearToBeDeletedBlocks();
        if (toBeDeletedBlocks.length > 0) {
            cmds.add(new DeleteBlockCommand(toBeDeletedBlocks));
        }
        long[] forceCompleteBlocks = dinfo.getAndClearForceCompleteBlocks();
        if (forceCompleteBlocks.length > 0) {
            cmds.add(new ForceCompleteBlockCommand(forceCompleteBlocks));
        }
        long[] checkConsistencyBlocks = dinfo.getAndClearCheckConsistencyBlocks();
        if (checkConsistencyBlocks.length > 0) {
            cmds.add(new CheckConsistencyCommand(checkConsistencyBlocks));
        }
        dinfo.getReplicationCommands(cmds);
        dinfo.getAndClearWriteChecksumBlocks(cmds);
        return cmds.toArray(DataNodeCommand.EMPTY_ARRAY);
    }

    @Override
    protected void datanodeDied(DatanodeInfo dinfo) {
        long[] deadBlocks = dinfo.getBlocks();
        for (long block: deadBlocks) {
            PlacedBlock pb = getBlock(block);
            if (pb != null) {
                blockReplicaRemoved(pb, dinfo, true);
            }
        }
        blockPlacementPolicy.removeDatanode(dinfo);
        replicator.datanodeDied(dinfo);
    }

    long getActiveBlockLen(long block) {
        PlacedBlock pb;
        synchronized (blockMap) {
            pb = activeBlocks.get(block);
        }
        if (pb == null) {
            return 0;
        }
        synchronized (pb) {
            return pb.getLen();
        }
    }

    @Override
    void changeReplication(long[] blocks, int replications) {
        for (long block: blocks) {
            PlacedBlock pb = getBlock(block);
            if (pb == null) {
                continue;
            }
            synchronized (pb) {
                if (pb.getDesiredReplication() > replications) {
                    DatanodeInfo[] toDeleted = blockPlacementPolicy.calcToDeletedLocations(
                            pb.getLocs(), replications);
                    for (DatanodeInfo loc: toDeleted) {
                        pb.removeLoc(loc);
                        loc.removeAndPrepareToDeleteBlock(block);
                    }
                    pb.setDesiredReplication(replications);
                } else if (pb.getDesiredReplication() < replications) {
                    replicator.requestReplication(block,
                            pb.getDesiredReplication());
                    pb.setDesiredReplication(replications);
                }
            }
        }
    }

    /**
     * Allocate a new block on several datanodes and assign a unique name to it.
     * The block is in pending status after this and should be made permanent by
     * either
     * {@link #datanodeReportBlockReceivedOrDeleted(String, BlockSize[], long[])}
     * or {@link #datanodeHeartbeat(String, long, long[])}. Or it can be removed
     * by {@link #datanodeDisconnect(String, boolean)}.
     * 
     * @param desiredReplication
     *            desired replication factor
     * @param fileBlockSize
     *            the preferred block size of the file
     */
    BlockLocationWithDataPath allocateBlock(String clientMachine,
            int desiredReplication, int fileBlockSize) throws FSException {
        long block = chooseBlockId();
        DatanodeInfo[] targets = blockPlacementPolicy.chooseTargets(
                clientMachine, block, desiredReplication, null, fileBlockSize);
        return new BlockLocationWithDataPath(block,
                DatanodeInfo.toLocationsWithDataPath(targets));
    }

    /**
     * Unreserve block on the given datanodes.
     * 
     * @param block
     * @param locs
     */
    void unreserveBlock(long block, String[] locs) {
        for (String loc: locs) {
            DatanodeInfo dinfo = datanodeMap.get(DatanodeInfo.getDatanodeNameFromFullName(loc));
            if (dinfo != null) {
                dinfo.unreserve(block);
            }
        }
    }

    /**
     * Force complete block from reservation.
     * 
     * @param blockId
     */
    void forceCompleteBlock(long blockId, String[] locations) {
        for (String loc: locations) {
            DatanodeInfo dinfo = datanodeMap.get(DatanodeInfo.getDatanodeNameFromFullName(loc));
            if (dinfo != null) {
                try {
                    dinfo.getProxy().sendCommand(new DataNodeCommand[] {
                        new ForceCompleteBlockCommand(new long[] {
                            blockId
                        })
                    });
                } catch (Exception e) {
                    LOG.log(Level.WARNING,
                            "failed to send ForceCompleteBlockCommand to datanode "
                                    + dinfo, e);
                }
                dinfo.addForceCompleteBlock(blockId);
            }
        }
    }

    void trashBlocks(long[] blocks, String reason) {
        LOG.info("Delete blocks " + Arrays.toString(blocks) + " because of "
                + reason);
        synchronized (blockMap) {
            for (long block: blocks) {
                PlacedBlock pb = activeBlocks.remove(block);
                if (pb == null) {
                    pb = blockMap.remove(block);
                }
                if (pb == null) {
                    continue;
                }
                synchronized (pb) {
                    for (DatanodeInfo dinfo: pb.getLocs()) {
                        dinfo.removeAndPrepareToDeleteBlock(block);
                    }
                }
            }
        }
    }

    long toReplicateSize() {
        return replicator.getToReplicateSize();
    }

    long replicatingSize() {
        return replicator.getReplicatingSize();
    }

    void recoverInconsistentBlock(long block, String initiatingDataNode,
            BlockCheckResult result) {
        blockConsistencyChecker.scheduleCheck(block, initiatingDataNode, result);
    }

    void reportConsistencyCheckResult(long block, String datanodeFullName,
            BlockCheckResult result) {
        PlacedBlock pb = getBlock(block);
        if (pb != null) {
            int replication;
            synchronized (pb) {
                replication = pb.getLocs().length;
            }
            blockConsistencyChecker.reportCheck(block, datanodeFullName,
                    result, replication);
        }
    }

    void verifyBlock(AsyncRpcCallEntry rpcCallEntry, long block) {
        blockConsistencyChecker.scheduleCheck(block, rpcCallEntry);
    }

    void writeChecksum(long block, String datanodeFullName, long checksum) {
        String datanodeName = DatanodeInfo.getDatanodeNameFromFullName(datanodeFullName);
        DatanodeInfo dinfo = datanodeMap.get(datanodeName);
        if (dinfo != null) {
            dinfo.addWriteChecksumBlock(new WriteChecksumCommand(block,
                    checksum));
        }
    }

    /**
     * Remove the specified replica of a block and request creating some replica
     * to maintain the total number of replica.
     */
    void recreateReplica(long block, String[] datanodes) {
        PlacedBlock pb = getBlock(block);
        if (pb == null) {
            return;
        }
        synchronized (pb) {
            for (String node: datanodes) {
                String name = DatanodeInfo.getDatanodeNameFromFullName(node);
                DatanodeInfo dinfo = datanodeMap.get(name);
                if (dinfo == null) {
                    continue;
                }
                pb.removeLoc(dinfo);
                dinfo.removeAndPrepareToDeleteBlock(block);
            }
        }
        delayedReplicationChecker.add(block, System.currentTimeMillis()
                + heartbeatInterval / 2 * 3);
    }

    @Override
    public void close() {
        backgroundTaskPool.shutdownNow();
        replicator.close();
        delayedReplicationChecker.close();
        try {
            replicator.join();
        } catch (InterruptedException e) {}
        try {
            delayedReplicationChecker.join();
        } catch (InterruptedException e) {}
    }

}
