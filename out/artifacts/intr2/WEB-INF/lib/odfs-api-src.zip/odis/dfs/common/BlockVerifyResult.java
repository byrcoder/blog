/**
 * @(#)BlockVerifySummary.java, 2012-5-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * @author zhangduo
 */
public class BlockVerifyResult implements IWritable {

    private long blockId;

    private boolean error;

    private boolean fixed;

    private Map<String, BlockCheckResult> results;

    public BlockVerifyResult() {}

    public BlockVerifyResult(long blockId, boolean fixed, boolean error,
            Map<String, BlockCheckResult> results) {
        this.blockId = blockId;
        this.error = error;
        this.fixed = fixed;
        this.results = results;
    }

    public long getBlockId() {
        return blockId;
    }

    public boolean isError() {
        return error;
    }

    public boolean isFixed() {
        return fixed;
    }

    public Map<String, BlockCheckResult> getResults() {
        return results;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        BlockVerifyResult that = (BlockVerifyResult) value;
        blockId = that.blockId;
        error = that.error;
        fixed = that.fixed;
        results = new HashMap<String, BlockCheckResult>(that.results);
        return this;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        blockId = in.readLong();
        error = in.readBoolean();
        fixed = in.readBoolean();
        int sz = CDataInputStream.readVInt(in);
        results = new HashMap<String, BlockCheckResult>(sz);
        for (int i = 0; i < sz; i++) {
            String name = StringWritable.readString(in);
            BlockCheckResult result = new BlockCheckResult();
            result.readFields(in);
            results.put(name, result);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(blockId);
        out.writeBoolean(error);
        out.writeBoolean(fixed);
        CDataOutputStream.writeVInt(results.size(), out);
        for (Map.Entry<String, BlockCheckResult> entry: results.entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            entry.getValue().writeFields(out);
        }
    }

    @Override
    public String toString() {
        return "BlockVerifyResult [blockId=" + blockId + ", error=" + error
                + ", fixed=" + fixed + ", results=" + results + "]";
    }

}
