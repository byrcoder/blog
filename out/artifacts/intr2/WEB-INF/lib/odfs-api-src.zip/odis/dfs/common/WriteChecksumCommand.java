/**
 * @(#)WriteChecksumCommand.java, 2012-5-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.dfs.datanode.DataNode;
import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class WriteChecksumCommand extends DataNodeCommand {

    private long block;

    private long checksum;

    public WriteChecksumCommand() {}

    public WriteChecksumCommand(long block, long checksum) {
        this.block = block;
        this.checksum = checksum;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(block);
        out.writeLong(checksum);
    }

    public long getBlock() {
        return block;
    }

    public long getChecksum() {
        return checksum;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        block = in.readLong();
        checksum = in.readLong();
    }

    @Override
    public IWritable copyFields(IWritable value) {
        WriteChecksumCommand that = (WriteChecksumCommand) value;
        block = that.block;
        checksum = that.checksum;
        return this;
    }

    @Override
    public void execute(DataNode dataNode) {
        dataNode.scheduleChecksumWrite(block, checksum);
    }

}
