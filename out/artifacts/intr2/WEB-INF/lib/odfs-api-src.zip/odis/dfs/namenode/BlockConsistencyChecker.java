/**
 * @(#)BlockChecker.java, 2009-2-16. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.FSConstants;
import odis.rpc2.AsyncRpcCallEntry;
import toolbox.misc.LogFormatter;

/**
 * Maintain a list of blocks that need to be check for consistency
 * <p>
 * TODO: need to clear dead checks.
 * 
 * @author zhangkun
 */
class BlockConsistencyChecker implements FSConstants {
    private static final Logger LOG = LogFormatter.getLogger(BlockConsistencyChecker.class);

    private static class CheckEntry {
        private final AsyncRpcCallEntry rpcCall;

        @SuppressWarnings("unused")
        private final long startTime;

        private final Map<String, BlockCheckResult> results;

        private CheckEntry(AsyncRpcCallEntry rpcCall, long startTime,
                Map<String, BlockCheckResult> results) {
            this.rpcCall = rpcCall;
            this.startTime = startTime;
            this.results = results;
        }

    }

    private final Map<Long, CheckEntry> checking = new HashMap<Long, CheckEntry>();

    private final ActiveFSBlockStore bstore;

    BlockConsistencyChecker(ActiveFSBlockStore bstore) {
        this.bstore = bstore;
    }

    private void scheduleCheckCommand(long block, Set<String> excludeDatanodes) {
        PlacedBlock pb = bstore.getBlock(block);
        if (pb == null) {
            LOG.warning("Failed to get information of " + block);
            return;
        };
        DatanodeInfo[] locs;
        synchronized (pb) {
            locs = pb.getLocs();
        }
        for (DatanodeInfo loc: locs) {
            if (excludeDatanodes.contains(loc.getFullName())) {
                continue;
            }
            loc.addCheckConsistencyBlock(block);
        }
    }

    /**
     * Schedule a consistency check for the specified block
     * 
     * @param block
     */
    void scheduleCheck(long block, AsyncRpcCallEntry rpcCall) {
        boolean schedule;
        synchronized (checking) {
            if (!checking.containsKey(block)) {
                schedule = true;
                CheckEntry entry = new CheckEntry(rpcCall,
                        System.currentTimeMillis(),
                        new HashMap<String, BlockCheckResult>());
                checking.put(block, entry);
            } else {
                schedule = false;
            }
        }
        if (schedule) {
            Set<String> excludes = Collections.emptySet();
            scheduleCheckCommand(block, excludes);
        }
    }

    /**
     * Schedule a consistency check, and record the result of the initiator. A
     * check can only be requested by a DataNode, after it has checked the block
     * stored on its own and found inconsistency.
     * 
     * @param block
     *            the block to be checked
     * @param initiatingDataNode
     *            the initiator
     * @param result
     *            the check result of the initiator
     */
    void scheduleCheck(long block, String initiatingDataNode,
            BlockCheckResult result) {
        boolean schedule;
        Set<String> excludes;
        synchronized (checking) {
            CheckEntry entry = checking.get(block);
            if (entry == null) {
                schedule = true;
                entry = new CheckEntry(null, System.currentTimeMillis(),
                        new HashMap<String, BlockCheckResult>());
                checking.put(block, entry);
            } else {
                schedule = false;
            }
            entry.results.put(initiatingDataNode, result);
            excludes = new HashSet<String>(entry.results.keySet());
        }
        if (schedule) {
            scheduleCheckCommand(block, excludes);
        }
    }

    private void finishRpcCall(AsyncRpcCallEntry rpcCall, long block,
            boolean error, boolean fixed,
            Map<String, BlockCheckResult> checkResults) {
        if (rpcCall != null) {
            rpcCall.setReturnValue(new BlockVerifyResult(block, error, fixed,
                    checkResults));
            rpcCall.finishCall();
        }
    }

    private static final Set<BlockCheckResult.Result> OK_SET;

    static {
        Set<BlockCheckResult.Result> okSet = new HashSet<BlockCheckResult.Result>();
        okSet.add(BlockCheckResult.Result.MATCH);
        okSet.add(BlockCheckResult.Result.ORIGINAL_CHECKSUM_NOT_EXIST);
        okSet.add(BlockCheckResult.Result.ORIGINAL_CHECKSUM_READ_ERROR);
        OK_SET = Collections.unmodifiableSet(okSet);
    }

    private void processCheckResults(long block, CheckEntry checkEntry) {
        // analyze check results
        // first pass, check if any replication is corrupted, find out 
        // origin checksum if we have one, and put the node which have
        // correct replication to goodNodes.
        long oc = CHECKUM_NA;
        Set<String> goodNodes = new HashSet<String>();
        for (Entry<String, BlockCheckResult> result: checkEntry.results.entrySet()) {
            if (result.getValue().getOriginalChecksum() != CHECKUM_NA) {
                if (oc == CHECKUM_NA) {
                    oc = result.getValue().getOriginalChecksum();
                } else if (oc != result.getValue().getOriginalChecksum()) {
                    // origin checksum mismatch, we can not handle this 
                    // situation.
                    LOG.warning("Original checksums of " + block
                            + " don't match, previous is " + oc + ", but on "
                            + result.getKey() + " it's "
                            + result.getValue().getOriginalChecksum());
                    finishRpcCall(checkEntry.rpcCall, block, false, false,
                            checkEntry.results);
                    return;
                }
                if (result.getValue().getResult() == BlockCheckResult.Result.MATCH) {
                    goodNodes.add(result.getKey());
                }
            }
        }
        if (goodNodes.size() == checkEntry.results.size()) {
            // all nodes are good.
            finishRpcCall(checkEntry.rpcCall, block, false, false,
                    checkEntry.results);
            return;
        }

        if (oc != CHECKUM_NA && goodNodes.isEmpty()) {
            // OC exists but no block is valid, we can not handle this 
            // situation.
            LOG.warning("Original checksums of " + block + " is " + oc
                    + ", but no replication is valid.");
            finishRpcCall(checkEntry.rpcCall, block, true, false,
                    checkEntry.results);
            return;
        }

        if (oc == CHECKUM_NA) {
            // no OC exists, find out the most occurring CC and use it as OC.
            int occur = 0;
            // CC->dataNodes map
            Map<Long, Set<String>> ccCandidates = new HashMap<Long, Set<String>>();
            int nodesInDoubt = 0;
            for (Entry<String, BlockCheckResult> result: checkEntry.results.entrySet()) {
                if (OK_SET.contains(result.getValue().getResult())) {
                    Set<String> set = ccCandidates.get(result.getValue().getCalculatedChecksum());
                    if (set == null) {
                        set = new HashSet<String>();
                        ccCandidates.put(
                                result.getValue().getCalculatedChecksum(), set);
                    }
                    set.add(result.getKey());
                    if (set.size() > occur) {
                        occur = set.size();
                        oc = result.getValue().getCalculatedChecksum();
                    }
                    nodesInDoubt++;
                }
            }
            if (occur <= nodesInDoubt / 2) {
                LOG.warning("Found block "
                        + block
                        + " inconsistent, I cannot fix it because no majority checksum exists : "
                        + checkEntry.results);
                finishRpcCall(checkEntry.rpcCall, block, true, false,
                        checkEntry.results);
                return;
            }
            goodNodes = ccCandidates.get(oc);
        }

        List<String> badNodes = new ArrayList<String>();
        for (Map.Entry<String, BlockCheckResult> entry: checkEntry.results.entrySet()) {
            if (goodNodes.contains(entry.getKey())) {
                if (entry.getValue().getOriginalChecksum() == CHECKUM_NA) {
                    bstore.writeChecksum(block, entry.getKey(), oc);
                }
            } else {
                badNodes.add(entry.getKey());
            }
        }
        if (!badNodes.isEmpty()) {
            LOG.info("Found block " + block + " inconsistent : "
                    + checkEntry.results + ", deleting on " + badNodes);
            bstore.recreateReplica(block, badNodes.toArray(new String[0]));
        }
        finishRpcCall(checkEntry.rpcCall, block, true, true, checkEntry.results);
    }

    void reportCheck(long block, String datanodeFullName,
            BlockCheckResult result, int totalDatanodeCount) {
        CheckEntry entry;
        synchronized (checking) {
            entry = checking.get(block);
            if (entry == null) {
                return;
            }
            entry.results.put(datanodeFullName, result);
            if (entry.results.size() < totalDatanodeCount) {
                return;
            }
            checking.remove(block);
        }
        processCheckResults(block, entry);
    }
}
