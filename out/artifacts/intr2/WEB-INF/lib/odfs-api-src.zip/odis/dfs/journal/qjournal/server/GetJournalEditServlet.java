package odis.dfs.journal.qjournal.server;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import toolbox.misc.LogFormatter;

/**
 * This servlet is used in two cases:
 * <ul>
 * <li>The QuorumJournalManager, when reading edits, fetches the edit streams
 * from the journal nodes.</li>
 * <li>During edits synchronization, one journal node will fetch edits from
 * another journal node.</li>
 * </ul>
 */
public class GetJournalEditServlet extends HttpServlet {
    private static final long serialVersionUID = -8494333506391737752L;

    private static final Logger LOG = LogFormatter
            .getLogger(GetJournalEditServlet.class);

    private static final String SN_PARAM = "sn";

    private static final int MAX_BYTES_TO_READ = 64 * 1024;

    private static final int BUFFER_SIZE = 4096;

    public static final String LOCAL_JOURNAL_KEY = "localjournal";

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        FileInputStream logFileIn = null;
        DataOutputStream out = new DataOutputStream(response.getOutputStream());
        response.setBufferSize(MAX_BYTES_TO_READ);
        String paramStr = request.getParameter(SN_PARAM);
        if (paramStr == null) {
            throw new IOException("Invalid request has no " + SN_PARAM
                    + " parameter");
        }
        long sn = Long.valueOf(paramStr);

        ServletContext context = getServletContext();
        JournalNode jn = (JournalNode) context.getAttribute(LOCAL_JOURNAL_KEY);
        FileJournalManager fileJM = jn.getFileJM();
        synchronized (fileJM) {
            if (!fileJM.exists(sn)) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND,
                        "No edit log found starting at ");
            }
            File logFile = fileJM.getLogFile(sn);
            if (!logFile.exists()) {
                logFile = fileJM.getTmpLogFile(sn);
            }
            logFileIn = new FileInputStream(logFile);
        }
        
        LOG.info("retriving edits " + sn);
        sendFile(logFileIn, out);
    }
    
    private void sendFile(FileInputStream fileIn, DataOutputStream out)
            throws IOException {
        try {
            byte buf[] = new byte[BUFFER_SIZE];
            int num = 1;
            while (num > 0) {
                num = fileIn.read(buf);
                if (num <= 0) {
                    break;
                }
                out.write(buf, 0, num);
            }
        } finally {
            if (out != null) {
                out.close();
            }
            fileIn.close();
        }
    }
    
    public static String buildPath(long sn) {
        StringBuilder path = new StringBuilder("/journal?");
        path.append(SN_PARAM).append("=").append(sn);
        return path.toString();
    }
}
