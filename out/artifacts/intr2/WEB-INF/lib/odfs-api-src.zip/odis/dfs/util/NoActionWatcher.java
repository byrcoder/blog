/**
 * @(#)NoActionWatcher.java, 2012-7-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.util;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

/**
 * @author zhangduo
 */
public final class NoActionWatcher implements Watcher {

    private static final NoActionWatcher WATCHER = new NoActionWatcher();

    public static NoActionWatcher getWatcher() {
        return WATCHER;
    }

    @Override
    public void process(WatchedEvent event) {}

}
