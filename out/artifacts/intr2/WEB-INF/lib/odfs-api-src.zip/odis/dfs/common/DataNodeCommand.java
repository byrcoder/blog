/**
 * @(#)DataNodeCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.IOException;

import odis.dfs.datanode.DataNode;
import odis.serialize.IWritable;

/**
 * Base class for data-node command. Issued by the NameNode to notify DataNodes
 * what should be done.
 * 
 * @author zhangduo
 */
public abstract class DataNodeCommand implements IWritable {
    public static final DataNodeCommand[] EMPTY_ARRAY = new DataNodeCommand[0];

    abstract public void execute(DataNode dataNode) throws IOException;
}
