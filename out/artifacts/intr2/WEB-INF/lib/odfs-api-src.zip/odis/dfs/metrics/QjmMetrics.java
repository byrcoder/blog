package odis.dfs.metrics;

import java.util.concurrent.atomic.AtomicLongArray;

public class QjmMetrics {
    private final AtomicLongArray metricsRecords = new AtomicLongArray(
            QjmMetricsItem.totalItems());

    public void increment(QjmMetricsItem item) {
        metricsRecords.incrementAndGet(item.offset());
    }

    public void decrement(QjmMetricsItem item) {
        metricsRecords.decrementAndGet(item.offset());
    }

    public void add(QjmMetricsItem item, long delta) {
        metricsRecords.addAndGet(item.offset(), delta);
    }

    public void fillMetricsRecords(long[] metricsRecords) {
        for (int i = 0; i < this.metricsRecords.length(); i++) {
            metricsRecords[i] = this.metricsRecords.get(i);
        }
    }
}
