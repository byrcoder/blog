package odis.dfs.datanode;

import java.io.IOException;

/**
 * DataNode fatal error exception
 * 
 * @author guodd
 */
public class DataNodeFatalException extends IOException {

    private static final long serialVersionUID = 7249553197092160968L;

    public DataNodeFatalException() {
        super();
    }

    public DataNodeFatalException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataNodeFatalException(String message) {
        super(message);
    }

    public DataNodeFatalException(Throwable cause) {
        super(cause);
    }


}
