package odis.dfs.journal.qjournal.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Arrays;
import java.util.Comparator;
import java.util.logging.Logger;
import java.util.zip.Adler32;

import odis.dfs.util.DfsUtils;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

public class FileJournalManager {

    private static final Logger LOG = LogFormatter
            .getLogger(FileJournalManager.class);

    private final File dir;

    private final Adler32 adler32 = new Adler32();

    private FileOutputStream out = null;

    private long currentSN = 0;
    
    private static final String JOURNAL_FILE_PREFIX = "fsedit.";

    private static final String UNFINALIZED_JOURNAL_FILE_SUFFIX = ".new";

    private static final String CHECKSUM_FILE_SUFFIX = ".adler32";
    
    private static final int BUFFER_SIZE = 4096;

    public FileJournalManager(File dir) throws IOException {
        this.dir = dir;
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Can not create journal root "
                    + dir.getAbsolutePath());
        }
        
        File tmpDir = this.getSyncLogTemporaryDir();
        if (!tmpDir.exists() && !tmpDir.mkdirs()) {
            throw new IOException(
                    "Can't create sync tmp data dir for JournalNode, dir="
                            + tmpDir);
        }
        
        updateCurrentSN();
    }
    
    public void updateCurrentSN() {
        File[] journals = this.dir.listFiles(JOURNAL_FILTER);
        if (journals.length > 0) {
            Arrays.sort(journals, SN_COMPARATOR);
            File journal = journals[journals.length - 1];
            currentSN = getSN(journal.getName());
            LOG.info("Found latest journal log :" + currentSN + ", length="
                    + journal.length());

        }
    }

    public void startLogSegment(long minimumSN) throws IOException {
        currentSN = Math.max(minimumSN, currentSN + 1);

        File newSegment = this.getTmpLogFile(currentSN);
        File existing = this.getLogFile(currentSN);
        //Should never come here because we update currentSN with localFile
        // Paranoid sanity check: we should never overwrite a finalized log file.
        // This can happen if the writer crashes exactly at the start of a segment.
        if (existing.exists()) {
            String errMsg = "BUG: Already have a finalized segment " + existing;
            LOG.warning(errMsg);
            throw new IOException(errMsg);
        }
        // If it's in-progress, it should not contain any content
        if (newSegment.exists() && newSegment.length() != 0) {
            String errMsg = "BUG: The log file " + existing
                    + " seems to contain valid log";
            LOG.warning(errMsg);
            throw new IOException(errMsg);
        }
        LOG.info("Start new journal segment " + newSegment.getAbsolutePath());
        out = new FileOutputStream(newSegment);
        adler32.reset();
    }

    public int finalizeLogSegment(long sn) throws IOException {
        File unfinalizedJournal = this.getTmpLogFile(sn);
        int checksum = 1;
        if (null != out && sn == currentSN) {//finalize current log segment
            out.close();
            out = null;
            checksum = (int) adler32.getValue();
        } else { //finalize recovery segment
            if (!unfinalizedJournal.exists()) {
                File checksumFile = this.getCheckSumFile(sn);
                return DfsUtils.readChecksum(checksumFile);
            }
            Adler32 adler32 = new Adler32();
            byte[] buf = new byte[8 * 1024];
            FileInputStream in = new FileInputStream(unfinalizedJournal);
            adler32.reset();
            try {
                for (int r; (r = in.read(buf)) > 0;) {
                    adler32.update(buf, 0, r);
                }
            } finally {
                ReadWriteUtils.safeClose(in);
            }
            checksum = (int) adler32.getValue();
        }
        
        File checksumFile = this.getCheckSumFile(sn);
        DfsUtils.writeChecksum(checksumFile, checksum);
        File finalizedJournal = this.getLogFile(sn);
        if (!unfinalizedJournal.renameTo(finalizedJournal)) {
            throw new IOException("Cannot rename "
                    + unfinalizedJournal.getAbsolutePath() + " to "
                    + finalizedJournal.getAbsolutePath());
        }
        if (currentSN < sn) {
            this.updateCurrentSN();
        }
        return checksum;
    }

    public void write(byte[] buf) throws IOException {
        write(buf, 0, buf.length);
    }

    public void write(byte[] buf, int off, int len) throws IOException {
        if (!this.isSegmentOpened()) {
            throw new IOException("Can't write, no segment open");
        }
        out.write(buf, off, len);
        out.getFD().sync();
        adler32.update(buf, off, len);
    }

    public void close() {
        ReadWriteUtils.safeClose(out);
        out = null;
    }

    public long deleteSegmentBefore(long sn) {
        File[] journals = this.dir.listFiles(JOURNAL_FILTER);
        if (journals.length > 0) {
            Arrays.sort(journals, SN_COMPARATOR);
            int i = 0;
            for (; i < journals.length; ++i) {
                File journal = journals[i];
                long journalSN = getSN(journal.getName());
                if (journalSN < sn) {
                    LOG.info("Delete journal sn=" + journalSN);
                    deleteSegment(journalSN);
                }
            }
            return i;
        }
        return 0;
    }
    
    public void deleteSegment(long sn) {
        File unfinalizedJournal = this.getTmpLogFile(sn);
        if (unfinalizedJournal.exists()) {
            LOG.info("Delete unfinalized segment " + unfinalizedJournal);
            if (!unfinalizedJournal.delete()) {
                LOG.warning("Can't delete file " + unfinalizedJournal);
            }
            
            return;
        }
       
        File finalizedJournal = this.getLogFile(sn);
        LOG.info("Delete finalized segment " + finalizedJournal);
        if (!finalizedJournal.delete()) {
            LOG.warning("Can't delete file " + finalizedJournal);
        }
        
        
        File checkSumFile = this.getCheckSumFile(sn);
        LOG.info("Delete finalized segment checkSum file" + checkSumFile);
        if (!checkSumFile.delete()) {
            LOG.warning("Can't delete file " + checkSumFile);
        }
    }
    
    public int getCurrentCheckSum() {
        return (int) adler32.getValue();
    }
    
    public int getCheckSum(long sn) throws IOException {
        File checksumFile = this.getCheckSumFile(sn);
        return DfsUtils.readChecksum(checksumFile);
    }
    
    public File getLogFile(long sn) {
        return new File(dir, JOURNAL_FILE_PREFIX + sn);
    }
    
    public File getCheckSumFile(long sn) {
        return new File(dir, JOURNAL_FILE_PREFIX + sn + CHECKSUM_FILE_SUFFIX);
    }

    public File getTmpLogFile(long sn) {
        return new File(dir, JOURNAL_FILE_PREFIX + sn
                + UNFINALIZED_JOURNAL_FILE_SUFFIX);
    }
    
    public static String getTmpLogFileName(long sn) {
        return JOURNAL_FILE_PREFIX + sn + UNFINALIZED_JOURNAL_FILE_SUFFIX;
    }

    public static String getLogFileName(long sn) {
        return JOURNAL_FILE_PREFIX + sn;
    }

    public static String getCheckSumFileName(long sn) {
        return JOURNAL_FILE_PREFIX + sn + CHECKSUM_FILE_SUFFIX;
    }

    public File getSyncLogTemporaryDir() {
        return new File(dir, "sync_tmp");
    }

    public File getSyncLogTemporaryFile(long sn, long epoch) {
        File dir = this.getSyncLogTemporaryDir();
        return new File(dir, JOURNAL_FILE_PREFIX + sn + ".epoch=" + epoch);
    }
    
    public boolean isInProgress(long sn) {
        File unfinalizedJournal = this.getTmpLogFile(sn);
        if (unfinalizedJournal.exists()) {
            return true;
        }
        return false;
    }
    
    public boolean exists(long sn) {
        File unfinalizedJournal = this.getTmpLogFile(sn);
        File finalizedJournal = this.getLogFile(sn);
        return unfinalizedJournal.exists() | finalizedJournal.exists();
    }
    
    public long getLogLength(long sn) {
        File unfinalizedJournal = this.getTmpLogFile(sn);
        File finalizedJournal = this.getLogFile(sn);
        if (unfinalizedJournal.exists()) {
            return unfinalizedJournal.length();
        }
        return finalizedJournal.length();
    }
    
    public long getCurrentSN() {
        return currentSN;
    }

    public boolean isSegmentOpened() {
        return out != null;
    }

    public static long downloadFromUrl(File tmpFile, String urlStr) throws IOException {
        LOG.info("Downloading file " + tmpFile + " from " + urlStr);
        URL url = new URL(urlStr);
        InputStream input = DfsUtils.buildInputStreamFromURL(url);
        if (null == input) {
            throw new IOException("Open input stream from url " + urlStr
                    + "failed");
        }

        OutputStream output = new FileOutputStream(tmpFile);
        long contentLen = copyBytes(input, output, BUFFER_SIZE, true);
        return contentLen;
    }
    
    /**
     * Copies from one stream to another.
     * 
     * @param in
     *            InputStrem to read from
     * @param out
     *            OutputStream to write to
     * @param buffSize
     *            the size of the buffer
     */
    public static long copyBytes(InputStream in, OutputStream out,
            int buffSize, boolean close) throws IOException {
        try {
            PrintStream ps = out instanceof PrintStream ? (PrintStream) out
                    : null;
            long totalRead = 0;
            byte buf[] = new byte[buffSize];
            int bytesRead = in.read(buf);
            while (bytesRead >= 0) {
                totalRead += bytesRead;
                out.write(buf, 0, bytesRead);
                if ((ps != null) && ps.checkError()) {
                    throw new IOException("Unable to write to output stream.");
                }
                bytesRead = in.read(buf);
            }
            return totalRead;
        } finally {
            if (close) {
                out.close();
                in.close();
            }
        }
    }
    
    public long maxFinalizedSegmentSN() {
        if (isInProgress(currentSN)) {
            return currentSN - 1;
        }
        return currentSN;
    }
    
    private static long getSN(String name) {
        int firstDot = name.indexOf('.');
        int secondDot = name.indexOf('.', firstDot + 1);
        if (secondDot < 0) {
            return Long.parseLong(name.substring(firstDot + 1));
        } else {
            return Long.parseLong(name.substring(firstDot + 1, secondDot));
        }
    }

    public static final FilenameFilter JOURNAL_FILTER = new FilenameFilter() {

        @Override
        public boolean accept(File dir, String name) {
            return name.startsWith(JOURNAL_FILE_PREFIX)
                    && !name.endsWith(CHECKSUM_FILE_SUFFIX);
        }
    };

    private static final Comparator<File> SN_COMPARATOR = new Comparator<File>() {

        @Override
        public int compare(File o1, File o2) {
            long sn1 = getSN(o1.getName());
            long sn2 = getSN(o2.getName());
            return sn1 > sn2 ? 1 : sn1 == sn2 ? 0 : -1;
        }
    };
}
