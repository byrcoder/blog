/**
 * @(#)NameNodeWatcher.java, 2012-12-25. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.FSConstants;
import odis.dfs.common.IClientProtocolV3;
import odis.dfs.util.DfsUtils;
import odis.dfs.util.NoActionWatcher;
import odis.io.ReadWriteUtils;
import odis.rpc2.RPC;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper;

import toolbox.misc.LogFormatter;

/**
 * Monitor namenode address on zookeeper.
 * 
 * @author zhangduo
 */
public class NameNodeWatcher extends Thread implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(NameNodeWatcher.class);

    private final String zkAddr;

    private final int zkTimeout;

    private final String activeNameNodePath;

    private final String username;

    private final long rpcTimeout;

    private volatile IClientProtocolV3 nameNode;

    private String nameNodeAddr;

    private ZooKeeper zk;

    private static enum ZkEventType {
        SESSION_EXPIRED, ADDR_CHANGED, NONE
    }

    private ZkEventType eventType = ZkEventType.NONE;

    private final Watcher watcher = new Watcher() {

        @Override
        public void process(WatchedEvent event) {
            LOG.info("Zookeeper event: " + event);
            synchronized (NameNodeWatcher.this) {
                if (KeeperState.Expired.equals(event.getState())) {
                    eventType = ZkEventType.SESSION_EXPIRED;
                } else {
                    eventType = ZkEventType.ADDR_CHANGED;
                }
                NameNodeWatcher.this.notifyAll();
            }
        }
    };

    private volatile boolean running = true;

    private void reconnect() {
        LOG.warning("ZooKeeper session expired, reconnecting...");
        ReadWriteUtils.safeCloseZooKeeper(zk);
        for (int retry = 0; running; retry++) {
            try {
                zk = new ZooKeeper(zkAddr, zkTimeout,
                        NoActionWatcher.getWatcher());
                eventType = ZkEventType.NONE;
                return;
            } catch (IOException e) {
                retry++;
                LOG.log(Level.WARNING, "connect to " + zkAddr
                        + " failed, retry = " + (retry + 1), e);
                DfsUtils.waitExpTime(retry);
            }
        }
    }

    private void setNameNode() {
        Watcher watcher = this.watcher;
        for (int retry = 0; running; retry++) {
            try {
                if (zk.exists(activeNameNodePath, watcher) != null) {
                    // watcher is already set, do not need to set it again
                    // when retry.
                    watcher = null;
                    byte[] addrBytes = zk.getData(activeNameNodePath, null,
                            null);
                    String addr = new String(addrBytes,
                            NAMENODE_ZNODE_ADDR_CHARSET);
                    if (!addr.equals(nameNodeAddr)) {
                        String[] ss = addr.split(":");
                        IClientProtocolV3 newNameNode = RPC.getProxy(
                                IClientProtocolV3.class, new InetSocketAddress(
                                        ss[0], Integer.parseInt(ss[1])),
                                CLIENT_RPC_DOMAIN, username, rpcTimeout);
                        IClientProtocolV3 oldNameNode = this.nameNode;
                        this.nameNode = newNameNode;
                        if (oldNameNode != null) {
                            RPC.close(oldNameNode);
                        }
                        LOG.info("Set NameNode address to " + addr);
                        nameNodeAddr = addr;
                    }
                }
                eventType = ZkEventType.NONE;
                return;
            } catch (KeeperException e) {
                if (Code.SESSIONEXPIRED.equals(e.code())) {
                    eventType = ZkEventType.SESSION_EXPIRED;
                    return;
                }
                if (Code.NONODE.equals(e.code())) {
                    LOG.warning("NameNode znode not exists");
                    eventType = ZkEventType.NONE;
                    return;
                }
                LOG.log(Level.WARNING, "get NameNode address failed, retry = "
                        + (retry + 1), e);
                DfsUtils.waitExpTime(retry);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "get NameNode address failed, retry = "
                        + (retry + 1), e);
                DfsUtils.waitExpTime(retry);
            }
        }
    }

    public NameNodeWatcher(String zkAddr, int zkTimeout, String zkRoot,
            String username, long rpcTimeout) throws InterruptedException,
            IOException {
        super("NameNodeWatcher-" + zkAddr + "-" + zkRoot);
        setDaemon(true);
        this.zkAddr = zkAddr;
        this.zkTimeout = zkTimeout;
        this.activeNameNodePath = zkRoot + "/" + ACTIVE_NAMENODE_ZNODE;
        this.username = username;
        this.rpcTimeout = rpcTimeout;
        this.zk = new ZooKeeper(zkAddr, zkTimeout, NoActionWatcher.getWatcher());
        synchronized (this) {
            setNameNode();
        }
    }

    @Override
    public void run() {
        synchronized (this) {
            while (running) {
                switch (eventType) {
                    case SESSION_EXPIRED:
                        reconnect();
                    case ADDR_CHANGED:
                        setNameNode();
                        break;
                    default:
                        try {
                            wait();
                        } catch (InterruptedException e) {}
                        break;
                }

            }
        }
    }

    public IClientProtocolV3 getNameNode() {
        return nameNode;
    }

    public InetSocketAddress getNameNodeAddr() {
        IClientProtocolV3 nameNode = this.nameNode;
        if (nameNode != null) {
            return RPC.getRemoteAddr(nameNode);
        } else {
            return null;
        }
    }

    public void shutdown() {
        running = false;
        ReadWriteUtils.safeCloseZooKeeper(zk);
        interrupt();
        try {
            join();
        } catch (InterruptedException e) {}
        IClientProtocolV3 nameNode = this.nameNode;
        if (nameNode != null) {
            RPC.close(nameNode);
        }
    }
}
