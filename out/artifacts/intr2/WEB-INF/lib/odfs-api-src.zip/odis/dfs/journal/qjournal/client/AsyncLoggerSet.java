package odis.dfs.journal.qjournal.client;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.qjournal.IQJournalProtocol.ExistResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.GetJournalStateResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.PrepareRecoveryResponse;
import odis.dfs.journal.qjournal.IQJournalProtocol.SegmentState;

import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ListenableFuture;

/**
 * Wrapper around a set of Loggers, taking care of fanning out calls to the
 * underlying loggers and constructing corresponding {@link QuorumCall}
 * instances.
 * 
 * @author chenxi
 */
public class AsyncLoggerSet implements Closeable {

    private final List<AsyncLogger> loggers;

    private long myEpoch = DFSConfig.INVALID_EPOCH;

    public AsyncLoggerSet(List<AsyncLogger> loggers) {
        this.loggers = loggers;
    }
    
    @Override
    public void close() {
        for (AsyncLogger logger: loggers) {
            logger.close();
        }
    }
    
    /**
     * Wait for a quorum of loggers to respond to the given call. If a quorum
     * can't be achieved, throws a QuorumException.
     * 
     * @param q
     *            the quorum call
     * @param timeoutMs
     *            the number of millis to wait
     * @param operationName
     *            textual description of the operation, for logging
     * @return a map of successful results
     * @throws QuorumException
     *             if a quorum doesn't respond with success
     * @throws IOException
     *             if the thread is interrupted or times out
     */
    <V> Map<AsyncLogger, V> waitForWriteQuorum(QuorumCall<AsyncLogger, V> q,
            int timeoutMs, String operationName) throws IOException {
        int majority = loggers.size() / 2 + 1;
        try {
            q.waitFor(loggers.size(), // either all respond
                    majority, // or we get a majority successes
                    majority, // or we get a majority failures,
                    timeoutMs, operationName);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted waiting " + timeoutMs
                    + "ms for a quorum of nodes to respond.");
        } catch (TimeoutException e) {
            throw new IOException("Timed out waiting " + timeoutMs
                    + "ms for a quorum of nodes to respond.");
        }

        if (q.countSuccesses() < majority) {
            q.rethrowException("Got too many exceptions to achieve quorum size "
                    + majority
                    + "/"
                    + loggers.size()
                    + " in operation "
                    + operationName);
        }

        return q.getResults();
    }
    
    /**
     * Wait for all loggers to respond to the given call. If no respond
     * can be achieved, throws a Exception.
     * <p>
     * This is used for open finalized segment, 
     * because it's always ok to read segment if some logger is ok
     * 
     * @param q
     *            the quorum call
     * @param timeoutMs
     *            the number of millis to wait
     * @param operationName
     *            textual description of the operation, for logging
     * @return a map of successful results
     * @throws QuorumException
     *             if a quorum doesn't respond with success
     * @throws IOException
     *             if the thread is interrupted or times out
     */
    <V> Map<AsyncLogger, V> waitForReadQuorum(QuorumCall<AsyncLogger, V> q,
            int timeoutMs, String operationName) throws IOException {
        int majority = loggers.size();
        try {
            q.waitFor(loggers.size(), // either all respond
                    majority, // or we get a majority successes
                    loggers.size(), // or we get all node failures,
                    timeoutMs, operationName);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted waiting " + timeoutMs
                    + "ms for a quorum of nodes to respond.");
        } catch (TimeoutException e) {
            if (0 < q.countSuccesses()) {
                return q.getResults();
            } else {
                throw new IOException("Timed out waiting " + timeoutMs
                        + "ms for a quorum of nodes to respond.");
            }
        }
        
        return q.getResults();
    }

    /**
     * @return true if an epoch has been established.
     */
    boolean isEpochEstablished() {
        return myEpoch != DFSConfig.INVALID_EPOCH;
    }

    void setEpoch(long epoch) {
        myEpoch = epoch;
        for (AsyncLogger l: loggers) {
            l.setEpoch(epoch);
        }
    }

    /**
     * @return the epoch number for this writer. This may only be called after a
     *         successful call to {@link #createNewUniqueEpoch()}.
     */
    public long getEpoch() {
        return myEpoch;
    }
    
    @Override
    public String toString() {
        return "[" + Joiner.on(", ").join(loggers) + "]";
    }

    public List<AsyncLogger> getLoggers() {
        return loggers;
    }

    // /////////////////////////////////////////////////////////////////////////
    // The rest of this file is simply boilerplate wrappers which fan-out the
    // various IPC calls to the underlying AsyncLoggers and wrap the result
    // in a QuorumCall.
    // /////////////////////////////////////////////////////////////////////////

    public QuorumCall<AsyncLogger, GetJournalStateResponse> getJournalState() {
        Map<AsyncLogger, ListenableFuture<GetJournalStateResponse>> calls = Maps
                .newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.getJournalState());
        }
        return QuorumCall.create(calls);
    }

    public QuorumCall<AsyncLogger, Long> newEpoch(String clusterId, long epoch) {
        Map<AsyncLogger, ListenableFuture<Long>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.newEpoch(epoch));
        }
        return QuorumCall.create(calls);
    }
    
    public QuorumCall<AsyncLogger, Long> startLogSegment(long minimumSN) {
        Map<AsyncLogger, ListenableFuture<Long>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.startLogSegment(minimumSN));
        }
        return QuorumCall.create(calls);
    }
    
    public QuorumCall<AsyncLogger, Integer> journal(long currentSN,
            byte[] records, int off, int len, int checksum) {
        Map<AsyncLogger, ListenableFuture<Integer>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger,
                    logger.journal(currentSN, records, off, len, checksum));
        }
        return QuorumCall.create(calls);
    }
    
    public QuorumCall<AsyncLogger, Integer> journal(long currentSN,
            byte[] records, int checksum) {
        Map<AsyncLogger, ListenableFuture<Integer>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.journal(currentSN, records, checksum));
        }
        return QuorumCall.create(calls);
    }

    public QuorumCall<AsyncLogger, Integer> finalizeLogSegment(long sn,
            long logLength) {
        Map<AsyncLogger, ListenableFuture<Integer>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.finalizeLogSegment(sn, logLength));
        }
        return QuorumCall.create(calls);
    }

    public QuorumCall<AsyncLogger, PrepareRecoveryResponse> prepareRecovery(
            long sn) {
        Map<AsyncLogger, ListenableFuture<PrepareRecoveryResponse>> calls = Maps
                .newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.prepareRecovery(sn));
        }
        return QuorumCall.create(calls);
    }

    public QuorumCall<AsyncLogger, Long> acceptRecovery(
            SegmentState stateToAccept, String fromUrl) {
        Map<AsyncLogger, ListenableFuture<Long>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.acceptRecovery(stateToAccept, fromUrl));
        }
        return QuorumCall.create(calls);
    }
    
    public QuorumCall<AsyncLogger, Long> deleteSegmentBefore(long sn) {
        Map<AsyncLogger, ListenableFuture<Long>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.deleteSegmentBefore(sn));
        }
        return QuorumCall.create(calls);
    }
    
    public QuorumCall<AsyncLogger, ExistResponse> exist(long sn) {
        Map<AsyncLogger, ListenableFuture<ExistResponse>> calls = Maps
                .newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.exist(sn));
        }
        return QuorumCall.create(calls);
    }
    
    public QuorumCall<AsyncLogger, Long> maxFinalizedSegmentSN() {
        Map<AsyncLogger, ListenableFuture<Long>> calls = Maps.newHashMap();
        for (AsyncLogger logger: loggers) {
            calls.put(logger, logger.maxFinalizedSegmentSN());
        }
        return QuorumCall.create(calls);
    }
}
