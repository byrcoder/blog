package odis.dfs.metrics;

public enum QjmMetricsItem {
    GET_JOURNAL_STATE_COUNT(0, "getJournalState次数"),
    GET_JOURNAL_STATE_DELAY(GET_JOURNAL_STATE_COUNT.offset + 1, "getJournalState时间"),
    
    NEW_EPOCH_COUNT(GET_JOURNAL_STATE_DELAY.offset + 1, "newEpoch次数"),
    NEW_EPOCH_DELAY(NEW_EPOCH_COUNT.offset + 1, "newEpoch时间"),
    
    START_SEGMENT_COUNT(NEW_EPOCH_DELAY.offset + 1, "startSegment次数"),
    START_SEGMENT_DELAY(START_SEGMENT_COUNT.offset + 1, "startSegment时间"),
    
    FINALIZE_SEGMENT_COUNT(START_SEGMENT_DELAY.offset + 1, "finalizeSegment次数"),
    FINALIZE_SEGMENT_DELAY(FINALIZE_SEGMENT_COUNT.offset + 1, "finalizeSegment时间"),
    
    PREPARE_RECOVERY_COUNT(FINALIZE_SEGMENT_DELAY.offset + 1, "prepareRecovery次数"),
    PREPARE_RECOVERY_DELAY(PREPARE_RECOVERY_COUNT.offset + 1, "prepareRecovery时间"),
    
    ACCEPT_RECOVERY_COUNT(PREPARE_RECOVERY_DELAY.offset + 1, "acceptRecovery次数"),
    ACCEPT_RECOVERY_DELAY(ACCEPT_RECOVERY_COUNT.offset + 1, "acceptRecovery时间"),
    
    WRITE_JOURNAL_COUNT(ACCEPT_RECOVERY_DELAY.offset + 1, "writeJournal次数"),
    WRITE_JOURNAL_DELAY(WRITE_JOURNAL_COUNT.offset + 1, "writeJournal时间"),
    WRITE_JOURNAL_BYTES(WRITE_JOURNAL_DELAY.offset + 1, "writeJournal字节"),
    
    OPEN_INPUTSTREAM_COUNT(WRITE_JOURNAL_BYTES.offset + 1, "openInputstream次数"),
    OPEN_INPUTSTREAM_DELAY(OPEN_INPUTSTREAM_COUNT.offset + 1, "openInputstream时间");
    
    private final int offset;

    private final String printName;

    private QjmMetricsItem(int offset, String printName) {
        this.offset = offset;
        this.printName = printName;
    }

    public int offset() {
        return offset;
    }

    public String getPrintName() {
        return printName;
    }

    public static int totalItems() {
        return OPEN_INPUTSTREAM_DELAY.offset + 1;
    }
}
