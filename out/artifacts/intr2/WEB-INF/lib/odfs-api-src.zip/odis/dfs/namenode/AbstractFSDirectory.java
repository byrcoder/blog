/**
 * @(#)AbstractFSDirectory.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsAction;
import odis.io.permission.FsPermission;
import odis.serialize.lib.StringWritable;
import odis.util.ChecksumOutputStream;
import odis.util.KeyValueIterator;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.mutable.MutableLong;

import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
abstract class AbstractFSDirectory<FBS extends AbstractFSBlockStore> implements
        FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(AbstractFSDirectory.class);

    // constants for on-disk data entries
    protected static final int ENTRY_FILE = 1;

    protected static final int ENTRY_DIR = 2;

    protected static final int ENTRY_SOFTLINK = 3; // link specified by a path

    protected static final int ENTRY_FILE_REF = 4; // hardlink to an existing file INode

    protected static final int ENTRY_FILE_UC = 5; // uncompleted file

    protected final FBS bstore;

    protected final DirectoryINode rootDir;

    protected final UserGroupManager ugMgr;

    protected final FsPermissionChecker permissionChecker;

    protected final FsPermission defaultPermission;

    protected final String defaultGroup;

    protected final String admin;

    protected final FSDirPropertyManager fsDirPropMgr;

    protected long distinctFileNum;

    protected long distinctFileSize;

    protected INode loadINode(CDataInputStream in, String path,
            Map<Long, INode> ctx) throws IOException {
        int type = in.read();
        if (type == ENTRY_FILE_REF) {
            long id = in.readVLong();
            INode node = ctx.get(id);
            if (node == null) {
                throw new IOException(
                        "File corrupted. Cannot find node with ID " + id);
            }
            // increase reference
            node.incRefCount();
            // return directly, no need to set lastModified etc
            return node;
        }

        long lastAccess = in.readLong();
        long lastModified = in.readLong();
        int desiredReplications = in.readUnsignedByte();
        String user = StringWritable.readString(in);
        String group = StringWritable.readString(in);
        int mode = in.readUnsignedShort();
        INode node;
        if (type == ENTRY_DIR) {
            int nr = in.readVInt();
            SortedArrayChildren children = new SortedArrayChildren(nr);
            long contentsLength = 0;
            long subDirNum = 0;
            long subFileNum = 0;
            for (int i = 0; i < nr; i++) {
                String name = StringWritable.readString(in);
                String subPath = (path == null ? INode.STR_SEP : path
                        + INode.SEP)
                        + name;
                INode subNode = loadINode(in, subPath, ctx);
                contentsLength += subNode.getContentsLength();
                subDirNum += subNode.getSubDirNum();
                subFileNum += subNode.getSubFileNum();
                if (subNode instanceof DirectoryINode) {
                    subDirNum++;
                } else if (subNode instanceof FileINode) {
                    subFileNum++;
                }
                children.put(UTF8String.create(name), subNode);
            }
            node = new DirectoryINode(children, desiredReplications,
                    lastAccess, lastModified);
            node.setContentsLength(contentsLength);
            node.setSubDirNum(subDirNum);
            node.setSubFileNum(subFileNum);
        } else if (type == ENTRY_FILE) {
            long id = in.readVLong();
            int nr = in.readVInt();
            long contentsLength;
            if (nr == 1) {
                long block = in.readLong();
                int len = in.readVInt();
                contentsLength = len;
                bstore.addActiveBlock(block, len, desiredReplications);
                node = new TinyFileINode(block, desiredReplications,
                        lastAccess, lastModified);
            } else {
                long[] blocks = new long[nr];
                contentsLength = 0;
                for (int i = 0; i < nr; i++) {
                    long block = in.readLong();
                    int len = in.readVInt();
                    contentsLength += len;
                    bstore.addActiveBlock(block, len, desiredReplications);
                    blocks[i] = block;
                }
                node = new NormalFileINode(blocks, desiredReplications,
                        lastAccess, lastModified);
            }
            if (id != 0) {
                ctx.put(id, node);
            }
            distinctFileNum++;
            distinctFileSize += contentsLength;
            node.setContentsLength(contentsLength);
        } else if (type == ENTRY_FILE_UC) {
            String holder = StringWritable.readString(in);
            int fileBlockSize = in.readVInt();
            FileINodeUC nodeUC = new FileINodeUC(holder, desiredReplications,
                    fileBlockSize, lastAccess, lastModified);
            for (int count = in.readVInt(); count > 0; count--) {
                BlockWithSize bs = new BlockWithSize();
                bs.readFields(in);
                nodeUC.blocks.add(bs);
                bstore.addBlock(bs.block, bs.size, desiredReplications);
            }
            node = nodeUC;
        } else {
            throw new IOException("Wrong file format. Unknown entry type: "
                    + type);
        }
        node.setUser(ugMgr.getUserSerialNumber(user));
        node.setGroup(ugMgr.getGroupSerialNumber(group));
        node.setFsPermission(mode);
        return node;
    }

    protected AbstractFSDirectory(FBS bstore, File imageFile,
            FsPermission defaultPermission, String defaultGroup, String admin,
            Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            MutableLong maxLoadedLogSN) throws IOException {
        this.bstore = bstore;
        this.ugMgr = new UserGroupManager();
        this.permissionChecker = new FsPermissionChecker(ugMgr);
        this.defaultPermission = defaultPermission;
        this.defaultGroup = defaultGroup;
        this.admin = admin;
        this.fsDirPropMgr = new FSDirPropertyManager();
        if (imageFile != null) {
            LOG.info("Start to load image file: " + imageFile.getAbsolutePath());
            CDataInputStream in = null;
            try {
                in = new CDataInputStream(new BufferedInputStream(
                        new FileInputStream(imageFile)));
                Map<Long, INode> ctx = new HashMap<Long, INode>();
                rootDir = (DirectoryINode) loadINode(in, null, ctx);
                fsDirPropMgr.loadFromImage(in);
                ugMgr.loadGroupsFromImage(in);
                int pendingCreatesCount = in.readVInt();
                for (int i = 0; i < pendingCreatesCount; i++) {
                    String path = StringWritable.readString(in);
                    FileINodeUC nodeUC = (FileINodeUC) loadINode(in, path, ctx);
                    INode nodeUCInNodeTree = unprotectedGetNode(path);
                    // using FileINodeUc in node tree if it exists.
                    if (nodeUCInNodeTree instanceof FileINodeUC) {
                        pendingCreates.put(path, (FileINodeUC) nodeUCInNodeTree);
                    } else {
                        pendingCreates.put(path, nodeUC);
                    }
                }
                int pendingCreateLastBlocksCount = in.readVInt();
                for (int i = 0; i < pendingCreateLastBlocksCount; i++) {
                    long id = in.readLong();
                    int locsCount = in.readVInt();
                    String[] locs = new String[locsCount];
                    for (int j = 0; j < locsCount; j++) {
                        locs[j] = StringWritable.readString(in);
                    }
                    pendingCreateLastBlocks.put(id, locs);
                }
                maxLoadedLogSN.setValue(in.readLong());
            } finally {
                ReadWriteUtils.safeClose(in);
            }
            LOG.info("Done loading image file: " + imageFile.getAbsolutePath());
        } else {
            long time = System.currentTimeMillis();
            rootDir = new DirectoryINode(null, DEFAULT_NUM_REPLICAS, time, time);
            rootDir.setUser(ugMgr.getUserSerialNumber(admin));
            rootDir.setGroup(ugMgr.getGroupSerialNumber(defaultGroup));
            rootDir.setFsPermission(defaultPermission.toShort());
            for (String systemDir: SYSTEM_DIRECTORYS) {
                unprotectedMkdirs(time, systemDir, NUM_REPLICAS_INHERITED,
                        defaultPermission, admin);
            }
            LOG.info("No image file specified");
        }
    }

    protected AbstractFSDirectory(FBS bstore, FsPermission defaultPermission,
            String defaultGroup, String admin, DirectoryINode rootDir,
            FSDirPropertyManager fsDirPropMgr, UserGroupManager ugMgr,
            FsPermissionChecker permissionChecker) {
        this.bstore = bstore;
        this.defaultPermission = defaultPermission;
        this.defaultGroup = defaultGroup;
        this.admin = admin;
        this.rootDir = rootDir;
        this.fsDirPropMgr = fsDirPropMgr;
        this.ugMgr = ugMgr;
        this.permissionChecker = permissionChecker;
    }

    /**
     * Load an edit log, and apply the changes to the in-memory structure This
     * is where we apply edits that we've been writing to disk all along.
     * <p>
     * FSBlockStore related operation:
     * <ul>
     * <li><b>OP_CREATE</b> remove block from FSBlockStore if we overwrite a
     * file.</li>
     * <li><b>OP_APPEND_BLOCK</b> only append block to FileINodeUC.</li>
     * <li><b>OP_ABANDON_BLOCK</b> only remove block from FileINodeUC.</li>
     * <li><b>OP_COMPLETE</b> first call addBlock of FSBlockStore to add block
     * to blockMap, then call completeFile to let FSBlockStore active the
     * blocks.</li>
     * <li><b>OP_ABANDON</b> only remove the FileINodeUC from node tree.</li>
     * <li><b>OP_RENAME</b> remove block from FSBlockStore if we overwrite a
     * file.</li>
     * <li><b>OP_DELETE</b> remove block from FSBlockStore.</li>
     * </ul>
     */
    long loadFSEdits(CDataInputStream in,
            Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            MutableLong maxLoadedLogSN) throws IOException {
        long numEdits = 0;
        for (int opcode; (opcode = in.read()) >= 0;) {
            try {
                long sn = in.readLong();
                boolean load;
                if (sn > maxLoadedLogSN.longValue()) {
                    maxLoadedLogSN.setValue(sn);
                    load = true;
                } else {
                    load = false;
                }
                long time = in.readLong();
                switch (opcode) {
                    case AbstractFSEditLogger.OP_CREATE: {
                        String file = StringWritable.readString(in);
                        boolean overwrite = in.readBoolean();
                        boolean createParent = in.readBoolean();
                        FsPermission permission = new FsPermission(
                                in.readUnsignedShort());
                        int replication = in.readInt();
                        int fileBlockSize = in.readInt();
                        String user = StringWritable.readString(in);
                        String holder = StringWritable.readString(in);
                        BlockLocationWithDataPath firstBlock = new BlockLocationWithDataPath();
                        firstBlock.readFields(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: start file " + file
                                + ", overwrite=" + overwrite
                                + ", createParent=" + createParent
                                + ", permission=" + permission
                                + ", replication=" + replication
                                + ", fileBlockSize=" + fileBlockSize
                                + ", holder=" + holder + ", user=" + user
                                + ", firstBlock = " + firstBlock);
                        if (!load) {
                            continue;
                        }
                        try {
                            Pair<FileINodeUC, FileINode> pair = unprotectedAddFileUC(
                                    time, file, overwrite, createParent,
                                    permission, replication, fileBlockSize,
                                    holder, user);
                            FileINodeUC fileUC = pair.getFirst();
                            fileUC.blocks.add(new BlockWithSize(
                                    firstBlock.getBlock(), 0));
                            pendingCreates.put(file, fileUC);
                            bstore.addBlock(firstBlock.getBlock(), 0,
                                    fileUC.getDesiredReplications());
                            if (pair.getSecond() != null) {
                                for (long block: pair.getSecond().getBlocks()) {
                                    bstore.removeBlock(block);
                                }
                            }
                            pendingCreateLastBlocks.put(firstBlock.getBlock(),
                                    firstBlock.getLocations());
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_APPEND_BLOCK: {
                        String file = StringWritable.readString(in);
                        int blockIndex = in.readInt();
                        String holder = StringWritable.readString(in);
                        BlockWithSize prevBlock;
                        if (in.readBoolean()) {
                            prevBlock = new BlockWithSize();
                            prevBlock.readFields(in);
                        } else {
                            prevBlock = null;
                        }
                        BlockLocationWithDataPath nextBlock = new BlockLocationWithDataPath();
                        nextBlock.readFields(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: append block of file " + file
                                + ", blockIndex=" + blockIndex + ", holder="
                                + holder + ", prevBlock=" + prevBlock
                                + ", nextBlock=" + nextBlock);
                        if (!load) {
                            continue;
                        }
                        FileINodeUC node = pendingCreates.get(file);
                        if (prevBlock != null) {
                            node.blocks.get(blockIndex - 1).size = prevBlock.size;
                            pendingCreateLastBlocks.remove(prevBlock.block);
                            bstore.addBlock(prevBlock.block, prevBlock.size,
                                    node.getDesiredReplications());
                        }
                        BlockWithSize nextBlockWithSize = new BlockWithSize(
                                nextBlock.getBlock(), 0);
                        node.blocks.add(nextBlockWithSize);
                        pendingCreateLastBlocks.put(nextBlock.getBlock(),
                                nextBlock.getLocations());
                        bstore.addBlock(nextBlock.getBlock(), 0,
                                node.getDesiredReplications());
                        break;
                    }
                    case AbstractFSEditLogger.OP_ABANDON_BLOCK: {
                        String file = StringWritable.readString(in);
                        int blockIndex = in.readInt();
                        String holder = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: abandon block of file " + file
                                + ", blockIndex=" + blockIndex + ", holder="
                                + holder);
                        if (!load) {
                            continue;
                        }
                        FileINodeUC node = pendingCreates.get(file);
                        BlockWithSize bs = node.blocks.remove(blockIndex);
                        pendingCreateLastBlocks.remove(bs.block);
                        bstore.removeBlock(bs.block);
                        break;
                    }
                    case AbstractFSEditLogger.OP_COMPLETE: {
                        String file = StringWritable.readString(in);
                        BlockWithSize lastBlock = new BlockWithSize();
                        lastBlock.readFields(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: complete file " + file
                                + " with last block " + lastBlock);
                        if (!load) {
                            continue;
                        }
                        FileINodeUC node = pendingCreates.remove(file);
                        pendingCreateLastBlocks.remove(lastBlock.block);
                        node.blocks.set(node.blocks.size() - 1, lastBlock);
                        bstore.addBlock(lastBlock.block, lastBlock.size,
                                node.getDesiredReplications());
                        if (!unprotectedCompleteFile(time, file)) {
                            for (BlockWithSize bs: node.blocks) {
                                bstore.removeBlock(bs.block);
                            }
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_ABANDON: {
                        String file = StringWritable.readString(in);
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: abandon file " + file + ", user="
                                + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedAbandonFileUC(time, file, user);
                            FileINodeUC node = pendingCreates.remove(file);
                            if (!node.blocks.isEmpty()) {
                                BlockWithSize lastBlock = node.blocks.get(node.blocks.size() - 1);
                                pendingCreateLastBlocks.remove(lastBlock.block);
                                for (BlockWithSize bs: node.blocks) {
                                    bstore.removeBlock(bs.block);
                                }
                            }
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_FORCE_COMPLETE: {
                        String file = StringWritable.readString(in);
                        BlockWithSize lastBlock;
                        if (in.readBoolean()) {
                            lastBlock = new BlockWithSize();
                            lastBlock.readFields(in);
                        } else {
                            lastBlock = null;
                        }
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: force complete file " + file
                                + ", lastBlock=" + lastBlock);
                        if (!load) {
                            continue;
                        }
                        FileINodeUC node = pendingCreates.remove(file);
                        if (lastBlock != null) {
                            pendingCreateLastBlocks.remove(lastBlock.block);
                            node.blocks.set(node.blocks.size() - 1, lastBlock);
                            bstore.addBlock(lastBlock.block, lastBlock.size,
                                    node.getDesiredReplications());
                        }
                        if (node.blocks.isEmpty()) {
                            unprotectedAbandonFileUC(time, file, null);
                        } else {
                            if (!unprotectedCompleteFile(time, file)) {
                                for (BlockWithSize bs: node.blocks) {
                                    bstore.removeBlock(bs.block);
                                }
                            }
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_DEPRIVE: {
                        String file = StringWritable.readString(in);
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: deprive file " + file + ", user="
                                + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            Pair<Boolean, FileINode> pair = unprotectedDeprive(
                                    time, file, user);
                            if (pair.getSecond() != null) {
                                for (long block: pair.getSecond().getBlocks()) {
                                    bstore.removeBlock(block);
                                }
                            }
                            FileINodeUC fileUC = pendingCreates.remove(file);
                            if (fileUC != null) {
                                if (!fileUC.blocks.isEmpty()) {
                                    BlockWithSize lastBlock = fileUC.blocks.get(fileUC.blocks.size() - 1);
                                    pendingCreateLastBlocks.remove(lastBlock.block);
                                    for (BlockWithSize bs: fileUC.blocks) {
                                        bstore.removeBlock(bs.block);
                                    }
                                }
                            }
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_RENAME: {
                        String src = StringWritable.readString(in);
                        String dst = StringWritable.readString(in);
                        boolean overwrite = in.readBoolean();
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: renamed file " + src + " to "
                                + dst + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            FileINode deletedFile = unprotectedRenameTo(time,
                                    src, dst, overwrite, user);
                            if (deletedFile != null) {
                                for (long block: deletedFile.getBlocks()) {
                                    bstore.removeBlock(block);
                                }
                            }
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_DELETE: {
                        String path = StringWritable.readString(in);
                        boolean recursive = in.readBoolean();
                        String user = StringWritable.readStringNull(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: deleted file " + path
                                + ", recursive=" + recursive + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            List<FileINode> deletedFiles = unprotectedDelete(
                                    time, path, recursive, user);
                            if (deletedFiles != null) {
                                for (FileINode deletedFile: deletedFiles) {
                                    for (long block: deletedFile.getBlocks()) {
                                        bstore.removeBlock(block);
                                    }
                                }
                            }
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_TRASH: {
                        String path = StringWritable.readString(in);
                        String trashPath = StringWritable.readString(in);
                        boolean recursive = in.readBoolean();
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: trash file " + path + " to "
                                + trashPath + ", recursive=" + recursive
                                + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedMkdirsAndRenameToWithoutCheckQuota(time,
                                    path, trashPath, recursive, user);
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_MKDIR: {
                        String dir = StringWritable.readString(in);
                        int desiredReplication = in.readInt();
                        FsPermission permission = new FsPermission(
                                in.readUnsignedShort());
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: make dir " + dir
                                + ", desiredReplications=" + desiredReplication
                                + ", permission=" + permission + ", user="
                                + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedMkdirs(time, dir, desiredReplication,
                                    permission, user);
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_SNAPSHOT: {
                        String src = StringWritable.readString(in);
                        String dst = StringWritable.readString(in);
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: snapshot " + src + " to " + dst
                                + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedSnapshot(time, src, dst, user);
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_REPLICATE: {
                        String path = StringWritable.readString(in);
                        int replications = in.readInt();
                        boolean recursive = in.readBoolean();
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: changed replications of path "
                                + path + " to " + replications + ", recursive="
                                + recursive + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedChangeReplication(time, path,
                                    replications, recursive, user);
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_CHOWN: {
                        String path = StringWritable.readString(in);
                        String owner = StringWritable.readStringNull(in);
                        String group = StringWritable.readStringNull(in);
                        boolean recursive = in.readBoolean();
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: chown of path " + path
                                + ", recursive=" + recursive + ", owner="
                                + owner + ", group=" + group + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedSetOwnerAndGroup(path, owner, group,
                                    recursive, user);
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_CHMOD: {
                        String path = StringWritable.readString(in);
                        FsPermission permission = new FsPermission(
                                in.readUnsignedShort());
                        boolean recursive = in.readBoolean();
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: chmod of path " + path
                                + ", permission=" + permission + ", recursive="
                                + recursive + ", user=" + user);
                        if (!load) {
                            continue;
                        }
                        try {
                            unprotectedSetPermission(path, permission,
                                    recursive, user);
                        } catch (FSException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                        break;
                    }
                    case AbstractFSEditLogger.OP_ADD_GROUP_USER: {
                        String group = StringWritable.readString(in);
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: add user " + user + " to group "
                                + group);
                        if (!load) {
                            continue;
                        }
                        ugMgr.addGroupUser(group, user);
                        break;
                    }
                    case AbstractFSEditLogger.OP_REMOVE_GROUP_USER: {
                        String group = StringWritable.readString(in);
                        String user = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: remove user " + user
                                + " from group " + group);
                        if (!load) {
                            continue;
                        }
                        ugMgr.removeGroupUser(group, user);
                        break;
                    }
                    case AbstractFSEditLogger.OP_REMOVE_GROUP: {
                        String group = StringWritable.readString(in);
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: remove group " + group);
                        if (!load) {
                            continue;
                        }
                        ugMgr.removeGroup(group);
                        break;
                    }
                    case AbstractFSEditLogger.OP_SET_SPACE_QUOTA: {
                        String path = StringWritable.readString(in);
                        long quota = in.readLong();
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: set space quota of " + path
                                + " to " + quota);
                        if (!load) {
                            continue;
                        }
                        fsDirPropMgr.setSpaceQuota(path, quota);
                        break;
                    }
                    case AbstractFSEditLogger.OP_SET_NAME_QUOTA: {
                        String path = StringWritable.readString(in);
                        long quota = in.readLong();
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: set name quota of " + path
                                + " to " + quota);
                        if (!load) {
                            continue;
                        }
                        fsDirPropMgr.setNameQuota(path, quota);
                        break;
                    }
                    case AbstractFSEditLogger.OP_SET_PROTECT: {
                        String path = StringWritable.readString(in);
                        boolean protect = in.readBoolean();
                        LOG.info((load ? "Loading" : "Skipping")
                                + " FSEdits: set protect state of " + path
                                + " to " + protect);
                        if (!load) {
                            continue;
                        }
                        fsDirPropMgr.setProtect(path, protect);
                        break;
                    }
                    case AbstractFSEditLogger.OP_SET_RECOVERABLE: {
                        String path = StringWritable.readString(in);
                        boolean recoverable = in.readBoolean();
                        LOG.info((load ? "Loading" : "Skipping")
                                + "Loading FSEdits: set recoverable state of "
                                + path + " to " + recoverable);
                        if (!load) {
                            continue;
                        }
                        fsDirPropMgr.setRecoverable(path, recoverable);
                        break;
                    }
                    default:
                        throw new IOException("Unknown opcode: " + opcode);
                }
                numEdits++;
            } catch (EOFException e) {
                LOG.log(Level.WARNING, "Got EOF when load edits", e);
                break;
            }
        }
        return numEdits;
    }

    /**
     * Return adler32 checksum.
     * 
     * @param imageFile
     * @return
     * @throws IOException
     */
    int saveFSImage(File imageFile, Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks, long maxLoadedLogSN)
            throws IOException {
        FileOutputStream rawOut = null;
        ChecksumOutputStream checksumOut = null;
        CDataOutputStream out = null;
        try {
            rawOut = new FileOutputStream(imageFile);
            checksumOut = new ChecksumOutputStream(rawOut);
            out = new CDataOutputStream(new BufferedOutputStream(checksumOut));
            ImageSaveContext ctx = new ImageSaveContext(bstore, ugMgr);
            rootDir.saveImage(out, ctx);
            ctx.clear();
            fsDirPropMgr.saveToImage(out);
            ugMgr.saveGroupsToImage(out);
            // store pending files
            out.writeVInt(pendingCreates.size());
            for (Map.Entry<String, FileINodeUC> entry: pendingCreates.entrySet()) {
                StringWritable.writeString(out, entry.getKey());
                entry.getValue().saveImage(out, ctx);
            }
            out.writeVInt(pendingCreateLastBlocks.size());
            for (Map.Entry<Long, String[]> entry: pendingCreateLastBlocks.entrySet()) {
                out.writeLong(entry.getKey());
                out.writeVInt(entry.getValue().length);
                for (String loc: entry.getValue()) {
                    StringWritable.writeString(out, loc);
                }
            }
            out.writeLong(maxLoadedLogSN);
            out.flush();
            rawOut.getFD().sync();
        } finally {
            ReadWriteUtils.safeClose(out);
            ReadWriteUtils.safeClose(checksumOut);
            ReadWriteUtils.safeClose(rawOut);
        }
        return (int) checksumOut.getChecksum();
    }

    protected INode unprotectedGetNode(String path) {
        if (path.length() == 1) {
            return rootDir;
        }
        String[] components = DirUtils.splitToComponents(path);
        DirectoryINode node = rootDir;
        for (int i = 0;; i++) {
            String name = components[i];
            INode childNode = node.getChild(name);
            if (i == components.length - 1) {
                return childNode;
            }
            if (childNode instanceof DirectoryINode) {
                node = (DirectoryINode) childNode;
            } else {
                return null;
            }
        }
    }

    /**
     * Get components and inodes on this path.
     * <p>
     * The returned inode array's length is the component array's length plus
     * 1(the first element is always rootDir), if no inode associate with the
     * component, the array element will be null.
     * 
     * @param path
     * @return
     */
    protected Pair<String[], INode[]> unprotectedGetPathExistingNodes(
            String path) {
        if (path.length() == 1) {
            return new Pair<String[], INode[]>(new String[0], new INode[] {
                rootDir
            });
        }
        String[] components = DirUtils.splitToComponents(path);
        INode[] nodes = new INode[components.length + 1];
        nodes[0] = rootDir;
        for (int i = 0; i < components.length; i++) {
            String name = components[i];
            nodes[i + 1] = ((DirectoryINode) nodes[i]).getChild(name);
            if (!(nodes[i + 1] instanceof DirectoryINode)) {
                break;
            }
        }
        return new Pair<String[], INode[]>(components, nodes);
    }

    /**
     * Update the contentsLength and subItemNum of all the INodes (except the
     * last one, i.e., the file INode) on the given path by the given delta
     * value. This method is called when a file is added to/removed from a path
     * and the contentsLength of its ancestor INodes should be updated
     * accordingly.
     * 
     * @param path
     * @param deltaContentsLength
     * @param deltaSubDirNum
     * @param deltaSubFileNum
     */
    private void unprotectedUpdateContentsLengthAndSubItemNum(String path,
            long deltaContentsLength, long deltaSubDirNum, long deltaSubFileNum) {
        String[] components = DirUtils.splitToComponents(path);
        DirectoryINode dir = rootDir;
        for (int i = 0;; i++) {
            dir.setContentsLength(dir.getContentsLength() + deltaContentsLength);
            dir.setSubDirNum(dir.getSubDirNum() + deltaSubDirNum);
            dir.setSubFileNum(dir.getSubFileNum() + deltaSubFileNum);
            if (i == components.length - 1) {
                break;
            }
            dir = (DirectoryINode) dir.getChild(components[i]);
        }
    }

    protected static enum MkdirCheckResult {
        EXISTS, NORMAL, FAILED
    }

    /**
     * Check if we can make this directory by the way.
     * 
     * @param dir
     * @param addedName
     *            in addFileUC, we will add one file immediately after we create
     *            the folder, so we need to check name quota with addedName = 1.
     * @return <code>EXISTS</code> means we do not need to create the directory
     *         because it is already exists. <code>NORMAL</code> means we can
     *         make the directory. <code>FAILED</code> means we can not make the
     *         directory.
     * @throws FSException
     */
    private MkdirCheckResult unprotectedCheckMkdirsQuotaAndACL(String dir,
            String user, int addedName) throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(dir);
        String[] components = pair.getFirst();
        INode[] nodes = pair.getSecond();
        permissionChecker.check(dir, components, nodes, FsAction.WRITE, null,
                null, null, null, user);

        int ancestorIndex = components.length;
        for (; ancestorIndex >= 0 && nodes[ancestorIndex] == null; ancestorIndex--);
        if (!(nodes[ancestorIndex] instanceof DirectoryINode)) {
            return MkdirCheckResult.FAILED;
        }
        if (ancestorIndex == nodes.length - 1) {
            return MkdirCheckResult.EXISTS;
        }
        // [0, ancestorIndex), check name quota with nodes.length - ancestorIndex + addedName
        unprotectedCheckQuota(null, INode.STR_SEP, 0, components.length
                - ancestorIndex + addedName);
        int length = 0;
        String curDir = INode.STR_SEP;
        for (int i = 0; i < ancestorIndex - 1; i++) {
            length += components[i].length() + 1;
            curDir = dir.substring(0, length);
            unprotectedCheckQuota(null, curDir, 0, components.length
                    - ancestorIndex + addedName);
        }
        for (int i = Math.max(ancestorIndex - 1, 0);; i++) {
            // if addedName == 0, do not need to check the last folder.
            if (i == components.length - 1 && addedName == 0) {
                break;
            } else if (i == components.length) {
                break;
            }
            length += components[i].length() + 1;
            curDir = dir.substring(0, length);
            unprotectedCheckQuota(null, curDir, 0, components.length - i - 1
                    + addedName);
        }
        return MkdirCheckResult.NORMAL;
    }

    /**
     * check if a item's parent dir is out of quota(quota<current size)
     * <p>
     * <strong>NOTE:</strong> make sure path is in the child path of rootPath(if
     * it is not null) before calling.
     * 
     * @param rootPath
     *            if the change is constrained within a subtree of the whole FS,
     *            designate the root of the subtree so that only the directories
     *            UNDER this rootPath will be checked with quota
     * @param path
     *            the path to the file that is being check(is likely to add to
     *            the file system)
     * @param addedSize
     *            the size of data to be added to the path
     * @param addedName
     *            the amount of files/dirs to be added to the path
     * @return true(out of quota, can not add any new file or dir) false(not out
     *         of quota, can add new file or dir)
     */
    private void unprotectedCheckQuota(String rootPath, String path,
            long addedSize, long addedName) throws FSException {
        // check quota up to down
        int start;
        DirectoryINode node;
        if (rootPath == null) { // check rootDir first
            if (fsDirPropMgr.outOfSpaceQuota(INode.STR_SEP,
                    rootDir.getContentsLength() + addedSize)) {
                throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                        INode.SEP + " is out of space quota");
            }
            if (fsDirPropMgr.outOfNameQuota(INode.STR_SEP,
                    rootDir.getSubDirNum() + rootDir.getSubFileNum()
                            + addedName)) {
                throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                        INode.SEP + " is out of name quota");
            }
            start = 1;
            node = rootDir;
        } else {
            // start should locate to the next char of slash.
            if (rootPath.length() == 1) {
                start = 1;
            } else {
                start = rootPath.length() + 1;
            }
            INode n = unprotectedGetNode(rootPath);
            if (n instanceof DirectoryINode) {
                node = (DirectoryINode) n;
            } else {
                node = null;
            }
        }
        for (;;) {
            int end = path.indexOf(INode.SEP, start);
            String dirPath;
            String dirName;
            if (end == -1) {
                dirPath = path;
                dirName = path.substring(start);
            } else {
                dirPath = path.substring(0, end);
                dirName = path.substring(start, end);
            }
            INode n = node == null ? null : node.getChild(dirName);
            long contentsLength = n == null ? 0 : n.getContentsLength();
            if (fsDirPropMgr.outOfSpaceQuota(dirPath, contentsLength
                    + addedSize)) {
                throw new FSException(FSException.NOT_ENOUGH_RESOURCE, dirPath
                        + " is out of space quota");
            }
            long subItemNum = n == null ? 0 : n.getSubDirNum()
                    + n.getSubFileNum();
            if (fsDirPropMgr.outOfNameQuota(dirPath, subItemNum + addedName)) {
                throw new FSException(FSException.NOT_ENOUGH_RESOURCE, dirPath
                        + " is out of name quota");
            }
            if (end == -1) {
                break;
            }
            start = end + 1;
            if ((n instanceof DirectoryINode)) {
                node = (DirectoryINode) n;
            } else {
                node = null;
            }
        }
    }

    private void internalMkdirs(long time, String path, int replications,
            int childrenCapacity, FsPermission permission, String user) {
        // we create folders up to down, and update the sub dir num by the way.
        String[] components = DirUtils.splitToComponents(path);
        List<DirectoryINode> parentDirs = new ArrayList<DirectoryINode>(
                components.length);
        parentDirs.add(rootDir);
        for (String name: components) {
            DirectoryINode parentNode = parentDirs.get(parentDirs.size() - 1);
            INode childNode = parentNode.getChild(name);
            if (childNode == null) { // make it
                SortedArrayChildren children = childrenCapacity <= 0 ? null
                        : new SortedArrayChildren(childrenCapacity);
                int replica = replications == FSConstants.NUM_REPLICAS_INHERITED ? parentNode.getDesiredReplications()
                        : replications;
                DirectoryINode node = new DirectoryINode(children, replica,
                        time, time);
                node.setUser(ugMgr.getUserSerialNumber(user));
                node.setGroup(parentNode.getGroup());
                node.setFsPermission(permission.toShort());
                parentNode.addChild(name, node, time);
                for (DirectoryINode parentDir: parentDirs) {
                    parentDir.setSubDirNum(parentDir.getSubDirNum() + 1);
                }
                parentDirs.add(node);
            } else {
                parentDirs.add((DirectoryINode) childNode);
            }
        }
    }

    protected Pair<FileINodeUC, FileINode> unprotectedAddFileUC(long time,
            String file, boolean overwrite, boolean createParent,
            FsPermission permission, int replication, int fileBlockSize,
            String holder, String user) throws FSException {
        String parent = DirUtils.getParent(file);
        permission = permission.applyUMask(FileINode.UMASK);
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(file);
        // pass addedSize=1 here to forbidden write when used space == quota
        unprotectedCheckQuota(null, parent, 1, 1);
        String[] components = pair.getFirst();
        INode[] nodes = pair.getSecond();
        permissionChecker.check(file, components, nodes, FsAction.WRITE, null,
                FsAction.WRITE, null, null, user);
        String fileName = components[components.length - 1];
        DirectoryINode parentNode;
        INode oldINode = nodes[nodes.length - 1];
        FileINodeUC node;
        if (oldINode != null) {
            if (!overwrite) {
                throw new FSException(FSException.PERMISSION_DENIED,
                        "Cannot start file " + file
                                + ". Cannot remove existing file, overwrite="
                                + overwrite);
            } else if (oldINode instanceof DirectoryINode) {
                throw new FSException(FSException.PERMISSION_DENIED,
                        "Cannot start file " + file
                                + ". Cannot overwrite existing directory");
            }
            // no need to check FileINodeUC, caller will check 
            // pendingCreates to avoid this situation.
            parentNode = (DirectoryINode) nodes[nodes.length - 2];
            node = new FileINodeUC(
                    holder,
                    replication == NUM_REPLICAS_INHERITED ? parentNode.getDesiredReplications()
                            : replication, fileBlockSize, time, time);
            node.setUser(ugMgr.getUserSerialNumber(user));
            node.setGroup(parentNode.getGroup());
            node.setFsPermission(permission.toShort());
            parentNode.removeChild(fileName, time);
            unprotectedUpdateContentsLengthAndSubItemNum(file,
                    -nodes[nodes.length - 1].getContentsLength(), 0, -1);
        } else if (!(nodes[nodes.length - 2] instanceof DirectoryINode)) {
            // we need to create parent folder
            if (!createParent
                    || unprotectedCheckMkdirsQuotaAndACL(parent, user, 1) == MkdirCheckResult.FAILED) {
                throw new FSException(FSException.ILLEGAL_PARAM,
                        "Cannot start file " + file
                                + " because its parent can not be created");
            }
            int group = 0;
            int parentReplication = 3;
            for (int i = nodes.length - 1; i >= 0; i--) {
                if (nodes[i] != null) {
                    group = nodes[i].getGroup();
                    parentReplication = nodes[i].getDesiredReplications();
                    break;
                }
            }
            node = new FileINodeUC(holder,
                    replication == NUM_REPLICAS_INHERITED ? parentReplication
                            : replication, fileBlockSize, time, time);
            node.setUser(ugMgr.getUserSerialNumber(user));
            node.setGroup(group);
            node.setFsPermission(permission.toShort());
            internalMkdirs(time, parent, FSConstants.NUM_REPLICAS_INHERITED,
                    -1, defaultPermission, user);
            parentNode = (DirectoryINode) unprotectedGetNode(parent);
        } else {
            parentNode = (DirectoryINode) nodes[nodes.length - 2];
            node = new FileINodeUC(
                    holder,
                    replication == NUM_REPLICAS_INHERITED ? parentNode.getDesiredReplications()
                            : replication, fileBlockSize, time, time);
            node.setUser(ugMgr.getUserSerialNumber(user));
            node.setGroup(parentNode.getGroup());
            node.setFsPermission(permission.toShort());
        }

        parentNode.addChild(fileName, node, time);
        FileINode deletedNode = null;
        if (oldINode != null) {
            oldINode.decRefCount();
            if (oldINode.getRefCount() == 0) {
                deletedNode = (FileINode) oldINode;
                distinctFileNum--;
                distinctFileSize -= deletedNode.getContentsLength();
            }
        }
        return new Pair<FileINodeUC, FileINode>(node, deletedNode);
    }

    protected boolean unprotectedCompleteFile(long time, String file) {
        String parentName = DirUtils.getParent(file);
        String name = DirUtils.getName(file);
        INode node = unprotectedGetNode(parentName);
        if (!(node instanceof DirectoryINode)) {
            return false;
        }
        DirectoryINode parentNode = (DirectoryINode) node;
        if (!(parentNode.getChild(name) instanceof FileINodeUC)) {
            return false;
        }
        FileINodeUC fileNodeUC = (FileINodeUC) parentNode.removeChild(name,
                time);
        List<BlockWithSize> blocks = fileNodeUC.blocks;
        FileINode fileNode;
        long contentsLength;
        if (blocks.size() == 1) {
            BlockWithSize blockWithSize = blocks.get(0);
            fileNode = new TinyFileINode(blockWithSize.block,
                    fileNodeUC.getDesiredReplications(), time, time);
            bstore.activateBlock(blockWithSize.block);
            contentsLength = blockWithSize.size;
        } else {
            long[] blockIds = new long[blocks.size()];
            contentsLength = 0;
            for (int i = 0; i < blocks.size(); i++) {
                BlockWithSize blockWithSize = blocks.get(i);
                bstore.activateBlock(blockWithSize.block);
                blockIds[i] = blockWithSize.block;
                contentsLength += blockWithSize.size;
            }
            fileNode = new NormalFileINode(blockIds,
                    fileNodeUC.getDesiredReplications(), time, time);
        }
        fileNode.setUser(fileNodeUC.getUser());
        fileNode.setGroup(fileNodeUC.getGroup());
        fileNode.setFsPermission(fileNodeUC.getFsPermission());
        fileNode.setContentsLength(contentsLength);
        parentNode.addChild(name, fileNode, time);
        unprotectedUpdateContentsLengthAndSubItemNum(file, contentsLength, 0, 1);
        distinctFileNum++;
        distinctFileSize += contentsLength;
        return true;
    }

    protected void unprotectedAbandonFileUC(long time, String file, String user)
            throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(file);
        permissionChecker.check(file, pair.getFirst(), pair.getSecond(), null,
                FsAction.WRITE, null, null, null, user);
        INode[] nodes = pair.getSecond();
        INode node = nodes[nodes.length - 1];
        if (!(node instanceof FileINodeUC)) {
            return;
        }
        DirectoryINode parentNode = (DirectoryINode) nodes[nodes.length - 2];
        parentNode.removeChild(pair.getFirst()[pair.getFirst().length - 1],
                time);
    }

    protected Pair<Boolean, FileINode> unprotectedDeprive(long time,
            String file, String user) throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(file);
        permissionChecker.check(file, pair.getFirst(), pair.getSecond(), null,
                FsAction.WRITE, FsAction.WRITE, null, null, user);
        INode[] nodes = pair.getSecond();
        INode node = nodes[nodes.length - 1];
        if (node == null) {
            return new Pair<Boolean, FileINode>(true, null);
        } else if (node instanceof DirectoryINode) {
            return new Pair<Boolean, FileINode>(false, null);
        }
        DirectoryINode parentNode = (DirectoryINode) nodes[nodes.length - 2];
        String name = pair.getFirst()[pair.getFirst().length - 1];
        parentNode.removeChild(name, time);
        if (node instanceof FileINode) {
            FileINode fileINode = (FileINode) node;
            fileINode.decRefCount();
            if (fileINode.getRefCount() == 0) {
                return new Pair<Boolean, FileINode>(true, fileINode);
            }
        }
        return new Pair<Boolean, FileINode>(true, null);
    }

    /**
     * Remove FileINodeUC nodes under this dir recursively.
     * 
     * @param dir
     */
    private void internalRemoveUCNodes(DirectoryINode dir) {
        for (KeyValueIterator<UTF8String, INode> iter = dir.iterator(); iter.hasNext();) {
            iter.next();
            INode node = iter.getValue();
            if (node instanceof DirectoryINode) {
                internalRemoveUCNodes((DirectoryINode) node);
            } else if (node instanceof FileINodeUC) {
                iter.remove();
            }
        }
    }

    protected FileINode unprotectedRenameTo(long time, String src, String dst,
            boolean overwrite, String user) throws FSException {
        Pair<String[], INode[]> srcPair = unprotectedGetPathExistingNodes(src);
        permissionChecker.check(src, srcPair.getFirst(), srcPair.getSecond(),
                null, FsAction.WRITE, null, null, null, user);
        INode[] srcNodes = srcPair.getSecond();
        INode srcNode = srcNodes[srcNodes.length - 1];
        if (srcNode == null || srcNode instanceof FileINodeUC) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot rename "
                    + src + " because it is not exist.");
        }
        Pair<String[], INode[]> dstPair = unprotectedGetPathExistingNodes(dst);
        if (dstPair.getSecond()[dstPair.getSecond().length - 1] instanceof DirectoryINode) {
            dst = (dst.length() == 1 ? INode.STR_SEP : dst + INode.SEP)
                    + srcPair.getFirst()[srcPair.getFirst().length - 1];
            dstPair = unprotectedGetPathExistingNodes(dst);
        }
        INode[] dstNodes = dstPair.getSecond();
        // only check write permission for access because we can only overwrite file.
        permissionChecker.check(dst, dstPair.getFirst(), dstPair.getSecond(),
                null, FsAction.WRITE, FsAction.WRITE, null, null, user);
        if (!(dstNodes[dstNodes.length - 2] instanceof DirectoryINode)) {
            throw new FSException(FSException.ILLEGAL_PARAM,
                    "Can not rename to " + dst
                            + " because its parent is not exist");
        }
        if (dstNodes[dstNodes.length - 1] != null) {
            if (dstNodes[dstNodes.length - 1] instanceof DirectoryINode) {
                throw new FSException(FSException.ILLEGAL_PARAM,
                        "Cannot rename to " + dst
                                + " because it is a directory");
            }
            if (dstNodes[dstNodes.length - 1] instanceof FileINodeUC) {
                throw new FSException(FSException.ILLEGAL_PARAM,
                        "Cannot rename to " + dst + " because it is pending");
            }
            if (srcNode instanceof DirectoryINode
                    && dstNodes[dstNodes.length - 1] instanceof FileINode) {
                throw new FSException(FSException.ILLEGAL_PARAM,
                        "Cannot rename " + src + "(directory) to " + dst
                                + " because it is a file");
            }
            if (!overwrite) {
                throw new FSException(
                        FSException.ILLEGAL_PARAM,
                        "Cannot rename to "
                                + dst
                                + " because overwrite is false and it is exists");
            }
        }
        long srcContentsLength = srcNode.getContentsLength();
        long srcSubDirNum = srcNode.getSubDirNum();
        long srcSubFileNum = srcNode.getSubFileNum();
        // src node is also deleted, so we need plus one.
        if (srcNode instanceof DirectoryINode) {
            srcSubDirNum++;
        } else { // FileINode
            srcSubFileNum++;
        }
        long addedSize = srcContentsLength;
        long addedName = srcSubDirNum + srcSubFileNum;
        if (dstNodes[dstNodes.length - 1] != null) {
            addedSize -= dstNodes[dstNodes.length - 1].getContentsLength();
            addedName -= 1;
        }
        unprotectedCheckQuota(DirUtils.getCommonAncestor(src, dst), dst,
                addedSize, addedName);
        if (srcNode instanceof DirectoryINode) {
            // remove FileINodeUC under srcNodes
            // TODO: Maybe we can let the pending file complete under the new location?
            internalRemoveUCNodes((DirectoryINode) srcNode);
        }
        DirectoryINode srcParentNode = (DirectoryINode) srcNodes[srcNodes.length - 2];
        String srcName = srcPair.getFirst()[srcPair.getFirst().length - 1];
        srcParentNode.removeChild(srcName, time);
        DirectoryINode dstParentNode = (DirectoryINode) dstNodes[dstNodes.length - 2];
        String dstName = dstPair.getFirst()[dstPair.getFirst().length - 1];
        FileINode deletedFile = (FileINode) dstParentNode.removeChild(dstName,
                time);
        dstParentNode.addChild(dstName, srcNode, time);
        if (deletedFile != null) {
            unprotectedUpdateContentsLengthAndSubItemNum(dst,
                    -deletedFile.getContentsLength(), 0, -1);
            deletedFile.decRefCount();
        }
        // update src
        unprotectedUpdateContentsLengthAndSubItemNum(src, -srcContentsLength,
                -srcSubDirNum, -srcSubFileNum);
        // update dst
        unprotectedUpdateContentsLengthAndSubItemNum(dst, srcContentsLength,
                srcSubDirNum, srcSubFileNum);
        if (deletedFile != null && deletedFile.getRefCount() == 0) {
            distinctFileNum--;
            distinctFileSize -= deletedFile.getContentsLength();
            return deletedFile;
        } else {
            return null;
        }
    }

    /**
     * Decrement ref count and collect file inode which ref count is 0
     * recursively.
     * 
     * @param node
     * @param deletedFiles
     *            null means do not need to collect file inode, just decrment
     *            ref count.
     */
    private void internalDecRefAndCollectDeletedFileINode(INode node,
            List<FileINode> deletedFiles) {
        if (node instanceof FileINode) {
            FileINode fileNode = (FileINode) node;
            fileNode.decRefCount();
            if (deletedFiles != null && fileNode.getRefCount() == 0) {
                deletedFiles.add(fileNode);
            }
        } else if (node instanceof DirectoryINode) {
            DirectoryINode dirNode = (DirectoryINode) node;
            for (KeyValueIterator<UTF8String, INode> iter = dirNode.iterator(); iter.hasNext();) {
                iter.next();
                internalDecRefAndCollectDeletedFileINode(iter.getValue(),
                        deletedFiles);
            }
        }
        // FileINodeUC is ignored
    }

    private void checkDeletePermission(String path, boolean recursive,
            String user, Pair<String[], INode[]> pair, String op)
            throws FSException {
        INode[] nodes = pair.getSecond();
        if (nodes[nodes.length - 1] instanceof DirectoryINode) {
            permissionChecker.check(path, pair.getFirst(), pair.getSecond(),
                    null, FsAction.WRITE, FsAction.ALL, FsAction.ALL,
                    FsAction.WRITE, user);
            if (!recursive) {
                throw new FSException(FSException.PERMISSION_DENIED, "Cannot "
                        + op + " directory " + path
                        + " when recursive is false.");
            }
        } else {
            permissionChecker.check(path, pair.getFirst(), pair.getSecond(),
                    null, FsAction.WRITE, FsAction.WRITE, null, null, user);
        }
    }

    protected List<FileINode> unprotectedDelete(long time, String path,
            boolean recursive, String user) throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(path);
        checkDeletePermission(path, recursive, user, pair, "delete");
        INode[] nodes = pair.getSecond();
        // deleting "/" is not allowed so nodes.length must larger than or 
        // equal to 2.
        INode parentNode = nodes[nodes.length - 2];
        if (!(parentNode instanceof DirectoryINode)) {
            LOG.info("Failed to delete " + path
                    + " because its parent is not exists");
            return null;
        }
        INode node = nodes[nodes.length - 1];
        if (node == null || node instanceof FileINodeUC) {
            LOG.info("Failed to delete " + path + " because it is not exists");
            return null;
        }
        long contentsLength = node.getContentsLength();
        long subDirNum = node.getSubDirNum();
        long subFileNum = node.getSubFileNum();
        // the node is also deleted, so we need plus one.
        if (node instanceof DirectoryINode) {
            subDirNum++;
        } else { // FileINode
            subFileNum++;
        }
        DirectoryINode parentDirNode = (DirectoryINode) parentNode;
        String name = pair.getFirst()[pair.getFirst().length - 1];
        INode deletedNode = parentDirNode.removeChild(name, time);
        List<FileINode> deletedFiles = new ArrayList<FileINode>();
        internalDecRefAndCollectDeletedFileINode(deletedNode, deletedFiles);
        unprotectedUpdateContentsLengthAndSubItemNum(path, -contentsLength,
                -subDirNum, -subFileNum);
        distinctFileNum -= deletedFiles.size();
        for (FileINode deletedFile: deletedFiles) {
            distinctFileSize -= deletedFile.getContentsLength();
        }
        return deletedFiles;
    }

    protected String unprotectedMkdirsAndRenameToWithoutCheckQuota(long time,
            String src, String dst, boolean recursive, String user)
            throws FSException {
        Pair<String[], INode[]> srcPair = unprotectedGetPathExistingNodes(src);
        // use the same permission as delete because the only use of this method
        // is trash.
        checkDeletePermission(src, recursive, user, srcPair, "rename");
        permissionChecker.check(src, srcPair.getFirst(), srcPair.getSecond(),
                null, FsAction.WRITE, FsAction.WRITE, null, null, user);
        INode[] srcNodes = srcPair.getSecond();
        INode srcNode = srcNodes[srcNodes.length - 1];
        if (srcNode == null || srcNode instanceof FileINodeUC) {
            LOG.warning("Cannot rename " + src + " because it is not exist.");
            return null;
        }
        String dstParent = DirUtils.getParent(dst);
        INode dstParentNode = unprotectedGetNode(dstParent);
        DirectoryINode dstParentDirNode;
        if (dstParentNode == null) {
            internalMkdirs(time, dstParent, FSConstants.NUM_REPLICAS_INHERITED,
                    -1, defaultPermission, user);
            dstParentDirNode = (DirectoryINode) unprotectedGetNode(dstParent);
        } else if (!(dstParentNode instanceof DirectoryINode)) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Can not rename "
                    + src + " to " + dst
                    + " because the dst parent is exists and not a directory.");
        } else {
            dstParentDirNode = (DirectoryINode) dstParentNode;
        }
        String dstName = DirUtils.getName(dst);
        if (dstParentDirNode.getChild(dstName) != null) {
            int i;
            for (i = 1; i > 0; i++) {
                String dstNameWithSuffix = dstName + "." + i;
                if (dstParentDirNode.getChild(dstNameWithSuffix) == null) {
                    dstName = dstNameWithSuffix;
                    break;
                }
            }
            if (i <= 0) {
                throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                        "Can not find a valid name for " + dst
                                + " because of integer overflow");
            }
        }
        long srcContentsLength = srcNode.getContentsLength();
        long srcSubDirNum = srcNode.getSubDirNum();
        long srcSubFileNum = srcNode.getSubFileNum();
        // src node is also deleted, so we need plus one.
        if (srcNode instanceof DirectoryINode) {
            srcSubDirNum++;
        } else { // FileINode
            srcSubFileNum++;
        }
        DirectoryINode srcParentDirNode = (DirectoryINode) srcNodes[srcNodes.length - 2];
        String srcName = srcPair.getFirst()[srcPair.getFirst().length - 1];
        srcParentDirNode.removeChild(srcName, time);
        dstParentDirNode.addChild(dstName, srcNode, time);
        unprotectedUpdateContentsLengthAndSubItemNum(src, -srcContentsLength,
                -srcSubDirNum, -srcSubFileNum);
        unprotectedUpdateContentsLengthAndSubItemNum(dst, srcContentsLength,
                srcSubDirNum, srcSubFileNum);
        return dst;
    }

    protected boolean unprotectedMkdirs(long time, String dir,
            int replications, FsPermission permission, String user)
            throws FSException {
        MkdirCheckResult result = unprotectedCheckMkdirsQuotaAndACL(dir, user,
                0);
        switch (result) {
            case EXISTS:
                return true;
            case FAILED:
                return false;
            default:
                internalMkdirs(time, dir, replications, -1, permission, user);
                return true;
        }
    }

    private void internalCheckFileINodeRefCount(String path, FileINode node)
            throws FSException {
        if (node.getRefCount() == 0xFFFF) {
            throw new FSException(FSException.NOT_ENOUGH_RESOURCE, path
                    + " ref count reach max allowed count " + 0xFFFF);
        }
    }

    private void internalCheckINodeRefCountAndPermissionRecursive(String path,
            String name, DirectoryINode node, String user) throws FSException {
        permissionChecker.checkINode(path, name, node, FsAction.READ_EXECUTE,
                user);
        for (KeyValueIterator<UTF8String, INode> iter = node.iterator(); iter.hasNext();) {
            iter.next();
            String childName = iter.getKey().toString();
            INode childNode = iter.getValue();
            if (childNode instanceof FileINode) {
                internalCheckFileINodeRefCount(path + INode.SEP + childName,
                        (FileINode) childNode);
            } else if (childNode instanceof DirectoryINode) {
                internalCheckINodeRefCountAndPermissionRecursive(path
                        + INode.SEP + childName, childName,
                        (DirectoryINode) childNode, user);
            }
        }
    }

    private void internalCopyOrLinkINode(long time, INode srcNode,
            DirectoryINode dstParentNode, String dstName, String user) {
        if (srcNode instanceof FileINode) {
            srcNode.incRefCount();
            dstParentNode.addChild(dstName, srcNode, time);
        } else if (srcNode instanceof DirectoryINode) {
            srcNode.setLastAccess(time);
            DirectoryINode srcDirNode = (DirectoryINode) srcNode;
            DirectoryINode dstDirNode = new DirectoryINode(
                    new SortedArrayChildren(srcDirNode.size()),
                    srcNode.getDesiredReplications(), time, time);
            dstDirNode.setGroup(dstParentNode.getGroup());
            dstDirNode.setUser(ugMgr.getUserSerialNumber(user));
            dstDirNode.setFsPermission(defaultPermission.toShort());
            dstParentNode.addChild(dstName, dstDirNode, time);
            for (KeyValueIterator<UTF8String, INode> iter = srcDirNode.iterator(); iter.hasNext();) {
                iter.next();
                internalCopyOrLinkINode(time, iter.getValue(), dstDirNode,
                        iter.getKey().toString(), user);
            }
            dstDirNode.setContentsLength(srcDirNode.getContentsLength());
            dstDirNode.setSubDirNum(srcDirNode.getSubDirNum());
            dstDirNode.setSubFileNum(srcDirNode.getSubFileNum());
        }
        // we do not care FileINodeUC
    }

    protected void unprotectedSnapshot(long time, String src, String dst,
            String user) throws FSException {
        Pair<String[], INode[]> srcPair = unprotectedGetPathExistingNodes(src);
        // just check traverse here, we will check other permission later
        // this is a performance issue, we need to confirm the ref count 
        // is not overflow recursively, so we do the permission check by
        // the way.
        permissionChecker.check(src, srcPair.getFirst(), srcPair.getSecond(),
                null, null, null, null, null, user);
        INode srcNode = srcPair.getSecond()[srcPair.getSecond().length - 1];
        if (srcNode == null || srcNode instanceof FileINodeUC) {
            throw new FSException(FSException.ILLEGAL_PARAM,
                    "Cannot link from " + src + " because it is not exists");
        }
        Pair<String[], INode[]> dstPair = unprotectedGetPathExistingNodes(dst);
        permissionChecker.check(dst, dstPair.getFirst(), dstPair.getSecond(),
                null, FsAction.WRITE, null, null, null, user);
        INode[] dstNodes = dstPair.getSecond();
        if (!(dstNodes[dstNodes.length - 2] instanceof DirectoryINode)) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot link to "
                    + dst + " because its parent is not exists");
        }
        if (dstNodes[dstNodes.length - 1] != null) {
            throw new FSException(FSException.ILLEGAL_PARAM, "Cannot link to "
                    + dst + " because it is already exists");
        }
        // recursively check ref count and permission
        if (srcNode instanceof DirectoryINode) {
            internalCheckINodeRefCountAndPermissionRecursive(src,
                    srcPair.getFirst()[srcPair.getFirst().length - 1],
                    (DirectoryINode) srcNode, user);
        } else { // FileINode
            internalCheckFileINodeRefCount(src, (FileINode) srcNode);
        }
        long srcContentsLength = srcNode.getContentsLength();
        long srcSubDirNum = srcNode.getSubDirNum();
        long srcSubFileNum = srcNode.getSubFileNum();
        // src node is also linked, so we need plus one.
        if (srcNode instanceof DirectoryINode) {
            srcSubDirNum++;
        } else { // FileINode
            srcSubFileNum++;
        }
        unprotectedCheckQuota(null, dst, srcContentsLength, srcSubDirNum
                + srcSubFileNum);
        internalCopyOrLinkINode(time, srcNode,
                (DirectoryINode) dstNodes[dstNodes.length - 2],
                dstPair.getFirst()[dstPair.getFirst().length - 1], user);
        unprotectedUpdateContentsLengthAndSubItemNum(dst, srcContentsLength,
                srcSubDirNum, srcSubFileNum);
    }

    private void internalChangeReplication(long time, INode node,
            int replications, boolean recursive) {
        if (node instanceof FileINode) {
            FileINode fileNode = (FileINode) node;
            if (fileNode.getDesiredReplications() != replications) {
                fileNode.setDesiredReplications(replications);
                long[] blocks = fileNode.getBlocks();
                if (blocks != null) {
                    bstore.changeReplication(blocks, replications);
                }
                node.setLastModified(time);
            }
        } else if (node instanceof DirectoryINode) {
            if (node.getDesiredReplications() != replications) {
                node.setDesiredReplications(replications);
                node.setLastModified(time);
            }
            if (recursive) {
                for (KeyValueIterator<UTF8String, INode> iter = ((DirectoryINode) node).iterator(); iter.hasNext();) {
                    iter.next();
                    internalChangeReplication(time, iter.getValue(),
                            replications, recursive);
                }
            }
        }
    }

    protected void unprotectedChangeReplication(long time, String path,
            int replications, boolean recursive, String user)
            throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(path);
        INode[] nodes = pair.getSecond();
        INode node = nodes[nodes.length - 1];
        if (recursive && (node instanceof DirectoryINode)) {
            permissionChecker.check(path, pair.getFirst(), nodes, null, null,
                    FsAction.ALL, FsAction.ALL, FsAction.WRITE, user);
        } else {
            permissionChecker.check(path, pair.getFirst(), nodes, null, null,
                    FsAction.WRITE, null, null, user);
        }

        if (node == null) {
            throw new FSException(FSException.ILLEGAL_PARAM,
                    "Cannot change replication for " + path
                            + " because it is not exists");
        }
        internalChangeReplication(time, node, replications, recursive);
    }

    private void internalSetOwnerAndGroup(INode node, String owner,
            String group, boolean recursive) {
        if (node instanceof FileINodeUC) {
            return;
        }
        if (!StringUtils.isBlank(owner)) {
            node.setUser(ugMgr.getUserSerialNumber(owner));
        }
        if (!StringUtils.isBlank(group)) {
            node.setGroup(ugMgr.getGroupSerialNumber(group));
        }
        if (recursive && (node instanceof DirectoryINode)) {
            for (KeyValueIterator<UTF8String, INode> iter = ((DirectoryINode) node).iterator(); iter.hasNext();) {
                iter.next();
                internalSetOwnerAndGroup(iter.getValue(), owner, group,
                        recursive);
            }
        }
    }

    protected void unprotectedSetOwnerAndGroup(String path, String owner,
            String group, boolean recursive, String user) throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(path);
        INode[] nodes = pair.getSecond();
        if (!admin.equals(user)) {
            permissionChecker.checkOwner(path, pair.getFirst(), nodes,
                    recursive, user);
        }
        INode node = nodes[nodes.length - 1];
        if (node == null || node instanceof FileINodeUC) {
            throw new FSException(FSException.ILLEGAL_PARAM,
                    "Cannot set owner and group because " + path
                            + " is not exists.");
        }
        internalSetOwnerAndGroup(node, owner, group, recursive);
    }

    private void internalSetPermission(INode node, FsPermission permission,
            boolean recursive) {
        if (node instanceof FileINodeUC) {
            return;
        }
        if (node instanceof DirectoryINode) {
            node.setFsPermission(permission.toShort());
            if (recursive) {
                for (KeyValueIterator<UTF8String, INode> iter = ((DirectoryINode) node).iterator(); iter.hasNext();) {
                    iter.next();
                    internalSetPermission(iter.getValue(), permission,
                            recursive);
                }
            }
        } else {
            permission = permission.applyUMask(FileINode.UMASK);
            node.setFsPermission(permission.toShort());
        }
    }

    protected void unprotectedSetPermission(String path,
            FsPermission permission, boolean recursive, String user)
            throws FSException {
        Pair<String[], INode[]> pair = unprotectedGetPathExistingNodes(path);
        INode[] nodes = pair.getSecond();
        if (!admin.equals(user)) {
            permissionChecker.checkOwner(path, pair.getFirst(), nodes,
                    recursive, user);
        }
        INode node = nodes[nodes.length - 1];
        if (node == null || node instanceof FileINodeUC) {
            throw new FSException(FSException.ILLEGAL_PARAM,
                    "Cannot set permission because " + path + " is not exists.");
        }
        internalSetPermission(node, permission, recursive);
    }

}
