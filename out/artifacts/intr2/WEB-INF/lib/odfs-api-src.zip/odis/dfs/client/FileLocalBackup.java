/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar, 2006
 */
package odis.dfs.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

/**
 * FileLocalBackup, not to be reused.
 * 
 * @author river
 */
public class FileLocalBackup implements LocalBackup {

    private static final Logger LOG = LogFormatter.getLogger(FileLocalBackup.class);

    private final File file;

    private OutputStreamImpl os;

    /**
     * 在dir目录下创建一个临时文件作为backup.
     * 
     * @param dir
     * @throws IOException
     */
    public FileLocalBackup(File dir) throws IOException {
        file = File.createTempFile("ndfsout", "bak", dir);
    }

    /**
     * 获得到backup的输出，如果多次调用这个方法，会返回同一个输出.
     */
    @Override
    public synchronized OutputStream getOutputStream() throws IOException {
        if (os == null) {
            os = new OutputStreamImpl(new FileOutputStream(file));
        } else {
            if (os.isClosed()) {
                throw new IOException("backup stream is closed");
            }
        }
        return os;
    }

    /**
     * 返回一个backup的输入，每次返回的inputstream都是不一样的，调用者需要 负责关闭这个InputStream.
     */
    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if (os != null && !os.isClosed()) {
            os.flush();
        }
        return new FileInputStream(file);
    }

    /**
     * 关闭backup，删除备份文件，如果已经打开了输出，这里会强制关闭.
     */
    @Override
    public synchronized void discard() throws IOException {
        ReadWriteUtils.safeClose(os);
        os = null;
        if (file.exists() && !file.delete()) {
            LOG.warning("delete file local backup " + file.getAbsolutePath()
                    + " failed");
        }
    }

    private static final class OutputStreamImpl extends FilterOutputStream {
        private boolean closed;

        public OutputStreamImpl(OutputStream os) {
            super(os);
            this.closed = false;
        }

        @Override
        public void write(byte b[], int off, int len) throws IOException {
            this.out.write(b, off, len);
        }

        @Override
        public void close() throws IOException {
            ReadWriteUtils.safeClose(out);
            this.closed = true;
        }

        public boolean isClosed() {
            return closed;
        }
    }

}
