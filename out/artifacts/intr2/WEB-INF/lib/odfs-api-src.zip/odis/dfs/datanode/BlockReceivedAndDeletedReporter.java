/**
 * @(#)BlockReceivedAndDeletedReporter.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockSize;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.IDataToNameProtocol;
import odis.dfs.util.DfsUtils;

import org.apache.commons.configuration.Configuration;

import toolbox.collections.primitive.LongArrayList;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class BlockReceivedAndDeletedReporter extends Thread {

    private static final Logger LOG = LogFormatter.getLogger(BlockReceivedAndDeletedReporter.class);

    private final DataNode dataNode;

    private final Lock lock = new ReentrantLock();

    private final Condition notEmpty = lock.newCondition();

    private final List<BlockSize> received = new ArrayList<BlockSize>();

    private final LongArrayList deleted = new LongArrayList();

    private final int maxRetryCount;

    BlockReceivedAndDeletedReporter(Configuration conf, DataNode dataNode) {
        super(dataNode.fullName + "-BlockReceivedAndDeletedReporter");
        setDaemon(true);
        this.dataNode = dataNode;
        this.maxRetryCount = conf.getInt(
                DFSConfig.DATANODE_REPORT_BLOCK_RECEIVED_AND_DELETED_MAX_RETRY_COUNT,
                DFSConfig.DEFAULT_DATANODE_REPORT_BLOCK_RECEIVED_AND_DELETED_MAX_RETRY_COUNT);
    }

    void blockReceived(BlockSize bs) {
        lock.lock();
        try {
            received.add(bs);
            notEmpty.signal();
        } finally {
            lock.unlock();
        }
    }

    void blockDeleted(long[] ids) {
        lock.lock();
        try {
            deleted.addAll(ids);
            notEmpty.signal();
        } finally {
            lock.unlock();
        }
    }

    void shutdown() {
        running = false;
        interrupt();
    }

    void awaitTermination() throws InterruptedException {
        join();
    }

    private volatile boolean running = true;

    private void reportToNameNode(IDataToNameProtocol nameNode,
            BlockSize[] received, long[] deleted) {
        for (int retry = 0;; retry++) {
            try {
                nameNode.reportBlockReceivedOrDeleted(dataNode.fullName,
                        received, deleted);
                break;
            } catch (Exception e) {
                if (maxRetryCount >= 0 && retry >= maxRetryCount) {
                    LOG.log(Level.WARNING, dataNode.fullName + " report "
                            + received.length + " received and "
                            + deleted.length
                            + " deleted to namenode failed after retry "
                            + retry + " times, give up", e);
                    return;
                }
                retry++;
                LOG.log(Level.WARNING, dataNode.fullName + " report "
                        + received.length + " received and " + deleted.length
                        + " deleted to namenode failed, retry = " + retry, e);
                DfsUtils.waitExpTime(retry - 1);
            }
        }
    }

    @Override
    public void run() {
        outer: while (running) {
            BlockSize[] receivedBlocks;
            long[] deletedBlocks;
            lock.lock();
            try {
                while (received.isEmpty() && deleted.isEmpty()) {
                    try {
                        notEmpty.await();
                    } catch (InterruptedException e) {
                        continue outer;
                    }
                }
                receivedBlocks = received.toArray(new BlockSize[0]);
                received.clear();
                deletedBlocks = deleted.toArray();
                deleted.clear();
            } finally {
                lock.unlock();
            }
            IDataToNameProtocol[] nameNodes = dataNode.getNameNodes();
            for (IDataToNameProtocol nameNode: nameNodes) {
                reportToNameNode(nameNode, receivedBlocks, deletedBlocks);
            }
        }
    }
}
