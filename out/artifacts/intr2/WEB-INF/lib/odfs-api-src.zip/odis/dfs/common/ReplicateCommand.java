/**
 * @(#)ReplicateCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.dfs.datanode.DataNode;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * Queue the replication of a block. The datanode decides when to do the actual
 * replication. Blocks marked with immediate will have a higher priority.
 * 
 * @author zhangduo
 */
public class ReplicateCommand extends DataNodeCommand {

    private long block;

    private String[] targets;

    private boolean immediate;

    public ReplicateCommand() {}

    public ReplicateCommand(long block, String[] targets, boolean immediate) {
        this.block = block;
        this.targets = targets;
        this.immediate = immediate;
    }

    public long getBlock() {
        return block;
    }

    public void setBlock(long block) {
        this.block = block;
    }

    public String[] getTargets() {
        return targets;
    }

    public void setTargets(String[] targets) {
        this.targets = targets;
    }

    public boolean isImmediate() {
        return immediate;
    }

    public void setImmediate(boolean immediate) {
        this.immediate = immediate;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        block = in.readLong();
        int sz = CDataInputStream.readVInt(in);
        targets = new String[sz];
        for (int i = 0; i < sz; i++) {
            targets[i] = StringWritable.readString(in);
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(block);
        CDataOutputStream.writeVInt(targets.length, out);
        for (String target: targets) {
            StringWritable.writeString(out, target);
        }

    }

    @Override
    public IWritable copyFields(IWritable value) {
        ReplicateCommand that = (ReplicateCommand) value;
        block = that.block;
        targets = Arrays.copyOf(that.targets, that.targets.length);
        immediate = that.immediate;
        return this;
    }

    @Override
    public void execute(DataNode dataNode) throws IOException {
        dataNode.scheduleBlockReplication(this);
    }

}
