package odis.dfs.journal.qjournal.server;

import java.io.IOException;

import com.google.common.annotations.VisibleForTesting;

/**
 * Used for injecting faults in QuorumJournalManager tests.
 * Calls into this are a no-op in production code. 
 */
public class JournalFaultInjector {
    static JournalFaultInjector instance = new JournalFaultInjector();

    public static JournalFaultInjector get() {
        return instance;
    }

    @VisibleForTesting
    public static void setInstance(JournalFaultInjector instance) {
        JournalFaultInjector.instance = instance;
    }

    public void beforePersistPaxosData() throws IOException {}
    public void afterPersistPaxosData() throws IOException {}
}

