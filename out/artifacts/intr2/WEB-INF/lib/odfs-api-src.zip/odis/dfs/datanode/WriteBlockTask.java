/**
 * @(#)WriteBlockTask.java, 2012-12-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.EOFException;
import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockSize;
import odis.dfs.common.DataNodeRequest;
import odis.dfs.common.DataNodeRequest.Op;
import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.common.DataNodeRequest.WriteBlockBody;
import odis.dfs.common.FSConstants;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.util.DfsUtils;
import odis.io.ByteBufferOutputStream;
import odis.io.CDataOutputStream;
import odis.io.DirectByteBufferPool;
import odis.io.InterruptibleSocket;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
class WriteBlockTask implements Runnable, FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(WriteBlockTask.class);

    private final DataNode dataNode;

    private final SocketChannel client;

    private final SocketAddress remoteAddr;

    private final long block;

    private final String[] targets;

    private final ReportCond reportCond;

    private final long connInitTime;

    private final DirectByteBufferPool directByteBufferPool;

    private final ByteBuffer bb;

    private InterruptibleSocket mirrorSocket;

    private long startTime;

    WriteBlockTask(DataNode dataNode, SocketChannel client, long block,
            String[] targets, ReportCond reportCond,
            DirectByteBufferPool directByteBufferPool, ByteBuffer bb,
            long connInitTime) {
        this.dataNode = dataNode;
        this.client = client;
        this.remoteAddr = client.socket().getRemoteSocketAddress();
        this.block = block;
        this.targets = targets;
        this.reportCond = reportCond;
        this.directByteBufferPool = directByteBufferPool;
        this.bb = bb;
        this.connInitTime = connInitTime;
    }

    void forceComplete() {
        ReadWriteUtils.safeClose(client);
    }

    private void cleanUp(BlockOutputStream localOut, boolean abandon) {
        long delay = System.currentTimeMillis() - startTime;
        dataNode.metrics.increment(DataNodeMetricsItem.WRITE_PARTIAL_COUNT);
        dataNode.metrics.add(DataNodeMetricsItem.WRITE_DELAY, delay);
        ReadWriteUtils.safeClose(mirrorSocket);
        directByteBufferPool.release(bb);
        if (abandon) {
            int bytesWritten = localOut.abandon();
            dataNode.metrics.add(DataNodeMetricsItem.WRITE_BYTES, bytesWritten);
        } else if (localOut != null) {
            try {
                localOut.close();
            } catch (DataNodeFatalException e) {
                LOG.log(Level.SEVERE,
                        "fatal error occurred when closing block " + block
                                + " from " + remoteAddr, e);
                dataNode.offline();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "close block " + block + " from "
                        + remoteAddr + " failed", e);
            }
            int blockLength = localOut.fileLength();
            LOG.info("Finalized partial block " + block + ". size is "
                    + blockLength);
            dataNode.dataSet.addBlock(block, blockLength);
            dataNode.blockRceivedAndDeletedReporter.blockReceived(new BlockSize(
                    block, blockLength));
            dataNode.metrics.add(DataNodeMetricsItem.WRITE_BYTES, blockLength);
        }
        // just close client connection.
        // a zero successCount means nothing.
        LOG.info("Closing " + remoteAddr + " on write error after "
                + (System.currentTimeMillis() - connInitTime) + "ms");
        ReadWriteUtils.safeClose(client);
        dataNode.writingBlocks.remove(block);
        dataNode.metrics.decrement(DataNodeMetricsItem.CONCURRENT_WRITE);
        Thread.currentThread().setName("Idle-DataXceiver");
    }

    private void writeToMirror() {
        if (mirrorSocket != null) {
            try {
                mirrorSocket.write(bb);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "write to mirror " + targets[0]
                        + " when write block " + block + " failed", e);
                ReadWriteUtils.safeClose(mirrorSocket);
                mirrorSocket = null;
            }
        }
    }

    private boolean readFromMirror() {
        if (mirrorSocket != null) {
            try {
                do {
                    if (mirrorSocket.read(bb) < 0) {
                        LOG.warning("Unexpected EOF Got when read from mirror "
                                + targets[0] + " when write block " + block);
                        ReadWriteUtils.safeClose(mirrorSocket);
                        mirrorSocket = null;
                        return false;
                    }
                } while (bb.hasRemaining());
                return true;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "read from mirror " + targets[0]
                        + " when write block " + block + " failed", e);
                ReadWriteUtils.safeClose(mirrorSocket);
                mirrorSocket = null;
            }
        }
        return false;
    }

    private void readAndWriteResponse(int expectedResponse) throws IOException {
        bb.position(0);
        bb.limit(4);
        if (readFromMirror()) {
            int flushResponse = bb.getInt(0);
            if (flushResponse != expectedResponse) {
                LOG.warning("Unexpected response " + flushResponse
                        + " got when flushing block " + block + " to "
                        + targets[0] + ", expected " + expectedResponse);
                ReadWriteUtils.safeClose(mirrorSocket);
                mirrorSocket = null;
            }
        }
        bb.position(0);
        bb.limit(4);
        bb.putInt(0, expectedResponse);
        do {
            client.write(bb);
        } while (bb.hasRemaining());
    }

    private void readFromClient(int count) throws IOException {
        bb.position(0);
        bb.limit(count);
        do {
            if (client.read(bb) < 0) {
                throw new EOFException("Unexpected EOF got from when writing "
                        + block);
            }
        } while (bb.hasRemaining());
    }

    @Override
    public void run() {
        Thread.currentThread().setName(
                "WB-" + dataNode.getFullName() + "-" + block + "-" + remoteAddr);
        dataNode.metrics.increment(DataNodeMetricsItem.CONCURRENT_WRITE);
        dataNode.metrics.increment(DataNodeMetricsItem.WRITE_COUNT);
        startTime = System.currentTimeMillis();
        if (targets.length > 0) {
            try {
                mirrorSocket = new InterruptibleSocket(
                        DataNode.createSocketAddr(targets[0]),
                        dataNode.writeChainTimeout, directByteBufferPool);
                LOG.info("Mirror block " + block + " to " + targets[0]);
                DataNodeRequest mirrorReq = new DataNodeRequest(Op.WRITE_BLOCK);
                WriteBlockBody mirrorBody = (WriteBlockBody) mirrorReq.getBody();
                mirrorBody.setBlock(block);
                mirrorBody.setTargets(targets);
                mirrorBody.setReportCond(reportCond);
                bb.clear();
                ByteBufferOutputStream byteOut = new ByteBufferOutputStream(bb);
                CDataOutputStream dataOut = new CDataOutputStream(byteOut);
                mirrorReq.writeFields(dataOut);
                bb.flip();
                mirrorSocket.write(bb);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "connect to mirror " + targets[0]
                        + " when write block " + block + " failed", e);
                ReadWriteUtils.safeClose(mirrorSocket);
                mirrorSocket = null;
            }
        }
        final BlockOutputStream localOut;
        try {
            localOut = dataNode.dataSet.createBlock(block);
        } catch (IOException e) {
            LOG.log(Level.WARNING, "create block output from " + remoteAddr
                    + " when write block " + block + " failed", e);
            cleanUp(null, false);
            return;
        }
        try {
            for (;;) {
                readFromClient(4);
                bb.flip();
                writeToMirror();
                int len = bb.getInt(0);
                if (len < 0) {
                    if (len == CHUNK_SIZE_END_OF_BLOCK) {
                        readFromClient(8);
                        bb.flip();
                        writeToMirror();
                        long clientChecksum = bb.getLong(0);
                        if (clientChecksum != CHECKUM_NA
                                && clientChecksum != localOut.getAdler32()) {
                            LOG.warning("Checksum mismatch when writing "
                                    + block
                                    + ": expected "
                                    + HexString.intToPaddedHex((int) clientChecksum)
                                    + ", actual "
                                    + HexString.intToPaddedHex((int) localOut.getAdler32()));
                            cleanUp(localOut, true);
                            return;
                        }
                        localOut.close();
                        break;
                    } else if (len == CHUNK_SIZE_FLUSH_WITH_RESPONSE) {
                        readAndWriteResponse(DATANODE_FLUSH_RESPONSE);
                    } else if (len == CHUNK_SIZE_FLUSH_WITHOUT_RESPONSE) {
                        // nothing to do
                    } else if (len == CHUNK_SIZE_SYNC_WITH_RESPONSE) {
                        localOut.sync();
                        readAndWriteResponse(DATANODE_SYNC_RESPONSE);
                    } else if (len == CHUNK_SIZE_SYNC_ASYNC_WITH_RESPONSE) {
                        Future<Object> future = dataNode.dataNodeMgr.asyncTaskPool.submit(new Callable<Object>() {

                            @Override
                            public Object call() throws Exception {
                                localOut.sync();
                                return null;
                            }

                        });
                        try {
                            readAndWriteResponse(DATANODE_SYNC_ASYNC_RESPONSE);
                        } finally {
                            future.get();
                        }
                    } else if (len == CHUNK_SIZE_SYNC_WITHOUT_RESPONSE) {
                        localOut.sync();
                    } else {
                        LOG.warning("Invalid chunk length got when writing "
                                + block + ": " + len);
                        cleanUp(localOut, reportCond != ReportCond.ALWAYS);
                        return;
                    }
                    continue;
                }
                while (len > 0) {
                    bb.position(0);
                    bb.limit(Math.min(bb.capacity(), len));
                    int bytesRead = client.read(bb);
                    if (bytesRead < 0) {
                        throw new EOFException(
                                "Unexpected EOF got from when writing " + block);
                    }
                    bb.flip();
                    writeToMirror();
                    if (bb.position() > 0) {
                        bb.position(0);
                        bb.limit(bytesRead);
                    }
                    localOut.write(bb);
                    len -= bytesRead;
                }
            }
        } catch (DataNodeFatalException e) {
            LOG.log(Level.SEVERE, "fatal error occurred when writing block "
                    + block, e);
            cleanUp(localOut, reportCond != ReportCond.ALWAYS);
            dataNode.offline();
            return;
        } catch (Exception e) {
            LOG.log(Level.WARNING, "write block " + block + " from "
                    + remoteAddr + " failed", e);
            cleanUp(localOut, reportCond != ReportCond.ALWAYS);
            return;
        }
        try {
            dataNode.dataSet.writeChecksum(block, localOut.getAdler32());
        } catch (Exception e) {
            LOG.log(Level.WARNING,
                    "write checksum "
                            + HexString.intToPaddedHex((int) localOut.getAdler32())
                            + " of block " + block + " failed", e);
        }
        long delay = System.currentTimeMillis() - startTime;
        int blockLength = localOut.fileLength();
        dataNode.dataSet.addBlock(block, blockLength);
        dataNode.metrics.add(DataNodeMetricsItem.WRITE_BYTES, blockLength);
        dataNode.metrics.add(DataNodeMetricsItem.WRITE_DELAY, delay);
        dataNode.blockRceivedAndDeletedReporter.blockReceived(new BlockSize(
                block, blockLength));
        int numMirrored;
        bb.position(0);
        bb.limit(1);
        if (readFromMirror()) {
            numMirrored = 1 + (bb.get(0) & 0xFF);
        } else {
            numMirrored = 1;
        }
        LOG.info("Finalized complete block " + block + ", size is "
                + blockLength + ", mirrored to "
                + DfsUtils.toString(targets, 0, numMirrored - 1));
        ReadWriteUtils.safeClose(mirrorSocket);
        bb.position(0);
        bb.limit(1);
        bb.put(0, (byte) numMirrored);
        try {
            do {
                client.write(bb);
            } while (bb.hasRemaining());
        } catch (Exception e) {
            LOG.log(Level.WARNING, "notify client " + remoteAddr
                    + " about completion of " + block + " failed", e);
        }
        directByteBufferPool.release(bb);
        LOG.info("Closing " + remoteAddr + " on write success after "
                + (System.currentTimeMillis() - connInitTime) + "ms");
        ReadWriteUtils.safeClose(client);
        dataNode.writingBlocks.remove(block);
        dataNode.metrics.decrement(DataNodeMetricsItem.CONCURRENT_WRITE);
        Thread.currentThread().setName("Idle-DataXceiver");
    }
}
