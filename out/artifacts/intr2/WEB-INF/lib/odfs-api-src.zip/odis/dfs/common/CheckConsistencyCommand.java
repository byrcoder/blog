/**
 * @(#)CheckConsistencyCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.dfs.datanode.DataNode;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * Read and calculate the checksum of a block stored on the DataNode, and
 * compare it with the original checksum, which is also stored on the DataNode.
 * 
 * @author zhangduo
 */
public class CheckConsistencyCommand extends DataNodeCommand {

    private long[] blocks;

    public CheckConsistencyCommand() {}

    public CheckConsistencyCommand(long[] blocks) {
        this.blocks = blocks;
    }

    public long[] getBlocks() {
        return blocks;
    }

    public void setBlocks(long[] blocks) {
        this.blocks = blocks;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(blocks.length, out);
        for (long block: blocks) {
            out.writeLong(block);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        int sz = CDataInputStream.readVInt(in);
        blocks = new long[sz];
        for (int i = 0; i < sz; i++) {
            blocks[i] = in.readLong();
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        CheckConsistencyCommand that = (CheckConsistencyCommand) value;
        blocks = Arrays.copyOf(that.blocks, that.blocks.length);
        return this;
    }

    @Override
    public void execute(DataNode dataNode) {
        dataNode.scheduleBlockConsistencyCheck(blocks);
    }

}
