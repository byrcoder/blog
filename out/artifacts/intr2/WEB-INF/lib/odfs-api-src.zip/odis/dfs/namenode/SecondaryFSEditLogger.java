/**
 * @(#)SecondaryFSEditLogger.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.IOException;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.JournalManager;
import odis.dfs.util.DfsUtils;

import org.apache.commons.configuration.Configuration;

/**
 * @author zhangduo
 */
class SecondaryFSEditLogger extends AbstractFSEditLogger {

    SecondaryFSEditLogger(Configuration conf) throws IOException {
        super(DfsUtils.createFromConf(conf.getString(
                DFSConfig.JOURNAL_MANAGER_CLASS,
                DFSConfig.DEFAULT_JOURNAL_MANAGER_CLASS), conf,
                JournalManager.class));
    }

    void deleteOldFSEditLog(long beforeSN) throws IOException {
        journalMgr.deleteSegmentBefore(beforeSN);
    }
}
