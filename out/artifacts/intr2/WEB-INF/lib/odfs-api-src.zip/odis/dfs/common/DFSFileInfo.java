/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.lib.UTF8Writable;

/**
 * DFSFileInfo tracks info about remote files, including name, size, etc.
 * 
 * @author Mike Cafarella
 */
@Deprecated
public class DFSFileInfo implements IWritable {
    static {
        WritableRegistry.registerAlias(DFSFileInfo.class, "DFSFileInfo");
    }

    String path;

    long len;

    long contentsLen; // for symbolic link to record target len

    boolean isDir;

    long lastModified;

    String target = null; // If this is a symbolic link, target should point to the real target

    /**
     */
    public DFSFileInfo() {}

    /**
     */
    public DFSFileInfo(String path, long len, long contentsLen, boolean isDir,
            long lastModified) {
        this.path = path;
        this.len = len;
        this.contentsLen = contentsLen;
        this.isDir = isDir;
        this.lastModified = lastModified;
    }

    /**
     */
    public String getPath() {
        return path;
    }

    /**
     */
    public String getName() {
        return new File(path.toString()).getName();
    }

    /**
     */
    public String getParent() {
        return DFSFile.getDFSParent(path.toString());
    }

    /**
     */
    public long getLen() {
        return len;
    }

    /**
     */
    public long getContentsLen() {
        return contentsLen;
    }

    /**
     */
    public boolean isDir() {
        return isDir;
    }

    /**
     */
    public boolean isSLink() {
        return (target != null);
    }

    /**
     */
    public String getTarget() {
        return target;
    }

    /**
     */
    public void setTarget(String target) {
        this.target = target;
    }

    /**
     */
    public long lastModified() {
        return lastModified;
    }

    /**
     */
    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }

    // ////////////////////////////////////////////////
    // Writable
    // ////////////////////////////////////////////////
    public void writeFields(DataOutput out) throws IOException {
        UTF8Writable.writeString(out, path);
        out.writeLong(len);
        out.writeLong(contentsLen);
        out.writeBoolean(isDir);
        out.writeLong(lastModified);
        boolean isSLink = (target != null);
        out.writeBoolean(isSLink);
        if (isSLink) {
            UTF8Writable.writeString(out, target);
        }
    }

    public void readFields(DataInput in) throws IOException {
        this.path = UTF8Writable.readString(in);
        this.len = in.readLong();
        this.contentsLen = in.readLong();
        this.isDir = in.readBoolean();
        this.lastModified = in.readLong();
        boolean isSLink = in.readBoolean();
        if (isSLink) {
            this.target = UTF8Writable.readString(in);
        } else {
            this.target = null;
        }
    }

    public IWritable copyFields(IWritable value) {
        DFSFileInfo fi = (DFSFileInfo) value;
        path = fi.path;
        len = fi.len;
        contentsLen = fi.contentsLen;
        isDir = fi.isDir;
        lastModified = fi.lastModified;
        target = fi.target;
        return this;
    }
}
