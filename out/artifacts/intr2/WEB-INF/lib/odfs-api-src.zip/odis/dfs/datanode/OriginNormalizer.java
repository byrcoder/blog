/**
 * @(#)OriginNormalizer.java, 2012-12-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import org.apache.commons.configuration.Configuration;

/**
 * @author zhangduo
 */
class OriginNormalizer implements OfflineDiskPathNormalizer {

    OriginNormalizer(Configuration conf) {}

    @Override
    public String getPrefix(String path) {
        return path;
    }

}
