/**
 * @(#)SegmentedReserveByCapacityPolicy.java, 2011-12-25. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSException;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class SegmentedReserveByCapacityPolicy extends AbstractReserveByCapacityPolicy {

    private static final Logger LOG = LogFormatter.getLogger(SegmentedReserveByCapacityPolicy.class);

    public SegmentedReserveByCapacityPolicy(Configuration conf) {
        super(conf.getInt(DFSConfig.MAX_REPLICATION_PER_TIME,
                DFSConfig.DEFAULT_MAX_REPLICATION_PER_TIME));
    }

    /**
     * {@inheritDoc}
     * <p>
     * First, we reserve on different machines, then on different disks.
     */
    @Override
    public synchronized DatanodeInfo[] chooseTargets(String srcHost,
            long block, int replicas, DatanodeInfo[] alreadyChosenNodes,
            int expectedBlockSize) throws FSException {
        List<DatanodeInfo> candidateNodes;
        long totalCapacity = 0;
        synchronized (datanodes) {
            candidateNodes = new ArrayList<DatanodeInfo>(datanodes.size());
            for (DatanodeInfo dinfo: datanodes) {
                if (dinfo.getRemaining() - dinfo.getReserved() > expectedBlockSize) {
                    totalCapacity += dinfo.getCapacity();
                    candidateNodes.add(dinfo);
                }
            }
        }
        if (totalCapacity == 0) {
            LOG.warning("Cannot find a single datanode with "
                    + "enough freespace to allocate a new block");
            throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                    "Cannot find a single datanode with "
                            + "enough freespace to allocate a new block");
        }
        Set<DatanodeInfo> alreadyChosenNodeSet = new HashSet<DatanodeInfo>();
        Set<String> alreadyChosenHostSet = new HashSet<String>();
        if (alreadyChosenNodes != null) {
            for (DatanodeInfo alreadyChosenNode: alreadyChosenNodes) {
                alreadyChosenNodeSet.add(alreadyChosenNode);
                alreadyChosenHostSet.add(alreadyChosenNode.getHost());
            }
        }
        List<DatanodeInfo> chosenTargets = new ArrayList<DatanodeInfo>(replicas
                - alreadyChosenNodeSet.size());

        long segmentLength = totalCapacity / replicas;

        long startCapacity;
        long endCapacity = 0;
        int startPos;
        int endPos = 0;
        // first, we reserve on different machine
        for (int i = 0; i < replicas; i++) {
            startCapacity = endCapacity;
            startPos = endPos;
            if (endPos == candidateNodes.size()) {
                break;
            }
            long targetCapacity = (i == replicas - 1) ? totalCapacity
                    : startCapacity + segmentLength;
            boolean alreadyChosen = false;
            for (;;) {
                DatanodeInfo dinfo = candidateNodes.get(endPos);
                endCapacity += dinfo.getCapacity();
                endPos++;
                alreadyChosen = alreadyChosen
                        | alreadyChosenHostSet.contains(dinfo.getHost());
                if (endPos == candidateNodes.size()) {
                    break;
                }
                if (endCapacity >= targetCapacity
                        && !dinfo.getHost().equals(
                                candidateNodes.get(endPos).getHost())) {
                    break;
                }
            }
            if (alreadyChosen) {
                // already have datanode on this segment
                continue;
            }
            DatanodeInfo dinfo = candidateNodes.get(startPos
                    + findRandomDatanode(
                            candidateNodes.subList(startPos, endPos),
                            endCapacity - startCapacity));
            chosenTargets.add(dinfo);
            alreadyChosenHostSet.add(dinfo.getHost());
            alreadyChosenNodeSet.add(dinfo);
            // This may happen if we already have more than one replications 
            // on one segment 
            if (alreadyChosenNodeSet.size() == replicas) {
                break;
            }
        }
        int missedCount = replicas - alreadyChosenNodeSet.size();
        if (missedCount > 0) {
            // try to reserve on different machine
            for (int i = 0; i < missedCount; i++) {
                int index = findRandomDatanode(candidateNodes, totalCapacity);
                DatanodeInfo dinfo = candidateNodes.get(index);
                if (alreadyChosenHostSet.contains(dinfo.getHost())) {
                    int j;
                    for (j = (index + 1) % candidateNodes.size(); j != index; j = (j + 1)
                            % candidateNodes.size()) {
                        dinfo = candidateNodes.get(j);
                        if (!alreadyChosenHostSet.contains(dinfo.getHost())) {
                            break;
                        }
                    }
                    // can not reserve on different machine
                    if (j == index) {
                        break;
                    }
                }
                chosenTargets.add(dinfo);
                alreadyChosenHostSet.add(dinfo.getHost());
                alreadyChosenNodeSet.add(dinfo);
            }
        }
        missedCount = replicas - alreadyChosenNodeSet.size();
        if (missedCount > 0) {
            // try to find as many datanodes as possible.
            for (int i = 0; i < missedCount; i++) {
                int index = findRandomDatanode(candidateNodes, totalCapacity);
                DatanodeInfo dinfo = candidateNodes.get(index);
                if (alreadyChosenNodeSet.contains(dinfo)) {
                    int j;
                    for (j = (index + 1) % candidateNodes.size(); j != index; j = (j + 1)
                            % candidateNodes.size()) {
                        dinfo = candidateNodes.get(j);
                        if (!alreadyChosenNodeSet.contains(dinfo)) {
                            break;
                        }
                    }
                    // can not reserve on different disk
                    if (j == index) {
                        break;
                    }
                }
                chosenTargets.add(dinfo);
                alreadyChosenNodeSet.add(dinfo);
            }
        }
        if (chosenTargets.isEmpty()) {
            LOG.warning("Cannot find a single datanode with enough freespace to allocate a new block");
            throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                    "Cannot find a single datanode with "
                            + "enough freespace to allocate a new block");
        }
        // the data is transfered through datanode as a chain, the failure rate
        // will be boosted if we have too many datanode on the chain, so we 
        // limit the max datanode number on a chain. We will do replication
        // several times to fit the replication number.
        if (maxReplicationPerTime > 0
                && chosenTargets.size() > maxReplicationPerTime) {
            chosenTargets = chosenTargets.subList(0, maxReplicationPerTime);
        }
        // log the allocated datanodes.
        LOG.info("Allocated block " + block + " on " + chosenTargets + ".");
        for (DatanodeInfo dinfo: chosenTargets) {
            dinfo.reserve(block, expectedBlockSize);
        }
        return chosenTargets.toArray(new DatanodeInfo[0]);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DatanodeInfo[] calcToDeletedLocations(DatanodeInfo[] datanodes,
            int desiredReplication) {
        // TODO: now we just random select some node based on the name, change 
        // to delete node in the same segment.
        return super.calcToDeletedLocations(datanodes, desiredReplication);
    }

}
