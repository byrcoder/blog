/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 5, 2006
 */
package odis.dfs.common;

import java.io.IOException;

/**
 * Protocol that a datanode uses to talk to a namenode. This includes connection
 * opening, heartbeating and operation-finishing callbacks.
 * 
 * @author zf
 */
public interface IDataToNameProtocol {

    /**
     * Found a block inconsistent on a DataNode. Will schedule a consistency
     * check and try to recover.
     * 
     * @param block
     *            block the block to be checked
     * @param initiatingDataNode
     *            the DataNode that has found the block on it inconsistent
     * @param result
     *            the check result on that DataNode
     */
    void recoverInconsistentBlock(long block, String initiatingDataNode,
            BlockCheckResult result) throws IOException;

    /**
     * Report a block consistency check result to namenode.
     * 
     * @param block
     *            the block checked
     * @param datanode
     *            the datanode doing the check
     * @param result
     *            the check result
     * @throws IOException
     */
    void reportConsistencyCheckResult(long block, String datanodeFullName,
            BlockCheckResult result) throws IOException;

    /**
     * Open connection to the namenode and report all blocks I have, and also my
     * capacity and remaining bytes. Invariants (different from original NDFS),
     * <ol>
     * <li><code>capacity</code> should never change during a single run of the
     * datanode. thus datanode should somehow "reserve" space on the local disk.
     * Although in actual implementation, we can simply claim we have a certain
     * amount of capacity. If somebody else uses our space, we can block and
     * whine.</li>
     * <li>The <code>volume</code> is used to detect datanode belonged to other
     * cluster. If we found this datanode had a volume that is different from
     * the one we had, we will generate a {@link ShutdownCommand} to tell the
     * datanode that it should quit. If the volume is -1(means a new datanode),
     * we will generate a {@link AssignVolumeCommand} to tell the datanode set
     * its volume.</li>
     * <ol>
     */
    DataNodeCommand connect(String sender, BlockSize blocks[], long capacity,
            long remaining, long volume) throws IOException;

    /**
     * Tell namenode that I will quit.
     * 
     * @param sender
     * @throws IOException
     */
    void disconnect(String sender) throws IOException;

    /**
     * Report all blocks to namenode.
     * <p>
     * DataNode should do this call with a fixed interval(typically much larger
     * than heartbeat interval) after connect. This makes namenode fix
     * inconsistent data.
     * 
     * @param sender
     * @param blocks
     * @return
     * @throws IOException
     */
    void blockReport(String sender, BlockSize blocks[]) throws IOException;

    /**
     * SendHeartbeat tells the NameNode that the DataNode is still alive and
     * well.
     * 
     * @param remaining
     *            serves as a checksum of the block report. namenode will use
     *            this to verify that it has the same set of blocks on this
     *            datanode as the datanode thinks.
     */
    DataNodeCommand[] sendHeartbeat(String sender, long remaining,
            long[] metricsRecord) throws IOException;

    /**
     * A datanode that has received or deleted (or both) some blocks.
     * 
     * @param sender
     * @param received
     * @param deleted
     * @throws IOException
     */
    void reportBlockReceivedOrDeleted(String sender, BlockSize[] received,
            long[] deleted) throws IOException;

    /**
     * Callback when the datanode is finished with replication of a block.
     * 
     * @param lblock
     *            the block and actual locations it has been confirmed
     *            replicated to. If failed, lblock.locations will be empty
     */
    void replicationDone(String sender, BlockSizeLocationWithDataPath lblock)
            throws IOException;
}
