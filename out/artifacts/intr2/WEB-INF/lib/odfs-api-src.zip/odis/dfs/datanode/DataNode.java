/**
 * @(#)DataNode.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.management.MemoryUsage;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockCheckResult.Result;
import odis.dfs.common.BlockSize;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.DataNodeExpireException;
import odis.dfs.common.DataNodeRequest;
import odis.dfs.common.DataNodeRequest.Op;
import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.common.FSConstants;
import odis.dfs.common.IDataToNameProtocol;
import odis.dfs.common.IDataToNameProtocolMethods;
import odis.dfs.common.INameToDataProtocol;
import odis.dfs.common.ReplicateCommand;
import odis.dfs.metrics.DataNodeMetrics;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.io.ByteBufferOutputStream;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.InterruptibleSocket;
import odis.io.ReadWriteUtils;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.rpc2.UDPRpcServer;
import odis.util.DaemonTracker;
import odis.util.DiskUsage;
import odis.util.SystemInfoUtils;
import odis.util.ThreadLocalRandomData;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableInt;

import toolbox.collections.Pair;
import toolbox.collections.primitive.IntegerLongPair;
import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class DataNode extends Thread implements INameToDataProtocol,
        FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(DataNode.class);

    final DataNodeMetrics metrics = new DataNodeMetrics();

    private final File dir;

    final String fullName;

    private final int port;

    final ServerSocketChannel socket;

    final Semaphore diskReadGuard;

    final DataNodeManager dataNodeMgr;

    private final DataXceiveServer dataXceiveServer;

    private final ExecutorService workerPool;

    final FSDataSet dataSet;

    private final BlockTransferManager blockTransferMgr;

    final BlockReceivedAndDeletedReporter blockRceivedAndDeletedReporter;

    private final long heartbeatInterval;

    private final long blockReportInterval;

    private final long reservedSpace;

    final ConcurrentMap<Long, WriteBlockTask> writingBlocks = new ConcurrentHashMap<Long, WriteBlockTask>();

    final ConcurrentMap<Connection, Connection> conns = new ConcurrentHashMap<Connection, Connection>();

    final long writeChainTimeout;

    private final UDPRpcServer rpcServer;

    private long volume;

    public String getFullName() {
        return fullName;
    }

    public void assignVolume(long volume) throws IOException {
        if (this.volume != VOLUME_NA) {
            if (this.volume == volume) {
                return;
            }
            throw new IllegalStateException("Cannot assign volume "
                    + HexString.longToPaddedHex(volume)
                    + " because we already assigned a volume "
                    + HexString.longToPaddedHex(this.volume));
        }
        File volumeFile = new File(dir, DATANODE_VOLUME_FILE_NAME);
        byte[] buf = new byte[8];
        CDataOutputStream.writeLong(volume, buf, 0);
        FileOutputStream out = new FileOutputStream(volumeFile);
        try {
            out.write(buf);
            out.getFD().sync();
        } finally {
            ReadWriteUtils.safeClose(out);
        }
    }

    private long loadVolume() throws IOException {
        File volumeFile = new File(dir, DATANODE_VOLUME_FILE_NAME);
        if (!volumeFile.exists()) {
            return VOLUME_NA;
        }
        byte[] buf = new byte[8];
        FileInputStream in = new FileInputStream(volumeFile);
        try {
            CDataInputStream.readFully(buf, in);
        } finally {
            ReadWriteUtils.safeClose(in);
        }
        return CDataInputStream.readLong(buf, 0);
    }

    DataNode(Configuration conf, DataNodeManager dataNodeMgr, File dir,
            DataXceiveServer dataXceiveServer, int startPort, int index)
            throws IOException {
        super(dataNodeMgr.getHostName() + ":"
                + (startPort + DATANODE_DELTA_PORT_INCREASE * index) + ":"
                + dir.getAbsolutePath());
        setDaemon(true);
        this.dataNodeMgr = dataNodeMgr;
        this.dir = dir;
        this.dataXceiveServer = dataXceiveServer;
        this.port = startPort + DATANODE_DELTA_PORT_INCREASE * index;
        this.fullName = dataNodeMgr.getHostName() + ":" + port + ":"
                + dir.getAbsolutePath();
        LOG.info("DataNode[" + fullName + "] start initialize");

        this.dataSet = new FSDataSet(dir, metrics);
        DiskUsage du = new DiskUsage(dir.getAbsolutePath());
        this.reservedSpace = conf.getLong(DFSConfig.DATANODE_RESERVE + ".."
                + index, DFSConfig.DEFAULT_DATANODE_RESERVE);
        LOG.info("DataNode[" + fullName + "] raw capacity is " + du.getTotal()
                + ", reserving " + reservedSpace + " bytes");
        if (du.getTotal() <= reservedSpace) {
            throw new DataNodeFatalException("Got negative capacity "
                    + (du.getTotal() - reservedSpace) + " when starting "
                    + fullName);
        }
        this.heartbeatInterval = conf.getLong(
                DFSConfig.DATANODE_HEARTBEAT_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_HEARTBEAT_INTERVAL);
        this.blockReportInterval = conf.getLong(
                DFSConfig.DATANODE_BLOCK_REPORT_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_BLOCK_REPORT_INTERVAL);

        int coreSize = conf.getInt(DFSConfig.DATANODE_THREAD_POOL_CORE_SIZE,
                DFSConfig.DEFAULT_DATANODE_THREAD_POOL_CORE_SIZE);
        int maxSize = conf.getInt(DFSConfig.DATANODE_THREAD_POOL_MAX_SIZE,
                DFSConfig.DEFAULT_DATANODE_THREAD_POOL_MAX_SIZE);
        long keepAlive = conf.getLong(DFSConfig.DATANODE_THREAD_POOL_KEEPALIVE,
                DFSConfig.DEFAULT_DATANODE_THREAD_POOL_KEEPALIVE);
        int maxQueueSize = conf.getInt(
                DFSConfig.DATANODE_THREAD_POOL_MAX_QUEUE_SIZE,
                DFSConfig.DEFAULT_DATANODE_THREAD_POOL_MAX_QUEUE_SIZE);
        final long stackSize = conf.getLong(
                DFSConfig.DATANODE_THREAD_STACKSIZE,
                DFSConfig.DEFAULT_DATANODE_THREAD_STACKSIZE);
        this.workerPool = new ThreadPoolExecutor(coreSize, maxSize, keepAlive,
                TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(
                        maxQueueSize), new ThreadFactory() {

                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(null, r, "Idle-DataXceiver",
                                stackSize);
                        t.setDaemon(true);
                        return t;
                    }
                });
        this.volume = loadVolume();
        this.diskReadGuard = new Semaphore(conf.getInt(
                DFSConfig.DATANODE_DISK_READ_MAX_CONCURRENCY,
                DFSConfig.DEFAULT_DATANODE_DISK_READ_MAX_CONCURRENCY));
        this.writeChainTimeout = conf.getLong(
                DFSConfig.DATANODE_WRITE_CHAIN_TIMEOUT,
                DFSConfig.DEFAULT_DATANODE_WRITE_CHAIN_TIMEOUT);
        this.rpcServer = RPC.getUDPServer(INameToDataProtocol.class, this, port);
        this.socket = ServerSocketChannel.open();
        this.blockRceivedAndDeletedReporter = new BlockReceivedAndDeletedReporter(
                conf, this);
        this.blockTransferMgr = new BlockTransferManager(conf, this,
                dataXceiveServer.directByteBufferPool);
        LOG.info("DataNode[" + fullName + "] is started");
    }

    private void processCmds(DataNodeCommand[] cmds) {
        for (DataNodeCommand cmd: cmds) {
            try {
                cmd.execute(this);
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        fullName + " execute " + cmd + " failed", e);
            }
        }
    }

    public void scheduleBlockDeletion(final long[] blocks) {
        dataNodeMgr.asyncTaskPool.execute(new Runnable() {

            @Override
            public void run() {
                for (long block: blocks) {
                    if (dataSet.deleteBlock(block)) {
                        LOG.info(fullName + " delete block " + block);
                    } else {
                        LOG.info(fullName + " failed to delete block " + block);
                    }
                }
                blockRceivedAndDeletedReporter.blockDeleted(blocks);
            }
        });
    }

    public void scheduleBlockForceCompletion(final long[] blocks) {
        dataNodeMgr.asyncTaskPool.execute(new Runnable() {

            @Override
            public void run() {
                for (long block: blocks) {
                    WriteBlockTask task = writingBlocks.get(block);
                    if (task != null) {
                        LOG.info(fullName + " force complete block " + block);
                        task.forceComplete();
                    }
                }

            }
        });
    }

    public void scheduleBlockReplication(ReplicateCommand cmd) {
        blockTransferMgr.schedule(cmd);
    }

    private void checkBlockConsistency(long block) {
        BlockCheckResult result = dataSet.checkBlockConsistency(block);
        IDataToNameProtocol[] nameNodes = getNameNodes();
        for (IDataToNameProtocol nameNode: nameNodes) {
            try {
                RPC.asyncInvoke(
                        nameNode,
                        IDataToNameProtocolMethods.REPORT_CONSISTENCY_CHECK_RESULT,
                        block, fullName, result);
            } catch (Exception e) {
                LOG.log(Level.WARNING, fullName
                        + " report consitency check result for " + block
                        + " to " + nameNode + " failed", e);
            }
        }
    }

    public void scheduleBlockConsistencyCheck(final long[] blocks) {
        dataNodeMgr.asyncTaskPool.execute(new Runnable() {

            @Override
            public void run() {
                for (long block: blocks) {
                    checkBlockConsistency(block);
                }
            }
        });
    }

    public void scheduleChecksumWrite(final long block, final long checksum) {
        dataNodeMgr.asyncTaskPool.execute(new Runnable() {

            @Override
            public void run() {
                try {
                    dataSet.writeChecksum(block, checksum);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, fullName + " write checksum "
                            + HexString.intToPaddedHex((int) checksum)
                            + " for block " + block + " failed", e);
                }

            }
        });
    }

    @Override
    public void sendCommand(DataNodeCommand[] cmds) throws RpcException {
        processCmds(cmds);
    }

    static InetSocketAddress createSocketAddr(String target) {
        int colon = target.indexOf(':');
        int colon2 = target.indexOf(':', colon + 1);
        if (colon2 == -1) { // no data path
            return new InetSocketAddress(target.substring(0, colon),
                    Integer.parseInt(target.substring(colon + 1)));
        } else {
            return new InetSocketAddress(target.substring(0, colon),
                    Integer.parseInt(target.substring(colon + 1, colon2)));
        }
    }

    IDataToNameProtocol[] getNameNodes() {
        return dataNodeMgr.watcher.getNameNodes();
    }

    private final AtomicBoolean offlineCalled = new AtomicBoolean(false);

    void offline() {
        if (offlineCalled.compareAndSet(false, true)) {
            dataNodeMgr.asyncMarkOfflineDisks(dir.getAbsolutePath());
        }
    }

    void startService() throws IOException, InterruptedException {
        List<Pair<IDataToNameProtocol, Future<DataNodeCommand>>> futures = new ArrayList<Pair<IDataToNameProtocol, Future<DataNodeCommand>>>();
        BlockSize[] blocks = dataSet.getAllBlocks();
        DiskUsage du = new DiskUsage(dir.getAbsolutePath());
        long capacity = du.getTotal() - reservedSpace;
        long remaining = du.getFree() - reservedSpace;
        IDataToNameProtocol[] nameNodes = getNameNodes();
        for (IDataToNameProtocol nameNode: nameNodes) {
            try {
                futures.add(new Pair<IDataToNameProtocol, Future<DataNodeCommand>>(
                        nameNode, RPC.<DataNodeCommand>asyncInvoke(nameNode,
                                IDataToNameProtocolMethods.CONNECT, fullName,
                                blocks, capacity, remaining, volume)));
            } catch (RpcException e) {
                LOG.log(Level.WARNING, "connect to " + nameNode + " failed", e);
            }
        }
        if (futures.isEmpty()) {
            throw new IOException("Cannot connect to any namenodes");
        }
        boolean succ = false;
        for (Pair<IDataToNameProtocol, Future<DataNodeCommand>> future: futures) {
            try {
                DataNodeCommand cmd = future.getSecond().get();
                if (cmd != null) {
                    cmd.execute(this);
                }
                succ = true;
            } catch (ExecutionException e) {
                LOG.log(Level.WARNING, "connect to " + future.getFirst()
                        + " failed", e);
            }
        }
        if (!succ) {
            throw new IOException("Cannot connect to any namenodes");
        }
        socket.socket().bind(new InetSocketAddress(port));
        socket.configureBlocking(false);
        dataXceiveServer.register(this, false);
        rpcServer.start();
        blockRceivedAndDeletedReporter.start();
        blockTransferMgr.start();

        long currentTime = System.currentTimeMillis();
        ThreadLocalRandomData rand = ThreadLocalRandomData.current();
        nextHeartbeatTime = currentTime + rand.nextLong(heartbeatInterval);
        nextBlockReportTime = currentTime + rand.nextLong(blockReportInterval);
        start();
    }

    void recoverInconsistentBlock(long block, BlockCheckResult result) {
        IDataToNameProtocol[] nameNodes = getNameNodes();
        for (IDataToNameProtocol nameNode: nameNodes) {
            try {
                RPC.asyncInvoke(nameNode,
                        IDataToNameProtocolMethods.RECOVER_INCONSISTENT_BLOCK,
                        block, fullName, result);
            } catch (Exception e) {
                LOG.log(Level.WARNING, fullName
                        + " schedule block recover for " + block
                        + ", initial result=" + result + " failed", e);
            }
        }
    }

    int transferBlock(long srcBlock, long dstBlock, String[] targets,
            ReportCond reportCond, MutableInt blockLengthHolder, ByteBuffer bb)
            throws IOException {
        LOG.info("Transfering block " + srcBlock + " as " + dstBlock + " to "
                + Arrays.toString(targets));
        long startTime = System.currentTimeMillis();
        BlockInputStream in = dataSet.openBlock(srcBlock, 0);
        if (blockLengthHolder != null) {
            blockLengthHolder.setValue(in.getLen());
        }
        InterruptibleSocket mirrorSocket = null;
        try {
            mirrorSocket = new InterruptibleSocket(
                    createSocketAddr(targets[0]), writeChainTimeout,
                    dataXceiveServer.directByteBufferPool);
        } finally {
            if (mirrorSocket == null) {
                ReadWriteUtils.safeClose(in);
            }
        }
        int bytesTransferred = in.getRemaining();
        try {
            DataNodeRequest req = new DataNodeRequest(Op.WRITE_BLOCK);
            DataNodeRequest.WriteBlockBody reqBody = (DataNodeRequest.WriteBlockBody) req.getBody();
            reqBody.setBlock(dstBlock);
            reqBody.setTargets(targets);
            reqBody.setReportCond(reportCond);
            bb.clear();
            ByteBufferOutputStream byteOut = new ByteBufferOutputStream(bb);
            CDataOutputStream dataOut = new CDataOutputStream(byteOut);
            req.writeFields(dataOut);
            bb.putInt(in.getRemaining());
            bb.flip();
            mirrorSocket.write(bb);
            while (in.getRemaining() > 0) {
                bb.clear();
                in.read(bb);
                bb.flip();
                mirrorSocket.write(bb);
            }
            bb.position(0);
            bb.limit(12);
            bb.putInt(0, CHUNK_SIZE_END_OF_BLOCK);
            bb.putLong(4, in.getAdler32());
            mirrorSocket.write(bb);
            bb.position(0);
            bb.limit(1);
            if (mirrorSocket.read(bb) < 0) {
                throw new EOFException("Got EOF when read successCount from "
                        + targets[0]);
            }
            int successCount = bb.get(0) & 0xFF;
            LOG.info("Transmitted block " + srcBlock + " as " + dstBlock
                    + " to " + Arrays.toString(targets) + ", successCount is "
                    + successCount);
            return successCount;
        } catch (BlockChecksumMismatchException e) {
            recoverInconsistentBlock(srcBlock, new BlockCheckResult(
                    Result.MISMATCH, e.oc, e.cc));
            throw e;
        } finally {
            ReadWriteUtils.safeClose(mirrorSocket);
            ReadWriteUtils.safeClose(in);
            long delay = System.currentTimeMillis() - startTime;
            metrics.increment(DataNodeMetricsItem.REPLICATION_COUNT);
            metrics.add(DataNodeMetricsItem.REPLICATION_DELAY, delay);
            metrics.add(DataNodeMetricsItem.REPLICATION_BYTES, bytesTransferred);
        }
    }

    void executeTask(Runnable task) {
        workerPool.execute(task);
    }

    void fillMetricsRecords(long[] metricsRecords) {
        metricsRecords[DataNodeMetricsItem.SYSTEM_LOAD.offset()] = (long) (SystemInfoUtils.getLoad() * 100);
        metricsRecords[DataNodeMetricsItem.PROCESSOR_NUM.offset()] = SystemInfoUtils.getProcessors();
        MemoryUsage usage = SystemInfoUtils.getMemoryUsage();
        metricsRecords[DataNodeMetricsItem.HEAP_INIT.offset()] = usage.getInit();
        metricsRecords[DataNodeMetricsItem.HEAP_USED.offset()] = usage.getUsed();
        metricsRecords[DataNodeMetricsItem.HEAP_COMMITTED.offset()] = usage.getCommitted();
        metricsRecords[DataNodeMetricsItem.HEAP_MAX.offset()] = usage.getMax();
        usage = SystemInfoUtils.getNonHeapMemoryUsage();
        metricsRecords[DataNodeMetricsItem.NON_HEAP_INIT.offset()] = usage.getInit();
        metricsRecords[DataNodeMetricsItem.NON_HEAP_USED.offset()] = usage.getUsed();
        metricsRecords[DataNodeMetricsItem.NON_HEAP_COMMITTED.offset()] = usage.getCommitted();
        metricsRecords[DataNodeMetricsItem.NON_HEAP_MAX.offset()] = usage.getMax();
        IntegerLongPair blockNumberAndSize = dataSet.blockNumberAndSize();
        metricsRecords[DataNodeMetricsItem.BLOCK_NUM.offset()] = blockNumberAndSize.getFirst();
        metricsRecords[DataNodeMetricsItem.BLOCK_SIZE.offset()] = blockNumberAndSize.getSecond();
        metrics.fillMetricsRecords(metricsRecords);
    }

    private volatile boolean running = true;

    private long nextHeartbeatTime;

    private long nextBlockReportTime;

    private long[] metricsRecords = new long[DataNodeMetricsItem.totalItems()];

    private void sendHeartbeat(IDataToNameProtocol[] nameNodes)
            throws IOException, InterruptedException {
        DiskUsage du = new DiskUsage(dir.getAbsolutePath());
        long totalSpace = du.getTotal() - reservedSpace;
        long freeSpace = Math.min(totalSpace - dataSet.totalSize(),
                du.getFree());
        fillMetricsRecords(metricsRecords);
        List<Pair<IDataToNameProtocol, Future<DataNodeCommand[]>>> futures = new ArrayList<Pair<IDataToNameProtocol, Future<DataNodeCommand[]>>>();
        for (IDataToNameProtocol nameNode: nameNodes) {
            try {
                futures.add(new Pair<IDataToNameProtocol, Future<DataNodeCommand[]>>(
                        nameNode, RPC.<DataNodeCommand[]>asyncInvoke(nameNode,
                                IDataToNameProtocolMethods.SEND_HEARTBEAT,
                                fullName, freeSpace, metricsRecords)));
            } catch (RpcException e) {
                LOG.log(Level.WARNING, fullName + " send heartbeat to "
                        + nameNode + " failed", e);
            }
        }
        for (Pair<IDataToNameProtocol, Future<DataNodeCommand[]>> future: futures) {
            try {
                DataNodeCommand[] cmds = future.getSecond().get();
                processCmds(cmds);
            } catch (ExecutionException e) {
                if (e.getCause() instanceof DataNodeExpireException) {
                    LOG.log(Level.WARNING,
                            fullName + " got heartbeat expired from "
                                    + future.getFirst(), e);
                    DataNodeCommand cmd = future.getFirst().connect(fullName,
                            dataSet.getAllBlocks(), totalSpace, freeSpace,
                            volume);
                    if (cmd != null) {
                        cmd.execute(this);
                    }
                } else {
                    LOG.log(Level.WARNING, fullName
                            + " get heartbeat result from " + future.getFirst()
                            + " failed", e);
                }
            }
        }
    }

    private void blockReport(IDataToNameProtocol[] nameNodes) {
        BlockSize[] blocks = dataSet.getAllBlocks();
        for (IDataToNameProtocol nameNode: nameNodes) {
            try {
                RPC.asyncInvoke(nameNode,
                        IDataToNameProtocolMethods.BLOCK_REPORT, fullName,
                        blocks);
            } catch (RpcException e) {
                LOG.log(Level.WARNING, fullName + " send block report to "
                        + nameNode + " failed", e);
            }
        }
    }

    @Override
    public void run() {
        DaemonTracker tr = new DaemonTracker();
        while (running) {
            try {
                long currentTime = System.currentTimeMillis();
                long toWaitTime = Math.min(nextHeartbeatTime,
                        nextBlockReportTime) - currentTime;
                if (toWaitTime > 0) {
                    try {
                        Thread.sleep(toWaitTime);
                    } catch (InterruptedException e) {}
                    continue;
                }
                IDataToNameProtocol[] nameNodes = getNameNodes();
                if (currentTime >= nextHeartbeatTime) {
                    sendHeartbeat(nameNodes);
                    nextHeartbeatTime += heartbeatInterval;
                }
                if (currentTime >= nextBlockReportTime) {
                    blockReport(nameNodes);
                    nextBlockReportTime += blockReportInterval;
                }
            } catch (Exception e) {
                tr.gotThrowable(e);
            }
        }
    }

    void shutdown() throws InterruptedException {
        IDataToNameProtocol[] nameNodes = getNameNodes();
        for (IDataToNameProtocol nameNode: nameNodes) {
            try {
                RPC.asyncInvoke(nameNode,
                        IDataToNameProtocolMethods.DISCONNECT, fullName);
            } catch (Exception e) {
                LOG.log(Level.WARNING, fullName + " send disconnect failed", e);
            }
        }
        running = false;
        rpcServer.stop();
        blockRceivedAndDeletedReporter.shutdown();
        blockTransferMgr.shutdown();
        interrupt();
        dataXceiveServer.cancel(this, true);
        List<Connection> list = new ArrayList<Connection>(conns.keySet());
        for (Connection conn: list) {
            ReadWriteUtils.safeClose(conn);
        }
        for (WriteBlockTask task: writingBlocks.values()) {
            task.forceComplete();
        }
        blockRceivedAndDeletedReporter.awaitTermination();
        blockTransferMgr.awaitTermination();
        join();
    }
}
