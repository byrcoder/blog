/**
 * @(#)NameNodeMetricsItem.java, 2012-4-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

/**
 * NameNode metrics items.
 * 
 * @author zhangduo
 */
public enum NameNodeMetricsItem {
    SYSTEM_LOAD(0, "系统负载"),
    PROCESSOR_NUM(SYSTEM_LOAD.offset + 1, "CPU个数"),
    
    HEAP_INIT(PROCESSOR_NUM.offset + 1, "初始堆内存"),
    HEAP_USED(HEAP_INIT.offset + 1, "已用堆内存"),
    HEAP_COMMITTED(HEAP_USED.offset + 1, "提交堆内存"),
    HEAP_MAX(HEAP_COMMITTED.offset + 1, "最大堆内存"),
    
    NON_HEAP_INIT(HEAP_MAX.offset + 1, "初始非堆内存"),
    NON_HEAP_USED(NON_HEAP_INIT.offset + 1, "已用非堆内存"),
    NON_HEAP_COMMITTED(NON_HEAP_USED.offset + 1, "提交非堆内存"),
    NON_HEAP_MAX(NON_HEAP_COMMITTED.offset + 1, "最大非堆内存"),
    
    DIR_NUM(NON_HEAP_MAX.offset + 1, "目录总数"),
    FILE_NUM(DIR_NUM.offset + 1, "文件总数"),
    DISTINCT_FILE_NUM(FILE_NUM.offset + 1, "不包含link的文件总数"),
    FILE_SIZE(DISTINCT_FILE_NUM.offset + 1, "文件总大小"),
    DISTINCT_FILE_SIZE(FILE_SIZE.offset + 1, "不包含link的文件总大小"),

    GET_C_U_I_D_COUNT(DISTINCT_FILE_SIZE.offset + 1, "getCUID次数"),
    GET_C_U_I_D_DELAY(GET_C_U_I_D_COUNT.offset + 1, "getCUID时间"),

    SET_READY_COUNT(GET_C_U_I_D_DELAY.offset + 1, "setReady次数"),
    SET_READY_DELAY(SET_READY_COUNT.offset + 1, "setReady时间"),

    CONSISTENCY_CHECK_COUNT(SET_READY_DELAY.offset + 1, "consistencyCheck次数"),
    CONSISTENCY_CHECK_DELAY(CONSISTENCY_CHECK_COUNT.offset + 1, "consistencyCheck时间"),
    
    VERIFY_BLOCK_COUNT(CONSISTENCY_CHECK_DELAY.offset + 1, "verifyBlock次数"),
    VERIFY_BLOCK_DELAY(VERIFY_BLOCK_COUNT.offset + 1, "verifyBlock时间"),

    COMPUTE_CONTENTS_LENGTH_AND_SUB_ITEM_NUM_COUNT(VERIFY_BLOCK_DELAY.offset + 1, "计算文件数和长度次数"),
    COMPUTE_CONTENTS_LENGTH_AND_SUB_ITEM_NUM_DELAY(COMPUTE_CONTENTS_LENGTH_AND_SUB_ITEM_NUM_COUNT.offset + 1, "计算文件数和长度时间"),

    CREATE_COUNT(COMPUTE_CONTENTS_LENGTH_AND_SUB_ITEM_NUM_DELAY.offset + 1, "创建文件次数"),
    CREATE_DELAY(CREATE_COUNT.offset + 1, "创建文件时间"),

    ABANDON_BLOCK_COUNT(CREATE_DELAY.offset + 1, "丢弃数据块次数"),
    ABANDON_BLOCK_DELAY(ABANDON_BLOCK_COUNT.offset + 1, "丢弃数据块时间"),

    ADD_BLOCK_COUNT(ABANDON_BLOCK_DELAY.offset + 1, "追加数据块次数"),
    ADD_BLOCK_DELAY(ADD_BLOCK_COUNT.offset + 1, "追加数据块时间"),

    ABANDON_FILE_IN_PROGRESS_COUNT(ADD_BLOCK_DELAY.offset + 1, "丢弃文件次数"),
    ABANDON_FILE_IN_PROGRESS_DELAY(ABANDON_FILE_IN_PROGRESS_COUNT.offset + 1, "丢弃文件时间"),

    COMPLETE_COUNT(ABANDON_FILE_IN_PROGRESS_DELAY.offset + 1, "完成文件次数"),
    COMPLETE_DELAY(COMPLETE_COUNT.offset + 1, "完成文件时间"),
    
    DEPRIVE_COUNT(COMPLETE_DELAY.offset + 1, "强制丢弃文件次数"),
    DEPRIVE_DELAY(DEPRIVE_COUNT.offset + 1, "强制丢弃文件时间"),

    IS_PENDING_COUNT(DEPRIVE_DELAY.offset + 1, "判断文件是否待完成次数"),
    IS_PENDING_DELAY(IS_PENDING_COUNT.offset + 1, "判断文件是否待完成时间"),

    PENDING_FILES_IN_DIR_COUNT(IS_PENDING_DELAY.offset + 1, "获取待完成文件列表次数"),
    PENDING_FILES_IN_DIR_DELAY(PENDING_FILES_IN_DIR_COUNT.offset + 1, "获取待完成文件列表时间"),

    EXISTS_COUNT(PENDING_FILES_IN_DIR_DELAY.offset + 1, "判断文件/目录是否存在次数"),
    EXISTS_DELAY(EXISTS_COUNT.offset + 1, "判断文件/目录是否存在时间"),

    GET_FILE_BLOCK_LOCATIONS_COUNT(EXISTS_DELAY.offset + 1, "获取文件数据块信息次数"),
    GET_FILE_BLOCK_LOCATIONS_DELAY(GET_FILE_BLOCK_LOCATIONS_COUNT.offset + 1, "获取文件数据块信息时间"),

    GET_FILE_STATUS_COUNT(GET_FILE_BLOCK_LOCATIONS_DELAY.offset + 1, "获取文件/目录信息次数"),
    GET_FILE_STATUS_DELAY(GET_FILE_STATUS_COUNT.offset + 1, "获取文件/目录信息时间"),

    MKDIRS_COUNT(GET_FILE_STATUS_DELAY.offset + 1, "创建目录次数"),
    MKDIRS_DELAY(MKDIRS_COUNT.offset + 1, "创建目录时间"),

    GET_LISTING_COUNT(MKDIRS_DELAY.offset + 1, "列举目录子项次数"),
    GET_LISTING_DELAY(GET_LISTING_COUNT.offset + 1, "列举目录子项时间"),

    RENAME_COUNT(GET_LISTING_DELAY.offset + 1, "重命名文件/目录次数"),
    RENAME_DELAY(RENAME_COUNT.offset + 1, "重命名文件/目录时间"),

    SNAPSHOT_COUNT(RENAME_DELAY.offset + 1, "创建快照次数"),
    SNAPSHOT_DELAY(SNAPSHOT_COUNT.offset + 1, "创建快照时间"),

    DELETE_COUNT(SNAPSHOT_DELAY.offset + 1, "删除次数"),
    DELETE_DELAY(DELETE_COUNT.offset + 1, "删除时间"),

    RECOVER_TRASH_COUNT(DELETE_DELAY.offset + 1, "从回收站恢复次数"),
    RECOVER_TRASH_DELAY(RECOVER_TRASH_COUNT.offset + 1, "从回收站恢复时间"),

    DELETE_TRASH_COUNT(RECOVER_TRASH_DELAY.offset + 1, "从回收站删除次数"),
    DELETE_TRASH_DELAY(DELETE_TRASH_COUNT.offset + 1, "从回收站删除时间"),

    GET_REPLICATION_NUMBER_COUNT(DELETE_TRASH_DELAY.offset + 1, "获取文件/目录备份数次数"),
    GET_REPLICATION_NUMBER_DELAY(GET_REPLICATION_NUMBER_COUNT.offset + 1, "获取文件/目录备份数时间"),

    SET_REPLICATION_NUMBER_COUNT(GET_REPLICATION_NUMBER_DELAY.offset + 1, "设置文件/目录备份数次数"),
    SET_REPLICATION_NUMBER_DELAY(SET_REPLICATION_NUMBER_COUNT.offset + 1, "设置文件/目录备份数时间"),

    SET_OWNER_COUNT(SET_REPLICATION_NUMBER_DELAY.offset + 1, "设置文件/目录用户和组次数"),
    SET_OWNER_DELAY(SET_OWNER_COUNT.offset + 1, "设置文件/目录用户和组时间"),

    SET_PERMISSION_COUNT(SET_OWNER_DELAY.offset + 1, "设置文件/目录权限次数"),
    SET_PERMISSION_DELAY(SET_PERMISSION_COUNT.offset + 1, "设置文件/目录权限时间"),

    SET_PROTECT_COUNT(SET_PERMISSION_DELAY.offset + 1, "改变目录protect属性次数"),
    SET_PROTECT_DELAY(SET_PROTECT_COUNT.offset + 1, "改变目录protect属性时间"),

    IS_PROTECT_COUNT(SET_PROTECT_DELAY.offset + 1, "判断目录是否protect次数"),
    IS_PROTECT_DELAY(IS_PROTECT_COUNT.offset + 1, "判断目录是否protect时间"),

    SET_RECOVERABLE_COUNT(IS_PROTECT_DELAY.offset + 1, "改变目录recoverable属性次数"),
    SET_RECOVERABLE_DELAY(SET_RECOVERABLE_COUNT.offset + 1, "改变目录recoverable属性时间"),

    IS_RECOVERABLE_COUNT(SET_RECOVERABLE_DELAY.offset + 1, "判断目录是否recoverable次数"),
    IS_RECOVERABLE_DELAY(IS_RECOVERABLE_COUNT.offset + 1, "判断目录是否recoverable时间"),

    SET_SPACE_QUOTA_COUNT(IS_RECOVERABLE_DELAY.offset + 1, "设置空间配额次数"),
    SET_SPACE_QUOTA_DELAY(SET_SPACE_QUOTA_COUNT.offset + 1, "设置空间配额时间"),

    GET_SPACE_QUOTA_COUNT(SET_SPACE_QUOTA_DELAY.offset + 1, "获取空间配额次数"),
    GET_SPACE_QUOTA_DELAY(GET_SPACE_QUOTA_COUNT.offset + 1, "获取空间配额时间"),

    SET_NAME_QUOTA_COUNT(GET_SPACE_QUOTA_DELAY.offset + 1, "设置名字空间配额次数"),
    SET_NAME_QUOTA_DELAY(SET_NAME_QUOTA_COUNT.offset + 1, "设置名字空间配额时间"),

    GET_NAME_QUOTA_COUNT(SET_NAME_QUOTA_DELAY.offset + 1, "获取名字空间配额次数"),
    GET_NAME_QUOTA_DELAY(GET_NAME_QUOTA_COUNT.offset + 1, "获取名字空间配额时间"),

    PRINT_DIR_PROPERTIES_COUNT(GET_NAME_QUOTA_DELAY.offset + 1, "输出目录属性次数"),
    PRINT_DIR_PROPERTIES_DELAY(PRINT_DIR_PROPERTIES_COUNT.offset + 1, "输出目录属性时间"),

    ADD_GROUP_USER_COUNT(PRINT_DIR_PROPERTIES_DELAY.offset + 1, "增加用户组次数"),
    ADD_GROUP_USER_DELAY(ADD_GROUP_USER_COUNT.offset + 1, "增加用户组时间"),

    REMOVE_GROUP_USER_COUNT(ADD_GROUP_USER_DELAY.offset + 1, "删除组中用户次数"),
    REMOVE_GROUP_USER_DELAY(REMOVE_GROUP_USER_COUNT.offset + 1, "删除组中用户时间"),

    REMOVE_GROUP_COUNT(REMOVE_GROUP_USER_DELAY.offset + 1, "删除用户组次数"),
    REMOVE_GROUP_DELAY(REMOVE_GROUP_COUNT.offset + 1, "删除用户组时间"),

    PRINT_GROUPS_COUNT(REMOVE_GROUP_DELAY.offset + 1, "输出用户组信息次数"),
    PRINT_GROUPS_DELAY(PRINT_GROUPS_COUNT.offset + 1, "输出用户组信息时间"),

    GET_LEASE_PERIOD_COUNT(PRINT_GROUPS_DELAY.offset + 1, "获取租约过期时间次数"),
    GET_LEASE_PERIOD_DELAY(GET_LEASE_PERIOD_COUNT.offset + 1, "获取租约过期时间时间"),

    RENEW_LEASE_COUNT(GET_LEASE_PERIOD_DELAY.offset + 1, "更新租约次数"),
    RENEW_LEASE_DELAY(RENEW_LEASE_COUNT.offset + 1, "更新租约时间"),

    REMOVE_LEASE_COUNT(RENEW_LEASE_DELAY.offset + 1, "断开连接次数"),
    REMOVE_LEASE_DELAY(REMOVE_LEASE_COUNT.offset + 1, "断开连接时间"),

    OBTAIN_LOCK_COUNT(REMOVE_LEASE_DELAY.offset + 1, "obtainLock次数"),
    OBTAIN_LOCK_DELAY(OBTAIN_LOCK_COUNT.offset + 1, "obtainLock时间"),

    LOCK_STATE_COUNT(OBTAIN_LOCK_DELAY.offset + 1, "lockState次数"),
    LOCK_STATE_DELAY(LOCK_STATE_COUNT.offset + 1, "lockState时间"),

    PROMOTE_COUNT(LOCK_STATE_DELAY.offset + 1, "promote次数"),
    PROMOTE_DELAY(PROMOTE_COUNT.offset + 1, "promote时间"),

    DOWNGRADE_COUNT(PROMOTE_DELAY.offset + 1, "downgrade次数"),
    DOWNGRADE_DELAY(DOWNGRADE_COUNT.offset + 1, "downgrade时间"),

    RELEASE_LOCK_COUNT(DOWNGRADE_DELAY.offset + 1, "releaseLock次数"),
    RELEASE_LOCK_DELAY(RELEASE_LOCK_COUNT.offset + 1, "releaseLock时间"),

    RECOVER_INCONSISTENT_BLOCK_COUNT(RELEASE_LOCK_DELAY.offset + 1, "recoverInconsistentBlock次数"),
    RECOVER_INCONSISTENT_BLOCK_DELAY(RECOVER_INCONSISTENT_BLOCK_COUNT.offset + 1, "recoverInconsistentBlock时间"),

    REPORT_CONSISTENCY_CHECK_RESULT_COUNT(RECOVER_INCONSISTENT_BLOCK_DELAY.offset + 1, "reportConsistencyCheckResult次数"),
    REPORT_CONSISTENCY_CHECK_RESULT_DELAY(REPORT_CONSISTENCY_CHECK_RESULT_COUNT.offset + 1, "reportConsistencyCheckResult时间"),

    CONNECT_COUNT(REPORT_CONSISTENCY_CHECK_RESULT_DELAY.offset + 1, "datanode连接次数"),
    CONNECT_DELAY(CONNECT_COUNT.offset + 1, "datanode连接时间"),

    DISCONNECT_COUNT(CONNECT_DELAY.offset + 1, "datanode断开连接次数"),
    DISCONNECT_DELAY(DISCONNECT_COUNT.offset + 1, "datanode断开连接时间"),
    
    BLOCK_REPORT_COUNT(DISCONNECT_DELAY.offset + 1, "datanode汇报所有block次数"),
    BLOCK_REPORT_DELAY(BLOCK_REPORT_COUNT.offset + 1, "datanode汇报所有block时间"),

    SEND_HEARTBEAT_COUNT(BLOCK_REPORT_DELAY.offset + 1, "datanode心跳次数"),
    SEND_HEARTBEAT_DELAY(SEND_HEARTBEAT_COUNT.offset + 1, "datanode心跳时间"),

    REPORT_BLOCK_RECEIVED_OR_DELETED_COUNT(SEND_HEARTBEAT_DELAY.offset + 1, "datanode汇报新block次数"),
    REPORT_BLOCK_RECEIVED_OR_DELETED_DELAY(REPORT_BLOCK_RECEIVED_OR_DELETED_COUNT.offset + 1, "datanode汇报新block时间"),

    REPLICATION_DONE_COUNT(REPORT_BLOCK_RECEIVED_OR_DELETED_DELAY.offset + 1, "datanode完成复制次数"),
    REPLICATION_DONE_DELAY(REPLICATION_DONE_COUNT.offset + 1, "datanode完成复制时间"),
    
    REQUEST_NUM(REPLICATION_DONE_DELAY.offset + 1, "总请求次数");
    
    private final int offset;
    
    private final String printName;

    private NameNodeMetricsItem(int offset, String printName) {
        this.offset = offset;
        this.printName = printName;
    }

    public int offset() {
        return offset;
    }
    
    public String getPrintName() {
        return printName;
    }

    public static int systemInfoItems() {
        return DISTINCT_FILE_SIZE.offset + 1;
    }

    public static int totalItems() {
        return REQUEST_NUM.offset + 1;
    }
}
