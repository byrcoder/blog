/**
 * @(#)DFSFileStatus.java, 2012-2-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.permission.FsPermission;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * Interface that represents the over the wire information for a file on odfs.
 * <p>
 * The contentsLength of directory is the sum of all its sub files
 * contentsLength.<br>
 * The refCount for directory is zero.<br>
 * The subDirNumber and subFileNumber for file is always zero.
 * 
 * @author zhangduo
 */
public class DFSFileStatus implements IWritable {

    private String path;

    private String symlink;

    private long contentsLength;

    private int refCount;

    private boolean isDir;

    private int replication;

    private long lastModified;

    private long lastAccess;

    private FsPermission permission;

    private String owner;

    private String group;

    private long subDirNumber;

    private long subFileNumber;

    public DFSFileStatus() {}

    public DFSFileStatus(String path, String symlink, long contentsLength,
            boolean isDir, int refCount, int replication, long lastModified,
            long lastAccess, FsPermission permission, String owner,
            String group, long subDirNumber, long subFileNumber) {
        this.path = path;
        this.symlink = symlink;
        this.contentsLength = contentsLength;
        this.isDir = isDir;
        this.refCount = refCount;
        this.replication = replication;
        this.lastModified = lastModified;
        this.lastAccess = lastAccess;
        this.permission = permission;
        this.owner = owner;
        this.group = group;
        this.subDirNumber = subDirNumber;
        this.subFileNumber = subFileNumber;
    }

    public String getPath() {
        return path;
    }

    public String getName() {
        return path.length() == 1 ? "/"
                : path.substring(path.lastIndexOf('/') + 1);
    }

    public boolean isSymlink() {
        return symlink != null;
    }

    public String getTarget() {
        return symlink;
    }

    public long getContentsLength() {
        return contentsLength;
    }

    public boolean isDir() {
        return isDir;
    }

    public int getRefCount() {
        return refCount;
    }

    public int getReplication() {
        return replication;
    }

    public long getLastModified() {
        return lastModified;
    }

    public long getLastAccess() {
        return lastAccess;
    }

    public FsPermission getPermission() {
        return permission;
    }

    public String getOwner() {
        return owner;
    }

    public String getGroup() {
        return group;
    }

    public long getSubDirNumber() {
        return subDirNumber;
    }

    public long getSubFileNumber() {
        return subFileNumber;
    }

    @Override
    public IWritable copyFields(IWritable value) {
        DFSFileStatus that = (DFSFileStatus) value;
        path = that.path;
        symlink = that.symlink;
        contentsLength = that.contentsLength;
        isDir = that.isDir;
        refCount = that.refCount;
        replication = that.replication;
        lastModified = that.lastModified;
        lastAccess = that.lastAccess;
        if (that.permission == null) {
            permission = null;
        } else {
            if (permission == null) {
                permission = new FsPermission();
            }
            permission.copyFields(that.permission);
        }
        owner = that.owner;
        group = that.group;
        subDirNumber = that.subDirNumber;
        subFileNumber = that.subFileNumber;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, path);
        CDataOutputStream.writeVLong(contentsLength, out);
        out.writeBoolean(isDir);
        CDataOutputStream.writeVInt(refCount, out);
        CDataOutputStream.writeVInt(replication, out);
        CDataOutputStream.writeVLong(lastModified, out);
        CDataOutputStream.writeVLong(lastAccess, out);
        permission.writeFields(out);
        StringWritable.writeString(out, owner);
        StringWritable.writeString(out, group);
        CDataOutputStream.writeVLong(subDirNumber, out);
        CDataOutputStream.writeVLong(subFileNumber, out);
        StringWritable.writeStringNull(out, symlink);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        path = StringWritable.readString(in);
        contentsLength = CDataInputStream.readVLong(in);
        isDir = in.readBoolean();
        refCount = CDataInputStream.readVInt(in);
        replication = CDataInputStream.readVInt(in);
        lastModified = CDataInputStream.readVLong(in);
        lastAccess = CDataInputStream.readVLong(in);
        permission = new FsPermission();
        permission.readFields(in);
        owner = StringWritable.readString(in);
        group = StringWritable.readString(in);
        subDirNumber = CDataInputStream.readVLong(in);
        subFileNumber = CDataInputStream.readVLong(in);
        symlink = StringWritable.readStringNull(in);
    }

    @Override
    public String toString() {
        return "[DFSFileStatus path=" + path + ", symlink=" + symlink
                + ", contentsLength=" + contentsLength + ", refCount="
                + refCount + ", isDir=" + isDir + ", replication="
                + replication + ", lastModified=" + lastModified
                + ", lastAccess=" + lastAccess + ", permission=" + permission
                + ", owner=" + owner + ", group=" + group + ", subDirNumber="
                + subDirNumber + ", subFileNumber=" + subFileNumber + "]";
    }

}
