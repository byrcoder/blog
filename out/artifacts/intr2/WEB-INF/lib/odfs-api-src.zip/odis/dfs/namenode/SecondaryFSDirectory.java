/**
 * @(#)SecondaryFSDirectory.java, 2012-12-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import odis.dfs.common.DFSConfig;
import odis.io.permission.FsPermission;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableLong;

/**
 * @author zhangduo
 */
class SecondaryFSDirectory extends AbstractFSDirectory<SecondaryFSBlockStore> {

    SecondaryFSDirectory(Configuration conf, SecondaryFSBlockStore bstore,
            File imageFile, Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks,
            MutableLong maxLoadedLogSN) throws IOException {
        super(bstore, imageFile, new FsPermission(conf.getInt(
                DFSConfig.NAMENODE_DEFAULT_PERMISSION,
                DFSConfig.DEFAULT_NAMENODE_DEFAULT_PERMISSION)),
                conf.getString(DFSConfig.NAMENODE_DEFAULT_GROUP,
                        DFSConfig.DEFAULT_NAMENODE_DEFAULT_GROUP),
                conf.getString(DFSConfig.NAMENODE_ADMIN,
                        DFSConfig.DEFAULT_NAMENODE_ADMIN), pendingCreates,
                pendingCreateLastBlocks, maxLoadedLogSN);
    }
}
