/**
 * @(#)RandomReadBlockTask.java, 2012-12-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.datanode.Connection.ICallback;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.util.DfsUtils;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class RandomReadBlockTask implements Runnable {

    private static final Logger LOG = LogFormatter.getLogger(RandomReadBlockTask.class);

    private final Connection conn;

    private final File blockFile;

    private final ByteBuffer bb;

    private final int len;

    private boolean initialized = false;

    private FileInputStream in;

    private FileChannel channel;

    private long startTime;

    private int off;

    private int bytesSent;

    RandomReadBlockTask(Connection conn, File blockFile, int off, int len,
            ByteBuffer bb) {
        this.conn = conn;
        this.blockFile = blockFile;
        this.off = off;
        this.len = len;
        this.bb = bb;
    }

    private void finishMetrics() {
        long delay = System.currentTimeMillis() - startTime;
        conn.dataNode.metrics.increment(DataNodeMetricsItem.RANDOM_READ_COUNT);
        conn.dataNode.metrics.add(DataNodeMetricsItem.RANDOM_READ_BYTES,
                bytesSent);
        conn.dataNode.metrics.add(DataNodeMetricsItem.RANDOM_READ_DELAY, delay);
        conn.dataNode.metrics.decrement(DataNodeMetricsItem.CONCURRENT_READ);
    }

    private void cleanUpWithoutCloseConn() {
        finishMetrics();
        ReadWriteUtils.safeClose(channel);
        ReadWriteUtils.safeClose(in);
    }

    private void cleanUp() {
        cleanUpWithoutCloseConn();
        ReadWriteUtils.safeClose(conn);
        Thread.currentThread().setName("Idle-DataXceiver");
    }

    @Override
    public void run() {
        Thread.currentThread().setName(
                "RRB-" + conn.dataNode.getFullName() + "-"
                        + DfsUtils.blockFile2BlockId(blockFile) + "-"
                        + conn.socket.socket().getRemoteSocketAddress());
        if (!initialized) {
            try {
                initialized = true;
                startTime = System.currentTimeMillis();
                conn.dataNode.metrics.increment(DataNodeMetricsItem.CONCURRENT_READ);
                bb.clear();
                bb.putInt(len);
                bb.flip();
                for (int i = 0; bb.hasRemaining()
                        && i < Connection.WRITE_MAX_SPINS; i++) {
                    conn.socket.write(bb);
                }
                if (bb.hasRemaining()) {
                    conn.asyncWrite(bb, new ICallback() {

                        @Override
                        public void operationSucceeded() {
                            conn.directByteBufferPool.release(bb);
                            conn.dataNode.executeTask(RandomReadBlockTask.this);
                        }

                        @Override
                        public void operationFailed() {
                            conn.directByteBufferPool.release(bb);
                            cleanUpWithoutCloseConn();
                        }
                    });
                    Thread.currentThread().setName("Idle-DataXceiver");
                    return;
                } else {
                    conn.directByteBufferPool.release(bb);
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        conn.remoteAddr() + " read "
                                + blockFile.getAbsolutePath()
                                + " send length failed", e);
                conn.directByteBufferPool.release(bb);
                cleanUp();
                return;
            }
        }

        try {
            if (in == null) {
                in = new FileInputStream(blockFile);
                channel = in.getChannel();
            }
            for (int i = 0; bytesSent < len && i < Connection.WRITE_MAX_SPINS; i++) {
                int transferred = (int) channel.transferTo(off,
                        len - bytesSent, conn.socket);
                if (transferred != 0) {
                    off += transferred;
                    bytesSent += transferred;
                } else {
                    // check whether we have a partial file
                    if (channel.size() < off - bytesSent + len) {
                        throw new EOFException("Unexpected EOF, expected "
                                + (len - bytesSent) + " bytes remaining");
                    }
                }
            }
            if (bytesSent < len) {
                conn.asyncWrite(null, new ICallback() {

                    @Override
                    public void operationSucceeded() {
                        conn.dataNode.executeTask(RandomReadBlockTask.this);
                    }

                    @Override
                    public void operationFailed() {
                        cleanUpWithoutCloseConn();
                    }
                });
                Thread.currentThread().setName("Idle-DataXceiver");
                return;
            }
            cleanUpWithoutCloseConn();
            Thread.currentThread().setName("Idle-DataXceiver");
        } catch (Exception e) {
            LOG.log(Level.WARNING,
                    conn.remoteAddr() + " read " + blockFile.getAbsolutePath()
                            + " failed", e);
            cleanUp();
        }

    }
}
