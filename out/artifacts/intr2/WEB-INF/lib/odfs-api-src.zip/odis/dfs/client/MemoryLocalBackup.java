/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar, 2006
 */
package odis.dfs.client;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import odis.dfs.common.DFSClientConfig;
import odis.io.DirectByteArrayOutputStream;

/**
 * Memory based backup implementation.
 * 
 * @author river
 */
public class MemoryLocalBackup implements LocalBackup {
    private static final long INITIAL_SIZE = DFSClientConfig.DEFAULT_BLOCK_SIZE_DEFAULT_VALUE;

    private DirectByteArrayOutputStream os = new DirectByteArrayOutputStream(
            (int) INITIAL_SIZE);

    public OutputStream getOutputStream() throws IOException {
        return os;
    }

    public InputStream getInputStream() throws IOException {
        return new ByteArrayInputStream(os.getBuffer(), 0, os.size());
    }

    public void discard() throws IOException {
        os.reset();
    }

}
