/**
 * @(#)AbstractPrimaryFSDirectory.java, 2013-2-10. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.mutable.MutableLong;

import odis.dfs.namenode.ActiveFSDirectory.DirectoryStatInfo;
import odis.io.permission.FsPermission;

/**
 * @author zhangduo
 */
abstract class AbstractPrimaryFSDirectory<FBS extends AbstractPrimaryFSBlockStore>
        extends AbstractFSDirectory<FBS> {
    protected final ReadWriteLock nodeTreeLock = new ReentrantReadWriteLock();

    protected AbstractPrimaryFSDirectory(FBS bstore, File imageFile,
            FsPermission defaultPermission, String defaultGroup, String admin,
            Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks, 
            MutableLong maxLoadedLogSN) throws IOException {
        super(bstore, imageFile, defaultPermission, defaultGroup, admin,
                pendingCreates, pendingCreateLastBlocks, maxLoadedLogSN);
    }

    protected AbstractPrimaryFSDirectory(FBS bstore,
            FsPermission defaultPermission, String defaultGroup, String admin,
            DirectoryINode rootDir, FSDirPropertyManager fsDirPropMgr,
            UserGroupManager ugMgr, FsPermissionChecker permissionChecker) {
        super(bstore, defaultPermission, defaultGroup, admin, rootDir,
                fsDirPropMgr, ugMgr, permissionChecker);
    }

    DirectoryStatInfo getStatInfo() {
        nodeTreeLock.readLock().lock();
        try {
            return new DirectoryStatInfo(rootDir.getSubDirNum(),
                    rootDir.getSubFileNum(), distinctFileNum,
                    rootDir.getContentsLength(), distinctFileSize);
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }

    INodeInfo getINodeInfo(String path) {
        nodeTreeLock.readLock().lock();
        try {
            INode node = unprotectedGetNode(path);
            if (node == null) {
                return null;
            }
            return INodeInfo.create(node, ugMgr);
        } finally {
            nodeTreeLock.readLock().unlock();
        }
    }
}
