/**
 * @(#)ReserveByCapacityPolicy.java, 2012-4-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSException;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class ReserveByCapacityPolicy extends AbstractReserveByCapacityPolicy {
    private static final Logger LOG = LogFormatter.getLogger(ReserveByCapacityPolicy.class);

    public ReserveByCapacityPolicy(Configuration conf) {
        super(conf.getInt(DFSConfig.MAX_REPLICATION_PER_TIME,
                DFSConfig.DEFAULT_MAX_REPLICATION_PER_TIME));
    }

    @Override
    public DatanodeInfo[] chooseTargets(String srcHost, long block,
            int replicas, DatanodeInfo[] alreadyChosenNodes,
            int expectedBlockSize) throws FSException {
        List<DatanodeInfo> candidateNodes;
        long totalCapacity = 0;
        synchronized (datanodes) {
            candidateNodes = new ArrayList<DatanodeInfo>(datanodes.size());
            for (DatanodeInfo dinfo: datanodes) {
                if (dinfo.getRemaining() - dinfo.getReserved() > expectedBlockSize) {
                    totalCapacity += dinfo.getCapacity();
                    candidateNodes.add(dinfo);
                }
            }
        }
        if (totalCapacity == 0) {
            LOG.warning("Cannot find a single datanode with "
                    + "enough freespace to allocate a new block");
            throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                    "Cannot find a single datanode with "
                            + "enough freespace to allocate a new block");
        }
        Set<DatanodeInfo> alreadyChosenNodeSet = new HashSet<DatanodeInfo>();
        Set<String> alreadyChosenHostSet = new HashSet<String>();
        if (alreadyChosenNodes != null) {
            for (DatanodeInfo alreadyChosenNode: alreadyChosenNodes) {
                alreadyChosenNodeSet.add(alreadyChosenNode);
                alreadyChosenHostSet.add(alreadyChosenNode.getHost());
            }
        }
        List<DatanodeInfo> chosenTargets = new ArrayList<DatanodeInfo>(replicas
                - alreadyChosenNodeSet.size());
        // reserve on different machine
        for (int i = 0, n = replicas - alreadyChosenNodeSet.size(); i < n; i++) {
            int index = findRandomDatanode(candidateNodes, totalCapacity);
            DatanodeInfo dinfo = candidateNodes.get(index);
            if (alreadyChosenHostSet.contains(dinfo.getHost())) {
                int j;
                for (j = (index + 1) % candidateNodes.size(); j != index; j = (j + 1)
                        % candidateNodes.size()) {
                    dinfo = candidateNodes.get(j);
                    if (!alreadyChosenHostSet.contains(dinfo.getHost())) {
                        break;
                    }
                }
                // can not reserve on different machine
                if (j == index) {
                    break;
                }
            }
            chosenTargets.add(dinfo);
            alreadyChosenHostSet.add(dinfo.getHost());
            alreadyChosenNodeSet.add(dinfo);
        }
        int missedCount = replicas - alreadyChosenNodeSet.size();
        if (missedCount > 0) {
            // try to find as many datanodes as possible
            for (int i = 0; i < missedCount; i++) {
                int index = findRandomDatanode(candidateNodes, totalCapacity);
                DatanodeInfo dinfo = candidateNodes.get(index);
                if (alreadyChosenNodeSet.contains(dinfo)) {
                    int j;
                    for (j = (index + 1) % candidateNodes.size(); j != index; j = (j + 1)
                            % candidateNodes.size()) {
                        dinfo = candidateNodes.get(j);
                        if (!alreadyChosenNodeSet.contains(dinfo)) {
                            break;
                        }
                    }
                    // can not reserve on different disk
                    if (j == index) {
                        break;
                    }
                }
                chosenTargets.add(dinfo);
                alreadyChosenNodeSet.add(dinfo);
            }
        }
        if (chosenTargets.isEmpty()) {
            LOG.warning("Cannot find a single datanode with enough freespace to allocate a new block");
            throw new FSException(FSException.NOT_ENOUGH_RESOURCE,
                    "Cannot find a single datanode with "
                            + "enough freespace to allocate a new block");
        }
        // the data is transfered through datanode as a chain, the failure rate
        // will be boosted if we have too many datanode on the chain, so we 
        // limit the max datanode number on a chain. We will do replication
        // several times to fit the replication number.
        if (maxReplicationPerTime > 0
                && chosenTargets.size() > maxReplicationPerTime) {
            chosenTargets = chosenTargets.subList(0, maxReplicationPerTime);
        }
        // log the allocated datanodes.
        LOG.info("Allocated block " + block + " on " + chosenTargets + ".");
        for (DatanodeInfo dinfo: chosenTargets) {
            dinfo.reserve(block, expectedBlockSize);
        }
        return chosenTargets.toArray(new DatanodeInfo[0]);
    }
}
