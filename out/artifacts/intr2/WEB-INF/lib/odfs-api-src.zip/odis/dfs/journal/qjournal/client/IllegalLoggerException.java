package odis.dfs.journal.qjournal.client;

import java.io.IOException;

public class IllegalLoggerException extends IOException {

    private static final long serialVersionUID = 536409481680081627L;

    public IllegalLoggerException() {
        super();
    }

    public IllegalLoggerException(String message, Throwable cause) {
        super(message, cause);
    }

    public IllegalLoggerException(String message) {
        super(message);
    }

    public IllegalLoggerException(Throwable cause) {
        super(cause);
    }
}
