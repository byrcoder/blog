/**
 * @(#)AbstractFSEditLogger.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

import odis.dfs.journal.JournalManager;
import odis.io.ReadWriteUtils;

/**
 * @author zhangduo
 */
abstract class AbstractFSEditLogger implements Closeable {

    protected static final int OP_CREATE = 0;

    protected static final int OP_APPEND_BLOCK = OP_CREATE + 1;

    protected static final int OP_ABANDON_BLOCK = OP_APPEND_BLOCK + 1;

    protected static final int OP_COMPLETE = OP_ABANDON_BLOCK + 1;

    protected static final int OP_ABANDON = OP_COMPLETE + 1;

    protected static final int OP_FORCE_COMPLETE = OP_ABANDON + 1;

    protected static final int OP_DEPRIVE = OP_FORCE_COMPLETE + 1;

    protected static final int OP_RENAME = OP_DEPRIVE + 1;

    protected static final int OP_DELETE = OP_RENAME + 1;

    protected static final int OP_TRASH = OP_DELETE + 1;

    protected static final int OP_MKDIR = OP_TRASH + 1;

    protected static final int OP_SNAPSHOT = OP_MKDIR + 1;

    protected static final int OP_REPLICATE = OP_SNAPSHOT + 1;

    protected static final int OP_CHOWN = OP_REPLICATE + 1;

    protected static final int OP_CHMOD = OP_CHOWN + 1;

    protected static final int OP_ADD_GROUP_USER = OP_CHMOD + 1;

    protected static final int OP_REMOVE_GROUP_USER = OP_ADD_GROUP_USER + 1;

    protected static final int OP_REMOVE_GROUP = OP_REMOVE_GROUP_USER + 1;

    protected static final int OP_SET_SPACE_QUOTA = OP_REMOVE_GROUP + 1;

    protected static final int OP_SET_NAME_QUOTA = OP_SET_SPACE_QUOTA + 1;

    protected static final int OP_SET_PROTECT = OP_SET_NAME_QUOTA + 1;

    protected static final int OP_SET_RECOVERABLE = OP_SET_PROTECT + 1;

    protected final JournalManager journalMgr;

    protected AbstractFSEditLogger(JournalManager journalMgr) {
        this.journalMgr = journalMgr;
    }

    InputStream openFSEditLog(long sn) throws IOException {
        return journalMgr.openFinalizedSegment(sn);
    }

    long maxFinalizedSegmentSN() throws IOException {
        return journalMgr.maxFinalizedSegmentSN();
    }

    @Override
    public void close() {
        ReadWriteUtils.safeClose(journalMgr);
    }

}
