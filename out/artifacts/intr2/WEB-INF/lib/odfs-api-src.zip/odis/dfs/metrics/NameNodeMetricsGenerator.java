/**
 * @(#)NameNodeMetricsGenerator.java, 2012-4-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import com.thoughtworks.qdox.JavaDocBuilder;
import com.thoughtworks.qdox.model.JavaClass;
import com.thoughtworks.qdox.model.JavaMethod;

/**
 * @author zhangduo
 */
public class NameNodeMetricsGenerator {

    private static void generateEnum() throws IOException {
        PrintWriter pw = new PrintWriter(new FileOutputStream(
                "NameNodeMetricsItems.template"));

        pw.println("    DIR_NUM(0),");
        pw.println("    FILE_NUM(DIR_NUM.offset + 1),");
        pw.println("    DISTINCT_FILE_NUM(FILE_NUM.offset + 1),");
        pw.println("    FILE_SIZE(DISTINCT_FILE_NUM.offset + 1),");
        pw.println("    DISTINCT_FILE_SIZE(FILE_SIZE.offset + 1),");
        String prevName = "DISTINCT_FILE_SIZE";
        JavaDocBuilder builder = new JavaDocBuilder();
        builder.addSource(new File(
                "src/java/odis/dfs/common/IClientProtocolV3.java"));
        builder.addSource(new File(
                "src/java/odis/dfs/common/IDataToNameProtocol.java"));
        for (JavaClass clz: builder.getClasses()) {
            for (JavaMethod method: clz.getMethods()) {
                pw.println();
                String methodName = method.getName();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < methodName.length(); i++) {
                    char c = methodName.charAt(i);
                    if (Character.isUpperCase(c)) {
                        sb.append('_');
                    }
                    sb.append(Character.toUpperCase(c));
                }
                String enumName = sb.toString();

                String countName = enumName + "_COUNT";
                String delayName = enumName + "_DELAY";
                pw.println("    " + countName + "(" + prevName
                        + ".offset + 1),");
                pw.println("    " + delayName + "(" + countName
                        + ".offset + 1),");
                prevName = delayName;
            }
        }
        pw.close();

    }

    public static void main(String[] args) throws Exception {
        generateEnum();
    }
}
