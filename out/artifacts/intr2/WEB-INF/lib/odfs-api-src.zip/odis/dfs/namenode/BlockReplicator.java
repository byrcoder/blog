/**
 * @(#)BlockReplicator.java, 2011-12-24. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSException;
import odis.util.DaemonTracker;

import org.apache.commons.configuration.Configuration;

import toolbox.collections.primitive.LongArrayList;
import toolbox.collections.primitive.LongCompactHashSet;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class BlockReplicator extends Thread {

    private static final Logger LOG = LogFormatter.getLogger(BlockReplicator.class);

    private final ActiveFSBlockStore bstore;

    private final LongCompactHashSet blocksWithOneReplicas = new LongCompactHashSet();

    private final LongCompactHashSet blocksWithTwoReplicas = new LongCompactHashSet();

    private final LongCompactHashSet blocksWithThreeOrMoreReplicas = new LongCompactHashSet();

    private final long replicationMaxPeriod;

    private final long replicationScheduleInterval;

    private final int replicationMinDataNode;

    static final class ReplicationEntry {
        final long scheduledTime;

        final String src;

        final String[] targets;

        public ReplicationEntry(long scheduledTime, String src, String[] targets) {
            this.scheduledTime = scheduledTime;
            this.src = src;
            this.targets = targets;
        }

        @Override
        public String toString() {
            return "[ReplicationEntry scheduledTime=" + scheduledTime
                    + ", src=" + src + ", targets=" + Arrays.toString(targets)
                    + "]";
        }

    }

    private final Map<Long, ReplicationEntry> replicating = new LinkedHashMap<Long, ReplicationEntry>();

    private volatile boolean closed = false;

    BlockReplicator(ActiveFSBlockStore bstore, Configuration conf) {
        super("Replicator");
        setDaemon(true);
        this.bstore = bstore;
        this.replicationMaxPeriod = conf.getLong(
                DFSConfig.REPLICATION_PERIOD_MAX,
                DFSConfig.DEFAULT_REPLICATION_PERIOD_MAX);
        this.replicationScheduleInterval = conf.getLong(
                DFSConfig.REPLICATION_SCHEDULE_INTERVAL,
                DFSConfig.DEFAULT_REPLICATION_SCHEDULE_INTERVAL);
        this.replicationMinDataNode = conf.getInt(
                DFSConfig.REPLICATION_MIN_DATANODE,
                DFSConfig.DEFAULT_REPLICATION_MIN_DATANODE);
    }

    synchronized void requestReplication(long block, int currentReplicas) {
        if (replicating.containsKey(block)) {
            return;
        }
        blocksWithOneReplicas.remove(block);
        blocksWithTwoReplicas.remove(block);
        blocksWithThreeOrMoreReplicas.remove(block);
        if (currentReplicas <= 1) {
            blocksWithOneReplicas.add(block);
        } else if (currentReplicas == 2) {
            blocksWithTwoReplicas.add(block);
        } else {
            blocksWithThreeOrMoreReplicas.add(block);
        }
    }

    synchronized void datanodeDied(DatanodeInfo dinfo) {
        for (Iterator<Map.Entry<Long, ReplicationEntry>> iter = replicating.entrySet().iterator(); iter.hasNext();) {
            Map.Entry<Long, ReplicationEntry> entry = iter.next();
            if (entry.getValue().src.equals(dinfo.getName())) {
                iter.remove();
                bstore.forceCompleteBlock(entry.getKey(),
                        entry.getValue().targets);
            }
        }
    }

    synchronized void cancelReplication(long block) {
        if (blocksWithOneReplicas.remove(block)) {
            return;
        }
        if (blocksWithTwoReplicas.remove(block)) {
            return;
        }
        blocksWithThreeOrMoreReplicas.remove(block);
    }

    synchronized long getToReplicateSize() {
        return (long) blocksWithOneReplicas.size()
                + blocksWithTwoReplicas.size()
                + blocksWithThreeOrMoreReplicas.size();
    }

    synchronized int getReplicatingSize() {
        return replicating.size();
    }

    synchronized void replicationDone(long block) {
        replicating.remove(block);
    }

    synchronized boolean isRelicating(long block) {
        return replicating.containsKey(block);
    }

    private void drainTo(LongArrayList list, int capacity,
            LongCompactHashSet blockSet) {
        int currentSize = list.size();
        for (long block: blockSet) {
            if (list.size() == capacity) {
                for (int i = currentSize; i < capacity; i++) {
                    blockSet.remove(list.get(i));
                }
                return;
            }
            list.add(block);
        }
        blockSet.clear();
    }

    /**
     * Always get all the <code>blocksWithOneReplicas</code>. If we found the
     * size is less than
     * <code>datanodeMap.size() * 2 - currentRelicatingCount</code>, we will get
     * from <code>blocksWithTwoRelicas</code> and then
     * <code>blocksWithThreeOrMoreReplicas</code>.
     * 
     * @return
     */
    private synchronized long[] getToCheckList() {
        int maxSize = bstore.datanodeNumber() * 2 - replicating.size();
        int capacity = Math.min(
                blocksWithOneReplicas.size() + blocksWithTwoReplicas.size()
                        + blocksWithThreeOrMoreReplicas.size(), maxSize);
        if (capacity == 0) {
            return new long[0];
        }
        long[] blocks = blocksWithOneReplicas.toArray();
        blocksWithOneReplicas.clear();
        if (blocks.length >= maxSize) {
            return blocks;
        }

        LongArrayList list = new LongArrayList(capacity);
        list.addAll(blocks);
        drainTo(list, capacity, blocksWithTwoReplicas);
        if (list.size() == capacity) {
            return list.getArray();
        }
        drainTo(list, capacity, blocksWithThreeOrMoreReplicas);
        list.trimToSize();
        return list.getArray();
    }

    /**
     * Return -1 means we do not need to process the block later. Return value >
     * 0 means we need to process it later, and the returned value is the
     * current replication of this block.
     * 
     * @return
     */
    private int replicateBlock(long block) {
        PlacedBlock pb = bstore.getBlock(block);
        if (pb == null) {
            LOG.warning("no valid block found for " + block);
            return -1;
        }
        DatanodeInfo[] locs;
        synchronized (pb) {
            locs = pb.getLocs();
        }

        int replicas = locs.length;
        int desiredReplicas = pb.getDesiredReplication();
        if (replicas == 0) {
            LOG.warning("Block " + block
                    + " has no replicas, data could be lost");
            return 0;
        }
        if (replicas >= desiredReplicas) {
            LOG.warning("Found enough replicas for block " + block);
            return -1;
        }
        DatanodeInfo dinfo = null;
        int minPendingReplicationLen = Integer.MAX_VALUE;
        for (DatanodeInfo loc: locs) {
            int pendingRelicationLen = loc.getReplicationQueueSize();
            if (pendingRelicationLen < minPendingReplicationLen) {
                minPendingReplicationLen = pendingRelicationLen;
                dinfo = loc;
            }
        }
        DatanodeInfo[] targets;
        try {
            targets = bstore.blockPlacementPolicy.chooseTargets(null, block,
                    desiredReplicas, locs, pb.getLen());
        } catch (FSException e) {
            LOG.log(Level.WARNING, "failed to get targets when replicating "
                    + block, e);
            return replicas;
        }
        String[] targetFullNames = DatanodeInfo.toLocationsWithDataPath(targets);
        synchronized (this) {
            dinfo.replicateBlock(block, targetFullNames, replicas == 1);
            ReplicationEntry entry = new ReplicationEntry(
                    System.currentTimeMillis(), dinfo.getName(),
                    targetFullNames);
            replicating.put(block, entry);
        }
        return -1;
    }

    private synchronized void replicationPeriodCheck() {
        long currentTime = System.currentTimeMillis();
        for (Iterator<Map.Entry<Long, ReplicationEntry>> iter = replicating.entrySet().iterator(); iter.hasNext();) {
            Map.Entry<Long, ReplicationEntry> entry = iter.next();
            if (currentTime - entry.getValue().scheduledTime > replicationMaxPeriod) {
                iter.remove();
                long block = entry.getKey();
                DatanodeInfo dinfo = bstore.getDatanode(entry.getValue().src);
                if (dinfo != null) {
                    dinfo.replicationDone(block);
                }
                LOG.info("Cancel replication for " + block + " to "
                        + Arrays.toString(entry.getValue().targets) + " on "
                        + dinfo + " because it is pending for a long time.");
                bstore.unreserveBlock(block, entry.getValue().targets);
                requestReplication(block, 1);
            } else {
                break;
            }
        }
    }

    @Override
    public void run() {
        DaemonTracker tr = new DaemonTracker();
        while (!closed) {
            try {
                if (bstore.datanodeNumber() < replicationMinDataNode) {
                    try {
                        Thread.sleep(replicationScheduleInterval);
                    } catch (InterruptedException e) {}
                    continue;
                }
                replicationPeriodCheck();
                long[] toCheckList = getToCheckList();
                boolean noProgress;
                if (toCheckList.length == 0) {
                    noProgress = true;
                } else {
                    int i;
                    for (i = 0; i < toCheckList.length; i++) {
                        int replicas = replicateBlock(toCheckList[i]);
                        if (replicas > 0) {
                            // This means we failed to do the replication
                            // This usually because we do not have enough space
                            // sleep a while after we request the split
                            break;
                        }
                    }
                    noProgress = i < toCheckList.length;
                    for (; i < toCheckList.length; i++) {
                        PlacedBlock pb = bstore.getBlock(toCheckList[i]);
                        synchronized (pb) {
                            if (pb.replicationCount() < pb.getDesiredReplication()) {
                                requestReplication(pb.getId(),
                                        pb.replicationCount());
                            }
                        }
                    }
                }
                if (noProgress) {
                    Thread.sleep(replicationScheduleInterval);
                }
            } catch (Throwable t) {
                tr.gotThrowable(t);
            }
        }
    }

    void close() {
        closed = true;
        interrupt();
    }

}
