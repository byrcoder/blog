/**
 * @(#)TransferBlockTask.java, 2012-12-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DataNodeRequest.ReportCond;
import odis.dfs.datanode.Connection.ICallback;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.io.ReadWriteUtils;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class TransferBlockTask implements Runnable {

    private static final Logger LOG = LogFormatter.getLogger(TransferBlockTask.class);

    private final Connection conn;

    private final long srcBlock;

    private final long dstBlock;

    private final String[] targets;

    private final ByteBuffer bb;

    TransferBlockTask(Connection conn, long srcBlock, long dstBlock,
            String[] targets, ByteBuffer bb) {
        this.conn = conn;
        this.srcBlock = srcBlock;
        this.dstBlock = dstBlock;
        this.targets = targets;
        bb.clear();
        this.bb = bb;
    }

    @Override
    public void run() {
        Thread.currentThread().setName(
                "TB-" + conn.dataNode.getFullName() + "-" + srcBlock + "-"
                        + dstBlock + "-"
                        + conn.socket.socket().getRemoteSocketAddress());
        conn.dataNode.metrics.increment(DataNodeMetricsItem.CONCURRENT_REPLICATION);
        try {
            int successCount = conn.dataNode.transferBlock(srcBlock, dstBlock,
                    targets, ReportCond.ON_COMPLETION, null, bb);
            bb.clear();
            bb.put((byte) successCount);
            bb.flip();
            for (int i = 0; bb.hasRemaining() && i < Connection.WRITE_MAX_SPINS; i++) {
                conn.socket.write(bb);
            }
            if (bb.hasRemaining()) {
                conn.asyncWrite(bb, new ICallback() {

                    @Override
                    public void operationSucceeded() {
                        conn.directByteBufferPool.release(bb);
                    }

                    @Override
                    public void operationFailed() {
                        conn.directByteBufferPool.release(bb);
                    }
                });
                return;
            }
            conn.directByteBufferPool.release(bb);
        } catch (Exception e) {
            LOG.log(Level.WARNING, "transfer block " + srcBlock + " as "
                    + dstBlock + " to " + Arrays.toString(targets) + " failed",
                    e);
            conn.directByteBufferPool.release(bb);
            ReadWriteUtils.safeClose(conn);
        } finally {
            conn.dataNode.metrics.decrement(DataNodeMetricsItem.CONCURRENT_REPLICATION);
            Thread.currentThread().setName("Idle-DataXceiver");
        }
    }
}
