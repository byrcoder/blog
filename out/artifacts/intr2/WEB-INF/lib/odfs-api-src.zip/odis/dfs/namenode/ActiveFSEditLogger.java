/**
 * @(#)ActiveFSEditLogger.java, 2012-11-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.IOException;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.journal.JournalManager;
import odis.dfs.util.DfsUtils;
import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.serialize.lib.StringWritable;

import org.apache.commons.configuration.Configuration;

/**
 * @author zhangduo
 */
class ActiveFSEditLogger extends AbstractFSEditLogger implements
        AsyncExecutiveEntryVisitor {

    private final DirectByteArrayOutputStream buffer;

    private final CDataOutputStream dataOut;

    protected int editsInLog;

    ActiveFSEditLogger(Configuration conf, long minimumSN) throws IOException {
        super(DfsUtils.createFromConf(conf.getString(
                DFSConfig.JOURNAL_MANAGER_CLASS,
                DFSConfig.DEFAULT_JOURNAL_MANAGER_CLASS), conf,
                JournalManager.class));
        buffer = new DirectByteArrayOutputStream();
        dataOut = new CDataOutputStream(buffer);
        journalMgr.recoverUnfinalizedSegmentAndStartNewSegment(minimumSN);
    }

    long currentLogFileSN() {
        return journalMgr.currentOpenedSegmentSN();
    }

    void nextLogFile(boolean recover) throws IOException {
        if (recover) {
            journalMgr.recoverUnfinalizedSegmentAndStartNewSegment(FSConstants.IMAGE_FILE_START_SN + 1);
        } else {
            journalMgr.finalizeSegmentAndStartNewSegment();
        }
        editsInLog = 0;
    }

    boolean hasBufferedLogs() {
        return buffer.getBufferSize() > 0;
    }

    void sync() throws IOException {
        journalMgr.write(buffer.getBuffer(), 0, buffer.getBufferSize());
        buffer.reset();
    }

    private void logPrologue(AsyncExecutiveEntry entry) throws IOException {
        dataOut.write(entry.op);
        dataOut.writeLong(journalMgr.currentOpenedSegmentSN() << 32
                | (editsInLog++));
        dataOut.writeLong(entry.time);
    }

    @Override
    public void visit(AsyncCreateExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            dataOut.writeBoolean(entry.overwrite);
            dataOut.writeBoolean(entry.createParent);
            dataOut.writeShort(entry.permission.toShort());
            dataOut.writeInt(entry.replication);
            dataOut.writeInt(entry.fileBlockSize);
            StringWritable.writeString(dataOut, entry.user);
            StringWritable.writeString(dataOut, entry.clientName);
            entry.firstBlock.writeFields(dataOut);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncAppendBlockExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            dataOut.writeInt(entry.blockIndex);
            StringWritable.writeString(dataOut, entry.clientName);
            if (entry.prevBlock != null) {
                dataOut.writeBoolean(true);
                entry.prevBlock.writeFields(dataOut);
            } else {
                dataOut.writeBoolean(false);
            }
            entry.nextBlock.writeFields(dataOut);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncAbandonBlockExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            dataOut.writeInt(entry.blockIndex);
            StringWritable.writeString(dataOut, entry.clientName);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncCompleteExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            entry.lastBlock.writeFields(dataOut);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncAbandonExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncDepriveExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncForceCompleteExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.file);
            if (entry.lastBlock != null) {
                dataOut.writeBoolean(true);
                entry.lastBlock.writeFields(dataOut);
            } else {
                dataOut.writeBoolean(false);
            }
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncRenameExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.src);
            StringWritable.writeString(dataOut, entry.dst);
            dataOut.writeBoolean(entry.overwrite);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncDeleteExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeBoolean(entry.recursive);
            StringWritable.writeStringNull(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncTrashExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            StringWritable.writeString(dataOut, entry.trashPath);
            dataOut.writeBoolean(entry.recursive);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncMkdirExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.dir);
            dataOut.writeInt(entry.replication);
            dataOut.writeShort(entry.permission.toShort());
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncSnapshotExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.src);
            StringWritable.writeString(dataOut, entry.dst);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncReplicateExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeInt(entry.replication);
            dataOut.writeBoolean(entry.recursive);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncChownExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            StringWritable.writeStringNull(dataOut, entry.owner);
            StringWritable.writeStringNull(dataOut, entry.group);
            dataOut.writeBoolean(entry.recursive);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncChmodExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeShort(entry.permission.toShort());
            dataOut.writeBoolean(entry.recursive);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncAddGroupUserExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.group);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncRemoveGroupUserExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.group);
            StringWritable.writeString(dataOut, entry.user);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncRemoveGroupExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.group);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncSetSpaceQuotaExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeLong(entry.quota);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncSetNameQuotaExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeLong(entry.quota);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncSetProtectExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeBoolean(entry.protect);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

    @Override
    public void visit(AsyncSetRecoverableExecutiveEntry entry) {
        try {
            logPrologue(entry);
            StringWritable.writeString(dataOut, entry.path);
            dataOut.writeBoolean(entry.recoverable);
        } catch (IOException e) {
            // should not happen
            throw new RuntimeException(e);
        }
    }

}
