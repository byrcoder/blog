/**
 * @(#)AbstractFSNameSystem.java, 2012-12-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.common.IDataToNameProtocol;
import odis.io.LockStateException;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.rpc2.AsyncRpcCallEntry;

import org.apache.commons.configuration.Configuration;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.misc.LogFormatter;
import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
abstract class AbstractFSNameSystem<FBS extends AbstractPrimaryFSBlockStore, DIR extends AbstractPrimaryFSDirectory<FBS>, FEL extends AbstractFSEditLogger>
        implements IDataToNameProtocol, Closeable, FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(AbstractFSNameSystem.class);

    protected final String admin;

    protected final long leasePeriod;

    protected final AtomicBoolean ready = new AtomicBoolean(false);

    protected final File namenodeRoot;

    // Keeps track of files that are being created
    protected final Map<String, FileINodeUC> pendingCreates;

    // Keeps track of the block that is the last one of those pending creates
    protected final Map<Long, String[]> pendingCreateLastBlocks;
    
    static final class FSProperties {
        final int dataVersion;

        final long volume;

        FSProperties(int dataVersion, long volume) {
            this.dataVersion = dataVersion;
            this.volume = volume;
        }

        @Override
        public String toString() {
            return "[dataVersion=" + dataVersion + ", volume="
                    + HexString.longToPaddedHex(volume) + "]";
        }

    }

    protected final FSProperties fsProps;

    protected void checkReady() throws FSException {
        if (!ready.get()) {
            throw new FSException(FSException.PERMISSION_DENIED,
                    "Service is not ready now, please try a little later.");
        }
    }

    protected void checkAdmin(String user) throws FSException {
        if (user == null) {
            return;
        }
        if (admin != null && !admin.equals(user)) {
            throw new FSException(FSException.PERMISSION_DENIED, "User " + user
                    + " is not the administrator");
        }
    }

    private FSProperties loadFSProperties() throws IOException {
        File propFile = new File(namenodeRoot, FS_PROPERTIES_FILE);
        if (!propFile.exists()) {
            return null;
        }
        Properties props = new Properties();
        FileInputStream in = new FileInputStream(propFile);
        try {
            props.load(in);
        } finally {
            ReadWriteUtils.safeClose(in);
        }
        return new FSProperties(Integer.parseInt(props.getProperty("version")),
                HexString.paddedHexToLong(props.getProperty("volume")));
    }

    private void storeFSProperties(FSProperties fsProps) throws IOException {
        Properties props = new Properties();
        props.setProperty("version", Integer.toString(fsProps.dataVersion));
        props.setProperty("volume", HexString.longToPaddedHex(fsProps.volume));
        File propFile = new File(namenodeRoot, FS_PROPERTIES_FILE);
        FileOutputStream out = new FileOutputStream(propFile);
        try {
            props.store(out, "ODFS properties files");
        } finally {
            ReadWriteUtils.safeClose(out);
        }
    }

    private void setupRoot(File root) throws IOException {
        if (!root.exists() && !root.mkdirs()) {
            throw new IOException("Create namenode root "
                    + root.getAbsolutePath() + " failed");
        }
        File imageDir = new File(root, FS_IMAGE_DIR);
        if (!imageDir.exists() && !imageDir.mkdirs()) {
            throw new IOException("Create image dir "
                    + imageDir.getAbsolutePath() + " failed");
        }
    }

    protected AbstractFSNameSystem(Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks, Configuration conf)
            throws IOException {
        this.pendingCreates = pendingCreates;
        this.pendingCreateLastBlocks = pendingCreateLastBlocks;
        this.namenodeRoot = new File(conf.getString(DFSConfig.NAMENODE_ROOT,
                DFSConfig.DEFAULT_NAMENODE_ROOT));
        this.admin = conf.getString(DFSConfig.NAMENODE_ADMIN,
                System.getProperty("user.name"));
        this.leasePeriod = conf.getLong(DFSConfig.NAMENODE_LEASE_PERIOD,
                DFSConfig.DEFAULT_NAMENODE_LEASE_PERIOD);
        setupRoot(namenodeRoot);
        FSProperties fsProps = loadFSProperties();
        if (fsProps == null) {
            long volume;
            while ((volume = UUID.randomUUID().getMostSignificantBits()) == VOLUME_NA);
            fsProps = new FSProperties(DATA_VERSION, volume);
            LOG.info("No FSProperties, generate a new one " + fsProps);
            storeFSProperties(fsProps);
        } else {
            LOG.info("Load FSProperties " + fsProps);
            if (fsProps.dataVersion < DATA_VERSION) {
                throw new IOException("Data version mismatch, expecetd "
                        + DATA_VERSION + " but actual " + fsProps.dataVersion);
            }
        }
        this.fsProps = fsProps;
    }

    protected AbstractFSNameSystem(Map<String, FileINodeUC> pendingCreates,
            Map<Long, String[]> pendingCreateLastBlocks, File namenodeRoot,
            String admin, long leasePeriod, FSProperties fsProps) {
        this.pendingCreates = pendingCreates;
        this.pendingCreateLastBlocks = pendingCreateLastBlocks;
        this.namenodeRoot = namenodeRoot;
        this.admin = admin;
        this.leasePeriod = leasePeriod;
        this.fsProps = fsProps;
    }

    abstract protected void internalSetReady();

    final void setReady(String user) throws FSException {
        checkAdmin(user);
        if (ready.compareAndSet(false, true)) {
            internalSetReady();
        }
    }

    boolean isReady() {
        return ready.get();
    }

    long getLeasePeriod() {
        return leasePeriod;
    }

    private static final DateTimeFormatter REPORT_FILE_DATE_FORMAT = DateTimeFormat.forPattern("yyMMdd_HHmmss");

    protected File getReportFile(String type) throws IOException {
        File reportDir = new File(namenodeRoot, FS_REPORT_DIR);
        if (!reportDir.exists() && !reportDir.mkdirs()) {
            throw new IOException("Create report dir "
                    + reportDir.getAbsolutePath() + " failed");
        }
        return new File(reportDir, type + "-"
                + REPORT_FILE_DATE_FORMAT.print(System.currentTimeMillis())
                + ".srf");
    }

    abstract FBS getFSBlockStore();

    abstract DIR getFSDirectory();

    abstract FEL getFSEditLogger();

    abstract String consistencyCheck(String user) throws IOException;

    abstract BlockVerifyResult verifyBlock(AsyncRpcCallEntry rpcCallEntry,
            long block) throws FSException;

    abstract void computeContentsLengthAndSubItemNum(String user)
            throws FSException;

    abstract BlockLocationWithDataPath create(AsyncRpcCallEntry rpcCallEntry,
            String file, boolean overwrite, boolean createParent,
            FsPermission permission, int replication, int fileBlockSize,
            String user, String clientMachine, String clientName)
            throws IOException;

    abstract void abandonBlock(AsyncRpcCallEntry rpcCallEntry, String file,
            int blockIndex, String clientName) throws IOException;

    abstract BlockLocationWithDataPath addBlock(AsyncRpcCallEntry rpcCallEntry,
            String file, int blockIndex, String clientMachine, String clientName)
            throws IOException;

    abstract void abandonFileInProgress(AsyncRpcCallEntry rpcCallEntry,
            String file, String user, String clientName) throws IOException;

    abstract boolean complete(AsyncRpcCallEntry rpcCallEntry, String file,
            String clientName) throws IOException;

    abstract boolean deprive(AsyncRpcCallEntry rpcCallEntry, String file,
            String user, String clientName) throws IOException;

    abstract boolean isPending(String file, String user) throws FSException;

    abstract String[] pendingFilesInDir(String path, String user)
            throws FSException;

    abstract BlockSizeLocationWithDataPath[] getFileBlockLocations(String file,
            String user) throws FSException;

    abstract DFSFileStatus getFileStatus(String file, String user)
            throws FSException;

    abstract void mkdirs(AsyncRpcCallEntry rpcCallEntry, String dir,
            int replications, FsPermission permission, String user,
            String clientName) throws FSException;

    abstract DFSFileStatus[] getListing(String dir, String user)
            throws FSException;

    abstract void rename(AsyncRpcCallEntry rpcCallEntry, String src,
            String dst, boolean overwrite, String user, String clientName)
            throws IOException;

    abstract void snapshot(AsyncRpcCallEntry rpcCallEntry, String src,
            String dst, String user, String clientName) throws IOException;

    abstract boolean delete(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, boolean permanently, String user,
            String clientName) throws IOException;

    abstract void recoverTrash(AsyncRpcCallEntry rpcCallEntry, String trash,
            String dst, String user, String clientName) throws IOException;

    abstract boolean deleteTrash(AsyncRpcCallEntry rpcCallEntry, String path,
            String user, String clientName) throws IOException;

    abstract int getReplicationNumber(String path, String user)
            throws FSException;

    abstract void setReplicationNumber(AsyncRpcCallEntry rpcCallEntry,
            String path, int replication, boolean recursive, String user,
            String clientName) throws IOException;

    abstract void setOwner(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, String owner, String group, String user,
            String clientName) throws IOException;

    abstract void setPermission(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, FsPermission permission, String user,
            String clientName) throws IOException;

    abstract void setProtect(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean protect, String user, String clientName) throws IOException;

    abstract boolean isProtect(String path) throws FSException;

    abstract void setRecoverable(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recoverable, String user, String clientName)
            throws IOException;

    abstract boolean isRecoverable(String path) throws FSException;

    abstract void setSpaceQuota(AsyncRpcCallEntry rpcCallEntry, String path,
            long quota, String user, String clientName) throws IOException;

    abstract long getSpaceQuota(String path) throws FSException;

    abstract void setNameQuota(AsyncRpcCallEntry rpcCallEntry, String path,
            long quota, String user, String clientName) throws IOException;

    abstract long getNameQuota(String path) throws FSException;

    abstract String printDirProperties() throws IOException;

    abstract void addGroupUser(AsyncRpcCallEntry rpcCallEntry, String group,
            String user, String opUser, String clientName) throws IOException;

    abstract void removeGroupUser(AsyncRpcCallEntry rpcCallEntry, String group,
            String user, String opUser, String clientName) throws IOException;

    abstract void removeGroup(AsyncRpcCallEntry rpcCallEntry, String group,
            String opUser, String clientName) throws IOException;

    abstract String printGroups() throws FSException;

    abstract void renewLease(String clientName) throws FSException;

    abstract void removeLease(String clientName) throws FSException;

    abstract int obtainLock(String src, int lock, String clientName)
            throws FSException;

    abstract String lockState(String src, String clientName) throws FSException;

    abstract int promote(String src, String clientName) throws FSException,
            LockStateException;

    abstract void downgrade(String src, String clientName) throws FSException,
            LockStateException;

    abstract void releaseLock(String src, String clientName) throws FSException;

    public abstract void close();
}
