/**
 * @(#)BlockLocationWithDataPath.java, 2012-2-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * The difference between this class and BlockLocation is, this class' location
 * contains datanode data directory(e.g., xx001:6000:/disk1)
 * 
 * @author zhangduo
 */
public class BlockLocationWithDataPath implements IWritable {

    private long block;

    private String[] locations;

    public BlockLocationWithDataPath() {}

    public BlockLocationWithDataPath(long block, String[] locations) {
        this.block = block;
        this.locations = locations;
    }

    public long getBlock() {
        return block;
    }

    public String[] getLocations() {
        return locations;
    }

    public void setLocations(String[] locs) {
        this.locations = locs;
    }

    public static String getHostFromLocation(String location) {
        int colon = location.indexOf(':');
        return location.substring(0, colon);
    }

    public static int getPortFromLocation(String location) {
        int colon = location.indexOf(':');
        int colon2 = location.indexOf(':', colon + 1);
        return Integer.parseInt(location.substring(colon + 1, colon2));
    }

    public static String getDataPathFromLocation(String location) {
        int colon = location.indexOf(':');
        int colon2 = location.indexOf(':', colon + 1);
        return location.substring(colon2 + 1);
    }

    public static InetSocketAddress getSocketAddressFromLocation(String location) {
        int colon = location.indexOf(':');
        int colon2 = location.indexOf(':', colon + 1);
        return new InetSocketAddress(location.substring(0, colon),
                Integer.parseInt(location.substring(colon + 1, colon2)));
    }

    @Override
    public IWritable copyFields(IWritable value) {
        BlockLocationWithDataPath that = (BlockLocationWithDataPath) value;
        block = that.block;
        locations = Arrays.copyOf(that.locations, that.locations.length);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(block);
        CDataOutputStream.writeVInt(locations.length, out);
        for (String location: locations) {
            StringWritable.writeString(out, location);
        }
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        block = in.readLong();
        int sz = CDataInputStream.readVInt(in);
        locations = new String[sz];
        for (int i = 0; i < sz; i++) {
            locations[i] = StringWritable.readString(in);
        }
    }

    @Override
    public String toString() {
        return "[BlockLocationWithDataPath block=" + block + ", locations="
                + Arrays.toString(locations) + "]";
    }

}
