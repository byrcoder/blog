/**
 * @(#)PrimaryNameNode.java, 2012-12-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.management.MemoryUsage;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSize;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSConfig;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.FSConstants;
import odis.dfs.common.FSException;
import odis.dfs.common.IClientProtocolV2;
import odis.dfs.common.IClientProtocolV3;
import odis.dfs.common.IDataToNameProtocol;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.metrics.DataNodeMetricsVaqueroReporter;
import odis.dfs.metrics.NameNodeMetrics;
import odis.dfs.metrics.NameNodeMetricsItem;
import odis.dfs.metrics.NameNodeMetricsVaqueroReporter;
import odis.dfs.namenode.ActiveFSDirectory.DirectoryStatInfo;
import odis.dfs.util.DfsUtils;
import odis.io.BytesTranscoder;
import odis.io.LockStateException;
import odis.io.NamedLock;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.ClientInfo;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.serialize.lib.StringWritable;
import odis.util.SystemInfoUtils;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.webapp.WebAppContext;

import toolbox.misc.FileUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import bsh.EvalError;
import bsh.Interpreter;

/**
 * @author zhangduo
 */
public class PrimaryNameNode implements IClientProtocolV3, IDataToNameProtocol,
        FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(PrimaryNameNode.class);

    private final Configuration conf;

    volatile AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem;

    private final ZooKeeper zk;

    final String zkAddr;

    final String zkRoot;

    private final int zkMaxRetryCount;

    final AbstractRpcServer clientRpcServer;

    final AbstractRpcServer systemRpcServer;

    final NameNodeMetrics namenodeMetrics = new NameNodeMetrics();

    final ConcurrentMap<String, long[]> datanodeMetricsMap = new ConcurrentHashMap<String, long[]>();

    private final NameNodeMetricsVaqueroReporter namenodeVaqueroReporter;

    private final DataNodeMetricsVaqueroReporter datanodeVaqueroReporter;

    private final ScheduledExecutorService vaqueroReportService = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "Vaquero Reporter");
            t.setDaemon(true);
            return t;
        }
    });

    private final int maxPathLength;

    private final int maxPathDepth;

    final String cuid;

    final String host;

    final int port;

    final long startTime = System.currentTimeMillis();

    private final AbstractRpcServer oldProxyRpcServer;

    private void setupZkRoot(String zkRoot) throws KeeperException,
            InterruptedException {
        if (!zkRoot.startsWith("/")) {
            throw new IllegalArgumentException(
                    "ZooKeeper path must start with / character");
        }
        if (zkRoot.length() == 1) {
            return;
        }
        String[] dirs = zkRoot.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < dirs.length; i++) {
            String dir = sb.append("/").append(dirs[i]).toString();
            if (zk.exists(dir, null) == null) {
                zk.create(dir, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                        CreateMode.PERSISTENT);
            }
        }
        String namenodeAddrDir = zkRoot + "/" + NAMENODE_ADDR_ZK_DIR;
        if (zk.exists(namenodeAddrDir, null) == null) {
            zk.create(namenodeAddrDir, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                    CreateMode.PERSISTENT);
        }
        String lockDir = zkRoot + "/" + FILE_SYSTEM_LOCK_ZK_DIR;
        if (zk.exists(lockDir, null) == null) {
            zk.create(lockDir, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                    CreateMode.PERSISTENT);
        }
    }

    private final Watcher sessionExpireWathcer = new Watcher() {

        @Override
        public void process(WatchedEvent event) {
            if (KeeperState.Expired.equals(event.getState())) {
                LOG.severe("ZooKeeper session expired, I must kill myself");
                System.exit(1);
            }
        }
    };

    public PrimaryNameNode(Configuration conf) throws IOException,
            KeeperException, InterruptedException {
        this.conf = conf;
        String zkAddr = DfsUtils.getZkAddr(conf);
        String zkRoot = conf.getString(DFSConfig.ZOOKEEPER_ROOT);
        int zkTimeout = conf.getInt(DFSConfig.ZOOKEEPER_TIMEOUT,
                DFSConfig.DEFAULT_ZOOKEEPER_TIMEOUT);
        this.zk = new ZooKeeper(zkAddr, zkTimeout, sessionExpireWathcer);
        setupZkRoot(zkRoot);
        this.zkAddr = zkAddr;
        this.zkRoot = zkRoot;
        this.zkMaxRetryCount = conf.getInt(
                DFSConfig.NAMENODE_ZK_MAX_RETRY_COUNT,
                DFSConfig.DEFAULT_NAMENODE_ZK_MAX_RETRY_COUNT);
        this.cuid = conf.getString(DFSConfig.CUID);
        this.host = InetAddressUtils.getShortHostName();
        this.port = conf.getInt(DFSConfig.NAMENODE_RPC_PORT);
        this.maxPathLength = conf.getInt(DFSConfig.NAMENODE_MAX_PATH_LENGTH,
                DFSConfig.DEFAULT_NAMENODE_MAX_PATH_LENGTH);
        this.maxPathDepth = conf.getInt(DFSConfig.NAMENODE_MAX_PATH_DEPTH,
                DFSConfig.DEFAULT_NAMENODE_MAX_PATH_DEPTH);
        int clientHandlerCount = conf.getInt(DFSConfig.NAMENODE_RPC_HANDLER,
                DFSConfig.DEFAULT_NAMENODE_RPC_HANDLER);
        int clientRpcQueueSize = conf.getInt(DFSConfig.NAMENODE_RPC_QUEUE_SIZE,
                10 * clientHandlerCount);
        int clientWorkerCount = Math.max(
                2 * SystemInfoUtils.getProcessors() - 2, 1);
        this.clientRpcServer = RPC.getNIOServer(IClientProtocolV3.class, this,
                port, clientHandlerCount, clientRpcQueueSize, 1, 0,
                clientWorkerCount, 10 * 1024 * 1024);
        this.clientRpcServer.setServerCallListener(namenodeMetrics);

        int systemHandlerCount = conf.getInt(
                DFSConfig.NAMENODE_SYSTEM_RPC_HANDLER,
                DFSConfig.DEFAULT_NAMENODE_SYSTEM_RPC_HANDLER);
        int systemRpcQueueSize = conf.getInt(
                DFSConfig.NAMENODE_SYSTEM_RPC_QUEUE_SIZE,
                10 * systemHandlerCount);
        int systemWorkerCount = Math.max(2 * SystemInfoUtils.getProcessors()
                - clientWorkerCount, 1);
        this.systemRpcServer = RPC.getNIOServer(IDataToNameProtocol.class,
                this, port + SYSTEM_RPC_PORT_DELTA, systemHandlerCount,
                systemRpcQueueSize, 1, 0, systemWorkerCount, 50 * 1024 * 1024);
        this.systemRpcServer.setServerCallListener(namenodeMetrics);
        namenodeVaqueroReporter = new NameNodeMetricsVaqueroReporter(conf);
        datanodeVaqueroReporter = new DataNodeMetricsVaqueroReporter(conf,
                "all");

        OldClientProtocolProxy oldProxy = new OldClientProtocolProxy(this);
        int oldProxyPort = conf.getInt(DFSConfig.NAMENODE_OLD_PROXY_RPC_PORT);
        this.oldProxyRpcServer = RPC.getNIOServer(IClientProtocolV2.class,
                oldProxy, oldProxyPort, clientHandlerCount, clientRpcQueueSize,
                1, 0, clientWorkerCount, 10 * 1024 * 1024);
    }

    private void putAddrOnZooKeeper() throws KeeperException,
            InterruptedException {
        String addr = zkRoot + "/" + NAMENODE_ADDR_ZK_DIR + "/" + host + ":"
                + port;
        for (int retry = 0;; retry++) {
            try {
                zk.create(addr, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                        CreateMode.EPHEMERAL);
                return;
            } catch (KeeperException e) {
                if (Code.CONNECTIONLOSS.equals(e.code())) {
                    if (zkMaxRetryCount >= 0 && retry >= zkMaxRetryCount) {
                        throw e;
                    }
                    retry++;
                    LOG.log(Level.WARNING, "put addr " + addr
                            + " on zookeeper failed, retry = " + retry, e);
                    DfsUtils.waitExpTime(retry - 1);
                } else {
                    throw e;
                }
            }
        }
    }

    private boolean tryBecomeActiveNameNode()
            throws UnsupportedEncodingException, KeeperException,
            InterruptedException {
        String activeNameNodeZNode = zkRoot + "/" + ACTIVE_NAMENODE_ZNODE;
        byte[] data = (host + ":" + port).getBytes(NAMENODE_ZNODE_ADDR_CHARSET);
        for (int retry = 0;; retry++) {
            try {
                zk.create(activeNameNodeZNode, data,
                        ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
                return true;
            } catch (KeeperException e) {
                if (Code.NODEEXISTS.equals(e.code())) {
                    return false;
                } else if (Code.CONNECTIONLOSS.equals(e.code())) {
                    if (zkMaxRetryCount >= 0 && retry >= zkMaxRetryCount) {
                        throw e;
                    }
                    retry++;
                    LOG.log(Level.WARNING, "try create " + activeNameNodeZNode
                            + " on zookeeper failed, retry = " + retry, e);
                    DfsUtils.waitExpTime(retry - 1);
                } else {
                    throw e;
                }
            }
        }
    }

    private void startVaqueroReporter() {
        long metricsReportInterval = conf.getLong(
                DFSConfig.METRICS_REPORT_INTERVAL,
                DFSConfig.DEFAULT_METRICS_REPORT_INTERVAL);
        vaqueroReportService.scheduleAtFixedRate(new Runnable() {

            @Override
            public void run() {
                try {
                    long[] namenodeMetrics = getNameNodeMetricsRecords();
                    namenodeVaqueroReporter.report(namenodeMetrics);
                    long[] datanodeMetrics = getDataNodeMetricsRecords();
                    datanodeVaqueroReporter.report(datanodeMetrics);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "report metrics to vaquero failed",
                            e);
                }
            }
        }, metricsReportInterval, metricsReportInterval, TimeUnit.MILLISECONDS);
    }

    private void startAsActiveNameNode() throws IOException, KeeperException,
            InterruptedException {
        LOG.info("Start as active namenode");
        ActiveFSNameSystem nameSystem = new ActiveFSNameSystem(conf,
                new ZooKeeperStore<NamedLock<String>>(zk, zkRoot + "/"
                        + FILE_SYSTEM_LOCK_ZK_DIR, LOCK_TRANSCODER));
        this.nameSystem = nameSystem;
        systemRpcServer.start();
        clientRpcServer.start();
        oldProxyRpcServer.start();
        putAddrOnZooKeeper();
        startVaqueroReporter();
    }

    private boolean isActiveNameNodeDead() throws InterruptedException,
            KeeperException {
        String activeNameNodeZNode = zkRoot + "/" + ACTIVE_NAMENODE_ZNODE;
        try {
            return zk.exists(activeNameNodeZNode, null) == null;
        } catch (KeeperException e) {
            if (Code.SESSIONEXPIRED.equals(e.code())) {
                throw e;
            }
            LOG.log(Level.WARNING, "get stat of " + activeNameNodeZNode
                    + " on zookeeper failed", e);
            return false;
        }
    }

    private BackupFSNameSystem startAsBackupNameNode() throws IOException,
            KeeperException, InterruptedException {
        LOG.info("Start as backup namenode");
        BackupFSNameSystem nameSystem = new BackupFSNameSystem(conf);
        this.nameSystem = nameSystem;
        systemRpcServer.start();
        clientRpcServer.start();
        oldProxyRpcServer.start();
        putAddrOnZooKeeper();
        return nameSystem;
    }

    private volatile boolean closed = false;

    private static final BytesTranscoder<String> STRING_TRANSCODER = new BytesTranscoder<String>() {

        @Override
        public byte[] encode(String obj) {
            return StringWritable.encode(obj);
        }

        @Override
        public String decode(byte[] data) {
            return StringWritable.decode(data, 0, data.length);
        }
    };

    private static final BytesTranscoder<NamedLock<String>> LOCK_TRANSCODER = new BytesTranscoder<NamedLock<String>>() {

        @Override
        public byte[] encode(NamedLock<String> obj) {
            return obj.encode(STRING_TRANSCODER);
        }

        @Override
        public NamedLock<String> decode(byte[] data) {
            return NamedLock.<String>decode(data, STRING_TRANSCODER);
        }

    };

    public void start() throws IOException, KeeperException,
            InterruptedException {
        if (tryBecomeActiveNameNode()) {
            startAsActiveNameNode();
            return;
        }
        BackupFSNameSystem backupNameSystem = startAsBackupNameNode();
        long followUpInterval = conf.getLong(
                DFSConfig.NAMENODE_BACKUP_FOLLOW_UP_INTERVAL,
                DFSConfig.DEFAULT_NAMENODE_BACKUP_FOLLOW_UP_INTERVAL);
        while (!closed) {
            backupNameSystem.followUp();
            if (isActiveNameNodeDead() && tryBecomeActiveNameNode()) {
                LOG.info("Active namenode dead, upgrade to active namenode");
                ActiveFSNameSystem activeFSNameSystem = backupNameSystem.upgrade(
                        conf, new ZooKeeperStore<NamedLock<String>>(zk, zkRoot
                                + "/" + FILE_SYSTEM_LOCK_ZK_DIR,
                                LOCK_TRANSCODER));
                this.nameSystem = activeFSNameSystem;
                startVaqueroReporter();
                return;
            }
            Thread.sleep(followUpInterval);
        }
    }

    public void join() throws InterruptedException {
        systemRpcServer.join();
    }

    public void stop() {
        closed = true;
        vaqueroReportService.shutdownNow();
        clientRpcServer.stop();
        systemRpcServer.stop();
        oldProxyRpcServer.stop();
        AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem = this.nameSystem;
        if (nameSystem != null) {
            nameSystem.close();
        }
        ReadWriteUtils.safeCloseZooKeeper(zk);
    }

    long[] getNameNodeMetricsRecords() {
        long[] namenodeMetricsRecords = new long[NameNodeMetricsItem.totalItems()];
        namenodeMetricsRecords[NameNodeMetricsItem.SYSTEM_LOAD.offset()] = (long) (SystemInfoUtils.getLoad() * 100);
        namenodeMetricsRecords[NameNodeMetricsItem.PROCESSOR_NUM.offset()] = SystemInfoUtils.getProcessors();
        MemoryUsage usage = SystemInfoUtils.getMemoryUsage();
        namenodeMetricsRecords[NameNodeMetricsItem.HEAP_INIT.offset()] = usage.getInit();
        namenodeMetricsRecords[NameNodeMetricsItem.HEAP_USED.offset()] = usage.getUsed();
        namenodeMetricsRecords[NameNodeMetricsItem.HEAP_COMMITTED.offset()] = usage.getCommitted();
        namenodeMetricsRecords[NameNodeMetricsItem.HEAP_MAX.offset()] = usage.getMax();
        usage = SystemInfoUtils.getNonHeapMemoryUsage();
        namenodeMetricsRecords[NameNodeMetricsItem.NON_HEAP_INIT.offset()] = usage.getInit();
        namenodeMetricsRecords[NameNodeMetricsItem.NON_HEAP_USED.offset()] = usage.getUsed();
        namenodeMetricsRecords[NameNodeMetricsItem.NON_HEAP_COMMITTED.offset()] = usage.getCommitted();
        namenodeMetricsRecords[NameNodeMetricsItem.NON_HEAP_MAX.offset()] = usage.getMax();
        AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> nameSystem = this.nameSystem;
        DirectoryStatInfo dirStatInfo = nameSystem.getFSDirectory().getStatInfo();
        namenodeMetricsRecords[NameNodeMetricsItem.DIR_NUM.offset()] = dirStatInfo.dirNum;
        namenodeMetricsRecords[NameNodeMetricsItem.FILE_NUM.offset()] = dirStatInfo.fileNum;
        namenodeMetricsRecords[NameNodeMetricsItem.DISTINCT_FILE_NUM.offset()] = dirStatInfo.distinctFileNum;
        namenodeMetricsRecords[NameNodeMetricsItem.FILE_SIZE.offset()] = dirStatInfo.fileSize;
        namenodeMetricsRecords[NameNodeMetricsItem.DISTINCT_FILE_SIZE.offset()] = dirStatInfo.distinctFileSize;
        namenodeMetrics.fillMetricsRecords(namenodeMetricsRecords);
        return namenodeMetricsRecords;
    }

    long[] getDataNodeMetricsRecords() {
        SortedMap<String, long[]> sorted = new TreeMap<String, long[]>(
                datanodeMetricsMap);
        long[] totalMetrics = new long[DataNodeMetricsItem.totalItems()];
        String host = null;
        for (Map.Entry<String, long[]> entry: sorted.entrySet()) {
            String name = entry.getKey();
            long[] metrics = entry.getValue();
            if (host == null || !name.startsWith(host)) {
                for (int i = 0; i <= DataNodeMetricsItem.NON_HEAP_MAX.offset(); i++) {
                    totalMetrics[i] += metrics[i];
                }
                host = name.split(":")[0];
            }
            for (int i = DataNodeMetricsItem.BLOCK_NUM.offset(); i < DataNodeMetricsItem.totalItems(); i++) {
                totalMetrics[i] += metrics[i];
            }
        }
        return totalMetrics;
    }

    private AbstractFSNameSystem<? extends AbstractPrimaryFSBlockStore, ? extends AbstractPrimaryFSDirectory<?>, ? extends AbstractFSEditLogger> getNameSystem()
            throws FSException {
        return this.nameSystem;
    }

    private String getClientUserName() {
        ClientInfo info = RPC.getClientInfo();
        if (info == null) {
            return null;
        }
        return info.username;
    }

    private String getClientMachine() {
        ClientInfo info = RPC.getClientInfo();
        if (info == null) {
            return null;
        }
        String clientHost = info.clientAddr.getHostName();
        if (clientHost.endsWith(".corp.yodao.com")) {
            clientHost = clientHost.substring(0, clientHost.indexOf('.'));
        }
        return clientHost;
    }

    private void checkPathLength(String path) throws FSException {
        if (path.length() > maxPathLength
                || StringUtils.countMatches(path, INode.STR_SEP) > maxPathDepth) {
            throw new FSException(FSException.PATH_TOO_LONG,
                    "Pathname too long. Limit " + maxPathLength
                            + " characters, " + maxPathDepth + " levels.");
        }
    }

    @Override
    public void recoverInconsistentBlock(long block, String initiatingDataNode,
            BlockCheckResult result) throws IOException {
        getNameSystem().recoverInconsistentBlock(block, initiatingDataNode,
                result);
    }

    @Override
    public void reportConsistencyCheckResult(long block,
            String datanodeFullName, BlockCheckResult result)
            throws IOException {
        getNameSystem().reportConsistencyCheckResult(block, datanodeFullName,
                result);
    }

    @Override
    public DataNodeCommand connect(String sender, BlockSize[] blocks,
            long capacity, long remaining, long volume) throws IOException {
        return getNameSystem().connect(sender, blocks, capacity, remaining,
                volume);
    }

    @Override
    public void disconnect(String sender) throws IOException {
        getNameSystem().disconnect(sender);
    }

    @Override
    public void blockReport(String sender, BlockSize[] blocks)
            throws IOException {
        LOG.info("BlockReport from " + sender + ", blocks=" + blocks.length);
        getNameSystem().blockReport(sender, blocks);
    }

    @Override
    public DataNodeCommand[] sendHeartbeat(String sender, long remaining,
            long[] metricsRecord) throws IOException {
        LOG.info("Heartbeat from " + sender + ", remaining=" + remaining);
        datanodeMetricsMap.put(
                DatanodeInfo.getDatanodeHBKeyFromFullName(sender),
                metricsRecord);
        return getNameSystem().sendHeartbeat(sender, remaining, metricsRecord);
    }

    @Override
    public void reportBlockReceivedOrDeleted(String sender,
            BlockSize[] received, long[] deleted) throws IOException {
        getNameSystem().reportBlockReceivedOrDeleted(sender, received, deleted);
    }

    @Override
    public void replicationDone(String sender,
            BlockSizeLocationWithDataPath lblock) throws IOException {
        getNameSystem().replicationDone(sender, lblock);
    }

    @Override
    public String getCUID(String clientName) {
        return cuid;
    }

    @Override
    public void setReady(String clientName) throws FSException {
        getNameSystem().setReady(getClientUserName());
    }

    @Override
    public String consistencyCheck(String clientName) throws IOException {
        return getNameSystem().consistencyCheck(getClientUserName());
    }

    @Override
    public BlockVerifyResult verifyBlock(String clientName, long block)
            throws FSException {
        return getNameSystem().verifyBlock(RPC.getAsyncRpcCallEntry(), block);
    }

    @Override
    public void computeContentsLengthAndSubItemNum(String clientName)
            throws FSException {
        getNameSystem().computeContentsLengthAndSubItemNum(getClientUserName());
    }

    @Override
    public BlockLocationWithDataPath create(String clientName, String file,
            boolean overwrite, boolean createParent, int replication,
            int fileBlockSize, FsPermission permission) throws IOException {
        checkPathLength(file);
        return getNameSystem().create(RPC.getAsyncRpcCallEntry(), file,
                overwrite, createParent, permission, replication,
                fileBlockSize, getClientUserName(), getClientMachine(),
                clientName);
    }

    @Override
    public void abandonBlock(String clientName, String file, int blockIndex)
            throws IOException {
        getNameSystem().abandonBlock(RPC.getAsyncRpcCallEntry(), file,
                blockIndex, clientName);
    }

    @Override
    public BlockLocationWithDataPath addBlock(String clientName, String file,
            int blockIndex) throws IOException {
        return getNameSystem().addBlock(RPC.getAsyncRpcCallEntry(), file,
                blockIndex, getClientMachine(), clientName);
    }

    @Override
    public void abandonFileInProgress(String clientName, String file)
            throws IOException {
        getNameSystem().abandonFileInProgress(RPC.getAsyncRpcCallEntry(), file,
                getClientUserName(), clientName);
    }

    @Override
    public boolean complete(String clientName, String file) throws IOException {
        return getNameSystem().complete(RPC.getAsyncRpcCallEntry(), file,
                clientName);
    }

    @Override
    public boolean deprive(String clientName, String file) throws IOException {
        return getNameSystem().deprive(RPC.getAsyncRpcCallEntry(), file,
                getClientUserName(), clientName);
    }

    @Override
    public boolean isPending(String clientName, String file) throws FSException {
        return getNameSystem().isPending(file, getClientUserName());
    }

    @Override
    public String[] pendingFilesInDir(String clientName, String path)
            throws FSException {
        return getNameSystem().pendingFilesInDir(path, getClientUserName());
    }

    @Override
    public boolean exists(String clientName, String path) throws FSException {
        return getFileStatus(clientName, path) != null;
    }

    @Override
    public BlockSizeLocationWithDataPath[] getFileBlockLocations(
            String clientName, String file) throws FSException {
        return getNameSystem().getFileBlockLocations(file, getClientUserName());
    }

    @Override
    public DFSFileStatus getFileStatus(String clientName, String file)
            throws FSException {
        return getNameSystem().getFileStatus(file, getClientUserName());
    }

    @Override
    public void mkdirs(String clientName, String dir, int replications,
            FsPermission permission) throws FSException, IOException {
        checkPathLength(dir);
        getNameSystem().mkdirs(RPC.getAsyncRpcCallEntry(), dir, replications,
                permission, getClientUserName(), clientName);
    }

    @Override
    public DFSFileStatus[] getListing(String clientName, String dir)
            throws FSException {
        return getNameSystem().getListing(dir, getClientUserName());
    }

    @Override
    public void rename(String clientName, String src, String dst,
            boolean overwrite) throws IOException {
        checkPathLength(dst);
        getNameSystem().rename(RPC.getAsyncRpcCallEntry(), src, dst, overwrite,
                getClientUserName(), clientName);
    }

    @Override
    public void snapshot(String clientName, String src, String dst)
            throws IOException {
        checkPathLength(dst);
        getNameSystem().snapshot(RPC.getAsyncRpcCallEntry(), src, dst,
                getClientUserName(), clientName);
    }

    @Override
    public boolean delete(String clientName, String path, boolean recursive,
            boolean permanently) throws IOException {
        return getNameSystem().delete(RPC.getAsyncRpcCallEntry(), path,
                recursive, permanently, getClientUserName(), clientName);
    }

    @Override
    public void recoverTrash(String clientName, String trash, String dst)
            throws IOException {
        checkPathLength(dst);
        getNameSystem().recoverTrash(RPC.getAsyncRpcCallEntry(), trash, dst,
                getClientUserName(), clientName);
    }

    @Override
    public boolean deleteTrash(String clientName, String path)
            throws IOException {
        return getNameSystem().deleteTrash(RPC.getAsyncRpcCallEntry(), path,
                getClientUserName(), clientName);
    }

    @Override
    public int getReplicationNumber(String clientName, String path)
            throws FSException {
        return getNameSystem().getReplicationNumber(path, getClientUserName());
    }

    @Override
    public void setReplicationNumber(String clientName, String path,
            int replication, boolean recursive) throws IOException {
        getNameSystem().setReplicationNumber(RPC.getAsyncRpcCallEntry(), path,
                replication, recursive, getClientUserName(), clientName);
    }

    @Override
    public void setOwner(String clientName, String path, boolean recursive,
            String owner, String group) throws IOException {
        getNameSystem().setOwner(RPC.getAsyncRpcCallEntry(), path, recursive,
                owner, group, getClientUserName(), clientName);
    }

    @Override
    public void setPermission(String clientName, String path,
            boolean recursive, FsPermission permission) throws IOException {
        getNameSystem().setPermission(RPC.getAsyncRpcCallEntry(), path,
                recursive, permission, getClientUserName(), clientName);
    }

    @Override
    public void setProtect(String clientName, String path, boolean protect)
            throws FSException, IOException {
        getNameSystem().setProtect(RPC.getAsyncRpcCallEntry(), path, protect,
                getClientUserName(), clientName);
    }

    @Override
    public boolean isProtect(String clientName, String path) throws FSException {
        return getNameSystem().isProtect(path);
    }

    @Override
    public void setRecoverable(String clientName, String path,
            boolean recoverable) throws IOException {
        getNameSystem().setRecoverable(RPC.getAsyncRpcCallEntry(), path,
                recoverable, getClientUserName(), clientName);
    }

    @Override
    public boolean isRecoverable(String clientName, String path)
            throws FSException {
        return getNameSystem().isRecoverable(path);
    }

    @Override
    public void setSpaceQuota(String clientName, String path, long quota)
            throws IOException {
        getNameSystem().setSpaceQuota(RPC.getAsyncRpcCallEntry(), path, quota,
                getClientUserName(), clientName);
    }

    @Override
    public long getSpaceQuota(String clientName, String path)
            throws FSException {
        return getNameSystem().getSpaceQuota(path);
    }

    @Override
    public void setNameQuota(String clientName, String path, long quota)
            throws IOException {
        getNameSystem().setNameQuota(RPC.getAsyncRpcCallEntry(), path, quota,
                getClientUserName(), clientName);
    }

    @Override
    public long getNameQuota(String clientName, String path) throws FSException {
        return getNameSystem().getNameQuota(path);
    }

    @Override
    public String printDirProperties(String clientName) throws IOException {
        return getNameSystem().printDirProperties();
    }

    @Override
    public void addGroupUser(String clientName, String group, String user)
            throws IOException {
        getNameSystem().addGroupUser(RPC.getAsyncRpcCallEntry(), group, user,
                getClientUserName(), clientName);
    }

    @Override
    public void removeGroupUser(String clientName, String group, String user)
            throws FSException, IOException {
        getNameSystem().removeGroupUser(RPC.getAsyncRpcCallEntry(), group,
                user, getClientUserName(), clientName);
    }

    @Override
    public void removeGroup(String clientName, String group) throws IOException {
        getNameSystem().removeGroup(RPC.getAsyncRpcCallEntry(), group,
                getClientUserName(), clientName);
    }

    @Override
    public String printGroups(String clientName) throws FSException {
        return getNameSystem().printGroups();
    }

    @Override
    public long getLeasePeriod(String clientName) throws FSException {
        return getNameSystem().getLeasePeriod();
    }

    @Override
    public void renewLease(String clientName) throws FSException {
        getNameSystem().renewLease(clientName);
    }

    @Override
    public void removeLease(String clientName) throws FSException {
        getNameSystem().removeLease(clientName);
    }

    @Override
    public int obtainLock(String clientName, String src, int lock)
            throws RpcException, IOException {
        return getNameSystem().obtainLock(src, lock, clientName);
    }

    @Override
    public String lockState(String clientName, String src) throws RpcException,
            IOException {
        return getNameSystem().lockState(src, clientName);
    }

    @Override
    public int promote(String clientName, String src)
            throws LockStateException, RpcException, IOException {
        return getNameSystem().promote(src, clientName);
    }

    @Override
    public void downgrade(String clientName, String src) throws RpcException,
            IOException, LockStateException {
        getNameSystem().downgrade(src, clientName);
    }

    @Override
    public void releaseLock(String clientName, String src) throws RpcException,
            IOException {
        getNameSystem().releaseLock(src, clientName);
    }

    private static void startInspector(PrimaryNameNode nameNode)
            throws Exception {
        InspectorServlet.nn = nameNode;
        File tmpDir = new File(DFSConfig.getTmpDir(), "Jetty_Inspector");
        if (tmpDir.exists()) {
            if (!FileUtils.fullyDelete(tmpDir)) {
                LOG.warning("Clean tmp dir " + tmpDir.getAbsolutePath()
                        + " failed");
            }
        }
        if (!tmpDir.mkdirs()) {
            LOG.warning("Create tmp dir " + tmpDir.getAbsolutePath()
                    + " failed, the inspector may not start correctly.");
        }
        int webPort = DFSConfig.conf().getInt(DFSConfig.NAMENODE_WEB_PORT,
                DFSConfig.DEFAULT_NAMENODE_WEB_PORT);
        Server webServer = new Server(webPort);
        WebAppContext wac = new WebAppContext(new File(DFSConfig.getHome(),
                "web_namenode").getAbsolutePath(), "/inspector");
        wac.setTempDirectory(tmpDir);
        webServer.setHandler(wac);
        webServer.setStopAtShutdown(true);
        webServer.start();

        LOG.info("Inspector was started on port " + webPort);
    }

    private static void startBeanShell(PrimaryNameNode nameNode)
            throws EvalError {
        int bshPort = DFSConfig.conf().getInt(DFSConfig.NAMENODE_BSH_PORT,
                DFSConfig.DEFAULT_NAMENODE_BSH_PORT);
        Interpreter interpreter = new Interpreter();
        interpreter.set("namenode", nameNode);
        interpreter.set("portnum", bshPort);
        interpreter.eval("setAccessibility(true)");
        interpreter.eval("server(portnum)");

        LOG.info("Bean shell was started on port " + bshPort);
    }

    public static void main(String[] args) throws Exception {
        DfsUtils.setupFileLogger(DFSConfig.getNamenodeLogDir(), "nn",
                DFSConfig.conf());
        final PrimaryNameNode nameNode = new PrimaryNameNode(DFSConfig.conf());
        Runtime.getRuntime().addShutdownHook(new Thread() {

            @Override
            public void run() {
                ReadWriteUtils.safeCloseZooKeeper(nameNode.zk);
            }

        });
        startInspector(nameNode);
        startBeanShell(nameNode);
        try {
            nameNode.start();
            nameNode.join();
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "start namenode failed, I will quit...", e);
            System.exit(1);
        }
    }
}
