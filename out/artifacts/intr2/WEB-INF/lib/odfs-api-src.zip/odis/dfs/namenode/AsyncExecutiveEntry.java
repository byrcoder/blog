/**
 * @(#)AsyncExecutiveEntry.java, 2012-12-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.io.permission.FsPermission;
import odis.rpc2.AsyncRpcCallEntry;

/**
 * @author zhangduo
 */
abstract class AsyncExecutiveEntry {

    final int op;

    final AsyncRpcCallEntry rpcCallEntry;

    long time;

    boolean delayed = false;

    boolean finished = false;

    AsyncExecutiveEntry(int op, AsyncRpcCallEntry rpcCallEntry) {
        this.op = op;
        this.rpcCallEntry = rpcCallEntry;
    }

    void setReturnValue(Object rv) {
        if (rpcCallEntry != null) {
            rpcCallEntry.setReturnValue(rv);
        }
    }

    void setError(Throwable error) {
        if (rpcCallEntry != null) {
            rpcCallEntry.setError(error);
        }
    }

    boolean leaseRelated() {
        return false;
    }

    void finish() {
        if (!finished) {
            if (rpcCallEntry != null) {
                rpcCallEntry.finishCall();
            }
            finished = true;
        }
    }

    abstract void accept(AsyncExecutiveEntryVisitor visitor);
}

class AsyncCreateExecutiveEntry extends AsyncExecutiveEntry {

    final String file;

    final boolean overwrite;

    final boolean createParent;

    final FsPermission permission;

    final int replication;

    final int fileBlockSize;

    final String user;

    final String clientMachine;

    final String clientName;

    BlockLocationWithDataPath firstBlock;

    AsyncCreateExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String file,
            boolean overwrite, boolean createParent, FsPermission permission,
            int replication, int fileBlockSize, String user,
            String clientMachine, String clientName) {
        super(AbstractFSEditLogger.OP_CREATE, rpcCallEntry);
        this.file = file;
        this.overwrite = overwrite;
        this.createParent = createParent;
        this.permission = permission;
        this.replication = replication;
        this.fileBlockSize = fileBlockSize;
        this.user = user;
        this.clientMachine = clientMachine;
        this.clientName = clientName;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncAppendBlockExecutiveEntry extends AsyncExecutiveEntry {
    final String file;

    final int blockIndex;

    final String clientMachine;

    final String clientName;

    BlockWithSize prevBlock;

    BlockLocationWithDataPath nextBlock;

    AsyncAppendBlockExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String file,
            int blockIndex, String clientMachine, String clientName) {
        super(AbstractFSEditLogger.OP_APPEND_BLOCK, rpcCallEntry);
        this.file = file;
        this.blockIndex = blockIndex;
        this.clientMachine = clientMachine;
        this.clientName = clientName;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncAbandonBlockExecutiveEntry extends AsyncExecutiveEntry {
    final String file;

    final int blockIndex;

    final String clientName;

    AsyncAbandonBlockExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String file, int blockIndex, String clientName) {
        super(AbstractFSEditLogger.OP_ABANDON_BLOCK, rpcCallEntry);
        this.file = file;
        this.blockIndex = blockIndex;
        this.clientName = clientName;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncCompleteExecutiveEntry extends AsyncExecutiveEntry {
    final String file;

    final String clientName;

    BlockWithSize lastBlock;

    AsyncCompleteExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String file,
            String clientName) {
        super(AbstractFSEditLogger.OP_COMPLETE, rpcCallEntry);
        this.file = file;
        this.clientName = clientName;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncAbandonExecutiveEntry extends AsyncExecutiveEntry {
    final String file;

    final String user;

    AsyncAbandonExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String file,
            String user) {
        super(AbstractFSEditLogger.OP_ABANDON, rpcCallEntry);
        this.file = file;
        this.user = user;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncForceCompleteExecutiveEntry extends AsyncExecutiveEntry {
    final String file;

    BlockWithSize lastBlock;

    AsyncForceCompleteExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String file) {
        super(AbstractFSEditLogger.OP_FORCE_COMPLETE, rpcCallEntry);
        this.file = file;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }

}

class AsyncDepriveExecutiveEntry extends AsyncExecutiveEntry {
    final String file;

    final String user;

    public AsyncDepriveExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String file, String user) {
        super(AbstractFSEditLogger.OP_DEPRIVE, rpcCallEntry);
        this.file = file;
        this.user = user;
    }

    @Override
    boolean leaseRelated() {
        return true;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncRenameExecutiveEntry extends AsyncExecutiveEntry {
    final String src;

    final String dst;

    final boolean overwrite;

    final String user;

    AsyncRenameExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String src,
            String dst, boolean overwrite, String user) {
        super(AbstractFSEditLogger.OP_RENAME, rpcCallEntry);
        this.src = src;
        this.dst = dst;
        this.overwrite = overwrite;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncDeleteExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final boolean recursive;

    final String user;

    AsyncDeleteExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, String user) {
        super(AbstractFSEditLogger.OP_DELETE, rpcCallEntry);
        this.path = path;
        this.recursive = recursive;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncTrashExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final String trashPath;

    final boolean recursive;

    final String user;

    AsyncTrashExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String path,
            String trashPath, boolean recursive, String user) {
        super(AbstractFSEditLogger.OP_TRASH, rpcCallEntry);
        this.path = path;
        this.trashPath = trashPath;
        this.recursive = recursive;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncMkdirExecutiveEntry extends AsyncExecutiveEntry {
    final String dir;

    final int replication;

    final FsPermission permission;

    final String user;

    AsyncMkdirExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String dir,
            int replication, FsPermission permission, String user) {
        super(AbstractFSEditLogger.OP_MKDIR, rpcCallEntry);
        this.dir = dir;
        this.replication = replication;
        this.permission = permission;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncSnapshotExecutiveEntry extends AsyncExecutiveEntry {
    final String src;

    final String dst;

    final String user;

    AsyncSnapshotExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String src,
            String dst, String user) {
        super(AbstractFSEditLogger.OP_SNAPSHOT, rpcCallEntry);
        this.src = src;
        this.dst = dst;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncReplicateExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final int replication;

    final boolean recursive;

    final String user;

    AsyncReplicateExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String path,
            int replication, boolean recursive, String user) {
        super(AbstractFSEditLogger.OP_REPLICATE, rpcCallEntry);
        this.path = path;
        this.replication = replication;
        this.recursive = recursive;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncChownExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final String owner;

    final String group;

    final boolean recursive;

    final String user;

    AsyncChownExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String path,
            String owner, String group, boolean recursive, String user) {
        super(AbstractFSEditLogger.OP_CHOWN, rpcCallEntry);
        this.path = path;
        this.owner = owner;
        this.group = group;
        this.recursive = recursive;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncChmodExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final FsPermission permission;

    final boolean recursive;

    final String user;

    AsyncChmodExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String path,
            FsPermission permission, boolean recursive, String user) {
        super(AbstractFSEditLogger.OP_CHMOD, rpcCallEntry);
        this.path = path;
        this.permission = permission;
        this.recursive = recursive;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncAddGroupUserExecutiveEntry extends AsyncExecutiveEntry {
    final String group;

    final String user;

    AsyncAddGroupUserExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String group, String user) {
        super(AbstractFSEditLogger.OP_ADD_GROUP_USER, rpcCallEntry);
        this.group = group;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncRemoveGroupUserExecutiveEntry extends AsyncExecutiveEntry {
    final String group;

    final String user;

    AsyncRemoveGroupUserExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String group, String user) {
        super(AbstractFSEditLogger.OP_REMOVE_GROUP_USER, rpcCallEntry);
        this.group = group;
        this.user = user;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncRemoveGroupExecutiveEntry extends AsyncExecutiveEntry {
    final String group;

    AsyncRemoveGroupExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String group) {
        super(AbstractFSEditLogger.OP_REMOVE_GROUP, rpcCallEntry);
        this.group = group;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncSetSpaceQuotaExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final long quota;

    AsyncSetSpaceQuotaExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String path, long quota) {
        super(AbstractFSEditLogger.OP_SET_SPACE_QUOTA, rpcCallEntry);
        this.path = path;
        this.quota = quota;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncSetNameQuotaExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final long quota;

    AsyncSetNameQuotaExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String path, long quota) {
        super(AbstractFSEditLogger.OP_SET_NAME_QUOTA, rpcCallEntry);
        this.path = path;
        this.quota = quota;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncSetProtectExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final boolean protect;

    AsyncSetProtectExecutiveEntry(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean protect) {
        super(AbstractFSEditLogger.OP_SET_PROTECT, rpcCallEntry);
        this.path = path;
        this.protect = protect;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

class AsyncSetRecoverableExecutiveEntry extends AsyncExecutiveEntry {
    final String path;

    final boolean recoverable;

    AsyncSetRecoverableExecutiveEntry(AsyncRpcCallEntry rpcCallEntry,
            String path, boolean recoverable) {
        super(AbstractFSEditLogger.OP_SET_RECOVERABLE, rpcCallEntry);
        this.path = path;
        this.recoverable = recoverable;
    }

    @Override
    void accept(AsyncExecutiveEntryVisitor visitor) {
        visitor.visit(this);
    }
}

interface AsyncExecutiveEntryVisitor {
    void visit(AsyncCreateExecutiveEntry entry);

    void visit(AsyncAppendBlockExecutiveEntry entry);

    void visit(AsyncAbandonBlockExecutiveEntry entry);

    void visit(AsyncCompleteExecutiveEntry entry);

    void visit(AsyncForceCompleteExecutiveEntry entry);

    void visit(AsyncAbandonExecutiveEntry entry);

    void visit(AsyncDepriveExecutiveEntry entry);

    void visit(AsyncRenameExecutiveEntry entry);

    void visit(AsyncDeleteExecutiveEntry entry);

    void visit(AsyncTrashExecutiveEntry entry);

    void visit(AsyncMkdirExecutiveEntry entry);

    void visit(AsyncSnapshotExecutiveEntry entry);

    void visit(AsyncReplicateExecutiveEntry entry);

    void visit(AsyncChownExecutiveEntry entry);

    void visit(AsyncChmodExecutiveEntry entry);

    void visit(AsyncAddGroupUserExecutiveEntry entry);

    void visit(AsyncRemoveGroupUserExecutiveEntry entry);

    void visit(AsyncRemoveGroupExecutiveEntry entry);

    void visit(AsyncSetSpaceQuotaExecutiveEntry entry);

    void visit(AsyncSetNameQuotaExecutiveEntry entry);

    void visit(AsyncSetProtectExecutiveEntry entry);

    void visit(AsyncSetRecoverableExecutiveEntry entry);
}

class NoActionAsyncExecutiveEntryVisitor implements AsyncExecutiveEntryVisitor {

    @Override
    public void visit(AsyncCreateExecutiveEntry entry) {}

    @Override
    public void visit(AsyncAppendBlockExecutiveEntry entry) {}

    @Override
    public void visit(AsyncAbandonBlockExecutiveEntry entry) {}

    @Override
    public void visit(AsyncCompleteExecutiveEntry entry) {}

    @Override
    public void visit(AsyncAbandonExecutiveEntry entry) {}

    @Override
    public void visit(AsyncForceCompleteExecutiveEntry entry) {}

    @Override
    public void visit(AsyncDepriveExecutiveEntry entry) {}

    @Override
    public void visit(AsyncRenameExecutiveEntry entry) {}

    @Override
    public void visit(AsyncDeleteExecutiveEntry entry) {}

    @Override
    public void visit(AsyncTrashExecutiveEntry entry) {}

    @Override
    public void visit(AsyncMkdirExecutiveEntry entry) {}

    @Override
    public void visit(AsyncSnapshotExecutiveEntry entry) {}

    @Override
    public void visit(AsyncReplicateExecutiveEntry entry) {}

    @Override
    public void visit(AsyncChownExecutiveEntry entry) {}

    @Override
    public void visit(AsyncChmodExecutiveEntry entry) {}

    @Override
    public void visit(AsyncAddGroupUserExecutiveEntry entry) {}

    @Override
    public void visit(AsyncRemoveGroupUserExecutiveEntry entry) {}

    @Override
    public void visit(AsyncRemoveGroupExecutiveEntry entry) {}

    @Override
    public void visit(AsyncSetSpaceQuotaExecutiveEntry entry) {}

    @Override
    public void visit(AsyncSetNameQuotaExecutiveEntry entry) {}

    @Override
    public void visit(AsyncSetProtectExecutiveEntry entry) {}

    @Override
    public void visit(AsyncSetRecoverableExecutiveEntry entry) {}

}
