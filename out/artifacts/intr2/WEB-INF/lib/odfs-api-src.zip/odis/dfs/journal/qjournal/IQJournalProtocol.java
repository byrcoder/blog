package odis.dfs.journal.qjournal;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.dfs.journal.qjournal.client.QuorumJournalManager;
import odis.dfs.journal.qjournal.server.JournalNode;
import odis.rpc2.RpcException;
import odis.serialize.IWritable;

/**
 * Protocol used to communicate between {@link QuorumJournalManager} and each
 * {@link JournalNode}. This is responsible for sending edits as well as
 * coordinating recovery of the nodes.
 * 
 * @author chenxi
 */
public interface IQJournalProtocol {

    public class GetJournalStateResponse implements IWritable {
        long lastPromisedEpoch;

        int httpPort;

        public GetJournalStateResponse() {}

        public GetJournalStateResponse(long lastPromisedEpoch, int httpPort) {
            this.lastPromisedEpoch = lastPromisedEpoch;
            this.httpPort = httpPort;
        }

        public long getLastPromisedEpoch() {
            return lastPromisedEpoch;
        }

        public void setLastPromisedEpoch(long lastPromisedEpoch) {
            this.lastPromisedEpoch = lastPromisedEpoch;
        }

        public int getHttpPort() {
            return httpPort;
        }

        public void setHttpPort(int httpPort) {
            this.httpPort = httpPort;
        }

        @Override
        public IWritable copyFields(IWritable value) {
            GetJournalStateResponse that = (GetJournalStateResponse) value;
            this.lastPromisedEpoch = that.lastPromisedEpoch;
            this.httpPort = that.httpPort;
            return this;
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(lastPromisedEpoch);
            out.writeInt(httpPort);
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            this.lastPromisedEpoch = in.readLong();
            this.httpPort = in.readInt();
        }
    }

    public class SegmentState implements IWritable {
        private boolean isInProgress;

        private long contentLength = -1;

        private long sn;

        public SegmentState() {}

        public boolean isInProgress() {
            return isInProgress;
        }

        public void setInProgress(boolean isInProgress) {
            this.isInProgress = isInProgress;
        }

        public long getContentLength() {
            return contentLength;
        }

        public void setContentLength(long contentLength) {
            this.contentLength = contentLength;
        }
        
        public long getSn() {
            return sn;
        }

        public void setSn(long sn) {
            this.sn = sn;
        }

        @Override
        public IWritable copyFields(IWritable value) {
            SegmentState that = (SegmentState) value;
            this.isInProgress = that.isInProgress;
            this.contentLength = that.contentLength;
            this.sn = that.sn;
            return this;
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeBoolean(isInProgress);
            out.writeLong(contentLength);
            out.writeLong(sn);
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            this.isInProgress = in.readBoolean();
            this.contentLength = in.readLong();
            this.sn = in.readLong();
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("{SegmentInfo:[sn=" + sn);
            sb.append("], [logFileLength=" + contentLength);
            sb.append("], [isInProgress=" + isInProgress);
            sb.append("]}");
            return sb.toString();
        }
    }

    public class PrepareRecoveryResponse implements IWritable {

        private boolean hasSegmentState = false;
        
        private SegmentState segmentState = null;

        private long acceptedInEpoch = -1;

        private long lastWriterEpoch;

        public PrepareRecoveryResponse() {}
        
        public PrepareRecoveryResponse(SegmentState segmentState,
                long acceptedInEpoch, long lastWriterEpoch) {
            this.segmentState = segmentState;
            this.acceptedInEpoch = acceptedInEpoch;
            this.lastWriterEpoch = lastWriterEpoch;
            if (null != segmentState) {
                this.hasSegmentState = true;
            }
        }

        public SegmentState getSegmentState() {
            return segmentState;
        }

        public void setSegmentState(SegmentState segmentState) {
            this.segmentState = segmentState;
        }

        public boolean hasSegmentState() {
            return null != this.segmentState;
        }
        
        public long getAcceptedInEpoch() {
            return acceptedInEpoch;
        }

        public void setAcceptedInEpoch(long acceptedInEpoch) {
            this.acceptedInEpoch = acceptedInEpoch;
        }

        public long getLastWriterEpoch() {
            return lastWriterEpoch;
        }

        public void setLastWriterEpoch(long lastWriterEpoch) {
            this.lastWriterEpoch = lastWriterEpoch;
        }
        
        public boolean isHasSegmentState() {
            return hasSegmentState;
        }

        public void setHasSegmentState(boolean hasSegmentState) {
            this.hasSegmentState = hasSegmentState;
        }

        @Override
        public IWritable copyFields(IWritable value) {
            PrepareRecoveryResponse that = (PrepareRecoveryResponse) value;
            this.segmentState = that.segmentState;
            this.acceptedInEpoch = that.acceptedInEpoch;
            this.lastWriterEpoch = that.lastWriterEpoch;
            return this;
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeBoolean(hasSegmentState);
            if (hasSegmentState) {
                this.segmentState.writeFields(out);
            }
            out.writeLong(acceptedInEpoch);
            out.writeLong(lastWriterEpoch);
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            this.hasSegmentState = in.readBoolean();
            if (this.hasSegmentState) {
                this.segmentState = new SegmentState();
                this.segmentState.readFields(in);
            }
            this.acceptedInEpoch = in.readLong();
            this.lastWriterEpoch = in.readLong();
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[acceptedInEpoch=" + acceptedInEpoch);
            sb.append("], [lastWriterEpoch=" + lastWriterEpoch);
            sb.append("], [hasSegmentState=" + hasSegmentState);
            sb.append("]");
            if (hasSegmentState) {
                sb.append(" , ");
                sb.append(segmentState.toString());
            }
            return sb.toString();
        }
    }
    
    public class ExistResponse implements IWritable {
        int httpPort;
        
        boolean exist;

        public ExistResponse() {}

        public ExistResponse(int httpPort, boolean exist) {
            super();
            this.httpPort = httpPort;
            this.exist = exist;
        }

        public int getHttpPort() {
            return httpPort;
        }

        public void setHttpPort(int httpPort) {
            this.httpPort = httpPort;
        }

        public boolean isExist() {
            return exist;
        }

        public void setExist(boolean exist) {
            this.exist = exist;
        }

        @Override
        public IWritable copyFields(IWritable value) {
            ExistResponse that = (ExistResponse) value;
            this.httpPort = that.httpPort;
            this.exist = that.exist;
            return this;
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeInt(httpPort);
            out.writeBoolean(exist);
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            this.httpPort = in.readInt();
            this.exist = in.readBoolean();
        }
    }

    /**
     * Get the current state of the journal, including the most recent epoch
     * number and the HTTP port.
     */
    public GetJournalStateResponse getJournalState(String clusterId)
            throws IOException;

    /**
     * Begin a new epoch.
     * 
     * @param clusterId
     *            which odfs cluster is asked for journalNode (eg. tiger:6080)
     * @param epoch
     *            The epoch number request to be writer
     * @return The last SN that the journalNode store
     */
    public long newEpoch(String clusterId, long epoch) throws IOException;

    /**
     * Journal edit records. This message is sent by the active name-node to the
     * JournalNodes to write edits to their local logs.
     * 
     * @param currentSN
     *            the SN the writer thinks it's to write
     * @param checksum
     *            the checksum of the file
     * @return the checksum of the current journal file
     */
    public int journal(RequestInfo reqInfo, long currentSN, byte[] records,
            int checksum) throws IOException;
    
    /**
     * Journal edit records. This message is sent by the active name-node to the
     * JournalNodes to write edits to their local logs.
     * 
     * @param currentSN
     *            the SN the writer thinks it's to write
     * @param checksum
     *            the checksum of the file
     * @return the checksum of the current journal file
     */
    public int journal(RequestInfo reqInfo, long currentSN, byte[] records,
            int off, int len, int checksum) throws IOException;

    /**
     * Heartbeat. This is a no-op on the server, except that it verifies that
     * the caller is in fact still the active writer, and provides up-to-date
     * information on the most recently committed txid.
     */
    public void heartbeat(RequestInfo reqInfo) throws IOException;

    /**
     * Start writing to a new log segment on the JournalNode. Before calling
     * this, one should finalize the previous segment using
     * {@link #finalizeLogSegment(RequestInfo, long, long)}.
     * 
     * @param minimumSN
     *            the new segment's SN should be larger than or equal to the
     *            minimumSN
     * @return the SN started
     */
    public long startLogSegment(RequestInfo reqInfo, long minimumSN)
            throws IOException;

    /**
     * Finalize the given log segment on the JournalNode. The segment is
     * expected to be in-progress and starting at the given SN.
     * 
     * @param sn
     *            the expected sn in the given log
     * @param logLength
     *            the checksum of the log segment
     * @return the length of the log segment
     * @throws IOException
     *             if no such segment exists
     */
    public int finalizeLogSegment(RequestInfo reqInfo, long sn, long logLength)
            throws IOException;

    /**
     * Begin the recovery process for a given segment.
     */
    public PrepareRecoveryResponse prepareRecovery(RequestInfo reqInfo, long sn)
            throws IOException;

    /**
     * Accept a proposed recovery for the given segment number
     */
    public long acceptRecovery(RequestInfo reqInfo, SegmentState stateToAccept,
            String fromUrl) throws IOException;
    
    /**
     * @return journals deleted
     */
    public long deleteSegmentBefore(long sn) throws RpcException;
    
    /**
     * check if the log segment sn is exist
     */
    public ExistResponse exist(long sn) throws RpcException;
    
    /**
     * Return the max sn for  finalized segment
     */
    public long maxFinalizedSegmentSN() throws RpcException;
}
