/**
 * @(#)DataNodeManager.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.metrics.DataNodeMetricsGangliaReporter;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.dfs.util.DfsUtils;
import odis.io.ReadWriteUtils;
import odis.util.DaemonTracker;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;
import org.apache.zookeeper.KeeperException;

import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import toolbox.text.util.PrefixSearcher;
import bsh.EvalError;
import bsh.Interpreter;

/**
 * @author zhangduo
 */
public class DataNodeManager implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(DataNodeManager.class);

    private final Configuration conf;

    private final String[] dataNodeLocations;

    private final int startPort;

    private final String hostName;

    private final File offlineFile;

    private final Map<String, DataNodeHolder> dataNodeMap;

    final DataXceiveServer dataXceiveServer;

    private final OfflineDiskPathNormalizer offlineDiskPathNormalizer;

    final NameNodeWatcher watcher;

    final ExecutorService asyncTaskPool = Executors.newCachedThreadPool(new ThreadFactory() {

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "Async-Task");
            t.setDaemon(true);
            return t;
        }
    });

    final ScheduledExecutorService backgroundTaskPool = Executors.newScheduledThreadPool(
            2, new ThreadFactory() {

                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "Background-Task");
                    t.setDaemon(true);
                    return t;
                }
            });

    private final DataNodeMetricsGangliaReporter gangliaReporter;

    private final class DataNodeHolder {
        private final File dir;

        private final int index;

        private volatile DataNode dataNode;

        DataNodeHolder(File dir, int index) {
            this.dir = dir;
            this.index = index;
        }

        synchronized void start() throws IOException, InterruptedException {
            if (dataNode != null) {
                throw new IllegalStateException("DataNode [" + hostName + ":"
                        + (startPort + DATANODE_DELTA_PORT_INCREASE * index)
                        + ":" + dir.getAbsolutePath() + "] is already started");
            }
            dataNode = new DataNode(conf, DataNodeManager.this, dir,
                    dataXceiveServer, startPort, index);
            dataNode.startService();
        }

        synchronized void stop() {
            if (dataNode != null) {
                try {
                    dataNode.shutdown();
                } catch (InterruptedException e) {}
                dataNode = null;
            }
        }

        boolean stopped() {
            return dataNode == null;
        }
    }

    private Map<String, DataNodeHolder> createDataNodeMap() {
        Map<String, DataNodeHolder> map = new HashMap<String, DataNodeHolder>(
                dataNodeLocations.length);
        for (int i = 0; i < dataNodeLocations.length; i++) {
            String dir = dataNodeLocations[i];
            map.put(dir, new DataNodeHolder(new File(dir), i));
        }
        return map;
    }

    public DataNodeManager(Configuration conf, String[] dataNodeLocations,
            int startPort, String hostName, File offlineFile)
            throws IOException, KeeperException, InterruptedException {
        this.conf = conf;
        this.dataNodeLocations = dataNodeLocations;
        this.startPort = startPort;
        this.hostName = hostName;
        this.offlineFile = offlineFile;
        this.offlineDiskPathNormalizer = DfsUtils.createFromConf(
                conf.getString(
                        DFSConfig.DATANODE_OFFLINE_DISK_PATH_NORMALIZER_CLASS,
                        DFSConfig.DEFAULT_DATANODE_OFFLINE_DISK_PATH_NORMALIZER_CLASS),
                conf, OfflineDiskPathNormalizer.class);
        this.watcher = new NameNodeWatcher(conf);
        this.dataXceiveServer = new DataXceiveServer(conf);
        this.dataNodeMap = Collections.unmodifiableMap(createDataNodeMap());
        this.gangliaReporter = new DataNodeMetricsGangliaReporter(conf,
                hostName);
    }

    public String[] getDataNodeLocations() {
        return dataNodeLocations;
    }

    public int getStartPort() {
        return startPort;
    }

    public String getHostName() {
        return hostName;
    }

    public File getOfflineFile() {
        return offlineFile;
    }

    private Set<String> loadOfflineDisks() throws IOException {
        Set<String> offlines = new HashSet<String>();
        if (offlineFile.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(
                    offlineFile));
            try {
                for (String line; (line = reader.readLine()) != null;) {
                    line = line.trim();
                    if (StringUtils.isEmpty(line)) {
                        LOG.warning("Found empty line in offline disks file "
                                + offlineFile.getAbsolutePath());
                        continue;
                    }
                    LOG.warning("Found error disk: " + line);
                    offlines.add(line);
                }
            } finally {
                ReadWriteUtils.safeClose(reader);
            }
        }
        return offlines;
    }

    private PrefixSearcher loadOfflineDisksAsPrefixSearcher()
            throws IOException {
        Set<String> offlines = loadOfflineDisks();
        if (offlines.isEmpty()) {
            return null;
        }
        PrefixSearcher ps = new PrefixSearcher();
        ps.compile(offlines);
        return ps;
    }

    private synchronized void checkOfflineDisks() throws IOException {
        PrefixSearcher ps = loadOfflineDisksAsPrefixSearcher();
        for (DataNodeHolder dataNodeHolder: dataNodeMap.values()) {
            if (ps != null
                    && ps.isPrefixInSet(dataNodeHolder.dir.getAbsolutePath())) {
                if (!dataNodeHolder.stopped()) {
                    dataNodeHolder.stop();
                }
            } else {
                if (dataNodeHolder.stopped()) {
                    try {
                        dataNodeHolder.start();
                    } catch (Exception e) {
                        LOG.log(Level.SEVERE, "start datanode on "
                                + dataNodeHolder.dir.getAbsolutePath()
                                + " failed", e);
                        markOfflineDisks(dataNodeHolder.dir.getAbsolutePath());
                    }
                }
            }
        }
    }

    private synchronized void markOfflineDisks(String rootPath) {
        DataNodeHolder dataNodeHolder = dataNodeMap.get(rootPath);
        if (dataNodeHolder == null) {
            LOG.warning("DataNode " + rootPath
                    + " not found when markOfflineDisks");
            return;
        }
        if (!dataNodeHolder.stopped()) {
            dataNodeHolder.stop();
        }
        try {
            Set<String> offlines = loadOfflineDisks();
            if (!offlines.isEmpty()) {
                PrefixSearcher ps = new PrefixSearcher();
                ps.compile(offlines);
                if (ps.isPrefixInSet(rootPath)) {
                    return;
                }
            }

            offlines.add(offlineDiskPathNormalizer.getPrefix(rootPath));
            String[] offlineDisks = offlines.toArray(new String[0]);
            Arrays.sort(offlineDisks);
            PrintWriter out = new PrintWriter(offlineFile);
            for (String offlineDisk: offlineDisks) {
                out.println(offlineDisk);
            }
            out.close();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "mark " + rootPath + " as offline failed", e);
        }
    }

    public void asyncMarkOfflineDisks(final String rootPath) {
        asyncTaskPool.execute(new Runnable() {

            @Override
            public void run() {
                markOfflineDisks(rootPath);
            }
        });
    }

    private void verifyPort(int start, int end) throws IOException {
        for (int i = start; i < end; i++) {
            ServerSocket serverSocket = null;
            try {
                serverSocket = new ServerSocket(i);
                serverSocket.setReuseAddress(true);
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "can not bind on port " + i, e);
                throw e;
            } finally {
                if (serverSocket != null) {
                    ReadWriteUtils.safeCloseServerSocket(serverSocket);
                }
            }
        }
    }

    public void start() throws IOException, InterruptedException {
        verifyPort(startPort, startPort + dataNodeLocations.length);
        dataXceiveServer.startServer();
        List<Future<?>> futures = new ArrayList<Future<?>>();
        PrefixSearcher ps = loadOfflineDisksAsPrefixSearcher();
        for (final DataNodeHolder dataNodeHolder: dataNodeMap.values()) {
            if (ps != null
                    && ps.isPrefixInSet(dataNodeHolder.dir.getAbsolutePath())) {
                continue;
            }
            futures.add(asyncTaskPool.submit(new Runnable() {

                @Override
                public void run() {
                    try {
                        dataNodeHolder.start();
                    } catch (DataNodeFatalException e) {
                        LOG.log(Level.SEVERE,
                                "fatal error occurred when starting "
                                        + dataNodeHolder.dir.getAbsolutePath(),
                                e);
                        markOfflineDisks(dataNodeHolder.dir.getAbsolutePath());
                    } catch (Exception e) {
                        LOG.log(Level.SEVERE, "start datanode on "
                                + dataNodeHolder.dir.getAbsolutePath()
                                + " failed, I must kill myself", e);
                        System.exit(1);
                    }
                }
            }));
        }
        for (Future<?> future: futures) {
            try {
                future.get();
            } catch (ExecutionException e) {
                // should not happen
                LOG.log(Level.WARNING, "start data server failed", e);
            }
        }
        long offlineDisksCheckInterval = conf.getLong(
                DFSConfig.DATANODE_OFFLINE_DISKS_CHECK_INTERVAL,
                DFSConfig.DEFAULT_DATANODE_OFFLINE_DISKS_CHECK_INTERVAL);
        this.backgroundTaskPool.scheduleAtFixedRate(new Runnable() {

            private DaemonTracker tr = new DaemonTracker();

            @Override
            public void run() {
                try {
                    checkOfflineDisks();
                } catch (Exception e) {
                    tr.gotThrowable(e);
                }
            }
        }, offlineDisksCheckInterval, offlineDisksCheckInterval,
                TimeUnit.MILLISECONDS);

        long metricsReportInterval = DFSConfig.conf().getLong(
                DFSConfig.METRICS_REPORT_INTERVAL,
                DFSConfig.DEFAULT_METRICS_REPORT_INTERVAL);
        backgroundTaskPool.scheduleAtFixedRate(new Runnable() {

            private final long[] metrics = new long[DataNodeMetricsItem.totalItems()];

            @Override
            public void run() {
                boolean reportGlobal = true;
                for (DataNodeHolder dataNodeHolder: dataNodeMap.values()) {
                    DataNode dn = dataNodeHolder.dataNode;
                    if (dn == null) {
                        continue;
                    }
                    dn.fillMetricsRecords(metrics);
                    if (reportGlobal) {
                        gangliaReporter.reportGlobal(metrics);
                        reportGlobal = false;
                    }
                    gangliaReporter.report(
                            dataNodeHolder.dir.getAbsolutePath(), metrics);
                }
            }
        }, metricsReportInterval, metricsReportInterval, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        asyncTaskPool.shutdownNow();
        backgroundTaskPool.shutdownNow();
        for (DataNodeHolder dataNodeHolder: dataNodeMap.values()) {
            dataNodeHolder.stop();
        }
        dataXceiveServer.shutdown();
        watcher.shutdown();
    }

    // only used for testcase
    boolean isStopped(String rootPath) {
        return dataNodeMap.get(rootPath).stopped();
    }

    public void join() throws KeeperException, InterruptedException {
        watcher.checkAddr();
    }

    private static boolean checkMachine() {
        String machineUnavailableFile = DFSConfig.conf().getString(
                DFSConfig.DATANODE_MACHINE_UNAVAILABLE_FILE,
                DFSConfig.DEFAULT_DATANODE_MACHINE_UNAVAILABLE_FILE);
        return !new File(machineUnavailableFile).exists();
    }

    private static void startBeanShell(DataNodeManager mgr) throws EvalError {
        int bshPort = DFSConfig.conf().getInt(DFSConfig.DATANODE_BSH_PORT,
                DFSConfig.DEFAULT_DATANODE_BSH_PORT);
        Interpreter interpreter = new Interpreter();
        interpreter.set("mgr", mgr);
        interpreter.set("portnum", bshPort);
        interpreter.eval("setAccessibility(true)");
        interpreter.eval("server(portnum)");

        LOG.info("Bean shell was started on port " + bshPort);
    }

    public static void main(String[] args) throws IOException, KeeperException,
            InterruptedException, EvalError {
        Configuration conf = DFSConfig.conf();
        DfsUtils.setupFileLogger(DFSConfig.getDatanodeLogDir(), "dn", conf);
        if (!checkMachine()) {
            LOG.severe("The machine is unavailable now, please try later.");
            return;
        }
        String[] dataNodeLocations = conf.getStringArray(DFSConfig.DATANODE_DIRS);
        int startPort = conf.getInt(DFSConfig.DATANODE_PORT,
                DFSConfig.DEFAULT_DATANODE_PORT);
        String offlineFile = conf.getString(
                DFSConfig.DATANODE_OFFLINE_DISKS_FILE,
                DFSConfig.DEFAULT_DATANODE_OFFLINE_DISKS_FILE);
        DataNodeManager mgr = new DataNodeManager(conf, dataNodeLocations,
                startPort, InetAddressUtils.getShortHostName(), new File(
                        offlineFile));
        startBeanShell(mgr);
        mgr.start();
        mgr.join();
    }
}
