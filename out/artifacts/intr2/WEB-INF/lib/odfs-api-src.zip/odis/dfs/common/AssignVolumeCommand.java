/**
 * @(#)AssignVolumeCommand.java, 2011-11-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.dfs.datanode.DataNode;
import odis.serialize.IWritable;

/**
 * Assigns a unique volume number to this data node who should use it to connect
 * to this namenode in the future.
 * 
 * @author zhangduo
 */
public class AssignVolumeCommand extends DataNodeCommand {

    private long volume;

    public AssignVolumeCommand() {}

    public AssignVolumeCommand(long volume) {
        this.volume = volume;
    }

    public long getVolume() {
        return volume;
    }

    public void setVolume(long volume) {
        this.volume = volume;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(volume);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        volume = in.readLong();
    }

    @Override
    public IWritable copyFields(IWritable value) {
        AssignVolumeCommand that = (AssignVolumeCommand) value;
        volume = that.volume;
        return this;
    }

    @Override
    public void execute(DataNode dataNode) throws IOException {
        dataNode.assignVolume(volume);
    }

}
