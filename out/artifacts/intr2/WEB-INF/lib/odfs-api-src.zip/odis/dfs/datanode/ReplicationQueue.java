/**
 * @(#)ReplicationQueue.java, 2012-3-11. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.ReplicateCommand;
import toolbox.collections.primitive.LongCompactHashSet;

/**
 * A queue for storing ReplicateCommand.
 * 
 * @author zhangduo
 */
class ReplicationQueue {

    private final Lock lock = new ReentrantLock();

    private final Condition notEmpty = lock.newCondition();

    private final Map<Long, BlockLocationWithDataPath> immediate = new LinkedHashMap<Long, BlockLocationWithDataPath>();

    private final Map<Long, BlockLocationWithDataPath> normal = new LinkedHashMap<Long, BlockLocationWithDataPath>();

    private final LongCompactHashSet replicating = new LongCompactHashSet();

    void putIfAbsent(ReplicateCommand cmd) {
        lock.lock();
        try {
            if (replicating.contains(cmd.getBlock())
                    || immediate.containsKey(cmd.getBlock())
                    || normal.containsKey(cmd.getBlock())) {
                return;
            }
            if (cmd.isImmediate()) {
                immediate.put(
                        cmd.getBlock(),
                        new BlockLocationWithDataPath(cmd.getBlock(),
                                cmd.getTargets()));
            } else {
                normal.put(
                        cmd.getBlock(),
                        new BlockLocationWithDataPath(cmd.getBlock(),
                                cmd.getTargets()));
            }
            notEmpty.signal();
        } finally {
            lock.unlock();
        }
    }

    private BlockLocationWithDataPath take(
            Map<Long, BlockLocationWithDataPath> map) {
        Iterator<BlockLocationWithDataPath> iter = map.values().iterator();
        BlockLocationWithDataPath lblock = iter.next();
        iter.remove();
        replicating.add(lblock.getBlock());
        return lblock;
    }

    BlockLocationWithDataPath take(long timeout) throws InterruptedException {
        long nanos = TimeUnit.MILLISECONDS.toNanos(timeout);
        lock.lock();
        try {
            for (;;) {
                if (!immediate.isEmpty()) {
                    return take(immediate);
                } else if (!normal.isEmpty()) {
                    return take(normal);
                } else {
                    try {
                        if (timeout > 0) {
                            if (nanos <= 0) {
                                return null;
                            }
                            nanos = notEmpty.awaitNanos(nanos);
                        } else {
                            notEmpty.await();
                        }
                    } catch (InterruptedException ie) {
                        notEmpty.signal(); // propagate to non-interrupted thread
                        throw ie;
                    }
                }
            }
        } finally {
            lock.unlock();
        }
    }

    void replicationDone(long block) {
        lock.lock();
        try {
            replicating.remove(block);
        } finally {
            lock.unlock();
        }
    }

    int size() {
        lock.lock();
        try {
            return immediate.size() + normal.size();
        } finally {
            lock.unlock();
        }
    }
}
