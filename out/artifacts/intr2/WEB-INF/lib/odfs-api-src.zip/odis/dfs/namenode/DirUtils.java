/**
 * @(#)DirUtils.java, 2011-11-18. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.ArrayList;
import java.util.List;

import odis.dfs.util.DfsUtils;

/**
 * INode name utilities.
 * 
 * @author zhangduo
 */
class DirUtils {
    private static final String DOUBLE_SEP = "" + INode.SEP + INode.SEP;

    /**
     * Normalize an ODFS path. Normalization done includes:
     * <ul>
     * <li>Trim the string (removing leading/trailing spaces/tabs)</li>
     * <li>Remove the trailing {@link INode#SEP} if one exists</li>
     * <li>Remove duplicate {@link INode#SEP}</li>
     * </ul>
     * -
     * 
     * @throws NullPointerException
     *             if the given path is null
     * @throws IllegalArgumentException
     *             if the given path is not start with {@link INode#SEP}
     */
    static String normalizePath(String path) {
        path = path.trim();
        if (path.charAt(0) != INode.SEP) {
            throw new IllegalArgumentException(path + " is not start with "
                    + INode.SEP);
        }
        if (path.length() == 1) { // root node 
            return path;
        }

        if (path.indexOf(DOUBLE_SEP) != -1) { // has duplicate SEPs
            StringBuilder sb = new StringBuilder(path.length() - 1);
            boolean sepOccur = false;
            for (int i = 0; i < path.length() - 1; i++) {
                char c = path.charAt(i);
                if (c == '/') {
                    if (sepOccur) {
                        continue;
                    } else {
                        sepOccur = true;
                    }
                } else {
                    sepOccur = false;
                }
                sb.append(c);
            }
            char lastChar = path.charAt(path.length() - 1);
            if (lastChar != INode.SEP) {
                sb.append(lastChar);
            }
            path = sb.toString();
        } else if (path.charAt(path.length() - 1) == INode.SEP) { // remove end SEP
            path = path.substring(0, path.length() - 1);
        }

        return path;
    }

    /**
     * Get parent path
     * 
     * @param path
     *            the path must be normalized using
     *            {@link #normalizePath(String)}
     * @return
     */
    static String getParent(String path) {
        return DfsUtils.getParent(path, INode.SEP, INode.STR_SEP);
    }

    /**
     * Get name.
     * 
     * @param path
     *            the path must be normalized using
     *            {@link #normalizePath(String)}
     * @return
     */
    static String getName(String path) {
        return DfsUtils.getName(path, INode.SEP, INode.STR_SEP);
    }

    /**
     * Get the longest common ancestor path of the two paths.
     * <p>
     * the path must be normalized using {@link #normalizePath(String)}
     * 
     * @param path1
     * @param path2
     * @return
     */
    static String getCommonAncestor(String path1, String path2) {
        String shortPath;
        String longPath;
        int idxMax;
        if (path1.length() < path2.length()) {
            shortPath = path1;
            longPath = path2;
            idxMax = path1.length();
        } else {
            shortPath = path2;
            longPath = path1;
            idxMax = path2.length();
        }
        int idx;
        for (idx = 0; idx < idxMax; idx++) {
            if (shortPath.charAt(idx) != longPath.charAt(idx)) {
                break;
            }
        }
        if (idx == idxMax
                && (longPath.length() == shortPath.length() || longPath.charAt(idx) == INode.SEP)) {
            return shortPath;
        }
        int lastSlash = shortPath.lastIndexOf(INode.SEP, idx - 1);
        if (lastSlash == 0) {
            return INode.STR_SEP;
        } else {
            return shortPath.substring(0, lastSlash);
        }
    }

    /**
     * Split the given to components without any /.
     * 
     * @param path
     *            the path must be normalized using
     *            {@link #normalizePath(String)}
     * @return
     */
    static String[] splitToComponents(String path) {
        if (path.length() == 1) {
            return new String[0];
        }
        List<String> components = new ArrayList<String>();
        int start = 1;
        int slashIdx = 0;
        while ((slashIdx = path.indexOf(INode.SEP, start)) >= 0) {
            components.add(path.substring(start, slashIdx));
            start = slashIdx + 1;
        }
        components.add(path.substring(start));
        return components.toArray(new String[0]);
    }

    /**
     * Check whether the given <code>path</code> is under the given
     * <code>dir</code>, or it is the <code>dir</code> itself.
     * 
     * @param dir
     * @param path
     *            the path must be normalized using
     *            {@link #normalizePath(String)}
     * @return
     */
    static boolean underOrIsDir(String dir, String path) {
        if (path.length() < dir.length()) {
            return false;
        }
        if (dir.length() == 1) {
            return true;
        }
        for (int i = 0; i < dir.length(); i++) {
            if (dir.charAt(i) != path.charAt(i)) {
                return false;
            }
        }
        if (path.length() == dir.length()) {
            return true;
        }
        return path.charAt(dir.length()) == INode.SEP;
    }

    /**
     * Check whether the given <code>path</code> is under the given
     * <code>dir</code>
     * 
     * @param dir
     * @param path
     *            the path must be normalized using
     *            {@link #normalizePath(String)}
     * @return
     */
    static boolean underDir(String dir, String path) {
        if (path.length() <= dir.length()) {
            return false;
        }
        if (dir.length() == 1) {
            return true;
        }
        for (int i = 0; i < dir.length(); i++) {
            if (dir.charAt(i) != path.charAt(i)) {
                return false;
            }
        }
        return path.charAt(dir.length()) == INode.SEP;
    }
}
