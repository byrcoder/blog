/**
 * @(#)BlockInputStream.java, 2012-12-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DataNodeRequest;
import odis.dfs.util.DfsUtils;
import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.ConnectionPool;
import odis.io.DirectByteArrayOutputStream;
import odis.io.InterruptibleSocket;
import odis.io.ReadWriteUtils;
import odis.io.TimeoutPolicy;
import toolbox.misc.LogFormatter;

/**
 * A stream that only reads one block of a file.
 * 
 * @author zhangkun, zhangduo
 */
abstract class BlockInputStream implements Closeable {

    protected final long block;

    protected final int blockIndex;

    protected final long startPos;

    protected final long endPos;

    protected BlockInputStream(long block, int blockIndex, long startPos,
            long endPos) {
        this.block = block;
        this.blockIndex = blockIndex;
        this.startPos = startPos;
        this.endPos = endPos;
    }

    /**
     * Try to seek to a position within the file. Return true if succeed. false
     * if the targetPos cannot be seeked to (maybe outside the block, or cannot
     * seek back). When false is returned, the caller has to close this block
     * stream and open a new one.
     * 
     * @param targetPos
     * @return
     * @throws IOException
     */
    boolean seek(long pos) throws IOException {
        if (pos < startPos || pos >= endPos) {
            return false;
        }
        return seekInBlock((int) (pos - startPos));
    }

    protected abstract boolean seekInBlock(int offset) throws IOException;

    /**
     * Try to read <tt>len</tt> bytes from stream and fill into the buf from
     * offset.
     * <p>
     * The implement classes need not to check params, DFSInputStream should
     * confirm the param is valid. And important, len must not be 0.
     * 
     * @param buf
     * @param off
     * @param len
     * @return number of bytes actually read. -1 if end of block is reached
     * @throws IOException
     */
    abstract int read(byte buf[], int off, int len) throws IOException;

    void setTimeout(long timeout) {}

    void setTimeoutPolicy(TimeoutPolicy timeoutPolicy) {}

    void setReadLengthHint(int length) {}

    private static final int MAX_SKIP_BUFFER_SIZE = 4 * 1024;

    /**
     * Skip n bytes.
     * 
     * @param n
     * @throws IOException
     */
    static void skip(InputStream in, long n) throws IOException {
        int size = (int) Math.min(MAX_SKIP_BUFFER_SIZE, n);
        byte[] skipBuffer = new byte[size];
        for (long remaining = n; remaining > 0;) {
            int read = in.read(skipBuffer, 0, (int) Math.min(size, remaining));
            if (read < 0) {
                throw new EOFException("Got EOF after " + (n - remaining)
                        + " bytes skipped when try to skip " + n + " bytes");
            }
            remaining -= read;
        }
    }

    @Override
    public abstract void close();
}

/**
 * Read block through network from datanode.
 * 
 * @author zhangduo
 */
abstract class NetworkedBlockInputStream extends BlockInputStream {

    protected final String dataNode;

    protected final InterruptibleSocket socket;

    protected int currentOffsetInBlock;

    protected NetworkedBlockInputStream(long block, int blockIndex,
            long startPos, long endPos, String dataNode,
            InterruptibleSocket socket, int initialOffsetInBlock) {
        super(block, blockIndex, startPos, endPos);
        this.dataNode = dataNode;
        this.socket = socket;
        this.currentOffsetInBlock = initialOffsetInBlock;
    }

    protected int readInt(byte[] buf) throws IOException {
        CDataInputStream.readFully(buf, 0, 4, socket.getInputStream());
        return CDataInputStream.readInt(buf, 0);
    }

    @Override
    void setTimeout(long timeout) {
        socket.setTimeout(timeout);
    }

    @Override
    void setTimeoutPolicy(TimeoutPolicy timeoutPolicy) {
        socket.setTimeoutPolicy(timeoutPolicy);
    }

    @Override
    public String toString() {
        return "[" + getClass().getSimpleName() + " dataNode=" + dataNode
                + ", socket=" + socket + ", currentOffsetInBlock="
                + currentOffsetInBlock + ", block=" + block + ", blockIndex="
                + blockIndex + ", startPos=" + startPos + ", endPos=" + endPos
                + "]";
    }

}

/**
 * Read block using DataNodeRequest with maxLength zero.
 * <p>
 * This means datanode will send all the data from start position to the end of
 * the block, and we will close the connection to datanode when close.
 * 
 * @author zhangduo
 */
class SequentialBlockInputStream extends NetworkedBlockInputStream {

    private final int maxSkip;

    SequentialBlockInputStream(long block, int blockIndex, long startPos,
            long endPos, String dataNode, long timeout,
            TimeoutPolicy timeoutPolicy, int initialOffsetInBlock, int maxSkip)
            throws IOException {
        super(block, blockIndex, startPos, endPos, dataNode,
                DfsUtils.createConnection(dataNode, timeout, timeoutPolicy),
                initialOffsetInBlock);
        this.maxSkip = maxSkip;
        boolean succ = false;
        try {
            DataNodeRequest req = new DataNodeRequest(
                    DataNodeRequest.Op.READ_BLOCK);
            DataNodeRequest.ReadBlockBody reqBody = (DataNodeRequest.ReadBlockBody) req.getBody();
            reqBody.setBlock(block);
            reqBody.setOffset(initialOffsetInBlock);
            byte[] buf = new byte[DataNodeRequest.ReadBlockBody.writableByteLength()];
            req.writeFields(new CDataOutputStream(
                    new DirectByteArrayOutputStream(buf)));
            socket.getOutputStream().write(buf);
            int length = readInt(buf);
            if (length != endPos - startPos - initialOffsetInBlock) {
                throw new IOException("DataNode sent data length(" + length
                        + ") doesn't match expected (" + (endPos - startPos)
                        + ")");
            }
            succ = true;
        } finally {
            if (!succ) {
                ReadWriteUtils.safeClose(socket);
            }
        }
    }

    @Override
    protected boolean seekInBlock(int offset) throws IOException {
        if (offset >= currentOffsetInBlock) {
            int toBeSkip = offset - currentOffsetInBlock;
            if (toBeSkip > maxSkip) {
                // skip length too large, I'd rather reconnect to
                // DataNode
                return false;
            }
            skip(socket.getInputStream(), toBeSkip);
            currentOffsetInBlock = offset;
            return true;
        }
        // seeking backward is not supported
        return false;
    }

    @Override
    int read(byte[] buf, int off, int len) throws IOException {
        int remaining = (int) (endPos - startPos) - currentOffsetInBlock;
        if (remaining <= 0) {
            return -1;
        }
        int read = socket.getInputStream().read(buf, off,
                Math.min(len, remaining));
        currentOffsetInBlock += read;
        return read;
    }

    @Override
    public void close() {
        ReadWriteUtils.safeClose(socket);
    }
}

/**
 * Read block using DataNodeRequest with a positive maxLength. You can use
 * {@link #setReadLengthHint(int)} to set this value.
 * <p>
 * This means datanode will only send no more than <tt>readLengthHint</tt> bytes
 * every time, so this is useful when you only want to read a small amount of
 * file(e.g., OMap). We will try our best to reuse connections to datanode, and
 * we usually return the connection to <tt>connPool</tt> when close.
 * 
 * @author zhangduo
 */
class RandomAccessBlockInputStream extends NetworkedBlockInputStream {

    private static final Logger LOG = LogFormatter.getLogger(RandomAccessBlockInputStream.class);

    private final ConnectionPool<InterruptibleSocket> connPool;

    private int readLengthHint;

    // the position of next byte to be read in current chunk
    private int chunkPos;

    // the length of current chunk
    private int chunkLength;

    private boolean trouble;

    private final DirectByteArrayOutputStream reqRawOut = new DirectByteArrayOutputStream(
            DataNodeRequest.ReadBlockBody.writableByteLength());

    private final CDataOutputStream reqOut = new CDataOutputStream(reqRawOut);

    RandomAccessBlockInputStream(long block, int blockIndex, long startPos,
            long endPos, String dataNode,
            ConnectionPool<InterruptibleSocket> connPool, long timeout,
            TimeoutPolicy timeoutPolicy, int initialOffsetInBlock,
            int readLengthHint) throws IOException {
        super(block, blockIndex, startPos, endPos, dataNode,
                DfsUtils.getConnection(connPool, dataNode, timeout,
                        timeoutPolicy), initialOffsetInBlock);
        this.connPool = connPool;
        this.readLengthHint = readLengthHint;
        boolean succ = false;
        try {
            getNewChunk();
            succ = true;
        } finally {
            if (!succ) {
                connPool.discardConnection(socket);
            }
        }
    }

    private void getNewChunk() throws IOException {
        DataNodeRequest req = new DataNodeRequest(DataNodeRequest.Op.READ_BLOCK);
        DataNodeRequest.ReadBlockBody reqBody = (DataNodeRequest.ReadBlockBody) req.getBody();
        reqBody.setBlock(block);
        reqBody.setOffset(currentOffsetInBlock);
        int expectedLength = Math.min(readLengthHint, (int) (endPos - startPos)
                - currentOffsetInBlock);
        reqBody.setMaxLength(expectedLength);
        reqRawOut.reset();
        req.writeFields(reqOut);
        reqRawOut.writeTo(socket.getOutputStream());
        int length = readInt(reqRawOut.getBuffer());
        if (length != expectedLength) {
            throw new IOException("DataNode sent data length(" + length
                    + ") doesn't match expected (" + (expectedLength) + ")");
        }
        chunkPos = 0;
        chunkLength = length;
    }

    @Override
    protected boolean seekInBlock(int offset) throws IOException {
        int delta = offset - currentOffsetInBlock;
        if (delta == 0) {
            return true;
        }
        trouble = true;
        // If the new offset fits in current chunk, just skip some bytes
        // and return
        if (delta > 0 && (chunkPos + delta < chunkLength)) {
            skip(socket.getInputStream(), delta);
            chunkPos += delta;
            currentOffsetInBlock = offset;
        } else {
            skip(socket.getInputStream(), chunkLength - chunkPos);
            currentOffsetInBlock = offset;
            getNewChunk();
        }
        trouble = false;
        return true;
    }

    @Override
    int read(byte[] buf, int off, int len) throws IOException {
        if (currentOffsetInBlock >= endPos - startPos) {
            return -1;
        }
        trouble = true;
        if (chunkPos == chunkLength) {
            getNewChunk();
        }
        int read = socket.getInputStream().read(buf, off,
                Math.min(len, chunkLength - chunkPos));
        if (read > 0) {
            chunkPos += read;
            currentOffsetInBlock += read;
        }
        trouble = false;
        return read;
    }

    @Override
    void setReadLengthHint(int readLengthHint) {
        this.readLengthHint = readLengthHint;
    }

    private boolean closed = false;

    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        if (!trouble) {
            if (chunkPos < chunkLength) {
                try {
                    skip(socket.getInputStream(), chunkLength - chunkPos);
                } catch (IOException e) {
                    LOG.log(Level.WARNING, "discard unused data in " + socket
                            + " failed", e);
                    connPool.discardConnection(socket);
                    return;
                }
            }
            connPool.releaseConnection(dataNode, socket);
        } else {
            connPool.discardConnection(socket);
        }

    }
}

/**
 * Read block from block cache.
 * 
 * @author zhangkun, zhangduo
 */
class BlockCacheBlockInputStream extends BlockInputStream {

    private final File cacheFile;

    private final RandomAccessFile in;

    BlockCacheBlockInputStream(long block, int blockIndex, long startPos,
            long endPos, File cacheFile,
            RandomAccessFile blockCacheInputStream, int initialOffsetInBlock)
            throws IOException {
        super(block, blockIndex, startPos, endPos);
        blockCacheInputStream.seek(startPos + initialOffsetInBlock);
        this.in = blockCacheInputStream;
        this.cacheFile = cacheFile;
    }

    @Override
    protected boolean seekInBlock(int offset) throws IOException {
        in.seek(startPos + offset);
        return true;
    }

    @Override
    int read(byte[] buf, int off, int len) throws IOException {
        long pos = in.getFilePointer();
        if (pos >= endPos) {
            return -1;
        }
        return in.read(buf, off, Math.min(len, (int) (endPos - pos)));
    }

    @Override
    public void close() {
        // Do nothing, DFSInputStream will close the input stream when closing.
    }

    @Override
    public String toString() {
        return "[BlockCacheBlockInputStream cacheFile="
                + cacheFile.getAbsolutePath() + ", block=" + block
                + ", blockIndex=" + blockIndex + ", startPos=" + startPos
                + ", endPos=" + endPos + "]";
    }

}

/**
 * Read block directly when we and datanode are on the same machine.
 * 
 * @author guodd, zhangduo
 */
class LocalDataNodeBlockInputStream extends BlockInputStream {

    private final File blockFile;

    private final RandomAccessFile in;

    LocalDataNodeBlockInputStream(long block, int blockIndex, long startPos,
            long endPos, File blockFile, int initialOffsetInBlock)
            throws IOException {
        super(block, blockIndex, startPos, endPos);
        this.blockFile = blockFile;
        this.in = new RandomAccessFile(blockFile, "r");
        long actualLength = in.length();
        if (actualLength != (endPos - startPos)) {
            ReadWriteUtils.safeClose(in);
            throw new IOException("Create LocalDatanodeBlockStream, file "
                    + blockFile.getAbsolutePath() + " length is wrong, actual "
                    + actualLength + ", expected " + (endPos - startPos));
        }
        if (initialOffsetInBlock > 0) {
            boolean succ = false;
            try {
                in.seek(initialOffsetInBlock);
                succ = true;
            } finally {
                if (!succ) {
                    ReadWriteUtils.safeClose(in);
                }
            }
        }
    }

    @Override
    protected boolean seekInBlock(int offset) throws IOException {
        in.seek(offset);
        return true;
    }

    @Override
    int read(byte[] buf, int off, int len) throws IOException {
        return in.read(buf, off, len);
    }

    @Override
    public void close() {
        ReadWriteUtils.safeClose(in);
    }

    @Override
    public String toString() {
        return "[LocalDataNodeBlockInputStream blockFile=" + blockFile
                + ", block=" + block + ", blockIndex=" + blockIndex
                + ", startPos=" + startPos + ", endPos=" + endPos + "]";
    }

}
