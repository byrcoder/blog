/**
 * @(#)DataNodeMetricsVaqueroReporter.java, 2012-4-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

import java.util.Arrays;

import odis.dfs.common.DFSConfig;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.StringUtils;

import vaquero.client.udp.AnalyzerMooee;

/**
 * @author zhangduo
 */
public class DataNodeMetricsVaqueroReporter {

    private final String cubType;

    private final AnalyzerMooee mooee;

    private void initVaqueroDraw() {
        int lev = 0;
        String drawName = cubType + "." + "load";
        mooee.addDraw(drawName, lev, "system load", "GAUGE");
        mooee.addProp(cubType + "." + DataNodeMetricsItem.SYSTEM_LOAD.name(),
                drawName);
        mooee.addProp(cubType + "." + DataNodeMetricsItem.PROCESSOR_NUM.name(),
                drawName);

        lev++;
        drawName = cubType + "." + "heap";
        mooee.addDraw(drawName, lev, "heap memory usage", "GAUGE");
        mooee.addProp(cubType + "." + DataNodeMetricsItem.HEAP_INIT.name(),
                drawName);
        mooee.addProp(cubType + "." + DataNodeMetricsItem.HEAP_USED.name(),
                drawName);
        mooee.addProp(
                cubType + "." + DataNodeMetricsItem.HEAP_COMMITTED.name(),
                drawName);
        mooee.addProp(cubType + "." + DataNodeMetricsItem.HEAP_MAX.name(),
                drawName);

        lev++;
        drawName = cubType + "." + "non heap";
        mooee.addDraw(drawName, lev, "non heap memory usage", "GAUGE");
        mooee.addProp(cubType + "." + DataNodeMetricsItem.NON_HEAP_INIT.name(),
                drawName);
        mooee.addProp(cubType + "." + DataNodeMetricsItem.NON_HEAP_USED.name(),
                drawName);
        mooee.addProp(
                cubType + "." + DataNodeMetricsItem.NON_HEAP_COMMITTED.name(),
                drawName);
        mooee.addProp(cubType + "." + DataNodeMetricsItem.NON_HEAP_MAX.name(),
                drawName);

        lev++;
        drawName = cubType + "." + "block number";
        mooee.addDraw(drawName, lev, "block number", "GAUGE");
        mooee.addProp(cubType + "." + DataNodeMetricsItem.BLOCK_NUM.name(),
                drawName);

        lev++;
        drawName = cubType + "." + "block size";
        mooee.addDraw(drawName, lev, "block size", "GAUGE");
        mooee.addProp(cubType + "." + DataNodeMetricsItem.BLOCK_SIZE.name(),
                drawName);

        lev++;
        drawName = cubType + "." + "concurrency";
        mooee.addDraw(drawName, lev, "read concurrency and write concurrency",
                "GAUGE");
        mooee.addProp(
                cubType + "." + DataNodeMetricsItem.CONCURRENT_READ.name(),
                drawName);
        mooee.addProp(
                cubType + "." + DataNodeMetricsItem.CONCURRENT_WRITE.name(),
                drawName);
        mooee.addProp(cubType + "."
                + DataNodeMetricsItem.CONCURRENT_REPLICATION.name(), drawName);

        for (DataNodeMetricsItem item: DataNodeMetricsItem.values()) {
            if (item.offset() <= DataNodeMetricsItem.CONCURRENT_REPLICATION.offset()) {
                continue;
            }
            lev++;
            drawName = cubType + "." + item.name().toLowerCase();
            String dsType = item.name().endsWith("_DELAY") ? "GAUGE"
                    : "COUNTER";
            mooee.addDraw(drawName, lev, item.name(), dsType);
            mooee.addProp(cubType + "." + item.name(), drawName);
        }
        mooee.moo();
    }

    public DataNodeMetricsVaqueroReporter(Configuration conf,
            String datanodeName) {
        String vaqueroAddr = conf.getString(DFSConfig.METRICS_VAQUERO_ADDR);
        if (StringUtils.isBlank(vaqueroAddr)) {
            mooee = null;
            cubType = null;
        } else {
            String[] ss = vaqueroAddr.split(":");
            String product = conf.getString(DFSConfig.METRICS_VAQUERO_PRODUCT);
            String cubName = datanodeName.replaceAll("[:/]+", "_");
            String cubType = "dn_" + cubName;
            mooee = new AnalyzerMooee(ss[0], Integer.parseInt(ss[1]), product,
                    cubType, cubName);
            this.cubType = cubType;
            initVaqueroDraw();
        }
    }

    private long[] prevMetrics = null;

    public void report(long[] metrics) {
        if (mooee == null) {
            return;
        }
        for (DataNodeMetricsItem item: DataNodeMetricsItem.values()) {
            double value;
            if (item.name().endsWith("_DELAY")) {
                if (prevMetrics == null) {
                    value = Double.NaN;
                } else {
                    long countDelta = metrics[item.offset() - 2]
                            - prevMetrics[item.offset() - 2];
                    if (countDelta <= 0) {
                        value = Double.NaN;
                    } else {
                        long delayDelta = metrics[item.offset()]
                                - prevMetrics[item.offset()];
                        value = (double) delayDelta / countDelta / 1000;
                    }
                }
            } else {
                value = metrics[item.offset()];
                if (item == DataNodeMetricsItem.SYSTEM_LOAD) {
                    value /= 100;
                }
            }
            mooee.report(cubType + "." + item.name(), value);
        }
        mooee.moo();
        if (prevMetrics == null) {
            prevMetrics = Arrays.copyOf(metrics, metrics.length);
        } else {
            System.arraycopy(metrics, 0, prevMetrics, 0, metrics.length);
        }
    }
}
