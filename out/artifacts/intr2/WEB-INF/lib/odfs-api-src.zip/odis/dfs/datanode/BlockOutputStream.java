/**
 * @(#)BlockOutputStream.java, 2012-12-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.logging.Logger;

import odis.dfs.common.FSConstants;
import odis.io.ReadWriteUtils;
import odis.util.unsafe.UnsafeHelper;
import sun.nio.ch.DirectBuffer;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class BlockOutputStream implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(BlockOutputStream.class);

    private final File file;

    private final FileOutputStream out;

    private final FileChannel channel;

    private int adler32 = 1;

    BlockOutputStream(File file) throws IOException {
        try {
            if (file.createNewFile()) {
                this.file = file;
                this.out = new FileOutputStream(file);
                this.channel = this.out.getChannel();
                return;
            }
        } catch (IOException e) {
            if (e.getMessage().startsWith(MSG_NO_SPACE_LEFT_ON_DEVICE)) {
                throw e;
            } else {
                throw new DataNodeFatalException(e);
            }
        }
        throw new IOException("Can not overwrite existing block file "
                + file.getAbsolutePath());
    }

    void write(ByteBuffer bb) throws IOException {
        adler32 = UnsafeHelper.adler32(adler32, ((DirectBuffer) bb).address()
                + bb.position(), bb.remaining());
        try {
            do {
                channel.write(bb);
            } while (bb.hasRemaining());
        } catch (IOException e) {
            if (e.getMessage().startsWith(MSG_NO_SPACE_LEFT_ON_DEVICE)) {
                throw e;
            } else {
                throw new DataNodeFatalException(e);
            }
        }
    }

    void sync() throws IOException {
        try {
            out.getFD().sync();
        } catch (IOException e) {
            if (e.getMessage().startsWith(MSG_NO_SPACE_LEFT_ON_DEVICE)) {
                throw e;
            } else {
                throw new DataNodeFatalException(e);
            }
        }
    }

    int abandon() {
        ReadWriteUtils.safeClose(out);
        int len = (int) file.length();
        if (!file.delete()) {
            LOG.warning("Cannot delete " + file.getAbsolutePath()
                    + " when abandon");
        }
        return len;
    }

    void close() throws IOException {
        try {
            out.close();
        } catch (IOException e) {
            if (e.getMessage().startsWith(MSG_NO_SPACE_LEFT_ON_DEVICE)) {
                throw e;
            } else {
                throw new DataNodeFatalException(e);
            }
        }
    }

    int fileLength() {
        return (int) file.length();
    }

    long getAdler32() {
        return adler32 & 0xFFFFFFFFL;
    }

}
