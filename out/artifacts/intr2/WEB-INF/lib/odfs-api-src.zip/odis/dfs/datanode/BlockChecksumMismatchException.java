/**
 * @(#)BlockChecksumMismatchException.java, 2012-12-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.datanode;

import java.io.IOException;

import toolbox.text.util.HexString;

/**
 * @author zhangduo
 */
public class BlockChecksumMismatchException extends IOException {

    private static final long serialVersionUID = -5671811160239322314L;

    final long block;

    final long oc;

    final long cc;

    public BlockChecksumMismatchException(long block, long oc, long cc) {
        super(block + " checksum mismatch, expected "
                + HexString.intToPaddedHex((int) oc) + ", actual "
                + HexString.intToPaddedHex((int) cc));
        this.block = block;
        this.oc = oc;
        this.cc = cc;
    }

}
