package odis.dfs.journal.qjournal.server;

import java.io.IOException;

public class JNException extends IOException {
    private static final long serialVersionUID = 1177019435422626838L;

    public static final int UNKNOWN = 0;

    public static final int ILLEGAL_PARAM = UNKNOWN + 1;

    public static final int ILLEGAL_STATE = ILLEGAL_PARAM + 1;
    
    public static final int ILLEGAL_CALL_ORDER = ILLEGAL_STATE + 1;
    
    public static final int ILLEGAL_EPOCH = ILLEGAL_CALL_ORDER + 1;
    
    public static final int ILLEGAL_CHECKSUM = ILLEGAL_EPOCH + 1;
    
    public static final int ILLEGAL_JOURNAL_LENGTH = ILLEGAL_CHECKSUM + 1;
    
    private int code;

    public int getCode() {
        return code;
    }

    public JNException(String message) {
        super(message);
        this.code = 0;
    }
    
    public JNException(int code, String message) {
        super(message);
        this.code = code;
    }

    public JNException(int code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }
    
    public JNException(int code, Throwable cause) {
        super(cause);
        this.code = code;
    }
}
