/**
 * @(#)DFSShell.java, 2013-1-8. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jline.console.ConsoleReader;
import jline.console.completer.Completer;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.FSConstants;
import odis.dfs.util.DfsUtils;
import odis.io.FileSystem;
import odis.io.Path;
import toolbox.misc.ClassUtils;
import toolbox.misc.cli.ITool;
import toolbox.misc.cli.OptionParseException;

/**
 * A simple command-line DFS client.
 * 
 * @author zhangduo
 */
public class DFSShell implements ITool, FSConstants {

    private static final Map<String, DFSShellCommand> CMDS;
    static {
        Map<String, DFSShellCommand> cmds = new HashMap<String, DFSShellCommand>();
        try {
            String[] classNames = ClassUtils.findClassesInPackage(
                    DFSShellCommand.class.getPackage().getName(),
                    Collections.<String>emptyList(),
                    Collections.<String>emptyList());
            for (String className: classNames) {
                Class<?> clazz = Class.forName(className);
                if (!DFSShellCommand.class.isAssignableFrom(clazz)
                        || !clazz.isAnnotationPresent(DFSShellCommandName.class)
                        || Modifier.isAbstract(clazz.getModifiers())) {
                    continue;
                }
                for (String cmdName: clazz.getAnnotation(
                        DFSShellCommandName.class).value()) {
                    cmds.put(
                            cmdName,
                            clazz.asSubclass(DFSShellCommand.class).newInstance());
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        CMDS = Collections.unmodifiableMap(cmds);
    }

    private InputStream in = System.in;

    private PrintStream out = System.out;

    private PrintStream err = System.err;

    public void setIn(InputStream in) {
        this.in = in;
    }

    public void setOut(PrintStream out) {
        this.out = out;
    }

    public void setErr(PrintStream err) {
        this.err = err;
    }

    private void help(boolean admin) {
        if (admin) {
            out.println("WARNING: odfs shell commands ONLY used by administrators");
            out.println("Commands:\n"
                    + " fsck                        run consistency check\n"
                    + " setsvrready [host:port]     enable the dfs service to receive requests\n"
                    + " setspacequota <dir> <quota> change directory quota to new value\n"
                    + " setnamequota <dir> <quota>  change directory name quota to new value\n"
                    + " setrcv <path>               set the path to be recoverable under which deleted files or directories will be put into trash can\n"
                    + " unsetrcv <path>             set the path to be unrecoverable\n"
                    + " protect <path>              protect a file or a directory.\n"
                    + "                             A path under protection will not be deleted or renamed.\n"
                    + " unprotect <path>            unprotect a file or a directory\n"
                    + " computecontentslengthandsubitemnum recalculate contents length and sub item number for the filesystem\n"
                    + " removetrash <trash>         remove the trash path from the trash can\n"
                    + " groups                      print group-user information on shell\n"
                    + " groupadd <group> <user>     add user to the group\n"
                    + " groupdel <group> [user]     if no user speicified, delete the group, otherwise delete user from the group.\n"
                    + " dirproperties                print dir properties");
        } else {
            out.println("odfs  shell -fs filesystem ui|<command>");
            out.println("1. ui: enter interactive shell");
            out.println("2. commands:\n"
                    + " --------------------------------- basic ----------------------------------\n"
                    + " ls [-t] [-r] [-c] [<path>]  list a directory, or the current directly\n"
                    + "                             with -t, sort by modification time(default by name)\n"
                    + "                             with -r, reverse sort\n"
                    + "                             with -c, will display desired replication number\n"
                    + " stat <path>            display file or directory status\n"
                    + " cd <path>              set a directory as the current directory\n"
                    + " du [<path>]            estimate file space usage\n"
                    + " nu [<path>]            estimate sub item(dir and file) usage\n"
                    + " find [-d depth] [<path>]  search the directory tree rooted at each given path\n"
                    + " cat <file>             display content of a file\n"
                    + " mv <src> <dst>         rename a file or directory\n"
                    + " cp <src> <dst>         copy a file\n"
                    + " ln <src> <dst>         make a link of file or directory\n"
                    + " rm [-r] [-f] [-p] <path>   delete a file or directory (no undo, be CAREFUL!)\n"
                    + "                            with -r (recursively), delete the src directory and its contents recursively\n"
                    + "                            with -f (forcely), delete the src directly without prompt\n"
                    + "                            with -p (permanently), delete the src permanently\n"
                    + " chown [-r] <owner> <group> <path>  change a file or directory's owner and group\n"
                    + "                                    with -r (recursively), effects all files and subdirs under the path\n"
                    + " chmod [-r] <permission> <path>  change a file or directory's permission\n"
                    + "                                 permission should be 3 bits octal number\n"
                    + "                                     rwxrwxrwx -> 777\n"
                    + "                                     rwxr-xr-- -> 754\n"
                    + "                                 with -r (recursively), effects all files and subdirs under the path\n"
                    + " setreplication [-r] <path> <rep>  set the desired replication number\n"
                    + "                                   with -r (recursively), effects all files and subdirs under the path\n"
                    + " getreplication <path>  get the desired replication number\n"
                    + " recover <trash> <dst>  recover trash to the target file or directory\n"
                    + " rcvstate <path>        show the path is recoverable or not\n"
                    + " protectstate <path>    show the path is protected or not.\n"
                    + " getspacequota <dir>        get the directory quota\n"
                    + " getnamequota <dir>         get the directory name quota\n"
                    + " put <localsrc> [<dst>] uploads a local file\n"
                    + " get <src> [<localdst>] download a file to local\n"
                    + " mput <pattern> [<dstdir]   uploads multiple local files with wildcards\n"
                    + " mget <pattern> [<localdst] download multiple files with wildcards\n"
                    + " mirror [-R] <dir> [<dst>]  download a directory recursively\n"
                    + "                        with -R (reverse), upload a local dir recursively\n"
                    + " mkdir [-n nrep] <path> create a new dir (given number of replications)\n"
                    + " lockstate <path>       show the lock state of a file\n"
                    + " ------------------------------ diagnostic --------------------------------\n"
                    + " blkinfo <file>         get block information of a file\n"
                    + " checkfile <file>       check (and repair if necessary) inconsistent blocks of a file\n"
                    + " checkblock <block>     check (and repair if necessary) a block for consistency");
        }
    }

    private final class UICompleter implements Completer {

        private final DistributedFileSystem dfs;

        public UICompleter(DistributedFileSystem dfs) {
            this.dfs = dfs;
        }

        @Override
        public int complete(String buffer, int cursor,
                List<CharSequence> candidates) {
            String lastPart;
            if (buffer == null) {
                buffer = "";
                lastPart = "";
            } else {
                lastPart = buffer.substring(buffer.lastIndexOf(' ') + 1);
            }
            String path;
            if (lastPart.startsWith(DistributedFileSystem.FILE_SEPARATOR)) {
                path = lastPart;
            } else {
                path = DfsUtils.canonicalize(dfs.getWorkingDir()
                        + DistributedFileSystem.FILE_SEPARATOR + lastPart);
            }
            String prefix;
            if (lastPart.length() > 0
                    && !lastPart.endsWith(DistributedFileSystem.FILE_SEPARATOR)) {
                prefix = DfsUtils.getName(path,
                        DistributedFileSystem.FILE_SEPARATOR_CHAR,
                        DistributedFileSystem.FILE_SEPARATOR);
                path = DfsUtils.getParent(path,
                        DistributedFileSystem.FILE_SEPARATOR_CHAR,
                        DistributedFileSystem.FILE_SEPARATOR);
            } else {
                prefix = "";
            }
            //            err.println();
            //            err.println("buffer=" + buffer + ", lastPart=" + lastPart
            //                    + ", path=" + path + ", prefix=" + prefix);
            DFSFileStatus[] files;
            try {
                files = dfs.getDFSClient().listFiles(path);
            } catch (IOException e) {
                e.printStackTrace(err);
                return -1;
            }
            if (files == null) {
                return -1;
            }
            for (DFSFileStatus file: files) {
                if (file.getName().startsWith(prefix)) {
                    if (file.isDir()) {
                        candidates.add(file.getName() + "/");
                    } else {
                        candidates.add(file.getName());
                    }
                }
            }
            int idx = lastPart.lastIndexOf(DistributedFileSystem.FILE_SEPARATOR_CHAR) + 1;
            return buffer.length() - lastPart.length() + idx;
        }
    }

    private void ui(DistributedFileSystem dfs) throws IOException {
        ConsoleReader reader = new ConsoleReader(in, out);
        reader.addCompleter(new UICompleter(dfs));
        for (String line; (line = reader.readLine("[" + dfs.getWorkingDir()
                + "]")) != null;) {
            try {
                String[] args = DfsUtils.parseCmd(line);
                if (args.length == 0) {
                    continue;
                }
                if ("help".equals(args[0])) {
                    if (args.length > 1 && "admin".equals(args[1])) {
                        help(true);
                    } else {
                        help(false);
                    }
                } else if ("clear".equals(args[0])) {
                    reader.clearScreen();
                } else if ("quit".equals(args[0]) || "exit".equals(args[0])) {
                    break;
                } else {
                    DFSShellCommand cmd = CMDS.get(args[0]);
                    if (cmd == null) {
                        err.println("Unrecognized command: " + args[0]);
                        continue;
                    }
                    cmd.exec(new DFSShellCommand.Context(dfs, in, out, err,
                            reader), Arrays.copyOfRange(args, 1, args.length));
                }
            } catch (IllegalArgumentException e) {
                err.println(e.getMessage());
            } catch (OptionParseException e) {
                err.println(e.getMessage());
            } catch (Exception e) {
                e.printStackTrace(err);
            }
        }
    }

    @Override
    public void usage(PrintWriter out) {
        out.println("Usage: odis.sh odfs ...");
        out.println("  1. odfs help [admin]");
        out.println("     display detail help message of operations");
        out.println("  2. odfs -fs filesystem ui|<...>");
        out.println("     ui     enter interactive shell");
        out.println("     ...    other commands");
    }

    @Override
    public String comment() {
        return "ODFS shell command line tool";
    }

    @Override
    public boolean exec(String[] args) throws Exception {
        PrintWriter out = new PrintWriter(this.out, true);
        if (args.length < 1) {
            usage(out);
            return false;
        }
        if ("help".equals(args[0])) {
            if (args.length > 1 && "admin".equals(args[1])) {
                help(true);
            } else {
                help(false);
            }
            return true;
        }
        DistributedFileSystem dfs;
        int remainingArgsStart;
        if ("-fs".equals(args[0])) {
            if (args.length < 3) {
                usage(out);
                return false;
            }
            dfs = (DistributedFileSystem) FileSystem.getNamed(args[1]);
            remainingArgsStart = 2;
        } else {
            dfs = (DistributedFileSystem) DFSClientContext.getDefaultFileSystem();
            remainingArgsStart = 0;
        }
        // change working directory to /
        dfs.setWokringDir(new Path(DistributedFileSystem.FILE_SEPARATOR));
        try {
            if ("ui".equals(args[remainingArgsStart])) {
                ui(dfs);
            } else {
                DFSShellCommand cmd = CMDS.get(args[remainingArgsStart]);
                if (cmd == null) {
                    err.println("Unrecognized command: "
                            + args[remainingArgsStart]);
                    return false;
                }
                cmd.exec(new DFSShellCommand.Context(dfs, in, this.out, err,
                        null), Arrays.copyOfRange(args, remainingArgsStart + 1,
                        args.length));
            }
        } finally {
            dfs.close();
        }
        return true;
    }
}
