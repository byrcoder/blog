/**
 * @(#)DFSInputStream.java, 2012-12-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.DFSClientConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.util.DfsUtils;
import odis.io.ConnectionPool;
import odis.io.FSInputStream;
import odis.io.InterruptibleSocket;
import odis.io.ReadWriteUtils;
import odis.io.TimeoutPolicy;
import odis.util.ThreadLocalRandomData;
import toolbox.misc.EmptyInstance;
import toolbox.misc.LogFormatter;

/**
 * FSInputStream that reading data from ODFS.
 * 
 * @author zhangduo
 */
public class DFSInputStream extends FSInputStream implements FSConstants {

    private static final Logger LOG = LogFormatter.getLogger(DFSInputStream.class);

    private final AtomicLong counter;

    private final IdleInputStreamTracker idleTracker;

    private final ConnectionPool<InterruptibleSocket> connPool;

    private final String file;

    private final int flags;

    private final String clientName;

    private final long[] blockStarts;

    private final long fileLength;

    private final BlockCache blockCache;

    private final int maxOpenRetryTimes;

    private final NameNodeWatcher nameNodeWatcher;

    private final String localHost;

    private final int sequentialBlockInputMaxSkip;

    private BlockSizeLocationWithDataPath[] blocks;

    private BlockInputStream blockInput;

    private RandomAccessFile blockCacheInput;

    private long pos;

    private boolean readFromLocalHost;

    private long timeout;

    private TimeoutPolicy timeoutPolicy = TimeoutPolicy.RESPONSE_IN_TIME;

    private int readLengthHint;

    private void openInfo() throws IOException {
        BlockSizeLocationWithDataPath[] blocks = nameNodeWatcher.getNameNode().getFileBlockLocations(
                clientName, file);
        if (blocks == null) {
            throw new FileNotFoundException("File " + file + " does not exist");
        }

        if (blocks[blocks.length - 1].getLen() <= 0) {
            LOG.warning("The last block "
                    + blocks[blocks.length - 1].getBlock() + " for file "
                    + file + " has length 0 or -1. Will be ignored.");
            blocks = Arrays.copyOf(blocks, blocks.length - 1);
        }
        if (this.blocks != null) {
            if (this.blocks.length != blocks.length) {
                throw new IOException("Blocklist for " + file
                        + " now has different length. Used to be "
                        + this.blocks.length + ", now is " + blocks.length);
            }
            for (int i = 0; i < blocks.length; i++) {
                if (this.blocks[i].getBlock() != blocks[i].getBlock()) {
                    throw new IOException("block list is change for " + file
                            + ": " + i + "th block ["
                            + this.blocks[i].getBlock() + "] --> ["
                            + blocks[i].getBlock() + "]");
                }
            }
        }
        this.blocks = blocks;
    }

    DFSInputStream(NameNodeWatcher nameNodeWatcher, String file, int flags,
            String clientName, String localHost,
            IdleInputStreamTracker idleTracker, BlockCache blockCache,
            ConnectionPool<InterruptibleSocket> connPool, AtomicLong counter,
            DFSClientConfig conf) throws IOException {
        this.nameNodeWatcher = nameNodeWatcher;
        this.file = file;
        this.flags = flags;
        this.clientName = clientName;
        this.localHost = localHost;
        this.idleTracker = idleTracker;
        this.blockCache = blockCache;
        this.connPool = connPool;
        this.counter = counter;
        this.timeout = conf.getDatanodeReadTimeout();
        this.maxOpenRetryTimes = conf.getOpenMaxRetryTime();
        this.sequentialBlockInputMaxSkip = conf.getSequentialReaderMaxSkip();
        this.readLengthHint = conf.getRandomReadLengthHint();
        openInfo();
        blockStarts = new long[blocks.length + 1];
        for (int i = 0; i < blocks.length; i++) {
            blockStarts[i + 1] = blockStarts[i] + blocks[i].getLen();
        }
        this.fileLength = blockStarts[blocks.length];
        if ((flags & DFSClient.IS_BLOCKCACHE) != 0) {
            blockCache.registerReader(BlockCache.getBlockCacheFileId(file,
                    blocks));
        }
    }

    @Override
    public synchronized void setReadFromLocalHost(boolean readFromLocalHost) {
        this.readFromLocalHost = readFromLocalHost;
    }

    @Override
    public synchronized void setTimeout(long timeout) {
        this.timeout = timeout;
        if (blockInput != null) {
            blockInput.setTimeout(timeout);
        }
    }

    @Override
    public synchronized void setTimeoutPolicy(TimeoutPolicy timeoutPolicy) {
        this.timeoutPolicy = timeoutPolicy;
        if (blockInput != null) {
            blockInput.setTimeoutPolicy(timeoutPolicy);
        }
    }

    @Override
    public synchronized void setReadLengthHint(int readLengthHint) {
        this.readLengthHint = readLengthHint;
        if (blockInput != null) {
            blockInput.setReadLengthHint(readLengthHint);
        }
    }

    @Override
    public synchronized void setIdleHint() {
        closeBlockInput();
    }

    private final byte[] singleByte = new byte[1];

    @Override
    public synchronized int read() throws IOException {
        int ret = read(singleByte);
        if (ret < 0) {
            return ret;
        } else {
            return singleByte[0] & 0xFF;
        }
    }

    private void closeBlockInput() {
        ReadWriteUtils.safeClose(blockInput);
        blockInput = null;
    }

    private boolean tryOpenBlockCache(int blockIndex, int offset) {
        if ((flags & DFSClient.IS_BLOCKCACHE) == 0) {
            return false;
        }
        try {
            String fileId = BlockCache.getBlockCacheFileId(file, blocks);
            if (blockCache.cached(fileId, blockIndex)) {
                if (blockCacheInput == null) {
                    blockCacheInput = blockCache.openBlockCache(fileId);
                }
                blockInput = new BlockCacheBlockInputStream(
                        blocks[blockIndex].getBlock(), blockIndex,
                        blockStarts[blockIndex], blockStarts[blockIndex + 1],
                        new File(fileId), blockCacheInput, offset);
                return true;
            } else {
                blockCache.scheduleBlock(blocks[blockIndex], blockIndex,
                        fileId, blockStarts[blockIndex]);
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Open block cache for " + file + " failed",
                    e);
        }
        return false;
    }

    private boolean isLocalDataNode(String dataNode) {
        return localHost.equals(BlockLocationWithDataPath.getHostFromLocation(dataNode));
    }

    private void markDataNodeAsDead(int blockIndex, String dataNode) {
        BlockSizeLocationWithDataPath block = blocks[blockIndex];
        String[] locs = block.getLocations();
        for (int i = 0; i < locs.length; i++) {
            if (locs[i].equals(dataNode)) {
                if (locs.length == 1) {
                    locs = EmptyInstance.STRINGS;

                } else {
                    String[] newLocs = new String[locs.length - 1];
                    if (i > 0) {
                        System.arraycopy(locs, 0, newLocs, 0, i);
                    }
                    if (i < locs.length - 1) {
                        System.arraycopy(locs, i + 1, newLocs, i, locs.length
                                - i - 1);
                    }
                    locs = newLocs;
                }
                break;
            }
        }
        LOG.info("Mark " + dataNode + " as dead for " + blockIndex
                + "th block " + block.getBlock() + " of file " + file
                + ", remaining dataNodes are " + Arrays.toString(locs));
        block.setLocations(locs);
    }

    private void markDataNodeAsDead(BlockInputStream blockInput) {
        if (blockInput instanceof NetworkedBlockInputStream) {
            NetworkedBlockInputStream networkedBlockInput = (NetworkedBlockInputStream) blockInput;
            markDataNodeAsDead(networkedBlockInput.blockIndex,
                    networkedBlockInput.dataNode);
        }
    }

    private String bestNode(int blockIndex) {
        String[] locs = blocks[blockIndex].getLocations();
        if (locs.length == 0) {
            return null;
        }
        if (locs.length == 1) {
            // we have no choice.
            return locs[0];
        }
        if (readFromLocalHost) {
            for (String dataNode: locs) {
                if (isLocalDataNode(dataNode)) {
                    return dataNode;
                }
            }
        }
        ThreadLocalRandomData rand = ThreadLocalRandomData.current();
        return locs[rand.nextInt(locs.length)];
    }

    private void openBlock(int blockIndex, int offset, long startTime)
            throws IOException {
        if (blockIndex < 0 || blockIndex >= blocks.length
                || offset > blocks[blockIndex].getLen()) {
            throw new IOException("position out of file's range, blockIndex="
                    + blockIndex + ", offset=" + offset);
        }
        closeBlockInput();
        if (tryOpenBlockCache(blockIndex, offset)) {
            return;
        }
        for (int retry = 0;; retry++) {
            String dataNode = bestNode(blockIndex);
            if (dataNode == null) {
                LOG.warning("Could not obtain " + blockIndex + "th block "
                        + blocks[blockIndex].getBlock() + " for file " + file
                        + " " + " from any live node, retry = " + retry);
                if (maxOpenRetryTimes >= 0 && retry >= maxOpenRetryTimes) {
                    throw new IOException("Could not obtain block "
                            + blocks[blockIndex] + " for file " + file
                            + " after retries for " + retry + " times.");
                }
                if (timeout > 0) {
                    long maxWaitTime = timeoutPolicy == TimeoutPolicy.COMPLETE_IN_TIME ? timeout
                            - (System.currentTimeMillis() - startTime)
                            : timeout;
                    if (maxWaitTime <= 0) {
                        throw new IOException("Read retry timeout for " + file
                                + ", timeout = " + timeout);
                    }
                    DfsUtils.waitExpTime(retry, maxWaitTime);
                } else {
                    DfsUtils.waitExpTime(retry);
                }
                openInfo();
                continue;
            }
            long blockId = blocks[blockIndex].getBlock();
            long startPos = blockStarts[blockIndex];
            long endPos = blockStarts[blockIndex + 1];
            try {
                if (readFromLocalHost && isLocalDataNode(dataNode)) {
                    File blockFile = DfsUtils.blockId2File(
                            new File(
                                    BlockLocationWithDataPath.getDataPathFromLocation(dataNode)),
                            blockId, BLOCK_FILE_SUFFIX);
                    blockInput = new LocalDataNodeBlockInputStream(blockId,
                            blockIndex, startPos, endPos, blockFile, offset);
                } else if ((flags & DFSClient.IS_RANDOMREAD) != 0) {
                    blockInput = new RandomAccessBlockInputStream(blockId,
                            blockIndex, startPos, endPos, dataNode, connPool,
                            timeout, timeoutPolicy, offset, readLengthHint);
                } else {
                    blockInput = new SequentialBlockInputStream(blockId,
                            blockIndex, startPos, endPos, dataNode, timeout,
                            timeoutPolicy, offset, sequentialBlockInputMaxSkip);
                }
                break;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "open connection to " + dataNode
                        + " for " + blockIndex + "th block "
                        + blocks[blockIndex].getBlock() + " of file " + file
                        + " failed", e);
                markDataNodeAsDead(blockIndex, dataNode);
                if (maxOpenRetryTimes >= 0 && retry >= maxOpenRetryTimes) {
                    throw new IOException("Could not obtain block "
                            + blocks[blockIndex] + " for file " + file
                            + " after retries for " + retry + " times.");
                }
            }
        }
    }

    /**
     * Open a block stream for reading on current pos
     */
    private void openBlock(long startTime) throws IOException {
        int blockIndex = Arrays.binarySearch(blockStarts, pos);
        if (blockIndex < 0) {
            blockIndex = -blockIndex - 2;
        }
        int offset = (int) (pos - blockStarts[blockIndex]);
        openBlock(blockIndex, offset, startTime);
    }

    @Override
    public synchronized int read(byte[] buf, int off, int len)
            throws IOException {
        assertOpen();
        idleTracker.updateTTL(this);
        // sanity check
        if (off < 0 || len < 0 || off + len > buf.length) {
            throw new ArrayIndexOutOfBoundsException(
                    "bad offset and length ( off = " + off + ",len = " + len
                            + ", buf_size = " + buf.length);
        }
        if (len == 0) {
            return 0;
        }
        if (pos >= fileLength) {
            return -1;
        }
        long startTime = System.currentTimeMillis();
        for (;;) {
            if (timeoutPolicy == TimeoutPolicy.COMPLETE_IN_TIME && timeout > 0
                    && System.currentTimeMillis() - startTime > timeout) {
                throw new IOException("Read retry timeout for " + file
                        + ", timeout = " + timeout);
            }
            if (blockInput == null || pos > blockInput.endPos) {
                openBlock(startTime);
            } else if (pos == blockInput.endPos) {
                // no need to binary search, a little faster
                openBlock(blockInput.blockIndex + 1, 0, startTime);
            }
            int ret;
            try {
                ret = blockInput.read(buf, off, len);
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Read error for " + file + " on "
                        + blockInput, e);
                markDataNodeAsDead(blockInput);
                closeBlockInput();
                continue;
            }
            if (ret > 0) {
                pos += ret;
                counter.addAndGet(ret);
            }
            return ret;
        }
    }

    @Override
    public synchronized void seek(long pos) throws IOException {
        assertOpen();
        if (pos < 0) {
            throw new IOException("Cannot seek to negative position " + pos);
        }
        if (pos > fileLength) {
            throw new IOException("Seeking beyond file end: " + pos
                    + ", file length=" + fileLength);
        }
        idleTracker.updateTTL(this);
        if (pos == this.pos) {
            return;
        }
        this.pos = pos;
        if (this.pos == fileLength) {
            return;
        }

        if (blockInput != null) {
            boolean succ = false;
            try {
                if (!blockInput.seek(pos)) {
                    closeBlockInput();
                }
                succ = true;
            } finally {
                if (!succ) {
                    markDataNodeAsDead(blockInput);
                    closeBlockInput();
                }
            }
        }
    }

    @Override
    public synchronized long skip(long n) throws IOException {
        long destPos = Math.min(pos + n, fileLength);
        seek(destPos);
        return destPos - pos;
    }

    @Override
    public synchronized int available() throws IOException {
        assertOpen();
        long remaining = fileLength - pos;
        return (int) Math.min(Integer.MAX_VALUE, remaining);
    }

    @Override
    public synchronized long getPos() throws IOException {
        return pos;
    }

    @Override
    public long getLength() {
        return fileLength;
    }

    private boolean closed = false;

    private void assertOpen() throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
    }

    @Override
    public synchronized void close() {
        if (closed) {
            return;
        }
        closed = true;
        ReadWriteUtils.safeClose(blockInput);
        ReadWriteUtils.safeClose(blockCacheInput);
        if ((flags & DFSClient.IS_BLOCKCACHE) != 0) {
            blockCache.cancelReader(BlockCache.getBlockCacheFileId(file, blocks));
        }
        idleTracker.remove(this);
    }

    @Override
    public synchronized String toString() {
        return "[DFSInputStream file=" + file + " pos=" + pos + " flags="
                + flags + " fileLength=" + fileLength + " closed=" + closed
                + " blockInput=" + blockInput + "]";
    }

}
