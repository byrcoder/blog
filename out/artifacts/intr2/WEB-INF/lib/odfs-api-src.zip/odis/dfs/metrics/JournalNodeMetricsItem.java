package odis.dfs.metrics;

public enum JournalNodeMetricsItem {
    SYSTEM_LOAD(0, "系统负载"),
    PROCESSOR_NUM(SYSTEM_LOAD.offset + 1, "CPU个数"),
    
    HEAP_INIT(PROCESSOR_NUM.offset + 1, "初始堆内存"),
    HEAP_USED(HEAP_INIT.offset + 1, "已用堆内存"),
    HEAP_COMMITTED(HEAP_USED.offset + 1, "提交堆内存"),
    HEAP_MAX(HEAP_COMMITTED.offset + 1, "最大堆内存"),
    
    NON_HEAP_INIT(HEAP_MAX.offset + 1, "初始非堆内存"),
    NON_HEAP_USED(NON_HEAP_INIT.offset + 1, "已用非堆内存"),
    NON_HEAP_COMMITTED(NON_HEAP_USED.offset + 1, "提交非堆内存"),
    NON_HEAP_MAX(NON_HEAP_COMMITTED.offset + 1, "最大非堆内存"),
    
    GET_JOURNAL_STATE_COUNT(NON_HEAP_MAX.offset + 1, "getJournalState次数"),
    GET_JOURNAL_STATE_DELAY(GET_JOURNAL_STATE_COUNT.offset + 1, "getJournalState时间"),
    
    NEW_EPOCH_COUNT(GET_JOURNAL_STATE_DELAY.offset + 1, "newEpoch次数"),
    NEW_EPOCH_DELAY(NEW_EPOCH_COUNT.offset + 1, "newEpoch时间"),
    
    START_LOG_SEGMENT_COUNT(NEW_EPOCH_DELAY.offset + 1, "startLogSegment次数"),
    START_LOG_SEGMENT_DELAY(START_LOG_SEGMENT_COUNT.offset + 1, "startLogSegment时间"),
    
    FINALIZE_LOG_SEGMENT_COUNT(START_LOG_SEGMENT_DELAY.offset + 1, "finalizeLogSegment次数"),
    FINALIZE_LOG_SEGMENT_DELAY(FINALIZE_LOG_SEGMENT_COUNT.offset + 1, "finalizeLogSegment时间"),
    
    PREPARE_RECOVERY_COUNT(FINALIZE_LOG_SEGMENT_DELAY.offset + 1, "prepareRecovery次数"),
    PREPARE_RECOVERY_DELAY(PREPARE_RECOVERY_COUNT.offset + 1, "prepareRecovery时间"),
    
    ACCEPT_RECOVERY_COUNT(PREPARE_RECOVERY_DELAY.offset + 1, "acceptRecovery次数"),
    ACCEPT_RECOVERY_DELAY(ACCEPT_RECOVERY_COUNT.offset + 1, "acceptRecovery时间"),
    
    JOURNAL_COUNT(ACCEPT_RECOVERY_DELAY.offset + 1, "journal次数"),
    JOURNAL_DELAY(JOURNAL_COUNT.offset + 1, "journal时间"),
    JOURNAL_BYTES(JOURNAL_DELAY.offset + 1, "journal数据总大小"),
    
    EXIST_COUNT(JOURNAL_BYTES.offset + 1, "exist次数"),
    EXIST_DELAY(EXIST_COUNT.offset + 1, "exist时间"),
    
    DELETE_SEGMENT_BEFORE_COUNT(EXIST_DELAY.offset + 1, "deleteSegmentBefore次数"),
    DELETE_SEGMENT_BEFORE_DELAY(DELETE_SEGMENT_BEFORE_COUNT.offset + 1, "deleteSegmentBefore时间"),
    
    HEARTBEAT_COUNT(DELETE_SEGMENT_BEFORE_DELAY.offset + 1, "heartbeat次数"),
    HEARTBEAT_DELAY(HEARTBEAT_COUNT.offset + 1, "heartbeat时间"),
    
    MAX_FINALIZED_SEGMENT_S_N_COUNT(HEARTBEAT_DELAY.offset + 1, "maxFinalizedSegmentSNCount次数"),
    MAX_FINALIZED_SEGMENT_S_N_DELAY(MAX_FINALIZED_SEGMENT_S_N_COUNT.offset + 1, "maxFinalizedSegmentSNCount时间"),
    
    REQUEST_NUM(MAX_FINALIZED_SEGMENT_S_N_DELAY.offset + 1, "总请求次数");
    
    private final int offset;

    private final String printName;

    private JournalNodeMetricsItem(int offset, String printName) {
        this.offset = offset;
        this.printName = printName;
    }

    public int offset() {
        return offset;
    }

    public String getPrintName() {
        return printName;
    }

    public static int systemInfoItems() {
        return NON_HEAP_MAX.offset + 1;
    }

    public static int totalItems() {
        return REQUEST_NUM.offset + 1;
    }
}
