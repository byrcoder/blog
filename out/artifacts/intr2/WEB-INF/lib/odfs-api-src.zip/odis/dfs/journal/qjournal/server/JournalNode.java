package odis.dfs.journal.qjournal.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.management.MemoryUsage;
import java.net.InetAddress;
import java.nio.channels.FileLock;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.journal.qjournal.IQJournalProtocol;
import odis.dfs.journal.qjournal.RequestInfo;
import odis.dfs.metrics.JournalNodeMetrics;
import odis.dfs.metrics.JournalNodeMetricsItem;
import odis.dfs.util.AtomicFileOutputStream;
import odis.dfs.util.DfsUtils;
import odis.dfs.util.PersistentLongFile;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.util.SystemInfoUtils;

import org.apache.commons.configuration.Configuration;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.webapp.WebAppContext;

import toolbox.misc.LogFormatter;

/**
 * The JournalNode is a daemon which allows namenodes using the
 * QuorumJournalManager to log and retrieve edits stored remotely.
 * 
 * @author chenxi
 */
public class JournalNode implements IQJournalProtocol, Runnable {
    private static final Logger LOG = LogFormatter.getLogger(JournalNode.class);

    private int httpPort = -1;

    private AbstractRpcServer server;
    
    private final JournalNodeMetrics metrics = new JournalNodeMetrics();

    private Server webServer;

    private String hostname;

    private int rpcPort;

    private File baseDir;
    
    private volatile boolean running = true;
    
    private long checkInterval;
    
    private ExecutorService executor;

    private PersistentLongFile lastPromisedEpoch;

    /**
     * The epoch number of the last writer to actually write a transaction. This
     * is used to differentiate log segments after a crash at the very beginning
     * of a segment.
     */
    private PersistentLongFile lastWriterEpoch;

    /**
     * Each RPC that comes from a given client contains a serial number which
     * only increases from the client's perspective. Whenever we switch epochs,
     * we reset this back to -1. Whenever an RPC comes from a client, we ensure
     * that it is strictly higher than any previous RPC. This guards against any
     * bugs in the RPC layer that would re-order RPCs or cause a stale retry
     * from an old request to resurface and confuse things.
     */
    private long currentEpochRpcSerial = -1;

    private FileJournalManager fileJM;

    /**
     * For persist paxos data
     */
    private SegmentState acceptedState = new SegmentState();

    private long acceptedInEpoch = -1;

    private boolean hasPrevousPaxosData = false;

    private static final String LAST_PROMISED_FILENAME = "last-promised-epoch";

    private static final String LAST_WRITER_EPOCH = "last-writer-epoch";
    
    private static final String LOCK_FILE_NAME = "journalNode.lock";

    public JournalNode(Configuration conf) throws Exception {
        this.rpcPort = conf.getInt(DFSConfig.DFS_QJOURNAL_SERVER_PORT);
        LOG.info("Creating journalNode at port: " + this.rpcPort);
        this.baseDir = new File(conf.getString(DFSConfig.JOURNAL_ROOT_DIR));
        if (!baseDir.exists() && !baseDir.mkdirs()) {
            throw new IOException(
                    "Can't create base data dir for JournalNode, baseDir="
                            + baseDir);
        }

        File paxosDir = this.getPaxosDir();
        if (!paxosDir.exists() && !paxosDir.mkdirs()) {
            throw new IOException(
                    "Can't create paxos data dir for JournalNode, dir="
                            + paxosDir);
        }
        
        server = RPC.getNIOServer(IQJournalProtocol.class, this, this.rpcPort,
                10, 10000, 1, 0);
        server.setServerCallListener(metrics);
        server.start();
        LOG.info("JournalNode RPC server started at port: " + this.rpcPort);

        LOG.info("Refresh cached datas...");
        refreshCachedData();

        LOG.info("Init local Journal Manager...");
        this.fileJM = new FileJournalManager(this.baseDir);

        initHttp(rpcPort + 1);
        
        checkInterval = conf.getLong(
                DFSConfig.DFS_QJOURNAL_CHECK_SERVER_INTERVAL_KEY,
                DFSConfig.DFS_QJOURNAL_CHECK_SERVER_INTERVAL_DEFAULT);
        
        executor = Executors.newFixedThreadPool(1);
    }
    
    /**
     * For testcase
     * @throws Exception 
     */
    public JournalNode(int rpcPort, File baseDir, long checkInterval)
            throws Exception {
        this.rpcPort = rpcPort;
        LOG.info("Creating journalNode at port: " + this.rpcPort);
        this.baseDir = baseDir;
        if (!baseDir.exists() && baseDir.mkdirs()) {
            throw new IOException(
                    "Can't create base data dir for JournalNode, baseDir="
                            + baseDir);
        }

        File paxosDir = this.getPaxosDir();
        if (!paxosDir.exists() && paxosDir.mkdirs()) {
            throw new IOException(
                    "Can't create paxos data dir for JournalNode, dir="
                            + paxosDir);
        }
        
        server = RPC.getNIOServer(IQJournalProtocol.class, this, this.rpcPort,
                1, 10, 1, 0);
        server.setServerCallListener(metrics);
        server.start();
        LOG.info("JournalNode RPC server started at port: " + this.rpcPort);

        LOG.info("Refresh cached datas...");
        refreshCachedData();

        LOG.info("Init local Journal Manager...");
        this.fileJM = new FileJournalManager(this.baseDir);

        initHttp(rpcPort + 1);
        
        this.checkInterval = checkInterval;
    }

    public void stop() {
        LOG.info("Stop journal node: " + this.hostname + ":" + this.rpcPort);
        this.running = false;
        
        if (webServer != null) {
            try {
                webServer.stop();
            } catch (Exception e) {
                LOG.warning("Unable to stop HTTP server for " + e);
            }
        }
        
        if (server != null) {
            server.stop();
        }
        
        this.abortCurrentSegment();
    }
    
    public long[] getJournalNodeMetricsRecords() {
        long[] metricsRecords = new long[JournalNodeMetricsItem.totalItems()];
        metricsRecords[JournalNodeMetricsItem.SYSTEM_LOAD.offset()] = (long) (SystemInfoUtils.getLoad() * 100);
        metricsRecords[JournalNodeMetricsItem.PROCESSOR_NUM.offset()] = SystemInfoUtils.getProcessors();
        MemoryUsage usage = SystemInfoUtils.getMemoryUsage();
        metricsRecords[JournalNodeMetricsItem.HEAP_INIT.offset()] = usage.getInit();
        metricsRecords[JournalNodeMetricsItem.HEAP_USED.offset()] = usage.getUsed();
        metricsRecords[JournalNodeMetricsItem.HEAP_COMMITTED.offset()] = usage.getCommitted();
        metricsRecords[JournalNodeMetricsItem.HEAP_MAX.offset()] = usage.getMax();
        usage = SystemInfoUtils.getNonHeapMemoryUsage();
        metricsRecords[JournalNodeMetricsItem.NON_HEAP_INIT.offset()] = usage.getInit();
        metricsRecords[JournalNodeMetricsItem.NON_HEAP_USED.offset()] = usage.getUsed();
        metricsRecords[JournalNodeMetricsItem.NON_HEAP_COMMITTED.offset()] = usage.getCommitted();
        metricsRecords[JournalNodeMetricsItem.NON_HEAP_MAX.offset()] = usage.getMax();
        metrics.fillMetricsRecords(metricsRecords);
        return metricsRecords;
    }

    @Override
    public String toString() {
        return  hostname + ":" + rpcPort;
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(checkInterval);
            } catch (Exception e) {
                LOG.log(Level.WARNING,
                        "JournalNode run() sleep caught exception: ", e);
            }
        }
    }

    @Override
    public GetJournalStateResponse getJournalState(String clusterId)
            throws IOException {
        long epoch = -1;
        epoch = getLastPromisedEpoch();
        LOG.info("Get journal state for " + clusterId + " get epoch: " + epoch);
        return new GetJournalStateResponse(epoch, httpPort);
    }

    @Override
    public long newEpoch(String clusterId, long epoch) throws 
            IOException {
        // Check that the new epoch being proposed is in fact newer than
        // any other that we've promised.
        long lastPromisedEpoch = this.getLastPromisedEpoch();
        if (epoch <= lastPromisedEpoch) {
            throw new JNException(JNException.ILLEGAL_EPOCH, "Proposed epoch "
                    + epoch + " <= last promised epoch " + lastPromisedEpoch);
        }

        setLastPromisedEpoch(epoch);
        this.fileJM.updateCurrentSN();
        return this.fileJM.getCurrentSN();
    }

    @Override
    public int journal(RequestInfo reqInfo, long currentSN, byte[] records,
            int checksum) throws IOException {
        return journal(reqInfo, currentSN, records, 0, records.length, checksum);
    }

    @Override
    public int journal(RequestInfo reqInfo, long currentSN, byte[] records,
            int off, int len, int checksum) throws IOException {
        this.checkRequest(reqInfo);
        this.checkCurrentSN(currentSN);

        // Make sure the log is continues
        // Avoid a logger failed to write but come back normal later
        long currentChecksum = this.fileJM.getCurrentCheckSum();
        if (currentChecksum != checksum) {
            String errorMsg = "Write to segment sn=" + currentSN
                    + " with different checksum, expected=" + checksum
                    + " while get checksum=" + currentChecksum;
            LOG.warning(errorMsg);
            throw new JNException(JNException.ILLEGAL_CHECKSUM, errorMsg);
        }
        this.fileJM.write(records, off, len);
        return this.fileJM.getCurrentCheckSum();
    }

    @Override
    public void heartbeat(RequestInfo reqInfo) throws IOException {
        this.checkRequest(reqInfo);
    }

    @Override
    public long startLogSegment(RequestInfo reqInfo, long minimumSN)
            throws IOException {
        if (null == this.fileJM) {
            throw new JNException(JNException.ILLEGAL_STATE,
                    "BUG: not init local file journal manager");
        }
        this.checkRequest(reqInfo);
        if (this.fileJM.isSegmentOpened()) {
            LOG.warning("Client is requesting a new log segment though we are already writing "
                    + this.fileJM.getCurrentSN()
                    + ". "
                    + "Aborting the current segment in order to begin the new one.");
            this.abortCurrentSegment();
        }

        long curLastWriterEpoch = this.getLastWriterEpoch();
        if (curLastWriterEpoch != reqInfo.getEpoch()) {
            LOG.info("Updating lastWriterEpoch from " + curLastWriterEpoch
                    + " to " + reqInfo.getEpoch());
            this.setLastWriterEpoch(reqInfo.getEpoch());
        }
        
        this.fileJM.startLogSegment(minimumSN);

        return this.fileJM.getCurrentSN();
    }

    @Override
    public int finalizeLogSegment(RequestInfo reqInfo, long sn, long logLength)
            throws IOException {
        this.checkRequest(reqInfo);
        
        File file = this.fileJM.getTmpLogFile(sn);
        File logFile = this.fileJM.getLogFile(sn);
        if (!file.exists() && !logFile.exists()) {
            String errMsg = "No log file to finalize at sn=" + sn;
            LOG.warning(errMsg);
            throw new JNException(JNException.ILLEGAL_STATE, errMsg);
        }

        long length = this.fileJM.getLogLength(sn);
        if (length != logLength) {
            String errMsg = "Unexpected finalized log length=" + length
                    + ", while expected log length=" + logLength;
            LOG.warning("BUG: " + errMsg);
            throw new JNException(JNException.ILLEGAL_JOURNAL_LENGTH, errMsg);
        }
        int checksum = this.fileJM.finalizeLogSegment(sn);
        // Once logs are finalized, a different length will never be decided.
        // During recovery, we treat a finalized segment the same as an accepted
        // recovery. Thus, we no longer need to keep track of the previously-
        // accepted decision. The existence of the finalized log segment is
        // enough.
        this.purgePaxosDecision(sn);
        LOG.info("Finalize log success with sn=" + sn);
        return checksum;
    }

    @Override
    public long deleteSegmentBefore(long sn) throws RpcException {
        executor.execute(new BackgroundRunner(sn));
        return 0;
    }
    
    @Override
    public ExistResponse exist(long sn) throws RpcException {
        File finalizedJournal = this.fileJM.getLogFile(sn);
        ExistResponse res = new ExistResponse();
        res.setHttpPort(httpPort);
        boolean exist = finalizedJournal.exists();
        res.setExist(exist);
        return res;
    }
    
    public int getHttpPort() {
        return httpPort;
    }

    public int getRpcPort() {
        return rpcPort;
    }

    public File getBaseDir() {
        return baseDir;
    }

    public FileJournalManager getFileJM() {
        return fileJM;
    }

    public long getLastPromisedEpoch() throws IOException {
        return lastPromisedEpoch.get();
    }

    public void setLastPromisedEpoch(long lastPromisedEpoch) throws IOException {
        this.lastPromisedEpoch.set(lastPromisedEpoch);
        // Since we have a new writer, reset the RPC serial - it will start
        // counting again from 0 for this writer.
        this.currentEpochRpcSerial = -1;
    }

    public long getLastWriterEpoch() throws IOException {
        return lastWriterEpoch.get();
    }

    public void setLastWriterEpoch(long lastWriterEpoch) throws IOException {
        this.lastWriterEpoch.set(lastWriterEpoch);
    }

    @Override
    public PrepareRecoveryResponse prepareRecovery(RequestInfo reqInfo, long sn)
            throws IOException {
        this.checkRequest(reqInfo);
        this.abortCurrentSegment();

        PrepareRecoveryResponse res = new PrepareRecoveryResponse();

        // Get previous accepted datas
        this.getPersistedPaxosData(sn);
        this.completeHalfDoneAcceptRecovery();
        

        SegmentState segInfo = this.getSegmentInfo(sn);
        boolean hasFinalizedSegment = segInfo != null
                && !segInfo.isInProgress();

        if (this.hasPrevousPaxosData && !hasFinalizedSegment) {
            if (this.acceptedState.getContentLength() != segInfo
                    .getContentLength()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Unexpected file length in prepare:\n");
                sb.append("prev accepted: ")
                        .append(this.acceptedState)
                        .append(", acceptedInEpoch=" + this.acceptedInEpoch);
                sb.append("\non disk: " + segInfo);
                String errInfo = sb.toString();
                LOG.warning(errInfo);
                throw new JNException(JNException.ILLEGAL_STATE, errInfo);
            }
            res.setAcceptedInEpoch(this.acceptedInEpoch);
            res.setSegmentState(this.acceptedState);
            res.setHasSegmentState(true);
        } else {
            res.setSegmentState(segInfo);
            res.setHasSegmentState(segInfo != null);
        }

        res.setLastWriterEpoch(this.getLastWriterEpoch());
        return res;
    }

    @Override
    public long acceptRecovery(RequestInfo reqInfo, SegmentState stateToAccept,
            String fromUrl) throws IOException {
        this.checkRequest(reqInfo);
        this.abortCurrentSegment();

        long sn = stateToAccept.getSn();
        if (stateToAccept.getContentLength() <= 0) {
            throw new JNException(JNException.ILLEGAL_STATE,
                    "bad contentLength to recovery: " + stateToAccept);
        }

        File syncedFile = null;
        this.getPersistedPaxosData(sn);
        // If we previously acted on acceptRecovery() from a higher-numbered
        // writer,
        // this call is out of sync. We should never actually trigger this,
        // since the
        // checkRequest() call above should filter non-increasing epoch numbers.
        if (this.hasPrevousPaxosData
                && this.acceptedInEpoch > reqInfo.getEpoch()) {
            throw new JNException(
                    JNException.ILLEGAL_STATE,
                    String.format(
                            "Bad paxos transition, out-of-order epochs.\nOld: %s\nNew: %s\n",
                            this.acceptedInEpoch, reqInfo.getEpoch()));
        }

        SegmentState currentSegment = getSegmentInfo(sn);
        if (null == currentSegment
                || currentSegment.getContentLength() != stateToAccept
                        .getContentLength()) {
            if (null == currentSegment) {
                LOG.info("Synchronizing log " + stateToAccept
                        + ": no current segment in place");
            } else {
                LOG.info("Synchronizing log " + stateToAccept
                        + ": old segment " + currentSegment
                        + " is not the right length");

                // Paranoid sanity check: if the new log is shorter than the log
                // we currently have, we should not end up discarding any transactions
                // which are already Committed.
                // This is ok, because odfs will handle every failed journal call
                // This only happened when write only success in one JN,
                // but the other 2 JN returned first and choosed to be recovery resource
                if (currentSegment.getContentLength() > stateToAccept
                        .getContentLength()) {
                    LOG.warning("Replace segment "
                            + currentSegment.getContentLength()
                            + " with new segment "
                            + stateToAccept.getContentLength()
                            + ": would discard already-committed edits ");
                }

                // Another paranoid check: we should not be asked to synchronize
                // a log
                // on top of a finalized segment.
                if (!currentSegment.isInProgress()) {
                    throw new JNException(JNException.ILLEGAL_STATE,
                            "Should never be asked to synchronize a different log on top of an "
                                    + "already-finalized segment");
                }
            }
            syncedFile = syncLog(reqInfo, stateToAccept, fromUrl);
        } else {
            LOG.info("Skipping download of log " + stateToAccept
                    + ": already have up-to-date logs");
        }

        // This is one of the few places in the protocol where we have a single
        // RPC that results in two distinct actions:
        //
        // - 1) Downloads the new log segment data (above)
        // - 2) Records the new Paxos data about the synchronized segment
        // (below)
        //
        // These need to be treated as a transaction from the perspective
        // of any external process. We do this by treating the
        // persistPaxosData()
        // success as the "commit" of an atomic transaction. If we fail before
        // this point, the downloaded edit log will only exist at a temporary
        // path, and thus not change any externally visible state. If we fail
        // after this point, then any future prepareRecovery() call will see
        // the Paxos data, and by calling completeHalfDoneAcceptRecovery() will
        // roll forward the rename of the referenced log file.
        //
        // See also: HDFS-3955
        //
        // The fault points here are exercised by the randomized fault injection
        // test case to ensure that this atomic "transaction" operates
        // correctly.
        JournalFaultInjector.get().beforePersistPaxosData();
        this.persistPaxosData(sn, stateToAccept, reqInfo.getEpoch());
        JournalFaultInjector.get().afterPersistPaxosData();

        if (null != syncedFile) {
            File tmpLogFile = this.fileJM.getTmpLogFile(sn);
            if (!syncedFile.renameTo(tmpLogFile)) {
                throw new IOException("Can't rename " + syncedFile + " to "
                        + tmpLogFile);
            }
        }
        LOG.info("Accepted recovery for segment " + sn + ": " + stateToAccept
                + ", url=" + fromUrl);
        return this.fileJM.getTmpLogFile(sn).length();
    }
    
    private void initHttp(int expectPort) throws Exception {
        this.hostname = InetAddress.getLocalHost().getHostName();
        JournalNodeInspectorServlet.jn = this;
        
        File appDir = new File(DFSConfig.getHome(), "journal");
        if (!appDir.exists()) {
            appDir = new File(DFSConfig.getHome(), "src/" + "journal");
        }
        LOG.info("Init webapp path:" + appDir.getAbsolutePath());
        
        File tmpDir = new File(DFSConfig.getHome(), "Qjournal");
        WebAppContext webAppContext = new WebAppContext(
                appDir.getAbsolutePath(), "/");
        webAppContext.setTempDirectory(tmpDir);
        webAppContext.setAttribute(GetJournalEditServlet.LOCAL_JOURNAL_KEY, this);
        
        this.httpPort = DfsUtils.probeFreePort(expectPort, 1);
        webServer = new Server(httpPort);
        webServer.setHandler(webAppContext);
        webServer.start();
        
        LOG.info("Inspector was started on port " + httpPort);
    }

    /**
     * Reload any data that may have been cached. This is necessary when we
     * first load the Journal.
     */
    private synchronized void refreshCachedData() {
        this.lastPromisedEpoch = new PersistentLongFile(new File(baseDir,
                LAST_PROMISED_FILENAME), 0);
        this.lastWriterEpoch = new PersistentLongFile(new File(baseDir,
                LAST_WRITER_EPOCH), 0);
    }

    private void abortCurrentSegment() {
        if (this.fileJM.isSegmentOpened()) {
            this.fileJM.close();
        }
    }

    private void checkCurrentSN(long sn) throws JNException {
        if (sn != this.fileJM.getCurrentSN()) {
            this.abortCurrentSegment();
            throw new JNException(JNException.ILLEGAL_PARAM,
                    "Writer out of sync: it thinks it is writing segment " 
                            + sn
                            + " but current segment is "
                            + this.fileJM.getCurrentSN());
        }
    }

    /**
     * Ensure that the given request is coming from the correct writer and
     * in-order.
     * 
     * @param reqInfo
     *            the request info
     * @throws Rpcxception
     *             if the request is invalid.
     */
    private synchronized void checkRequest(RequestInfo reqInfo)
            throws IOException {
        long lastPromisedEpoch = this.getLastPromisedEpoch();
        if (reqInfo.getEpoch() < lastPromisedEpoch) {
            throw new JNException(JNException.ILLEGAL_PARAM, 
                    "RPC's epoch " + reqInfo.getEpoch()
                    + " is less than the last promised epoch "
                    + lastPromisedEpoch);
        } else if (reqInfo.getEpoch() > lastPromisedEpoch) {
            // A newer client has arrived. Fence any previous writers by
            // updating the promise.
            this.setLastPromisedEpoch(reqInfo.getEpoch());
        }

        // Ensure that the RPCs are arriving in-order as expected.
        if (reqInfo.getRpcSerialNumber() <= this.currentEpochRpcSerial) {
            throw new JNException(JNException.ILLEGAL_CALL_ORDER,
                    "RPC serial "
                            + reqInfo.getRpcSerialNumber()
                            + " from client was not higher than prior highest RPC serial "
                            + this.currentEpochRpcSerial);
        }
        this.currentEpochRpcSerial = reqInfo.getRpcSerialNumber();
    }

    /**
     * @return the path for the file which contains persisted data for the
     *         paxos-like recovery process for the given log segment.
     */
    private File getPaxosFile(long sn) {
        return new File(getPaxosDir(), String.valueOf(sn));
    }

    private File getPaxosDir() {
        return new File(this.baseDir, "paxos");
    }

    private void getPersistedPaxosData(long sn) throws IOException {
        File f = this.getPaxosFile(sn);
        this.hasPrevousPaxosData = false;
        if (!f.exists()) {
            return;
        }
        this.hasPrevousPaxosData = true;
        DataInputStream in = new DataInputStream(new FileInputStream(f));

        try {
            this.acceptedState.readFields(in);
            this.acceptedInEpoch = in.readLong();
        } finally {
            in.close();
        }
    }

    public void persistPaxosData(long sn, SegmentState segmentState,
            long acceptedInEpoch) throws IOException {
        File f = this.getPaxosFile(sn);
        boolean success = false;
        AtomicFileOutputStream fos = new AtomicFileOutputStream(f);
        DataOutputStream out = new DataOutputStream(fos);
        try {
            segmentState.writeFields(out);
            out.writeLong(acceptedInEpoch);
            out.flush();
            fos.flush();
            success = true;
        } finally {
            if (success) {
                fos.close();
            } else {
                fos.abort();
            }
        }
    }
    
    /**
     * Remove the previously-recorded 'accepted recovery' information
     * for a given log segment, once it is no longer necessary. 
     * @param sn the transaction ID to purge
     * @throws IOException if the file could not be deleted
     */
    private void purgePaxosDecision(long sn) throws IOException {
        File paxosFile = this.getPaxosFile(sn);
        if (paxosFile.exists()) {
            if (!paxosFile.delete()) {
                throw new IOException("Unable to delete paxos file "
                        + paxosFile);
            }
        }
    }

    /**
     * In the case the node crashes in between downloading a log segment and
     * persisting the associated paxos recovery data, the log segment will be
     * left in its temporary location on disk. Given the paxos data, we can
     * check if this was indeed the case, and &quot;roll forward&quot; the
     * atomic operation.
     * 
     * @throws IOException
     *             if the temporary file is unable to be renamed into place
     */
    private void completeHalfDoneAcceptRecovery() throws IOException {
        if (!this.hasPrevousPaxosData) {
            return;
        }

        long sn = this.acceptedState.getSn();
        long epoch = this.acceptedInEpoch;

        File tmp = this.fileJM.getSyncLogTemporaryFile(sn, epoch);

        if (tmp.exists()) {
            File dst = this.fileJM.getTmpLogFile(sn);
            LOG.info("Rolling forward previously half-completed synchronization: "
                    + tmp + " -> " + dst);
            if (!tmp.renameTo(dst)) {
                throw new IOException("Can't rename " + tmp + " to " + dst);
            }
        }
    }

    /**
     * @return the current state of the given segment, or null if the segment
     *         does not exist.
     */
    private SegmentState getSegmentInfo(long sn) {
        if (!this.fileJM.exists(sn)) {
            LOG.info("Not found segment info with sn=" + sn);
            return null;
        }

        SegmentState segmentState = new SegmentState();
        segmentState.setSn(sn);
        segmentState.setInProgress(this.fileJM.isInProgress(sn));

        File logFile = null;
        if (segmentState.isInProgress()) {
            logFile = this.fileJM.getTmpLogFile(sn);
        } else {
            logFile = this.fileJM.getLogFile(sn);
        }
        long contentLength = logFile.length();
        if (0 == contentLength) {
            LOG.info("Found empty segment with sn=" + sn);
            return null;
        }
        segmentState.setContentLength(contentLength);

        LOG.info("getSegmentInfo(" + sn + "): " + segmentState);
        return segmentState;
    }

    /**
     * Synchronize a log segment from another JournalNode. The log is downloaded
     * from the provided URL into a temporary location on disk, which is named
     * based on the current request's epoch.
     * 
     * @return the temporary location of the downloaded file
     */
    private File syncLog(RequestInfo reqInfo, final SegmentState segment,
            final String url) throws IOException {
        final File tmpFile = this.fileJM.getSyncLogTemporaryFile(
                segment.getSn(), reqInfo.getEpoch());
        LOG.info("Synchronizing log " + segment + " from " + url);
        boolean success = false;
        try {
            long contentLen = FileJournalManager.downloadFromUrl(tmpFile, url);
            if (!tmpFile.exists()) {
                throw new IOException("BUG: SyncLog from " + url
                        + " success, but tmp file " + tmpFile + " is not exist");
            }
            if (contentLen != segment.getContentLength()) {
                throw new IOException("SyncLog " + segment.getSn() + " from "
                        + url + ": expected " + segment.getContentLength()
                        + ", but get " + contentLen);
            }
            success = true;
        } finally {
            if (!success) {
                if (!tmpFile.delete()) {
                    LOG.warning("Failed to delete temporary file " + tmpFile);
                }
            }
        }
        return tmpFile;
    }
    
    //Now this is only for delete segment
    protected class BackgroundRunner implements Runnable {
        long sn;

        public BackgroundRunner(long sn) {
            this.sn = sn;
        }

        @Override
        public void run() {
            LOG.info("Delete Segment before sn=" + sn);
            fileJM.deleteSegmentBefore(sn);
        }
    }
    
    public static void main(String[] args) throws Exception {
        Configuration conf = DFSConfig.conf();
        //Init logger
        File logDir = new File(DFSConfig.getLogDir(), "journalNode");
        if (!logDir.exists()) {
            if (!logDir.mkdirs()) {
                throw new IOException("Create log dir " + logDir + " failed");
            }
        }
        String hostname = InetAddress.getLocalHost().getHostName();
        LogFormatter.clearLoggerHandlers("");
        LogFormatter.setRotateFileLogger(
                "",
                logDir.getPath(),
                "Jn-" + hostname + ".log",
                DFSConfig.conf().getInt(DFSConfig.LOG_FILE_LIMIT,
                        DFSConfig.DEFAULT_LOG_FILE_LIMIT),
                DFSConfig.conf().getInt(DFSConfig.LOG_FILE_COUNT,
                        DFSConfig.DEFAULT_LOG_FILE_COUNT),
                DFSConfig.conf().getBoolean(DFSConfig.LOG_APPEND,
                        DFSConfig.DEFAULT_LOG_APPEND));
        LogFormatter.setLogLevel(DFSConfig.getLogLevel(), Level.INFO);

        // starting
        JournalNode jn = new JournalNode(conf);
        FileOutputStream lockFileOS = null;
        FileLock lock = null;
        try {
            // get the lock
            lockFileOS = new FileOutputStream(new File(DFSConfig.getLogDir(),
                    LOCK_FILE_NAME));
            lock = lockFileOS.getChannel().tryLock();
            if (lock == null) {
                LOG.info("Get journalnode lock failed, exit...");
                System.exit(1);
            }
            jn.run();
            System.out.println("JournalNode was returned.");
        } finally {
            if (lock != null)
                lock.release();
            if (lockFileOS != null)
                lockFileOS.close();
        }
        System.exit(0);
    }

    @Override
    public long maxFinalizedSegmentSN() throws RpcException {
        return this.fileJM.maxFinalizedSegmentSN();
    }
}
