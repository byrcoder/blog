package odis.dfs.util;

import toolbox.collections.ArrayQueue;

/**
 * @author yaming
 */
public class QueueCounter {

    private static final class Entry {
        public int value;

        public long time;

        public Entry() {
            this.value = -1;
            this.time = 0;
        }

        public void set(int value) {
            this.value = value;
            this.time = System.currentTimeMillis();
        }
    }

    private final ArrayQueue<Entry> queue;

    public QueueCounter(int size) {
        this.queue = new ArrayQueue<Entry>(size);
        for (int i = 0; i < size; i++) {
            queue.add(new Entry());
        }
    }

    public synchronized void add(int value) {
        Entry e = queue.remove();
        e.set(value);
        queue.add(e);
    }

    public synchronized long getSum(long timeLimit) {
        long result = 0;
        long startTime;
        if (timeLimit <= 0) {
            startTime = 0;
        } else {
            startTime = System.currentTimeMillis() - timeLimit;
        }
        for (Entry e: queue) {
            if (e.time > startTime) {
                result += e.value;
            }
        }
        return result;
    }

    public synchronized long getAvg(long timeLimit) {
        long maxTime = System.currentTimeMillis();
        long minTime = maxTime;
        long result = 0;
        long startTime;
        if (timeLimit <= 0) {
            startTime = 0;
        } else {
            startTime = maxTime - timeLimit;
        }
        for (Entry e: queue) {
            if (e.time > startTime) {
                minTime = Math.min(minTime, e.time);
                result += e.value;
            }
        }
        if (maxTime == minTime) {
            return 0;
        } else {
            return result * 1000 / (maxTime - minTime);
        }
    }

    public synchronized int getCount(long timeLimit) {
        int result = 0;
        long startTime;
        if (timeLimit <= 0) {
            startTime = 0;
        } else {
            startTime = System.currentTimeMillis() - timeLimit;
        }
        for (Entry e: queue) {
            if (e.time > startTime) {
                result++;
            }
        }
        return result;
    }

    public synchronized int getCountAvg(long timeLimit) {
        long maxTime = System.currentTimeMillis();
        long minTime = maxTime;
        int result = 0;
        long startTime;
        if (timeLimit <= 0) {
            startTime = 0;
        } else {
            startTime = maxTime - timeLimit;
        }
        for (Entry e: queue) {
            if (e.time > startTime) {
                minTime = Math.min(minTime, e.time);
                result++;
            }
        }
        if (maxTime == minTime) {
            return 0;
        } else {
            return (int) (result * 1000 / (maxTime - minTime));
        }
    }

    public synchronized int getCount(int value, long timeLimit) {
        int result = 0;
        long startTime;
        if (timeLimit <= 0) {
            startTime = 0;
        } else {
            startTime = System.currentTimeMillis() - timeLimit;
        }
        for (Entry e: queue) {
            if (e.time > startTime) {
                if (e.value == value) {
                    result++;
                }
            }
        }
        return result;
    }

    public synchronized int getCountAvg(int value, long timeLimit) {
        long maxTime = System.currentTimeMillis();
        long minTime = maxTime;
        int result = 0;
        long startTime;
        if (timeLimit <= 0) {
            startTime = 0;
        } else {
            startTime = maxTime - timeLimit;
        }
        for (Entry e: queue) {
            if (e.time > startTime) {
                minTime = Math.min(minTime, e.time);
                if (e.value == value) {
                    result++;
                }
            }
        }
        if (maxTime == minTime) {
            return 0;
        } else {
            return (int) (result * 1000 / (maxTime - minTime));
        }
    }
}
