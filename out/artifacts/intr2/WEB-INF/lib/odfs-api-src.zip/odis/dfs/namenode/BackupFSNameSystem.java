/**
 * @(#)BackupFSNameSystem.java, 2012-12-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.logging.Logger;

import odis.dfs.common.BlockCheckResult;
import odis.dfs.common.BlockLocationWithDataPath;
import odis.dfs.common.BlockSize;
import odis.dfs.common.BlockSizeLocationWithDataPath;
import odis.dfs.common.BlockVerifyResult;
import odis.dfs.common.DFSFileStatus;
import odis.dfs.common.DataNodeCommand;
import odis.dfs.common.FSException;
import odis.dfs.metrics.DataNodeMetricsItem;
import odis.io.CDataInputStream;
import odis.io.NamedLock;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.rpc2.AsyncRpcCallEntry;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.mutable.MutableLong;
import org.apache.zookeeper.KeeperException;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
class BackupFSNameSystem
        extends
        AbstractFSNameSystem<BackupFSBlockStore, BackupFSDirectory, BackupFSEditLogger> {

    private static final Logger LOG = LogFormatter.getLogger(BackupFSNameSystem.class);

    private final BackupFSBlockStore bstore;

    private final BackupFSDirectory dir;

    private final BackupFSEditLogger editLogger;

    private long nextEditLogSN;

    private boolean upgradeGuard = false;

    private long concurrentRequest = 0;
    
    protected MutableLong maxLoadedLogSN = new MutableLong(Long.MIN_VALUE);

    BackupFSNameSystem(Configuration conf) throws IOException {
        super(new HashMap<String, FileINodeUC>(),
                new HashMap<Long, String[]>(), conf);
        File imageRoot = new File(namenodeRoot, FS_IMAGE_DIR);
        File imageFile = ImageManager.getNewestImageFile(imageRoot, false);
        this.bstore = new BackupFSBlockStore(fsProps.volume);
        this.dir = new BackupFSDirectory(conf, bstore,
                ImageManager.getNewestImageFile(imageRoot, false),
                pendingCreates, pendingCreateLastBlocks, maxLoadedLogSN);
        this.editLogger = new BackupFSEditLogger(conf);
        this.nextEditLogSN = (imageFile == null ? IMAGE_FILE_START_SN
                : ImageManager.getSN(imageFile)) + 1;
        followUp();
    }

    void loadFSEdits(AbstractFSEditLogger editLogger, long sn)
            throws IOException {
        LOG.info("Start loading edit log with sn " + sn);
        InputStream in = editLogger.openFSEditLog(sn);
        if (in == null) {
            LOG.info("Segment " + sn + " doesn't exist, skip it");
            return;
        }
        CDataInputStream dataIn = new CDataInputStream(new BufferedInputStream(
                in));
        long editsLoaded;
        try {
            editsLoaded = dir.loadFSEdits(dataIn, pendingCreates,
                    pendingCreateLastBlocks, maxLoadedLogSN);
        } finally {
            ReadWriteUtils.safeClose(dataIn);
        }
        LOG.info("Done loading edit log with sn " + sn + ", " + editsLoaded
                + " edits loaded");
    }

    void followUp() throws IOException {
        long maxFinalizedSegmentSN = editLogger.maxFinalizedSegmentSN();
        for (; nextEditLogSN <= maxFinalizedSegmentSN; nextEditLogSN++) {
            loadFSEdits(editLogger, nextEditLogSN);
        }
    }

    ActiveFSNameSystem upgrade(Configuration conf,
            ZooKeeperStore<NamedLock<String>> lockStore)
            throws InterruptedException, IOException, KeeperException {
        synchronized (this) {
            upgradeGuard = true;
            while (concurrentRequest > 0) {
                this.wait();
            }
        }
        editLogger.close();

        ActiveFSEditLogger activeEditLogger = new ActiveFSEditLogger(conf,
                nextEditLogSN);
        for (long sn = nextEditLogSN, endEditLogSN = activeEditLogger.currentLogFileSN(); sn < endEditLogSN; sn++) {
            loadFSEdits(activeEditLogger, sn);
        }
        ActiveFSNameSystem activeNameSystem = new ActiveFSNameSystem(conf,
                namenodeRoot, admin, leasePeriod, fsProps, bstore, dir,
                pendingCreates, pendingCreateLastBlocks, activeEditLogger,
                lockStore);
        if (ready.get()) {
            activeNameSystem.setReady(null);
        }
        return activeNameSystem;
    }

    @Override
    protected void internalSetReady() {}

    @Override
    public void recoverInconsistentBlock(long block, String initiatingDataNode,
            BlockCheckResult result) throws IOException {}

    @Override
    public void reportConsistencyCheckResult(long block,
            String datanodeFullName, BlockCheckResult result)
            throws IOException {}

    @Override
    public DataNodeCommand connect(String sender, BlockSize[] blocks,
            long capacity, long remaining, long volume) throws IOException {
        synchronized (this) {
            if (upgradeGuard) {
                return null;
            }
            concurrentRequest++;
        }
        try {
            return bstore.datanodeConnect(sender, blocks, capacity, remaining,
                    volume);
        } finally {
            synchronized (this) {
                if (--concurrentRequest == 0) {
                    this.notifyAll();
                }
            }
        }
    }

    @Override
    public void disconnect(String sender) throws IOException {
        synchronized (this) {
            if (upgradeGuard) {
                return;
            }
            concurrentRequest++;
        }
        try {
            bstore.datanodeDisconnect(sender);
        } finally {
            synchronized (this) {
                if (--concurrentRequest == 0) {
                    this.notifyAll();
                }
            }
        }
    }

    @Override
    public void blockReport(String sender, BlockSize[] blocks)
            throws IOException {
        synchronized (this) {
            if (upgradeGuard) {
                return;
            }
            concurrentRequest++;
        }
        try {
            bstore.datanodeBlockReport(sender, blocks);
        } finally {
            synchronized (this) {
                if (--concurrentRequest == 0) {
                    this.notifyAll();
                }
            }
        }
    }

    @Override
    public DataNodeCommand[] sendHeartbeat(String sender, long remaining,
            long[] metricsRecord) throws IOException {
        synchronized (this) {
            if (upgradeGuard) {
                return DataNodeCommand.EMPTY_ARRAY;
            }
            concurrentRequest++;
        }
        try {
            int xmitsInProgress = (int) metricsRecord[DataNodeMetricsItem.CONCURRENT_REPLICATION.offset()];
            return bstore.datanodeHeartbeat(sender, remaining, xmitsInProgress,
                    false);
        } finally {
            synchronized (this) {
                if (--concurrentRequest == 0) {
                    this.notifyAll();
                }
            }
        }
    }

    @Override
    public void reportBlockReceivedOrDeleted(String sender,
            BlockSize[] received, long[] deleted) throws IOException {
        synchronized (this) {
            if (upgradeGuard) {
                return;
            }
            concurrentRequest++;
        }
        try {
            bstore.datanodeReportBlockReceivedOrDeleted(sender, received,
                    deleted);
        } finally {
            synchronized (this) {
                if (--concurrentRequest == 0) {
                    this.notifyAll();
                }
            }
        }
    }

    @Override
    public void replicationDone(String sender,
            BlockSizeLocationWithDataPath lblock) throws IOException {
        synchronized (this) {
            if (upgradeGuard) {
                return;
            }
            concurrentRequest++;
        }
        try {
            bstore.datanodeReplicationDone(sender, lblock);
        } finally {
            synchronized (this) {
                if (--concurrentRequest == 0) {
                    this.notifyAll();
                }
            }
        }
    }

    @Override
    String consistencyCheck(String user) throws IOException {
        checkAdmin(user);
        File reportFile = getReportFile("fsck");
        new FileSystemConsistencyChecker<BackupFSBlockStore>(dir, bstore,
                reportFile).fsck();
        return reportFile.getAbsolutePath();
    }

    @Override
    BackupFSBlockStore getFSBlockStore() {
        return bstore;
    }

    @Override
    BackupFSDirectory getFSDirectory() {
        return dir;
    }

    @Override
    BackupFSEditLogger getFSEditLogger() {
        return editLogger;
    }

    @Override
    BlockVerifyResult verifyBlock(AsyncRpcCallEntry rpcCallEntry, long block)
            throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void computeContentsLengthAndSubItemNum(String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    BlockLocationWithDataPath create(AsyncRpcCallEntry rpcCallEntry,
            String file, boolean overwrite, boolean createParent,
            FsPermission permission, int replication, int fileBlockSize,
            String user, String clientMachine, String clientName)
            throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void abandonBlock(AsyncRpcCallEntry rpcCallEntry, String file,
            int blockIndex, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    BlockLocationWithDataPath addBlock(AsyncRpcCallEntry rpcCallEntry,
            String file, int blockIndex, String clientMachine, String clientName)
            throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void abandonFileInProgress(AsyncRpcCallEntry rpcCallEntry, String file,
            String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean complete(AsyncRpcCallEntry rpcCallEntry, String file,
            String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean deprive(AsyncRpcCallEntry rpcCallEntry, String file, String user,
            String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean isPending(String file, String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    String[] pendingFilesInDir(String path, String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    BlockSizeLocationWithDataPath[] getFileBlockLocations(String file,
            String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    DFSFileStatus getFileStatus(String file, String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void mkdirs(AsyncRpcCallEntry rpcCallEntry, String dir, int replications,
            FsPermission permission, String user, String clientName)
            throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    DFSFileStatus[] getListing(String dir, String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void rename(AsyncRpcCallEntry rpcCallEntry, String src, String dst,
            boolean recursive, String user, String clientName)
            throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void snapshot(AsyncRpcCallEntry rpcCallEntry, String src, String dst,
            String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean delete(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, boolean permanently, String user,
            String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void recoverTrash(AsyncRpcCallEntry rpcCallEntry, String trash, String dst,
            String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean deleteTrash(AsyncRpcCallEntry rpcCallEntry, String path,
            String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    int getReplicationNumber(String path, String user) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setReplicationNumber(AsyncRpcCallEntry rpcCallEntry, String path,
            int replication, boolean recursive, String user, String clientName)
            throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setOwner(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, String owner, String group, String user,
            String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setPermission(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recursive, FsPermission permission, String user,
            String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setProtect(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean protect, String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean isProtect(String path) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setRecoverable(AsyncRpcCallEntry rpcCallEntry, String path,
            boolean recoverable, String user, String clientName)
            throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    boolean isRecoverable(String path) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setSpaceQuota(AsyncRpcCallEntry rpcCallEntry, String path, long quota,
            String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    long getSpaceQuota(String path) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void setNameQuota(AsyncRpcCallEntry rpcCallEntry, String path, long quota,
            String user, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    long getNameQuota(String path) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    String printDirProperties() throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void addGroupUser(AsyncRpcCallEntry rpcCallEntry, String group,
            String user, String opUser, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void removeGroupUser(AsyncRpcCallEntry rpcCallEntry, String group,
            String user, String opUser, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void removeGroup(AsyncRpcCallEntry rpcCallEntry, String group,
            String opUser, String clientName) throws IOException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    String printGroups() throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void renewLease(String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void removeLease(String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    int obtainLock(String src, int lock, String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    String lockState(String src, String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    int promote(String src, String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void downgrade(String src, String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    void releaseLock(String src, String clientName) throws FSException {
        throw new FSException(FSException.NOT_ACTIVE_NN,
                "I'm not the active NameNode");
    }

    @Override
    public void close() {
        editLogger.close();
        bstore.close();
    }

}
