/**
 * @(#)FSImageAndEditsVerifier.java, 2013-3-28. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import odis.dfs.common.DFSConfig;
import odis.dfs.common.FSConstants;
import odis.dfs.journal.JournalManager;
import odis.dfs.journal.qjournal.client.QuorumJournalManager;
import odis.io.CDataInputStream;
import odis.io.ReadWriteUtils;
import odis.io.permission.FsPermission;
import odis.util.KeyValueIterator;

import org.apache.commons.configuration.BaseConfiguration;
import org.apache.commons.lang.mutable.MutableLong;

import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class FSImageAndEditsVerifier {
    private static final Logger LOG = LogFormatter.getLogger(FSImageAndEditsVerifier.class);

    private static final class CorruptedImageException extends Exception {

        private static final long serialVersionUID = 6849695464015221435L;

        public CorruptedImageException(String message) {
            super(message);
        }

        @Override
        public synchronized Throwable fillInStackTrace() {
            return this;
        }

    }

    private final Map<String, FileINodeUC> pendingCreates = new HashMap<String, FileINodeUC>();

    private final Map<Long, String[]> pendingCreateLastBlocks = new HashMap<Long, String[]>();

    private final FSDirectory dir;

    private final JournalManager journalMgr;

    private long currentLogSN;

    private MutableLong maxLoadedLogSN = new MutableLong(Long.MIN_VALUE);

    private void verify(StringBuilder path, DirectoryINode dirNode)
            throws CorruptedImageException {
        int pathLength = path.length();
        for (KeyValueIterator<UTF8String, INode> iter = dirNode.iterator(); iter.hasNext();) {
            iter.next();
            path.append('/').append(iter.getKey().toString());
            INode node = iter.getValue();
            if (node instanceof DirectoryINode) {
                verify(path, (DirectoryINode) node);
            } else if (node instanceof FileINode) {
                verify(path, (FileINode) node);
            } else {
                verify(path, (FileINodeUC) node);
            }
            path.setLength(pathLength);
        }
    }

    private void verify(StringBuilder path, FileINode fileNode)
            throws CorruptedImageException {
        if (fileNode.getRefCount() <= 0) {
            throw new CorruptedImageException("file " + path
                    + " has ref count " + fileNode.getRefCount());
        }
        if (fileNode.getDesiredReplications() <= 0) {
            throw new CorruptedImageException("file " + path
                    + " has replication " + fileNode.getDesiredReplications());
        }
        for (int i = 0; i < fileNode.getBlocks().length; i++) {
            long block = fileNode.getBlocks()[i];
            if (block >= FSConstants.RESERVED_BLOCK_LOWER
                    && block < FSConstants.RESERVED_BLOCK_UPPER) {
                throw new CorruptedImageException("file " + path
                        + " has invalid block id " + block + " at pos " + i);
            }
        }
    }

    private void verify(StringBuilder path, FileINodeUC fileNodeUC)
            throws CorruptedImageException {
        if (fileNodeUC.fileBlockSize <= 0) {
            throw new CorruptedImageException("fileUC " + path
                    + " has block size " + fileNodeUC.fileBlockSize);
        }
        if (fileNodeUC.getDesiredReplications() <= 0) {
            throw new CorruptedImageException("fileUC " + path
                    + " has replication " + fileNodeUC.getDesiredReplications());
        }
        for (int i = 0; i < fileNodeUC.blocks.size(); i++) {
            BlockWithSize bs = fileNodeUC.blocks.get(i);
            if (bs.block >= FSConstants.RESERVED_BLOCK_LOWER
                    && bs.block < FSConstants.RESERVED_BLOCK_UPPER) {
                throw new CorruptedImageException("fileUC " + path
                        + " has invalid block id " + bs.block + " at pos " + i);
            }
        }
    }

    private void verify() throws CorruptedImageException {
        verify(new StringBuilder(), dir.rootDir);
    }

    public FSImageAndEditsVerifier(File imageFile, JournalManager journalMgr)
            throws IOException {
        this.dir = new FSDirectory(imageFile, pendingCreates,
                pendingCreateLastBlocks, maxLoadedLogSN);
        this.journalMgr = journalMgr;
        this.currentLogSN = ImageManager.getSN(imageFile) + 1;
    }

    public void run() throws IOException {
        try {
            verify();
        } catch (CorruptedImageException e) {
            LOG.severe("CorruptedImage found: " + e.getMessage());
            return;
        }
        long maxFinalizedSegmentSN = journalMgr.maxFinalizedSegmentSN();
        for (; currentLogSN <= maxFinalizedSegmentSN; currentLogSN++) {
            InputStream in = journalMgr.openFinalizedSegment(currentLogSN);
            if (null == in) {
                LOG.warning("Segment " + currentLogSN
                        + " doesn't exist, skip it");
                continue;
            }
            LOG.info("Start loading segment " + currentLogSN);
            CDataInputStream dataIn = new CDataInputStream(
                    new BufferedInputStream(in));
            long numEdits;
            try {
                numEdits = dir.loadFSEdits(dataIn, pendingCreates,
                        pendingCreateLastBlocks, maxLoadedLogSN);
            } finally {
                ReadWriteUtils.safeClose(dataIn);
            }
            LOG.info("Done loading segment " + currentLogSN + ", " + numEdits
                    + " edits loaded");
            try {
                verify();
            } catch (CorruptedImageException e) {
                LOG.severe("CorruptedImage found after load edit file "
                        + currentLogSN + ": " + e.getMessage());
                return;
            }
            return;
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 4) {
            System.out.println("Usage: [imageFile] [jn0] ... [jnn]");
            System.out.println("eg: ./bin/odis.sh run odis.dfs.namenode.FSImageAndEditsVerifier"
                    + " /disk2/odfs/namenode/image/fsimage.256"
                    + " nb097:3456 nb108:3456 nb108:4567");
            System.exit(1);
        }
        File imageFile = new File(args[0]);
        BaseConfiguration conf = new BaseConfiguration();
        String[] jns = new String[args.length - 1];
        for (int i = 1; i < args.length; ++i) {
            jns[i - 1] = args[i];
        }
        System.out.println(Arrays.deepToString(jns));
        conf.setProperty(DFSConfig.DFS_QJOURNAL_JOURNAL_NODES, jns);
        QuorumJournalManager journalMgr = new QuorumJournalManager(conf);
        FSImageAndEditsVerifier v = new FSImageAndEditsVerifier(imageFile,
                journalMgr);
        v.run();
    }

    private static final class FSBlockStore extends AbstractFSBlockStore {

        FSBlockStore() {
            super(new HashMap<Long, PlacedBlock>(),
                    new HashMap<Long, PlacedBlock>());
        }

        @Override
        void changeReplication(long[] blocks, int replications) {
            for (long block: blocks) {
                PlacedBlock pb = activeBlocks.get(block);
                if (pb == null) {
                    pb = blockMap.get(block);
                }
                if (pb == null) {
                    LOG.warning("Block " + block
                            + " not exists when change replication");
                    continue;
                }
                pb.setDesiredReplication(replications);
            }
        }

        @Override
        public void close() {}

    }

    private static final class FSDirectory extends
            AbstractFSDirectory<FSBlockStore> {

        protected FSDirectory(File imageFile,
                Map<String, FileINodeUC> pendingCreates,
                Map<Long, String[]> pendingCreateLastBlocks, 
                MutableLong maxLoadedLogSN) throws IOException {
            super(new FSBlockStore(), imageFile, new FsPermission(00777),
                    "kaiwoo", System.getProperty("user.name"), pendingCreates,
                    pendingCreateLastBlocks, maxLoadedLogSN);
        }

    }
}
