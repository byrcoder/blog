/**
 * @(#)DataNodeMetrics.java, 2012-4-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

import java.util.concurrent.atomic.AtomicLongArray;

/**
 * @author zhangduo
 */
public class DataNodeMetrics {
    private final AtomicLongArray metricsRecords = new AtomicLongArray(
            DataNodeMetricsItem.totalItems()
                    - DataNodeMetricsItem.systemInfoItems());

    public void increment(DataNodeMetricsItem item) {
        metricsRecords.incrementAndGet(item.offset()
                - DataNodeMetricsItem.systemInfoItems());
    }

    public void decrement(DataNodeMetricsItem item) {
        metricsRecords.decrementAndGet(item.offset()
                - DataNodeMetricsItem.systemInfoItems());
    }

    public void add(DataNodeMetricsItem item, long delta) {
        metricsRecords.addAndGet(
                item.offset() - DataNodeMetricsItem.systemInfoItems(), delta);
    }

    public void fillMetricsRecords(long[] metricsRecords) {
        for (int i = 0; i < this.metricsRecords.length(); i++) {
            metricsRecords[i + DataNodeMetricsItem.systemInfoItems()] = this.metricsRecords.get(i);
        }
    }
}
