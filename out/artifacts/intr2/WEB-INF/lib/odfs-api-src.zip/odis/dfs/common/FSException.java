/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 5, 2006
 */
package odis.dfs.common;

import java.io.IOException;

/**
 * Exception indicating any error condition thrown at server side. This is
 * usually used for error caused by the client (e.g. malformed requests). For
 * errors that the servers are responsible for (temporary out of resource), the
 * server should log and let the client retry through returning special values.
 * In the latter case, the client library should do the retry. We use error code
 * instead of exception hierarchy to indicate different errors because our RPC
 * cannot pass hierarchical classes.
 * 
 * @author zf
 */
public class FSException extends IOException {
    private static final long serialVersionUID = 8288806699839235893L;

    public static final int UNKNOWN = 0;

    public static final int ILLEGAL_PARAM = UNKNOWN + 1;

    public static final int ILLEGAL_STATE = ILLEGAL_PARAM + 1;

    public static final int NOT_ENOUGH_RESOURCE = ILLEGAL_STATE + 1;

    public static final int PERMISSION_DENIED = NOT_ENOUGH_RESOURCE + 1;

    public static final int NOT_ENOUGH_REPLICATION = PERMISSION_DENIED + 1;

    public static final int INVALID_BLOCK_INDEX = NOT_ENOUGH_REPLICATION + 1;

    public static final int PATH_TOO_LONG = INVALID_BLOCK_INDEX + 1;

    public static final int NOT_ACTIVE_NN = PATH_TOO_LONG + 1;

    public static final int NAMENODE_SHUTDOWN = NOT_ACTIVE_NN + 1;

    public static final int ZK_ERROR = NAMENODE_SHUTDOWN + 1;

    private int code;

    public int getCode() {
        return code;
    }

    public FSException(int code, String message) {
        super(message);
        this.code = code;
    }

    public FSException(int code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }
}
