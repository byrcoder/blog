/**
 * @(#)BlockInfo.java, Dec 10, 2010. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.common;

import java.util.Arrays;

/**
 * A class encapsulating all information about a block at client-side
 * 
 * @author zhangkun
 */
public class BlockInfo {
    /**
     * The offset of the block in the file
     */
    private long offset;

    private long block;

    private long len;

    private String[] locations;

    public BlockInfo() {}

    public BlockInfo(long b, long len, String[] locations, long offset) {
        this.block = b;
        this.len = len;
        this.locations = locations;
        this.offset = offset;
    }

    /**
     * Get the offset of the block within the file
     * 
     * @return
     */
    public long getOffset() {
        return offset;
    }

    /**
     * Get the length of the block
     * 
     * @return
     */
    public long getLength() {
        return len;
    }

    /**
     * Get the locations of the replicas of the block. A location is usually a
     * string in the form "IP:PORT"
     * 
     * @return
     */
    public String[] getLocations() {
        return locations;
    }

    /**
     * Get the block ID
     * 
     * @return
     */
    public long getBlockID() {
        return block;
    }

    @Override
    public String toString() {
        return "BlockInfo [offset=" + offset + ", block=" + block + ", len="
                + len + ", locations=" + Arrays.toString(locations) + "]";
    }

}
