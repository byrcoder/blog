/**
 * @(#)NameNodeMetrics.java, 2012-4-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.metrics;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLongArray;

import odis.dfs.common.IClientProtocolV3;
import odis.dfs.common.IDataToNameProtocol;
import odis.rpc2.ClientInfo;
import odis.rpc2.PermissionManager.PermitType;
import odis.rpc2.ServerCallListener;

/**
 * @author zhangduo
 */
public class NameNodeMetrics implements ServerCallListener {

    private final AtomicLongArray metricsRecords = new AtomicLongArray(
            NameNodeMetricsItem.totalItems()
                    - NameNodeMetricsItem.systemInfoItems());

    private static final class MetricsPair {
        public final int countOffset;

        public final int delayOffset;

        private MetricsPair(NameNodeMetricsItem count, NameNodeMetricsItem delay) {
            this.countOffset = count.offset()
                    - NameNodeMetricsItem.systemInfoItems();
            this.delayOffset = delay.offset()
                    - NameNodeMetricsItem.systemInfoItems();
        }

    }

    private final Map<Method, MetricsPair> method2MetricsPair;

    private void addMethod2Map(Map<Method, MetricsPair> map, Method method) {
        String methodName = method.getName();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < methodName.length(); i++) {
            char c = methodName.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append('_');
            }
            sb.append(Character.toUpperCase(c));
        }
        String enumName = sb.toString();
        String countName = enumName + "_COUNT";
        String delayName = enumName + "_DELAY";
        map.put(method, new MetricsPair(NameNodeMetricsItem.valueOf(countName),
                NameNodeMetricsItem.valueOf(delayName)));
    }

    public NameNodeMetrics() {
        Map<Method, MetricsPair> map = new HashMap<Method, MetricsPair>(
                IClientProtocolV3.class.getMethods().length
                        + IDataToNameProtocol.class.getMethods().length, 0.5f);
        for (Method method: IClientProtocolV3.class.getMethods()) {
            addMethod2Map(map, method);
        }
        for (Method method: IDataToNameProtocol.class.getMethods()) {
            addMethod2Map(map, method);
        }
        method2MetricsPair = Collections.unmodifiableMap(map);
    }

    private static final class Attach {
        long startTime;
    }

    @Override
    public Object createAttach(ClientInfo clientInfo) {
        return new Attach();
    }

    @Override
    public void startReceive(Method method, Object attach) {}

    @Override
    public void endReceive(Method method, Object[] args, Object attach) {
        metricsRecords.incrementAndGet(NameNodeMetricsItem.REQUEST_NUM.offset()
                - NameNodeMetricsItem.systemInfoItems());
    }

    @Override
    public void getPermit(Method method, PermitType permit, Object attach) {}

    @Override
    public void startCall(Method method, Object attach) {
        ((Attach) attach).startTime = System.currentTimeMillis();
    }

    @Override
    public void endCall(Method method, Object returnValue, Throwable error,
            Object attach) {
        long endTime = System.currentTimeMillis();
        long time = endTime - ((Attach) attach).startTime;
        MetricsPair pair = method2MetricsPair.get(method);
        if (pair != null) {
            metricsRecords.incrementAndGet(pair.countOffset);
            metricsRecords.addAndGet(pair.delayOffset, time);
        }
    }

    @Override
    public void callTimeout(Method method, Object returnValue, Throwable error,
            Object attach) {}

    @Override
    public void startSend(Method method, Object attach) {}

    @Override
    public void endSend(Method method, Object attach) {}

    public void fillMetricsRecords(long[] metricsRecords) {
        for (int i = 0; i < this.metricsRecords.length(); i++) {
            metricsRecords[i + NameNodeMetricsItem.systemInfoItems()] = this.metricsRecords.get(i);
        }
    }

}
