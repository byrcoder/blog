/**
 * @(#)ZooKeeperStore.java, 2012-12-25. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.dfs.namenode;

import java.util.ArrayList;
import java.util.List;

import odis.dfs.common.FSException;
import odis.io.BytesTranscoder;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;

import toolbox.collections.Pair;

/**
 * @author zhangduo
 */
class ZooKeeperStore<T> {

    private final ZooKeeper zk;

    private final String path;

    private final BytesTranscoder<T> transcoder;

    ZooKeeperStore(ZooKeeper zk, String path, BytesTranscoder<T> transcoder) {
        this.zk = zk;
        this.path = path;
        this.transcoder = transcoder;
    }

    void add(String name, T obj) throws FSException {
        String znode = path + "/" + name;
        byte[] data = transcoder.encode(obj);
        try {
            zk.create(znode, data, ZooDefs.Ids.OPEN_ACL_UNSAFE,
                    CreateMode.PERSISTENT);
        } catch (KeeperException e) {
            throw new FSException(FSException.ZK_ERROR, "add " + name + "->"
                    + obj + " failed", e);
        } catch (InterruptedException e) {
            throw new FSException(FSException.ZK_ERROR, "add " + name + "->"
                    + obj + " failed", e);
        }
    }

    void set(String name, T obj) throws FSException {
        String znode = path + "/" + name;
        byte[] data = transcoder.encode(obj);
        try {
            zk.setData(znode, data, -1);
        } catch (KeeperException e) {
            throw new FSException(FSException.ZK_ERROR, "set " + name + "->"
                    + obj + " failed", e);
        } catch (InterruptedException e) {
            throw new FSException(FSException.ZK_ERROR, "set " + name + "->"
                    + obj + " failed", e);
        }
    }

    void delete(String name) throws FSException {
        String znode = path + "/" + name;
        try {
            zk.delete(znode, -1);
        } catch (InterruptedException e) {
            throw new FSException(FSException.ZK_ERROR, "delete " + name
                    + " failed", e);
        } catch (KeeperException e) {
            throw new FSException(FSException.ZK_ERROR, "delete " + name
                    + " failed", e);
        }
    }

    List<Pair<String, T>> getAll() throws FSException {
        try {
            List<String> children = zk.getChildren(path, null);
            List<Pair<String, T>> objList = new ArrayList<Pair<String, T>>();
            for (String child: children) {
                objList.add(new Pair<String, T>(child,
                        transcoder.decode(zk.getData(path + "/" + child, null,
                                null))));
            }
            return objList;
        } catch (KeeperException e) {
            throw new FSException(FSException.ZK_ERROR, "getAll failed", e);
        } catch (InterruptedException e) {
            throw new FSException(FSException.ZK_ERROR, "getAll failed", e);
        }
    }
}
