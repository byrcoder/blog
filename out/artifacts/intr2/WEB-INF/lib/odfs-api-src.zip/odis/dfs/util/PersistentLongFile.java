package odis.dfs.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Logger;

import odis.util.MiscUtils;

import toolbox.misc.LogFormatter;

public class PersistentLongFile {
    private static final Logger LOG = LogFormatter
            .getLogger(PersistentLongFile.class);

    private final File file;

    private final long defaultVal;

    private long value;

    private boolean loaded = false;

    public PersistentLongFile(File file, long defaultVal) {
        this.file = file;
        this.defaultVal = defaultVal;
    }

    public long get() throws IOException {
        if (!loaded) {
            value = readFile(file, defaultVal);
            loaded = true;
        }
        return value;
    }

    public void set(long newVal) throws IOException {
        if (value != newVal || !loaded) {
            writeFile(file, newVal);
        }
        value = newVal;
        loaded = true;
    }

    /**
     * Atomically write the given value to the given file, including fsyncing.
     * 
     * @param file
     *            destination file
     * @param val
     *            value to write
     * @throws IOException
     *             if the file cannot be written
     */
    public static void writeFile(File file, long val) throws IOException {
        AtomicFileOutputStream fos = new AtomicFileOutputStream(file);
        try {
            fos.write(String.valueOf(val).getBytes());
            fos.write('\n');
            fos.close();
            fos = null;
        } finally {
            if (fos != null) {
                fos.abort();
            }
        }
    }

    public static long readFile(File file, long defaultVal) throws IOException {
        long val = defaultVal;
        if (file.exists()) {
            BufferedReader br = new BufferedReader(new FileReader(file));
            try {
                val = Long.valueOf(br.readLine());
                br.close();
                br = null;
            } finally {
                MiscUtils.safeClose(br);
            }
        }
        return val;
    }
}
