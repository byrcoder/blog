/**
 * @(#)SeqFileUtils.java, 2007-5-21. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import toolbox.collections.ArrayUtils;
import toolbox.misc.ClassUtils;

/**
 * @deprecated Use odis.app.view.SeqFileUtils instead. Utilities to process
 *             sequence file.
 * @author river
 */
@Deprecated
public class SeqFileUtils {

    /**
     * Load keys from sequence file into set.
     * 
     * @param fs
     * @param file
     * @return
     * @throws IOException
     */
    public static Set<Object> loadKeysToSet(FileSystem fs, File file)
            throws IOException {
        HashSet<Object> result = new HashSet<Object>();
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, new Path(file));
        try {
            IWritable key = ClassUtils.newInstance(reader.getKeyClass());
            IWritable value = ClassUtils.newInstance(reader.getValueClass());
            while (reader.next(key, value)) {
                result.add(key);
                key = ClassUtils.newInstance(reader.getKeyClass());
            }
        } finally {
            reader.close();
        }
        return result;
    }

    /**
     * Load keys and values into map.
     * 
     * @param fs
     * @param file
     * @return
     * @throws IOException
     */
    public static Map<Object, Object> loadToMap(FileSystem fs, File file)
            throws IOException {
        Map<Object, Object> map = new HashMap<Object, Object>();

        SequenceFile.Reader reader = new SequenceFile.Reader(fs, new Path(file));
        try {
            IWritable key = ClassUtils.newInstance(reader.getKeyClass());
            IWritable value = ClassUtils.newInstance(reader.getValueClass());
            while (reader.next(key, value)) {
                map.put(key, value);
                key = ClassUtils.newInstance(reader.getKeyClass());
                value = ClassUtils.newInstance(reader.getValueClass());
            }
        } finally {
            reader.close();
        }
        return map;
    }

    /**
     * Save map[key--value] to sequence file ordered by key.
     * 
     * @param fs
     * @param file
     * @param map
     * @throws IOException
     */
    @SuppressWarnings("rawtypes")
    public static void saveMap(FileSystem fs, File file, Map map)
            throws IOException {
        if (map.isEmpty()) {
            throw new IOException("map is empty");
        }

        Object[] keys = new Object[map.size()];
        Object[] values = new Object[map.size()];
        int index = 0;
        for (Iterator it = map.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            keys[index] = entry.getKey();
            values[index] = entry.getValue();
            index++;
        }
        ArrayUtils.sortArrays(keys, values);

        SequenceFile.Writer writer = new SequenceFile.Writer(fs,
                new Path(file), (Class) keys[0].getClass(),
                (Class) values[0].getClass());
        try {
            for (int i = 0; i < keys.length; i++) {
                writer.write((IWritable) keys[i], (IWritable) values[i]);
            }
        } finally {
            writer.close();
        }
    }

}
