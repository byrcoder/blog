/**
 * @(#)ChecksumOutputStream.java, 2011-4-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Adler32;

/**
 * This output stream computes checksum when writing one byte out.
 * 
 * @author leiran
 */
public class ChecksumOutputStream extends FilterOutputStream {
    private Adler32 checker;

    public ChecksumOutputStream(OutputStream out) {
        super(out);
        this.checker = new Adler32();
    }

    @Override
    public void write(int b) throws IOException {
        out.write(b);
        checker.update(b);
    }

    @Override
    public void write(byte b[]) throws IOException {
        out.write(b);
        checker.update(b);
    }

    @Override
    public void write(byte b[], int off, int len) throws IOException {
        out.write(b, off, len);
        checker.update(b, off, len);
    }

    public long getChecksum() {
        return checker.getValue();
    }
}
