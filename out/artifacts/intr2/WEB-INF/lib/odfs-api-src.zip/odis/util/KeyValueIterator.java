/**
 * @(#)KeyValueIterator.java, 2011-9-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.util.NoSuchElementException;

/**
 * An key value iterator over a collection.
 * 
 * @author zhangduo
 */
public interface KeyValueIterator<K, V> {

    /**
     * Returns <code>true</code> if the iteration has more elements.
     * 
     * @return
     */
    boolean hasNext();

    /**
     * Move to the next element in the iteration.
     * 
     * @exception NoSuchElementException
     *                iteration has no more elements.
     */
    void next();

    /**
     * Get the current Key.
     * 
     * @return
     * @exception IllegalStateException
     *                if the <tt>next</tt> method has not yet been called
     */
    K getKey();

    /**
     * Get the current Value.
     * 
     * @return
     * @exception IllegalStateException
     *                if the <tt>next</tt> method has not yet been called
     */
    V getValue();

    /**
     * Removes from the underlying collection the last element returned by the
     * iterator.
     * 
     * @exception IllegalStateException
     *                if the <tt>next</tt> method has not yet been called, or
     *                the <tt>remove</tt> method has already been called after
     *                the last call to the <tt>next</tt> method.
     */
    void remove();
}
