/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package odis.util;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.io.IFileSystem.PathFilter;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.LogFormatter;

/**
 * This utility writes logs into a SequenceFile. Rolling and compression are
 * supported.
 * 
 * @author zhangkun
 */
public class SequenceFileLogger {
    public static final Class<LongWritable> KEY_CLASS = LongWritable.class;

    public static final Class<StringWritable> VALUE_CLASS = StringWritable.class;

    private static final Logger LOG = LogFormatter.getLogger(SequenceFileLogger.class);

    private SequenceFile.Writer writer;

    private Path currentFile;

    private long rollingSize = 0;

    private int maxLogFiles = 0;

    private final Path logDir;

    private final String prefix;

    private final IFileSystem fs;

    /**
     * Set the maximum allowed number of log files under the log directory, with
     * the given name prefix. The oldest files will be deleted if this limit is
     * exceeded. Note there will be actually maximum (limit+1) files that exist,
     * prefix.0 is the file being written, while prefix.limit is the oldest
     * file.
     * 
     * @param limit
     *            the limit. Set to 0 (default) to disable limit.
     */
    public void setMaxLogFiles(int limit) {
        maxLogFiles = limit;
    }

    /**
     * Set the rolling size. If the current log file reaches the rolling size,
     * the logger will start a new file.
     * 
     * @param size
     *            the rolling size. Set to 0 (default) to disable rolling.
     */
    public void setRollingSize(long size) {
        rollingSize = size;
    }

    /**
     * Constructs a logger
     * 
     * @param fs
     *            the file system that stores the log files
     * @param logDir
     *            the directory where the log files are put in
     * @param prefix
     *            the name prefix of the log files
     * @throws java.io.IOException
     */
    public SequenceFileLogger(IFileSystem fs, Path logDir, String prefix)
            throws IOException {
        this.logDir = logDir;
        if (!fs.exists(logDir)) {
            fs.mkdirs(logDir);
        }
        this.prefix = prefix;
        this.fs = fs;
        startNewFile();
    }

    @Override
    public String toString() {
        return "[" + SequenceFileLogger.class.getSimpleName() + " dir="
                + logDir + " prefix=" + prefix + "]";
    }

    private void startNewFile() throws IOException {
        // close current writer
        if (writer != null) {
            try {
                writer.close();
            } catch (Throwable e) {
                LOG.log(Level.WARNING, this + " failed to close log file", e);
            }
            writer = null;
        }
        // see if target file exists
        Path newLogFile = new Path(logDir, prefix + ".0");
        if (fs.exists(newLogFile)) {
            // roll old files
            int[] oldNos = getSerialNos();
            if (oldNos != null && oldNos.length > 0) {
                LOG.info(this + " starting new file, oldest file: " + prefix
                        + "." + oldNos[oldNos.length - 1]);
                // roll old files
                for (int i = oldNos.length - 1; i >= 0; i--) {
                    String oldFileName = prefix + "." + oldNos[i];
                    if (maxLogFiles > 0 && oldNos[i] > maxLogFiles - 1) {
                        // delete oldest files if necessary
                        LOG.info(this + " deleting old log: " + oldFileName);
                        fs.delete(new Path(logDir, oldFileName));
                    } else {
                        // rename old files
                        fs.rename(new Path(logDir, oldFileName), new Path(
                                logDir, prefix + "." + (oldNos[i] + 1)));
                    }
                }
            }
        }
        currentFile = newLogFile;
        // open new writer
        writer = new SequenceFile.CompressedWriter(fs, newLogFile, KEY_CLASS,
                VALUE_CLASS, false,
                SequenceFile.CompressedWriter.DEFAULT_BLOCK_SIZE, false,
                CompressAlgo.GZIP);
    }

    public Path getCurrentFile() {
        return currentFile;
    }

    /**
     * Get a sorted list of serial numbers of existing files in the log dir.
     * 
     * @return
     * @throws java.io.IOException
     */
    private int[] getSerialNos() throws IOException {
        FileInfo[] files = fs.listFiles(logDir, new PathFilter() {
            @Override
            public boolean accept(Path path) {
                if (path.getName().startsWith(prefix + ".")) {
                    if (path.getName().substring(prefix.length() + 1).matches(
                            "\\d+"))
                        ;
                    return true;
                }
                return false;
            }
        });
        if (files == null) {
            return null;
        }
        int[] nos = new int[files.length];
        for (int i = 0; i < files.length; i++) {
            String name = files[i].getPath().getName();
            int dotPos = name.lastIndexOf(".");
            nos[i] = Integer.parseInt(name.substring(dotPos + 1));
        }
        Arrays.sort(nos);
        return nos;
    }

    private final LongWritable key = new LongWritable();

    private final StringWritable value = new StringWritable();

    /**
     * Write a log.
     * 
     * @param msg
     */
    public synchronized void log(String msg) {
        try {
            if (writer == null
                    || (rollingSize > 0 && writer.getSize() > rollingSize)) {
                startNewFile();
            }
            key.set(System.currentTimeMillis());
            value.set(msg);
            writer.write(key, value);
        } catch (Throwable e) {
            LOG.log(Level.WARNING, "Failed to log: " + msg, e);
        }
    }

    /**
     * Close the current file to make it readable. A new file will be opened
     * when next invocating to {@link #log(java.lang.String)} is made.
     * 
     * @throws java.io.IOException
     */
    public synchronized void closeWriter() throws IOException {
        if (writer != null) {
            writer.close();
            writer = null;
        }
    }
}
