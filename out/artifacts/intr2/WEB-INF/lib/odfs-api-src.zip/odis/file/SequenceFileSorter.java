/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.file;

import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.file.CompressUtils.CompressAlgo;
import odis.file.SequenceFile.Writer;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.Limit;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import toolbox.misc.LogFormatter;

/**
 * Sorter for sequence file. Now we can read the data out before all data
 * sorted.
 * 
 * @author river
 */
public class SequenceFileSorter {
    public static final String SORT_MEMORY = "merge_sort.memory";

    protected static final Logger LOG = LogFormatter.getLogger(SequenceFileSorter.class.getName());

    private static class RemoteFile {
        private FileSystem fs;

        private File file;

        private RemoteFile(FileSystem fs, File file) {
            this.fs = fs;
            this.file = file;
        }

        public String toString() {
            if (fs == null || file == null) {
                return "";
            }
            return fs.getName() + "://" + file;
        }

        @Override
        public int hashCode() {
            final int PRIME = 31;
            int result = 1;
            result = PRIME * result + ((file == null) ? 0 : file.hashCode());
            result = PRIME * result + ((fs == null) ? 0 : fs.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final RemoteFile other = (RemoteFile) obj;
            if (file == null) {
                if (other.file != null) {
                    return false;
                }
            } else if (!file.equals(other.file)) {
                return false;
            }
            if (fs == null) {
                if (other.fs != null) {
                    return false;
                }
            } else if (!fs.equals(other.fs)) {
                return false;
            }
            return true;
        }
    }

    private static final int DEFAULT_FACTOR;

    private static final int DEFAULT_MEMORY;
    static {
        DEFAULT_FACTOR = OdisLibConfig.conf().getInt(
                "file.seqfile.sort.factor", 100);
        boolean windows = System.getProperty("os.name", "linux").toUpperCase().startsWith(
                "WIN");
        boolean isTest = (System.getProperty("IS_TEST") != null);
        if (windows || isTest) {
            DEFAULT_MEMORY = 1;
        } else {
            DEFAULT_MEMORY = OdisLibConfig.conf().getInt(
                    "file.seqfile.sort.memory-mb", 100);
        }
    }

    protected int memory = DEFAULT_MEMORY * 1024 * 1024; // bytes

    protected int factor = DEFAULT_FACTOR; // merged per pass

    private BlockingQueue<RemoteFile> inFiles = new LinkedBlockingQueue<RemoteFile>();

    private volatile int processed;

    private volatile long processedSize;

    private FileSystem nfs;

    private IRecordComparator comparator;

    private Class<? extends IWritable> keyClass;

    private Class<? extends IWritable> valClass;

    private File outFile;

    private int segments = -1;

    private int pass = -1;

    private boolean keyLengthFixed;

    private boolean valLengthFixed;

    private boolean objectCompressed;

    private boolean objectCompressedSet = false;

    public SequenceFileSorter(FileSystem nfs, File outFile,
            Class<? extends IWritableComparable> keyClass,
            Class<? extends IWritable> valClass, IRecordComparator comparator) {
        this(nfs, outFile, keyClass, valClass, comparator, false);
        this.objectCompressedSet = false;
    }

    public SequenceFileSorter(FileSystem nfs, File outFile,
            Class<? extends IWritableComparable> keyClass,
            Class<? extends IWritable> valClass, IRecordComparator comparator,
            boolean objectCompressed) {
        this.nfs = nfs;
        this.outFile = outFile;
        this.keyClass = keyClass;
        this.valClass = valClass;
        this.comparator = comparator;
        this.keyLengthFixed = WritableRegistry.getWritableSize(keyClass) >= 0;
        this.valLengthFixed = keyLengthFixed
                && WritableRegistry.getWritableSize(valClass) >= 0;
        this.objectCompressed = objectCompressed;
        objectCompressedSet = true;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public int getMemory() {
        return memory;
    }

    public void setFactor(int factor) {
        this.factor = factor;
    }

    public int getFactor() {
        return this.factor;
    }

    public boolean addInputFile(FileSystem fs, File file) {
        if (!queueInputFile(fs, file)) {
            return false;
        }
        if (!endInputQueue()) {
            return false;
        }
        return true;
    }

    public boolean queueInputFile(FileSystem fs, File file) {
        try {
            RemoteFile rf = new RemoteFile(fs, file);
            LOG.info("Adding remote file: " + rf);
            if (inFiles.contains(rf)) {
                return false;
            }
            inFiles.put(rf);
            return true;
        } catch (InterruptedException e) {
            return false;
        }
    }

    public boolean dequeueInputFile(FileSystem fs, File file) {
        RemoteFile rf = new RemoteFile(fs, file);
        LOG.info("Removing remote file: " + rf);
        return inFiles.remove(rf);
    }

    public boolean endInputQueue() {
        return queueInputFile(null, null);
    }

    public int doneInputCount() {
        return processed;
    }

    public long doneInputSize() {
        return processedSize;
    }

    protected int sortPass() throws IOException {
        LOG.fine("running sort pass");
        SortPass sortPass = new SortPass(); // make the SortPass
        try {
            return sortPass.run(); // run it
        } finally {
            sortPass.close(); // close it
        }
    }

    protected int mergePass(int pass, boolean last) throws IOException {
        LOG.fine("running merge pass=" + pass);
        MergePass mergePass = new MergePass(pass, last);
        try { // make a merge pass
            return mergePass.run(); // run it
        } finally {
            mergePass.close(); // close it
        }
    }

    /**
     * Read in all the sequence files and do the first sort pass. After
     * prepare(), data is ready for read.
     * 
     * @throws IOException
     */
    public void prepare() throws IOException {
        segments = sortPass();
        pass = 0;
        while (segments > factor) {
            segments = mergePass(++pass, false);
        }
    }

    public void complete() throws IOException {
        assert segments >= 0;
        assert pass >= 0;
        while (segments > 1) {
            segments = mergePass(++pass, segments <= factor);
        }
    }

    public IRecordReader<IWritable, IWritable> read() throws IOException {
        assert segments >= 0;
        assert pass >= 0;
        if (segments == 1) {
            return (IRecordReader) new SequenceFile.Reader(nfs, new Path(
                    outFile));
        } else {
            return new SortReader(pass);
        }
    }

    public void cleanTempFiles() throws IOException {
        if (segments == 1) {
            return;
        } else {
            File file = new File(outFile.getPath() + "." + pass);
            LOG.info("Clean temporary file: " + file);
            nfs.delete(new Path(file));
        }
    }

    protected class SortReader implements IRecordReader<IWritable, IWritable> {
        private MergeQueue queue;

        private DataInputBuffer inBuf = new DataInputBuffer();

        private long size;

        private long pos;

        private byte[] oubuf;

        private CompressAlgo compressAlgo = CompressAlgo.LZO;

        public SortReader(int pass) throws IOException {
            if (objectCompressed) {
                oubuf = new byte[4096];
            }
            queue = new MergeQueue(factor);
            File inFile = new File(outFile.getPath() + "." + pass);
            size = nfs.getLength(new Path(inFile));
            pos = 0;
            FSDataInputStream in = nfs.open(new Path(inFile));

            try {
                long end = nfs.getLength(new Path(inFile));

                while (in.getPos() < end && queue.size() < factor) {
                    long length = in.readLong();
                    @SuppressWarnings("unused")
                    long count = in.readLong();
                    FSDataInputStream readerIn = nfs.open(new Path(inFile),
                            memory / (factor + 1));
                    readerIn.seek(in.getPos());
                    SequenceFile.Reader reader = new SequenceFile.Reader(
                            readerIn, length);
                    reader.disableSync(); // disable sync on temp files
                    compressAlgo = reader.getCompressAlgo();

                    MergeStream ms = new MergeStream(reader); // add segment to queue
                    if (ms.next()) {
                        pos += ms.in.getPos();
                        queue.add(ms);
                    }
                    in.seek(reader.getFileEnd());
                }
            } finally {
                in.close();
            }
        }

        public boolean next(IWritable key, IWritable value) throws IOException {
            if (queue.size() == 0) {
                return false;
            }

            MergeStream ms = queue.remove();
            long oldPos = ms.in.getPos();
            DataOutputBuffer buf = ms.buffer;
            inBuf.reset(buf.getData(), 0, buf.size());
            key.readFields(inBuf);

            if (objectCompressed) {
                int ucSize = inBuf.readVInt();
                Limit.checkBufferSize(ucSize);
                if (ucSize > oubuf.length) {
                    int newSize = oubuf.length << 1;
                    while (newSize < ucSize) {
                        newSize = newSize << 1;
                    }
                    oubuf = new byte[newSize];
                }

                CompressUtils.uncompress(inBuf.getBuffer(),
                        inBuf.getPosition(), inBuf.getSize(), oubuf, 0,
                        compressAlgo, ucSize);
                inBuf.reset(oubuf, 0, ucSize);
            }
            value.readFields(inBuf);

            boolean hasMore = ms.next();
            long newPos = ms.in.getPos();
            pos += (newPos - oldPos);

            if (hasMore) {
                queue.add(ms);
            } else {
                ms.in.close();
            }
            return true;
        }

        public void close() throws IOException {
            queue.close();
        }

        public Class<? extends IWritable> getKeyClass() {
            return keyClass;
        }

        public Class<? extends IWritable> getValueClass() {
            return valClass;
        }

        public long getPos() throws IOException {
            return pos;
        }

        public long getSize() throws IOException {
            return size;
        }

    }

    protected class SortPass {

        protected int limit = memory;

        protected DataOutputBuffer buffer = new DataOutputBuffer(limit + 10240);

        // because we read over a little bit
        protected byte[] rawBuffer;

        protected int[] starts = new int[1024];

        protected int[] pointers = new int[starts.length];

        protected int[] pointersCopy = new int[starts.length];

        protected int[] keyLengths = new int[starts.length];

        protected int[] lengths = new int[starts.length];

        protected SequenceFile.Reader in;

        protected FSDataOutputStream out;

        protected long lastTotalEntrySize = 0;

        public SortPass() {}

        private SequenceFile.Reader nextInputReader() throws IOException {
            RemoteFile rf = null;
            while (true)
                try {
                    rf = inFiles.take();
                    if (rf.file == null && rf.fs == null) {
                        return null;
                    }
                    LOG.info("Merge in data from " + rf);
                    SequenceFile.Reader reader = new SequenceFile.Reader(rf.fs,
                            new Path(rf.file));
                    if (objectCompressedSet) {
                        if (reader.isObjectCompressed() != objectCompressed) {
                            throw new IOException(
                                    "object compression setting inconsistency");
                        }
                    } else {
                        objectCompressed = reader.isObjectCompressed();
                    }
                    processed++;
                    return reader;
                } catch (InterruptedException e) {
                    continue;
                }
        }

        private int getDataSizeInSequenceFile(int keyLength, int totalLength) {
            int size = totalLength;
            if (!keyLengthFixed) {
                size += DataOutputBuffer.getVIntSize(keyLength);
            }
            if (!valLengthFixed) {
                size += DataOutputBuffer.getVIntSize(totalLength);
            }
            return size;
        }

        public int run() throws IOException {
            processed = 0;
            processedSize = 0;
            int segments = 0;

            in = nextInputReader();
            try {
                while (in != null) {
                    // reset buffer
                    int count = 0;
                    buffer.reset();
                    LOG.fine("reading segment " + segments);
                    lastTotalEntrySize = 0;
                    // read a segment
                    while (in != null && buffer.size() < limit) {
                        int start = buffer.size(); // read an entry into buffer
                        int keyLength = -1;
                        try {
                            keyLength = in.next(buffer);
                        } catch (IOException e) {
                            LOG.log(Level.SEVERE, "Error while reading from "
                                    + in, e);
                            throw e;
                        }
                        int length = buffer.size() - start;

                        if (keyLength == -1) {
                            in.close();
                            in = nextInputReader(); // = null when at the end
                            continue;
                        }

                        if (count == starts.length) {
                            grow();
                        }

                        starts[count] = start; // update pointers
                        pointers[count] = count;
                        lengths[count] = length;
                        keyLengths[count] = keyLength;

                        int entrySize = getDataSizeInSequenceFile(keyLength,
                                length);
                        lastTotalEntrySize += entrySize;
                        processedSize += entrySize;
                        count++;
                    }

                    // buffer is full -- sort & flush it
                    LOG.fine("sorting segment " + segments);
                    rawBuffer = buffer.getData();
                    sort(count);
                    LOG.fine("flushing segment " + segments);
                    flush(count, segments == 0 && in == null);
                    segments++;
                }
            } finally {
                if (in != null) {
                    in.close();
                }
            }
            return segments;
        }

        public void close() throws IOException {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }

        protected void grow() {
            int newLength = starts.length * 3 / 2;
            starts = grow(starts, newLength);
            pointers = grow(pointers, newLength);
            pointersCopy = new int[newLength];
            keyLengths = grow(keyLengths, newLength);
            lengths = grow(lengths, newLength);
        }

        private int[] grow(int[] old, int newLength) {
            int[] result = new int[newLength];
            System.arraycopy(old, 0, result, 0, old.length);
            return result;
        }

        protected void flush(int count, boolean done) throws IOException {
            if (out == null) {
                File sortpassOutFile = done ? outFile : new File(
                        outFile.getPath() + ".0");
                out = nfs.create(new Path(sortpassOutFile));
            }

            if (!done) { // an intermediate file
                out.writeLong(lastTotalEntrySize); // write size
                out.writeLong(count); // write count
            }

            Writer writer = new SequenceFile.Writer(out, keyClass, valClass,
                    objectCompressed);
            if (!done) {
                writer.disableSync(); // disable sync on temp files
            }

            long oldPos = out.getPos();
            for (int i = 0; i < count; i++) { // write in sorted order
                int p = pointers[i];
                writer.append(rawBuffer, starts[p], lengths[p], keyLengths[p]);
            }

            long dataSize = out.getPos() - oldPos;
            if (!done && dataSize != lastTotalEntrySize) {// for last time, sync emitted
                throw new RuntimeException("bad data");
            }
        }

        protected void sort(int count) {
            System.arraycopy(pointers, 0, pointersCopy, 0, count);
            mergeSort(pointersCopy, pointers, 0, count);
        }

        private void mergeSort(int src[], int dest[], int low, int high) {
            int length = high - low;

            // Insertion sort on smallest arrays
            if (length < 7) {
                for (int i = low; i < high; i++)
                    for (int j = i; j > low
                            && compare(dest[j - 1], dest[j]) > 0; j--)
                        swap(dest, j, j - 1);
                return;
            }

            // Recursively sort halves of dest into src
            int mid = (low + high) >>> 1;
            mergeSort(dest, src, low, mid);
            mergeSort(dest, src, mid, high);

            // If list is already sorted, just copy from src to dest. This is an
            // optimization that results in faster sorts for nearly ordered lists.
            if (compare(src[mid - 1], src[mid]) <= 0) {
                System.arraycopy(src, low, dest, low, length);
                return;
            }

            // Merge sorted halves (now in src) into dest
            for (int i = low, p = low, q = mid; i < high; i++) {
                if (q >= high || p < mid && compare(src[p], src[q]) <= 0) {
                    dest[i] = src[p++];
                } else {
                    dest[i] = src[q++];
                }
            }
        }

        private int compare(int i, int j) {
            int v = comparator.compare(rawBuffer, starts[i], keyLengths[i],
                    lengths[i] - keyLengths[i], rawBuffer, starts[j],
                    keyLengths[j], lengths[j] - keyLengths[j]);
            return v;
        }

        private void swap(int x[], int a, int b) {
            int t = x[a];
            x[a] = x[b];
            x[b] = t;
        }
    }

    protected class MergePass {

        private int pass;

        private boolean last;

        private MergeQueue queue;

        private FSDataInputStream in;

        private File inFile;

        public MergePass(int pass, boolean last) throws IOException {
            this.pass = pass;
            this.last = last;

            this.queue = new MergeQueue(factor, last ? outFile : new File(
                    outFile.getPath() + "." + this.pass), last);

            this.inFile = new File(outFile.getPath() + "." + (pass - 1));
            this.in = nfs.open(new Path(inFile));
        }

        public void close() throws IOException {
            in.close(); // close and delete input
            nfs.delete(new Path(inFile));
            queue.close(); // close queue
        }

        public int run() throws IOException {
            int segments = 0;
            long end = nfs.getLength(new Path(inFile));
            while (in.getPos() < end) {
                LOG.finer("merging segment " + segments);
                long totalLength = 0;
                long totalCount = 0;
                while (in.getPos() < end && queue.size() < factor) {
                    long length = in.readLong();
                    long count = in.readLong();
                    totalLength += length;
                    totalCount += count;

                    FSDataInputStream readerIn = nfs.open(new Path(inFile),
                            memory / (factor + 1));
                    readerIn.seek(in.getPos());
                    SequenceFile.Reader reader = new SequenceFile.Reader(
                            readerIn, length);
                    reader.disableSync(); // disable sync on temp files

                    MergeStream ms = new MergeStream(reader); // add segment to queue
                    if (ms.next()) {
                        queue.add(ms);
                    }

                    in.seek(reader.getFileEnd());
                }

                if (!last) { // intermediate file
                    queue.out.writeLong(totalLength); // write size
                    queue.out.writeLong(totalCount); // write count
                }

                queue.merge(); // do a merge
                segments++;
            }
            return segments;
        }
    }

    private final Comparator<MergeStream> mergeStreamComparator = new Comparator<MergeStream>() {

        @Override
        public int compare(MergeStream o1, MergeStream o2) {
            return comparator.compare(o1.buffer.getData(), 0, o1.keyLength,
                    o1.buffer.size() - o1.keyLength, o2.buffer.getData(), 0,
                    o2.keyLength, o2.buffer.size() - o2.keyLength);
        }
    };

    private class MergeStream {

        private SequenceFile.Reader in;

        private DataOutputBuffer buffer = new DataOutputBuffer();

        private int keyLength;

        public MergeStream(SequenceFile.Reader reader) throws IOException {
            if (reader.getKeyClass() != keyClass) {
                throw new IOException("wrong key class: "
                        + reader.getKeyClass() + " is not " + keyClass);
            }
            if (reader.getValueClass() != valClass) {
                throw new IOException("wrong value class: "
                        + reader.getValueClass() + " is not " + valClass);
            }
            this.in = reader;
        }

        public boolean next() throws IOException {
            buffer.reset();
            keyLength = in.next(buffer);
            return keyLength >= 0;
        }

    }

    private class MergeQueue extends PriorityQueue<MergeStream> {
        private static final long serialVersionUID = 1L;

        private FSDataOutputStream out;

        private boolean done;

        public MergeQueue(int size) {
            super(size, mergeStreamComparator);
        }

        public MergeQueue(int size, File out, boolean done) throws IOException {
            super(size, mergeStreamComparator);
            this.out = nfs.create(new Path(out), true, memory / (factor + 1));
            this.done = done;
        }

        public void merge() throws IOException {
            SequenceFile.Writer writer = new SequenceFile.Writer(out, keyClass,
                    valClass, objectCompressed);
            if (!done) {
                writer.disableSync(); // disable sync on temp files
            }

            while (size() != 0) {
                MergeStream ms = remove();
                DataOutputBuffer buffer = ms.buffer; // write top entry
                writer.append(buffer.getData(), 0, buffer.size(), ms.keyLength);

                if (ms.next()) { // has another entry
                    add(ms);
                } else {
                    ms.in.close();
                }
            }
        }

        public void close() throws IOException {
            MergeStream ms; // close inputs
            while (!isEmpty()) {
                ms = remove();
                ms.in.close();
            }
            if (out != null)
                out.close(); // close output
        }
    }

}
