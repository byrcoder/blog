/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.file;

import java.io.IOException;

import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.IFileSystem;
import odis.io.Path;

/**
 * FIXME: Need javadoc
 * 
 * @author david
 */
public class RecordFile {

    public static abstract class Writer<K, V> implements IRecordWriter<K, V> {
        protected FSDataOutputStream out;

        public Writer(FSDataOutputStream out) {
            this.out = out;
        }

        public Writer(IFileSystem fs, Path filename, boolean overwrite)
                throws IOException {
            if (fs.exists(filename)) {
                if (overwrite) {
                    if (!fs.delete(filename))
                        throw new IOException("cannot delete existing file "
                                + filename);
                } else
                    throw new IOException("file " + filename + " cannot be "
                            + "override");
            }
            this.out = fs.create(filename, overwrite);
        }

        public long getSize() throws IOException {
            return out.getPos();
        }

        public void close() throws IOException {
            out.close();
        }
    }

    public static abstract class Reader<K, V> implements IRecordReader<K, V> {
        protected FSDataInputStream in;

        protected long length;

        public Reader(FSDataInputStream in) {
            this.in = in;
        }

        public Reader(IFileSystem nfs, Path filename, int bufferSize)
                throws IOException {
            this.in = nfs.open(filename, bufferSize);
            this.length = nfs.getLength(filename);
        }

        public long getPos() throws IOException {
            return in.getPos();
        }

        public long getSize() throws IOException {
            return length;
        }

        public void close() throws IOException {
            in.close();
        }
    }

}
