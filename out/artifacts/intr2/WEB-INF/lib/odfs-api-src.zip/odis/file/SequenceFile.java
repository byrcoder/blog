/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.file;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetAddress;
import java.rmi.server.UID;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.dfs.client.DistributedFileSystem;
import odis.file.CompressUtils.CompressAlgo;
import odis.file.CompressUtils.CompressedData;
import odis.io.BadObjectException;
import odis.io.BmzCompression;
import odis.io.CDataOutputStream;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.DirectByteArrayOutputStream;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Limit;
import odis.io.Path;
import odis.serialize.DynamicWritableRegistry;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.WritableComparator;
import odis.serialize.lib.StringWritable;
import odis.util.ByteArrayBufferPool;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.text.util.HexString;
import toolbox.text.util.PropertiesString;

/**
 * Support for flat files of binary key/value pairs. The format of a sequence
 * file is a header followed by records {header,(key,value)*}.
 * <p>
 * The file format is described in detail in Odis Dev Manual:
 * https://dev.kaiwoo.cn/svn/outfox/outfox/doc/OdisTutorial/Manual
 * </p>
 * <p>
 * ChangeLog from nutch code base:<br>
 * <code> 
 * (yitao) Change the writer so that it will flush a block when next record 
 *         will go beyond the current block.<br>
 * (river) 支持定长的key length<br>
 * (river) 数据长度和key length使用vint保存<br>
 * </code>
 * </p>
 * <p>
 * ChangeLog in odis code base: <br>
 * <code>
 * (zl) Port to odis.file.*. Support IRecordWriter, IRecordReader interface.<br> 
 * (david) added support to IFixedLengthStruct to replace FIXED_LENGTH field.<br>
 * (zf) Block compressed sequence file.<br>
 * (jiangfy) 支持多种压缩算法: LZO 和 GZIP<br>
 * </code>
 * </p>
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public class SequenceFile {

    protected static final Logger LOG = LogFormatter.getLogger(SequenceFile.class.getName());

    public static final byte VERSION_NUMBER_OLD = 5;

    public static final byte VERSION_NUMBER_NEW = 6;

    public static final byte[] SEQ_VERSION_OLD = new byte[] {
        (byte) 'S', (byte) 'E', (byte) 'Q', VERSION_NUMBER_OLD
    };

    public static final byte[] SEQ_VERSION_NEW = new byte[] {
        (byte) 'S', (byte) 'E', (byte) 'Q', VERSION_NUMBER_NEW
    };

    public static final int HEADER_SIZE = 256;

    public static final int HEADER_RESERVED_SIZE = 23;

    public static final int SYNC_ESCAPE = 0x7fffffff;

    // sync value of "length" as vInt
    public static final int SYNC_ESCAPE_SIZE = CDataOutputStream.calcVIntSize(SYNC_ESCAPE);

    public static final int SYNC_HASH_SIZE = 16;// number of bytes in hash

    public static final int SYNC_SIZE = SYNC_ESCAPE_SIZE + SYNC_HASH_SIZE;

    // escape + hash
    public static final int SYNC_INTERVAL = 100 * SYNC_SIZE;

    protected static final byte[] SYNC;

    public static byte[] getSync() {
        return Arrays.copyOf(SYNC, SYNC.length);
    }

    public static final int NOT_COMPRESSED = 0;

    public static final int OBJECT_LEVEL_COMPRESSION = 0x01;

    // each compression chunk will be at most compression_block_size + 
    // COMPRESS_CHUNK_EXTRA_SIZE long. If longer, we'll split into multiple 
    // chunks.
    public static final int COMPRESS_CHUNK_EXTRA_SIZE = 128 * 1024;

    public static final CompressAlgo DEFAULT_COMPRESS_ALGO = CompressAlgo.LZO;

    static {
        try { // use hash of uid + host
            MessageDigest digester = MessageDigest.getInstance("MD5");
            digester.update((new UID() + "@" + InetAddress.getLocalHost()).getBytes());
            SYNC = digester.digest();
        } catch (Exception e) {
            System.err.println("Cannot initialize SYNC for sequence file by "
                    + "looking up local host name. ");
            throw new RuntimeException(e);
        }
    }

    /**
     * The IRecordWriter for writing a sequence-file.
     * 
     * @author zl
     */
    public static class Writer implements IRecordWriter<Object, Object> {

        protected final OutputBufferPool outputBufferPool;

        protected final IFileSystem fs;

        protected final Path target;

        protected final Class<? extends IWritable> keyClass;

        protected final Class<? extends IWritable> valClass;

        protected FSDataOutputStream out;

        private int lastEntrySize = 0; // Size of the last record

        private int lastEntryAndPrefixSize = 0; // Size of the last record and prefix

        // Insert a globally unique 16-byte value every few entries, so that one
        // can seek into the middle of a file and then synchronize with record
        // starts and ends by scanning for this value.
        private long lastSyncPos; // position of last sync

        protected byte[] sync = SYNC; // 16 random bytes

        protected int fixedKeyLength = 0;

        protected int fixedValLength = 0; // only used by BlockCompressedWriter

        protected int fixedLength = 0;

        protected CompressAlgo compressAlgo;

        /**
         * @deprecated use the version with Path instead
         * @param nfs
         * @param file
         * @param keyClass
         * @param valClass
         * @throws IOException
         */
        @Deprecated
        public Writer(FileSystem nfs, File file, Class keyClass, Class valClass)
                throws IOException {
            this(nfs, file, keyClass, valClass, null, false);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @throws IOException
         *             if an I/O error occurs
         */
        public Writer(IFileSystem fs, Path file, Class keyClass, Class valClass)
                throws IOException {
            this(fs, file, keyClass, valClass, null, false);
        }

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public Writer(FileSystem nfs, File file, Class keyClass,
                Class valClass, Properties properties) throws IOException {
            this(nfs, file, keyClass, valClass, properties, false);
        }

        /**
         * The constructor.
         * 
         * @param nfs
         * @param file
         * @param keyClass
         * @param valClass
         * @param properties
         * @throws IOException
         */
        public Writer(IFileSystem fs, Path file, Class keyClass,
                Class valClass, Properties properties) throws IOException {
            this(fs, file, keyClass, valClass, properties, false);
        }

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public Writer(FileSystem nfs, File file, Class keyClass,
                Class valClass, boolean override) throws IOException {
            this(nfs, file, keyClass, valClass, null, override);
        }

        /**
         * Open a file to write records
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param override
         *            override the file if existed
         * @throws IOException
         *             if an I/O error occurs
         */
        public Writer(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean override) throws IOException {
            this(fs, file, keyClass, valClass, null, override);
        }

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public Writer(FileSystem fs, File file, Class keyClass, Class valClass,
                Properties properties, boolean overwrite) throws IOException {
            this(fs, file, keyClass, valClass, properties, overwrite, 0);
        }

        /**
         * Opens a file to write records
         * 
         * @param fs
         *            the instance of file system
         * @param file
         *            the name of file
         * @param keyClass
         *            the key class in the file
         * @param valClass
         *            the value class in the file
         * @param overwrite
         *            whether to overwrite if the file exists
         * @throws IOException
         *             if an I/O error occurs
         */
        public Writer(IFileSystem fs, Path file, Class keyClass,
                Class valClass, Properties properties, boolean overwrite)
                throws IOException {
            this(fs, file, keyClass, valClass, properties, overwrite, 0,
                    DEFAULT_COMPRESS_ALGO);
        }

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        protected Writer(FileSystem fs, File file, Class keyClass,
                Class valClass, Properties properties, boolean overwrite,
                int compressBlockSize) throws IOException {
            this(fs, new Path(file), keyClass, valClass, properties, overwrite,
                    compressBlockSize, DEFAULT_COMPRESS_ALGO);
        }

        protected String fn() {
            if (fs == null) {
                return "<stream>";
            }
            return fs.getName() + ":" + target;
        }

        /**
         * @param compressBlockSize
         *            used by BlockCompressedWritable to pass in compression
         *            block size (>0), normal Writer always passes
         *            NOT_COMPRESSED (0)
         */
        protected Writer(IFileSystem fs, Path file, Class keyClass,
                Class valClass, Properties properties, boolean overwrite,
                int compressBlockSize, CompressAlgo compressAlgo)
                throws IOException {
            this(fs, file, keyClass, valClass, properties, overwrite,
                    compressBlockSize, compressAlgo,
                    OutputBufferPoolHolder.DEFAULT_POOL);
        }

        protected Writer(IFileSystem fs, Path file, Class keyClass,
                Class valClass, Properties properties, boolean overwrite,
                int compressBlockSize, CompressAlgo compressAlgo,
                OutputBufferPool outputBufferPool) throws IOException {
            this.fs = fs;
            this.target = file;
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.out = null;
            this.compressAlgo = compressAlgo;
            this.outputBufferPool = outputBufferPool;

            if (fs.exists(target)) {
                if (overwrite) {
                    if (!fs.delete(target)) {
                        throw new IOException("cannot delete existing file "
                                + fn());
                    }
                } else {
                    throw new IOException("file " + fn() + " cannot be "
                            + "overwritten");
                }
            }

            init(fs.create(target), properties, compressBlockSize, compressAlgo);
        }

        public Writer(DistributedFileSystem dfs, Path file, Class keyClass,
                Class valClass, boolean overwrite, int flags)
                throws IOException {
            this(dfs, file, keyClass, valClass, null, overwrite, 0,
                    DEFAULT_COMPRESS_ALGO, flags);
        }

        public Writer(DistributedFileSystem dfs, Path file, Class keyClass,
                Class valClass, Properties properties, boolean overwrite,
                int compressBlockSize, CompressAlgo compressAlgo, int flags)
                throws IOException {
            this(dfs, file, keyClass, valClass, properties, overwrite,
                    compressBlockSize, compressAlgo, flags,
                    OutputBufferPoolHolder.DEFAULT_POOL);
        }

        public Writer(DistributedFileSystem dfs, Path file, Class keyClass,
                Class valClass, Properties properties, boolean overwrite,
                int compressBlockSize, CompressAlgo compressAlgo, int flags,
                OutputBufferPool outputBufferPool) throws IOException {
            this.fs = dfs;
            this.target = file;
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.out = null;
            this.compressAlgo = compressAlgo;
            this.outputBufferPool = outputBufferPool;

            if (fs.exists(target)) {
                if (overwrite) {
                    if (!fs.delete(target)) {
                        throw new IOException("cannot delete existing file "
                                + fn());
                    }
                } else {
                    throw new IOException("file " + fn() + " cannot be "
                            + "overwritten");
                }
            }

            init(new FSDataOutputStream(dfs.createRaw(file, overwrite, false,
                    flags)), null, 0, compressAlgo);
        }

        /**
         * Construct a writer directly from an FSDataOutputStream.
         * 
         * @param ostream
         *            the FSDataOutputStream that data writes to. It should be a
         *            fresh stream to which nothing has been written before.
         * @param compressBlockSize
         *            used by BlockCompressedWritable to pass in compression
         *            block size (>0), normal Writer always passes
         *            NOT_COMPRESSED (0)
         */
        public Writer(FSDataOutputStream ostream, Class keyClass,
                Class valClass, Properties properties, int compressBlockSize)
                throws IOException {
            this(ostream, keyClass, valClass, properties, compressBlockSize,
                    OutputBufferPoolHolder.DEFAULT_POOL);
        }

        public Writer(FSDataOutputStream ostream, Class keyClass,
                Class valClass, Properties properties, int compressBlockSize,
                OutputBufferPool outputBufferPool) throws IOException {
            this.fs = null;
            this.target = null;
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.outputBufferPool = outputBufferPool;

            init(ostream, properties, compressBlockSize, DEFAULT_COMPRESS_ALGO);
        }

        /**
         * Construct a writer directly from an FSDataOutputStream.
         * 
         * @param ostream
         *            the FSDataOutputStream that data writes to. It should be a
         *            fresh stream to which nothing has been written before.
         * @param compressAlgo
         *            compress algorithm. If compressBlockSize == 0, this
         *            parameter is not used.
         * @param compressBlockSize
         *            used by BlockCompressedWritable to pass in compression
         *            block size (>0), normal Writer always passes
         *            NOT_COMPRESSED (0)
         */
        public Writer(FSDataOutputStream ostream, Class keyClass,
                Class valClass, Properties properties, int compressBlockSize,
                CompressAlgo compressAlgo) throws IOException {
            this(ostream, keyClass, valClass, properties, compressBlockSize,
                    compressAlgo, OutputBufferPoolHolder.DEFAULT_POOL);
        }

        public Writer(FSDataOutputStream ostream, Class keyClass,
                Class valClass, Properties properties, int compressBlockSize,
                CompressAlgo compressAlgo, OutputBufferPool outputBufferPool)
                throws IOException {
            this.fs = null;
            this.target = null;
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.outputBufferPool = outputBufferPool;

            init(ostream, properties, compressBlockSize, compressAlgo);
        }

        /**
         * Directly open at creation: write to an arbitrary stream using a
         * specified buffer size. This method is only used during sorting, it
         * should not be used outside.
         */
        Writer(FSDataOutputStream out, Class keyClass, Class valClass,
                boolean objectCompressed) throws IOException {
            this(out, keyClass, valClass, objectCompressed,
                    OutputBufferPoolHolder.DEFAULT_POOL);
        }

        Writer(FSDataOutputStream out, Class keyClass, Class valClass,
                boolean objectCompressed, OutputBufferPool outputBufferPool)
                throws IOException {
            this.fs = null;
            this.target = null;
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.outputBufferPool = outputBufferPool;
            int compressInfo = 0;
            if (objectCompressed) {
                compressInfo = OBJECT_LEVEL_COMPRESSION << 28;
            }
            init(out, null, compressInfo, DEFAULT_COMPRESS_ALGO);
        }

        /**
         * Disable sync in the file
         */
        public void disableSync() {
            sync = null;
        }

        public byte[] getSync() {
            return sync == null ? null : Arrays.copyOf(sync, sync.length);
        }

        /**
         * Returns the size of last record (key/value)
         * 
         * @return the size of last record
         */
        public synchronized int getLastEntrySize() {
            return lastEntrySize;
        }

        /**
         * Returns the size of last record (key/value) and prefix
         * 
         * @return the size of last record and prefix
         */
        public synchronized int getLastEntryAndPrefixSize() {
            return lastEntryAndPrefixSize;
        }

        public Class<?> getKeyClass() {
            if (this.out == null) {
                throw new RuntimeException(
                        "You cannot get key class unless you open an file");
            }
            return keyClass;
        }

        public Class<?> getValueClass() {
            if (this.out == null) {
                throw new RuntimeException(
                        "You cannot get value class unless you open an file");
            }
            return valClass;
        }

        /**
         * Returns current position of the output stream. Note that for block
         * compressed file, this only moves after a block is written.
         * 
         * @return current position in the output stream
         * @throws IOException
         */
        public long getPos() throws IOException {
            return out.getPos();
        }

        /**
         * @see IRecordWriter#getSize()
         */
        public synchronized long getSize() throws IOException {
            if (this.out == null) {
                throw new IOException(
                        "You cannot get size unless you open an file");
            }
            return out.getPos();
        }

        /**
         * Writes an array of key-value pares.
         * 
         * @param keys
         *            the array of keys
         * @param vals
         *            the array of values
         * @throws IOException
         *             if an I/O error occurs
         */
        public void write(Object[] keys, Object[] vals) throws IOException {
            for (int i = 0; i < keys.length; i++) {
                write((IWritable) keys[i], (IWritable) vals[i]);
            } // for i
        }

        /**
         * Writes an array of key-value pairs and close the writer.
         * 
         * @param keys
         *            the array of keys
         * @param vals
         *            the array of values
         * @throws IOException
         *             if an I/O error occurs
         */
        public void writeAndClose(Object[] keys, Object[] vals)
                throws IOException {
            write(keys, vals);
            close();
        }

        /**
         * NOTE: the key and value should be IWritable objects.
         * 
         * @see IRecordWriter#write(Object, Object)
         */
        public synchronized void write(IWritable key, IWritable val)
                throws IOException {
            if (key.getClass() != keyClass) {
                throw new IOException("Wrong key class: " + key + " is "
                        + key.getClass() + ", not " + keyClass + ": " + fn());
            }
            if (val.getClass() != valClass) {
                throw new IOException("Wrong value class: " + val + " is "
                        + val.getClass() + ", not " + valClass + ": " + fn());
            }
            DataOutputBuffer buffer = outputBufferPool.allocate();
            try {
                key.writeFields(buffer);
                int keyLength = buffer.size();
                if (keyLength == 0) {
                    throw new IOException("zero length keys not allowed: "
                            + key + ", " + fn());
                }

                val.writeFields(buffer);
                append(buffer.getData(), 0, buffer.size(), keyLength);
            } finally {
                outputBufferPool.release(buffer);
            }
        }

        //clean the buffer
        //so getPos will get the right position in compressedwriter
        public synchronized void flushBuffer() throws IOException {
            //do nothing
        }

        /**
         * @see IRecordWriter#close()
         */
        public synchronized void close() throws IOException {
            if (out != null) {
                out.close();
                out = null;
            }
        }

        /**
         * Initialize the writer given an output stream, writer file header.
         * 
         * @param compressInfo
         *            , the high 4 bits means the compress method, and the low
         *            28 bits stores the compressBlockSize.
         * @param out
         *            the output stream
         * @throws IOException
         */
        private void init(FSDataOutputStream out, Properties properties,
                int compressInfo, CompressAlgo compressAlgo) throws IOException {
            fixedKeyLength = WritableRegistry.getWritableSize((Class<? extends IWritable>) keyClass);
            fixedValLength = WritableRegistry.getWritableSize((Class<? extends IWritable>) valClass);

            if (fixedValLength > 0 && fixedKeyLength > 0
                    && (((compressInfo >> 28) & 0x0f) == 0)) {
                fixedLength = fixedValLength + fixedKeyLength;
            } else {
                fixedLength = 0;
            }

            this.out = out;

            long startPos = out.getPos();
            /**
             * 为了让旧版本的 odis 也能读新版本代码写出的没有压缩或者使用 lzo 压缩的代码， 这里保持旧版本的 version
             */
            if (compressInfo == 0 || compressAlgo == CompressAlgo.LZO) {
                out.write(SEQ_VERSION_OLD);
            } else {
                out.write(SEQ_VERSION_NEW);
            }

            out.writeInt(fixedKeyLength);

            out.writeInt(fixedValLength);

            // zf: 0 for normal Writer, >0 for BlockCompressedWritable
            // river: the high 4 bits stores the compress methods
            out.writeInt(compressInfo);

            // write compress algorithm
            out.writeByte(compressAlgo.byteValue());

            byte[] reserved = new byte[HEADER_RESERVED_SIZE];
            Arrays.fill(reserved, (byte) 0);
            out.write(reserved);

            // zl: Previously, nutch use UTF8 and WritableName to write key and
            // class
            // name, here we directly output it as out.writeUTF(). Now we change
            // to
            // use UTF8Writable and directly get the class name.
            // We don't need the map in WritableNames, whod do we need that?
            // zl: still need to use WritableNames -- allow WritableNames to
            // load
            // modified classes -- 3/11/2006
            String keyClassName = WritableRegistry.getWritableName(keyClass);
            String valClassName = WritableRegistry.getWritableName(valClass);
            // keep compatible with UTF8Writable, use short for length
            byte[] buf = new byte[3 * Math.max(keyClassName.length(),
                    valClassName.length())];
            if (buf.length > HEADER_SIZE - sync.length) {
                throw new IOException("Too long class name in header: " + fn());
            }
            int keyLength = StringWritable.encode(keyClassName, buf, 0);
            out.writeShort(keyLength);
            out.write(buf, 0, keyLength);
            int valLength = StringWritable.encode(valClassName, buf, 0);
            out.writeShort(valLength);
            out.write(buf, 0, valLength);
            if (properties != null) {
                String propString = PropertiesString.encode(properties);
                if (propString.length() * 3 > buf.length) {
                    buf = new byte[propString.length() * 3];
                }
                if (buf.length > HEADER_SIZE - sync.length) {
                    throw new IOException("Too long prop string in header: "
                            + fn());
                }
                int propLength = StringWritable.encode(propString, buf, 0);
                out.writeShort(propLength);
                out.write(buf, 0, propLength);
            } else {
                out.writeShort(0);
            }

            if (out.getPos() - startPos > HEADER_SIZE - sync.length) {
                throw new IOException("Too long meta info in header: " + fn());
            }

            int toFill = (int) (HEADER_SIZE - sync.length - (out.getPos() - startPos));
            if (toFill > 0) {
                byte[] fill = new byte[toFill];
                Arrays.fill(fill, (byte) 0);
                out.write(fill);
            }

            // out.writeInt(SYNC_ESCAPE); // zf: this is necessary for us to
            // find the
            // sync from pos 0
            out.write(sync); // write the sync bytes

            this.out.flush(); // flush header
        }

        /** Append a key/value pair. */
        public synchronized void append(byte[] data, int start, int length,
                int keyLength) throws IOException {

            boolean syncNeeded = false;
            if (keyLength == 0) {
                throw new IOException("zero length keys not allowed: " + fn());
            }
            // whether it's time to emit sync
            syncNeeded = (sync != null && fixedLength <= 0 && out.getPos() >= lastSyncPos
                    + SYNC_INTERVAL);
            if (syncNeeded) {
                lastSyncPos = out.getPos(); // update lastSyncPos
                if (LOG.isLoggable(Level.FINEST)) {
                    LOG.finest("sync@" + lastSyncPos);
                }
                out.writeVInt(SYNC_ESCAPE); // escape it
                out.write(sync); // write sync
            }

            long prefixStart = out.getPos();
            if (fixedLength <= 0) {
                out.writeVInt(length); // total record length
            } else if (fixedLength != length) {
                throw new IOException("entry length mismatched with "
                        + "FIXED_LENGTH fields : " + length + "!="
                        + fixedLength + ", " + fn());
            }
            if (fixedKeyLength > 0) {
                if (fixedKeyLength != keyLength) {
                    throw new IOException("key length mismatched with "
                            + "FIXED_LENGTH field for" + " type "
                            + keyClass.getName() + ": " + fn());
                }
            } else {
                out.writeVInt(keyLength); // key portion length
            }
            long prefixStop = out.getPos();

            out.write(data, start, length); // data

            lastEntrySize = length;
            lastEntryAndPrefixSize = length
                    + ((int) (prefixStop - prefixStart));
        }

        public void write(Object key, Object value) throws IOException {
            write((IWritable) key, (IWritable) value);
        }

    }

    /**
     * The sequence-file Writer with object compression.
     * 
     * @author zl
     */
    public static class ObjectCompressWriter extends Writer {

        private final ByteArrayBufferPool byteArrayBufferPool;

        private CompressedData cdata = new CompressedData();

        /**
         * @deprecated
         */
        @Deprecated
        public ObjectCompressWriter(FileSystem fs, File file, Class keyClass,
                Class valClass, boolean overwrite) throws IOException {
            super(fs, file, keyClass, valClass, null, overwrite,
                    OBJECT_LEVEL_COMPRESSION << 28);
            this.byteArrayBufferPool = ByteArrayBufferPoolHolder.DEFAULT_POOL;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public ObjectCompressWriter(FileSystem fs, File file, Class keyClass,
                Class valClass) throws IOException {
            this(fs, file, keyClass, valClass, true);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @throws IOException
         *             if an I/O error occurs
         */
        public ObjectCompressWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass) throws IOException {
            this(fs, file, keyClass, valClass, true);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @throws IOException
         *             if an I/O error occurs
         */
        public ObjectCompressWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite) throws IOException {
            this(fs, file, keyClass, valClass, overwrite, DEFAULT_COMPRESS_ALGO);
        }

        public ObjectCompressWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, CompressAlgo compressAlgo)
                throws IOException {
            this(fs, file, keyClass, valClass, overwrite, compressAlgo,
                    ByteArrayBufferPoolHolder.DEFAULT_POOL);
        }

        public ObjectCompressWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, CompressAlgo compressAlgo,
                OutputBufferPool outputBufferPool) throws IOException {
            super(fs, file, keyClass, valClass, null, overwrite,
                    OBJECT_LEVEL_COMPRESSION << 28, compressAlgo,
                    outputBufferPool);
            this.byteArrayBufferPool = ByteArrayBufferPoolHolder.DEFAULT_POOL;
        }

        public ObjectCompressWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, CompressAlgo compressAlgo,
                ByteArrayBufferPool byteArrayBufferPool) throws IOException {
            super(fs, file, keyClass, valClass, null, overwrite,
                    OBJECT_LEVEL_COMPRESSION << 28, compressAlgo);
            this.byteArrayBufferPool = byteArrayBufferPool;
        }

        public ObjectCompressWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, CompressAlgo compressAlgo,
                OutputBufferPool outputBufferPool,
                ByteArrayBufferPool byteArrayBufferPool) throws IOException {
            super(fs, file, keyClass, valClass, null, overwrite,
                    OBJECT_LEVEL_COMPRESSION << 28, compressAlgo,
                    outputBufferPool);
            this.byteArrayBufferPool = byteArrayBufferPool;
        }

        @Override
        public synchronized void write(IWritable key, IWritable val)
                throws IOException {
            if (key.getClass() != keyClass) {
                throw new IOException("Wrong key class: " + key + " is "
                        + key.getClass() + ", not " + keyClass + ": " + fn());
            }
            if (val.getClass() != valClass) {
                throw new IOException("Wrong value class: " + val + " is "
                        + val.getClass() + ", not " + valClass + ": " + fn());
            }
            DataOutputBuffer buf1 = outputBufferPool.allocate();
            DataOutputBuffer cbuf = outputBufferPool.allocate();
            byte[] compressBuf = null;
            try {
                key.writeFields(buf1);
                int keyLength = buf1.size();
                if (keyLength == 0) {
                    throw new IOException("zero length keys not allowed: "
                            + key + ": " + fn());
                }
                val.writeFields(cbuf);
                CompressUtils.compress(cbuf.getData(), 0, cbuf.size(),
                        compressAlgo, byteArrayBufferPool, cdata);
                if (cdata.len < 0) {
                    throw new IOException("compression failed(" + cdata.len
                            + "), jvm may be crashed: " + fn());
                }
                compressBuf = cdata.data;
                buf1.writeVInt(cbuf.size());
                buf1.write(cdata.data, 0, cdata.len);
                super.append(buf1.getData(), 0, buf1.size(), keyLength);
            } finally {
                if (compressBuf != null) {
                    byteArrayBufferPool.release(compressBuf);
                }
                outputBufferPool.release(cbuf);
                outputBufferPool.release(buf1);
            }
        }

        public void compressAndAppend(byte[] data, int start, int length,
                int keyLength) throws IOException {
            if (keyLength == 0) {
                throw new IOException("zero length keys not allowed: " + ": "
                        + fn());
            }
            DataOutputBuffer buf1 = outputBufferPool.allocate();
            buf1.reset();
            byte[] compressBuf = null;
            try {
                buf1.write(data, start, keyLength);
                CompressUtils.compress(data, keyLength + start, length
                        - keyLength, compressAlgo, byteArrayBufferPool, cdata);

                if (cdata.len < 0) {
                    throw new IOException("compression failed(" + cdata.len
                            + "), jvm may be crashed: " + fn());
                }
                compressBuf = cdata.data;

                buf1.writeVInt(length - keyLength);
                buf1.write(cdata.data, 0, cdata.len);
                super.append(buf1.getData(), 0, buf1.size(), keyLength);
            } finally {
                if (compressBuf != null) {
                    byteArrayBufferPool.release(compressBuf);
                }
                outputBufferPool.release(buf1);
            }
        }
    }

    /**
     * Sequence file writer that creates a file with adjacent records compressed
     * together.
     * 
     * @author zf
     */
    public static class CompressedWriter extends Writer {
        public static final int DEFAULT_BLOCK_SIZE = OdisLibConfig.conf().getInt(
                "file.seqfile.compress.block-size", 1024 * 1024);

        private static final int BMZ_B = OdisLibConfig.conf().getInt(
                "file.seqfile.compress.bmz-b", 64);

        // compression block size, default to 1MB
        protected int blockSize;

        protected int nrRecordsInBlock;

        protected DataOutputBuffer keyBuffer, keyLenBuffer, valBuffer,
                valLenBuffer;

        protected DataOutputBuffer objectCompressBuffer = new DataOutputBuffer();

        protected boolean objectCompression = false;

        protected DirectByteArrayOutputStream byteOutStream = new DirectByteArrayOutputStream();

        protected CompressedData cdata = new CompressedData();

        private static class BmzPool {
            private LinkedList<BmzCompression> freeList = new LinkedList<BmzCompression>();

            private int createdCount = 0;

            private int maxPlainLen = 0;

            private int maxPoolSize = 0;

            public BmzPool(int maxPoolSize, int maxPlainLen) {
                this.maxPoolSize = maxPoolSize;
                this.maxPlainLen = maxPlainLen;
            }

            private synchronized BmzCompression allocate() {
                while (true) {
                    if (!freeList.isEmpty()) {
                        return freeList.remove();
                    }
                    if (createdCount < maxPoolSize) {
                        BmzCompression bmz = new BmzCompression(maxPlainLen,
                                BMZ_B);
                        createdCount++;
                        return bmz;
                    }
                    try {
                        this.wait();
                    } catch (InterruptedException e) {}
                }
            }

            private synchronized void release(BmzCompression bmz) {
                if (bmz.getMaxPlainLen() != maxPlainLen) {
                    throw new RuntimeException("bad bmz for pool");
                }
                freeList.add(bmz);
                this.notify();
            }

        }

        protected static final HashMap<Integer, BmzPool> bmzPoolMap = new HashMap<Integer, BmzPool>();

        protected static final int MAX_BMZ_COUNT = 16;

        private static BmzPool getBmzPool(int maxPlainLength) {
            BmzPool pool;
            synchronized (bmzPoolMap) {
                pool = bmzPoolMap.get(maxPlainLength);
                if (pool == null) {
                    pool = new BmzPool(MAX_BMZ_COUNT, maxPlainLength);
                    bmzPoolMap.put(maxPlainLength, pool);
                }
            }
            return pool;
        }

        private BmzPool bmzPool = null;

        private ByteArrayBufferPool byteArrayBufferPool = ByteArrayBufferPoolHolder.DEFAULT_POOL;

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public CompressedWriter(FileSystem fs, File file, Class keyClass,
                Class valClass, boolean overwrite, int blockSize)
                throws IOException {
            this(fs, new Path(file), keyClass, valClass, overwrite, blockSize,
                    false);
        }

        public CompressedWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, int blockSize,
                boolean objectCompression) throws IOException {
            this(fs, file, keyClass, valClass, overwrite, blockSize,
                    objectCompression, DEFAULT_COMPRESS_ALGO);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @param blockSize
         *            the size of the block
         * @throws IOException
         *             if an I/O error occurs
         */
        public CompressedWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, int blockSize,
                boolean objectCompression, CompressAlgo compressAlgo)
                throws IOException {
            super(fs, file, keyClass, valClass, null, overwrite,
                    objectCompression ? (blockSize & 0xfffffff)
                            | (OBJECT_LEVEL_COMPRESSION << 28)
                            : (blockSize & 0xfffffff), compressAlgo);

            if (blockSize <= 0) {
                throw new IllegalArgumentException("Compression block size "
                        + "must be > 0" + fn());
            }
            this.blockSize = blockSize & 0xfffffff;
            this.objectCompression = objectCompression;

            keyBuffer = new DataOutputBuffer();
            valBuffer = new DataOutputBuffer();
            if (fixedKeyLength <= 0) {
                keyLenBuffer = new DataOutputBuffer(2);
            }
            if (fixedValLength <= 0 || objectCompression) {
                valLenBuffer = new DataOutputBuffer(2);
            }
            bmzPool = getBmzPool(blockSize + COMPRESS_CHUNK_EXTRA_SIZE);
        }

        public CompressedWriter(DistributedFileSystem dfs, Path file,
                Class keyClass, Class valClass, boolean overwrite,
                int blockSize, boolean objectCompression,
                CompressAlgo compressAlgo, int flags) throws IOException {
            super(dfs, file, keyClass, valClass, null, overwrite,
                    objectCompression ? (blockSize & 0xfffffff)
                            | (OBJECT_LEVEL_COMPRESSION << 28)
                            : (blockSize & 0xfffffff), compressAlgo, flags);
            if (blockSize <= 0) {
                throw new IllegalArgumentException("Compression block size "
                        + "must be > 0" + fn());
            }
            this.blockSize = blockSize & 0xfffffff;
            this.objectCompression = objectCompression;

            keyBuffer = new DataOutputBuffer();
            valBuffer = new DataOutputBuffer();
            if (fixedKeyLength <= 0) {
                keyLenBuffer = new DataOutputBuffer(2);
            }
            if (fixedValLength <= 0 || objectCompression) {
                valLenBuffer = new DataOutputBuffer(2);
            }
            bmzPool = getBmzPool(blockSize + COMPRESS_CHUNK_EXTRA_SIZE);
        }

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public CompressedWriter(FileSystem fs, File file, Class keyClass,
                Class valClass, boolean overwrite) throws IOException {
            this(fs, file, keyClass, valClass, overwrite, DEFAULT_BLOCK_SIZE);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @throws IOException
         *             if an I/O error occurs
         */
        public CompressedWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite) throws IOException {
            this(fs, file, keyClass, valClass, overwrite, DEFAULT_BLOCK_SIZE,
                    false);
        }

        /**
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public CompressedWriter(FileSystem nfs, File file, Class keyClass,
                Class valClass) throws IOException {
            this(nfs, file, keyClass, valClass, true, DEFAULT_BLOCK_SIZE);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be written to
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @throws IOException
         *             if an I/O error occurs
         */
        public CompressedWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass) throws IOException {
            this(fs, file, keyClass, valClass, true, DEFAULT_BLOCK_SIZE, false);
        }

        @Override
        public synchronized void write(IWritable key, IWritable val)
                throws IOException {
            if (key.getClass() != keyClass) {
                throw new IOException("Wrong key class: " + key + " is "
                        + key.getClass() + ", not " + keyClass);
            }
            if (val.getClass() != valClass) {
                throw new IOException("Wrong value class: " + val + " is "
                        + val.getClass() + ", not " + valClass);
            }

            // write key
            int oldKeyLen = keyBuffer.size();
            key.writeFields(keyBuffer);
            int keyLen = keyBuffer.size() - oldKeyLen;
            if (keyLen == 0) {
                throw new IOException("Zero-sized key not allowed.");
            }
            if (fixedKeyLength <= 0) {
                keyLenBuffer.writeVInt(keyLen);
            } else if (keyLen != fixedKeyLength) {
                throw new IOException("fixed length key size mismatch: "
                        + keyLen + ", expecting " + fixedKeyLength);
            }

            // write value
            int oldValLen = valBuffer.size();
            int valLen;
            if (objectCompression) {
                ((IWritable) val).writeFields(objectCompressBuffer);

                byte[] compressBuf = null;
                try {
                    CompressUtils.compress(objectCompressBuffer.getData(), 0,
                            objectCompressBuffer.size(), compressAlgo,
                            byteArrayBufferPool, cdata);
                    compressBuf = cdata.data;
                    cdata.data = null;
                    valBuffer.writeVInt(objectCompressBuffer.size());
                    valBuffer.write(compressBuf, 0, cdata.len);
                } finally {
                    if (compressBuf != null) {
                        byteArrayBufferPool.release(compressBuf);
                    }
                }
                objectCompressBuffer.reset((int) (64 * UnitUtils.K));
            } else {
                val.writeFields(valBuffer);
            }
            valLen = valBuffer.size() - oldValLen;

            if (objectCompression || fixedValLength <= 0) {
                valLenBuffer.writeVInt(valLen);
            } else if (valLen != fixedValLength) {
                throw new IOException("fixed length value size mismatch: "
                        + valLen + ", expecting " + fixedValLength);
            }

            nrRecordsInBlock++;

            // see if we had a whole block
            if (keyBuffer.size() + valBuffer.size() >= blockSize) {
                writeBlock();
            }
        }

        /**
         * Append data, value data should not be compressed even if the object
         * compression is set. This method is called by the sorter, so we will
         * not decompress the value data during sorting.
         */
        @Override
        public void append(byte[] data, int start, int length, int keyLength)
                throws IOException {
            keyBuffer.write(data, start, keyLength);
            if (fixedKeyLength <= 0) {
                keyLenBuffer.writeVInt(keyLength);
            } else if (keyLength != fixedKeyLength) {
                throw new IOException("fixed length key size mismatch: "
                        + keyLength + ", expecting " + fixedKeyLength);
            }
            int valLength = length - keyLength;
            valBuffer.write(data, start + keyLength, valLength);
            if (objectCompression || fixedValLength <= 0) {
                valLenBuffer.writeVInt(valLength);
            } else if (valLength != fixedValLength) {
                throw new IOException("fixed value size mismatch: " + valLength
                        + ", expecting " + fixedValLength);
            }
            nrRecordsInBlock++;

            if (keyBuffer.size() + valBuffer.size() >= blockSize) {
                writeBlock();
            }
        }

        @Override
        public synchronized void flushBuffer() throws IOException {
            writeBlock();
        }

        @Override
        public synchronized void close() throws IOException {
            writeBlock();
            super.close();
        }

        /**
         * Return number of accumulated records in the current block.
         */
        public int getRecordsInBlock() {
            return nrRecordsInBlock;
        }

        protected void writeBlock() throws IOException {
            if (nrRecordsInBlock == 0) {
                return;
            }

            // write sync
            if (sync != null) {
                out.writeVInt(SYNC_ESCAPE); // escape it
                out.write(sync); // write sync
            }

            // write number of records
            out.writeVInt(nrRecordsInBlock);

            // write keys
            if (fixedKeyLength <= 0) {
                writeCompressed(keyLenBuffer, false, false);
                keyLenBuffer.reset();
            }
            writeCompressed(keyBuffer, true, false);
            keyBuffer.reset(blockSize);

            // write values
            if (fixedValLength <= 0 || objectCompression) {
                writeCompressed(valLenBuffer, false, false);
                valLenBuffer.reset();
            }
            writeCompressed(valBuffer, true, true);
            valBuffer.reset(blockSize);

            nrRecordsInBlock = 0;
        }

        /**
         * Compress a piece of data and write out its length and compressed
         * bytes to output stream.
         * 
         * @param twoPass
         *            if the data is amenable to two-pass compression, we'll use
         *            BMZ+LZO for these, otherwise only LZO is used.
         * @param allowEmpty
         *            if the data could be empty
         * @throws IOException
         *             if compression error
         */
        private void writeCompressed(DataOutputBuffer data, boolean twoPass,
                boolean allowEmpty) throws IOException {
            byte[] d0 = data.getData();
            int len = data.size();
            int off = 0;
            int max = blockSize + COMPRESS_CHUNK_EXTRA_SIZE;
            if (len == 0) {
                if (!allowEmpty) {
                    throw new RuntimeException(
                            "cannot write empty buffer compressed.");
                } else {
                    // for empty data
                    out.writeVInt(0);
                    out.writeVInt(0);
                    return;
                }
            }

            byte[] compressedData;
            int compressedLength = 0;

            do {
                int l = Math.min(len - off, max);
                byte[] compressBuffer = null;
                try {
                    if (twoPass) {
                        BmzCompression bmz = bmzPool.allocate();
                        try {
                            int l2 = bmz.compress(d0, off, l);
                            compressedData = bmz.getBuf();
                            if (l2 < 0) {
                                throw new IOException(
                                        "Bmzip compression error: " + len);
                            }
                            CompressUtils.compress(compressedData, 0, l2,
                                    compressAlgo, byteArrayBufferPool, cdata);
                            compressedLength = cdata.len;
                            compressBuffer = cdata.data;
                            compressedData = cdata.data;
                            cdata.data = null;
                        } finally {
                            bmzPool.release(bmz);
                        }
                    } else {
                        CompressUtils.compress(d0, off, l, compressAlgo,
                                byteArrayBufferPool, cdata);
                        compressedLength = cdata.len;
                        compressBuffer = cdata.data;
                        compressedData = cdata.data;
                        cdata.data = null;
                    }
                    // this is not the last block, write an escape
                    if (off + l < len) {
                        out.writeVInt(0);
                    }
                    out.writeVInt(compressedLength);
                    out.write(compressedData, 0, compressedLength);
                    off += l;
                } finally {
                    if (compressBuffer != null) {
                        byteArrayBufferPool.release(compressBuffer);
                    }
                }
            } while (off < len);
        }
    }

    /**
     * The IRecordReader that can read a sequence-file. Usage: see javadoc of
     * IRecordReader
     * 
     * @author zl
     */
    public static class Reader implements IRecordReader<Object, Object>,
            ISkipReader<Object, Object> {
        static {
            WritableRegistry.load();
        }

        protected IFileSystem fs = null;

        protected Path file;

        protected Class<? extends IWritable> keyClass;

        protected Class<? extends IWritable> valClass;

        protected ClassLoader classLoader = null;

        protected FSDataInputStream in;

        protected DataOutputBuffer outBuf = new DataOutputBuffer();

        protected DataInputBuffer inBuf = new DataInputBuffer();

        protected byte[] version = new byte[SEQ_VERSION_NEW.length];

        protected byte[] sync = new byte[SYNC_HASH_SIZE];

        protected byte[] syncCheck = new byte[SYNC_HASH_SIZE];

        protected long lastSyncStart;

        protected long start, end; // start and end in the main content

        protected long fileEnd;

        protected int keyLength;

        protected int fixedKeyLength;

        protected int fixedValLength; // used only by block compressed file

        protected int fixedLength;

        protected Properties properties;

        // object level compressed file suppoer
        protected boolean objectCompressed;

        // block compressed file support
        protected int compressBlockSize;

        protected DataInputBuffer keyLenBuf, keyBuf, valLenBuf, valBuf;

        protected int bufferedRecords;

        protected static final int READ_OBJECT_COMPRESS_BUFFER_SIZE = 4 * 1024;

        protected byte[] oubuf;

        protected final ByteArrayBufferPool byteArrayBufferPool;

        protected WritableComparator keyComparator;

        protected CompressAlgo compressAlgo;

        /**
         * For subclass which want to init reader itself.
         */
        protected Reader() {
            this(ByteArrayBufferPoolHolder.DEFAULT_POOL);
        }

        /**
         * For subclass which want to init reader itself.
         * 
         * @param byteArrayBufferPool
         */
        protected Reader(ByteArrayBufferPool byteArrayBufferPool) {
            this.byteArrayBufferPool = byteArrayBufferPool;
        }

        /**
         * Create a reader for <code>fileName</code>
         * 
         * @deprecated Use the version with Path instead
         */
        @Deprecated
        public Reader(FileSystem fs, File file) throws IOException {
            this(fs, new Path(file));
        }

        /**
         * @deprecated Use the version with Path instead
         */
        @Deprecated
        public Reader(FileSystem fs, File file, int bufferSize)
                throws IOException {
            this(fs, new Path(file), bufferSize);
        }

        /**
         * Create a reader for <code>fileName</code>, read [start, start+length)
         * in whole stream
         * 
         * @deprecated Use the version with Path instead
         */
        @Deprecated
        public Reader(FileSystem fs, File file, long start, long length)
                throws IOException {
            this(fs, new Path(file), start, length);
        }

        /**
         * Opens a file of records for read
         * 
         * @deprecated Use the version with Path instead
         * @param fs
         *            the instance of file system
         * @param file
         *            the name of file
         * @param start
         *            the start position to be read in the <code>file</code>
         * @param length
         *            the length to be read since the <code>start</code>
         * @param bufferSize
         *            the size of buffer to read this file
         * @throws IOException
         */
        @Deprecated
        public Reader(FileSystem fs, File file, long start, long length,
                int bufferSize) throws IOException {
            this(fs, new Path(file), start, length, bufferSize);
        }

        /**
         * Deprecated
         * 
         * @deprecated Use the version with Path instead
         */
        @Deprecated
        public Reader(FileSystem fs, File file, long start, long length,
                int bufferSize, Class<? extends IWritableComparable> keyCls,
                Class<? extends IWritable> valCls) throws IOException {
            this(fs, new Path(file), start, length, bufferSize, keyCls, valCls);
        }

        /**
         * The constructor with default buffer-size.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be read
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file) throws IOException {
            this(fs, file, FileSystem.DEFAULT_OPEN_BUFFER_SIZE);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be read
         * @param bufferSize
         *            the buffer-size for reading the file
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file, int bufferSize)
                throws IOException {
            this(fs, file, 0, -1, bufferSize);
        }

        /**
         * Create a reader for <code>fileName</code>, read [start, start+length)
         * in whole stream
         */
        public Reader(IFileSystem nfs, Path file, long start, long length)
                throws IOException {
            this(nfs, file, start, length, FileSystem.DEFAULT_OPEN_BUFFER_SIZE);
        }

        /**
         * Opens a file of records for read
         * 
         * @param fs
         *            the instance of file system
         * @param file
         *            the name of file
         * @param start
         *            the start position to be read in the <code>file</code>
         * @param length
         *            the length to be read since the <code>start</code>
         * @param bufferSize
         *            the size of buffer to read this file
         * @throws IOException
         */
        public Reader(IFileSystem fs, Path file, long start, long length,
                int bufferSize) throws IOException {
            this(fs, file, start, length, bufferSize,
                    (Class<? extends IWritableComparable>) null,
                    (Class<? extends IWritable>) null);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the path to the sequence to be read
         * @param start
         *            the start position to be read in the <code>file</code>
         * @param length
         *            the length to be read since the <code>start</code>
         * @param bufferSize
         *            the size of buffer to read this file
         * @param keyClass
         *            the class of the key
         * @param valClass
         *            the class of the value
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file, long start, long length,
                int bufferSize, Class<? extends IWritableComparable> keyClass,
                Class<? extends IWritable> valClass) throws IOException {
            this(fs, file, start, length, bufferSize, keyClass, valClass,
                    ByteArrayBufferPoolHolder.DEFAULT_POOL);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the path to the sequence to be read
         * @param start
         *            the start position to be read in the <code>file</code>
         * @param length
         *            the length to be read since the <code>start</code>
         * @param bufferSize
         *            the size of buffer to read this file
         * @param keyClass
         *            the class of the key
         * @param valClass
         *            the class of the value
         * @param byteArrayBufferPool
         *            the byte[] buffer pool
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file, long start, long length,
                int bufferSize, Class<? extends IWritableComparable> keyClass,
                Class<? extends IWritable> valClass,
                ByteArrayBufferPool byteArrayBufferPool) throws IOException {
            this.fs = fs;
            this.file = file;
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.byteArrayBufferPool = byteArrayBufferPool;
            this.in = fs.open(file, bufferSize);
            this.fileEnd = in.getLength();
            this.start = start;
            this.end = length >= 0 ? start + length : this.fileEnd;
            init(); // parse header
            sync(start); // sync to "start" in the content part
        }

        /**
         * Construct a read using a pre-opened FSDataInputStream
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the path to the sequence to be read
         * @param in
         *            the pre-opened FSDataInputStream
         * @throws IOException
         */
        public Reader(IFileSystem fs, Path file, FSDataInputStream in)
                throws IOException {
            this(fs, file, in, ByteArrayBufferPoolHolder.DEFAULT_POOL);
        }

        /**
         * Construct a read using a pre-opened FSDataInputStream
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the path to the sequence to be read
         * @param in
         *            the pre-opened FSDataInputStream
         * @param byteArrayBufferPool
         *            the byte[] buffer pool
         * @throws IOException
         */
        public Reader(IFileSystem fs, Path file, FSDataInputStream in,
                ByteArrayBufferPool byteArrayBufferPool) throws IOException {
            this.fs = fs;
            this.file = file;
            this.in = in;
            this.byteArrayBufferPool = byteArrayBufferPool;
            this.fileEnd = in.getLength();
            this.start = 0;
            this.end = fileEnd;
            init();
            sync(start);
        }

        /**
         * The constructor will use classLoader to instantiate key/value class
         * 
         * @author tuqc 2009/9/24
         * @param fs
         *            the file-system instance
         * @param file
         *            the file to be read
         * @param classLoader
         *            the classloader to loader key/value class
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file, ClassLoader classLoader)
                throws IOException {
            this(fs, file, 0, -1L, FileSystem.DEFAULT_OPEN_BUFFER_SIZE,
                    classLoader);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the path to the sequence to be read
         * @param start
         *            the start position to be read in the <code>file</code>
         * @param length
         *            the length to be read since the <code>start</code>
         * @param bufferSize
         *            the size of buffer to read this file
         * @param classLoader
         *            the class loader of key value class
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file, long start, long length,
                int bufferSize, ClassLoader classLoader) throws IOException {
            this(fs, file, start, length, bufferSize, classLoader,
                    ByteArrayBufferPoolHolder.DEFAULT_POOL);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param file
         *            the path to the sequence to be read
         * @param start
         *            the start position to be read in the <code>file</code>
         * @param length
         *            the length to be read since the <code>start</code>
         * @param bufferSize
         *            the size of buffer to read this file
         * @param classLoader
         *            the class loader of key value class
         * @param byteArrayBufferPool
         *            the byte[] buffer pool
         * @throws IOException
         *             if an I/O error occurs
         */
        public Reader(IFileSystem fs, Path file, long start, long length,
                int bufferSize, ClassLoader classLoader,
                ByteArrayBufferPool byteArrayBufferPool) throws IOException {
            this.fs = fs;
            this.file = file;
            this.keyClass = null;
            this.valClass = null;
            this.byteArrayBufferPool = byteArrayBufferPool;
            this.in = fs.open(file, bufferSize);
            this.fileEnd = in.getLength();
            this.start = start;
            this.end = length >= 0 ? start + length : this.fileEnd;
            this.classLoader = classLoader;
            init(); // parse header
            sync(start); // sync to "start" in the content part
        }

        /**
         * A special constructor for fixing header-missing files. It will read
         * header from another file <b>headerFile</b> and then read content from
         * <b>file</b>
         * 
         * @param fs
         *            the file-system
         * @param file
         *            the file to be read
         * @param headerFile
         *            the file that provides header, which should have the same
         *            header as the data file
         * @throws java.io.IOException
         */
        public Reader(IFileSystem fs, Path file, Path headerFile)
                throws IOException {
            this(fs, headerFile);
            this.file = file;
            this.in.close();
            this.in = fs.open(file, FileSystem.DEFAULT_OPEN_BUFFER_SIZE);
            this.fileEnd = in.getLength();
            this.start = 0;
            this.end = start + this.fileEnd;
            sync(HEADER_SIZE + 1);
        }

        /**
         * process <code>length</code> (really content length) of the input
         * stream from current position: actual-size=length+HEADER
         * 
         * @param in
         *            input stream
         * @param length
         *            process length in the stream since current position
         * @throws IOException
         */
        protected Reader(FSDataInputStream in, long length) throws IOException {
            this(in, length, ByteArrayBufferPoolHolder.DEFAULT_POOL);
        }

        /**
         * process <code>length</code> (really content length) of the input
         * stream from current position: actual-size=length+HEADER
         * 
         * @param in
         *            input stream
         * @param length
         *            process length in the stream since current position
         * @param byteArrayBufferPool
         *            the byte[] buffer pool
         * @throws IOException
         */
        protected Reader(FSDataInputStream in, long length,
                ByteArrayBufferPool byteArrayBufferPool) throws IOException {
            this.in = in;
            this.byteArrayBufferPool = byteArrayBufferPool;
            this.start = in.getPos();
            init();
            this.fileEnd = in.getPos() + length;
            this.end = this.fileEnd;
        }

        public CompressAlgo getCompressAlgo() {
            return compressAlgo;
        }

        public Properties getMetaInfo() {
            return properties;
        }

        public String toString() {
            return fs.getName() + "://" + file + " [" + start + "," + end + ")";
        }

        public long getEnd() {
            return end;
        }

        protected void disableSync() {
            sync = null;
        }

        /**
         * @see IRecordReader#getKeyClass()
         */
        public Class<? extends IWritable> getKeyClass() {
            if (this.in == null) {
                throw new RuntimeException("You cannot get key class unless "
                        + "you open an file");
            }
            return this.keyClass;
        }

        /**
         * @see IRecordReader#getValueClass()
         */
        public Class<? extends IWritable> getValueClass() {
            if (this.in == null) {
                throw new RuntimeException("You cannot get value class unless "
                        + "you open an file");
            }
            return this.valClass;
        }

        /**
         * @see IRecordReader#getSize()
         */
        public long getSize() throws IOException {
            if (this.in == null) {
                throw new IOException("You cannot get size unless you open an "
                        + "file");
            }
            return end - start;
        }

        long getFileEnd() {
            return fileEnd;
        }

        public int getFixedKeyLength() {
            return fixedKeyLength;
        }

        /**
         * Returns current position of the input stream, relative to the start.
         * Note that for block-compressed file, this only moves when a new block
         * is read.
         * 
         * @see IRecordReader#getPos()
         */
        public synchronized long getPos() throws IOException {
            if (this.in == null) {
                throw new IOException(
                        "You cannot get poistion unless you open an file");
            }
            return in.getPos() - start;
        }

        public Object[] readAllAndClose() throws IOException {
            Object[] res = new Object[2];
            try {
                ArrayList<Object> keys = new ArrayList<Object>();
                ArrayList<Object> vals = new ArrayList<Object>();

                IWritable key = keyClass.newInstance();
                IWritable val = valClass.newInstance();
                while (next(key, val)) {
                    keys.add(keyClass.newInstance().copyFields(key));
                    vals.add(valClass.newInstance().copyFields(val));
                } // while

                res[0] = keys.toArray((Object[]) Array.newInstance(keyClass,
                        keys.size()));
                res[1] = vals.toArray((Object[]) Array.newInstance(valClass,
                        vals.size()));
            } catch (InstantiationException e) {
                LOG.log(Level.WARNING, "Exception in readAllAndClose", e);
                throw new IOException(e);
            } catch (IllegalAccessException e) {
                LOG.log(Level.WARNING, "Exception in readAllAndClose", e);
                throw new IOException(e);
            } finally {
                close();
            }
            return res;
        }

        /** Set the current byte position in the input file. */
        public synchronized void seek(long position) throws IOException {
            if (position < 0) {
                throw new IndexOutOfBoundsException("Seeking to bad position: "
                        + position);
            }
            in.seek(position);
            if (isBlockCompressed()) {
                bufferedRecords = 0; // reset buffer
            }
        }

        /** Return the current byte position in the input file. */
        public synchronized long getPosition() throws IOException {
            return in.getPos();
        }

        private boolean nextUncompressed(IWritableComparable target,
                IWritableComparable key, IWritable val) throws IOException {
            boolean more = true;
            while (more) {
                outBuf.reset();
                keyLength = next(outBuf);
                if (keyLength < 0) {
                    more = false;
                } else {
                    inBuf.reset(outBuf.getData(), outBuf.size());
                    try {
                        key.readFields(inBuf);
                        if (inBuf.getPosition() != keyLength) {
                            throw new IOException("Reading: " + fn() + ": key "
                                    + "writable read " + inBuf.getPosition()
                                    + " bytes, should read " + keyLength
                                    + ". Either file is corrupted or the key "
                                    + "class(" + getKeyClass() + ") does I/O "
                                    + "incorrectly");
                        }
                    } catch (Exception e) {
                        throw new BadObjectException("Read key object "
                                + "error before pos " + this.getPos() + ": "
                                + fn(), e);
                    }

                    if (keyComparator.compare(key, target) >= 0) {
                        break;
                    }
                }
            }

            // read value
            if (more) {
                try {
                    if (objectCompressed) {
                        int ucSize = inBuf.readInt();
                        Limit.checkBufferSize(ucSize);
                        if (ucSize > oubuf.length) {
                            int newSize = oubuf.length << 1;
                            while (newSize < ucSize) {
                                newSize = newSize << 1;
                            }
                            oubuf = new byte[newSize];
                        }

                        CompressUtils.uncompress(inBuf.getBuffer(),
                                inBuf.getPosition(), inBuf.getSize(), oubuf, 0,
                                compressAlgo, ucSize);

                        inBuf.reset(oubuf, 0, ucSize);
                    }
                    val.readFields(inBuf);
                } catch (Exception e) {
                    throw new BadObjectException("read value object error "
                            + "before pos " + this.getPos() + ": " + fn(), e);
                }
            }
            return more;
        }

        private boolean nextCompressed(Object target, Object key, Object val)
                throws IOException {
            while (true) {
                // block compressed
                if (bufferedRecords == 0)
                    try {
                        readBlock();
                    } catch (EOFException e) {
                        return false;
                    }

                // read key
                int keyLength;
                if (fixedKeyLength > 0) {
                    keyLength = fixedKeyLength;
                } else {
                    keyLength = keyLenBuf.readVInt();
                }

                // read value
                int valLength;
                if (fixedValLength > 0) {
                    valLength = fixedValLength;
                } else {
                    valLength = valLenBuf.readVInt();
                }

                int keyPos = keyBuf.getPosition();

                try {
                    ((IWritable) key).readFields(keyBuf);
                    if (keyBuf.getPosition() - keyPos != keyLength) {
                        throw new IOException("Reading: " + fn() + ": key "
                                + "writable read "
                                + (keyBuf.getPosition() - keyPos)
                                + " bytes, should read " + keyLength
                                + ". Either file is corrupted or "
                                + "the key class(" + getKeyClass()
                                + ") does I/O incorrectly.");
                    }
                } catch (Exception e) {
                    bufferedRecords = 0;
                    throw new BadObjectException("bad object found in "
                            + "compressed data, the whole compressed block "
                            + "should be skipped: " + fn());
                }

                int valPos = valBuf.getPosition();
                if (keyComparator.compare(key, target) < 0) {
                    valBuf.skip(valLength);
                    bufferedRecords--;
                } else {
                    try {
                        if (objectCompressed) {
                            int ucSize = valBuf.readVInt();
                            Limit.checkBufferSize(ucSize);
                            int compressedSize = valLength
                                    - (valBuf.getPosition() - valPos);
                            if (ucSize > oubuf.length) {
                                oubuf = Limit.createBuffer(ucSize);
                            }

                            CompressUtils.uncompress(valBuf.getBuffer(),
                                    valBuf.getPosition(), compressedSize,
                                    oubuf, 0, compressAlgo, ucSize);

                            inBuf.reset(oubuf, ucSize);
                            ((IWritable) val).readFields(inBuf);
                            valBuf.skip(compressedSize);
                        } else {
                            ((IWritable) val).readFields(valBuf);
                        }

                        if (valBuf.getPosition() - valPos != valLength) {
                            throw new IOException("Reading: " + fn()
                                    + ": value" + " writable read "
                                    + (valBuf.getPosition() - valPos)
                                    + " bytes, should read " + valLength
                                    + ". Either file is corrupted "
                                    + "or the value class(" + getValueClass()
                                    + ") does I/O incorrectly.");
                        }
                    } catch (Exception e) {
                        bufferedRecords = 0;
                        throw new BadObjectException(
                                "bad object found before position "
                                        + this.getPos() + ": " + fn(), e);
                    }

                    bufferedRecords--;
                    return true;
                }
            }
        }

        /**
         * Return the key and val until key is greater or equal to target.
         * 
         * @param key
         * @param val
         * @return
         * @throws IOException
         */
        public synchronized boolean next(IWritableComparable target,
                IWritableComparable key, IWritable val) throws IOException {
            if (key.getClass() != keyClass || target.getClass() != keyClass) {
                throw new IOException("Wrong key class : given "
                        + key.getClass() + "/" + target.getClass() + " is not "
                        + keyClass + " in file, " + fn());
            }
            if (val.getClass() != valClass) {
                throw new IOException("Wrong value class : given "
                        + val.getClass() + " is not " + valClass + " in file, "
                        + fn());
            }

            if (compressBlockSize <= 0) {
                return nextUncompressed(target, key, val);
            } else {
                return nextCompressed(target, key, val);
            }
        }

        /**
         * @see IRecordReader#next(Object, Object)
         */
        public synchronized boolean next(IWritable key, IWritable val)
                throws IOException {
            if (key.getClass() != keyClass) {
                throw new IOException("Wrong key class: " + key.getClass()
                        + " is not " + keyClass);
            }
            if (val.getClass() != valClass) {
                throw new IOException("Wrong value class: " + val.getClass()
                        + " is not " + valClass);
            }

            if (compressBlockSize <= 0) {
                // normal sequence file
                boolean more = false;
                outBuf.reset();

                // read key
                keyLength = next(outBuf);

                if (keyLength < 0) {
                    more = false;
                } else {
                    inBuf.reset(outBuf.getData(), outBuf.size());

                    try {
                        key.readFields(inBuf);
                        if (inBuf.getPosition() != keyLength) {
                            throw new IOException(
                                    "Reading: "
                                            + file
                                            + ": key writable read "
                                            + inBuf.getPosition()
                                            + " bytes, should read "
                                            + keyLength
                                            + ". Either file is corrupted or the key class("
                                            + getKeyClass()
                                            + ") does I/O incorrectly.");
                        }
                    } catch (Exception e) {
                        throw new BadObjectException(
                                "read key object error before pos "
                                        + this.getPos() + ": " + fn(), e);
                    }
                    more = true;
                }
                // read value
                if (more) {
                    try {
                        if (objectCompressed) {
                            int ucSize = inBuf.readVInt();
                            Limit.checkBufferSize(ucSize);
                            if (ucSize > oubuf.length) {
                                int newSize = oubuf.length << 1;
                                while (newSize < ucSize) {
                                    newSize = newSize << 1;
                                }
                                oubuf = new byte[newSize];
                            }

                            CompressUtils.uncompress(inBuf.getBuffer(),
                                    inBuf.getPosition(), inBuf.getSize(),
                                    oubuf, 0, compressAlgo, ucSize);

                            inBuf.reset(oubuf, 0, ucSize);
                        }
                        val.readFields(inBuf);
                    } catch (Exception e) {
                        throw new BadObjectException(
                                "read value object error before pos "
                                        + this.getPos() + ": " + fn(), e);
                    }
                }

                return more;
            } else {
                // block compressed
                if (bufferedRecords == 0) {
                    try {
                        readBlock();
                    } catch (EOFException e) {
                        return false;
                    }
                }
                // read key
                int keyLength = fixedKeyLength > 0 ? fixedKeyLength
                        : keyLenBuf.readVInt();
                int pos = keyBuf.getPosition();
                ((IWritable) key).readFields(keyBuf);
                if (keyBuf.getPosition() - pos != keyLength) {
                    throw new IOException("Reading: " + file
                            + ": key writable read "
                            + (keyBuf.getPosition() - pos)
                            + " bytes, should read " + keyLength
                            + ". Either file is corrupted or the key class("
                            + getKeyClass() + ") does I/O incorrectly.");
                }

                // read value
                int valLength;
                if (fixedValLength <= 0 || objectCompressed) {
                    valLength = valLenBuf.readVInt();
                } else {
                    valLength = fixedValLength;
                }

                int valPos = valBuf.getPosition();

                try {
                    if (objectCompressed) {
                        int ucSize = valBuf.readVInt();
                        Limit.checkBufferSize(ucSize);
                        int compressedSize = valLength
                                - (valBuf.getPosition() - valPos);
                        if (ucSize > oubuf.length) {
                            oubuf = Limit.createBuffer(ucSize);
                        } else if (oubuf.length > READ_OBJECT_COMPRESS_BUFFER_SIZE) {
                            oubuf = Limit.createBuffer(Math.max(ucSize,
                                    READ_OBJECT_COMPRESS_BUFFER_SIZE));
                        }
                        CompressUtils.uncompress(valBuf.getBuffer(),
                                valBuf.getPosition(), compressedSize, oubuf, 0,
                                compressAlgo, ucSize);

                        inBuf.reset(oubuf, ucSize);
                        ((IWritable) val).readFields(inBuf);
                        valBuf.skip(compressedSize);
                    } else {
                        ((IWritable) val).readFields(valBuf);
                    }

                    int acturalRead = valBuf.getPosition() - valPos;
                    if (acturalRead != valLength) {
                        throw new BadObjectException(
                                "Reading: "
                                        + file
                                        + ": value writable read "
                                        + acturalRead
                                        + " bytes, should read "
                                        + valLength
                                        + ". Either file is corrupted or the key class("
                                        + getValueClass()
                                        + ") does I/O incorrectly.");
                    }
                } catch (Exception e) {
                    bufferedRecords = 0;
                    byte[] bytes = valBuf.getBuffer();
                    int bytesOffset = valPos;
                    int bytesLength = valBuf.getLimit() - bytesOffset;
                    if (bytesLength > valLength + 8) {
                        bytesLength = valLength + 8;
                    }
                    boolean more = false;
                    if (bytesLength > 65535) {
                        bytesLength = 65535;
                        more = true;
                    }
                    LOG.log(Level.SEVERE,
                            "bad object, valSize = "
                                    + valLength
                                    + ", bufSize="
                                    + (valBuf.getLimit() - bytesOffset)
                                    + ", bytes=["
                                    + HexString.bytesToHex(bytes, bytesOffset,
                                            bytesLength) + (more ? "..." : "")
                                    + "]", e);
                    throw new BadObjectException("bad object found before "
                            + "position " + this.getPos() + ": " + fn(), e);
                }

                bufferedRecords--;
                return true;
            }
        }

        /**
         * Return if the file is block compressed.
         */
        public boolean isBlockCompressed() {
            return compressBlockSize > 0;
        }

        // read next compressed block
        private void readBlock() throws IOException {
            long oldPos = in.getPos();
            if (oldPos >= this.fileEnd || this.lastSyncStart >= end) {
                throw new EOFException("file end");
            }

            bufferedRecords = in.readVInt();
            if (bufferedRecords == SYNC_ESCAPE) {
                lastSyncStart = oldPos;
                if (lastSyncStart >= end) {
                    throw new EOFException("file end");
                }

                in.readFully(syncCheck); // read syncCheck
                if (!Arrays.equals(sync, syncCheck)) {// check it
                    throw new IOException("Invalid sync. File is corrupt!");
                }
                bufferedRecords = in.readVInt();
            }
            if (fixedKeyLength <= 0) {
                readCompressed(keyLenBuf, false);
            }
            readCompressed(keyBuf, true);
            if (fixedValLength <= 0 || objectCompressed) {
                readCompressed(valLenBuf, false);
            }
            readCompressed(valBuf, true);
        }

        /**
         * Read a compressed chunk of data.
         * 
         * @param twoPass
         *            if the data is amenable to two-pass compression, we'll use
         *            BMZ+LZO for these, otherwise only LZO is used.
         * @throws IOException
         *             IO error or uncompression problem
         * @see CompressedWriter#writeCompressed(DataOutputBuffer, boolean)
         */
        private void readCompressed(DataInputBuffer data, boolean twopass)
                throws IOException {
            boolean next;
            DataOutputBuffer obuf = null; // only used in the slow path
            do {
                int len = in.readVInt();
                if (len == 0) {
                    len = in.readVInt();
                    if (len == 0) {
                        // no more data
                        data.reset();
                        return;
                    }
                    next = len != 0;
                } else {
                    next = false;
                }

                // we must use two buffer pool to allocate the buffer to 
                // avoid deadlock
                byte[] ubuf1 = byteArrayBufferPool.allocate((compressBlockSize + COMPRESS_CHUNK_EXTRA_SIZE) * 2);
                byte[] ubuf2 = byteArrayBufferPool.allocate((compressBlockSize + COMPRESS_CHUNK_EXTRA_SIZE) * 2);
                try {
                    in.readFully(ubuf1, 0, len);
                    // FIXME for 2-pass, this may not be enough as bmz may 
                    // expand the data, but that should be very rare for the
                    // large buffer we use
                    len = CompressUtils.uncompress(ubuf1, 0, len, ubuf2, 0,
                            compressAlgo, -1);
                    byte[] buf = ubuf2;
                    if (len < 0) {
                        throw new IOException("uncompression error: " + len);
                    }
                    if (twopass) {
                        len = BmzCompression.uncompress(ubuf2, 0, len, ubuf1);
                        buf = ubuf1;
                        if (len < 0) {
                            throw new IOException("BMZ uncompression error: "
                                    + len);
                        }
                    }
                    if (obuf == null && !next) {
                        // fast path
                        byte[] d = new byte[len];
                        System.arraycopy(buf, 0, d, 0, len);
                        data.reset(d, len);
                        return;
                    } else {
                        // slow path
                        if (obuf == null) {
                            obuf = new DataOutputBuffer(len);
                        }
                        obuf.write(buf, 0, len);
                    }
                } finally {
                    byteArrayBufferPool.release(ubuf2);
                    byteArrayBufferPool.release(ubuf1);
                }
            } while (next);
            data.reset(obuf.getData(), obuf.size());
        }

        /**
         * @see IRecordReader#close()
         */
        public synchronized void close() throws IOException {
            if (in != null) {
                in.close();
                in = null;
            }
        }

        protected String fn() {
            if (fs == null) {
                return "<stream>";
            }
            return fs.getName() + ":" + file;
        }

        /**
         * Initialize the reader, read file header
         * 
         * @throws IOException
         */
        protected void init() throws IOException {
            LOG.info("Initializing SequenceFile Reader for " + file);
            long startPos = in.getPos();

            in.readFully(version);
            if ((version[0] != SEQ_VERSION_NEW[0])
                    || (version[1] != SEQ_VERSION_NEW[1])
                    || (version[2] != SEQ_VERSION_NEW[2])) {
                throw new IOException("Not a SequenceFile: " + fn());
            }
            if (version[3] > SEQ_VERSION_NEW[3]) {
                throw new IOException("Verion doesn't match: " + version[3]
                        + ", only <=" + SEQ_VERSION_NEW[3] + " supported: "
                        + fn());
            }

            fixedKeyLength = in.readInt();
            fixedValLength = in.readInt();

            if (fixedKeyLength > 0 && fixedValLength > 0) {
                fixedLength = fixedKeyLength + fixedValLength;
            }

            int compressInfo = in.readInt();
            if (compressInfo < 0) {
                compressInfo = 0; // for compatable with old sequence files
            }

            compressAlgo = CompressAlgo.get(in.readByte());

            compressBlockSize = compressInfo & 0xfffffff;
            objectCompressed = ((compressInfo >> 28) & 0x0f) == OBJECT_LEVEL_COMPRESSION;

            if (compressBlockSize > 0) {
                Limit.checkBufferSize(compressBlockSize);
                if (fixedKeyLength <= 0) {
                    keyLenBuf = new DataInputBuffer();
                }
                keyBuf = new DataInputBuffer();
                if (fixedValLength <= 0 || objectCompressed) {
                    valLenBuf = new DataInputBuffer();
                }
                valBuf = new DataInputBuffer();
            }

            if (objectCompressed) {
                oubuf = new byte[READ_OBJECT_COMPRESS_BUFFER_SIZE];
            }

            // skip the reserved data
            in.skip(HEADER_RESERVED_SIZE);

            int keyLength = in.readUnsignedShort();
            byte[] buf = new byte[keyLength];
            in.readFully(buf);
            String keyClassName = StringWritable.decode(buf, 0, keyLength);
            int valLength = in.readUnsignedShort();
            if (valLength > buf.length) {
                buf = new byte[valLength];
            }
            in.readFully(buf, 0, valLength);
            String valClassName = StringWritable.decode(buf, 0, valLength);
            // read key and val class name
            // modify by tuqc
            Class<? extends IWritable> kc, vc;
            if (classLoader != null) {
                WritableRegistry.enableDynamicReload();
                DynamicWritableRegistry dyRegistry = DynamicWritableRegistry.get(classLoader);
                dyRegistry.dynamicLoad();
                kc = dyRegistry.getWritableClass(keyClassName);
                vc = dyRegistry.getWritableClass(valClassName);
            } else {
                kc = WritableRegistry.getWritableClass(keyClassName);
                vc = WritableRegistry.getWritableClass(valClassName);
            }
            if (this.keyClass == null) {
                this.keyClass = kc;
            } else if (!kc.isAssignableFrom(keyClass)) {
                throw new RuntimeException("Expected key class " + kc
                        + " in file is not assignable from " + this.keyClass);
            }
            if (IWritableComparable.class.isAssignableFrom(keyClass)) {
                keyComparator = WritableComparator.get(keyClass.asSubclass(IWritableComparable.class));
            }

            if (this.valClass == null) {
                this.valClass = vc;
            } else if (!vc.isAssignableFrom(valClass)) {
                throw new RuntimeException("Expected value class " + vc
                        + " in file is not assignable from " + this.valClass);
            }
            int propLength = in.readUnsignedShort();
            if (propLength > 0) {
                if (propLength > buf.length) {
                    buf = new byte[propLength];
                }
                in.readFully(buf, 0, propLength);
                String propValue = StringWritable.decode(buf, 0, propLength);
                properties = PropertiesString.decode(propValue);
            } else {
                properties = new Properties();
            }

            long toSkip = HEADER_SIZE - SYNC_HASH_SIZE
                    - (in.getPos() - startPos);
            if (toSkip > 0) {
                in.skip(toSkip);
            }
            in.readFully(sync);
        }

        public boolean isObjectCompressed() {
            return objectCompressed;
        }

        public int getCompressBlockSize() {
            return compressBlockSize;
        }

        public byte[] getSync() {
            return sync == null ? null : Arrays.copyOf(sync, sync.length);
        }

        /** Seek to the next sync mark past a given position. */
        public synchronized void sync(long position) throws IOException {
            if (position < 0) {
                throw new IndexOutOfBoundsException("Syncing to bad position: "
                        + position + ", " + fn());
            }

            // fixed length records: no sync needed
            if (fixedLength > 0 && !isBlockCompressed()) {
                if (position <= HEADER_SIZE) {
                    position = HEADER_SIZE;
                } else {
                    position = ((position - HEADER_SIZE + fixedLength - 1) / fixedLength)
                            * fixedLength + HEADER_SIZE;
                }
                in.seek(position);
                return;
            }

            // position extends the file end
            if (position + SYNC_SIZE >= fileEnd) {
                in.seek(fileEnd);
                return;
            }

            // position before the header
            if (position <= HEADER_SIZE) {
                in.seek(HEADER_SIZE);
                // no sync at the beginning: take as empty sync
                lastSyncStart = in.getPos();
                return;
            }

            in.seek(position + SYNC_ESCAPE_SIZE);
            lastSyncStart = in.getPos() - SYNC_ESCAPE_SIZE;
            in.readFully(syncCheck);
            int syncLen = sync.length;
            for (int i = 0; in.getPos() < fileEnd; i++) {
                int j = 0;
                for (; j < syncLen; j++) {
                    if (sync[j] != syncCheck[(i + j) % syncLen]) {
                        break;
                    }
                }
                if (j == syncLen) {
                    // zf: this is causing problem when we sync(0) because the
                    // sync in
                    // the header doesn't having a leading escape
                    // let's now work around this and not seeking back to before the sync
                    //          in.seek(in.getPos() - SYNC_SIZE);  // position before sync
                    if (isBlockCompressed()) {
                        bufferedRecords = 0; // reset buffer
                    }
                    return;
                }
                syncCheck[i % syncLen] = in.readByte();
                lastSyncStart++;
            }
        }

        /**
         * Fetch next key and value with specified length. FIXME this only works
         * for uncompressed
         * 
         * @param key
         *            the key instance
         * @param value
         *            the value instance
         * @param length
         *            the length of this entry (pair)
         * @throws IOException
         *             if an I/O error occurs
         */
        public synchronized void nextKeyAndValue(IWritable key,
                IWritable value, int length) throws IOException {
            if (compressBlockSize > 0) {
                throw new IllegalStateException("Not implemented for block"
                        + " compressed sequence file: " + fn());
            }
            outBuf.reset();
            outBuf.write(in, length);
            inBuf.reset(outBuf.getData(), outBuf.size());
            key.readFields(inBuf);
            value.readFields(inBuf);
        }

        /**
         * Read the next key/value pair in the file into <code>buffer</code>.
         * Returns the length of the key read, or -1 if at end of file, or read
         * extends the "end" position. The length of the value may be computed
         * by calling buffer.getLength() before and after calls to this method.
         * 
         * @param buffer
         *            the buffer to read (key,value) into
         * @throws IOException
         */
        public synchronized int next(DataOutputBuffer buffer)
                throws IOException {
            if (compressBlockSize <= 0) {
                long oldPos = in.getPos();
                if (oldPos >= fileEnd || lastSyncStart >= end) {// end of file or beyond end
                    return -1;
                }
                int length; // length of the next record
                if (fixedLength <= 0 || objectCompressed) { // not fixed length records
                    try {
                        length = in.readVInt();
                    } catch (EOFException e) {
                        LOG.warning("EOF catched when getting length of record."
                                + "oldPos = "
                                + oldPos
                                + ", fileEnd = "
                                + fileEnd);
                        return -1;
                    }
                    // process a sync entry
                    if (version[3] > 1 && sync != null && length == SYNC_ESCAPE) {
                        lastSyncStart = oldPos;
                        if (LOG.isLoggable(Level.FINER)) {
                            LOG.finer("sync-len@" + oldPos + ", sync-start@"
                                    + in.getPos());
                        }
                        in.readFully(syncCheck); // read syncCheck
                        if (!Arrays.equals(sync, syncCheck)) { // check it
                            throw new IOException("File is corrupt!");
                        }
                        if (LOG.isLoggable(Level.FINER)) {
                            LOG.finer("sync-end@" + in.getPos());
                        }
                        // The start position of this sync is already 
                        // behind the "end" point
                        // We should not read any more in this reader
                        if (lastSyncStart >= end) {
                            return -1;
                        }
                        length = in.readVInt(); // re-read length
                    }
                } else { // fixed length records
                    if (oldPos >= end) {
                        return -1;
                    }
                    length = fixedLength;
                }

                int keyLength = fixedKeyLength > 0 ? fixedKeyLength
                        : in.readVInt();
                buffer.write(in, length);
                return keyLength;
            } else {
                // block compressed file
                if (bufferedRecords == 0) {
                    try {
                        readBlock();
                    } catch (EOFException e) {
                        return -1;
                    }
                }
                // read key
                int keyLength = fixedKeyLength > 0 ? fixedKeyLength
                        : keyLenBuf.readVInt();
                buffer.write(keyBuf, keyLength);

                // read value
                int valLength;
                if (fixedValLength <= 0 || objectCompressed) {
                    valLength = valLenBuf.readVInt();
                } else {
                    valLength = fixedValLength;
                }
                buffer.write(valBuf, valLength);

                bufferedRecords--;
                return keyLength;
            }
        }

        /**
         * Skip a number of records.
         * 
         * @param c
         *            number of records to skip
         * @return actual number of records skipped
         * @throws IOException
         */
        public synchronized int skip(int c) throws IOException {
            int skipped = 0;
            for (int i = 0; i < c; i++) {
                if (compressBlockSize <= 0) {
                    // REMIND slow skip implementation for uncompressed file as
                    // this is not used a lot
                    outBuf.reset();
                    if (next(outBuf) < 0) {
                        break;
                    }
                    skipped++;
                } else {
                    // optmize for compressed case as this is used by indexed file
                    if (bufferedRecords == 0) {
                        try {
                            readBlock();
                        } catch (EOFException e) {
                            break;
                        }
                    }
                    // skip key
                    int keyLength = fixedKeyLength > 0 ? fixedKeyLength
                            : keyLenBuf.readVInt();
                    keyBuf.skip(keyLength);

                    // skip value
                    int valLength = fixedValLength > 0 ? fixedValLength
                            : valLenBuf.readVInt();
                    valBuf.skip(valLength);

                    bufferedRecords--;
                }
            }
            return skipped;
        }

        public synchronized int getBufferedRecordNum() {
            return bufferedRecords;
        }

        @Override
        public boolean next(Object target, Object key, Object value)
                throws IOException {
            return next((IWritableComparable) target,
                    (IWritableComparable) key, (IWritable) value);
        }

        @Override
        public boolean next(Object key, Object value) throws IOException {
            return next((IWritable) key, (IWritable) value);
        }
    }

    /**
     * One chunk of data, contains the buffer and the buffer size.
     * 
     * @author river
     */
    public static class CompressedChunk {
        private int size;

        private byte[] buf;

        public CompressedChunk(byte[] buf, int size) {
            this.buf = buf;
            this.size = size;
        }
    }

    /**
     * DataBlock contains key length chunks, key data chunks, val length chunks
     * and value data chunks.
     * 
     * @author river
     */
    public static class DataBlock {
        private int recordCount = 0;

        ArrayList<CompressedChunk> keyLenChunks = new ArrayList<CompressedChunk>();

        ArrayList<CompressedChunk> valLenChunks = new ArrayList<CompressedChunk>();

        ArrayList<CompressedChunk> keyChunks = new ArrayList<CompressedChunk>();

        ArrayList<CompressedChunk> valChunks = new ArrayList<CompressedChunk>();

        /**
         * Clear all the chunks.
         */
        public void clear() {
            recordCount = 0;
            keyLenChunks.clear();
            valLenChunks.clear();
            keyChunks.clear();
            valChunks.clear();
        }

    }

    /**
     * This reader add {@link BlockCompressedReader#nextBlock()} and
     * {@link BlockCompressedReader#getCurrentBlock()} to allow user access the
     * original compressed block.
     * {@link BlockCompressedWriter#writeCompressedBlock(odis.file.SequenceFile.DataBlock)}
     * can write the compressed block out without decompression. The data is not
     * auto decompressed when {@link BlockCompressedReader#nextBlock()} called.
     * The key data is decompressed the first time when
     * {@link BlockCompressedReader#nextKeyInBlock(IWritable)} called, and the
     * value data is decompressed the first time when
     * {@link BlockCompressedReader#nextValueInBlock(IWritable)} called.
     * 
     * @author river
     */
    public static class BlockCompressedReader extends Reader {
        private DataBlock dataBlock = new DataBlock();

        private boolean blockReady = false;

        private boolean keyDecompressed = false;

        private int keyRecordNumber;

        private boolean valDecompressed = false;

        private int valRecordNumber;

        /**
         * Constructor. The file to be read must be block compressed without
         * object compression, or {@link IOException} should be raised.
         * 
         * @param fs
         * @param path
         * @throws IOException
         */
        public BlockCompressedReader(IFileSystem fs, Path path)
                throws IOException {
            super(fs, path);
            if (this.getCompressBlockSize() <= 0) {
                throw new IOException("file " + fn()
                        + " is not block compressed");
            }
        }

        /**
         * Get the current block after {@link #nextBlock()} invoked. Code to
         * access blocks should be like : <code>
         *     while (reader.nextBlock()) {
         *         DataBlock block = getCurrentBlock();
         *         ...
         *     }
         * </code>
         * 
         * @return
         */
        public DataBlock getCurrentBlock() {
            if (blockReady) {
                return dataBlock;
            } else {
                return null;
            }
        }

        /**
         * Read the next block or return false if no more block. The methods to
         * access data in block, such as {@link #getCurrentBlock()},
         * {@link #nextKeyInBlock(IWritable)}, should only be called when
         * {@link #nextBlock()} returns true.
         * 
         * @return
         * @throws IOException
         */
        public boolean nextBlock() throws IOException {
            long oldPos = in.getPos();
            if (oldPos >= this.fileEnd || this.lastSyncStart >= end) {
                return false;
            }

            bufferedRecords = in.readVInt();
            if (bufferedRecords == SYNC_ESCAPE) {
                lastSyncStart = oldPos;
                if (lastSyncStart >= end) {
                    throw new EOFException("file end");
                }

                in.readFully(syncCheck); // read syncCheck
                if (!Arrays.equals(sync, syncCheck)) {// check it
                    throw new IOException("Invalid sync. File is corrupt: "
                            + fn());
                }
                bufferedRecords = in.readVInt();
            }
            dataBlock.clear();
            dataBlock.recordCount = bufferedRecords;

            if (fixedKeyLength <= 0) {
                readChunks(dataBlock.keyLenChunks);
            }
            readChunks(dataBlock.keyChunks);
            if (fixedValLength <= 0 || objectCompressed) {
                readChunks(dataBlock.valLenChunks);
            }
            readChunks(dataBlock.valChunks);

            if (dataBlock.keyChunks.size() > 0) {
                blockReady = true;
                keyDecompressed = false;
                valDecompressed = false;
                return true;
            } else {
                blockReady = false;
                return false;
            }
        }

        /**
         * Read the next key in current block, or return false if no more key in
         * current block. This method is independent with
         * {@link #nextValueInBlock(IWritable)}, that is to say, the read
         * pointer for value is not affected in this method. Key data
         * decompression is done when the first key in current block accessed,
         * and value data is not affected.
         * 
         * @param key
         * @return
         * @throws IOException
         */
        public boolean nextKeyInBlock(IWritable key) throws IOException {
            if (!keyDecompressed) {
                if (this.fixedKeyLength < 0) {
                    decompressChunks(dataBlock.keyLenChunks, this.keyLenBuf,
                            false);
                }
                decompressChunks(dataBlock.keyChunks, this.keyBuf, true);
                keyRecordNumber = dataBlock.recordCount;
                keyDecompressed = true;
            }
            if (keyRecordNumber == 0) {
                return false;
            }

            int keyLen;
            if (this.fixedKeyLength < 0) {
                keyLen = this.keyLenBuf.readVInt();
            } else {
                keyLen = this.fixedKeyLength;
            }

            int oldPos = keyBuf.getPosition();
            key.readFields(keyBuf);
            if (keyBuf.getPosition() - oldPos != keyLen) {
                throw new IOException("key length in data ("
                        + (keyBuf.getPosition() - oldPos)
                        + ") is not the same " + "as key length expected("
                        + keyLen + "): " + fn());
            }

            keyRecordNumber--;
            return true;
        }

        /**
         * Refer to {@link #nextKeyInBlock(IWritable)}.
         * 
         * @param value
         * @return
         * @throws IOException
         */
        public boolean nextValueInBlock(IWritable value) throws IOException {
            if (!valDecompressed) {
                if (this.fixedValLength < 0) {
                    decompressChunks(dataBlock.valLenChunks, this.valLenBuf,
                            false);
                }
                decompressChunks(dataBlock.valChunks, this.valBuf, true);
                valRecordNumber = dataBlock.recordCount;
                valDecompressed = true;
            }
            if (valRecordNumber == 0) {
                return false;
            }

            int valLen;
            if (this.fixedValLength < 0) {
                valLen = this.valLenBuf.readVInt();
            } else {
                valLen = this.fixedValLength;
            }

            int oldPos = valBuf.getPosition();
            value.readFields(valBuf);
            if (valBuf.getPosition() - oldPos != valLen) {
                throw new IOException("value length in data ("
                        + (valBuf.getPosition() - oldPos)
                        + ") is not the same as value length expected("
                        + valLen + ")");
            }

            valRecordNumber--;
            return true;
        }

        /**
         * Decompress chunks.
         * 
         * @param chunks
         * @param data
         * @param twopass
         * @throws IOException
         */
        private void decompressChunks(ArrayList<CompressedChunk> chunks,
                DataInputBuffer data, boolean twopass) throws IOException {
            data.reset();

            byte[] ubuf1 = byteArrayBufferPool.allocate((compressBlockSize + COMPRESS_CHUNK_EXTRA_SIZE) * 2);
            byte[] ubuf2 = twopass ? byteArrayBufferPool.allocate((compressBlockSize + COMPRESS_CHUNK_EXTRA_SIZE) * 2)
                    : null;

            try {
                int chunkNumber = chunks.size();
                DataOutputBuffer obuf = null;

                for (int i = 0; i < chunkNumber; i++) {
                    CompressedChunk chunk = chunks.get(i);

                    int len;
                    if (twopass) {
                        len = CompressUtils.uncompress(chunk.buf, 0,
                                chunk.size, ubuf2, 0, compressAlgo, -1);
                        if (len < 0) {
                            throw new IOException("uncompression error.");
                        }
                        len = BmzCompression.uncompress(ubuf2, 0, len, ubuf1);
                        if (len < 0) {
                            throw new IOException("BMZ uncompression error : "
                                    + len);
                        }
                    } else {
                        len = CompressUtils.uncompress(chunk.buf, 0,
                                chunk.size, ubuf1, 0, compressAlgo, -1);
                        if (len < 0) {
                            throw new IOException("uncompression error.");
                        }
                    }

                    if (obuf == null) {
                        obuf = new DataOutputBuffer(len);
                    }
                    obuf.write(ubuf1, 0, len);
                }

                data.reset(obuf.getData(), 0, obuf.size());
            } finally {
                if (ubuf2 != null) {
                    byteArrayBufferPool.release(ubuf2);
                }
                byteArrayBufferPool.release(ubuf1);
            }
        }

        /**
         * Read in one chunks. Because one block could be too large to be
         * compressed once, it could be split into several compressed chunks.
         * Every chunk except the last chunk should be started with 0(vint).
         * 
         * @param chunks
         * @throws IOException
         */
        private void readChunks(ArrayList<CompressedChunk> chunks)
                throws IOException {
            boolean hasMore;
            do {
                int length = in.readVInt();
                if (length == 0) {
                    length = in.readVInt();
                    hasMore = true;
                } else {
                    hasMore = false;
                }

                if (length > 0) {
                    byte[] buf = new byte[length];
                    in.read(buf, 0, length);
                    CompressedChunk chunk = new CompressedChunk(buf, length);
                    chunks.add(chunk);
                }
            } while (hasMore);
        }

        /**
         * Override {@link Reader#next(Object, Object)} by using
         * {@link #nextKeyInBlock(IWritable)} and
         * {@link #nextValueInBlock(IWritable)}.
         */
        @Override
        public boolean next(IWritable key, IWritable value) throws IOException {
            while (true) {
                if (blockReady) {
                    if (nextKeyInBlock(key)) {
                        if (!nextValueInBlock(value)) {
                            throw new IOException("key without value found");
                        }
                        return true;
                    }
                }

                if (!nextBlock()) {
                    return false;
                }
            }
        }

    }

    /**
     * {@link BlockCompressedWriter} add
     * {@link BlockCompressedWriter#writeCompressedBlock(odis.file.SequenceFile.DataBlock)}
     * method to output compressed block returned from
     * BlockCompressedReader#getCurrentBlock() directly without
     * uncompress/compress.
     * 
     * @author river
     */
    public static class BlockCompressedWriter extends CompressedWriter {

        /**
         * Construct writer. The blockSize should be exactly the same as reader,
         * and you can get the value by {@link Reader#getCompressBlockSize()}.
         * 
         * @param fs
         * @param file
         * @param keyClass
         * @param valClass
         * @param overwrite
         * @param blockSize
         * @throws IOException
         */
        public BlockCompressedWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, int blockSize)
                throws IOException {
            super(fs, file, keyClass, valClass, overwrite, blockSize, false);
        }

        public BlockCompressedWriter(IFileSystem fs, Path file, Class keyClass,
                Class valClass, boolean overwrite, int blockSize,
                CompressAlgo compressAlgo) throws IOException {
            super(fs, file, keyClass, valClass, overwrite, blockSize, false,
                    compressAlgo);
        }

        private void writeChunks(ArrayList<CompressedChunk> chunks)
                throws IOException {

            if (chunks.isEmpty()) {
                out.writeVInt(0);
                out.writeVInt(0);
                return;
            }

            int chunkNumber = chunks.size();
            for (int i = 0; i < chunkNumber; i++) {
                CompressedChunk chunk = chunks.get(i);
                if (i < chunkNumber - 1) {
                    out.writeVInt(0);
                }
                out.writeVInt(chunk.size);
                out.write(chunk.buf, 0, chunk.size);
            }
        }

        /**
         * Write compressed block directly. If
         * {@link Writer#write(Object, Object)} is called previously, the data
         * in buffer should be flushed first before writing this block.
         * 
         * @param block
         * @throws IOException
         */
        public void writeCompressedBlock(DataBlock block) throws IOException {

            // flush data in buffer
            if (this.nrRecordsInBlock > 0) {
                this.writeBlock();
            }

            // write sync
            if (sync != null) {
                out.writeVInt(SYNC_ESCAPE); // escape it
                out.write(sync); // write sync
            }

            // write number of records
            out.writeVInt(block.recordCount);

            // write keys
            if (fixedKeyLength <= 0) {
                writeChunks(block.keyLenChunks);
            }
            writeChunks(block.keyChunks);

            // write values
            if (fixedValLength <= 0) {
                writeChunks(block.valLenChunks);
            }
            writeChunks(block.valChunks);
        }

    }
}
