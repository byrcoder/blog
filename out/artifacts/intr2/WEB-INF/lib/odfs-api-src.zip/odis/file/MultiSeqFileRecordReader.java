/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 14, 2006
 */
package odis.file;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;

/**
 * A readers for reading multiple sequence files in the same directory as a
 * single stream of records. Positioning in done globally using a long number.
 * The header at the beginning of each sequence file is properly skipped when
 * seeking between files. It is assumed that all files in the directory have the
 * same key/value types. Files opened are not closed until the whole reader is
 * closed.
 * 
 * @author zf, zl Change log: - 7/13/2006 (zl) Modify it to implement
 *         IRecordReader interface
 */

public class MultiSeqFileRecordReader implements IRecordReader<Object, Object> {
    private IFileSystem nfs;

    private FileInfo[] files;

    private long[] offsets;

    private long pos;

    private SequenceFile.Reader[] readers;

    private int n;

    private int cur = -1; // current index of reader

    /**
     * This constructor reads files from the first byte.
     * 
     * @param dir
     *            the directory containing all sequence files.
     */
    public MultiSeqFileRecordReader(FileSystem nfs, File dir)
            throws IOException {
        this(nfs, dir, 0);
    }

    /**
     * This constructor reads files from the first byte.
     * 
     * @param dir
     *            the directory containing all sequence files.
     */
    public MultiSeqFileRecordReader(FileSystem nfs, String dir)
            throws IOException {
        this(nfs, dir, 0);
    }

    /**
     * @param dir
     *            the directory containing all sequence files.
     * @param pos
     *            initial position of the reader. a sync operatation will be
     *            performed to move the pointer to the first record after a sync
     *            point from the requested position.
     */
    public MultiSeqFileRecordReader(FileSystem nfs, String dir, int pos)
            throws IOException {
        this(nfs, new File(dir), pos);
    }

    /**
     * Copired from toolbox.misc.FileUtils, and make the input parameter into
     * FileInfo Sort the files by the length of name, then by the dictionary
     * order of names. Sorting is done in place.
     */
    private static void sortByNameLength(FileInfo[] files) {
        Arrays.sort(files, new Comparator<FileInfo>() {
            public int compare(FileInfo o1, FileInfo o2) {
                String n1 = o1.getPath().getName();
                String n2 = o2.getPath().getName();
                int len1 = n1.length();
                int len2 = n2.length();
                if (len1 == len2)
                    return n1.compareTo(n2);
                else if (len1 < len2)
                    return -1;
                else
                    return 1;
            }
        });
    }

    /**
     * @param dir
     *            the directory containing all sequence files.
     * @param pos
     *            initial position of the reader. a sync operatation will be
     *            performed to move the pointer to the first record after a sync
     *            point from the requested position.
     */
    public MultiSeqFileRecordReader(FileSystem nfs, File dir, int pos)
            throws IOException {
        this.nfs = nfs;
        files = nfs.listFiles(new Path(dir));
        n = files.length;

        // sort by length, then by dictionary order
        // because we want part-5 to appear before part-10
        sortByNameLength(files);

        // compute offsets of each file's start
        offsets = new long[n + 1];
        long off = 0;
        for (int i = 0; i < n; i++) {
            offsets[i] = off;
            off += nfs.getLength(files[i].getPath());
        }
        offsets[n] = off;

        readers = new SequenceFile.Reader[n];

        this.pos = pos;
        if (openReader())
            sync(this.pos);
    }

    public Class<? extends IWritable> getKeyClass() {
        return readers[cur].getKeyClass();
    }

    public Class<? extends IWritable> getValueClass() {
        return readers[cur].getValueClass();
    }

    public boolean next(IWritable key, IWritable value) throws IOException {
        if (cur == n) {
            return false;
        }
        boolean r = readers[cur].next(key, value);
        if (!r) {
            throw new IOException(
                    "Reader returns false before reaching end of file");
        }
        // update pos after read
        pos = offsets[cur] + readers[cur].getPosition();
        if (pos >= offsets[cur + 1]) {
            openReader(); // open next file
        }
        return true;
    }

    public void close() throws IOException {
        for (int i = 0; i < n; i++)
            if (readers[i] != null) {
                readers[i].close();
                readers[i] = null;
            }
        cur = -3;
    }

    public long getPos() throws IOException {
        return pos;
    }

    /**
     * @return Total length of all files.
     */
    public long getSize() throws IOException {
        return offsets[n];
    }

    /**
     * Open reader at current position and point <code>cur</code> to it. The
     * reader, if newly opened, is positioned at the beginning. Thus an extra
     * seek is needed if not the first pair is needed.
     * 
     * @return false if at end of the whole stream
     */
    private boolean openReader() throws IOException {
        while (true) {
            // find the current reader
            cur = Arrays.binarySearch(offsets, pos);
            if (cur < 0) {
                cur = -(cur + 1) - 1; // -(cur+1) is insertion point
            }
            if (cur == n) {
                return false;
            }
            if (readers[cur] == null) {
                readers[cur] = new SequenceFile.Reader(nfs,
                        files[cur].getPath());
                pos = offsets[cur] + readers[cur].getPosition();
            }
            if (pos < offsets[cur + 1]) {
                return true;
            }
        }
    }

    protected void sync(long l) throws IOException {
        while (true) {
            if (l < 0) {
                throw new ArrayIndexOutOfBoundsException(
                        "Sync'ing to a negative index: " + l);
            }
            if (l > offsets[n]) {
                l = offsets[n];
            }
            if (cur == n || l < offsets[cur] || l >= offsets[cur + 1]) {
                this.pos = l;
                if (!openReader()) {
                    return; // end of file
                }
            }
            readers[cur].sync(l - offsets[cur]);
            // update pos after read
            l = offsets[cur] + readers[cur].getPosition();
            if (l >= offsets[cur + 1]) {
                this.pos = l;
                openReader();
            } else {
                return;
            }
        }
    }

    @Override
    public boolean next(Object key, Object value) throws IOException {
        return next((IWritable) key, (IWritable) value);
    }

}
