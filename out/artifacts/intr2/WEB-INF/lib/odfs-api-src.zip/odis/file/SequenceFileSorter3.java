/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.file;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Limit;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.util.ThreadLocalRandomData;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

/**
 * Sorter for sequence files. Now we can read the data out before all data are
 * sorted.
 * <p>
 * Usage:<br>
 * <code>
 *   SequenceFileSorter3 sorter = new SequenceFileSorter3();<br>
 *   <br>
 *   sorter.queueInputFile();<br>
 *   sorter.endInputQueue();<br>
 *   <br>
 *   sorter.prepare();<br>
 *   IRecordReader reader = sorter.read();<br>
 *   ...<br>
 *   reader.next();<br>
 *   ...<br>
 *   reader.close();<br>
 * </code>
 * 
 * @author river, David
 */
public class SequenceFileSorter3 {
    public static final String SORT_MEMORY = "merge_sort.memory";

    public static final String READ_MEMORY = "merge_sort.read-memory";

    protected static final Logger LOG = LogFormatter.getLogger(SequenceFileSorter3.class);

    private static class RemoteFile {
        private IFileSystem fs;

        private Path file;

        private RemoteFile(IFileSystem fs, Path file) {
            this.fs = fs;
            this.file = file;
        }

        public String toString() {
            if (fs == null || file == null) {
                return "";
            }
            return fs.getName() + "://" + file;
        }

        @Override
        public int hashCode() {
            final int PRIME = 31;
            int result = 1;
            result = PRIME * result + ((file == null) ? 0 : file.hashCode());
            result = PRIME * result + ((fs == null) ? 0 : fs.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final RemoteFile other = (RemoteFile) obj;
            if (file == null) {
                if (other.file != null) {
                    return false;
                }
            } else if (!file.equals(other.file)) {
                return false;
            }
            if (fs == null) {
                if (other.fs != null) {
                    return false;
                }
            } else if (!fs.equals(other.fs)) {
                return false;
            }
            return true;
        }
    }

    private static final int DEFAULT_FACTOR;

    private static final int DEFAULT_MEMORY;

    private static final int DEFAULT_READ_MEMORY;
    static {
        DEFAULT_FACTOR = OdisLibConfig.conf().getInt(
                "file.seqfile.sort.factor", 100);
        boolean windows = System.getProperty("os.name", "linux").toUpperCase().startsWith(
                "WIN");
        boolean isTest = (System.getProperty("IS_TEST") != null);
        if (windows || isTest) {
            DEFAULT_MEMORY = 1;
            DEFAULT_READ_MEMORY = 3;
        } else {
            DEFAULT_MEMORY = OdisLibConfig.conf().getInt(
                    "file.seqfile.sort.memory-mb", 100);
            DEFAULT_READ_MEMORY = OdisLibConfig.conf().getInt(
                    "file.seqfile.read.memory-mb", DEFAULT_MEMORY * 3);
        } // else
    }

    protected int memory = DEFAULT_MEMORY * 1024 * 1024; // bytes

    protected int readMemory = DEFAULT_READ_MEMORY * 1024 * 1024; // bytes

    protected int factor = DEFAULT_FACTOR; // merged per pass

    private ArrayList<RemoteFile> inFiles = new ArrayList<RemoteFile>();

    private volatile int processed;

    private volatile long processedSize;

    private IFileSystem fs;

    private IRecordComparator comparator;

    private Class<? extends IWritable> keyClass;

    private Class<? extends IWritable> valClass;

    private Path segmDir;

    private int segments = -1;

    private boolean keyLengthFixed;

    private boolean valLengthFixed;

    private int compressBlockSize;

    private boolean objectCompressed;

    private boolean objectCompressedSet = false;

    /**
     * The constructor.
     * 
     * @param fs
     *            the file-system for output and temporary files.
     * @param segmDir
     *            the output folder for segments. NOTE: Do not read the files in
     *            this folder. Call read() to get a reader of the output.
     * @param keyClass
     *            the class of the key
     * @param valClass
     *            the class of the value
     * @param comparator
     *            the record-comparator
     */
    public SequenceFileSorter3(IFileSystem fs, Path segmDir,
            Class<? extends IWritable> keyClass,
            Class<? extends IWritable> valClass, IRecordComparator comparator) {
        this(fs, segmDir, keyClass, valClass, comparator, false);
        compressBlockSize = -1;
        objectCompressedSet = false;
    }

    /**
     * The constructor.
     * 
     * @param fs
     *            the file-system for output and temporary files.
     * @param segmDir
     *            the output folder for segments NOTE: Do not read the files in
     *            this folder. Call read() to get a reader of the output.
     * @param keyClass
     *            the class of the key
     * @param valClass
     *            the class of the value
     * @param comparator
     *            the record-comparator
     */
    public SequenceFileSorter3(IFileSystem fs, Path segmDir,
            Class<? extends IWritable> keyClass,
            Class<? extends IWritable> valClass, IRecordComparator comparator,
            boolean objectCompressed) {
        this.fs = fs;
        this.segmDir = segmDir;
        this.keyClass = keyClass;
        this.valClass = valClass;
        this.comparator = comparator;
        this.keyLengthFixed = WritableRegistry.getWritableSize(keyClass) >= 0;
        this.valLengthFixed = keyLengthFixed
                && WritableRegistry.getWritableSize(valClass) >= 0;
        this.objectCompressed = objectCompressed;
        objectCompressedSet = true;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public int getMemory() {
        return memory;
    }

    public void setReadMemory(int readMemory) {
        this.readMemory = readMemory;
    }

    public int getReadMemory() {
        return readMemory;
    }

    public void setFactor(int factor) {
        this.factor = factor;
    }

    public int getFactor() {
        return this.factor;
    }

    /**
     * Add a single input file and close the queue.
     * 
     * @param fs
     *            the file-system
     * @param file
     *            the path
     * @return true if success, false otherwise
     */
    public boolean addInputFile(IFileSystem fs, File file) {
        if (!queueInputFile(fs, file))
            return false;
        if (!endInputQueue())
            return false;
        return true;
    }

    /**
     * Add a fs-file pair to the buffer queue.
     * 
     * @param fs
     *            the file-system
     * @param file
     *            the file
     * @return true if success, false if the specified fs-file has existed in
     *         the queue.
     */
    public boolean queueInputFile(IFileSystem fs, File file) {
        RemoteFile rf = new RemoteFile(fs, file == null ? null : new Path(file));
        LOG.info("Adding remote file: " + rf);
        synchronized (inFiles) {
            if (inFiles.contains(rf))
                return false;
            inFiles.add(rf);
            inFiles.notifyAll();
        }
        return true;
    }

    /**
     * Removes a fs-file pair from the queue.
     * 
     * @param fs
     *            the file-system
     * @param file
     *            the path
     * @return true
     */
    public boolean dequeueInputFile(FileSystem fs, File file) {
        RemoteFile rf = new RemoteFile(fs, new Path(file));
        LOG.info("Removing remote file: " + rf);
        return inFiles.remove(rf);
    }

    /**
     * Tells the reading thread all input files are added.
     * 
     * @return true if succe, false if the queue has been ended
     */
    public boolean endInputQueue() {
        return queueInputFile(null, null);
    }

    /**
     * Returns the number of inputs done.
     * 
     * @return the number of inputs done
     */
    public int doneInputCount() {
        return processed;
    }

    /**
     * Returns the size of inputs done in bytes.
     * 
     * @return the size of inputs done in bytes
     */
    public long doneInputSize() {
        return processedSize;
    }

    protected int sortPass() throws IOException {
        LOG.info("Running sort pass with " + readMemory + " memory as buffer");

        // make the SortPass
        SortPass sortPass = new SortPass(readMemory);
        // run it
        return sortPass.run();
    }

    private void endQueue(MergeQueue queue, HashSet<Integer> toDel,
            int newSegm, Path workDir) throws IOException {
        LOG.info("Merging " + toDel.size() + " segments into " + newSegm);
        queue.merge(workDir.cat("" + newSegm));

        queue.close();
        if (!toDel.isEmpty()) {
            for (Integer td: toDel) {
                fs.delete(workDir.cat("" + td));
            } // for td
            toDel.clear();
        } // if
    }

    /**
     * Merges the output segments into at most <remains> segments
     * 
     * @param remains
     *            the maximum number of segments to remain after merging
     * @return the number of remaining segments
     * @throws IOException
     *             if an I/O error occurs
     */
    protected int merge(Path workDir, int remains) throws IOException {
        PriorityQueue<Integer> files = new PriorityQueue<Integer>(100);
        int max = 0;
        for (FileInfo f: fs.listFiles(workDir)) {
            int num = Integer.parseInt(f.getPath().getName());
            if (num > max)
                max = num;
            files.add(num);
        } // for f

        HashSet<Integer> toDel = new HashSet<Integer>();

        LOG.info("Merge " + files.size() + " segments ...");
        int newSegm = 0;
        MergeQueue queue = null;
        int newFiles = 0;
        try {
            while (files.size() + newFiles > remains) {
                int curSegm = files.poll();
                toDel.add(curSegm);
                SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                        workDir.cat("" + curSegm));
                MergeStream ms = new MergeStream(reader);
                if (!ms.next()) {
                    ms.in.close();
                    continue;
                } // if

                if (queue == null) {
                    newSegm = ++max;
                    queue = new MergeQueue(factor);
                    newFiles++;
                } // if

                queue.add(ms);
                if (queue.size() >= factor) {
                    endQueue(queue, toDel, newSegm, workDir);
                    files.add(newSegm);
                    newFiles--;
                    queue = null;
                } // if
            } // while
        } finally {
            if (queue != null) {
                endQueue(queue, toDel, newSegm, workDir);
                files.add(newSegm);
                newFiles--;
                queue = null;
            } // if
        }

        return files.size();
    }

    /**
     * Read in all the sequence files and do the first sort pass. After
     * prepare(), data is ready for read.
     * 
     * @throws IOException
     */
    public void prepare() throws IOException {
        fs.delete(segmDir);
        fs.mkdirs(segmDir);
        segments = sortPass();

        if (segments > factor)
            segments = merge(segmDir, factor);
    }

    /**
     * Merge the results into a single one
     * 
     * @throws IOException
     *             if an I/O error occurs
     */
    public void complete() throws IOException {
        assert segments >= 0;
        if (segments > 1) {
            merge(segmDir, 1);
        } // if
    }

    /**
     * Opens a IRecordReader for reading. Call this function after calling
     * prepare. The caller should close this reader after reading.
     * 
     * @return the created IRecordReader.
     * @throws IOException
     *             if an I/O error occurs
     */
    public IRecordReader<IWritable, IWritable> read() throws IOException {
        assert segments >= 0;
        if (!fs.exists(segmDir)) {
            throw new IOException("Not output segments!");
        }
        FileInfo[] segms = fs.listFiles(segmDir);
        if (segms.length == 0) {
            throw new IOException("Not output segments!");
        }

        if (segms.length == 1) {
            return (IRecordReader) new SequenceFile.Reader(fs,
                    segms[0].getPath());
        } else {
            return new SortReader(segmDir);
        }
    }

    /**
     * Removes the temporary files used during sorting if any.
     * 
     * @throws IOException
     *             if an I/O error occurs
     */
    public void cleanTempFiles() throws IOException {}

    protected class SortReader implements IRecordReader<IWritable, IWritable> {
        private MergeQueue queue;

        private DataInputBuffer inBuf = new DataInputBuffer();

        private long size;

        private long pos;

        private byte[] oubuf;

        private CompressAlgo compressAlgo = CompressAlgo.LZO;

        public SortReader(Path inDir) throws IOException {
            if (objectCompressed) {
                oubuf = new byte[4096];
            }
            queue = new MergeQueue(factor);
            FileInfo[] files = fs.listFiles(inDir);

            pos = 0;
            size = 0;
            for (FileInfo f: files) {
                SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                        f.getPath());
                compressAlgo = reader.getCompressAlgo();
                MergeStream ms = new MergeStream(reader); // add segment
                if (ms.next()) {
                    pos += reader.getPos();
                    size += reader.getSize();
                    queue.add(ms);
                } // if
            } // for f
        }

        public boolean next(IWritable key, IWritable value) throws IOException {
            if (queue.size() == 0)
                return false;

            MergeStream ms = queue.remove();
            long oldPos = ms.in.getPos();
            DataOutputBuffer buf = ms.buffer;
            inBuf.reset(buf.getData(), 0, buf.size());
            key.readFields(inBuf);

            if (objectCompressed) {
                int ucSize = inBuf.readVInt();
                Limit.checkBufferSize(ucSize);
                if (ucSize > oubuf.length) {
                    int newSize = oubuf.length << 1;
                    while (newSize < ucSize) {
                        newSize = newSize << 1;
                    }
                    oubuf = new byte[newSize];
                }

                CompressUtils.uncompress(inBuf.getBuffer(),
                        inBuf.getPosition(), inBuf.getSize(), oubuf, 0,
                        compressAlgo, ucSize);

                inBuf.reset(oubuf, 0, ucSize);
            }
            value.readFields(inBuf);

            boolean hasMore = ms.next();
            long newPos = ms.in.getPos();
            pos += (newPos - oldPos);

            if (hasMore) {
                queue.add(ms);
            } else {
                ms.in.close();
            }
            return true;
        }

        public void close() throws IOException {
            queue.close();
        }

        public Class<? extends IWritable> getKeyClass() {
            return keyClass;
        }

        public Class<? extends IWritable> getValueClass() {
            return valClass;
        }

        public long getPos() throws IOException {
            return pos;
        }

        public long getSize() throws IOException {
            return size;
        }
    }

    private SequenceFile.Writer createWriter(Path path) throws IOException {
        if (compressBlockSize > 0) {
            return new SequenceFile.CompressedWriter(fs, path, keyClass,
                    valClass, true,
                    SequenceFile.CompressedWriter.DEFAULT_BLOCK_SIZE,
                    objectCompressed);
        } else if (objectCompressed) {
            return new SequenceFile.ObjectCompressWriter(fs, path, keyClass,
                    valClass);
        } else {
            return new SequenceFile.Writer(fs, path, keyClass, valClass);
        }
    }

    protected class SortPass {
        class SortPassLocal {
            public int[] starts = new int[1024];

            public int[] pointers = new int[starts.length];

            public int[] pointersCopy = new int[starts.length];

            public int[] keyLengths = new int[starts.length];

            public int[] lengths = new int[starts.length];

            public int count = 0;

            public DataOutputBuffer buffer = new DataOutputBuffer();

            public byte[] rawBuffer;

            int segments;

            public SortPassLocal() {}

            /**
             * Returns the memory used in this local set. The size equals:
             * memory of buffer/starts/pointers/pointersCopy/keyLengths/ lengths
             * 
             * @return the memory used in this local set
             */
            public int memoryUsed() {
                return buffer.size() + count * (5 * 4);
            }

            /**
             * Resets the buffer for reading
             */
            public void reset() {
                if (count > 0) {
                    /*
                     * limit potential size if the buffer to no more than 11/10
                     * of buffer.size()
                     */
                    buffer.reset((int) (buffer.size() / 10.0 * 11));
                    if (starts.length > 1024
                            && starts.length > (int) (count / 10.0 * 11)) {
                        // try reduce the memory used for starts etc. arrays
                        int newLength = (int) (count / 10.0 * 11);
                        if (newLength < 1024)
                            newLength = 1024;
                        LOG.info("Shrink starts from " + starts.length + " to "
                                + newLength);
                        starts = new int[newLength];
                        pointers = new int[starts.length];
                        pointersCopy = new int[starts.length];
                        keyLengths = new int[starts.length];
                        lengths = new int[starts.length];
                    } // if
                } else {
                    buffer.reset();
                }
                count = 0;
            }

            /**
             * Grows the buffers and copies old contents to the new buffers
             */
            public void grow() {
                int newLength = starts.length * 3 / 2;

                starts = grow(starts, newLength);
                pointers = grow(pointers, newLength);
                pointersCopy = new int[newLength];
                keyLengths = grow(keyLengths, newLength);
                lengths = grow(lengths, newLength);
            }

            private int[] grow(int[] old, int newLength) {
                int[] result = new int[newLength];
                System.arraycopy(old, 0, result, 0, old.length);
                return result;
            }

            /**
             * Inserts a new entry info into the list.
             * 
             * @param start
             *            the start offset of this entry
             * @param length
             *            the length of this entry in bytes
             * @param keyLength
             *            the lenght of the key-part of this entry in bytes
             */
            public void newEntry(int start, int length, int keyLength) {
                if (count == starts.length)
                    grow();

                starts[count] = start;
                pointers[count] = count;
                lengths[count] = length;
                keyLengths[count] = keyLength;

                count++;
            }

            private int compare(int i, int j) {
                return comparator.compare(rawBuffer, starts[i], keyLengths[i],
                        lengths[i] - keyLengths[i], rawBuffer, starts[j],
                        keyLengths[j], lengths[j] - keyLengths[j]);
            }

            /**
             * Input : src[low-high] and dest[low-high] are the same Output:
             * dest[low-high] are sorted, src[low-high] undefined. Other
             * elements of src and dest unchanged.
             */
            private void mergeSort(int src[], int dest[], int low, int high) {
                int length = high - low;

                // Insertion sort on smallest arrays
                if (length < 7) {
                    for (int i = low; i < high; i++)
                        for (int j = i; j > low
                                && compare(dest[j - 1], dest[j]) > 0; j--) {
                            swap(dest, j, j - 1);
                        } // for j, i
                    return;
                } // if

                // Recursively sort halves of dest into src
                int mid = (low + high) >>> 1;
                mergeSort(dest, src, low, mid);
                mergeSort(dest, src, mid, high);

                /*
                 * If list is already sorted, just copy from src to dest. This
                 * is an optimization that results in faster sorts for nearly 
                 * ordered lists.
                 */
                if (compare(src[mid - 1], src[mid]) <= 0) {
                    System.arraycopy(src, low, dest, low, length);

                    return;
                }

                // Merge sorted halves (now in src) into dest
                for (int i = low, p = low, q = mid; i < high; i++) {
                    if (q >= high || p < mid && compare(src[p], src[q]) <= 0)
                        dest[i] = src[p++];
                    else
                        dest[i] = src[q++];
                } // for i
            }

            private void swap(int x[], int a, int b) {
                int t = x[a];
                x[a] = x[b];
                x[b] = t;
            }

            void mergeSort() {
                System.arraycopy(pointers, 0, pointersCopy, 0, count);
                mergeSort(pointersCopy, pointers, 0, count);
            }

            protected void flush(Path sortpassOutFile) throws IOException {
                SequenceFile.Writer writer = createWriter(sortpassOutFile);
                try {
                    for (int i = 0; i < count; i++) { // write in sorted order
                        int p = pointers[i];
                        writer.append(rawBuffer, starts[p], lengths[p],
                                keyLengths[p]);
                    } // for i
                } finally {
                    writer.close();
                }
            }
        }

        protected int limit;

        protected long lastTotalEntrySize = 0;

        public SortPass(int memory) {
            /*
             * limit per local-data is one third of the total. One third for 
             * reading, the second third for sort/flush, and the last third for
             * growing the buffer.
             */
            this.limit = memory / 3;
        }

        private RemoteFile nextRemoteFile() {
            ThreadLocalRandomData rand = ThreadLocalRandomData.current();
            synchronized (inFiles) {
                while (true) {
                    if (inFiles.size() > 0) {
                        int randRange = inFiles.size();
                        RemoteFile lastFile = inFiles.get(inFiles.size() - 1);
                        if (lastFile.file == null && lastFile.fs == null) {
                            --randRange;
                        }
                        if (randRange > 0) {
                            RemoteFile rf = inFiles.get(rand.nextInt(randRange));
                            inFiles.remove(rf);
                            return rf;
                        } else
                            return lastFile;
                    }
                    try {
                        inFiles.wait();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }

        private SequenceFile.Reader nextInputReader() throws IOException {
            RemoteFile rf = nextRemoteFile();

            if (rf.file == null && rf.fs == null)
                return null;
            LOG.info("Merge in data from " + rf);
            SequenceFile.Reader reader = new SequenceFile.Reader(rf.fs, rf.file);
            try {
                if (objectCompressedSet) {
                    if (reader.isObjectCompressed() != objectCompressed
                            || reader.getCompressBlockSize() != compressBlockSize) {
                        throw new IOException(
                                "Object compression setting inconsistent");
                    } // if
                } else {
                    objectCompressed = reader.isObjectCompressed();
                    compressBlockSize = reader.getCompressBlockSize();
                } // else
                processed++;

                SequenceFile.Reader res = reader;
                reader = null;
                return res;
            } finally {
                if (reader != null)
                    reader.close();
            }
        }

        private int calcDataSizeInSequenceFile(int keyLength, int totalLength) {
            int size = totalLength;
            if (!keyLengthFixed) {
                size += DataOutputBuffer.getVIntSize(keyLength);
            }
            if (!valLengthFixed) {
                size += DataOutputBuffer.getVIntSize(totalLength);
            }
            return size;
        }

        SortPassLocal readLocal;

        public class SortWork extends AsyncWork {
            public SortPassLocal sortLocal = new SortPassLocal();

            Path sortpassOutFile;

            /*
             * Whether the sorting(and saving) thread has job to do (or is doing
             * job).
             */
            boolean hasJob = false;

            public SortWork() {
                super(true);
                start();
            }

            @Override
            protected boolean hasJob() {
                return hasJob;
            }

            @Override
            protected void passJob(Object... objects) {
                sortpassOutFile = segmDir.cat("" + readLocal.segments);

                /*
                 * Exchange readLocal and sortLocal
                 */
                SortPassLocal tmp = sortLocal;
                sortLocal = readLocal;
                readLocal = tmp;

                hasJob = true;
            }

            @Override
            protected void pollJob() {
                hasJob = false;
            }

            @Override
            protected boolean runJob() throws Exception {
                LOG.info("Sorting segment " + sortLocal.segments + " in "
                        + "memory(size=" + sortLocal.buffer.size() + ", count="
                        + sortLocal.count + ") ...");
                sortLocal.rawBuffer = sortLocal.buffer.getData();
                sortLocal.mergeSort();
                LOG.info("Flushing segment " + sortLocal.segments + " to "
                        + sortpassOutFile + " ...");
                sortLocal.flush(sortpassOutFile);
                LOG.info("Flushed segment " + sortLocal.segments + " to "
                        + sortpassOutFile + " ...");
                return true;
            }
        }

        /**
         * Runs the sort process
         * 
         * @return the number of output segments
         * @throws IOException
         *             if an I/O error occurs
         */
        public int run() throws IOException {
            processed = 0;
            processedSize = 0;
            int segments = 0;

            SortWork sortWork = new SortWork();
            readLocal = new SortPassLocal();
            SequenceFile.Reader in = nextInputReader();
            try {
                while (in != null) {
                    // reset buffer
                    readLocal.reset();
                    LOG.info("Reading segment " + segments + " into "
                            + "memory ...");
                    lastTotalEntrySize = 0;

                    int lastEntrySize = 0;
                    // read a segment
                    while (in != null && readLocal.memoryUsed() < limit) {
                        // read an entry into buffer
                        int start = readLocal.buffer.size();
                        int keyLength = -1;
                        try {
                            keyLength = in.next(readLocal.buffer);
                        } catch (IOException e) {
                            LOG.log(Level.SEVERE, "Error while reading from "
                                    + in, e);
                            throw e;
                        }
                        int length = readLocal.buffer.size() - start;

                        if (keyLength == -1) {
                            in.close();
                            in = nextInputReader(); // = null when at the end
                            continue;
                        } // if

                        // update pointers
                        readLocal.newEntry(start, length, keyLength);

                        lastEntrySize = calcDataSizeInSequenceFile(keyLength,
                                length);
                        lastTotalEntrySize += lastEntrySize;
                        processedSize += lastEntrySize;
                    } // while

                    // log the memory usage of current segment
                    LOG.info("Segment " + segments + " used "
                            + readLocal.buffer.size() + " buffer and engaged "
                            + readLocal.memoryUsed() + " memory, the"
                            + " last entry's size is " + lastEntrySize);

                    readLocal.segments = segments;
                    try {
                        /*
                         * Wait for sorting thread to idle, then exchange 
                         * readLocal with sortLocal, and let sorting thread 
                         * sort.
                         */
                        sortWork.addJob();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                    segments++;
                } // while

                try {
                    sortWork.stopWork();
                    sortWork.checkException();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } finally {
                // release the memory
                readLocal = null;
                if (in != null)
                    in.close();
            }

            return segments;
        }
    }

    private final Comparator<MergeStream> mergeStreamComparator = new Comparator<MergeStream>() {

        @Override
        public int compare(MergeStream o1, MergeStream o2) {
            return comparator.compare(o1.buffer.getData(), 0, o1.keyLength,
                    o1.buffer.size() - o1.keyLength, o2.buffer.getData(), 0,
                    o2.keyLength, o2.buffer.size() - o2.keyLength);
        }
    };

    private class MergeStream {
        private SequenceFile.Reader in;

        private DataOutputBuffer buffer = new DataOutputBuffer();

        private int keyLength;

        public MergeStream(SequenceFile.Reader reader) throws IOException {
            if (reader.getKeyClass() != keyClass)
                throw new IOException("wrong key class: "
                        + reader.getKeyClass() + " is not " + keyClass);
            if (reader.getValueClass() != valClass)
                throw new IOException("wrong value class: "
                        + reader.getValueClass() + " is not " + valClass);
            this.in = reader;
        }

        public boolean next() throws IOException {
            buffer.reset((int) (500 * UnitUtils.K));
            keyLength = in.next(buffer);
            return keyLength >= 0;
        }

    }

    private class MergeQueue extends PriorityQueue<MergeStream> {
        private static final long serialVersionUID = 1L;

        public MergeQueue(int size) throws IOException {
            super(size, mergeStreamComparator);
        }

        public void merge(Path output) throws IOException {
            SequenceFile.Writer writer = createWriter(output);
            writer.disableSync();
            try {
                while (size() != 0) {
                    MergeStream ms = remove();
                    DataOutputBuffer buffer = ms.buffer; // write top entry
                    writer.append(buffer.getData(), 0, buffer.size(),
                            ms.keyLength);

                    if (ms.next()) { // has another entry
                        add(ms);
                    } else {
                        ms.in.close();
                    } // else
                } // while
            } finally {
                writer.close();
            }
        }

        public void close() throws IOException {
            MergeStream ms; // close inputs
            while (!isEmpty()) {
                ms = remove();
                ms.in.close();
            } // while
        }
    }

}
