/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 14, 2006
 */
package odis.file;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;

import odis.conf.OdisLibConfig;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;

/**
 * 类似MapFile，但是提供了全索引，并且在索引中记录了数据的长度，从而便于读取.
 * 
 * @author river
 */
public class IndexedFile {
    /** The name of the index file. */
    public static final String INDEX_FILE_NAME = "index";

    /** The name of the data file. */
    public static final String DATA_FILE_NAME = "data";

    /** The name of the data file for compressed indexed files. */
    public static final String COMPRESSED_DATA_FILE_NAME = "compressed_data";

    public static final int DEFAULT_COMPRESS_BLOCK_SIZE = 64 * 1024;

    /** Renames an existing map directory. */
    public static void rename(FileSystem nfs, String oldName, String newName)
            throws IOException {
        Path oldDir = new Path(oldName);
        Path newDir = new Path(newName);
        if (!nfs.rename(oldDir, newDir)) {
            throw new IOException("Could not rename " + oldDir + " to "
                    + newDir);
        }
    }

    /** Deletes the named map file. */
    public static void delete(FileSystem nfs, String name) throws IOException {
        Path dir = new Path(name);
        Path data = dir.cat(DATA_FILE_NAME);
        Path index = dir.cat(INDEX_FILE_NAME);

        nfs.delete(data);
        nfs.delete(index);
        nfs.delete(dir);
    }

    public static File getDataFile(File dir) {
        return new File(dir, DATA_FILE_NAME);
    }

    public static File getIndexFile(File dir) {
        return new File(dir, INDEX_FILE_NAME);
    }

    public static class OffsetAndLength implements IWritable {
        static {
            WritableRegistry.registerSize(OffsetAndLength.class, Long.SIZE
                    / Byte.SIZE + Integer.SIZE / Byte.SIZE);
        }

        private long offset;

        private int length;

        public OffsetAndLength() {}

        public void set(long offset, int length) {
            this.offset = offset;
            this.length = length;
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(offset);
            out.writeInt(length);
        }

        public void readFields(DataInput in) throws IOException {
            offset = in.readLong();
            length = in.readInt();
        }

        public IWritable copyFields(IWritable value) {
            OffsetAndLength that = (OffsetAndLength) value;
            offset = that.offset;
            length = that.length;
            return this;
        }

        public long getOffset() {
            return offset;
        }

        public int getLength() {
            return length;
        }

        public String toString() {
            return "(" + offset + "," + length + ")";
        }
    }

    public static class Writer implements IRecordWriter<Object, Object> {
        protected SequenceFile.Writer data;

        protected SequenceFile.Writer index;

        protected OffsetAndLength offsetAndLength = new OffsetAndLength();

        // for CompressedWriter
        protected Writer() {}

        /**
         * @deprecated use the version with Path instead
         * @param nfs
         * @param dir
         * @param keyClass
         * @param valClass
         * @throws IOException
         */
        @Deprecated
        public Writer(FileSystem nfs, File dir, Class keyClass, Class valClass)
                throws IOException {
            this(nfs, dir, keyClass, valClass, false);
        }

        /**
         * Create the named map for keys of the named class.
         * 
         * @param fs
         *            the file-system instance
         * @param dir
         *            the path of the indexed file to be written
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @throws IOException
         *             if an I/O error occurs
         */
        public Writer(IFileSystem fs, Path dir, Class keyClass, Class valClass)
                throws IOException {
            this(fs, dir, keyClass, valClass, false);
        }

        /**
         * Create the named map for keys of the named class.
         * 
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public Writer(FileSystem nfs, File dir, Class keyClass, Class valClass,
                boolean overwrite) throws IOException {
            this(nfs, new Path(dir), keyClass, valClass, overwrite);
        }

        /**
         * Create the named map for keys of the named class.
         * 
         * @param fs
         *            the file-system instance
         * @param dir
         *            the path of the indexed file to be written
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @throws IOException
         *             if an I/O error occurs
         */
        public Writer(IFileSystem fs, Path dir, Class keyClass, Class valClass,
                boolean overwrite) throws IOException {
            if (fs.exists(dir)) {
                if (fs.listFiles(dir).length != 0) {
                    if (overwrite) {
                        fs.delete(dir);
                        fs.mkdirs(dir);
                    } else {
                        throw new IOException(
                                "already exists and is not empty: " + dir);
                    }
                }
            } else {
                fs.mkdirs(dir);
            }

            Path dataFile = new Path(dir, DATA_FILE_NAME);
            Path indexFile = new Path(dir, INDEX_FILE_NAME);

            data = new SequenceFile.Writer(fs, dataFile, keyClass, valClass);
            this.index = new SequenceFile.Writer(fs, indexFile, keyClass,
                    OffsetAndLength.class);
            index.disableSync();
        }

        /** Close the index file. */
        public synchronized void close() throws IOException {
            data.close();
            index.close();
        }

        /**
         * Append a key/value pair to the map. The key must be strictly greater
         * than the previous key added to the map.
         */
        public synchronized void write(IWritable key, IWritable val)
                throws IOException {

            data.write(key, val);
            offsetAndLength.set(data.getPos() - data.getLastEntrySize(),
                    data.getLastEntrySize());
            index.write(key, offsetAndLength);
        }

        public long getSize() throws IOException {
            return data.getSize();
        }

        @Override
        public void write(Object key, Object value) throws IOException {
            write((IWritable) key, (IWritable) value);
        }
    }

    /**
     * Class to create compressed indexed files, using
     * {@link SequenceFile.CompressedWriter} for the data file.
     * 
     * @author zf
     */
    public static class CompressedWriter extends Writer {
        /**
         * @deprecated use the version with Path instead
         * @param nfs
         * @param dir
         * @param keyClass
         * @param valClass
         * @throws IOException
         */
        @Deprecated
        public CompressedWriter(FileSystem nfs, File dir,
                Class<? extends IWritable> keyClass,
                Class<? extends IWritable> valClass) throws IOException {
            this(nfs, dir, keyClass, valClass, true,
                    OdisLibConfig.conf().getInt(
                            "file.idxfile.compress.block-size",
                            DEFAULT_COMPRESS_BLOCK_SIZE));
        }

        /**
         * The constructor with compress blocksize read from configuration file.
         * 
         * @param fs
         *            the file-system instance
         * @param dir
         *            the path ot the file to be written
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @throws IOException
         *             if an I/O error occurs
         */
        public CompressedWriter(IFileSystem fs, Path dir,
                Class<? extends IWritable> keyClass,
                Class<? extends IWritable> valClass) throws IOException {
            this(fs, dir, keyClass, valClass, true,
                    OdisLibConfig.conf().getInt(
                            "file.idxfile.compress.block-size",
                            DEFAULT_COMPRESS_BLOCK_SIZE));
        }

        /**
         * @deprecated use the version with Path instead
         * @param nfs
         * @param dir
         * @param keyClass
         * @param valClass
         * @param overwrite
         * @throws IOException
         */
        @Deprecated
        public CompressedWriter(FileSystem nfs, File dir,
                Class<? extends IWritable> keyClass,
                Class<? extends IWritable> valClass, boolean overwrite)
                throws IOException {
            this(nfs, dir, keyClass, valClass, overwrite,
                    OdisLibConfig.conf().getInt(
                            "file.idxfile.compress.block-size",
                            DEFAULT_COMPRESS_BLOCK_SIZE));
        }

        /**
         * The constructor with compress blocksize read from configuration file.
         * 
         * @param fs
         *            the file-system instance
         * @param dir
         *            the path ot the file to be written
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @throws IOException
         *             if an I/O error occurs
         */
        public CompressedWriter(IFileSystem fs, Path dir,
                Class<? extends IWritable> keyClass,
                Class<? extends IWritable> valClass, boolean overwrite)
                throws IOException {
            this(fs, dir, keyClass, valClass, overwrite,
                    OdisLibConfig.conf().getInt(
                            "file.idxfile.compress.block-size",
                            DEFAULT_COMPRESS_BLOCK_SIZE));
        }

        /**
         * @deprecated use the version with Path instead
         * @param nfs
         * @param dir
         * @param keyClass
         * @param valClass
         * @param overwrite
         * @param compressBlockSize
         * @throws IOException
         */
        @Deprecated
        public CompressedWriter(FileSystem nfs, File dir,
                Class<? extends IWritable> keyClass,
                Class<? extends IWritable> valClass, boolean overwrite,
                int compressBlockSize) throws IOException {
            this(nfs, new Path(dir), keyClass, valClass, overwrite,
                    compressBlockSize);
        }

        /**
         * The constructor.
         * 
         * @param fs
         *            the file-system instance
         * @param dir
         *            the path ot the file to be written
         * @param keyClass
         *            the key-class
         * @param valClass
         *            the value-class
         * @param overwrite
         *            whether overwrite the file if existed, or throw an
         *            IOException
         * @param compressBlockSize
         *            the compress-block-size
         * @throws IOException
         *             if an I/O error occurs
         */
        public CompressedWriter(IFileSystem fs, Path dir,
                Class<? extends IWritable> keyClass,
                Class<? extends IWritable> valClass, boolean overwrite,
                int compressBlockSize) throws IOException {
            if (fs.exists(dir)) {
                if (fs.listFiles(dir).length != 0) {
                    if (overwrite) {
                        fs.delete(dir);
                        fs.mkdirs(dir);
                    } else {
                        throw new IOException(
                                "already exists and is not empty: " + dir);
                    }
                }
            } else {
                fs.mkdirs(dir);
            }

            Path dataFile = dir.cat(COMPRESSED_DATA_FILE_NAME);
            Path indexFile = dir.cat(INDEX_FILE_NAME);

            data = new SequenceFile.CompressedWriter(fs, dataFile, keyClass,
                    valClass, overwrite, compressBlockSize, false);
            index = new SequenceFile.Writer(fs, indexFile, keyClass,
                    OffsetAndLength.class);
            index.disableSync();
        }

        @Override
        public synchronized void write(IWritable key, IWritable val)
                throws IOException {
            // hack: offset is start of block, length is index in the block
            offsetAndLength.set(data.getPos(),
                    ((SequenceFile.CompressedWriter) data).getRecordsInBlock());
            data.write(key, val);
            index.write(key, offsetAndLength);
        }
    }

    public static class Reader implements IRecordReader<Object, Object> {
        private WritableComparator comparator;

        private long indexSize = 0;

        private IWritableComparable getKey;

        // the data, on disk
        private SequenceFile.Reader data;

        private SequenceFile.Reader index;

        // whether the index Reader was closed
        private boolean indexClosed = false;

        // the index, in memory
        private int count = -1;

        private IWritableComparable[] keys;

        private long[] positions;

        private int[] lengths;

        private boolean atBeginOfData;

        private int currentIndex;

        private boolean compressed;

        /** Returns the class of keys in this file. */
        public Class<? extends IWritableComparable> getKeyClass() {
            return data.getKeyClass().asSubclass(IWritableComparable.class);
        }

        /** Returns the class of values in this file. */
        public Class<? extends IWritable> getValueClass() {
            return data.getValueClass();
        }

        /**
         * Construct a map reader for the named map.
         * 
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public Reader(FileSystem nfs, File dir) throws IOException {
            this(nfs, dir, null);
        }

        /**
         * Construct a map reader for the named map.
         * 
         * @param the
         *            file-system instance
         * @param the
         *            path to the folder of the indexed-file
         */
        public Reader(IFileSystem fs, Path dir) throws IOException {
            this(fs, dir, null);
        }

        /**
         * Construct a map reader for the named map using the named comparator.
         * 
         * @deprecated use the version with Path instead
         */
        @Deprecated
        public Reader(FileSystem nfs, File dir, BinaryComparator bCmp)
                throws IOException {
            this(nfs, new Path(dir), bCmp);
        }

        /** Construct a map reader for the named map using the named comparator. */
        public Reader(IFileSystem nfs, Path dir, BinaryComparator bCmp)
                throws IOException {
            Path dataFile = dir.cat(DATA_FILE_NAME);
            Path compressedFile = dir.cat(COMPRESSED_DATA_FILE_NAME);
            Path indexFile = dir.cat(INDEX_FILE_NAME);

            if (!nfs.exists(dataFile) && nfs.exists(compressedFile)) {
                dataFile = compressedFile;
                compressed = true;
            }
            // open the data
            this.data = new SequenceFile.Reader(nfs, dataFile);

            if (bCmp == null) {
                this.comparator = new WritableComparator(data.getKeyClass());
            } else {
                this.comparator = new WritableComparator(data.getKeyClass(),
                        bCmp);
            } // else

            try {
                this.getKey = (IWritableComparable) this.comparator.getComparableClass().newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            // open the index
            this.index = new SequenceFile.Reader(nfs, indexFile);
            indexSize = nfs.getLength(indexFile);
        }

        private void readIndex() throws IOException {
            // read the index entirely into memory
            if (this.keys != null)
                return;

            this.count = 0;

            int fixedKeyLength = index.getFixedKeyLength();

            // FIXME: this count could be larger than the actural entry count
            int guessEntryCount = (int) (indexSize / (fixedKeyLength > 0 ? (fixedKeyLength + WritableRegistry.getWritableSize(OffsetAndLength.class))
                    : (WritableRegistry.getWritableSize(OffsetAndLength.class) + 4)));

            this.keys = new IWritableComparable[guessEntryCount];
            this.positions = new long[guessEntryCount];
            this.lengths = new int[guessEntryCount];

            try {
                OffsetAndLength offsetAndLength = new OffsetAndLength();
                while (true) {
                    IWritableComparable k = (IWritableComparable) comparator.getComparableClass().newInstance();

                    if (!index.next(k, offsetAndLength))
                        break;

                    if (count == keys.length) { // time to grow arrays
                        int newLength = (keys.length * 3) / 2;
                        IWritableComparable[] newKeys = new IWritableComparable[newLength];
                        long[] newPositions = new long[newLength];
                        int[] newLengths = new int[newLength];
                        System.arraycopy(keys, 0, newKeys, 0, count);
                        System.arraycopy(positions, 0, newPositions, 0, count);
                        System.arraycopy(lengths, 0, newLengths, 0, count);
                        keys = newKeys;
                        positions = newPositions;
                        lengths = newLengths;
                    }

                    keys[count] = k;
                    positions[count] = offsetAndLength.offset;
                    lengths[count] = offsetAndLength.length;
                    count++;
                }
            } catch (EOFException e) {
                SequenceFile.LOG.warning("Unexpected EOF reading " + index
                        + " at entry #" + count + ".  Ignoring.");
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                indexClosed = true;
                index.close();
            }
        }

        private void at(int index) throws IOException {
            currentIndex = index;
            data.seek(positions[currentIndex]);
            if (compressed)
                data.skip(lengths[currentIndex]);
            else
                atBeginOfData = true;
        }

        public synchronized boolean first() throws IOException {
            if (count > 0) {
                at(0);
                return true;
            } else {
                return false;
            }
        }

        public synchronized boolean last() throws IOException {
            if (count > 0) {
                at(count - 1);
                return true;
            } else {
                return false;
            }
        }

        /**
         * Positions the reader at the named key, or if none such exists, at the
         * first entry after the named key. Returns true iff the named key
         * exists in this map.
         */
        public synchronized boolean seek(IWritableComparable key)
                throws IOException {
            if (this.keys == null) {
                readIndex();
            }
            int index = binarySearch(key);

            boolean found = index >= 0;

            if (!found) {
                index = index * (-1) - 1;
            }

            if (index < count) {
                at(index);
            }

            return found;
        }

        private int binarySearch(IWritableComparable key) {
            int low = 0;
            int high = count - 1;

            while (low <= high) {
                int mid = (low + high) >>> 1;
                IWritableComparable midVal = keys[mid];
                int cmp = comparator.compare(midVal, key);

                if (cmp < 0)
                    low = mid + 1;
                else if (cmp > 0)
                    high = mid - 1;
                else {
                    // key found, search back to find the first occur of key
                    while (mid > low
                            && comparator.compare(keys[mid - 1], key) == 0)
                        mid--;
                    return mid;
                }
            }
            return -(low + 1); // key not found.
        }

        /**
         * Read the next key/value pair in the map into <code>key</code> and
         * <code>val</code>. Returns true if such a pair exists and false when
         * at the end of the map
         */
        public synchronized boolean next(IWritableComparable key, IWritable val)
                throws IOException {
            if (atBeginOfData && !compressed) {
                data.nextKeyAndValue(key, val, lengths[currentIndex]);
                atBeginOfData = false;
                return true;
            } else {
                return data.next(key, val);
            }
        }

        /** Return the value for the named key, or null if none exists. */
        public synchronized IWritable get(IWritableComparable key, IWritable val)
                throws IOException {
            if (seek(key)) {
                next(getKey, val); // don't smash key
                return val;
            } else
                return null;
        }

        /** Close the map. */
        public synchronized void close() throws IOException {
            if (!indexClosed) {
                index.close();
            }
            data.close();
        }

        public long getPos() throws IOException {
            return data.getPos();
        }

        public long getSize() throws IOException {
            return data.getSize();
        }

        @Override
        public boolean next(Object key, Object value) throws IOException {
            return next((IWritableComparable) key, (IWritable) value);
        }
    }

}
