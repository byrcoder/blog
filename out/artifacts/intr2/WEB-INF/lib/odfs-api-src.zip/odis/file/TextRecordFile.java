package odis.file;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;

import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.lib.StringWritable;
import toolbox.collections.ArrayUtils;

/**
 * A simple text record file with each text line as a key/value pair. The text
 * encoding is always UTF-8.
 * 
 * @author zl
 */
public class TextRecordFile {

    public static class Writer<K, V> extends RecordFile.Writer<K, V> {

        private String separator;

        private String encoding;

        private OutputStreamWriter wout;

        public Writer(IFileSystem fs, File filename, String sp,
                boolean overwrite) throws IOException {
            this(fs, new Path(filename), sp, overwrite);
        }

        public Writer(IFileSystem fs, Path filename, String sp,
                boolean overwrite) throws IOException {
            super(fs, filename, overwrite);
            separator = sp;
            this.encoding = "utf-8";
            this.wout = new OutputStreamWriter(this.out, this.encoding);
        }

        public void write(K key, V value) throws IOException {
            this.wout.write(key.toString());
            this.wout.write(separator);
            this.wout.write(value.toString());
            this.wout.write("\n");
            this.wout.flush();
        }
    }

    public static class Reader extends
            RecordFile.Reader<StringWritable, StringWritable> {

        private static final byte LINE_BREAK_BYTE = '\n';

        private String separator;

        private long start, end;

        private byte[] lineBuffer;

        private int bufferSize;

        private String encoding;

        public Reader(IFileSystem fs, Path filename, String sp)
                throws IOException {
            this(fs, filename, sp, 0, fs.getLength(filename), 4096, null);
        }

        @Deprecated
        public Reader(IFileSystem nfs, File filename, String sp)
                throws IOException {
            this(nfs, new Path(filename), sp);
        }

        @Deprecated
        public Reader(IFileSystem nfs, File filename, String sp, int bufferSize)
                throws IOException {
            this(nfs, new Path(filename), sp, 0, bufferSize);
        }

        @Deprecated
        public Reader(IFileSystem nfs, File filename, String sp, long start,
                long length) throws IOException {
            this(nfs, filename, sp, start, length, 4096, null);
        }

        public Reader(IFileSystem fs, Path filename, String sp, long start,
                long length) throws IOException {
            this(fs, filename, sp, start, length, 4096, null);
        }

        @Deprecated
        public Reader(IFileSystem nfs, File filename, String sp, long start,
                long length, String encoding) throws IOException {
            this(nfs, filename, sp, start, length, 4096, encoding);
        }

        public Reader(IFileSystem fs, Path filename, String sp, long start,
                long length, String encoding) throws IOException {
            this(fs, filename, sp, start, length, 4096, encoding);
        }

        @Deprecated
        public Reader(IFileSystem nfs, File filename, String sp, long start,
                long length, int bufferSize, String encoding)
                throws IOException {
            this(nfs, new Path(filename), sp, start, length, bufferSize,
                    encoding);
        }

        public Reader(IFileSystem fs, Path filename, String sp, long start,
                long length, int bufferSize, String encoding)
                throws IOException {
            super(fs, filename, bufferSize);
            // set the boundary of reading: will read from after the first \n
            // since "start" and till the first \n since "end" (not included)
            this.start = start;
            this.end = start + length;
            this.separator = sp;
            this.bufferSize = bufferSize;
            this.lineBuffer = new byte[this.bufferSize];
            if (encoding != null)
                this.encoding = encoding;
            else
                this.encoding = "utf-8";
            if (this.start <= 0)
                return;
            // sync to the first \n after start
            in.seek(this.start - 1); // seek to the position before start
            byte prevByte = in.readByte();
            if (prevByte != LINE_BREAK_BYTE)
                readLine();
        }

        /** ugly implementation */
        private String readLine() throws IOException {
            int pos = 0;
            try {
                lineBuffer[pos] = in.readByte();
                while (lineBuffer[pos] != LINE_BREAK_BYTE) {
                    pos++;
                    if (pos >= lineBuffer.length)
                        lineBuffer = ArrayUtils.expand(lineBuffer,
                                lineBuffer.length + bufferSize);
                    lineBuffer[pos] = in.readByte();
                }
            } catch (EOFException e) {} // silent here: end of the file
            // FIXME zf: this is slow. Use CharsetDecoder instead.
            return new String(lineBuffer, 0, pos, encoding);
        }

        // no matter what, read key as a string
        public Class<StringWritable> getKeyClass() {
            return StringWritable.class;
        }

        // no matter what, read value as a string
        public Class<StringWritable> getValueClass() {
            return StringWritable.class;
        }

        public boolean next(StringWritable key, StringWritable value)
                throws IOException {
            if (in.getPos() >= end) {
                return false;
            }
            String line = readLine();
            if (line == null) {
                return false;
            }
            int sp = line.indexOf(separator);
            if (sp > 0 && sp + 1 < line.length()) {
                key.set(line.substring(0, sp));
                value.set(line.substring(sp + 1, line.length()));
            } else {
                key.set(line);
                value.set("\n");
            }
            return true;
        }

    }

}
