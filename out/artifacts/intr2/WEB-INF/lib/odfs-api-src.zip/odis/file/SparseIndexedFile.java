package odis.file;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;
import odis.serialize.lib.LongWritable;
import toolbox.misc.ClassUtils;

/**
 * Functionality similar to IndexedFile. Implementation uses two levels of
 * indirection to avoid reading all the keys into memory
 * 
 * @author jimmysu
 */
public class SparseIndexedFile {
    /** The names of the index file. */
    public static final String SPARSE_INDEX_FILE_NAME = "sparse_index";

    /** The name of the data file. */
    public static final String DATA_FILE_NAME = "data";

    /** The name of the metadata file. */
    public static final String METADATA_FILE_NAME = "metadata";

    /** Renames an existing map directory. */
    public static void rename(IFileSystem nfs, String oldName, String newName)
            throws IOException {
        Path oldDir = new Path(oldName);
        Path newDir = new Path(newName);
        if (!nfs.rename(oldDir, newDir)) {
            throw new IOException("Could not rename " + oldDir + " to "
                    + newDir);
        }
    }

    /** Deletes the named map file. */
    public static void delete(IFileSystem nfs, String name) throws IOException {
        Path dir = new Path(name);
        Path data = dir.cat(DATA_FILE_NAME);
        Path sparseIndex = dir.cat(SPARSE_INDEX_FILE_NAME);
        Path metaData = dir.cat(METADATA_FILE_NAME);

        nfs.delete(data);
        nfs.delete(sparseIndex);
        nfs.delete(metaData);
        nfs.delete(dir);
    }

    @Deprecated
    public static File getDataFile(File dir) {
        return new File(dir, DATA_FILE_NAME);
    }

    public static Path getDataPath(Path dir) {
        return dir.cat(DATA_FILE_NAME);
    }

    //return the sparse index here
    @Deprecated
    public static File getIndexFile(File dir) {
        return new File(dir, SPARSE_INDEX_FILE_NAME);
    }

    public static Path getIndexPath(Path dir) {
        return dir.cat(SPARSE_INDEX_FILE_NAME);
    }

    public static class Offset implements IWritable {
        static {
            WritableRegistry.registerSize(Offset.class, Long.SIZE / Byte.SIZE);
        }

        private long offset;

        public Offset() {}

        public void set(long offset) {
            this.offset = offset;
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(offset);
        }

        public void readFields(DataInput in) throws IOException {
            offset = in.readLong();
        }

        public IWritable copyFields(IWritable value) {
            // TODO Auto-generated method stub
            return null;
        }
    }

    public static class Writer implements IRecordWriter<Object, Object> {
        public static final String NAME_SKIP_SIZE = "skip";

        public static final int DEFAULT_SKIP_SIZE = 100;

        private SequenceFile.Writer data;

        private SequenceFile.Writer sparseIndex;

        private SequenceFile.Writer metaData;

        private int entryCount = 0;

        private long schemaID = -1;

        private int skipSize;

        private Offset offset = new Offset();

        @Deprecated
        public Writer(IFileSystem nfs, File dir, Class keyClass, Class valClass)
                throws IOException {
            this(nfs, dir, keyClass, valClass, DEFAULT_SKIP_SIZE, false);
        }

        public Writer(IFileSystem nfs, Path dir, Class keyClass, Class valClass)
                throws IOException {
            this(nfs, dir, keyClass, valClass, DEFAULT_SKIP_SIZE, false);
        }

        @Deprecated
        public Writer(IFileSystem nfs, File dir, Class keyClass,
                Class valClass, boolean overwrite) throws IOException {
            this(nfs, dir, keyClass, valClass, DEFAULT_SKIP_SIZE, overwrite);
        }

        public Writer(IFileSystem nfs, Path dir, Class keyClass,
                Class valClass, boolean overwrite) throws IOException {
            this(nfs, dir, keyClass, valClass, DEFAULT_SKIP_SIZE, overwrite);
        }

        @Deprecated
        public Writer(IFileSystem nfs, File dir, Class keyClass,
                Class valClass, int skipSize, boolean overwrite)
                throws IOException {
            this(nfs, new Path(dir), keyClass, valClass, skipSize, overwrite);
        }

        /** Create the named map for keys of the named class. */
        public Writer(IFileSystem nfs, Path dir, Class keyClass,
                Class valClass, int skipSize, boolean overwrite)
                throws IOException {

            if (nfs.exists(dir)) {
                if (nfs.listFiles(dir).length != 0) {
                    if (overwrite) {
                        nfs.delete(dir);
                        nfs.mkdirs(dir);
                    } else {
                        throw new IOException(
                                "already exists and is not empty: " + dir);
                    }
                }
            } else {
                nfs.mkdirs(dir);
            }

            Path dataFile = new Path(dir, DATA_FILE_NAME);
            Path sparseIndexFile = new Path(dir, SPARSE_INDEX_FILE_NAME);
            Path metaDataFile = new Path(dir, METADATA_FILE_NAME);

            this.data = new SequenceFile.Writer(nfs, dataFile, keyClass,
                    valClass);
            this.sparseIndex = new SequenceFile.Writer(nfs, sparseIndexFile,
                    keyClass, Offset.class);
            Properties indexMetaInfo = new Properties();
            indexMetaInfo.setProperty(NAME_SKIP_SIZE, String.valueOf(skipSize));
            this.metaData = new SequenceFile.Writer(nfs, metaDataFile,
                    LongWritable.class, LongWritable.class, indexMetaInfo);
            this.skipSize = skipSize;
            sparseIndex.disableSync();
        }

        public synchronized void setSchemaID(long schemaID) {
            this.schemaID = schemaID;
        }

        /** Close the index file. */
        public synchronized void close() throws IOException {
            data.close();
            sparseIndex.close();
            metaData.write(new LongWritable(entryCount), new LongWritable(
                    entryCount));
            metaData.write(new LongWritable(schemaID), new LongWritable(
                    schemaID));
            metaData.close();
        }

        /**
         * Append a key/value pair to the map. The key must be strictly greater
         * than the previous key added to the map.
         */
        public synchronized void write(IWritable key, IWritable val)
                throws IOException {

            data.write(key, val);

            //sparse index ratio is skipSize:1
            if (entryCount % skipSize == 0) {
                offset.set(data.getPos() - data.getLastEntryAndPrefixSize());
                sparseIndex.write(key, offset);
            }
            entryCount++;
        }

        public long getSize() throws IOException {
            return data.getSize();
        }

        @Override
        public void write(Object key, Object value) throws IOException {
            write((IWritable) key, (IWritable) value);
        }
    }

    public static class Reader implements IRecordReader<Object, Object> {
        private WritableComparator comparator;

        private long sparseIndexSize = 0;

        private IWritableComparable getKey; // buffer used during iteration

        // the data, on disk
        private SequenceFile.Reader data;

        private SequenceFile.Reader sparseIndex;

        private SequenceFile.Reader metaData;

        // whether the index Reader was closed
        private boolean indexClosed = false;

        // the sparse index, in memory
        private int count = -1;

        private IWritableComparable[] keys;

        private long[] positions;

        private int skipSize;

        private long schemaID;

        private long entryCount;

        /** Returns the class of keys in this file. */
        public Class<? extends IWritableComparable> getKeyClass() {
            return data.getKeyClass().asSubclass(IWritableComparable.class);
        }

        /** Returns the class of values in this file. */
        public Class<? extends IWritable> getValueClass() {
            return data.getValueClass();
        }

        @Deprecated
        public Reader(IFileSystem nfs, File dir) throws IOException {
            this(nfs, dir, null);
        }

        /** Construct a map reader for the named map. */
        public Reader(IFileSystem nfs, Path dir) throws IOException {
            this(nfs, dir, null);
        }

        @Deprecated
        public Reader(IFileSystem nfs, File dir, BinaryComparator bCmp)
                throws IOException {
            this(nfs, new Path(dir), bCmp);
        }

        /** Construct a map reader for the named map using the named comparator. */
        public Reader(IFileSystem nfs, Path dir, BinaryComparator bCmp)
                throws IOException {
            Path dataFile = dir.cat(DATA_FILE_NAME);
            Path sparseIndexFile = dir.cat(SPARSE_INDEX_FILE_NAME);
            Path metaDataFile = dir.cat(METADATA_FILE_NAME);
            // open the data
            this.data = new SequenceFile.Reader(nfs, dataFile);

            if (bCmp == null) {
                this.comparator = new WritableComparator(
                        data.getKeyClass().asSubclass(IWritableComparable.class));
            } else {
                this.comparator = new WritableComparator(
                        data.getKeyClass().asSubclass(IWritableComparable.class),
                        bCmp);
            } // else

            this.getKey = (IWritableComparable) ClassUtils.newInstance(this.comparator.getComparableClass());

            // open the index
            this.sparseIndex = new SequenceFile.Reader(nfs, sparseIndexFile);
            String temp = this.sparseIndex.getMetaInfo().getProperty(
                    Writer.NAME_SKIP_SIZE, "100");
            try {
                this.skipSize = Integer.parseInt(temp);
            } catch (Exception e) {
                throw new IOException(
                        "skip size setting in file header error : " + temp);
            }
            sparseIndexSize = nfs.getLength(sparseIndexFile);
            this.metaData = new SequenceFile.Reader(nfs, metaDataFile);
            LongWritable k = new LongWritable();
            LongWritable v = new LongWritable();
            metaData.next(k, v);
            entryCount = k.get();
            metaData.next(k, v);
            schemaID = k.get();
            metaData.close();
        }

        public long getEntryCount() {
            return entryCount;
        }

        public long getSchemaID() {
            return schemaID;
        }

        private void readIndex() throws IOException {
            // read the sparse index entirely into memory
            if (this.keys != null)
                return;

            this.count = 0;

            int fixedKeyLength = sparseIndex.getFixedKeyLength();

            //FIXME: this count could be larger or smaller than the actural entry count
            int guessEntryCount = (int) (sparseIndexSize / (fixedKeyLength > 0 ? (fixedKeyLength + WritableRegistry.getWritableSize(Offset.class))
                    : (WritableRegistry.getWritableSize(Offset.class) + 4)));

            this.keys = new IWritableComparable[guessEntryCount];
            this.positions = new long[guessEntryCount];

            try {
                Offset offset = new Offset();
                while (true) {
                    IWritableComparable k = (IWritableComparable) comparator.getComparableClass().newInstance();

                    if (!sparseIndex.next(k, offset))
                        break;

                    if (count == keys.length) { // time to grow arrays
                        int newLength = (keys.length * 3) / 2;
                        IWritableComparable[] newKeys = new IWritableComparable[newLength];
                        long[] newPositions = new long[newLength];
                        System.arraycopy(keys, 0, newKeys, 0, count);
                        System.arraycopy(positions, 0, newPositions, 0, count);
                        keys = newKeys;
                        positions = newPositions;
                    }

                    keys[count] = k;
                    positions[count] = offset.offset;
                    count++;
                }
            } catch (EOFException e) {
                SequenceFile.LOG.warning("Unexpected EOF reading "
                        + sparseIndex + " at entry #" + count + ".  Ignoring.");
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                indexClosed = true;
                sparseIndex.close();
            }
        }

        //assumes index is not out of bounds.  this should be checked at the caller of this method
        private void at(int index) throws IOException {
            int sparseIndexNum = index / skipSize;
            long dataPosition = positions[sparseIndexNum];
            int curIndex = sparseIndexNum * skipSize;
            data.seek(dataPosition);

            IWritableComparable key = ClassUtils.newInstance(comparator.getComparableClass().asSubclass(
                    IWritableComparable.class));
            IWritable val = ClassUtils.newInstance(data.getValueClass());

            //scan forward for the right index in denseIndex
            if (index % skipSize != 0) {
                data.next(key, val);
                curIndex++;
                while (curIndex != index) {
                    data.next(key, val);
                    curIndex++;
                }
            }
        }

        public synchronized boolean first() throws IOException {
            if (this.keys == null) {
                readIndex();
            }

            if (count > 0) {
                at(0);
                return true;
            } else {
                return false;
            }
        }

        public synchronized boolean last() throws IOException {
            if (this.keys == null) {
                readIndex();
            }

            if (count > 0) {
                long lastEntryPosition = positions[count - 1];
                data.seek(lastEntryPosition);
                long curIndex = (count - 1) * skipSize;

                IWritableComparable key = (IWritableComparable) ClassUtils.newInstance(comparator.getComparableClass());
                IWritable val = ClassUtils.newInstance(data.getValueClass());

                while (curIndex != entryCount - 1) {
                    data.next(key, val);
                    curIndex++;
                }
                return true;
            } else {
                return false;
            }
        }

        public synchronized boolean seek(IWritableComparable key)
                throws IOException {
            IWritable val = ClassUtils.newInstance(data.getValueClass());
            return seek(key, val);
        }

        /**
         * Positions the reader at the named key, or if none such exists, at the
         * first entry after the named key. Returns true iff the named key
         * exists in this map.
         */
        protected boolean seek(IWritableComparable key, IWritable value)
                throws IOException {
            if (this.keys == null) {
                readIndex();
            }

            IWritableComparable lastVal = keys[count - 1];
            int cmp = comparator.compare(lastVal, key);
            int startIndex;

            if (cmp < 0) {
                //for this case, the target key is greater than the last sparseIndex key, so we scan forward from the last sparseIndex key
                startIndex = count - 1;
            } else {
                int index = binarySearch(key);

                if (index < 0) {
                    index = index * (-1) - 1;
                    index--;
                }

                startIndex = index;
            }

            //scan forward from startIndex in data
            long dataPosition = positions[startIndex];
            data.seek(dataPosition);

            boolean found = false;

            //scan forward for the right position in data
            boolean notEndOfFile = true;
            data.next(getKey, value);
            while (true) {
                cmp = comparator.compare(getKey, key);

                if (cmp == 0) {
                    found = true;
                    break;
                } else if (cmp > 0) {
                    break;
                }
                dataPosition = data.getPos();
                notEndOfFile = data.next(getKey, value);
                if (notEndOfFile == false) {
                    break;
                }
            }

            if (notEndOfFile) {
                data.seek(dataPosition);
            }
            return found;
        }

        private int binarySearch(IWritableComparable key) {
            int low = 0;
            int high = count - 1;

            while (low <= high) {
                int mid = (low + high) >>> 1;
                IWritableComparable midVal = keys[mid];
                int cmp = comparator.compare(midVal, key);

                if (cmp < 0) {
                    low = mid + 1;
                } else if (cmp > 0) {
                    high = mid - 1;
                } else {
                    return mid; // key found
                }
            }
            return -(low + 1); // key not found.
        }

        /**
         * Read the next key/value pair in the map into <code>key</code> and
         * <code>val</code>. Returns true if such a pair exists and false when
         * at the end of the map
         */
        public synchronized boolean next(IWritableComparable key, IWritable val)
                throws IOException {
            return data.next(key, val);
        }

        /** Return the value for the named key, or null if none exists. */
        public synchronized IWritable get(IWritableComparable key, IWritable val)
                throws IOException {
            if (seek(key, val)) {
                return val;
            } else {
                return null;
            }
        }

        /** Close the map. */
        @Override
        public synchronized void close() throws IOException {
            if (!indexClosed) {
                sparseIndex.close();
            }
            data.close();
        }

        @Override
        public long getPos() throws IOException {
            return data.getPos();
        }

        @Override
        public long getSize() throws IOException {
            return data.getSize();
        }

        @Override
        public boolean next(Object key, Object value) throws IOException {
            return next((IWritableComparable) key, (IWritable) value);
        }
    }
}
