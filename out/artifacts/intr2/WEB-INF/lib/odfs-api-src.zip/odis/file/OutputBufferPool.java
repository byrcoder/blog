/**
 * @(#)OutputBufferPool.java, 2011-7-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.file;

import odis.io.DataOutputBuffer;

/**
 *
 * @author zhangduo
 *
 */
public interface OutputBufferPool {
    DataOutputBuffer allocate();
    
    void release(DataOutputBuffer buffer);
}
