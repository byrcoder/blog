/**
 * @(#)DefaultOutputBufferPool.java, 2011-7-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.file;

import java.util.ArrayDeque;

import odis.io.DataOutputBuffer;

/**
 * @author zhangduo
 */
public class DefaultOutputBufferPool implements OutputBufferPool {

    private final long maxTotalSize;

    private final long maxBufferSize;

    private long currentSize;

    private ArrayDeque<DataOutputBuffer> pool = new ArrayDeque<DataOutputBuffer>();

    /**
     * @param maxTotalSize
     *            the max total size of all buffers
     * @param maxBufferSize
     *            the max size per buffer
     */
    public DefaultOutputBufferPool(long maxTotalSize, long maxBufferSize) {
        this.maxTotalSize = maxTotalSize;
        this.maxBufferSize = maxBufferSize;
    }

    @Override
    public synchronized DataOutputBuffer allocate() {
        DataOutputBuffer buffer = pool.poll();
        if (buffer == null) {
            return new DataOutputBuffer();
        }
        currentSize -= buffer.getData().length;
        return buffer;
    }

    @Override
    public synchronized void release(DataOutputBuffer buffer) {
        if (buffer.getData().length <= maxBufferSize
                && currentSize + buffer.getData().length <= maxTotalSize) {
            pool.add(buffer);
            buffer.reset();
            currentSize += buffer.getData().length;
        }
    }

    public synchronized long getCurrentPoolSize() {
        return currentSize;
    }

    public synchronized void clear() {
        pool.clear();
    }

}
