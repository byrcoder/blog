/**
 * @(#)ByteArrayBufferPoolHolder.java, 2011-7-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.file;

import odis.util.BoundedByteArrayBufferPool;
import odis.util.ByteArrayBufferPool;
import toolbox.misc.UnitUtils;

/**
 * @author zhangduo
 */
final class ByteArrayBufferPoolHolder {
    static ByteArrayBufferPool DEFAULT_POOL = new BoundedByteArrayBufferPool(
            64 * UnitUtils.M);
}
