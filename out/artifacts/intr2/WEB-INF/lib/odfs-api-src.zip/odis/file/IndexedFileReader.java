package odis.file;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import odis.file.IndexedFile.OffsetAndLength;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;
import toolbox.collections.ArrayUtils;
import toolbox.misc.ClassUtils;

/**
 * Concurrent reader implementation for indexed file. Several cursor could be
 * opened on single index file reader, which share the same index in memory.
 * 
 * @author river
 */
public class IndexedFileReader {
    private WritableComparator comparator;

    private IFileSystem fs;

    private Path file;

    private Path dataFile;

    private Path indexFile;

    private Class<? extends IWritableComparable> keyClass;

    private Class<? extends IWritable> valClass;

    private int count = -1;

    private IWritableComparable[] keys;

    private long[] positions;

    private int[] lengths;

    private LinkedList<Cursor> freeCursors = new LinkedList<Cursor>();

    private LinkedList<Cursor> activeCursors = new LinkedList<Cursor>();

    private int maxCursorCount = 0;

    private boolean closed = false;

    private boolean compressed = false;

    /**
     * Use the version using Path instead
     */
    @Deprecated
    public IndexedFileReader(FileSystem fs, File file) throws IOException {
        this(fs, new Path(file), null, 0);
    }

    public IndexedFileReader(FileSystem fs, Path file) throws IOException {
        this(fs, file, null, 0);
    }

    public IndexedFileReader(FileSystem fs, Path file, BinaryComparator comp,
            int maxCursorCount) throws IOException {
        this.fs = fs;
        this.file = file;
        this.maxCursorCount = maxCursorCount;

        dataFile = file.cat(IndexedFile.DATA_FILE_NAME);
        Path compressedFile = file.cat(IndexedFile.COMPRESSED_DATA_FILE_NAME);
        indexFile = file.cat(IndexedFile.INDEX_FILE_NAME);

        if (!fs.exists(dataFile) && fs.exists(compressedFile)) {
            dataFile = compressedFile;
            compressed = true;
        }
        SequenceFile.Reader dataFileReader = new SequenceFile.Reader(fs,
                dataFile);
        try {
            keyClass = dataFileReader.getKeyClass().asSubclass(
                    IWritableComparable.class);
            valClass = dataFileReader.getValueClass();
        } finally {
            dataFileReader.close();
        }

        if (comp == null) {
            this.comparator = new WritableComparator(
                    (Class<? extends IWritableComparable>) keyClass);
        } else {
            this.comparator = new WritableComparator(
                    (Class<? extends IWritableComparable>) keyClass, comp);
        } // else

        loadIndex();
    }

    /**
     * Use the version using Path instead.
     */
    @Deprecated
    public IndexedFileReader(FileSystem fs, File file, BinaryComparator comp,
            int maxCursorCount) throws IOException {
        this(fs, new Path(file), comp, maxCursorCount);
    }

    private void loadIndex() throws IOException {
        this.count = 0;
        SequenceFile.Reader indexReader = new SequenceFile.Reader(fs, indexFile);

        try {
            if (indexReader.getKeyClass() != keyClass) {
                throw new IOException("bad index file key class "
                        + indexReader.getKeyClass());
            }

            int fixedKeyLength = indexReader.getFixedKeyLength();

            long indexSize = fs.getLength(indexFile);

            int guessEntryCount = (int) (indexSize / (fixedKeyLength > 0 ? (fixedKeyLength + WritableRegistry.getWritableSize(OffsetAndLength.class))
                    : (WritableRegistry.getWritableSize(OffsetAndLength.class) + 4)));

            this.keys = new IWritableComparable[guessEntryCount];
            this.positions = new long[guessEntryCount];
            this.lengths = new int[guessEntryCount];

            OffsetAndLength offsetAndLength = new OffsetAndLength();
            while (true) {
                IWritableComparable k = (IWritableComparable) ClassUtils.newInstance(comparator.getComparableClass());

                if (!indexReader.next(k, offsetAndLength)) {
                    break;
                }

                if (count == keys.length) { // time to grow arrays
                    int newLength = (keys.length * 3) / 2;
                    keys = (IWritableComparable[]) ArrayUtils.expand(keys,
                            IWritableComparable.class, newLength);
                    positions = ArrayUtils.expand(positions, newLength);
                    lengths = ArrayUtils.expand(lengths, newLength);
                }

                keys[count] = k;
                positions[count] = offsetAndLength.getOffset();
                lengths[count] = offsetAndLength.getLength();
                count++;
            }

        } catch (EOFException e) {
            SequenceFile.LOG.warning("Unexpected EOF reading " + indexReader
                    + " at entry #" + count + ".  Ignoring.");
        } finally {
            indexReader.close();
        }

    }

    public Class<? extends IWritableComparable> getKeyClass() {
        return keyClass;
    }

    public Class<? extends IWritable> getValueClass() {
        return valClass;
    }

    /**
     * Open a cursor for read, the cursor must be released by calling
     * {@link #closeCursor(Cursor)} or Cursor.close(). The cursor in internally
     * reused, and all the cursor is acturally closed when {@link #close()}
     * called.
     * 
     * @return cursor
     * @throws IOException
     */
    public synchronized Cursor openCursor() throws IOException {
        while (!closed) {
            if (!freeCursors.isEmpty()) {
                Cursor cursor = freeCursors.removeFirst();
                cursor.active = true;
                activeCursors.addFirst(cursor);
                return cursor;
            }

            if (maxCursorCount <= 0
                    || freeCursors.size() + activeCursors.size() < maxCursorCount) {
                Cursor cursor = new Cursor();
                cursor.active = true;
                activeCursors.addFirst(cursor);
                return cursor;
            }

            try {
                wait(10000);
            } catch (InterruptedException e) {}
        }

        throw new IOException("cannot get cursor because the indexed file "
                + file + " is closed");
    }

    public synchronized void closeCursor(Cursor cursor) {
        activeCursors.remove(cursor);
        cursor.active = false;
        freeCursors.addFirst(cursor);
        notify();
    }

    public synchronized void close() {
        for (Cursor cursor: activeCursors) {
            try {
                cursor.internalClose();
            } catch (IOException e) {}
        }

        for (Cursor cursor: freeCursors) {
            try {
                cursor.internalClose();
            } catch (IOException e) {}
        }

        activeCursors.clear();
        freeCursors.clear();

        closed = true;
    }

    public class Cursor {

        private SequenceFile.Reader data;

        private IWritableComparable tmpKey;

        private int currentIndex = 0;

        private boolean atBeginOfData = false;

        private boolean active = false;

        private Cursor() throws IOException {
            data = new SequenceFile.Reader(fs, dataFile);
            tmpKey = ClassUtils.newInstance(getKeyClass());
        }

        private void at(int index) throws IOException {
            currentIndex = index;
            data.seek(positions[currentIndex]);
            if (compressed)
                data.skip(lengths[currentIndex]);
            else
                atBeginOfData = true;
        }

        private int binarySearch(IWritableComparable key) {
            int low = 0;
            int high = count - 1;

            while (low <= high) {
                int mid = (low + high) >>> 1;
                IWritableComparable midVal = keys[mid];
                int cmp = comparator.compare(midVal, key);

                if (cmp < 0) {
                    low = mid + 1;
                } else if (cmp > 0) {
                    high = mid - 1;
                } else {
                    return mid; // key found
                }
            }
            return -(low + 1); // key not found.
        }

        public synchronized boolean seek(IWritableComparable key)
                throws IOException {
            assert keys != null;

            if (!active) {
                throw new IOException("cursor is closed");
            }

            int index = binarySearch(key);

            boolean found = index >= 0;

            if (!found) {
                index = index * (-1) - 1;
            }

            if (index < count) {
                at(index);
            }

            return found;
        }

        public synchronized boolean next(IWritableComparable key,
                IWritable value) throws IOException {
            assert keys != null;

            if (!active) {
                throw new IOException("cursor is closed");
            }

            if (atBeginOfData && !compressed) {
                data.nextKeyAndValue(key, value, lengths[currentIndex]);
                atBeginOfData = false;
                return true;
            } else {
                return data.next(key, value);
            }

        }

        public synchronized boolean get(IWritableComparable key, IWritable value)
                throws IOException {
            assert keys != null;
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return seek(key) && next(tmpKey, value);
        }

        public synchronized boolean get(IWritableComparable key,
                IWritableComparable storedKey, IWritable value)
                throws IOException {
            assert keys != null;
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return seek(key) && next(storedKey, value);
        }

        public long getPos() throws IOException {
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return data.getPos();
        }

        public void close() {
            if (!active)
                return;
            closeCursor(this);
        }

        private void internalClose() throws IOException {
            data.close();
        }

    }
}
