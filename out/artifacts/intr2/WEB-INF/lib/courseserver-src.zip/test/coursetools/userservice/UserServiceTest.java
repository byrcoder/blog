package coursetools.userservice;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.Config;
import coursetools.communit.helper.PurchaseRecord;
import coursetools.communit.server.processors.AddPurchasedInfoProcessor;
import coursetools.database.StorageService;
import coursetools.database.bean.UserPurchaseEntity;
import org.apache.commons.configuration.Configuration;

import java.io.*;
import java.util.*;

/**
 * test case or main for UserService
 * User: zhaowei
 * Date: 14-11-24
 * Time: 上午9:45
 */
public class UserServiceTest {


    public static void main(String[] args) throws Exception {
//        testGetPurchasedUsers();
//        testGetPurchasedUserNum();
//        Configuration conf = coursetools.common.CourseContext.getConfig();
//        Config.init(conf);
//
//
////        UserService.getInstance().addPurchaseRecords("zhaoweideyouxian@163.com", purchaseRecord);

        String inputDir = "/disk1/zhaowei/gitlab/couseuserserver/delete.txt";
        String line = "";
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputDir), "utf-8"));
        int i = 0;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
            if (line.indexOf("\\\"itemId\\\":\\\"721\\\"") != -1 && line.indexOf("\"command\":\"addPurchase\"") != -1) {
                JSONObject json = JSON.parseObject(line);
                String para = json.getString("parameters");
                System.out.println("para:" + para);
                JSONObject paraObj = JSON.parseObject(para);

                String purchaseStr = paraObj.getString("purchase");
                JSONObject purchaseObj = JSON.parseObject(purchaseStr);

                System.out.println("value:" + purchaseObj);

                String itemId = purchaseObj.getString("itemId");
                if (itemId.equals("721")) {
                    String time = purchaseObj.getString("time");
                    String userId = purchaseObj.getString("userId");
                    PurchaseRecord purchaseRecord = new PurchaseRecord();
                    purchaseRecord.itemId = itemId;
                    purchaseRecord.userId = userId;
                    purchaseRecord.time = time;
                    System.out.println(JSON.toJSONString(purchaseRecord));
                    UserService.getInstance().addPurchaseRecords(userId, purchaseRecord);
                    i++;
                }
            }
        }
        System.out.println("加入了" + i) ;
    }

    public static void testGetPurchasedUsers() {
//        System.out.println(UserService.getInstance().getPurchasedUsers("721"));

    }

    public static void testGetPurchasedUserNum() {
        Configuration conf = coursetools.common.CourseContext.getConfig();
        Config.init(conf);
        List<UserPurchaseEntity> allUserList = StorageService.getInstance().getAllUserPurchase();
        List<UserPurchaseEntity> userListFor710 = new ArrayList<UserPurchaseEntity>();
        for (UserPurchaseEntity userPurchaseEntity : allUserList) {
            String records = userPurchaseEntity.getPurchases();
            if (records.indexOf("\"itemId\\\":\\\"721\\\"") != -1) {
                userListFor710.add(userPurchaseEntity);
                System.out.println(records);
            }
        }

        System.out.println("新报名了710课的人数:" + userListFor710.size());
    }

    public static void test() throws Exception {
        String line = "";
        Map<String, String> cet4 = new HashMap<String, String>();
        Map<String, String> cet6 = new HashMap<String, String>();

        String cet4File = "/disk1/zhaowei/gitlab/couseuserserver/cet4.txt";
        String cet6File = "/disk1/zhaowei/gitlab/couseuserserver/cet6.txt";

        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(cet4File), "utf-8"));
        int i = 0;
        List<String> cet4list = new LinkedList<String>();
        List<String> cet6list = new LinkedList<String>();
        while ((line = br.readLine()) != null) {
            cet4list.add(line);
        }
        br.close();
        br = new BufferedReader(new InputStreamReader(new FileInputStream(cet6File), "utf-8"));
        while ((line = br.readLine()) != null) {
            cet6list.add(line);
        }
        System.out.print("四级数目:" + cet4list.size());
        System.out.print("六级数目:" + cet6list.size());

        br = new BufferedReader(new InputStreamReader(new FileInputStream("sendRecord_1.txt"), "utf-8"));
        Map<String, String> oldUsers = new HashMap<String, String>();
        while ((line = br.readLine()) != null) {
            String[] a = line.split("@");
            if (a.length == 3) {
                String userId = a[0];
                oldUsers.put(userId, "");
            } else if (a.length == 4) {
                String userId = a[0] + "@" + a[1];
                oldUsers.put(userId, "");
            }
        }


        Configuration conf = coursetools.common.CourseContext.getConfig();
        Config.init(conf);
        List<UserPurchaseEntity> allUserList = StorageService.getInstance().getAllUserPurchase();
        List<UserPurchaseEntity> userListFor710 = new ArrayList<UserPurchaseEntity>();
        for (UserPurchaseEntity userPurchaseEntity : allUserList) {
            String records = userPurchaseEntity.getPurchases();
            if (records.indexOf("\"itemId\\\":\\\"710\\\"") != -1 || records.indexOf("\"itemId\\\":\\\"709\\\"") != -1) {
                if (!oldUsers.containsKey(userPurchaseEntity.getUserId())) {
                    userListFor710.add(userPurchaseEntity);
                    System.out.println(records);
                }
            }
        }


        System.out.println("新报名了710课的人数:" + userListFor710.size());
        UserService.getInstance().cleanUserServerCache("a");
//        if (true) return;

        String title = "“四/六级冲刺课”专属优惠码到账了！";
        String content1 = "恭喜你获赠6个“四/六级冲刺课”专属优惠码!" +
                "<BR>“<a href = \"http://xue.youdao.com/course/detail/705\">四级冲刺课</a>”优惠码为:";
        String content2 = "<BR>“<a href = \"http://xue.youdao.com/course/detail/704\">六级冲刺课</a>”优惠码为:";
        String content3 = "<BR>在购买“四/六级冲刺课”时，单个优惠码可抵扣30元。<BR><BR>注意：<BR>1.优惠码可供本人使用，也可转赠他人；<BR>\n" +
                "2.优惠码只针对“四/六级冲刺课”，购买其他课程时无效；<BR>\n" +
                "3.四级优惠码只能用于四级冲刺课，六级优惠码只能用于六级冲刺课；<BR>\n" +
                "4.一个账号只能使用一个优惠码，而不能累计使用多个不同的优惠码；<BR>\n" +
                "5.一个优惠码只能使用一次，使用后即作废；点击\"去支付\"按钮表示使用一次，后续支付中断则此优惠码也无法继续使用<BR>\n" +
                "6.优惠码的有效期至12月15日24:00，过期作废。<BR><BR>有道学堂拥有最终解释权。<BR>客服电话：4008671360<BR>客服QQ：800018489";


        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("/disk1/zhaowei/gitlab/couseuserserver/sendRecord.txt"), "utf-8"));
        for (UserPurchaseEntity userPurchaseEntity : userListFor710) {
            Thread.sleep(20);
//            if (userPurchaseEntity.getUserId().equals("zhaoweideyouxian@163.com") || userPurchaseEntity.getUserId().equals("sina1899971111")) {
            StringBuilder sbCet4 = new StringBuilder();
            StringBuilder sbCet4ForRecord = new StringBuilder();

            String item = cet4list.get(0);
            sbCet4ForRecord.append(item).append(",");
            sbCet4.append("<font color = \"#1cb061\">").append(item).append("</font>、");
            cet4list.remove(0);

            item = cet4list.get(0);
            sbCet4ForRecord.append(item).append(",");
            sbCet4.append("<font color = \"#1cb061\">").append(item).append("</font>、");
            cet4list.remove(0);

            item = cet4list.get(0);
            sbCet4ForRecord.append(item);
            sbCet4.append("<font color = \"#1cb061\">").append(item).append("</font>");
            cet4list.remove(0);

            StringBuilder sbCet6 = new StringBuilder();
            StringBuilder sbCet6ForRecord = new StringBuilder();

            item = cet6list.get(0);
            sbCet6ForRecord.append(item).append(",");
            sbCet6.append("<font color = \"#1cb061\">").append(item).append("</font>、");
            cet6list.remove(0);

            item = cet6list.get(0);
            sbCet6ForRecord.append(item).append(",");
            sbCet6.append("<font color = \"#1cb061\">").append(item).append("</font>、");
            cet6list.remove(0);

            item = cet6list.get(0);
            sbCet6ForRecord.append(item);
            sbCet6.append("<font color = \"#1cb061\">").append(item).append("</font>");
            cet6list.remove(0);

            StringBuilder allSb = new StringBuilder();
            allSb.append(content1).append(sbCet4.toString()).append(content2).append(sbCet6.toString()).append(content3);
            System.out.println(userPurchaseEntity.getUserId());
            UserService.getInstance().addNormalMessage(userPurchaseEntity.getUserId(), "“四/六级冲刺课”专属优惠码到账了！”", "", allSb.toString(), "", "有道学堂", "");
            bufferedWriter.write(userPurchaseEntity.getUserId() + "@" + sbCet4ForRecord.toString() + "@" + sbCet6ForRecord.toString() + "\n");
            bufferedWriter.flush();
//            }
        }

        bufferedWriter.flush();
        bufferedWriter.close();
        UserService.getInstance().cleanUserServerCache("zhaoweideyouxian@163.com");
        System.out.println("执行完毕");
    }
}
