package coursetools.userservice;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by zhaowei on 2014/11/19.
 */
public class TestUserService {
    private static Set<String> userIdSet = new HashSet<String>();

    public TestUserService() throws IOException {
        loadUserId();
    }

    /**
     * 加载用户的id信息，用于打压
     */
    public static void loadUserId() throws IOException {
        String inputDir = "F:\\youdaoDict\\workspace\\couseuserserver\\data\\stressTestUserId.txt";
//        String inputDir = "/disk1/zhaowei/gitl/ab/couseuserserver/data/stressTestUserId.txt";
        String line = "";
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputDir), "utf-8"));
        while ((line = br.readLine()) != null) {
            userIdSet.add(line);
        }
        System.out.println("load users' id num is:" + userIdSet.size());
    }
    public static class ClientThread extends Thread {
        @Override
        public void run() {
            long begin = System.currentTimeMillis();
            int i = 0;
            for (String userId: userIdSet) {
                i++;
                if (i > 1000) {
                    break;
                }

                if (UserService.getInstance().getPurchaseRecords(userId).size() == 0) {
                    System.out.println("error");
                }
            }
            long end = System.currentTimeMillis();
            System.out.println("时间" + (end - begin));
        }
    }

    public static void main(String[] args) throws IOException {
        TestUserService test = new TestUserService();
        for (int i = 0 ; i < 20; i++) {
            ClientThread thread = new ClientThread();
            thread.start();
        }
    }
}
