package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSONObject;
import coursetools.communit.helper.CommuniConstants;
import coursetools.communit.helper.PurchaseRecord;
import coursetools.userservice.UserService;

/**
 * CleanCacheProcessorTest.java
 * <p/>
 * Copyright 2014 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 * <p/>
 * User: zhaowei
 * Date: 14-10-19
 */
public class CleanCacheProcessorTest {


    public static void main(String[] args) {
        System.out.println(UserService.getInstance().cleanUserServerCache(""));
    }
}
