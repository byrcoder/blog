package coursetools.userservice;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.Config;
import coursetools.communit.helper.PurchaseRecord;
import coursetools.communit.helper.UserProfileUtils;
import coursetools.database.StorageService;
import coursetools.database.bean.UserPurchaseEntity;
import org.apache.commons.configuration.Configuration;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import java.util.*;

/**
 * Created by Administrator on 2014/12/6.
 */
public class DeleteRecord {
    private static final String ERROR = "error";
    private static final String PURCHASE_RECORDS_DETAIL = "coursePurchaseRecordsDetail";

    private static String getDataFromProfileServerWithoutEncode(String url, String userid, String key, String value) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        HttpPost post = new HttpPost (url);
        try {
            List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            nvps.add(new BasicNameValuePair("userid", userid));
            nvps.add(new BasicNameValuePair("key", key));

            nvps.add(new BasicNameValuePair("value", value));
            post.setEntity(new UrlEncodedFormEntity(nvps));

            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
                String strResult = EntityUtils.toString(response.getEntity());
                JSONObject result = JSONObject.parseObject(strResult);
                if (result == null) {
                    return null;
                }

                Integer error = result.getInteger(ERROR);
                if (error == null) {
                    error = 1;
                }
                if (error == 0) {
                    return strResult;
                } else {
                    return null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return null;
    }
    public static void main(String[]args) {
        Configuration conf = coursetools.common.CourseContext.getConfig();
        Config.init(conf);
        String[] userIds = {"qq5296B57588D17ED5B7C62E290A8EFEC4"

        };
        String itemIdForDel = "622";

        List<UserPurchaseEntity> userPurchases = StorageService.getInstance().getAllUserPurchase();
        Map<String, UserPurchaseEntity> map = new HashMap<String, UserPurchaseEntity>();
        for (UserPurchaseEntity userPurchaseEntity: userPurchases) {
            map.put(userPurchaseEntity.getUserId(), userPurchaseEntity);
        }
        for (String userId: userIds) {
            try{
                deleteFromMysql(map, userId, itemIdForDel);
                System.out.println("删除" + userId + "的" + itemIdForDel + "数据成功");
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("删除" + userId + "的数据失败");
            }
            deleteFromCassandra(userId, itemIdForDel);
        }
//        System.out.println(UserProfileUtils.getInstance().getPurchaseRecords("qq52B4530EECA6EA8C70453277A52CCCA5"));
//
//        getDataFromProfileServerWithoutEncode("http://xue.youdao.com/profile/set/remove", "qq52B4530EECA6EA8C70453277A52CCCA5",
//                PURCHASE_RECORDS_DETAIL, "%7B%22itemId%22%3A%22704%22%2C%22time%22%3A%221417688577961%22%2C%22userId%22%3A%22qq52B4530EECA6EA8C70453277A52CCCA5%22%7D");
//////////        getDataFromProfileServerWithoutEncode("http://xue.youdao.com/profile/set/remove", "qq16C9CB3825CE4BAEFD74CE24FB847180",
//////////                PURCHASE_RECORDS_DETAIL, "%7B%27userId%27%3A%27qq16C9CB3825CE4BAEFD74CE24FB847180%27%2C%27itemId%27%3A%27704%27%2C%27time%27%3A%271416741788215%27%7D");
//        System.out.println(UserProfileUtils.getInstance().getPurchaseRecords("qq52B4530EECA6EA8C70453277A52CCCA5"));
    }

    private static boolean deleteFromCassandra(String userId, String itemIdForDel) {
        List<String> records = UserProfileUtils.getInstance().getPurchaseRecordsWithString(userId);
        for (String record: records) {
            if (record.indexOf("itemId%27%3A%27" + itemIdForDel + "%27%2C") != -1) {
                try {
                    getDataFromProfileServerWithoutEncode("http://xue.youdao.com/profile/set/remove", userId,
                PURCHASE_RECORDS_DETAIL, record);
                    System.out.println("删除" + JSON.toJSONString(record) + "成功");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }

    private static boolean deleteFromMysql(Map<String, UserPurchaseEntity> map, String userId, String itemIdForDel) {
        UserPurchaseEntity userPurchaseEntity = map.get(userId);
        String list = userPurchaseEntity.getPurchases();
        JSONArray jsonArray = JSON.parseArray(list);
        JSONArray newJsonArray = new JSONArray();
        for (int i = 0 ; i < jsonArray.size();i++) {
            String one = jsonArray.getString(i);
            JSONObject object = JSON.parseObject(one);
            String itemId = object.getString("itemId");
            if (!itemId.equals(itemIdForDel)) {
                newJsonArray.add(one);
            }
        }
        userPurchaseEntity.setPurchases(JSON.toJSONString(newJsonArray));
        StorageService.getInstance().save(userPurchaseEntity);
        return true;
    }
}
