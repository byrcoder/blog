package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSONObject;

/**
 * test case or main for IsContainPurchasedInfoProcessor
 * User: zhaowei
 * Date: 14-11-24
 * Time: 上午9:45
 */
public class IsContainPurchasedInfoProcessorTest {

    public static void main(String[] args) {
        IsContainPurchasedInfoProcessor isContainPurchasedInfoProcessor = new IsContainPurchasedInfoProcessor();
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.isContain;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, "ljg-578@163.com");
        para.put(coursetools.communit.helper.CommuniConstants.itemId, "705");
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        System.out.println(isContainPurchasedInfoProcessor.handle(requestBean));

    }
}
