package coursetools.userservice;

import coursetools.database.StorageService;
import coursetools.database.bean.UserPurchaseEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2014/12/8.
 */
public class NoDoubleUidTest {

    public static void main(String[] args) {
        StorageService storageService = StorageService.getInstance();
        System.out.println(createUID("henry101010@qq.com",704));
        List<UserPurchaseEntity> list = storageService.getAllUserPurchase();
        Map<Integer, String> hashMap = new HashMap<Integer, String>();
        for(UserPurchaseEntity userPurchaseEntity:list) {
            Integer uid = createUID(userPurchaseEntity.getUserId(), 704);
            System.out.println(userPurchaseEntity.getUserId() + ":" + uid);
            if (hashMap.containsKey(uid)) {
                System.out.println("重复1:" + hashMap.get(uid) + "|uid=" + uid);
                System.out.println("重复2:" + userPurchaseEntity.getUserId());
            } else {
                hashMap.put(uid, userPurchaseEntity.getUserId());
            }
        }
    }

    public static int createUID(String username, Integer courseId) {
        // 唯一性ID
        String name = String.format("%s%s", username, courseId);
        int uid = name.hashCode();
        uid = uid < 0 ? -uid : uid;
        int len = 9 - sizeOfInt(uid);
        if (len > 0) {
            for (int i = 0; i < len; i++) {
                uid *= 10;
            }
        }
        return uid;
    }

    public static final int[] sizeTable = {
            9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, Integer.MAX_VALUE
    };

    public static int sizeOfInt(int x) {
        for (int i = 0; ; i++) {
            if (x <= sizeTable[i]) {
                return i + 1;
            }
        }
    }
}
