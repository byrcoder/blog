package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.Config;
import coursetools.communit.helper.CommuniConstants;
import coursetools.communit.helper.PurchaseRecord;
import coursetools.database.StorageService;
import coursetools.database.bean.CourseStatisticEntity;
import coursetools.database.bean.UserPurchaseEntity;
import coursetools.userservice.UserService;
import org.apache.commons.configuration.Configuration;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * test case or main for AddPurchasedInfoProcessor
 * User: zhaowei
 * Date: 14-11-24
 * Time: 上午9:45
 */
public class AddPurchasedInfoProcessorTest {

    private static boolean isContainItem(String itemId, UserPurchaseEntity userPurchaseEntity) {
        String records = userPurchaseEntity.getPurchases();
        String index = "\"" + itemId + "\\";
        return (records.indexOf(index) != -1);
    }


    public static void main(String [] args) throws Exception {
        Configuration conf = coursetools.common.CourseContext.getConfig();
        Config.init(conf);
        Map<String, String>map = new HashMap<String, String>();

        map.put("b9dbe51b8c81b1c15110a3556900c3f20","601");
        map.put("bf0af85f6d52ceb9fb9103c259bc4a192","602");
        map.put("be4a95579875efd441de9831d01cad3a2","603");
        map.put("b01711c5ab0abc698a6f5ca4a7eb7dbb9","616");
        map.put("b87c16ea3f35219705fdae17eac43cb8f","615");
        map.put("b87ab6b680d194baa92fa50afac616cea","613");
        map.put("b75ba9b500c033516606020b08667262c","622");
        map.put("b5b6b75ecc96301a9576f14c1a406e24b","642");
        map.put("b99eb0f9ce77b9300d76c12bd8f1402b6","704");
        map.put("b5d8eb595b22fed92fcec796f9d10f3ab","703");
        map.put("bca83d3967a0d49c38d717463644e7de0","705");
        String line = "";

        AddPurchasedInfoProcessor purchasedInfoProcessor = new AddPurchasedInfoProcessor();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("/disk1/zhaowei/gitlab/dict-profile/delete2.txt"), "utf-8"));
        int j = 0;

        StorageService storageService = StorageService.getInstance();
        List<UserPurchaseEntity> list = storageService.getAllUserPurchase();
        Map<String, UserPurchaseEntity> userPurchaseEntityHashMap = new HashMap<String, UserPurchaseEntity>();
        for (UserPurchaseEntity userPurchaseEntity: list) {
            userPurchaseEntityHashMap.put(userPurchaseEntity.getUserId(), userPurchaseEntity);
        }

        while ((line = br.readLine()) != null) {
//            System.out.println(j++);
            try {
                String[] aa = line.split("@&@&");
                String value = aa[1];
                value = URLDecoder.decode(value, "utf-8");
                JSONArray array = JSON.parseArray(value);
                for (int i = 0 ;i < array.size();i ++) {
                    JSONObject object = array.getJSONObject(i);
                    String userId = object.getString("userId");
                    UserPurchaseEntity userPurchaseEntity = userPurchaseEntityHashMap.get(userId);


                    String itemId = object.getString("itemId");
                    if (userId == null || itemId == null) {
                        continue;
                    }
                    if (map.containsKey(itemId)) {
                        itemId = map.get(itemId);
                    }
                    try {
                        Integer intItem = Integer.parseInt(itemId);
                    } catch (Exception e) {
                        continue;
                    }
                    if (userPurchaseEntity != null && userPurchaseEntity.getPurchases() != null  && isContainItem(itemId, userPurchaseEntity)) {
                        continue;
                    }
                    String time = object.getString("time");
                    String itemName = object.getString("itemName");
                    String extendInfo = object.getString("extendInfo");
                    String price = object.getString("price");
                    String product = object.getString("product");
                    String recordId = object.getString("recordId");

                    PurchaseRecord purchaseRecord = new PurchaseRecord();
                    purchaseRecord.itemId = itemId;
                    purchaseRecord.userId = userId;
                    purchaseRecord.time = time;
                    purchaseRecord.itemName = itemName;
                    purchaseRecord.extendInfo = extendInfo;
                    purchaseRecord.price = price;
                    purchaseRecord.product = product;
                    purchaseRecord.recordId = recordId;
                    System.out.println(JSON.toJSONString(purchaseRecord));

                    coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
                    requestBean.command = CommuniConstants.addPurchase;;
                    JSONObject para = new JSONObject();
                    para.put(CommuniConstants.purchase, purchaseRecord.toString());
                    requestBean.parameters = para;


                    purchasedInfoProcessor.handle(requestBean);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("处理完毕");
















        //统计数目
//
//        UserService.getInstance().cleanUserServerCache("zhaoweideyouxian@163.com");

//        StorageService storageService = StorageService.getInstance();
////
//        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
//        List<UserPurchaseEntity> list = storageService.getAllUserPurchase();
//        for (UserPurchaseEntity userPurchaseEntity: list) {
//            String records = userPurchaseEntity.getPurchases();
//            try {
//                JSONArray jsonArray = JSON.parseArray(records);
//                for (int i = 0 ; i < jsonArray.size();i++) {
//                    String str = jsonArray.getString(i);
//                    try {
//                        JSONObject jsonObject = JSON.parseObject(str);
//                        PurchaseRecord purchaseRecord = PurchaseRecord.fromJson(jsonObject.toJSONString());
//                        int itemid = Integer.parseInt(purchaseRecord.itemId);
//                        Integer num = map.get(itemid);
//                        if (num == null) {
//                            map.put(itemid, 1);
//                        } else {
//                            map.put(itemid, num + 1);
//                        }
//                    } catch (Exception e) {
//                        e.printStackTrace();;
//                    }
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        System.out.println("统计完成");
//
//        for (Map.Entry<Integer, Integer> entry: map.entrySet()) {
//            CourseStatisticEntity courseStatisticEntity = new CourseStatisticEntity();
//            courseStatisticEntity.setBuyNum(entry.getValue());
//            courseStatisticEntity.setId(entry.getKey());
//            storageService.save(courseStatisticEntity);
//
//        }














        //统计人均
//        StorageService storageService = StorageService.getInstance();
//        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
//        List<UserPurchaseEntity> list = storageService.getAllUserPurchase();
//        for (UserPurchaseEntity userPurchaseEntity: list) {
//            String records = userPurchaseEntity.getPurchases();
//            try {
//                JSONArray jsonArray = JSON.parseArray(records);
//                int num = jsonArray.size();
//                Integer value = map.get(num);
//                if (num > 10) {
//                    System.out.println(JSON.toJSONString(userPurchaseEntity));
//                }
//                if (value != null) {
//                    map.put(num, value + 1);
//                } else {
//                    map.put(num, 1);
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        for (Integer num: map.keySet()) {
//            System.out.println(num + ":" + map.get(num));
//        }
//        System.out.println("统计完成");

    }
}

