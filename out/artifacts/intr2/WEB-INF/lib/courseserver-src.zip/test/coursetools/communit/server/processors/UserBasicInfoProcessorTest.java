package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;

/**
 * test case or main for UserBasicInfoProcessor
 * User: zhaowei
 * Date: 14-11-24
 * Time: 上午9:45
 */
public class UserBasicInfoProcessorTest {
    public static void main(String[] args) {
//        System.setProperty("SERVLET_HOME", "F:\\youdaoDict\\workspace\\couseuserserver\\web\\WEB-INF\\");
//        UserBasicInfoProcessor userBasicInfoProcessor = new UserBasicInfoProcessor();
//        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
//        requestBean.parameters = JSON.parseObject("{'key':'nickname2', 'value':'zhaowei2'}");
//        userBasicInfoProcessor.processAddBasicInfo("zhaowei", requestBean);
    }
}
