package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import coursetools.communit.helper.CommuniConstants;
import coursetools.communit.server.processors.UserMessageProcessor;
import coursetools.userservice.UserService;
import junit.framework.Assert;
import org.junit.Test;

/**
 * UserMessageProcessorTest.java
 * <p/>
 * Copyright 2014 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 * <p/>
 * User: zhaowei
 * Date: 14-10-19
 */
public class UserMessageProcessorTest {


    public static void main(String[] args) {
        UserMessageProcessor userMessageProcessor = new UserMessageProcessor();
//        System.out.println(userMessageProcessor.pushMessage("test", null, "test", "http://dict.youdao.com/", "http://home.iyoudao.net/images/home.png", "viz_同学", "这个是一个测试的消息的内容", false));
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(CommuniConstants.opName, CommuniConstants.addMsg);
        para.put(CommuniConstants.userId, "tamamamamam@163.com");
        para.put(CommuniConstants.msgUrl, "http://home.iyoudao.net/images/home.png");
        para.put(CommuniConstants.msgTitle, "老师喊你来写六级基础强化班（词汇、翻译、写作、听力、阅读）作业啦！");
        para.put(CommuniConstants.msgSimpleContent, "一个测试");
        para.put(CommuniConstants.msgContent, "<span class=\"message-content\"><a href=\"homeworkIndex.do?id=702&amp;subLesson=169\">六级基础强化班（词汇、翻译、写作、听力、阅读）</a>有新的作业啦，老师讲的都掌握了没？做过才知道！赶紧来练习吧！</span>");
        para.put(CommuniConstants.msgSender, "viz_赵伟");
        para.put(CommuniConstants.msgAvatar, "");
        requestBean.parameters = para;



//        System.out.println(JSON.toJSON(userMessageProcessor.processAddMessage("tamamamamam@163.com", requestBean)));
//
//        System.out.println(JSON.toJSON(userMessageProcessor.getMsgListFrom("tamamamamam@163.com", System.currentTimeMillis(), Integer.MAX_VALUE, false)));
//        System.out.println(JSON.toJSON(userMessageProcessor.getMsgListFrom("tamamamamam@163.com", System.currentTimeMillis(), Integer.MAX_VALUE, true)));

//        System.out.println(userMessageProcessor.readOneMessage("test", "26050a5d-8d52-4e5b-8296-a8a19cb75e22"));
//        System.out.println(JSON.toJSON(userMessageProcessor.getMsgListFrom("test", System.currentTimeMillis(), Integer.MAX_VALUE, false)));
    }
}
