package coursetools.communit.server.processors;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.Config;
import coursetools.communit.helper.PurchaseRecord;
import coursetools.communit.helper.RequestBean;
import coursetools.database.StorageService;
import coursetools.database.bean.UserPurchaseEntity;
import org.apache.commons.configuration.Configuration;

import java.util.*;

/**
 * test case or main for ListPurchasedInfoProcessor
 * User: zhaowei
 * Date: 14-11-24
 * Time: 上午9:45
 */
public class ListPurchasedInfoProcessorTest {

    public static void main(String[] args) {
        Configuration conf = coursetools.common.CourseContext.getConfig();
        Config.init(conf);
        Map<String, String> map = new HashMap<String, String>();

        map.put("b9dbe51b8c81b1c15110a3556900c3f20","601");
        map.put("bf0af85f6d52ceb9fb9103c259bc4a192","602");
        map.put("be4a95579875efd441de9831d01cad3a2","603");
        map.put("b01711c5ab0abc698a6f5ca4a7eb7dbb9","616");
        map.put("b87c16ea3f35219705fdae17eac43cb8f","615");
        map.put("b87ab6b680d194baa92fa50afac616cea","613");
        map.put("b75ba9b500c033516606020b08667262c","622");
        map.put("b5b6b75ecc96301a9576f14c1a406e24b","642");
        map.put("b99eb0f9ce77b9300d76c12bd8f1402b6","704");
        map.put("b5d8eb595b22fed92fcec796f9d10f3ab","703");
        map.put("bca83d3967a0d49c38d717463644e7de0","705");
//        ListPurchasedInfoProcessor listPurchasedInfoProcessor = new ListPurchasedInfoProcessor();
//        RequestBean requestBean = new RequestBean();
//        requestBean.parameters = JSON.parseObject("{\"userId\":\"zhaoweideyouxian@163.com\"}");
//        System.out.println(listPurchasedInfoProcessor.handle(requestBean));

        List<UserPurchaseEntity> userPurchases = StorageService.getInstance().getAllUserPurchase();

        int num = 0 ;
        for (UserPurchaseEntity userPurchaseEntity: userPurchases) {
            System.out.println(num++);
            String list = userPurchaseEntity.getPurchases();
            JSONArray jsonArray = JSON.parseArray(list);
            Set<String> hashSet = new HashSet<String>();
            for (int i = 0 ; i < jsonArray.size();i++) {
                String one = jsonArray.getString(i);
                JSONObject object = JSON.parseObject(one);
                String itemId = object.getString("itemId");
                if (map.containsKey(itemId)) {
                    itemId = map.get(itemId);
                    object.put("itemId", itemId);
                } else {
                    try {
                        Integer numnum = Integer.parseInt(itemId);
                    } catch (Exception e) {
                        e.printStackTrace();
                        continue;
                    }
                }
                one = JSON.toJSONString(object);
                if (hashSet.contains(one)) {
                    continue;
                } else {
                    hashSet.add(one);
                }
            }
            JSONArray newJsonArray = new JSONArray();
            for (String one: hashSet) {
                newJsonArray.add(one);
            }
            userPurchaseEntity.setPurchases(JSON.toJSONString(newJsonArray));
            StorageService.getInstance().save(userPurchaseEntity);
        }
    }
}
