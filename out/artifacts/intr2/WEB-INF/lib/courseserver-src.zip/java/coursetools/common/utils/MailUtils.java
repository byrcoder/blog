/**
 * @(#)MailUtils.java, Jul 8, 2013. Copyright 2013 Yodao, Inc. All rights
 *                     reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is subject
 *                     to license terms.
 */
package coursetools.common.utils;

import toolbox.misc.LogFormatter;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 不用密码发送邮件，用于发送后台程序的执行报告.
 * from bisheng to bisheng.
 * 
 * 注意:
 * 如果本地没有对soda.rd.netease.com这个域名的解析，
 * 可能执行会报javax.mail.MessagingException: 501 Syntax: HELO hostname
 * 在集群上执行是没有问题的
 * 
 * @author zhaowei
 */
public class MailUtils {
    protected static final Logger LOG = LogFormatter.getLogger(MailUtils.class);

    // 邮箱服务器
    private static final String HOST = "soda.rd.netease.com";

    private static final String MAIL_TO_DEFAULT = "zhaowei@rd.netease.com";

    private static final String MAIL_FROM = "zhaowei@rd.netease.com";
//private static final String MAIL_FROM = "zhaoweideyouxian@163.com";


    public static final String MAIL_CC = "bisheng@rd.netease.com";

    private static final String NAME = "viz";
    
    /**
     * 
     * 此段代码用来发送普通电子邮件
     * mail_to set default as bisheng@rd.netease.com 
     * @param subject
     * @param mailBody
     * @return
     * @throws Exception
     */
    public static boolean send(String subject, String mailBody) {
        return send(MAIL_TO_DEFAULT, subject, mailBody);
    }
    /**
     * 
     * 此段代码用来发送普通电子邮件
     * mail_to set default as bisheng@rd.netease.com 
     * @param subject
     * @param mailBody
     * @return
     * @throws Exception
     */
    public static boolean sendcc(String subject, String mailBody, String to, String cc) {
        return sendcc(MAIL_TO_DEFAULT, subject, mailBody, to, cc);
    }
    /**
     * 
     * 此段代码用来发送普通电子邮件
     * mail_to set default as bisheng@rd.netease.com 
     * @param subject
     * @param mailBody
     * @return
     * @throws Exception
     */
    public static String send(String subject, String mailBody, List<String> toPersonList) {
    	StringBuilder sb = new StringBuilder();
    	sb.append("以下用户发送失败:");
    	for (String person: toPersonList) {
            if (!send(person, subject, mailBody)) {
            	sb.append(person).append("\n");
            }
    	}
    	return sb.toString();
    }
    
    /**
     * 
     * @param mail_to
     * @param subject
     * @param mailBody
     * @return
     * @throws Exception
     */
    public static boolean send(String mail_to, String subject, String mailBody) {
        try {
            Properties props = new Properties(); // 获取系统环境
            props.put("mail.smtp.host", HOST);
            props.put("mail.smtp.auth", "false");
            Session session = Session.getDefaultInstance(props, null);
            // 设置session,和邮件服务器进行通讯。
            MimeMessage message = new MimeMessage(session);
            StringBuilder sb = new StringBuilder();
            sb.append(mailBody).append("\n\n");
            sb.append("--本邮件由bisheng后台服务自动发送，如果不想再被打扰,请回复本邮件--\n");
            Date sendDate = new Date();
            sb.append("\n发送时间:").append(sendDate.toString());
            message.setSubject(subject); // 设置邮件主题
            message.setText(sb.toString()); // 设置邮件正文
            message.setSentDate(sendDate); // 设置邮件发送日期
            Address address = new InternetAddress(MAIL_FROM, NAME);
            
            BodyPart mdp=new MimeBodyPart();
            mdp.setContent(sb.toString(),"text/html;charset = utf-8");
            Multipart mm=new MimeMultipart();
            mm.addBodyPart(mdp);
            message.setContent(mm);
            message.setFrom(address); // 设置邮件发送者的地址
            if (mail_to == null) {
                mail_to = MAIL_TO_DEFAULT; 
            }
            Address toAddress = new InternetAddress(mail_to); // 设置邮件接收方的地址

            message.addRecipient(Message.RecipientType.TO, toAddress);
            Transport.send(message); // 发送邮件
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            LOG.log(Level.SEVERE, "MailUtils send email failed.");
            return false;
        }
    }
    
    /**
     * 
     * @param mail_to
     * @param subject
     * @param mailBody
     * @return
     * @throws Exception
     */
    public static boolean sendcc(String mail_to, String subject, String mailBody, String to, String cc) {
        try {
            Properties props = new Properties(); // 获取系统环境
            props.put("mail.smtp.host", HOST);
            props.put("mail.smtp.auth", "false");
            Session session = Session.getDefaultInstance(props, null);
            // 设置session,和邮件服务器进行通讯。
            MimeMessage message = new MimeMessage(session);
            StringBuilder sb = new StringBuilder();
            sb.append(mailBody).append("\n\n");
            sb.append("--本邮件由bisheng后台服务自动发送，如果不想再被打扰,请回复本邮件--\n");
            Date sendDate = new Date();
            sb.append("\n发送时间:").append(sendDate.toString());
            message.setSubject(subject); // 设置邮件主题
            message.setText(sb.toString()); // 设置邮件正文
            message.setSentDate(sendDate); // 设置邮件发送日期
            Address address = new InternetAddress(MAIL_FROM, NAME);
            
            BodyPart mdp=new MimeBodyPart();
            mdp.setContent(sb.toString(),"text/html;charset = utf-8");
            Multipart mm=new MimeMultipart();
            mm.addBodyPart(mdp);
            message.setContent(mm);
            message.setFrom(address); // 设置邮件发送者的地址
            if (mail_to == null) {
                mail_to = MAIL_TO_DEFAULT; 
            }
            Address toAddress = new InternetAddress(mail_to); // 设置邮件接收方的地址
            if (cc != null) {
                Address ccAddress = new InternetAddress(cc); // 设置邮件接收方的地址
                message.addRecipient(Message.RecipientType.CC, ccAddress);
            }

            message.addRecipient(Message.RecipientType.TO, toAddress);
            Transport.send(message); // 发送邮件
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            LOG.log(Level.SEVERE, "MailUtils send email failed.");
            return false;
        }
    }

    public static void main(String[]args) {
        StringBuilder sb = new StringBuilder();
        sb.append("内容:").append("土； ").append("<BR>");
        sb.append("<BR><BR><BR>姓名:").append("fadsfaf jfadsf革柑").append("<BR>");
        sb.append("电话:").append(12121).append("<BR>");
        sb.append("邮箱:").append(333).append("<BR>");
        MailUtils.send("youdao_kaoyan@rd.netease.com", "test", sb.toString());
    }
}
