package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSONObject;
import coursetools.database.StorageService;
import coursetools.database.bean.UserPurchaseEntity;

/**
 * 增加用户的购买记录信息
 * @author zhaowei
 */
public class IsContainPurchasedInfoProcessor extends SimpleProcessor {
    private StorageService storageService = StorageService.getInstance();

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String userId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.userId);
            if (userId == null) {
                return coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, "no userId in parameters");
            }
            String itemId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.itemId);
            if (itemId == null) {
                return coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, "no itemId in parameters");
            }
            try {
                UserPurchaseEntity userPurchaseEntity = storageService.getUserPurchase(userId);

                coursetools.communit.helper.ResponseBean responseBean;
                responseBean = coursetools.common.utils.WebBeanUtils.newSuccInnerResponse(requestBean);

                if (userPurchaseEntity == null) {
                    responseBean.result = "false";
                } else {
                    String records = userPurchaseEntity.getPurchases();
                    if (records == null) {
                        responseBean.result = "false";
                    } else {
                        if (records.indexOf("\"itemId\\\":\\\"" + itemId + "\\\"") != -1) {
                            responseBean.result = "true";
                        } else {
                            responseBean.result = "false";
                        }
                    }
                }
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } catch (Exception e) {
                e.printStackTrace();
                return coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }
}
