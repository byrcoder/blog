package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import coursetools.common.utils.WebBeanUtils;
import coursetools.database.StorageService;
import coursetools.database.bean.CourseStatisticEntity;
import coursetools.database.bean.UserPurchaseEntity;

import java.util.List;
import java.util.Set;

/**
 * 获取买了这个课程的所有的用户
 * @author zhaowei
 */
public class GetPurchasedUsersProcessor extends SimpleProcessor {
    private StorageService storageService = StorageService.getInstance();

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String courseId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.itemId);
            if (courseId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no course id in parameters");
            }
            Set<String> allUserIds = storageService.getAllUsersByCourseId(courseId);
            coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);

            if (allUserIds == null) {
                responseBean.result = "[]";
            } else {
                responseBean.result = JSON.toJSONString(allUserIds);
            }
            responseBean.finishTime = System.currentTimeMillis();
            return responseBean;
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }
}
