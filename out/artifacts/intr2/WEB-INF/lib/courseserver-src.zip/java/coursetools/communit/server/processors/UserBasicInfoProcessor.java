package coursetools.communit.server.processors;

import insight.common.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.utils.WebBeanUtils;
import coursetools.database.StorageService;
import coursetools.database.bean.UserInfoEntity;

/**
 * 操作用户的基本信息
 * 
 * @author zhaowei
 */
public class UserBasicInfoProcessor extends SimpleProcessor {
    private static final String userBasicInfoKey = "userBasisInfo";

    private StorageService storageService = StorageService.getInstance();

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String userId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.userId);
            if (userId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no user id in parameters");
            }
            String opName = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.opName);
            if (opName == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no special operation name");
            }
            if (opName.equals(coursetools.communit.helper.CommuniConstants.updateBasicProfile)) {
                return processAddBasicInfo(userId, requestBean);
            } else if (opName.equals(coursetools.communit.helper.CommuniConstants.getBasicProfile)) {
                return processGetBasicInfo(userId, requestBean);
            } else if (opName.equals(coursetools.communit.helper.CommuniConstants.getUserAllAddress)) {
                return processGetUserAllAddress(userId, requestBean);
            } else if (opName.equals(coursetools.communit.helper.CommuniConstants.addUserAddress)) {
                return processAddUserAddress(userId, requestBean);
            } else if (opName.equals(coursetools.communit.helper.CommuniConstants.updateUserAddress)) {
                return processUpdateUserAddress(userId, requestBean);
            } else if (opName.equals(coursetools.communit.helper.CommuniConstants.deleteUserAddress)) {
                return processDeleteUserAddress(userId, requestBean);
            }

            return WebBeanUtils.newFailInnerResponse(requestBean, "unknown sub command");
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }

    /**
     * 获取用户信息
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processGetBasicInfo(String userId, coursetools.communit.helper.RequestBean requestBean) {
        UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        responseBean.finishTime = System.currentTimeMillis();
        responseBean.result = userInfoEntity.getBasicInfo();
        return responseBean;
    }

    /**
     * 处理增加一个属性
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processAddBasicInfo(String userId, coursetools.communit.helper.RequestBean requestBean) {
        String key = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.key);
        if (key == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean, "no key inf parameters");
        }

        String value = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.value);
        if (value == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean, "no value inf parameters");
        }
        UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
        JSONObject userBasicInfo = null;
        if (userInfoEntity != null) {
            try {
                userBasicInfo = JSON.parseObject(userInfoEntity.getBasicInfo());
                userBasicInfo.put(key, value);
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("@@ERROR@@ serious error, user basic info parse error:" + userId);
                userBasicInfo = new JSONObject();
                userBasicInfo.put(key, value);
                userBasicInfo.put("userId", userId);
            }
        } else {
            userInfoEntity = new UserInfoEntity();
            userInfoEntity.setUserId(userId);
            userBasicInfo = new JSONObject();
            userBasicInfo.put(key, value);
            userBasicInfo.put("userId", userId);
        }
        userInfoEntity.setBasicInfo(JSON.toJSONString(userBasicInfo));
        // 重新写回数据库,刷新缓存
        storageService.save(userInfoEntity);
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        responseBean.finishTime = System.currentTimeMillis();
        return responseBean;
    }

    private coursetools.communit.helper.ResponseBean processGetUserAllAddress(String userId, coursetools.communit.helper.RequestBean requestBean) {
        UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        responseBean.finishTime = System.currentTimeMillis();
        responseBean.result = StringUtils.isEmpty(userInfoEntity.getUserAddress()) ? "[]" : userInfoEntity.getUserAddress();
        return responseBean;
    }

    private coursetools.communit.helper.ResponseBean processAddUserAddress(String userId, coursetools.communit.helper.RequestBean requestBean) {
        UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
        JSONArray userAddressArray = null;
        if (userInfoEntity != null) {
            try {
                userAddressArray = JSONArray.parseArray(userInfoEntity.getUserAddress());
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("@@ERROR@@ serious error, user basic info parse error:" + userId);
            }
        } else {
            userInfoEntity = new UserInfoEntity();
            userInfoEntity.setUserId(userId);
        }
        if (userAddressArray == null)
            userAddressArray = new JSONArray();
        String addressInfo = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.addressInfo);
        JSONObject userAddressJson = null;
        try {
            userAddressJson = JSON.parseObject(addressInfo);
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean, "addressInfo format error!");
        }

        int maxId = 1;
        if (userAddressArray.size() > 0) {
            JSONObject tmpJson = (JSONObject) userAddressArray.get(userAddressArray.size() - 1);
            maxId = tmpJson.get(coursetools.communit.helper.CommuniConstants.addressId) == null ? maxId : (tmpJson
                    .getInteger(coursetools.communit.helper.CommuniConstants.addressId) + 1);
        } else
            userAddressJson.put(coursetools.communit.helper.CommuniConstants.addressDefaultTag, true);// 第一个设置为默认
        userAddressJson.put(coursetools.communit.helper.CommuniConstants.addressId, maxId);
        userAddressArray.add(userAddressJson);
        updateDefaultAddress(maxId, userAddressJson.getBooleanValue(coursetools.communit.helper.CommuniConstants.addressDefaultTag), userAddressArray);
        userInfoEntity.setUserAddress(userAddressArray.toJSONString());
        // 重新写回数据库,刷新缓存
        storageService.save(userInfoEntity);
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        responseBean.finishTime = System.currentTimeMillis();
        return responseBean;
    }

    private coursetools.communit.helper.ResponseBean processUpdateUserAddress(String userId, coursetools.communit.helper.RequestBean requestBean) {
        UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
        JSONArray userAddressArray = null;
        if (userInfoEntity != null) {
            try {
                userAddressArray = JSONArray.parseArray(userInfoEntity.getUserAddress());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (userAddressArray == null || userAddressArray == null)
            return WebBeanUtils.newFailInnerResponse(requestBean, userId + " has none userAddress data");

        String addressInfo = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.addressInfo);
        JSONObject userAddressJson = null;
        try {
            userAddressJson = JSON.parseObject(addressInfo);
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean, "addressInfo format error!");
        }

        Integer modId = userAddressJson.getInteger(coursetools.communit.helper.CommuniConstants.addressId);
        String key = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.key);
        if (key.equals(coursetools.communit.helper.CommuniConstants.defaultAddress))
            userAddressJson.put(coursetools.communit.helper.CommuniConstants.addressDefaultTag, true);

        for (int i = 0; i < userAddressArray.size(); i++) {
            JSONObject tmpJson = (JSONObject) userAddressArray.get(i);
            if (tmpJson.getInteger(coursetools.communit.helper.CommuniConstants.addressId).equals(modId)) {
                userAddressArray.set(i, userAddressJson);
                break;
            }
        }

        updateDefaultAddress(modId, userAddressJson.getBooleanValue(coursetools.communit.helper.CommuniConstants.addressDefaultTag), userAddressArray);
        userInfoEntity.setUserAddress(userAddressArray.toJSONString());
        // 重新写回数据库,刷新缓存
        storageService.save(userInfoEntity);
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        responseBean.finishTime = System.currentTimeMillis();
        return responseBean;
    }

    /**
     * modId为默认地址，则更新其他非此id的默认地址数据
     * 
     * @param modId
     * @param isDefault
     * @param userAddressArray
     */
    private void updateDefaultAddress(Integer modId, boolean isDefault, JSONArray userAddressArray) {
        if (modId == null || userAddressArray == null || userAddressArray.size() == 0)
            return;
        boolean hasDefault = false;
        for (int i = 0; i < userAddressArray.size(); i++) {
            JSONObject tmpJson = (JSONObject) userAddressArray.get(i);
            if (!tmpJson.getInteger(coursetools.communit.helper.CommuniConstants.addressId).equals(modId) && isDefault) {
                tmpJson.put(coursetools.communit.helper.CommuniConstants.addressDefaultTag, false);
            }
            if (tmpJson.getBooleanValue(coursetools.communit.helper.CommuniConstants.addressDefaultTag))
                hasDefault = true;
        }

        // 没有默认地址则设置第一个地址为默认地址
        if (!hasDefault) {
            JSONObject tmpJson = (JSONObject) userAddressArray.get(0);
            tmpJson.put(coursetools.communit.helper.CommuniConstants.addressDefaultTag, true);
        }
    }

    private coursetools.communit.helper.ResponseBean processDeleteUserAddress(String userId, coursetools.communit.helper.RequestBean requestBean) {
        UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
        JSONArray userAddressArray = null;
        if (userInfoEntity != null) {
            try {
                userAddressArray = JSONArray.parseArray(userInfoEntity.getUserAddress());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (userAddressArray == null || userAddressArray == null)
            return WebBeanUtils.newFailInnerResponse(requestBean, userId + " has none userAddress data");

        Integer addressId = requestBean.parameters.getInteger(coursetools.communit.helper.CommuniConstants.key);
        boolean delete = false;
        boolean defaultDelete = false;
        for (int i = 0; i < userAddressArray.size(); i++) {
            JSONObject tmpJson = (JSONObject) userAddressArray.get(i);
            if (tmpJson.getInteger(coursetools.communit.helper.CommuniConstants.addressId).equals(addressId)) {
                userAddressArray.remove(i);
                delete = true;
                if (tmpJson.getBooleanValue(coursetools.communit.helper.CommuniConstants.addressDefaultTag))
                    defaultDelete = true;
                break;
            }
        }
        if (delete) {
            // 设置默认地址
            if (defaultDelete && userAddressArray.size() > 0) {
                JSONObject tmpJson = (JSONObject) userAddressArray.get(0);
                tmpJson.put(coursetools.communit.helper.CommuniConstants.addressDefaultTag, true);
            }
            userInfoEntity.setUserAddress(userAddressArray.toJSONString());
            // 重新写回数据库,刷新缓存
            storageService.save(userInfoEntity);
            coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
            responseBean.finishTime = System.currentTimeMillis();
            return responseBean;
        } else
            return WebBeanUtils.newFailInnerResponse(requestBean, userId + " has none userAddress id:" + addressId);

    }
}
