/**
 * @(#)MailInfoTask.java, 2013-5-21. 
 * 
 * Copyright 2013 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common.utils.notify;

import insight.common.mail.MailInfo;
import insight.common.mail.MailSender;

/**
 * 发送邮件通知的工具类
 * 
 * @author qipeng
 *
 */
public class MailInfoTask implements IInfoTask {

    public final static String TASK_TYPE = "EMAIL";
    
    private MailSender sender;
    
    private MailInfo mailInfo;
    
    public MailInfoTask(MailInfo mailInfo) {
        this.mailInfo = mailInfo;
    }
    
    @Override
    public String getType() {
        return TASK_TYPE;
    }
    
    @Override
    public boolean send() {
        return sender.sendMail(mailInfo);
    }

    /**
     * @param sender the sender to set
     */
    public void setSender(MailSender sender) {
        this.sender = sender;
    }

}
