package coursetools.communit.client;

import org.apache.mina.core.future.ReadFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.LineDelimiter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.transport.socket.SocketConnector;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

import coursetools.common.Constant;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 一个测试mina服务端的例子
 * @author zhaowei
 * @version 2014-09-16
 */
public class MinaClient {
    private SocketConnector connector;
    private TextLineCodecFactory  lineCodec;
    private IoSession session = null;
    private int timeout = 60;
    private String host;
    private String clientInfo;

    /**
     *
     * @param timeout 连接超时的时间
     */
    public MinaClient(int timeout) throws UnknownHostException {
        this.host = host;
        connector = new NioSocketConnector();
        connector.setConnectTimeoutMillis(10000);
        this.timeout = timeout;
        lineCodec = new TextLineCodecFactory( Charset.forName( "UTF-8" ), LineDelimiter.UNIX, LineDelimiter.UNIX);
        connector.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(lineCodec)
        );
        lineCodec.setDecoderMaxLineLength(1024 * 1024);
        lineCodec.setEncoderMaxLineLength(1024 * 1024);
        connector.getSessionConfig().setTcpNoDelay(true);
        connector.getSessionConfig().setUseReadOperation(true);

        //初始化域名
        Constant.USER_SERVER_HOST=System.getProperty(Constant.USER_SERVER_HOST_KEY,
        		Constant.USER_SERVER_HOST);
        
        //get all ips from domain name try one by one.
        InetAddress[] addresses = InetAddress.getAllByName(coursetools.common.Constant.USER_SERVER_HOST);
        //sort ip array
        List<String> ips = new ArrayList<String>();
        for (InetAddress addresse: addresses) {
            try {
                String ip = addresse.getHostAddress();
                ips.add(ip);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Collections.sort(ips);

        //connect
        for (String ip: ips) {
            try {
                session = connector.connect(new InetSocketAddress(ip,
                        coursetools.common.Constant.USER_SERVER_PORT)).awaitUninterruptibly().getSession();
                System.out.println("\n\nconnect to " + ip + " server sucess!!!!\n\n");
                break;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (session == null) {
            throw new UnknownHostException();
        }

        StringBuilder sb = new StringBuilder();
        sb.append(getInetAddress()).append(System.getProperty("user.name"));
        clientInfo = sb.toString();
    }

    /**
     * 调远程的服务端结果
     * @param requestBean
     * @return responseBean
     */
    public coursetools.communit.helper.ResponseBean invoke(coursetools.communit.helper.RequestBean requestBean) {
        try {
            requestBean.clientId = clientInfo;
            if (session.isConnected()) {
                requestBean.sendTime = System.currentTimeMillis();
                return  writeAndRead(session, requestBean);
            } else {
                session.close(true);
                InetAddress[] addresses = InetAddress.getAllByName(coursetools.common.Constant.USER_SERVER_HOST);
                List<String> ips = new ArrayList<String>();
                for (InetAddress addresse: addresses) {
                    try {
                        String ip = addresse.getHostAddress();
                        ips.add(ip);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                Collections.sort(ips);

                //connect
                for (String ip: ips) {
                    try {
                        session = connector.connect(new InetSocketAddress(ip,
                                coursetools.common.Constant.USER_SERVER_PORT)).awaitUninterruptibly().getSession();
                        System.out.println("\n\nconnect to " + ip + " server sucess!!!!\n\n");
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (session == null) {
                    throw new UnknownHostException();
                }
                return writeAndRead(session, requestBean);
            }
        } catch (Exception e) {
            coursetools.communit.helper.ResponseBean responseBean = coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, "connect to server error");
            return responseBean;
        }
    }

    private coursetools.communit.helper.ResponseBean writeAndRead(IoSession session, coursetools.communit.helper.RequestBean requestBean) {
        try{
            session.write(requestBean.toString()).awaitUninterruptibly();
            ReadFuture readFuture = session.read();
            if (readFuture.awaitUninterruptibly(timeout, TimeUnit.SECONDS)) {
                try {
                    coursetools.communit.helper.ResponseBean responseBean = coursetools.communit.helper.ResponseBean.fromString((String) readFuture.getMessage());
                    return responseBean;
                } catch (Exception e) {
                    return coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, "parse result error");
                }
            } else {
                return coursetools.common.utils.WebBeanUtils.newFailInnerResponse(requestBean, "get data time out");
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static InetAddress getInetAddress() {
        try{
            return InetAddress.getLocalHost();
        }catch(UnknownHostException e){
            System.out.println("unknown host!");
        }
        return null;
    }
}

