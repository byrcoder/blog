package coursetools.communit.server.processors;

import java.util.Arrays;

import coursetools.common.utils.WebBeanUtils;
import coursetools.database.StorageService;
import coursetools.database.bean.CourseStatisticEntity;

/**
 * 获取一个课程有多少用户买了
 * 
 * @author zhaowei
 */
public class GetPurchasedUserNumProcessor extends SimpleProcessor {
    private StorageService storageService = StorageService.getInstance();

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String courseId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.itemId);
            if (courseId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no course id in parameters");
            }
            String opName = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.opName);
            if (opName == null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
                responseBean.result = getPurchaseNumByCourseId(courseId);
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else if (opName.equals(coursetools.communit.helper.CommuniConstants.getArrayPurchaseNumOp)) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
                String[] courseIdArray = parseArrayString(courseId);
                String[] resultArray = new String[courseIdArray.length];
                for (int i = 0; i < courseIdArray.length; i++) {
                    resultArray[i] = getPurchaseNumByCourseId(courseIdArray[i]);
                    System.out.println(courseIdArray[i]+"="+resultArray[i]);
                }
                responseBean.result = Arrays.toString(resultArray);
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
        return WebBeanUtils.newFailInnerResponse(requestBean, "unknown sub command");
    }

    private String getPurchaseNumByCourseId(String courseId) {
        String result = "0";
        try {
            CourseStatisticEntity courseStatisticEntity = storageService.getCourseStatistic(Integer.valueOf(courseId));
            if (courseStatisticEntity != null)
                result = String.valueOf(courseStatisticEntity.getBuyNum());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * @param arrayString
     *            format=[1,2,3,4]
     * @return
     */
    public String[] parseArrayString(String arrayString) {
        String tmp = arrayString.substring(1, arrayString.length() - 1);
        tmp=tmp.replace(" ", "");
        return tmp.split(",");
    }
}
