package coursetools.database;

import coursetools.common.Config;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.io.File;

/**
 * sessionFactory
 */
public class SessionManager {
    private static SessionManager instance = new SessionManager();
    private SessionFactory sessionFactory;
    public static SessionManager getInstance() {
        return instance;
    }

    private SessionManager() {
        try {
            configureSessionFactory();
            System.out.println("sessionFatory init over");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
    public Session getSession() {
        return sessionFactory.openSession();
    }

    private SessionFactory configureSessionFactory() {
        try {
            System.out.println("init sessionFatory... ");
            String webInfoPath = Config.hibernatePath;
            System.out.println("hibernatePath is:" + webInfoPath);
            File file = new File(webInfoPath);
            Configuration configuration = new Configuration();
            configuration.configure(file);
            sessionFactory = configuration.buildSessionFactory();
            return sessionFactory;
        } catch (HibernateException e) {
            e.printStackTrace();
        }
        return sessionFactory;
    }

    public void closeSession(Session session) {
        if (session != null) {
            if (session.isOpen()) {
                session.close();
            }
        }
    }
}
