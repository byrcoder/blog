package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.utils.HashMapCache;
import coursetools.common.utils.WebBeanUtils;
import coursetools.communit.helper.CommuniConstants;
import coursetools.database.StorageService;
import coursetools.database.bean.MsgTemplateEntity;
import coursetools.database.bean.UserMsgEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 用户消息情况存储
 * @author zhaowei
 */
public class UserMessageProcessor extends SimpleProcessor {
    private static final String ERROR = "error";
    private static final String BASE_URL = "http://xue.youdao.com/message/";
    private static final String SEND_MESSAGE_URL = BASE_URL + "push";
    private static final String FETCH_MESSAGE_URL = BASE_URL + "pull";
    private static final String FETCH_UNREAD_NUM_URL = BASE_URL + "count";
    private static final String READ_MSG_URL = BASE_URL + "markread";

    private static final String[] KEYS_WITH_USERID = {"userid", "type", "url", "image", "username", "content", "app"};
    private static final String[] KEYS_WITH_GROUPID = {"groupid", "type", "url", "image", "username", "content", "app"};
    private static final String APPNAME = "course";

    private StorageService storageService = StorageService.getInstance();
    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String userId = requestBean.parameters.getString(CommuniConstants.userId);
            if (userId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no user id in parameters");
            }
            String opName = requestBean.parameters.getString(CommuniConstants.opName);
            if (opName == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no special operation name");
            }
            if (opName.equals(CommuniConstants.addMsg)) {
                return processAddMessage(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getUnReadMsgNum)) {
                return processGetUnReadNum(userId, requestBean);
            } else if (opName.equals(CommuniConstants.readMsg)) {
                return processReadAction(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getUnReadMsg)) {
                return processGetUnReadMessage(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getMsg)) {
                return processGetMessage(userId, requestBean);
            }
            return WebBeanUtils.newFailInnerResponse(requestBean, "unknown sub command");
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }

    /**
     * 阅读一条消息
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processReadAction(String userId, coursetools.communit.helper.RequestBean requestBean) {
        String msgIdStr = requestBean.parameters.getString(CommuniConstants.msgId);
        if (msgIdStr != null) {
            try{
                boolean isSuccess = readOneMessage(userId, msgIdStr);
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
                storageService.unReadNumCache.invalidate(userId);
                storageService.messageCache.invalidate(userId);
                responseBean.finishTime = System.currentTimeMillis();
                responseBean.result = String.valueOf(isSuccess);
                return responseBean;
            } catch (Exception e) {
                return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
            }
        } else {
            return WebBeanUtils.newFailInnerResponse(requestBean, "no sendtime as msg id");
        }
    }

    /**
     * 增加一条消息
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processAddMessage(String userId, coursetools.communit.helper.RequestBean requestBean) {
        String msgContent = requestBean.parameters.getString(CommuniConstants.msgContent);
        if (msgContent == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean, "no message content in parameters");
        }
        String msgTitle = requestBean.parameters.getString(CommuniConstants.msgTitle);
        String msgSender = requestBean.parameters.getString(CommuniConstants.msgSender);
        String msgSimpleContent = requestBean.parameters.getString(CommuniConstants.msgSimpleContent);
        String msgUrl = requestBean.parameters.getString(CommuniConstants.msgUrl);
        String msgAvatar = requestBean.parameters.getString(CommuniConstants.msgAvatar);

        try {
            storageService.unReadNumCache.invalidate(userId);
            storageService.messageCache.invalidate(userId);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("title", msgTitle);
            jsonObject.put("simpleContent", msgSimpleContent);
            jsonObject.put("allContent", msgContent);

            pushMessage(userId, null, "msg", msgUrl, msgAvatar, msgSender, jsonObject.toJSONString(), true);

            coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
            responseBean.finishTime = System.currentTimeMillis();
            responseBean.result = "true";
            return responseBean;
        } catch (Exception e) {
            e.printStackTrace();
            coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newFailInnerResponse(requestBean, "save into db failed");
            responseBean.finishTime = System.currentTimeMillis();
            return responseBean;
        }
    }


    /**
     * 获取未读的消息数
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processGetUnReadNum(String userId, coursetools.communit.helper.RequestBean requestBean) {
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        Integer unReadNum = storageService.unReadNumCache.get(userId);
        if (unReadNum == null) {
            unReadNum = getUnReadMessageNum(userId);
            storageService.unReadNumCache.put(userId, unReadNum);
        }
        responseBean.finishTime = System.currentTimeMillis();
        responseBean.result = String.valueOf(unReadNum);
        return responseBean;
    }


    /**
     * 获取用户的消息，包括未读和已读
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processGetMessage(String userId, coursetools.communit.helper.RequestBean requestBean) {
        return getMessageList(userId, requestBean, true);
    }
    /**
     * 获取未读的消息
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean processGetUnReadMessage(String userId, coursetools.communit.helper.RequestBean requestBean) {
        return getMessageList(userId, requestBean, false);
    }

    /**
     *
     * @param requestBean
     * @param isAll false return unread message only
     */
    private coursetools.communit.helper.ResponseBean getMessageList(String userId, coursetools.communit.helper.RequestBean requestBean, boolean isAll) {
        long endTime = requestBean.parameters.getLongValue(CommuniConstants.msgEndTime);
        if (endTime == 0) {
            endTime = System.currentTimeMillis();
        }
        Integer len = requestBean.parameters.getInteger(CommuniConstants.len);
        if (len == null) {
            len = 5;
        }
        String cacheKey = HashMapCache.buildKey(endTime, len, userId, "getMsg" + isAll);
        HashMap<String, List<UserMsgEntity>> map = storageService.messageCache.get(userId);
        if (map == null) {
            map = new HashMap <String, List<UserMsgEntity>>();
            storageService.messageCache.put(userId, map);
        }
        List<UserMsgEntity> resultList = map.get(cacheKey);
        if (resultList == null) {
            if (isAll) {
                resultList = getMsgListFrom(userId, endTime, len, false);
            } else {
                resultList = getMsgListFrom(userId, endTime, len, true);
            }
            if (resultList != null) {
                map.put(cacheKey, resultList);
            }
        }
        if (resultList == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean, "null list read from db");
        }
        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
        responseBean.finishTime = System.currentTimeMillis();
        responseBean.result = JSON.toJSONString(resultList);
        return responseBean;
    }

    /**
     *
     * @param userId
     * @param groupId  groupid and userid shouldn't appear both at the same time.
     * @param type  message's type
     * @param redirectUrl  when user click this message, the target page will be this parameter.
     * @param imageOfSender
     * @param userNameOfSender
     * @param Content  message's content
     * @param isPush if true, user will get push message without opening app.but this is working with hangzhou push system. Without that ,this parameter is useless
     * @return  is sucessful
     */
    private boolean pushMessage(String userId, String groupId, String type, String redirectUrl, String imageOfSender,
                               String userNameOfSender, String Content, boolean isPush) {
        String[] keys = null;
        List<String> values = new ArrayList<String>();
        if (userId != null && userId.length() > 0) {
            keys = KEYS_WITH_USERID;
            values.add(userId);
        } else if (groupId != null && groupId.length() > 0) {
            keys = KEYS_WITH_GROUPID;
            values.add(groupId);
        } else {
            return false;
        }
        values.add(type);
        values.add(redirectUrl);
        values.add(imageOfSender);
        values.add(userNameOfSender);
        values.add(Content);
        values.add(APPNAME);
        return postData(keys, values, isPush);
    }

    /**
     * send post data to other server and get result
     * @param userId
     * @return  unreaded num
     */
    private boolean readOneMessage(String userId, String msgId) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        StringBuilder sb = new StringBuilder();
        sb.append(READ_MSG_URL).append("?userid=").append(userId).append("&messageid=").append(msgId).append("&app=").append(APPNAME);

        System.out.println("标记已读:" + sb.toString());
        HttpPost post = new HttpPost(sb.toString());
        try {
            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
               return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return false;
    }

    /**
     * send post data to other server and get result
     * @param userId
     * @return  unreaded num
     */
    private int getUnReadMessageNum(String userId) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        StringBuilder sb = new StringBuilder();
        sb.append(FETCH_UNREAD_NUM_URL).append("?userid=").append(userId).append("&keyfrom=").append(APPNAME);

        HttpPost post = new HttpPost(sb.toString());
        try {
            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
                String strResult = EntityUtils.toString(response.getEntity());
                if (strResult != null) {
                    try {
                        JSONObject resultJson = JSON.parseObject(strResult);
                        int count = resultJson.getIntValue("count");
                        return count;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return -1;
    }

    /**
     * send post data to other server and get result
     * @param userId
     * @param endTime
     * @param len
     * @param justUnRead
     * @return  is successful
     */
    private List<UserMsgEntity> getMsgListFrom(String userId, long endTime, int len, boolean justUnRead) {
        List<UserMsgEntity> result = new ArrayList<UserMsgEntity>();
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        StringBuilder sb = new StringBuilder();
        sb.append(FETCH_MESSAGE_URL).append("?userid=").append(userId).append("&limit=").append(len)
                .append("&endtime=").append(endTime).append("&keyfrom=").append(APPNAME);
        if (justUnRead) {
            sb.append("&unread=").append("true");
        }
        HttpPost post = new HttpPost(sb.toString());
        try {
            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
                String strResult = EntityUtils.toString(response.getEntity());

                if (strResult != null) {
                    try {
                        JSONArray jsonArray = JSON.parseArray(strResult);
                        for (int i = 0 ; i < jsonArray.size();i++) {
                            try {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                UserMsgEntity userMsgEntity = new UserMsgEntity();
                                long time = jsonObject.getLongValue("time");
                                userMsgEntity.setSendTime(new Timestamp(time));

                                String url = jsonObject.getString("url");
                                String image = jsonObject.getString("image");
                                String userid = jsonObject.getString("userid");
                                String id = jsonObject.getString("id");
                                userMsgEntity.setId(id);
                                Boolean read = jsonObject.getBoolean("read");
                                userMsgEntity.setMsgRead(read.booleanValue());
                                userMsgEntity.setUrl(URLDecoder.decode(url, "utf-8"));
                                userMsgEntity.setMsgAvatar(URLDecoder.decode(image, "utf-8"));
                                userMsgEntity.setUserId(userid);
                                String content = URLDecoder.decode(jsonObject.getString("content"), "utf-8");
                                String username = URLDecoder.decode(jsonObject.getString("username"), "utf-8");;
                                userMsgEntity.setSender(username);

                                //由于消息中心的存储不只有一个content字段，所以更多的内容属性做成了json存在这个字段中
                                //存和取都做一下转换
                                try {
                                    JSONObject contentJson = JSON.parseObject(content);
                                    String title = contentJson.getString("title");
                                    userMsgEntity.setTitle(title);
                                    String simpleContent = contentJson.getString("simpleContent");
                                    userMsgEntity.setSimpleContent(simpleContent);
                                    String allContent = contentJson.getString("allContent");
                                    userMsgEntity.setContent(allContent);
                                } catch (Exception e) {
//                                    e.printStackTrace();
                                    userMsgEntity.setContent(content);
                                }
                                result.add(userMsgEntity);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        return result;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return null;
    }


    /**
     * send post data to other server and get result
     * @param keys
     * @param values
     * @param isPush
     * @return  is successful
     */
    private boolean postData(String[] keys, List<String> values, boolean isPush) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        HttpPost post = new HttpPost(SEND_MESSAGE_URL);
        try {
            List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            if (keys != null && values != null) {
                if (keys.length != values.size()) {
                    return false;
                } else {
                    for (int i = 0 ; i < keys.length; i++) {
                        String key = keys[i];
                        if (key.equals("userid")) {
                            nvps.add(new BasicNameValuePair(keys[i], values.get(i)));
                        } else {
                            nvps.add(new BasicNameValuePair(keys[i], URLEncoder.encode(values.get(i), "utf-8")));
                        }
                    }
                }
            }
            post.setEntity(new UrlEncodedFormEntity(nvps));

            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
                String strResult = EntityUtils.toString(response.getEntity());
                JSONObject result = JSONObject.parseObject(strResult);
                if (result == null) {
                    return false;
                }
                Integer error = result.getInteger(ERROR);
                if (error == null) {
                    error = 1;
                }
                if (error == 0) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return false;
    }
}
