package coursetools.database.bean;

import java.util.HashMap;
import java.util.Map;

/**
 *消息类型模版
 * 在存储的时候就可以只存一下里面的字段就好了，节省存储空间
 */
public enum MsgType {
    normal(1, "normal"),
    purchasedSucc(2, "purchasedSucc");


    private final int code;
    private final String message;
    /**
     * 用来存储从int code -> statusCode的映射
     */
    private static Map<Integer, MsgType> map = new HashMap<Integer, MsgType>();
    static {
        for(MsgType s: values()) {
            map.put(s.getCode(), s);
        }
    }
    /**
     * @param code
     * @param message
     */
    private MsgType(int code, String message) {
        this.code = code;
        this.message = message;
    }

    /**
     * 由编号获取类型
     * @param code
     * @return StatusCode
     */
    public static MsgType fromCode(int code) {
        MsgType msgType = map.get(code);
        return msgType != null ? msgType : normal;
    }
    /**
     * 返回状态码的文本说明
     * @return
     */
    public String getMessage() {
        return message;
    }

    /**
     * 返回状态码的数值代码
     * @return
     */
    public int getCode() {
        return code;
    }

    @Override
    public String toString() {
        return "(code: " + code + ", message: " + message + ")";
    }

    public String toJSONString() {
        return "{\"code\": " + code + ",\"message\": \"" + message + "\"}";
    }

}
