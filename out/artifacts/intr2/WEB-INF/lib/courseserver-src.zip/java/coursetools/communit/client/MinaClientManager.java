package coursetools.communit.client;

import coursetools.common.Constant;
import coursetools.communit.helper.ResponseBean;

import java.net.UnknownHostException;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * mina客户端的管理器
 * 
 * @author zhaowei
 * @version 2014-09-16
 */
public class MinaClientManager {
	private LinkedBlockingQueue<MinaClient> pool = new LinkedBlockingQueue<MinaClient>();

	private static final int DEF_POOL_SIZE = 200;

	/**
	 * 构造函数：初始化pool
	 */
	public MinaClientManager(int timeout) {
		String sizeString = System.getProperty(Constant.CLIENT_POOL_SIZE,
				String.valueOf(DEF_POOL_SIZE));
		for (int i = 0; i < Integer.valueOf(sizeString); ++i) {
			try {
				MinaClient minaClient = new MinaClient(timeout);
				if (minaClient != null) {
					pool.offer(minaClient);
				}
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 调MinaServer的服务
	 * 
	 * @param requestBean
	 * @return responseBean
	 */
	public ResponseBean invoke(
			coursetools.communit.helper.RequestBean requestBean) {
		MinaClient client = null;
		while (client == null) {
			try {
				client = pool.take();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			return client.invoke(requestBean);
		} catch (Exception e) {
			return null;
		} finally {
			pool.offer(client);
		}
	}
}
