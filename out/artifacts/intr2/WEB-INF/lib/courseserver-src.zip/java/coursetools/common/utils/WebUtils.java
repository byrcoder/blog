/**
 * @(#)WebUtils.java, 2011-3-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common.utils;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import outfox.account.conf.AccConst;
import outfox.account.data.user.UserInfoWritable;
import outlog.toolbox.analyzer.Filter;
import toolbox.web.ParameterUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;
import java.util.logging.Logger;

/**
 * Web相关的工具方法集合
 * @author zhaowei
 *
 */
public final class WebUtils {
    private static final String KEY_SPLITE = "_";
    private static WebUtils instance = new WebUtils();


    /**
     * 返回一个实例
     * @return
     */
    public static WebUtils getInstance() {
        return instance;
    }

    
    /**
     * 检查该请求来源是否在 {@link toolbox.flagfilter.FlagFilter} 的白名单中
     * @param request
     * @return
     */
    public static boolean inWhiteList(HttpServletRequest request) {
        return request.getAttribute("inFlagFilterWhiteList") != null;
    }

    /**
     * 获取 {@link javax.servlet.http.HttpServletRequest}的参数, 如果参数不存在, 返回默认值
     * @param request
     * @param name
     * @param defValue
     * @return
     */
    public static String getParameter(HttpServletRequest request, String name, String defValue) {
        String ret = request.getParameter(name);
        if(ret != null && ret.length() > 0) {
            return ret;
        }
        return defValue;
    }

    /**
     * 获取 {@link javax.servlet.http.HttpServletRequest}的参数, 如果参数不存在, 返回默认值
     * @param request
     * @param name
     * @param defValue
     * @return
     */
    public static double getParameter(HttpServletRequest request, String name, double defValue) {
        String ret = request.getParameter(name);
        if(ret != null) {
            try {
                return Double.parseDouble(ret);
            } catch (NumberFormatException e) {}
        }
        return defValue;
    }

    /**
     * 获取 {@link javax.servlet.http.HttpServletRequest}的参数, 如果参数不存在, 返回默认值
     * @param request
     * @param name
     * @param defValue
     * @return
     */
    public static int getParameter(HttpServletRequest request, String name, int defValue) {
        String ret = request.getParameter(name);
        if(ret != null) {
            try {
                return Integer.parseInt(ret);
            } catch (NumberFormatException e) {}
        }
        return defValue;
    }

    /**
     * 获取 {@link javax.servlet.http.HttpServletRequest}的参数, 如果参数不存在, 返回默认值
     * @param request
     * @param name
     * @param defValue
     * @return
     */
    public static long getParameter(HttpServletRequest request, String name, long defValue) {
        String ret = request.getParameter(name);
        if(ret != null) {
            try {
                return Long.parseLong(ret);
            } catch (NumberFormatException e) {}
        }
        return defValue;
    }

    /**
     * 获取 {@link javax.servlet.http.HttpServletRequest}的参数, 如果参数不存在, 返回默认值
     * @param request
     * @param delValue
     * @return
     */
    public static List<String> getPostStringList(HttpServletRequest request, List<String> delValue) {
        try {
            BufferedReader reader = request.getReader();
            if(reader != null) {
                List<String> list = new ArrayList<String>();
                String ln = null;
                while ((ln = reader.readLine()) != null) {
                    list.add(ln);
                }
                return list;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return delValue;
    }

    /**
     * 获取 {@link javax.servlet.http.HttpServletRequest}的参数, 如果参数不存在, 返回默认值
     * 没有对post过来的数据大小进行限制，这里存在安全问题
     * @param request
     * @return
     */
    public String getPostString(HttpServletRequest request) {
        try {
            BufferedReader reader = request.getReader();
            if(reader != null) {
                StringBuilder sb = new StringBuilder();
                String ln;
                while ((ln = reader.readLine()) != null) {
                    sb.append(ln);
                }
                return sb.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 记录日志
     * @param logger
     * @param request
     * @param response
     * @param elapsed 单位 ms
     */
    public static void log(Logger logger, HttpServletRequest request,
            HttpServletResponse response, long elapsed) {
        StringBuilder buffer = buildStringForLog(logger, request, response, elapsed);
        logger.info(buffer.toString());
    }
    @SuppressWarnings("rawtypes")
    private static StringBuilder buildStringForLog(Logger logger, HttpServletRequest request,
            HttpServletResponse response, long elapsed) {
        StringBuilder buffer = new StringBuilder();
        buffer.append("{");
        buffer.append("\"logTime\":").append(System.currentTimeMillis());
        buffer.append(",");


        String ip = getRequestIP(request);
//        UserCookie account = UserManager.getUserCookie(request);
//        String userId = (account == null)? "NOT_LOGIN": String.valueOf(account.getUserId());

        buffer.append("\"ip\":").append("\"").append(ip).append("\",");
        buffer.append("\"basePath\":\"").append(request.getServletPath()).append("\",");

        buffer.append("\"useragent\":\"").append(request.getHeader("User-Agent")).append("\",");
        buffer.append("\"referer\":\"").append(request.getHeader("Referer")).append("\",");
        buffer.append("\"url\":\"").append(ParameterUtils.getURL(request)).append("\",");
        buffer.append("\"elapsed\":\"").append(elapsed).append("ms").append("\",");

        for(Enumeration paramNames = request.getParameterNames(); paramNames.hasMoreElements();) {
            String paramName = (String) paramNames.nextElement();
            buffer.append("\"").append(paramName).append("\"").append(":\"")
            .append(request.getParameter(paramName)).append("\"").append(",");
        }
        buffer.append("}");
        return buffer;
    }

    public static String getRequestIP(HttpServletRequest request) {
        String ip = request.getRemoteAddr();
        if(Filter.isCompanyIp(ip)){
            ip = request.getHeader("x-forwarded-for");
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = request.getRemoteAddr();
            }
        }
        return ip;
    }

    private static HashSet<Character> INVALID_CHARS = new HashSet<Character>();

    static {
        INVALID_CHARS.add(' ');
        INVALID_CHARS.add('(');
        INVALID_CHARS.add(')');
        INVALID_CHARS.add('（');
        INVALID_CHARS.add('）');
        INVALID_CHARS.add('.');
        INVALID_CHARS.add('·');
        INVALID_CHARS.add('/');
        INVALID_CHARS.add('／');
    }

    /**
     * 对url进行UTF-8编码，并替换特殊字符
     *
     * @param url
     * @return
     */
    public static String encodeUrl(String url) {
        if (StringUtils.isEmpty(url)) {
            return "";
        }
        try {
            return URLEncoder.encode(url, "UTF-8")
                    .replace("+", "%20").replace("*", "%2A")
                    .replace("%7E", "~").replace("#", "%23");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    /**
     * 将一个url中参数部分解析出来，放在map中
     *
     * @param params    url中的参数部分
     * @return
     */
    public static Map<String, String> parseParams(String params) {
        if (StringUtils.isEmpty(params)) {
            return Collections.emptyMap();
        }
        String[] pairs = params.split("&");
        Map<String, String> res = new HashMap<String, String>(pairs.length);
        for (String p: pairs) {
            String []pair = p.split("=");
            if (pair.length != 2) {
                System.err.println("Bad param input:" + p + " of " + params);
                continue;
            }
            res.put(pair[0], pair[1]);
        }
        return res;
    }

    /**
     * build query string from params
     * @param request
     * @return
     */
    public static String getQueryStringFromParams(HttpServletRequest request) {
        StringBuilder sb = new StringBuilder();
        Enumeration<?> params = request.getParameterNames();
        while(params.hasMoreElements()) {
            String p = (String) params.nextElement();
            if (sb.length() > 0)  {
                sb.append("&");
            }
            sb.append(p).append("=").append(request.getParameter(p));
        }
        return sb.toString();
    }

    public static boolean getWithoutResult(String url) {
        boolean res = false;

        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpGet get = new HttpGet(url);
        try {
            HttpResponse response = client.execute(get);
            int code = response.getStatusLine().getStatusCode();

            res = (code == HttpStatus.SC_OK);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            get.releaseConnection();
        }
        return res;
    }



    /**
     * build request url
     * @param host
     * @param params
     * @return
     * @throws java.io.UnsupportedEncodingException
     */
    public static String buildUrl(String host, Map<String, Object> params)
            throws UnsupportedEncodingException {
        StringBuilder url = new StringBuilder(host);
        url.append("?");

        for (String k : params.keySet()) {
            String v = String.valueOf(params.get(k));

            k = URLEncoder.encode(k, "UTF-8");
            v = URLEncoder.encode(v, "UTF-8");
            url.append(k).append("=").append(v).append("&");
        }

        return url.toString();
    }

    /**
     * get user id set by account server from req
     */
    public static String getUserId(HttpServletRequest req) {
        String id = (String)req.getAttribute(coursetools.common.Constant.REQUEST_USER_ID);
        return id;
    }

    /**
     * format an String list in json format
     */
    public static String buildJSONArray(List<String> list) {
        StringBuilder sb = new StringBuilder("[");
        for (String s : list) {
            if (sb.length() == 1) {
                sb.append(s);
            } else {
                sb.append(",").append(s);
            }
        }
        return sb.append("]").toString();
    }

    public String getNickName(HttpServletRequest request) {
        Object nickObject = request.getAttribute(AccConst.ATTR_NICK_NAME);
        return (nickObject == null) ? null : nickObject.toString();
    }

    public String modifyNickName(String userNickName) {
        if (userNickName != null) {
            int index = userNickName.lastIndexOf("@");
            if (index != -1) {
                userNickName = userNickName.substring(0, index);
            }
            if (userNickName.length() > 5) {
                userNickName = userNickName.substring(0, 5) + "*";
            }
            return userNickName;
        }
        return null;
    }

    /**
     * 发在消息中心的评论
     * @param review
     * @return
     */
    public String modifyMsgReviewContent(String review, boolean needStart) {
        if (review != null && review.length() > 0) {
            if (review.length() > 30) {
                review = review.substring(0, 30) + "...";
            }
            return needStart ? ":" + review: review;
        }
        return "";
    }

    public String getNickNameByUserId(String userId) {
        if (userId != null) {
            int index = userId.indexOf("@");
            if (index != -1) {
                userId = userId.substring(0, index);
            }
            if (userId.length() > 5) {
                userId = userId.substring(0, 5) + "*";
            } else {
                userId = userId;
            }
            return userId;
        }
        return null;
    }

    /**
     * 获取用户信息
     * @param request
     * @return
     */
    public UserInfoWritable getUserInfo(HttpServletRequest request) {
        Object userInfoObject = request.getAttribute("DICT" + AccConst.ATTR_PART_USER_ID_WRITABLE);
        return (userInfoObject == null) ? null : (UserInfoWritable)userInfoObject;
    }

    public String getAvatar(HttpServletRequest request) {
        UserInfoWritable userInfo = getUserInfo(request);
        if (userInfo != null && StringUtils
                .isNotBlank(userInfo.imageUrl)) {
            return userInfo.imageUrl;
        }
        return null;
    }


    public String getMsgGroupKey(int msgType, int resourceType, int resourceId) {
        StringBuilder sb = new StringBuilder();
        sb.append(msgType).append("_").append(resourceType).append("_").append(resourceId);
        return sb.toString();
    }



    public String buildKey(String... strs) {
        StringBuilder sb = new StringBuilder();
        for (String str: strs) {
            sb.append(str).append(KEY_SPLITE);
        }
        return sb.toString();
    }
    public String buildKey(int... ints) {
        StringBuilder sb = new StringBuilder();
        for (int intEle: ints) {
            sb.append(intEle).append(KEY_SPLITE);
        }
        return sb.toString();
    }

    public String buildKey(String str, int... ints) {
        StringBuilder sb = new StringBuilder();
        sb.append(str).append(KEY_SPLITE);
        for (int intEle: ints) {
            sb.append(intEle).append(KEY_SPLITE);
        }
        return sb.toString();
    }

    public String buildKey(String str1, String str2, int... ints) {
        StringBuilder sb = new StringBuilder();
        sb.append(str1).append(KEY_SPLITE);
        sb.append(str2).append(KEY_SPLITE);
        for (int intEle: ints) {
            sb.append(intEle).append(KEY_SPLITE);
        }
        return sb.toString();
    }
}
