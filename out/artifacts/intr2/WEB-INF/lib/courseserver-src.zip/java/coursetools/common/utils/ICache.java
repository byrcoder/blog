package coursetools.common.utils;

/**
 * The interface of a cache system.
 * 
 * @author caowei, David, wanglj
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the value
 * 
 */
public interface ICache<K, V> {
    /**
     * Add a key-value pair to the cache
     * 
     * @param key  the key of the pair
     * @param data  the value of the pair
     */
    void put(K key, V data);
    
    /**
     * Fetch a value from cache
     * @param key  the key of the data to be fetched
     * @return  the value corresponding to the specified key. null if not found.
     */
    V get(K key);
    
    /**
     * Make a cached item expired
     * 
     * @param key  the key of the pair to be expired
     */
    void invalidate(K key);
    
    /**
     * Remove all data in the cache
     *
     */
    void clear();
}
