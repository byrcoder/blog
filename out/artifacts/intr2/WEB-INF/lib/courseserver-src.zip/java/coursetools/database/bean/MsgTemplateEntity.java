package coursetools.database.bean;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "msgTemplate")
public class MsgTemplateEntity {
    private Integer id;

    @javax.persistence.Column(name = "id")
    @Id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private String templateContent;

    @javax.persistence.Column(name = "templateContent")
    @Basic
    public String getTemplateContent() {
        return templateContent;
    }

    public void setTemplateContent(String templateContent) {
        this.templateContent = templateContent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MsgTemplateEntity that = (MsgTemplateEntity) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (templateContent != null ? !templateContent.equals(that.templateContent) : that.templateContent != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (templateContent != null ? templateContent.hashCode() : 0);
        return result;
    }
}
