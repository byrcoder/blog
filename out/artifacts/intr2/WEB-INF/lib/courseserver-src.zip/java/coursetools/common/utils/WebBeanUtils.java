package coursetools.common.utils;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;

public class WebBeanUtils {
    private static final String RESULT_ISSUCC = "issucc";
    private static final String RESULT_VALUE = "value";
    private static final String APPENDINFO_VALUE = "appendInfo";
    private static final String RESULT_REASON = "reason";
    public static String newSuccResult(Map<String, String> map) {
        JSONObject obj = new JSONObject();
        obj.put(RESULT_ISSUCC, 1);
        JSONObject valueObj = new JSONObject();
        for (Map.Entry<String, String> entry: map.entrySet()) {
            valueObj.put(entry.getKey(), entry.getValue());
        }
        obj.put(RESULT_VALUE, valueObj.toString());
        return obj.toString();
    }

    public static String newSuccResult(String value) {
        JSONObject obj = new JSONObject();
        obj.put(RESULT_ISSUCC, 1);
        obj.put(RESULT_VALUE, value);
        return obj.toString();
    }

    public static String newSuccResult(String value, String appendInfo) {
        JSONObject obj = new JSONObject();
        obj.put(RESULT_ISSUCC, 1);
        obj.put(RESULT_VALUE, value);
        obj.put(APPENDINFO_VALUE, appendInfo);
        return obj.toString();
    }


    public static String newFailResult(String reason) {
        JSONObject obj = new JSONObject();
        obj.put(RESULT_ISSUCC, 0);
        obj.put(RESULT_REASON, reason);
        return obj.toString();
    }

    public static coursetools.communit.helper.ResponseBean newFailInnerResponse(coursetools.communit.helper.RequestBean requestBean, String reason) {
        coursetools.communit.helper.ResponseBean responseBean = new coursetools.communit.helper.ResponseBean();
        responseBean.clientId = requestBean.clientId;
        responseBean.command = requestBean.command;
        responseBean.finishTime = System.currentTimeMillis();
        responseBean.succ = false;
        responseBean.sendTime = requestBean.sendTime;
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("reason", reason);
        responseBean.result = jsonObject.toString();
        return responseBean;
    }


    public static coursetools.communit.helper.ResponseBean newSuccInnerResponse(coursetools.communit.helper.RequestBean requestBean) {
        coursetools.communit.helper.ResponseBean responseBean = new coursetools.communit.helper.ResponseBean();
        responseBean.clientId = requestBean.clientId;
        responseBean.command = requestBean.command;
        responseBean.succ = true;
        responseBean.sendTime = requestBean.sendTime;
        return responseBean;

    }
}
