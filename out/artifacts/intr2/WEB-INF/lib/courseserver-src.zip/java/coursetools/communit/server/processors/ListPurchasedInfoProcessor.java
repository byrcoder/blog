package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.utils.WebBeanUtils;
import coursetools.communit.helper.RequestBean;
import coursetools.database.StorageService;
import coursetools.database.bean.UserPurchaseEntity;

/**
 * 获取用户的购买记录信息
 * @author zhaowei
 */
public class ListPurchasedInfoProcessor extends SimpleProcessor {

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String userId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.userId);
            if (userId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no user id in parameters");
            }
            UserPurchaseEntity userPurchase = StorageService.getInstance().getUserPurchase(userId);
            if (userPurchase == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "get data from user center error");
            }

            coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
            responseBean.finishTime = System.currentTimeMillis();
            responseBean.result = userPurchase.getPurchases();
            return responseBean;
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }
}
