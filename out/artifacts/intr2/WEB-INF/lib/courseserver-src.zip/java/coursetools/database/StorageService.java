package coursetools.database;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.utils.HashMapCache;
import coursetools.database.bean.*;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *  for dao and db cache
 */
public class StorageService {
    private static StorageService instance = new StorageService();
    private SessionManager sessionManager;
    public HashMapCache<String, UserPurchaseEntity> userPurchaseCache;//purchased record cache
    public HashMapCache<String, Set<String>> allPurchasedUserCache;//purchased record cache
    private static final String allUserPurchaseCahceKey = "allUserPurchase";

    private HashMapCache<String, UserInfoEntity> userInfoMap;
    private HashMapCache<Integer, CourseStatisticEntity> courseStatisticCache;
    public HashMapCache<String, HashMap<String, List<UserMsgEntity>>> messageCache;
    public HashMapCache<String, Integer> unReadNumCache;

    private StorageService() {
        userPurchaseCache = new HashMapCache<String, UserPurchaseEntity>(10000, 60 * 5 * 1);
        userPurchaseCache.init();

        allPurchasedUserCache = new HashMapCache<String, Set<String>>(10000, 60 * 60 * 1);
        allPurchasedUserCache.init();

        userInfoMap = new HashMapCache<String, UserInfoEntity>(10000, 60 * 60 * 1);
        userInfoMap.init();

        courseStatisticCache = new HashMapCache<Integer, CourseStatisticEntity>(10000, 60 * 60);
        courseStatisticCache.init();

        messageCache=new HashMapCache<String, HashMap<String, List<UserMsgEntity>>>(10000, 60 * 60); 
        messageCache.init();
        
        unReadNumCache = new HashMapCache<String, Integer>(10000, 60 * 60);//timeout with 1 year
        unReadNumCache.init();

        sessionManager = SessionManager.getInstance();
    }

    public static StorageService getInstance() {
        return instance;
    }

    /**
     * 清理存储层的所有的缓存
     * @return
     */
    public boolean cleanAllCache() {
        userPurchaseCache.clear();
        allPurchasedUserCache.clear();
        userInfoMap.clear();
        courseStatisticCache.clear();
        messageCache.clear();
        unReadNumCache.clear();
        return true;
    }

    /**
     * TODO
     * 目前缓存清理这块存在一些问题，由于是多台服务器，如果一个用户只映射到一台机器，那么用户的所有的缓存也在这台机器上是没有问题。
     * 这样用户购买了一个资料，那么发生购买行为的缓存会在这台机器上得到更新。
     * 但如果之后的分配规则发生了变化，分配到了别的机器上面，那么就会出现另一台机器的缓存得不到更新，取到的还是老数据
     * 目前客户端对这块逻辑进行了ip排序，所以在只有两台服务器的情况下，这种方案还是没有问题的。后续修改为多机分布式时需要重点考虑一下服务器间的数据同步,例如redis。
     *
     * @param object
     * @return
     */
    public boolean save(Object object) {
        Session session = sessionManager.getSession();
        org.hibernate.Transaction ts = session.getTransaction();
        ts.begin();
        try {
            session.saveOrUpdate(object);
            ts.commit();
            session.flush();
            if (object instanceof UserInfoEntity) {
                UserInfoEntity userInfoEntity = (UserInfoEntity)object;
                userInfoMap.put(userInfoEntity.getUserId(), userInfoEntity);
            } if (object instanceof UserPurchaseEntity) {
                UserPurchaseEntity userPurchaseEntity = (UserPurchaseEntity)object;
                userPurchaseCache.put(userPurchaseEntity.getUserId(), userPurchaseEntity);
            } if (object instanceof CourseStatisticEntity) {
                CourseStatisticEntity courseStatisticEntity = (CourseStatisticEntity)object;
                courseStatisticCache.put(courseStatisticEntity.getId(), courseStatisticEntity);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            if (ts != null) {
                ts.rollback();
            }
            return false;
        } finally {
            sessionManager.closeSession(session);
        }
    }
    public boolean delete(Object object) {
        Session session = sessionManager.getSession();
        org.hibernate.Transaction ts = session.getTransaction();
        ts.begin();
        try {
            session.delete(object);
            ts.commit();
            session.flush();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            if (ts != null) {
                ts.rollback();
            }
            return false;
        } finally {
            sessionManager.closeSession(session);
        }
    }

    /**
     * get user info from db, cache first
     * @param userId
     * @return
     */
    public UserInfoEntity getUserInfo(String userId) {
        UserInfoEntity userInfoEntity = userInfoMap.get(userId);
        if (userInfoEntity == null) {
            Session session = sessionManager.getSession();
            try {
                Criteria criteria = session.createCriteria(UserInfoEntity.class);
                criteria.add(Restrictions.eq("userId", userId));
                Object obj = criteria.uniqueResult();
                if (obj != null) {
                    userInfoEntity = (UserInfoEntity)obj;
                    userInfoMap.put(userId, userInfoEntity);
                    return userInfoEntity;
                } else {
                    return null;
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
                return null;
            } finally {
                sessionManager.closeSession(session);
            }
        } else {
            return userInfoEntity;
        }
    }

    public UserPurchaseEntity getUserPurchase(String userId) {
        UserPurchaseEntity userPurchaseEntity = userPurchaseCache.get(userId);
        if (userPurchaseEntity == null) {
            Session session = sessionManager.getSession();
            try {
                Criteria criteria = session.createCriteria(UserPurchaseEntity.class);
                criteria.add(Restrictions.eq("userId", userId));
                Object obj = criteria.uniqueResult();
                if (obj != null) {
                    userPurchaseEntity = (UserPurchaseEntity)obj;
                    userPurchaseCache.put(userId, userPurchaseEntity);
                    return userPurchaseEntity;
                }
                return null;
            } catch (NullPointerException e) {
                e.printStackTrace();
                return null;
            } finally {
                sessionManager.closeSession(session);
            }
        } else {
            return userPurchaseEntity;
        }
    }

    /**
     * 加载买了某个课的所有的用户列表
     * @param courseId
     * @return
     */
    public Set<String> getAllUsersByCourseId(String courseId) {
        //先查缓存中是否有,毕竟扫一次数据库表操作还是非常巨大的。
        Set<String> allUsers = allPurchasedUserCache.get(courseId);
        if (allUsers != null) {
            return allUsers;
        }
        Session session = sessionManager.getSession();
        try {
            Criteria criteria = session.createCriteria(UserPurchaseEntity.class);
            List<UserPurchaseEntity> allUserPurchase = criteria.list();
            if (allUserPurchase != null) {
                for (UserPurchaseEntity userPurchaseEntity: allUserPurchase) {
                    try {
                        String list = userPurchaseEntity.getPurchases();
                        JSONArray jsonArray = JSON.parseArray(list);
                        for (int i = 0 ; i < jsonArray.size();i++) {
                            String one = jsonArray.getString(i);
                            JSONObject object = JSON.parseObject(one);
                            String itemId = object.getString("itemId");
                            String userId = object.getString("userId");
                            Set<String> allIds = allPurchasedUserCache.get(itemId);
                            if (allIds == null) {
                                allIds = new HashSet<String>();
                                allPurchasedUserCache.put(itemId, allIds);
                            }
                            allIds.add(userId);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        continue;
                    }
                }
            }
            return allPurchasedUserCache.get(courseId);
        } catch (NullPointerException e) {
            e.printStackTrace();
            return null;
        } finally {
            sessionManager.closeSession(session);
        }
    }

    public List<UserPurchaseEntity> getAllUserPurchase() {
        Session session = sessionManager.getSession();
        try {
            Criteria criteria = session.createCriteria(UserPurchaseEntity.class);
            return criteria.list();
        } catch (NullPointerException e) {
            e.printStackTrace();
            return null;
        } finally {
            sessionManager.closeSession(session);
        }
    }

    public CourseStatisticEntity getCourseStatistic(Integer courseId) {
        CourseStatisticEntity courseStatisticEntity = courseStatisticCache.get(courseId);
        if (courseStatisticEntity == null) {
            Session session = sessionManager.getSession();
            try {
                Criteria criteria = session.createCriteria(CourseStatisticEntity.class);
                criteria.add(Restrictions.eq("id", courseId));
                Object obj = criteria.uniqueResult();
                if (obj != null) {
                    courseStatisticEntity = (CourseStatisticEntity)obj;
                    courseStatisticCache.put(courseStatisticEntity.getId(), courseStatisticEntity);
                    return courseStatisticEntity;
                }
                return null;
            } catch (NullPointerException e) {
                e.printStackTrace();
                return null;
            } finally {
                sessionManager.closeSession(session);
            }
        } else {
            return courseStatisticEntity;
        }
    }
}
