package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.utils.WebBeanUtils;
import coursetools.database.StorageService;
import coursetools.database.bean.UserInfoEntity;

/**
 * 用于立即清理后台的所有的缓存
 * @author zhaowei
 */
public class CleanCacheProcessor extends SimpleProcessor {
    private StorageService storageService = StorageService.getInstance();

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String userId = requestBean.parameters.getString(coursetools.communit.helper.CommuniConstants.userId);
            if (userId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no user id in parameters");
            }
            storageService.cleanAllCache();
            return WebBeanUtils.newSuccInnerResponse(requestBean);
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }
}
