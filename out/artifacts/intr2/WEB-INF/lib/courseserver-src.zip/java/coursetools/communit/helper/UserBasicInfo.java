package coursetools.communit.helper;

/**
 * 用户基本信息
 * @author zhaowei
 * @version 2014-09-16
 */
public class UserBasicInfo {
    public String userId;
    public String head;

}
