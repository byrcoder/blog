/**
 * @(#)Config.java, 2012-12-4. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common;
import org.apache.commons.configuration.Configuration;

/**
 * 全局配置
 * 
 * @author zhaowei
 */
public final class Config {
    
    //如果之前已要加载，那么下次不再加载
    private static boolean isInited = false;
    
    private static Configuration conf;

    public static String requestLogHost = "nb384:2325,nb374:2325";

    //    public static final String USER_SERVER_HOST = "nc021x.corp.youdao.com";
    public static String user_server_host;
    public static int user_server_port;
    public static String hibernatePath;
    /**
     *
     * 从一个Configuration对象中load配置信息
     *
     * @param conf
     */
    public static void init(Configuration conf) {
        Config.conf = conf;
        user_server_host = conf.getString("service.user_server_host");
        user_server_port = conf.getInt("service.user_server_port");
        hibernatePath = conf.getString("service.hibernatePath");
        if (hibernatePath == null || hibernatePath.indexOf("hibernate.cfg.xml")  == -1) {
            System.out.println("your should set hibernate path first!!!!! Please set it as your local machine dir in file conf/course-default.xml");
            System.exit(1);
        }
    }
}