package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.Config;
import coursetools.common.utils.WebBeanUtils;
import coursetools.communit.helper.CommuniConstants;
import coursetools.communit.helper.PurchaseRecord;
import coursetools.communit.helper.UserProfileUtils;
import coursetools.database.StorageService;
import coursetools.database.bean.CourseStatisticEntity;
import coursetools.database.bean.UserPurchaseEntity;
import org.apache.commons.configuration.Configuration;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 增加用户的购买记录信息
 * 
 * @author zhaowei
 */
public class AddPurchasedInfoProcessor extends SimpleProcessor {
    private StorageService storageService = StorageService.getInstance();

    private static Map<String, String> map = new HashMap<String, String>();

    public AddPurchasedInfoProcessor() {
        map.put("b9dbe51b8c81b1c15110a3556900c3f20", "601");
        map.put("bf0af85f6d52ceb9fb9103c259bc4a192", "602");
        map.put("be4a95579875efd441de9831d01cad3a2", "603");
        map.put("b01711c5ab0abc698a6f5ca4a7eb7dbb9", "616");
        map.put("b87c16ea3f35219705fdae17eac43cb8f", "615");
        map.put("b87ab6b680d194baa92fa50afac616cea", "613");
        map.put("b75ba9b500c033516606020b08667262c", "622");
        map.put("b5b6b75ecc96301a9576f14c1a406e24b", "642");
        map.put("b99eb0f9ce77b9300d76c12bd8f1402b6", "704");
        map.put("b5d8eb595b22fed92fcec796f9d10f3ab", "703");
        map.put("bca83d3967a0d49c38d717463644e7de0", "705");
    }

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
        try {
            String purchase = requestBean.parameters.getString(CommuniConstants.purchase);
            if (purchase == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean, "no record info in parameters");
            }
            try {
                coursetools.communit.helper.PurchaseRecord purchaseRecord = coursetools.communit.helper.PurchaseRecord.fromJson(purchase);
                if (purchaseRecord != null) {
                    if (purchaseRecord.time == null) {
                        purchaseRecord.time = String.valueOf(System.currentTimeMillis());
                    }
                } else {
                    return WebBeanUtils.newFailInnerResponse(requestBean, "purchase entity fromat is wrong");
                }
                // modify statistic of course's buy num,inner add doesnot modify
                if (purchaseRecord.extendInfo == null || !purchaseRecord.extendInfo.equals(CommuniConstants.inner)) {
                    try {
                        String courseId = purchaseRecord.itemId;
                        try {
                            Integer courseIdInt = Integer.parseInt(courseId);
                            try {
                                modifyStatistic(courseIdInt);
                            } catch (Exception e) {
                                e.printStackTrace();
                                System.out.println(e.getMessage());
                            }
                        } catch (Exception e) {
                            String courseIdInt = map.get(courseId);
                            if (courseIdInt != null) {
                                purchaseRecord.itemId = courseIdInt;
                                modifyStatistic(Integer.parseInt(courseIdInt));
                            } else {
                                e.printStackTrace();
                                System.out.println(e.getMessage());
                                return WebBeanUtils.newFailInnerResponse(requestBean, "not int type course id");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        e.printStackTrace();
                    }
                }

                String userId = purchaseRecord.userId;
                UserPurchaseEntity userPurchaseEntity = storageService.getUserPurchase(userId);

                if (userPurchaseEntity == null) {
                    userPurchaseEntity = new UserPurchaseEntity();
                    userPurchaseEntity.setUserId(userId);
                }
                JSONArray jsonArray = null;
                if (userPurchaseEntity.getPurchases() != null && userPurchaseEntity.getPurchases().length() > 0) {
                    try {
                        jsonArray = JSON.parseArray(userPurchaseEntity.getPurchases());
                    } catch (Exception e) {
                        jsonArray = new JSONArray();
                    }
                } else {
                    jsonArray = new JSONArray();
                }
                jsonArray.add(JSON.toJSONString(purchaseRecord));
                userPurchaseEntity.setPurchases(jsonArray.toJSONString());
                storageService.save(userPurchaseEntity);

                coursetools.communit.helper.ResponseBean responseBean;
                UserProfileUtils.getInstance().addPurchaseRecord(purchaseRecord);
                responseBean = WebBeanUtils.newSuccInnerResponse(requestBean);
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } catch (Exception e) {
                e.printStackTrace();
                return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean, e.getMessage());
        }
    }

    private void modifyStatistic(int courseId) {
        CourseStatisticEntity courseStatisticEntity = storageService.getCourseStatistic(courseId);
        if (courseStatisticEntity == null) {
            courseStatisticEntity = new CourseStatisticEntity();
            courseStatisticEntity.setId(courseId);
            courseStatisticEntity.setBuyNum(0);
        }
        courseStatisticEntity.setBuyNum(courseStatisticEntity.getBuyNum() + 1);
        storageService.save(courseStatisticEntity);
    }
}
