/**
 * @(#)SmsInfoTask.java, 2013-5-21. 
 * 
 * Copyright 2013 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common.utils.notify;

import coursetools.common.utils.QxtSmsHelperForCourse;


/**
 * 发送短信通知的工具类
 * 
 * @author qipeng
 *
 */
public class SmsInfoTask implements IInfoTask {

    public final static String TASK_TYPE = "SMS";
    
    private QxtSmsHelperForCourse smsSender;
    
    private SmsInfo smsInfo;
    
    public SmsInfoTask(SmsInfo smsInfo) {
        this.smsInfo = smsInfo;
    }
    
    @Override
    public String getType() {
        return TASK_TYPE;
    }
    
    @Override
    public boolean send() {
        return smsSender.sendSMS(smsInfo.getFrom(), 
                smsInfo.getTo(), smsInfo.getMessage());
    }

    /**
     * @param smsSender the smsSender to set
     */
    public void setSmsSender(QxtSmsHelperForCourse smsSender) {
        this.smsSender = smsSender;
    }
    
    public static class SmsInfo {
        
        private String from;
        
        private String to;
        
        private String message;

        /**
         * @param from
         * @param to
         * @param message
         */
        public SmsInfo(String from, String to, String message) {
            this.from = from;
            this.to = to;
            this.message = message;
        }
        
        /**
         * @param to
         * @param message
         */
        public SmsInfo(String to, String message) {
            this.from = to;
            this.to = to;
            this.message = message;
        }

        /**
         * @return the from
         */
        public String getFrom() {
            return from;
        }

        /**
         * @return the to
         */
        public String getTo() {
            return to;
        }

        /**
         * @return the message
         */
        public String getMessage() {
            return message;
        }
    }
}
