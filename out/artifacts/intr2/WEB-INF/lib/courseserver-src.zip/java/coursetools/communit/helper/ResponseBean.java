package coursetools.communit.helper;

import com.alibaba.fastjson.JSON;

/**
 * 返回给客户端的响应
 * @author zhaowei
 *
 */
public class ResponseBean {
    public String clientId;
    public long sendTime;
    public long finishTime;
    public long dealTime;
    public long recvTime;
    public String command;
    public boolean succ = false;
    public String result;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

    public static ResponseBean fromString(String s) {
        if (s == null) {
            return null;
        }
        try {
            return JSON.parseObject(s, ResponseBean.class);
        } catch (Exception e) {
            return null;
        }
    }
}
