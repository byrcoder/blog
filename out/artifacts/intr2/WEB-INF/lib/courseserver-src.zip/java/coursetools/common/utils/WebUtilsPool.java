package coursetools.common.utils;

/**
 */
public class WebUtilsPool {
    private static ThreadLocal<WebUtils> utilsPool = new ThreadLocal<WebUtils>();

    public static WebUtils getWebUtils() {
        WebUtils webUtils = utilsPool.get();
        if (webUtils == null) {
            utilsPool.set(webUtils = new WebUtils());
        }
        return webUtils;
    }
}
