package coursetools.database.bean;
import java.sql.Timestamp;

public class UserMsgEntity {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String userId;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private boolean msgRead;

    public boolean getMsgRead() {
        return msgRead;
    }

    public void setMsgRead(boolean msgRead) {
        this.msgRead = msgRead;
    }

    private Timestamp sendTime;

    public Timestamp getSendTime() {
        return sendTime;
    }

    public void setSendTime(Timestamp sendTime) {
        this.sendTime = sendTime;
    }

    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private String simpleContent;

    public String getSimpleContent() {
        return simpleContent;
    }

    public void setSimpleContent(String simpleContent) {
        this.simpleContent = simpleContent;
    }

    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    private String sender;

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    private String msgAvatar;

    public String getMsgAvatar() {
        return msgAvatar;
    }

    public void setMsgAvatar(String msgAvatar) {
        this.msgAvatar = msgAvatar;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserMsgEntity that = (UserMsgEntity) o;

        if (id != that.id) return false;
        if (msgRead != that.msgRead) return false;
        if (content != null ? !content.equals(that.content) : that.content != null) return false;
        if (msgAvatar != null ? !msgAvatar.equals(that.msgAvatar) : that.msgAvatar != null) return false;
        if (sendTime != null ? !sendTime.equals(that.sendTime) : that.sendTime != null) return false;
        if (sender != null ? !sender.equals(that.sender) : that.sender != null) return false;
        if (simpleContent != null ? !simpleContent.equals(that.simpleContent) : that.simpleContent != null)
            return false;
        if (title != null ? !title.equals(that.title) : that.title != null) return false;
        if (url != null ? !url.equals(that.url) : that.url != null) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result =  (id != null ? id.hashCode() : 0);;
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (sendTime != null ? sendTime.hashCode() : 0);
        return result;
    }
}
