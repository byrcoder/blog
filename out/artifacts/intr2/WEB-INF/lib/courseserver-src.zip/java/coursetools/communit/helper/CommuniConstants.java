package coursetools.communit.helper;

/**
 * mina客户端的管理器
 * @author zhaowei
 * @version 2014-09-16
 */
public class CommuniConstants {


    //通信命令接口
    public static final String purchasedList = "purchasedList";
    public static final String addPurchase = "addPurchase";
    public static final String isContain = "isContainPurchase";

    public static final String userBasicProfileOp = "userBasicProfileOp";//对用户基本信息进行操作
    public static final String updateBasicProfile = "updateBasicProfile";//增加或者修改用户的基本信息的操作，是userBasicProfileOp的子命令
    public static final String getBasicProfile = "getBasicProfile";//获取用户的基本信息的操作，是userBasicProfileOp的子命令

    public static final String addressInfo="addressInfo";//用户地址信息
    public static final String addUserAddress="addUserAddress";//添加用户的地址信息
    public static final String updateUserAddress="updateUserAddress";//更新用户的地址信息
    public static final String deleteUserAddress="deleteUserAddress";//删除用户的地址信息
    public static final String getUserAllAddress="getUserAllAddress";//获取用户的所有地址信息

    public static final String userMsgOp = "userMsgOp";//用户操作消息
    public static final String addMsg = "addMsg";//增加一条消息, 用户操作消息的子命令
    public static final String getUnReadMsgNum = "getUnReadMsgNum";//获取未读的消息数, 用户操作消息的子命令
    public static final String getUnReadMsg = "getUnReadMsg";//获取未读消息, 用户操作消息的子命令
    public static final String getMsg = "getMsg";//获取已读和未读消息, 用户操作消息的子命令
    public static final String readMsg = "readMsg";//阅读了一条消息, 用户操作消息的子命令
    public static final String getCourseNum = "getCourseNum";//阅读了一条消息, 用户操作消息的子命令

    public static final String userCourseOp = "userCourseOp";//用户操作消息
    public static final String getStudyingCourseNum = "getStudyingCourseNum";//获取用户当前的课程数，用户操作消息的子命令
    public static final String addStudyingCourse = "addStudyingCourse";//增加一个用户正在学习的课程，用户操作消息的子命令
    public static final String getStudyingCourse = "getStudyingCourse";//获取一个用户当前正在学习的所有课程，用户操作消息的子命令
    public static final String delStudyingCourse = "delStudyingCourse";//删除一个用户当前的课程，用户操作消息的子命令
    public static final String addStudyingProgress = "addStudyingProgress";//增加一个用户当前的课程，用户操作消息的子命令
    public static final String getStudyingProgress = "getStudyingProgress";//获取一个用户所有的课程的课时进度，用户操作消息的子命令
    public static final String getLessonStudyingProgress = "getLessonStudyingProgress";//获取一个用户某个课程的课时进度，用户操作消息的子命令
    public static final String getCourseUnlockLesson = "getCourseUnlockLesson";//获取一个用户某个课程未锁定录播的子命令
    public static final String addCourseUnlockLesson = "addCourseUnlockLesson";//添加一个用户某个课程未锁定录播的子命令

    public static final String getPurchaseNumOp = "getPurchaseNumOp";//获取购买了某个资料的用户数
    public static final String getPurchasedUsers = "getPurchasedUsers";//获取购买了某个资料的所有的用户的id
    public static final String getArrayPurchaseNumOp = "getArrayPurchaseNumOp";//获取批量课程资料购买的用户数

    public static final String cleanCache = "cleanCache";//内部消息，用于清理后台的所有的缓存

    //通信参数接口
    public static final String purchase = "purchase";
    public static final String userId = "userId";
    public static final String itemId = "itemId";
    public static final String lessonId = "lessonId";
    public static final String time = "time";
    public static final String opName = "opName";
    public static final String key = "key";
    public static final String value = "value";
    public static final String start = "start";
    public static final String len = "len";
    public static final String msgContent = "msgContent";
    public static final String msgSimpleContent = "msgSimpleContent";
    public static final String msgTitle = "msgTitle";
    public static final String msgUrl = "msgUrl";
    public static final String msgSender = "msgSender";
    public static final String msgAvatar = "msgAvatar";
    public static final String msgId = "msgId";
    public static final String endtime = "endtime";
    public static final String sendtime = "sendtime";
    public static final String templateValue = "templateValue";
    public static final String templateId = "templateId";
    public static final String msgType = "msgType";
    public static final String msgNickName = "msgNickName";
    public static final String msgCourseTitle = "msgCourseTitle";
    public static final String msgCourseId = "msgCourseId";
    public static final String msgStartTime = "msgStartTime";
    public static final String msgEndTime = "msgEndTime";
    public static final String defaultAddress="defaultAddress";//设置默认
    public static final String modAddress="modAddress";//修改地址
    public static final String delAddress="delAddress";//删除地址

    //其它参数接口
    public static final String inner="inner";//参数inner标示是内网添加用户
    public static final String addressId="id";
    public static final String addressDefaultTag="default";
}
