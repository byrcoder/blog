package coursetools.communit.log;

import coursetools.common.Config;
import outlog.logging.RemoteLogger;
import outlog.toolbox.Clock;
import outlog.toolbox.analyzer.Filter;
import toolbox.misc.LogFormatter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
* 本类copy自 outlog.http.RequestLogger,区别是用于解决不加visibleAttributes
* 由于outlog.http.RequestLogger不能使用继承来扩展，所以直接复制代码，另写一个
*
* @author zhaowei
*
*/
public class CourseRequestLogger {
    private static final Logger LOG = LogFormatter.getLogger(CourseRequestLogger.class.getName());
    private String userIdCookieName = "OUTFOX_SEARCH_USER_ID";
    private String userIdAttrName = "outlog.http.userid";
    private final Random rand = new Random();
    private static final int thirtyYears = 3600 * 24 * 365 * 30;
    private String productName = "CourseUserServer";
    private String userNameAttributeName = "__email__";
    private String domain = null;
    private String path = null;
    private String sinkAddrs = Config.requestLogHost;

    private final static int DEFAULT_QUEUE_SIZE = 8 << 10;
    private int sendQueueMaxSize = DEFAULT_QUEUE_SIZE;

    public CourseRequestLogger() {
        this.init();
    }


    /**
     * Get the userid cookie from the request. Return null if not exist.
     * @param req
     * @return
     */
    public Cookie getUserIdCookie(HttpServletRequest req) {
        Cookie[] cookies = req.getCookies();
        Cookie cookie = null;
        if(cookies != null) {
            for(Cookie c : cookies) {
                if(userIdCookieName.equals(c.getName())) {
                    cookie = c;
                    break;
                }
            }
        }
        if (cookie == null) {
            Object userIdCookie = req.getAttribute(userIdAttrName);
            if (userIdCookie != null)
                return (Cookie) userIdCookie;
        }
        return cookie;
    }
    /**
     * Generate a userid cookie.
     * that needs to be written in the response.
     * @param req
     * @return
     */
    public Cookie generateUserIdCookie(HttpServletRequest req) {
        Cookie cookie = new Cookie(this.userIdCookieName, rand.nextInt() + "@" + req.getRemoteAddr());
        cookie.setMaxAge(thirtyYears);
        if(domain != null) {
            cookie.setDomain(domain);
            if (path != null && !"".equals(path))
                cookie.setPath(path);
        }
        req.setAttribute(userIdAttrName, cookie);
        return cookie;
    }
    public void setCookieDomain(String domain) {
        this.domain = domain;
    }
    public void setPath(String path){
        this.path = path;
    }

    public void setSendQueueMaxSize(int size) {
        sendQueueMaxSize = size;
    }

    public void init() {
        if(sinkAddrs == null) {
            throw new RuntimeException("Sink address is not set");
        }
        RemoteLogger logger = new RemoteLogger(productName, sinkAddrs, sendQueueMaxSize);
        remoteLogger = logger;
        LOG.log(Level.INFO, "[requestLogger] requestLogger initialized. productName : "
                + productName + " sinkAddr : " + sinkAddrs);
    }

    public void setProductName(String name) {
        this.productName = name;
    }


    private RemoteLogger remoteLogger = null;
    /**
     * Set the address of logging sink. Supports multiple addresses, like "host1:2323,host2:2323,host3:4848".
     * When more than one sinks are given, the logs will be sent to the first server initially.
     * If the current server fails, will select next server in a round-robin manner.
     */
    public synchronized void setSinkAddr(String addrString) {
        this.sinkAddrs = addrString;
    }

    private static void append(StringBuilder buffer, String key, String value) {
        buffer.append("\t");
        buffer.append(key);
        buffer.append("=");
        buffer.append(value);
    }

    public void enqueue(String log) {
        if (remoteLogger != null) {
            remoteLogger.log(log);
        } else {
            LOG.warning("RequestLogger is not initialized");
        }
    }



    public void log(HttpServletRequest req, HttpServletResponse res) {
        log(productName, null, null, req, res, null);
    }

    public void log(String category, HttpServletRequest req, HttpServletResponse res) {
        log(category, null, null, req, res, null);
    }

    /**
     * Log an HTTP request "AS IS".
     * @param category
     * @param req
     * @param res
     * @see outlog.http.RequestLogger#log(String, String, String, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, String)
     */
    public void log(String category, HttpServletRequest req, HttpServletResponse res, String message) {
        log(category, null, null, req, res, message);
    }

    public void log(String category, String serverURLEncoding, String urlEncoding, HttpServletRequest req, HttpServletResponse res) {
        log(category, serverURLEncoding, urlEncoding, req, res, null);
    }
    private static String escape(String text) {
        if(text == null) {
            return "NULL";
        }
        int length = text.length();
        StringBuilder buffer = new StringBuilder(length);
        for(int i = 0; i < length; i++) {
            char ch = text.charAt(i);
            switch(ch) {
                case '\t': buffer.append("\\t"); break;
                case '\n': buffer.append("\\n"); break;
                case '\r': buffer.append("\\r"); break;
                case '[': buffer.append("\\["); break;
                case ']': buffer.append("\\]"); break;
                case '\\': buffer.append("\\\\"); break;
                default: buffer.append(ch);
            }
        }
        return buffer.toString();
    }

    /**
     * direct write log
     */
    public void log( String log) {
        enqueue(log);
    }

    /**
     * Log an HTTP request, recording the user_id in cookie, user's IP and the request's all parameters.
     * Use this method if the parameters in the request is not corrected decoded and needs a transcode.
     * This method will get the parameters by translate them from <b>serverURLEncoding</b> to <b>urlEncoding</b>.
     * @param category
     * @param serverURLEncoding the default URL encoding of the web server
     * @param urlEncoding the URL encoding of this request
     * @param req the HttpServletRequest
     * @param res the HttpServletResponse
     * @param message any additional messages you want to log. It can be null, which means no message
     */
    @SuppressWarnings("rawtypes")
    public void log(String category, String serverURLEncoding, String urlEncoding, HttpServletRequest req, HttpServletResponse res, String message) {
        StringBuilder buffer = new StringBuilder();
        buffer.append(Clock.currentTimeMillis());
        buffer.append("\t");

        buffer.append(category);
        for( Enumeration attrNames = req.getParameterNames(); attrNames.hasMoreElements(); ) {
            String attrName = (String) attrNames.nextElement();
            String value = req.getParameter(attrName);
            try {
                if(serverURLEncoding != null && urlEncoding != null) {
                    value = new String(value.getBytes(serverURLEncoding), urlEncoding);
                }
                append(buffer, escape(attrName), escape(value));
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception", e);
            }
        }
//        for( Enumeration attrNames = req.getAttributeNames(); attrNames.hasMoreElements(); ) {
//            String attrName = (String) attrNames.nextElement();
//            if (attrName.contains(".")) {
//                continue;
//            }
//            buffer.append("\t[@").append(escape(attrName)).append("=")
//                    .append(escape(req.getAttribute(attrName).toString())).append("]");
//        }

        String ip = getRequestIP(req);
        buffer.append("\t[ip=" + ip + "]");
        Cookie cookie = getUserIdCookie(req);
        if(cookie == null) {
            cookie = generateUserIdCookie(req);
//            res.addCookie(cookie);
        }
        buffer.append("\t[basePath=" + req.getServletPath() + "]");

        buffer.append("\t[userid="+escape(cookie.getValue())+"]");

        Object userName = req.getAttribute(userNameAttributeName);
        buffer.append("\t[username=" + escape(userName == null ? null : userName.toString()) + "]");
        buffer.append("\t[useragent="+ escape(req.getHeader("User-Agent"))+"]");
        buffer.append("\t[referer=" + escape(req.getHeader("Referer")) + "]");
        buffer.append("\t").append(message);

        enqueue(buffer.toString());
    }

    protected String getRequestIP(HttpServletRequest request) {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String ip = httpRequest.getRemoteAddr();
        if(Filter.isCompanyIp(ip)){
            ip = httpRequest.getHeader("x-forwarded-for");
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = httpRequest.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = httpRequest.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = httpRequest.getRemoteAddr();
            }
        }
        return ip;
    }
}
