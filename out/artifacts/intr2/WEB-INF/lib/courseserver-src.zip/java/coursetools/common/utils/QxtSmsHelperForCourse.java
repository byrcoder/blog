package coursetools.common.utils;
/** QxtSmsHelper */

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;

/**
 * 企信通帮助类
 * <li>需要初始化: 调用setGroup和init</li>
 */
public class QxtSmsHelperForCourse {

    //-- public finals --//
    //-- private finals --//

    //-- properties --//

    private HttpClient client = null;

    private int timeout = 4000;
    private int connection = 10;

    private String host = "smsknl.163.com";
    private int port = 8089;
    private String path = "/servlet/CorpIdentifyNotCheck";
    private String group = null;

    //-- constructors --//

    /** 初始化 */
    public void init() {
        HttpConnectionManager connectionManager = new MultiThreadedHttpConnectionManager();

        HttpConnectionManagerParams params = connectionManager.getParams();
        params.setConnectionTimeout(timeout);
        params.setDefaultMaxConnectionsPerHost(connection);
        params.setMaxTotalConnections(connection);
        params.setTcpNoDelay(false);

        client = new HttpClient(connectionManager);
        client.getHostConfiguration().setHost(host, port);
    }

    //-- destructors --//
    //-- implements --//
    //-- un-implements --//
    //-- methods --//

    /**
     * 相当于调用sendSMS(to, to, message)
     *
     * @see #sendSMS(String, String, String)
     */
    public boolean sendSMS(String to, String message) {
        return sendSMS(to, to, message);
    }

    /**
     * 发送短信给用户
     * <li>需要自行保证参数正确性</li>
     * <li>需要自行控制字数(160字节, 80汉字)</li>
     * <li>运营商可能在message后添加内容</li>
     *
     * @param from 发信人手机号(用户不可见, 一个from每天最多发送100条短信)
     * @param to 收信人手机号
     * @param message 发信内容
     * @return 发信成功或失败
     */
    public boolean sendSMS(String from, String to, String message) {
        String result = sendSmsWithResult(from, to, message);
        return result != null && "ok".equals(result);
    }

    public String sendSmsWithResult(String from, String to, String message) {
        String sendMessage = null;
        try {
            sendMessage = toGbkHexString(message);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return "toGbkHexString failed: " + message;        }

        String query = path
                + "?phone=" + to
                + "&frmphone=" + from
                + "&msgprop=" + group
                + "&message=" + sendMessage
                + "&corpinfo=1";
        System.out.println("http://" + host + ":" + port + query);
        GetMethod method = new GetMethod(query);
        method.addRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        try {
            client.executeMethod(method);

            InputStream is = method.getResponseBodyAsStream();
            String result = IOUtils.toString(is, "utf-8");
            System.out.println(result);
            return result.trim().toLowerCase();
        } catch (Exception e) {
            e.printStackTrace();
            return ("executeMethod failed");
        } finally {
            method.releaseConnection();
        }
    }

    //-- functions --//

    /**
     * 获得ASCII数组的十六进制形式, 如:
     * <li>[0, 255] -> "00FF"</li>
     * <li>['0', 'a'] -> "3041</li>
     */
    private static String generateHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            int i = (b < 0) ? (b + 256) : b;
            byte[] pair = new byte[2];
            pair[0] = (byte) getHexForm(i / 16); // 高4位
            pair[1] = (byte) getHexForm(i % 16); // 低4位

            sb.append(new String(pair));
        }
        return sb.toString();
    }

    private static final byte UPPER_KEY = 65; // 65(0x41)就是'A'
    private static final byte NUMBER_KEY = 48; // 48(0x30)就是'0'

    /**
     * 获得数字(0~15)的十六进制表示(大写)
     * <li>1(0x1) -> 十六进制表示(大写): 1 -> '1'(49 -> 0x31)</li>
     * <li>11(0xb) -> 十六进制表示(大写): B -> 'B'(66 -> 0x42)</li>
     */
    private static int getHexForm(int b) {
        if (b >= 10) {
            return b + UPPER_KEY - 10;
        } else {
            return b + NUMBER_KEY;
        }
    }

    //-- utils --//

    public static String toGbkHexString(String s) throws UnsupportedEncodingException {
        byte[] bytes = s.getBytes("gbk");
        return generateHexString(bytes);
    }

    //-- getters & setters --//

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public void setConnection(int connection) {
        this.connection = connection;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    //-- iWritables --//
    //-- inner classes --//
}
