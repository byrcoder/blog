package coursetools.communit.server.processors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.utils.HashMapCache;
import coursetools.common.utils.WebBeanUtils;
import coursetools.communit.helper.CommuniConstants;
import coursetools.database.StorageService;
import coursetools.database.bean.UserInfoEntity;

/**
 * 用户课程情况处理工具
 * 
 * @author zhaowei
 */
public class UserCourseProcessor extends SimpleProcessor {
    private StorageService storageService = StorageService.getInstance();

    private HashMapCache<String, String> progressCache;

    public UserCourseProcessor() {
        progressCache = new HashMapCache<String, String>(10000,
                60 * 60 * 24 * 10);
        progressCache.init();
    }

    @Override
    public coursetools.communit.helper.ResponseBean handle(
            coursetools.communit.helper.RequestBean requestBean) {
        try {
            String userId = requestBean.parameters
                    .getString(CommuniConstants.userId);
            if (userId == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no user id in parameters");
            }
            String opName = requestBean.parameters
                    .getString(CommuniConstants.opName);
            if (opName == null) {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no special operation name");
            }
            if (opName.equals(CommuniConstants.addStudyingCourse)) {
                return addStudyingCourse(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getStudyingCourseNum)) {
                return getStudyingCourseNum(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getStudyingCourse)) {
                return getStudyingCourse(userId, requestBean);
            } else if (opName.equals(CommuniConstants.delStudyingCourse)) {
                return delStudyingCourse(userId, requestBean);
            } else if (opName.equals(CommuniConstants.addStudyingProgress)) {
                return addStudyingProgress(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getStudyingProgress)) {
                return getStudyingProgress(userId, requestBean);
            } else if (opName
                    .equals(CommuniConstants.getLessonStudyingProgress)) {
                return getLessonStudyingProgress(userId, requestBean);
            } else if (opName.equals(CommuniConstants.getCourseUnlockLesson)) {
                return getCourseUnlockLesson(userId, requestBean);
            } else if (opName.equals(CommuniConstants.addCourseUnlockLesson)) {
                return addCourseUnlockLesson(userId, requestBean);
            }

            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "unknown sub command");
        } catch (Exception e) {
            e.printStackTrace();
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 获取某个用户某个课的课时的进度
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean getLessonStudyingProgress(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        String courseId = requestBean.parameters
                .getString(CommuniConstants.itemId);
        if (courseId == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "no CourseId in parameter");
        }
        String keyCached = userId + courseId;
        String resultCached = progressCache.get(keyCached);
        if (resultCached != null) {

        }
        try {
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                String lessonProgressStr = userInfoEntity.getLessonProgress();
                JSONObject studyCourse;
                if (lessonProgressStr == null) {
                    responseBean.result = "{}";
                } else {
                    try {
                        JSONObject progressJson = JSON
                                .parseObject(lessonProgressStr);
                        JSONObject result = new JSONObject();
                        for (String key: progressJson.keySet()) {
                            if (key.startsWith(courseId)) {
                                Long value = progressJson.getLongValue(key);
                                result.put(key, value);
                            }
                        }
                        responseBean.result = result.toJSONString();
                    } catch (Exception e) {
                        System.out
                                .println("studying record parse error, reset as null");
                        responseBean.result = "{}";
                    }
                }
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 获取某个用户全部课的课时的进度
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean getStudyingProgress(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        try {
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                String lessonProgressStr = userInfoEntity.getLessonProgress();
                JSONObject studyCourse;
                if (lessonProgressStr == null) {
                    responseBean.result = "{}";
                }
                try {
                    responseBean.result = lessonProgressStr;
                } catch (Exception e) {
                    System.out
                            .println("studying record parse error, reset as null");
                    responseBean.result = "{}";
                }
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 添加一个正在学习的课程数
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean addStudyingProgress(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        String courseId = requestBean.parameters
                .getString(CommuniConstants.itemId);
        if (courseId == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "no CourseId in parameter");
        }
        String lessonId = requestBean.parameters
                .getString(CommuniConstants.lessonId);
        if (lessonId == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "no lessonId in parameter");
        }

        Long time = requestBean.parameters.getLong(CommuniConstants.time);
        if (time == null) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "no time in parameter");
        }
        try {
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                String lessonProgressStr = userInfoEntity.getLessonProgress();
                JSONObject lessonProgressJson;
                if (lessonProgressStr == null) {
                    lessonProgressJson = new JSONObject();
                } else {
                    try {
                        lessonProgressJson = JSON
                                .parseObject(lessonProgressStr);
                    } catch (Exception e) {
                        System.out
                                .println("studying record parse error, reset as null");
                        lessonProgressJson = new JSONObject();
                    }
                }
                StringBuilder sb = new StringBuilder();
                sb.append(courseId).append("_").append(lessonId);
                lessonProgressJson.put(sb.toString(), time);
                userInfoEntity.setLessonProgress(JSON
                        .toJSONString(lessonProgressJson));
                storageService.save(userInfoEntity);
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                responseBean.finishTime = System.currentTimeMillis();
                responseBean.result = "true";
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 删除一个正在学习的课程数
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean delStudyingCourse(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        String courseId = requestBean.parameters
                .getString(CommuniConstants.itemId);

        if (courseId != null) {
            try {
                UserInfoEntity userInfoEntity = storageService
                        .getUserInfo(userId);
                if (userInfoEntity != null) {
                    String studyCourseStr = userInfoEntity.getStudyingCourse();
                    JSONObject studyCourse;
                    if (studyCourseStr == null) {
                        return WebBeanUtils.newFailInnerResponse(requestBean,
                                "this course is no in studying list:"
                                        + courseId);
                    }
                    try {
                        studyCourse = JSON.parseObject(studyCourseStr);
                        if (studyCourse.containsKey(courseId)) {
                            studyCourse.remove(courseId);
                            userInfoEntity.setStudyingCourse(JSON
                                    .toJSONString(studyCourse));
                            storageService.save(userInfoEntity);
                        }
                        coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                                .newSuccInnerResponse(requestBean);
                        responseBean.finishTime = System.currentTimeMillis();
                        responseBean.result = "true";
                        return responseBean;
                    } catch (Exception e) {
                        return WebBeanUtils.newFailInnerResponse(requestBean,
                                "this course progress is error, needn't delete this course:"
                                        + courseId);
                    }
                } else {
                    return WebBeanUtils.newFailInnerResponse(requestBean,
                            "no such user with id:" + userId);
                }
            } catch (Exception e) {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        e.getMessage());
            }
        } else {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "no CourseId in parameter");
        }
    }

    /**
     * 获取正在学习的课程
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean getStudyingCourse(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        try {
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                String studyCourseStr = userInfoEntity.getStudyingCourse();
                if (studyCourseStr == null) {
                    responseBean.result = "{}";
                } else {
                    responseBean.result = studyCourseStr;
                }
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 获取正在学习的课程数
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean getStudyingCourseNum(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        try {
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                String studyCourseStr = userInfoEntity.getStudyingCourse();
                JSONObject studyCourse;
                if (studyCourseStr == null) {
                    responseBean.result = String.valueOf("0");
                } else {
                    try {
                        studyCourse = JSON.parseObject(studyCourseStr);
                        responseBean.result = String
                                .valueOf(studyCourse.size());
                    } catch (Exception e) {
                        System.out
                                .println("studying record parse error, reset as null");
                        responseBean.result = String.valueOf("0");
                    }
                }
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 增加一个正在学习的课程
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean addStudyingCourse(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        String courseId = requestBean.parameters
                .getString(CommuniConstants.itemId);
        if (courseId != null) {
            try {
                UserInfoEntity userInfoEntity = storageService
                        .getUserInfo(userId);
                if (userInfoEntity != null) {
                    String studyCourseStr = userInfoEntity.getStudyingCourse();
                    JSONObject studyCourse;
                    if (studyCourseStr == null) {
                        studyCourse = new JSONObject();
                    } else {
                        try {
                            studyCourse = JSON.parseObject(studyCourseStr);
                        } catch (Exception e) {
                            System.out
                                    .println("studying record parse error, reset as null");
                            studyCourse = new JSONObject();
                        }
                    }
                    studyCourse.put(courseId, System.currentTimeMillis());
                    userInfoEntity.setStudyingCourse(JSON
                            .toJSONString(studyCourse));
                    storageService.save(userInfoEntity);

                    coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                            .newSuccInnerResponse(requestBean);
                    responseBean.finishTime = System.currentTimeMillis();
                    responseBean.result = "true";
                    return responseBean;
                } else {
                    return WebBeanUtils.newFailInnerResponse(requestBean,
                            "no such user with id:" + userId);
                }
            } catch (Exception e) {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        e.getMessage());
            }
        } else {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    "no CourseId in parameter");
        }
    }

    /**
     * 获取用户本某个课程的未锁信息
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean getCourseUnlockLesson(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        try {
            String courseId = requestBean.parameters
                    .getString(CommuniConstants.itemId);
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                String unlockLesson = userInfoEntity.getUnlockLesson();
                JSONObject json;// [String,JSONArray]
                if (unlockLesson != null) {
                    try {
                        json = JSON.parseObject(unlockLesson);
                        responseBean.result = json.get(courseId).toString();
                    } catch (Exception e) {
                        System.out
                                .println("getCourseUnlockLesson record parse error, reset as null");
                    }
                }
                if (null == responseBean.result)
                    responseBean.result = String.valueOf("[]");
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }

    /**
     * 添加用户本某个课程的未锁信息
     * 
     * @param userId
     */
    private coursetools.communit.helper.ResponseBean addCourseUnlockLesson(
            String userId, coursetools.communit.helper.RequestBean requestBean) {
        try {
            String courseId = requestBean.parameters
                    .getString(CommuniConstants.itemId);
            String lessonId = requestBean.parameters
                    .getString(CommuniConstants.lessonId);
            UserInfoEntity userInfoEntity = storageService.getUserInfo(userId);
            if (userInfoEntity != null) {
                coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils
                        .newSuccInnerResponse(requestBean);
                String unlockLesson = userInfoEntity.getUnlockLesson();
                JSONObject json = (unlockLesson == null) ? new JSONObject()
                        : JSON.parseObject(unlockLesson);
                JSONArray lessonArray = (JSONArray) json.get(courseId);
                if (null == lessonArray) {
                    lessonArray = new JSONArray();
                    json.put(courseId, lessonArray);
                }
                if (!lessonArray.contains(lessonId))
                    lessonArray.add(lessonId);

                userInfoEntity.setUnlockLesson(JSON.toJSONString(json));
                storageService.save(userInfoEntity);
                responseBean.result = "true";
                responseBean.finishTime = System.currentTimeMillis();
                return responseBean;
            } else {
                return WebBeanUtils.newFailInnerResponse(requestBean,
                        "no such user with id:" + userId);
            }
        } catch (Exception e) {
            return WebBeanUtils.newFailInnerResponse(requestBean,
                    e.getMessage());
        }
    }
}
