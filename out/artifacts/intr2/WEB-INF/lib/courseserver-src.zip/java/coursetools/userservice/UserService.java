package coursetools.userservice;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import coursetools.common.Constant;
import coursetools.communit.client.MinaClientManager;
import coursetools.communit.helper.CommuniConstants;
import coursetools.database.bean.MsgType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 用户信息服务模块
 * 
 * @author zhaowei
 * @version 2014-09-16
 */
public class UserService {
    private MinaClientManager minaClientManager = new MinaClientManager(Constant.USER_SERVER_TIMEOUT);

    private static UserService instance = new UserService();

    private UserService() {}

    public static UserService getInstance() {
        return instance;
    }

    /**
     * 获取用户的购买记录
     * 
     * @param userId
     * @param start
     * @param len
     * @return null if exception or list
     */
    public List<coursetools.communit.helper.PurchaseRecord> getPurchaseRecords(String userId, int start, int len) throws Exception {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.purchasedList;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.start, start);
        para.put(coursetools.communit.helper.CommuniConstants.len, len);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        try {
            coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
            if (responseBean == null) {
                return null;
            }
            List<coursetools.communit.helper.PurchaseRecord> list = new ArrayList<coursetools.communit.helper.PurchaseRecord>();
            try {
                JSONArray jsonArray = JSON.parseArray(responseBean.result);
                for (int i = 0; i < jsonArray.size(); i++) {
                    try {
                        coursetools.communit.helper.PurchaseRecord record = JSON.parseObject(jsonArray.getString(i),
                                coursetools.communit.helper.PurchaseRecord.class);
                        list.add(record);
                    } catch (Exception e) {
                        System.out.println("Exception in getPurchaseRecords.parseObject, userId=" + userId);
                        e.printStackTrace();
                    }
                }
                return list;
            } catch (Exception e) {
                System.out.println("Exception in getPurchaseRecords, userId=" + userId);
                e.printStackTrace();
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获取用户的全部购买记录
     * 
     * @param userId
     * @return null if exception or list
     */
    public List<coursetools.communit.helper.PurchaseRecord> getPurchaseRecords(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.purchasedList;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        try {
            coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
            if (responseBean == null) {
                return null;
            }
            List<coursetools.communit.helper.PurchaseRecord> list = new ArrayList<coursetools.communit.helper.PurchaseRecord>();
            try {
                if (responseBean.result.length() == 0) {
                    return list;
                }
                JSONArray jsonArray = JSON.parseArray(responseBean.result);
                for (int i = 0; i < jsonArray.size(); i++) {
                    try {
                        coursetools.communit.helper.PurchaseRecord record = JSON.parseObject(jsonArray.getString(i),
                                coursetools.communit.helper.PurchaseRecord.class);
                        list.add(record);
                    } catch (Exception e) {
                        System.out.println("Exception in getPurchaseRecords.parseObject, userId=" + userId);
                        e.printStackTrace();
                    }
                }
                return list;
            } catch (Exception e) {
                System.out.println("Exception in getPurchaseRecords, userId=" + userId);
                System.out.println("record is:" + responseBean.result);
                e.printStackTrace();
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 增加一个用户的购买记录到用户中心
     * 
     * @param userId
     * @return succ?true : false
     */
    public boolean addPurchaseRecords(String userId, coursetools.communit.helper.PurchaseRecord purchaseRecord) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.addPurchase;;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.purchase, purchaseRecord.toString());
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return responseBean.succ;
    }

    /**
     * 判断用户是否购买了一个item
     * 
     * @param userId
     * @return is purchased ? 1 ; 0， if exception, return -1
     */
    public int isContainPurchaseRecords(String userId, String itemId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.isContain;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, itemId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return -1;
        }
        return responseBean.result.equals("true") ? 1 : 0;
    }

    /**
     * 增加用户的基本信息
     */
    public boolean addUserBasicProfile(String userId, String key, String value) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userBasicProfileOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.updateBasicProfile);
        para.put(coursetools.communit.helper.CommuniConstants.key, key);
        para.put(coursetools.communit.helper.CommuniConstants.value, value);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return responseBean.succ;
    }

    /**
     * 增加用户的基本信息
     */
    public JSONObject getUserBasicProfile(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userBasicProfileOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getBasicProfile);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return null;
        }
        return JSON.parseObject(responseBean.result);
    }

    // 获取所有用户地址信息
    public JSONArray getUserAllAddress(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userBasicProfileOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getUserAllAddress);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return new JSONArray();
        }
        JSONArray jsonArray = JSON.parseArray(responseBean.result);
        return jsonArray;
    }

    public JSONObject getUserAddressByDefault(String userId) {
        JSONArray jsonArray = getUserAllAddress(userId);
        if (jsonArray == null)
            return new JSONObject() ;
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject tmpJson = (JSONObject) jsonArray.get(i);
            if (tmpJson.getBooleanValue("default"))
                return tmpJson;
        }
        return new JSONObject() ;
    }

    public JSONObject getUserAddressById(String userId, int addressId) {
        JSONArray jsonArray = getUserAllAddress(userId);
        if (jsonArray == null)
            return new JSONObject() ;
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject tmpJson = (JSONObject) jsonArray.get(i);
            if (tmpJson.getIntValue("id") == addressId)
                return tmpJson;
        }
        return new JSONObject() ;
    }

    public boolean addUserAddress(String userId, String addressInfo) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userBasicProfileOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.addUserAddress);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.addressInfo, addressInfo);
        requestBean.parameters = para;
        long time = System.currentTimeMillis();
        para.put(coursetools.communit.helper.CommuniConstants.sendtime, time);
        requestBean.sendTime = time;
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return responseBean.succ;
    }

    public boolean updateUserAddress(String userId, String addressInfo, Boolean setDefault) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userBasicProfileOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.updateUserAddress);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.addressInfo, addressInfo);
        if (setDefault)
            para.put(coursetools.communit.helper.CommuniConstants.key, coursetools.communit.helper.CommuniConstants.defaultAddress);
        else
            para.put(coursetools.communit.helper.CommuniConstants.key, coursetools.communit.helper.CommuniConstants.modAddress);
        requestBean.parameters = para;
        long time = System.currentTimeMillis();
        para.put(coursetools.communit.helper.CommuniConstants.sendtime, time);
        requestBean.sendTime = time;
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return responseBean.succ;
    }

    public boolean deleteUserAddress(String userId, int addressId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userBasicProfileOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.deleteUserAddress);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.key, addressId);
        requestBean.parameters = para;
        long time = System.currentTimeMillis();
        para.put(coursetools.communit.helper.CommuniConstants.sendtime, time);
        requestBean.sendTime = time;
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return responseBean.succ;
    }
    
    /**
     * 增加用户购买成功的消息
     * 
     * @param userId
     * @return
     */
    public boolean addPurchasedSuccMessage(String userId, String nickName, String courseId, String courseTitle, String startTime) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.addMsg);
        String title = courseTitle + "购买成功";
        para.put(coursetools.communit.helper.CommuniConstants.msgTitle, title);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);

        JSONObject templateValue = new JSONObject();

        templateValue.put(coursetools.communit.helper.CommuniConstants.msgNickName, nickName);
        templateValue.put(coursetools.communit.helper.CommuniConstants.msgCourseId, courseId);
        templateValue.put(coursetools.communit.helper.CommuniConstants.msgCourseTitle, courseTitle);
        templateValue.put(coursetools.communit.helper.CommuniConstants.msgStartTime, startTime);
        para.put(coursetools.communit.helper.CommuniConstants.templateValue, JSON.toJSONString(templateValue));
        para.put(coursetools.communit.helper.CommuniConstants.msgContent, "");
        para.put(coursetools.communit.helper.CommuniConstants.msgSender, "系统");
        para.put(coursetools.communit.helper.CommuniConstants.templateId, MsgType.purchasedSucc.getCode());
        requestBean.parameters = para;
        long time = System.currentTimeMillis();
        para.put(coursetools.communit.helper.CommuniConstants.sendtime, time);
        requestBean.sendTime = time;
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return Boolean.parseBoolean(responseBean.result);
    }

    /**
     * 增加用户购买成功的消息 参数可以为null 关于content和templateId的配合:
     * 如果templateId不为0，则content存的是一组变量，用于替换template中的值
     * 如果templateId为0，则content中的存是消息内容，直接显示
     * 
     * @param userId
     *            接收的用户id
     * @param title
     *            消息的标题
     * @param simpleContent
     *            消息的简介，有可能消息比较长，可以让用户先看一两句话
     * @param content
     *            消息内容，可能是全文本，也可能是一个json，里面存了模板变量
     * @param url
     *            点击消息后跳转的地址，移动端比较有用。不是内容里面有某个地址
     * @param sender
     *            发送者
     * @param senderAvatar
     *            发送者头像url
     * @return 是否提交成功
     */
    public boolean addNormalMessage(String userId, String title, String simpleContent, String content, String url, String sender, String senderAvatar) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.addMsg);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgUrl, url);
        para.put(coursetools.communit.helper.CommuniConstants.msgTitle, title);
        para.put(coursetools.communit.helper.CommuniConstants.msgSimpleContent, simpleContent);
        para.put(coursetools.communit.helper.CommuniConstants.msgContent, content);
        para.put(coursetools.communit.helper.CommuniConstants.msgSender, sender);
        para.put(coursetools.communit.helper.CommuniConstants.msgAvatar, senderAvatar);
        requestBean.parameters = para;
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        try {
            boolean resultBoolean = Boolean.parseBoolean(responseBean.result);
            return resultBoolean;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * @param userId
     * @param endTime
     *            eg. System.getCurrentMillis()
     * @return -1 means error
     */
    public coursetools.communit.helper.ResponseBean getUnReadMsgNum(String userId, long endTime) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getUnReadMsgNum);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgEndTime, endTime);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        return responseBean;
    }

    /**
     * @param userId
     * @return -1 means error
     */
    public coursetools.communit.helper.ResponseBean readOneMsg(String userId, String messageId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.readMsg);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgId, messageId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        return responseBean;
    }

    /**
     * 获取未读消息数
     * 
     * @param userId
     * @param endTime
     *            eg. System.currentTimeMillis()
     * @param len
     * @return -1 means error
     */
    public coursetools.communit.helper.ResponseBean getUnReadMsg(String userId, long endTime, int len) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getUnReadMsg);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgEndTime, endTime);
        para.put(coursetools.communit.helper.CommuniConstants.len, len);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        return responseBean;
    }

    /**
     * 获取未读消息数
     * 
     * @param userId
     * @param endTime
     *            eg. System.currentTimeMillis()
     * @return -1 means error
     */
    public coursetools.communit.helper.ResponseBean getUnReadMsg(String userId, long endTime) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getUnReadMsg);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgEndTime, endTime);
        para.put(coursetools.communit.helper.CommuniConstants.len, 5);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        return responseBean;
    }

    /**
     * 获取消息，包括读和未读的
     * 
     * @param userId
     * @param endTime
     *            eg. System.currentTimeMillis()
     * @param len
     * @return -1 means error
     */
    public coursetools.communit.helper.ResponseBean getMsg(String userId, long endTime, int len) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getMsg);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgEndTime, endTime);
        para.put(coursetools.communit.helper.CommuniConstants.len, len);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取消息，包括读和未读的
     * 
     * @param userId
     * @param endTime
     *            eg. System.currentTimeMillis()
     * @return -1 means error
     */
    public coursetools.communit.helper.ResponseBean getMsg(String userId, long endTime) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userMsgOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getMsg);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.msgEndTime, endTime);
        para.put(coursetools.communit.helper.CommuniConstants.len, 5);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取用户正在学习的课程数
     * 
     * @param userId
     * @return
     */
    public coursetools.communit.helper.ResponseBean getStudingCourseNum(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getStudyingCourseNum);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 增加正在学习的课程
     * 
     * @param userId
     * @param courseId
     * @return 是否增加成功
     */
    public coursetools.communit.helper.ResponseBean addStudingCourse(String userId, String courseId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.addStudyingCourse);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取一个课程的购买用户数
     * 
     * @param courseId
     * @return num of purchased user
     */
    public coursetools.communit.helper.ResponseBean getPurchasedUserNum(String courseId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.getPurchaseNumOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    public coursetools.communit.helper.ResponseBean getPurchasedUserNumByCourseList(String[] courseIdArray) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.getPurchaseNumOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.itemId, Arrays.toString(courseIdArray));
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getArrayPurchaseNumOp);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }
    
    /**
     * 获取一个课程的所有的购买用户
     *
     * @param courseId
     * @return num of purchased user
     */
    public coursetools.communit.helper.ResponseBean getPurchasedUsers(String courseId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = CommuniConstants.getPurchasedUsers;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取正在学习的课
     * 
     * @param userId
     * @return eg. ['602', '603'] in responseBean.result
     */
    public coursetools.communit.helper.ResponseBean getStudyingCourse(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getStudyingCourse);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 从正在学习的课中删除一个课
     * 
     * @param userId
     * @param courseId
     * @return
     */
    public coursetools.communit.helper.ResponseBean delStudingCourse(String userId, String courseId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        requestBean.sendTime = System.currentTimeMillis();
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.delStudyingCourse);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        requestBean.parameters = para;
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 增加一个课时的进度情况
     * 
     * @param userId
     * @param courseId
     * @param lessonId
     * @param time
     *            (unit: millisecond)
     * @return
     */
    public coursetools.communit.helper.ResponseBean addCourseLessonProgress(String userId, String courseId, String lessonId, long time) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        requestBean.sendTime = System.currentTimeMillis();
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.addStudyingProgress);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        para.put(coursetools.communit.helper.CommuniConstants.lessonId, lessonId);
        para.put(coursetools.communit.helper.CommuniConstants.time, time);
        requestBean.parameters = para;
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取全部课时的进度情况
     * 
     * @param userId
     * @return
     */
    public coursetools.communit.helper.ResponseBean getCourseLessonProgress(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        requestBean.sendTime = System.currentTimeMillis();
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getStudyingProgress);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        requestBean.parameters = para;
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取用户本某个课程的已学课时数
     * 
     * @param userId
     * @param courseId
     * @return
     */
    public coursetools.communit.helper.ResponseBean getCourseLessonProgress(String userId, String courseId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        requestBean.sendTime = System.currentTimeMillis();
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getLessonStudyingProgress);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        requestBean.parameters = para;
        return minaClientManager.invoke(requestBean);
    }

    /**
     * 获取用户本某个课程的未锁信息
     * 
     * @param userId
     * @param courseId
     * @return
     */
    public coursetools.communit.helper.ResponseBean getCourseUnlockLesson(String userId, String courseId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        requestBean.sendTime = System.currentTimeMillis();
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.getCourseUnlockLesson);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        requestBean.parameters = para;
        return minaClientManager.invoke(requestBean);
    }
    
    /**
     * 添加用户本某个课程的未锁信息
     * 
     * @param userId
     * @param courseId
     * @return
     */
    public coursetools.communit.helper.ResponseBean addCourseUnlockLesson(String userId, String courseId,String lesson) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = coursetools.communit.helper.CommuniConstants.userCourseOp;
        requestBean.sendTime = System.currentTimeMillis();
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.opName, coursetools.communit.helper.CommuniConstants.addCourseUnlockLesson);
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        para.put(coursetools.communit.helper.CommuniConstants.itemId, courseId);
        para.put(coursetools.communit.helper.CommuniConstants.lessonId, lesson);
        requestBean.parameters = para;
        return minaClientManager.invoke(requestBean);
    }
    
    /**
     * 清除所在有
     * 
     * @param userId
     * @return succ?true : false
     */
    public boolean cleanUserServerCache(String userId) {
        coursetools.communit.helper.RequestBean requestBean = new coursetools.communit.helper.RequestBean();
        requestBean.command = CommuniConstants.cleanCache;;
        JSONObject para = new JSONObject();
        para.put(coursetools.communit.helper.CommuniConstants.userId, userId);
        requestBean.parameters = para;
        requestBean.sendTime = System.currentTimeMillis();
        coursetools.communit.helper.ResponseBean responseBean = minaClientManager.invoke(requestBean);
        if (responseBean == null) {
            return false;
        }
        return responseBean.succ;
    }
}
