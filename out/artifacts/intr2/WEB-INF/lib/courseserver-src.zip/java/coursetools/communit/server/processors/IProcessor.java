package coursetools.communit.server.processors;
import coursetools.communit.helper.ResponseBean;

/**
 * 一个处理接口
 * @author zhaowei
 *
 */
public interface IProcessor {
    public void preHandle(coursetools.communit.helper.RequestBean requestBean);
    public void postHandle(coursetools.communit.helper.RequestBean requestBean, ResponseBean responseBean);
    public ResponseBean handle(coursetools.communit.helper.RequestBean requestBean);
}
