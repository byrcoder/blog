package coursetools.database.bean;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "userInfo")
public class UserInfoEntity {
    private String userId;

    @javax.persistence.Column(name = "userId")
    @Id
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private String basicInfo;

    @javax.persistence.Column(name = "basicInfo")
    @Basic
    public String getBasicInfo() {
        return basicInfo;
    }

    public void setBasicInfo(String basicInfo) {
        this.basicInfo = basicInfo;
    }


    private String studyingCourse;

    @javax.persistence.Column(name = "studyingCourse")
    @Basic
    public String getStudyingCourse() {
        return studyingCourse;
    }

    public void setStudyingCourse(String studyingCourse) {
        this.studyingCourse = studyingCourse;
    }

    private String lessonProgress;

    @javax.persistence.Column(name = "lessonProgress")
    @Basic
    public String getLessonProgress() {
        return lessonProgress;
    }

    public void setLessonProgress(String lessonProgress) {
        this.lessonProgress = lessonProgress;
    }

    private String userAddress;

    @javax.persistence.Column(name = "userAddress")
    @Basic
    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }
    
    private String unlockLesson;

    @javax.persistence.Column(name = "unlockLesson")
    @Basic
    public String getUnlockLesson() {
        return unlockLesson;
    }

    public void setUnlockLesson(String unlockLesson) {
        this.unlockLesson = unlockLesson;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserInfoEntity that = (UserInfoEntity) o;

        if (basicInfo != null ? !basicInfo.equals(that.basicInfo) : that.basicInfo != null) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = userId != null ? userId.hashCode() : 0;
        result = 31 * result + (basicInfo != null ? basicInfo.hashCode() : 0);
        return result;
    }
}
