/**
 * @(#)IInfoTask.java, 2013-5-21. 
 * 
 * Copyright 2013 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common.utils.notify;

/**
 *
 * @author qipeng
 *
 */
public interface IInfoTask {
    
    /**
     * 获取当前信息提示任务的类型，目前有两种SMS和EMAIL
     * @return
     */
    public String getType();
    
    /**
     * 发送信息提示
     * @return
     */
    public boolean send();
    
    //public void syncSend();
}
