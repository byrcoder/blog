package coursetools.database.bean;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "userPurchase")
public class UserPurchaseEntity {
    private String userId;

    @javax.persistence.Column(name = "userId")
    @Id
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private String purchases;

    @javax.persistence.Column(name = "purchases")
    @Basic
    public String getPurchases() {
        return purchases;
    }

    public void setPurchases(String purchases) {
        this.purchases = purchases;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserPurchaseEntity that = (UserPurchaseEntity) o;

        if (purchases != null ? !purchases.equals(that.purchases) : that.purchases != null) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = userId != null ? userId.hashCode() : 0;
        result = 31 * result + (purchases != null ? purchases.hashCode() : 0);
        return result;
    }
}
