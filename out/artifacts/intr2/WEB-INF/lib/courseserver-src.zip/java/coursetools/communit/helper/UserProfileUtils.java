package coursetools.communit.helper;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


/**
 * 访问用户中心的接口的java封装
 * @author zhaowei
 */
public class UserProfileUtils {
    //这个地址上线前需要换成能在配置文件中修改的
    private static final String PROFILE_URL = "http://xue.youdao.com/profile";
    private static final String SET_ADD_STR = "/set/add";
    private static final String SET_DEL_STR = "/set/remove";
    private static final String PURCHASE_RECORDS = "coursePurchaseRecords";
    private static final String PURCHASE_RECORDS_DETAIL = "coursePurchaseRecordsDetail";
    private static final String SHOWED_PURCHASE_RECORDS = "courseShowedPurchaseRecords";
    private static final String ERROR = "error";
    private static final String STUDY_VIDEO_PROGRESS_SET = "courseVideoStudyProgressSet";
    private static final String STUDY_VIDEO_PROGRESS_LATEST = "courseVideoStudyProgressLatest";
    private static final String COURSE_ITEM_TO_PURCHASED_ITEM_SET = "courseItemToPurchasedItemSet_";
    
    private static final String TEXT_SET_STR = "/text/set";
    private static final String TEXT_GET_STR = "/text/get";

    private static ThreadLocal<UserProfileUtils> threadLocalUtils = new ThreadLocal<UserProfileUtils>();

    public static UserProfileUtils getInstance() {
    	UserProfileUtils utils = threadLocalUtils.get();
        if (utils == null) {
        	utils = new UserProfileUtils();
        	threadLocalUtils.set(utils);
        }
        return utils;
    }

    /**
     * @return true if adding succ
     */
    public boolean addShowedPurchaseRecord(String userId, String courseId) {
    	if (courseId == null) {
    		return false;
    	}
        String url =  PROFILE_URL + SET_ADD_STR;
        String result = getDataFromProfileServer(url, userId, SHOWED_PURCHASE_RECORDS, courseId);
        if (result != null) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 获取已显示过的购买信息
     * @param userId
     * @return null if error
     */
    public List<String> getShowedPurchaseRecords(String userId) {
        List<String> list = new ArrayList<String>();
        String url =  PROFILE_URL + "/set/all";
        String result = getDataFromProfileServer(url, userId, SHOWED_PURCHASE_RECORDS, null);
        if (result == null) {
            return null;
        }
        JSONObject json = JSONObject.parseObject(result);
        String value = json.getString("values");
        if (value != null) {
            JSONArray array = JSONArray.parseArray(value);
            for (int i = 0 ; i < array.size();i++) {
                String element = array.getString(i);
                element = URLDecoder.decode(element);
                list.add(element);
            }
        }

        return list;
    }

    /**
     * 获取用户的全部购买记�?
     * @param userId
     * @return null if error
     */
    public boolean hadShowedPurchasedRecord(String userId, String itemId) {
        String url =  PROFILE_URL + "/set/contains";
        String result = getDataFromProfileServer(url, userId, SHOWED_PURCHASE_RECORDS, itemId);
        if (result == null) {
            //如果出现网络问题，我们先认为不存在，这个时�?会向我的邮箱发邮件的�?
            return false;
        } else {
            result = URLDecoder.decode(result);
            JSONObject jsonObject = JSONObject.parseObject(result);
            Integer error = jsonObject.getInteger(ERROR);
            if (error == null) {
                error = 1;
            }
            if (error == 0) {
                Boolean contains = jsonObject.getBoolean("contains");
                if (contains == null) {
                    return false;
                }
                return contains;
            }
        }
        return false;
    }
    


    /**
     * 加入用户的全部购买记录
     * @return true if adding succ
     */
    public boolean addPurchaseRecord(PurchaseRecord purchaseRecord) {
    	if (purchaseRecord.userId == null || purchaseRecord.itemId == null) {
    		return false;
    	}
        String url =  PROFILE_URL + SET_ADD_STR;
        String result = getDataFromProfileServer(url, purchaseRecord.userId, PURCHASE_RECORDS_DETAIL, purchaseRecord.toString());
        if (result != null) {
            result = getDataFromProfileServer(url, purchaseRecord.userId, PURCHASE_RECORDS, String.valueOf(purchaseRecord.itemId));
            if (result != null) {
                return true;
            } else {
                //如果存详细成功了，但是存id没有成功，这个时候需要删除详细,但是还是不删除了,毕竟不是数据库，接受不回滚吧
                //应用程序再加一次就好了
                return false;
            }
        } else {
            return false;
        }
    }


    /**
     * 加入用户的全部购买记录
     * @return true if adding succ
     */
    public boolean delPurchaseRecord(PurchaseRecord purchaseRecord) {
        if (purchaseRecord.userId == null || purchaseRecord.itemId == null) {
            return false;
        }
        String url =  PROFILE_URL + SET_DEL_STR;
        String result = getDataFromProfileServer(url, purchaseRecord.userId, PURCHASE_RECORDS_DETAIL, purchaseRecord.toString());
        if (result != null) {
            result = getDataFromProfileServer(url, purchaseRecord.userId, PURCHASE_RECORDS, String.valueOf(purchaseRecord.itemId));
            if (result != null) {
                return true;
            } else {
                //如果存详细成功了，但是存id没有成功，这个时候需要删除详细,但是还是不删除了,毕竟不是数据库，接受不回滚吧
                //应用程序再加一次就好了
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 获取用户的全部购买记录
     * @param userId
     * @return null if error
     */
    public List<PurchaseRecord> getPurchaseRecords(String userId) {
        List<PurchaseRecord> list = new ArrayList<PurchaseRecord>();
        String url =  PROFILE_URL + "/set/all";
        String result = getDataFromProfileServer(url, userId, PURCHASE_RECORDS_DETAIL, null);
        if (result == null) {
            return null;
        }
        JSONObject json = JSONObject.parseObject(result);
        String value = json.getString("values");
        if (value != null) {
            JSONArray array = JSONArray.parseArray(value);
            for (int i = 0 ; i < array.size();i++) {
                String element = array.getString(i);
                element = URLDecoder.decode(element);
                try {
                    PurchaseRecord purchaseRecord = PurchaseRecord.fromJson(element);
                    list.add(purchaseRecord);
                } catch (Exception e) {
                    PurchaseRecord purchaseRecord = new PurchaseRecord();
                    purchaseRecord.itemId = element;
                    purchaseRecord.userId = userId;
                    list.add(purchaseRecord);
//                    e.printStackTrace();
                }
            }
        }
        return list;
    }

    /**
     * 获取用户的全部购买记录
     * @param userId
     * @return null if error
     */
    public List<String> getPurchaseRecordsWithString(String userId) {
        List<String> list = new ArrayList<String>();
        String url =  PROFILE_URL + "/set/all";
        String result = getDataFromProfileServer(url, userId, PURCHASE_RECORDS_DETAIL, null);
        if (result == null) {
            return null;
        }
        JSONObject json = JSONObject.parseObject(result);
        String value = json.getString("values");
        if (value != null) {
            JSONArray array = JSONArray.parseArray(value);
            for (int i = 0 ; i < array.size();i++) {
                String element = array.getString(i);
                list.add(element);
            }
        }
        return list;
    }

    /**
     * 获取用户的全部购买记录
     * @param userId
     * @return null if error
     */
    public boolean hadPurchased(String userId, String itemId) {
        String url =  PROFILE_URL + "/set/contains";
        String result = getDataFromProfileServer(url, userId, PURCHASE_RECORDS, itemId);
        if (result == null) {
            //如果出现网络问题，我们先认为不存在，这个时候会向我的邮箱发邮件的。
            return false;
        } else {
        	result = URLDecoder.decode(result);
            JSONObject jsonObject = JSONObject.parseObject(result);
            Integer error = jsonObject.getInteger(ERROR);
            if (error == null) {
                error = 1;
            }
            if (error == 0) {
                Boolean contains = jsonObject.getBoolean("contains");
                if (contains == null) {
                    return false;
                }
                return contains;
            }
        }
        return false;
    }

    private String getDataFromProfileServer(String url, String userid, String key, String value) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        HttpPost post = new HttpPost (url);
        try {
            List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            nvps.add(new BasicNameValuePair("userid", userid));
            nvps.add(new BasicNameValuePair("key", key));
            if (value != null) {
                value = URLEncoder.encode(value, "utf-8");
            }
            nvps.add(new BasicNameValuePair("value", value));
            post.setEntity(new UrlEncodedFormEntity(nvps));

            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
                String strResult = EntityUtils.toString(response.getEntity());
                JSONObject result = JSONObject.parseObject(strResult);
                if (result == null) {
                    return null;
                }
                Integer error = result.getInteger(ERROR);
                if (error == null) {
                    error = 1;
                }
                if (error == 0) {
                    return strResult;
                } else {
                    return null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return null;
    }


    private String getDataFromProfileServerWithoutEncode(String url, String userid, String key, String value) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();
        HttpConnectionParams.setSoTimeout(params, 1000 * 60);
        HttpConnectionParams.setConnectionTimeout(params, 1000 * 60);
        HttpPost post = new HttpPost (url);
        try {
            List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            nvps.add(new BasicNameValuePair("userid", userid));
            nvps.add(new BasicNameValuePair("key", key));

            nvps.add(new BasicNameValuePair("value", value));
            post.setEntity(new UrlEncodedFormEntity(nvps));

            HttpResponse response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            if (code == HttpStatus.SC_OK) {
                String strResult = EntityUtils.toString(response.getEntity());
                JSONObject result = JSONObject.parseObject(strResult);
                if (result == null) {
                    return null;
                }
                Integer error = result.getInteger(ERROR);
                if (error == null) {
                    error = 1;
                }
                if (error == 0) {
                    return strResult;
                } else {
                    return null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            post.releaseConnection();
        }
        return null;
    }

    public static void main(String[]args) throws Exception {

//        String inputDir = "D:\\addLog2.txt";
//        String line = "";
//        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputDir), "utf-8"));
//        int i = 0;
//        while ((line = br.readLine()) != null) {
//            try {
//                int begin = line.indexOf("{");
//                if (begin != -1) {
//                    String jsonStr = line.substring(begin);
//                    JSONObject json = JSON.parseObject(jsonStr);
//                    JSONObject parameters = json.getJSONObject("parameters");
//                    String purchaseStr = parameters.getString("purchase");
//                    System.out.println(purchaseStr);
//                    JSONObject purchase = JSON.parseObject(purchaseStr);
//                    String userId = purchase.getString("userId");
//                    String itemId = purchase.getString("itemId");
//                    PurchaseRecord purchaseRecord = new PurchaseRecord();
//                    purchaseRecord.product = "course";
//                    purchaseRecord.itemId = itemId;
//                    purchaseRecord.userId = userId;
//                    UserProfileUtils.getInstance().addPurchaseRecord(purchaseRecord);
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }


//        List<PurchaseRecord> list= UserProfileUtils.getInstance().getPurchaseRecords("m15927381768@163.com");
////
//        System.out.print(JSON.toJSON(list));
//        try {
//            PurchaseRecord purchaseRecord = new PurchaseRecord();
//            purchaseRecord.product = "course";
//            purchaseRecord.itemId = "663";
//            purchaseRecord.userId = "scg199165@126.com";
//            purchaseRecord.time = String.valueOf(System.currentTimeMillis());
//            UserProfileUtils.getInstance().addPurchaseRecord(purchaseRecord);
//            System.out.println("scg199165@126.com");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
        System.out.println(UserProfileUtils.getInstance().getPurchaseRecords("qq683634DF8A4DA9D9CD834771AFCD07F4"));
//        boolean isBuyed = UserProfileUtils.getInstance().hadPurchased("sina5074518764", "701");
//        System.out.println(isBuyed);
//        try {
//            PurchaseRecord purchaseRecord = new PurchaseRecord();
//            purchaseRecord.product = "course";
//            purchaseRecord.itemId = "b5d8eb595b22fed92fcec796f9d10f3ab";
//            purchaseRecord.userId = "ambrosiacon@163.com";
//            purchaseRecord.time = String.valueOf(System.currentTimeMillis());
//            UserProfileUtils.getInstance().addPurchaseRecord(purchaseRecord);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        System.out.println(UserProfileUtils.getInstance().getPurchaseRecords("qq683634DF8A4DA9D9CD834771AFCD07F4"));
////        System.out.println(UserService.getInstance().getPurchaseRecords("youdaoceshi666@163.com"));
////                System.out.println(UserProfileUtils.getInstance().getPurchaseRecords("bidingguoji@163.com"));
//        PurchaseRecord purchaseRecord = new PurchaseRecord();
//            purchaseRecord.time = String.valueOf(System.currentTimeMillis());
//            purchaseRecord.itemId = "701";
//            purchaseRecord.userId = "qq683634DF8A4DA9D9CD834771AFCD07F4";
//        UserProfileUtils.getInstance().addPurchaseRecord(purchaseRecord);
////        System.out.println(UserProfileUtils.getInstance().delPurchaseRecord(purchaseRecord));
////        UserProfileUtils.getInstance().getDataFromProfileServerWithoutEncode("http://xue.youdao.com/profile/set/remove","qq683634DF8A4DA9D9CD834771AFCD07F4",
////                PURCHASE_RECORDS_DETAIL, "%7B%27userId%27%3A%27qq683634DF8A4DA9D9CD834771AFCD07F4%27%2C%27product%27%3A%27code%27%2C%27itemId%27%3A%27bca83d3967a0d49c38d717463644e7de0%27%2C%27time%27%3A%271415536376781%27%2C%27extendInfo%27%3A%27%27%7D");
//        System.out.println(UserProfileUtils.getInstance().getPurchaseRecords("qq683634DF8A4DA9D9CD834771AFCD07F4"));



//        bidingguoji@163.com
    }
}
