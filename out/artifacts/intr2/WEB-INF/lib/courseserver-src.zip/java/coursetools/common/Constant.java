/**
 * @(#)Constant.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common;

/**
 *
 * @author zhaowei
 *
 */
public class Constant {
    public static final int USER_SERVER_TIMEOUT = 30;
    public static String USER_SERVER_HOST = "courseuser.corp.youdao.com";
    public static final int USER_SERVER_PORT = 8896;

    public static final String REQUEST_USER_ID = "__USER_ID__";
    
    public static final String CLIENT_POOL_SIZE="CLIENT_POOL_SIZE";
    
    public static final String USER_SERVER_HOST_KEY="USER_SERVER_HOST";
}

