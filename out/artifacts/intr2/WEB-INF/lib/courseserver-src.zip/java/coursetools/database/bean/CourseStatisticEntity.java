package coursetools.database.bean;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created with IntelliJ IDEA.
 * User: Administrator
 * Date: 14-7-7
 * Time: 下午8:04
 * To change this template use File | Settings | File Templates.
 */
@Entity(name = "courseStatistic")
public class CourseStatisticEntity {
    private int id;

    @javax.persistence.Column(name = "id")
    @Id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int clickNum;

    @javax.persistence.Column(name = "clickNum")
    @Basic
    public int getClickNum() {
        return clickNum;
    }

    public void setClickNum(int clickNum) {
        this.clickNum = clickNum;
    }

    private int buyNum;

    @javax.persistence.Column(name = "buyNum")
    @Basic
    public int getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(int buyNum) {
        this.buyNum = buyNum;
    }

    private int likeNum;

    @javax.persistence.Column(name = "likeNum")
    @Basic
    public int getLikeNum() {
        return likeNum;
    }

    public void setLikeNum(int likeNum) {
        this.likeNum = likeNum;
    }

    private int registNum;

    @javax.persistence.Column(name = "registNum")
    @Basic
    public int getRegistNum() {
        return registNum;
    }

    public void setRegistNum(int registNum) {
        this.registNum = registNum;
    }

    private int finishNum;

    @javax.persistence.Column(name = "finishNum")
    @Basic
    public int getFinishNum() {
        return finishNum;
    }

    public void setFinishNum(int finishNum) {
        this.finishNum = finishNum;
    }

    private int dislikeNum;

    @javax.persistence.Column(name = "dislikeNum")
    @Basic
    public int getDislikeNum() {
        return dislikeNum;
    }

    public void setDislikeNum(int dislikeNum) {
        this.dislikeNum = dislikeNum;
    }

    private float avgScore;

    @javax.persistence.Column(name = "avgScore")
    @Basic
    public float getAvgScore() {
        return avgScore;
    }


    public void setAvgScore(float avgScore) {
        this.avgScore = avgScore;
    }

    private int rateNum;

    @javax.persistence.Column(name = "rateNum")
    @Basic
    public int getRateNum() {
        return rateNum;
    }

    public void setRateNum(int rateNum) {
        this.rateNum = rateNum;
    }

    public void init() {
        this.avgScore = 0;
        this.buyNum = 0;
        this.clickNum = 0;
        this.dislikeNum = 0;
        this.finishNum = 0;
        this.rateNum = 0;
        this.registNum = 0;
        this.likeNum = 0;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseStatisticEntity that = (CourseStatisticEntity) o;

        if (Float.compare(that.avgScore, avgScore) != 0) return false;
        if (buyNum != that.buyNum) return false;
        if (clickNum != that.clickNum) return false;
        if (dislikeNum != that.dislikeNum) return false;
        if (finishNum != that.finishNum) return false;
        if (id != that.id) return false;
        if (likeNum != that.likeNum) return false;
        if (rateNum != that.rateNum) return false;
        if (registNum != that.registNum) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + clickNum;
        result = 31 * result + buyNum;
        result = 31 * result + likeNum;
        result = 31 * result + registNum;
        result = 31 * result + finishNum;
        result = 31 * result + dislikeNum;
        result = 31 * result + (avgScore != +0.0f ? Float.floatToIntBits(avgScore) : 0);
        result = 31 * result + rateNum;
        return result;
    }
}
