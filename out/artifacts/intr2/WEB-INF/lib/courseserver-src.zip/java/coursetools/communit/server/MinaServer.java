package coursetools.communit.server;

import coursetools.common.Config;
import coursetools.common.utils.WebBeanUtils;
import coursetools.communit.helper.CommuniConstants;
import coursetools.communit.server.processors.CleanCacheProcessor;
import coursetools.communit.server.processors.GetPurchasedUserNumProcessor;
import coursetools.communit.server.processors.GetPurchasedUsersProcessor;
import coursetools.communit.server.processors.UserCourseProcessor;
import org.apache.commons.configuration.Configuration;
import org.apache.mina.core.future.WriteFuture;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.LineDelimiter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.transport.socket.SocketAcceptor;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * 用于监听服务
 * @author zhaowei
 * @version 2014-09-16
 */
public class MinaServer {

    private static Map<String, coursetools.communit.server.processors.SimpleProcessor> processorMap = new HashMap<String, coursetools.communit.server.processors.SimpleProcessor>();

    static {
        Configuration conf = coursetools.common.CourseContext.getConfig();
        Config.init(conf);
        processorMap.put(CommuniConstants.purchasedList, new coursetools.communit.server.processors.ListPurchasedInfoProcessor());
        processorMap.put(CommuniConstants.addPurchase, new coursetools.communit.server.processors.AddPurchasedInfoProcessor());
        processorMap.put(CommuniConstants.isContain, new coursetools.communit.server.processors.IsContainPurchasedInfoProcessor());
        processorMap.put(CommuniConstants.userBasicProfileOp, new coursetools.communit.server.processors.UserBasicInfoProcessor());
        processorMap.put(CommuniConstants.userMsgOp, new coursetools.communit.server.processors.UserMessageProcessor());
        processorMap.put(CommuniConstants.userCourseOp, new UserCourseProcessor());
        processorMap.put(CommuniConstants.getPurchaseNumOp, new GetPurchasedUserNumProcessor());
        processorMap.put(CommuniConstants.getPurchasedUsers, new GetPurchasedUsersProcessor());
        processorMap.put(CommuniConstants.cleanCache, new CleanCacheProcessor());
    }

    public static void main(String[] args) throws IOException {
        SocketAcceptor acceptor = new NioSocketAcceptor(128);
        acceptor.getSessionConfig().setReadBufferSize(1024 * 5);
        acceptor.getSessionConfig().setReceiveBufferSize(1024 * 5);
        acceptor.getSessionConfig().setWriteTimeout(30);
        acceptor.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, 10);
        TextLineCodecFactory  lineCodec = new TextLineCodecFactory( Charset.forName( "UTF-8" ), LineDelimiter.UNIX, LineDelimiter.UNIX);
        lineCodec.setDecoderMaxLineLength(1024 * 1024);
        lineCodec.setEncoderMaxLineLength(1024 * 1024);
        acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(lineCodec));
        acceptor.getFilterChain().addLast("ThreadPool",new ExecutorFilter(Executors.newCachedThreadPool()));

        acceptor.getSessionConfig().setTcpNoDelay(true);
        acceptor.setReuseAddress(true);
        acceptor.setHandler(new MyIoHandler());
        acceptor.bind(new InetSocketAddress(Config.user_server_port));
    }

    public static class MyIoHandler extends IoHandlerAdapter {
        @Override
        public void sessionCreated(IoSession session) throws Exception {
            System.out.println("sesion created");
        }

         @Override
         public void messageReceived(IoSession session, Object message) throws Exception {
             long recTime = System.currentTimeMillis();
             try {
                 coursetools.communit.helper.RequestBean requestBean = coursetools.communit.helper.RequestBean.fromString((String) message);
                 coursetools.communit.server.processors.SimpleProcessor processor = processorMap.get(requestBean.command);
                 if (processor == null) {
                     coursetools.communit.helper.ResponseBean responseBean = WebBeanUtils.newFailInnerResponse(requestBean, "no reqeust command");
                     session.write(responseBean);
                 }
                 processor.preHandle(requestBean);
                 coursetools.communit.helper.ResponseBean responseBean = processor.handle(requestBean);
                 responseBean.dealTime = responseBean.finishTime - recTime;
                 responseBean.recvTime = recTime - requestBean.sendTime;
                 processor.postHandle(requestBean, responseBean);
                 responseBean.finishTime = System.currentTimeMillis();
                 WriteFuture writeResult = session.write(responseBean.toString());
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }
    }
}