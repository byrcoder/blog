package coursetools.communit.server.processors;

import org.apache.log4j.PropertyConfigurator;
import toolbox.misc.LogFormatter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * 处理用户相关的请求的父类处理器
 * @author zhaowei
 */
public class SimpleProcessor implements IProcessor {
    public coursetools.communit.log.CourseRequestLogger requestLogger = new coursetools.communit.log.CourseRequestLogger();
    private static final Log logger = LogFactory.getLog(SimpleProcessor.class);

    public SimpleProcessor() {
        PropertyConfigurator.configure("log4j.properties");

        requestLogger.init();
    }
    @Override
    public void preHandle(coursetools.communit.helper.RequestBean requestBean) {
        String requestStr = requestBean.toString();
        requestLogger.log(requestStr);
        logger.info(requestStr);
    }

    @Override
    public void postHandle(coursetools.communit.helper.RequestBean requestBean, coursetools.communit.helper.ResponseBean responseBean) {
        StringBuilder sb = new StringBuilder();
        logger.info(responseBean.toString());
        sb.append("@@ANALYSIS@@ userServer.").append(responseBean.command).append(".time=").append(responseBean.finishTime - responseBean.sendTime);
        logger.info(sb.toString());
    }

    @Override
    public coursetools.communit.helper.ResponseBean handle(coursetools.communit.helper.RequestBean requestBean) {
         return null;
    }
}
