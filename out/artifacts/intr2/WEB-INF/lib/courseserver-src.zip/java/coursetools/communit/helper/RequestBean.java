package coursetools.communit.helper;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * 从客户端过来的请求
 * @author zhaowei
 *
 */
public class RequestBean {
    public String clientId; //客户端的id
    public long sendTime;//发送的时间
    public String command; //需要执行什么命令
    public JSONObject parameters; //参数

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

    public static RequestBean fromString(String s) {
        if (s == null) {
            return null;
        }
        try {
            return JSON.parseObject(s, RequestBean.class);
        } catch (Exception e) {
            return null;
        }
    }

}
