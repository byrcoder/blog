/**
 * @(#)NotifyTask.java, 2013-5-21. 
 * 
 * Copyright 2013 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common.utils.notify;

import insight.common.mail.MailSender;
import toolbox.misc.LogFormatter;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

/**
 * 简单的异步发送信息通知工具类
 * 
 * @author qipeng
 *
 */
public class InfoNotifier {

    public static final Logger LOG = 
            LogFormatter.getLogger(InfoNotifier.class);
    
    private ExecutorService threadPool = null;
    
    private MailSender mailSender;
    
    private coursetools.common.utils.QxtSmsHelperForCourse smsSender;
    
    private int poolSize = 100;
        
    public void init() {
        threadPool = Executors.newFixedThreadPool(poolSize);
    }
    
    public void notify(IInfoTask task) {
        Worker worker = new Worker(task);
        threadPool.execute(worker);
    }
    
    public class Worker implements Runnable {

        private IInfoTask task;
        
        public Worker(IInfoTask task) {
            this.task = task;
        }
        
        @Override
        public void run() {
            LOG.info("Begin to send task " + task.getType());
            boolean result = task.send();
            LOG.info("End to send task " + task.getType() + ", result=" + result);
        }
    }

    /**
     * @return the mailSender
     */
    public MailSender getMailSender() {
        return mailSender;
    }

    /**
     * @param mailSender the mailSender to set
     */
    public void setMailSender(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    /**
     * @return the smsSender
     */
    public coursetools.common.utils.QxtSmsHelperForCourse getSmsSender() {
        return smsSender;
    }

    /**
     * @param smsSender the smsSender to set
     */
    public void setSmsSender(coursetools.common.utils.QxtSmsHelperForCourse smsSender) {
        this.smsSender = smsSender;
    }
    
    
}
