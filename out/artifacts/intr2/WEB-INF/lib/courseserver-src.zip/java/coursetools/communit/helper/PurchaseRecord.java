package coursetools.communit.helper;

import com.alibaba.fastjson.JSON;

/**
 * @author zhaowei
 */
public class PurchaseRecord {
 	public String userId;
 	public String product;
 	public String itemId;
    public String itemName;
 	public String time;
 	public String recordId;
 	public String price;
 	public String channel;
 	public String extendInfo;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

    public static PurchaseRecord fromJson(String objStr) {
        return JSON.parseObject(objStr, PurchaseRecord.class);
    }
}
