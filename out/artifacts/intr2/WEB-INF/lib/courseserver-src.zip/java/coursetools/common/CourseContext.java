/**
 * @(#)BeggarContext.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package coursetools.common;

import odis.tools.ToolContext;

import java.io.File;

/**
 * Environment for service.
 * 
 * @author dongyu
 */
public class CourseContext extends ToolContext {

    /**
     * returns the app's conf dir path, with a '/' at the end.
     * @return
     */
    public static String getAppConfDir() {
        return getAppHome() + "/conf/";
    }

    /**
     * returns the app's conf dir path, with a '/' at the end.
     * @return
     */
    public static String getAppConfPath(String fileName) {
        return getAppHome() + "/conf/" + fileName;
    }

    /**
     * returns the app's data dir path, with a '/' at the end.
     * @return
     */
    public static String getAppDataDir() {
        return getAppHome() + "/data/";
    }

    /**
     * returns the app's data file of fileName.
     */
    public static File getAppDataFile(String fileName) {
        return new File(getAppDataDir(), fileName);
    }

    /**
     * returns the app's bin dir path, with a '/' at the end.
     * @return
     */
    public static String getAppBinDir() {
        return getAppHome() + "/bin/";
    }

    /**
     * returns the app's binary file of fileName.
     * @param fileName
     * @return
     */
    public static File getAppBinFile(String fileName) {
        return new File(getAppBinDir(), fileName);
    }
    
}