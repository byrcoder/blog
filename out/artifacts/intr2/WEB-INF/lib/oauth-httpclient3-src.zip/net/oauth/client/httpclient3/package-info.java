/**
 * Classes that integrate the Apache Commons HTTP Client version 3 with the OAuth library.
 */
package net.oauth.client.httpclient3;

