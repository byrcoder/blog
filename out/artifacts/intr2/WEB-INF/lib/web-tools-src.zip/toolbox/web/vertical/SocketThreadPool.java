package toolbox.web.vertical;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;

import toolbox.misc.LogFormatter;

public class SocketThreadPool {
    private static final Logger LOG = LogFormatter.getLogger(SocketThreadPool.class.getName());
    public enum STATE {
        PRECONNECT,
        READY,
        WRITING,
        READING,
        NOTIFYING,
        DONE
    }
    private boolean connectionFailureReported = false;
    public class SocketThread extends Thread {
        private Socket socket;
        private DataInputStream istream;
        private DataOutputStream ostream;
        private STATE state;
        private String request;
        private String clientIP;
        private int serialNo;
        private Vector<Document> resultPool;
        private long timeOutMS;
        private boolean closedOnThisSide;
        public STATE getSocketThreadState() {
            return state;
        }
        public SocketThread(long timeOutMS) {
            super();
            this.timeOutMS = timeOutMS;
        }
        public synchronized void sendRequest(String req, String clientIP, Vector<Document> resultPool, int serialNo) {
            if(state == STATE.READY) {
                request = req;
                this.clientIP = clientIP;
                this.resultPool = resultPool;
                this.serialNo = serialNo;
                state = STATE.WRITING;
                notify();
            }
        }
        /**
         * @return "TO" means timeout, "SM" means "serialNo mismatch", "OK" means ok
         */
        public synchronized String finish(int serialNo) {
            if(serialNo != this.serialNo) {
                LOG.info("serialNo mismatch");
                return "SM";
            }
            if(state == STATE.DONE) {
                notify();
                return "OK";
            } else if(state == STATE.READING || state == STATE.WRITING) {
                try {
                    closedOnThisSide = true;
                    socket.close();
                } catch (Exception e){}
            } else if(state == STATE.NOTIFYING) {
                state = STATE.DONE;
                return "OK";
            }
            return "TO";
        }
        public void run() {
            SAXReader reader = new SAXReader();
            while(true) {
                try {
                    state = STATE.PRECONNECT;
                    // connect the socket
                    Thread.sleep(5000);
                    socket = new Socket();
                    try {
                        socket.connect(endpoint);
                    } catch (Exception e) {
                        if(! connectionFailureReported) {
                            LOG.log(Level.INFO, "Failed to connect to " + endpoint, e);
                            connectionFailureReported = true;
                        }
                        continue;
                    }
                    istream = new DataInputStream(socket.getInputStream());
                    ostream = new DataOutputStream(socket.getOutputStream());
                    LOG.info("Connected to vertical searcher: " + socket);
                    connectionFailureReported = false;
                    while(true) {
                        state = STATE.READY;
                        readySet.add(this);
                        // wait for request
                        synchronized(this) {
                            try {
                                wait();
                            } catch (Exception e){}
                            state = STATE.WRITING;
                        }
                        //LOG.info("Sending vertical request " + request + " through " + socket + ", serialNo=" + serialNo);
                        // write the request
                        byte[] requestBytes = request.getBytes("UTF-16LE");
                        ostream.writeInt(requestBytes.length);
                        ostream.write(requestBytes);
                        byte[] addressBytes = clientIP.getBytes("UTF-16LE");
                        ostream.writeInt(addressBytes.length);
                        ostream.write(addressBytes);
                        ostream.flush();
                        // read result
                        state = STATE.READING;
                        int resultSize = istream.readInt();
                        //LOG.info("Receiving vertical result from " + socket + ", size="+resultSize);
                        if(resultSize > 0) {
                            byte[] buffer = new byte[resultSize];
                            istream.readFully(buffer);
                            ByteArrayInputStream bistream = new ByteArrayInputStream(buffer);
                            //LOG.info("Result=" + new String(buffer, "UTF-16LE"));
                            InputStreamReader ireader = new InputStreamReader(bistream, "UTF-16LE");
                            Document doc = reader.read(ireader);
                            synchronized(resultPool) {
                                resultPool.add(doc);
                            }
                            ireader.close();
                            bistream.close();
                        }
                        synchronized(this) {
                            // notify the threads waiting on this SocketThread
                            state = STATE.NOTIFYING;
                            notifyAll();
                            // wait for finish
                            if(state != STATE.DONE) {
                                state = STATE.DONE;
                                try {
                                    wait(timeOutMS);
                                } catch (Exception e){
                                    LOG.info("VerticalSearcher DEBUG: exception happens when waiting for finish: " + e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    LOG.log(Level.INFO, "Exception, closedOnThisSide=" + closedOnThisSide + ", request=" + request, e);
                } finally {
                    closedOnThisSide = false;
                    try {
                        istream.close();
                    } catch (Exception ex) {}
                    try {
                        ostream.close();
                    } catch (Exception ex) {}
                    try {
                        socket.close();
                    } catch (Exception ex) {}
                }
            }
        }
    }
    private InetSocketAddress endpoint;
    private SocketThread[] threads;
    private List<SocketThread> readySet;
    /**
     * Send a request via an available socket.
     * @param req The request is the query string
     * @param resultPool A caller prepared vector to put the result Documents object
     * @return The chosen SocketThread, null if no SocketThread available
     */
    public synchronized SocketThread send(String req, String clientIP, Vector<Document> resultPool, int serialNo) {
        if(!readySet.isEmpty()) {
            SocketThread thread = readySet.get(0);
            readySet.remove(0);
            thread.sendRequest(req, clientIP, resultPool, serialNo);
            return thread;
        }
        connectionFailureReported = false;
        StringBuilder buffer = new StringBuilder();
        for(SocketThread thread : threads) {
            buffer.append(thread.state);
            buffer.append(" ");
        }
        LOG.info("No available SocketThread for vertical searcher " + endpoint + ", states: " + buffer.toString());
        return null;
    }

    public SocketThreadPool(InetSocketAddress endpoint, int size, long threadTimeOut) {
        this.endpoint = endpoint;
        readySet = Collections.synchronizedList(new LinkedList<SocketThread>());
        threads = new SocketThread[size];
        for(int i = 0; i < threads.length; i++) {
            threads[i] = new SocketThread(threadTimeOut);
            threads[i].start();
        }
    }
}
