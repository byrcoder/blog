package toolbox.web;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

import toolbox.misc.LogFormatter;
import toolbox.misc.monitored.AbstractListenerHandler;
import toolbox.misc.monitored.FileUtils;
import toolbox.misc.monitored.IFileListener;
import toolbox.misc.monitored.IMonitoredFilesResource;
import toolbox.misc.net.UrlUtils;

/**
 * 这个类与HttpResource类似，不同的是，HttpResource只维护对一个远程文件的同步，
 * 而这个类维护一个文件列表（file list)，对多个文件一起维护远程同步。
 * 
 * 它所同步的文件有：
 *      1, 文件列表文件(listFile)，文本文件，其中每一行都列出一个要同步的文件名，以#开头的是注释；
 *      2, 其它任何文件，由listFile所列出的文件
 * 
 * 当新增加一个要同步的文件时，必须把该文件的文件名写入listFile中，要删除一个同步的文件时，也
 * 应该把该文件名从listFile中去除。
 * 
 * @author why
 *
 */
public class FileListHttpResource implements IMonitoredFilesResource {
    private static final Logger LOG = LogFormatter.getLogger(FileListHttpResource.class);
    private static boolean IS_WINDOWS = 
        System.getProperty("os.name").toLowerCase().startsWith("win");

    private ScheduledExecutorService scheduler = Executors
                        .newScheduledThreadPool(1, new ThreadFactory() {
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "schedule-thread");
            t.setDaemon(true);
            return t;
        }
    });

    private HttpFile listFile; // 这个文件中存放的是同步的文件列表
    private File localRoot; // 本地存放同步后的文件副本的根目录

    // 被同步的文件 url -> HttpFile
    private ConcurrentHashMap<String, HttpFile> syncFiles = new ConcurrentHashMap<String, HttpFile>();
    
    private ListenerHandler listeners = new ListenerHandler();
    
    // 如果keepInMem为false，则不在内存中保留同步文件的数据，每次比较是否更新都是从File中读取数据
    // 进行比较；如果为true，则在内存中保存该文件的数据，比较是否更新时直接使用内存的数据
    private boolean keepInMem;
    
    public FileListHttpResource(String listFileUrl, File localRoot, long checkInterval) {
        this(listFileUrl, localRoot, checkInterval, true);
    }

    /**
     * @param listFileUrl 列表文件的url
     * @param localRoot 本地目录，存放同步后的远程文件副本
     * @param checkInterval 每隔多长时间检测远程文件是否有变化
     * @param keepInMem 是否保存同步文件的数据在内存中，减少比较文件数据是否变化所需要的io
     */
    public FileListHttpResource(String listFileUrl, File localRoot, long checkInterval, 
            boolean keepInMem) {
        this.keepInMem = keepInMem;
        this.listFile = new HttpFile(listFileUrl, localRoot);
        this.localRoot = localRoot;
        if (!localRoot.exists()) {
            localRoot.mkdirs();
        }
        
        try {
            initSyncFiles();
        } catch (IOException e) {
            LOG.log(Level.WARNING, "exception when initSyncTable", e);
            this.listFile.getLocal().delete();
        }
        
        Runnable checkRunnable = new Runnable() {
            public void run() {
                try {
                    checkUpdate();
                } catch (Throwable e) {
                    LOG.log(Level.WARNING, "check update failed", e);
                }
            }
        };
        scheduler.scheduleWithFixedDelay(checkRunnable, 100, checkInterval,
                TimeUnit.MILLISECONDS);
    }
    
    /**
     * add a listener
     */
    public void registerListener(IFileListener listener) {
        listeners.addListener(listener);
    }
    
    /**
     * 检查本地listFile中所列出来的文件，填充syncFiles
     * 
     * TODO: 正确的逻辑是，每次初始化的时候都从remote下载所有的文件，而不是
     * 检查本地已存在的文件，这样才能保证每次启动都与remote保持一致。(2008-10-24) ??
     * 
     * @throws IOException 
     */
    private void initSyncFiles() throws IOException {
        ArrayList<HttpFile> addedFiles = new ArrayList<HttpFile>();
        ArrayList<HttpFile> removedFiles = new ArrayList<HttpFile>();
        checkLocalListFile(addedFiles, removedFiles);
        
        for (HttpFile file : addedFiles) {
            LOG.info("file " + file.getUrl() + " added to sync table");
            syncFiles.put(file.getUrl(), file);
        }
        
        for (HttpFile file : syncFiles.values()) {
            LOG.info("check file " + file.getUrl());
            checkUpdate(file, null, false);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
            }
        }
    }
    
    private void checkUpdate() throws IOException {
        // check if the listFile has been modified
        ArrayList<HttpFile> addedFiles = new ArrayList<HttpFile>();
        ArrayList<HttpFile> removedFiles = new ArrayList<HttpFile>();

        if (checkUpdate(listFile, null, false)) {
            checkLocalListFile(addedFiles, removedFiles);
        }
        
        // notify deleted files
        for (HttpFile file : removedFiles) {
            LOG.info("file " + file.getUrl() + " removed");
            syncFiles.remove(file.getUrl());
            File local = file.getLocal();
            listeners.fileChanged(local, IFileListener.EVT_FILE_REMOVED);
            local.delete();
        }

        // check modified files
        for (HttpFile file : syncFiles.values()) {
            //LOG.info("check file " + file.getUrl());
            checkUpdate(file, listeners, false);
        }
        
        // check added files
        for (HttpFile file : addedFiles) {
            LOG.info("new file " + file.getUrl() + " added");
            checkUpdate(file, listeners, true);
            syncFiles.put(file.getUrl(), file);
        }
        
    }
    
    /**
     * 检查本地的listFile中的内容与syncFiles中的是否一致，有哪些是新增的文件列表，哪些是去除的
     * @param addedFiles
     * @param removedFiles
     * @throws IOException
     */
    private void checkLocalListFile(List<HttpFile> addedFiles, 
            List<HttpFile> removedFiles) throws IOException {
        
        final Set<String> list = new TreeSet<String>();
        
        InputStream is = null;
        if (keepInMem) {
            byte[] data = listFile.getData();
            if (data==null) {
                listFile.loadDataFromFile();
                data = listFile.getData();
            }
            is = new ByteArrayInputStream(data);
        } else {
            is = new FileInputStream(listFile.getLocal());
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"));
        try {
            String line;
            String listFileName = listFile.getFilename();
            String listFileUrlStr = listFile.getUrl();
            while((line=reader.readLine())!=null) {
                line = line.trim();
                if (line.length()>0 && !line.startsWith("#") && !line.equals(listFileName)) {
                    try {
                        URL listFileUrl = new URL(listFileUrlStr);
                        URL fileUrl = new URL(listFileUrl, line);
                        list.add(fileUrl.toString());
                    } catch (MalformedURLException e) {
                    }
                }
            }
            
        } finally {
            reader.close();
            is.close();
        }
        
        Collection<HttpFile> files = syncFiles.values();
        for (HttpFile file : files) {
            if (!list.contains(file.getUrl())) {
                removedFiles.add(file);
                //files.remove(file);
            }
        }
                
        for (String url : list) {
            if (!syncFiles.containsKey(url)) {
                HttpFile file = new HttpFile(url, localRoot);
                addedFiles.add(file);
            }
        }
    }
    
    /**
     * 检查file是否有更新，如果有则通知listener
     * 
     * @param file
     * @param listener
     * @param force 如果为true，则无论数据有没有变化，都从remote下载文件并通知给listener
     * @return 返回true如果数据下载成功并且有变化，否则返回false（下载失败或者数据没有变化）
     * @throws IOException
     */
    private boolean checkUpdate(HttpFile file, IFileListener listener, boolean force) throws IOException {
        File local = file.getLocal();
        File tmpFile = new File(local + ".tmp");

        HttpClient client = new HttpClient();
        GetMethod method = new GetMethod(file.getUrl());
        
        String lastModifiedString = file.getLastModifiedString();
        method.addRequestHeader("Connection", "close");
        if (lastModifiedString != null) {
            method.addRequestHeader("If-Modified-Since", lastModifiedString);
        }

        int code = client.executeMethod(method);
        if (code!=200) return false;
        
        OutputStream os = null;
        if (keepInMem) {
            os = new ByteArrayOutputStream();
        } else {
            os = new FileOutputStream(tmpFile);
        }
        //FileOutputStream os = new FileOutputStream(tmpFile);
        //ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            InputStream is = method.getResponseBodyAsStream();
            try {
                byte[] buf = new byte[4096];
                int len;
                while ((len = is.read(buf)) > 0) {
                    os.write(buf, 0, len);
                }
            } finally {
                is.close();
            }
        } finally {
            os.close();
        }
        
        byte[] newData = null;
        if (keepInMem) {
            newData = ((ByteArrayOutputStream)os).toByteArray();
            if (!force && local.exists() && Arrays.equals(file.getData(), newData)) {
                return false;
            }
            FileOutputStream fos = new FileOutputStream(tmpFile);
            try {
                fos.write(newData);
            } finally {
                fos.close();
            }
            //file.setData(newData);
        } else {
            if (!force && local.exists() && FileUtils.equals(local, tmpFile)) {
                return false;
            }
        }
        
        LOG.info("New data saved in temp file "
                + tmpFile.getAbsolutePath() + " ...");
        int evt = local.exists() && !force ? IFileListener.EVT_FILE_MODIFIED : 
            IFileListener.EVT_FILE_CREATED;
        
        if (IS_WINDOWS) {
            local.delete();
        }
        if (!tmpFile.renameTo(local)) {
            throw new IOException("rename " + tmpFile.getAbsolutePath()
                    + " to " + local.getAbsolutePath() + " failed");
        }
        file.setData(newData);
        
        LOG.info("New data renamed to " + local.getAbsolutePath());

        if (listener!=null)
            listener.fileChanged(local, evt);

        Header lastModifiedHeader = method.getResponseHeader("Last-Modified");
        if (lastModifiedHeader != null) {
            String tmp = lastModifiedHeader.getValue();
            if (tmp != null && tmp.length() > 0) {
                file.setLastModifiedString(tmp);
            }
        }
        
        synchronized (this) {
            this.notifyAll();
        }
        
        return true;
    }

    /**
     * 同步文件信息
     */
    class HttpFile {
        private String url;
        private File local;
        //private String filename; // file name
        private byte[] data = null; // 文件的内容，放在内存中，与新的数据进行比较
        private String lastModifiedString = null;
        
        public HttpFile(String url, File root) {
            this.url = url;
            String filename = UrlUtils.getUrlFile(url);
            this.local = new File(root, filename);
            
            if (keepInMem && local.exists()) {
                try {
                    loadDataFromFile();
                } catch (IOException e) {
                }
            }
        }

        public String getLastModifiedString() {
            return lastModifiedString;
        }

        public void setLastModifiedString(String lastModifiedString) {
            this.lastModifiedString = lastModifiedString;
        }

        public String getUrl() {
            return url;
        }

        public File getLocal() {
            return local;
        }
        
        public String getFilename() {
            return local.getName();
        }
        
        public byte[] getData() {
            return data;
        }

        public void setData(byte[] data) {
            this.data = data;
        }
        
        public void loadDataFromFile() throws IOException {
            FileInputStream is = new FileInputStream(local);
            try {
                data = new byte[is.available()];
                is.read(data);
            } finally {
                is.close();
            }
        }

        @Override
        public boolean equals(Object obj) {
            if (obj==null) return false;
            if (obj==this) return true;
            if (!(obj instanceof HttpFile)) return false;
            HttpFile o = (HttpFile)obj;
            return url.equals(o.url);
        }

        @Override
        public int hashCode() {
            return url==null ? 0 : url.hashCode();
        }
        
    }
    
    class ListenerHandler extends AbstractListenerHandler<IFileListener> 
                                                    implements IFileListener {
        public synchronized void fileChanged(File file, int evt) {
            notifyAllListeners(file, evt);
        }

        @Override
        protected void notifyListener(IFileListener listener, Object... args) {
            File file = (File)args[0];
            int evt = (Integer)args[1];
            listener.fileChanged(file, evt);
        }
        
    }

    public File[] getFiles() {
        ArrayList<File> files = new ArrayList<File>();
        for (HttpFile hf : syncFiles.values()) {
            files.add(hf.getLocal());
        }
        return files.toArray(new File[files.size()]);
    }
    
}
