package toolbox.web.vertical;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;

import toolbox.misc.LogFormatter;
import toolbox.web.vertical.SocketThreadPool.STATE;
import toolbox.web.vertical.SocketThreadPool.SocketThread;

public class VerticalSearcher {
    private static final Logger LOG = LogFormatter.getLogger(VerticalSearcher.class.getName());
    public class Receipt {
        private Vector<Document> results;
        private Vector<SocketThread> threads;
        private long startTime;
        private int serialNo;
        private String req;
        private Receipt(Vector<Document> results, Vector<SocketThread> threads, String req, int serialNo) {
            this.results = results;
            this.threads = threads;
            this.serialNo = serialNo;
            this.req = req;
            startTime = System.currentTimeMillis();
        }
    }
    private SocketThreadPoolFactory factory;
    public void setFactory(SocketThreadPoolFactory factory) {
        this.factory = factory;
    }
    private SocketThreadPool[] servers;
    public void setServers(String[] serverAddrs) {
        servers = new SocketThreadPool[serverAddrs.length];
        for(int i = 0; i < servers.length; i++) {
            String[] split = serverAddrs[i].split(":");
            servers[i] = factory.createPool(new InetSocketAddress(split[0], Integer.parseInt(split[1])));
        }
    }
    /**
     * The minimum time to process a request. (millis)
     */
    private long minWaitTime = 200;
    public void setMinWaitTime(long millis) {
        minWaitTime = millis;
    }
    private int serialNo = 0;
    private synchronized int nextSerialNo() {
        return serialNo++;
    }
    /**
     * Send a request to all existing back-end servers
     * @param req
     * @return
     */
    public Receipt sendRequest(String req, String clientIP) {
		req = req.replaceAll("\"", "");
        Vector<Document> resultPool = new Vector<Document>();
        Vector<SocketThread> threads = new Vector<SocketThread>();
        Receipt receipt = new Receipt(resultPool, threads, req, nextSerialNo());
        for(SocketThreadPool pool : servers) {
            SocketThread thread = pool.send(req, clientIP, resultPool, receipt.serialNo);
            receipt.threads.add(thread);
        }
        return receipt;
    }

    /**
     * Map the result types to Spring MVC model keys
     */
    private HashMap<String, String> resultMap;
    public void setResultMap(String[] settings) {
        resultMap = new HashMap<String, String>();
        for(String setting : settings) {
            String[] split = setting.split(":");
            if(split.length == 2) {
                resultMap.put(split[0], split[1]);
            }
        }
    }

    /**
     * The score threshold of results. Results with scores less than this threshold will
     * be ignored.
     */
    private int scoreThreshold = 0;
    public void setScoreThreshold(int threshold) {
        this.scoreThreshold = threshold;
    }

    /**
     * Set the limits of number of results every area can display.
     * If an area's limit is not set, the default is "unlimited".
     */
    private HashMap<String, Integer> areaLimits = new HashMap<String, Integer>();
    public void setAreaLimits(String[] settings) {
        areaLimits = new HashMap<String, Integer>();
        for(String setting : settings) {
            String[] split = setting.split(":");
            if(split.length == 2) {
                areaLimits.put(split[0], Integer.parseInt(split[1]));
            }
        }
    }
    /**
     * Finish the request and write the results to the Spring MVC model. Those theads that haven't got replies yet will
     * be interrupted by closing the sockets.
     * Generally the keys of the model represents the display areas in the result page, like onebox, rightbox etc.
     * The values of the model are Vector<HashMap<String, String>>, whose keys are attribute names of the result elements and
     * values are attributes values. The text (if exists) is treated as a special attribute "__text".
     * @param receipt The Receipt object returned by sendRequest()
     * @param model The Spring MVC model, where I put the results.
     * @return
     */
    public void finish(Receipt receipt, HashMap<String, Object> model) {
        if(receipt == null) {
            LOG.severe("receipt is null");
            return;
        }
        if( receipt.threads.size() == 0) {
            return;
        }
        for(SocketThread thread : receipt.threads) {
            long timeLeft = minWaitTime - System.currentTimeMillis() + receipt.startTime;
            if(timeLeft <= 0) {
                break;
            } else {
                if(thread != null) {
                    synchronized(thread) {
                        if(thread.getSocketThreadState() == STATE.WRITING || thread.getSocketThreadState() == STATE.READING) {
                            LOG.info("timeLeft=" + timeLeft);
                                try {
                                    // it will be notified in SocketThread.run()
                                    thread.wait(timeLeft);
                                } catch (Exception e){}
                        }
                    }
                }
            }
        }
        // finish the SocketThreads
        StringBuilder statusLog = new StringBuilder();
        statusLog.append("Vertical results for " + receipt.req + " :");
        for(int i = 0; i < receipt.threads.size(); i++) {
            SocketThread thread = receipt.threads.get(i);
            String status;
            if(thread != null) {
                status = thread.finish(receipt.serialNo);
            } else {
                status = "NA";
            }
            statusLog.append(" " + status);
            LOG.info("@@ANALYSIS@@ vertical.status." + i + "=" + status);
        }
        LOG.info(statusLog.toString());
        synchronized(receipt.results) {
            // remove empty results
            for(Iterator<Document> it = receipt.results.iterator(); it.hasNext(); ) {
                Document doc = it.next();
                if(doc.getRootElement() == null || doc.getRootElement().elements() == null 
                        || doc.getRootElement().elements().isEmpty()) {
                    it.remove();
                }
            }
            model.put("verticalResultDocuments",receipt.results);
            for(Document doc : receipt.results) {
                Element root = doc.getRootElement();
                for ( Iterator i = root.elementIterator(); i.hasNext(); ) {
                    Element element = (Element) i.next();
                    String name = element.getName();
                    String area = resultMap.get(name);
                   // LOG.info("Got a result: " + name + ", mapped to area:" + area);
                    if(area == null) {
                        LOG.warning("Unresolved result element: "+name);
                        continue;
                    }
                    // a doc will generate a new item
                    HashMap<String, String> item = new HashMap<String, String>();
                    // add all attributes into this item
                    for(Iterator it = element.attributeIterator(); it.hasNext(); ) {
                        Attribute attr = (Attribute)it.next();
                        item.put(attr.getName(), attr.getStringValue());
                        if("score".equalsIgnoreCase(attr.getName())) {
                            // XXX the "score" attribute is excluded from the XML doc in the result
                            // because XML doc is visible to end users, who may guess the meaning of it.
                            // In fact the score attribute has been never been assigned meaningfully.
                            it.remove();
                        }
                    }
                    item.put("__name", name);
                    // add text value
                    if(element.getText() != null) {
                        item.put("__text", element.getText());
                    }
                    try {
                        int score = 1;
                        String scoreStr = item.get("score");
                        if(scoreStr != null) {
                            score = Integer.parseInt(scoreStr);
                        }
                        // add this item, if its score is not less than the threshold
                        if(score >= scoreThreshold) {
                            @SuppressWarnings("unchecked")
                                Vector<HashMap<String, String>> value = (Vector) model.get(area);
                            if(value == null) {
                                // first item in this area
                                value = new Vector<HashMap<String, String>>();
                                model.put(area, value);
                            }
                            Integer areaLimit = areaLimits.get(area);
                            if(areaLimit != null && areaLimit <= value.size()) {
                                // this area is already full, find the less scored item
                                int lowest = Integer.MAX_VALUE;
                                int lowestIndex = -1;
                                for(int j = 0; j < value.size(); j++) {
                                    HashMap<String, String> oldItem = (HashMap<String, String>) value.get(j);
                                    int s = Integer.parseInt(oldItem.get("score"));
                                    if(s < lowest) {
                                        s = lowest;
                                        lowestIndex = j;
                                    }
                                }
                                // if the new item is higher-scored than the lowest one, replace it
                                if(score > lowest) {
                                    value.set(lowestIndex, item);
                                }
                            } else {
                                value.add(item);
                            }
                        }
                    } catch (Exception e){
                        LOG.log(Level.SEVERE, "Exception when adding result items", e);
                    }
                }
            }
        }
    }
}
