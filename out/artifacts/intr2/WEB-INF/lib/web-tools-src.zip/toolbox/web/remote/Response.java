/**
 * 
 */
package toolbox.web.remote;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import odis.serialize.IWritable;

/**
 * 服务器端向客户端返回的结果.
 * 结果的生成形式如下:
 * 
 * <code>
 * Response res = new Response();
 * ...
 * // 生成一条结果记录
 * Result resultRecord = new Result();
 * resultRecord.setName(name); // 设置结果的名称
 * resultRecord.getProperties().put(key, value);
 * ...
 * // 将该条结果记录添加到Response中
 * res.addResultRecord(resultRecord); 
 * ...
 * 
 * @author ares
 */
public class Response implements IWritable {
    private ArrayList<Result> result = new ArrayList<Result>();

    public List<Result> getResults() {
        return result;
    }
    /**
     * 获得返回结果的记录条目
     * @return
     */
    public int getRecordNumber() {
        return result.size();
    }

    /**
     * 获得第index条结果记录
     * @param index
     * @return
     */
    public Result getResultRecord(int index) {
        return result.get(index);
    }

    /**
     * 添加一条结果记录
     * @param record
     */
    public void addResultRecord(Result record) {
        result.add(record);
    }

    public void readFields(DataInput in) throws IOException {
        result.clear();
        int recordNumber = in.readInt();
        for (int i = 0; i < recordNumber; i++) {
            Result record = new Result();
            record.readFields(in);
            result.add(record);
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(result.size());
        for (Result record : result) {
            record.writeFields(out);
        }
    }

    public IWritable copyFields(IWritable value) {
        Response res = (Response)value;
        this.result.clear();
        for(Result r : res.result) {
            Result copy = new Result();
            copy.copyFields(r);
            this.result.add(copy);
        }
        return this;
    }

    public String toString() {
        return "[Response results=" + result.toString() + "]";
    }
}
