package toolbox.web;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import toolbox.misc.LogFormatter;
/**
 * This controller just passes all the parameters to the Velocity view.
 * @author zhangkun
 *
 */
public class GenericTemplateController implements Controller {
    private static final Logger LOG = LogFormatter.getLogger(GenericTemplateController.class.getName());
    private String viewPath;
    public void setViewPath(String viewPath) {
        this.viewPath = viewPath;
    }
    public String getViewPath() {
        return viewPath;
    }

    protected String defaultURLEncoding = "UTF-8";
    protected String tomcatURLEncoding = "ISO-8859-1";
    public void setDefaultURLEncoding(String encoding) {
        defaultURLEncoding = encoding;
    }
    public void setTomcatURLEncoding(String encoding) {
        tomcatURLEncoding = encoding;
    }
    protected String redecode(String input, String encoding) throws UnsupportedEncodingException {
        if(input == null) return null;
        if(encoding == null) {
            encoding = defaultURLEncoding;
        }
        String newString;
        try {
            newString = new String(input.getBytes(tomcatURLEncoding), encoding);
        } catch(UnsupportedEncodingException e) {
            newString = new String(input.getBytes(tomcatURLEncoding), defaultURLEncoding);
        }
        return newString;
    }
    protected byte[] getOriginalBytes(String input) throws UnsupportedEncodingException {
        return input.getBytes(tomcatURLEncoding);
    }

    protected void putUserAgentContext(HashMap<String, Object> model, HttpServletRequest req) {
        String userAgent = req.getHeader("User-Agent");
        if(userAgent != null) {
            int pos = 0;
            if((pos = userAgent.indexOf("MSIE")) != -1) {
                 model.put("userAgent", "ie");
                 String[] split = userAgent.substring(pos).split("[ ;/]+");
                 if(split.length > 1) {
                     model.put("userAgentVersion", split[1]);
                 }
            } else if((pos = userAgent.indexOf("Firefox")) != -1) {
                 model.put("userAgent", "firefox");
                 String[] split = userAgent.substring(pos).split("[ ;/]+");
                 if(split.length > 1) {
                     model.put("userAgentVersion", split[1]);
                 }
            } else {
                 model.put("userAgent", "other");
            }
        }
        LOG.info("userAgent=" + model.get("userAgent") + ", version=" + model.get("userAgentVersion"));
    }

    @SuppressWarnings("unchecked")
    protected HashMap<String, Object> getModel(HttpServletRequest req) throws Exception {
        String userName = (String) req.getAttribute("__email__");
        if(userName == null) {
            userName = "";
        }
        Map<String, Object> parameters = req.getParameterMap();
        HashMap<String, Object> model = new HashMap<String, Object>();
        for(String key : parameters.keySet()) {
            model.put(key, redecode(req.getParameter(key), null));
        }
        model.put("userName", userName);
        model.put("viewUtils", ViewUtils.getInstance());
        putUserAgentContext(model, req);
        return model;
    }
    public ModelAndView handleRequest(HttpServletRequest req,
            HttpServletResponse res) throws Exception {
        return new ModelAndView(getViewPath(), getModel(req));
    }

}
