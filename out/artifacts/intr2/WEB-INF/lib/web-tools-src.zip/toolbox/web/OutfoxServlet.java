package toolbox.web;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.springframework.web.servlet.DispatcherServlet;

import toolbox.misc.LogFormatter;

@SuppressWarnings("serial")
public class OutfoxServlet extends DispatcherServlet {
    private static final Logger LOG = LogFormatter.getLogger(OutfoxServlet.class.getName());
    @Override
    public void init(ServletConfig config) throws ServletException{
        LogFormatter.setShowLoggerNames(true);
        LOG.info("OutfoxServlet Initializing...");
        String home = config.getServletContext().getRealPath("WEB-INF");
        LOG.info("Home directory="+home);
        System.setProperty("outfox.home", home);
        System.setProperty("nutch.home", home);
        System.setProperty("odis.home", home);
        System.setProperty("native.home", home);
        System.setProperty("resource_manager.home", home);
        System.setProperty("toolbox.wordsegment.lib", home + "/lib/wordsegment");
        try {
            TermLabeler.setStopWordPath(home + "/stop.txt");
            LOG.info("Loaded stop words from " + home + "/stop.txt");
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Failed to load stop words for TermLabeler", e);
        }
        super.init(config);
    }
}
