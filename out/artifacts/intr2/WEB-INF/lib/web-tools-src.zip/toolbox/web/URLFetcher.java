package toolbox.web;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;

import toolbox.misc.LogFormatter;
import toolbox.misc.net.UrlUtils;

/**
 * thread safe fetcher based on httpclient.
 * 
 * @author shicq
 */
public class URLFetcher {
    protected static final Logger LOG = LogFormatter.getLogger(URLFetcher.class
            .getName());

    protected int maxConnection = 64;

    protected int timeoutConnection = 1000;

    protected int timeoutSocket = 1000;

    protected int maxContentSize = 2 * 1024 * 1024;

    protected int maxConnectionPerIp = 8;

    protected static URLFetcher singleton = null;

    // singleton mode.
    public static final URLFetcher getInstance() {
        if (singleton == null) {
            synchronized (URLFetcher.class) {
                if (singleton == null) {
                    singleton = new URLFetcher();
                    singleton.init();
                }
            }
        }
        return singleton;
    }

    public static final Header BROWSER_HEADER = new Header(
            "User-Agent",
            "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11");

    private HttpClient client;

    private MultiThreadedHttpConnectionManager connectionManager;

    /**
     * initialize connection manager & http client.
     */
    public void init() {
        connectionManager = new MultiThreadedHttpConnectionManager();
        connectionManager.getParams().setMaxTotalConnections(maxConnection);
        connectionManager.getParams().setConnectionTimeout(
                timeoutConnection * 3);
        connectionManager.getParams().setSoTimeout(timeoutSocket);
        connectionManager.getParams().setSendBufferSize(maxContentSize);
        connectionManager.getParams().setReceiveBufferSize(maxContentSize);
        connectionManager.getParams().setDefaultMaxConnectionsPerHost(
                maxConnectionPerIp);
        client = new HttpClient(connectionManager);
        client.getParams().setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
    }

    // fetch url into byte[]
    public byte[] fetchAsByte(String url) {
        return fetchAsByte(url, true);
    }
    
    // fetch url into byte[]
    public byte[] fetchAsByte(String url, boolean followRedirects) {
        LOG.info("Fetch url=" + url);
        try {
            GetMethod method = getMethod(url, followRedirects);
            try {
                int code = client.executeMethod(method);
                if (code == HttpStatus.SC_OK) {
                    LOG.info("Fetch Status=OK url=" + url);
                    return method.getResponseBody();
                }
            } finally {
                method.releaseConnection();
            }
        } catch (Throwable th) {
            LOG.log(Level.WARNING, "fetch_url=" + url, th);
            th.printStackTrace();
        }
        return null;
    }

    
    // fetch url into InputStream
    public InputStream fetchAsStream(String url) {
        return fetchAsStream(url, true);
    }

    // fetch url into InputStream
    public InputStream fetchAsStream(String url, boolean followRedirects) {
        LOG.info("Fetch url=" + url);
        GetMethod method = getMethod(url, followRedirects);
        try {
            int code = client.executeMethod(method);
            if (code == HttpStatus.SC_OK) {
                LOG.info("Fetch Status=OK url=" + url);
                byte[] bytes = method.getResponseBody();
                if (bytes != null) {
                    return new ByteArrayInputStream(bytes);
                }
            }
        } catch (Throwable th) {
            LOG.log(Level.WARNING, "fetch_url=" + url, th);
        } finally {
            method.releaseConnection();
        }

        return null;
    }
    
    // fetch url into String
    public String fetchAsString(String url) {
        return fetchAsString(url, true);
    }

    // fetch url into String
    public String fetchAsString(String url, boolean followRedirects) {
        LOG.info("Fetch url=" + url);
        return execute(getMethod(url, followRedirects));
    }

    /**
     * @param method
     * @return
     */
    private String execute(GetMethod method) {
        String url = null;
        try {
            url = method.getURI().toString();
            int code = client.executeMethod(method);
            if (code == HttpStatus.SC_OK) {
                LOG.info("Fetch Status=OK url=" + url);
                return method.getResponseBodyAsString();
            }
        } catch (Throwable th) {
            LOG.log(Level.WARNING, "fetch_url=" + url, th);
        } finally {
            method.releaseConnection();
        }
        return null;
    }

    /**
     * @param url
     * @param followRedirects
     * @return
     */
    private GetMethod getMethod(String url, boolean followRedirects) {
        GetMethod method = new GetMethod(url);
        method.setFollowRedirects(followRedirects);
        method.setRequestHeader(BROWSER_HEADER);
        method.setRequestHeader("Referer", UrlUtils.getHostTemplate(url) + "/");
        return method;
    }
    
    /**
     * 带着cookie去抓取，会自动followredirects
     * @param url
     * @param cookieHeader
     *          cookie的具体内容。该值将直接被写到Request的Header中。需要自己将Cookie转换为String
     * @return
     */
    public String fetchAsString(String url, String cookieHeader) {
        GetMethod method = getMethod(url, false);
        method.addRequestHeader("Cookie", cookieHeader);
        
        return execute(method);
    }
    
    public static void main(String[] args) {
        String ret = URLFetcher.getInstance().fetchAsString("http://mailtest.163.com/auth/login.s", "NTES_SESS=7HeqgvuYYwG3.evNb.hqgi2.dnjuQ6IMlsDiK_QAOckfsHBnse9N0vfXURSBJaKQEYNqYIwiQgcjU20RRFsMDuYzwI9kdsv7367gqjgghyrJLaigcvROzHnFN");
        System.out.println(ret);
    }

    // check whether url exist, retry 3 times.
    public boolean exist(String url) {
        return exist(url, true);
    }
    
    // check whether url exist, retry 3 times.
    public boolean exist(String url, boolean followRedirects) {
        // Create a method instance.
        HeadMethod method = new HeadMethod(url);
        method.setFollowRedirects(followRedirects);
        // Provide custom retry handler is necessary
        method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,
                new DefaultHttpMethodRetryHandler(3, false));
        try {
            // Execute the method.
            int statusCode = client.executeMethod(method);
            if (statusCode == HttpStatus.SC_OK) {
                return true;
            }
        } catch (Throwable th) {
            LOG.log(Level.WARNING, "fetch_url=" + url, th);
        } finally {
            method.releaseConnection();
        }
        return false;
    }
    

    public void setMaxConnection(int maxConnection) {
        this.maxConnection = maxConnection;
    }

    public void setTimeoutConnection(int timeoutConnection) {
        this.timeoutConnection = timeoutConnection;
    }

    public int getTimeoutSocket() {
        return timeoutSocket;
    }

    public void setTimeoutSocket(int timeoutSocket) {
        this.timeoutSocket = timeoutSocket;
    }

    public int getMaxConnection() {
        return maxConnection;
    }

    public int getTimeoutConnection() {
        return timeoutConnection;
    }

    public int getMaxContentSize() {
        return maxContentSize;
    }

    public int getMaxConnectionPerIp() {
        return maxConnectionPerIp;
    }

    public void setMaxContentSize(int maxContentSize) {
        this.maxContentSize = maxContentSize;
    }

    public void setMaxConnectionPerIp(int maxConnectionPerIp) {
        this.maxConnectionPerIp = maxConnectionPerIp;
    }
}
