/**
 * 
 */
package toolbox.web.remote;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * 客户端向服务器端发送的请求，用户可以用{@link #getAttributeMap()}方法对需要传输的其它参数进行配置
 * @author ares
 */
public class Request implements IWritable {

    public Request() {
        attrs = new WritableProperties();
    }
    
    /**
     * 初始化请求内容
     * @param query 查询
     * @param ip 查询来自的ip
     * @param user 用户名
     */
    public Request(String query, String ip, String user) {
        this.query = query;
        this.ip = ip;
        this.user = user;
        time = System.currentTimeMillis();
        attrs = new WritableProperties();
    }
    
    private WritableProperties attrs;
    
    private long time;
    
    private String query;

    private String ip;

    private String user;

    public String getQuery() {
        return query;
    }

    public String getIP() {
        return ip;
    }

    public String getUser() {
        return user;
    }
    
    public WritableProperties getAttributeMap() {
        return attrs;
    }

    public void readFields(DataInput in) throws IOException {
        time = in.readLong();
        query = StringWritable.readString(in);
        ip = StringWritable.readStringNull(in);
        user = StringWritable.readStringNull(in);
        attrs.readFields(in);
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(time);
        StringWritable.writeString(out, query);
        StringWritable.writeStringNull(out, ip);
        StringWritable.writeStringNull(out, user);
        attrs.writeFields(out);
    }

    public IWritable copyFields(IWritable value) {
        return null;
    }

    public String toString() {
        return "[Request query=" + query + " ip=" + ip + " user=" + user
                + " attrs=" + attrs + "]";
    }
}
