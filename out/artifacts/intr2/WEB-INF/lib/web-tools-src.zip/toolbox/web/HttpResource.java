package toolbox.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Resource loaded and updated by http protocol. We recommand the callback
 * interface, which needs no time-polling.
 * 
 * @author river
 */
public class HttpResource {
    private static final Log LOG = LogFactory.getLog(HttpResource.class);

    private static boolean IS_WINDOWS = System.getProperty("os.name")
            .toLowerCase().startsWith("win");

    private String url;

    private File local;

    private String lastModifiedString = null;

    private List<ListenerItem> listeners = new ArrayList<ListenerItem>();

    private ScheduledExecutorService scheduler = Executors
            .newScheduledThreadPool(1, new ThreadFactory() {
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "schedule-thread");
                    t.setDaemon(true);
                    return t;
                }
            });

    /**
     * Create HttpResource with the given url of resource and copy the data into
     * local file "local". The HttpResource should check for the updating with
     * interval "checkInterval(ms)".
     * 
     * @param url
     * @param local
     * @param checkInterval
     */
    public HttpResource(String url, File local, long checkInterval) {
        this.url = url;
        this.local = local;
        Runnable checkRunnable = new Runnable() {
            public void run() {
                try {
                    checkUpdate();
                } catch (Throwable e) {
                    LOG.warn("check update from " + HttpResource.this.url
                            + " to " + HttpResource.this.local + " failed", e);
                }
            }
        };
        scheduler.scheduleWithFixedDelay(checkRunnable, 100, checkInterval,
                TimeUnit.MILLISECONDS);
    }

    /**
     * Register a callback interface on file changing, this interface should be
     * called anytime the file is changed, and it is called on registered if the
     * file is exist already.
     * 
     * @param listener
     */
    public void registerListener(FileChangeListener listener) {
        synchronized (this) {
            if (local.exists()) {
                listener.onFileChange(local);
                listeners.add(new ListenerItem(listener, local.lastModified()));
            } else {
                listeners.add(new ListenerItem(listener, 0));
            }
        }
    }

    public File getFile() {
        return local;
    }

    /**
     * Return the file until local file is ready.
     * 
     * @return
     */
    public File acquireFile() {
        while (!local.exists()) {
            synchronized (this) {
                try {
                    this.wait(10000);
                } catch (InterruptedException e) {}
            }
        }

        return local;
    }

    private boolean equals(File f1, File f2) throws IOException {
        if (f1.length() != f2.length())
            return false;

        FileInputStream is1 = new FileInputStream(f1);
        byte[] buf1;
        try {
            buf1 = new byte[is1.available()];
            is1.read(buf1);
        } finally {
            is1.close();
        }

        FileInputStream is2 = new FileInputStream(f2);
        byte[] buf2;
        try {
            buf2 = new byte[is2.available()];
            is2.read(buf2);
        } finally {
            is2.close();
        }

        return Arrays.equals(buf1, buf2);
    }

    /**
     * Check for the updating of http resource.
     * 
     * @throws IOException
     */
    private void checkUpdate() throws IOException {
        HttpClient client = new HttpClient();
        GetMethod method = new GetMethod(url);
        
        method.addRequestHeader("Connection", "close");
        if (lastModifiedString != null) {
            method.addRequestHeader("If-Modified-Since", lastModifiedString);
        }

        int code = client.executeMethod(method);
        if (code == 200) {
            File tmpFile = new File(local + ".tmp");
            FileOutputStream fos = new FileOutputStream(tmpFile);
            try {
                InputStream is = method.getResponseBodyAsStream();
                try {
                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = is.read(buf)) > 0) {
                        fos.write(buf, 0, len);
                    }
                } finally {
                    is.close();
                }
            } finally {
                fos.close();
            }

            if (!local.exists() || !equals(local, tmpFile)) {
                LOG.info("New data saved in temp file "
                        + tmpFile.getAbsolutePath() + " ...");
                if (IS_WINDOWS) {
                    local.delete();
                }
                if (!tmpFile.renameTo(local)) {
                    throw new IOException("rename " + tmpFile.getAbsolutePath()
                            + " to " + local.getAbsolutePath() + " failed");
                }
                LOG.info("New data renamed to " + local.getAbsolutePath());

                synchronized (this) {
                    long lastModified = local.lastModified();
                    for (ListenerItem item: listeners) {
                        if (item.lastModified != lastModified) {
                            LOG.info("Call onFileChange() on item " + item
                                    + "(" + item.lastModified + " != "
                                    + lastModified + ")");
                            item.listener.onFileChange(local);
                            item.lastModified = lastModified;
                        } else {
                            LOG.warn("Item time is same to the new file ("
                                    + item.lastModified + "==" + lastModified
                                    + "), could it be possible?");
                            // mode by likui 2007.06.27
                            // 即使时间比较相同也触发回调函数
                            item.listener.onFileChange(local);
                        }
                    }
                }
            }

            Header lastModifiedHeader = method
                    .getResponseHeader("Last-Modified");
            if (lastModifiedHeader != null) {
                String tmp = lastModifiedHeader.getValue();
                if (tmp != null && tmp.length() > 0) {
                    lastModifiedString = tmp;
                }
            }

            synchronized (this) {
                this.notifyAll();
            }
        }
    }

    /**
     * Callback interface on file changing.
     * 
     * @author river
     */
    public static interface FileChangeListener {
        public void onFileChange(File file);
    }

    private class ListenerItem {
        private FileChangeListener listener;

        private long lastModified;

        public ListenerItem(FileChangeListener listener, long lastModified) {
            this.listener = listener;
            this.lastModified = lastModified;
        }

    }

}
