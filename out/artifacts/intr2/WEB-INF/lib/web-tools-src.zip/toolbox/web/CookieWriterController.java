package toolbox.web;

import java.util.logging.Logger;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import toolbox.misc.LogFormatter;

public class CookieWriterController implements Controller {
    private static final Logger LOG = LogFormatter.getLogger(CookieWriterController.class.getName());
    private int defaultMaxAge = 3600 * 24 * 365 * 30; // seconds
    public ModelAndView handleRequest(HttpServletRequest req,
            HttpServletResponse res) throws Exception {
        String name = req.getParameter("n");
        if(name == null) {
            return null;
        }
        String value = req.getParameter("v");
        if(value == null) {
            value = "";
        }
        String ageString = req.getParameter("age");
        int age = defaultMaxAge;
        if(ageString != null) {
            try {
                age = Integer.parseInt(ageString);
            } catch(Exception e) {}
        }
        String domain = req.getParameter("domain");
        Cookie cookie = new Cookie(name, value);
        if(domain != null) {
            cookie.setDomain(domain);
        }
        cookie.setMaxAge(age);
        res.addCookie(cookie);
        LOG.info("Sending cookie:" + name + "=" + value + ", age=" + age + ", domain=" + domain);
        return null;
    }
}
