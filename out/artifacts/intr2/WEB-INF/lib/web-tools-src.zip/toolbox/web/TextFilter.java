package toolbox.web;

import java.util.Vector;

/**
 * Replace some substrings of the input string
 * @author zhangkun
 */
public class TextFilter {
    private static class Policy {
        public String find;
        public String replace;
        public Policy(String find, String replace) {
            this.find = find;
            this.replace = replace;
        }
    }
    Vector<Policy> policies;
    public TextFilter() {
        policies = new Vector<Policy>();
    }
    public void addPolicy(String find, String replace) {
        policies.add(new Policy(find, replace));
    }
    public String filter(String input) {
        String result = input;
        for(Policy p : policies) {
            result = result.replaceAll(p.find, p.replace);
        }
        return result;
    }
    public String[] filter(String[] input) {
        String[] result = new String[input.length];
        for(int i = 0; i < result.length; i++) {
            result[i] = filter(input[i]);
        }
        return result;
    }
}
