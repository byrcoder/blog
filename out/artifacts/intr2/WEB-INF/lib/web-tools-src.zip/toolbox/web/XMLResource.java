/**
 * @(#)ConfigUtils.java, Dec 22, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.web;

import java.io.File;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.Document;

import toolbox.misc.LogFormatter;
import toolbox.web.FileResource;
import toolbox.web.HttpResource;
import toolbox.web.StringList;
import toolbox.web.XMLUtils;

/**
 * combining FileResource & HttpResource &XMLUtils.
 * to provide a xml visitor.
 * @author shicq
 * 
 */
public class XMLResource implements toolbox.web.HttpResource.FileChangeListener {
	public static final Logger LOG = LogFormatter.getLogger(StringList.class);

	String uri;

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public XMLResource() {
	}

	public static XMLResource getInstance(String uri, long checkInterval){
		return new XMLResource(uri, checkInterval);
	}

	public static XMLResource getInstance(String uri){
		return new XMLResource(uri);
	}

	public XMLResource(String uri) {
		this(uri, 300000);
	}

	public XMLResource(String uri, long checkInterval) {
		this.uri = uri;
		this.checkInterval = checkInterval;
		this.init();
	}

	Document doc = null;

	public Document getDoc() {
		return doc;
	}

	// 5 minutes
	long checkInterval = 300000;

	final ReentrantLock lock = new ReentrantLock();

	public long getCheckInterval() {
		return checkInterval;
	}

	public void setCheckInterval(long checkInterval) {
		this.checkInterval = checkInterval;
	}

	@Override
	public void onFileChange(File file) {
		try {
			lock.lock();
			doc = XMLUtils.read(file);
		} catch (Throwable th) {
			final String msg = this + " onFileChange fail.";
			LOG.log(Level.WARNING, msg, th);
		} finally {
			lock.unlock();
		}
	}

	public String getString(String xpathStr) {
		try {
			lock.lock();
			return XMLUtils.getText(doc, xpathStr);
		} finally {
			lock.unlock();
		}
	}

	/**
	 * initialize the string list;
	 */
	public void init() {
		if (uri.trim().toLowerCase().startsWith("http://")) {
			File localDirectory = new File(".XMLResource");
			// if not exist, create the directory.
			if (!localDirectory.exists()) {
				localDirectory.mkdir();
			}
			File local = new File(localDirectory, ".XMLResource"
					+ Math.abs(uri.hashCode()) + "_");
			HttpResource hr = new HttpResource(uri, local, checkInterval);
			hr.registerListener(this);
			// this.onFileChange(local);
		} else {
			FileResource fr = new FileResource(new File(uri), checkInterval);
			fr.registerListener(this);
			// this.onFileChange(new File(uri));
		}
		
	}
}
