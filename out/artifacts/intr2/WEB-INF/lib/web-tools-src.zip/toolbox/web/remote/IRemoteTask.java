/**
 * @(#)IRemoteTask.java, 2008-7-7. Copyright 2008 Yodao, Inc. All rights
 *                                 reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use
 *                                 is subject to license terms.
 */
package toolbox.web.remote;

import toolbox.simplenet.rpc.RPCException;

/**
 * 远程服务的调用接口.
 * @author ares
 */
public interface IRemoteTask {

    public Response execute(Request request) throws RPCException;
}
