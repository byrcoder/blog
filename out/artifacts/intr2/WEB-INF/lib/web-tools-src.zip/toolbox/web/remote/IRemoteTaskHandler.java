/**
 * @(#)IRemoteTaskHandler.java, 2008-7-7. Copyright 2008 Yodao, Inc. All rights
 *                                        reserved. YODAO
 *                                        PROPRIETARY/CONFIDENTIAL. Use is
 *                                        subject to license terms.
 */
package toolbox.web.remote;

import toolbox.simplenet.rpc.MonitoredRPCClient;
import toolbox.simplenet.server.IContextListener;

/**
 * 远程服务程序需要实现的处理方法接口. 
 *
 * @author ares
 */

public interface IRemoteTaskHandler extends IRemoteTask, IContextListener, MonitoredRPCClient.IPing {
}
