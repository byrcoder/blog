package toolbox.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import toolbox.misc.LogFormatter;

/**
 * provide simple process to web.
 * 
 * @author shicq
 */
public class ParameterUtils {
    protected static final ParameterUtils ParameterUtils = new ParameterUtils();

    public static final ParameterUtils getInstance() {
        return ParameterUtils;
    }

    protected static final Logger LOG = LogFormatter
            .getLogger(ParameterUtils.class.getName());

    /**
     * fill all the parameter into model
     * 
     * @param request
     * @param model
     */
    @SuppressWarnings("unchecked")
    public static void fillModel(HttpServletRequest request,
            Map<String, Object> model) {
        Map<String, String[]> parameters = new HashMap<String, String[]>(
                request.getParameterMap());
        for (String key: parameters.keySet()) {
            String value = request.getParameter(key);
            model.put(key, value);
        }
    }

    /**
     * fill all the parameter into model, with content encoding.
     * 
     * @param request
     * @param model
     * @param serverEncoding
     * @param contentEncoding
     */
    @SuppressWarnings("unchecked")
    public static void fillModel(HttpServletRequest request,
            Map<String, Object> model, String serverEncoding,
            String contentEncoding) {
        Map<String, String[]> parameters = new HashMap<String, String[]>(
                request.getParameterMap());
        for (String key: parameters.keySet()) {
            String value = request.getParameter(key);
            String encodedValue = null;
            try {
                encodedValue = new String(value.getBytes(serverEncoding),
                        contentEncoding);
            } catch (UnsupportedEncodingException e) {
                encodedValue = value;
            }
            model.put(key, encodedValue);
        }
    }

    /**
     * get string.
     * 
     * @param request
     * @param name
     * @param def
     * @return
     */
    public static String getString(HttpServletRequest request, String name,
            String def) {
        String value = request.getParameter(name);
        return value == null ? def : value;
    }
    
    
    // time in mill seconds
    public static final long TIME_MS_MINUTE = 1000L * 60;
    public static final long TIME_MS_HOUR = 1000L * 3600;
    public static final long TIME_MS_DAY = TIME_MS_HOUR * 24;
    public static final long TIME_MS_WEEK = TIME_MS_DAY * 7;
    public static final long TIME_MS_MONTH = TIME_MS_DAY * 30;
    public static final long TIME_MS_YEAR = TIME_MS_DAY * 365;

    /**
     * support:
     * [1 Y == 1 TIME_MS_YEAR]
     * [1 m == 1 TIME_MS_MONTH]
     * [1 h/H == 1 TIME_MS_HOUR]
     * [1 d/D == 1 TIME_MS_DAY]
     * [1 w/W == 1 TIME_MS_WEEK]
     * [1 M == 1 TIME_MS_MONTH]  
     * [1 s/ /S == 1 1000ms]
     * without support minutes
     *
     * @param dailyTime
     * @return ms
     */

	public static long getTime(HttpServletRequest request, String name, long def) {
		String timeStr = getString(request, name, null);
		if(timeStr == null || timeStr.trim().length() == 0)
			return def;
		try {
			int index = timeStr.length() - 1;
			char unit = timeStr.charAt(index);
			if (unit == 's' || unit == 'S') {
				return (long) (1000L * Float.parseFloat(timeStr.substring(0,
						index)));
			} else if (unit == 'm') {
				return (long) (TIME_MS_MINUTE * Float.parseFloat(timeStr
						.substring(0, index)));
			} else if (unit == 'h' || unit == 'H') {
				return (long) (TIME_MS_HOUR * Float.parseFloat(timeStr
						.substring(0, index)));
			} else if (unit == 'd' || unit == 'D') {
				return (long) (TIME_MS_DAY * Float.parseFloat(timeStr
						.substring(0, index)));
			} else if (unit == 'w' || unit == 'W') {
				return (long) (TIME_MS_WEEK * Float.parseFloat(timeStr
						.substring(0, index)));
			} else if (unit == 'M') {
				return (long) (TIME_MS_MONTH * Float.parseFloat(timeStr
						.substring(0, index)));
			} else if (unit == 'Y' || unit == 'y') {
				return (long) (TIME_MS_YEAR * Float.parseFloat(timeStr
						.substring(0, index)));
			} else {
				return Long.parseLong(timeStr) * 1000L;
			}
		} catch (Throwable e) {
			return def;
		}

	}

    public static final int SIZE_BYTE_KILO = 1024;

    public static final int SIZE_BYTE_MEGA = SIZE_BYTE_KILO * 1024;
    /**
     * support:
     * [1 k/K == 1 SIZE_BYTE_KILO]
     * [1 m/M == 1 SIZE_BYTE_MEGA]
     *
     * @param dailyTime
     * @return ms
     */

	public static int getSize(HttpServletRequest request, String name, int def) {
		String sizeStr = getString(request, name, null);
		if (sizeStr == null || sizeStr.trim().length() == 0)
			return def;
		try {
			int index = sizeStr.length() - 1;
			char unit = sizeStr.charAt(index);
			if (unit == 'k' || unit == 'K') {
				return (int) (SIZE_BYTE_KILO * Float.parseFloat(sizeStr
						.substring(0, index)));
			} else if (unit == 'm' || unit == 'M') {
				return (int) (SIZE_BYTE_MEGA * Float.parseFloat(sizeStr
						.substring(0, index)));
			} else {
				return Integer.parseInt(sizeStr);
			}
		} catch (Throwable e) {
			return def;
		}
	}
  
    /**
     * get integer.
     * 
     * @param request
     * @param name
     * @param def
     * @return
     */
    public static int getInt(HttpServletRequest request, String name, int def) {
        String tmp = request.getParameter(name);
        if (tmp == null || tmp.length() == 0)
            return def;
        else {
            try {
                return Integer.parseInt(tmp.trim());
            } catch (NumberFormatException e) {
                return def;
            }
        }
    }

    /**
     * get long.
     * 
     * @param request
     * @param name
     * @param def
     * @return
     */
    public static long getLong(HttpServletRequest request, String name, long def) {
        String tmp = request.getParameter(name);
        if (tmp == null || tmp.length() == 0)
            return def;
        else {
            try {
                return Long.parseLong(tmp.trim());
            } catch (NumberFormatException e) {
                return def;
            }
        }
    }
    
    /**
     * get float.
     * 
     * @param request
     * @param name
     * @param def
     * @return
     */
    public static float getFloat(HttpServletRequest request, String name, float def) {
        String tmp = request.getParameter(name);
        if (tmp == null || tmp.length() == 0)
            return def;
        else {
            try {
                return Float.parseFloat(tmp.trim());
            } catch (NumberFormatException e) {
                return def;
            }
        }
    }
    
    

    /**
     * return the request url.
     * @param request
     * @return
     */
    public static String getURL(HttpServletRequest request) {
        StringBuilder urlBuffer = new StringBuilder();
        urlBuffer.append(request.getRequestURL());
        String queryString = request.getQueryString();
        if (queryString != null) {
            urlBuffer.append("?");
            urlBuffer.append(request.getQueryString());
        }
        return urlBuffer.toString();
    }

    /**
     * return the request url by encoding.
     * @param request
     * @param encoding
     * @return
     * @throws IOException
     */
    public static String getURL(HttpServletRequest request, String encoding)
            throws IOException {
        return getURL(request, encoding, null);
    }

    /**
     * Return the request url by encoding & filter unwanted params in url.
     * 
     * @param request
     * @return
     * @throws IOException
     */
    public static String getURL(HttpServletRequest request, String encoding,
            String[] filterParas) throws IOException {
        HashSet<String> filterParaSet = new HashSet<String>();
        if (filterParas != null) {
            filterParaSet.addAll(Arrays.asList(filterParas));
        }
        StringBuilder urlBuffer = new StringBuilder();
        urlBuffer.append(request.getRequestURL());
        boolean first = true;
        String paramValueEncoding = (encoding == null) ? "UTF-8" : encoding;
        for (Object o: request.getParameterMap().keySet()) {
            String key = (String) o;
            if (filterParaSet.contains(key)) {
                continue;
            }
            String[] values = request.getParameterValues(key);
            for (String value: values) {
                if (first) {
                    urlBuffer.append('?');
                    first = false;
                } else {
                    urlBuffer.append('&');
                }
                urlBuffer.append(key).append('=').append(
                        URLEncoder.encode(value, paramValueEncoding));
            }
        }
        return urlBuffer.toString();
    }

    /**
     * the most full visit url.
     * @param request
     * @return
     */
    public static String getFullURL(HttpServletRequest request) {
        String pathInfo = request.getPathInfo();
        String queryString = request.getQueryString();
        StringBuilder urlBuffer = new StringBuilder();
        String scheme = request.getScheme();
        int port = request.getServerPort();
        urlBuffer.append(scheme);
        urlBuffer.append("://");
        urlBuffer.append(request.getServerName());
        if ((scheme.equals("http") && port != 80)
                || (scheme.equals("https") && port != 443)) {
            urlBuffer.append(":");
            urlBuffer.append(port);
        }        
        urlBuffer.append(request.getContextPath());
        urlBuffer.append(request.getServletPath());
        if (pathInfo != null) {
            urlBuffer.append(pathInfo);
        }
        if (queryString != null) {
            urlBuffer.append(queryString);
        }
        return urlBuffer.toString();
    }

    /**
     * request url without host.
     * @param request
     * @return
     */
    public static String getURI(HttpServletRequest request){
        StringBuilder urlBuffer = new StringBuilder();
        urlBuffer.append(request.getRequestURI());        
        String queryString = request.getQueryString();   // d=789
        if (queryString != null) {
            urlBuffer.append("?");
            urlBuffer.append(queryString);
        }
        return urlBuffer.toString();
    }

    /**
     * case parameter setting then written into cookie.
     * when no parameter available, then test the cookie.
     * case value == null: read cookie
     * case value.length == 0 : delete cookie
     * case valeu.length > 0 : add cookie.
     * @param request
     * @param response
     * @param name
     * @param cookieName
     * @param domain
     * @param maxAge
     * @return
     */
    public static String getCookieParameter(HttpServletRequest request,
            HttpServletResponse response, String name, String cookieName,
            String domain, int maxAge) {
        // check parameter.
        String value = getString(request, name, null);
        if (value == null) {
            // check cookie.
            Cookie cookie = CookieUtil.findCookie(request, cookieName);
            if (cookie != null) {
                value = cookie.getValue();
            }
        } else if (value.length() == 0) {
            try {
                CookieUtil.deleteCookie(response, cookieName, domain, null);
            } catch (ServletException e) {
                e.printStackTrace();
            }
        } else {
            // set cookie.
            try {
                CookieUtil.addCookie(response, cookieName, value, domain, null,
                        maxAge);
            } catch (ServletException e) {
                e.printStackTrace();
            }
        }
        return value;
    } 
    
    
    /**
     * case parameter setting then written into cookie.
     * when no parameter available, then test the cookie.
     * case value == null: read cookie
     * case value.length == 0 : delete cookie
     * case valeu.length > 0 : add cookie.
     * @param request
     * @param response
     * @param name
     * @param cookieName
     * @param path
     * @param domain
     * @param maxAge
     * @return
     */
    public static String getCookieParameter(HttpServletRequest request,
            HttpServletResponse response, String name, String cookieName, String path,
            String domain, int maxAge) {
        // check parameter.
        String value = getString(request, name, null);
        if (value == null) {
            // check cookie.
            Cookie cookie = CookieUtil.findCookie(request, cookieName);
            if (cookie != null) {
                value = cookie.getValue();
            }
        } else if (value.length() == 0) {
            try {
                CookieUtil.deleteCookie(response, cookieName, domain, path);
            } catch (ServletException e) {
                e.printStackTrace();
            }
        } else {
            // set cookie.
            try {
                CookieUtil.addCookie(response, cookieName, value, domain, path,
                        maxAge);
            } catch (ServletException e) {
                e.printStackTrace();
            }
        }
        return value;
    } 
    
    
    /**
     * domain=".youdao.com"
     * cookieName = "_parameter_cookie_" + name
     * maxAge = MAX_VALUE
     * @param request
     * @param response
     * @param name
     * @return
     */
    public static String getCookieParameter(HttpServletRequest request,
            HttpServletResponse response, String name) {
        return getCookieParameter(request, response, name, "parameter_cookie_"
                + name, ".youdao.com", Integer.MAX_VALUE);
    }
    
    /**
     * append url with parameters.
     * @param url
     * @param name
     * @param value
     * @param name_value_pairs
     * @return
     */
    public static String appendParameter(String url, String name, String value,
            String... name_value_pairs) {
        return appendParameter(url, "UTF-8", name, value, name_value_pairs);
    }
    
    /**
     * append url with parameters.
     * @param url
     * @param encoding
     * @param name
     * @param value
     * @param name_value_pairs
     * @return
     */
    public static String appendParameter(String url, String encoding,
            String name, String value, String... name_value_pairs) {
        StringBuilder sb = new StringBuilder(url);
        if (url.contains("?")) {
            if (!url.endsWith("&")) {
                sb.append("&");
            }
        } else {
            sb.append("?");
        }
        sb.append(name).append("=")
                .append(ViewUtils.encodeURL(value, encoding));
        if (name_value_pairs != null) {
            for (int i = 0; i < name_value_pairs.length / 2; i++) {
                sb.append("&").append(name_value_pairs[2 * i]).append("=");
                sb.append(ViewUtils.encodeURL(name_value_pairs[2 * i + 1],
                        encoding));
            }
        }
        return sb.toString();
    }
    
    /**
     * check whether parameter exist.
     * @param request
     * @param name
     * @return
     */
    public static boolean hasParameter(HttpServletRequest request, String name) {
        return request.getParameter(name) != null
                && request.getParameter(name).length() != 0;
    }
}
