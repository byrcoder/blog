/**
 * 
 */
package toolbox.web.remote;

import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.simplenet.client.Client;
import toolbox.simplenet.commons.BasicFuture;
import toolbox.simplenet.commons.IFuture;
import toolbox.simplenet.rpc.MonitoredRPCClient;
import toolbox.simplenet.rpc.RPCClient;
import toolbox.simplenet.rpc.RPCException;
import toolbox.simplenet.rpc.RPCTimeoutException;

/**
 * 远程服务的本地客户端, 是对{@link RPCClient}的包装.
 * 
 * 客户端的使用方式有两种，一种是同步调用，例如如下的代码：
 * <code>
 *   ...
 *   RemoteClient client = new RemoteClient(addr);
 *   Response res = client.execute(req);
 *   ...
 * </code>
 * 
 * 另外一种办法是异步调用，使用{@link #invoke(Method, Object[])}
 * 方法，例如如下代码：
 * <code>
 *   ...
 *   RemoteClient client = new RemoteClient(addr);
 *   RemoteFuture future = client.submit(req); 
 *   ...
 *   future.join(); // 阻塞等待远程调用结束 
 *   if (future.isFinished()) {
 *       if (future.getException() != null) {
 *          // process exception
 *          ...
 *       } else {
 *          // process result
 *          Response res = future.getResult();
 *          ...
 *       }
 *   } else {
 *       // invoke is not finished yet
 *       ...
 *   }
 * </code>
 * 
 * @author ares
 *
 */
public class RemoteClient {
    private static final Logger LOG = LogFormatter.getLogger(RemoteClient.class); 
    private static final long DEFAULT_CALL_TIMEOUT = 10000;
    
    public RemoteClient(String name, InetSocketAddress addr, ScheduledExecutorService retryThreadPool) {
        this(name, addr, 1, Client.DEFAULT_CONNECT_TIMEOUT,
                Client.DEFAULT_WRITE_TIMEOUT, DEFAULT_CALL_TIMEOUT, retryThreadPool);
    }

    private final ScheduledExecutorService retryThreadPool;
    private final String name;
    public RemoteClient(String name, InetSocketAddress addr, int connectionNumber,
            long connectTimeout, long writeTimeout, long callTimeout,
            ScheduledExecutorService retryThreadPool) {
        this.name = name;
        this.addr = addr;
        this.connectionNumber = connectionNumber;
        this.connectTimeout = connectTimeout;
        this.writeTimeout = writeTimeout;
        this.callTimeout = callTimeout;
        this.retryThreadPool = retryThreadPool;
    }
    public String getName() {
        return name;
    }
    private MonitoredRPCClient client;
    private IRemoteTask task;

    private Method method;

    private InetSocketAddress addr;
    private int connectionNumber = 1;
    private long connectTimeout = Client.DEFAULT_CONNECT_TIMEOUT;
    private long writeTimeout = Client.DEFAULT_WRITE_TIMEOUT;
    private long callTimeout = DEFAULT_CALL_TIMEOUT;
    private long retryInterval = 1000;
    
    public void setConnectionNumber(int connectionNumber) {
        this.connectionNumber = connectionNumber;
    }

    public void setConnectTimeout(long connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public void setCallTimeout(long callTimeout) {
        this.callTimeout = callTimeout;
    }

    public void setRetryInterval(long interval) {
        this.retryInterval = interval;
    }
    private class RetryPolicy implements MonitoredRPCClient.IRetryPolicy {
        private AtomicInteger count = new AtomicInteger(0);
        public boolean onException(Throwable t) {
            LOG.log(Level.WARNING, "MonitoredRPCClient '" + name + "' on " + addr + " got Exception", t);
            return false;
        }

        public boolean onRpcException(RPCException t) {
            if(t instanceof RPCTimeoutException) {
                if(count.incrementAndGet() >= 5) {
                    LOG.log(Level.WARNING, "MonitoredRPCClient '" + name + "' on " + addr + " timed out too many times");
                    return true;
                } else {
                    LOG.log(Level.WARNING, "MonitoredRPCClient '" + name + "' on " + addr + " timed out", t);
                    return false;
                }
            } else {
                LOG.log(Level.WARNING, "Got RPCException", t);
                return true;
            }
        }

        public void onSuccess() {
            count.set(0);
        }

        public void reset() {
            count.set(0);
        }
    }
    /**
     * 初始化RemoteClient，并打开连接服务，所有的超时单位为毫秒
     * @param addr 远程服务的地址
     * @param connectionNumber 客户端与服务器端维持的最大连接数目
     * @param connectTimeout 连接超时
     * @param writeTimeout 写超时
     * @param callTimeout 调用超时，仅在同步调用时使用
     * @throws RPCException 
     * @throws NoSuchMethodException
     */
    public void init() throws RPCException, NoSuchMethodException {
        if(client != null) {
            throw new IllegalStateException("already initialized");
        }
        client = new MonitoredRPCClient(addr, connectionNumber, connectTimeout,
                writeTimeout, callTimeout, retryThreadPool, retryInterval);
        client.setRetryPolicy(new RetryPolicy());
        client.open();
        task = client.getProxy(IRemoteTask.class);
        method = IRemoteTask.class.getMethod("execute", Request.class);
    }

    /**
     * 同步调用远程服务
     * @param request
     * @return
     * @throws RPCException
     */
    public Response execute(Request request) throws RPCException {
        return task.execute(request);
    }

    /**
     * 异步调用远程服务，使用默认的超时时间
     * @param request
     * @return 
     */
    public RemoteFuture submit(Request request) {
        return submit(request, this.callTimeout);
    }
    
    /**
     * 异步调用远程服务，以timeout作为超时，单位毫秒
     * @param request
     * @param timeout
     * @return 如果服务器无法连上，返回null
     */
    public RemoteFuture submit(Request request, long timeout) {
        IFuture future = client.invoke(method, request);
        if(future == null) {
            return null;
        }
        return new RemoteFuture(future, timeout);
    }

    /**
     * 关闭连接
     */
    public void close() {
        client.close();
    }
    
    /**
     * 异步调用的返回对象，是对{@link BasicFuture}的封装
     *
     * @author ares
     *
     */
    public static class RemoteFuture {

        private IFuture future;
        private long timeout;

        private RemoteFuture(IFuture future, long timeout) {
            this.future = future;
            this.timeout = timeout;
        }

        public boolean isFinished() {
            return future.isDone();
        }

        public Response getResult() 
                throws InterruptedException, ExecutionException, TimeoutException {
            return (Response) future.get(timeout, TimeUnit.MILLISECONDS);
        }
    }
    
    public String toString() {
        return "[RemoteClient name=" + name + " addr=" + addr + "]";
    }
}
