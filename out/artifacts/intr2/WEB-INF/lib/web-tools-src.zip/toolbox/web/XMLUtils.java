package toolbox.web;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.tidy.Configuration;
import org.w3c.tidy.LexParseException;
import org.w3c.tidy.Tidy;

import toolbox.misc.LogFormatter;

import com.sun.org.apache.xerces.internal.parsers.DOMParser;
import com.sun.org.apache.xerces.internal.xni.parser.XMLInputSource;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import com.sun.org.apache.xml.internal.serializer.Method;
import com.sun.org.apache.xml.internal.utils.Constants;
import com.sun.org.apache.xml.internal.utils.PrefixResolver;
import com.sun.org.apache.xpath.internal.XPath;
import com.sun.org.apache.xpath.internal.XPathContext;
import com.sun.org.apache.xpath.internal.objects.XObject;

/**
 *<p> provide xml parse and xpath visit function used in search & velocity
 *usage:
 *<p>
 *xml:
 * <root>
 *  <item><name>n1</name><value>v1</value></item>
 *  <item><name>n2</name><value>v2</value></item>
 *  <comment>datas<comment>
 * </root> 
 * 
 * <p> DEMO 0 :
 * Document doc = XMLUtils.read(xml)
 * 
 * <p> DEMO 1 :
 * XMLUtils.getText(doc, "/root/comment") == "datas";
 * 
 * <p> DEMO 2 :
 * for(Node node: XMLUtils.getNodes(doc, "/root/item")){
 *      System.out.println(XMLUtils.getText(node, "name"));
 * }
 * 
 * OUT:
 * n1
 * n2
 * <p>
 * 
 *  
 * @author shicq
 *
 */
public class XMLUtils {
    protected static final XMLUtils XMLUtils = new XMLUtils();
    public static final XMLUtils getInstance(){
        return XMLUtils;
    } 
    protected static final Logger LOG = LogFormatter.getLogger(XMLUtils.class
            .getName());
    
    // as xpath is limited, cache all the xpath.
    protected static final ConcurrentHashMap<String, XPath> xpathCache = new ConcurrentHashMap<String, XPath>();
    // default prefixResolver.
    protected static final PrefixResolver PrefixResolver = new PrefixResolver() {
        public String getBaseIdentifier() {
            return null;
        }
        public String getNamespaceForPrefix(String prefix) {
            return Constants.S_XMLNAMESPACEURI;
        }
        public String getNamespaceForPrefix(String prefix, Node context) {
            return Constants.S_XMLNAMESPACEURI;
        }
        public boolean handlesNullPrefixes() {
            return false;
        }
    };
    /**
     * added cache for all the xpath.
     * @param xpath
     * @return
     */
    protected static final XPath toXPath(String xpathStr) {
        if (xpathStr == null)
            return null;
        XPath xpath = xpathCache.get(xpathStr);
        if (xpath != null) {
            return xpath;
        } else {
            try {
                xpath = new XPath(xpathStr, null, PrefixResolver, XPath.SELECT,
                        null);
                xpathCache.put(xpathStr, xpath);
                return xpath;
            } catch (Throwable e) {
                System.out.println("toXPath Exception xpath=" + xpathStr);
                e.printStackTrace();
                return null;
            }
        }
    }
    /**
     * read the xpath into nodelist.
     * @param contextNode
     * @param xpathStr
     * @return
     */
    public static NodeList getNodeList(Node contextNode, String xpathStr) {
        if (contextNode == null) {
            System.out.println("Exception: node=null");
            return null;
        }
        if (xpathStr == null) {
            System.out.println("Exception: xpath=null");
            return null;
        }
        XPath xpath = toXPath(xpathStr);
        if (xpath == null) {
            System.out.println("Exception: toXPath=null");
            return null;
        }
        XPathContext xpathSupport = xpathContextPool.borrowPool();
        try {
            int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
            // xpath not thread safe.
            XObject xobj = xpath
                    .execute(xpathSupport, ctxtNode, PrefixResolver);
            NodeList nodelist = xobj.nodelist();
            xobj = null;
            return nodelist;
        } catch (Throwable e) {
            System.out.println("getNodeList Exception: xpath=" + xpathStr);
            e.printStackTrace();
            return null;
        } finally {
            xpathContextPool.returnPool(xpathSupport);
        }
    }
    
    protected static SimplePool<XPathContext> xpathContextPool = new SimplePool<XPathContext>(64) {
        private static final long serialVersionUID = 3587459396696974280L;
        @Override
        public XPathContext initialValue() {
            XPathContext xpathSupport = new XPathContext();
            xpathSupport.pushNamespaceContext(PrefixResolver);
            return xpathSupport;
        }
        public void resetValue(XPathContext e){
            e.reset();
        }
        
    };
  
    /**
     * provide iterable for getNodes.
     * @param obj
     * @param path
     * @return
     */
    public static AbstractList<Node> getNodes(Node obj, String path){
        NodeList nodeList = getNodeList(obj,path);
        return toArray(nodeList);
    }
    
    /**
     * provide text read.
     * @param obj
     * @param path
     * @return
     * @throws XPathExpressionException 
     */
    public static String getText(Node contextNode, String xpathStr){
        if (contextNode == null) {
            LOG.log(Level.WARNING, "element=" + contextNode + "path=" + xpathStr);
            return null;
        }
        try {
            Node node = getNode(contextNode, xpathStr);
            if(node == null || node.getTextContent() == null)
                return "";      
            return node.getTextContent().trim();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "path=" + xpathStr, e);
        }
        return null;
    }
    
    /**
     * escapt xml.
     * @param contextNode
     * @param xpathStr
     * @return
     */
    public static String getXML(Node contextNode, String xpathStr) {
        return StringEscapeUtils.escapeXml(getText(contextNode, xpathStr));
    }
    /**
     * escape html
     * @param contextNode
     * @param xpathStr
     * @return
     */
    public static String getHTML(Node contextNode, String xpathStr) {
        return StringEscapeUtils.escapeHtml(getText(contextNode, xpathStr));
    }

    /**
     * check whether the xpath exist in the node.
     * @param obj
     * @param path
     * @return
     * @throws XPathExpressionException 
     */
    public static boolean exists(Node obj, String path){
        Node node = getNode(obj, path);
        if (node == null)
            return false;
        else
            return true;
    }

    /**
     * provide Node readed.
     * @param contextNode
     * @param xpathStr
     * @return
     */
    public static Node getNode(Node contextNode, String xpathStr) {
        if (contextNode == null) {
            System.out.println("Exception: node=null");
            return null;
        }
        if (xpathStr == null) {
            System.out.println("Exception: xpath=null");
            return null;
        }
        XPath xpath = toXPath(xpathStr);
        if (xpath == null) {
            System.out.println("Exception: toXPath=null");
            return null;
        }        
        XPathContext xpathSupport = xpathContextPool.borrowPool();
        try {
            // xpath not thread safe.
            int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
            XObject xobj = xpath.execute(xpathSupport, ctxtNode,
                  PrefixResolver);            
            Node node = xobj.nodeset().nextNode();
            xobj = null;
            return node;
        } catch (Throwable e) {
            System.out.println("getNode Exception: xpath=" + xpathStr);
            e.printStackTrace();
            return null;
        } finally {
            xpathContextPool.returnPool(xpathSupport);
        }    
    }
    
    
    /**
     * provide int read.
     * @param obj
     * @param path
     * @return
     * @throws XPathExpressionException 
     * @throws NumberFormatException 
     */
    public static int getInt(Node obj, String path){
        try {
            String text = getText(obj, path);
            if(text == null  || text.length() < 1){
                LOG.log(Level.WARNING, "unkown path="+path);    
                return -1;
            }
            return Integer.valueOf(text).intValue();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "path="+path, e);
        }
        return -1;
    }

    /**
     * provide long read
     * @param obj
     * @param path
     * @return
     * @throws XPathExpressionException 
     * @throws NumberFormatException 
     */
    public static long getLong(Node obj, String path){
        try{
            String text = getText(obj, path);
            if(text == null  || text.length() < 1){
                LOG.log(Level.WARNING, "unkown path="+path);    
                return -1;
            }
            return Long.valueOf(text).longValue();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "path="+path, e);
        }
        return -1;
    }

    /**
     * provide date read.
     * @param obj
     * @param path
     * @return
     * @throws XPathExpressionException 
     * @throws NumberFormatException 
     */
    public static Date getDate(Node obj, String path){
        try{
            String text = getText(obj, path);
            if(text == null || text.length() < 1){
                LOG.log(Level.WARNING, "unkown path="+path);    
                return null;
            }
            return new Date(Long.valueOf(text).longValue());
        } catch (Exception e) {
            LOG.log(Level.WARNING, "path="+path, e);
        }
        return null;
    }

/*    *//**
     * provide threadLocal for DocumentBuilder
     *//*
    public static final ThreadLocal<DocumentBuilder> DocBuilders = new ThreadLocal<DocumentBuilder>(){
        @Override
        public DocumentBuilder initialValue(){
            // Use the DocumentBuilderFactory to create a DocumentBuilder.
            try {
                return BuilderFactory.get().newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }
            return null;
        }
    };*/
    
/*    *//**
     * provide threadLocal for DocumentBuilderFactory
     *//*
    public static final ThreadLocal<DocumentBuilderFactory> BuilderFactory = new ThreadLocal<DocumentBuilderFactory>(){
        public DocumentBuilderFactory initialValue(){
            // Instantiate a DocumentBuilderFactory.
            DocumentBuilderFactory dFactory =  // DocumentBuilderFactory.newInstance();
                new org.apache.xerces.jaxp.DocumentBuilderFactoryImpl();
                // new com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl();
            // default using resin's DocumentFactory instead of xerces. 
            // new org.apache.xerces.jaxp.DocumentBuilderFactoryImpl();
            // And setNamespaceAware, which is required when parsing xsl files
            dFactory.setNamespaceAware(true);
            return dFactory;
        } 
    };
    */
    /**
     * read a file as document.
     * @param xmlFile
     * @return
     * @throws Exception
     */
    public static Document read(File xmlFile) throws Exception {
        long start = System.currentTimeMillis();   
        Document document = read(new FileReader(xmlFile));
        long end = System.currentTimeMillis();
         LOG.info("XMLUtils.read(file) time=" + (end - start));
        return document;
    }

    /**
     * read a String as document.
     * @param xmlStr
     * @return
     * @throws Exception
     */
    public static Document read(String xmlStr) throws Exception {
        long start = System.currentTimeMillis();
        Document document = read(new StringReader(xmlStr.trim()));
        long end = System.currentTimeMillis();
         LOG.info("XMLUtils.read(string) time=" + (end - start));
        return document;
    }
    
    /**
     * provide reader into document. 
     * @param charStream
     * @return
     * @throws Exception
     */
    public static Document read(Reader charStream)throws Exception{
        DOMParser parser = parserPool.borrowPool();
        try {
            XMLInputSource xmlInputSource = new XMLInputSource(null, null, null);
            xmlInputSource.setCharacterStream(charStream);
            parser.parse(xmlInputSource);
            Document document = parser.getDocument();        
            return document;
        } finally {
            parserPool.returnPool(parser);
        }
    }

    // provided simple xml cache.
    static ConcurrentHashMap<String, Document> docCache = new ConcurrentHashMap<String, Document>();
    static AtomicLong lastUpdateTime = new AtomicLong();
    // when xml changed then creat new, else return cache.
    /**
     * <p> provide very simple implemented cached xmlstr reading.
     * <p> default time is 1 minute.
     */
    public static Document cachedRead(String xmlStr) throws Exception {
        if (xmlStr == null)
            return null;
        String key = String.valueOf(xmlStr.hashCode());
        Document cached = docCache.get(key);
        if (cached == null) {
            // parse new.
            cached = read(xmlStr);
            docCache.put(key, cached);
        }
        // update time.
        long now = System.currentTimeMillis();
        if (docCache.size() > 4 || now - lastUpdateTime.get() > 600000l) {
            // clear cache.
            docCache.clear();
            lastUpdateTime.set(now);
        }
        return cached;
    }
    
    protected static SimplePool<DOMParser> parserPool = new SimplePool<DOMParser>(8) {
        private static final long serialVersionUID = 3432558791795273680L;
        @Override
        public DOMParser initialValue() {
            return new DOMParser();
        }
        public void resetValue(DOMParser e){
            e.reset();
        }
    };

    /**
     * changed nodelist into list
     * provide interface for foreach.
     * @param nodes
     * @return
     */
    public static AbstractList<Node> toArray(final NodeList nodes){
        if(nodes == null)
            return null;
        final AbstractList<Node> array = new AbstractList<Node>(){
            @Override
            public Node get(int index) {
                return nodes.item(index);
            }
            @Override
            public int size() {
                return nodes.getLength();
            }
        };
        return array;
    }
    
    
/*    *//**
     * toString for NodeList 
     * @param obj
     * @return
     *//*
    public static String toString(NodeList obj){
        if(obj == null)
            return "";
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < obj.getLength(); i ++){
            sb.append(toString(obj.item(i)));
        }
        return sb.toString();
    }    
    */
    
    public static ArrayList<Item> addItem(String key, String value) {
        return addItem(null, key, value);
    }

    public static ArrayList<Item> removeItem(ArrayList<Item> array, String key) {
        ArrayList<Item> delete = new ArrayList<Item>();
        for (Item item: array) {
            if (item.key.startsWith(key)) {
                delete.add(item);
            }
        }
        for (Item item: delete) {
            array.remove(item);
        }
        return array;
    }

    public static ArrayList<Item> addItem(ArrayList<Item> array, String key,
            String value) {
        if (array == null) {
            array = new ArrayList<Item>();
        }
        array.add(new Item(key, value));
        return array;
    }
    
    /**
     * parse document into Items.
     * Item is key-value pair & attrs.
     * easy for
     *
     * @author shicq
     *
     */
    public static class Item implements Comparable<Item>{
        public Map<String, String> attrs = new HashMap<String,String>();
        public String addAttr(String name, String value){
            return attrs.put(name, value);
        }
        
        public String getAttr(String name){
            return attrs.get(name);
        }
        
        public Map<String, String> getAttrs() {
            return attrs;
        }
        public Item(String key, String value){
            this.key = key;
            this.value = value;
        }
        public String key;
        public String getKey() {
            return key;
        }
        public void setKey(String key) {
            this.key = key;
        }
        public String getValue() {
            return value;
        }
        public void setValue(String value) {
            this.value = value;
        }
        public String value;        
        public String toString() {
            StringBuilder sb = new StringBuilder(key);
            if (attrs.size() > 0) {
                sb.append("[@");
                boolean first = true;
                for (String name: attrs.keySet()) {
                    if (first) {
                        first = false;
                    } else {
                        sb.append(";");
                    }
                    sb.append(name).append("=").append(attrs.get(name));
                }
                sb.append("]");
            }
            if (value != null && value.length() > 0) {
                sb.append("=").append(value);
            }
            return sb.toString();
        }
        @Override
        public int compareTo(Item o) {
            int c = this.key.compareTo(o.key);
            if (c == 0) {
                c = this.value.compareTo(o.value);
            }
            return c;
        }
    }
    /**
     * select intersted items.
     * @param array
     * @param names
     * @return
     */
    public static ArrayList<Item> selectItem(ArrayList<Item> array, String names) {
        String[] keys = names.split(",");
        ArrayList<Item> result = new ArrayList<Item>();
        for (String key: keys) {
            key = key.trim();
            for (Item item: array) {
                if (item.key.startsWith(key)) {
                    result.add(item);
                }
            }
        }
        return result;
    }
    
    public static ArrayList<Item> toItems(Node node){
        return toItems(node,ITEM_CHILDREN);
    }
    
    public static ArrayList<Item> toItems(Node node, int itemType){
        return toItems(node, null, itemType);
    }

    
    public static final int ITEM_CHILDREN = 0;
    public static final int ITEM_SELF = 1;
    
    /**
     * put a node's child nodes into {@link Item} array.
     * @param node
     * @param array
     * @param itemType  the type is ITEM_CHILDREN | ITEM_SELF
     * @return
     */
    protected static ArrayList<Item> toItems(Node node, ArrayList<Item> array, int itemType){
        if (array == null) {
            array = new ArrayList<Item>();
        }
        
        if(itemType == ITEM_CHILDREN){
            List<Node> children = toArray(node.getChildNodes());
            for (Node child: children) {
                array.add(toItem(child));
            }    
        }else if(itemType == ITEM_SELF){
            array.add(toItem(node));
        }
        return array;
    }
    
    /**
     * changed a node to key-value Item.
     * @param node
     * @return
     */
    protected static Item toItem(Node node) {
        String name = node.getNodeName();
        String value = getText(node, ".");
        Item item = new Item(name, value);
        NamedNodeMap attrs = node.getAttributes();
        if (attrs != null) {
            for (int i = 0; i < attrs.getLength(); i++) {
                Node attr = attrs.item(i);
                item.addAttr(attr.getNodeName().trim(), attr.getNodeValue());
            }
        }
        return item;
    }
    
    /**
     * toString for Node
     * serializer a node into xml string.
     * @param obj
     * @return
     */
    public static String toString(Node obj) {
        try {
            StringWriter writer = new StringWriter();
            XMLSerializer serializer = serializers.get();
            serializer.setOutputCharStream(writer);
            serializer.serialize(obj);
            return writer.toString().trim();
        } catch (Exception e) {
            LOG.log(Level.WARNING, "XMLUitls.toString()", e);
        }
        return null;
    }
    /**
     * searializer.
     */
    protected static final ThreadLocal<XMLSerializer> serializers = new ThreadLocal<XMLSerializer>() {
        @Override
        protected XMLSerializer initialValue() {  
            OutputFormat format = new OutputFormat();
            format.setIndenting(true);
            format.setStandalone(false);
            format.setOmitXMLDeclaration(true);
            format.setMethod(Method.XML);
            XMLSerializer serializer = new XMLSerializer(format);
            return serializer;
        }
    };
    
    /**
     * write a document into file.
     * @param document
     * @param file
     * @return
     * @throws Exception
     */
    public static File write(Document document, File file) throws Exception {
        Writer writer = new FileWriter(file);
        try {
            write(document, new FileWriter(file));
        } finally {
            writer.close();
        }
        return file;
    }
    
    /**
     * write a document into writer.
     * @param document
     * @param writer
     * @return
     * @throws Exception
     */
    public static Writer write(Document document, Writer writer) throws Exception {
        Transformer transformer = TransformerFactory.newInstance()
                .newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.transform(new DOMSource(document), new StreamResult(
                new BufferedWriter(writer)));
        return writer;
    }
    

/**
 *  simple and useful tool for transform html to xml.
 * @param html
 * @param encoding see {@link Configuration}
 * @return
 * @throws LexParseException
 */
    public static final String html2xml(String html, int encoding) throws LexParseException {
        Tidy tidy = new Tidy();
        tidy.setCharEncoding(encoding);
        tidy.setXmlOut(true);
        tidy.setQuiet(true);
        ByteArrayInputStream in = new ByteArrayInputStream(html.getBytes());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        tidy.parseDOM(in, out);
        return new String(out.toByteArray());
    }

    /**
     * default encoding.
     * @param html
     * @return
     * @throws LexParseException
     */
    public static final String html2xml(String html) throws LexParseException {
    	return html2xml(html, Configuration.UTF8);
    }
    

    /**
     * very simple pool 
     *
     * @author shicq
     *
     * @param <E>
     */
    protected static abstract class SimplePool<E> extends ArrayList<E> {
        private static final long serialVersionUID = -6167876569571870752L;
        public SimplePool(int capacity) {
            super(capacity);            
            for (int i = 0; i < capacity; i++) {
                this.add(initialValue());
            }             
            idx.set(capacity - 1);
            washIdx.set(capacity - 1);
            washer.setDaemon(true);
            washer.start();
        }
        public abstract E initialValue();        
        public void resetValue(E e){}
        ReentrantLock returnLock = new ReentrantLock();
        ReentrantLock borrowLock = new ReentrantLock();
        public E borrowPool() {
            E ret = borrowOnce();
            while (ret == null) {
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {}                
                ret = borrowOnce();
            }
            return ret;
        }
        AtomicInteger idx = new AtomicInteger(0);
        AtomicInteger washIdx = new AtomicInteger(0);
        Thread washer = new Thread() {
            public void run() {
                while (true) {
                    while (washIdx.get() < idx.get()) {
                        washPool();
                    }
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {}
                }
            }
        };
        
        protected void washPool() {
            try {
                returnLock.lock();
                if (washIdx.get() < idx.get()) {
                    int k = washIdx.get() + 1;
                    E e = this.get(k);
                    try {
                        resetValue(e);
                        washIdx.set(k);
                    } catch (Throwable a) {}                    
                }
            } finally {
                returnLock.unlock();
            }
        } 
        
        protected E borrowOnce(){
            try {
                borrowLock.lock();
                returnLock.lock();
                int k = idx.get();
                if (k > -1) {
                    E e = this.get(k);
                    idx.set(k - 1);
                    if (washIdx.get() > idx.get()) {
                        washIdx.set(idx.get());
                    }
                    return e; 
                } else {
                    return null;
                }
            } finally {
                returnLock.unlock();
                borrowLock.unlock();
            }
        } 
        
        public E returnPool(E e) {   
            try {
                returnLock.lock();
                int k = idx.get() + 1;
                idx.set(k);
                return this.set(k, e);
            } finally {
                returnLock.unlock();
            }
        }
    }
}
