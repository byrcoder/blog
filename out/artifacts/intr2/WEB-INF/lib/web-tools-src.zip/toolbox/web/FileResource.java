/**
 * @(#)FileResource.java, 2007-5-17. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.web;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 本地文件资源，资源对象会创建后台线程不断检查文件是否已经更新，在文件更新的时候
 * 通知所有注册到这个资源的listener.
 * 
 * @author river
 *
 */
public class FileResource {
    private File file;
    private long checkInterval;
    private long lastModified = 0;
    private List<HttpResource.FileChangeListener> listeners = new ArrayList<HttpResource.FileChangeListener>();
    
    /**
     * 创建一个文件资源，这个资源每隔interval(ms)时间检查一次文件是否更新.
     * @param file
     * @param interval
     */
    public FileResource(File file, long interval) {
        this.file = file;
        if (file.exists())
            lastModified = file.lastModified();
        else
            lastModified = 0;
        this.checkInterval = interval;
        Thread checkThread = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    checkUpdate();
                    try {
                        Thread.sleep(checkInterval);
                    } catch(InterruptedException e) {}
                }
            }
        }, "checkThread");
        checkThread.setDaemon(true);
        checkThread.start();
    }
    
    /**
     * 在这个文件资源上注册一个更新回调接口.
     * @param listener
     */
    public void registerListener(HttpResource.FileChangeListener listener) {
        synchronized(listeners) {
            listeners.add(listener);
            if (lastModified != 0) {
                listener.onFileChange(file);
            }
        }
    }
    
    private void checkUpdate() {
        long time = file.exists() ? file.lastModified() : 0;
        if (time != lastModified) {
            if (time != 0) {
                synchronized(listeners) {
                    for (HttpResource.FileChangeListener listener : listeners) {
                        listener.onFileChange(file);
                    }
                }
            }
            lastModified = time;
        }
    }
    
}
