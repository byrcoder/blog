package toolbox.web;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import toolbox.misc.LogFormatter;

public class ErrorPageController implements Controller {
    private static final Logger LOG = LogFormatter.getLogger(ErrorPageController.class.getName());
    private boolean debug = false;
    private String contentType = "text/html; charset=utf-8";
    public void setContentType(String value) {
        contentType = value;
    }
    public void setDebug(boolean debug) {
        this.debug = debug;
    }
    public void setUpdateClient(Object updateClient) {
        this.updateClient = updateClient;
    }
    private Object updateClient;
    public ModelAndView handleRequest(HttpServletRequest req,
            HttpServletResponse res) throws Exception {
        Throwable ex = (Throwable) req.getAttribute("javax.servlet.error.exception");
        String uri = (String) req.getAttribute("javax.servlet.error.request_uri");
        HashMap<String, Object> model = new HashMap<String, Object>();
        model.put("debug", debug);
        model.put("viewUtils", ViewUtils.getInstance());
        res.setContentType(contentType);
        if(ex == null) {
            model.put("type", "not_found");
            model.put("request_uri", uri);
        } else {
            model.put("type", "exception");
            model.put("exception", ex);
            LOG.log(Level.WARNING, "Exception", ex);
        }
        if (updateClient != null) {
            model.put("resources", updateClient);
        }
        return new ModelAndView("error", model);
    }
}
