package toolbox.web;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Tool to set, find and delete cookie.
 * @author river
 *
 */
public class CookieUtil {
    
    /**
     * Find the cookie with given name.
     * @param request
     * @param name
     * @return
     */
    public static Cookie findCookie(HttpServletRequest request, String name) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return null;
        }

        for (Cookie cookie : cookies) {
            if (cookie.getName().equals(name)) {
                return cookie;
            }
        }

        return null;
    }
    
    /**
     * Add cookie to response.
     * If the max age is negative, the cookie should remain 
     * in the memory of browser and lost when the browser is closed;
     * if the max age is positive, the cookie should be persistent
     * until the age reached; if the max age is zero, then the cookie
     * is removed.
     * 
     * @param response Http response
     * @param name name of cookie
     * @param value value of cookie
     * @param domain domain of cookie, can be null
     * @param path path of cookie, can be null
     * @param age max age of cookie(in seconds)
     * @throws ServletException
     */
    public static void addCookie(HttpServletResponse response, 
            String name, 
            String value, 
            String domain, 
            String path, 
            int age) throws ServletException {
        if (name.indexOf(' ') >= 0 || value.indexOf(' ') >=0) {
            throw new ServletException("cookie value should not contains space");
        }
        Cookie cookie = new Cookie(name, value);
        if (domain != null) {
            cookie.setDomain(domain);
        }
        cookie.setPath(path);
        cookie.setMaxAge(age);
        response.addCookie(cookie);
    }
    
    /**
     * Remove the cookie.
     * @param response
     * @param name
     * @param domain
     * @param path
     * @throws ServletException
     */
    public static void deleteCookie(HttpServletResponse response,
            String name,
            String domain,
            String path) throws ServletException {
        addCookie(response, name, "deleted", domain, path, 0);
    }

}
