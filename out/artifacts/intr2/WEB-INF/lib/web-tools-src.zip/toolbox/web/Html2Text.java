/**
 * @(#)Html2Text.java, 2009-10-29. 
 * 
 * Copyright 2009 Netease, Inc. All rights reserved.
 * NETEASE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.web;

import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import toolbox.tousy.html.DefaultHtmlHandler;
import toolbox.tousy.html.HTMLElements;
import toolbox.tousy.html.HTMLScanner;

/**
 * 从html中抽取正文，基于tousy
 *
 * @author guocz
 *
 */
public class Html2Text {
    
    /**
     * 从html中抽取正文，如果出错，返回""
     * @param html
     * @return
     */
    public static String html2Text(String html) {
        if (StringUtils.isEmpty(html)) {
            return StringUtils.EMPTY;
        }
        HTMLScanner scanner = new HTMLScanner();
        Html2TextHandler handler = new Html2TextHandler();
        scanner.registerHtmlHandler(handler);
        try {
            scanner.scan(new StringReader(html));
        } catch (IOException e) {
            return StringUtils.EMPTY;
        }
        return handler.getText();
    }

    private static class Html2TextHandler extends DefaultHtmlHandler {

        private boolean inScript = false;
        
        private boolean inStyle = false;
        
        private boolean inHeader = false;
        
        private StringBuffer sb = new StringBuffer();
        
        public String getText() {
            return sb.toString();
        }
        @Override
        public void characters(char[] buf, int offset, int count) {
            if (action()) {
                sb.append(buf, offset, count);
            }
        }

        private boolean action() {
            return !inScript && !inStyle && !inHeader;
        }

        @Override
        public void emptyElement(String name, int code, Properties attributes,
                char[] attrValue, int offset, int count) {
        }

        @Override
        public void endElement(String name, int code) {
            if (code == HTMLElements.SCRIPT) {
                inScript = false;
            } else if (code == HTMLElements.STYLE) {
                inStyle = false;
            } else if (code == HTMLElements.HEAD) {
                inHeader = false;
            }
        }

        @Override
        public void startElement(String name, int code, Properties attributes,
                char[] attrValue, int offset, int count) {
            if (code == HTMLElements.SCRIPT) {
                inScript = true;
            } else if (code == HTMLElements.STYLE) {
                inStyle = true;
            } else if (code == HTMLElements.HEAD) {
                inHeader = true;
            }
        }
        
    }
}
