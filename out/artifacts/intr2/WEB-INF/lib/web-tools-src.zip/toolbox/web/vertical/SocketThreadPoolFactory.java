package toolbox.web.vertical;

import java.net.InetSocketAddress;

public class SocketThreadPoolFactory {
    private int poolSize = 2;
    public void setPoolSize(int size) {
        poolSize = size;
    }
    private long threadTimeOut = 5000;
    public void setThreadTimeOut(long ms) {
        this.threadTimeOut = ms;
    }
    public SocketThreadPool createPool(InetSocketAddress addr) {
        return new SocketThreadPool(addr, poolSize, threadTimeOut);
    }
}
