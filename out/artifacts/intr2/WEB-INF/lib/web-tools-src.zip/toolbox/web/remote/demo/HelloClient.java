/**
 * @(#)HelloClient.java, 2008-7-7. Copyright 2008 Yodao, Inc. All rights
 *                                 reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use
 *                                 is subject to license terms.
 */
package toolbox.web.remote.demo;

import java.net.InetSocketAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeoutException;

import toolbox.simplenet.commons.NamedThreadFactory;
import toolbox.web.remote.BroadcastClient;
import toolbox.web.remote.RemoteClient;
import toolbox.web.remote.Request;
import toolbox.web.remote.Response;
import toolbox.web.remote.BroadcastClient.BroadcastFuture;
import toolbox.web.remote.RemoteClient.RemoteFuture;

/**
 * demo程序的客户端
 * 
 * @author ares
 */
public class HelloClient {

    public static void main(String[] args) throws Exception {
        ScheduledExecutorService retryThreadPool = 
            Executors.newScheduledThreadPool(5, new NamedThreadFactory("retryThread", true));

        // 测试同步调用
        RemoteClient client = new RemoteClient("hello", new InetSocketAddress(
                "127.0.0.1", 17911), retryThreadPool);
        Request request = new Request("query", "127.0.0.1", "ares");
        Response response = client.execute(request);
        System.out.println("Response name = " + response.getResultRecord(0).getName());
        System.out.println("Response result = "
                + response.getResultRecord(0).getProperties().get("result"));

        // 测试异步调用
        RemoteFuture[] futures = new RemoteFuture[20];
        for (int i = 0; i < 5; i++) {
            request = new Request("query-" + i, "127.0.0.1", "ares-" + i);
            futures[i] = client.submit(request);
            Thread.sleep(100);
        }
        for (int i = 0; i < 5; i++) {
            response = (Response) futures[i].getResult();
            System.out.println("Finished client " + i);
            System.out.println("Client " + i + " finished. time = "
                    + response.getResultRecord(0).getProperties().get("result")
                    + " response name = <" + response.getResultRecord(0).getName() + ">");
        }

        // 测试异步调用超时
        request = new Request("query-test-time-out", "127.0.0.1", "ares");
        RemoteFuture future = client.submit(request, 1000);
        try {
            future.getResult();
        } catch (TimeoutException e) {
            System.out.println("time out success.");
        } catch (Throwable t) {
            t.printStackTrace();
        }
        client.close();

        // 测试Broadcast
        request = new Request("query-test-broadcast", "127.0.0.1", "ares");
        BroadcastClient bc = new BroadcastClient();
        bc.register("demo", new InetSocketAddress("localhost", 17911));
        BroadcastFuture f = bc.submit(request);
        Response res = f.getAllResponses().get(0);
        System.out.println("Name: " + res.getResultRecord(0).getName() + " result: "
                + res.getResultRecord(0).getProperties().get("result"));

    }

}
