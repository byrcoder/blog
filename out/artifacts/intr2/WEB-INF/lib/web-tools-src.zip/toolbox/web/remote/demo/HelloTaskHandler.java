/**
 * @(#)HelloTaskHandler.java, 2008-7-7. Copyright 2008 Yodao, Inc. All rights
 *                                      reserved. YODAO
 *                                      PROPRIETARY/CONFIDENTIAL. Use is subject
 *                                      to license terms.
 */
package toolbox.web.remote.demo;

import toolbox.simplenet.rpc.RPCException;
import toolbox.simplenet.server.Context;
import toolbox.web.remote.IRemoteTaskHandler;
import toolbox.web.remote.Request;
import toolbox.web.remote.Response;
import toolbox.web.remote.Result;

/**
 * 服务器端的处理程序
 * 
 * @author ares
 */
public class HelloTaskHandler implements IRemoteTaskHandler {

    public Response execute(Request request) throws RPCException {
        System.out.println("Get a request from [user=" + request.getUser()
                + "][ip=" + request.getIP() + "]" + "[query="
                + request.getQuery() + "]");
        try {
            if (request.getUser().equals("ares"))
                Thread.sleep(10000);
            else
                Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Response response = new Response();
        Result result = new Result();
        result.setName("hello");
        result.getProperties().put("result", Long.toString(System.currentTimeMillis()));
        response.addResultRecord(result);
        return response;
    }

    public void onContextCreate(Context context) {
        System.out.println("Client connected.");
    }

    public void onContextDestroy(Context context) {
        System.out.println("Client closed.");
    }

    public void monitorPing() throws RPCException {
        // TODO Auto-generated method stub
        
    }

}
