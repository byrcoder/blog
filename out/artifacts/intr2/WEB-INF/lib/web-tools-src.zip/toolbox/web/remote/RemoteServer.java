/**
 * @(#)RemoteServer.java, 2008-7-10. Copyright 2008 Yodao, Inc. All rights
 *                                   reserved. YODAO PROPRIETARY/CONFIDENTIAL.
 *                                   Use is subject to license terms.
 */
package toolbox.web.remote;

import java.io.IOException;

import toolbox.simplenet.rpc.RPCServer;

/**
 * 对{@link RPCServer}的一个封装，任何远程服务都需要通过传递一个{@link IRemoteTaskHandler}
 * 来启动一个RemoteServer.
 * 
 * 注意RemoteServer只拥有一个IRemoteTaskHandler的实例，这个实例是被复用的，你需要保证{@link IRemoteTask}
 * 的操作调用是线程安全的
 * 
 * 调用方式如下：
 * <code>
 *   RemoteServer server = new RemoteServer(instance, port);
 *   server.start();
 * </code>
 * 注意，你可以使用{@link #join()}等待服务器推出
 * 
 * @author ares
 */
public class RemoteServer {

    private RPCServer server;

    public RemoteServer(IRemoteTaskHandler handler, int port) {
        this(handler, port, 1, 1);
    }

    /**
     * 初始化服务.
     * @param handler
     * @param port
     * @param ioWorkerNumber 服务保持的io连接数目
     * @param processorNumber 处理线程数量
     */
    public RemoteServer(IRemoteTaskHandler handler, int port,
            int ioWorkerNumber, int processorNumber) {
        server = new RPCServer(handler, port, ioWorkerNumber, processorNumber);
        server.getServer().setVerbose(false);
    }

    /**
     * 启动服务.
     * @throws IOException
     */
    public void start() throws IOException {
        server.start();
    }
    
    /**
     * 停止服务.
     */
    public void stop() {
        server.stop();
    }

    /**
     * 等待服务退出.
     * @throws InterruptedException
     */
    public void join() throws InterruptedException {
        server.join();
    }

}
