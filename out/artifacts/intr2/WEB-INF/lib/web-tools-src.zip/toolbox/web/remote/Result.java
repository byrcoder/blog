/**
 * @(#)Result.java, 2008-9-4. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.web.remote;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 *
 * @author zhangkun
 *
 */
public class Result implements IWritable {

    private String name;
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    private final WritableProperties props = new WritableProperties();
    public WritableProperties getProperties() {
        return props;
    }
    public void put(String key, String value) {
        props.put(key, value);
    }
    public String get(String key) {
        return props.get(key);
    }
    public void readFields(DataInput in) throws IOException {
        name = StringWritable.readString(in);
        props.readFields(in);
    }

    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, name);
        props.writeFields(out);
    }

    public IWritable copyFields(IWritable value) {
        Result v = (Result)value;
        this.name = v.name;
        this.props.copyFields(v.props);
        return this;
    }
    @Override
    public String toString() {
        return "[Result name=" + name + ", props=" + props + "]";
    }
}
