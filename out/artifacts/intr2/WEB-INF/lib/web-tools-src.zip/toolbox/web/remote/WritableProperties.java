/**
 * 
 */
package toolbox.web.remote;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * writable configuration
 * 
 * @author ares
 */
public class WritableProperties extends
        HashMap<String, String> implements IWritable {

    private static final long serialVersionUID = -9115898915211080751L;

    public void readFields(DataInput in) throws IOException {
        clear();
        int size = in.readInt();
        for(int i = 0; i < size; i++) {
            String key = StringWritable.readStringNull(in);
            String value = StringWritable.readStringNull(in);
            put(key, value);
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(size());
        for(Map.Entry<String, String> e : this.entrySet()) {
            StringWritable.writeStringNull(out, e.getKey());
            StringWritable.writeStringNull(out, e.getValue());
        }
    }
    
    public IWritable copyFields(IWritable arg0) {
        this.clear();
        this.putAll((WritableProperties)arg0);
        return this;
    }
}
