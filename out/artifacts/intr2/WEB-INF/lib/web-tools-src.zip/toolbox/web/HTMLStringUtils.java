/**
 * @(#)HTMLStringUtils.java, 2009-9-28. Copyright 2009 Youdao, Inc. All rights
 *                           reserved. YOUDAO PROPRIETARY/CONFIDENTIAL. Use is
 *                           subject to license terms.
 */
package toolbox.web;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.tidy.Configuration;
import org.w3c.tidy.LexParseException;
import org.w3c.tidy.Tidy;

import toolbox.misc.LogFormatter;
import toolbox.tousy.html.HTMLElements;
import toolbox.tousy.html.HTMLHandler;
import toolbox.tousy.html.RawHTMLScanner;

/**
 * @author sunly
 */
public class HTMLStringUtils {
    public static final Logger LOG = LogFormatter.getLogger(HTMLStringUtils.class);

    private static void warningThis(String msg) {
        LOG.log(Level.WARNING, "[" + HTMLStringUtils.class.getSimpleName() + "]" + msg);
    }

    private static void warningThis(String msg, Exception e) {
        LOG.log(Level.WARNING, "[" + HTMLStringUtils.class.getSimpleName() + "]" + msg, e);
    }

    static {
        warningThis("initialized");
    }
    /**
     * 过滤掉所有的html标签, 且转义代码也被转换; 连续空格被当作一个; 使用HTMLScanner
     */
    public static final int FILTER_NO_TAG = 0x0001;
    
    public static final int FILTER_NEWLINE = 0x0002;

    /**
     * 去除PRE标签
     */
    public static final int FILTER_PRE = 0x0008;

    public static final int FILTER_SCRIPT = 0x0010;
    public static final HTMLStringUtils instance = new HTMLStringUtils();

    private static Tidy tidy = new Tidy();
    static {
        tidy.setNumEntities(true);
        tidy.setCharEncoding(Configuration.UTF8);
        tidy.setXHTML(true);
    }

    /**
     * <p>
     * Escapes the characters in a <code>String</code> using HTML entities.
     * </p>
     * <p>
     * For example:
     * </p>
     * <p>
     * <code>"bread" & "butter"</code>
     * </p>
     * becomes:
     * <p>
     * <code>&amp;quot;bread&amp;quot; &amp;amp; &amp;quot;butter&amp;quot;</code>
     * .
     * </p>
     * <p>
     * Supports all known HTML 4.0 entities, including funky accents. Note that
     * the commonly used apostrophe escape character (&amp;apos;) is not a legal
     * entity and so is not supported).
     * </p>
     * 
     * @param str
     *            the <code>String</code> to escape, may be null
     * @return a new escaped <code>String</code>, <code>null</code> if null
     *         string input
     * @see #unescapeHtml(String)
     * @see <a
     *      href="http://hotwired.lycos.com/webmonkey/reference/special_characters/">ISO
     *      Entities</a>
     * @see <a href="http://www.w3.org/TR/REC-html32#latin1">HTML 3.2 Character
     *      Entities for ISO Latin-1</a>
     * @see <a href="http://www.w3.org/TR/REC-html40/sgml/entities.html">HTML
     *      4.0 Character entity references</a>
     * @see <a href="http://www.w3.org/TR/html401/charset.html#h-5.3">HTML 4.01
     *      Character References</a>
     * @see <a
     *      href="http://www.w3.org/TR/html401/charset.html#code-position">HTML
     *      4.01 Code positions</a> XXX: 这里直接拷贝了apache的部分包, 因为直接用会把汉字转义
     */
    public static String escapeHtml(String str) {
        // TODO: shall we use toolbox.tousy.html.HTMLEscape instead?
        if (str == null) {
            return null;
        }
        StringWriter writer = new StringWriter((int) (str.length() * 1.5));
        int len = str.length();
        for (int i = 0; i < len; i++) {
            char c = str.charAt(i);
            String entityName = Entities.HTML40.entityName(c);
            if (entityName == null) {
                writer.write(c);
            } else {
                writer.write('&');
                writer.write(entityName);
                writer.write(';');
            }
        }
        return writer.toString();
    }

    /**
     * <p>
     * Unescapes a string containing entity escapes to a string containing the
     * actual Unicode characters corresponding to the escapes. Supports HTML 4.0
     * entities.
     * </p>
     * <p>
     * For example, the string "&amp;lt;Fran&amp;ccedil;ais&amp;gt;" will become
     * "&lt;Fran&ccedil;ais&gt;"
     * </p>
     * <p>
     * If an entity is unrecognized, it is left alone, and inserted verbatim
     * into the result string. e.g. "&amp;gt;&amp;zzzz;x" will become
     * "&gt;&amp;zzzz;x".
     * </p>
     * 
     * @param str
     *            the <code>String</code> to unescape, may be null
     * @return a new unescaped <code>String</code>, <code>null</code> if null
     *         string input
     * @see #escapeHtml(Writer, String)
     */
    public static String unescapeHtml(String str) {
        if (str == null) {
            return null;
        }
        StringWriter writer = new StringWriter((int) (str.length() * 1.5));
        int firstAmp = str.indexOf('&');
        if (firstAmp < 0) {
            writer.write(str);
        } else {
            writer.write(str, 0, firstAmp);
            int len = str.length();
            for (int i = firstAmp; i < len; i++) {
                char c = str.charAt(i);
                if (c == '&') {
                    int nextIdx = i + 1;
                    int semiColonIdx = str.indexOf(';', nextIdx);
                    if (semiColonIdx == -1) {
                        writer.write(c);
                        continue;
                    }
                    int amphersandIdx = str.indexOf('&', i + 1);
                    if (amphersandIdx != -1 && amphersandIdx < semiColonIdx) {
                        // Then the text looks like &...&...;
                        writer.write(c);
                        continue;
                    }
                    String entityContent = str.substring(nextIdx, semiColonIdx);
                    int entityValue = -1;
                    int entityContentLen = entityContent.length();
                    if (entityContentLen > 0) {
                        if (entityContent.charAt(0) == '#') { // escaped value
                            // content is an
                            // integer
                            // (decimal or
                            // hexidecimal)
                            if (entityContentLen > 1) {
                                char isHexChar = entityContent.charAt(1);
                                try {
                                    switch (isHexChar) {
                                        case 'X':
                                        case 'x': {
                                            entityValue = Integer.parseInt(entityContent.substring(2), 16);
                                            break;
                                        }
                                        default: {
                                            entityValue = Integer.parseInt(entityContent.substring(1), 10);
                                        }
                                    }
                                    if (entityValue > 0xFFFF) {
                                        entityValue = -1;
                                    }
                                } catch (NumberFormatException e) {
                                    entityValue = -1;
                                }
                            }
                        } else { // escaped value content is an entity name
                            entityValue = Entities.HTML40.entityValue(entityContent);
                        }
                    }

                    if (entityValue == -1) {
                        writer.write('&');
                        writer.write(entityContent);
                        writer.write(';');
                    } else {
                        writer.write(entityValue);
                    }
                    i = semiColonIdx; // move index up to the semi-colon
                } else {
                    writer.write(c);
                }
            }
        }
        return writer.toString();
    }

    public static String escapeXml(String str) {
        if (str == null) {
            return null;
        }
        StringWriter writer = new StringWriter((int) (str.length() * 1.5));
        int len = str.length();
        for (int i = 0; i < len; i++) {
            char c = str.charAt(i);
            String entityName = Entities.XML.entityName(c);
            if (entityName == null) {
                writer.write(c);
            } else {
                writer.write('&');
                writer.write(entityName);
                writer.write(';');
            }
        }
        return writer.toString();
    }

    /**
     * <p>
     * Cleans up all invalid tags, and return it.
     * </p>
     * <p>
     * this method will filter all invalid tags, encode all attribute values
     * using {@link #escapeHtml(String)}
     * </p>
     * <p>
     * for example: "\&lt;p&gt;&lt;em&gt;&lt;a href=\"http://a.com/a?b=1&amp;c=3\"&gt;test &amp; a &gt; &lt;/a&gt;&lt;/em&gt;&lt;/p&gt;&lt;br&gt;&lt;div&gt;"
     * will be converted into "\&lt;p&gt;&lt;em&gt;&lt;a href=\"http://a.com/a?b=1&amp;c=3\"&gt;test &amp; a &amp;gt; &amp;lt;/a&gt;&lt;/em&gt;&lt;/p&gt;&lt;br&gt;&lt;div&gt;"
     * </p>
     * <p>
     * if input string contains too much error and cannot be automatically
     * fixed, then null will be returned.
     * 
     * @param str
     * @return valid html content
     */
    public static String tidyHtmlContent(String str) {
        if (str == null)
            return "";

        ByteArrayInputStream Bis1;
        try {
            str = HTMLStringUtils.filter(str, HTMLStringUtils.FILTER_PRE | HTMLStringUtils.FILTER_SCRIPT);
            Bis1 = new ByteArrayInputStream(("<body>" + str + "</body>").getBytes("UTF-8"));
            ByteArrayOutputStream sos = new ByteArrayOutputStream();
            tidy.parse(Bis1, sos);
            String result = sos.toString("UTF-8");
            int start = result.indexOf("<body>") + 6;
            int end = result.lastIndexOf("</body>");
            result = result.substring(start, end).replaceAll("\\s+", " ").trim();
            return result;
        } catch (UnsupportedEncodingException e) {
            warningThis("tidyHtmlContent ~ encoding failed", e);
        } catch (LexParseException e) {
            warningThis("tidyHtmlContent ~ parse failed", e);
        }

        // 如果抛了异常, 则返回去掉所有标签的内容
        return HTMLStringUtils.filter(str, HTMLStringUtils.FILTER_NO_TAG);
    }

    /**
     * <p>
     * Cleans up all invalid tags, and return it.
     * </p>
     * <p>
     * This is just a wrapper for {@link #tidyHtmlContent(String)}
     * 
     * @param buf
     * @param offset
     * @param count
     * @return tidied up String
     */
    public static String tidyHtmlContent(char[] buf, int offset, int count) {
        return tidyHtmlContent(new String(buf, offset, count));
    }

    /**
     * <p>
     * Escapes the characters in a <code>String</code> using JavaScript String
     * rules. 中文将被转成unicode内码形式(<code>'\\u'</code>), 因此只能用于表示前的最后一次转换.
     * </p>
     * <p>
     * Escapes any values it finds into their JavaScript String form. Deals
     * correctly with quotes and control-chars (tab, backslash, cr, ff, etc.)
     * </p>
     * <p>
     * So a tab becomes the characters <code>'\\'</code> and <code>'t'</code>.
     * </p>
     * <p>
     * The only difference between Java strings and JavaScript strings is that
     * in JavaScript, a single quote must be escaped.
     * </p>
     * <p>
     * Example:
     * 
     * <pre>
     * input string: He didn't say, &quot;Stop!&quot;
     * output string: He didn\'t say, \&quot;Stop!\&quot;
     * </pre>
     * 
     * </p>
     * 
     * @param str
     *            String to escape values in, may be null
     * @return String with escaped values, <code>null</code> if null string
     *         input
     */
    public static String escapeJson(String json) {
        return StringEscapeUtils.escapeJavaScript(json);
    }

    /**
     * <p>
     * Unescapes any JavaScript literals found in the <code>String</code>.
     * </p>
     * <p>
     * For example, it will turn a sequence of <code>'\'</code> and <code>'n'</code> into
     * a newline character, unless the <code>'\'</code> is preceded by another <code>'\'</code>.
     * </p>
     * 
     * @param str
     *            the <code>String</code> to unescape, may be null
     * @return A new unescaped <code>String</code>, <code>null</code> if null
     *         string input
     */
    public static String unescapeJson(String str) {
        return StringEscapeUtils.unescapeJavaScript(str);
    }

    public static void main(String args[]) throws LexParseException, UnsupportedEncodingException {
        String blah = "<div>blah<p>测试测试<br>& test >";

        System.out.println(stripAllTags(blah));
    }
    /**
     * 对html文本进行过滤
     * 
     * @param content
     *            原始html
     * @param flags
     *            同时进行多个操作的话用|连接，比如FILTER_IMAGE_URL|FILTER_PRE<br/>
     *            注意彼此互斥的操作不能同时进行，比如FILTER_NO_TAG和FILTER_IMAGE_URL <br/>
     *            {@link #FILTER_NO_TAG}<br/>{@link #FILTER_NO_TAG_HTML_VALID} <br/>
     *            {@link #FILTER_IMAGE_URL}<br/> {@link #FILTER_PRE}
     * @return
     */
    private static String filter(String content, int flags) {
        if (content == null)
            return "";

            RawHTMLScanner scanner = new RawHTMLScanner();
            RebuildHtmlHandler handler = new RebuildHtmlHandler(flags);
            scanner.registerHtmlHandler(handler);
            try {
                scanner.scan(new StringReader(content));
            } catch (IOException e) {
                LOG.log(Level.WARNING, "parse error", e);
                return content;
            }
            return handler.toHtmlString();
    }
    
    public static String stripAllTags(String str){
        if (str == null)
            return "";

        ByteArrayInputStream Bis1;
        try {
            str = HTMLStringUtils.filter(str, HTMLStringUtils.FILTER_NO_TAG | HTMLStringUtils.FILTER_SCRIPT);
            Bis1 = new ByteArrayInputStream(("<body>" + str + "</body>").getBytes("UTF-8"));
            ByteArrayOutputStream sos = new ByteArrayOutputStream();
            tidy.parse(Bis1, sos);
            String result = sos.toString("UTF-8");
            int start = result.indexOf("<body>") + 6;
            int end = result.lastIndexOf("</body>");
            result = result.substring(start, end).replaceAll("\\s+", " ").trim();
            return result;
        } catch (UnsupportedEncodingException e) {
            warningThis("stripAllTags ~ encoding failed", e);
        } catch (LexParseException e) {
            warningThis("stripAllTags ~ parse failed", e);
        }

        // 如果抛了异常, 则返回去掉所有标签的内容
        return HTMLStringUtils.filter(str, HTMLStringUtils.FILTER_NO_TAG);
    }
    
    /**
     * 去掉所有的tag，同时，div，p，br标签都会被转换为\n
     * @param str
     * @return
     */
    public static String stripToPrintable(String str) {
        return filter(str, FILTER_NO_TAG | FILTER_NEWLINE);
    }

}
/**
 * @author zhangduo
 */
class RebuildHtmlHandler implements HTMLHandler {

    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(RebuildHtmlHandler.class);

    private StringBuilder sb = new StringBuilder();

    private int flags;

    private boolean inScript = false;

    public RebuildHtmlHandler(int flags) {
        this.flags = flags;
    }

    public void characters(char[] buf, int offset, int count) {

        if (action(HTMLStringUtils.FILTER_SCRIPT) && inScript)
            return;

        if (action(HTMLStringUtils.FILTER_NO_TAG)) {
            if (!inScript) {
                sb.append(buf, offset, count);
            }
            return;
        }
        sb.append(buf, offset, count);
    }

    public void comment(char[] buf, int offset, int count) {
    // ignore

    }

    public void declDoctype(String root, String pubid, String sysid) {
    // ignore

    }

    public void emptyElement(String name, int code, Properties attributes, char[] attrBuffer, int offset, int count) {
        if (ignoreElement(code)) {
            return;
        }
        
        if (action(HTMLStringUtils.FILTER_NEWLINE)) {
            if (code == HTMLElements.BR) {
                sb.append("\n");
                return;
            }
        }

        if (action(HTMLStringUtils.FILTER_NO_TAG)) {
            return;
        }

        if (action(HTMLStringUtils.FILTER_PRE) && code == HTMLElements.PRE) {
            return;
        }

        if (action(HTMLStringUtils.FILTER_SCRIPT) && code == HTMLElements.SCRIPT) {
            return;
        }

        if (HTMLElements.TAGSET.contains(name)) {
            sb.append("<" + name);
            for (Map.Entry<Object, Object> entry: attributes.entrySet()) {
                String key = entry.getKey().toString();
                if (key.startsWith("on"))
                    continue;
                sb.append(" " + key + "=\"" + HTMLStringUtils.escapeHtml(entry.getValue().toString()) + "\"");
            }
            sb.append("/>");
        }
    }

    public void endDocument() {
    // do nothing
    }

    public void startDocument() {
    // do nothing
    }

    public void endElement(String name, int code) {
        if (ignoreElement(code)) {
            return;
        }
        if (action(HTMLStringUtils.FILTER_NEWLINE)) {
            if (code == HTMLElements.P || code == HTMLElements.DIV) {
                sb.append("\n");
                return;
            }
        }
        if (action(HTMLStringUtils.FILTER_NO_TAG)) {
            if (code == HTMLElements.SCRIPT) {
                inScript = false;
            }
            return;
        }
        if (action(HTMLStringUtils.FILTER_PRE) && code == HTMLElements.PRE) {
            return;
        }
        if (action(HTMLStringUtils.FILTER_SCRIPT) && code == HTMLElements.SCRIPT) {
            inScript = false;
            return;
        }
        if (HTMLElements.TAGSET.contains(name))
            sb.append("</" + name + ">");
    }

    public void startElement(String name, int code, Properties attributes, char[] attrBuffer, int offset, int count) {
        if (ignoreElement(code)) {
            return;
        }
        if (action(HTMLStringUtils.FILTER_NO_TAG)) {
            if (code == HTMLElements.SCRIPT) {
                inScript = true;
            }
            return;
        }
        if (action(HTMLStringUtils.FILTER_PRE) && code == HTMLElements.PRE) {
            return;
        }
        if (action(HTMLStringUtils.FILTER_SCRIPT) && code == HTMLElements.SCRIPT) {
            inScript = true;
            return;
        }
        if (HTMLElements.TAGSET.contains(name)) {
            sb.append("<" + name);
            if(name.equals("a")){
                //if we found a link, then set target -> _blank
                attributes.setProperty("target", "_blank");
            }
            
            for (Map.Entry<Object, Object> entry: attributes.entrySet()) {
                String key = entry.getKey().toString();
                if (key.startsWith("on"))
                    continue;
                sb.append(" " + key + "=\"" + HTMLStringUtils.escapeHtml(entry.getValue().toString()) + "\"");
            }
            sb.append(">");
        }
    }

    private boolean ignoreElement(int code) {
        return code == HTMLElements.HTML || code == HTMLElements.BODY || code == HTMLElements.HEAD;
    }

    public String toHtmlString() {
        return sb.toString();
    }

    private boolean action(int flag) {
        return (flags & flag) != 0;
    }

}
