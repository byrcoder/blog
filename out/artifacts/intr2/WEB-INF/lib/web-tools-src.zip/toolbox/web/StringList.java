package toolbox.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * provided a String list, which initialized by {@link HttpResource} or
 * {@link FileResource}; which check by the http:// or not.
 * <p>
 * file read into string list as each string in one line.
 * <p>
 * line start with # makes comments.
 * 
 * @author shicq
 */
public class StringList implements toolbox.web.HttpResource.FileChangeListener {
    public static final Logger LOG = LogFormatter.getLogger(StringList.class);

    String uri;

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public StringList() {
    }
    
    public StringList(String uri) {
        this(uri, 50);
    }

    public StringList(String uri,long checkInterval) {
        this.uri = uri;
        this.checkInterval = checkInterval;
        this.init();
    }

    ArrayList<String> strings = new ArrayList<String>();

    private String[] sortedStrings = new String[0];

    long checkInterval = 60000;

    final ReentrantLock lock = new ReentrantLock(); 
    
    
    Comparator<String> comparator = null;
    
    public Comparator<String> getComparator() {
        return comparator;
    }

    public void setComparator(Comparator<String> comparator) {
        this.comparator = comparator;
    }

    public ArrayList<String> getStrings() {
        return new ArrayList<String>(strings);
    }

    public long getCheckInterval() {
        return checkInterval;
    }

    public void setCheckInterval(long checkInterval) {
        this.checkInterval = checkInterval;
    }

    @Override
    public void onFileChange(File file) {
        // when file changed, reload the content.
        ArrayList<String> tmpStrings; 
        String[] tmpSortedStrings; 
        try {
            ArrayList<String> list = new ArrayList<String>();
            BufferedReader reader = new BufferedReader(new FileReader(file));
            try {
                String s = null;
                while ((s = reader.readLine()) != null) {
                    s = s.trim();
                    if (s.startsWith("#") || s.length() < 1) {
                        continue;
                    } else {
                        list.add(s);
                    }
                }
            } finally {
                reader.close();
            }
            LOG.info("loaded " + list.size() + " strings from " + uri);
            if (list.size() > 0) {
                tmpStrings = list;
                tmpSortedStrings = list.toArray(new String[list.size()]);
                // sort.
                if (comparator != null) {
                    Arrays.sort(tmpSortedStrings, comparator);
                } else {
                    Arrays.sort(tmpSortedStrings);
                }
                
                try {
                    // lock the change.
                    lock.lock();
                    ArrayList<String> old = strings;
                    String[] oldsorted = sortedStrings;
                    strings = tmpStrings;
                    sortedStrings = tmpSortedStrings;
                    // clear;
                    old.clear();
                    old = null;
                    for (int i = 0; i < oldsorted.length; i++)
                        oldsorted[i] = null;
                    oldsorted = null;
                } finally {
                    lock.unlock();
                }
            }            

        } catch (Throwable th) {
            final String msg = this + " onFileChange fail.";
            LOG.log(Level.WARNING, msg, th);
        } 
        // null means fail.
        if (strings.size() == 0) {
            final String msg = this + " onFileChange warning.";
            LOG.log(Level.WARNING, msg);
        }
    }

    /**
     * initialize the string list;
     */
    public void init() {
        if (uri.trim().toLowerCase().startsWith("http://")) {
            File localDirectory = new File("_stringlist_");
            // if not exist, create the directory.
            if (!localDirectory.exists()) {
                localDirectory.mkdir();
            }
            File local = new File(localDirectory, "_stringlist_"
                    + Math.abs(uri.hashCode()) + "_");
            HttpResource hr = new HttpResource(uri, local, checkInterval);
            hr.registerListener(this);
        } else {
            FileResource fr = new FileResource(new File(uri), checkInterval);
            fr.registerListener(this);
        }
    }

    /**
     * The number of <code>item</code>s in the list. The range of valid
     * child object indices is 0 to <code>length-1</code> inclusive.
     */
    public int getLength() {
        return strings.size();
    }

    /**
     * Checks if the<code>item</code> is a member of
     * this list.
     * 
     * @param item
     *            <code>item</code> whose presence in this list is to
     *            be tested.
     * @return True if this list contains the <code>item</code>.
     */
    public boolean contains(String item) {
        try {
            lock.lock();
            int index = -1;
            if (comparator != null) {
                index = Arrays.binarySearch(sortedStrings, item, comparator);
            } else {
                index = Arrays.binarySearch(sortedStrings, item);
            }
            if (index > -1) {
                return true;
            } else {
                return false;
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * Returns the <code>index</code>th item in the collection or
     * <code>null</code> if <code>index</code> is greater than or equal to the
     * number of objects in the list. The index starts at 0.
     * 
     * @param index
     *            index into the collection.
     * @return The <code>index</code>th
     *         position in the <code>StringList</code>, or <code>null</code> if
     *         the index specified is not valid.
     */
    public String item(int index) {
        try {
            lock.lock();
            return strings.get(index);
        } catch (IndexOutOfBoundsException e) {
            LOG.warning("StringList:" + e.getMessage());
            return null;
        } finally {
            lock.unlock();
        }
    }
    
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (Field f: this.getClass().getDeclaredFields()) {
            try {
                if (Modifier.isPublic(f.getModifiers())
                        || Modifier.isStatic(f.getModifiers())
                        || Modifier.isFinal(f.getModifiers()))
                    continue;
                if (sb.length() > 1) {
                    sb.append("; ");
                }
                sb.append(f.getName()).append("=").append(f.get(this));
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
