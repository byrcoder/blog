/**
 * @(#)BroadcastClient.java, 2008-7-13. Copyright 2008 Yodao, Inc. All rights
 *                                      reserved. YODAO
 *                                      PROPRIETARY/CONFIDENTIAL. Use is subject
 *                                      to license terms.
 */
package toolbox.web.remote;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import toolbox.simplenet.client.Client;
import toolbox.simplenet.commons.NamedThreadFactory;
import toolbox.simplenet.rpc.RPCException;
import toolbox.web.remote.RemoteClient.RemoteFuture;

/**
 * 广播形式的RemoteClient. 
 * <li>利用{@link #register(InetSocketAddress)}注册远程服务, 然后通过
 * {@link #submit(Request)}对所用远程服务进行异步调用.
 * </li>
 * 
 * @author ares
 */
public class BroadcastClient {
    private static final Logger LOG = LogFormatter.getLogger(BroadcastClient.class);
    public BroadcastClient() {
        clients = new ArrayList<RemoteClient>();
    }

    private int connectionNumber = 1;
    private long connectTimeout = Client.DEFAULT_CONNECT_TIMEOUT;
    private long callTimeout = 10000;
    private long retryInterval = 1000;
    private ScheduledExecutorService retryThreadPool = 
        Executors.newScheduledThreadPool(5, new NamedThreadFactory("retryThread", true));
    private ArrayList<RemoteClient> clients;

    public void setConnectionNumber(int connectionNumber) {
        this.connectionNumber = connectionNumber;
        for(RemoteClient client : clients) {
            client.setConnectionNumber(connectionNumber);
        }
    }

    public void setConnectTimeout(long connectTimeout) {
        this.connectTimeout = connectTimeout;
        for(RemoteClient client : clients) {
            client.setConnectTimeout(connectTimeout);
        }
    }

    public void setCallTimeout(long callTimeout) {
        this.callTimeout = callTimeout;
        for(RemoteClient client : clients) {
            client.setCallTimeout(callTimeout);
        }
    }

    public void setRetryInterval(long retryInterval) {
        this.retryInterval = retryInterval;
        for(RemoteClient client : clients) {
            client.setRetryInterval(retryInterval);
        }
    }

    /**
     * 注册一个远程服务
     * @param address 该远程服务的地址
     * @param name 该远程服务的名字，只在输出日志时被使用。
     * @throws RPCException
     * @throws NoSuchMethodException
     */
    public void register(String name, InetSocketAddress address) {
        synchronized (this) {
            RemoteClient client = new RemoteClient(name, address, retryThreadPool);
            client.setCallTimeout(callTimeout);
            client.setConnectTimeout(connectTimeout);
            client.setConnectionNumber(connectionNumber);
            client.setRetryInterval(retryInterval);
            clients.add(client);
        }
    }

    /**
     * 注册一系列远程服务。格式为 "NAME@HOST:PORT"。NAME在输出日志时被使用。
     * @param serverAddrs
     */
    public void setServers(String[] serverAddrs) throws IOException {
        clients.clear();
        for(String addr : serverAddrs) {
            String[] split = addr.split("@");
            if(split.length < 2) {
                throw new RuntimeException("invalid format: " + addr + ", should be NAME@HOST:PORT");
            }
            register(split[0], InetAddressUtils.createSocketAddr(split[1]));
        }
    }
    /**
     * 初始化客户端
     */
    public void init() {
        for(RemoteClient client : clients) {
            try {
                client.init();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Failed to initialize client " + client, e);
            }
        }
    }
    /**
     * 提交一个请求，使用默认的超时时间
     * @param request
     * @return
     */
    public BroadcastFuture submit(Request request) {
        synchronized (this) {
            return submit(request, this.callTimeout);
        }
    }

    /**
     * 提交一个带超时时间的请求
     * @param request
     * @param timeout
     * @return
     */
    public BroadcastFuture submit(Request request, long timeout) {
        synchronized (this) {
            BroadcastFuture future = new BroadcastFuture();
            for (int i = 0; i < clients.size(); i++) {
                RemoteClient client = clients.get(i);
                RemoteFuture f = client.submit(request, timeout);
                future.addFuture(f, request);
            }
            return future;
        }
    }

    /**
     * Map the result types to Spring MVC model keys. Format:
     * result_name:model_key, meaning all Responses with the name response_name
     * will be put in a List of Result with the key model_key in the model.
     */
    private HashMap<String, String> resultMap;
    public void setResultMap(String[] settings) {
        resultMap = new HashMap<String, String>();
        for(String setting : settings) {
            String[] split = setting.split(":");
            if(split.length == 2) {
                resultMap.put(split[0], split[1]);
            }
        }
    }

    /**
     * 提交请求的Future,它有若干个{@link RemoteFuture}组成 
     *
     * @author ares
     *
     */
    public class BroadcastFuture {

        private ArrayList<RemoteFuture> futures;
        private ArrayList<Request> requests;
        
        private BroadcastFuture() {
            futures = new ArrayList<RemoteFuture>();
            requests = new ArrayList<Request>();
        }

        private void addFuture(RemoteFuture future, Request request) {
            futures.add(future);
            requests.add(request);
        }

        /**
         * 获得所有的结果, 阻塞调用
         * @return
         */
        public List<Response> getAllResponses() {
            ArrayList<Response> res = new ArrayList<Response>();
            for (RemoteFuture future : futures) {
                if(future != null) {
                    Response response = null;
                    try {
                        response = future.getResult();
                    } catch (InterruptedException e) {
                        LOG.log(Level.WARNING, "one broadcast future interrupted", e);
                    } catch (ExecutionException e) {
                        LOG.log(Level.WARNING, 
                                "one broadcast future execution failed", e.getCause());
                    } catch (TimeoutException e) {
                        LOG.log(Level.WARNING, "one broadcast future timeout", e);
                    }
                    if (response != null) {
                        res.add(response);
                    }
                }
            }
            return res;
        }

        /**
         * 根据resultMap的映射，将每个Response中的Result放入到model对应的key中.
         * Model中每个key对应一个Result的List。
         */
        public void putInModel(Map<String, Object> model) {
            putInModel(model, null);
        }
        /**
         * 根据resultMap的映射，将每个Response中的Result放入到model对应的key中.
         * Model中每个key对应一个Result的List。
         * 如果req不为null，将把每个服务的返回情况记录到req的attribute中。比如对名为typo的服务，那么会加入web.remote.result.typo这条属性，
         * 可能的值是NA, NORESULT, OK, TIMEOUT.
         * 阻塞调用
         */
        @SuppressWarnings("unchecked")
        public void putInModel(Map<String, Object> model, HttpServletRequest req) {
            for (int i = 0; i < futures.size(); i++) {
                RemoteFuture future = futures.get(i);
                String status;
                if(future == null) {
                    LOG.info("Remote service '" + clients.get(i) + "' is down");
                    status = "NA";
                } else {
                    Response response = null;
                    try {
                        response = future.getResult();
                    } catch (InterruptedException e) {
                        LOG.log(Level.WARNING, "one broadcast future interrupted", e);
                    } catch (ExecutionException e) {
                        LOG.log(Level.WARNING, 
                                "one broadcast future execution failed", e.getCause());
                    } catch (TimeoutException e) {
                        LOG.log(Level.WARNING, "one broadcast future timeout", e);
                    }
                    if (response != null) {
                        if(response.getRecordNumber() == 0) {
                            status = "NORESULT";
                        } else {
                            status = "OK";
                        }
                        for(Result result : response.getResults()) {
                            String key = resultMap.get(result.getName());
                            if(key != null) {
                                List<Result> list = (List) model.get(key);
                                if(list == null) {
                                    list = new ArrayList<Result>();
                                    model.put(key, list);
                                }
                                list.add(result);
                            } else {
                                LOG.warning("Unmapped result: " + result.getName() + " from " + clients.get(i));
                            }
                        }
                    } else {
                        status = "TIMEOUT";
                        LOG.warning("Remote service '" + clients.get(i) + "' timed out for query '" + requests.get(i) + "'");
                    }
                }
                String serviceName = clients.get(i).getName();
                LOG.info("@@ANALYSIS@@ remote.service.status." + serviceName + "=" + status);
                if(req != null) {
                    req.setAttribute("web.remote.result." + serviceName, status);
                }
            }
        }

        /**
         * 获得某一个调用的Future
         * @param index
         * @return
         */
        public RemoteFuture getFuture(int index) {
            return futures.get(index);
        }

    }

    /**
     * 关闭Client
     */
    public void close() {
        synchronized (this) {
            for (RemoteClient client: clients) {
                client.close();
            }
        }
    }

}
