/**
 * @(#)HelloService.java, 2008-7-7. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.web.remote.demo;

import toolbox.simplenet.rpc.RPCServer;

/**
 * Demo程序的服务器端
 * @author ares
 *
 */
public class HelloService {
    
    public static void main(String[] args) throws Exception {
        HelloTaskHandler handler = new HelloTaskHandler();
        RPCServer server = new RPCServer(handler, 17911, 20, 50);
        server.start();
        server.join();
    }

}
