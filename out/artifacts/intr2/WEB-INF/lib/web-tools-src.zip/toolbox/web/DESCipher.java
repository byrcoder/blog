package toolbox.web;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


/**
 * A handy DES cipher for Strings using any String as the key
 * @author zhangkun
 *
 */
public class DESCipher {
	private javax.crypto.Cipher cipher;

	public DESCipher() throws NoSuchAlgorithmException, NoSuchPaddingException {
	    this.cipher = javax.crypto.Cipher.getInstance("DES");
	}

    /**
     * Convert a String to a valid DES key
     * @param key
     * @return
     * @throws UnsupportedEncodingException 
     */
    private byte[] getKey(String key) throws UnsupportedEncodingException {
        byte[] result = new byte[8];
        byte[] bytes = key.getBytes("UTF-8");
        for(int i = 0; i < bytes.length; i++) {
            result[i % 8] = bytes[i];
        }
        return result;
    }
	/**
	 * Encrypt
	 * @param key
	 * @param content
	 * @return
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	public synchronized String encrypt(String key, String content) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		try {
			SecretKey skey = new SecretKeySpec(getKey(key), "DES");
			cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, skey);
			byte[] bytes = cipher.doFinal(content.getBytes("UTF-8"));
			return Base64.encodeBytes(bytes, Base64.DONT_BREAK_LINES);
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
	/**
	 * Decrypt
	 * @param key
	 * @param content
	 * @return
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	public synchronized String decrypt(String key, String content) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		try {
			SecretKey skey = new SecretKeySpec(getKey(key), "DES");
			cipher.init(javax.crypto.Cipher.DECRYPT_MODE, skey);
			byte[] bytes = cipher.doFinal(Base64.decode(content));
			return new String(bytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
}
