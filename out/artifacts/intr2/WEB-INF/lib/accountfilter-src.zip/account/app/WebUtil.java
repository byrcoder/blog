/**
 * @(#)WebUtil.java, Nov 15, 2007. Copyright 2007 Yodao, Inc. All rights
 *                   reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to
 *                   license terms.
 */
package account.app;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import toolbox.misc.net.UrlUtils;
import toolbox.web.ViewUtils;

/**
 * @author phx
 */
public class WebUtil {

    public static final String TOOLBAR = "toolbar";
    public static final String YOUDAO_HOME = "http://www.youdao.com";
    public static final String SERVICE = "service";
    public static final String BACK_URL = "back_url";
    public static final String INCLUDE_URL = "iurl";
    public static final String TARGET_URL = "target_url";
    public static final String VIEWMODE = "view";
    public static final String OUTFOXER_NET = "outfoxer.net";
    public static final String USERNAME = "username";
    public static final String TOOLBAR_EMAIL = "emailforwad";
    public static final String PASSWORD = "password";
    public static final String YOUDAO_DOMAIN = "youdao.com";
    public static final String NETEASE_DOMAIN = "163.com";    
    public static final String ACCOUNT_HOME = "http://account.youdao.com";

    private static WebUtil singleton = new WebUtil();

    public static WebUtil getInstance() {
        return singleton;
    }

    public static boolean checkYoudaoDomain(String url) {
        return url != null
                && UrlUtils.getDomainFromUrl(url).equals(YOUDAO_DOMAIN);
    }

    /**
     * 将params中的key,value对添加到url之后
     * 
     * @param url
     * @param params
     *            key1, value1, ...., keyN, valueN. keyi cannot be null, valuei
     *            can be null
     * @return
     * @see #appendPara(String, String, String)
     */
    public static String appendParas(String url, String... params)
            throws UnsupportedEncodingException {
        if (params == null || params.length == 0 || params.length % 2 != 0) {
            throw new RuntimeException("Unexpected key value parameters");
        }

        StringBuilder builder = new StringBuilder();
        builder.append(url);
        for (int i = 0; i < params.length; i += 2) {
            String key = params[i];
            if (key == null) {
                throw new RuntimeException("Unexpected key value parameters");
            }
            String value = params[i + 1];

            builder.append((i == 0 && !url.contains("?")) ? "?" : "&");
            builder.append(key);

            if (value != null) {
                builder.append("=").append(URLEncoder.encode(value, "UTF-8"));
            }
        }

        return builder.toString();
    }

    public static String appendPara(String url, String name, String value)
            throws UnsupportedEncodingException {
        boolean firstPara = false;
        if (!url.contains("?")) {
            url += "?";
            firstPara = true;
        }

        if (!url.contains("&" + name + "=") && !url.contains("?" + name + "=")) {
            if (!firstPara)
                url += "&";
            url += name + "=" + URLEncoder.encode(value, "UTF-8");
        }

        return url;
    }

    public static String formatMobileUrl(String url) { 
        return ViewUtils.getHTMLValidText(url);
    }

    /**
     * 判断是不是来自outfoxer.net的测试请求
     * 
     * @param request
     * @param thisUrl
     * @param backUrl
     * @return
     */
    public static boolean isOutfoxerLogin(HttpServletRequest request,
            String thisUrl, String backUrl) {
        String referer = request.getHeader("Referer");
        return (referer != null && referer.contains(OUTFOXER_NET))
                || (thisUrl != null && thisUrl.contains(OUTFOXER_NET))
                || (backUrl != null && backUrl.contains(OUTFOXER_NET));
    }

    /**
     * 从request的Attribute中读取{@link CheckFilter.EMAIL_ATTR}, 读取成功返回Email,
     * 否则返回""
     * 
     * @param request
     * @return
     */
    public static String getUserName(HttpServletRequest request) {
        String useremail = "";
        if (request.getAttribute(CheckFilter.EMAIL_ATTR) != null) {
            useremail = (String) request.getAttribute(CheckFilter.EMAIL_ATTR);
        }
        return useremail;
    }

    public static boolean hasPara(HttpServletRequest request, String paraName) {
        return request.getParameter(paraName) != null
                && request.getParameter(paraName).length() != 0;
    }

    public static String getString(HttpServletRequest request, String name,
            String def) {
        String tmp = request.getParameter(name);
        if (tmp == null)
            return def;
        else {
            return tmp.trim();
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, String[]> getUnMutableParamMap(
            HttpServletRequest request) {
        return request.getParameterMap();
    }

    public static final String MIME_TYPE_XHTML_STRICT = "application/vnd.wap.xhtml+xml";
    public static final String MIME_TYPE_XHTML = "application/xhtml+xml";
    public static final String MIME_TYPE_HTML = "text/html";

    public static void processMimeType(HttpServletRequest request,
            HttpServletResponse response) {
        response.setCharacterEncoding("UTF-8");
        String acceptedHeader = request.getHeader("accept");
        if (acceptedHeader != null) {
            if (acceptedHeader.indexOf(MIME_TYPE_XHTML_STRICT) > -1) {
                response.setContentType(MIME_TYPE_XHTML_STRICT);
            } else if (acceptedHeader.indexOf(MIME_TYPE_XHTML) > -1) {
                response.setContentType(MIME_TYPE_XHTML);
            } else {
                response.setContentType(MIME_TYPE_HTML);
            }
        }
    }

}
