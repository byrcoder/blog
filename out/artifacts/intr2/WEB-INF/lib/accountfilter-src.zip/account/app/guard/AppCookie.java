package account.app.guard;

import java.util.Properties;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.misc.MD5;
import toolbox.misc.StringProperties;

/**
 * AppCookie defines the format of cookie stored in client for authentication.
 * @author river
 *
 */
public class AppCookie {
    private static final Logger LOG = LogFormatter.getLogger(AppCookie.class);
    
    private Properties properties = new Properties();

    private String value;

    private long timestamp = -1;

    private String token;
    
    public AppCookie() {
    }

    /**
     * Create cookie instance and call decode on given value.
     * @param value
     * @throws CookieFormatException
     */
    public AppCookie(String value) throws CookieFormatException {
        decode(value);
    }

    /**
     * Return the properties object to get/set application values.
     * @return
     */
    public Properties getProperties() {
        return properties;
    }

    /**
     * Return the timestamp attached to this cookie.
     * @return
     */
    public long getTimestamp() {
        return timestamp;
    }

    /**
     * Lock the cookie with given key. One hash token
     * will be calculated according to the key.
     * @param key
     */
    public void lock(String key) {
        assert key != null;
        timestamp = System.currentTimeMillis();
        value = StringProperties.encode(properties);
        token = MD5.digest(key + "," + value + "," + timestamp);
    }

    public void lock(String key, long timestamp) {
        this.timestamp = timestamp;
        value = StringProperties.encode(properties);
        token = MD5.digest(key + "," + value + "," + timestamp);
    }

    /**
     * Return the string to be set to client.
     * @param key
     * @return
     */
    public String encode() {
        if (value == null || timestamp < 0 || token == null) {
            throw new RuntimeException("call lock before encode");
        }
        return token + "|" + timestamp + "|" + value;
    }

    /**
     * Decode the cookie from value and with key.
     * @param key
     * @return
     */
    public void decode(String s) throws CookieFormatException {
        int pos = s.indexOf('|');
        if (pos <= 0)
            throw new CookieFormatException("cannot find token: " + s);

        token = s.substring(0, pos);

        int tpos = s.indexOf('|', pos + 1);
        if (tpos <= 0)
            throw new CookieFormatException("cannot find timestamp: " + s);

        String tmp = s.substring(pos + 1, tpos);
        try {
            timestamp = Long.parseLong(tmp);
        } catch (NumberFormatException e) {
            throw new CookieFormatException("timestamp format error: " + s, e);
        }

        value = s.substring(tpos + 1);
        properties = StringProperties.decode(value);
    }

    /**
     * Check the token with given key, and validate the timestamp with timeWindow.
     * @param key
     * @param timeWindow
     * @return
     */
    public boolean check(String key, long timeWindow) {
        assert value != null && token != null && key != null;
        long now = System.currentTimeMillis();
        if (timeWindow > 0 && Math.abs(timestamp - now) > timeWindow) {
            LOG.severe("check timeout : " + timestamp + " < " + now);
            return false;
        }

        String tmp = MD5.digest(key + "," + value + "," + timestamp);
        if (!tmp.equals(token)) {
            LOG.severe("token mismatch : " + tmp + " <> " + token);
            return false;
        }

        return true;
    }

}
