/**
 * @(#)CheckFilter.java, 2007-10-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package account.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.net.util.IPAddressUtil;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.web.CookieUtil;
import toolbox.web.FileResource;
import toolbox.web.HttpResource;
import toolbox.web.HttpResource.FileChangeListener;
import account.app.guard.AccountSupports;

import com.netease.urs.CookieNames;

/**
 * 用于检查登录cookie的合法性，并且在cookie不合法的时候转向到对应的login页面的filter.
 * 这个filter需要配置在只有登录以后的用户才可以访问的页面资源的前面.
 * 
 * 目前这个filter支持如下的配置:
 * <ul>
 * <li>(必须设置)encoding: 读取请求数据的encoding
 * <li>(必须设置)login_url: 登录请求发送到的页面，发送请求到login页面的时候，原始页面的url以及参数会被编码
 * 在back_url参数中发送.
 * <li>service: 发送登录请求的时候带的service参数，用于登录的时候显示对应的splash页面
 * <li>config: 指定一个规则的配置文件，这个地方可以是一个url地址，也可以是一个文件名（文件在WEB-INF目录下)
 * <li>local_copy: 如果config指定的是一个url地址，那么还需要指定一个local_copy，以便保存下载到本地的配置文件.
 * <li>account_supported:是否支持account帐号的登录
 * <li>no_login_allowd:是否允许匿名使用，主要用于搜索类产品
 * <li>allow_autologin:是否允许保存登录的用户登录，默认为允许
 * <li>max_savelogin_time:持久cookie过期时间，以秒为单位，默认为3个月
 * </ul>
 * 在config指定的规则文件中，允许配置如下的项:
 * <ul>
 * <li>allow_ip: 允许的ip段，格式为"x.x.x.x-x.x.x.x,x.x.x.x"，多个ip段用逗号隔开
 * <li>deny_ip: 禁止访问的ip段
 * <li>allow_user: 允许访问的用户，是一个用逗号隔开的正则表达式列表
 * <li>deny_user: 禁止访问的用户，是一个用逗号隔开的正则表达式列表
 * </ul>
 * 
 * 规则文件的修改会被监听（http的规则资源会每5分钟检查一次更新，本地文件的资源会每分钟检查一次更新）.
 * 
 * @author river
 */
public class CheckFilter implements Filter {
    public static final Logger LOG = LogFormatter.getLogger(CheckFilter.class);
    
    /*
     * 参数名字常量定义.
     */
    public static final String NAME_ALLOW_USER = "allow_user";
    public static final String NAME_DENY_USER = "deny_user";
    
    public static final String NAME_ALLOW_IP = "allow_ip";
    public static final String NANE_DENY_IP = "deny_ip";
    
    public static final String NAME_ENCODING = "encoding";
    public static final String NAME_LOGIN_URL = "login_url";
    public static final String NAME_SERVICE = "service";
    public static final String NAME_ACCOUNT_SUPPORTED = "account_supported";
    public static final String NAME_CONFIG = "config";
    public static final String NAME_LOCAL_COPY = "local_copy";
    public static final String NAME_NO_LOGIN_ALLOWED = "no_login_allowd";
    public static final String NAME_AUTO_LOGIN_ALLOWED = "auto_login_allowd";
    public static final String NAME_TRIAL_LOGIN_ALLOWED = "trial_login_allowd";
    public static final String NAME_MAX_SAVE_LOGIN_TIMEE = "max_savelogin_time";
    public static final String NAME_BACKEND_RELOGIN = "backend_relogin";
    public static final String NAME_BACKEND_RELOGIN_DOMAIN = "backend_relogin_domain";
    public static final String NAME_RELOGIN_SERVICE_URL = "relogin_service_url";
    public static final String NAME_PREVIEW_LOGIN = "preview_login";
    public static final String NAME_PREVIEW_ERROR_PAGE = "preview_error_page";
    public static final String ALLOW_GROUPS = "allow_groups";
    public static final String NAME_LOGINED_COOKIE = "logined_cookie_allowed";
    public static final String NAME_LOGINED_COOKIE_DOMAIN = "logined_cookie_domain";
    
    //写到attribute中的常量
    public static final String AUTHCOOKIE_ATTR = "__authcookie__";
    public static final String EMAIL_ATTR = "__email__";
    public static final String TRIAL_ATTR = "__trialId__";
    public static final String COOKIEVALUE_ATTR = "__cookievalue__";
    public static final String CHECKFILTER_ATTR = "__checkfiltered__";
    public static final String MOBILE_ATTR = "__mobile__";
    public static final String CREATE_TIME_ATTR = "__create_time__";
    public static final String WHITE_IP = "white_ip";
    public static final String WHITE_USER = "white_user";
    public static final String PREVIEW_MOD = "__preview_mod__";
    
    public static final String YOUDAO_COM_DOMAIN = ".youdao.com";
    
    public static final int ONE_YEAR = 3600 * 24 * 365 * 1;
    /** 在Cookie中，表明当前用户是否登录 */
    public static final String NTES_LOGINED = "NTES_LOGINED";
    //内置的group
    private static final int GROUP_INTERNAL = 1;

    private static final int GROUP_ADMIN = 0;

    public static final String RELOGIN = "relogin";

    private List<int[]> deniedIps = new ArrayList<int[]>();

    private List<int[]> allowedIps = new ArrayList<int[]>();

    @SuppressWarnings("unused")
    private List<Pattern> deniedUsers = new ArrayList<Pattern>();

    private List<Pattern> allowedUsers = new ArrayList<Pattern>();

    private ArrayList<Integer> allowGroups = new ArrayList<Integer>();

    private String encoding = null;

    private String loginUrl = null;

    private String service = null;
    
    private String reloginServiceUrl = null;
    
    private boolean accountSupported = false;
  
    private boolean noLoginAllowed = false;

    /** 单位: 秒, 默认为: 30天 */
    private long maxSaveloginTime = UnitUtils.DAY_SEC * 30;
    
    private boolean autoLoginAllowed = true;
    
    private boolean trialLoginAllowed = true;
    
    private boolean backendRelogin = false;
    
    private boolean previewLogin = false;
    
    private String backendReloginDomain = null;
    
    private boolean loginedCookie = false;
    //  默认为youdao.com, 最好与host关联
    private String loginedCookieDomain = ".youdao.com"; 
    
    private BackendReloginClient backendReloginClient;
    
    private TrialLoginHandler trialLoginHandler;

    private String previewErrorPage = null;
    
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, 
            FilterChain chain) throws IOException, ServletException {
        
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        request.setAttribute(CHECKFILTER_ATTR, true);
        

        /*
         * Check ip address.在白名单就默认允许访问，在黑名单则都不允许访问
         */ 
        boolean allowed = false;
        String remoteIp = request.getRemoteAddr();
        if (checkIp(remoteIp, allowedIps)) {
            allowed = true;
        } else if (checkIp(remoteIp, deniedIps)) {
            // Deny the request in deny-ip list
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        
        String email = null;
        String cookieName = null;
        String cookieValue = null;
        String mobile = null;
        String createTime = null;
                
        //是否支持内部认证
        if(accountSupported) {
            //以下是内部帐号认证，即xx@rd.netease.com的认证
            String[] results = AccountEmailUtils.getAccountEmail(request);
            assert results != null && results.length == 2;
            email = results[0];
            if (email != null && !checkGroup(response, results[1])) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }

            cookieName = AccountSupports.ACCOUNT_COOKIE_NAME;
            cookieValue = "";
            if (email != null)
                allowed = true;
        } else {
            // 以下是urs帐号认证，即xx@163.com, xx@yeah.net, xx@126.com等帐号的认证
            String[] results = AccountEmailUtils.getURSEmail(request,
                    (maxSaveloginTime > 0 ? maxSaveloginTime : Integer.MAX_VALUE),
                    autoLoginAllowed);
            assert results != null && results.length == 4;
            email = results[0];
            cookieName = results[1];
            cookieValue = results[2];
            mobile = results[3];
            createTime = results[4];
            
            if (email != null) {
                if (cookieName.equals(CookieNames.NTES_SESS)) {
                    // ntes_sess cookie说明用户验证通过. ntes_passort
                    // cookie只说明用户可能是登录过的，需要到urs进行cookie置换
                    allowed = true;
                } else if (backendRelogin) {
                    // relogin with service, 后台Cookie置换
                    cookieValue = backendReloginClient.reloginWithService(
                            email, request.getRemoteAddr(), cookieValue);
                    
                    allowed = cookieValue != null;
                    
                    if (allowed) {
                        // maxAge=-1，表示该cookie只存在于内存中，关闭浏览器即清除，下次登录时需要再次去urs置换。
                        String domain = backendReloginDomain == null ?  YOUDAO_COM_DOMAIN : backendReloginDomain;
                        if (backendReloginDomain == null)
                        CookieUtil.addCookie(response, CookieNames.NTES_SESS,
                                cookieValue, domain, null, -1);
                    }
                }
            }
            
            // 检查是否存在试用登录
            if (trialLoginHandler != null) {
                allowed = trialLoginHandler.checkTrialLogin(request, response,
                        allowed, email);
            }
        }
        
          

        /*
         * Check the user.
         */
        if (previewLogin) {
            if (checkIp(remoteIp, allowedIps)) {
                request.setAttribute(PREVIEW_MOD, WHITE_IP);
            } else if (checkUser(email, allowedUsers)) {
                request.setAttribute(PREVIEW_MOD, WHITE_USER);
            } else {
                LOG.info("preview login: not allowed user, " + email);
                // 内测模式，只允许白名单上的用户访问
                allowed = false;
                if (previewErrorPage != null) {
                    response.sendRedirect(previewErrorPage);
                } else {
                    response.sendError(HttpServletResponse.SC_FORBIDDEN);
                }
                return;
            }
        } 
        
        
        if (email != null) {
            // 认证后用户的email
            request.setAttribute(EMAIL_ATTR, email);                             
        } 
        
        {
            Cookie cookie = CookieUtil.findCookie(request, NTES_LOGINED);                                   
            if (loginedCookie) {                
                // 如果登录，并且cookie不在有效期内(null, false, maxAge), 则重写Cookie
                if (email != null 
                        && (cookie == null 
                                || !"true".equals(cookie.getValue()) 
                                || cookie.getMaxAge() < 7200)) {                
                    CookieUtil.addCookie(response, NTES_LOGINED, "true", loginedCookieDomain, "/", ONE_YEAR);                    
                } else if (email == null && cookie != null){
                    // 没有登录，并且cookie存在, 则清除Cookie
                    CookieUtil.addCookie(response, NTES_LOGINED, "", loginedCookieDomain, "/", 0);
                }
            } else {
                // 如果没有登录需求，则清楚该COOKIE
                if (cookie != null) {
                    CookieUtil.addCookie(response, NTES_LOGINED, "", loginedCookieDomain, "/", 0);
                }
            }
        }
        
        if (cookieName != null) {
            //通过认证的cookie名
            request.setAttribute(AUTHCOOKIE_ATTR, cookieName);
        }
        if (cookieValue != null) {
            //通过认证的cookie值
            request.setAttribute(COOKIEVALUE_ATTR, cookieValue);
        }
        
        if (mobile != null) {
            //用户手机号
            request.setAttribute(MOBILE_ATTR, mobile);
        }
        if (createTime != null) {
            request.setAttribute(CREATE_TIME_ATTR, createTime);
        }

        if (allowed || noLoginAllowed) {
            //访问允许
            chain.doFilter(request, response);
        } else {
            //需要登录或者置换cookie
            String login = getRedirectLoginUrl(request, cookieName);          
            response.sendRedirect(login);
        }
    }

    private boolean checkGroup(HttpServletResponse response, String groupStr)
            throws IOException {
        int group = Integer.parseInt(groupStr);
        if (allowGroups.size() > 0) {
            if (!allowGroups.contains(group)) {
                LOG.warning("not in allowed group, groud id = " + group);
                return false;
            }
        } else {
            if (group != GROUP_ADMIN && group != GROUP_INTERNAL) {
                LOG.warning("not in default group, groud id = " + group);
                return false;
            }
        }
        return true;
    }

    private String getRedirectLoginUrl(HttpServletRequest request,
            String cookieName) throws UnsupportedEncodingException, IOException {
        
         // Set the encoding of request. Encoding must be set when the
         // request is firstly used        
        if (encoding != null) {
            request.setCharacterEncoding(encoding);
        }

        // Redirect to the login page.
        String backUrl = getBackUrl(request, encoding);
        String referer = request.getHeader("Referer");
        if (referer != null) {
            backUrl = WebUtil.appendPara(backUrl, "oreferer", referer);
        }
        
        StringBuilder login = new StringBuilder();
        
        login.append(loginUrl)
            .append(loginUrl.indexOf('?') > 0 ? "&" : "?")
            .append("back_url=").append(URLEncoder.encode(backUrl, encoding));
        
        if (service != null) {
            login.append("&service=").append(service);
        }

        // 如果有Persistent Cookie, 则需要置换以得到(NTES_SESS)
        if (CookieNames.NTES_PASSPORT.equals(cookieName)) {
            login.append("&").append(RELOGIN).append("=1");
            LOG.info("save login, redirect to get inmemory cookie: " + login);
        } else {
            LOG.info("not login, redirect to " + login);
        }
        return login.toString();
    }
    




    /**
     * Load ip and user rule from configuration.
     * @param configFile
     * @throws IOException
     */
    private void loadConfig(File configFile) throws IOException {
        LOG.info("loading config from " + configFile.getAbsolutePath());
        Properties properties = new Properties();
        FileInputStream fis = new FileInputStream(configFile);
        try {
            properties.load(fis);
        } finally {
            fis.close();
        }

        String tmp = properties.getProperty(NAME_ALLOW_USER);
        ArrayList<Pattern> newAllowedUsers = new ArrayList<Pattern>();
        if (tmp != null && tmp.length() > 0) {
            makePatternList(newAllowedUsers, tmp.toLowerCase());
            LOG.info(newAllowedUsers.size() + " allowed users loaded");
        }

        tmp = properties.getProperty(NAME_DENY_USER);
        ArrayList<Pattern> newDeniedUsers = new ArrayList<Pattern>();
        if (tmp != null && tmp.length() > 0) {
            makePatternList(newDeniedUsers, tmp.toLowerCase());
            LOG.info(newDeniedUsers.size() + " denied users loaded");            
        }

        tmp = properties.getProperty(NAME_ALLOW_IP);
        ArrayList<int[]> newAllowedIps = new ArrayList<int[]>();
        if (tmp != null && tmp.length() > 0) {
            makeIpSegmentList(newAllowedIps, tmp);
            LOG.info(newAllowedIps.size() + " allowed ips loaded");
        }

        tmp = properties.getProperty(NANE_DENY_IP);
        ArrayList<int[]> newDeniedIps = new ArrayList<int[]>();
        if (tmp != null && tmp.length() > 0) {
            makeIpSegmentList(newDeniedIps, tmp);
            LOG.info(newDeniedIps.size() + " denied ips loaded");
        }

        ArrayList<Integer> newAllowGroups = new ArrayList<Integer>();
        tmp = properties.getProperty(ALLOW_GROUPS);
        if (tmp != null) {
            String[] parts = tmp.split("[,\\s]+");
            for (String p: parts) {
                newAllowGroups.add(Integer.parseInt(p));
            }
            LOG.info(newAllowGroups.size() + " allowed groups loaded");
        }

        allowedUsers = newAllowedUsers;
        deniedUsers = newDeniedUsers;
        allowedIps = newAllowedIps;
        deniedIps = newDeniedIps;
        allowGroups = newAllowGroups;
        LOG.info("config loaded from" + configFile.getAbsolutePath());
    }
    
    @Override
    public void init(FilterConfig config) throws ServletException {
        // case native.home == null. Init the native lib home.        
        String nativeHome = System.getProperty("native.home");
        if (nativeHome == null) {
            nativeHome = config.getServletContext().getRealPath("WEB-INF");
            System.setProperty("native.home", nativeHome);
        }
        
        readParas(config);
        initConfigFile(config);
        
        if(this.backendRelogin) {
            backendReloginClient = new BackendReloginClient(reloginServiceUrl);
            backendReloginClient.init();
        }
        
        if(this.trialLoginAllowed) {
            trialLoginHandler = new TrialLoginHandler();
        }
        

        LOG.info("Account Check Filter Initilized: ");
        LOG.info("loginUrl = " + loginUrl);
        LOG.info("encoding = " + encoding);
        LOG.info("server = " + service);
        LOG.info("noLoginAllowed = " + noLoginAllowed);
        LOG.info("accountSupported = " + accountSupported);
        LOG.info("autoLoginAllowed = " + autoLoginAllowed);
        LOG.info("trialLoginAllowed = " + trialLoginAllowed);
        LOG.info("maxSaveloginTime = " + maxSaveloginTime);
        LOG.info("backendRelogin = " + backendRelogin);
        LOG.info("previewLogin = " + previewLogin);
        LOG.info("previewErrorPage = " + previewErrorPage);
    }

    private void initConfigFile(FilterConfig config) throws ServletException {
        String configPath = config.getInitParameter(NAME_CONFIG);
        if (configPath != null && configPath.length() > 0) {
            FileChangeListener listener = new FileChangeListener() {
                @Override
                public void onFileChange(File file) {
                    try {
                        loadConfig(file);
                    } catch (IOException e) {
                        LOG.log(Level.SEVERE,
                                "load configuration from local file " + file
                                        + " failed");
                    }
                }
            };

            if (configPath.indexOf(':') > 0) {
                // this could be one url
                String localPath = config.getInitParameter(NAME_LOCAL_COPY);
                File localCopy;
                if (localPath == null || localPath.length() == 0) {
                    try {
                        localCopy = File.createTempFile(
                                "/tmp/check-filter-config", "properties");
                    } catch (IOException e) {
                        throw new ServletException("create temp file failed", e);
                    }
                } else {
                    localCopy = new File(localPath);
                }
                HttpResource resource = new HttpResource(configPath, localCopy,
                        UnitUtils.MINUTE * 5);
                resource.registerListener(listener);
            } else {
                FileResource resource = new FileResource(new File(configPath), UnitUtils.MINUTE);
                resource.registerListener(listener);
            }
        }
    }

    private void readParas(FilterConfig config) throws ServletException {
        encoding = config.getInitParameter(NAME_ENCODING);
        loginUrl = config.getInitParameter(NAME_LOGIN_URL);
        service = config.getInitParameter(NAME_SERVICE);

        if (loginUrl == null || encoding == null || loginUrl.length() == 0
                || encoding.length() == 0) {
            throw new ServletException(NAME_LOGIN_URL + " and " + NAME_ENCODING
                    + " must be set in filter configuration");
        }

        String tmp = config.getInitParameter(NAME_ACCOUNT_SUPPORTED);
        if (tmp != null) {
            accountSupported = Boolean.parseBoolean(tmp);
        }
        
        tmp = config.getInitParameter(NAME_BACKEND_RELOGIN_DOMAIN);
        if (tmp != null) {
            backendReloginDomain = tmp;
        }
        

        
        tmp = config.getInitParameter(NAME_NO_LOGIN_ALLOWED);
        if (tmp != null) {
            noLoginAllowed = Boolean.parseBoolean(tmp);            
        }

        tmp = config.getInitParameter(NAME_LOGINED_COOKIE);
        if (tmp != null) {
            loginedCookie = Boolean.parseBoolean(tmp);
            
            tmp = config.getInitParameter(NAME_LOGINED_COOKIE_DOMAIN);
            if (tmp != null) {
                loginedCookieDomain = tmp;
            }
        }
        tmp = config.getInitParameter(NAME_MAX_SAVE_LOGIN_TIMEE);
        if (tmp != null) {
            maxSaveloginTime = Long.parseLong(tmp);
        }

        tmp = config.getInitParameter(NAME_AUTO_LOGIN_ALLOWED);
        if (tmp != null) {
            autoLoginAllowed = Boolean.parseBoolean(tmp);
        }

        tmp = config.getInitParameter(NAME_TRIAL_LOGIN_ALLOWED);
        if (tmp != null) {
            trialLoginAllowed = Boolean.parseBoolean(tmp);
        }
        
        tmp = config.getInitParameter(NAME_BACKEND_RELOGIN);
        if (tmp != null) {
            backendRelogin = Boolean.parseBoolean(tmp);
        }
        
        tmp = config.getInitParameter(NAME_RELOGIN_SERVICE_URL);
        if (tmp != null && tmp.length() > 0) {
            reloginServiceUrl = tmp;
        }
        
        tmp = config.getInitParameter(NAME_PREVIEW_LOGIN);
        if (tmp != null) {
            previewLogin  = Boolean.parseBoolean(tmp);
        }
        
        tmp = config.getInitParameter(NAME_PREVIEW_ERROR_PAGE);
        if (tmp != null && tmp.length() > 0) {
            previewErrorPage = tmp;
        }
    }
    
    public void destroy() {
    }

    /**
     * Create one pattern list.
     * @param list
     * @param s
     */
    private void makePatternList(List<Pattern> list, String s) {
        String [] parts = s.split(",");
        for (String part : parts) {
            try {
                list.add(Pattern.compile(part.trim()));    
            }
            catch(Exception e) {
                LOG.warning("wrong pattern: " + part);
                e.printStackTrace();
            }
            
        }
    }

    /**
     * Create ip segment list.
     * @param list
     * @param s
     */
    private void makeIpSegmentList(List<int[]> list, String s) {
        try {
            String[] parts = s.split(",");
            for (String part: parts) {
                int[] ips = new int[2];
                int pos = part.indexOf('-');
                if (pos > 0) {
                    ips[0] = parseIp(part.substring(0, pos).trim());
                    ips[1] = parseIp(part.substring(pos + 1).trim());
                } else {
                    ips[0] = parseIp(part.trim());
                    ips[1] = ips[0];
                }
                list.add(ips);
            }
        } catch (Exception e) {
            LOG.warning("parse ip segment error: " + s);
            e.printStackTrace();
        }
    }
    
    /**
     * Parse the string format ip into int.
     * 
     * @param ip
     * @return
     */
    private int parseIp(String ip) {
        byte[] bs = IPAddressUtil.textToNumericFormatV4(ip);
        return (((int) bs[0] & 0xFF) << 24) | (((int) bs[1] & 0xFF) << 16)
                | (((int) bs[2] & 0xFF) << 8) | ((int) bs[3] & 0xFF);
    }
    
    /**
     * Check if the given ip in the iplist.
     * @param ipString
     * @param ipsList
     * @return
     */
    private boolean checkIp(String ipString, List<int[]> ipsList) {
        if (ipsList.isEmpty()) return false;
        
        int ip = parseIp(ipString);
        for (int [] ips : ipsList) {
            if (ip>=ips[0] && ip<=ips[1] ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if the email in the patterns.
     * @param email
     * @param patterns
     * @return
     */
    private boolean checkUser(String email, List<Pattern> patterns) {
        if (patterns.isEmpty()) return false;
        if (email == null) return false;
        
        for (Pattern pattern : patterns) {
            if (pattern.matcher(email.toLowerCase()).matches()) {
                return true;
            }
        }
        
        return false;
    }
    
    public static String getBackUrl(HttpServletRequest request,
            String encoding) throws IOException {
        return getBackUrl(request, encoding, null);
    }

    /**
     * Return the back url by encoding all the params in url.
     * @param request
     * @return
     * @throws IOException
     */
    public static String getBackUrl(HttpServletRequest request,
            String encoding, String[] filterParas) throws IOException {
        
        Set<String> filterParaSet = new HashSet<String>();
        if(filterParas != null) {
            filterParaSet.addAll(Arrays.asList(filterParas));
        }
        StringBuilder urlBuffer = new StringBuilder();
        urlBuffer.append(request.getRequestURL());
        
        boolean first = true;
        String paramValueEncoding = (encoding == null) ? "UTF-8" : encoding;
        
        Map<String, String[]> paramsMap = WebUtil.getUnMutableParamMap(request);
        for (String key : paramsMap.keySet()) {
            
            if (key.equals(AccountSupports.TOKEN_PARAM_NAME)) {
                continue;
            }

            if (filterParaSet.contains(key)) {
                continue;
            }
            
            String [] values = request.getParameterValues(key);
            for (String value : values) {
                if (first) {
                    urlBuffer.append('?');
                    first = false;
                } else {
                    urlBuffer.append('&');
                }
                urlBuffer.append(URLEncoder.encode(key, paramValueEncoding)).append('=').append(
                        URLEncoder.encode(value, paramValueEncoding));
            }
        }
        return urlBuffer.toString();
    }

}
