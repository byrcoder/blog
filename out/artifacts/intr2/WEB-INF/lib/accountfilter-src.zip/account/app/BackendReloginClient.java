/**
 * @(#)BackendLoginClient.java, 2009-1-21. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package account.app;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;

import toolbox.misc.LogFormatter;

/**
 *
 * 用于后台认证urs的cookie
 * @author phx
 *
 */
public class BackendReloginClient {
    public static final Logger LOG = LogFormatter.getLogger(BackendReloginClient.class);
    
    private static final int MAX_CONNECTION = 100;

    private static final int CONNECTION_TIMEOUT = 500;

    private static final int SOCKET_TIMEOUT = 500;

    private static final int MAX_CONTENT_SIZE = 2 * 1024 * 1024;
    
    private static final int MAX_CONNECTION_PER_IP = 100;
    
    private static final String COOKIE_STR = "cookie=";
    
    private HttpClient backendLoginClient;

    private MultiThreadedHttpConnectionManager connectionManager;
    
    private String reloginServiceUrl;
    

    /**
     * @return sesscookie, if relogin with service successed
     */
    public String reloginWithService(String userName, String userIp,
            String persistCookie) {
        String reloginUrl = reloginServiceUrl;
        try {
            reloginUrl = WebUtil.appendPara(reloginUrl, "username", userName);
            reloginUrl = WebUtil.appendPara(reloginUrl, "product", "search");
            reloginUrl = WebUtil.appendPara(reloginUrl, "userip", userIp);
            reloginUrl = WebUtil.appendPara(reloginUrl, "persistCookie",
                    persistCookie);
        } catch (UnsupportedEncodingException e) {
            return null;
        }
        LOG.info("relogin with service url " + reloginUrl);
        GetMethod method = new GetMethod(reloginUrl);
        method.setFollowRedirects(true);
        int code;
        try {
            code = backendLoginClient.executeMethod(method);
            if (code == HttpServletResponse.SC_OK) {
                String result = method.getResponseBodyAsString();
                LOG.info("relogin result: " + result);
                String resultCookie = parseCookie(result);
                if(resultCookie == null) {
                    LOG.warning("invalid persistCookie: username=" + userName
                            + ", pcookie=" + persistCookie);
                }
                return resultCookie;
            }
            LOG.warning("relogin with service failed. code=" + code);
            return null;
        } catch (HttpException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            method.releaseConnection();
        }
    }

    private String parseCookie(String result) {
        int index = result.indexOf(COOKIE_STR);
        int index1 = result.indexOf("&domain=");
        if(index > 0 && index1 > 0 && index1 > index + COOKIE_STR.length()) {
            return result.substring(index + COOKIE_STR.length(), index1);
        }
        return null;
    }
    
    public BackendReloginClient(String reloginServiceUrl) {
        this.reloginServiceUrl = reloginServiceUrl;
    }
    
    public void init() {
        connectionManager = new MultiThreadedHttpConnectionManager();
        connectionManager.getParams().setMaxTotalConnections(MAX_CONNECTION);
        connectionManager.getParams().setConnectionTimeout(
                CONNECTION_TIMEOUT * 3);
        connectionManager.getParams().setSoTimeout(SOCKET_TIMEOUT);
        connectionManager.getParams().setSendBufferSize(MAX_CONTENT_SIZE);
        connectionManager.getParams().setReceiveBufferSize(MAX_CONTENT_SIZE);
        connectionManager.getParams().setDefaultMaxConnectionsPerHost(MAX_CONNECTION_PER_IP);

        backendLoginClient = new HttpClient(connectionManager);
    }

}
