/**
 * @(#)AccountSupports.java, 2007-10-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package account.app.guard;

/**
 * Some support for account.
 * @author river
 */
public class AccountSupports {

    /**
     * Cookie name of account.
     */
    public static final String ACCOUNT_COOKIE_NAME = "__guard_cookie__";
    
    public static final String TRIAL_COOKIE_NAME = "YODAO_TRIAL_ID";
    
    /**
     * Param name used in token.
     */
    public static final String TOKEN_PARAM_NAME = "_at_";
    
    private static final String ACCOUNT_SECRET = "T0psecr7tforAccont.project";

    /**
     * Get the secret of account.
     * @return
     */
    public static String getAccountSecret() {
        return ACCOUNT_SECRET;
    }
    
}
