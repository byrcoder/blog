/**
 * @(#)TrialLoginHandler.java, 2009-1-21. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package account.app;

import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import toolbox.misc.LogFormatter;
import toolbox.web.CookieUtil;
import account.app.guard.AccountSupports;

/**
 * 用于处理试用用户登录相关的工作
 * @author phx
 *
 */
public class TrialLoginHandler {
    public static final Logger LOG = LogFormatter
            .getLogger(TrialLoginHandler.class);

    public boolean checkTrialLogin(HttpServletRequest request,
            HttpServletResponse response, boolean allowed, String email) {
        String trialId = getTrialId(request);
        if (trialId != null) {
            allowed = true;
            request.setAttribute(CheckFilter.TRIAL_ATTR, trialId);
        }

        if (email != null && trialId != null) {
            // 如果同时存在email和trialId，则应该把trialId清除
            removeTrialCookie(response);
        }

        return allowed;
    }

    /**
     * 清除trialId
     * 
     * @param request
     * @param response
     */
    private void removeTrialCookie(HttpServletResponse response) {
        try {
            LOG.info("remove trial cookie");
            CookieUtil.deleteCookie(response,
                    AccountSupports.TRIAL_COOKIE_NAME,
                    CheckFilter.YOUDAO_COM_DOMAIN, null);
        } catch (ServletException e) {
            LOG.warning("remove trial cookie failed");
            e.printStackTrace();
        }

    }

    /**
     * 取出trial cookie
     * @param request
     * @return
     */
    private String getTrialId(HttpServletRequest request) {
        Cookie cookie = CookieUtil.findCookie(request,
                AccountSupports.TRIAL_COOKIE_NAME);
        if (cookie != null) {
            return cookie.getValue();
        } else
            return null;
    }
}
