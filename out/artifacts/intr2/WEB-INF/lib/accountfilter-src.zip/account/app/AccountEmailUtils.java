/**
 * @(#)EmailUtils.java, 2009-1-21. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package account.app;

import static com.netease.urs.CookieNames.NTES_PASSPORT;
import static com.netease.urs.CookieNames.NTES_SESS;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.web.CookieUtil;
import account.app.guard.AccountSupports;
import account.app.guard.AppCookie;
import account.app.guard.CookieFormatException;

import com.netease.urs.CookieValidator;

/**
 *
 * @author phx
 *
 */
public class AccountEmailUtils {
    public static final Logger LOG = LogFormatter.getLogger(AccountEmailUtils.class);
    
    public static String[] getAccountEmail(HttpServletRequest request) {
        Cookie accountCookie = CookieUtil
                .findCookie(request, AccountSupports.ACCOUNT_COOKIE_NAME);
        String email = null;
        String group = null;
        if (accountCookie != null) {
            AppCookie appCookie = new AppCookie();
            try {
                appCookie.decode(accountCookie.getValue());
                if (appCookie.check(AccountSupports.getAccountSecret(), 0)) {
                    email = appCookie.getProperties().getProperty("email");
                    group = appCookie.getProperties().getProperty("group");
                } else {
                    LOG.warning("not valid account cookie");
                }
            } catch (CookieFormatException e) {
                LOG.log(Level.WARNING, "bad cookie format", e);
            }
        }
        return new String[] {email, group};
    }

    public static String[] getURSEmail(HttpServletRequest request) {
        return getURSEmail(request, -1, true);
    }

    /**
     * 
     * 返回的结果格式如下: &lt;email, cookieName, cookieValue, mobile, createTime &gt; 
     * 
     * 如果是有效的登录Cookie, 则email非空， 
     * 并且返回的cookieName, cookieValue表示email是从哪个Cookie获取到的
     * 返回的createTime在其他字段有效的时候才有效, 需要把它从字符串转换成为整数
     * 
     * @param request
     * @param maxSaveloginTime 单位: 秒
     * @param autoLoginAllowed
     * @return
     */
    public static String[] getURSEmail(HttpServletRequest request,
            long maxSaveloginTime, boolean autoLoginAllowed) {
        String email = null;
        String cookieName = null;
        String cookieValue = null;
        String mobile = "";
        String createTime = null;
        
        // 首先检查Session Cookie 
        Cookie inMemoryCookie = CookieUtil.findCookie(request, NTES_SESS);
        if (inMemoryCookie != null) {
            CookieValidator validator = new CookieValidator();
            // 验证Session Cookie是否是7天内生成的
            if (validator.validateInMemoryCookie(inMemoryCookie.getValue(),
                    UnitUtils.DAY_SEC * 7, false)) {
                
                // 判断是否允许autologin
                if (!validator.isAutoLogin() || autoLoginAllowed) {
                    mobile = validator.getMobile();
                    email = validator.getEmail();
                    cookieName = NTES_SESS;
                    cookieValue = inMemoryCookie.getValue();
                    createTime = validator.getCreateTime() + "";
                } else {
                    LOG.warning("auto login not allowed: "
                            + validator.getEmail() + "="
                            + inMemoryCookie.getValue() + ",");
                }
                
            } else {
                LOG.warning("not valid cookie: " + NTES_SESS + "="
                        + inMemoryCookie.getValue());
            }
        }

        // 如果sess cookie已经失效，还需要再看一下是否有persistent cookie，如果有的话应该重新进行置换
        if (email == null && autoLoginAllowed) {
            Cookie persistentCookie = CookieUtil.findCookie(request, NTES_PASSPORT);
            if (persistentCookie != null) {
                CookieValidator validator = new CookieValidator();
                // 如果persistent cookie无效，或者超过了有效期
                if (validator.validatePersistentCookie(persistentCookie.getValue(), 
                        maxSaveloginTime, false)) {
                    mobile = validator.getMobile();
                    email = validator.getEmail();
                    cookieName = NTES_PASSPORT;
                    cookieValue = persistentCookie.getValue();
                    createTime = validator.getCreateTime() + "";
                } else {
                    LOG.warning("not valid cookie: " + NTES_PASSPORT + "=" + persistentCookie.getValue());
                }
            }
        }

        return new String[] {
            email, cookieName, cookieValue, mobile, createTime
        };
    }
}
