package account.app.guard;

public class CookieFormatException extends Exception {

    private static final long serialVersionUID = -7244569264322106292L;

    public CookieFormatException() {
    }

    public CookieFormatException(String message) {
        super(message);
    }

    public CookieFormatException(String message, Throwable cause) {
        super(message, cause);
    }
}
