/**
 * @(#)EmailerTest.java, 2012-9-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.maintain.alarm;

import static org.junit.Assert.*;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.junit.Test;

/**
 *
 * @author youdao
 *
 */
public class EmailerTest {

    /**
     * Test method for {@link toolbox.maintain.alarm.Emailer#sendEmail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String[])}.
     */
    @Test
    public void testSendEmail() {
        Emailer emailer = new Emailer();
        String content = "att";
        assertEquals(emailer.sendEmail("postmaster@rd.netease.com",
                                       "jilp@rd.netease.com",
                                       "Testing 1-2-3", content, 
                                       new String[] {"./conf/mail.conf"}),
                    true);
    }

    /**
     * Test method for {@link toolbox.maintain.alarm.Emailer#getMailServerConfig()}.
     */
    @Test
    public void testGetMailServerConfig() {
        try {
            System.out.println(InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

}
