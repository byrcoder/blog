package toolbox.maintain.ace;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.maintain.shared.TimeSequenceHashMap;


/**
 * 一个用于处理ACEConfigurationSection的类。功能包括读写ACEConfiguration，使用大概如下<br>
 * <code>
 ACEConfigurationEditor editor = new ACEConfigurationEditor();
 ACEConfigurationSection section = new ACEConfigurationSection("mainSection");
 section.addStringValue("port", "10125");
 section.addLongValue("sub_indx", 0);
 editor.addSection(section);
 editor.write("filename"); //写入文件
 * </code>
 * 如果是从文件中读取出来，那么可以使用下面的方法：<br>
 * editor.loadConfiguratoin(file);
 * 
 * @see ACEConfigurationSection
 * @author neat
 */
public class ACEConfigurationEditor {

    private TimeSequenceHashMap<String, ACEConfigurationSection> name2section = 
        new TimeSequenceHashMap<String, ACEConfigurationSection>();

    public TimeSequenceHashMap<String, ACEConfigurationSection> getName2Section() {
        return name2section;
    }

    public void addSection(ACEConfigurationSection section) {
        if (!name2section.containsKey(section.getSectionName())) {
            name2section.put(section.getSectionName(), section);
        }
    }

    public void addSubSection(String parentName, ACEConfigurationSection section) {
        if (!name2section.containsKey(parentName)) {
            //FIXME: now we create parent section auto.
//            throw new RuntimeException("We dont have a parent section called " 
//                    + parentName);
            name2section.put(parentName, new ACEConfigurationSection(parentName));
        } 
        name2section.get(parentName).addSubSection(section);
        section.setParentSectionName(parentName);
    }

    public ACEConfigurationSection getSection(String sectionName) {
        return name2section.get(sectionName);
    }

    public void write2File(File file) throws IOException {
        FileWriter writer = null;
        try {
            writer = new FileWriter(file, false); // create a new file
            writer.write(this.toString());
        } catch (Exception e) {} finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    public String toString() {
        String _2str = "";
        for (String section: name2section.sequenceKeySet()) {
            _2str += name2section.get(section).toString() + "\n\n";
        }
        return _2str;
    }

    public void loadConfiguration(File file) throws IOException {
        if (!file.exists()) {
            throw new IOException("file " + file.getAbsolutePath() + " not exist!!!");
        }
        name2section.clear();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String line = null;
            ACEConfigurationSection section = null;
            while ((line = reader.readLine()) != null) {
                String regex= "\".*?\"=dword:[a-fA-F0-9]*|\".*?\"=\".*?\"|^\\[.*?]$";
                Pattern pt = Pattern.compile(regex);
                Matcher mt = pt.matcher(line); 
                    
                if (mt.find()) {
               //   System.out.println(mt.group());
                   line = mt.group();
                }
                section = handleLine(line, section);
            }
        } catch (IOException e) {
            throw e;
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    /**
     * 我们将parse你给出的string，用split("\n")的方式，然后处理每行. 
     * 和loadConfiguration（Filefile)类似
     * 
     * @param string
     */
    public void loadConfigurationFromString(String string) {
        name2section.clear();
        ACEConfigurationSection section = null;
        for (String line: string.split("\n")) {
            String regex= "\".*?\"=dword:[a-zA-Z0-9]*|\".*?\"=\".*?\"|^\\[.*?]$";
            Pattern pt = Pattern.compile(regex);
            Matcher mt = pt.matcher(line); 
                
            if (mt.find()) {
           //    System.out.println(mt.group());
               line = mt.group();
            }
            section = handleLine(line, section);
        }
    }

    private ACEConfigurationSection handleLine(String line, 
            ACEConfigurationSection section) {
        line = line.trim();
       
        if (line.equals("") || line.startsWith("//")){
            return section;
        }
        if (line.startsWith("[") && line.endsWith("]")) {
            if (line.contains("/")) { // sub
                String _line = line.substring(1, line.length() - 1);

                section = new ACEConfigurationSection(

                        _line.substring(_line.indexOf("/") + 1), 

                        line.substring(1, line.length() - 1).split("/")[0]);

                addSubSection(section.getParentSectionName(), section);
            } else {
                section = new ACEConfigurationSection(
                        line.substring(1, line.length() - 1));
                addSection(section);
            }
        } else {
            String keyvalue[] = line.split("\"=");
            if (keyvalue[1].startsWith("\"") && keyvalue[1].endsWith("\"")) {
                section.addStringValue(
                        keyvalue[0].substring(1, keyvalue[0].length()), 
                        keyvalue[1].substring(1,keyvalue[1].length() - 1));
            } else if (keyvalue[1].startsWith("dword:")) {
                section.addLongValue(
                        keyvalue[0].substring(1, keyvalue[0].length()), 
                        Long.parseLong(keyvalue[1].substring(6), 16));
            }
        }
        return section;
    }

    public static void main(String args[]) throws Exception {
        // ACEConfigurationEditor editor = new ACEConfigurationEditor();
        // ACEConfigurationSection section = new
        // ACEConfigurationSection("mainSection");
        // section.addStringValue("port", "10125");
        // section.addLongValue("sub_indx", 0);
        // editor.addSection(section);
        // System.out.println(editor.toString());
        // editor.loadConfiguration(new File("test.config"));
        // System.out.println(editor.toString());
        String section = "[Local]\n"
            + "\"current\"=dword:a\n"
            + "\"latest\"=dword:AAAA\n"
            + "[Summary]\n"
            + "\"current\"=\"dword:AAAA //test\"aa\" \n"
            + "\"latest\"=dword:AAAA\n"
            + "[Snapshot]\n"
            + "\"current\"=dword:AAAA\n"
            + "\"latest\"=dword:AAAA\n";
        ACEConfigurationEditor editor = new ACEConfigurationEditor();
        editor.loadConfiguration(new File("D:\\a"));
       // editor.loadConfigurationFromString(section);
        System.out.println(editor);
    }
}
