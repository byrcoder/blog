package toolbox.maintain.schedule;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.quartz.JobDataMap;

import toolbox.misc.cli.GetOpts;

/**
 * a simple crontab tool
 * 
 * @author neat
 */
public class Crontab {
    
    private static String getConfigIntro() {
        String s = "配置文件的写法大概如下," +
                        "其中success和fail对应为成功或者失败的时候发信给谁(可不填): \n\n"
            + "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n"
            + "<config>\n"
            + "\t<exec cron=\"\" expr=\"\" success=\"\" fail=\"\"/>\n"
            + "</config>\n";
        return s;
    }
    
    private static String getCrontabExpIntro() {
        String s =  " 一个cron表达式有至少6个（也可能7个）有空格分隔的时间元素。 \n"
            + " 如0 0 10,14 * * ? 2006.从左到右，这些元素的定义如下：\n"
            + " \t1.秒（0－59）\n"
            + " \t2.分钟（0－59）\n"
            + " \t3.小时（0－23）\n"
            + " \t4.月份中的日期（1－31）\n"
            + " \t5.月份（1-12或JAN－DEC）\n"
            + " \t6.星期中的日期（1-7或SUN－SAT）\n"
            + " \t7.年份（1970－2099） \n"
            + " \n"
            + " 其中每个元素可以是一个值(如6),一个连续区间(9-12)," +
                        "一个间隔时间(8-18/4)(/表示每隔4小时) \n"
            + " 一个列表(1,3,5),通配符。由于\"月份中的日期\"" +
                        "和\"星期中的日期\"这两个元素互斥的,必须要对其中一个设置 \n"
            + " \t0 0 10,14,16 * * ? 每天上午10点，下午2点，4点 \n"
            + " \t0 0/30 9-17 * * ? 朝九晚五工作时间内每半小时 \n";
        return s;
    }
    
    /**
     * parse config file.
     * @param filename
     * @return
     */
    private ArrayList<CronJob> parseCronJobs(String filename) throws Exception{
        ArrayList<CronJob> jobs = new ArrayList<CronJob>();
        SAXReader reader = new SAXReader();
        Document document = reader.read(new File(filename));
        for(Object obj: document.getRootElement().elements("exec")) {
            Element exec = (Element) obj;
            String cron = exec.attributeValue("cron");
            String expr = exec.attributeValue("expr");
            CronJob job = new CronJob(cron, expr);
            job.setSuccess(exec.attributeValue("success"));
            job.setFail(exec.attributeValue("fail"));
            jobs.add(job);
        }
        return jobs;
    }
    
    public final static String cronjobName = "cronJob";
    /**
     * a crontab job
     * @author neat
     *
     */
    public static class CronJob {
        private String cron; //crontab exp
        private String expr; //the command u wanna execute.
        private String success = null;
        private String fail = null;
        
        public CronJob(String cron, String expr) {
            this.cron = cron;
            this.expr = expr;
        }

        public String getCron() { return cron; }
        public String getExpr() { return expr; }
        public void setSuccess(String success) { this.success = success; }
        public String getSuccess() { return success; }
        public void setFail(String fail) { this.fail = fail; }
        public String getFail() { return fail; }
    }
    
    public static void usage() {
        System.out.println("Usage: toolbox.maintain.schedule.Crontab -c config");
        System.out.println("************** config intro ***************");
        System.out.println(getConfigIntro());
        System.out.println("************** cron intro ***************");
        System.out.println(getCrontabExpIntro());
        System.exit(1);
    }
    
    public static void main(String args[]) throws Exception{
//        boolean autoReload = false;
        String config = null;
        try {
            GetOpts op = new GetOpts("c:", args);
            config = op.getOpt("c");
            if (config == null || config.equals("")) {
                throw new IOException("config cant be null");
            }
        } catch (Exception e) {
            e.printStackTrace();
            usage();
        }
        
        Crontab crontab = new Crontab();
        ArrayList<CronJob> jobs = crontab.parseCronJobs(config);
        QuartzClient client = new QuartzClient();
        for (int idx = 0; idx < jobs.size(); idx++ ) {
            JobDataMap map = new JobDataMap();
            map.put(cronjobName, jobs.get(idx));
            client.addJob("triggerName" + idx, 
                    "triggerGroup" + idx, 
                    "triggerDescrip" + idx, 
                    "jobName" + idx, 
                    "jobGroup" + idx, 
                    "description" + idx, 
                    CronJobExecutor.class, 
                    jobs.get(idx).getCron(), 
                    map);
            System.out.println("Regist Job:time:" + jobs.get(idx).getCron() 
                    + ", expr is " + jobs.get(idx).getExpr());
        }
/*        
        while (true) { 
            try { 
                Thread.sleep(2000); 
            } catch(Exception e) {} 
        }
*/
        synchronized (crontab) {
            crontab.wait();
        }
    }

}
