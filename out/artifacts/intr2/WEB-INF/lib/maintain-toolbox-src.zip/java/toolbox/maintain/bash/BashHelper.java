package toolbox.maintain.bash;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.CharBuffer;

import toolbox.maintain.shared.WritableHashMap;

public class BashHelper {

    /**
     * Execute a command in the shell.
     * 
     * @param cmd
     * @return "out" : stdout, "err" : stderr, "ret" : return value
     * @throws IOException
     */
    public static WritableHashMap shell(String cmd, 
            int outputBufferSize) throws IOException {
        WritableHashMap ret = new WritableHashMap();
        Process p = Runtime.getRuntime().exec("bash");
        ret = shell(p, cmd, outputBufferSize);
        return ret;
    }
    
    
    /**
     * Execute a command in the shell. If cmd is not null, we will use it as
     * input of the process.
     * 
     * @param p
     * @param cmd
     * @param outputBufferSize
     * @return
     * @throws IOException
     */
    public static WritableHashMap shell(Process p, String cmd, 
            int outputBufferSize) throws IOException {
        WritableHashMap ret = new WritableHashMap();
        OutputStream ostream = p.getOutputStream();
        Writer writer = new OutputStreamWriter(ostream);
        if (cmd != null) {
            writer.write(cmd);
            writer.write("\n");
        }
        writer.close();
        Reader outReader = new InputStreamReader(p.getInputStream());
        Reader errReader = new InputStreamReader(p.getErrorStream());
        CharBuffer out = CharBuffer.allocate(outputBufferSize == -1 ? 1024 * 10 : outputBufferSize);
        CharBuffer err = CharBuffer.allocate(outputBufferSize == -1 ? 1024 * 10 : outputBufferSize);
        boolean finished = false;
        while (!finished) {
            int outc = outReader.read(out);
            int errc = errReader.read(err);
            if (out.remaining() == 0) {
                if (outputBufferSize == -1) {
                    out.reset();
                } else {
                    outc = -1;
                }
            }
            if (err.remaining() == 0) {
                if (outputBufferSize == -1) {
                    err.reset();
                } else {
                    errc = -1;
                }
            }
            if ((outc == -1 || errc == -1)) {
                break;
            }
            try {
                p.exitValue();
                finished = true;
            } catch (IllegalThreadStateException e) {
                try {
                        Thread.sleep(10);
                } catch (InterruptedException e2) {}
            }
        }
        out.flip();
        err.flip();
        if (!finished) { //just break from that loop, try wait any more.
            try {
                p.waitFor();
            } catch (Exception e) {
                p.destroy();
            }
        }
        int retValue = p.exitValue();
        outReader.close();
        errReader.close();
        ret.put("out", out.toString());
        ret.put("err", err.toString());
        ret.put("ret", Integer.toString(retValue));
        return ret;
    }

    /**
     * Execute a command in the shell.
     * 
     * @param p
     * @param cmd
     * @return
     * @throws IOException
     */
    public static WritableHashMap shell(String cmd, 
            OutputStream outstream) throws IOException {
        Process p = Runtime.getRuntime().exec("bash");
        OutputStream ostream = p.getOutputStream();
        Writer writer = new OutputStreamWriter(ostream);
        if (cmd != null) {
            writer.write(cmd);
            writer.write("\n");
        }
        writer.close();

        BashStreamReader out = new BashStreamReader(outstream, p.getInputStream());
        BashStreamReader err = new BashStreamReader(outstream, p.getErrorStream());
        out.start();
        err.start();
        
        boolean finished = false;
        while (!finished) {
            try {
                p.exitValue();
                finished = true;
            } catch (IllegalThreadStateException e) {
                try {
                        Thread.sleep(10);
                } catch (InterruptedException e2) {}
            }
        }

        WritableHashMap retValue = new WritableHashMap();
        retValue.put("out", out.getInfo());
        retValue.put("err", err.getInfo());
        retValue.put("ret", p.exitValue() + "");
        return retValue;
    }

}
