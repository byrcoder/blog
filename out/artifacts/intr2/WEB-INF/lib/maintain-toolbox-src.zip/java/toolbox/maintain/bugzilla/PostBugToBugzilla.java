package toolbox.maintain.bugzilla;

import toolbox.maintain.alarm.Emailer;


/**
 * Post bug to bugzilla
 * @author neat
 *
 */
public class PostBugToBugzilla {

    protected String bugzillaAddress = "bugzilla-daemon@dev.corp.yodao.com";
    protected String reporter = "";
    protected String product = "";
    protected String component = "";
//    protected Emailer emailer = new Emailer();
    protected String newLine = "\n";
    public enum BugVersion {
        unspecified
    }
    public enum OS {
        All
    }
    public enum Platform {
        All
    }
    public enum Severity {
        blocker, critical, major, normal, minor, trivial, enhancement
    }
    public enum Priority {
        P1, P2, P3, P4, P5
    }

    /**
     * @param reporter
     *            should be xxx@rd.netease.com
     * @param product
     * @param component
     */
    public PostBugToBugzilla(String reporter, String product, String component) {
        this.reporter = reporter;
        this.product = product;
        this.component = component;
    }

    /**
     * 提交一个bug到bugzilla上面. severity为normal, priority为p3, os为all, platform为all,
     * version为unspecified
     * 
     * @param subject
     * @param description
     */
    public void postBug(String subject, String description) {
        postBug(Severity.normal, Priority.P3, subject, description);
    }

    /**
     * 提交一个bug到bugzilla上面. os为默认的all, platform为all, version为unspecified
     * 
     * @param component
     * @param severity
     * @param priority
     * @param subject
     * @param description
     */
    public void postBug(Severity severity, Priority priority, 
            String subject, String description) {
        postBug(severity, priority, OS.All, Platform.All, 
                BugVersion.unspecified, subject, description);
    }

    /**
     * 提交一个bug到bugzilla上面
     * 
     * @param component
     * @param severity
     * @param priority
     * @param os
     * @param platform
     * @param version
     * @param subject
     * @param description
     */
    public void postBug(Severity severity, 
            Priority priority, OS os, Platform platform,
            BugVersion version, String subject, String description) {
        String content = "---BEGIN---" + newLine;
        content += "From:" + reporter + newLine;
        content += "Subject:" + subject + newLine;
        content += newLine;
        content += "@product = " + product + newLine;
        content += "@component = " + component + newLine;
        content += "@severity = " + severity + newLine;
        content += "@priority = " + priority + newLine;
        content += "@op_sys = " + os + newLine;
        content += "@rep_platform = " + platform + newLine;
        content += "@version = " + version + newLine;
        content += newLine;
        content += description + newLine;
        content += "--";

        //System.out.println(content);
        new Emailer().sendEmail("dengyulin@rd.netease.com", bugzillaAddress, "post a bug", 
                content, new String[0]);
    }

    public static void main(String args[]) {
        PostBugToBugzilla pbug = new PostBugToBugzilla(
                "dengyulin@rd.netease.com", 
                "MaintainMonitor", 
                "websearch_web");
        pbug.postBug(Severity.normal, Priority.P4, 
                "test", "testdescription");
    }

    public String getBugzillaAddress() {
        return bugzillaAddress;
    }

    public void setBugzillaAddress(String bugzillaAddress) {
        this.bugzillaAddress = bugzillaAddress;
    }
}
