package toolbox.maintain.alarm;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public final class Emailer {

    //we will cut content if the content is too large.
    private int maxContentSize = 1024 * 1024; // 1M

    private static Properties fMailServerConfig = new Properties();

    static {
        fetchConfig();
    }

    public static void usage() {
        System.out.println("Usage: toolbox.manager.tools.Emailer "
                + "[-f from] -t to -title title -ct content -size size");
        System.out.println("-f from:\tDefault is postmaster@rd.netease.com");
        System.out.println("-size size:\tDefault is postmaster@rd.netease.com");
        System.exit(1);
    }

    /**
     * Send a single email Synchronously, generally not recommended. 'Cause once
     * dev-smtp falls down, this method'll be blocked and service'll be hung up.
     */
    public boolean syncSendEmail(String aFromEmailAddr, String aToEmailAddr,
            String aSubject, String aBody, String[] fileDirs) {
        Session session = Session.getDefaultInstance(fMailServerConfig, null);
        MimeMessage message = new MimeMessage(session);
        try {
            message.setFrom(new InternetAddress(aFromEmailAddr));
            String tos[] = aToEmailAddr.split(";");
            ArrayList<InternetAddress> address = new ArrayList<InternetAddress>();
            for (int idx = 0; idx < tos.length; idx++) {
                if (!tos[idx].trim().equals("")) {
                    try {
                        address.add(new InternetAddress(tos[idx]));
                    } catch (javax.mail.internet.AddressException e) {
                        System.err.println("address:[" + tos[idx]
                                + "] is not correct");
                    }
                }
            }
            message.addRecipients(Message.RecipientType.TO,
                    address.toArray(new InternetAddress[address.size()]));
            message.setSubject(aSubject);
            /** with attachment */
            Multipart multipart = new MimeMultipart("related");

            //part1: content
            MimeBodyPart msgPart = new MimeBodyPart();
            msgPart.setContent(limit(aBody), "text/html;charset=UTF-8");
            msgPart.setHeader("Content-Transfer-Encoding", "quoted-printable");
            multipart.addBodyPart(msgPart);
            //part2->partn: attenchment.
            if (fileDirs != null && fileDirs.length > 0) {
                for (String filename: fileDirs) {
                    MimeBodyPart fileBodyPart = new MimeBodyPart();
                    DataSource datasource = new FileDataSource(filename);
                    fileBodyPart.setDataHandler(new DataHandler(datasource));
                    fileBodyPart.setFileName(new File(filename).getName());
                    // fileBodyPart.setFileName("=?" + "GB2312" + "?B?"
                    // + enc.encode((datasource.getName()).getBytes()) + "?=");
                    fileBodyPart.setContentID(new File(filename).getName());
                    multipart.addBodyPart(fileBodyPart);
                }
            }

            message.setContent(multipart);
            Transport.send(message);
            return true;
        } catch (MessagingException ex) {
            System.err.println("Cannot send email.\n\r " + ex);
            return false;
        }
    }

    /**
     * Send email asynchronously. If no response received from dev-smtp in 5
     * minutes, it returns false(failure).
     */
    public boolean sendEmail(final String aFromEmailAddr,
            final String aToEmailAddr, final String aSubject,
            final String aBody, final String[] fileDirs) {
        Boolean isSendSuccess = false;

        ExecutorService executor = Executors.newSingleThreadExecutor();
        FutureTask<Boolean> future = new FutureTask<Boolean>(
                new Callable<Boolean>() {
                    public Boolean call() {
                        return syncSendEmail(aFromEmailAddr, aToEmailAddr,
                                aSubject, aBody, fileDirs);
                    }
                });

        executor.execute(future);
        try {
            // 取得结果，同时设置超时执行时间为5分钟。
            isSendSuccess = future.get(5 * 60 * 1000L, TimeUnit.MILLISECONDS);
        } catch (java.util.concurrent.TimeoutException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            future.cancel(true);
        } catch (ExecutionException e) {
            future.cancel(true);
        } finally {
            executor.shutdown();
        }
        return isSendSuccess;
    }

    /**
     * call this method if you wanna reset maxContentSize. default is 100 *
     * 1024(1M)
     * 
     * @param size
     */
    public void setMaxContentSize(int size) {
        this.maxContentSize = size;
    }

    private String limit(String content) {
        byte[] contentBytes = content.getBytes();
        if (contentBytes.length > maxContentSize) {
            contentBytes = new byte[maxContentSize];
            System.arraycopy(content.getBytes(), 0, contentBytes, 0,
                    maxContentSize);
        }
        return new String(contentBytes);
    }

    public Properties getMailServerConfig() {
        return fMailServerConfig;
    }

    /**
     * Allows the config to be refreshed at runtime, instead of requiring a
     * restart.
     */
    public static void refreshConfig() {
        fMailServerConfig.clear();
        fetchConfig();
    }

    /**
     * Open a specific text file containing mail server parameters, and populate
     * a corresponding Properties object.
     */
    private static void fetchConfig() {
        InputStream input = null;
        try {
            input = new FileInputStream("conf/mail.conf");
            fMailServerConfig.load(input);
        } catch (IOException ex) {
            System.err.println("Cannot open and load mail server properties file.");
            System.err.println("We will use default configuration");
            fMailServerConfig.put("", "");
            fMailServerConfig.put("mail.host", "soda.rd.netease.com");
            fMailServerConfig.put("mail.from", "postmaster@rd.netease.com");
            fMailServerConfig.put("mail.user", "postmaster@rd.netease.com");
            fMailServerConfig.put("mail.smtp.host", "220.181.8.38");
            fMailServerConfig.put("mail.debug", "true");
        } finally {
            try {
                fMailServerConfig.put("mail.smtp.localhost", 
				                      InetAddress.getLocalHost().getHostName().split("\\.")[0]);
            } catch (UnknownHostException e) {
                fMailServerConfig.put("mail.smtp.localhost", "localhost");
                e.printStackTrace();
            }
            
            try {
                if (input != null)
                    input.close();
            } catch (IOException ex) {
                System.err.println("Cannot close mail server properties file.");
                ex.printStackTrace();
            }
        }
    }

}
