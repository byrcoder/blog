package toolbox.maintain;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import toolbox.maintain.bash.LinkTool;

/**
 * some useful method
 * @author neat
 *
 */
public class Helper {
    /**
     * Write a String to a file
     * 
     * @param file
     * @param string
     * @param append
     * @throws IOException
     */
    public static void writeStringToFile(File file, String string, 
            boolean append) throws IOException {
        writeStringToFile(file, string, "UTF-8", append);
    }
    
    /**
     * Write a String to a file
     * 
     * @param file
     * @param string
     * @param append
     * @throws IOException
     */
    public static void writeStringToFile(File file, String string, 
            String charset, boolean append) throws IOException {
        BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(
                        new FileOutputStream(file, append), charset));
        writer.write(string);
        writer.close();
    }
    
    /**
     * Read the whole content of the file and return it as a arrayList
     * 
     * @param file
     * @return
     * @throws IOException
     */
    public static ArrayList<String> readStringListFromFile(File file, String spliter) 
            throws IOException {
        String array[] = readStringFromFile(file, "UTF-8").split(spliter);
        ArrayList<String> list = new ArrayList<String>(array.length);
        for (String str: array) {
            list.add(str);
        }
        return list;
    }
    
    /**
     * Read the whole content of the file and return it as a String
     * 
     * @param file
     * @return
     * @throws IOException
     */
    public static String[] readStringArrayFromFile(File file, String spliter) 
            throws IOException {
        return readStringFromFile(file, "UTF-8").split(spliter);
    }

    /**
     * Read the whole content of the file and return it as a String
     * 
     * @param file
     * @return
     * @throws IOException
     */
    public static String readStringFromFile(File file) 
            throws IOException {
        return readStringFromFile(file, "UTF-8");
    }

    /**
     * Read the whole content of the file and return it as a String
     * 
     * @param file
     * @return
     * @throws IOException
     */
    public static String readStringFromFile(File file, String charset) 
            throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), charset));
        char[] buffer = new char[256];
        StringBuilder string = new StringBuilder();
        while (true) {
            int c = reader.read(buffer);
            if (c == -1) {
                break;
            }
            string.append(buffer, 0, c);
        }
        return string.toString();
    }

    /**
     * Write a byte array to a file
     * 
     * @param file
     * @param string
     * @param append
     * @throws IOException
     */
    public static void writeBytesToFile(File file, byte bytes[]) throws IOException {
        FileOutputStream out = new FileOutputStream(file);
        out.write(bytes);
        out.close();
    }

    /**
     * Read the whole content of the file and return it as a byte[]
     * 
     * @param file
     * @return
     * @throws IOException
     */
    public static byte[] readBytesFromFile(File file) throws IOException {
        FileInputStream in = new FileInputStream(file);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        try {
            while (true) {
                int length = in.read(buffer);
                if (length == -1) {
                    break;
                }
                out.write(buffer, 0, length);
            }
            return out.toByteArray();
        } finally {
            in.close();
            out.close();
        }
    }
    
    /**
     * return a server list. e.g.: list=tb{51-53}, needformate=true,
     * namelength=3, we will return tb051, tb052, tb053. if needformate = false,
     * we will return tb51,tb52,tb53.
     * 
     * @param list
     * @param needformate
     * @namelength
     * @return
     */
    public static String[] expandServerList(String list, boolean needformate, int namelength) {
        ArrayList<String> serverList = new ArrayList<String>();
        String parts[] = list.split(",");
        for (String part: parts) {
            if (part.trim().equals("")) {
                continue;
            }
            String quoted = quotedstr(part, "{", "}");
            if (quoted == null) {
                serverList.add(part);
            } else {
                String prefix = part.substring(0, part.indexOf("{"));
                String suffix = part.substring(part.indexOf("}") + 1);
                String limits[] = quoted.split("-");
                int min = Integer.parseInt(limits[0]);
                int max = Integer.parseInt(limits[1]);
                for (int idx = min; idx <= max; idx++) {
                    if (needformate) {
                        serverList.add(prefix + String.format("%0" 
                                + namelength + "d", idx, '0') + suffix);
                    } else {
                        serverList.add(prefix + idx + suffix);
                    }
                }
            }
        }
        return serverList.toArray(new String[0]);
    }

    /**
     * get first quoted substring
     * 
     * @param line
     * @param leftquoter
     * @param rightquoter
     * @return
     */
    public static String quotedstr(String line, String leftquoter, 
            String rightquoter) {
        int left = line.indexOf(leftquoter);
        if (left == -1) {
            return null;
        }
        int right = line.indexOf(rightquoter);
        if (right == -1) {
            return null;
        }
        return line.substring(left + 1, right);
    }
    
    /**
     * return the whole exception as string.
     * @param e
     * @return
     */
    public static String getException(Throwable e) {
        if (e == null) {
            return null;
        }
        StackTraceElement[] trace = e.getStackTrace();
        String line = e.toString() + "\n";
        for (int i = 0; i < trace.length; i++) {
            line += "\tat " + trace[i] + "\n";
        }
        Throwable itscause = e.getCause();
        if (itscause != null) {
            line += getExceptionCaused(trace, itscause);
        }
        return line;
    }

    public static String getExceptionCaused(StackTraceElement causedTrace[], Throwable e) {
        StackTraceElement[] trace = e.getStackTrace();
        int m = trace.length - 1, n = causedTrace.length - 1;
        while (m >= 0 && n >= 0 && trace[m].equals(causedTrace[n])) {
            m--;
            n--;
        }
        int framesInCommon = trace.length - 1 - m;
        String line = "Caused by: " + e.toString() + "\n";
        for (int i = 0; i <= m; i++) {
            line += "\tat " + trace[i] + "\n";
        }
        if (framesInCommon != 0) {
            line += "\t... " + framesInCommon + " more\n";
        }
        Throwable itscause = e.getCause();
        if (itscause != null) {
            line += getExceptionCaused(trace, itscause);
        }
        return line;
    }
    
    public static boolean isXml(String xml) {
        return (xml != null) && (xml.trim().startsWith("<?xml"));
    }
    
    /**
     * check one url
     * @param url
     * @return
     */
    public static boolean isUrl(String url) {
        return (url != null) && (url.startsWith("http://") || url.startsWith("https://"));
    }
    
    public static String filterHtml(String html) {
        return html.replaceAll("&", "&amp;").replaceAll("<", "&lt;")
                .replaceAll(">", "&gt;").replaceAll("\"", "&quot;")
                .replaceAll(" ", "&nbsp;").replaceAll("©", "&copy;")
                .replaceAll("®", "reg;");
    }
    
    public static String filterXml(String xml) {
        return xml.replaceAll("<", "&lt;").replaceAll(">", "&gt;")
                .replaceAll("&", "&amp;").replaceAll("\"", "&quot;")
                .replaceAll("'", "&apos;");
    }
    
    /**
     * replace all quotation marks
     * @param s
     * @return
     */
    public static String filterStr4DbString(String s) {
        if (s == null) { return s; }
        return s.replaceAll("'", "&apos;").replaceAll("\"", "&quot;");
    }
    
    /**
     * parse string from db. replace back all quotation marks
     */
    public static String parseStrFromDbString(String s) {
        if (s == null) { return s; }
        return s.replaceAll("&apos;", "'").replaceAll("&quot;", "\"");
    }
    
    /**
     * Delete files or links
     * 
     * @param file
     * @author linfeng
     */
    public static void deleteFiles(File file) {
        if (file == null)
            return;
        // Unlink the links
        LinkTool.UnlinkSymbolLink(file.getAbsolutePath());
        // If file is a link, file.exists() = false and delete it directly.
        if (file.exists() && file.isDirectory()) {
            for (File subFile: file.listFiles())
                deleteFiles(subFile);
        }
        file.delete();
    }
}
