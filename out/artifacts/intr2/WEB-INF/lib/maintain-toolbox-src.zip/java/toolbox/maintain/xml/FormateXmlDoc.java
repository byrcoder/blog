package toolbox.maintain.xml;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import toolbox.misc.cli.GetOpts;


/**
 * pretty print xml files.
 * 
 * @author neat
 */
public class FormateXmlDoc {

    public static void usage() {
        System.out.println("Usage: toolbox.maintain.xml.FormateXmlDoc -f filename");
        System.exit(1);
    }

    public static void main(String args[]) throws Exception {
        String filename = "";
        try {
            GetOpts op = new GetOpts("f:", args);
            filename = op.getOpt("f");
            if (filename == null || filename.equals("")) {
                throw new IOException("filename cant be null");
            }
        } catch (Exception e) {
            e.printStackTrace();
            usage();
        }
        SAXReader reader = new SAXReader();
        Document document = reader.read(new File(filename));
        XMLWriter writer = null;
        try {
            // Pretty print the document to System.out
            OutputFormat format = OutputFormat.createPrettyPrint();
            format.setIndentSize(4);
            writer = new XMLWriter(new FileWriter(filename), format);
            writer.write(document);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
