package toolbox.maintain.schedule;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import toolbox.maintain.Helper;
import toolbox.maintain.alarm.Emailer;
import toolbox.maintain.bash.BashHelper;
import toolbox.maintain.schedule.Crontab.CronJob;
import toolbox.maintain.shared.WritableHashMap;
import toolbox.misc.LogFormatter;

public class CronJobExecutor implements Job{

    private final static Logger LOG = LogFormatter.getLogger(CronJobExecutor.class);
    
    public void execute(JobExecutionContext context) throws JobExecutionException {
        JobDataMap map = context.getJobDetail().getJobDataMap();
        CronJob job = (CronJob)map.get(Crontab.cronjobName);
        WritableHashMap ret = new WritableHashMap();
        try {
//            Process process = Runtime.getRuntime().exec(job.getExpr());
//            ret = BashHelper.shell(process, 
//                   null,         //we dont need anymore input for this process 
//                   1024 * 10); //1M buffer
            ret = BashHelper.shell(job.getExpr(), -1);
        } catch (IOException e) {
            LOG.log(Level.SEVERE, "Execute job fail!" + job.getExpr(), e);
            ret.put("ret", "1");
            ret.put("err", Helper.getException(e));
        }
        if (ret.get("ret").equals("0")) { //success
            if (job.getSuccess() != null && !job.getSuccess().equals("")) {
                new Emailer().sendEmail("postmaster@rd.netease.com", 
                        job.getSuccess(), 
                        "[Job Success]" + job.getExpr(), 
                        "", 
                        new String[0]);
            }
        } else {
            if (job.getFail() != null && !job.getFail().equals("")) {
                new Emailer().sendEmail("postmaster@rd.netease.com", 
                        job.getSuccess(), 
                        "[Job Fail]" + job.getExpr(), 
                        "", 
                        new String[0]);
            }
        }
    }

}
