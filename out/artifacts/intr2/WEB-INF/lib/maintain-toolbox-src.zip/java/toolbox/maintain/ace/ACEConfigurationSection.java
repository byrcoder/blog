package toolbox.maintain.ace;

import toolbox.maintain.shared.TimeSequenceHashMap;

/**
 * 一个用来存储规定格式数据的类，大概的格式如下<br>
 * [SectionName］<br>
 * "key"="value"//如果是string类型的值<br>
 * "key"=dword:value//如果是long类型的值<br>
 * [SectionName/SubSectionName] //如果有子section<br>
 * ... <br>
 * [SectionName/SubSectionName_x]<br>
 * ...<br>
 * 
 * @author neat
 */
public class ACEConfigurationSection {

    private String sectionName;

    private String parentSectionName;

    private TimeSequenceHashMap<String, ACEValuePair> pairmap = 
        new TimeSequenceHashMap<String, ACEValuePair>();

    /**
     * if one section has a parent section, cant has subsections.
     */
    private TimeSequenceHashMap<String, ACEConfigurationSection> subSections = 
        new TimeSequenceHashMap<String, ACEConfigurationSection>();

    public ACEConfigurationSection(String sectionName) {
        this(sectionName, null);
    }

    public ACEConfigurationSection(String sectionName, String parentSectionName) {
        this.sectionName = sectionName;
        this.parentSectionName = parentSectionName;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getParentSectionName() {
        return parentSectionName;
    }
    
    public TimeSequenceHashMap<String, ACEValuePair> getPairMap(){
        return this.pairmap;
    }
    
    public void setParentSectionName(String parentSectionName){
        this.parentSectionName = parentSectionName;
    }

    public TimeSequenceHashMap<String, ACEConfigurationSection> getSubSections() {
        return subSections;
    }

    public void addSubSection(ACEConfigurationSection section) {
        section.parentSectionName = sectionName;
        subSections.put(section.sectionName, section);
    }

    public void addStringValue(String key, String value) {
        pairmap.put(key, new ACEValuePair(key, value));
    }

    public void addStringValue(String subSection, String key, String value) {
        subSections.get(subSection).addStringValue(key, value);
    }

    public void addLongValue(String key, long value) {
        pairmap.put(key, new ACEValuePair(key, value));
    }

    public void addLongValue(String subSection, String key, long value) {
        subSections.get(subSection).addLongValue(key, value);
    }
    
    /**
     * 查询本section，看是否能找到对应key的string值 . 如果找不到，那么返回null. 注意，不会去查subsection
     * 
     * @return
     */
    public String getStringValue(String key) {
        if (pairmap.containsKey(key)) {
            return pairmap.get(key).getStringValue();
        }
        return null;
    }

    public String getStringValue(String subSectionName, String key) {
        if (subSections.containsKey(subSectionName)) {
            return subSections.get(key).getStringValue(key);
        }
        return null;
    }

    /**
     * 查询本section，看是否能找到对应key的string值 . 如果找不到，那么返回Long.Max_VALUEl.
     * 注意，不会去查subsection
     * 
     * @return
     */
    public long getLongValue(String key) {
        if (pairmap.containsKey(key)) {
            return pairmap.get(key).getLongValue();
        } else {
            return Long.MAX_VALUE;
        }
    }

    public Long getLongValue(String subSectionName, String key) {
        if (subSections.containsKey(subSectionName)) {
            return subSections.get(subSectionName).getLongValue(key);
        }
        return Long.MAX_VALUE;
    }

    public String toString() {
        String _2str = "";
        if (parentSectionName == null || parentSectionName.equals("")) {
            // 这种情况下，需要检查子section
            _2str = "[" + sectionName + "]";
            for (String key: pairmap.sequenceKeySet()) {
                _2str += "\n" + pairmap.get(key).toString();
            }
            for (String sectionName: subSections.sequenceKeySet()) {
                _2str += "\n" + subSections.get(sectionName).toString();
            }
        } else {
            // 这种情况下，不需要检查子section
            _2str = "[" + parentSectionName + "/" + sectionName + "]";
            for (String key: pairmap.sequenceKeySet()) {
                _2str += "\n" + pairmap.get(key).toString();
            }
        }
        return _2str;
    }

    /**
     * 用于记录section里面key－value对的类。 key是string，Value是string或者long.
     * 
     * @author yulindeng
     */
    public class ACEValuePair {
        private String key = "";

        private String svalue = null;

        private long intvalue = Long.MAX_VALUE;

        public ACEValuePair(String key, String value) {
            this.key = key;
            this.svalue = value;
        }

        public ACEValuePair(String key, long value) {
            this.key = key;
            this.intvalue = value;
        }

        public String getStringValue() {
            return svalue;
        }

        public Long getLongValue() {
            return intvalue;
        }

        public String toString() {
            if (svalue != null && !svalue.equals("")) {
                return "\"" + key + "\"=\"" + svalue + "\"";
            } else {
                return "\"" + key + "\"=dword:" + Long.toHexString(intvalue) + "";
            }
        }
    }
}
