package toolbox.maintain.schedule;

import java.util.Calendar;

import org.quartz.*;

/**
 * Simple schedule tool, like crontab; but in this system, "crontab" expression
 * is not the same one with nomal crontab. <br>
 * <br>
 * 一个cron表达式有至少6个（也可能7个）有空格分隔的时间元素。 <br>
 * 如0 0 10,14 * * ? 2006.从左到右，这些元素的定义如下：
 * <li>1.秒（0－59）
 * <li>2.分钟（0－59）
 * <li>3.小时（0－23）
 * <li>4.月份中的日期（1－31）
 * <li>5.月份（1-12或JAN－DEC）
 * <li>6.星期中的日期（1-7或SUN－SAT）
 * <li>7.年份（1970－2099） <br>
 * <br>
 * 其中每个元素可以是一个值(如6),一个连续区间(9-12),一个间隔时间(8-18/4)(/表示每隔4小时),<br>
 * 一个列表(1,3,5),通配符。由于"月份中的日期"和"星期中的日期"这两个元素互斥的,必须要对其中一个设置<br>
 * <li>0 0 10,14,16 * * ? 每天上午10点，下午2点，4点
 * <li>0 0/30 9-17 * * ? 朝九晚五工作时间内每半小时 <br>
 * <br>
 * u can find a detail intro at this websit: <br>
 * {@link http://www.opensymphony.com/quartz/wikidocs/TutorialLesson6.html}
 * 
 * @author neat
 */
public class QuartzClient extends Thread {
    private SchedulerFactory schedFact = 
        new org.quartz.impl.StdSchedulerFactory();

    private Scheduler sched;

    public QuartzClient() {
        this.setDaemon(true);
        try {
            sched = schedFact.getScheduler();
            sched.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * We will run jobs at a special time.
     * 
     * @param triggerName
     * @param triggerGroup
     * @param triggerDescrip
     * @param jobName
     *            should be different with other
     * @param jobGroup
     * @param description
     * @param jobClazz
     * @param crontExp
     *            contab expression
     * @param jobDataMap
     *            in jobClazz, u can get things from this data map.
     * @param joblistener
     */
    public void addJob(String triggerName, String triggerGroup, 
            String triggerDescrip, String jobName, String jobGroup,
            String description, Class jobClazz, String crontExp, 
            JobDataMap jobDataMap) {//, JobListener joblistener) {
        try {
            JobDetail jobDetail = new JobDetail(jobName, jobGroup, jobClazz);
            jobDetail.setDescription(description);
            jobDetail.setJobDataMap(jobDataMap);
            CronTrigger trigger = new CronTrigger(triggerName, triggerGroup);
            trigger.setDescription(triggerDescrip);
            trigger.setCronExpression(crontExp);
//            if (joblistener != null) {
//                sched.addJobListener(joblistener);
//                jobDetail.addJobListener(joblistener.getName());
//            }
            sched.scheduleJob(jobDetail, trigger);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * we will run job ag. and ag.
     * @param triggerName
     * @param triggerGroup
     * @param triggerDescrip
     * @param jobName
     * @param jobGroup
     * @param description
     * @param jobClazz
     * @param jobDataMap
     * @param intervalMills
     */
    public void addRepeatJob(String triggerName, String triggerGroup, 
            String triggerDescrip, String jobName, String jobGroup, 
            String description, Class jobClazz, JobDataMap jobDataMap,
            long intervalMills) {
        try {
            JobDetail jobDetail = new JobDetail(jobName, jobGroup, jobClazz);
            jobDetail.setDescription(description);
            jobDetail.setJobDataMap(jobDataMap);
            //CronTrigger trigger = new CronTrigger(triggerName, triggerGroup);
            SimpleTrigger trigger = new SimpleTrigger(triggerName, triggerGroup);
            trigger.setDescription(triggerDescrip);
            trigger.setStartTime(Calendar.getInstance().getTime());
            trigger.setRepeatInterval(intervalMills);
            trigger.setRepeatCount(-1);
//            if (joblistener != null) {
//                sched.addJobListener(joblistener);
//                jobDetail.addJobListener(joblistener.getName());
//            }
            sched.scheduleJob(jobDetail, trigger);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
//    public void addJobListener(String jobName, String jobGroup, 
//            JobListener joblistener) throws SchedulerException {
//        sched.addJobListener(joblistener);
//        JobDetail jdetail = sched.getJobDetail(jobName, jobGroup);
//        jdetail.addJobListener(joblistener.getName());
//    }
    
    public void delJob(String jobName, String jobGroup) {
        try {
            sched.deleteJob(jobName, jobGroup);
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }
}
