/**
 * @(#)FileCopy.java, 2010-1-8. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.maintain.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;

import toolbox.misc.cli.Options;

/**
 * 用来从多个stat盘copy数据到ssd的工�? 采用多个reader单个writer的方式，
 * 用来保证ssd的写操作是大块顺序写，�?不是随机写�?
 * @author neat
 */
public class FileCopy {
    
    public static final int DEFAULT_BLOCK_SIZE = 1024 * 1024 * 200; //200M
    public static final int DEFAULT_MAX_KEEP = 8; //每个reader�?��缓存多少�?
    private Reader readers[];
    private File fdest[];
    
    public FileCopy(String src[], String dest[]) throws IOException {
        if (src.length != dest.length) {
            throw new RuntimeException("the length of src does not matches dest");
        }
        readers = new Reader[src.length];
        for (int idx = 0; idx < src.length; idx++) {
            File file = new File(src[idx]);
            if (!file.exists()) {
                throw new RuntimeException("file doest not exist:" + src[idx]);
            }
            readers[idx] = new Reader(file, DEFAULT_MAX_KEEP, DEFAULT_BLOCK_SIZE);
        }
        fdest = new File[dest.length];
        for (int idx = 0; idx < dest.length; idx++) {
            fdest[idx] = new File(dest[idx]);
            if (!fdest[idx].exists()) {
                File parent = fdest[idx].getParentFile();
                if (parent != null && parent.exists() == false) {
                    if (parent.mkdirs() == false) {
                        throw new IOException("File '" + fdest[idx]
                                + "' could not be created");
                    }
                }
            }
        }
    }
    
    public void start() {
        for (Reader reader: readers) {
            reader.start();
        }
        new Writer(readers, fdest).run();
    }
    
    private static class Segment {
        public int length;      //length of this segment
        public byte[] data;     //data
        public Segment(int blockSize) {
            this.data = new byte[blockSize];
        }
    }
    
    private class Writer extends Thread {
        
        private ArrayList<Reader> readers = new ArrayList<Reader>();
        //key is the hash code of reader.
        private HashMap<Integer, FileOutputStream> outputs 
            = new HashMap<Integer, FileOutputStream>();

        public Writer(Reader readers[], File dests[]) {
            for (int idx = 0; idx < readers.length; idx++) {
                this.readers.add(readers[idx]);
                try {
                    FileOutputStream o = new FileOutputStream(dests[idx], false);
                    outputs.put(readers[idx].hashCode(), o);
                } catch (FileNotFoundException e) {
                    // 不做处理, 在new的时候已经创建父目录,
                } 
            }
        }

        public void run() {
            try {
                int current = 0; // 优先选择上一次写数据的reader.
                int retry = 0;
                Reader reader;
                while (readers.size() > 0) {
                    reader = readers.get(current);
                    Segment seg = reader.getNextBlock();
                    int id = reader.hashCode();
                    
                    if (seg == null) {
                        retry ++;
                        // 如果当前的reader已经结束了，那么剔除
                        if (reader.finished) {
                            readers.remove(current);
                            outputs.get(id).close();
                        }
                        // 当前reader没有数据/结束，那么都�?��看下�?��reader.
                        current++;
                        if (readers.size() != 0) {
                            current = current % readers.size();
                        }
                    } else {
                        retry = 0;
                        // write, if seg.id > 0, use append
                        outputs.get(id).write(seg.data, 0, seg.length);
                    }
                    //如果�?��的reader都没有，那么�?00ms.
                    if (retry > readers.size()) { 
                        try {
                            sleep(100);
                        } catch (Exception e) {}
                        retry = 0;
                    }
                }
            } catch (IOException e) {} finally {
                for (FileOutputStream out: outputs.values()) {
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException e) {}
                    }
                }
            }
        }
    }

    private class Reader extends Thread {
        private boolean finished = false;
        private File file;
        private int queueSize;
        private int blockSize;
        private LinkedBlockingQueue<Segment> segments;

        /**
         * @param file
         * @param queueSize
         *            块个�?
         * @param blockSize
         *            块大�?
         */
        public Reader(File file, int queueSize, int blockSize) {
            this.file = file;
            this.queueSize = queueSize;
            this.blockSize = blockSize;
            segments = new LinkedBlockingQueue<Segment>(this.queueSize);
        }
        
        public void run() {
            FileInputStream input = null;
            try {
                input = new FileInputStream(file);
                while (true) {
                    //read a big block.
                    Segment segment = new Segment(this.blockSize);
                    int size = input.read(segment.data);
                    segment.length = size;
                    try {
                        segments.put(segment);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    
                    //如果已经没有�?��读的了，那么�?��循环.
                    if (input.available() == 0) {
                        break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                finished = true;
                if (input != null) {
                    try {
                        input.close();
                    } catch (Exception e) {}
                }
            }
        }

        
        public Segment getNextBlock() {
            if (segments == null || segments.size() == 0) {
                return null;
            }
            return segments.poll();
        }
        
        public boolean isFinished() {
            return finished;
        }
    }

    public static void main(String args[]) throws Exception {
        Options options = new Options();
        options.withOption("s", "src", "src files, use ',' to slpit");
        options.withOption("d", "dest", "dest files, use ',' to split");
        
        options.parse(args);

        String src[] = options.getStringOpt("s").split(",");
        String dest[] = options.getStringOpt("d").split(",");
        
        new FileCopy(src, dest).start();
    }
}
