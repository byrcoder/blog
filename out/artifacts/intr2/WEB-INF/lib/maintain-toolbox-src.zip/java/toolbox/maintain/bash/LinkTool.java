package toolbox.maintain.bash;

import java.io.IOException;
import java.util.logging.Logger;

import toolbox.maintain.shared.WritableHashMap;
import toolbox.misc.LogFormatter;

/**
 * 调用system的一些link方法.
 * 
 * @author neat
 */
public class LinkTool {
    
    private static Logger LOG = LogFormatter.getLogger(LinkTool.class.getName()); 

    /**
     * 对给定的src目录创建一个叫做dest的软链接
     * 
     * @param src
     * @param dest
     * @return
     */
    public static boolean MakeSymbolLink(String src, String dest) {
        try {
            String cmd = "python scripts/ln.py -slink -s " + src + " -d " + dest;
            WritableHashMap map = BashHelper.shell(cmd, 1024);
            LOG.info("Execute: " + cmd + ", and ret is \n" + map);
            return map.get("ret").equals("0") ? true: false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 去掉某个目录的软连接
     * 
     * @param src
     * @return
     */
    public static boolean UnlinkSymbolLink(String src) {
        try {
            String cmd = "python scripts/ln.py -unlink -s " + src;
            WritableHashMap map = BashHelper.shell(cmd, 1024);
            LOG.info("Execute: " + cmd + ", and ret is \n" + map);
            return map.get("ret").equals("0") ? true: false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 对一个给定的目录作hardlink，具体的方法是使用递归的办法遍历源目录，
     * 如果是文件那么就创建hardlink，否则的华创建对应的dir，
     * 并且遍历子目录。
     * 
     * @param src
     * @param dest
     * @return
     */
    public static boolean MakeHardLink(String src, String dest) {
        try {
            String cmd = "python scripts/ln.py -s " + src + " -d " + dest;
            WritableHashMap map = BashHelper.shell(cmd, 1024);
            LOG.info("Execute: " + cmd + ", and ret is \n" + map);
            return map.get("ret").equals("0") ? true: false;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * 对一个给定的文件做hardlink.
     * 
     * @param file1
     * @param file2
     * @return
     */
    public static boolean MakeFileHardLink(String file1, String file2) {
        try {
            String cmd = "ln " + file1 + " " + file2;
            WritableHashMap map = BashHelper.shell(cmd, 1024);
            LOG.info("Execute: " + cmd + ", and ret is \n" + map);
            return map.get("ret").equals("0") ? true: false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}
