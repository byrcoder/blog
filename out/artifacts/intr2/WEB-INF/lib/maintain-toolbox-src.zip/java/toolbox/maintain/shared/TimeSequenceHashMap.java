package toolbox.maintain.shared;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A hash map, we will record the order of keys.
 * @author neat
 *
 * @param <K>
 * @param <V>
 */
public class TimeSequenceHashMap<K, V> extends HashMap<K, V> {
    private static final long serialVersionUID = 1L;

    private ArrayList<K> list;

    public TimeSequenceHashMap() {
        list = new ArrayList<K>();
    }

    @Override
    public void clear() {
        list.clear();
        super.clear();
    }

    @Override
    public V put(K arg0, V arg1) {
        if (list.contains(arg0)) {
            list.remove(arg0);
        }
        list.add(arg0);
        return super.put(arg0, arg1);
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> arg0) {
        if (arg0 instanceof TimeSequenceHashMap) {
            for (K k: ((TimeSequenceHashMap<K, V>) arg0).sequenceKeySet()) {
                put(k, arg0.get(k));
            }
        } else {
            for (K k: arg0.keySet()) {
                put(k, arg0.get(k));
            }
        }
    }

    @Override
    public V remove(Object arg0) {
        list.remove(arg0);
        return super.remove(arg0);
    }

    public ArrayList<K> sequenceKeySet() {
        return list;
    }
}
