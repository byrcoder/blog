package toolbox.maintain.shared;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;

import odis.serialize.IWritable;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class WritableHashMap extends HashMap<String, String> 
        implements IWritable {
    private static final long serialVersionUID = 1305512061815705501L;

    public synchronized void writeFields(DataOutput out) throws IOException {
        out.writeInt(this.size());
        for (String key: keySet()) {
            out.writeUTF(key);
            out.writeUTF(get(key));
        }
    }

    public synchronized void readFields(DataInput in) throws IOException {
        int size = in.readInt();
        for (int idx = 0; idx < size; idx++) {
            put(in.readUTF(), in.readUTF());
        }
    }

    public synchronized IWritable copyFields(IWritable value) {
        clear();
        WritableHashMap other = (WritableHashMap) value;
        for (String key: other.keySet()) {
            if (key != null) {
                String v = other.get(key);
                if (v != null) {
                    put(key, v);
                }
            }
        }
        return this;
    }
    
    /**
     * formate as
     * <item>
     *   <key>value</key>
     * <item>
     *
     */
    public String toXml() {
        String xml = "<item>\n";
        for (String key: keySet()) {
            xml += "<" + key + ">"  + get(key) + "</" + key + ">\n";
        }
        xml += "</item>";
        return xml;
    }
    
    /**
     * parse xml like:
     * <code>
     * <?xml version="1.0" encoding="utf-8" ?>
     * <root>
     *   <item>
     *      <key>value</key>
     *   </item>
     * </root>
     * </code>
     * @param xml
     * @return
     * @throws DocumentException 
     * @throws IOException 
     * @throws IOException 
     */
    public static WritableHashMap parseXml(String xml) throws DocumentException, IOException {
        WritableHashMap map = new WritableHashMap();
        SAXReader reader = new SAXReader();
        Document document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
        Element item = document.getRootElement().element("item");
        for (Object obj: item.elements()) {
            Element element = (Element) obj;
            map.put(element.getName(), element.getText());
        }
        return map;
    }
}
