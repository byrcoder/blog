package toolbox.maintain.alarm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Send msg to some group. You need to regiest ur mobile here:
 * http://sms.corp.yodao.com:8080/group
 * @author yaming
 * @author neat
 */
public class SmsSender {

    private static String address = "http://sms.corp.yodao.com:8080";

    public static void send(String group[], String message) {
        try {
            for (String item: group) {
                URL url = new URL(getSendUrl(item, message));
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(url.openStream()));
                String s = "";
                StringBuffer sb = new StringBuffer();
                while ((s = br.readLine()) != null) {
                    sb.append(s + "\n");
                }
                br.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getSendUrl(String group, 
            String message) throws UnsupportedEncodingException {
        message = URLEncoder.encode(message, "UTF-8");
        message = message.replace("+", "%20");
        String url = address + "/sms?group="+ group + "&message=" + message;
        System.out.println(url);
        return url;
    }

    public static void main(String[] args) throws Exception {
        SmsSender.send(new String[] {
            "manager"
        }, "DataExchangeSuccess!");
    }
}
