package toolbox.maintain.bash;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;

/**
 * read out stream and err stream of bash
 */
public class BashStreamReader extends Thread {
    private OutputStream out;

    private BufferedReader reader;

    private boolean cancel = false;

    private StringBuilder sb = new StringBuilder();

    public BashStreamReader(OutputStream out, InputStream inputStream) {
        this.out = out;
        reader = new BufferedReader(new InputStreamReader(inputStream));
    }

    public void run() {
        if (reader != null) {
            try {
                while (!cancel) {
                    String line = reader.readLine();
                    if (line == null)
                        break;
                    output(line);
                    sb.append(line + "\n");
                }
            } catch (IOException e) {
                e.printStackTrace(new PrintStream(out));
            } finally {
                try {
                    reader.close();
                } catch (IOException e) {}
            }

        }
    }

    public synchronized void output(final String line) {
        try {
            String withenter = line + "\n";
            out.write(withenter.getBytes(), 0, withenter.length());
            out.flush();
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public String getInfo() {
        return sb.toString();
    }

    public boolean isCancel() {
        return cancel;
    }

    public void setCancel(boolean cancel) {
        this.cancel = cancel;
    }

}
