/**
 * @(#)KeyValueCache.java, 2012-7-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.rpc2.RpcException;
import odis.serialize.IWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;

/**
 *
 * @author wangfk
 *
 */
public class KeyValueCache<V extends IWritable>  {
    private GlobalCache cache;

    public KeyValueCache() {
        this.cache = GlobalCache.getInstance();
    }

    /**
     * @param key
     * @return null if not exists
     * @throws RpcException
     * @throws AccException
     */
    public V get(String key, V value) throws RpcException, AccException {
        byte[] bytesValue = cache.get(key);
        return bytesToWritable(bytesValue, value);
    }

    public void put(String key, V value
            ) throws RpcException, AccException {
        
        byte[] bytes = writableToBytes(value);
        cache.put(key, bytes);
    }

    /**
     * @param key
     * @return the value to be removed, return null if not exists
     * @throws RpcException
     * @throws AccException
     */
    public V remove(String key, V value) throws RpcException, AccException {
        byte[] bytesValue = cache.remove(key);
        return bytesToWritable(bytesValue, value);
    }

    private V bytesToWritable(byte[] bytesValue, V value) throws AccException {
        if (bytesValue == null || value == null) {
            return null;
        }
        try {

            value.readFields(new CDataInputStream(
                    new ByteArrayInputStream(bytesValue)));
        } catch (Exception e) {
            throw new AccException(e, AccExpType.UNKNOWN_EXCEPTION);
        }
        return value;
    }

    private byte[] writableToBytes(IWritable value) throws AccException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            value.writeFields(new CDataOutputStream(os));
        } catch (IOException e) {
            throw new AccException(e, AccExpType.UNKNOWN_EXCEPTION);
        }
        return os.toByteArray();
    }
}
