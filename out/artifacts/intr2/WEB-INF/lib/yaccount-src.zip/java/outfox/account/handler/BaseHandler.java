/**
 * @(#)BaseHttpHandler.java, 2011-9-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.FORMAT;
import outfox.account.data.AuthInfo;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;
import outfox.account.utils.SecurityUtils;
import outfox.account.utils.xss.XssUtils;
import toolbox.misc.net.UrlUtils;


/**
 * only get servlet context
 * 
 * @author wangfk
 * @modifier chen-chao
 */
public class BaseHandler extends HttpServlet{
    private static final long serialVersionUID = 3517934144636588279L;
    public static final String NO_MISS = ReqUtils.NO_MISS;
    protected static final Log LOG = LogFactory.getLog(BaseHandler.class);
    public BaseHandler() {
        LOG.info(this.getClass().getName() + " init.");
    }
    protected void setName(HttpServletRequest req, String name) {
        req.setAttribute(AccConst.REQUEST_NAME, name);
    }
    
    protected void setErrorAttribute(HttpServletRequest req) {
        req.setAttribute(AccConst.ATTR_FORMAT, req.getParameter(AccConst.PARAM_FORMAT));
        req.setAttribute(AccConst.ATTR_DISPLAY_NAME, req.getParameter(AccConst.PARAM_DISPLAY_NAME));
        req.setAttribute(AccConst.ATTR_HTTP_STATUS, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    protected void setErrorAttribute(HttpServletRequest req, HttpStatus stat) {
        req.setAttribute(AccConst.ATTR_FORMAT, req.getParameter(AccConst.PARAM_FORMAT));
        req.setAttribute(AccConst.ATTR_DISPLAY_NAME, req.getParameter(AccConst.PARAM_DISPLAY_NAME));
        req.setAttribute(AccConst.ATTR_HTTP_STATUS, stat);
    }
    
    protected void write(HttpServletRequest req, HttpServletResponse resp, Map<String, Object> params, HttpStatus stat) throws AccException {
        BaseHandler.write(req, resp, AuthUtils.getReqVal(req, AccConst.PARAM_FORMAT), AuthUtils.convertMap2List(params), stat);
    }
    
    protected static void write(HttpServletRequest req, HttpServletResponse resp, HttpStatus stat, List<Parameter> params) throws AccException {
        BaseHandler.write(req, resp, AuthUtils.getReqVal(req, AccConst.PARAM_FORMAT), params, stat);
    }
    
    protected void write(HttpServletRequest req, HttpServletResponse resp, List<Parameter> params, HttpStatus stat) throws AccException {
        BaseHandler.write(req, resp, AuthUtils.getReqVal(req, AccConst.PARAM_FORMAT), params, stat);
    }
    
    protected void writeJSON(HttpServletRequest req, HttpServletResponse resp, JSONObject obj, HttpStatus stat) throws AccException {
        req.setAttribute(AccConst.ATTR_RESULT, obj);
        AuthUtils.writeJSONChunked(resp, obj, stat);
    }
    private static final String WRITE_BYTES = "write bytes [**] %s";
    protected void write(HttpServletRequest req, HttpServletResponse resp, FORMAT format, byte[] data, HttpStatus stat) throws AccException {
        long len = 0;
        if (data != null) {
            len = data.length;
        }
        req.setAttribute(AccConst.ATTR_RESULT, String.format(WRITE_BYTES, len));
        switch(format) {
            case image:
                AuthUtils.writeImageChunked(resp, data, stat);
                break;
            default:
                throw new AccException("format:" + format + " is not supported or UPPERCASE?", AccExpType.NOT_SUPPORT);  
        }
    }
    
    protected String getQueryUrl(HttpServletRequest req) {
        return SecurityUtils.escapeSecurityQuery(req);
    }
    
    protected static void write(HttpServletRequest req, HttpServletResponse resp, String format, List<Parameter> params, HttpStatus stat) throws AccException {
        FORMAT form = FORMAT.json.defaultValueOf(format);
        req.setAttribute(AccConst.ATTR_RESULT, params);
        switch(form) {
            case json:
                AuthUtils.writeJSONChunked(resp, params2JSON(params), stat);
                break;
            case plain:
                AuthUtils.writePlainChunked(resp, params2Plain(params), stat);
                break;
            case html:
                AuthUtils.writeHTMLChunked(resp, params2Html(params), stat);
                break;
            case jsjson:
                AuthUtils.writeJSChunked(resp, params2JSON(params).toString(), stat);
                break;
            case jsplain:
                AuthUtils.writeJSChunked(resp, params2Plain(params), stat);
                break;
            
            default:
                throw new AccException("format:" + format + " is not supported or UPPERCASE?", AccExpType.NOT_SUPPORT);
                /*
                 * no break
                 */
        }
    }
    
    protected void writeJSON(HttpServletResponse resp, String format, JSONObject obj, HttpStatus stat) throws AccException {
        FORMAT form = FORMAT.json;
        try {
            form = FORMAT.valueOf(format);
        } catch(Exception e) {
            LOG.warn("format:" + format +" is not supported. using json default");
        }
        switch(form) {
            case json:
                AuthUtils.writeJSONChunked(resp, obj, stat);
                break;
            case jsjson:
                AuthUtils.writeJSChunked(resp, obj.toString(), stat);
                break;
            default:
                throw new AccException("format:" + format + " is not supported or UPPERCASE?", AccExpType.NOT_SUPPORT);
                /*
                 * no break
                 */
        }
    }
    
    protected static JSONObject params2JSON(List<Parameter> params) {
        JSONObject obj = new JSONObject(); 
        if (params != null) {
            for (Parameter p : params) {
                obj.put(p.getKey(), p.getValue());
            }
        }
        
        return obj;
    }
    
    protected static String params2Plain(List<Parameter> params) {
        
        if (params != null) {
            StringBuilder sb = new StringBuilder();
            for (Parameter p : params) {
                sb.append(p.getKey()).append("=").append(p.getValue()).append(";");
            }
            return sb.toString();
        }
        return AccConst.BLANK_STRING;
    }
    
    /**
     * if no html param, it will return null
     * @param params
     * @return
     * @throws AccException 
     */
    protected static String params2Html(List<Parameter> params) throws AccException {
        if (params != null) {
            String content = null;
            for (Parameter p : params) {
                if (AccConst.HTML_CONTENT.equals(p.getKey())) {
                    // html content;
                    content = p.getStrVal();
                    break;
                } 
            }
            for (Parameter p : params) {
                
                final String key = p.getKey();
                String strVal = p.getStrVal();
                if (key.startsWith("xss")){
                    strVal = XssUtils.filterXSS(strVal);
                }
                content = content.replaceAll(AccConst.HTML_TOKEN + key + AccConst.HTML_TOKEN, strVal);
            }
            return content;
            
        }
        return AccConst.BLANK_STRING;
    }
    
    /**
     * check login
     * @param req
     * @return
     * @throws AccException
     */
    protected AuthInfo checkLogin(HttpServletRequest req) throws AccException {
        AuthInfo authInfo = getLoginInfo(req);
        if (!authInfo.isLogin()) {
            throw new AccException("no token", AccExpType.NO_LOGIN);
        }
        return authInfo;
    }
    
    /**
     * check bind login
     * @param req
     * @return
     * @throws AccException
     */
    protected AuthInfo checkBindLogin(HttpServletRequest req) throws AccException {
        AuthInfo authInfo = getLoginInfo(req);
        if (!authInfo.isBind()) {
            throw new AccException("no bind", AccExpType.NO_BIND_AUTHORIZE);
        }
        return authInfo;
    }
    
    protected AuthInfo checkAuthorize(HttpServletRequest req) throws AccException {
        AuthInfo authInfo = getLoginInfo(req);
        if (!authInfo.isLogin() && !authInfo.isBind()) {
            throw new AccException("no bind or no login", AccExpType.NO_LOGIN);
        }
        return authInfo;
    }
    
    protected AuthInfo getLoginInfo(HttpServletRequest req) throws AccException {
        String product = AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME);
        AccConfig.checkProduct(product);
        
        SessionCookieWritable sess = ReqUtils.getSessionCookieWritable(req, product);
        PersistTokenWritable pers = ReqUtils.getPersTokenWritable(req, product);
        SessionCookieWritable bind = ReqUtils.getBindCookieWritable(req, product);
        UserInfoWritable userinfo = ReqUtils.getUserInfo(req, product);
        String userId = ReqUtils.getUserIdByProduct(req, product);
        String bindUserId = ReqUtils.getBindUserIdByProduct(req, product);
        return new AuthInfo(product, sess, pers, bind, userinfo, userId, bindUserId);
    }
    
    /**
     * check parameter
     * @param req
     * @param paramKey
     * @param target
     * <li>
     * targe is null, the parameter should not exist;
     * </li><li>
     * target is "NO_MISS", the parameter should not miss;
     * </li><li>
     * target is other case, the parameter should be equal with the target string.
     * </li>
     * @throws AccException
     */
    protected void checkParam(HttpServletRequest req, String paramKey, String target) throws AccException {
        ReqUtils.checkParam(req, paramKey, target);
    }
    /**
     * check header
     * @param req
     * @param headkey
     * @param target
     * <li>
     * targe is null, the parameter should not exist;
     * </li><li>
     * target is "NO_MISS", the parameter should not miss;
     * </li><li>
     * target is other case, the parameter should be equal with the target string.
     * </li>
     * @throws AccException
     */
    protected void checkHeader(HttpServletRequest req, String headKey, String target) throws AccException {
        ReqUtils.checkHeader(req, headKey, target);
    }
    
    protected void checkParamOrHeader(HttpServletRequest req, String key, String target) throws AccException {
        ReqUtils.checkParamOrHeader(req, key, target);
    }
    
    protected void checkOauth2AccessToken(HttpServletRequest req, String headerKey, String target) throws AccException {
        String header = req.getHeader(headerKey);
        if (header == null) {
            throw new AccException("Access token is error.", AccExpType.FAKE_TOKEN);
        } 
        System.out.println(header);
        String[] info = header.split(" ");
        if (info.length != 2 || !info[1].equals(target) || !info[0].equals("OAuth2")) {
            throw new AccException("Access token is error.", AccExpType.FAKE_TOKEN);
        }
    }
    
    /**
     * check wether the request is https or not
     * @param req
     * @throws AccException
     */
    protected void checkHttpsProtocal(HttpServletRequest req) throws AccException {
        AuthUtils.checkHttpsProtocal(req);
    }
    
    /**
     * check request method
     * @param req
     * @throws AccException
     */
    protected void checkReqMethod(HttpServletRequest req, RequestMethod method) throws AccException {
        if (!req.getMethod().equalsIgnoreCase(method.name())) {
            throw new AccException("not support request method" + req.getMethod(), AccExpType.NOT_SUPPORT);
        }
    }
    
    protected void safeRedirect(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        safeRedirect(req, resp, "");
    }
    /**
     * Redirect using url indicated by parameter 'ru', otherwise use given default redirect url.
     * @param req
     * @param resp
     * @param defaultRedirectURL
     * @throws AccException
     */
    public static void safeRedirect(HttpServletRequest req, HttpServletResponse resp, 
            String defaultRedirectURL) throws AccException {
        String ru = AuthUtils.getReqVal(req, AccConst.PARAM_REDIRECT_URL_NAME, 
                defaultRedirectURL);
        ru = AuthUtils.addScheme(req, ru, null);
        safeRedirect(ru, resp);
    }
    
    /**
     * Redirect after checking redirect url's domain.
     * @param redirectUrl
     * @param resp
     * @throws AccException
     */
    public static void safeRedirect(String redirectUrl, HttpServletResponse resp) 
        throws AccException {
        String domain = UrlUtils.getDomainFromUrl(redirectUrl);
        if (!AccConfig.isTestCaseMode() && isNotSubDomain(domain)){
            throw new AccException(AccExpType.LOGIC_ERROR, "redirect url %s, " +
            		"domain is %s. domain error.", redirectUrl, domain);
        }
        redirect(resp, redirectUrl);
    }
    
    protected void redirect(HttpServletRequest req, HttpServletResponse resp, String defaultRedirectURL) throws AccException{
        redirect(req, resp, defaultRedirectURL, null);
    }

    protected void redirect(HttpServletRequest req, HttpServletResponse resp, String defaultRedirectURL, String scheme)
            throws AccException {
        String ru = AuthUtils.getReqVal(req, AccConst.PARAM_REDIRECT_URL_NAME, defaultRedirectURL);
        ru = AuthUtils.addScheme(req, ru, scheme);
        redirect(resp, ru);
    }
    
    private static void redirect(HttpServletResponse resp, String ru) throws AccException {
        try {
            ru = ru.replaceAll("\r", "").replaceAll("\n", "");
            resp.sendRedirect(ru);
            LOG.info("send redirect to "+ru);
        } catch (IOException e) {
            throw new AccException(
                    AccExpType.REDIRECT_URL_ERROR, e , "redirect url: %s error.",ru);
        }
    }
    
    public static final String NETEASE_DOMAIN = "163.com";
    public static final String YOUDAO_DOMAIN = "youdao.com";
    private static boolean isNotSubDomain(String domain) {
        return !AuthUtils.isSubDomain(domain, NETEASE_DOMAIN)
                && !AuthUtils.isSubDomain(domain, YOUDAO_DOMAIN);
    }
    
    protected boolean getParamBoolean(FilterConfig conf, String key, boolean defaultVal) {
        String value = getParamStr(conf, key, null);
        if (StringUtils.isBlank(value)) {
            return defaultVal;
        }
        try {
            return Boolean.parseBoolean(value);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    protected String getParamStr(FilterConfig conf, String key, String defaultVal) {
        String value = conf.getInitParameter(key);
        if (StringUtils.isBlank(value)) {
            return defaultVal;
        }
        return value;
    }
    
    protected static String generateRedirectUrl(String redirectUrl, String product, String tp, boolean success, Map<String, Object> result) throws AccException {
        LOG.info("login goto register.");
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, tp));
        params.add(new Parameter(AccConst.PARAM_SUCCESS, success));
        if (result != null) {
            String returnStr = (String)result.get(AccConst.RETURN_STR);
            Map<String,String> map = AuthUtils.parseQuery(returnStr);
            for (Entry<String,String> entry : map.entrySet()) {
                params.add(new Parameter(entry.getKey(), entry.getValue()));
            }
        }
        return AuthUtils.composeQueryUrl(redirectUrl, params);
    }
    
    protected void replyOK(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        JSONObject obj = new JSONObject();
        obj.put(AccConst.OPERATION_SUCCESS, true);
        writeJSON(req, resp, obj, HttpStatus.OK);
    }
    
    protected String getUserId(Map<String, Object> authResMap) {
        if (authResMap != null) {
            return (String)authResMap.get(AccConst.USER_ID);
        }
        return null;
    }
}
