package outfox.account.conf;

import java.io.File;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.AccountRPCServer;
import outfox.account.server.ch.YMaster;

/**
 * This class is for setting home property and velocity path. It extends from
 * ServletContextListener, so every configuration of ydrive will be configured,
 * like "omap".
 * 
 * @author chen-chao
 */
public class ContextListener implements ServletContextListener {
    private static final Log LOG = LogFactory.getLog(ContextListener.class);

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Account ContextListener init....");
        // init ServletContextListener
        String realPath = sce.getServletContext().getRealPath(
                "WEB-INF");
        
        File log4jFile = new File(realPath + "/conf", "log4j.properties");
        System.out.println("Read log4j.propeties at" + log4jFile.getAbsolutePath());
        PropertyConfigurator.configureAndWatch(log4jFile.getAbsolutePath());
        System.setProperty(AccConst.ACCOUNT_HOME, realPath);
        LOG.info("Set yaccount.home=" + realPath);
        AccConfig.init(realPath);
        LOG.info("DONE: AccountServer Config init.");
        
        // Create new zookeeper connection, compete to be the active consistent
        // hash manager. If success, register ConsistentHashManager as zookeeper
        // listener, otherwise, wait for the active manager to die and complete
        // again.
        try {
            YMaster consistentHashMaster = new YMaster();
            consistentHashMaster.start();
        } catch (AccException e) {
            throw new AccRunTimeException("YMaster init failed.", e);
        }
        
        // Create new zookeeper connection, register ConsistentHashAdjuster as zookeeper
        // listener.
        AccountRPCServer rpcServer = new AccountRPCServer();
        rpcServer.initConsistentHash();
        rpcServer.start();
        try {
            rpcServer.join();
        } catch (InterruptedException e) {
            LOG.fatal("AccountRPCServer init interrupted.", e);
        }
        LOG.info("DONE: AccountServer ContextListener init.");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // TODO Auto-generated method stub
        
    }
}
