/**
 * @(#)QConnVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Properties;

/**
 * @author wangzhen
 */
public class QConnVerifier extends QConnBaseVerifier {
    
    public static final String NAME = "cqq";

    public QConnVerifier(Properties props) {
        super(props, NAME);
    }
    
    @Override
    public String getVerifierName() {
        return NAME;
    }
}
