/**
 * @(#)BaiduVerifier.java, 2013-4-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 *
 * @author zhanglz
 *
 */
public class BaiduVerifier extends Oauth2Verifier {
    private static final String VERIFIER_NAME = "baidu";
    /**
     * Keys read from HttpRequest or written by HttpResponse
     */
    private static final String PARAM_NAME_ACCESS_TOKEN = "access_token";
    
    /**
     * Keys read from property files.
     */
    private static final String CONF_NAME_ACCOUNT_URL = "accountURL";
    
    /**
     * JSON keys returned by baidu open api
     */
    private static final String JSON_NAME_USER_ID = "userid";
    private static final String JSON_NAME_USER_NAME = "username";
    private static final String JSON_NAME_USER_PROTRAIT = "portrait";
    private static final String JSON_NAME_ERROR_CODE = "error_code";
    private static final String JSON_NAME_ERROR = "error";
    
    /**
     * one day
     */
    private static long DEFAULT_REFRESH_TIME_MILL = 24 * 60 * 60 * 1000L;
    private long configRefreshTimeInMill;

    /**
     * @param props
     * @param name
     */
    public BaiduVerifier(Properties props) {
        super(props, VERIFIER_NAME);
        configRefreshTimeInMill = getLongPros(props, 
                VERIFIER_NAME + VerifierConfConst.REFRESH_TIME_IN_MILLI, 
                DEFAULT_REFRESH_TIME_MILL);
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, 
            HttpServletResponse resp) throws AccException{
        // set query string to session for callback handler to get.
        OAuth2Utils.addQueryAttribute(req, resp);
        
        // prepare parameters to get authorization code.
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.RESPONSE_TYPE, 
                OAuthConstant.AUTHORIZED_CODE));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, 
                getAbsoluteCallbackUrl(req)));
        if (AuthUtils.isMobile(req)) {
            params.add(new Parameter(OAuthConstant.DISPLAY, 
                    OAuthConstant.DISPLAY_MODE_MOBILE));
        }
        //TODO: force login support for baidu?
        
        // set state code for callback to check.
        String stat = OAuth2Utils.genState(req);        
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, stat));
        
        // redirect
        if (AccConfig.isStressTest()) {
            stressRedirect(req, resp);
        } else {
            AuthUtils.redirect(resp, getAbsoluteAuthorizeUrl(), params);
        }
        return null;
    }
    
    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, 
            HttpServletResponse resp) throws AccException {
        String code = req.getParameter(OAuthConstant.OAUTH2_CODE);
        
        // prepare parameters.
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.GRANT_TYPE, 
                OAuthConstant.GRANT_TYPE_VALUE_AUTHOR_CODE));
        params.add(new Parameter(OAuthConstant.OAUTH2_CODE, code));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, 
                getAbsoluteCallbackUrl(req)));
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, secret));
        
        // get access token.
        JSONObject obj = AccHttpClient.getInstance().getJSON(Method.POST, 
                getAbsoluteAccessUrl(), null, params, null);
        disposeResponseError(obj);
        
        // set result into tpToken.
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(OAuthConstant.ACCESS_TOKEN, 
                obj.getString(OAuthConstant.ACCESS_TOKEN));
        // baidu tells us to refresh access token in expired_in seconds.
        // baidu access token will expire in ten years without refreshing access token.
        // so set expire time of tpToken to -1.
        result.put(OAuthConstant.REFRESH_TIME, getRefreshTimeInMilli(obj));
        result.put(OAuthConstant.REFRESH_TOKEN, 
                obj.getString(OAuthConstant.REFRESH_TOKEN));
        return result;
    }
    
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, 
            HttpServletResponse resp, String token, long expireTime) 
            throws AccException {
        // decode token to check signature and read persist cookie from Omap, 
        // which will be set into THIRD_PARTY_PERS_TOKEN 
        Map<String, Object> result = super.verifyAuthToken(req, resp, 
                token, expireTime);
        
        // get tpToken and set access token
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        TpToken tpToken = tokenWritable.getTpToken();
        
        // check if need to refresh access token.
        long refreshTime = Long.parseLong(tpToken.getProperty(
                OAuthConstant.REFRESH_TIME));
        if (tpToken.getCreateTime() + refreshTime <= System.currentTimeMillis()) {
            JSONObject obj = refreshAccessToken(tpToken.refresh);
            tpToken.token = obj.getString(OAuthConstant.ACCESS_TOKEN);
            tpToken.refresh = obj.getString(OAuthConstant.REFRESH_TOKEN);
            tpToken.setProperty(OAuthConstant.REFRESH_TIME, 
                    String.valueOf(getRefreshTimeInMilli(obj)));
            store.writePersToken(tpToken);
        }
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        thirdPartyTokens.put(AccConst.TOKEN, tpToken.token);
        
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        
        // TODO update userInfo in other thread
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        
        // update userInfo
        store.writeUserInfo(userInfo);
        
        // AccConst.THIRD_PARTY_PERS_TOKEN should not remove
        // has checked in third party, but now it is expired
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        return result;
    }
    
    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, 
            HttpServletResponse resp) throws AccException {
        String accessToken = (String) req.getAttribute(OAuthConstant.ACCESS_TOKEN);
        return getUserInfoByAccessToken(accessToken);
    }
    
    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens)
            throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", 
                    AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        String accessToken = thirdPartyTokens.get(AccConst.TOKEN);
        return getUserInfoByAccessToken(accessToken);
    }
    
    @Override
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo)
            throws AccException {
        Map<String,Object> newMap = new HashMap<String, Object>(authInfo);
        newMap.remove(OAuthConstant.ACCESS_TOKEN);
        newMap.remove(OAuthConstant.REFRESH_TOKEN);
        return newMap;
    }
    
    @Override
    public String getVerifierName() {
        return VERIFIER_NAME;
    }
    
    private UserInfoWritable getUserInfoByAccessToken(String accessToken) 
        throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(PARAM_NAME_ACCESS_TOKEN, accessToken));
        JSONObject responseObj = JSONObject.fromObject(AccHttpClient.getInstance().
                getString(Method.GET, getAbsoluteUrl(properties.get(
                        CONF_NAME_ACCOUNT_URL)), null, params, null));
        disposeResponseError(responseObj);
        UserInfoWritable userInfo = new UserInfoWritable();
        userInfo.originalId = responseObj.getString(JSON_NAME_USER_ID);
        //baidu{originalId}
        userInfo.userId = tpId2ownId(userInfo.originalId);
        userInfo.userName = responseObj.getString(JSON_NAME_USER_NAME);
        userInfo.imageUrl = responseObj.getString(JSON_NAME_USER_PROTRAIT);
        userInfo.from = getVerifierName();
        return userInfo;
    }
    
    private JSONObject refreshAccessToken(String refreshToken) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, appkey));
        params.add(new Parameter(OAuthConstant.GRANT_TYPE, 
                OAuthConstant.GRANT_TYPE_REFRESH));
        params.add(new Parameter(OAuthConstant.GRANT_TYPE_REFRESH, refreshToken));
        JSONObject result = AccHttpClient.getInstance().getJSON(Method.GET, 
                getAbsoluteAccessUrl(), null, params, null);
        disposeResponseError(result);
        return result;
    }
    
    private void disposeResponseError(JSONObject responseObj) throws AccException {
        if (responseObj.containsKey(JSON_NAME_ERROR_CODE)) {
            throw new AccException(responseObj.toString(), null, 
                    AccExpType.TP_ERROR, responseObj.getInt(JSON_NAME_ERROR_CODE));
        }
        
        if (responseObj.containsKey(JSON_NAME_ERROR)) {
            throw new AccException(responseObj.toString(), null, 
                    AccExpType.TP_ERROR, responseObj.getInt(JSON_NAME_ERROR));
        }
    }
    
    private long getRefreshTimeInMilli(JSONObject resObj) {
        long refreshTime = resObj.getLong(OAuthConstant.EXPIRES_IN) * 1000L;
        return configRefreshTimeInMill == -1 ? refreshTime : 
            Math.min(refreshTime, configRefreshTimeInMill);
    }
}
