/**
 * @(#)AccountRPCServer.java, 2012-8-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException.SessionExpiredException;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.protocol.ICacheService;
import outfox.account.rpc.protocol.IRpcVerifierService;
import outfox.account.rpc.protocol.impl.MemoryCacheService;
import outfox.account.rpc.protocol.impl.RpcVerifierService;
import outfox.account.server.ch.ConsistentHashAdjuster;
import outfox.account.server.zk.Serviceable;
import outfox.account.server.zk.ZooKeeperWatcher;

/**
 * @author chen-chao
 */
public class AccountRPCServer extends Thread implements Serviceable {
    private static final Log LOG = LogFactory.getLog(AccountRPCServer.class);
    private boolean start;

    public void setStart(boolean start) {
        this.start = start;
    }
    // Set when the rpc server is stopped
    private volatile boolean stopped = false;
    private int port;

    private List<Class<?>> protocols;

    private List<Object> impls;

    private int handlerCount;

    private int queueSize;

    private int maxConnPerClient;

    private long clientDisconnectTime;
    
    private ZooKeeperWatcher watcher;
    
    private AbstractRpcServer server = null;
    
    private AccountRPCServerWapper wapper = null;
    
    private ConsistentHashAdjuster hashCircleAdjuster = null;

    public AccountRPCServer(int port, List<Class<?>> protocols, List<Object> impls,
            int handlerCount, int queueSize, int maxConnPerClient,
            long clientDisconnectTime) {
        this.protocols = protocols;
        this.impls = impls;
        this.port = port;
        this.handlerCount = handlerCount;
        this.queueSize = queueSize;
        this.maxConnPerClient = maxConnPerClient;
        this.clientDisconnectTime = clientDisconnectTime;
        initConsistentHash();
    }
    
    public AccountRPCServer() {
        this.start = AccConfig.getPros().getBoolean(AccConfig.NAME_RPC_SERVICE_START);
        port = AccConfig.getPros().getInt(AccConfig.NAME_RPC_SERVICE_PORT);
        protocols = new ArrayList<Class<?>>();
        protocols.add(ICacheService.class);
        protocols.add(IRpcVerifierService.class);
        impls = new ArrayList<Object>();
        impls.add(MemoryCacheService.getInstance());
        impls.add(RpcVerifierService.getInstance());
        handlerCount = AccConfig.getPros().getInt(AccConfig.NAME_RPC_SERVICE_HANDLER_COUNT);
        queueSize = AccConfig.getPros().getInt(AccConfig.NAME_RPC_QUEUE_SIZE);
        maxConnPerClient = AccConfig.getPros().getInt(AccConfig.NAME_RPC_MAX_CONNECTION_PER_CLIENT);
        clientDisconnectTime = AccConfig.getPros().getLong(AccConfig.NAME_RPC_CLIENT_DISCONNECT_TIME);
    }
    
    public void initConsistentHash() {
        wapper = new AccountRPCServerWapper(this);
        int vnodeNum = AccConfig.getPros().getInt(
                AccConfig.NAME_HASH_VNODENUM);
        try {
            watcher = new ZooKeeperWatcher("AccountRPCServer", this);
        } catch (AccException e) {
            throw new AccRunTimeException("zookeeper watcher init failed.", e);
        }
        ServerAddress address = new ServerAddress("localhost", port);
        System.out.println("ADD rpc server "+address+" into consistentHash.");
        LOG.info("ADD rpc server "+address+" into consistentHash.");
        hashCircleAdjuster = new ConsistentHashAdjuster(this, address,
                watcher, vnodeNum);
        hashCircleAdjuster.start();
    }
    
    public AccountRPCServer(int port) {
        this();
        this.port = port;
        initConsistentHash();
    }

    public void run() {
        
        if (start) {
            server = RPC.getNIOServer(protocols, impls, port,
                    handlerCount, queueSize, maxConnPerClient,
                    clientDisconnectTime);
            try {
                server.start();
                stopped = false;
                LOG.info("RpcServer started on port " + port);
            } catch (IOException e) {
                LOG.fatal("RPC server error.", e);
            }
        }
    }
    
    public void stopServer() {
        stopped = true;
        if (server != null) {
            server.stop();
        }
        
        LOG.info("RpcServer ended");
    }
    
    public String getAddress() {
        return AccConst.LOCAL_HOST + ":" + port;
    }
    
    @Override
    public void interrupt() {
        super.interrupt();
        stopServer();
    }

    public int getPort() {
        return port;
    }

    @Override
    public ZooKeeperWatcher getZooKeeper() {
        return watcher;
    }

    @Override
    public void shutdown() {
        stopServer();
    }

    @Override
    public void recover(String why, Exception cause) {
        LOG.warn("Recover rpc server because " + why);
        if (cause != null && cause instanceof SessionExpiredException) {
            // restart accountRPC server
            wapper.init();
        } else {
            LOG.fatal("Could not recover from this kind of exception", cause);
        } 
    }

    @Override
    public void stop(String why) {
        stopServer();
    }

    @Override
    public boolean isStopped() {
        return stopped;
    }
}
