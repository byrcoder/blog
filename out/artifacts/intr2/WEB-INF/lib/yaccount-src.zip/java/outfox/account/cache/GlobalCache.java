/**
 * @(#)GlobalCacheHolder.java, 2012-8-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache;

import odis.rpc2.RpcException;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.rpc.client.RpcCacheClient;
import outfox.account.rpc.client.RpcClientFactory;
import outfox.account.rpc.protocol.ICacheService;

/**
 * FOR cross process. using RPC to connect multi-server cache.
 * @author chen-chao
 */
public class GlobalCache{
    private RpcCacheClient client;
    private static volatile GlobalCache instance = null;
    public RpcCacheClient getClient() {
        return client;
    }
    public static GlobalCache getInstance() {
        // XXX: here should only using double check (Instance Holder will create instance in other project (filter dependence).)
        if (instance == null) {
            synchronized (GlobalCache.class) {
                if (instance == null) {
                    instance = new GlobalCache();
                }
            }
        }
        return instance;
    }
    
    /**
     * this function for re-init rpc client, it will be used in testcase.
     */
    public void reInit() {
        client = (RpcCacheClient)RpcClientFactory.refresh(ICacheService.class);
    }
    
    private GlobalCache() {
        client = (RpcCacheClient)RpcClientFactory.getClient(ICacheService.class);
    }
    /**
     * only if RPC error, it will throw exception.
     * @param key
     * @return
     * @throws AccException
     */
    public byte[] get(String key) throws AccException {
        if (key == null) {
            return null;
        }
        try {
            ICacheService cacheService = client.lookup(key);
            return cacheService.getBytesValue(key);
        } catch(RpcException e) {
            throw new AccException("get key:"+key, AccExpType.SERVER_RPC_EXCEPTION);
        }
    }
    /**
     * only if RPC error, it will throw exception.
     * @param key
     * @return
     * @throws AccException
     */
    public void put(String key, byte[] value) throws AccException {
        if (key == null) {
            return;
        }
        try {
            ICacheService cacheService = client.lookup(key);
            cacheService.putBytesValue(key, value);
        } catch(RpcException e) {
            throw new AccException("put key:"+key,e, AccExpType.SERVER_RPC_EXCEPTION);
        }
    }
    /**
     * only if RPC error, it will throw exception.
     * @param key
     * @return
     * @throws AccException
     */
    public byte[] remove(String key) throws AccException {
        if (key == null) {
            return null;
        }
        try {
            ICacheService cacheService = client.lookup(key);
            return cacheService.removeBytesValue(key);
        } catch(RpcException e) {
            throw new AccException("remove key:"+key, AccExpType.SERVER_RPC_EXCEPTION);
        }
    }
}
