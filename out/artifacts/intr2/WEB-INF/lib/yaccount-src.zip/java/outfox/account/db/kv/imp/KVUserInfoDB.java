/**
 * @(#)OmapUserInfoDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;
import outfox.account.conf.AccConfig;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.in.IUserInfoDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class KVUserInfoDB extends BaseKVDB implements IUserInfoDB {
    private static final String STORE_NAME = "accUser";
    /**
     * key: userid 
     * value : UserInfoWritable
     */
    private static final String[] types = {
        "VINTSTRING",
        "CUSTOM(outfox.account.data.UserInfoWritable)"
    };
    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;
    
    @SuppressWarnings("unchecked")
    public KVUserInfoDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }
    @Override
    public UserInfoWritable write(UserInfoWritable userinfo) {
        if (userinfo == null) {
            return null;
        }
        StringWritable key = new StringWritable(userinfo.userId);
        try {
            kvStore.writeKeyValue(key, userinfo);
        } catch (AccException e) {
            e.printStackTrace();
        }
        return userinfo;
    }
    
    public UserInfoWritable read(String userId){
        UserInfoWritable value = new UserInfoWritable();
        try {
            if (kvStore.readValue(new StringWritable(userId), value)) {
                return value;
            } else {
                return null;
            }
        } catch (AccException e) {
            e.printStackTrace();
        }
        return null;
    }
}
