/**
 * @(#)RemoveMappingIteratorTask.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.db.DataStore;
import outfox.account.db.in.IUserMappingDB.IUserMappingIter;
import outfox.account.db.in.IteratorService;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class RemoveMappingIteratorTask extends AbstractIteratorTask<IUserMappingIter>{
    protected final DataStore store;
    public RemoveMappingIteratorTask(IteratorService<IUserMappingIter> dbIterService, DataStore store, String mainId) {
        super(dbIterService, mainId);
        this.store = store;
    }

    @Override
    protected void runTask(Object value) throws AccException {
        store.removeUserMapping((MainId2ShadowIdWritable)value);
    }

}
