package outfox.account.profile;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import org.springframework.stereotype.Repository;
import toolbox.cassandra.client.CassandraClient;
import toolbox.cassandra.client.exception.CassandraRuntimeException;
import toolbox.cassandra.client.exception.NotFoundException;
import toolbox.cassandra.client.protocol.Keyspace;
import toolbox.cassandra.client.protocol.Table;

import java.io.Closeable;
import java.io.IOException;

/**
 * profile相关信息的数据库读写
 *
 * @author yangzhe
 * @version created on 15-3-2.
 */
public class ProfileDAO implements Closeable {
    Keyspace keyspace;
    Session session;

    Table datatext;
    Table nickuserid;
    Table useridnick;

    public ProfileDAO() {
        try {
            keyspace = CassandraClient.getInstance(new QueryOptions().setConsistencyLevel(ConsistencyLevel.QUORUM))
                    .getKeyspace("dict_profile");
        } catch (NotFoundException e) {
            e.printStackTrace();
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
        session = keyspace.getGlobalSession();
        datatext = keyspace.openTable("datatext");
        nickuserid = keyspace.openTable("nickuserid");
        useridnick = keyspace.openTable("useridnick");
    }

    public String getTextValue(String userid, String key) throws CassandraRuntimeException {
        try {
            ResultSet resultSet = session.execute(datatext.selectBuilder().where(QueryBuilder.eq("userid", userid))
                    .and(QueryBuilder.eq("key", key)));
            Row row = resultSet.one();
            if (row == null) {
                return null;
            }
            return row.getString("value");
        } catch (Exception e) {
            e.printStackTrace();
            throw new CassandraRuntimeException(e);
        }
    }

    public String getNicknameByUserid(String userid) {
        ResultSet resultSet = session.execute(useridnick.selectBuilder().where(QueryBuilder.eq("userid", userid)));
        Row row;
        if ((row = resultSet.one()) != null) {
            return row.getString("nickname");
        }
        return null;
    }

    public String getUseridByNickname(String nickname) {
        ResultSet resultSet = session.execute(nickuserid.selectBuilder().where(QueryBuilder.eq("nickname", nickname)));
        Row row;
        if ((row = resultSet.one()) != null) {
            return row.getString("userid");
        }
        return null;
    }

    @Override
    public void close() throws IOException {
        try {
            CassandraClient.getInstance().close();
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
    }
}
