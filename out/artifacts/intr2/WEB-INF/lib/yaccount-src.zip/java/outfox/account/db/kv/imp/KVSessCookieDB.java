/**
 * @(#)OmapSessCookieDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.db.kv.IKeyValueStore.Iter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class KVSessCookieDB extends BaseKVDB implements ISessCookieDB {

    private static final String STORE_NAME = "accSess";

    /**
     * key: sessIndex 
     * value : SessionCookieWritable
     */
    private static final String[] types = {
        "VINTSTRING", "CUSTOM(outfox.account.data.SessionCookieWritable)"
    };

    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;

    @SuppressWarnings("unchecked")
    public KVSessCookieDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }

    @Override
    public SessionCookieWritable write(TpToken tp){
        if (tp == null) {
            return null;
        }
        StringWritable key = new StringWritable(tp.sessIndex);
        SessionCookieWritable value = new SessionCookieWritable(tp);
        try {
            kvStore.writeKeyValue(key, value);
        } catch (AccException e) {
            e.printStackTrace();
        }
        return value;
    }

    public SessionCookieWritable read(TpToken tpToken){
        if (tpToken == null) {
            return null;
        }
        return read(tpToken.sessIndex);
    }

    public SessionCookieWritable read(String sessIndex) {
        if (StringUtils.isBlank(sessIndex)) {
            return null;
        }
        SessionCookieWritable value = new SessionCookieWritable();
        try {
            if (kvStore.readValue(new StringWritable(sessIndex), value)) {
                return value;
            } else {
                return null;
            }
        } catch (AccException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void remove(TpToken tp){
        if (tp == null) {
            return;
        }
        remove(tp.sessIndex);
    }

    public void remove(String sessIndex){
        if (StringUtils.isBlank(sessIndex)) {
            return;
        }
        try {
            kvStore.deleteKey(new StringWritable(sessIndex));
        } catch (AccException e) {
            e.printStackTrace();
        }
    }

    /**
     * thread unsafe
     *
     * @author chen-chao
     *
     */
    private class KVSessCookieIter implements ISessCookieIter {
        private Iter<IWritableComparable, IWritable> iter = null;

        private IWritableComparable key = null;

        public KVSessCookieIter(String sessIndex) throws AccException {
            try {
                iter = kvStore.getIter();
                if (sessIndex == null) {
                    sessIndex = "";
                }
                key = new StringWritable(sessIndex);
                iter.seekTo(key, false);
            } catch (AccException e) {
                AuthUtils.disposeException(e, AccExpType.STORE_SERVICE_EXCEPTION);
            } 
        }

        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         * @throws AccException 
         */
        @Override
        public SessionCookieWritable next() throws AccException {
            SessionCookieWritable value = new SessionCookieWritable();
            if (!iter.next(key, value)) {
                return null;
            }
            return value;
        }

        @Override
        public void close() {
            AuthUtils.closeQuiet(iter);
        }
    }

    @Override
    public ISessCookieIter getIter(String sessIndex) throws AccException {
        return new KVSessCookieIter(sessIndex);
    }

    @Override
    public ISessCookieIter getIter(Object... startKeys) throws AccException {
        if (startKeys != null) {
            return getIter((String) startKeys[0]);
        }

        throw new AccException("no start keys", AccExpType.NOT_SUPPORT);
    }
}
