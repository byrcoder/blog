/**
 * @(#)ConsistentHash.java, 2010-7-21. 
 * 
 * 1. ignore hash collisions in the first version. 
 * 2. only support MD5 in the first version 
 * 3. only one thread of the Master will use this, so lock is unneeded now. 
 *                          
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package outfox.account.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import outfox.account.conf.AccConst;
import outfox.account.rpc.ServerAddress;

/**
 * @author konglh
 */
public class ConsistentHash implements Serializable {
    private static final long serialVersionUID = 1L;

    // Constants
    public static final int MD5_HASH = 0;       // MD5 Based
    public static final int MAX_HASH = 1;       // max idx of the hash function

    private int hashFunction;
    
    private int vnodeNum;                       // virtual node number of each server
    private long version = 0;   // version number of the current hashing data, starting from 0

    // Store the logic circle of the consistent hash, the entry format is <token, server>
    private TreeMap<BigInteger, String> circle = new TreeMap<BigInteger, String>();
    
    // the list of all the node's name
    private Set<String> nodeList = new TreeSet<String>();
    
    /**
     * used for deserialize
     */
    public ConsistentHash() {
        super();
        this.hashFunction = MD5_HASH;
    }

    /**
     * @param vnodeNum
     */
    public ConsistentHash(Integer vnodeNum) {
        super();
        this.vnodeNum = vnodeNum;
        this.hashFunction = MD5_HASH;
    }

    /**
     * @param vnodeNum
     * @param hashIdx
     */
    public ConsistentHash(Integer vnodeNum, int hashIdx) {
        super();
        this.vnodeNum = vnodeNum;
        if (hashIdx >= MAX_HASH) {
            hashIdx = MD5_HASH;
        }
        this.hashFunction = hashIdx;
    }

    /**
     * @param vnodeNum
     * @param nodes
     */
    public ConsistentHash(Integer vnodeNum, String[] nodes) {
        super();
        this.vnodeNum = vnodeNum;
        this.hashFunction = MD5_HASH;
        this.add(nodes);
    }

    /**
     * @param vnodeNum
     * @param hashIdx
     * @param nodes
     */
    public ConsistentHash(Integer vnodeNum, int hashIdx, String[] nodes) {
        super();
        this.vnodeNum = vnodeNum;
        if (hashIdx >= MAX_HASH) {
            hashIdx = MD5_HASH;
        }
        this.hashFunction = hashIdx;
        this.add(nodes);
    }
    
    /**
     * @param key the key you want to query
     * @return the node who is responsible for the given key
     */
    public String get(String key) {
        return get(this.calculateHash(key));
    }
    
    public long getVersion() {
        return this.version;
    }
    
    /**
     * Used to update the whole data and increment the version number
     * Just for ydrive system.
     * 
     * @param nodes 
     */
    public void update(List<ServerAddress> nodes) {
        ++this.version;
        this.clear();
        for (ServerAddress node: nodes) {
            this.add(node.toString());
        }
    }
    
    /**
     * Add all the given nodes to the circle, just for test
     * 
     * @param nodes
     */
    public void add(String[] nodes) {
        for (String node: nodes) {
            this.add(node);
        }
    }
    
    /**
     * wrapper for serialize
     * 
     * @return the serialize byte array of this object
     */
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        DataOutputStream dout = new DataOutputStream(bout);

        this.serialize(dout);
        
        dout.close();
        bout.close();

        return bout.toByteArray();
    }

    /**
     * wrapper for deserialize
     * 
     * @param data
     * @throws IOException
     */
    public void fromByteArray(byte[] data) throws IOException {
        ByteArrayInputStream bin = new ByteArrayInputStream(data);
        DataInputStream din = new DataInputStream(bin);
        
        this.deserialize(din);

        din.close();
        bin.close();
    }    
    
    /**
     * Dump the logic circle
     */
    public String dump() {
        BigInteger[] keyArray = new BigInteger[circle.keySet().size()];
        circle.keySet().toArray(keyArray);

        StringBuilder sb = new StringBuilder();

        sb.append("\n****** The consistent hash logic circle is :\n");
        for (BigInteger item: keyArray) {
            sb.append(item + "\t\t" + circle.get(item) + "\n");
        }
        sb.append("\n");
        
        return sb.toString();
    }
        
    /**
     * Add a node to the circle
     * 
     * @param node
     */
    protected void add(String node) {
        nodeList.add(node);
        for (int i = 0; i < vnodeNum; i++) {
            circle.put(calculateHash(node.toString() + i), node);
        }
    }    

    /**
     * Get the first available Node who has one token that is equal or just above
     * the given one in the circle
     * 
     * @param hashK
     * @return the node who is responsible for the given key
     */
    protected String get(BigInteger hashK) {
        if (circle.isEmpty()) {
            return null;
        }

        BigInteger key = findNodeFor(hashK);
        return circle.get(key);
    }

    /**
     * @return the logic circle of the consistent hashing, stored in a TreeMap
     */
    protected TreeMap<BigInteger, String> getCircle() {
        return circle;
    }

    /**
     * Remove a node from the circle,
     * 
     * @param node
     */
    protected void remove(String node) {
        nodeList.remove(node);
        for (int i = 0; i < vnodeNum; i++) {
            circle.remove(calculateHash(node.toString() + i));
        }
    }

    /**
     * Remove all the nodes from the circle,
     */
    protected void clear() {
        nodeList.clear();
        circle.clear();
    }
        
    /**
     * Serialize the nodes list to the stream, in the format:
     *  <len:nodeName>*
     * 
     * @param dos
     * @throws IOException
     */
    protected void serialize(DataOutput dos) throws IOException {
        dos.writeInt(this.hashFunction);
        dos.writeInt(this.vnodeNum);
        dos.writeLong(this.version);
        
        int machNum = this.circle.size() / this.vnodeNum;
        dos.writeInt(machNum);
        
        for (String node : nodeList) {
            byte[] data = node.getBytes("UTF-8");
            dos.writeInt(data.length);
            dos.write(data);
        }
    }

    protected boolean deserialize(DataInput dis) throws IOException {
        this.hashFunction = dis.readInt();
        this.vnodeNum = dis.readInt();
        this.version = dis.readLong();
        this.clear();
        
        int machNum = dis.readInt(); // nodes num

        for (int i = 0; i < machNum; i++) {
            int len = dis.readInt();
            byte[] data = new byte[len];
            dis.readFully(data);
            String node = new String(data, 0, data.length, AccConst.UTF8);  // hard decode

            this.add(node);
        }

        return true;
    }

    /**
     * Gets the first available key equal or above the given one, if none found,
     * returns the first k in the circle
     * 
     * @param hashK
     * @return the first available key equal or above the given one in the circle
     */
    private BigInteger findNodeFor(BigInteger hashK) {
        BigInteger k = circle.ceilingKey(hashK);

        if (k == null) {
            k = circle.firstKey();
        }

        return k;
    }

    /**
     * Calculates the MD5 hash value for a string
     * WARN: MessageDigest is not thread-safe, so we need to instantiate one instance for each query
     * 
     * @param key
     * @return the md5 hashing value of the key, in BigInteger format
     */
    private BigInteger md5HashingAlg(String key) {
        MessageDigest md5 = null;           // md5 object

        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("No md5 algorithm found");
        }
        
        md5.reset();
        md5.update(key.getBytes());
        BigInteger res = new BigInteger(md5.digest());

        return res;
    }

    /**
     * @param key
     * @return the hashing value of the key according to the given algorithm
     */
    private BigInteger calculateHash(String key) {
        switch (hashFunction) {
            case MD5_HASH:
                return md5HashingAlg(key);
            default:
                // use the md5 hash as default
                return md5HashingAlg(key);
        }
    }
}
