/**
 * @(#)IUserMappingDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.db.in.IUserMappingDB.IUserMappingIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IUserMappingDB extends IteratorService<IUserMappingIter>{
    public MainId2ShadowIdWritable readOne(String userId) throws AccException;
    public MainId2ShadowIdWritable read(String userId, Long timestamp) throws AccException;
    public MainId2ShadowIdWritable readShadow(String shadowId) throws AccException;
    public void write(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException; 
    public void remove(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException;
    public void removeMainOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException;
    public void removeShadowOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException;
    public void writeMainOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException;
    public void writeShadowOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException;
    public interface IUserMappingIter extends Iterator<MainId2ShadowIdWritable>{
        public MainId2ShadowIdWritable next() throws AccException;
        public void close();
    }
    public IUserMappingIter getIter(String userId) throws AccException;
    public IUserMappingIter getIter(String userId, Long timestamp) throws AccException;
}
