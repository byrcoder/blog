/**
 * @(#)IVerifier.java, 2012-9-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IVerifier {
    /**
     * get verifier name
     * @return
     */
    public String getVerifierName();
    
    /**
     * get authorize request, the function will connect will the third party. It will return JSONObject back. 
     * Or redirect to third party page and return null back.  
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    public Map<String,Object> authRequest(HttpServletRequest req, HttpServletResponse resp)throws AccException;
    /**
     * this function is only used in callback handler
     * get user information from third party
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp)throws AccException;
    
    /**
     * verifier the request is valid to call third party API. 
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    public Map<String,Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp)throws AccException;
    
    /**
     * encode TpToken to a string, which will be used in header or cookie
     * 
     * @param tpToken
     * @return
     * FORMAT:
     * verifierName|product|app|expire-time|create-time|ip|userId|verifierSpecialInfo|signature
     * @throws AccException
     */
    public String encode(TpToken tpToken) throws AccException;
    /**
     * encode TpToken to a string, which will be used in header or cookie
     * FORMAT:
     * verifierName|product|app|expire-time|create-time|ip|userId|verifierSpecialInfo|signature
     * @param tpToken
     * @return
     * @throws AccException
     */
    public TpToken decode(String tpToken) throws AccException;
    
    /**
     * encode TpToken to a string, which will be used in header or cookie
     * FORMAT:
     * verifierName|product|app|expire-time|create-time|ip|userId|signature
     * @param tpToken
     * @return
     * @throws AccException
     */
    public TpToken decode(TpToken tpToken) throws AccException;
    
    /**
     * String convert third-party id to our project id
     * @param id
     * @return
     * @throws AccException 
     */
    public String tpId2ownId(String id) throws AccException;
    
    /**
     * get third-party from own id 
     * @param id
     * @return
     * @throws AccException 
     */
    public String ownId2tp(String ownId) throws AccException;
    
    /**
     * verifier the request is valid to call third party API. 
     * @param req TODO
     * @param resp TODO
     * @param token
     * @param expiredTime
     * @return
     * @throws AccException
     */
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expiredTime)
            throws AccException;
    
    public Map<String, Object> verifyAuthToken(Map<String, Object> information, String token, long expiredTime)
            throws AccException;
    
    public String getProduct();
    
    public void remove(TpToken tpToken) throws AccException;
    
    /**
     * only used in stress test
     * @return
     */
    public UserInfoWritable genStressUser();
    
    /**
     * only used in stress test
     * @return
     */
    public Map<String, Object> genStressAuthInfo();
    
    /**
     * only used in stress test
     * @return
     */
    public Map<String,Object> stress(HttpServletRequest req, HttpServletResponse resp) throws AccException;
    
    /**
     * only used in stress test
     * @throws AccException 
     */
    public void stressRedirect(HttpServletRequest req, HttpServletResponse resp) throws AccException;
    
    /**
     * milli-seconds
     * @return
     */
    public long getSessAliveTime();
}
