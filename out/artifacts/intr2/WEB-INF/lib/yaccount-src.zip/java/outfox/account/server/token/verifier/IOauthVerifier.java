/**
 * @(#)IOauthVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IOauthVerifier extends ITokenVerifier {
    /**
     * get authorize information from third party API (include access token). 
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp)throws AccException;
    
    /**
     * remove authorize token/ secret/ refresh token.
     * @param authTokens
     * @return
     * @throws AccException
     */
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException;
    
    /**
     * @param thirdPartyTokens
     * @return
     * @throws AccException
     */
    public  UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens)throws AccException;
}
