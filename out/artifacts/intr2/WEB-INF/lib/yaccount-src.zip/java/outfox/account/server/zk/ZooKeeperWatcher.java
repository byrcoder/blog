/**
 * @(#)ZooKeeperWatcher.java, 2011-7-4. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.zk;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.SessionExpiredException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.ZKUtils;


/**
 * Acts as the single ZooKeeper Watcher.  One instance of this is instantiated
 * for each Master, Store Server, and RPC Data Store process.
 *
 * <p>This is the only class that implements {@link Watcher}.  Other internal
 * classes which need to be notified of ZooKeeper events must register with
 * the local instance of this watcher via {@link #registerListener}.
 *
 * <p>This class also holds and manages the connection to ZooKeeper.  Code to
 * deal with connection related events and exceptions are handled here.
 *
 * @author licx
 */
public class ZooKeeperWatcher implements Watcher {
    private static final Log LOG = LogFactory.getLog(ZooKeeperWatcher.class);

    // Identifiier for this watcher (for logging only).
    private String identifier;

    // Service associated with zookeeper
    private Serviceable service;

    // zookeeper quorum servers
    private String quorum;

    // zookeeper connection
    private ZooKeeper zooKeeper;

    // whether the zookeeper is connected, set to false if a Disconnected
    // event is received
    AtomicBoolean connected = new AtomicBoolean(false);

    // listeners to be notified
    private final List<ZooKeeperListener> listeners =
        new CopyOnWriteArrayList<ZooKeeperListener>();

    // the root node for current cluster
    public final String rootZNode;
    // the directory that including all the Account Servers
    public final String accountServerDirZNode;
    // znode containing the master address
    public final String masterAddressZNode;
    // znode containing the Consistent Hash data
    public final String consistentHashZNode;

    /**
     * @param descriptor descriptor of this ZooKeeper watcher, will be used
     * in logging
     * @throws YDriveDistributeServiceException 
     */
    public ZooKeeperWatcher(String descriptor, Serviceable service)
            throws AccException {
        this.quorum = AccConfig.getPros().getString(
                        AccConfig.NAME_ZK_SERVER_NODE);
        if (StringUtils.isBlank(quorum)) {
            throw new AccException(AccConfig.NAME_ZK_SERVER_NODE + " is error.");
        }
        quorum = quorum.replace(";", ",");
        this.identifier = descriptor;
        this.service = service;
        // root znode is in the format of "ynote-{RPC Version}"
        // so different versions of store server would register in different
        // znode tree
        String rootPrefix = AccConfig.getPros().getString(
                AccConfig.NAME_ZK_ZNODE_ROOT);
        this.rootZNode = rootPrefix + "-" + AccConst.VERSION;
        this.accountServerDirZNode = ZKUtils.joinZNode(rootZNode,
                AccConfig.getPros().getString(
                        AccConfig.NAME_ZK_ZNODE_ACCOUNT_SERVER));
        this.masterAddressZNode = ZKUtils.joinZNode(rootZNode,
                AccConfig.getPros().getString(
                        AccConfig.NAME_ZK_ZNODE_MASTER)); 
        this.consistentHashZNode =ZKUtils.joinZNode(rootZNode,
                AccConfig.getPros().getString(
                        AccConfig.NAME_ZK_ZNODE_HASH));
        buildZKConnection();
    }

    /**
     * Builds ZooKeeper connection as well as creates the necessary znodes
     * in ZooKeeper. If these znodes already exist, just fail silently, this
     * will ensure the existence of necessary znodes.
     * @throws KeeperException if fail to build zk connection
     *
     */
    private void buildZKConnection() throws AccException {
        try {
            int timeout = AccConfig.getPros().getInt(
                    AccConfig.NAME_ZK_SESSION_TIMEOUT);
            this.zooKeeper = ZKUtils.connect(quorum, timeout, this, identifier);
            ZKUtils.createPersistentAndFailSilent(this, rootZNode, new byte[0]);
            ZKUtils.createPersistentAndFailSilent(this, accountServerDirZNode, new byte[0]);
            ZKUtils.createPersistentAndFailSilent(this, consistentHashZNode, null);
        } catch (IOException e) {
            throw new AccException(prefix("Fail to " + "connect ZooKeeper with quorum: " + quorum), e,
                    AccExpType.DISTRIBUTE_SERVICE_EXCEPTION);
        } catch (KeeperException e) {
            throw new AccException(prefix("Fail to " + "create necessary znodes"), e,
                    AccExpType.DISTRIBUTE_SERVICE_EXCEPTION);
        }
    }

    /**
     * Get the connection to ZooKeeper.
     * @return connection reference to zookeeper
     */
    public ZooKeeper getZooKeeper() {
        return zooKeeper;
    }

    /**
     * Register the specified listener to receive ZooKeeper events.
     * @param listener
     */
    public void registerListener(ZooKeeperListener listener) {
        listeners.add(listener);
    }

    /**
     * Remove the specified listener so that it would not receive any
     * ZooKeeper events.
     * @param listener
     */
    public void removeListener(ZooKeeperListener listener) {
        listeners.remove(listener);
    }

    /**
     * Method called from ZooKeeper for events and connection status.
     * <p>
     * Valid events are passed along to listeners.  Connection status changes
     * are dealt with locally.
     */
    @Override
    public void process(WatchedEvent event) {
        LOG.debug(prefix("Received ZooKeeper Event, type=" + event.getType() +
                ", state=" + event.getState() + ", path=" + event.getPath()));

        switch (event.getType()) {
            // If event type is NONE, this is a connection status change
            case None: {
                processStateEvent(event);
                break;
            }
            // Otherwise pass along to the listeners
            case NodeCreated: {
                for (ZooKeeperListener listener: listeners) {
                    listener.nodeCreated(event.getPath());
                }
                break;
            }
            case NodeDeleted: {
                for (ZooKeeperListener listener: listeners) {
                    listener.nodeDeleted(event.getPath());
                }
                break;
            }
            case NodeDataChanged: {
                for (ZooKeeperListener listener: listeners) {
                    listener.nodeDataChanged(event.getPath());
                }
                break;
            }
            case NodeChildrenChanged: {
                for (ZooKeeperListener listener: listeners) {
                    listener.nodeChildrenChanged(event.getPath());
                }
                break;
            }
        }
    }

    /**
     * Called when there is a connection-related event via the Watcher callback.
     *
     * <p>If Disconnected, a count down timer would be started and this
     * instance would be closed if ZooKeeper does not come back in a given
     * interval.
     *
     * <p>If SyncConnected, disconnected count down timer would be interrupted
     * and ZooKeeper status is back to normal.
     *
     * <p>If Expired, a new ZooKeeper session would be created to recover
     * the service. See the implementations of <code>Recoverable</code>.
     *  
     * @param event
     */
    protected void processStateEvent(WatchedEvent event) {
        switch (event.getState()) {
            case SyncConnected:
                LOG.info(prefix("Sync connected with the zookeeper, " +
                    "might be a temporary connection failure or " +
                    "a new ZK session is established"));
                synchronized (connected) {
                    connected.set(true);
                    connected.notifyAll();
                }
                // sometimes the service might be stopped when the ZKDisconnectTimer
                // timeout while the zookeeper server does not timeout. If the
                // connection is back to normal at this time, we would not receive
                // the Expired event and the service would be left as unavailable.
                // Following is used to deal with this situation.
                if (service.isStopped()) {
                    service.recover("ZooKeeper is connected but service is stopped",
                            new SessionExpiredException());
                }
                break;
            case Disconnected:
                LOG.warn(prefix("Disconnected from the zookeeper"));
                connected.set(false);
                // start a timer thread
                new ZKDisconnectTimer().start();
                break;
            case Expired:
                LOG.warn(prefix("ZooKeeper session expired, recovering..."));
                // stop the timer first, otherwise this timer might stop
                // the store server, which is already recovered
                synchronized (connected) {
                    connected.set(true);
                    connected.notifyAll();
                }
                // recover the service
                service.recover("ZooKeeper session expired",
                        new SessionExpiredException());
                break;
            default:
                break;
        }
    }

    /**
     * Count down thread when ZooKeeper is disconnected. This thread is started
     * if ZooKeeper receives Disconnected event. The associated service would be
     * stopped if ZooKeeper does not come back after sometime.
     * 
     * <p>Here we take the ZooKeeper session timeout as the count down period.
     * This is because for store server, the normal ones would not get notified
     * until the disconnected one timeout. So during this period the disconnected
     * store server could still serve users. Once it timeout in ZooKeeper,
     * consistent hash would be updated in ZooKeeper and then all users would
     * be dispatched to the other normal store servers. At this time, this store
     * server could stop its service.
     */
    class ZKDisconnectTimer extends Thread {
        public ZKDisconnectTimer() {
            super("ZooKeeper-Disconnected-Timer");
        }

        public void run() {
            int timeout = AccConfig.getPros().getInt(
                    AccConfig.NAME_ZK_SESSION_TIMEOUT,
                    AccConfig.DEFAULT_ZK_SESSION_TIMEOUT);
            // count down is started if connected is false
            if (!connected.get()) {
                synchronized (connected) {
                    try {
                        connected.wait(timeout);
                    } catch (InterruptedException e) {
                        LOG.warn(prefix("Interrupted while waiting for " +
                    		"ZooKeeper coming back"), e);
                    }
                }
                // stop associated service if still disconnected after count down
                if (!connected.get()) {
                    service.stop("ZooKeeper is disconnected for too long, stopping...");
                } else {
                    LOG.info(prefix("ZooKeeper is back to normal"));
                }
            }
        }
    }

    /**
     * Handles KeeperExceptions in client calls.
     * <p>
     * This may be temporary but for now this gives one place to deal with these.
     * <p>
     * TODO: Currently this method rethrows the exception to let the caller handle
     * <p>
     * @param ke
     * @throws Exception 
     */
    public void keeperException(KeeperException ke)
            throws KeeperException {
        LOG.warn(prefix("Received unexpected KeeperException, "
                + "re-throwing exception"), ke);
        throw ke;
    }

    /**
     * Handles InterruptedExceptions in client calls.
     * <p>
     * This may be temporary but for now this gives one place to deal with these.
     * <p>
     * TODO: Currently, this method does nothing.
     *       Is this ever expected to happen?  Do we stop service or can we let it run?
     * <p>
     * @param ie
     */
    public void interruptedException(InterruptedException ie) {
        LOG.warn(prefix("Received InterruptedException, doing nothing here"), ie);
        // At least preserver interrupt.
        Thread.currentThread().interrupt();
        // no-op
    }

    /**
     * Close the connection to ZooKeeper.
     * @throws InterruptedException
     */
    public void close() {
        try {
            if (zooKeeper != null) {
                zooKeeper.close();
            }
        } catch (InterruptedException e) {}
    }

    @Override
    public String toString() {
        return this.identifier;
    }

    /**
     * Adds this instance's identifier as a prefix to the passed <code>str</code>
     * @param str String to amend.
     * @return A new string with this instance's identifier as prefix
     */
    public String prefix(final String str) {
        return this.toString() + " " + str;
    }
}
