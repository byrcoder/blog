/**
 * @(#)DataStore.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.cache.Cache;
import outfox.account.cache.TimeSensitiveCache;
import outfox.account.cache.memcached.MemcachedCache;
import outfox.account.cache.memcached.MemcachedManager;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.*;
import outfox.account.data.coremail.CoremailDataWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.in.*;
import outfox.account.db.in.IPersTokenDB.IPersTokenIter;
import outfox.account.db.in.ISessCookieDB.ISessCookieIter;
import outfox.account.db.in.IUserMappingDB.IUserMappingIter;
import outfox.account.db.kv.cassandra.*;
import outfox.account.db.kv.imp.*;
import outfox.account.db.kv.iter.*;
import outfox.account.exceptions.AccException;
import outfox.account.profile.ProfileService;
import outfox.account.utils.AuthUtils;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Data store for all data operations. The class will ioslate business layer and Data layer.
 * @author chen-chao
 */
public class DataStore {
    private static final Log LOG = LogFactory.getLog(DataStore.class);
    private static volatile DataStore instance = null;

    public static DataStore getInstance() {
        try {
            if(instance == null) {
                synchronized(DataStore.class) {
                    if(instance == null) {
                        instance = new DataStore();
                    }
                }
            }
            return instance;
        } catch (Throwable t) {
            LOG.warn("init datastore error.", t);
            return null;
        }
    }
    // UserInfo use local cache.
    private TimeSensitiveCache<String> cache = null;
    
    // Session cookie use memcached.
    private Cache sessCache = null;

    private ProfileService profileService;

    private IPersTokenDB persTokenDB;

    private ISessCookieDB sessCookieDB;

    private IUserInfoDB userInfoDB;

    private IUserMappingDB userMappingDB;
    
    private IShowKeyDB showKeyDB;
    
    private IPublicViewMappingDB publicViewMappingDB;
    
    private ICoremailDB coremailDB;
    
    private DataStore() {
        init();
    }
    private static final boolean ENABLE_MEMCACHED = AccConfig.getPros().getBoolean(AccConfig.NAME_ENABLE_MEMCACHED_IN_FILTER);
    /**
     * for test
     */
    private void init() {
        boolean enableCache = AccConfig.getPros().getBoolean(AccConfig.NAME_ENABLE_READ_DATASTORE_CACHE);
        int cachesize = AccConfig.getPros().getInt(AccConfig.NAME_READ_CACHE_LIMITS);

        float loadfactor = AccConfig.getPros().getFloat(AccConfig.NAME_READ_CACHE_LOAD_FACTOR);
        cache = new TimeSensitiveCache<String>(enableCache, (int) (cachesize / (loadfactor - 0.1)),
                loadfactor, cachesize);
        
        if (ENABLE_MEMCACHED) {
            MemcachedCache memCache = (MemcachedCache) MemcachedManager.getInstance().getCache(AccConst.NAME_SESS_COOKIE_MEMCACHED);
            int refreshTime = AccConfig.getPros().getInt(AccConfig.NAME_MEMCACHED_CACHE_REFRESH_TIME);
            memCache.setExpirationTime(refreshTime);
            sessCache = memCache;
        }
        // using omap init interfaces
        persTokenDB = new PerTokenTable();
        sessCookieDB = new SessCookieTable();
        userInfoDB = new UserInfoTable();
        //userMappingDB = new KVUserMappingDB();
        //showKeyDB = new KVShowKeyDB();
        //publicViewMappingDB = new KVPublicViewMappingDB();
        //coremailDB = new KVCoremailDB();
        profileService = new ProfileService();
    }

    /**
     * 获取用户在个人中心（profile）设置的不可重复的昵称，如果用户没有设置过会返回空字符串，不会返回null
     * 如果用户改过昵称，分别使用abc三个昵称，当前使用c，则这个用户的userid只会返回c
     * 会在本地有1小时的缓存，即新修改昵称之后其他服务最多有1小时会拿到旧数据
     * @param userid
     * @return
     */
    public String getNickname(String userid){
        return profileService.getNicknameByUserid(userid);
    }

    /**
     * 根据用户在个人中心（profile）设置的不可重复的昵称获取用户的userid，如果昵称无人使用会返回空字符串，不会返回null
     * 如果用户改过昵称，分别使用abc三个昵称，当前使用c，则传入abc都会返回这个用户的userid
     * 会在本地有1小时的缓存，即新修改昵称之后其他服务最多有1小时会拿到旧数据
     * @param nickname
     * @return
     */
    public String getUserid(String nickname){
        return profileService.getUseridByNickname(nickname);
    }

    /**
     * 获取用户在个人中心（profile）设置的头像，如果用户没有设置过会返回空字符串，不会返回null
     * 会在本地有1小时的缓存，即新修改头像之后其他服务最多有1小时会拿到旧数据
     * @param userid
     * @return
     */
    public String getAvatar(String userid){
        return profileService.getAvatarByUserid(userid);
    }

    /**
     * 获取用户在个人中心（profile）设置的性别，值为数字，1是男2是女，如果用户没有设置过会返回空字符串，不会返回null
     * 会在本地有1小时的缓存，即新修改头像之后其他服务最多有1小时会拿到旧数据
     * @param userid
     * @return
     */
    public String getGender(String userid) {
        return profileService.getGenderByUserid(userid);
    }

    @SuppressWarnings("unused")
    private TimeSensitiveCache<String> getCache() {
        return cache;
    }

    public Cache getSessCache() {
        return sessCache;
    }

    /**
     * for test.
     * @return
     */
    @SuppressWarnings("unused")
    private IPersTokenDB getPersTokenDB() {
        return persTokenDB;
    }

    @SuppressWarnings("unused")
    private ISessCookieDB getSessCookieDB() {
        return sessCookieDB;
    }

    @SuppressWarnings("unused")
    private IUserInfoDB getUserInfoDB() {
        return userInfoDB;
    }

    @SuppressWarnings("unused")
    private IUserMappingDB getUserMappingDB() {
        return userMappingDB;
    }
    @SuppressWarnings("unused")
    private IShowKeyDB getShowKeyDB() {
        return showKeyDB;
    }

    public void writePersToken(PersistTokenWritable tw) throws AccException {
        persTokenDB.write(tw);
    }

    public void writePersToken(TpToken tp) throws AccException {
        persTokenDB.write(tp);
    }
    
    /**
     * only for testing
     * @param tp
     * @throws AccException
     */
    public void writeToken(TpToken tp) throws AccException {
        persTokenDB.write(tp);
        sessCookieDB.write(tp);
    }
    
    /**
     * TODO: speed up
     * only for testing
     * @return
     * @throws AccException
     */
    public long getPersTokenCount() throws AccException {
        CountIteratorTask<IPersTokenIter> task = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        task.doIter();
        return (Long)task.returnValue();
    }
    
    /**
     * TODO: speed up
     * only for testing
     * @return
     * @throws AccException
     */
    public long getSessCookieCount() throws AccException {
        CountIteratorTask<ISessCookieIter> task = new CountIteratorTask<ISessCookieIter>(sessCookieDB, "");
        task.doIter();
        return (Long)task.returnValue();
    }

    public void writeSessToken(TpToken tp) throws AccException {
        
        SessionCookieWritable sess = sessCookieDB.write(tp);
        if (tp != null && sess != null) {
            writeToSessCache(tp.sessIndex, sess);
        }
        
    }

    public PersistTokenWritable readPersToken(TpToken tp) throws AccException {
        return persTokenDB.read(tp);
    }

    /**
     * tp
     * @param tp
     * @return
     * @throws AccException
     */
    @SuppressWarnings("unused")
    private SessionCookieWritable readSessCookie(TpToken tp) throws AccException {
        if (tp != null) {
            return readSessCookie(tp.sessIndex);
        }
        return null;
    }

    /**
     * get the session cookie. The cookie may be expired. Only used in reading cookie instance strictly.
     */
    public SessionCookieWritable readSessCookie(String sessIndex) throws AccException {
        SessionCookieWritable sess = readFromSessCache(sessIndex);
        if (sess == null) {
            sess = sessCookieDB.read(sessIndex);
            if (sess != null) {
                writeToSessCache(sessIndex, sess);
            }
        }
        return sess;
    }
    private static final long USER_INFO_EXPIRED_TIME = AccConfig.getPros().getLong(AccConfig.NAME_USER_INFO_EXPIRE_TIME);
    public void writeUserInfo(UserInfoWritable userInfo) throws AccException {
        userInfo = userInfoDB.write(userInfo);
        if (userInfo != null) {
            cache.put(userInfo.userId, userInfo, USER_INFO_EXPIRED_TIME);
        }
        LOG.info("write userinfo:"+userInfo);
    }

    public UserInfoWritable readUserInfo(String userId) throws AccException {
        UserInfoWritable userInfo = (UserInfoWritable)cache.get(userId);
        if (userInfo == null) {
            userInfo = userInfoDB.read(userId);
            if (userInfo != null) {
                cache.put(userId, userInfo, USER_INFO_EXPIRED_TIME);
            }
        } 
        return userInfo;
    }

    /**
     * TpToken dose not contain session index
     * @param tp
     * @throws AccException
     */
    public void removeTokenWhichNoSessIndex(TpToken tp) throws AccException {
        PersistTokenWritable pres = persTokenDB.read(tp);
        if (pres == null) {
            SessionCookieWritable sess = sessCookieDB.read(tp);
            removeToken(sess);
        } else {
            removeToken(pres);
        }
    }

    public void removeToken(String sessIndex) throws AccException {
        SessionCookieWritable sess = readSessCookie(sessIndex);
        removeToken(sess);
    }
    
    public void removeToken(SessionCookieWritable sess) throws AccException {
        if (sess != null) {
            final TpToken tpToken = sess.getTpToken();
            removeTokenWithCache(tpToken);
        }
    }
    
    public void removeToken(PersistTokenWritable pers) throws AccException {
        if (pers != null) {
            final TpToken tpToken = pers.getTpToken();
            removeTokenWithCache(tpToken);
        }
    }
    
    public void removeTokenWithoutCleanCache(TpToken tpToken) throws AccException {
        if (tpToken != null) {
            persTokenDB.remove(tpToken);
            sessCookieDB.remove(tpToken);
        }
    }
    
    public void removeTokenWithCache(TpToken tpToken) throws AccException {
        removeFromSessCache(tpToken.sessIndex);
        removeTokenWithoutCleanCache(tpToken);
    }

    public static class ScanCount {
        public long scanCount;
        public long processCount;
        public ScanCount() {
            scanCount = 0;
            processCount = 0;
        }
        public ScanCount(long scanCount, long processCount) {
            this.scanCount = scanCount;
            this.processCount = processCount;
        }
        public ScanCount add(ScanCount that) {
            this.scanCount += that.scanCount;
            this.processCount += that.processCount;
            return this;
        }
    }
    
    public ScanCount removeTokenByStartChars(String startChars, Long expireTimeInMilli) throws AccException{
        RemoveExpiredTokensIterTask task = new RemoveExpiredTokensIterTask(this, sessCookieDB, startChars, expireTimeInMilli);
        task.doIter();
        return new ScanCount(task.getScanCount(), (Long)task.returnValue());
    }
    
    public PersistTokenWritable getAliveToken(TpToken tp, long expireTimeInMilli) throws AccException {
        PersistTokenWritable tokenWritable = readPersToken(tp);
        if (tokenWritable != null) {
            TpToken tpToken = tokenWritable.getTpToken();
            if (!(tpToken.isExpired() || tpToken.isExpired(expireTimeInMilli))) {
                return tokenWritable;
            }
        }
        return null;
    }

    public SessionCookieWritable getAliveSession(String sessIndex, long expireTimeInMilli)
            throws AccException {
        SessionCookieWritable session = readSessCookie(sessIndex);
        if (session != null) {
            // judge alive -> token expire -> self expire
            if (!AuthUtils.isExpired(session.getSessCreateTime(), session.getSessAliveTime()) 
                    && !AuthUtils.isExpired(session.getSessCreateTime(), session.getTpToken().getExpiredTime()) 
                    && !AuthUtils.isExpired(session.getSessCreateTime(), expireTimeInMilli)) {
                return session;
            }
            // sess may be expire in cache. read it from db again.
            removeFromSessCache(sessIndex);
        }
        return null;
    }

    public boolean isAlive(String sessIndex, long expireTimeInMilli) throws AccException {
        return getAliveSession(sessIndex, expireTimeInMilli) != null;
    }

    public void revokeAuthorize(String userId, Set<String> products, Set<String> apps, Set<String> tps,
            Map<String, Set<String>> condition) throws AccException {
        RevokeUserTokenIteratorTask task = new RevokeUserTokenIteratorTask(persTokenDB, sessCookieDB, userId,
                products, apps, tps, condition);
        task.doIter();
    }

    
    public MainId2ShadowIdWritable getUserMapping(String userid) throws AccException {
        return userMappingDB.readOne(userid);
    }
    public MainId2ShadowIdWritable getShadowMapping(String shadowId) throws AccException {
        return userMappingDB.read(shadowId, AccConst.DEFAULT_TIME);
    }

    /**
     * check the mapping is partly mapping or not.
     * If it is partly mapping (caused by add or delete error or server restart.)
     * It will return null. Else it will return mapping relationship.
     * @param userId (should use shadowId to check)  / mainId can not check partly mapping.
     * @return
     * @throws AccException
     */
    public MainId2ShadowIdWritable safeUserMapping(String userId) throws AccException {
        MainId2ShadowIdWritable mapping = getUserMapping(userId);
        if (mapping != null) {
            if (mapping.getShadowUserId().equals(userId)) {
                mapping = userMappingDB.read(mapping.getMainUserId(), mapping.getBindingTimeStamp());
            }
        }
        return mapping;
    }
    
    public MainId2ShadowIdWritable getMainMapping(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        return userMappingDB.read(mainId2ShadowIdWritable.getMainUserId(), mainId2ShadowIdWritable.getBindingTimeStamp());
    }
    
    public MainId2ShadowIdWritable addUserMapping(String mainId, String shadowId) throws AccException {
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(mainId, shadowId);
        userMappingDB.write(mainId2ShadowIdWritable);
        return mainId2ShadowIdWritable;
    }
    
    public MainId2ShadowIdWritable removeUserMapping(String userid) throws AccException {
        // 1. get
        MainId2ShadowIdWritable mapping = getUserMapping(userid);
        
        // 2. remove
        return removeUserMapping(mapping);
    }
    
    public MainId2ShadowIdWritable removeUserMapping(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException{
        userMappingDB.remove(mainId2ShadowIdWritable);
        return mainId2ShadowIdWritable;
    }
    
    public void removeShadowMappingOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        userMappingDB.removeShadowOnly(mainId2ShadowIdWritable);
    }
    
    public boolean isOnlyOneBindInfo(String userId) throws AccException {
        String mainId = getMainId(userId);
        if (mainId == null){
            return false;
        }

        CountTwiceIteratorTask<IUserMappingIter> task = new CountTwiceIteratorTask<IUserMappingDB.IUserMappingIter>(
                userMappingDB, mainId);
        task.doIter();
        return (Integer)task.returnValue() == 1;
    }
    
    public int getMappingCount(String userId) throws AccException {
        String mainId = getMainId(userId);
        if (mainId == null) {
            return 0;
        }
        CountIteratorTask<IUserMappingIter> task = new CountIteratorTask<IUserMappingDB.IUserMappingIter>(
                userMappingDB, mainId);
        task.doIter();
        long count = (Long)task.returnValue();
        return (int)count;
    }

    protected String getMainId(String userId) throws AccException {
        String mainId = userId;
        if (!AuthUtils.isValidEmailAddress(userId)) {
            MainId2ShadowIdWritable mapping = safeUserMapping(userId);
            if (mapping == null) {
                return null;
            }
            mainId = mapping.getMainUserId();
        }
        return mainId;
    }
    
    public void removeAllMapping(String mainId) throws AccException {
        RemoveMappingIteratorTask task = new RemoveMappingIteratorTask(userMappingDB, this, mainId);
        task.doIter();
    }
            
    public static class MappingRelationship {
        private String mainId;
        private List<String> shadowIds;
        public MappingRelationship(String mainId, List<String> shadowIds) {
            this.mainId = mainId;
            this.shadowIds = shadowIds;
        }
        public String getMainId() {
            return mainId;
        }
        public List<String> getShadowIds() {
            return shadowIds;
        }
    }
    
    public MappingRelationship getAllMappingByMainId(String mainId) throws AccException {
        GetMappingRelationshipIteratorTask task = new GetMappingRelationshipIteratorTask(userMappingDB, mainId);
        task.doIter();
        return (MappingRelationship)task.returnValue();
    }
    
    public MappingRelationship getAllMapping(String userId) throws AccException {
        String mainId = getMainId(userId);
        if (mainId == null) {
            return null;
        }
        return getAllMappingByMainId(mainId);
    }
    
    public String genShowKey() throws AccException {
        String key = AuthUtils.genUniqueToken();
        showKeyDB.write(key);
        return key;
    }
    
    /**
     * read only once.
     * @return
     * @throws AccException
     */
    public String readShowKey(String key) throws AccException {
        String value = showKeyDB.read(key);
        showKeyDB.remove(value);
        return value;
    }
    
    public PublicViewWritable readPublicViewMapping(String key) throws AccException {
        return publicViewMappingDB.read(key);
    }
    /**
     * 
     * @param suffix
     * suffix of url
     * @param userId
     * userId
     * @param authorize
     * using AccConst.AUTHORIZE_TYPE 
     * READ | WRITE or only READ
     * @throws AccException
     */
    public void writePublicViewMapping(String suffix, String userId, int authorize) throws AccException {
        PublicViewWritable publicView = new PublicViewWritable(suffix, userId, authorize);
        publicViewMappingDB.write(suffix, publicView);
    }
    
    public void removePublicViewMapping(String suffix) throws AccException {
        publicViewMappingDB.remove(suffix);
    }
    
    public void writeCoremailDomainURL(String domain, String url) throws AccException {
        coremailDB.writeCoremailDomainURL(domain, url);
    }
    
    public void removeCoremailDomainURL(String domain) throws AccException {
        coremailDB.removeCoremailDomainURL(domain);
    }
    /**
     * only for small data
     * @return
     * @throws AccException 
     */
    @SuppressWarnings("unchecked")
    public List<PublicViewWritable> getAllPublicViewMapping(String startKey) throws AccException {
        GetPublicViewsIterTask task = new GetPublicViewsIterTask(publicViewMappingDB, startKey);
        task.doIter();
        return (List<PublicViewWritable>)task.returnValue();
    }
    
    public CoremailDataWritable readCoremailData(String domain) throws AccException {
        return coremailDB.read(domain);
    }
    
    public void removeSessIndexOnly(TpToken tp) throws AccException {
        if (tp != null) {
            removeSessIndexOnly(tp.sessIndex);
        }
        
    }
    /**
     * remove store first. Else, cache may load session cookie again after removing the cookie from cache.
     * @param sessIndex
     * @throws AccException
     */
    public void removeSessIndexOnly(String sessIndex) throws AccException {
        
        sessCookieDB.remove(sessIndex);
        removeFromSessCache(sessIndex);
    }
    
    public SessionCookieWritable readFromSessCache(String sessIndex) {
        if (ENABLE_MEMCACHED) {
            try {
                return (SessionCookieWritable)sessCache.get(sessIndex).get();
            } catch(Throwable t) {
                // read no log output. if memcached is crashed, the write operation will put the information.
                // use local cache for a while
                return (SessionCookieWritable)cache.get(sessIndex);
            }
        } else {
            return (SessionCookieWritable) cache.get(sessIndex);
        }
        
    }
    
    public void writeToSessCache(String sessIndex, SessionCookieWritable sessCookie) {
        if (ENABLE_MEMCACHED) {
            try {
                sessCache.put(sessIndex, sessCookie);
            } catch(Throwable t) {
                LOG.warn("write memcache error.", t);
                cache.put(sessIndex, sessCookie);
            }
        } else {
           cache.put(sessIndex, sessCookie);
        }
    }
    
    public void removeFromSessCache(String sessIndex) {
        if (ENABLE_MEMCACHED) {
            try {
                sessCache.evict(sessIndex);
            } catch (Throwable t) {
                LOG.warn("remove from memcache error.", t);
                cache.remove(sessIndex);
            }
        } else {
            cache.remove(sessIndex);
        }
    }
}
