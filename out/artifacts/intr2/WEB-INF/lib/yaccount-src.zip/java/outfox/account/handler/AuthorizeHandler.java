/**
 * @(#)RemoveAuthorizeHandler.java, 2012-9-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.AuthInfo;
import outfox.account.data.Parameter;
import outfox.account.device.DeviceManager;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.logic.event.AccEvent;
import outfox.account.server.token.TokenManager;
import outfox.account.utils.AuthUtils;
import toolbox.web.CookieUtil;

/**
 * @author chen-chao
 */
@Controller
public class AuthorizeHandler extends BaseHandler {
    private static final long serialVersionUID = -7663358038032539763L;
    public static final String DELIMS = ",";
    
    @RequestMapping(AccConst.RESET_URL)
    public void removeCurrentAuthorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "reset");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        String product = req.getParameter(AccConst.PARAM_PRODUCT_NAME);
        AuthUtils.cleanCookies(req, resp, product);
        
        AuthInfo tokens = getLoginInfo(req);
        
        //TODO: remove
        if (LOG.isDebugEnabled()) {
            LOG.debug("tokens.isLogin()=" + tokens.isLogin());
        }
        if (tokens.isLogin()) {
            Cookie c = CookieUtil.findCookie(req, product+AccConst.COOKIE_KEEP_TOKEN);
            if (c == null) {
                TokenManager.remove(tokens.tpToken);
            } 
            
            // device status handle.
            String userId = tokens.tpToken.userId;
            List<AccEvent> eventList = new ArrayList<AccEvent>();
            List<Parameter> deviceCheckResult = new ArrayList<Parameter>();
            DeviceManager.tryTransferStatus(product, userId, OPERATOR.FINSIH_LOGOUT, 
                    null, req, deviceCheckResult, eventList);
            DeviceManager.handleEvents(eventList);
        }
        String redirectUrl = req.getParameter(AccConst.PARAM_REDIRECT_URL_NAME);
        if (StringUtils.isNotBlank(redirectUrl)) {
            safeRedirect(req, resp);
        }
    }

    private void removeTokens(HttpServletRequest req, HttpServletResponse resp, AuthInfo tokens)
            throws AccException {
        AuthUtils.cleanCookies(req, resp, tokens.product);
        TokenManager.remove(tokens.tpToken);
    }
    
    /**
     * <pre>
     * user can remove all products authorize!
     * but request should set which user(login which product).
     * Default will remove only this sess-pers pair and clean URS cookies.
     * like :
     * /remove?product=YNOTE&capp=client                        // remove all client authorize of YNOTE
     * /remove?product=YNOTE&ctp=tsina                          // remove all tsina authorize of YNOTE
     * /remove?product=YNOTE&all=1                               // remove all authorize of all products and include this request authorize
     * /remove?product=YNOTE&all=1&wcproduct=YNOTE,FANFAN,       // remove all authorize of YNOTE and FANFAN and include this request authorize
     * /remove?product=YNOTE&capp=client,mobile&ctp=tsina,urstoken  // remove client & tsina || client & urstoken || mobile & tsina || mobile & urstoken of YNOTE
     * /remove?product=YNOTE&capp=client&ctp=tsina&cd=client|urstoken,;mobile|urstoken,urscookie; // remove client & tsina || client & urs token || mobile & urstoken || mobile & urscookie of YNOTE
     * </pre>
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(AccConst.REMOVE_URL)
    public void removeAuthorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "remove-authorize");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        AuthInfo tokens = checkLogin(req);
        
        boolean all = AuthUtils.getReqBoolean(req,  AccConst.PARAM_ALL, false);
        Set<String> wantCleanProducts = null;
        Set<String> wantCleanApps = null;
        Set<String> wantCleanTps = null;
        Map<String,Set<String>> condition = null;
        if (all) {
            wantCleanProducts = splitToSet(req.getParameter(AccConst.PARAM_WANT_CLEAN_PRODUCTS_NAME));
            
            // must clean the authorize itself.
            removeTokens(req, resp, tokens);
        } else {
            wantCleanApps = splitToSet(req.getParameter(AccConst.PARAM_WANT_CLEAN_APPS_NAME));
            wantCleanTps = splitToSet(req.getParameter(AccConst.PARAM_WANT_CLEAN_TPS_NAME));
            String conditions = req.getParameter(AccConst.PARAM_WANT_CLEAN_CONDITION);
            condition = makeCondition(conditions);
            wantCleanProducts = new HashSet<String>();
            wantCleanProducts.add(tokens.product);
        }
        boolean removeBind = AuthUtils.getReqBoolean(req,  AccConst.PARAM_WANT_CLEAN_BIND, false);
        if (removeBind) {
            TokenManager.revokeAuthorizeBind(tokens.tpToken.userId, wantCleanProducts, wantCleanApps, wantCleanTps, condition);
        } else {
            TokenManager.revokeAuthorize(tokens.tpToken.userId, wantCleanProducts, wantCleanApps, wantCleanTps, condition);
        }
    }

    private Map<String,Set<String>> makeCondition(String conditions) throws AccException {
        if (StringUtils.isBlank(conditions)) {
            return null;
        }
        Map<String,Set<String>> condSet = new HashMap<String,Set<String>>();
        if (conditions != null) {
            String[] condition = conditions.split(";");
            for (int i = 0; i < condition.length; i++) {
                String[] kv = condition[i].split("\\|");
                if (kv.length != 2) {
                    throw new AccException("not app1|tp1,tp2,;app2|tp1,tp3; format. Condition is :" + conditions, AccExpType.LOGIC_ERROR);
                }
                final String appName = kv[0];
                if (!condSet.containsKey(appName)) {
                   condSet.put(appName, new HashSet<String>());
                }
                String[] tps = kv[1].split(",");
                for (int j = 0; j < tps.length; j++) {
                    condSet.get(appName).add(tps[j]);
                }
            }
        }
        return condSet;
    }
    
    private Set<String> splitToSet(String src){
        Set<String> set = null;
        if (StringUtils.isNotBlank(src)) {
            String[] array = src.split(DELIMS);
            set = new HashSet<String>();
            for (String elem : array) {
                set.add(elem);
            }
        }
        return set;
    }
}
