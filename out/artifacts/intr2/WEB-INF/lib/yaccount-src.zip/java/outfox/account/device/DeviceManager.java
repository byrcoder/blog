/**
 * @(#)DeviceStatusLogic.java, 2013-6-3. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.Parameter;
import outfox.account.data.device.DeviceInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.logic.ListenerManager;
import outfox.account.logic.event.AccEvent;
import outfox.account.utils.AuthUtils;

/**
 * Device manager to handle device status check.
 * @author chen-chao, zhanglz
 */
public class DeviceManager {
    private static final Log LOG = LogFactory.getLog(DeviceManager.class);
    public static final String EVENT_SOURCE = DeviceManager.class.getCanonicalName();
    
    /**
     * Try to transfer device status. Three cases may happen.
     * <p>
     * 1. This status transfer is OK.
     * <ul>
     * <li>1.1 return true
     * <li>1.2 generate event when reaching a different status
     * </ul>
     * 
     * <p>
     * 2. This status transfer is not permitted but this invoking may happen, just like 'cq' a logouting device.
     * <ul>
     * <li>2.1 return false to indicate that upper caller should not continue normal process but return error info.
     * <li>2.2 add error info into given 'result'
     * </ul>
     * <p>
     * 3. This status transfer is not permitted and this invoking should neven happen theoretically unless program error.
     * <ul>
     * <li>3.1 return true.
     * <li>3.2 log unknown status transfer. 
     * </ul>
     * @param product
     * @param userId
     * @param op
     * @param req
     * @param resp
     * @param result should interrupt login process.
     * @param eventList
     * @return
     * @throws AccException
     */
    public static boolean tryTransferStatus(String product, String userId, OPERATOR op, 
            String deviceId, HttpServletRequest req, List<Parameter> result, List<AccEvent> eventList) 
        throws AccException {
        // get deviceId from http request if given device id is blank.
        if (StringUtils.isBlank(deviceId)) {
            deviceId = AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_ID);
        }
        // Only if there's product, user id and device id, we can get current status
        // Else return true not to interrupt normal login process.
        if (StringUtils.isBlank(product) || StringUtils.isBlank(userId) ||
                StringUtils.isBlank(deviceId)) {
            return true;
        }
        LOG.debug("Enter device status transfer.userId=" + userId + ", op=" + op + ", deviceId=" + deviceId);
        DeviceStore store = DeviceStore.getInstance();
        DeviceStatus curStatus = null;
        // 'getDeviceStatus' method is optimized by memcached but return inaccurate status when memcached crash. 
        if (op == OPERATOR.FILTER) {
            curStatus = store.getDeviceStatus(product, userId, deviceId, false);
            if (null == curStatus) {
                LOG.warn(deviceStatusPrefix("Current status is null when doing filter, memcached " 
            		+ "may crash. set current status into ONLINE, deviceId=" + deviceId));
                curStatus = DeviceStatus.ONLINE;
            }
        } else {
            // read directly from omap for other operator which are more less frequency.
            curStatus = store.getDeviceStatus(product, userId, deviceId, true);
        }
        DeviceInfoWritable deviceInfo = null;
        // when a new device login, a null status is returned, we change it to DeviceStatus.EMPTY
        if (curStatus == null && (op == OPERATOR.LOGIN || op == OPERATOR.CQ || op == OPERATOR.POLL)) {
            curStatus = DeviceStatus.EMPTY;
            // For new devices, device info will be saved when process device event.
            deviceInfo = extractDeviceInfo(product, deviceId, req);
        }
        if (null == curStatus) {
            LOG.error(deviceStatusPrefix("Login user met a null device status, " +
                        "this shouldn't happen." + "userId=" + userId + 
                        ", deviceId=" + deviceId + ", op=" + op.name()));
            return true;
        }
        // The try to transfer status got 'nextStatus == null' .
        // This means that there is no state transfer in state machine, which may 
        // be caused by program error if checkRes still equals true. 
        DeviceStatus nextStatus = DeviceManager.nextStatus(curStatus, op);
        boolean checkRes = true; 
        if (null == nextStatus) {
            switch (op) {
                case CQ:
                case LOGIN:
                case POLL:
                case FILTER:
                    // status transfer failed because invoke handler when 
                    // current status is DELETING or LOGOUTING.
                    // this is the cases that we should tell device to offline 
                    // or delete user's data.
                    if (curStatus == DeviceStatus.DELETING || 
                            curStatus == DeviceStatus.LOGOUTING) {
                        int errorCode = curStatus == DeviceStatus.DELETING ? 
                                AccConst.ERROR_DEVICE_DELETE : AccConst.ERROR_DEVICE_OFFLINE;
                        result.add(new Parameter(AccConst.ERROR_CODE, errorCode));
                        checkRes = false;
                    }
                    break;
            }
        } 
        // there is no next status and we are not sure this transfer is invalid.
        // That is, this is a unknown status transfer.
        if (checkRes && null == nextStatus) {
            LOG.warn(deviceStatusPrefix("we met a unknow state transfer. userId=" + userId
                    + ", deviceId=" + deviceId + ", from=" + curStatus.name() + 
                    ", op=" + op.name()));
        }
        // there is a valid state transfer.
        if (checkRes && null != nextStatus) {
            DeviceEvent deviceEvent = new DeviceEvent(EVENT_SOURCE, userId, 
                    deviceId, product, curStatus, nextStatus, op);
            // update device info.
            if (null != deviceInfo) {
                deviceEvent.setDeviceInfo(deviceInfo);
            }
            eventList.add(deviceEvent);
        }
        return checkRes;
    }
    
    private static DeviceInfoWritable extractDeviceInfo(String product, 
            String deviceId, HttpServletRequest req) {
        DeviceInfoWritable result = new DeviceInfoWritable(product, deviceId);
        result.setName(AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_NAME));
        result.setModel(AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_MODEL));
        result.setOs(AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_OS));
        result.setOsVer(AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_OS_VERSION));
        result.setClientVer(AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_CLIENT_VERSION));
        result.setType(AuthUtils.getParamOrHeader(req, AccConst.PARAM_DEVICE_TYPE));
        return result;
    }
    
    /**
     * get next status by defined operations. if return is NULL, it means undefined status.
     * @param from
     * @param op
     * @return
     */
    public static DeviceStatus nextStatus(DeviceStatus from, OPERATOR op) {
        if (null == from) {
            return null;
        }
        DeviceStatus status = null;
        switch (from) {
            case EMPTY:
                status = nextEmptyStatus(op);
                break;
            case ONLINE:
                status = nextOnlineStatus(op);
                break;
            case LOGOUTING:
                status = nextLogoutingStatus(op);
                break;
            case LOGOUT:
                status = nextLogoutStatus(op);
                break;
            case DELETING:
                status = nextDeletingStatus(op);
                break;
            default:
                break;
        }
        return status;
    }
    
    public static void handleEvents(List<AccEvent> eventList) throws AccException {
        // handle event synchronously.
        for (AccEvent event : eventList) {
            event.process();
        }
        // handle event asynchronously.
        ListenerManager.getInstance().notifyEvents(eventList);
    }
    
    private static DeviceStatus nextEmptyStatus(OPERATOR op) {
        DeviceStatus status = null;
        switch(op) {
            case CQ: /* no break */
            case LOGIN: /* no break */
            case POLL:
                status = DeviceStatus.ONLINE;
                break;
            default:
                break;
        }
        return status;
    }
    
    private static DeviceStatus nextOnlineStatus(OPERATOR op) {
        DeviceStatus status = null;
        switch(op) {
            case CQ: /* no break */
            case LOGIN: /* no break */
            case POLL:
                status = DeviceStatus.ONLINE;
                break;
            case REQUEST_LOGOUT:
                status = DeviceStatus.LOGOUTING;
                break;
            case REQUEST_DELETE:
                status = DeviceStatus.DELETING;
                break;
            case FINSIH_LOGOUT:
                status = DeviceStatus.LOGOUT;
                break;
            default:
                break;
        }
        return status;
    }
    
    private static DeviceStatus nextLogoutingStatus(OPERATOR op) {
        DeviceStatus status = null;
        switch(op) {
            case LOGIN: 
            case POLL:
                status = DeviceStatus.ONLINE;
                break;
            case REQUEST_LOGOUT:
                status = DeviceStatus.LOGOUTING;
                break;
            case REQUEST_DELETE:
                status = DeviceStatus.DELETING;
                break;
            case FINSIH_LOGOUT:
                status = DeviceStatus.LOGOUT;
                break;
            default:
                break;
        }
        return status;
    }
    
    private static DeviceStatus nextLogoutStatus(OPERATOR op) {
        DeviceStatus status = null;
        switch(op) { 
            case CQ:
                status = DeviceStatus.ONLINE;
                break;
            case LOGIN: 
            case POLL:
                status = DeviceStatus.ONLINE;
                break;
            case REQUEST_LOGOUT:
                status = DeviceStatus.LOGOUT;
                break;
            case REQUEST_DELETE:
                status = DeviceStatus.DELETING;
                break;
            case FINSIH_LOGOUT:
                status = DeviceStatus.LOGOUT;
                break;
            default:
                break;
        }
        return status;
    }
    
    private static DeviceStatus nextDeletingStatus(OPERATOR op) {
        DeviceStatus status = null;
        switch(op) {
            case REQUEST_DELETE:
                status = DeviceStatus.DELETING;
                break;
            case FINSIH_LOGOUT:
                status = DeviceStatus.DELETING;
                break;
            case FINISH_DELETE:
                status = DeviceStatus.EMPTY;
                break;
            default:
                break;
        }
        return status;
    }
    
    /**
     * Add log prefix for searching convenience.
     * @param logInfo
     * @return
     */
    private static String deviceStatusPrefix(String logInfo) {
        String prefix = "DEVICE_STATUS: ";
        return prefix + logInfo;
    }
}
