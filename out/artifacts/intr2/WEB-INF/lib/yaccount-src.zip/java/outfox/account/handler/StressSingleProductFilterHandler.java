/**
 * @(#)StressSingleProductFilterHandler.java, 2013-9-6. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.device.DeviceStore;
import outfox.account.device.DeviceStatus;
import outfox.account.data.device.DeviceInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.utils.AuthUtils;

/**
 * This controller only used in stress test.
 * @author chen-chao
 */
@Controller
public class StressSingleProductFilterHandler extends BaseHandler {
    private static final long serialVersionUID = -3563522052465699817L;
    private static final Log LOG = LogFactory.getLog(StressSingleProductFilterHandler.class);
    private DataStore store;
    private DeviceStore deviceStore;
    public void init(){
        store = DataStore.getInstance();
        deviceStore = DeviceStore.getInstance();
    }
    @RequestMapping(AccConst.STRESS_SINGLE_PRODUCT_FILTER)
    public void showHttpProtocal(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "stress-single-product-filter");
        JSONObject obj = new JSONObject();
        if (req.getAttribute(AccConst.USER_ID_ATTR) != null) {
            obj.put(AccConst.FLAG_LOGIN, true);
        } else {
            obj.put(AccConst.FLAG_LOGIN, false);
        }
        writeJSON(req, resp, obj, HttpStatus.OK);
    }
    @RequestMapping(AccConst.STRESS_MEMCACHED_WRITE)
    public void writeMemcached(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "stress-memcached-write");
        String sessIndex = req.getParameter("sid");
        SessionCookieWritable writable = new SessionCookieWritable();
        writable.getTpToken().sessIndex = sessIndex;
        store.writeToSessCache(sessIndex, writable);
        JSONObject obj = new JSONObject();
        obj.put("write", sessIndex);
        writeJSON(req, resp, obj, HttpStatus.OK);
    }
    
    @RequestMapping(AccConst.STRESS_MEMCACHED_READ)
    public void readMemcached(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "stress-memcached-read");
        String sessIndex = req.getParameter("sid");
        SessionCookieWritable writable = store.readFromSessCache(sessIndex);
        JSONObject obj = new JSONObject();
        if (writable == null) {
            obj.put("read", "null");
        } else {
            obj.put("read", writable.getTpToken().sessIndex);
        }
        writeJSON(req, resp, obj, HttpStatus.OK);
    }
    
    @RequestMapping(AccConst.STRESS_MEMCACHED_REMOVE)
    public void rmMemcached(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "stress-memcached-rm");
        String sessIndex = req.getParameter("sid");
        store.removeFromSessCache(sessIndex);
        JSONObject obj = new JSONObject();
        obj.put("rm", sessIndex);
        writeJSON(req, resp, obj, HttpStatus.OK);
    }
    
    @RequestMapping(AccConst.STRESS_CREATE_COOKIE_URL)
    protected void createCookie(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "stress-create-cookie");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        String userid = req.getParameter("userid");

        //create userinfo
        UserInfoWritable userInfo = new UserInfoWritable();
        userInfo.userId = userid;
        userInfo.userName = "accountserver_stress";
        userInfo.email = "accountserver_stress@163.com";
        userInfo.imageUrl = "accountserver_stress";
        userInfo.originalId = "accountserver_stress";
        userInfo.from = "stress";
        userInfo.alias = "accountserver_stress";
        store.writeUserInfo(userInfo);

        //create sessioncookie
        TpToken tp = new TpToken();
        tp.userId = userid;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        tp.setSessAliveTime(-1L);
        IVerifier verifier = TokenVerifierFactory.getInstance().getTokenVerifier( "YNOTE","tsina");
        TokenUtils.encode(verifier,tp);
        store.writeToken(tp);
        
        LOG.info("create sessioncookie for " + userid);

        List<Parameter> returnMessage = new ArrayList<Parameter>();
        returnMessage.add(new Parameter("userid", userid));
        returnMessage.add(new Parameter("cookie",tp.sessIndex));
        returnMessage.add(new Parameter("userName",userInfo.userName));
        write(req, resp, returnMessage,HttpStatus.OK);
    }

    @RequestMapping(AccConst.STRESS_CREATE_DEVICE_URL)
    protected void createDevice(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "stress-create-device");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        String deviceid = req.getParameter("deviceid");
        String userid = req.getParameter("userid");

        //造deviceinfo
        DeviceInfoWritable deviceInfo = new DeviceInfoWritable();
        deviceInfo.setDeviceId(deviceid);
        deviceInfo.setProduct("YNOTE");
        deviceInfo.setName("Administrator");
        deviceInfo.setOs("windows xp");
        deviceInfo.setOsVer("sp1");
        deviceInfo.setModel("pc");
        deviceInfo.setClientVer("30400000");
        deviceInfo.setType("pc");
        deviceStore.updateDeviceInfo(deviceInfo);
        deviceStore.updateDeviceStatus("YNOTE",userid,deviceid,DeviceStatus.ONLINE);

        LOG.info("create deviceInfo:" + deviceid + ", for user:" + userid); 

        List<Parameter> returnMessage = new ArrayList<Parameter>();
        returnMessage.add(new Parameter("deviceid", deviceid));
        returnMessage.add(new Parameter("userid", userid));
        write(req, resp, returnMessage,HttpStatus.OK);
	}
}
