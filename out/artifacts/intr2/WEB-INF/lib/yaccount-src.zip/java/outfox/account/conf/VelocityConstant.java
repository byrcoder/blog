package outfox.account.conf;
/**
 * constant values are for velocity page display
 *
 * @author chen-chao
 *
 */
public interface VelocityConstant {

    /**
     * pages
     */
    static final String PAGE_ERROR = "error";

    static final String PAGE_INDEX = "index";

    static final String PAGE_SELF_CLOSE_REDIRECT = "selfCloseAndRedirect";

    static final String PAGE_DISPLAY = "display";

    static final String PAGE_LOGIN_DONE = "loginDone";

    static final String PAGE_QPLUS_LOGIN_PAGE = "loginQplus";

    /**
     * values flag
     */
    static final String VALUE_MESSAGE = "message";

    static final String VALUE_STACK_MESSAGE = "stack";

    static final String VALUE_OAUTH_APP = AccConst.CONSUMER_OAUTH;

    static final String VALUE_TSINA_APP = AccConst.CONSUMER_TSINA;
    
    static final String VALUE_WQQ_APP = AccConst.CONSUMER_WEIBO_QQ;

    static final String VALUE_CONTENT = "content";

    static final String VALUE_REDIRECT_URL = "redirectUrl";

    static final String VALUE_URS_LOGIN_URL = "ursLogin";

    static final String VALUE_URS_JSON_LOGIN_URL = "ursJSONLogin";

    static final String VALUE_QPLUS_LOGIN_URL = "qplus";

    static final String VALUE_QQ_CONNECT_LOGIN_URL = "cqq";
    
    static final String VALUE_URS_TOKEN_LOGIN_URL = "urstoken";
    
    static final String VALUE_GET_URS_SESS = "geturssess";
    
    static final String VALUE_GET_URS_SESS_EMAIL = "geturssess_email";

    static final String VALUE_POLL_URL = "poll";

    static final String VALUE_RESET_URL = "reset";

    static final String VALUE_REQUEST_PARAMS_URL = "requstParam";

    static final String VALUE_COOKIE_QUERY_URL = "cookieQuery";

    static final String VALUE_SUCCESSFUL_FLAG = "success";

    static final String VALUE_URL = "url";

    static final String VALUE_PARAM = "param";
}
