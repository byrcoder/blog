/**
 * @(#)QConnBaseVerifier.java, Nov 7, 2013. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.QQUserInfoWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 * @author wangzhen
 */
public abstract class QConnBaseVerifier extends Oauth2Verifier {
    
    public QConnBaseVerifier(Properties props, String name) {
        super(props, name);
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp) throws AccException {
     // set query cookie and redirect to third-party
        OAuth2Utils.addQueryAttribute(req, resp);
        
        // prepare params
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.RESPONSE_TYPE, OAuthConstant.AUTHORIZED_CODE));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        String state = OAuth2Utils.genState(req);
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, state));
        if (AuthUtils.isMobile(req)) {
            params.add(new Parameter(OAuthConstant.DISPLAY, OAuthConstant.DISPLAY_MODE_MOBILE));
        }
        
        // redirect
        if (AccConfig.isStressTest()) {
            stressRedirect(req, resp);
            
        } else {
            AuthUtils.redirect(resp, getAbsoluteAuthorizeUrl(), params);
        }
        return null;
    }

    
    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // get access token, expire time, remain, others
        String msg = req.getParameter(OAuthConstant.CQQ_MESSAGE);
        String code = req.getParameter(OAuthConstant.OAUTH2_CODE);
        if (!StringUtils.isBlank(msg)) {
            throw new AccException(String.format("error code: %s, error msg: %s", code, msg));
        }
        
        AccHttpClient client = AccHttpClient.getInstance();
        List<Parameter> params = new ArrayList<Parameter>();

        params.add(new Parameter(OAuthConstant.GRANT_TYPE, OAuthConstant.GRANT_TYPE_VALUE_AUTHOR_CODE));
        params.add(new Parameter(OAuthConstant.OAUTH2_CODE, code));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, secret));
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, System.currentTimeMillis()));
        // callback( {"error":100019,"error_description":"code to access token error"} );
        String callback = client.getString(Method.GET, getAbsoluteAccessUrl(), null,
                params, null);
        JSONObject obj = convertToJson(callback);
        throwError(obj);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(OAuthConstant.ACCESS_TOKEN, obj.getString(OAuthConstant.ACCESS_TOKEN));
        result.put(OAuthConstant.EXPIRED, obj.getLong(OAuthConstant.EXPIRES_IN) * 1000L);
        return result;
    }

    /**
     * convert callback( {"error":100019,"error_description":"code to access token error"} );
     * to {"error":100019,"error_description":"code to access token error"}
     * @param callback
     * @return
     * @throws AccException
     */
    private JSONObject convertToJson(String callback) throws AccException {
        int lIndex = callback.indexOf("{");
        int rIndex = callback.indexOf("}");
        if (lIndex == -1 && rIndex == -1) {
            String[] pair = callback.split("&");
            JSONObject obj = new JSONObject();
            for (String keyValue : pair) {
                String [] kv = keyValue.split("=");
                if (kv.length != 2) {
                    throw new AccException("cqq callback:"+callback, AccExpType.TP_ERROR);
                }
                obj.put(kv[0], kv[1]);
            }
            return obj;
        } else if (lIndex >= 0 && rIndex >= 0) {
            return JSONObject.fromObject(callback.substring(lIndex, rIndex + 1));
        } else {
            throw new AccException("cqq callback:"+callback, AccExpType.TP_ERROR);
        }
        
    }

    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        String openId = getOpenId(req, resp);
        String accToken = (String) req.getAttribute(OAuthConstant.ACCESS_TOKEN);
        return getUserInfoById(accToken, openId, false);
    }
    
    private String getOpenId(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        String accToken = (String) req.getAttribute(OAuthConstant.ACCESS_TOKEN);
        return getOpenId(accToken);
    }
    
    private String getOpenId(String accToken) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.ACCESS_TOKEN, accToken));
        JSONObject obj = convertToJson(AccHttpClient.getInstance().getString(Method.GET,
                getAbsoluteUrl(properties.get("accountURL")), null, params, null));
        throwError(obj);
        return obj.getString(OAuthConstant.QQ_OPEN_ID);
    }

    private void throwError(JSONObject obj) throws AccException {
        if (obj.containsKey("error")) {
            throw new AccException(obj.toString(), null, AccExpType.TP_ERROR, obj.getInt("error"));
        }
    }
    
    private void throwAPIError(JSONObject obj) throws AccException {
        String ret = obj.getString("ret");
        if (!ret.equals("0")) {
            throw new AccException(obj.toString(), null, AccExpType.TP_ERROR, obj.getInt("ret"));
        }
    }
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expireTime) throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expireTime);
        
        // set access token
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        TpToken tpToken = tokenWritable.getTpToken();
        thirdPartyTokens.put(AccConst.TOKEN,
                tpToken.token);
        thirdPartyTokens.put(AccConst.OPEN_ID, tpToken.authid);
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        // TODO update userInfo in other thread
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        // update userInfo

        store.writeUserInfo(userInfo);
        // AccConst.THIRD_PARTY_PERS_TOKEN should not remove
        // has checked in thrid party, but now it is expired
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        return result;
    }

    @Override
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException {
        Map<String,Object> newMap = new HashMap<String, Object>(authInfo);
        newMap.remove(OAuthConstant.ACCESS_TOKEN);
        newMap.remove(OAuthConstant.REMIND);
        return newMap;
    }

    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        String accToken = thirdPartyTokens.get(AccConst.TOKEN);
        String openId = thirdPartyTokens.get(AccConst.OPEN_ID);
        
        return getUserInfoById(accToken, openId, thirdPartyTokens.containsKey(AccConst.SINGLE_SIGN_ON));
    }
    
    private UserInfoWritable getUserInfoById(String accToken, String openId, boolean sso) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.ACCESS_TOKEN, accToken));
        params.add(new Parameter(OAuthConstant.QQ_OAUTH_CONSUMER_KEY, appkey));
        params.add(new Parameter(OAuthConstant.QQ_OPEN_ID, openId));
        String getAccountInfoUrl = null;
        if (sso) {
            getAccountInfoUrl = getAbsoluteUrl(properties.get("ssoAccountURL"));
        } else {
            getAccountInfoUrl = getAbsoluteUrl(properties.get("accountInfoURL"));
        }
        JSONObject obj = JSONObject.fromObject(AccHttpClient.getInstance().getString(Method.GET,
                getAccountInfoUrl, null, params, null));
        throwAPIError(obj);
        return new QQUserInfoWritable(tpId2ownId(openId), openId, obj);
    }

}
