/**
 * @(#)PersistTokenWritable.java, 2012-8-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.List;

/**
 * @author chen-chao
 */
public class PersistTokenWritable extends AbstractWritable {
    private static final long serialVersionUID = -3732321645083718298L;
    private TpToken tpToken;
    public TpToken getTpToken() {
        return tpToken;
    }
    public void setTpToken(TpToken tpToken) {
        this.tpToken = tpToken;
    }
    private long lastActiveTime;
    public long getLastActiveTime() {
        return lastActiveTime;
    }
    public void setLastActiveTime(long lastActiveTime) {
        this.lastActiveTime = lastActiveTime;
    }
    public PersistTokenWritable(){
        this(null,null);
    }
    public PersistTokenWritable(TpToken tpToken) {
        this(tpToken, null);
    }
    public PersistTokenWritable(TpToken tpToken, List<Parameter> params) {
        super(params);
        if (tpToken != null) {
            this.tpToken = tpToken;
            lastActiveTime = tpToken.getCreateTime();
        } else {
            this.tpToken = new TpToken();
        }
        
    }
    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        lastActiveTime = in.readLong();
        tpToken.readFields(in);
    }
    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        out.writeLong(lastActiveTime);
        tpToken.writeFields(out);
    }
}
