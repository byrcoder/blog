/**
 * @(#)LoginHandler.java, 2012-9-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.rpc2.RpcException;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.conf.AccConst.VerifierType;
import outfox.account.data.AccCookies;
import outfox.account.data.Parameter;
import outfox.account.device.DeviceManager;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.logic.event.AccEvent;
import outfox.account.server.token.TokenManager;
import outfox.account.server.token.verifier.impl.AccessTokenVerifier;
import outfox.account.utils.AuthUtils;
import toolbox.web.CookieUtil;

/**
 * @author chen-chao
 */
@Controller
public class LoginHandler extends BaseHandler {
    private static final long serialVersionUID = -1571359453372103184L;
    /**
     * /login/acc/login?app=&product=&tp=&cf=&format=&fr=
     * 
     * @throws AccException
     * @throws RpcException
     */
    @RequestMapping(AccConst.LOGIN_URL)
    public void login(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        // 0. setName in analyzer and vaquero.
        setName(req, "login");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkParam(req, AccConst.PARAM_APP_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_THIRD_PARTY_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_COOKIE_FORMAT, NO_MISS);
        String cookieParam = req.getParameter(AccConst.PARAM_COOKIE_FORMAT);
        checkCookieFormat(cookieParam);
        String product = req.getParameter(AccConst.PARAM_PRODUCT_NAME);
        AccConfig.checkProduct(product);
        processForceLogin(req, resp, product);
        Map<String,Object> result = TokenManager.authReq(req, resp);
        
        // check device status.
        List<AccEvent> eventList = new ArrayList<AccEvent>();
        List<Parameter> deviceCheckResult = new ArrayList<Parameter>();
        if (!DeviceManager.tryTransferStatus(product, getUserId(result), 
                OPERATOR.LOGIN, null, req, deviceCheckResult, eventList)) {
            write(req, resp, deviceCheckResult, HttpStatus.SERVICE_UNAVAILABLE);
            return;
        } 
        DeviceManager.handleEvents(eventList);
        
        String tp = req.getParameter(AccConst.PARAM_THIRD_PARTY_NAME);
        returnResult(req, resp, product, tp, result);
    }
    
    public static void returnResult(HttpServletRequest req, HttpServletResponse resp, String product, String tp,
            Map<String, Object> result) throws AccException {
        VerifierType type = TokenManager.getVerifierType(req, resp);
        if (type.equals(VerifierType.Oauth2)) {
            return;
        }
        if (AccessTokenVerifier.NAME.equals(tp)) {
            // reset tp
            tp = req.getParameter(AccConst.PARAM_ACCESS_TOKEN_VERIFIER);
        }
        if (result != null && result.containsKey(AccConst.REGISTER)) {
            
            safeRedirect(req, resp, generateRegisterUrl(product, tp, result));
        } else {
            if (!StringUtils.isBlank(AuthUtils.getReqVal(req, AccConst.PARAM_FORCE_REDIRECT))) {
                String redirectUrl = AuthUtils.getReqVal(req, AccConst.PARAM_REDIRECT_URL_NAME);
                if (StringUtils.isNotBlank(redirectUrl)) {
                    // append login status to redirect url indicated by 'ru'
                    redirectUrl = generateRedirectUrl(redirectUrl, product, tp, 
                            true, result);
                } else {
                    // use default login done redirect url.
                    redirectUrl = generateLoginDoneUrl(product, tp, result);
                }
                // modify scheme if necessarily.
                String scheme = AuthUtils.getReqVal(req, AccConst.ATTR_REDICT_SCHEME);
                redirectUrl = AuthUtils.addScheme(req, redirectUrl, scheme);
                safeRedirect(redirectUrl, resp);
            } else {
                write(req, resp, HttpStatus.OK,AuthUtils.convertMap2List(result));
            }
        } 
        
    }
    
    private static String generateLoginDoneUrl(String product, String tp, Map<String, Object> result) throws AccException {
        String loginDone = generateRedirectUrl(AccConst.LOGIN_DONE_LOCATION, product, tp, true, result);
        LOG.info("login goto register url:"+loginDone);
        return loginDone;
    }
    
    private static String generateRegisterUrl(String product, String tp, Map<String, Object> result) throws AccException {
        String registerUrl = AccConfig.getRegisterUrl(product, tp);
        registerUrl = generateRedirectUrl(registerUrl, product, tp, true,result);
        LOG.info("login goto register url:"+registerUrl);
        return registerUrl;
    }
    
    protected void checkCookieFormat(String cookieParam) throws AccException {
        int value = 0;
        try {
            value = Integer.parseInt(cookieParam);
        } catch(Exception e) {
            throw new AccException("cookie format error:" + cookieParam, e, AccExpType.LOGIC_ERROR);
        }
        if (value <= 0 || (value >= (COOKIE_FORMAT.b.value() << 1))) {
            throw new AccException("cookie format error:" + cookieParam, AccExpType.LOGIC_ERROR);
        }
        if (COOKIE_FORMAT.b.isContain(value) && COOKIE_FORMAT.se.isContain(value)) {
            throw new AccException("cookie format conflict:" + cookieParam, AccExpType.LOGIC_ERROR);
        }
    }
    protected void processForceLogin(HttpServletRequest req, HttpServletResponse resp, String product) {
        Cookie forceCookie = CookieUtil.findCookie(req, product + AccConst.COOKIE_LOGIN);
        boolean forceLogin = AuthUtils.getReqBoolean(req, AccConst.PARAM_FORCE_LOGIN, false);
        // forceLogin == true, or force cookie value is true.
        req.setAttribute(AccConst.ATTR_FORCE_LOGIN, forceLogin);
        if (forceCookie != null) {
            req.setAttribute(AccConst.ATTR_FORCE_LOGIN, 
                    AccCookies.isForceLoginByShadowCookie(forceCookie));
        } else {
            
            forceCookie = CookieUtil.findCookie(req, product + AccConst.COOKIE_FORCE_LOGIN);
            // only ynote has YNOTE_FORCE cookie.
            if (forceCookie != null) {
                req.setAttribute(AccConst.ATTR_FORCE_LOGIN, true);
                resp.addCookie(AuthUtils.deleteCookie(product + AccConst.COOKIE_FORCE_LOGIN, AuthUtils.getCookieDomain(req), true));
            }
        }
    }
}
