/**
 * @(#)BaseKVDB.java, 2012-9-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import outfox.account.conf.AccConfig;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.db.kv.OmapKeyValueStore;

/**
 * @author chen-chao
 */
public class BaseKVDB {
    protected IKeyValueStore<?, ?> keyValueStore;
    public BaseKVDB(String type, String tableName, String[] struct) {
        if (AccConfig.OMAP.equals(type)) {
            // omap init
            keyValueStore = new OmapKeyValueStore((String) AccConfig
                    .getPros().getProperty(AccConfig.NAME_OMAP_STORE_SPACE), tableName
                    , struct);
        } else {
            // TODO redis init ?
        }
    }
    
}
