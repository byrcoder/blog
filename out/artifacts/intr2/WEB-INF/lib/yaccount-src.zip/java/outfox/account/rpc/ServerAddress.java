/**
 * @(#)ServerAddress.java, 2012-8-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;

/**
 * @author chen-chao
 */
public class ServerAddress implements Comparable<ServerAddress> {
    private static final Log LOG = LogFactory.getLog(ServerAddress.class);
    
    private static final String Separator = ":";

    private String domainName = "";
    private String ipstr = "";
    private int port = -1;

    private String stringValue = ""; // domain_name:ip_string:port

    /**
     * Construct a ServerAddress from a string of the form domainname:ipstr:port
     * Deserialize
     * 
     * @param hostAndPort
     *            format 'domainname:ipstr:port'
     */
    public ServerAddress(String serverAddrStr) {
        String[] strArray = serverAddrStr.split(Separator);

        if (strArray.length != 3) {
            LOG.warn("Not a domain" + Separator + "host"
                    + Separator + "port : " + serverAddrStr);
            throw new IllegalArgumentException("Not a domain" + Separator
                    + "host" + Separator + "port : " + serverAddrStr);
        }

        this.domainName = strArray[0];
        this.ipstr =  strArray[1];
        this.port = Integer.parseInt(strArray[2]);
        this.stringValue = domainName + Separator + this.ipstr
                + Separator + this.port;
    }

    /**
     * Construct a ServerAddress from host IP string, port number
     * 
     * @param host
     *            host IP string or hostname
     * @param port
     *            port number
     */
    public ServerAddress(String host, int port) {
        if (host.equals("local") || host.equals("localhost")) {
            try {
                host = InetAddress.getLocalHost().getHostAddress();
            } catch (UnknownHostException e) {
                LOG.warn("Unknow host!");
            }
        }

        InetSocketAddress address = new InetSocketAddress(host, port);
        this.ipstr = address.getAddress().getHostAddress();

        this.domainName = DomainName.getInstance().getDomainName(
                address.getHostName());
        this.port = port;
        this.stringValue = domainName + Separator + this.ipstr
                + Separator + this.port;
    }

    /** @return bind address */
    public String getIP() {
        return this.ipstr;
    }

    /** @return port number */
    public int getPort() {
        return this.port;
    }

    public String getDomainName() {
        return this.domainName;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getHost() {
        return ((domainName == null || domainName.isEmpty()) ? ipstr
                : domainName);
    }

    /** @return the InetSocketAddress */
    public InetSocketAddress getInetSocketAddress() {
        return new InetSocketAddress(ipstr, port);
    }

    @Override
    public String toString() {
        return this.stringValue;
    }
    
    @Override
    public int hashCode() {
            int result = this.ipstr.hashCode();
            result ^= this.port;
            return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        return this.compareTo((ServerAddress) o) == 0;
    }

    public int compareTo(ServerAddress o) {
        if (this.ipstr.equals(o.ipstr) && (this.port == o.port)) {
            return 0;
        }
        return this.toString().compareTo(o.toString());
    }
}

/**
 * Helper class to get the domain name of the given host name
 * 
 * @author konglh
 */
class DomainName {
    public static final Log LOG = LogFactory.getLog(DomainName.class);

    private static Properties prop = null;

    /**
     * @param hostname host name of the server
     * @return the corresponding domain name
     */
    String getDomainName(String hostname) {
        String result = null;
        if (prop != null) {
            result = prop.getProperty(hostname);
        }

        if (result == null) {
            result = "";
        }

        return result;
    }

    public static DomainName getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private static class SingletonHolder {
        private static final DomainName INSTANCE = new DomainName();
    }

    private DomainName() {
        File propFile = AccConfig.getConfigFile("domain.properties");
        FileInputStream instream = null;
        try {
            instream = new FileInputStream(propFile);
            prop = new Properties();
            prop.load(instream);
            
        } catch (FileNotFoundException e) {
            LOG.warn("Unable to load domain file : "
                    + propFile.getAbsolutePath()
                    + ", we'll use ip instead of domain name.");
        } catch (IOException e) {
            LOG.warn("Read domain file : " + propFile.getAbsolutePath()
                    + " failed! We'll use ip instead of domain name.");
        } finally {
            IOUtils.closeQuietly(instream);
        }
    }
}
