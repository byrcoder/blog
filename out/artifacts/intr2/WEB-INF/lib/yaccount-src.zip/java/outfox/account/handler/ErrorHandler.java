/**
 * @(#)ErrorHandler.java, 2012-9-4. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.verifier.impl.AccessTokenVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;
import outfox.account.utils.SecurityUtils;

/**
 * @author chen-chao
 */
@Controller
public class ErrorHandler extends BaseHandler {
    private static final long serialVersionUID = -559944037083777373L;
    
    protected Object getAttribute(HttpServletRequest req, String key, Object value) {
        Object v = req.getAttribute(key);

        return (v == null ? value : v);
    }
    
    protected String getParam(HttpServletRequest req, String key, String value) {
        String v = req.getParameter(key);

        return (v == null ? value : v);
    }

    private AccException checkErrorCode(HttpServletRequest request) {
        int errorCode = 500;
        try {
            errorCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        }catch (Exception e) {
            // do nothing
        }

        if (errorCode == 404) {
            return new AccException("bad uri:" + request.getAttribute("javax.servlet.error.request_uri"),
                    AccExpType.UNKNOWN_URI);
        }
        if (errorCode == 405) {
            return new AccException("Unsupported request method:" + request.getMethod(),
                    AccExpType.UNKNOWN_URI);
        }
        return null;
    }

    private AccException getException(HttpServletRequest request) {
        AccException checkEx = checkErrorCode(request);
        if (checkEx != null) {
            return checkEx;
        }
        Throwable ex = (Throwable) request.getAttribute("javax.servlet.error.exception");
        AccException exc = getTagetException(ex);
        if (AccExpType.UNKNOWN_EXCEPTION.equals(exc.getExceptionType())) {
            if (ex == null) {
                return exc;
            }
            return new AccException(ex.getClass().getCanonicalName(), ex, AccExpType.UNKNOWN_EXCEPTION);
        }
        return exc;
    }

    private AccException getTagetException(Throwable ex) {
        if (ex == null) {
            return new AccException("exception is empty.", AccExpType.UNKNOWN_EXCEPTION);
        }
        if (ex instanceof AccException) {
            return (AccException) ex;
        } else if (ex instanceof AccRunTimeException) {
            return new AccException(ex.getMessage(), ex, AccExpType.RUNTIME_EXCEPTION);
        } else {
            Throwable t = null;
            if (ex instanceof InvocationTargetException) {
                t = ((InvocationTargetException) ex).getTargetException();
                if (t == ex) {
                    return new AccException("circle exception:"+ex.toString(), AccExpType.UNKNOWN_EXCEPTION);
                }
            } else {
                t = ex.getCause();
                if (t == ex) {
                    return new AccException("circle exception:"+ex.toString(), AccExpType.UNKNOWN_EXCEPTION);
                }
            }
            return getTagetException(t);
        }
    }

    private static final String UNKNOWN = "Unknown";

    @RequestMapping(AccConst.ERROR_URL)
    public void processError(HttpServletRequest req, HttpServletResponse resp) {
        // Analyze the servlet exception       
        setName(req, "error");
        Integer statusCode = (Integer) getAttribute(req, "javax.servlet.error.status_code",
                HttpStatus.INTERNAL_SERVER_ERROR.value());
        String servletName = (String) getAttribute(req, "javax.servlet.error.servlet_name", UNKNOWN);
        String requestUri = (String) getAttribute(req, "javax.servlet.error.request_uri", UNKNOWN);
        
        StringBuilder errInfo = new StringBuilder();
        String queryString = SecurityUtils.escapeSecurityQuery(ReqUtils.getQueryString(req));
        String display = getParam(req, AccConst.PARAM_APP_NAME, AccConst.DEFAULT_DISPLAY_MODE);
        FORMAT format = FORMAT.valueOf(getParam(req, AccConst.ATTR_FORMAT, FORMAT.json.name()));
        errInfo.append("ServletName:").append(servletName).append(",").append("display:").append(display)
                .append(",").append("Query:").append(requestUri);
        if (!StringUtils.isBlank(queryString)) {
            errInfo.append("?").append(queryString);
        }

        AccException exception = getException(req);
        Level level = exception.getExceptionType().getLogLevel();
        switch (level.toInt()) {
            case Level.FATAL_INT:
                LOG.fatal(errInfo, exception);
                break;
            case Level.ERROR_INT:
                LOG.error(errInfo, exception);
                break;
            case Level.WARN_INT:
                LOG.warn(errInfo, exception);
                break;
            // don't output the exception's stack trace for following log levels
            case Level.INFO_INT:
                LOG.info(errInfo + "  " + exception.getMessage());
                break;
            case Level.DEBUG_INT:
                LOG.debug(errInfo + "  " + exception.getMessage());
                break;
            case Level.TRACE_INT:
                LOG.trace(errInfo + "  " + exception.getMessage());
                break;
            default:
                LOG.warn(errInfo, exception);
                break;
        }
        JSONObject errorInfo = new JSONObject();
        errorInfo.put(AccConst.ERROR_OLD_HTTP_STATUS, statusCode.toString());
        errorInfo.put(AccConst.ERROR_CODE, exception.getExceptionType().getErrorCode());
        int thirdPartyErrorCode = exception.getThirdPartyErrorCode();
        if (thirdPartyErrorCode != 0) {
            errorInfo.put(AccConst.ERROR_THIRD_PARTY_CODE, thirdPartyErrorCode);
        }
        
        // if no show param and error, redirect
        // TODO: write information into poll.
        if (requestUri.endsWith("callback")) {
            // .../login/acc/callback?error_uri=...&error=...&error_description=...&error_code=...
            HttpSession session = req.getSession(false);
            String originalQueryString = (String)session.getAttribute(AccConst.ATTR_QUERY);
            if (StringUtils.isNotBlank(originalQueryString)) {
                if (StringUtils.isNotBlank(queryString)) {
                    queryString = queryString + "&" + originalQueryString;
                }
                else {
                    queryString = originalQueryString;
                }
            }
        }
        HashMap<String,String> map = AuthUtils.parseQuery(queryString);
        if (StringUtils.isBlank(map.get(AccConst.PARAM_SHOW_ERROR))) {
            if (AuthUtils.isWeb(map.get(AccConst.PARAM_APP_NAME))) {
                // redirect with error info for request of web. 
                redirect(req, resp, map, errorInfo);
                return;
            } else {
                if (requestUri.endsWith("login") || requestUri.endsWith("callback")
                        || requestUri.endsWith("cross/second") || requestUri.endsWith("geturssess")) {

                    redirect(req, resp, map, null);
                    return;
                }
            }
        }
        
        // Set response content type
        try {
            HttpStatus httpStatus = (HttpStatus) getAttribute(req, AccConst.ATTR_HTTP_STATUS,
                    HttpStatus.INTERNAL_SERVER_ERROR);
            if (httpStatus == null) {
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }
            writeJSON(resp, format.name(), errorInfo, httpStatus);
        } catch (AccException e) {
            LOG.warn("server write error back, then throw error!!", e);
        }
    }
    
    private void redirect(HttpServletRequest req, HttpServletResponse resp, 
            Map<String, String> map, JSONObject errorInfo) {
        try {
            String product = map.get(AccConst.PARAM_PRODUCT_NAME);
            if (!AccConfig.getProductSet().contains(product)) {
                // using default.
                safeRedirect(req, resp, AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_ERROR_REDIRECT_URL));
            } else {
                String errorRedirectUrl = map.get(AccConst.PARAM_ERROR_REDIRECT_URL);
                if (StringUtils.isNotBlank(errorRedirectUrl)) {
                    // add tp code for specified error redirect url.
                    if (null != errorInfo) {
                        errorRedirectUrl = AuthUtils.composeQueryUrl(
                                errorRedirectUrl, errorInfo);
                    }
                    safeRedirect(errorRedirectUrl, resp);
                } else {
                    String tp = map.get(AccConst.PARAM_THIRD_PARTY_NAME);
                    if (AccessTokenVerifier.NAME.equals(tp)) {
                        tp = map.get(AccConst.PARAM_ACCESS_TOKEN_VERIFIER);
                    }
                    safeRedirect(req, resp, AccConfig.getErrorUrl(product, tp));
                }
                
            }
        } catch (AccException e) {
            // do nothing
            LOG.warn("redirect error.", e);
        }
    }
}
