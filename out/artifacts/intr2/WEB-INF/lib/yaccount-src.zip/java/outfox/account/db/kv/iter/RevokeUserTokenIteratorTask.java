/**
 * @(#)RevokeUserToken.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import java.util.Map;
import java.util.Set;

import org.springframework.cache.Cache;

import outfox.account.cache.memcached.MemcachedManager;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.db.in.IPersTokenDB.IPersTokenIter;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class RevokeUserTokenIteratorTask extends AbstractIteratorTask<IPersTokenIter>{
    private Set<String> products = null;
    private Set<String> apps = null;
    private Set<String> tps = null;
    private Map<String,Set<String>> condition = null;
    protected IPersTokenDB persTokenDB= null;
    protected ISessCookieDB sessCookieDB= null;
    private static Cache sessCache = null;
    public RevokeUserTokenIteratorTask(IPersTokenDB persTokenDB, ISessCookieDB sessCookieDB,  String userId, Set<String> products, Set<String> apps, Set<String> tps,
            Map<String, Set<String>> condition) {
        super(persTokenDB, userId);
        this.sessCookieDB = sessCookieDB;
        this.persTokenDB = persTokenDB;
        this.apps = apps;
        this.products = products;
        this.condition = condition;
        this.tps = tps;
        if (AccConfig.getPros().getBoolean(AccConfig.NAME_ENABLE_MEMCACHED_IN_FILTER)) {
            MemcachedManager.getInstance().getCache(AccConst.NAME_SESS_COOKIE_MEMCACHED);
        }
    }

    @Override
    protected boolean isEnd(Object value) {
        // TODO Auto-generated method stub
        return super.isEnd(value);
    }

    /**
     * remove token from store first. 
     * Else, cache may load session cookie again after removing the cookie from cache.
     */
    @Override
    protected void runTask(Object value) throws AccException {
        PersistTokenWritable pers = (PersistTokenWritable)value;
        TpToken tpToken = pers.getTpToken();
        if (isTarget(tpToken, products, apps, tps, condition)) {
            persTokenDB.remove(tpToken);
            sessCookieDB.remove(tpToken);
            removeFromSessCache(tpToken.sessIndex);
        }
    }
    
    public void removeFromSessCache(String sessIndex) {
        if (sessCache == null) {
            return;
        }
        try {
            sessCache.evict(sessIndex);
        } catch(Throwable t) {
            // Quiet
        }
    }
    
    /**
     * If set is null or set has no elements, we consider the condition will be
     * triggered. Or product , app and verifier name of tpToken are contained in
     * sets.
     * 
     * @param tpToken
     * @param products
     * @param apps
     * @param tps
     * @return
     */
    private boolean isTarget(TpToken tpToken, Set<String> products, Set<String> apps, Set<String> tps, Map<String, Set<String>> condition) {
        boolean matchProduct =  (products == null || products.size() == 0 || products.contains(tpToken.product));
        boolean matchApp = (apps == null || apps.size() == 0 || apps.contains(tpToken.app) || apps.contains(AccConfig
                        .getMappingType(tpToken.app)));
        boolean matchTp = (tps == null || tps.size() == 0 || tps.contains(tpToken.verifierName));
        boolean matchCondition = (condition == null || condition.size() == 0 || matchCondition(tpToken, condition));
        return matchProduct && matchApp && matchTp && matchCondition;
    }

    private boolean matchCondition(TpToken tpToken, Map<String, Set<String>> condition) {
        final String app = tpToken.app;
        Set<String> tps = condition.get(app);
        if (tps == null) {
            tps = condition.get(AccConfig.getMappingType(app));
            if (tps == null) {
                return false;
            }
        }
        return tps.contains(tpToken.verifierName);
    }
}
