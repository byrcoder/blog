/**
 * @(#)OAuth2Utils.java, 2012-9-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;

/**
 * @author chen-chao
 */
public class OAuth2Utils {
    private static final Log LOG = LogFactory.getLog(OAuth2Utils.class);
    /**
     * this cookie should be generate each time.
     * 
     * @param req
     * @param resp
     */
    public static void addQueryAttribute(HttpServletRequest req, HttpServletResponse resp) {
        
        String queryString = getNotEmptyQueryString(req);
        req.getSession().setAttribute(AccConst.ATTR_QUERY, queryString);
        String ru = req.getParameter(AccConst.PARAM_REDIRECT_URL_NAME);
        if (StringUtils.isNotBlank(ru)) {
            req.getSession().setAttribute(AccConst.PARAM_REDIRECT_URL_NAME, ru);
        }
        
    }

    protected static String getNotEmptyQueryString(HttpServletRequest req) {
        String queryString = ReqUtils.getQueryString(req);
        if (StringUtils.isBlank(queryString)) {
            queryString = "null";
        }
        return queryString;
    }
    
    
    public static String genState(HttpServletRequest req) {
        String state = AuthUtils.randomStr();
        LOG.info("gen STATE Code:" + state);
        req.getSession().setAttribute(OAuthConstant.CALLBACK_STATE_CODE, state);
        return state;
    }
    
    public static void checkStat(HttpServletRequest req) throws AccException {
        String state = req.getParameter(OAuthConstant.CALLBACK_STATE_CODE);
        final HttpSession session = req.getSession(false);
        if (session == null) {
            throw new AccException("Oauth2 state is not exist", AccExpType.TP_ERROR);
        }
        String origin = (String) session.getAttribute(OAuthConstant.CALLBACK_STATE_CODE);
        session.removeAttribute(OAuthConstant.CALLBACK_STATE_CODE);
        if (origin == null && state != null) {
            throw new AccException("Oauth2 state is not exist", AccExpType.TP_ERROR);
        } else if (origin != null && !origin.equals(state)){
            throw new AccException(String.format("Oauth2 state is not same. maybe attack. origin: %s, now: %s", origin, state), AccExpType.TP_ERROR);
        }
        // origin equals state or (origin == null && state == null) 
    }

    /**
     * this cookie should be generate each time.
     * 
     * @param req
     * @param resp
     */
    public static String getQueryAttribute(HttpServletRequest req, HttpServletResponse resp) {
        HttpSession session = req.getSession(false);
        String queryString = null;
        if (session != null) {
            queryString = (String)session.getAttribute(AccConst.ATTR_QUERY);
        }
        return queryString;
    }
    
}
