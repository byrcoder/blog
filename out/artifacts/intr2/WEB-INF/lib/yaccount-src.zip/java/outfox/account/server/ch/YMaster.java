/**
 * @(#)YMaster.java, 2010-7-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.ch;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.SessionExpiredException;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.zk.Serviceable;
import outfox.account.server.zk.ZooKeeperWatcher;

/**
 * YMaster is the master server for YNote. Each server starts a YMaster
 * when start up, but there is only one active master in the cluster at
 * any time. The others block themselves and wait until master or cluster
 * shutdown or until the active master loses its lease in zookeeper.
 * Thereafter, all running master compete again to take over master role.
 *
 * @author licx
 */
public class YMaster extends Thread implements Serviceable {
    private static final Log LOG = LogFactory.getLog(YMaster.class);

    // Set when the master is stopped
    private volatile AtomicBoolean stopped = new AtomicBoolean(false);

    // Service address of the Master
    private ServerAddress address;

    // Zookeeper connection and watcher
    private ZooKeeperWatcher zooKeeper;

    // Manager and zk listener for master election
    private ActiveMasterManager masterManager;

    // Handles everything related to consistent hash in master
    private ConsistentHashManager hashCircleManager;

    private boolean masterOwner;
    
    /**
     * Initializes the master. The steps are as follows:
     * 1. Initialize master address
     * 2. Connect to ZooKeeper.
     * Remaining steps of initialization occur in {@link #run()} so that they
     * run in their own thread rather than within the context of the constructor.
     * 
     * @throws YDriveException
     */
    public YMaster() throws AccException {
        this("YMaster", AccConfig.getPros().getInt(
                AccConfig.NAME_MASTER_PORT, AccConfig.DEFAULT_MASTER_PORT));
    }

    /**
     * This constructor is usually used in test
     *
     * @param name master thread name
     * @param port http port of the master
     * @throws YDriveException
     */
    public YMaster(String name, int port) throws AccException {
        super(name);
        try {
            this.masterOwner = false;
            this.address = new ServerAddress(
                    InetAddress.getLocalHost().getHostAddress(), port);
            // Open connection to zookeeper and set the primary watcher
            this.zooKeeper = new ZooKeeperWatcher("YMaster", this);
            LOG.info("Start master on " + address);
        } catch (UnknownHostException e) {
            throw new AccRunTimeException(
                    "Fail to obtain the local host address", e);
        }
    }

    public boolean isMasterOwner() {
        return masterOwner;
    }

    @Override
    public ZooKeeperWatcher getZooKeeper() {
        return zooKeeper;
    }

    /**
     * Main processing loop for the master:
     * 1. Block until becoming active master<br/>
     * 2. Finish initialization via {@link #finishInitialization()}<br/>
     * 3. set masterOwner=true<br/>
     * 4. Enter loop until we are stopped<br/>
     * 5. Stop services and perform cleanup once stopped<br/>
     */
    @Override
    public void run() {
        try {
            if (competeActiveMaster()) {
                finishInitialization();
                masterOwner = true;
                synchronized (stopped) {
                    // Check if we should stop every second.
                    while (!stopped.get()) {
                        stopped.wait(1000);
                    }
                }
            } else {
                LOG.warn("Stop waiting to become active master, " +
            		"probably because this master is stopped");
            }
        } catch (Throwable t) {
            LOG.fatal("Unhandled master exception, master would be stopped", t);
        } finally {
            if (masterManager != null) {
                masterManager.stop();
            }
            if (hashCircleManager != null) {
                hashCircleManager.stop();
            }
            stopped.set(true);
        }
        LOG.info("YMaster main thread exiting");
    }

    /**
     * Block on becoming the active master.
     *
     * We compete with other masters to write our address into ZooKeeper. If we
     * succeed, we are the primary/active master and finish initialization.
     *
     * If we do not succeed, there is another active master and we should
     * wait until it dies and then try to become the next active master.
     *
     * @return true if we become the active master
     * @throws KeeperException
     */
    private boolean competeActiveMaster() throws KeeperException {
        masterManager = new ActiveMasterManager(zooKeeper, this, address);
        zooKeeper.registerListener(masterManager);
        LOG.info("Compete to become the active master...");
        return masterManager.blockUntilBecomingActiveMaster();
    }

    /**
     * Finish the initialization of the master in its own thread.
     *
     * Consistent hash is inititialized and synchronized in zookeeper. And
     * {@link ConsistentHashManager} will take charge of the updates of
     * consistent hash over the cluster.
     *
     * Note: This method should not be called until this master becomes the
     * active master in the cluster.
     *
     * @throws YDriveException
     */
    private void finishInitialization() throws AccException {
        int vnodeNum = AccConfig.getPros().getInt(
                AccConfig.NAME_HASH_VNODENUM);
        hashCircleManager = new ConsistentHashManager(this, zooKeeper, vnodeNum);
        zooKeeper.registerListener(hashCircleManager);
        hashCircleManager.start();
    }

    @Override
    public void recover(String why, Exception cause) {
        LOG.warn("Recover master because " + why);
        // stop current master thread and start a new one if this exception
        // is SessionExpiredException
        shutdown();
        if (cause != null && cause instanceof SessionExpiredException) {
            try {
                new YMaster().start();
            } catch (AccException e) {
                LOG.fatal("Fail to recover master from ZooKeeper " +
            		"session expireation", e);
            }
        } else {
            LOG.fatal("Could not recover from this kind of exception", cause);
        }
    }

    @Override
    public boolean isStopped() {
        return stopped.get();
    }

    /**
     * Stop everything except ZooKeeper. Once stopped, this master would
     * not be able to provide any service. All ZooKeeper events would not be
     * received except the state events.
     *
     * <p>This method is usually used when the master is disconnected from
     * ZooKeeper. ZooKeeper client is kept alive so when ZooKeeper is back
     * to normal, an <i>Expired</i> event would be received and this master
     * would try to recover itself.
     *
     * <p>If you want to stop the master totally, call
     * {@link YMaster#shutdown()}.
     */
    @Override
    public void stop(String why) {
        if (stopped.get()) {
            LOG.info("This master has already been stopped...");
            return;
        }

        LOG.fatal("Stop master service because " + why);
        synchronized (stopped) {
            stopped.set(true);
            stopped.notifyAll();
        }

        synchronized (masterManager.hasActiveMaster) {
            masterManager.hasActiveMaster.notifyAll();
        }
    }

    @Override
    public void shutdown() {
        stop("YMaster is shutdown");
        if (zooKeeper != null) {
            zooKeeper.close();
        }
    }
}
