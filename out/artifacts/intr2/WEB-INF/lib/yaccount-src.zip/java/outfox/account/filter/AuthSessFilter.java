/**
 * @(#)AuthFilter.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.handler.BaseHandler;
import outfox.account.server.token.TokenManager;
import outfox.account.utils.AuthUtils;

/**
 * AuthSessFilter should passed firstly.
 * @author chen-chao
 */
public class AuthSessFilter extends BaseHandler implements Filter{
    private static final long serialVersionUID = -2300188484442484442L;
    @Override
    public void doFilter(ServletRequest arg1, ServletResponse arg2, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) arg1;
        HttpServletResponse resp = (HttpServletResponse) arg2;
        try {
            String product = AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME);
            
            if (StringUtils.isNotBlank(product)) {
                TokenManager.verifySessionCookie(product, req, resp);
            }
            if (AuthUtils.isDebug(req)) {
                // debug here.
                LOG.debug("");
            }
            
        } catch (Throwable e) {
            if (AuthUtils.isDebug(req)) {
                // debug here.
                LOG.debug("");
            }
            String errInfo = getQueryUrl(req);
            LOG.warn("request:" + errInfo, e);
            
        }
        chain.doFilter(req, resp);
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        // TODO Auto-generated method stub
        
    }

}
