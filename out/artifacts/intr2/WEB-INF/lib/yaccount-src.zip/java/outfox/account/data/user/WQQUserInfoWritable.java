/**
 * @(#)WQQUserInfoWritable.java, 2012-11-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

import net.sf.json.JSONObject;

/**
 * @author chen-chao
 */
public class WQQUserInfoWritable extends UserInfoWritable{
    private static final long serialVersionUID = 2979242972929769303L;
    public static final String WQQ = "wqq";
    /**
         {
            errcode : 返回错误码,
            msg : 错误信息,
            ret : 返回值，0-成功，非0-失败,
            data : 
            {
                    birth_day : 出生天,
                    birth_month : 出生月,
                    birth_year : 出生年,
                    city_code : 城市id,
                    comp : 
                    {
                            begin_year : 开始年,
                            company_name : 公司名称,
                            department_name : 部门名称,
                            end_year : 结束年,
                            id : 公司id
                    },
                    country_code : 国家id,
                    edu : 教育信息
                    {
                            departmentid : 院系id,
                            id : 教育信息记录id,
                            level : 学历级别,
                            schoolid : 学校id,
                            year : 入学年
                    },
                    fansnum : 听众数,
                    favnum : 收藏数,
                    head : 头像url,
                    homecity_code : 家乡所在城市id,
                    homecountry_code : 家乡所在国家id,
                    homepage : 个人主页,
                    homeprovince_code : 家乡所在省id,
                    hometown_code : 家乡所在城镇id,
                    idolnum : 收听的人数,
                    industry_code : 行业id,
                    introduction : 个人介绍,
                    isent : 是否企业机构,
                    ismyblack : 是否在当前用户的黑名单中，0-不是，1-是,
                    ismyfans : 是否是当前用户的听众，0-不是，1-是,
                    ismyidol : 是否是当前用户的偶像，0-不是，1-是,
                    isrealname : 是否实名认证，0-未实名认证，1-已实名认证,
                    isvip : 是否认证用户，0-不是，1-是,
                    location : 所在地,
                    mutual_fans_num : 互听好友数,
                    name : 用户帐户名,
                    nick : 用户昵称,
                    openid : 用户唯一id，与name相对应,
                    province_code : 地区id,
                    regtime : 注册时间,
                    send_private_flag : 是否允许所有人给当前用户发私信，0-仅有偶像，1-名人+听众，2-所有人,
                    sex : 用户性别，1-男，2-女，0-未填写,
                    tag : 标签
                    {
                            id : 个人标签id,
                            name : 标签名
                    },
                    tweetinfo : 最近的一条原创微博信息
                    {
                            city_code : 城市码,
                            country_code : 国家码,
                            emotiontype : 心情类型,
                            emotionurl : 心情图片url,
                            from : 来源,
                            fromurl : 来源url,
                            geo : 地理位置信息,
                            id : 微博唯一id,
                            image : 图片url列表,
                            latitude : 纬度,
                            location : 发表者所在地,
                            longitude : 经度,
                            music : 音频信息
                            {
                                    author : 演唱者,
                                    url : 音频地址,
                                    title : 音频名字，歌名
                            },
                            origtext : 原始内容,
                            province_code : 省份码,
                            self : 是否自已发的的微博，0-不是，1-是,
                            status : 微博状态，0-正常，1-系统删除，2-审核中，3-用户删除，4-根删除,
                            text : 微博内容,
                            timestamp : 服务器时间戳，不能用于翻页,
                            type : 微博类型，1-原创发表，2-转载，3-私信，4-回复，5-空回，6-提及，7-评论,
                            video : 视频信息
                            {
                                    picurl : 缩略图,
                                    player : 播放器地址,
                                    realurl : 视频原地址,
                                    shorturl : 视频的短url,
                                    title : 视频标题
                            }
                    },
                    tweetnum : 发表的微博数,
                    verifyinfo : 认证信息,
                    exp : 经验值,
                    level : 微博等级
            },
            seqid : 序列号
         }
     */
    public static final String DATA = "data";
    public static final String NICK = "nick";
    public static final String HEAD = "head";
    public static final String NAME = "name";
    public static final String SEX = "sex";
    public static final String IS_VIP = "isvip";
    public static final String IS_REAL_NAME = "isrealname";
    public static final String TRUE = "1";
    public WQQUserInfoWritable() {
        super();
    }
    public WQQUserInfoWritable(String userId,String originalId, JSONObject obj) {
        super();
        this.userId = userId;
        this.originalId = originalId;
        this.from = WQQ;
        
        final JSONObject data = obj.getJSONObject(DATA);
        this.userName = data.getString(NICK);
        this.imageUrl = data.getString(HEAD);
        this.alias = data.getString(NAME);
        setGenderValue(data.getInt(SEX));
        setIsVIP(TRUE.equals(data.getString(IS_VIP)));
        setLocation(data.getString(LOCATION));
        setBirthDay(data.getString(BIRTH_DAY));
        setBirthMonth(data.getString(BIRTH_MONTH));
        setBirthYEAR(data.getString(BIRTH_YEAR));
        setIsRealName(TRUE.equals(data.getString(IS_REAL_NAME)));
    }
    public boolean getIsVIP() {
        return getBooleanProperty(VIP);
    }
    public void setIsVIP(boolean isVip) {
        setBooleanProperty(VIP, isVip);
    }
    
    private void setGenderValue(int value) {
        switch(value) {
            case 1:
                setGender(GENDER_VALUE.MAN);
                break;
            case 2:
                setGender(GENDER_VALUE.WOMEN);
                break;
            default:
                setGender(GENDER_VALUE.UNKNOWN);
                break;        
        }
    }
    
    public void setGender(GENDER_VALUE gender) {
        setProperty(GENDER, gender.name());
    }
    public void setLocation(String location) {
        setProperty(LOCATION, location);
    }
    public String getLocation() {
        return getProperty(LOCATION);
    }
    
    public void setIsRealName(boolean isReal) {
        this.setBooleanProperty(IS_REAL_NAME, isReal);
    }
    public boolean getIsRealName() {
        return getBooleanProperty(IS_REAL_NAME);
    }
    
}
