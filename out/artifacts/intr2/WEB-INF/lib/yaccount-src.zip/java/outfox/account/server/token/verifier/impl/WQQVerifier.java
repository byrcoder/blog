/**
 * @(#)WqqVerifier.java, 2012-9-11. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.data.user.WQQUserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * Access token will be expired after 14 days, refresh token will be expired after 3 * 30 days.
 * @author chen-chao
 *
 */
public class WQQVerifier extends Oauth2Verifier {
    public final String FORMAT_VALUE = "json";

    public final String OAUTH_VERSION_VALUE = "2.a";

    public final String NAME_CLIENT_IP = "clientip";

    public static final String NAME = "wqq";
    
    /**
     * three months
     */
    public static long DEFAULT_WQQ_EXPIRE_TIME = 3 * 30 * 24 * 60 * 60 * 1000L;
    
    /**
     * 14 days
     */
    public static long DEFAULT_WQQ_REFRESH_TIME = 14 * 24 * 60 * 60 * 1000L; 
    private long defaultExpireInMill;
    private long defaultRefreshInMill;
    
    private String accountUrl;
    public WQQVerifier(Properties props) {
        super(props, NAME);
        defaultRefreshInMill = getLongPros(props, NAME + VerifierConfConst.REFRESH_TIME_IN_MILLI, DEFAULT_WQQ_REFRESH_TIME);
        defaultExpireInMill = getLongPros(props, NAME + VerifierConfConst.EXPIRE_TIME_IN_MILLI, DEFAULT_WQQ_EXPIRE_TIME);
        try {
            accountUrl = getAbsoluteUrl(properties.get("accountURL"));
        } catch(AccException e) {
            throw new AccRunTimeException(e);
        }
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // set query cookie and redirect to third-party
        OAuth2Utils.addQueryAttribute(req, resp);

        // prepare params
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.RESPONSE_TYPE, OAuthConstant.AUTHORIZED_CODE));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        String state = OAuth2Utils.genState(req);
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, state));
        // redirect
        if (AccConfig.isStressTest()) {
            stressRedirect(req, resp);
        } else {
            AuthUtils.redirect(resp, getAbsoluteAuthorizeUrl(), params);
        }
        return null;
    }

    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // get access token, expire time, remain, others
        String code = req.getParameter(OAuthConstant.OAUTH2_CODE);
        String openId = req.getParameter(OAuthConstant.QQ_OPEN_ID);
        String openKey = req.getParameter(OAuthConstant.QQ_OPEN_KEY);
        if (StringUtils.isBlank(code) || StringUtils.isBlank(openId) || StringUtils.isBlank(openKey)) {
            throw new AccException("wqq error:" + req.getQueryString(), AccExpType.TP_ERROR);
        }
        List<Parameter> params = new ArrayList<Parameter>();

        params.add(new Parameter(OAuthConstant.GRANT_TYPE, OAuthConstant.GRANT_TYPE_VALUE_AUTHOR_CODE));
        params.add(new Parameter(OAuthConstant.OAUTH2_CODE, code));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, secret));
        String state = AuthUtils.genUniqueToken();
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, state));
        // error: errorCode=10018&errorMsg='Authorization code is illegal'
        // success: access_token=ACCESS_TOKEN&expires_in=60&refresh_token=REFRESH_TOKEN
        String res = AccHttpClient.getInstance().getString(Method.POST, getAbsoluteAccessUrl(), null, params, null);
        throwErrorException(res);
        Map<String, String> map = parseResult(res);
        
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(OAuthConstant.ACCESS_TOKEN, map.get(OAuthConstant.ACCESS_TOKEN));
        result.put(OAuthConstant.REFRESH_TOKEN, map.get(OAuthConstant.REFRESH_TOKEN));
        // use refresh_token as expire time. 3 months
        result.put(OAuthConstant.EXPIRED, defaultExpireInMill);
        result.put(OAuthConstant.REFRESH_TIME, getRefreshTime(map));
        result.put(OAuthConstant.QQ_OPEN_ID, openId.toUpperCase());
        result.put(OAuthConstant.QQ_OPEN_KEY, openKey);
        return result;
    }

    public Map<String, String> parseResult(String result) throws AccException {
        if (StringUtils.isBlank(result)) {
            return null;
        }
        final String SENTENCE_SPLIT_TOKEN = "&";
        final String KEY_VALUE_SPLIT_TOKEN = "=";
        String[] sentences = result.split(SENTENCE_SPLIT_TOKEN);
        Map<String, String> map = new HashMap<String, String>();
        for (String sentence: sentences) {
            String[] kv = sentence.split(KEY_VALUE_SPLIT_TOKEN);
            if (kv.length != 2) {
                throw new AccException("result error:" + result, AccExpType.TP_ERROR);
            }
            map.put(kv[0], kv[1]);
        }
        return map;
    }

    public void throwErrorException(String result) throws AccException {
        // "errorCode=123&errorMsg=something"
        if (result.contains("errorCode=")) {
            throw new AccException(result, null, AccExpType.TP_ERROR, Integer.parseInt(result.substring(
                    result.indexOf("=") + 1, result.indexOf("&"))));
        }
    }

    public void checkApiError(JSONObject obj) throws AccException {
        if (obj == null) {
            throw new AccException("return api result is NULL.", AccExpType.TP_ERROR);
        }
        if (!obj.containsKey("ret")) {
            throw new AccException(obj.toString(), AccExpType.TP_ERROR);
        }
        String ret = obj.getString("ret");
        final int code = Integer.parseInt(ret);
        if (code != 0) {
            throw new AccException(obj.toString(), null, AccExpType.TP_ERROR, code);
        }
    }

    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        thirdPartyTokens.put(AccConst.TOKEN,
                (String) req.getAttribute(OAuthConstant.ACCESS_TOKEN));
        thirdPartyTokens.put(OAuthConstant.REFRESH_TOKEN,
                (String) req.getAttribute(OAuthConstant.REFRESH_TOKEN));
        thirdPartyTokens.put(AccConst.OPEN_ID, (String) req.getAttribute(OAuthConstant.QQ_OPEN_ID));
        thirdPartyTokens.put(OAuthConstant.QQ_OPEN_KEY, (String) req.getAttribute(OAuthConstant.QQ_OPEN_KEY));
        thirdPartyTokens.put(AccConst.IP_ADDRESS, AuthUtils.getRequestIP(req));

        return getUserInfo(thirdPartyTokens);
    }

    /**
     * need openId, access_token, ip
     */
    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        // https://open.t.qq.com/api/user/info?format=json&oauth_consumer_key=xx&access_token=xx&openid=xx&clientip=xx&oauth_version=2.a&scope=xx
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_FORMAT, FORMAT_VALUE));
        params.add(new Parameter(OAuthConstant.QQ_OAUTH_CONSUMER_KEY, appkey));
        String openId = thirdPartyTokens.get(AccConst.OPEN_ID);
        params.add(new Parameter(OAuthConstant.QQ_OPEN_ID, openId));
        params.add(new Parameter(OAuthConstant.ACCESS_TOKEN, thirdPartyTokens.get(AccConst.TOKEN)));
        params.add(new Parameter(NAME_CLIENT_IP, thirdPartyTokens.get(AccConst.IP_ADDRESS)));
        params.add(new Parameter(OAuthConstant.OAUTH_VERSION, OAUTH_VERSION_VALUE));

        JSONObject obj = AccHttpClient.getInstance().getJSON(Method.GET, accountUrl, null,
                params, null);
        checkApiError(obj);
        openId = openId.toUpperCase();
        return new WQQUserInfoWritable(tpId2ownId(openId), openId, obj);
    }

    /**
     * return access_token=ACCESS_TOKEN&expires_in=60&refresh_token=REFRESH_TOKEN&name=NAME
     * @param refreshToken
     * @return
     * @throws AccException
     */
    private Map<String, String> refreshToken(String refreshToken) throws AccException {
        // https://open.t.qq.com/cgi-bin/oauth2/access_token?client_id=APP_KEY&grant_type=refresh_token&refresh_token=REFRESH_TOKEN
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.GRANT_TYPE, OAuthConstant.GRANT_TYPE_REFRESH));
        params.add(new Parameter(OAuthConstant.GRANT_TYPE_REFRESH, refreshToken));
        String state = AuthUtils.genUniqueToken();
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, state));
        String result = AccHttpClient.getInstance().getString(Method.GET, getAbsoluteAccessUrl(), null, params, null);
        throwErrorException(result);
        
        Map<String,String> map =  parseResult(result);
        String nowStat = map.get(OAuthConstant.CALLBACK_STATE_CODE);
        if (!state.equals(nowStat)) {
            throw new AccException(String.format("state is not same, origin:%s, now %s.", state, nowStat), AccExpType.TP_ERROR);
        }
        return map;
    }

    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expireTime) throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expireTime);

        // set access token
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        TpToken tpToken = tokenWritable.getTpToken();
        // refresh token
        if (System.currentTimeMillis() - tpToken.getCreateTime() >= Long.parseLong(tpToken
                .getProperty(OAuthConstant.REFRESH_TIME))) {
            Map<String, String> map = refreshToken(tpToken.refresh);
            tpToken.token = map.get(OAuthConstant.ACCESS_TOKEN);
            tpToken.refresh = map.get(OAuthConstant.REFRESH_TOKEN);
            tpToken.setProperty(OAuthConstant.REFRESH_TIME, Long.toString(getRefreshTime(map)));
            // TODO: asynchronous
            store.writePersToken(tpToken);
        }
        thirdPartyTokens.put(AccConst.TOKEN, tpToken.token);
        thirdPartyTokens.put(AccConst.IP_ADDRESS, AuthUtils.getRequestIP(req));
        thirdPartyTokens.put(AccConst.OPEN_ID, tpToken.getProperty(OAuthConstant.QQ_OPEN_ID));
        
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        // update userInfo
        // TODO update userInfo in other thread
        store.writeUserInfo(userInfo);
        // AccConst.THIRD_PARTY_PERS_TOKEN should not remove
        // has checked in thrid party, but now it is expired
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        return result;
    }

    /**
     * res should contain OAuthConstant.EXPIRES_IN and its unit is second.
     * @param map
     * @return
     */
    private long getRefreshTime(Map<String, String> map) {
        long refreshTime = Long.parseLong(map.get(OAuthConstant.EXPIRES_IN)) * 1000L;
        return defaultRefreshInMill == -1 ? refreshTime : Math.min(refreshTime, defaultRefreshInMill);
    }

    @Override
    public String getVerifierName() {
        return NAME;
    }

    @Override
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException {
        Map<String, Object> newMap = new HashMap<String, Object>(authInfo);
        newMap.remove(OAuthConstant.ACCESS_TOKEN);
        newMap.remove(OAuthConstant.REMIND);
        newMap.remove(OAuthConstant.REFRESH_TOKEN);
        newMap.remove(OAuthConstant.QQ_OPEN_ID);
        newMap.remove(OAuthConstant.QQ_OPEN_KEY);
        return newMap;
    }

}
