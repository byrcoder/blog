/**
 * @(#)RpcCoremailAPI.java, 2012-11-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.coremail;

import javax.jws.WebParam;

/**
 *
 * @author wangxin
 *
 */
@javax.jws.WebService(
        name = "API",
        targetNamespace = "http://coremail.cn/apiws"
)
public interface CoremailAPI {

    String getVersionInfo();

    CoremailReturnInfo getAttrs(@WebParam(name = "user_at_domain") String userAtDomain,
                                @WebParam(name = "attrs") String attrs);
    
    CoremailReturnInfo sesTimeOut(@WebParam(name = "ses_id")String sid);
}