/**
 * @(#)TimeUtil.java, 2012-4-10. 
 * Copyright 2011 Yodao, Inc. All rights reserved. 
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * This class has some constant values about time and computing time interval
 * methods
 * 
 * @author chen-chao
 */
public final class TimeUtil {
    // print log at X:59 clock, X will be 0~23
    public static final int END_MIN = 59;

    // print log at 23:59
    public static final int END_HOUR = 23;

    // milliseconds (1 minute)
    public static final long MIN_MILLISECONDS = 1000 * 60;

    // milliseconds(1 hour)
    public static final long HOUR_MILLISECONDS = MIN_MILLISECONDS * 60;

    // milliseconds(1 day)
    public static final long DAY_MILLISECONDS = HOUR_MILLISECONDS * 24;

    // milliseconds(a week)
    public static final long WEEK_MILLISECONDS = DAY_MILLISECONDS * 7;

    // 2 minutes
    public static final long TWO_MINUTES_MILLISECONDS = MIN_MILLISECONDS * 2;

    /**
     * On the same hour, compute time interval between current to end. For
     * example: present is 10:30, end will be 10:40 The time interval will be 10
     * * 60 * 1000 milliseconds.
     * 
     * @param endMin
     *        end time
     * @return time interval (show as milliseconds, accurate to minute)
     */
    public static long computeTimeInterval(int endMin) {
        GregorianCalendar currCalendar = new GregorianCalendar();
        GregorianCalendar endCalendar = new GregorianCalendar(currCalendar
                .get(Calendar.YEAR), currCalendar.get(Calendar.MONTH),
                currCalendar.get(Calendar.DAY_OF_MONTH), currCalendar
                        .get(Calendar.HOUR_OF_DAY), endMin, currCalendar
                        .get(Calendar.SECOND));
        Date currDate = currCalendar.getTime();
        Date endDate = endCalendar.getTime();
        // divide MIN_TO_MILLISECONDS and multiply MIN_TO_MILLISECONDS again
        // try to avoid executing the task at the last second in minute.
        return (endDate.getTime() - currDate.getTime()) / MIN_MILLISECONDS
                * MIN_MILLISECONDS;
    }

    /**
     * In the same day, compute time interval between current to end. For
     * example: present is 10:30, end will be 11:40 The time interval will be 70
     * * 60 * 1000 milliseconds.
     * 
     * @param endHour
     *        end hour
     * @param endMin
     *        end minute
     * @return time interval (show as milliseconds, accurate to minute)
     */
    public static long computeTimeInterval(int endHour, int endMin) {
        GregorianCalendar currCalendar = new GregorianCalendar();
        GregorianCalendar endCalendar = new GregorianCalendar(currCalendar
                .get(Calendar.YEAR), currCalendar.get(Calendar.MONTH),
                currCalendar.get(Calendar.DAY_OF_MONTH), endHour, endMin,
                currCalendar.get(Calendar.SECOND));
        Date currDate = currCalendar.getTime();
        Date endDate = endCalendar.getTime();
        return (endDate.getTime() - currDate.getTime()) / MIN_MILLISECONDS
                * MIN_MILLISECONDS;
    }
}
