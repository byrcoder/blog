/**
 * @(#)AccRpcClient.java, 2012-9-3. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.client;

import java.util.HashMap;
import java.util.Map;

import odis.rpc2.RPC;
import odis.rpc2.RpcException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.zk.ZkHashDistributeStrategy;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public abstract class AccRpcClient {
    protected static final Log LOG = LogFactory.getLog(AccRpcClient.class);
    private static final int TIMEOUT = AccConfig.getPros().getInt(
            AccConfig.NAME_RPC_SERVICE_TIMEOUT);

    protected static final boolean USE_LOCAL_SERVICE = AccConfig.getPros().getBoolean(
            AccConfig.NAME_RPC_USE_LOCAL_SERVICE);
    protected ZkHashDistributeStrategy strategy;
    protected Map<ServerAddress, Object> rpcServices;
    
    protected Class<?> rpcProtocalClazz;
    protected Object localProtocalService;
    
    public AccRpcClient(Class<?> rpcProtocalClazz, Object localProtocalService) {
        try {
            strategy = new ZkHashDistributeStrategy();
        } catch (AccException e) {
            throw new AccRunTimeException("init ZkHashDistributeStrategy failed.", e);
        }
        rpcServices = new HashMap<ServerAddress, Object>();
        this.rpcProtocalClazz = rpcProtocalClazz;
        this.localProtocalService = localProtocalService;
    }
    
    public Object lookup(String key) throws AccException {
        ServerAddress address = strategy.lookupService(key);
        
        Object service = rpcServices.get(address);
        if (service == null) {
            if (USE_LOCAL_SERVICE && AuthUtils.isLocal(address.getIP())) {
                service = localProtocalService;
                rpcServices.put(address, localProtocalService);
            } else {
                try {
                    service = RPC.getProxy(rpcProtocalClazz, address.getInetSocketAddress(), TIMEOUT);
                    rpcServices.put(address, service);
                } catch (RpcException e) {
                    throw new AccRunTimeException("Cache rpc proxy can not init.", e);
                }
            }
            rpcServices.put(address, service);
        } 
        return service;
    }
    
    /**
     * stop client
     * @param why
     */
    public void stop(String why) {
        LOG.info("stop rpc client. reson:" + why);
        for (Object services : rpcServices.values()) {
            RPC.close(services);
        }
        rpcServices.clear();
        LOG.info("stop rpc client done.");
    }
}
