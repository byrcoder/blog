/**
 * @(#)Listeners.java, 2013-6-4. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.logic;

import java.util.EventListener;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;

import net.spy.memcached.internal.BasicThreadFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.device.listener.DeviceOnlineListener;
import outfox.account.device.listener.DeviceSmsNotifyListener;
import outfox.account.exceptions.AccException;
import outfox.account.logic.event.AccEvent;

/**
 * Event name => Listeners list
 * @author chen-chao
 */
public class ListenerManager {
    private static final Log LOG = LogFactory.getLog(ListenerManager.class);
    private CopyOnWriteArrayList<EventListener> list;
    private static volatile ListenerManager instance;
    private ExecutorService service;
    public static ListenerManager getInstance() {
        if (instance == null) {
            synchronized (ListenerManager.class) {
                if(instance == null) {
                    instance = new ListenerManager();
                }
            }    
        }
        return instance;
    }
    private ListenerManager() {
        list = new CopyOnWriteArrayList<EventListener>();
        service = new ThreadPoolExecutor(0, AccConfig.getPros()
                .getInt(AccConfig.NAME_EVENT_NOTIFY_QUEUE_SIZE), 60L, 
                TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(), 
                new BasicThreadFactory("EventExecutor", true), 
                new AbortPolicy());
        registerListener(new DeviceSmsNotifyListener());
        registerListener(new DeviceOnlineListener());
    }
    
    public void registerListener(EventListener listener){
        if (listener == null) {
            return;
        }
        list.add(listener);    
    }
    
    public void removeListener(EventListener listener) {
        if (listener == null) {
            return;
        }
        list.remove(listener);
    }
    
    public void notifyEvents(List<AccEvent> eventList) {
        if (eventList == null){
            return;
        }
        for (AccEvent event : eventList) {
            service.execute(new EventExecutor(event, list));
        }
    }
    
    public static class EventExecutor implements Runnable {
        private AccEvent event;
        private List<EventListener> listeners;
        public EventExecutor(AccEvent event, List<EventListener> listeners) {
            this.event = event;
            this.listeners = listeners;
        }
        @Override
        public void run() {
            try {
                for(EventListener listener : listeners) {
                    event.notify(listener);
                }
            } catch(AccException e) {
                LOG.warn("EventExecutor error. catch AccException event type:"
                        + event.getClass() + " string:" + event, e);
            } catch(Throwable t) {
                LOG.warn("EventExecutor error. catch throwable. event type:" +
                        event.getClass() + " string:" + event, t);
            }
        }
        
    }
}
