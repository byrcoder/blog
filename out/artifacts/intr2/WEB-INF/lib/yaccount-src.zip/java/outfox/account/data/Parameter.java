/**
 * @(#)Parameter.java, 2012-9-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class Parameter implements Comparable<Parameter>{
    public String key;
    public Object val;
    public Parameter(String key, Object val) {
        this.key = key;
        this.val = val;
    }
    public String getStrVal() {
        return val == null ? null : AuthUtils.toString(val);
    }
    public String getKey() {
        return key;
    }
    public Object getValue() {
        return val;
    }
    @Override
    public int compareTo(Parameter o) {
        return key.compareTo(o.key);
    }
}
