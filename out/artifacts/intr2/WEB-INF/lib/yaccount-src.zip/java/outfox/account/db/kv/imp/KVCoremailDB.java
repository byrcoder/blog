/**
 * @(#)OmapPersTokenDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.data.coremail.CoremailDataWritable;
import outfox.account.db.in.ICoremailDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.db.kv.IKeyValueStore.Iter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class KVCoremailDB extends BaseKVDB implements ICoremailDB {
    /**
     * for auth1.0
     */
    private static final String STORE_NAME = "coremailData";

    /**
     * key: userid, signature value, product+app+verifer 
     * value: PersistTokenWritable
     */
    private static final String[] types = {
        "VINTSTRING",
        "CUSTOM(outfox.account.data.coremail.CoremailDataWritable)"
    };

    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;

    @SuppressWarnings("unchecked")
    public KVCoremailDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }

    /**
     * if persist token is expired, will remove session cookies.
     */
    @Override
    public CoremailDataWritable read(String domain) throws AccException {
        if (StringUtils.isBlank(domain)) {
            return null;
        }
        CoremailDataWritable data = new CoremailDataWritable();
        return kvStore.readValue(new StringWritable(domain), data) ?  data : null;
    }
    @Override
    public void writeCoremailDomainURL(String domain, String url)
            throws AccException {
        if (StringUtils.isNotBlank(domain) && StringUtils.isNotBlank(url)) {
            CoremailDataWritable data = new CoremailDataWritable(url);
            data.setDomain(domain);
            kvStore.writeKeyValue(new StringWritable(domain),data);
        }
    }
    @Override
    public void removeCoremailDomainURL(String domain) throws AccException {
        if (StringUtils.isNotBlank(domain)) {
            kvStore.deleteKey(new StringWritable(domain));
        }
    }
    
    /**
     * compatible auth1.0
     * @return
     * @throws AccException
     */
    public Iter<IWritableComparable, IWritable> getCoremailIter()
            throws AccException {
        return kvStore.getIter();
    }

    @Override
    public ICoremailIter getIter(String domain) throws AccException {
        
        return new KVCoremailIter(domain);
    }
    
    /**
     * thread unsafe
     *
     * @author chen-chao
     *
     */
    private class KVCoremailIter implements ICoremailIter {
        private Iter<IWritableComparable, IWritable> iter = null;
        private StringWritable key = null;
        public KVCoremailIter(String startKey) throws AccException {
            try {
                iter = kvStore.getIter();
                if (StringUtils.isBlank(startKey)) {
                    key = new StringWritable();
                } else {
                    key = new StringWritable(startKey);
                    iter.seekTo(key, false);
                }
            } catch (AccException e) {
                AuthUtils.disposeException(e, AccExpType.STORE_SERVICE_EXCEPTION);
            }
        }

        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         * @throws AccException 
         */
        @Override
        public CoremailDataWritable next() throws AccException {
            CoremailDataWritable value = new CoremailDataWritable();
            if (!iter.next(key, value)) {
                return null;
            }
            return value;
        }

        @Override
        public void close() {
            AuthUtils.closeQuiet(iter);
        }
    }
    
    @Override
    public ICoremailIter getIter(Object... startKeys) throws AccException {
        if (startKeys == null || startKeys.length == 0) {
            return getIter("");
        }
        return getIter(startKeys[0].toString());
    }
}
