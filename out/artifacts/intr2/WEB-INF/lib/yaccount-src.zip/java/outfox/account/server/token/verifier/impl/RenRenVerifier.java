/**
 * @(#)RenRenVerifier.java, 2012-11-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.entity.UrlEncodedFormEntity;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.RenRenUserInfoWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class RenRenVerifier extends Oauth2Verifier {

    private long defaultExpireInMill;

    private long defaultRefreshInMill;

    /**
     * never
     */
    public static long DEFAULT_RENREN_EXPIRE_TIME = -1L;

    /**
     * one day
     */
    public static long DEFAULT_RENREN_REFRESH_TIME = 24 * 60 * 60 * 1000L;
    
    public static final String FORCE_LOGIN = "x_renew";
    public static final String FORCE_LOGIN_VALUE = "true";
    public static final String KEY_USER = "user";
    public static final String KEY_ID = "id";

    private static final String RENREN_SIGNATURE = "sig";
    private static final String VERSION = "v";
    private static final String VERSION_VALUE = "1.0";
    private static final String FORMAT = "format";
    private static final String FORMAT_VALUE = "JSON";
    
    private static final String METHOD_NAME = "method";
    private static final String METHOD_GET_USER_INFO = "users.getInfo";
    private static final String METHOD_GET_USER_ID = "users.getLoggedInUser";    
    
    public static final String API_KEY = "api_key";
    
    public static final String UID = "uid";
    public static final String UIDS = "uids";
    public static final String FIELDS = "fields";
    public static final String FIELDS_VALUE = "name,sex,vip,birthday,headurl,star,zidou";
    private String apiUrl;
    public RenRenVerifier(Properties props) {
        super(props, NAME);
        defaultRefreshInMill = getLongPros(props, NAME + VerifierConfConst.REFRESH_TIME_IN_MILLI,
                DEFAULT_RENREN_REFRESH_TIME);
        defaultExpireInMill = getLongPros(props, NAME + VerifierConfConst.EXPIRE_TIME_IN_MILLI,
                DEFAULT_RENREN_EXPIRE_TIME);
        apiUrl = properties.get("apiURL");
    }

    public static final String NAME = "renren";

    @Override
    public String getVerifierName() {
        return NAME;
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // set query cookie and redirect to third-party
        OAuth2Utils.addQueryAttribute(req, resp);

        // prepare params
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.RESPONSE_TYPE, OAuthConstant.AUTHORIZED_CODE));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, OAuth2Utils.genState(req)));
        if (AuthUtils.getReqBoolean(req, AccConst.ATTR_FORCE_LOGIN, false)) {
            params.add(new Parameter(FORCE_LOGIN, FORCE_LOGIN_VALUE));
        }
        // redirect
        if (AccConfig.isStressTest()) {
            stressRedirect(req, resp);
        } else {
            AuthUtils.redirect(resp, getAbsoluteAuthorizeUrl(), params);
        }
        return null;
    }

    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // get access token, expire time, remain, others
        String code = req.getParameter(OAuthConstant.OAUTH2_CODE);
        if (StringUtils.isBlank(code)) {
            throw new AccException("renren error:" + req.getQueryString(), AccExpType.TP_ERROR);
        }
        List<Parameter> params = new ArrayList<Parameter>();

        params.add(new Parameter(OAuthConstant.GRANT_TYPE, OAuthConstant.GRANT_TYPE_VALUE_AUTHOR_CODE));
        params.add(new Parameter(OAuthConstant.OAUTH2_CODE, code));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, secret));
        // error: errorCode=10018&errorMsg='Authorization code is illegal'
        JSONObject res = AccHttpClient.getInstance().getJSON(Method.GET, getAbsoluteAccessUrl(), null, params, null);
        // {"expires_in":2594344,"refresh_token":"177001|0.lz3Ox7sycrYtgTM5.268888","user":{"id":2002,"name":"xxxname","avatar":[{"type":"avatar","url":"http://head.xiaonei.com/min4.jpg"},{"type":"tiny","url":"http://head.xiaonei.com/min5.jpg"},{"type":"main","url":"http://head.xiaonei.com/mid.jpg"},{"type":"large","url":"http://head.xiaonei.com/mid.jpg"}]},"access_token":"177001|6.9f2318be288bdf91f091c312e2c1477a.2592000.1355540400-200267592"}
        throwErrorException(res);
        System.out.println(res);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(OAuthConstant.ACCESS_TOKEN, res.getString(OAuthConstant.ACCESS_TOKEN));
        result.put(OAuthConstant.REFRESH_TOKEN, res.getString(OAuthConstant.REFRESH_TOKEN));
        // use refresh_token as expire time. 3 months
        result.put(OAuthConstant.EXPIRED, defaultExpireInMill);
        result.put(OAuthConstant.REFRESH_TIME, getRefreshTime(res));
        
        result.put(UID, res.getJSONObject(KEY_USER).getInt(KEY_ID));
        return result;
    }

    /**
     * res should contain OAuthConstant.EXPIRES_IN and its unit is second.
     * @param map
     * @return
     */
    private long getRefreshTime(JSONObject res) {
        long refreshTime = res.getLong(OAuthConstant.EXPIRES_IN) * 1000L;
        return defaultRefreshInMill == -1 ? refreshTime : Math.min(refreshTime, defaultRefreshInMill);
    }

    private void throwErrorException(JSONObject result) throws AccException {
        // {"error":"invalid_grant","error_code":20204,"error_description":"Invalid authorization code: xn7HFma8AzTLqtEdy1QJnn71ubrOBaaD1"}
        if (result.containsKey("error_code")) {
            throw new AccException(result.toString(), null , AccExpType.TP_ERROR, result.getInt("error_code"));
        }
    }

    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        thirdPartyTokens
                .put(AccConst.TOKEN, AuthUtils.getReqVal(req, OAuthConstant.ACCESS_TOKEN));
        thirdPartyTokens.put(AccConst.OPEN_ID, AuthUtils.getReqObjAttr(req, UID, "").toString());
        return getUserInfo(thirdPartyTokens);
    }

    /**
     * <pre>
     * return:
     * {
     *   "access_token": "10000|5.a6b7dbd428f731035f771b8d15063f61.86400.1292922000-222209506",
     *   "expires_in": 87063,
     *   "refresh_token": "10000|0.385d55f8615fdfd9edb7c4b5ebdc3e39-222209506",
     * }
     * </pre>
     * 
     * @param refreshToken
     * @return
     * @throws AccException
     */
    private JSONObject refreshToken(String refreshToken) throws AccException {
        // reqest: https://graph.renren.com/oauth/token?grant_type=refresh_token&refresh_token=...&client_id=...&client_secret=...
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, appkey));
        params.add(new Parameter(OAuthConstant.GRANT_TYPE, OAuthConstant.GRANT_TYPE_REFRESH));
        params.add(new Parameter(OAuthConstant.GRANT_TYPE_REFRESH, refreshToken));
        JSONObject result = AccHttpClient.getInstance().getJSON(Method.GET, getAbsoluteAccessUrl(), null, params, null);
        throwErrorException(result);

        return result;
    }
    
    private List<Parameter> perpareAPIParameters(List<Parameter> params, String accessToken, String methodName) throws AccException {
        params.add(new Parameter(OAuthConstant.ACCESS_TOKEN, accessToken));
        params.add(new Parameter(FORMAT, FORMAT_VALUE));
        params.add(new Parameter(VERSION, VERSION_VALUE));
        params.add(new Parameter(METHOD_NAME, methodName));
        params.add(new Parameter(API_KEY, appkey));
        params.add(new Parameter(RENREN_SIGNATURE, sign(params)));
        return params;
    }
    
    private JSONObject callOpenAPI(List<Parameter> params, String accessToken, String methodName) throws AccException {
        perpareAPIParameters(params, accessToken, methodName);
        UrlEncodedFormEntity entity = AccHttpClient.composeUrlEncodingEntity(params, AccConst.UTF8);
        String res = AccHttpClient.getInstance().getString(Method.POST, apiUrl, null, null, entity);
        if (res.startsWith("[")) {
            res = res.substring(1, res.length() - 1);
        }
        return JSONObject.fromObject(res);
    }
    
    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        String uid = thirdPartyTokens.get(AccConst.OPEN_ID);
        if (StringUtils.isBlank(uid)) {
            uid = getUserId(thirdPartyTokens);
        }
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(UIDS, uid));
        params.add(new Parameter(FIELDS, FIELDS_VALUE));
        JSONObject res = callOpenAPI(params, thirdPartyTokens.get(AccConst.TOKEN), METHOD_GET_USER_INFO);
        throwErrorException(res);
        return new RenRenUserInfoWritable(tpId2ownId(uid),uid, res);
    }
    
    private String getUserId(Map<String, String> thirdPartyTokens) throws AccException{
        List<Parameter> params = new ArrayList<Parameter>();
        JSONObject obj = callOpenAPI(params, thirdPartyTokens.get(AccConst.TOKEN), METHOD_GET_USER_ID);
        throwErrorException(obj);
        return obj.getString(UID);
    }

    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expireTime) throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expireTime);

        // set access token
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        TpToken tpToken = tokenWritable.getTpToken();
        // refresh token
        if (System.currentTimeMillis() - tpToken.getCreateTime() >= Long.parseLong(tpToken
                .getProperty(OAuthConstant.REFRESH_TIME))) {
            JSONObject res = refreshToken(tpToken.refresh);
            tpToken.token = res.getString(OAuthConstant.ACCESS_TOKEN);
            tpToken.refresh = res.getString(OAuthConstant.REFRESH_TOKEN);
            tpToken.setProperty(OAuthConstant.REFRESH_TIME, Long.toString(getRefreshTime(res)));
            thirdPartyTokens.put(AccConst.OPEN_ID, Integer.toString(res.getJSONObject(KEY_USER).getInt(KEY_ID)));
            // TODO: asynchronous
            store.writePersToken(tpToken);
        }
        thirdPartyTokens.put(AccConst.TOKEN, tpToken.token);
        
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        // update userInfo
        // TODO update userInfo in other thread
        store.writeUserInfo(userInfo);
        // AccConst.THIRD_PARTY_PERS_TOKEN should not remove
        // has checked in thrid party, but now it is expired
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        return result;
    }
    @Override
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException {
        Map<String, Object> newMap = new HashMap<String, Object>(authInfo);
        newMap.remove(OAuthConstant.ACCESS_TOKEN);
        newMap.remove(OAuthConstant.REFRESH_TOKEN);
        newMap.remove(OAuthConstant.SCOPE);
        return newMap;
    }

    private static String SYMBOL_EQUAL = "=";
    private String sign(List<Parameter> params) throws AccException {
        if (params == null  || params.size() == 0) {
            throw new AccException("can not sign params. params is empty.", AccExpType.TP_ERROR);
        }
        Parameter[] sort = new Parameter[params.size()];
        params.toArray(sort);
        Arrays.sort(sort);
        StringBuilder sb = new StringBuilder();
        for(Parameter param : sort) {
            sb.append(param.key).append(SYMBOL_EQUAL).append(param.val);
        }
        sb.append(secret);
        return DigestUtils.md5Hex(sb.toString());
    }
}
