/**
 * @(#)AuthPersFilter.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.handler.BaseHandler;
import outfox.account.server.token.TokenManager;
import outfox.account.utils.AuthUtils;

/**
 * set user id.
 * 
 * @author chen-chao
 */
public class AuthPersFilter extends BaseHandler implements Filter {
    private static final long serialVersionUID = -8602629918109714494L;

    private boolean wantPerTokenForce = false;

    @Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) arg0;
        HttpServletResponse resp = (HttpServletResponse) arg1;
        try {
            String product = AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME);
            if (StringUtils.isNotBlank(product)) {
                verifierAuthToken(req, resp, product);
            }
            
        } catch (Throwable e) {
            if (AuthUtils.isDebug(req)) {
                // debug here.
                LOG.debug("");
            }
            String errInfo = getQueryUrl(req);
            LOG.warn("request:" + errInfo, e);
        }
        chain.doFilter(req, resp);
    }

    public void verifierAuthToken(HttpServletRequest req, HttpServletResponse resp, String product)
            throws AccException {
        if (!wantPerTokenForce
                && req.getAttribute((product) + AccConst.ATTR_PART_SESS_WRITABLE) != null) {
            return;
        }
        Map<String, Object> result = TokenManager.verifyAuthToken(product, req, resp);
        if (AuthUtils.isDebug(req)) {
            // debug here.
            LOG.debug(result);
        }
    }

    @Override
    public void init(FilterConfig config) throws ServletException {
        // no matter whether session writable is set.
        wantPerTokenForce = Boolean.parseBoolean(config.getInitParameter("wantPersTokenForce"));
    }

}
