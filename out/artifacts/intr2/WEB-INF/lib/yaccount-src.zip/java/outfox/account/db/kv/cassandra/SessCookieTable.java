package outfox.account.db.kv.cassandra;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.QueryOptions;
import com.datastax.driver.core.Session;
import org.apache.commons.lang.StringUtils;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.exceptions.AccException;
import toolbox.cassandra.client.CassandraClient;
import toolbox.cassandra.client.exception.CassandraRuntimeException;
import toolbox.cassandra.client.exception.NotFoundException;
import toolbox.cassandra.client.protocol.Keyspace;
import toolbox.cassandra.client.protocol.Table;

import java.util.List;

/**
 * @author yangzhe
 * @version created on 14-9-3.
 */
public class SessCookieTable implements ISessCookieDB {

    Keyspace keyspace;
    Table<SessCookieEntity> table;
    Session session;

    public SessCookieTable() {
        try {
            keyspace = CassandraClient.getInstance(new QueryOptions().setConsistencyLevel(ConsistencyLevel.QUORUM))
                    .getKeyspace("dict_account_server");
        } catch (NotFoundException e) {
            e.printStackTrace();
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
        table = keyspace.openTable("sesscookie");
        session = keyspace.getGlobalSession();
    }


    @Override
    public SessionCookieWritable write(TpToken tp) throws AccException {
        if (tp == null) {
            return null;
        }
        SessionCookieWritable value = new SessionCookieWritable(tp);
        try {
            table.update(new SessCookieEntity(tp.sessIndex, value));
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }
        return value;
    }

    @Override
    public SessionCookieWritable read(String sessIndex) throws AccException {
        if (StringUtils.isBlank(sessIndex)) {
            return null;
        }
        try {
            List<SessCookieEntity> list = table.resultSetToEntityList(table.get(sessIndex), new SessCookieEntity());
            if (list.size() > 0) {
                return list.get(0).toWritable();
            }
        } catch (CassandraRuntimeException e) {
            throw new AccException(e);
        }
        return null;
    }

    @Override
    public SessionCookieWritable read(TpToken tpToken) throws AccException {
        if (tpToken == null) {
            return null;
        }
        return read(tpToken.sessIndex);
    }

    @Override
    public void remove(TpToken tp) throws AccException {
        if (tp == null) {
            return;
        }
        remove(tp.sessIndex);
    }

    @Override
    public void remove(String sessIndex) throws AccException {
        if (StringUtils.isBlank(sessIndex)) {
            return;
        }
        try {
            table.delete(sessIndex);
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }

    }

    //iter是为了定期执行清理数据的task的，cassandra不这么搞，留空
    private class KVSessCookieIter implements ISessCookieIter {

        public KVSessCookieIter(String sessIndex) throws AccException {

        }

        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         *
         * @throws AccException
         */
        @Override
        public SessionCookieWritable next() throws AccException {
            return null;
        }

        @Override
        public void close() {
        }
    }

    @Override
    public ISessCookieIter getIter(String sessIndex) throws AccException {
        return new KVSessCookieIter(sessIndex);
    }

    @Override
    public ISessCookieIter getIter(Object... startKeys) throws AccException {
        if (startKeys != null) {
            return getIter((String) startKeys[0]);
        }

        throw new AccException("no start keys", AccException.AccExpType.NOT_SUPPORT);
    }
}
