/**
 * @(#)QJVerifier.java, 2013-2-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.data.user.PhoneQJUserInfoWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.verifier.ITokenVerifier;
import outfox.account.server.token.verifier.Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient;

/**
 * @author chen-chao
 */
public class PhoneQJVerifier extends Verifier implements ITokenVerifier {
    private String baseUrl;
    public static final String PARAM_CLASS = "class";
    public static final String VALUE_CLASS_OAUTH = "oauth";
    public static final String PARAM_METHOD = "method";
    public static final String VALUE_METHOD_CHECK_TOKEN = "is_unique_token_exists";
    public static final String PARAM_TOKEN = "token";
    public static final String RES_STATUS = "status";
    public static final String RES_RESULT = "results";
    public PhoneQJVerifier(Properties props) {
        super(props);
        baseUrl = getAndCheck(props, NAME + VerifierConfConst.BASE_URL);
        idPattern = getAndCheck(props, NAME + VerifierConfConst.ID);
        getIdPrefix();
    }

    public static final String NAME = "qj";
    @Override
    public String getVerifierName() {
        return NAME;
    }


    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        // https://friutapi.7g.cn/?class=oauth&method=is_unique_token_exists&token=xxx
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(PARAM_CLASS, VALUE_CLASS_OAUTH));
        params.add(new Parameter(PARAM_METHOD, VALUE_METHOD_CHECK_TOKEN));
        String token = thirdPartyTokens.get(AccConst.TOKEN);
        params.add(new Parameter(PARAM_TOKEN, token));
        HttpResponse resp = null;
        StringBuilder info = new StringBuilder();
        String userId = null;
        try {
            resp = AccHttpClient.getInstance().doGet(baseUrl, null, params);
            int statusCode = resp.getStatusLine().getStatusCode();
            info.append("QJ http status code:").append(statusCode);
            if (statusCode == 200) {
                // exist  {results:7e8d8f36541955671061e48371b858d8 ,message:'',status:200}
                // not exist {results:0 ,message:'',status:200}
                // error {results:0 ,message:'',status:2xx}
                JSONObject result = JSONObject.fromObject(AuthUtils.getStringResponse(resp));
                info.append("QJ return result:").append(result);
                int status = result.getInt(RES_STATUS);
                if (status == 200) {
                    userId = result.getString(RES_RESULT);
                    if ("0".equals(userId)) {
                        throw new AccException(info.toString(), null, AccExpType.FAKE_TOKEN, 0);
                    } 
                } else {
                    throw new AccException(info.toString(), null, AccExpType.QJ_SERVER_ERROR, status);
                }
            } else {
                throw new AccException(info.toString(), null, AccExpType.QJ_SERVER_ERROR, statusCode);
            }
        } finally {
            AccHttpClient.closeQuiet(resp);
        }
        PhoneQJUserInfoWritable userInfo = new PhoneQJUserInfoWritable(tpId2ownId(userId), userId);
        return userInfo;
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        throw new AccException("not support",AccExpType.NOT_SUPPORT);
    }

}
