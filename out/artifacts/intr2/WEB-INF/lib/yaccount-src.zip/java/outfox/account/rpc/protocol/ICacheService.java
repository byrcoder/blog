/**
 * @(#)ICacheService.java, 2012-7-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.protocol;

import odis.rpc2.RpcException;
import outfox.account.exceptions.AccException;

/**
 *
 * @author wangfk, chen-chao
 *
 */
public interface ICacheService {
    /**
     * @param key
     * @return value indexed by the key, return null if not exists
     * @throws YDriveException
     * @throws RpcException
     */
    public byte[] getBytesValue(String key) throws AccException, RpcException;

    public void putBytesValue(String key, byte[] value) throws AccException, RpcException;

    /**
     * @param key
     * @return the value to be removed, null if not exists
     * @throws YDriveException
     * @throws RpcException
     */
    public byte[] removeBytesValue(String key) throws AccException, RpcException;
}
