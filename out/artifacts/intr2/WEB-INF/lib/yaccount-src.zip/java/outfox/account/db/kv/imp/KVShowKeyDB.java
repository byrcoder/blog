/**
 * @(#)KVShowKey.java, 2012-12-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;
import outfox.account.conf.AccConfig;
import outfox.account.db.in.IShowKeyDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class KVShowKeyDB extends BaseKVDB implements IShowKeyDB{
    private static final String STORE_NAME = "accShowKey";
    /**
     * key: showKey 
     * value : showKey
     */
    private static final String[] types = {
        "VINTSTRING",
        "VINTSTRING"
    };
    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;
    @SuppressWarnings("unchecked")
    public KVShowKeyDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }
    
    public void write(String key) throws AccException {
        if (key == null) {
            return;
        }
        StringWritable keyWritable = new StringWritable(key);
        kvStore.writeKeyValue(keyWritable, keyWritable);
    }
    
    public String read(String key) throws AccException {
        StringWritable value = new StringWritable();
        if (kvStore.readValue(new StringWritable(key), value)) {
            return key;
        } else {
            return null;
        }
    }
    
    public void remove(String key) throws AccException {
        kvStore.deleteKey(new StringWritable(key));
    }
}
