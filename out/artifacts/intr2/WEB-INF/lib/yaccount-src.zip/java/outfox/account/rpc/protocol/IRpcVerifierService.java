/**
 * @(#)ISessionCookieVerifier.java, 2012-8-15. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.protocol;

import java.util.Map;

import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.exceptions.AccException;
import odis.rpc2.RpcException;

/**
 * RPC protocol for the youdao service to verify session cookie from account server
 *
 * @author wangfk, chen-chao
 *
 */
public interface IRpcVerifierService {
    /**
     * @param sessionCookie
     * @param expiryTimeInMilli
     * @return userid if session cookie is valid, else <code>null</code>
     * @throws RpcException
     * @throws AccException 
     */
    public SessionCookieWritable verifySessionCookie(String sessionCookie, String product,
            long expireTimeInMilli) throws RpcException, AccException;
    
    public PersistTokenWritable verifyAuthToken(String token, String product, long expireTimeInMilli)
            throws RpcException, AccException;
    
    public PersistTokenWritable verifyAuthToken(String token, long expireTimeInMilli)
            throws RpcException, AccException;

    public SessionCookieWritable verifySessionCookie(String sessionCookie, long expireTimeInMilli)
            throws RpcException, AccException;

    PersistTokenWritable verifyAuthToken(String token, long expireTimeInMilli, String ip)
            throws RpcException, AccException;

    PersistTokenWritable verifyAuthToken(Map<String, Object> info, String token, long expireTimeInMilli)
            throws RpcException, AccException;
}
