/**
 * @(#)IUserInfoDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IUserInfoDB {

    UserInfoWritable write(UserInfoWritable userinfo) throws AccException;
    public UserInfoWritable read(String userId) throws AccException;
}
