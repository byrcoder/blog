/**
 * @(#)IKeyValueStore.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv;

import java.io.Closeable;
import java.io.IOException;

import outfox.account.exceptions.AccException;


/**
* @author wangfk
*/
public interface IKeyValueStore<Key, Value> {
   /**
    * Write key value data to key-value store. if key already exists, overwrite it
    * @param key
    * @param value
    * @throws YDriveServerStoreException
    */
   public void writeKeyValue(Key key, Value value)
       throws AccException;

   /**
    * Write batch key-value pair to store
    * @param keys
    * @param values
    * @throws IOException
    * @throws YDriveServerStoreException 
    */
   public void writeKeyValues(Key[] keys, Value[] values)
           throws AccException;

   /**
    * Read value from key-value store. If given key does not exist, return false
    * @param key
    * @return value, If given key does not exist, return false
    * @throws YDriveServerStoreException
    */
   public boolean readValue(Key key, Value value) throws AccException;

   /**
    * Read values by given keys.
    * Iff keys[index] is not exist in store, the returned values[index] is null
    * @param keys
    * @return
    * @throws YDriveServerStoreException
    */
   public void readValues(Key[] keys, Value[] values) throws AccException;

   /**
    * Delete key. Do nothing if not exist
    * @param key
    * @throws YDriveServerStoreException
    */
   public void deleteKey(Key key) throws AccException;

   /**
    * Delete keys
    * @param keys
    * @throws YDriveServerStoreException
    */
   public void deleteKeys(Key[] keys) throws AccException;
   
   public boolean containsKey(Key key) throws AccException;

   /**
    * Close the store
    * @throws YDriveServerStoreException
    */
   public void close() throws AccException;

   /**
    * The iterator of the store.
    * 
    * @author wangfk
    *
    * @param <Key>
    * @param <Value>
    */
   public interface Iter<Key, Value> extends Closeable {
       /**
        * Move to a specified key. You will need to call next() to get the row after calling this method.
        * 
        * @param key
        * @param accurate
        * @return If key is found,then return true. If key is not found and accurate==true, return false. 
        * If key is not found and accurate==false, then move to the nearest row that has a bigger key and return true. 
        * If the given key is bigger than all the existing keys, return false. If the table is empty, return false.
        * @throws YDriveServerStoreException
        */
       public boolean seekTo(Key key, boolean accurate) throws AccException;

       /**
        * Return next element by cursor. Before this method, {@link #seekTo(Object, boolean)} must be invoked.
        * 
        * @param key the key to return, would not read key if key==null
        * @param value the value to return, would not read value if value==null
        * @return
        * @throws YDriveServerStoreException
        */
       public boolean next(Key key, Value value) throws AccException;

       /**
        * Close the Iterator
        */
       public void close();
   }

   /**
    * Create iterator of store, iterators of the same store is thread-safe
    * @return
    * @throws YDriveServerStoreException 
    */
   public Iter<Key,Value> getIter() throws AccException;
}

