package outfox.account.db.kv.cassandra;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.utils.Bytes;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import toolbox.cassandra.client.annotation.Column;
import toolbox.cassandra.client.annotation.ColumnKey;
import toolbox.cassandra.client.annotation.RowKey;
import toolbox.cassandra.client.protocol.Entity;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * @author yangzhe
 * @version created on 14-9-2.
 */
public class PerTokenEntity implements Entity {

    @RowKey
    public String userid;

    @ColumnKey
    public String app;

    @ColumnKey
    public String product;

    @ColumnKey
    public String verifiername;

    @ColumnKey
    public String signature;

    @Column
    public ByteBuffer data;

    public PerTokenEntity() {
        
    }

    public PerTokenEntity(PersistTokenWritable pw) {
        TpToken tpToken = pw.getTpToken();
        this.userid = tpToken.userId;
        this.app = tpToken.app;
        this.product = tpToken.product;
        this.verifiername = tpToken.verifierName;
        this.signature = tpToken.signature;
        DataOutputBuffer out = new DataOutputBuffer();
        try {
            pw.writeFields(out);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.data = ByteBuffer.wrap(out.getData(), 0, out.size());
    }

    public PerTokenEntity(TpToken tpToken) {
        this(new PersistTokenWritable(tpToken));
    }

    public PersistTokenWritable toWritable() {
        DataInputBuffer inputBuffer = new DataInputBuffer(Bytes.getArray(this.data));
        PersistTokenWritable res = new PersistTokenWritable();
        try {
            res.readFields(inputBuffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return res;
    }

    @Override
    public String getTableName() {
        return "pertoken";
    }

    @Override
    public int getTTL() {
        return 3600 * 24 * 90;
    }

    @Override
    public ConsistencyLevel getReadConsistencyLevel() {
        return ConsistencyLevel.QUORUM;
    }

    @Override
    public ConsistencyLevel getWriteConsistencyLevel() {
        return ConsistencyLevel.QUORUM;
    }
}
