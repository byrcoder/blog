/**
 * @(#)CoremailUserInfoWritable.java, 2013-3-1. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

/**
 * @author chen-chao
 */
public class CoremailUserInfoWritable extends UserInfoWritable {
    private static final long serialVersionUID = -6892284025962399288L;
    public static final String COREMAIL = "coremail";
    public CoremailUserInfoWritable() {
        
    }
    /**
     * email address
     * @param userId
     */
    public CoremailUserInfoWritable(String userId) {
        this.userId = userId;
        this.originalId = userId;
        this.userName = userId;
        this.from = COREMAIL;
    }
}
