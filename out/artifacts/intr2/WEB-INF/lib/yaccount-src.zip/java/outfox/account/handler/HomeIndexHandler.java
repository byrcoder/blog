/**
 * @(#)HomeIndexHandler.java, 2011-11-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import outfox.account.conf.AccConst;
import outfox.account.conf.VelocityConstant;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * home index
 * 
 * @author chen-chao
 */
@Controller
public class HomeIndexHandler extends BaseHandler {
    private static final long serialVersionUID = 3478854126427196710L;

    @RequestMapping(AccConst.URL_ROOT)
    public ModelAndView process(HttpServletRequest req, HttpServletResponse resp) {
        setName(req, "home");
        ModelAndView model = new ModelAndView(VelocityConstant.PAGE_INDEX);

        model.addObject(VelocityConstant.VALUE_TSINA_APP, req.getContextPath() + AccConst.URL_AUTH_PREFIX
                + AccConst.LOGIN_URL + "?app=web&product=DICT&tp=tsina&cf=2&fr=1");
        model.addObject(VelocityConstant.VALUE_WQQ_APP, req.getContextPath() + AccConst.URL_AUTH_PREFIX
                + AccConst.LOGIN_URL + "?app=web&product=DICT&tp=wqq&cf=2&fr=1");
        model.addObject(VelocityConstant.VALUE_QQ_CONNECT_LOGIN_URL, req.getContextPath() + AccConst.URL_AUTH_PREFIX
                + AccConst.LOGIN_URL + "?app=web&product=DICT&tp=cqq&cf=2&fr=1");
        model.addObject(VelocityConstant.VALUE_TSINA_APP + "_bind", req.getContextPath()
                + AccConst.URL_AUTH_PREFIX + AccConst.LOGIN_URL + "?app=web&product=DICT&tp=tsina&cf=8&fr=1");
        model.addObject(VelocityConstant.VALUE_COOKIE_QUERY_URL, req.getContextPath()
                + AccConst.URL_AUTH_PREFIX + AccConst.COOKIE_QUERY_URL + "?product=DICT&cf=3");
        model.addObject(VelocityConstant.VALUE_REQUEST_PARAMS_URL, req.getContextPath()
                + AccConst.REQUEST_PCI_URL);
        model.addObject(VelocityConstant.VALUE_RESET_URL, req.getContextPath() + AccConst.URL_AUTH_PREFIX + AccConst.RESET_URL);

        model.addObject(VelocityConstant.VALUE_POLL_URL, req.getContextPath() + AccConst.POLL_URL);

        model.addObject(VelocityConstant.VALUE_GET_URS_SESS, req.getContextPath() + AccConst.URL_AUTH_PREFIX + AccConst.GET_URS_SESS_URL + "?product=DICT&method=write_cookie");
        model.addObject(VelocityConstant.VALUE_GET_URS_SESS_EMAIL, req.getContextPath() + AccConst.URL_AUTH_PREFIX + AccConst.GET_URS_SESS_URL + "?product=DICT&method=email");

        model.addObject(VelocityConstant.VALUE_URS_TOKEN_LOGIN_URL, req.getContextPath()
                + AccConst.URL_AUTH_PREFIX + AccConst.LOGIN_URL
                + "?app=web&product=DICT&tp=urstoken&cf=2&fr=1&username=urstest_DICT%40163.com&password=cc03e747a6afbbcbf8be7668acfebee5");
        return model;
    }

}
