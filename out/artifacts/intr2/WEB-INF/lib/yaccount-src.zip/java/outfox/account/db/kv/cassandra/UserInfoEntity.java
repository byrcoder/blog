package outfox.account.db.kv.cassandra;

import com.datastax.driver.core.ConsistencyLevel;
import outfox.account.data.user.UserInfoWritable;
import toolbox.cassandra.client.annotation.Column;
import toolbox.cassandra.client.annotation.RowKey;
import toolbox.cassandra.client.protocol.Entity;

/**
 * @author yangzhe
 * @version created on 14-9-3.
 */
public class UserInfoEntity implements Entity {

    @RowKey
    public String userid;
    @Column
    public String username;
    @Column
    public String email;
    @Column
    public String imageurl;
    @Column
    public String originalid;
    @Column
    public String fromm;//多个m是因为from是cassandra的保留字
    @Column
    public String alias;

    public UserInfoEntity() {
    }

    public UserInfoEntity(UserInfoWritable u) {
        this.userid = u.userId;
        this.username = u.userName;
        this.email = u.email;
        this.imageurl = u.imageUrl;
        this.originalid = u.originalId;
        this.fromm = u.from;
        this.alias = u.alias;
    }

    public UserInfoWritable toWritable() {
        UserInfoWritable u = new UserInfoWritable();
        u.userId = this.userid;
        u.userName = this.username;
        u.email = this.email;
        u.imageUrl = this.imageurl;
        u.originalId = this.originalid;
        u.from = this.fromm;
        u.alias = this.alias;
        return u;
    }

    @Override
    public String getTableName() {
        return "userinfo";
    }

    @Override
    public int getTTL() {
        return 0;
    }

    @Override
    public ConsistencyLevel getReadConsistencyLevel() {
        return ConsistencyLevel.QUORUM;
    }

    @Override
    public ConsistencyLevel getWriteConsistencyLevel() {
        return ConsistencyLevel.QUORUM;
    }
}
