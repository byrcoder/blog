/**
 * @(#)DEVICE_STATUS.java, 2013-6-6. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device;
/**
 * Device status
 *
 * @author chen-chao
 *
 */
public enum DeviceStatus{
    EMPTY((short)1), // this device is a new device or an old device whose user data has been deleted.
    ONLINE((short)2), // this device has logged in and not yet logged out.
    LOGOUTING((short)3), 
    LOGOUT((short)4), 
    DELETING((short)5);
    
    private short state;
    private DeviceStatus(short state) {
        this.state = state;
    }
    public short getState() {
        return state;
    }
    public static DeviceStatus valueOf(short state) {
        DeviceStatus status = null;
        switch (state) {
            case 1:
                status = EMPTY;
                break;
            case 2:
                status = ONLINE;
                break;
            case 3:
                status = LOGOUTING;
                break;
            case 4:
                status = LOGOUT;
                break;
            case 5:
                status = DELETING;
                break;
            default:
                status = EMPTY;
                break;
        }
        return status;
    }
}
