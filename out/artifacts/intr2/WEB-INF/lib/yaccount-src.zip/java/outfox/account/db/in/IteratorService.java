/**
 * @(#)IteratorService.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IteratorService<K> {
    public K getIter(Object ... startKeys) throws AccException;
}
