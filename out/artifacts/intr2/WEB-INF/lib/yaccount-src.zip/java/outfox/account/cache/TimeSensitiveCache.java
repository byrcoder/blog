/**
 * @(#)TimeSensitiveCache.java, 2012-12-3. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache;

import outfox.account.conf.AccConfig;
import outfox.account.utils.AuthUtils;

/**
 * key-value stored in the map will be expired. 
 * You can set expired time for each key-value.
 * Default expired time is {@link AccConfig#NAME_USER_INFO_EXPIRE_TIME}.
 * @author chen-chao
 */
public class TimeSensitiveCache<Key> {
    private LocalWriteCache<Key, TimeSlot> cache;
    public TimeSensitiveCache(boolean realCache, int limit) {
        cache = new LocalWriteCache<Key, TimeSlot>(realCache, limit);
    }
    
    public TimeSensitiveCache(boolean realCache, int init, float load, int limit) {
        cache = new LocalWriteCache<Key, TimeSlot>(realCache, init, load, limit);
    }
    
    public static class TimeSlot {
        long endTime;
        Object val;

        private final static long DEFAULT_REFRESH_TIME = AccConfig.getPros().getLong(
                AccConfig.NAME_LOCAL_CACHE_EXPIRE_TIME);

        private final static long DEFAULT_MAX_RANDOM_TIME = AccConfig.getPros().getLong(
                AccConfig.NAME_LOCAL_CACHE_RANDOM_EXPIRE_TIME);

        public TimeSlot() {
            this(null, null);
        }
        public TimeSlot(Object obj) {
            this(obj, null);
        }
        public TimeSlot(Object obj, Long refreshTime) {
            this.val = obj;
            if (refreshTime == null) {
                // random 10 minutes expired
                refreshTime = DEFAULT_REFRESH_TIME + AuthUtils.getRandomMilliSecond(DEFAULT_MAX_RANDOM_TIME);
            }
            endTime = System.currentTimeMillis() + refreshTime;
        }
        public boolean isExpired() {
            return endTime < System.currentTimeMillis();
        }
        
        public Object getValue(){
            return val;
        }
    }
    
    public Object get(Key key) {
        TimeSlot slot = cache.get(key);
        if (slot == null || slot.isExpired()) {
            return null;
        }
        return slot.getValue();
    }
    
    public Object remove(Key key) {
        TimeSlot slot = cache.remove(key);
        if (slot != null) {
            return slot.getValue();
        }
        return null;
    }
    
    public void put(Key key, Object value) {
        cache.put(key, new TimeSlot(value));
    }
    
    public void put(Key key, Object value, long refreshTime) {
        cache.put(key, new TimeSlot(value, refreshTime));
    }
}
