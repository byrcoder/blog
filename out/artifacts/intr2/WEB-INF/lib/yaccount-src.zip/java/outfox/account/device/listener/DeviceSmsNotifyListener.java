/**
 * @(#)DeviceSmsNotifyListener.java, 2013-6-7. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device.listener;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import outfox.account.conf.AccConst.OPERATOR;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpResponse;

import outfox.account.conf.AccConfig;
import outfox.account.data.Parameter;
import outfox.account.device.DeviceEvent;
import outfox.account.device.DeviceStatus;
import outfox.account.utils.client.AccHttpClient;

/**
 * Listener to invoke webserver's restful interface to notify VIP user about
 * device changing by SMS.
 * @author zhanglz
 *
 */
public class DeviceSmsNotifyListener implements IDeviceEventListener {
    private static final Log LOG = LogFactory.getLog(DeviceSmsNotifyListener.class);
    private static String WS_NOTIFY_URL = AccConfig.getPros().getString(
            AccConfig.NAME_DEVICE_WS_NOTIFY, AccConfig.DEFAULT_DEVICE_WS_NOTIFY);
    private static String PARAM_USER_ID = "userid";
    private static String PARAM_DEVICE_ID = "device_id";
    @Override
    public void handleEvent(DeviceEvent event) {
        if (AccConfig.isTestCaseMode()) {
            return;
        }
        if (!needSendSms(event)) {
            return;
        }
        HttpResponse response = null;
        try {
            List<Parameter> paramList = new ArrayList<Parameter>();
            paramList.add(new Parameter(PARAM_USER_ID, event.getUserId()));
            paramList.add(new Parameter(PARAM_DEVICE_ID, event.getDeviceId()));
            List<Header> headerList = new ArrayList<Header>();
            response = AccHttpClient.getInstance().doGet(WS_NOTIFY_URL, headerList, paramList);
        } catch (Exception e) {
            LOG.error("Notify device login failed. event= " + event.dump(), e);
        } finally {
            AccHttpClient.closeQuiet(response);
        }
    }
   
    private boolean needSendSms(DeviceEvent event) {
        // only poll and login action may trigger sms.
        if (event.getOp() != OPERATOR.LOGIN && event.getOp() != OPERATOR.POLL 
                && event.getOp() != OPERATOR.CQ) {
            return false;
        }
        // empty parameter check.
        if (event.getFrom() == null || event.getTo() == null ||
                StringUtils.isBlank(event.getDeviceId()) ||
                StringUtils.isBlank(event.getUserId())) {
            return false;
        }
        // from empty status to online.
        if (event.getFrom() == DeviceStatus.EMPTY && event.getTo() == DeviceStatus.ONLINE) {
            return true;
        }
        return false;
    }

}
