/**
 * @(#)TokenData.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TokenData {
    public String token;
    public long expireTime;
    public TokenData(String token, long expireTime) {
        this.token = token;
        this.expireTime = expireTime;
    }
    public static TokenData extractTokenDataFromReq(HttpServletRequest req, String product) {
        String token = AuthUtils.getParamOrHeader(req, product + AccConst.ATTR_PART_PC);
        if (StringUtils.isBlank(token)) {
            return null;
        }
        long expireTime = AuthUtils.getReqLong(req, product + AccConst.ATTR_PART_PERSIST_TOKEN_EXPIRE_TIME, -1);
        return new TokenData(token, expireTime);
    }
    
    public static Map<String, TokenData> extractTokenDataFromReq(HttpServletRequest req) {
        Map<String, TokenData> map = new HashMap<String, TokenData>();
        for (String product : AccConfig.getProductSet()) {
            TokenData token= extractTokenDataFromReq(req, product);
            if (token != null) {
                map.put(product, token);
            }
        }
        return map;
    }
    
    public static String extractTokenFromReq(HttpServletRequest req, String product) {
        return AuthUtils.getReqVal(req, product + AccConst.ATTR_PART_PC);
    }
    
    public static Map<String,String> extractTokenFromReq(HttpServletRequest req) {
        Map<String, String> map = new HashMap<String, String>();
        for (String product : AccConfig.getProductSet()) {
            String token = extractTokenFromReq(req, product);
            if (!StringUtils.isBlank(token)) {
                map.put(product, token);
            }
        }
        return map;
    }
    
    public static long extractExpireTimeFromReq(HttpServletRequest req, String product) {
        return AuthUtils.getReqLong(req, product + AccConst.ATTR_PART_PERSIST_TOKEN_EXPIRE_TIME, -1);
    }
    
    public static Map<String,Long> extractExpireTimeFromReq(HttpServletRequest req) {
        Map<String, Long> expireTime = new HashMap<String, Long>();
        for (String product : AccConfig.getProductSet()) {
            expireTime.put(product, extractExpireTimeFromReq(req, product));
        }
        return expireTime;
    }
}
