package outfox.account.db.kv.cassandra;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.utils.Bytes;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import outfox.account.data.SessionCookieWritable;
import toolbox.cassandra.client.annotation.Column;
import toolbox.cassandra.client.annotation.RowKey;
import toolbox.cassandra.client.protocol.Entity;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * @author yangzhe
 * @version created on 14-9-3.
 */
public class SessCookieEntity implements Entity {
    @RowKey
    public String sessindex;

    @Column
    public ByteBuffer data;

    public SessCookieEntity() {

    }

    public SessCookieEntity(String sessIndex, SessionCookieWritable session) {
        this.sessindex = sessIndex;
        DataOutputBuffer out = new DataOutputBuffer();
        try {
            session.writeFields(out);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.data = ByteBuffer.wrap(out.getData(), 0, out.size());
    }

    public SessionCookieWritable toWritable() {
        SessionCookieWritable res = new SessionCookieWritable();
        DataInputBuffer inputBuffer = new DataInputBuffer(Bytes.getArray(this.data));
        try {
            res.readFields(inputBuffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return res;
    }

    @Override
    public String getTableName() {
        return "sesscookie";
    }

    @Override
    public int getTTL() {
        return 3600 * 24 * 30;
    }

    @Override
    public ConsistencyLevel getReadConsistencyLevel() {
        return ConsistencyLevel.QUORUM;
    }

    @Override
    public ConsistencyLevel getWriteConsistencyLevel() {
        return ConsistencyLevel.QUORUM;
    }
}
