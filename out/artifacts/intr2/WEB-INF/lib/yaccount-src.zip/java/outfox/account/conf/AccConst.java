/**
 * @(#)AccountConstant.java, 2012-8-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.conf;

import outfox.account.data.Parameter;

/**
 * FOR all constant value
 * @author chen-chao
 */
public interface AccConst {
    
    static final String PARAM_API_NAME = "API";
    
    static final String NAME_PRODUCT = "product";
    
    static final String PARAM_APP_NAME = "app";

    static final String PARAM_REDIRECT_URL_NAME = "ru";

    static final String PARAM_PCINDEX_NAME = "pci";

    static final String PARAM_PC_NAME = "pc";

    static final String PARAM_SHOW_USER_INFO_NAME = "su";

    static final String PARAM_IS_PERSIST_COOKIE = "pe";

    static final String PARAM_DISPLAY_NAME = "display";
    
    static final String PARAM_DEBUG_NAME = "debug";

    static final String PARAM_SHADOW_USER_ID = "bid";

    static final String PARAM_BINDING_COOKIE_ENABLED = "bc";
    
    static final String PARAM_GET_ACCESS_TOKEN = "ga";
    
    static final String PARAM_ERROR_REDIRECT_URL = "er";
    
    static final String PARAM_PRODUCT_NAME = NAME_PRODUCT;
    
    static final String PARAM_PRODUCT_DEFALUT_VALUE = "YNOTE";
    
    static final String PARAM_URS_PRODUCT_NAME = "ursp";
    
    static final String PARAM_URS_PRODUCT_DEFAULT_VALUE = "note";
    
    static final String PARAM_WANT_CLEAN_PRODUCTS_NAME = "c"+NAME_PRODUCT;
    
    static final String PARAM_WANT_CLEAN_APPS_NAME = "c"+PARAM_APP_NAME;
    
    static final String PARAM_WANT_CLEAN_BIND = "cbind";
    
    static final String PARAM_THIRD_PARTY_NAME = "tp";
    
    static final String PARAM_WANT_CLEAN_TPS_NAME = "c"+PARAM_THIRD_PARTY_NAME;
    
    static final String PARAM_OPEN_ID = "opid";
    
    static final String PARAM_OPEN_KEY = "opkey";
    
    static final String PARAM_DOMAIN = "domain";
    
    static final String PARAM_SHOW_ERROR = "show";
    
    static final String PARAM_SHOW_KEY = "key";
    
    static final String PARAM_GET_USER_INFO = "getinfo";
    
    static final String PARAM_REGISTER = "rg";
    
    static final String PARAM_ACCESS_TOKEN_VERIFIER = "acc";
    
    static final String PARAM_TOKEN = "token";
    static final String PARAM_TOKEN_EXPIRE_TIME = "et";
    static final String PARAM_KEEP_TOKEN = "kt";
    
    static final String PARAM_OTHER = "other";
    /**
     * client|tsina,mobile|urstoken,
     * only remove client-tsina and mobile-urstoken
     */
    static final String PARAM_WANT_CLEAN_CONDITION = "cd";
    
    static final String PARAM_ALOGRITHM = "al";
    static final String PARAM_CIPHER = "ci";
    
    static final String PARAM_FORMAT = "format";
    
    static final String PARAM_USER_CAPTCHA = "captcha";
    
    static final String PARAM_USER_ID = "userid";
    
    static final String PARAM_PASSWORD = "pass";
    
    static final String PARAM_FORCE_REDIRECT = "fr";
        
    static final String PARAM_FORCE_LOGIN = "f";
    
    static final String PARAM_COOKIE_FORMAT = "cf";
    
    static final String PARAM_LOGIN_INFO = "lo";
    
    static final String PARAM_AES_IV = "iv";
    
    static final String PARAM_ALL = "all";
    
    static final String PARAM_SUCCESS = "s";
    
    static final String PARAM_URS_MEMORY_COOKIE = "um";
    
    static final String PARAM_URS_USERNAME = "username";

    static final String PARAM_URS_PASSWORD = "password";

    static final String PARAM_METHOD = "method";
    
    /**
     * coremail param
     */
    static final String PARAM_COREMAIL_SID = "sid";
    
    static final String PARAM_COREMAIL_DOMAIN = "domain";
    
    static final String PARAM_COREMAIL_USERID = "coremail_userid";
    
    static final String PARAM_COREMAIL_PASSWORD = "pass";
    
    static final String NO_REDIRECT_URL = "none";
    
    static final String DEFAULT_DISPLAY_MODE = "web";
    
    static final String UTF8 = "UTF-8";

    static final String JSON_CONTENT_TYPE = "application/json;charset=UTF-8";
    static final String HTML_CONTENT_TYPE = "text/html;charset=UTF-8";
    static final String PLAIN_CONTENT_TYPE = "text/plain;charset=UTF-8";
    static final String IMAGE_CONTENT_TYPE = "image/jpeg;charset=UTF-8";
    static final String XML_CONTENT_TYPE = "text/xml;charset=UTF-8";
    static enum ENCRYPT_ALGORITHM {
        NONE,RSA,AES;
        public ENCRYPT_ALGORITHM defaultNameOf(String str) {
            try {
                return ENCRYPT_ALGORITHM.valueOf(str.toUpperCase());
            } catch (Exception e) {
                return this;
            }
        }
    }
    
    public static enum CIPHER_TYPE {
        NONE("", false), 
        AES_DEFAULT("AES", false), 
        AES_CBC_PKCS7("AES/CBC/PKCS7Padding", true),
        RSA_DEFAULT("RSA/ECB/NoPadding", false),
        AES_CBC_PKCS5("AES/CBC/PKCS5Padding", false),
        RSA_ECB_PKCS1("RSA/ECB/PKCS1Padding", false);
        private String typeValue;
        private boolean withBC;
        private CIPHER_TYPE(String typeValue, boolean withBC) {
            this.typeValue = typeValue;
            this.withBC = withBC; 
        }
        public String getType(){
            return typeValue;
        }
        public boolean withBC() {
            return withBC;
        }
        public CIPHER_TYPE defaultNameOf(String type) {
            try {
                return CIPHER_TYPE.valueOf(type);
            } catch(Exception e) {
                return this;
            }
        }
    }
    
    static enum CIPHER_ALGORITHM_TYPE {
        NONE("NONE",CIPHER_TYPE.NONE, ENCRYPT_ALGORITHM.NONE), 
        AES_DEFAULT("AES", CIPHER_TYPE.AES_DEFAULT,ENCRYPT_ALGORITHM.AES), 
        AES_CBC_PKCS7("AC7",CIPHER_TYPE.AES_CBC_PKCS7, ENCRYPT_ALGORITHM.AES),
        RSA_DEFAULT("RSA", CIPHER_TYPE.RSA_DEFAULT, ENCRYPT_ALGORITHM.RSA),
        AES_CBC_PKCS5("AC5", CIPHER_TYPE.AES_CBC_PKCS5, ENCRYPT_ALGORITHM.AES),
        RSA_ECB_PKCS1("RE1", CIPHER_TYPE.RSA_ECB_PKCS1, ENCRYPT_ALGORITHM.RSA),
        RSA_ECB_PKCS1_SPLIT_EXP_MODULUS("RE1S", CIPHER_TYPE.RSA_ECB_PKCS1, ENCRYPT_ALGORITHM.RSA),
        RSA_ECB_NOPADING_SPLIT_EXP_MODULUS("RSAS", CIPHER_TYPE.RSA_DEFAULT, ENCRYPT_ALGORITHM.RSA);
        private CIPHER_TYPE cipherType;

        private ENCRYPT_ALGORITHM algorithm;
        
        private String alias;

        private CIPHER_ALGORITHM_TYPE(String alias, CIPHER_TYPE cipherType, ENCRYPT_ALGORITHM algorithm) {
            this.cipherType = cipherType;
            this.algorithm = algorithm;
            this.alias = alias;
        }
        
        public String getAlias() {
            return alias;
        }
        
        public CIPHER_TYPE getCipherType() {
            return cipherType;
        }
        
        public ENCRYPT_ALGORITHM getAlgorithm() {
            return algorithm;
        }

        public CIPHER_ALGORITHM_TYPE defaultValueOf(String alias) {
            try {
                for (CIPHER_ALGORITHM_TYPE type: CIPHER_ALGORITHM_TYPE.values()) {
                    if (type.alias.equals(alias.toUpperCase())) {
                        return type;
                    }
                }
            } catch (Exception e) {
                // do nothing
            }
            return this;
        }
    }
    
    enum METHOD_NAMES {
        EMAIL, WRITE_COOKIE,
    }
    enum COOKIE_FORMAT {
        none(0),
        /**
         * want user info
         */
        info(1),
        /**
         * want session cookie 
         */
        se(2),
        /**
         * want persist cookie
         */
        pe(4),
        /**
         * want bind cookie
         */
        b(8);
        private int value;
        COOKIE_FORMAT(int val) {
            this.value = val;
        }
        public int value() {
            return value;
        }
        public COOKIE_FORMAT defaultNameOf(String str) {
            try {
                return COOKIE_FORMAT.valueOf(str);
            } catch (Exception e) {
                return this;
            }
        }
        public boolean isContain(int val) {
            return (val & this.value) != 0;
        }
        
        public boolean isOnlyContain(int val) {
            return (val ^ value) == 0 ;
        }
        /**
         * remove COOKIE_FORMAT value
         * @param val
         * @return
         */
        public int remove(int val) {
            return (val & value) == 0 ? val : (val ^ value);
        }
    }
    
    enum FORMAT {
        json, plain, html, jsjson, jsplain, image;
        public FORMAT defaultValueOf(String str) {
            try {
                return FORMAT.valueOf(str);
            } catch (Exception e) {
                return this;
            }
            
        }
    }
    
    static final String HTML_CONTENT = "html";
    static final String HTML_TOKEN = "$$";
    static final String BLANK_STRING = "";

    /**
     * constant values
     */
    static final String COOKIE_PERSISTENT = "_PERS";
    static final String COOKIE_SESSION = "_SESS";

    static final String COOKIE_LOGIN = "_LOGIN";

    static final String COOKIE_SESSION_BIND = "_BIND";
    
    static final String COOKIE_KEEP_TOKEN = "_KEEP_TOKEN";
    
    static final String COOKIE_TOKEN = "_TOKEN";
    static final String COOKIE_BIND_TOKEN = "_BIND_TOKEN";
    
    static final String COOKIE_PUBLIC_VIEW = "_PUBLIC_VIEW";
    
    static final String COOKIE_FORCE_LOGIN = "_FORCE";
    
    static final String ATTR_QUERY = "QUERY";

    static final String CONSUMER_TSINA = "tsina";

    static final String CONSUMER_OAUTH = "oauth";

    static final String CONSUMER_URS = "urs";

    static final String CONSUMER_QPLUS = "qplus";

    static final String CONSUMER_QQ_CONNECT = "cqq";

    static final String CONSUMER_WEIBO_QQ = "wqq";
    
    /**
     * TODO: compatity
     */
    static final String COOKIE_REGISTER = "_REGISTER";

    /**
     * attribute
     */
    static final String ATTR_PART_USER_ID = "_user_id"; 
    static final String WRITABLE = "_writable";
    static final String ATTR_PART_USER_ID_WRITABLE = ATTR_PART_USER_ID + WRITABLE ; 
    static final String ATTR_PART_BIND_USER_ID = "_bind_user_id";
    static final String ATTR_PART_BIND_USER_ID_WRITABLE = ATTR_PART_BIND_USER_ID + WRITABLE ; 
    
    static final String ATTR_PART_SESS_WRITABLE = "_sess" + WRITABLE ; 
    static final String ATTR_PART_BIND_WRITABLE = "_bind" + WRITABLE ; 
    static final String ATTR_LOGIN_SET = "login_products";
    static final String ATTR_BIND_SET = "bind_products";
    static final String ATTR_PART_SESSION_EXPIRE_TIME = "_st";
    
    static final String ATTR_PART_PERSIST_TOKEN_EXPIRE_TIME = "_pt";
    
    static final String ATTR_FORCE_LOGIN = PARAM_FORCE_LOGIN;
    
    static final String ATTR_FORCE_REDIRECT = PARAM_FORCE_REDIRECT;
    
    static final String ATTR_REDICT_SCHEME = "re-scheme";
    
    static final String ATTR_SERVLET_EXCEPTION = "javax.servlet.error.exception";

    static final String ATTR_APP_NAME = PARAM_APP_NAME;
    
    static final String ATTR_ALOGRITHM = PARAM_ALOGRITHM;

    static final String ATTR_REAL_APP_NAME = "realapp";

    static final String ATTR_PCINDEX_NAME = PARAM_PCINDEX_NAME;

    static final String ATTR_PC_NAME = PARAM_PC_NAME;
    
    static final String ATTR_CHECKED_PC = "checked.pc";
    
    static final String ATTR_PART_PC = "-"+PARAM_PC_NAME.toUpperCase();
    
    static final String ATTR_PART_PERSTOKEN_WRITABLE = "_"+PARAM_PC_NAME + WRITABLE;

    static final String ATTR_REDIRECT_URL_NAME = PARAM_REDIRECT_URL_NAME;

    static final String ATTR_BINDING_ENABLE = PARAM_BINDING_COOKIE_ENABLED;

    static final String ATTR_IS_CLOSE_REDIRECT_NAME = "cr";

    static final String ATTR_IS_REDIRECT_NAME = "rd";

    static final String ATTR_SET_PRESIST_COOKIE = PARAM_IS_PERSIST_COOKIE;

    static final String ATTR_CONSUMER_NAME = "consumer.name";

    static final String ATTR_SESSION_COOKIE = COOKIE_SESSION;

    static final String ATTR_OAUTH_VERSION = "oauth.version";

    static final String ATTR_FORMAT = PARAM_FORMAT;
    
    static final String ATTR_ACCTOKEN = "accToken";
    
    static final String ATTR_DONE = "done";
    
    static final String ATTR_HTTP_STATUS = "httpstat";
    
    static final String ATTR_DISPLAY_NAME = PARAM_DISPLAY_NAME;
    
    static final String ATTR_AUTHORIZE = "authorize";
    static final String ATTR_URS_EMAIL = "__URS_EMAIL__";
    static final String ATTR_NICK_NAME = "__NICK_NAME__";
    
    static final String ATTR_PUBLIC_VIEW_USER_ID = "__PUBLIC_VIEW_ID__";
    
    static final String ATTR_QUERY_TABLE = "query.table";
    static final String ATTR_NOT_CHECK_V1_SESS_COOKIE = "not_check_sv1";
    static final String ATTR_NOT_CHECK_V1_PERS_COOKIE = "not_check_pv1";
    static final String ATTR_NOT_CHECK_V1_BIND_COOKIE = "not_check_bv1";
    static final String ATTR_NOT_CHECK_V1_URS_COOKIE = "not_check_ursv1";
    
    static final String ATTR_RESULT = "result";
    
    static final String ATTR_PRODUCT_NAME = PARAM_PRODUCT_NAME;
    
    static final String ATTR_THIRD_PARTY_NAME = PARAM_THIRD_PARTY_NAME;
    
    static final String ATTR_COOKIE_FORMAT = PARAM_COOKIE_FORMAT;
    
    static final String ATTR_PRIVATE_KEY_HEX = "priv_key_hex";
    static final String ATTR_IP = "__ip__";
    /**
     * mapping url
     */
    static final String URL_ROOT = "/";
    
    static final String URL_INDEX = "index";
    
    static final String URL_AUTH_PREFIX = "/acc";
    
    static final String RESET_URL = "/se/reset";
    
    static final String REMOVE_URL = "/se/remove";

    static final String LOGIN_URL = "/login";

    static final String ACCOUNT_BINDING_PREFIX = "/se/bind";

    static final String ACCOUNT_BINDING_ADD_URL = ACCOUNT_BINDING_PREFIX
            + "/add";

    static final String ACCOUNT_BINDING_GET_INFO_URL = ACCOUNT_BINDING_PREFIX
            + "/binfo";
    
    static final String ACCOUNT_BINDING_GET_ALL_URL = ACCOUNT_BINDING_PREFIX
            + "/all";

    static final String ACCOUNT_BINDING_GET_MAIN_ID_URL = ACCOUNT_BINDING_PREFIX
            + "/mainid";

    static final String ACCOUNT_BINDING_REMOVE_URL = ACCOUNT_BINDING_PREFIX
            + "/remove";
    
    static final String ACCOUNT_BINDING_CHECK_BINDED_URL = ACCOUNT_BINDING_PREFIX
            + "/check";

    static final String ERROR_URL = "/error";
    
    static final String COOKIE_QUERY_URL = "/co/cq";
    
    static final String GET_SESS_URL = "/pe/getsess";

    static final String REQUEST_PCI_URL = "/rp";

    static final String STRESS_CREATE_COOKIE_URL = "/stress/create/cookie";

    static final String STRESS_CREATE_DEVICE_URL = "/stress/create/device";
    
    static final String SHOW_REQUEST_URL = "/showreq";
    
    static final String SHOW_PROTOCOL_URL = "/showprotocol";
    
    static final String STRESS_SINGLE_PRODUCT_FILTER = "/stress/spfilter";
    
    static final String STRESS_MEMCACHED_WRITE = "/stress/mem/write";
    
    static final String STRESS_MEMCACHED_READ = "/stress/mem/read";
    
    static final String STRESS_MEMCACHED_REMOVE = "/stress/mem/rm";
    
    static final String GEN_SHOW_REQUEST_URL = SHOW_REQUEST_URL + "/gen";

    static final String LOGIN_DONE_URL = "/se/done";
    
    static final String GET_URS_SESS_URL = "/se/geturssess";
    
    static final String CALLBACK_URL = "/callback";
    
    static final String DISPATCH_URL = "/acc";
    
    static final String POLL_URL = "/poll";
    
    static final String CROSS_COOKIE_DOMAIN_URL = "/se/cross/domain";
    
    static final String CROSS_URS_COOKIE_DOMAIN_URL = "/se/cross/domain/urs";

    static final String CROSS_PROCESS_FIRST_URL = "/se/cross/first";

    static final String CROSS_PROCESS_SECOND_URL = "/cross/second";
    
    static final String REGISTER_QUERY_URL = "/reg/query";
    
    static final String REGISTER_CHANGE_CAPTCHA_URL = "/reg/change";
    
    static final String REGISTER_SHOW_URL = "/reg/show";
    
    static final String REGISTER_SEND_URL = "/reg/send";
    
    static final String CAPTCHA_CHECK = "/reg/check";

    /**
     * URS url
     */
    static final String REGISTER_URS_URL = "http://reg.163.com/services/fastRegPassport";
    
    /**
     * coremail url api
     */
    static final String COREMAIL_API_URL = "http://coremail.cn/apiws";
    
    static final String COREMAIL_LOGIN_PREFIX = "/coremail";
    
    static final String COREMAIL_LOGIN_QUERY = COREMAIL_LOGIN_PREFIX + "/query";
    
    static final String COREMAIL_LOGIN_REGISTER = COREMAIL_LOGIN_PREFIX + "/reg";
    
    static final String COREMAIL_LOGIN_AUTH = COREMAIL_LOGIN_PREFIX + "/auth";
    
    /**
     * log constant
     */
    /**
     * this value in request attribute MUST not contain " " or "."
     */
    static final String REQUEST_NAME = "request_name";

    static final String EXCEPTION_NAME = "exception_name";

    /**
     * query login, response information
     */
    static final String FLAG_LOGIN = "login";
    
    static final String FLAG_BIND = "bind";
    
    static final String FLAG_BIND_USER = "buser";

    static final String FLAG_NAME = "name";

    static final String FLAG_ATNAME = "atName";

    static final String FLAG_EMAIL = "email";
    
    static final String FLAG_ACCESS_TOKEN = "ac";
    
    static final String FLAG_OPEN_KEY = "opk";
    
    static final String FLAG_MAIN_ID = "mainid";

    /**
     * request method
     */
    static final String GET = "GET";

    /**
     * oauth version
     */
    static final String OAUTH_VERSION_1 = "1.0";

    static final String OAUTH_VERSION_1A = "1.0a";

    static final String OAUTH_VERSION_2 = "2.0";

    /**
     * login info
     */
    enum LOGIN_STAT {
        logout(0), sess(1), pers(2), relogin(4), forcelogin(8), bind(16), rebind(32);
        private final int value;

        private LOGIN_STAT(int value) {
            this.value = value;
        }

        public int value() {
            return value;
        }
        public LOGIN_STAT defaultNameOf(String str) {
            try {
                return LOGIN_STAT.valueOf(str);
            } catch (Exception e) {
                return this;
            }
        }
        public boolean isContainedIn(int val) {
            return (val & this.value) != 0;
        }
        /**
         * remove COOKIE_FORMAT value
         * @param val
         * @return
         */
        public int remove(int val) {
            return (val & value) == 0 ? val : (val ^ value);
        }
        
        public int add(int val) {
            return (val | this.value);
        }
    }
    
    /**
     * verifier type
     *
     * @author chen-chao
     *
     */
    public enum VerifierType{
        Common, Oauth, Oauth1, Oauth2, Urs
    }
    

    /**
     * cookie path root
     */
    static final String COOKIE_ROOT_PATH = "/";

    static final String ANALYZER_ATTR_PREFIX = "_a_";

    static final String ANALYZER_OAUTH_APP = ANALYZER_ATTR_PREFIX + "app";

    static final String ANALYZER_CONSUMER = ANALYZER_ATTR_PREFIX + "consumer";

    static final String ANALYZER_OPENID_COOKIE_STATE = ANALYZER_ATTR_PREFIX
            + "cookie_state";

    /**
     * URL const
     */
    static final String SYMBOL_EQUAL = "=";

    static final String SYMBOL_SINGLE_AND = "&";

    static final String SYMBOL_QUESTION = "?";

    static final int AUTH_ERROR_CODE = 207;

    static final String ACCOUNT_HOME = "yaccount.home";

    static final String ENV_ACCOUNT_HOME = "YOUDAO_ACCOUNT_HOME";
    
    static final String USER_ID_ATTR = "__USER_ID__";
    static final String USER_INFO_WRITABLE = "userInfoWritable";
    static final String USER_ID = "userid";
    static final String USER_NAME = "username";
    static final String USER_EMAIL = "email";
    static final String USER_IMAGE_URL = "imageurl";
    static final String USER_IMAGE_URL_BIG = "imageurl_big";
    static final String USER_ALIAS = "alias";
    static final String USER_FROM = "from";
    static final String FILE_SEPERATOR = "/";
    static final String OPERATION_SUCCESS = "success";
    
    enum OAUTH_TYPE {
        ACCESS_TOKEN("accessToken"), REQUEST_TOKEN("requestToken"), TOKEN_SECRET(
                "tokenSecret");

        private final String value;

        private OAUTH_TYPE(String value) {
            this.value = value;
        }

        public String value() {
            return value;
        }

    }
    
    /**
     * RPC
     */
    static final String LOCAL_HOST = "localhost";
    static final String HTTP_PROTOCAL = "http";
    static final String HTTPS_PROTOCAL = "https";
    
    /**
     * error
     */
    static final String ERROR_OLD_HTTP_STATUS = "old";
    static final String ERROR_MESSAGE = "msg";
    static final String ERROR_EXCEPTION_TYPE = "type";
    static final String ERROR_CODE = "ecode";
    static final String ERROR_THIRD_PARTY_CODE = "tpcode";
    
    static final String LINE_SPARATOR = "\n";
    
    static final String ACCESS_TOKEN = "access_token";
    static final String ACCESS_SECRET = "access_secret";
    
    static final String REMAIN = "remain";
    static final String REMIND = "remind";
    static final String EXPIRED = "expire";
    
    static final String REFRESH_TOKEN = "refresh_token";
    
    static final String THIRD_PARTY_PERS_TOKEN = "persToken";
    
    static final String VERSION = "1.4";
    
    static final String TP_TOKEN = "tpToken";
    
    static final String URS_TOKEN = "ursToken";
    
    static final long DEFAULT_TIME = 0L;
    
    static final String V2_FLAG = "v2|";
    
    static final int V2_FLAG_LENGTH = V2_FLAG.length();
    
    static final String IP_ADDRESS = "IP";
    
    
    static final Parameter LOGIN_TRUE = new Parameter(AccConst.FLAG_LOGIN, true);
    static final Parameter LOGIN_FALSE = new Parameter(AccConst.FLAG_LOGIN, false);
    
    /**
     * /acc/se/done?s=true&product=&tp=
     */
    static final String LOGIN_DONE_LOCATION = AccConst.DISPATCH_URL + AccConst.LOGIN_DONE_URL;
    /**
     * /acc/reg/show?s=true&product=&tp=&mp=
     */
    static final String REGISTER_LOCATION = AccConst.DISPATCH_URL + AccConst.REGISTER_SHOW_URL;

    enum AUTHORIZE_TYPE {
        READ(1), WRITE(2), REMOVE(4), SHARE(8);
        private final int value;

        private AUTHORIZE_TYPE(int value) {
            this.value = value;
        }

        public int value() {
            return value;
        }
        public boolean isContainedIn(int val) {
            return (val & this.value) != 0;
        }
    }
    
    static final String URS_CODE_OK = "200";
    
    static final String URS_CODE_NOT_EXIST = "104";
    
    static final String NEW_LINE = "\n";
    
    static final String REGISTER = "REGISTER";
    static final String TOKEN = "token";
    static final String OPEN_ID = "openid";
    static final String URS_PRODUCT = "ursProduct";
    static final String WSDL_URL = "wsdlURL";
    static final String RETURN_STR = "return";
    static final String PRODUCT = AccConst.PARAM_PRODUCT_NAME;
    
    static final String SINGLE_SIGN_ON = "sso";
    
    
    static final String URS_MEMORY_CHECK = "URSM|";
    
    static final int URS_MEMORY_CHECK_LENGTH = URS_MEMORY_CHECK.length();
    
    static final String EMPTY_STR = "";
    
    /**
     * device related const.
     */
    static final String PARAM_DEVICE_ID = "device_id";
    
    /**
     * Device information related parameters.
     */
    static final String PARAM_DEVICE_NAME = "device_name";
    /**
     * iphone or ipad
     */
    static final String PARAM_DEVICE_TYPE = "device_type";
    /**
     * 4S, 
     */
    static final String PARAM_DEVICE_MODEL = "device_model";
    /**
     * windows
     */
    static final String PARAM_DEVICE_OS = "os";
    static final String PARAM_DEVICE_OS_VERSION = "os_ver";
    static final String PARAM_DEVICE_CLIENT_VERSION = "client_ver";
    
    /**
     * Returned when device is requested to delete user data.
     */
    static final int ERROR_DEVICE_DELETE = 2061;
    /**
     * Returned when device is requested to offline.
     */
    static final int ERROR_DEVICE_OFFLINE = 2060;
    
    public static enum OPERATOR {
        CQ, LOGIN,POLL,
        FILTER,
        REQUEST_DELETE, REQUEST_LOGOUT, FINSIH_LOGOUT, FINISH_DELETE
    }
    
    public static Object EMPTY_OBJ = new Object();
    
    public static final String NAME_SESS_COOKIE_MEMCACHED = "sessCookie@global";
}
