package outfox.account.profile;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.util.HashSet;
import java.util.Set;

/**
 * @author yangzhe
 * @version created on 15-3-2.
 */
public class RedisService {
    private JedisCluster jedis;
    private static final String PRIFIX = "mc:";
    private static int timeout = 60 * 1;
    private static final int ONEMONTH = 30 * 24 * 3600;

    public RedisService() {
        Set<HostAndPort> jedisClusterNodes = new HashSet<HostAndPort>();
        jedisClusterNodes.add(new HostAndPort("ws036", 7001));
        jedisClusterNodes.add(new HostAndPort("ws045", 7001));
        jedis = new JedisCluster(jedisClusterNodes);
    }

    public int getInt(String key) {
        if (jedis.exists(PRIFIX + key)) {
            return Integer.parseInt(jedis.get(PRIFIX + key));
        }
        return -1;
    }

    public long getLong(String key) {
        if (jedis.exists(PRIFIX + key)) {
            return Long.parseLong(jedis.get(PRIFIX + key));
        }
        return -1;
    }

    public String getString(String key) {
        return jedis.get(PRIFIX + key);
    }

    public void setValue(String key, String value) {
        jedis.setex(PRIFIX + key, timeout, value);
    }

    public void setValueOneMonth(String key, String value) {
        jedis.setex(PRIFIX + key, ONEMONTH, value);
    }

    public void delKey(String key) {
        jedis.del(PRIFIX + key);
    }

    public boolean exist(String key) {
        return jedis.exists(PRIFIX + key);
    }

}
