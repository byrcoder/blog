/**
 * @(#)QConnThirdVerifier.java, Nov 7, 2013. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Properties;

/**
 *
 * @author wangzhen
 *
 */
public class QConnThirdVerifier extends QConnBaseVerifier {
    
    public static final String NAME = "cqq-third";
    
    public QConnThirdVerifier(Properties props) {
        super(props, NAME);
    }
    
    @Override
    public String getVerifierName() {
        return NAME;
    }

}
