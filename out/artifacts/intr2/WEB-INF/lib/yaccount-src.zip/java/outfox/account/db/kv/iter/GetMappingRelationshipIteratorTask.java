/**
 * @(#)GetMappingRelationShip.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import java.util.ArrayList;
import java.util.List;

import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.db.DataStore.MappingRelationship;
import outfox.account.db.in.IUserMappingDB.IUserMappingIter;
import outfox.account.db.in.IteratorService;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class GetMappingRelationshipIteratorTask extends AbstractIteratorTask<IUserMappingIter>{
    private List<String> ids;
    private MappingRelationship relationship = null;
    private String mainId = null;
    public GetMappingRelationshipIteratorTask(IteratorService<IUserMappingIter> dbIterService, String mainId) {
        super(dbIterService, mainId);
        this.mainId = mainId;
    }

    @Override
    protected void preTask() {
        ids = new ArrayList<String>();
    }

    @Override
    protected void runTask(Object value) throws AccException {
        MainId2ShadowIdWritable mapping = (MainId2ShadowIdWritable)value;
        ids.add(mapping.getShadowUserId());
    }

    @Override
    protected void postTask() {
        if (ids.size() != 0) {
            relationship = new MappingRelationship(mainId, ids);
        }
    }

    @Override
    public Object returnValue() {
        return relationship;
    }

}
