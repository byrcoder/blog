/**
 * @(#)OpenIdConstant.java, 2011-9-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.conf;

/**
 * The constant values are for OAuth protocol.
 * @author wangfk
 * @author chen-chao
 */
public interface OAuthConstant {
    static final String PATH_CALLBACK = "/oauth/callback";

    static final String ACCOUNT_URL = "accountURL";

    static final String CALLBACK_URL = "callbackURL";

    static final String SPECIAL_CALLBACK_URL = "oob";

    static final String CALLBACK_STATE_CODE = "state";

    static final String REDIRECT_PARAM_NAME_CONSUMER = "consumer";

    /**
     * used in OAuth V2.0
     */
    static final String PATH_CALLBACK_V2 = "/oauth/callback2";

    static final String AUTHORIZED_CODE = "code";

    static final String REDIRECT_URI = "redirect_uri";

    static final String CLIENT_ID = "client_id";

    static final String RESPONSE_TYPE = "response_type";

    static final String CLIENT_SECRET = "client_secret";

    static final String GRANT_TYPE = "grant_type";
    static final String GRANT_TYPE_REFRESH = "refresh_token";

    static final String AUTH_TYPE = "auth_type";

    static final String GRANT_TYPE_VALUE_AUTHOR_CODE = "authorization_code";

    static final String GRANT_TYPE_VALUE_REFRESH = "refresh_token";

    static final String AUTHORIZED_HEAD_NAME = "Authorization";

    static final String REFRESH_TOKEN = AccConst.REFRESH_TOKEN;

    static final String ACCESS_TOKEN = AccConst.ACCESS_TOKEN;
    
    static final String REMAIN = AccConst.REMAIN;
    
    static final String REMIND = AccConst.REMIND;
    
    
    static final String EXPIRED = AccConst.EXPIRED;
    static final String SINA_REMIND_IN = "remind_in"; 
    
    static final String REFRESH_TIME = "refresh_time";
    
    static final String SCOPE = "scope";
    
    static final String EXPIRES_IN = "expires_in";
    
    static final String OPEN_ID = "openid";

    static final String OAUTH2_CODE = "code";
    
    static final String CQQ_MESSAGE = "msg";
    
    static final String QQ_OAUTH_CONSUMER_KEY = "oauth_consumer_key";
    
    static final String QQ_OPEN_ID = OPEN_ID;
    
    static final String QQ_OPEN_KEY = "openkey";

    static final String OAUTH_VERSION = "oauth_version";
    /**
     * for sina force login
     */
    static final String SINA_IS_FORCE_LOGIN = "forcelogin";

    static final String DISPLAY = "display";

    static final String DISPLAY_MODE_MOBILE = "mobile";

    /**
     * password, username login
     */
    static final String USERNAME = "username";

    static final String PASSWORD = "password";

    /**
     * used in sina OAuth2.0
     */
    static final String ACCOUNT_INFO_URL = "accountInfoURL";

    /**
     * used in weibo qq OAuth2.0
     */
    static final String PATH_CALLBACK_WQQ = "/oauth/callback/wqq";

    /**
     * used in QQ (QQ connect and QQ plus)
     */
    static final String PATH_CALLBACK_CQQ = "/oauth/callback/cqq";

    static final String PATH_CALLBACK_Qplus = "/oauth/callback/qplus";
    
}
