/**
 * @(#)TokenEncodeUtils.java, 2012-9-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.AccCookies;
import outfox.account.data.TpToken;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.server.token.verifier.Verifier.TwoPart;
import outfox.account.server.token.verifier.impl.URSTokenVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;

/**
 * @author chen-chao
 */
public class TokenUtils {
    private static final Log LOG = LogFactory.getLog(TokenUtils.class);
    public static final String SPLIT_CHARS = "||";
    private static final int TOKEN_MAX_LENGTH = AccConfig.getPros().getInt(AccConfig.NAME_CHECK_TOKEN_LENGTH);
    private static DataStore datastore = DataStore.getInstance();
    public static String encode(IVerifier verifier, TpToken tpToken) throws AccException {
        String encode = verifier.encode(tpToken);
        String sign = AuthUtils.sign(encode, verifier.getVerifierName());
        tpToken.signature = sign;
        tpToken.srcToken = encode + sign;
        tpToken.parseToken = tpToken.srcToken;
        return tpToken.srcToken;
    }
    
    public static String getBaseString(String src) throws AccException {
        int index = src.lastIndexOf(SPLIT_CHARS);
        if (index == -1 || index == src.length() - SPLIT_CHARS.length()) {
            throw new AccException("get token base string error:" + src + " index is:" + index, AccExpType.FAKE_TOKEN);
        } 
        return src.substring(0, index + SPLIT_CHARS.length());
    }
    
    /**
     * check in memory.
     * @param token
     * @return
     * @throws AccException
     */
    public static TpToken decode(String token) throws AccException {
        String[] result = checkToken(token);
        IVerifier verifierInstance = TokenVerifierFactory.getInstance().getTokenVerifier(result[1],
                result[2]);
        TpToken tpToken = verifierInstance.decode(token);
        tpToken.signature = result[0];
        return tpToken;
    }
    
    /**
     * return signature, product, verifierName
     * @param token
     * @return
     * @throws AccException
     */
    public static String[] checkToken(String token) throws AccException {
        if (StringUtils.isBlank(token)) {
            throw new AccException("token is empty.", AccExpType.FAKE_TOKEN);
        }
        if (token.length() < 10 || token.length() > TOKEN_MAX_LENGTH) {
            throw new AccException("token length more than:" + TOKEN_MAX_LENGTH, AccExpType.FAKE_TOKEN);
        }
        // check signature
        String baseString = getBaseString(token);
        String sign = getSignature(token, baseString);
        TwoPart tw = getProductAndVerifierName(token);
        IVerifier verifierInstance = TokenVerifierFactory.getInstance().getTokenVerifier(tw.first,
                tw.second);
        String signature = AuthUtils.sign(baseString, verifierInstance.getVerifierName());
        if (!sign.equals(signature)) {
            throw new AccException("signature error:" + token, AccExpType.FAKE_TOKEN);
        }
        String[] result = new String[]{sign, tw.first, tw.second};
        return result;
    }

    private static String getSignature(String token, String baseString) {
        return token.substring(baseString.length());
    }
    
    /**
     * first is product name and second is verifierName
     * @param token
     * @return
     */
    public static TwoPart getProductAndVerifierName(String token) {
        TwoPart tw = new TwoPart(token);
        String verifierName = tw.first;
        tw.next();
        tw.second = verifierName;
        return tw; 
    }
    
    public static TpToken genCompleteTpToken(IVerifier verifier, TpToken tp) throws AccException {
        String token = encode(verifier, tp);
        String cookieIndex = AuthUtils.genUniqueToken(token);
        tp.sessIndex = cookieIndex;
        tp.setSessAliveTime(verifier.getSessAliveTime());
        return tp;
    }
    
    public static AccCookies tpTokenGenCookie(HttpServletRequest req, HttpServletResponse resp,
            Map<String, Object> response, TpToken tpToken) throws AccException {
        AccCookies accCookie = genCookieByCookieParam(req, tpToken);
        datastore.writePersToken(tpToken);
        datastore.writeSessToken(tpToken);
        accCookie.addCookieToResponse(resp);
        LOG.info(String.format(
                "user id: %s, product: %s, ip: %s, and app: %s are added into datastore. logined!",
                tpToken.userId, tpToken.product, tpToken.ip, tpToken.app));
        return accCookie;
    }
    
    public static AccCookies genCookieByCookieParam(HttpServletRequest req, TpToken tpToken) throws AccException {
        int cookieParam = AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value());
        return genCookieByCookieParam(req, tpToken, cookieParam);
    }
    
    public static AccCookies genCookieByCookieParam(HttpServletRequest req, TpToken tpToken, int cookieParam) throws AccException {
        final String product = tpToken.product;
        AccCookies oldCookies = AccCookies.extractCookies(req,
                product);
        AccCookies accCookie = new AccCookies(product, req, tpToken.app);
        String token = tpToken.srcToken;
        String cookieIndex = tpToken.sessIndex;
        
        if (COOKIE_FORMAT.pe.isContain(cookieParam)) {
            // want a persist token
            accCookie.genPersCookie(token, tpToken.getExpiredTime());
        }
        //TODO: why ?
        accCookie.forceLogin(false);
        if (COOKIE_FORMAT.se.isContain(cookieParam)) {
            if (oldCookies.isLogin()) {
                final Cookie sessionCookie = oldCookies.getSessionCookie();
                if ((sessionCookie == null) || (sessionCookie != null && !sessionCookie.getValue().equals(cookieIndex))) {
                    // session cookie will be rewrite.
                    accCookie.relogin(true);
                }
            }
            if (req.getAttribute(product + AccConst.ATTR_PART_PC) != null) {
                // only perstoken can refresh session cookie create time.
                if (AuthUtils.getReqBoolean(req, AccConst.PARAM_URS_MEMORY_COOKIE, false)) {
                    // gen cookie
                    IVerifier verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, tpToken.verifierName);
                    if (verifier instanceof URSTokenVerifier) {
                        URSTokenVerifier ursVerifier = (URSTokenVerifier) verifier;
                        String sessCookieValue = URSTokenVerifier.generateURSMemorySessVal(ursVerifier.getSessCookieValue(tpToken), tpToken, tpToken.getSessAliveTime());
                        tpToken.sessIndex = sessCookieValue;
                        cookieIndex = sessCookieValue;
                        accCookie.genSessCookie(sessCookieValue);
                        datastore.writePersToken(tpToken);
                    }
                }
		// only session can refresh its create time.
                LOG.info(String
                        .format("user id: %s, product: %s, ip: %s, and app: %s (user-agent:%s, other:%s)  are added into datastore. Relogined!",
                                tpToken.userId, tpToken.product, tpToken.ip, tpToken.app,
                                ReqUtils.getUserAgent(req),
                                AuthUtils.getReqParamVal(req, AccConst.PARAM_OTHER, AccConst.EMPTY_STR)));

                datastore.writeSessToken(tpToken);
            } else {
                LOG.info(String
                        .format("user id: %s, product: %s, ip: %s, and app: %s (user-agent:%s, other:%s) want to get NEW SESSCOOKIE. FAILED!",
                                tpToken.userId, tpToken.product, tpToken.ip, tpToken.app,
                                ReqUtils.getUserAgent(req),
                                AuthUtils.getReqParamVal(req, AccConst.PARAM_OTHER, AccConst.EMPTY_STR)));
            }
            
        } else {
            final Cookie bindCookie = oldCookies.getBindCookie();
            if (oldCookies.isBind() && COOKIE_FORMAT.b.isContain(cookieParam) ) {
                if ((bindCookie == null) || (bindCookie != null && !bindCookie.getValue().equals(cookieIndex)) ) {
                    accCookie.reBind(true);
                }
            }
        }
        // bind cookie and session cookie
        if ((cookieParam & 10) != 0) {
            // add session cookie or bind cookie

            if (COOKIE_FORMAT.b.isContain(cookieParam)) {
                accCookie.genBindCookie(cookieIndex);
                accCookie.setSessCookie(null);
            } else {
                accCookie.genSessCookie(cookieIndex);
                accCookie.setBindCookie(null);
            }
        }
        if (COOKIE_FORMAT.info.isOnlyContain(cookieParam) && StringUtils.isNotBlank(tpToken.userId)) {
            accCookie.setNotSendToResponse(true);
        }
        // continue
        return accCookie;
    }
    public static long checkTokenExpired(TpToken tpToken) throws AccException {
        if (tpToken.getExpiredTime() == -1) {
            return tpToken.getExpiredTime();
        }
        long remain = tpToken.getCreateTime() + tpToken.getExpiredTime() - System.currentTimeMillis();
        if (remain <= 0) {
            throw new AccException("token expired.", AccExpType.FAKE_TOKEN);
        }
        return remain;
    }
}
