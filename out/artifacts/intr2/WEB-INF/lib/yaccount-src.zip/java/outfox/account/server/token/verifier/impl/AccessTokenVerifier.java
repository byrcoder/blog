/**
 * @(#)AccessTokenVerifier.java, 2013-1-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.AccCookies;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.ITokenVerifier;
import outfox.account.server.token.verifier.Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.CipherUtils;

/**
 * verifier name is : tpAcc
 * idPattern is {verifier}{id}
 * 
 * @author chen-chao
 */
public class AccessTokenVerifier extends Verifier {

    public static final String NAME = VerifierConfConst.ACCESS_TOKEN_VERIFIER_NAME;
    private String supportVerifierNames;
    protected Set<String> supportVeriferSet; 
    public AccessTokenVerifier(Properties props) {
        super(props);
        supportVerifierNames = getAndCheck(props, getVerifierName() + VerifierConfConst.VERIFIER_SUPPORT);
        supportVeriferSet = new HashSet<String>();
        if (StringUtils.isNotBlank(supportVerifierNames)) {
            supportVerifierNames.replace(" ", ""); // trim
            supportVeriferSet.addAll(Arrays.asList(supportVerifierNames.split(",")));
        }
    }

    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException {
        // TODO Auto-generated method stub
        return null;
    }
    
    public String ownId2tp(String tpName, String ownId) throws AccException {
        
        throw new AccException(AccExpType.NOT_SUPPORT);
    }

    @Override
    public String ownId2tp(String ownId) throws AccException {
        throw new AccException(AccExpType.NOT_SUPPORT);
    }
    
    public String tpId2ownId(String thirdParty, String id) throws AccException {
        ITokenVerifier verifier = getVerifier(thirdParty);
        return verifier.tpId2ownId(id);
    }
    
    @Override
    public String tpId2ownId(String id) throws AccException {
        throw new AccException(AccExpType.NOT_SUPPORT);
    }

    @Override
    public String getVerifierName() {
        return NAME;
    }
    
    protected ITokenVerifier getVerifier(String thirdPartyName) throws AccException {
        if (StringUtils.isBlank(thirdPartyName)) {
            throw new AccException(AccExpType.PARAM_MISSING_ERROR, "which third party? param %s is missing?", AccConst.PARAM_ACCESS_TOKEN_VERIFIER);
        }
        if (!supportVeriferSet.contains(thirdPartyName)) {
            throw new AccException(AccExpType.LOGIC_ERROR, "verifier %s-%s is not supported by access token verifier", product, thirdPartyName);
        }
        TokenVerifierFactory vf = TokenVerifierFactory.getInstance();
        return (ITokenVerifier)vf.getTokenVerifier(product, thirdPartyName);
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        String thirdPartyName = AuthUtils.getReqVal(req, AccConst.PARAM_ACCESS_TOKEN_VERIFIER);
        ITokenVerifier thirdVerifier = getVerifier(thirdPartyName);
        String accessToken = null;
        String openId = null;
        String pci = AuthUtils.getReqVal(req, AccConst.PARAM_PCINDEX_NAME);
        String alogrithm = (String)req.getAttribute(AccConst.ATTR_ALOGRITHM);
        String priKeyHex = (String)req.getAttribute(AccConst.ATTR_PRIVATE_KEY_HEX);
        if (StringUtils.isBlank(pci) && priKeyHex == null) {
            
            AuthUtils.checkHttpsProtocal(req);
            accessToken = AuthUtils.getParamOrHeaderOrAttr(req, OAuthConstant.ACCESS_TOKEN);
            openId = AuthUtils.getParamOrHeaderOrAttr(req, AccConst.PARAM_OPEN_ID);
            
        } else {
            String info = null;
            if (priKeyHex != null) {
                info = CipherUtils.decryptInfo(req, alogrithm, priKeyHex);
            } else {
                info = CipherUtils.decryptInfo(req, pci);
            }
            Map<String,String> map = AuthUtils.genInfoMap(info);
            accessToken = map.get(OAuthConstant.ACCESS_TOKEN);
            openId = map.get(AccConst.PARAM_OPEN_ID);
        }
        
        Map<String, String> tokens = new HashMap<String, String>();
        tokens.put(AccConst.TOKEN, accessToken);
        tokens.put(AccConst.OPEN_ID, openId);
        String clientIP = AuthUtils.getRequestIPIncludeInner(req);
        tokens.put(AccConst.IP_ADDRESS, clientIP);
        tokens.put(AccConst.SINGLE_SIGN_ON, AccConst.SINGLE_SIGN_ON);
        UserInfoWritable userinfo = thirdVerifier.getUserInfo(tokens);
        if (userinfo == null || StringUtils.isBlank(userinfo.userId)) {
            throw new AccException(AccExpType.FAKE_TOKEN, " token %s is fake.", accessToken);
        }
        TpToken tp = new TpToken();
        tp.userId = userinfo.userId;
        //don't know expire time
        tp.setExpiredTime(getExpireTime(req));
        tp.token = accessToken;
        tp.ip = clientIP;
        tp.product = product;
        tp.app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
        tp.verifierName = NAME;
        tp.setProperty(AccConst.PARAM_ACCESS_TOKEN_VERIFIER, thirdPartyName);
        TokenUtils.genCompleteTpToken(this, tp);
        tp.setProperty(OAuthConstant.QQ_OPEN_ID, AuthUtils.toNotNullString(openId));

        store.writeUserInfo(userinfo);
        Map<String, Object> returnInfo = new HashMap<String, Object>();
        shouldPutUserInfoInReturnInfo(returnInfo, AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value()), userinfo);

        AccCookies cookies = TokenUtils.tpTokenGenCookie(req, resp, returnInfo, tp);
        // write persist cookie into resultInfo 
        shouldPutPersTokenInReturnInfo(returnInfo, cookies.getProduct(), tp.app, cookies.getPerTokenV2());
        return returnInfo;
    }
    
    /**
     * get expire time. if the request dosen't have the parameter, using -1L.
     * 
     * @param req
     * @return
     */
    private long getExpireTime(HttpServletRequest req) {
        String expireTime = req.getParameter(AccConst.PARAM_TOKEN_EXPIRE_TIME);
        long expire = -1L;
        try {
            expire = Long.parseLong(expireTime);
            if (expire < 0) {
                expire = -1L;
            }
        }catch(Throwable t) {
            LOG.warn("Expire time get from request is "+expireTime+". set to -1L");
            expire = -1L;
        }
        return expire;
    }
    
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp,
            String token, long expiredTime) throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expiredTime);
        // set access token
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        TpToken tpToken = tokenWritable.getTpToken();
        thirdPartyTokens.put(AccConst.TOKEN, tpToken.token);
        thirdPartyTokens.put(AccConst.OPEN_ID, tpToken.getProperty(OAuthConstant.OPEN_ID));
        thirdPartyTokens.put(AccConst.SINGLE_SIGN_ON, AccConst.SINGLE_SIGN_ON);
        thirdPartyTokens.put(AccConst.IP_ADDRESS, AuthUtils.getRequestIPIncludeInner(req));
        // check in third party.
        ITokenVerifier thirdVerifier = getVerifier(tpToken.getProperty(AccConst.PARAM_ACCESS_TOKEN_VERIFIER));
        UserInfoWritable userInfo = thirdVerifier.getUserInfo(thirdPartyTokens);
        userInfo.putInfoMap(result);
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        return result;
    }
}
