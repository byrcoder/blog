/**
 * @(#)QplusVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.data.AccCookies;
import outfox.account.data.TpToken;
import outfox.account.data.user.QQUserInfoWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.server.token.verifier.qplus.QOpenBean;
import outfox.account.server.token.verifier.qplus.QOpenInfo;
import outfox.account.server.token.verifier.qplus.QOpenService;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class QplusVerifier extends Verifier {

    private String appKey;

    private String appSecret;

    private String lang;

    private String baseUrl;

    public static final String NAME = "qplus";

    private QOpenService qplus;
    
    public static final String OPEN_ID = "openid";
    public static final String OPEN_KEY = "openkey";
    public static final String USER_IP = "userip";

    public QplusVerifier(Properties props) {
        super(props);
        baseUrl = getAndCheck(props, NAME + VerifierConfConst.BASE_URL);
        appKey = getAndCheck(props, NAME + VerifierConfConst.KEY);
        appSecret = getAndCheck(props, NAME + VerifierConfConst.SECRET);
        lang = getAndCheck(props, NAME + ".consumer.lang");
        idPattern = getAndCheck(props, NAME + VerifierConfConst.ID);
        qplus = QOpenService.createInstance(appKey, appSecret, lang, baseUrl);
        getIdPrefix();
    }

    @Override
    public String getVerifierName() {
        return NAME;
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        String openKey = req.getParameter(AccConst.PARAM_OPEN_KEY);
        String openId = req.getParameter(AccConst.PARAM_OPEN_ID);
        String userIp = AuthUtils.getRequestIP(req);
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        thirdPartyTokens.put(OPEN_KEY, openKey);
        thirdPartyTokens.put(OPEN_ID, openId);
        thirdPartyTokens.put(USER_IP, userIp);
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);

        if (userInfo != null) {
            TpToken tp = new TpToken();
            tp.userId = userInfo.userId;
            tp.setExpiredTime(-1L);
            tp.token = openKey;
            tp.authid = openId;
            tp.ip = userIp;
            tp.product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
            tp.app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
            tp.verifierName = NAME;
            TokenUtils.genCompleteTpToken(this, tp);
            
            store.writeUserInfo(userInfo);
            Map<String,Object> returnInfo = new HashMap<String,Object>();
            userInfo.putInfoMap(returnInfo);
            
            AccCookies cookies = TokenUtils.tpTokenGenCookie(req, resp, returnInfo, tp);
            // qplus will not set pers token
            cookies.addCookieToResponse(resp);
            return returnInfo;
        } else {
            throw new AccException("can not get result for qplus.", AccExpType.TP_ERROR);
        }
    }

    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("thirdPartyTokens is null", AccExpType.FAKE_TOKEN);
        }
        String openId = thirdPartyTokens.get(OPEN_ID);
        String openKey = thirdPartyTokens.get(OPEN_KEY);
        String userIp = thirdPartyTokens.get(USER_IP);
        if (StringUtils.isBlank(openId) || StringUtils.isBlank(openKey) || StringUtils.isBlank(userIp) ) {
            throw new AccException(String.format("openId:%s, openKey:%s and userIp:%s, can not get userinfo", openId, openKey, userIp), AccExpType.FAKE_TOKEN);
        }
        int count = 3;
        QOpenInfo result = null;
        while (count-- != 0) {
            try {
                result = qplus.getUserInfo(new QOpenBean(openId, openKey, userIp)).getQPlusInfo();
            } catch (IOException e) {
                continue;
            }
            break;
        }
        if (result == null) {
            return null;
        }
        return new QQUserInfoWritable(tpId2ownId(openId), openId, result);
    }

}
