/**
 * @(#)AuthUtils.java, 2011-12-14. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.security.KeyPair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;
import net.sf.json.util.JSONTokener;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.MalformedCookieException;
import org.apache.http.impl.cookie.BrowserCompatSpec;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpStatus;

import outfox.account.cache.LocalWriteCache;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.conf.AccConst.OAUTH_TYPE;
import outfox.account.data.AccCookies;
import outfox.account.data.CipherKeyPair;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.xss.XssUtils;
import toolbox.web.CookieUtil;

/**
 * @author chen-chao
 */
public class AuthUtils {
    public static final String SEPARATOR = "/";

    private static final ThreadLocal<Random> rand = new ThreadLocal<Random>() {
        protected Random initialValue() {
            return new Random(System.currentTimeMillis());
        }
    };
    
    private static final int RSA_CACHE_SIZE = AccConfig.getPros().getInt(AccConfig.NAME_RSA_KEY_CACHE_LIMITS);
 
    /**
     * if REMOVE_PROBABILITY = 1024, then 1/1024 probability will remove key-pair.
     */
    private static final int REMOVE_PROBABILITY = RSA_CACHE_SIZE >> 7;  
    private static final LocalWriteCache<Integer, KeyPair> KEYS_CACHE = new LocalWriteCache<Integer, KeyPair>(
            true, RSA_CACHE_SIZE);

    public static final String PREFIX_DOMAIN = "www.";

    /**
     * random mapping (64), '_' and '-' can only used in url mapping.
     */
    private static char[] charactors = {
        'Z', 'm', 'V', '0', 'B', 'W', 'R', 'c', 'y', 'E', 'o', 'N', 'L', 'M', 'H', 'j', 'u', '5', 't', 'h',
        'F', 'G', 'n', '2', '4', 'f', 'd', '1', 'S', 'A', 'I', 'D', 'K', 'l', 'U', 'O', 'z', 'Y', 'k', 's',
        'b', '-', '3', 'r', 'a', 'x', '7', '9', 'Q', 'g', 'e', '6', 'p', 'q', 'P', 'T', 'w', 'J', 'i', 'v',
        'X', '8', 'C', '_',
    };

    private static String LOCAL_IP = null;

    private static Set<String> COOKIE_POST_MAP = new HashSet<String>();
    static {
        COOKIE_POST_MAP.add(AccConst.COOKIE_SESSION_BIND);
        COOKIE_POST_MAP.add(AccConst.COOKIE_SESSION);
        COOKIE_POST_MAP.add(AccConst.COOKIE_LOGIN);
        COOKIE_POST_MAP.add(AccConst.COOKIE_PERSISTENT);
        try {
            LOCAL_IP = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            throw new AccRunTimeException("get local ip error.", e);
        }
    }
    /**
     * from 0 ~ maxMilliSecond
     * @param maxMilliSecond
     * @return
     */
    public static long getRandomMilliSecond(long maxMilliSecond) {
        return (long)(rand.get().nextFloat() * maxMilliSecond);
    }

    public static String getLocalIP() {
        return LOCAL_IP;
    }

    public static boolean isLocal(String ip) {
        return LOCAL_IP.equals(ip);
    }

    public static boolean isContain(String cookieNamePostfix) {
        return COOKIE_POST_MAP.contains(cookieNamePostfix);
    }

    public static char[] getMappingChars() {
        return Arrays.copyOf(charactors, charactors.length);
    }

    private static String byteToShortString(byte[] buffer, int offest) {
        long v = (((long) buffer[offest + 0] << 56) + ((long) (buffer[offest + 1] & 255) << 48)
                + ((long) (buffer[offest + 2] & 255) << 40) + ((long) (buffer[offest + 3] & 255) << 32)
                + ((long) (buffer[offest + 4] & 255) << 24) + ((buffer[offest + 5] & 255) << 16)
                + ((buffer[offest + 6] & 255) << 8) + ((buffer[offest + 7] & 255) << 0));
        v = Math.abs(v);
        StringBuffer res = new StringBuffer();
        while (v != 0) {
            res.append(charactors[(int) (v & 63)]); // v % charactors.length
            v >>= 6; // v / charactors.length
        }
        return res.toString();
    }

    public static String byteToShortString(byte[] buffer) {

        int i = buffer.length & 7; // buffer.length % 8
        byte[] formatBuffer = new byte[buffer.length + 8 - i];
        System.arraycopy(buffer, 0, formatBuffer, 0, buffer.length);
        while (i != 0) {
            formatBuffer[formatBuffer.length - i] = 0;
            i--;
        }
        int times = formatBuffer.length >> 3; // formatBuffer.length / 8
        StringBuilder res = new StringBuilder();
        for (i = 0; i != times; i++) {
            res.append(byteToShortString(formatBuffer, i << 3)); // i * 8
        }
        return res.toString();
    }

    /**
     * convert a long value to an 8 bytes array.
     * 
     * @param v
     * @return
     */
    private static byte[] convertLong2Bytes(long v) {
        byte[] buffer = new byte[8];
        buffer[0] = (byte) (v >>> 56);
        buffer[1] = (byte) (v >>> 48);
        buffer[2] = (byte) (v >>> 40);
        buffer[3] = (byte) (v >>> 32);
        buffer[4] = (byte) (v >>> 24);
        buffer[5] = (byte) (v >>> 16);
        buffer[6] = (byte) (v >>> 8);
        buffer[7] = (byte) (v >>> 0);
        return buffer;
    }

    public static String genUniqueToken() {
        long nano = getNanoTime();
        return byteToShortString(convertLong2Bytes(nano))
                + byteToShortString(DigestUtils.sha256Hex(
                        (nano + Long.toHexString(rand.get().nextLong()))).getBytes());

    }
    
    public static String randomStr() {
        return byteToShortString((""+rand.get().nextLong()).getBytes());
    }
    
    public static synchronized long getNanoTime() {
        return System.nanoTime();
    }

    /**
     * using msg to generate an unique token
     * 
     * @param msg
     * @return
     */
    public static String genUniqueToken(String msg) {
        long nano = getNanoTime();
        return byteToShortString(convertLong2Bytes(nano))
                + byteToShortString(DigestUtils.sha256Hex(
                        nano + msg + Long.toHexString(rand.get().nextLong())).getBytes());
    }

    public static String generateFileId() {
        long v = rand.get().nextLong() + System.currentTimeMillis() * 37; // use a primer
        v = Math.abs(v);
        StringBuffer res = new StringBuffer();
        while (v != 0) {
            res.append(charactors[(int) (v & 63)]); // v % 64
            v >>= 8; // v / 64
        }
        return res.toString();
    }

    /**
     * get real client-ip of http request
     * 
     * @param httpRequest
     * @return ip address
     */
    public static String getRequestIP(ServletRequest request) {
        if (!(request instanceof HttpServletRequest)) {
            return request.getRemoteAddr();
        }
        HttpServletRequest httpRequest = (HttpServletRequest) request;

        String ip = httpRequest.getHeader("x-forwarded-for");
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = httpRequest.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = httpRequest.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = httpRequest.getRemoteAddr();
        }

        return ip;
    }
    /**
     * First check "__ip__" attribute from request.
     * If attribute is null, return remote request IP.
     * 
     * @param req
     * @return
     */
    public static String getRequestIPIncludeInner(ServletRequest req) {
        String clientIP = (String)req.getAttribute(AccConst.ATTR_IP);
        if (clientIP == null) {
            clientIP = AuthUtils.getRequestIP(req);
        }
        return clientIP;
    }

    /**
     * get cookie value from cookieKey
     * 
     * @param req
     *            servlet request
     * @param cookieKey
     *            {@link #COOKIE_YNOTE_SESS}
     * @return
     */
    public static String extractCookieValue(ServletRequest req, String CookieKey) {
        HttpServletRequest request = (HttpServletRequest) req;
        Cookie cookie = CookieUtil.findCookie(request, CookieKey);
        if (cookie == null) {
            return null;
        }
        return cookie.getValue().trim();
    }

    /**
     * @param request
     * @param path
     *            path should start with "/"
     * @return
     */
    public static String generateAbsoluteUrl(HttpServletRequest request, String path) {
        return generateAbsoluteUrl(request, request.getContextPath(), path);
    }
    public static String generateAbsoluteUrl(HttpServletRequest request, String contextPath, String path) {
        return generateAbsoluteUrl(request, contextPath, path, null);
    }
    /**
     * @param request
     * @param path
     *            path should start with "/"
     * @return
     */
    public static String generateAbsoluteUrl(HttpServletRequest request, String contextPath, String path, String scheme) {
        StringBuffer url = null;
        if (StringUtils.isBlank(scheme)) {
            url = new StringBuffer(request.getScheme());
        } else {
            url = new StringBuffer(scheme);
        }
        url.append("://").append(request.getServerName());
        if (80 != request.getServerPort()) {
            url.append(':').append(request.getServerPort());
        }

        url.append(contextPath).append(path);
        return url.toString();
    }

    public static JSONObject convertToJSON(String str) {
        return JSONObject.fromObject(new JSONTokener(str));
    }

    public static void jsonToResponse(HttpServletResponse resp, JSONObject json) throws IOException {
        String content = json.toString();
        resp.setContentType(AccConst.JSON_CONTENT_TYPE);
        resp.getOutputStream().write(content.getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }

    /**
     * Is url string containing query string?
     * 
     * @param url
     * @return
     */
    public static boolean isContainQueryString(String url) {
        if (url == null) {
            return false;
        }
        return url.indexOf("?") >= 0 ? true : false;
    }

    /**
     * Validate
     * 
     * @param inputString
     * @return
     */
    public static boolean isValidEmailAddress(String inputString) {
        Pattern emailPatter = Pattern.compile("^[\\w\\!#\\$%\'\\*\\+/=\\?{\\|}\\~\\^\\.\\-_]+@[\\w\\.\\-]+$");
        return emailPatter.matcher(inputString).matches();
    }

    public static Cookie deleteCookie(String name, String domain, boolean httpOnly) {
        return genCookie(name, "", domain, AccConst.COOKIE_ROOT_PATH, 0, httpOnly);
    }
    
    /**
     * this cookie is delete cookie.
     * @param name
     * @param value
     * @param domain
     * @param httpOnly
     * @return
     */
    public static Cookie tickyCookie(String name, String value, String domain, boolean httpOnly) {
        return genCookie(name, value, domain, AccConst.COOKIE_ROOT_PATH, 0, httpOnly);
    }

    public static Cookie genCookie(String name, String value, String domain, String path, int age,
            boolean httpOnly) {
        Cookie cookie = new Cookie(name, value);
        cookie.setDomain(domain);
        cookie.setPath(path);
        cookie.setHttpOnly(httpOnly);
        cookie.setMaxAge(age);
        return cookie;
    }

    public static String genAccessTokenName(String consumer) {
        return consumer + "." + OAUTH_TYPE.ACCESS_TOKEN.value();
    }

    public static String genRequestTokenName(String consumer) {
        return consumer + "." + OAUTH_TYPE.REQUEST_TOKEN.value();
    }

    public static String genTokenSecretName(String consumer) {
        return consumer + "." + OAUTH_TYPE.TOKEN_SECRET.value();
    }

    public static String genRefreshTokenName(String consumer) {
        return consumer + "." + OAuthConstant.REFRESH_TOKEN;
    }

    /**
     * get a free port of local host
     * 
     * @return
     * @throws IOException
     */
    public static int getFreePort() throws IOException {
        ServerSocket server = new ServerSocket(0);
        int port = server.getLocalPort();
        server.close();
        return port;
    }

    public static List<Integer> getFreePorts(int size) throws IOException {
        ArrayList<Integer> result = new ArrayList<Integer>();
        ArrayList<ServerSocket> sockets = new ArrayList<ServerSocket>();
        for (int i = 0; i < size; ++i) {
            ServerSocket server = new ServerSocket(0);
            sockets.add(server);
            result.add(server.getLocalPort());
        }

        for (ServerSocket server: sockets) {
            server.close();
        }
        return result;
    }

    private static final String JS_CONTENT_FORMAT = "<script type=\"text/javascript\">parent.callback(%s);</script>";

    public static void writeJSChunked(HttpServletResponse resp, String result, HttpStatus stat)
            throws AccException {
        String content = String.format(JS_CONTENT_FORMAT, XssUtils.filterXSS(result));
        writeHTMLChunked(resp, content, stat);
    }

    public static void writePlainChunked(HttpServletResponse resp, String plain, HttpStatus stat)
            throws AccException {
        try {
            write(resp, plain.getBytes(AccConst.UTF8), true, AccConst.PLAIN_CONTENT_TYPE, stat);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("Encoding error in plain write. stat:" + stat, e,
                    AccExpType.ENCODING_ERROR);
        }

    }

    public static void writeJSONChunked(HttpServletResponse resp, JSONObject object, HttpStatus stat)
            throws AccException {
        try {
            write(resp, object.toString().getBytes(AccConst.UTF8), true, AccConst.JSON_CONTENT_TYPE, stat);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("Encoding error in json write. stat:" + stat, e, AccExpType.ENCODING_ERROR);
        }
    }

    public static void writeHTMLChunked(HttpServletResponse resp, String html, HttpStatus stat)
            throws AccException {
        try {
            write(resp, html.getBytes(AccConst.UTF8), true, AccConst.HTML_CONTENT_TYPE, stat);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("Encoding error in html/js write. stat:" + stat + " html:" + html, e,
                    AccExpType.ENCODING_ERROR);
        }
    }
    
    public static void writeImageChunked(HttpServletResponse resp, byte[] data,
            HttpStatus stat) throws AccException {
        write(resp, data, true, AccConst.IMAGE_CONTENT_TYPE, stat);
    }
    
    public static void writeXML(HttpServletResponse resp, String xml, HttpStatus stat) throws AccException {
        try {
            write(resp, xml.getBytes(AccConst.UTF8), true, AccConst.XML_CONTENT_TYPE, stat);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("Encoding error in html/js write. stat:" + stat + " xml:" + xml, e,
                    AccExpType.ENCODING_ERROR);
        }
    }
    
    private static void write(HttpServletResponse resp, byte[] bytes, boolean isChunked, String contentType,
            HttpStatus stat) throws AccException {
        resp.setContentType(contentType);
        resp.setStatus(stat.value());
        if (!isChunked) {
            resp.setContentLength(bytes.length);
            resp.setBufferSize(bytes.length);

        }
        ServletOutputStream out = null;
        try {
            out = resp.getOutputStream();
            out.write(bytes);
        } catch (IOException e) {
            throw new AccException("response write error. content-type:" + contentType + " stat:" + stat, e,
                    AccExpType.RESPONSE_WRITE_BYTE_ERROR);
        } 
    }

    public static String getStringFromBytes(byte[] array, String charset) {
        try {
            return new String(array, charset);
        } catch (Throwable t) {
            return null;
        }
    }
    /**
     * Append KVs in json object as parameters to given url.
     * @param url
     * @param jsonObj
     * @return
     * @throws AccException
     */
    public static String composeQueryUrl(String url, JSONObject jsonObj) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        for (@SuppressWarnings("rawtypes")
        Iterator iter = jsonObj.keys(); iter.hasNext();) {
            String key = (String)iter.next();
            Object value = jsonObj.get(key);
            if (null != value) {
                params.add(new Parameter(key, value.toString()));
            }
        }
        return composeQueryUrl(url, params);
        
    }

    /**
     * compose a url with url parameters.
     * 
     * @param url
     * @param params
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String composeQueryUrl(String url, Parameter p) throws AccException {
        if (p == null) {
            return url;
        }
        boolean first = checkIsFirstUrlParameter(url);
        StringBuilder parameterBuilder = new StringBuilder();

        if (!StringUtils.isBlank(p.getKey())) {
            if (first) {
                first = false;
            } else {
                parameterBuilder.append("&");
            }
            if (p.getValue() == null) {
                p.val = "";
            }
        }

        try {
            parameterBuilder.append(URLEncoder.encode(p.getKey(), AccConst.UTF8)).append("=")
                    .append(URLEncoder.encode(p.getStrVal(), AccConst.UTF8));
        } catch (UnsupportedEncodingException e) {
            throw new AccException(e, AccExpType.ENCODING_ERROR);
        }

        return composeUrl(url, parameterBuilder);
    }
    /**
     * compose a url with url parameters.
     * 
     * @param url
     * @param params
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String composeQueryUrl(String url, List<Parameter> params) throws AccException {
        if (params == null) {
            return url;
        }
        boolean first = checkIsFirstUrlParameter(url);
        StringBuilder parameterBuilder = new StringBuilder();
        for (Parameter p: params) {
            final String key = p.getKey();
            if (StringUtils.isBlank(key)) {
                continue;
            }
            if (first) {
                first = false;
            } else {
                parameterBuilder.append("&");
            }
            final Object value = p.getValue();
            if (value == null) {
                p.val = "";
            }
            try {
                parameterBuilder.append(URLEncoder.encode(key, AccConst.UTF8)).append("=")
                        .append(URLEncoder.encode(p.getStrVal(), AccConst.UTF8));
            } catch (UnsupportedEncodingException e) {
                throw new AccException(e, AccExpType.ENCODING_ERROR);
            }

        }
        return composeUrl(url, parameterBuilder);
    }

    private static boolean checkIsFirstUrlParameter(String url) {
        boolean first = true;
        if (url.indexOf("&") > 0) {
            first = false;
        }
        if (first) {
            int index = url.indexOf("?");
            if (index > 0 && index < url.length() - 1) {
                first = false;
            }
        }
        return first;
    }

    private static String composeUrl(String url, StringBuilder parameterBuilder) {
        String paramString = parameterBuilder.toString();
        if (StringUtils.isBlank(paramString)) {
            return url;
        }
        StringBuilder buffer = new StringBuilder();
        buffer.append(url);
        if (url.indexOf('?') < 0) {
            buffer.append("?");
        }
        buffer.append(paramString);

        return buffer.toString();
    }

    public static final String toString(Object from) {

        return (from == null) ? null : from.toString();
    }
    
    public static final String toNotNullString(Object from) {
        return (from == null) ? "" : from.toString();
    }

    public static class MultiPartValue {
        public String name;

        public String type;

        public String filename;

        public String disposition;

        public Object value;
    }

    public enum ParseMultiPartState {
        start, none, split,
    }

    /**
     * can not diff with "" and "\r\n", "\r" and "\n" (something will be wrong
     * in mac request).
     * 
     * @param req
     * @return
     * @throws AccException
     */
    public static final Map<String, MultiPartValue> simpleParseMultiPart(HttpServletRequest req)
            throws AccException {
        HashMap<String, MultiPartValue> map = null;
        String charset = Charset.defaultCharset().name();
        String contentType = req.getContentType();
        if (contentType != null) {
            int index = contentType.indexOf("charset=");
            if (index != -1) {
                charset = contentType.substring(index + "charset=".length()).trim();
            }
        }
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(req.getInputStream()));
            String line = null;
            StringBuilder sb = null;
            Map<String, String> store = null;
            ParseMultiPartState state = ParseMultiPartState.none;
            map = new HashMap<String, AuthUtils.MultiPartValue>();
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("--")) {
                    // boundary
                    switch (state) {
                        case none:
                            state = ParseMultiPartState.start;
                            break;
                        case split:
                            state = ParseMultiPartState.start;
                            MultiPartValue mpValue = new MultiPartValue();
                            mpValue.name = store.get("name");
                            mpValue.disposition = store.get("Content-Disposition");
                            mpValue.filename = store.get("filename");
                            mpValue.type = store.get("Content-Type");
                            String value = sb.toString();
                            if (value.equals(AccConst.LINE_SPARATOR)) {
                                value = "";
                            }
                            if ("application/octet-stream".equals(mpValue.type)) {
                                if (-1 == mpValue.type.indexOf(";")) {

                                }
                                mpValue.value = value.getBytes();
                            } else {
                                mpValue.value = new String(value.getBytes(), charset);
                            }

                            // store
                            map.put(mpValue.name, mpValue);
                            // clean
                            store.clear();
                            sb = null;
                            break;
                        default:
                            throw new AccException("state error:" + state, AccExpType.NOT_SUPPORT);
                    }

                } else if (line.startsWith("Content-Type")) {
                    store.put("Content-Type", line.substring(line.indexOf(":") + 1).trim());
                } else if (line.startsWith("Content-Disposition")) {
                    String[] kvs = line.split(";");
                    store = new HashMap<String, String>();
                    for (String kv: kvs) {
                        String[] kvInner = kv.split(":");
                        if (kvInner.length == 1) {
                            kvInner = kv.split("=");

                        }
                        if (kvInner.length == 2) {
                            String tmp = kvInner[1].trim();
                            if (tmp.startsWith("\"")) {
                                kvInner[1] = tmp.substring(1, tmp.length() - 1);
                            }
                            store.put(kvInner[0].trim(), kvInner[1].trim());
                        } else {
                            throw new AccException("not key: value? " + kv, AccExpType.NOT_SUPPORT);
                        }

                    }
                } else {
                    if (StringUtils.isBlank(line)) {

                        switch (state) {
                            case start:
                                state = ParseMultiPartState.split;
                                sb = new StringBuilder();
                                continue; /* escape the blank line */
                            default:
                                break;
                        }
                        Class<BufferedReader> r = BufferedReader.class;
                        Field f = r.getDeclaredField("skipLF");
                        f.setAccessible(true);
                        sb.append(AccConst.LINE_SPARATOR);
                    } else {
                        sb.append(line);
                    }
                }
            }
        } catch(AccException e) {
            throw e;
        } catch (Exception e) {
            throw new AccException("simpleParseMultiPart read error", e, AccExpType.RUNTIME_EXCEPTION);
        } finally {
            IOUtils.closeQuietly(reader);
        }

        return map;

    }

    public static String removeSuffix(String filename) {
        int index = filename.indexOf(".class");
        return index > 0 ? filename.substring(0, index) : filename;
    }
    public static void redirect(HttpServletResponse resp, String url, List<Parameter> params)
            throws AccException {
        String redirectUrl = null;
        try {
            redirectUrl = composeQueryUrl(url, params);
            resp.sendRedirect(redirectUrl);
        } catch (IOException e) {
            throw new AccException("can not redirect to " + redirectUrl, AccExpType.URI_ERROR);
        }
    }

    public static List<Parameter> convertMap2List(Map<String, Object> objs) {
        if (objs == null) {
            return null;
        }
        List<Parameter> parameters = new ArrayList<Parameter>();
        for (Entry<String, Object> entry: objs.entrySet()) {
            parameters.add(new Parameter(entry.getKey(), toString(entry.getValue())));
        }
        return parameters;
    }

    public static String addScheme(HttpServletRequest req, String redirectUrl, String defaultScheme) {
        if (StringUtils.isBlank(redirectUrl)) {
            return generateAbsoluteUrl(req, "");
        } else if (redirectUrl.startsWith(AccConst.HTTP_PROTOCAL)) {
            // http or https
            return redirectUrl;
        } else {
            // no scheme or no http scheme
            if (redirectUrl.startsWith(AccConst.URL_ROOT)) {
                if (StringUtils.isBlank(defaultScheme)) {
                    return generateAbsoluteUrl(req, redirectUrl);
                } else {
                    return generateAbsoluteUrl(req, req.getContextPath(), redirectUrl, defaultScheme);
                }
                
            } else {
                return generateAbsoluteUrl(req, "", redirectUrl);
            }
        }
    }

    public static String sign(String baseString, String key) {
        return byteToShortString(DigestUtils.sha256Hex(baseString + key).getBytes());
    }

    public static String getCookieDomain(HttpServletRequest req) {
        if (AccConfig.getPros().getBoolean(AccConfig.NAME_GLOBAL_TESTING)) {
            return AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_TESTING_FIX_DOMAIN);
        }
        if (AccConfig.getPros().getBoolean(AccConfig.NAME_GLOBAL_DOMAIN)) {
            return AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_DOMAIN_NAME);
        }
        String serverName = req.getServerName().toLowerCase();
        if (serverName.startsWith(PREFIX_DOMAIN)) {
            serverName = serverName.substring(serverName.indexOf(PREFIX_DOMAIN) + PREFIX_DOMAIN.length());
        }
        return "." + serverName;
    }

    public static boolean isWeb(HttpServletRequest req) {
        return isWeb(getReqVal(req, AccConst.PARAM_APP_NAME));
    }

    public static boolean isWeb(String appType) {
        if (AccConfig.CLIENT_TYPE_WEB.equals(AccConfig.getMappingType(appType))) {
            return true;
        }
        return false;
    }

    public static boolean isMobile(String appType) {
        if (AccConfig.CLIENT_TYPE_MOBILE.equals(AccConfig.getMappingType(appType))) {
            return true;
        }
        return false;
    }

    public static boolean isMobile(HttpServletRequest req) {
        return isMobile(getReqVal(req, AccConst.PARAM_APP_NAME));
    }

    public static Object byte2Obj(byte[] bytes) throws AccException {
        ByteArrayInputStream bis = null;
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new ByteArrayInputStream(bytes));
            return ois.readObject();

        } catch (IOException e) {
            throw new AccException("can not convert bytes to Object.", e, AccExpType.UNKNOWN_EXCEPTION);
        } catch (ClassNotFoundException e) {
            throw new AccException("can not convert byte to object, no such class?", e,
                    AccExpType.UNKNOWN_EXCEPTION);
        } finally {
            IOUtils.closeQuietly(bis);
            IOUtils.closeQuietly(ois);
        }
    }

    public static byte[] obj2bytes(Object obj) throws AccException {
        ByteArrayOutputStream bos = null;
        ObjectOutputStream oos = null;
        try {
            bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            return bos.toByteArray();

        } catch (IOException e) {
            throw new AccException("AccCookie to bytes error", e, AccExpType.UNKNOWN_EXCEPTION);
        } finally {
            IOUtils.closeQuietly(oos);
            IOUtils.closeQuietly(bos);
        }
    }

    public static Object byte2Obj(byte[] bytes, Class<?> clazz) throws AccException {
        Object obj = byte2Obj(bytes);
        if (clazz.isInstance(obj)) {
            return obj;
        }
        throw new AccException("bytes is not" + clazz, AccExpType.BYTES_NO_MATCH_OBJ_EXCEPTION);
    }

    /**
     * get param from req, no matter value in req params or req attributes.
     * 
     * @param req
     * @param key
     * @return
     */
    public static String getReqVal(HttpServletRequest req, String key) {
        String value = (String) req.getAttribute(key);
        if (StringUtils.isBlank(value)) {
            return req.getParameter(key);
        }
        return value;
    }
    
    public static boolean getBooleanAttr(HttpServletRequest req, String key , boolean defaultVal) {
        Object obj = req.getAttribute(key);
        if (obj == null) {
            return defaultVal;
        }
        if (obj instanceof Boolean) {
            return (Boolean)obj;
        }
        return defaultVal;
    }

    /**
     * get param from req, no matter value in req params or req attributes.
     * 
     * @param req
     * @param key
     * @return
     */
    public static String getReqVal(HttpServletRequest req, String key, String defaultVal) {
        String value = (String) req.getAttribute(key);
        if (StringUtils.isBlank(value)) {
            if (StringUtils.isBlank((value = req.getParameter(key)))) {
                return defaultVal;
            }
        }
        return value;
    }

    /**
     * get param from req, value is in req params.
     * 
     * @param req
     * @param key
     * @return
     */
    public static String getReqParamVal(HttpServletRequest req, String key, String defaultVal) {
        String value = req.getParameter(key);
        if (StringUtils.isBlank(value)) {
            return defaultVal;
        }
        return value;
    }

    /**
     * get param from req, no matter value in req params or req attributes.
     * 
     * @param req
     * @param key
     * @return
     */
    public static int getReqInt(HttpServletRequest req, String key, int defaultVal) {
        Object value = getReqObjAttr(req, key, defaultVal);
        if (value instanceof Integer) {
            return (Integer) value;
        }
        try {
            return Integer.parseInt((String) value);
        } catch (Exception e) {
            return defaultVal;
        }
    }
    
    public static Object getReqObjAttr(HttpServletRequest req, String key, Object defaultVal) {
        Object value = req.getAttribute(key);
        if (value == null) {
            value = req.getParameter(key);
            if (value == null) {
                return defaultVal;
            }
        }
        return value;
    }

    /**
     * get param from req, no matter value in req params or req attributes.
     * 
     * @param req
     * @param key
     * @return
     */
    public static boolean getReqBoolean(HttpServletRequest req, String key, boolean bool) {
        Object value = getReqObjAttr(req, key, bool);
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        try {
            return Boolean.parseBoolean((String) value);
        } catch (Exception e) {
            return bool;
        }
    }

    /**
     * get param from req, no matter value in req params or req attributes.
     * 
     * @param req
     * @param key
     * @return
     */
    public static long getReqLong(HttpServletRequest req, String key, long defaultVal) {
        Object value = getReqObjAttr(req, key, defaultVal);
        if (value instanceof Long) {
            return (Long) value;
        }
        try {
            return Long.parseLong((String) value);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    public static boolean isExpired(long createTime, long expiredTime) {
        if (expiredTime == -1) {
            // never expired
            return false;
        }
        if (System.currentTimeMillis() - createTime < expiredTime) {
            return false;
        }
        return true;
    }

    public static byte[] aesURSEncrypt(byte[] content, byte[] secret) throws AccException {
        return CipherUtils.aesEncrypt(null, content, secret).encryptResult;
    }

    public static byte[] aesURSDecrypt(byte[] content, byte[] secret) throws AccException {
        return CipherUtils.aesDecrypt(null, content, secret, null);
    }

    /**
     * not special key, the method will use MD5 to hash key.
     * 
     * @param content
     * @param anyKey
     * @return
     * @throws AccException
     */
    public static String aesEncryptAnyKey(String content, String anyKey) throws AccException {
        try {
            byte[] encrypt = aesURSEncrypt(content.getBytes(AccConst.UTF8), DigestUtils.md5(anyKey));
            return Hex.encodeHexString(encrypt);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("content can not convert to UTF-8:" + content, AccExpType.ENCODING_ERROR);
        }
    }

    public static String aesEncryptString(String content, String hexSecret) throws AccException {
        try {
            byte[] encrypt = aesURSEncrypt(content.getBytes(AccConst.UTF8),
                    strHex(hexSecret));
            return Hex.encodeHexString(encrypt);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("content can not convert to UTF-8:" + content, AccExpType.ENCODING_ERROR);
        } 
    }

    public static String aesDecryptAnyKey(String content, String anyKey) throws AccException {
        try {
            byte[] bytes = strHex(content);
            byte[] encrypt = aesURSDecrypt(bytes, DigestUtils.md5(anyKey));
            return new String(encrypt, AccConst.UTF8);
        }catch (UnsupportedEncodingException e) {
            throw new AccException("content can not convert to UTF-8:" + content, AccExpType.ENCODING_ERROR);
        }
    }

    public static String aesDecryptString(String content, String hexSecret) throws AccException {
        try {
            byte[] bytes = strHex(content);
            byte[] encrypt = aesURSDecrypt(bytes, strHex(hexSecret));
            return new String(encrypt, AccConst.UTF8);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("content can not convert to UTF-8:" + content, AccExpType.ENCODING_ERROR);
        }
    }

    public static byte[] strHex(String content) throws AccException {
        if (content == null) {
            return null;
        }
        try {
            return Hex.decodeHex(content.toCharArray());
        } catch (DecoderException e) {
            throw new AccException(AccExpType.LOGIC_ERROR, e, "can not hex string. content: %s", content); 
        }
    }

    /**
     * get a singleton class object
     * 
     * @param clazz
     * @return
     * @throws AccException
     */
    public static Object getInstance(Class<?> clazz) {
        Method getInstance;
        try {
            getInstance = clazz.getDeclaredMethod("getInstance");
            return getInstance.invoke(null);
        } catch (SecurityException e) {
            throw new AccRunTimeException(new AccException("getInstance method of " + clazz
                    + "  can not be accessed", e, AccExpType.NOT_SUPPORT));
        } catch (NoSuchMethodException e) {
            throw new AccRunTimeException(new AccException("getInstance() method of " + clazz
                    + "  is not implement", e, AccExpType.NOT_IMPLEMENT_METHOD));
        } catch (IllegalArgumentException e) {
            throw new AccRunTimeException(new AccException("getInstance method of " + clazz
                    + "  is invoked with missing args", e, AccExpType.PARAM_MISSING_ERROR));
        } catch (IllegalAccessException e) {
            throw new AccRunTimeException(new AccException("getInstance method of " + clazz
                    + "  can not be accessed", e, AccExpType.NOT_SUPPORT));
        } catch (InvocationTargetException e) {
            throw new AccRunTimeException(new AccException("getInstance method of " + clazz
                    + "  is invoked error", e.getCause(), AccExpType.NOT_SUPPORT));
        }
    }

    public static void setAttributeIfNull(HttpServletRequest req, String key, Object value) {
        if (req.getAttribute(key) == null) {
            req.setAttribute(key, value);
        }
    }

    public static boolean isDebug(HttpServletRequest req) {
        return !StringUtils.isBlank(req.getParameter(AccConst.PARAM_DEBUG_NAME));
    }

    public static String getParamOrHeader(HttpServletRequest req, String key) {
        String value = req.getParameter(key);
        if (StringUtils.isBlank(value)) {
            return req.getHeader(key);
        }
        return value;
    }
    
    public static String getParamOrHeaderOrAttr(HttpServletRequest req, String key) {
        String value = (String)req.getAttribute(key);
        if (StringUtils.isBlank(value)) {
            return getParamOrHeader(req, key);
        }
        return value;
    }

    /**
     * @param parent
     *            should be a valid path
     * @param child
     * @return
     */
    public static String joinPath(String parent, String child) {
        String p = parent.replace('\\', '/');
        String c = child.replace('\\', '/');

        if (StringUtils.isBlank(p)) {
            return c;
        }

        if (StringUtils.isBlank(c)) {
            return p;
        }

        if (!c.startsWith(SEPARATOR)) {
            return p + (p.endsWith(SEPARATOR) ? "" : SEPARATOR) + c;
        } else {
            return p + (p.endsWith(SEPARATOR) ? c.substring(1) : c);
        }
    }

    public static Parameter genParamFormReq(HttpServletRequest req, String key) {
        return new Parameter(key, req.getParameter(key));
    }

    public static Parameter genParamFormMap(Map<String, String> map, String key) {
        return new Parameter(key, map.get(key));
    }

    public static String getStringResponse(HttpResponse resp) throws AccException {
        try {
            return EntityUtils.toString(resp.getEntity(), AccConst.UTF8);
        } catch (Exception e) {
            throw new AccException("can not convert response to string", e, AccExpType.UNKNOWN_EXCEPTION);
        }
    }

    /**
     * <pre>
     * If a request is Https, 
     * it use https:// 
     * OR
     * the request has X-PROTOCAL header, all values <b>MUST</b> be "https".
     * Fake https request may add head X-PROTOCAL : https, But our nginx will and X-PROTOCAL : http. 
     * </pre> 
     * @param req
     * @throws AccException
     */
    public static void checkHttpsProtocal(HttpServletRequest req) throws AccException {
        if (!isHttpsProtocal(req)) {
            throw new AccException("not https", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
        }
    }
    
    public static boolean isHttpsProtocal(HttpServletRequest req) throws AccException {
        boolean isHttps = true;
        if (!req.getRequestURL().toString().startsWith("https://")) {
            
            Enumeration<String> iter = req.getHeaders("X-PROTOCOL");
            while(iter.hasMoreElements()) {
                isHttps = isHttps && AccConst.HTTPS_PROTOCAL.equals(iter.nextElement());
            }
        }
        return isHttps;
    }

    public static String aesEncrypt(String hexKey, Parameter... params) throws AccException {
        String src = CipherUtils.paramsCompose(params);
        return AuthUtils.aesEncryptString(src, hexKey);
    }

    public static int milliApproxSecond(long millis) {
        return (int) (millis >> 10);
    }

    public static KeyPair genRSAKeys(byte[] secret) throws AccException {
        return CipherUtils.genRSAKey(null, secret);
    }
    
    /**
     * cache[token] is key-pair
     * <p> 1. get a token first.
     * <p>  
     * 2.1 If not exist, generate a new key-pair and put into cache[token];
     * 2.2 If cache[token] is exist.
     * <p> 2.3 will has 1/REMOVE_PROBABILITY probability remove the cache[token]
     * <p>
     * 3 return key-pair
     * 
     * @param secret
     * @return
     * @throws AccException
     */
    public static KeyPair genRSAKeysCache(byte[] secret) throws AccException {
        int token = rand.get().nextInt(RSA_CACHE_SIZE);
        KeyPair keypair = KEYS_CACHE.get(token);
        if(keypair == null) {
            keypair = genRSAKeys(secret);
            synchronized (KEYS_CACHE) {
                KEYS_CACHE.put(token, keypair);
            }
        } else {
            // keypair exist
            int otherToken = rand.get().nextInt(REMOVE_PROBABILITY);
            if (otherToken == 0) {
                // remove it
                synchronized (KEYS_CACHE) {
                    KEYS_CACHE.remove(token);
                }
            }
        }
        return keypair;
    }
    
    public static String rsaDecryptHex(String encryptContentHex, String priKeyHex) throws AccException {
        try {
            return new String(rsaDecrypt(strHex(encryptContentHex), strHex(priKeyHex)),
                    AccConst.UTF8).trim();
        } catch (Exception e) {
            throw new AccException("Result can not convert to UTF-8. encryptContent:"
                    + encryptContentHex, e, AccExpType.ENCODING_ERROR);
        }
    }

    public static byte[] rsaDecrypt(byte[] encryptContent, byte[] priKeyBytes) throws AccException {
        return CipherUtils.rsaDecrypt(null, encryptContent, priKeyBytes);
    }

    public static String rsaEncryptHex(String rawContent, String pubKeyHex) throws AccException {
        try {
            return Hex.encodeHexString(rsaEncrypt(rawContent.getBytes(AccConst.UTF8), strHex(pubKeyHex)));
        } catch (Exception e) {
           throw new AccException();
        }
    }

    public static byte[] rsaEncrypt(byte[] rawContent, byte[] pubKey) throws AccException {
        return CipherUtils.rsaEncrypt(null, rawContent, pubKey);
    }
    
    public static String rsaEncryptHex(String hexKey, Parameter... params) throws AccException {
        String src = CipherUtils.paramsCompose(params);
        return AuthUtils.rsaEncryptHex(src, hexKey);
    }

    /**
     * add /acc befor partUrl
     * @param partUrl
     * @return
     */
    public static String makeUrl(String partUrl) {
        return AccConst.URL_AUTH_PREFIX + partUrl;
    }
    
    public static void disposeException(AccException e, AccExpType ... expected) throws AccException {
        if (expected != null) {
            for (AccExpType i : expected) {
                if (e.getExceptionType() == i) {
                    return;
                }
            }
        }
        throw e;
    }
    
    public static void closeQuiet(Closeable close) {
        try {
            if (close != null) {
                close.close();
            }
        } catch(Throwable t) {
            // quiet
        }
    }
    
    public static HashMap<String, String> parseQuery(String queryString) {
        if (queryString == null) {
            return new HashMap<String, String>(1);
        }
        String[] querys = queryString.split("&");
        HashMap<String, String> querytable = new HashMap<String, String>(12);
        for(String query : querys) {
            String [] kv = query.split("=");
            if (kv.length == 2) {
                querytable.put(kv[0], kv[1]);
            } else if (kv.length == 1) {
                querytable.put(kv[0], "");
            }
        }
        return querytable;
    }
    
    public static boolean isSubDomain(String maybeSubDomain, String mainDomain) {
        if(StringUtils.isBlank(maybeSubDomain) || StringUtils.isBlank(mainDomain)) {
            return false;
        }
        if (maybeSubDomain.equals(mainDomain)) {
            return true;
        }
        return maybeSubDomain.endsWith("."+mainDomain);
    }
    
    public static boolean isV2Token(String value){
        return value != null && value.startsWith(AccConst.V2_FLAG);
    }
    
    public static void cleanOldCookies(HttpServletRequest req, HttpServletResponse resp,  String product) {
        // clean OLD cookies
        resp.addCookie(deleteCookie(product + AccConst.COOKIE_SESSION_BIND, getCookieDomain(req), true));
        resp.addCookie(deleteCookie(product + AccConst.COOKIE_SESSION_BIND + AccConst.COOKIE_LOGIN, getCookieDomain(req), false));
        // add login force cookies
        resp.addCookie(genCookie(product + AccConst.COOKIE_FORCE_LOGIN, "true", getCookieDomain(req), AccConst.URL_ROOT, -1, true));
    }
    private static final BrowserCompatSpec COOKIE_SPEC = new BrowserCompatSpec();
    
    public static Map<String, org.apache.http.cookie.Cookie> extractCookieHeader(HttpResponse resp) throws AccException {
        Header[] headers = resp.getHeaders("Set-Cookie");
        CookieOrigin origin = new CookieOrigin("localhost", 80, "/", false);

        Map<String, org.apache.http.cookie.Cookie> cookies = new HashMap<String, org.apache.http.cookie.Cookie>();
        
        for (Header h: headers) {
            try {
                
                for(org.apache.http.cookie.Cookie cookie : COOKIE_SPEC.parse(h, origin)) {
                    final String name = cookie.getName();
                    cookies.put(name,cookie);
                }
            } catch (MalformedCookieException e) {
                throw new AccException(AccExpType.COOKIE_HEADER_ERROR);
            }
        }
        
        return cookies;
    }
    private static final String NULL="NULL";
    public static String showBytes(byte[] byteArray) {
        if (byteArray == null) {
            return NULL;
        } else {
            return Hex.encodeHexString(byteArray);
        }
    }
    
    public static Map<String, String> genInfoMap(String info) throws AccException {
        if (StringUtils.isBlank(info)) {
            throw new AccException("no information", AccExpType.URS_TOKEN_INIT_EXCPTION);
        }
        String[] kvs = info.split("&");
        Map<String, String> infoMap = new HashMap<String, String>();
        for (String kv: kvs) {
            String[] keyAndValue = kv.split("=");
            if (keyAndValue.length != 2) {
                throw new AccException("key and value missed : " + kv, AccExpType.URS_TOKEN_INIT_EXCPTION);
            }
            infoMap.put(keyAndValue[0], keyAndValue[1]);
        }
        return infoMap;
    }
    
    public static String getParameter(String encoded, String key)
            throws AccException {
        if (StringUtils.isBlank(encoded)) {
            return null;
        }
        int start = encoded.indexOf(key+"=");
        if (start == -1) {
            return null;
        }
        start += key.length() + 1;
        int end = encoded.indexOf("&", start);
        String value = (end == -1) ? encoded.substring(start) : encoded
                .substring(start, end); 

        try {
            return URLDecoder.decode(value, AccConst.UTF8);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("url decoding error.", AccExpType.ENCODING_ERROR);
        }
    }
    
    public static void cleanCookies(HttpServletRequest req, HttpServletResponse resp, String product) {
        AccCookies cookie = new AccCookies(product, req, AccConfig.CLIENT_TYPE_WEB);
        cookie.cleanAllCookiesInResponse(resp);
        UrsUtils.cleanURSCookies(resp);
        
        // TODO: if web login changed, remove the code.
        AuthUtils.cleanOldCookies(req, resp, product);
    }
    
    /**
     * URL： http://reg.163.com/services/fastRegPassport?
     * username=&password=&product
     * =&userip=&mobile=&retflag=&pid=&operatetime=&xforwardedfor=&antiauto=
     * 
     * @param req
     * @return
     */
    public static String registerURS(String userMail, String pass, String ursProduct, String userIp)
            throws AccException {
        return AccHttpClient.getInstance().getString(outfox.account.utils.client.AccHttpClient.Method.GET,
                AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_URS_REGISTER_URL), null,
                AuthUtils.createRegisterParam(userMail, pass, ursProduct, userIp), null);
    }
    
    private static List<Parameter> createRegisterParam(String username, String password,String ursProduct, String userIp) {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("username", username));
        params.add(new Parameter("password", password));
        params.add(new Parameter("product", ursProduct));
        params.add(new Parameter("userip", userIp));
        return params;
    }
    
    /**
     * only for old service compatible
     * @param req
     * @return
     */
    public static String getProductForCompatible(HttpServletRequest req) {
        String product = AuthUtils.getReqParamVal(req, AccConst.PARAM_PRODUCT_NAME,
                AccConst.PARAM_PRODUCT_DEFALUT_VALUE).toUpperCase();
        if (AccConfig.getPros().getString(AccConfig.NAME_REGISTER_PRODUCT_NAME).equals(product.toLowerCase())) {
            product = AccConst.PARAM_PRODUCT_DEFALUT_VALUE;
        }
        return product;
    }
    
    /**
     * This method will ensure getting all content of a file
     * @param filepath
     * @return
     * @throws IOException
     */
    public static String readFileContent(String filepath) throws AccException {
        
        byte[] arr = readFile(filepath);
        try {
            return new String(arr, "utf-8");
        } catch (UnsupportedEncodingException e) {
            throw new AccException("encoding error in readFileContent.", e, AccExpType.ENCODING_ERROR);
        }
    }

    public static byte[] readFile(String filepath) throws AccException {
        FileInputStream fis = null;
        try {
            File file = new File(filepath);
            byte[] arr = new byte[(int)file.length()];
            fis = new FileInputStream(filepath);

            int n = 0, i = 0, len = arr.length;
            while((n = fis.read(arr, i, len))!= -1){
                len -= n;
                if (len <= 0){
                    break;
                }
                i = n;
            }
            return arr;
        } catch(IOException e) {
            throw new AccException(e,AccExpType.IO_ERROR);
        } finally {
            IOUtils.closeQuietly(fis);
        }
        
    }
    
    public static CipherKeyPair genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE cipher) throws AccException {
        CipherKeyPair cipherkeyPair = null;
        String encryptKey = null;
        String decryptKey = null;
        switch(cipher.getAlgorithm()) {
            case RSA:
                KeyPair kp = AuthUtils.genRSAKeysCache(null);
                // send public key to client, store private key
                cipherkeyPair = new CipherKeyPair(kp);
                break;
            case AES:
                decryptKey = DigestUtils.md5Hex(AuthUtils.genUniqueToken());
                encryptKey = decryptKey;
                cipherkeyPair = new CipherKeyPair(encryptKey, decryptKey);
                break;
            default:
                throw new AccException(AccExpType.PARAM_NOT_EQUAL_TAGET_ERROR, "%s parameter error.", AccConst.PARAM_ALOGRITHM);
        }
        return cipherkeyPair;
    }
}
