/**
 * @(#)LoginDoneHandler.java, 2011-12-16. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
@Controller
public class LoginDoneHandler extends BaseHandler{
    private static final long serialVersionUID = -7384152937479931000L;

    private static final Log LOG = LogFactory.getLog(LoginDoneHandler.class);

    @RequestMapping(AccConst.LOGIN_DONE_URL)
    protected void loginDone(HttpServletRequest req,
            HttpServletResponse resp) throws AccException  {
        setName(req, "login_done");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkParam(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        
        String product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        AccConfig.checkProduct(product);
        boolean isSuccess = AuthUtils.getReqBoolean(req, AccConst.PARAM_SUCCESS, false);
        String tp = req.getParameter(AccConst.PARAM_THIRD_PARTY_NAME);
        LOG.info(String.format("login done. success=%s, product %s, tp %s.",isSuccess, product, tp));
        String redirectUrl = isSuccess ? AccConfig.getLoginSuccessUrl(product, tp) : AccConfig.getErrorUrl(product, tp) ;
        safeRedirect(req, resp, redirectUrl);
    }
    
}
