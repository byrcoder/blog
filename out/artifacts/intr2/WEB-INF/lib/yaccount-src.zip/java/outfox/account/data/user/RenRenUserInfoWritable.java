/**
 * @(#)RenRenUserInfoWritable.java, 2012-11-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

import java.util.StringTokenizer;

import net.sf.json.JSONObject;

/**
 * @author chen-chao
 */
public class RenRenUserInfoWritable extends UserInfoWritable{
    private static final long serialVersionUID = -8047284176479907128L;
    public RenRenUserInfoWritable() {
        super();
    }
    public static final String RENREN = "renren";
    public static final String NAME = "name";
    public static final String HEAD_URL = "headurl";
    public static final String SEX = "sex";
    public static final String BIRTH_DAY = "birthday";
    public static final String ZIDOU = "zidou";
    public static final String NO_VIP = "0";
    public static final String MAY_BE_VIP = "1";
    public static final String BIRTH_DAY_SPLIT = "-";
    public static final String STAR = "star";
    public static final String TRUE = "1";
    public RenRenUserInfoWritable(String userId, String originId, JSONObject obj) {
        this.userId = userId;
        this.originalId = originId;
        this.from = RENREN;
        this.userName = obj.getString(NAME);
        this.imageUrl = obj.getString(HEAD_URL);
        setGenderVal(obj.getInt(SEX));
        if (MAY_BE_VIP.equals(obj.getString(ZIDOU))) {
            setIsVIP(TRUE.equals(obj.getString(VIP)));
        } else {
            setIsVIP(false);
        }
        
        // format like: 1961-09-27
        String birthday = obj.getString(BIRTH_DAY);
        StringTokenizer token = new StringTokenizer(birthday, BIRTH_DAY_SPLIT);
        setBirthYEAR(token.nextToken());
        setBirthMonth(token.nextToken());
        setBirthDay(token.nextToken());
        
        setIsRealName(TRUE.equals(obj.getString(STAR)));
        setIsRealPic(TRUE.equals(obj.getString(STAR)));
        
    }

    public void setGender(GENDER_VALUE gender) {
        setProperty(GENDER, gender.name());
    }
    
    private void setGenderVal(int val) {
        if (val == 0) {
            setGender(GENDER_VALUE.WOMEN);
        } else {
            setGender(GENDER_VALUE.MAN);
        }
    }
    
    public boolean getIsVIP() {
        return getBooleanProperty(VIP);
    }
    public void setIsVIP(boolean isVip) {
        setBooleanProperty(VIP, isVip);
    }
    
    public String getIsRealName() {
        return getProperty(IS_REAL_NAME);
    }
    public void setIsRealName(boolean real) {
        this.setBooleanProperty(IS_REAL_NAME, real);
    }
    public void setIsRealPic(boolean isReal) {
        this.setBooleanProperty(IS_REAL_PIC, isReal);
    }
    
    public boolean getIsRealPic() {
        return getBooleanProperty(IS_REAL_PIC);
    }
}
