/**
 * @(#)MemoryCacheService.java, 2012-7-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.protocol.impl;

import odis.rpc2.RpcException;
import outfox.account.cache.LocalWriteCache;
import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.rpc.protocol.ICacheService;

/**
 *
 * @author wangfk
 *
 */
public class MemoryCacheService implements ICacheService {
    private static final int CACHE_SIZE = AccConfig.getPros().getInt(
            AccConfig.NAME_RPC_CACHE_SERVER_ITEM_COUNT_LIMITS);
    private static final int ITEM_MAX_SIZE = AccConfig.getPros().getInt(
            AccConfig.NAME_RPC_CACHE_SERVER_ITEM_SIZE_LIMITS);

    private static final float LOAD_FACTOR = AccConfig.getPros().getFloat(
            AccConfig.NAME_RPC_CACHE_SERVER_LOAD_FACTOR);
    private LocalWriteCache<String, byte[]> cache = null;
    private static class Holder {
        private static final MemoryCacheService instance = new MemoryCacheService();
    }
    
    private MemoryCacheService() {
        cache = new LocalWriteCache<String, byte[]>(true, (int)(CACHE_SIZE/(LOAD_FACTOR-0.1)), LOAD_FACTOR, CACHE_SIZE);
    }
    public static MemoryCacheService getInstance() {
        return Holder.instance;
    }

    @Override
    public byte[] getBytesValue(String key) throws AccException {
        return cache.get(key);
    }

    @Override
    public void putBytesValue(String key, byte[] value) throws AccException {
        checkItemSize(value);
        synchronized (this) {
            cache.put(key, value);
        }
    }

    @Override
    public byte[] removeBytesValue(String key) throws AccException,
            RpcException {
        synchronized (this) {
            return cache.remove(key);
        }
    }
    
    private void checkItemSize(byte[] value) throws AccException {
        if (value.length > ITEM_MAX_SIZE) {
            throw new AccException("The item size is over max size limit: "
                    + ITEM_MAX_SIZE + "(byte)",
                    AccExpType.CACHE_ITEM_SIZE_EXCEED);
        }
    }
}
