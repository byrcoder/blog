/**
 * @(#)ErrorLogPrint.java, 2012-12-4. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.log;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author chen-chao
 */
public class ErrorLogger {
    private static final Log LOG = LogFactory.getLog(ErrorLogger.class);
    public static void print(String log, Exception e) {
        LOG.error(log, e);
    }
}
