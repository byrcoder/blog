/**
 * @(#)IVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.AccCookies;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TokenData;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;


/**
 * @author chen-chao
 */
public abstract class Verifier implements IVerifier{
    protected static final Log LOG = LogFactory.getLog(Verifier.class);
    protected static DataStore store = null;
    protected boolean checkExpireTime = false;
    public static final String REPLACE_TOKEN = "{id}";
    public static final long DEFAULT_SESS_ALIVE_TIME = AccConfig.getPros().getLong(AccConfig.NAME_COOKIE_SESS_MAX_AGE);
    protected String idPattern = REPLACE_TOKEN;
    protected String idPrefix = null;
    protected String product;
    protected Hashtable<String, String> properties;
    protected long sessAliveTime;
    public String getProduct() {
        return product;
    }
    
    public Verifier(Properties props) {
        properties = new Hashtable<String, String>();
        product = props.getProperty(AccConst.NAME_PRODUCT);
        sessAliveTime = getLongPros(props, getVerifierName()+VerifierConfConst.SESS_ALIVE_TIME, DEFAULT_SESS_ALIVE_TIME);
        store = DataStore.getInstance();
        getIdPrefix();
    }

    protected void getIdPrefix() {
        int startIndex = idPattern.indexOf(REPLACE_TOKEN);
        idPrefix = idPattern.substring(0, startIndex);
    }
    
    public String ownId2tp(String ownId) throws AccException {
        if (!AuthUtils.isValidEmailAddress(ownId)) {
            if (ownId.startsWith(idPrefix)){
                return getVerifierName();
            }
        }
        return null;
    }
    
    public TpToken decode(String token) throws AccException {
        TpToken tpToken = new TpToken(token);
        return decode(tpToken);
    }
    public TpToken decode(TpToken tpToken) throws AccException {
        String token = tpToken.parseToken;
        if (StringUtils.isBlank(token)) {
            throw new AccException("no token, can not parsed.", AccExpType.NO_LOGIN);
        }
        TwoPart two = new TwoPart(token);
        
        // check verifier name
        String verifierName = two.first;
        if (!getVerifierName().equals(verifierName)) {
            throw new AccException("verifier name:" + getVerifierName() + "  token tp:" +verifierName,AccExpType.VERIFIER_MISS_MATCH_TOKEN);
        }
        tpToken.verifierName = verifierName;
        two.next();
        // check product
        String product = two.first;
        if (!AccConfig.getProductSet().contains(product)){
            throw new AccException("token product :" + product, AccExpType.FAKE_TOKEN);
        }
        tpToken.product = product;
        
        // check app
        two.next();
        String app = two.first;
        if (AccConfig.getMappingType(app) == null) {
            throw new AccException("token app:" + app,AccExpType.FAKE_TOKEN);
        }
        tpToken.app = app;
        // check expire time
        two.next();
        long expireTime = Long.parseLong(two.first);
        
        if (checkExpireTime && System.currentTimeMillis() > expireTime) {
            // expire
            throw new AccException("token expired in " + expireTime + " current:" + System.currentTimeMillis(), AccExpType.FAKE_TOKEN);
        }
        tpToken.setExpiredTime(expireTime);
        
        two.next();
        tpToken.setCreateTime(Long.parseLong(two.first));
        two.next();
        tpToken.ip = two.first;
        two.next();
        tpToken.userId = two.first;
        tpToken.parseToken = two.second;
        return tpToken;
    }
    
    @Override
    public String encode(TpToken tpToken) throws AccException {
        StringBuilder sb = new StringBuilder();
        sb.append(tpToken.verifierName).append(TokenUtils.SPLIT_CHARS)
          .append(tpToken.product).append(TokenUtils.SPLIT_CHARS)
          .append(tpToken.app).append(TokenUtils.SPLIT_CHARS)
          .append(tpToken.getExpiredTime()).append(TokenUtils.SPLIT_CHARS)
          .append(tpToken.getCreateTime()).append(TokenUtils.SPLIT_CHARS)
          .append(tpToken.ip).append(TokenUtils.SPLIT_CHARS)
          .append(tpToken.userId).append(TokenUtils.SPLIT_CHARS);
          
        return sb.toString();
    }

    @Override
    public String tpId2ownId(String id) throws AccException {
        return idPattern.replace(REPLACE_TOKEN, id);
    }

    public static class TwoPart {
        public String first;
        public String second;
        protected int index;
        protected String splitChars;
        public TwoPart(String token, String splitChars) {
            this.splitChars = splitChars;
            next(token, splitChars);
        }
        
        public String next() {
            next(second, splitChars);
            return first;
        }

        private void next(String token, String splitChar) {
            index = token.indexOf(splitChar);
            if (index == -1) {
                throw new AccRunTimeException("token parse error:" + token);
            }
            first = token.substring(0, index);
            second = token.substring(index + splitChar.length());
        }
        
        public TwoPart(String token) {
            this(token, TokenUtils.SPLIT_CHARS);
        }
    }
    
    

    /**
     * check in memory , signature, and DB
     * subclass should check token's in ThirdParty
     */
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        TokenData tokens = TokenData.extractTokenDataFromReq(req, product);
        return verifyAuthToken(req, resp, tokens.token, tokens.expireTime);
    }
    
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expiredTime)
            throws AccException {
        String[] result = TokenUtils.checkToken(token);
        TpToken tpToken = decode(token);
        tpToken.signature = result[0];
        if (tpToken.isExpired()) {
            // TODO remove session cookies in other threads
            throw new AccException("token is expired.", AccExpType.FAKE_TOKEN);
        }
        // check in database
        PersistTokenWritable tokenWritable = store.getAliveToken(tpToken, expiredTime);
        if (tokenWritable == null) {
            throw new AccException("token is not exist or expired.", AccExpType.FAKE_TOKEN);
        }
        HashMap<String, Object> hashMap = new HashMap<String, Object>(); 
        hashMap.put(AccConst.THIRD_PARTY_PERS_TOKEN, tokenWritable);
        return hashMap;
    }
    
    
    @Override
    public Map<String, Object> verifyAuthToken(Map<String, Object> information, String token, long expiredTime)
            throws AccException {
        return this.verifyAuthToken(null, null, token, expiredTime);
    }

    @Override
    public void remove(TpToken tpToken) throws AccException {
        // do nothing
    }

    public Object getProperty(String key) {
        return properties.get(key);
    }
    public void setProperty(String key , String value) {
        properties.put(key, value);
    }
    public Set<Entry<String, String>> getProperties() {
        return properties.entrySet();
    }

    /**
     * return value of key
     * @param prop
     * @param key
     * @return
     */
    public static String getAndCheck(Properties props, String key) {
        String value = props.getProperty(key);
        if (value == null) {
            throw new AccRunTimeException(new AccException("Not exist the key:" + key, AccExpType.NOT_SUPPORT));
        }
        return value;
    }
    
    public static long getLongPros(Properties props, String key, long value) {
        try {
            return Long.parseLong(props.getProperty(key));
        } catch(Exception e) {
            return value;
        }
    }
    
    public UserInfoWritable genStressUser(){
        UserInfoWritable info = new UserInfoWritable();
        final String uniqueStr = AuthUtils.genUniqueToken();
        info.email = "fakestress"+uniqueStr+"@stress.com";
        info.userId = "fakestress"+uniqueStr;
        info.from = "fakestress";
        info.originalId = uniqueStr;
        return info;
    }
    
    
    private static final long expireTime = AccConfig.getPros().getLong(AccConfig.NAME_FAKE_EXPIRE_TIME);
    public Map<String, Object> genStressAuthInfo() {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(OAuthConstant.ACCESS_TOKEN, AuthUtils.genUniqueToken());
        result.put(OAuthConstant.REMAIN, expireTime);
        result.put(OAuthConstant.EXPIRED, expireTime);
        return result;
    }
    
    public void stressRedirect(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        try {
            String stat = (String)req.getSession().getAttribute(OAuthConstant.CALLBACK_STATE_CODE);
            resp.sendRedirect(String.format("%s?state=%s", AuthUtils.generateAbsoluteUrl(req, AuthUtils.makeUrl(AccConst.CALLBACK_URL)), stat));
        } catch (IOException e) {
            throw new AccException("stress call back error", e, AccExpType.REDIRECT_URL_ERROR);
        }
    }
    
    protected void initProps(Properties props) {
        String name = getVerifierName();
        for (Entry<Object, Object> prop: props.entrySet()) {
            String propName = (String) prop.getKey();
            if (propName.startsWith(name + ".consumer.")) {
                String c = propName.substring(name.length() + 10);
                properties.put(c, (String) prop.getValue());
            }
        }
    }

    @Override
    public Map<String,Object> stress(HttpServletRequest req, HttpServletResponse resp) throws AccException{
        Map<String, Object> ret = genStressAuthInfo();
        UserInfoWritable userInfo = genStressUser();
        TpToken tp = new TpToken();
        tp.userId = userInfo.userId;
        tp.setExpiredTime(expireTime);
        tp.token = (String) ret.get(OAuthConstant.ACCESS_TOKEN);
        tp.ip = AuthUtils.getRequestIP(req);
        tp.product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        tp.app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
        tp.verifierName = getVerifierName();
        TokenUtils.genCompleteTpToken(this, tp);
        store.writeUserInfo(userInfo);
        userInfo.putInfoMap(ret);
        AccCookies cookies = TokenUtils.tpTokenGenCookie(req, resp, ret, tp);
        // write persist cookie into resultInfo 
        ret.put(cookies.getProduct() + AccConst.ATTR_PART_PC, cookies.getPerTokenV2());
        return ret;
    }
    
    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        throw new AccException(AccExpType.NOT_SUPPORT);
    }
    
    @Override
    public long getSessAliveTime() {
        return sessAliveTime;
    }
    
    public Map<String,Object> shouldPutUserInfoInReturnInfo(Map<String,Object> ret, int cookieParam,UserInfoWritable userInfo) {
        if (COOKIE_FORMAT.info.isContain(cookieParam)) {
            userInfo.putInfoMap(ret);
        }
        return ret;
    }
    
    public Map<String,Object> shouldPutPersTokenInReturnInfo(Map<String,Object> ret, String product, String app, String persToken) {
        if (StringUtils.isNotBlank(persToken) && !AuthUtils.isWeb(app)) {
            ret.put(product + AccConst.ATTR_PART_PC, persToken);
        }
        return ret;
    }
    
}
