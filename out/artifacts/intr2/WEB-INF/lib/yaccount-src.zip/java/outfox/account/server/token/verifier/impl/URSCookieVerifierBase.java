/**
 * @(#)URSCookieVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.AccCookies;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TokenData;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.URSVerifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;

/**
 * @author chen-chao
 */
public abstract class URSCookieVerifierBase extends URSVerifier {
    public URSCookieVerifierBase(Properties props, String name) {
        super(props);
        this.name = name;
        sessExpireTime = getLongPros(props,name + VerifierConfConst.URS_COOKIE_SESS_EXPIRE, SESS_EXPIRE_DEFAULT);
        persExpireTime = getLongPros(props,name + VerifierConfConst.URS_COOKIE_PERS_EXPIRE, PERS_EXPIRE_DEFAULT);
    }
    protected long sessExpireTime;
    protected long persExpireTime;
    protected String name;
    public static final long SESS_EXPIRE_DEFAULT = 7 * 24 * 60 * 60 * 1000L;
    public static final long PERS_EXPIRE_DEFAULT = 30 * 24 * 60 * 60 * 1000L;
    public static final String COOKIE_VALUE = "cookieVal";
    public static final String IS_SESSION_COOKIE_VALUE = "isSessVal";
    public static final String IP = AccConst.IP_ADDRESS;
    
    public Map<String, Object> authRequest(Cookie sess, Cookie pers, HttpServletRequest req, HttpServletResponse resp) throws AccException {
        
        String userId = null;
        String cookieValue = null;
        long expireTime = sessExpireTime;
        boolean isSess = true;
        if (sess != null) {
            // check session 
            cookieValue = sess.getValue();
            userId = UrsUtils.extractInfoBySessionCookie(cookieValue, sessExpireTime)[0];
        }
        
        if (StringUtils.isBlank(userId)) {
            if (pers != null) {
                cookieValue = pers.getValue();
                userId = UrsUtils.extractInfoByPesistCookie(cookieValue, persExpireTime, req.getRemoteAddr())[0];
                expireTime = persExpireTime;
                isSess = false;
            }
        }
        if (StringUtils.isBlank(userId)) {
            throw new AccException(AccExpType.NO_LOGIN);
        }
        TpToken tp = new TpToken();
        tp.userId = userId;
        tp.setExpiredTime(expireTime);
        tp.token = cookieValue;
        tp.ip = AuthUtils.getRequestIP(req);
        tp.product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        tp.app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
        tp.verifierName = name;
        tp.setBooleanProperty(IS_SESSION_COOKIE_VALUE, isSess);
        tp.setProperty(IP, tp.ip);
        TokenUtils.genCompleteTpToken(this, tp);
        UserInfoWritable userInfo = genUserInfo(userId, name);
        
        store.writeUserInfo(userInfo);
        Map<String,Object> returnInfo = new HashMap<String,Object>();
        shouldPutUserInfoInReturnInfo(returnInfo, AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value()), userInfo);
        
        AccCookies cookies = TokenUtils.tpTokenGenCookie(req, resp, returnInfo, tp);
        // write persist cookie into resultInfo 
        shouldPutPersTokenInReturnInfo(returnInfo, cookies.getProduct(), tp.app, cookies.getPerTokenV2());
        return returnInfo;
    }

    /**
     * check in memory , signature, and DB
     * subclass should check token's in ThirdParty
     */
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        TokenData tokens = TokenData.extractTokenDataFromReq(req, product);
        return verifyAuthToken(req, resp, tokens.token, tokens.expireTime);
    }
    
    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expiredTime)
            throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expiredTime);
        // set access token
        return verifierHelper(AuthUtils.getRequestIP(req), result);
    }

    protected Map<String, Object> verifierHelper(String ip, Map<String, Object> result)
            throws AccException {
        PersistTokenWritable tokenWritable = (PersistTokenWritable)result.get(AccConst.THIRD_PARTY_PERS_TOKEN);
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        TpToken tpToken = tokenWritable.getTpToken();
        thirdPartyTokens.put(AccConst.TOKEN, tpToken.token);
        thirdPartyTokens.put(IS_SESSION_COOKIE_VALUE, tpToken.getProperty(IS_SESSION_COOKIE_VALUE));
        thirdPartyTokens.put(IP, ip);
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        userInfo.putInfoMap(result);
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        return result;
    }
    
    

    @Override
    public Map<String, Object> verifyAuthToken(Map<String, Object> information, String token, long expiredTime)
            throws AccException {
        // check in memory, DB
        Map<String, Object> result =super.verifyAuthToken(information, token, expiredTime);
        if (information == null) {
            throw new AccException("NO IP Address.", AccExpType.PARAM_MISSING_ERROR);
        }
        return verifierHelper((String)information.get(AccConst.IP_ADDRESS), result);
    }

    @Override
    public String getVerifierName() {
        return name;
    }

    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        String cookieValue = thirdPartyTokens.get(AccConst.TOKEN);
        boolean isSess = Boolean.parseBoolean(thirdPartyTokens.get(IS_SESSION_COOKIE_VALUE));
        String userId = null;
        if (isSess) {
            userId = UrsUtils.extractInfoBySessionCookie(cookieValue, sessExpireTime)[0];
        } else {
            userId = UrsUtils.extractInfoByPesistCookie(cookieValue, persExpireTime, thirdPartyTokens.get(IP))[0];
        }
        if (StringUtils.isBlank(userId)) {
            throw new AccException(AccExpType.NO_LOGIN);
        }
        return genUserInfo(userId, name);
    }

}
