/**
 * @(#)URSProxyCookieVerifier.java, 2012-11-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.MalformedCookieException;
import org.apache.http.impl.cookie.BrowserCompatSpec;

import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient;

import com.netease.urs.CookieNames;

/**
 * @author chen-chao
 */
public class URSProxyCookieVerifier extends URSCookieVerifierBase {
    public static final String NAME = VerifierConfConst.URS_PROXY_COOKIE_VERIFIER_NAME;
    public static final String NAME_TYPE = "type";
    public static final String VALUE_TYPE = "0";
    protected BrowserCompatSpec cookieSpec = new BrowserCompatSpec();
    public static final String URS_LOGIN_URL = "https://reg.163.com/logins.jsp";
    public URSProxyCookieVerifier(Properties props) {
        super(props, NAME);
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        AuthUtils.checkHttpsProtocal(req);
       
        String username = req.getParameter(AccConst.PARAM_URS_USERNAME);
        String passwordMD5 = req.getParameter(AccConst.PARAM_URS_PASSWORD);
        String host = req.getServerName();
        int port = req.getLocalPort();
        Cookie ntesSess = getNeteaseSessCookie(host, port, username, passwordMD5);
        return super.authRequest(convertToJavaxSessCookie(ntesSess), null, req, resp);
    }
    
    private javax.servlet.http.Cookie convertToJavaxSessCookie(Cookie cookie) {
        if (cookie == null) {
            return null;
        }
        javax.servlet.http.Cookie c = new javax.servlet.http.Cookie(cookie.getName(), cookie.getValue());
        c.setPath(cookie.getPath());
        c.setDomain(cookie.getDomain());
        c.setMaxAge(-1);
        return c;
    }

    protected Cookie getNeteaseSessCookie(String host, int port, String userName, String password)
            throws AccException {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put(AccConst.PARAM_URS_USERNAME, userName);
        map.put(AccConst.PARAM_URS_PASSWORD, password);
        map.put(NAME_TYPE, VALUE_TYPE);
        UrlEncodedFormEntity entity = AccHttpClient.composeUrlEncodingEntity(map, AccConst.UTF8);
        
        HttpResponse resp = AccHttpClient.getInstance().doPost(URS_LOGIN_URL, null, null, entity);
        Cookie cookie = extractNTESSessCookie(host, port, resp);
        AccHttpClient.closeQuiet(resp);
        return cookie;
    }

    private Cookie extractNTESSessCookie(String host, int port, HttpResponse resp) throws AccException {
        Header[] headers = resp.getHeaders("Set-Cookie");
        CookieOrigin origin = new CookieOrigin(host, port, "/", false);

        List<Cookie> cookies = new ArrayList<Cookie>();

        for (Header h: headers) {
            try {
                cookies.addAll(cookieSpec.parse(h, origin));
            } catch (MalformedCookieException e) {
                throw new AccException("cookie format error: " + h, AccExpType.TP_ERROR);
            }
        }

        for (Cookie cookie: cookies) {
            if (CookieNames.NTES_SESS.equals(cookie.getName())) {
                return cookie;
            }
        }
        return null;
    }
}
