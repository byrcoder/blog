/**
 * @(#)DeviceStatusWritable.java, 2013-5-30. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.device;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.data.AbstractWritable;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class DeviceToDeleteWritable extends AbstractWritable {
    private static final long serialVersionUID = 989842138981989240L;
    private static final String USER_SPLIT_CHAR = ",";
    private String product;
    private String deviceId;
    private Set<String> userIdSet = new HashSet<String>();
    public DeviceToDeleteWritable(){}
    /**
     * @param product
     * @param deviceId
     */
    public DeviceToDeleteWritable(String product, String deviceId) {
        super();
        this.product = product;
        this.deviceId = deviceId;
    }

    public Set<String> getUserIdSet() throws AccException {
        return Collections.unmodifiableSet(userIdSet);
    }
    
    public void putUserId(String userId) {
        if (StringUtils.isNotEmpty(userId)) {
            userIdSet.add(userId);
        }
    }
    
    public void removeUserId(String userId) {
        userIdSet.remove(userId);
    }
    
    public boolean isExistUsers() {
        return userIdSet.size() != 0;
    }
    
    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        product = StringWritable.readStringNull(in);
        deviceId = StringWritable.readStringNull(in);
        Collections.addAll(userIdSet, decodeUserIds(StringWritable.readStringNull(in)));
    }

    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, product);
        StringWritable.writeStringNull(out, deviceId);
        StringWritable.writeStringNull(out, encodeUserIds(userIdSet));
    }
    
    public static String encodeUserIds(Set<String> users) {
        // if given set is empty, an empty string will be returned.
        return StringUtils.join(users, USER_SPLIT_CHAR);
    }
    
    public static String[] decodeUserIds(String users) {
        // return zero-length array for empty string
        if (StringUtils.isBlank(users)) {
            return new String[0];
        }
        return users.split(",");
    }
}
