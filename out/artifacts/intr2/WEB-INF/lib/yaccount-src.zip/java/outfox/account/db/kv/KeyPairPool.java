/**
 * @(#)PoolableKeyPairFactory.java, 2011-5-18. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv;

import java.util.HashMap;

import java.util.ArrayList;
import java.util.List;

import odis.serialize.IWritableComparable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.StackObjectPool;

import outfox.omap.data.KeyPair;

/**
 * KeyPair pool holds a bunch of KeyPairs in memory so that we can borrow
 * a KeyPair form it instead of instantiating a new one.
 *
 * <p>NOTICE: borrowed KeyPair might contain the previous key values,
 * rewrite or wipe out the values according to the application.
 *
 * @author licx
 * @author chen-chao
 * @see outfox.ydrive.server.store.impl.OmapFileEntryStore
 * @see outfox.ydrive.server.store.impl.OmapFileMetaStore
 * @see outfox.ydrive.server.store.impl.OmapMailHistoryStore
 */
public class KeyPairPool {
    private static final Log LOG = LogFactory.getLog(KeyPairPool.class);

    private StackObjectPool pool =
        new StackObjectPool(new PoolableKeyPairFactory(), 10240);

    private List<Class<? extends IWritableComparable>> keyClasses;

    private static final HashMap<String, KeyPairPool> keyPairPoolCache =
        new HashMap<String, KeyPairPool>();

    public static final synchronized KeyPairPool getKeyPairPool(
            Class<? extends IWritableComparable> ... keyClasses) {
        StringBuilder keyBuilder = new StringBuilder();
        for (Class<? extends IWritableComparable> c : keyClasses) {
            keyBuilder.append(c.getName()).append(",");
        }
        String key = keyBuilder.toString();
        if (! keyPairPoolCache.containsKey(key)) {
            keyPairPoolCache.put(key, new KeyPairPool(keyClasses));
        }
        return keyPairPoolCache.get(key);
    }

    /**
     * constructor param is like "A, B, C, D", then construct the KeyPair is like
     * KeyPair<A, KeyPair<B,KeyPair<C,D>>>
     * @param keyClasses
     */
    private KeyPairPool(Class<? extends IWritableComparable> ... keyClasses) {
        assert(keyClasses != null && keyClasses.length >= 2);
        this.keyClasses = new ArrayList<Class<? extends IWritableComparable>>();
        for (Class<? extends IWritableComparable> c : keyClasses){
            this.keyClasses.add(c);
        }
    }
    
    /**
     * the function to create KeyPair Object
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    private KeyPair createNewKeyPair() throws InstantiationException, IllegalAccessException{
        KeyPair tmpKey = null;
        for (int i = keyClasses.size() - 2; i >= 0 ; i--){
            if (tmpKey == null){
                tmpKey = new KeyPair(keyClasses.get(i).newInstance(), keyClasses.get(i+1).newInstance());
            } else {
                tmpKey = new KeyPair(keyClasses.get(i).newInstance(), tmpKey);
            }
        }
        return tmpKey;
    }

    /**
     * Borrow a KeyPair from the pool. If any exception occurs, instantiate
     * a new KeyPair.
     * <p>NOTICE: borrowed KeyPair might contain the previous key values,
     * rewrite or wipe out the values according to the application.
     * @return
     */
    public KeyPair borrowKey() {
        KeyPair kp = null;
        try {
            kp = (KeyPair) pool.borrowObject();
        } catch (Throwable e) {
            LOG.warn("Borrow KeyPair from object pool fault, " +
                        "just create a new KeyPair.", e);
            try {
                kp = createNewKeyPair();
            } catch (Exception e1) {
                // should not be here
                StringBuilder sb = new StringBuilder();
                for (Class<? extends IWritableComparable> c : keyClasses){
                    sb.append(" keyType=").append(c);
                }
                LOG.warn("Fail to create KeyPair for :"+sb.toString());
            }
        }
        return kp;
    }

    /**
     * Return a borrowed KeyPair to the pool.
     * @param
     */
    public void returnKey(KeyPair kp) {
        if (kp == null) {
            return;
        }
        try {
            pool.returnObject(kp);
        } catch (Exception e) {
            LOG.warn("Return KeyPair to object pool fault.", e);
        }
    }

    /*
     * A KeyPair factory which is used in KeyPair pool.
     */
    private class PoolableKeyPairFactory implements PoolableObjectFactory {
        @Override
        public void activateObject(Object arg0) throws Exception {}

        @Override
        public void destroyObject(Object arg0) throws Exception {}

        @Override
        public Object makeObject() throws Exception {
            // make an empty key pair
            return createNewKeyPair();
        }

        @Override
        public void passivateObject(Object arg0) throws Exception {}

        @Override
        public boolean validateObject(Object arg0) {
            return true;
        }
    }
}

