/**
 * @(#)UserInfoWritable.java, 2012-8-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.data.AbstractWritable;

/**
 * @author chen-chao
 */
public class UserInfoWritable extends AbstractWritable{
    private static final long serialVersionUID = -8836958350478523414L;
    public String userId;
    public String userName;
    public String email;
    public String imageUrl;
    public String originalId;
    public String from;
    public String alias;
    /**
     * 1 is man, 2 is women, 0 is unknown
     */
    public static final String GENDER = "gender";
    public enum GENDER_VALUE {
        UNKNOWN((byte)0), MAN((byte)1), WOMEN((byte)2);
        private byte value;
        private GENDER_VALUE(byte value) {
            this.value = value;
        }
        public byte getValue() {
            return value;
        }
    }
    /**
     * false is not vip, true is vip
     */
    public static final String VIP = "vip"; 
    public static final String LEVEL = "level";
    public static final String BIRTH_YEAR = "birth_year";
    public static final String BIRTH_MONTH = "birth_month";
    public static final String BIRTH_DAY = "birth_day";
    public static final String LOCATION = "location";
    /**
     * false is not real name, true is real name
     */
    public static final String IS_REAL_NAME = "isrealname";
    /**
     * false is not real, true is real
     */
    public static final String IS_REAL_PIC = "isrealpic";
    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        //XXX: Add new field, please use setProperty method, refer to 'imageurl_big'
        userId = StringWritable.readString(in);
        userName = StringWritable.readStringNull(in);
        email = StringWritable.readStringNull(in);
        imageUrl = StringWritable.readStringNull(in);
        originalId = StringWritable.readStringNull(in);
        from = StringWritable.readStringNull(in);
        alias = StringWritable.readStringNull(in);
    }
    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        //XXX: Add new field, please use getProperty method, refer to 'imageurl_big'
        StringWritable.writeString(out, userId);
        StringWritable.writeStringNull(out, userName);
        StringWritable.writeStringNull(out, email);
        StringWritable.writeStringNull(out, imageUrl);
        StringWritable.writeStringNull(out, originalId);
        StringWritable.writeStringNull(out, from);
        StringWritable.writeStringNull(out, alias);
    }
    
    public Map<String, Object> putInfoMap(Map<String, Object> map) {
        map.put(AccConst.USER_ID, userId);
        map.put(AccConst.USER_NAME, userName);
        map.put(AccConst.USER_EMAIL, email);
        map.put(AccConst.USER_IMAGE_URL, imageUrl);
        if (StringUtils.isNotBlank(getBigImageUrl())) {
            map.put(AccConst.USER_IMAGE_URL_BIG, getBigImageUrl());
        }
        map.put(AccConst.USER_ALIAS, alias);
        map.put(AccConst.USER_FROM, from);
        return map;
    }
    
    public JSONObject putIntoJSON(JSONObject obj) {
        obj.put(AccConst.USER_ID, userId);
        obj.put(AccConst.USER_NAME, userName);
        obj.put(AccConst.USER_EMAIL, email);
        obj.put(AccConst.USER_IMAGE_URL, imageUrl);
        if (StringUtils.isNotBlank(getBigImageUrl())) {
            obj.put(AccConst.USER_IMAGE_URL_BIG, getBigImageUrl());
        }
        obj.put(AccConst.USER_ALIAS, alias);
        obj.put(AccConst.USER_FROM, from);
        return obj;
    }
    
    public JSONObject getJSON() {
        JSONObject obj = new JSONObject();
        return putIntoJSON(obj);
    }
    
    public Map<String, Object> getInfoMap() {
        HashMap<String,Object> map = new HashMap<String, Object>();
        return putInfoMap(map);
    }
    
    public void setNickName(String nickname, String defaultName) {
        if (StringUtils.isBlank(nickname)) {
            this.userName = defaultName;
        } else {
            this.userName = nickname;
        }
    }
    
    public GENDER_VALUE getGender() {
        try {
            return GENDER_VALUE.valueOf(getProperty(GENDER));
        } catch (Exception e) {
            return GENDER_VALUE.UNKNOWN;
        }
    }
    
    public void setBirthDay(String day) {
        this.setProperty(BIRTH_DAY, day);
    }
    public String getBirthDay() {
        return getProperty(BIRTH_DAY);
    }
    
    public void setBirthMonth(String month) {
        this.setProperty(BIRTH_MONTH, month);
    }
    public String getBirthMonth() {
        return getProperty(BIRTH_MONTH);
    }
    
    public void setBirthYEAR(String year) {
        this.setProperty(BIRTH_YEAR, year);
    }
    public String getBirthYEAR() {
        return getProperty(BIRTH_YEAR);
    }
    
    public void setBigImageUrl(String imageUrl_big) {
        this.setProperty(AccConst.USER_IMAGE_URL_BIG, imageUrl_big);
    }
    
    public String getBigImageUrl() {
        return getProperty(AccConst.USER_IMAGE_URL_BIG);
    }
}
