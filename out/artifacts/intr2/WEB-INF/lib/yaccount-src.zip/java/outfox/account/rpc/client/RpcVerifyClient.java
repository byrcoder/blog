/**
 * @(#)RpcVerifyClient.java, 2012-9-3. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.client;

import outfox.account.exceptions.AccException;
import outfox.account.rpc.protocol.IRpcVerifierService;
import outfox.account.rpc.protocol.impl.RpcVerifierService;

/**
 * @author chen-chao
 */
public class RpcVerifyClient extends AccRpcClient {
    public RpcVerifyClient() {
        super(IRpcVerifierService.class, RpcVerifierService.getInstance());
        LOG.info("Verifier rpc service init done.");
    }
    /**
     * key is session cookie value or persist token
     */
    public IRpcVerifierService lookup(String key) throws AccException {
        return (IRpcVerifierService)super.lookup(key);
    }
}
