/**
 * @(#)QQUserInfoWritable.java, 2012-10-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

import net.sf.json.JSONObject;
import outfox.account.server.token.verifier.qplus.QOpenInfo;

/**
 * @author chen-chao
 */
public class QQUserInfoWritable extends UserInfoWritable {
    private static final long serialVersionUID = -1824689868746461303L;
    public static final String QQ = "qq";
    public static final String FIGURE = "figureurl_qq_1";
    public static final String FIGURE_2 = "figureurl_qq_2";
    public static final String NICKNAME = "nickname";
    public static final String TRUE = "1";
    public String getLevel() {
        return getProperty(LEVEL);
    }
    
    public void setGender(GENDER_VALUE gender) {
        setProperty(GENDER, gender.name());
    }
    
    public void setLevel(String level) {
        setProperty(LEVEL, level);
    }
    
    public boolean getIsVIP() {
        return getBooleanProperty(VIP);
    }
    public void setIsVIP(boolean isVip) {
        setBooleanProperty(VIP, isVip);
    }
    
    public QQUserInfoWritable() {
        
    }
    /**
     * 男 utf-8
     */
    static final char[] man = {30007};
    /**
     * 女 utf-8
     */
    static final char[] woman = {22899};
    static final String manStr = new String(man);
    static final String womanStr = new String(woman);
    /**
     * 女 utf-8
     */
    
    public QQUserInfoWritable(String userId, String originalId, JSONObject obj) {
        super();
        this.originalId = originalId;
        this.userId = userId;
        if (obj.containsKey(NICKNAME)) {
            setNickName(obj.getString(NICKNAME), userId);
        } else {
            setNickName(userId, userId);
        }
        if (obj.containsKey(FIGURE)) {
            this.imageUrl = obj.getString(FIGURE);
        }
        if (obj.containsKey(FIGURE_2)) {
            setBigImageUrl(obj.getString(FIGURE_2));
        }
        if (obj.containsKey(GENDER)) {
            setGenderValue(obj.getString(GENDER));
        }
        if (obj.containsKey(LEVEL)) {
            this.setLevel(obj.getString(LEVEL));
        }
        if (obj.containsKey(VIP)) {
            this.setIsVIP(TRUE.equals(obj.getString(VIP)));
        }
        
        this.from = QQ;
    }
    
    protected void setGenderValue(String gender) {
        if (manStr.equals(gender)) {
            this.setGender(GENDER_VALUE.MAN);
        } else if (womanStr.equals(gender)){
            this.setGender(GENDER_VALUE.WOMEN);
        } else {
            this.setGender(GENDER_VALUE.UNKNOWN);
        }
    }
    
    public QQUserInfoWritable(String userId, String originalId, QOpenInfo info) {
        super();
        this.userId = userId;
        this.from = QQ;
        this.originalId = originalId;
        this.userName = info.getNick();
        this.imageUrl = info.getFace();
        setGenderValue(info.getGender());
    }
    
    
}
