/**
 * @(#)XssUtils.java, 2012-10-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils.xss;

import java.io.File;
import java.io.UnsupportedEncodingException;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;

import com.netease.security.xssdefender.filter.XSSFilter;
import com.netease.security.xssdefender.filter.XSSFilterWrapper;

/**
 * @author chen-chao
 */
public class XssUtils {
    private static final long XSS_FILTER_TIEMOUT = AccConfig.getPros()
            .getLong(AccConfig.NAME_XSS_FILTER_TIMEOUT,
                    AccConfig.DEFAULT_XSS_FILTER_TIMEOUT);
    private static XSSFilter XSS_FILTER = null;
    static {
        try {
            File filterConf = AccConfig.getConfigFile("filters.properties");
            XSS_FILTER = XSSFilterWrapper.getFilter(filterConf.getAbsolutePath(), "note");
        } catch (Exception e) {
            throw new AccRunTimeException(e);
        }
    }
    
    /**
     * Do a XSS filter for the given note content. Any text which might lead to
     * a XSS attack would be filtered.
     *
     * @param data note content data to be filtered
     * @return filtered content data
     * @throws {@link AccException} 
     */
    public static byte[] filterXSS(byte[] data) throws AccException {
        try {
            String content = new String(data, AccConst.UTF8);
            String filtered = XSS_FILTER.getFilteredHTML(content,
                    XSSFilter.TYPE_NORMAL_HTML, XSS_FILTER_TIEMOUT);
            return filtered.getBytes(AccConst.UTF8);
        } catch(Exception e) {
            throw new AccException(AccExpType.XSS_FILTER_FAILED);
        }
    }
    
    /**
     * avoid xss attack
     * @param str
     * @return
     * @throws UnsupportedEncodingException 
     * @throws {@link AccException} 
     */
    public static String filterXSS(String str) throws AccException {
        if (str == null) {
            return str;
        }
        try {
            return new String(filterXSS(str.getBytes(AccConst.UTF8)),
                    AccConst.UTF8);
        } catch(UnsupportedEncodingException e) {
            throw new AccException(AccExpType.ENCODING_ERROR);
        }
    }
}
