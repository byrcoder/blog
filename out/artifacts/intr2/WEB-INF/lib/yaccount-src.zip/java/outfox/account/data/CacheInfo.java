/**
 * @(#)CacheInfo.java, 2012-9-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import outfox.account.conf.AccConst;


/**
 * It will be put into global cache.
 * @author chen-chao
 */
public class CacheInfo implements Serializable{
    private static final long serialVersionUID = -7872626683677198854L;
    Map<String, Object> properties;
    Cookie sessionCookie;
    Cookie bindCookie;
    Cookie loginCookie;
    
    public CacheInfo(AccCookies accCookies, Map<String,Object> info) {
        properties = new HashMap<String,Object>();
        if (info != null) {
            properties.putAll(info);
        }
        if (accCookies != null) {
            sessionCookie = accCookies.getSessionCookie();
            bindCookie = accCookies.getBindCookie();
            properties.put(accCookies.getProduct() + AccConst.ATTR_PART_PC, accCookies.getPerTokenV2());
            loginCookie = accCookies.genShadowCookie();
        }
    }
    
    public CacheInfo() {
        this(null, null);
    }
    
    public Map<String, Object> getProperties() {
        return properties;
    }
    
    public void addCookieIntoResponse(HttpServletResponse resp) {
        addCookie(resp, sessionCookie);
        addCookie(resp, bindCookie);
        if (loginCookie != null) {
            resp.addCookie(loginCookie);
        }
    }
    
    private void addCookie(HttpServletResponse resp, Cookie cookie) {
        if (cookie != null) {
            cookie.setValue(AccConst.V2_FLAG+cookie.getValue());
            resp.addCookie(cookie);
        }
    }
}
