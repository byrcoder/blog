/**
 * @(#)AccRunTimeException.java, 2012-8-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.exceptions;

/**
 * @author chen-chao
 */
public class AccRunTimeException  extends RuntimeException {
    private static final long serialVersionUID = -3458780921407067274L;

    public AccRunTimeException() {
    }

    /**
     * @param message
     */
    public AccRunTimeException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public AccRunTimeException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public AccRunTimeException(String message, Throwable cause) {
        super(message, cause);
    }
}
