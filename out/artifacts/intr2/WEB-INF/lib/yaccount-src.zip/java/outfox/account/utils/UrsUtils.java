/**
 * @(#)UrsUtils.java, 2011-9-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import static com.netease.urs.CookieNames.NTES_PASSPORT;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.verifier.impl.URSTokenVerifier;
import toolbox.misc.UnitUtils;
import toolbox.web.CookieUtil;
import account.app.AccountEmailUtils;
import account.app.BackendReloginClient;

import com.netease.urs.CookieNames;
import com.netease.urs.CookieValidator;

/**
 * @author wangfk
 * @modifier chen-chao
 */
public class UrsUtils {
    private static BackendReloginClient backendReloginClient;

    private static final String YOUDAO_COM_DOMAIN = ".youdao.com";

    private static final String URS_CHECK = "http://reg.163.com/services/chgcookie";

    /**
     * only check URS session cookie and get URS information.
     * 
     * @param req
     * @param resp
     * @return
     * @throws ServletException
     */
    public static String[] extractInfo(ServletRequest req, ServletResponse resp)
            throws ServletException {
        return extractInfoFromCookie(req, resp, null, -1, false, false);
    }

    /**
     * check session cookie and persist cookie from urs(163 passport). If only
     * has persist cookie, the function will use persist cookie to get session
     * cookie.
     * 
     * @param req
     * @param resp
     * @param backendReloginDomain
     *        if backendReloginDomain equals null, backendReloginDomain will be
     *        {@link UrsUtils#YOUDAO_COM_DOMAIN}
     * @param checkPersistCookie
     *        if true, check persist cookie and use it to get session cookie. if
     *        false, don't check persist cookie.
     * @param genSessionCookie
     *        if true, generate {@link com.netease.urs.CookieNames#NTES_SESS}
     *        cookie and write into response if false, generate nothing
     * @param expireTime
     *        millisecond if expireTime <= 0, then expireTime will set to 30
     *        days.
     * @return
     * @throws ServletException
     */
    public static String[] extractInfoFromCookie(ServletRequest req,
            ServletResponse resp, String backendReloginDomain, long expireTime,
            boolean checkPersistCookie, boolean genSessionCookie)
            throws ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        String[] info = genFakeURSInfo(request);
        if (info != null) {
            return info;
        }
        synchronized (UrsUtils.class) {
            if (backendReloginClient == null) {
                backendReloginClient = new BackendReloginClient(URS_CHECK);
                backendReloginClient.init();
            }
        }
        
        Cookie URSSess = CookieUtil.findCookie(request, NTES_SESS);
        Cookie URSPers = CookieUtil.findCookie(request, NTES_PASSPORT);
        if(URSSess != null || URSPers != null) {
            req.setAttribute(AccConst.ATTR_NOT_CHECK_V1_URS_COOKIE, true);
        }
        
        // convert milliseconds to seconds
        expireTime = (expireTime <= 0 ? UnitUtils.DAY_SEC * 30
                : (int) (expireTime / 1000));
        String[] results = AccountEmailUtils.getURSEmail(request, expireTime,
                true);

        // result is not null
        String email = results[0];
        String name = results[1];
        String cookieValue = results[2];

        if (email == null) {
            return results;
        }
        if (CookieNames.NTES_SESS.equals(name)) {
            // session cookie exist
            return results;
        }
        if (checkPersistCookie) {
            if (cookieValue != null) {
                cookieValue = backendReloginClient.reloginWithService(email,
                        req.getRemoteAddr(), cookieValue);
            }
            if (cookieValue == null) {
                return new String[5];
            }
            if (genSessionCookie && cookieValue != null) {
                // maxAge=-1, session cookie
                String domain = backendReloginDomain == null ? YOUDAO_COM_DOMAIN
                        : backendReloginDomain;
                CookieUtil.addCookie(response, CookieNames.NTES_SESS,
                        cookieValue, domain, "/", -1);
                return results;
            }
        }
        return results;
    }

    /**
     * 
     * @param cookieValue
     * @param expireTime millisecond
     * @return
     */
    public static String[] extractInfoBySessionCookie(
            String cookieValue, long expireTime) {
        String[] info = genFakeURSInfo(CookieNames.NTES_SESS, cookieValue);
        if (info != null) {
            return info;
        }
        String email = null;
        String mobile = "";
        String createTime = null;
        if (cookieValue != null) {
            CookieValidator validator = new CookieValidator();
            // check Session Cookie is alive (millisecond/1024 approximate second. /1000 ~ /1024) 
            if (validator.validateInMemoryCookie(cookieValue, expireTime >> 10,
                    false)) {
                mobile = validator.getMobile();
                email = validator.getEmail();
                createTime = validator.getCreateTime() + "";
            }
        }
        return new String[] {
            email, NTES_SESS, cookieValue, mobile, createTime
        };
    }

    /**
     * 
     * @param cookieValue
     * @param expiredTime millisecond
     * @return
     */
    public static String[] extractInfoByPesistCookie(
            String cookieValue, long expiredTime, String ip) {
        String[] info = genFakeURSInfo(CookieNames.NTES_PASSPORT, cookieValue);
        if (info != null) {
            return info;
        }
        String email = null;
        String mobile = "";
        String createTime = null;
        if (cookieValue != null) {
            CookieValidator validator = new CookieValidator();
            // if persistent cookie is invalid or expired (millisecond/1024 approximate second. /1000 ~ /1024) 
            if (validator.validatePersistentCookie(cookieValue, expiredTime >> 10, false)) {
                mobile = validator.getMobile();
                email = validator.getEmail();
                createTime = validator.getCreateTime() + "";
            }
        }
        
        if (cookieValue != null) {
            cookieValue = backendReloginClient.reloginWithService(email,
                    ip, cookieValue);
        }
        if (cookieValue == null) {
            return new String[]{null, null, null, null, null};
        }
        return new String[] {
            email, NTES_PASSPORT, cookieValue, mobile, createTime
        };
    }
    protected static final String URS_COOKIE_DOMAIN = ".youdao.com"; 
    public static final String S_INFO = "S_INFO";
    public static final String P_INFO = "P_INFO";
    public static final String NTES_SESS = CookieNames.NTES_SESS;
    public static void cleanURSCookies(HttpServletResponse resp) {
        // clean URS cookies
        resp.addCookie(AuthUtils.deleteCookie(CookieNames.NTES_PASSPORT, URS_COOKIE_DOMAIN, true));
        resp.addCookie(AuthUtils.deleteCookie(CookieNames.NTES_SESS, URS_COOKIE_DOMAIN, true));
        resp.addCookie(AuthUtils.deleteCookie(S_INFO, URS_COOKIE_DOMAIN, false));
    }
    public static final String FAKE_URS_ID_FORMAT = "urstest_ynote%s@163.com";
    public static final String FAKE_URS_ID_PREFIX = "urstest_ynote";
    public static String[] genFakeURSInfo(ServletRequest req) {
        Cookie sess = CookieUtil.findCookie((HttpServletRequest)req, CookieNames.NTES_SESS);
        if (sess != null) {
            return genFakeURSInfo(sess.getName(), sess.getValue());
        }
        return null;
    }
    
    public static String[] genFakeURSInfo(String cookieName, String cookieValue) {
        if (AccConfig.isTestCaseMode()) {
            String userName = AccConfig.getUrsUserName();
            if (StringUtils.isBlank(userName)) {
                userName = String.format(FAKE_URS_ID_FORMAT, AuthUtils.generateFileId());
            }
            return new String[] {
                    userName, cookieName, cookieValue, null, null
            };
        } else {
            return null;
        }
    }
    public static String getURSWapperCookieValue(String token) {
        return token.substring(AccConst.URS_MEMORY_CHECK_LENGTH);
    }
    
    public static class WapperURSCookieInfo {
        public String product;

        public String userId;

        public String sessCookieVal;

        public String verifierName;

        public long expiredTime;

        public WapperURSCookieInfo(String product, String userId, String verifierName,
                String sessCookieVal, String expiredTime) {
            this.product = product;
            this.userId = userId;
            this.sessCookieVal = sessCookieVal;
            this.verifierName = verifierName;
            try {
                this.expiredTime = Long.parseLong(expiredTime);
            }catch(Exception e) {
                // fake login, expire it.
                this.expiredTime = 0;
            }
        }

        public WapperURSCookieInfo() {}
    }
    
    public static WapperURSCookieInfo getInfoFromCookieValue(String cookieValue) throws AccException {
        if (StringUtils.isBlank(cookieValue)) {
            return new WapperURSCookieInfo();
        }
        URSTokenVerifier.checkSign(cookieValue);
        String token = getURSWapperCookieValue(cookieValue);
        // check sign
        
        String[] infoString = token.split("\\|\\|");
        return new WapperURSCookieInfo(infoString[0], infoString[1], infoString[2], infoString[3], infoString[4]);
    }
}
