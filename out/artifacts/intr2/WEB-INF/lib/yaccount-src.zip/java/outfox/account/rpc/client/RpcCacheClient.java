/**
 * @(#)RpcCacheServer.java, 2012-7-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.client;

import outfox.account.exceptions.AccException;
import outfox.account.rpc.protocol.ICacheService;
import outfox.account.rpc.protocol.impl.MemoryCacheService;

/**
 *
 * @author wangfk
 *
 */
public class RpcCacheClient extends AccRpcClient{
    
    public RpcCacheClient() {
        super(ICacheService.class, MemoryCacheService.getInstance());
        LOG.info("Cache rpc service init done.");
    }
    
    public ICacheService lookup(String key) throws AccException {
        return (ICacheService)super.lookup(key);
    }
}
