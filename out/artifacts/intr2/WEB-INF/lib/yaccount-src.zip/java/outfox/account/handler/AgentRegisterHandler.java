/**
 * @(#)AgentRegisterHandler.java, 2012-9-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.cache.LocalWriteCache;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.utils.AuthUtils;
import toolbox.web.CookieUtil;

import com.netease.is.image.CheckCode_a;

/**
 * @author wangxin, chen-chao
 */
@Controller
public class AgentRegisterHandler extends BaseHandler {
    private static final long serialVersionUID = 8348804841118765683L;
    private LocalWriteCache<String, CaptchaStore> idMap = new LocalWriteCache<String, CaptchaStore>(true, 100);
    
    @RequestMapping(AccConst.REGISTER_SHOW_URL)
    protected void showRegisterPage(HttpServletRequest req,
            HttpServletResponse resp) throws AccException  {
        setName(req, "register-show");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkParam(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        String product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        AccConfig.checkProduct(product);
        String tp = req.getParameter(AccConst.PARAM_THIRD_PARTY_NAME);
        LOG.info(String.format("register for product %s, tp %s.",product, tp));
        String redirectUrl = AccConfig.getRegisterUrl(product, tp);
        //TODO  using params
        safeRedirect(req, resp, redirectUrl);
    }
    
    /**
     * /reg/query?app=&product=&guid=&height=&width=;
     * 
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(AccConst.REGISTER_QUERY_URL)
    public void registerQuery(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // 0. setname in analyzer and vaquero
        setName(req, "registerQuery");
        checkParam(req, AccConst.PARAM_APP_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        String product = AuthUtils.getProductForCompatible(req);
        // 1. get captcha id
        String cid = getCaptchaID(req,resp,product);
        if (cid == null) {
            LOG.info("no captcha id, create a new one");
            cid = AuthUtils.genUniqueToken();
            // 2. set captcha to response
            
            resp.addCookie(createRegisterCookie(cid, product));
        }
        CaptchaStore cap = getCaptchaInfo(req, cid);
        // 3. set captcha to response
        sendCaptchaResponse(req, cap, resp, cid);
    }

    /**
     * @param cid
     * @return
     */
    private CaptchaStore getCaptchaInfo(HttpServletRequest req, String cid) {
        CaptchaStore cap = idMap.get(cid);
        if (cap == null) {
            cap = new CaptchaStore();
        }
        int height = -1, width = -1;
        if (req.getParameter("height") != null) {
            height = Integer.valueOf(req.getParameter("height"));
        }
        if (req.getParameter("width") != null) {
            width = Integer.valueOf(req.getParameter("width"));
        }
        if (cap.height < 0) {
            cap.height = height;
        }
        if (cap.width < 0) {
            cap.width = width;
        }
        return cap;
    }

    /**
     * /reg/send?app=&product=&captcha=&userid=&pass=&guid=&ursp=
     * 
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(AccConst.REGISTER_SEND_URL)
    public void sendToURS(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        setName(req, "sendToURS");
        checkParam(req, AccConst.PARAM_APP_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_USER_CAPTCHA, NO_MISS);
        checkParam(req, AccConst.PARAM_USER_ID, NO_MISS);
        checkParam(req, AccConst.PARAM_PASSWORD, NO_MISS);
        
        checkCaptcha(req, resp);
        
        String ursProduct = AuthUtils.getReqParamVal(req, AccConst.PARAM_URS_PRODUCT_NAME,
                AccConst.PARAM_URS_PRODUCT_DEFAULT_VALUE);
        String returnValue = AuthUtils.registerURS(req.getParameter(AccConst.PARAM_USER_ID),
                req.getParameter(AccConst.PARAM_PASSWORD), ursProduct, AuthUtils.getRequestIP(req));
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("StatusCode", returnValue));
        write(req, resp, params, HttpStatus.OK);
    }
    
    @RequestMapping(AccConst.CAPTCHA_CHECK)
    public void check(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        checkParam(req, AccConst.PARAM_USER_CAPTCHA, NO_MISS);
        checkCaptcha(req, resp);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("success", true));
        write(req, resp, params, HttpStatus.OK);
    }
    
    private void checkCaptcha(HttpServletRequest req, HttpServletResponse resp) throws AccException{
        String product = AuthUtils.getProductForCompatible(req);
        String cid = getCaptchaID(req, resp, product);
        if (cid == null) {
            throw new AccException("Not find captcha id",
                    AccException.AccExpType.CAPTCHA_CODE_NOT_FOUND_ERROR);
        }
        CaptchaStore cap = idMap.get(cid);
        if (cap == null) {
            throw new AccException("Not find captcha id in idMap",
                    AccException.AccExpType.CAPTCHA_CODE_NOT_FOUND_ERROR);
        }
        idMap.remove(cid);
        if (isExpired(cap)) {
            throw new AccException("captcha is expired",
                    AccException.AccExpType.CAPTCHA_CODE_EXPIRED_ERROR);
        } else {
            String userCaptcha = req.getParameter(AccConst.PARAM_USER_CAPTCHA).toLowerCase();
            String realCaptcha = cap.code.toLowerCase();
            if (!userCaptcha.equals(realCaptcha)) {
                throw new AccException(String.format("input captcha error. expect:%s, user:%s.",realCaptcha, userCaptcha),
                        AccException.AccExpType.CAPTCHA_CODE_ERROR);
            }
        }
    }

    /**
     * @param cap
     * @return
     */
    private boolean isExpired(CaptchaStore cap) {
        if (System.currentTimeMillis() - cap.createTime > AccConfig.getPros()
                .getLong(AccConfig.NAME_CAPTCHA_CODE_TIMEOUT,
                        AccConfig.DEFAULT_CAPTCHA_CODE_TIMEOUT)) {
            return true;
        }
        return false;
    }


    /**
     * @param req
     * @return
     */
    private String getCaptchaID(HttpServletRequest req, HttpServletResponse resp, String product) {
        String cid = null;
        Cookie cookie = CookieUtil.findCookie(req, product + AccConst.COOKIE_REGISTER);
        if (null != cookie) {
            cid = cookie.getValue();
            
            resp.addCookie(createRegisterCookie(cid, product));
        }
        return cid;
    }

    /**
     * @param domain
     * @param id
     * @return
     */
    private Cookie createRegisterCookie(String id, String product) {
        Cookie cookie = new Cookie(product + AccConst.COOKIE_REGISTER, id);
        cookie.setMaxAge(-1);
        cookie.setHttpOnly(true);
        cookie.setPath(AccConst.COOKIE_ROOT_PATH);
        return cookie;
    }

    /**
     * @param resp
     * @param id
     * @throws AccException
     */
    private void sendCaptchaResponse(HttpServletRequest req, CaptchaStore cap, HttpServletResponse resp, String id)
            throws AccException {
        try {
            CheckCode_a checkCode = createYnoteCheckCode(cap.height,cap.width);
            ByteArrayInputStream im = checkCode.createCAPTCHA();
            cap.code = checkCode.getCheckCode();
            cap.createTime = System.currentTimeMillis();
            idMap.put(id, cap);
            byte[] image = IOUtils.toByteArray(im);
            write(req, resp, FORMAT.image, image, HttpStatus.OK);
        } catch (IOException e) {
            throw new AccRunTimeException("InputStream to byte[] error", e);
        }
    }                                                                                                                               

    /**
     * @return
     */
    private CheckCode_a createYnoteCheckCode(int height, int width) {
        CheckCode_a code = new CheckCode_a();
        if (height < 0
                || height > AccConfig.getPros().getInt(
                        AccConfig.NAME_CAPTCHA_HEIGHT,
                        AccConfig.DEFAULT_CAPTCHA_HEIGHT)) {
            height = AccConfig.getPros().getInt(AccConfig.NAME_CAPTCHA_HEIGHT,
                    AccConfig.DEFAULT_CAPTCHA_HEIGHT);
        }
        if (width < 0
                || width > AccConfig.getPros().getInt(
                        AccConfig.NAME_CAPTCHA_WIDTH,
                        AccConfig.DEFAULT_CAPTCHA_WIDTH)) {
            width = AccConfig.getPros().getInt(AccConfig.NAME_CAPTCHA_WIDTH,
                    AccConfig.DEFAULT_CAPTCHA_WIDTH);
        }
        code.setOutputSize(height,width);
        code.setCodeLength(
                AccConfig.getPros().getInt(AccConfig.NAME_CAPTCHA_MIN_LENGTH,
                        AccConfig.DEFAULT_CAPTCHA_MIN_LENGTH),
                AccConfig.getPros().getInt(AccConfig.NAME_CAPTCHA_MAX_LENGTH,
                        AccConfig.DEFAULT_CAPTCHA_MAX_LENGTH));
       return code;
    }
    
    private static class CaptchaStore {
        public String code;
        public long createTime;
        public int height,width;
        public CaptchaStore(){
            height = -1;
            width = -1;
        }
    }
}
