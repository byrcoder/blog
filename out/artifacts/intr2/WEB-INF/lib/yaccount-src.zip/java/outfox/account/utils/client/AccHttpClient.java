/**
 * @(#)SSLClient.java, 2012-1-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils.client;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.Cookie;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.AutoRetryHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.utils.AuthUtils;

/**
 * If our application is client, only using {@link #getAccessTokenByPassword}.
 * If our application is web application, and no callback, using
 * {@link #getAuthorizedCode} first, then using
 * {@link #getAccessTokenByAuthorize}
 * 
 * @author chen-chao
 */
public class AccHttpClient {
    protected static final Log LOG = LogFactory.getLog(AccHttpClient.class);

    public enum Method {
        GET, POST
    }

    public enum Style {
        QUERY_STRING, HEAD
    }

    HttpClient client = null;

    private PoolingClientConnectionManager connectionManager;

    public HttpClient getClient() {
        return client;
    }

    public void setClient(HttpClient client) {
        this.client = client;
    }

    private AccHttpClient() {
        this(1024, 1024 * 1024, 10000, 10000, CookiePolicy.IGNORE_COOKIES, true, true);
    }

    private static class SSLClientHolder {
        private static final AccHttpClient instance = new AccHttpClient();
    }

    public static AccHttpClient getInstance() {
        return SSLClientHolder.instance;
    }

    private static class TrustAnyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}

        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[] {};
        }

    }

    /**
     * @param maxConnectPerHost
     *            max number of connection
     * @param maxConnection
     *            total number of connections
     * @param connectTimeOut
     *            wait max time before a connection established.
     * @param socketTimeOut
     *            socket wait max time
     * @param retryCount
     *            retry time of connection
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    public AccHttpClient(int maxConnectPerHost, int maxConnection, int connectTimeOut, int socketTimeOut,
            String cookiePolicy, boolean isAutoRetry, boolean redirect) {
        SSLContext sslcontext = null;
        try {
            sslcontext = SSLContext.getInstance("SSL");
            sslcontext.init(null, new TrustManager[] {
                new TrustAnyTrustManager()
            }, new java.security.SecureRandom());
        } catch (Exception e) {
            throw new AccRunTimeException("can not create request client.", e);
        }
        // if a ssl certification is not correct, it will not throw any exceptions.
        // TODO remove SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER later
        Scheme https = new Scheme("https", 443, new SSLSocketFactory(sslcontext,
                SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER));
        Scheme http = new Scheme("http", 80, PlainSocketFactory.getSocketFactory());
        SchemeRegistry sr = new SchemeRegistry();
        sr.register(https);
        sr.register(http);

        connectionManager = new PoolingClientConnectionManager(sr, socketTimeOut, TimeUnit.SECONDS);
        connectionManager.setDefaultMaxPerRoute(maxConnectPerHost);
        connectionManager.setMaxTotal(maxConnection);
        HttpParams params = new BasicHttpParams();
        params.setLongParameter(ClientPNames.CONN_MANAGER_TIMEOUT, connectTimeOut);
        params.setParameter(ClientPNames.COOKIE_POLICY, cookiePolicy);
        params.setBooleanParameter(ClientPNames.HANDLE_REDIRECTS, redirect);
        params.setBooleanParameter(ClientPNames.ALLOW_CIRCULAR_REDIRECTS, false);

        if (isAutoRetry) {
            client = new AutoRetryHttpClient(new DefaultHttpClient(connectionManager, params));
        } else {
            client = new DefaultHttpClient(connectionManager, params);
        }
    }

    public JSONObject getJSON(Method method, String url, List<Header> headers, List<Parameter> urlParameters,
            HttpEntity entity) throws AccException {
        String ret = null;
        try {
             ret = getString(method, url, headers, urlParameters, entity);
             return JSONObject.fromObject(ret);
        }catch(Exception e) {
            System.out.println(ret);
            throw new AccException("can not create JSON obj. string is"+ret, e,AccExpType.ENCODING_ERROR);
        }
    }

    /**
     * use default utf-8 encoding;
     * 
     * @param url
     * @param headers
     * @param urlParameters
     * @return
     * @throws AccException
     */
    public String getString(Method method, String url, List<Header> headers, List<Parameter> urlParameters,
            HttpEntity entity) throws AccException {
        return getString(method, url, headers, urlParameters, entity, AccConst.UTF8);
    }

    public String getString(Method method, String url, List<Header> headers, List<Parameter> urlParameters,
            HttpEntity entity, String encoding) throws AccException {
        byte[] content = getBytes(method, url, headers, urlParameters, entity);
        if (content != null) {
            try {
                String ret = new String(content, encoding);
                return ret;
            } catch (UnsupportedEncodingException e) {
                throw new AccException("get reseponse string encoding error, encoding:" + encoding, e,
                        AccExpType.ENCODING_ERROR);
            }
        }
        return null;
    }

    public byte[] getBytes(Method method, String url, List<Header> headers, List<Parameter> params,
            HttpEntity entity) throws AccException {
        byte[] content = null;
        try {
            switch (method) {
                case GET:
                    content = byteArrayHandler.handleResponse(doGet(url, headers, params));
                    break;
                case POST:
                    content = byteArrayHandler.handleResponse(doPost(url, headers, params, entity));
                    break;
                default:
                    throw new AccException("method:" + method, AccExpType.NOT_IMPLEMENT_METHOD);
            }

        } catch (Exception e) {
            throw new AccException("convert response to bytes error", e, AccExpType.RESPONSE_TO_BYTES_ERROR);
        }
        return content;
    }

    /**
     * If you call doGet , you should call closeQuiet() to close the response.
     * @param url
     * @param headers
     * @param urlParameters
     * @return
     * @throws AccException
     */
    public HttpResponse doGet(String url, List<Header> headers, List<Parameter> urlParameters)
            throws AccException {
        String composeQueryUrl = AuthUtils.composeQueryUrl(url, urlParameters);
        if (AccConfig.isTestCaseMode()) {
            System.out.println(composeQueryUrl);
            System.out.println("Headers:");
            if (headers != null) {
                for (Header h: headers) {
                    System.out.println(h.getName() + ":" + h.getValue());
                }
            }
        }
        LOG.debug("get query url:" + composeQueryUrl);
        HttpGet get = new HttpGet(composeQueryUrl);
        if (headers != null) {
            Header[] array = new Header[headers.size()];
            headers.toArray(array);
            get.setHeaders(array);
        }
        
        try {
            HttpResponse resp = client.execute(get);
            return resp;
        } catch (Exception e) {
            throw new AccException("request error:" + get.getURI().toString(), e, AccExpType.GET_REQUEST_ERROR);
        }
    }

    public HttpResponse doPost(String url, List<Header> headers, List<Parameter> params, HttpEntity entity)
            throws AccException {
        HttpPost post = new HttpPost(AuthUtils.composeQueryUrl(url, params));
        if (headers != null) {
            Header[] array = new Header[headers.size()];
            headers.toArray(array);
            post.setHeaders(array);
        }
        post.setEntity(entity);
        try {
            return client.execute(post);
        } catch (Exception e) {
            throw new AccException("request error" + post.getURI(), e, AccExpType.GET_REQUEST_ERROR);
        }
    }

    public static UrlEncodedFormEntity composeUrlEncodingEntity(Map<String, Object> postParam, String charset)
            throws AccException {
        if (postParam == null) {
            return null;
        } 
        List<NameValuePair> postParams = new ArrayList<NameValuePair>();
        for (Entry<String, Object> entry: postParam.entrySet()) {
            postParams.add(new BasicNameValuePair((String) entry.getKey(), AuthUtils.toString(entry
                    .getValue())));
        }
        return createUrlEncodeFormEntiy(charset, postParams);
    }
    
    public static UrlEncodedFormEntity composeUrlEncodingEntity(List<Parameter> postParam, String charset)
            throws AccException {
        if (postParam == null) {
            return null;
        } 
        List<NameValuePair> postParams = new ArrayList<NameValuePair>();
        for (Parameter param: postParam) {
            postParams.add(new BasicNameValuePair((String) param.key, param.getStrVal()));
        }
        return createUrlEncodeFormEntiy(charset, postParams);
    }

    protected static UrlEncodedFormEntity createUrlEncodeFormEntiy(String charset,
            List<NameValuePair> postParams) throws AccException {
        UrlEncodedFormEntity entity = null;
        try {
            entity = new UrlEncodedFormEntity(postParams, charset);
        } catch (UnsupportedEncodingException e) {
            throw new AccException("get reseponse URLEncoding error. charset:" + charset, e,
                    AccExpType.ENCODING_ERROR);
        }
        return entity;
    }

    /**
     * Post query using url-form encoding
     * Must call {@link #closeQuiet}.
     * @param url
     * @param postParam
     * @return
     * @throws UnsupportedEncodingException
     * @throws AccException
     */
    public HttpResponse doPostUrlEncoding(String url, Map<String, Object> postParam, String charset)
            throws AccException {

        return doPost(url, null, null, composeUrlEncodingEntity(postParam, charset));
    }

    /**
     * This is for fixing the bug in
     * {@link org.apache.http.entity.mime.content.InputStreamBody}
     * 
     * @author wangfk
     */
    public static class InputStreamKnownSizeBody extends InputStreamBody {
        private int length;

        public InputStreamKnownSizeBody(final InputStream in, final int length, final String filename) {
            super(in, filename);
            this.length = length;
        }

        public InputStreamKnownSizeBody(final InputStream in, final int length, final String mimeType,
                final String filename) {
            super(in, mimeType, filename);
            this.length = length;
        }

        @Override
        public long getContentLength() {
            return this.length;
        }
    }
    
    public static MultipartEntity composeMultiPartEntity(Map<String, Object> postParam, String charset)
            throws AccException {
        return composeMultiPartEntity(postParam, charset, charset);
    }
    /**
     * Some multipart parser can not parse "utf-8" or other charset in multipart header, so
     * the headerCharset <b>MUST</b> be ascii.
     * @param postParam
     * @param headerCharset
     * if it is null, the header charset of multipart will be default(ascii).
     * @param bodyCharset
     * @return
     * @throws AccException
     */
    public static MultipartEntity composeMultiPartEntity(Map<String, Object> postParam, String headerCharset, String bodyCharset)
            throws AccException {
        MultipartEntity entity = null;
        if (headerCharset == null) {
            entity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
        } else {
            entity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE, null,
                    Charset.forName(headerCharset));
        }
         

        for (Map.Entry<String, Object> entry: postParam.entrySet()) {
            // byte[]
            if (byte[].class.isInstance(entry.getValue())) {
                entity.addPart(entry.getKey(), new InputStreamKnownSizeBody(new ByteArrayInputStream(
                        (byte[]) entry.getValue()), ((byte[]) entry.getValue()).length, "file"));
            }
            // File
            else if (File.class.isInstance(entry.getValue())) {
                entity.addPart(entry.getKey(), new FileBody((File) entry.getValue()));
            }
            // String
            else {
                try {
                    entity.addPart(entry.getKey(), new StringBody(AuthUtils.toString(entry.getValue()), Charset.forName(bodyCharset)));
                } catch (Exception e) {
                    throw new AccException("request String parameter error. Key:" + entry.getKey()
                            + " value:" + entry.getValue(), e, AccExpType.POST_MULTIPART_ERROR);
                }
            }
        }
        return entity;
    }

    /**
     * Post a query using multi-part
     * Must call {@link #closeQuiet}.
     * @param url
     * @param postParam
     * @return
     * @throws AccException
     */
    public HttpResponse doPostByMultipart(String url, Map<String, Object> postParam, String charset)
            throws AccException {

        return doPost(url, null, null, composeMultiPartEntity(postParam, charset));
    }

    public ArrayList<Header> getHeader(Header[] headers, String key, String name) {
        ArrayList<Header> list = new ArrayList<Header>();
        if (headers != null) {
            for (Header header: headers) {
                if (header.getName().equals(key)) {
                    list.add(new BasicHeader(name, header.getValue()));
                }
            }
        }
        return list;
    }

    ByteArrayHandler byteArrayHandler = new ByteArrayHandler();

    private static class ByteArrayHandler implements ResponseHandler<byte[]> {
        @Override
        public byte[] handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
            HttpEntity entity = response.getEntity();

            if (entity != null) {
                try {
                    return EntityUtils.toByteArray(entity);
                } finally {
                    EntityUtils.consumeQuietly(entity);
                }
            } else {
                return null;
            }
        }
    }

    public static void closeQuiet(HttpResponse response){
        if (response != null) {
            EntityUtils.consumeQuietly(response.getEntity());
        }
    }
    public static final String COOKIE_HEADER_NAME = "Cookie";
    public static Header makeCookies2Header(Cookie ...cookies) {
        if (cookies == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (Cookie cookie : cookies) {
            sb.append(cookie.getName()).append("=").append(cookie.getValue()).append(";");
        }
        return new BasicHeader(COOKIE_HEADER_NAME, sb.toString());
    }
}
