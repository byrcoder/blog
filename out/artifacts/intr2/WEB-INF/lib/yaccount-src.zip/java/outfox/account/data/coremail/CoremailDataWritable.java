/**
 * @(#)CoremailDataWritable.java, 2012-11-6. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.coremail;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringPropertiesWritable;
import odis.serialize.lib.StringWritable;
/**
 *
 * @author wangxin
 *
 */
public class CoremailDataWritable implements IWritable{

    private String wsdlURL;
    public static final String DOMAIN = "domain";
    /**
     * @return the domainURL
     */
    public String getWsdlURL() {
        return wsdlURL;
    }

    /**
     * @param domainURL the domainURL to set
     */
    public void setWsdlURL(String wsdlURL) {
        this.wsdlURL = wsdlURL;
    }


    // for extending
    private StringPropertiesWritable reservedProperties;
    
    public CoremailDataWritable(String url) {
        wsdlURL = url;
        reservedProperties = new StringPropertiesWritable();
    }
    
    public CoremailDataWritable() {
        reservedProperties = new StringPropertiesWritable();
    }
    
    @Override
    public void readFields(DataInput in) throws IOException {
        wsdlURL = StringWritable.readStringNull(in);
        reservedProperties.readFields(in);
    }


    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, wsdlURL);
        reservedProperties.writeFields(out);
        
    }


    @Override
    public IWritable copyFields(IWritable value) {
        CoremailDataWritable that = (CoremailDataWritable) value;
        this.wsdlURL = that.wsdlURL;
        this.reservedProperties.copyFields(that.reservedProperties);
        return this;
    }

    public void setDomain(String domain) {
        reservedProperties.put(DOMAIN, domain);
    }
    public String getDomain() {
        return reservedProperties.get(DOMAIN);
    }
}
