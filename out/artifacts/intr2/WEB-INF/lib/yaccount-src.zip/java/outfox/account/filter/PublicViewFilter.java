/**
 * @(#)PublicViewFilter.java, 2013-2-20. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.data.PublicViewWritable;
import outfox.account.db.DataStore;
import outfox.account.handler.BaseHandler;
import toolbox.web.CookieUtil;

/**
 * "referer_url_prefix" is its parameter.
 * If you want "note.youdao.com/yws/pv/xxx" mapping userA@163.com.
 * you should add using "note.youdao.com/yws/pv/" as its "referer_url_prefix".
 * 
 * And add mapping of "xxx" => userA@163.com in ServerManager system.
 * @author chen-chao
 */
public class PublicViewFilter extends BaseHandler implements Filter {
    private static final long serialVersionUID = -6943548450537516978L;
    /**
     * key is suffix of url, value is userId
     */
    private DataStore store = null;
    private String refererUrlPrefix = null;
    private String product = null;

    @Override
    public void destroy() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) arg0;
        HttpServletResponse resp = (HttpServletResponse) arg1;
        Cookie cookie = CookieUtil.findCookie(req, product + AccConst.COOKIE_PUBLIC_VIEW);
        String referer = (cookie == null) ? "" : cookie.getValue();
        
        try {

            if (StringUtils.isNotBlank(referer)) {
                int index = referer.lastIndexOf(refererUrlPrefix);
                if (index >= 0) {
                    String suffix = referer.substring(index + refererUrlPrefix.length());
                    String keyfrom = req.getParameter("keyfrom");
                    if (suffix.equals(keyfrom)) {
                    
                        PublicViewWritable mapping = store.readPublicViewMapping(suffix);
                        if (mapping != null) {
                            // old
                            req.setAttribute(AccConst.ATTR_PUBLIC_VIEW_USER_ID, mapping.userId);
    
                            LOG.info(String.format("referer:%s, suffix:%s, using userId:%s.", referer, suffix, mapping.userId));
                        } 
                    }
                }
            }
            LOG.info("passed. referer:"+referer);
        } catch (Throwable e) {
            LOG.warn(String.format("referer:%s, prefix:%s.", referer, refererUrlPrefix), e);
        }
        
        chain.doFilter(req, resp);
    }
    private boolean isInit = false;
    public boolean isInit() {
        return isInit;
    }

    public void setInit(boolean isInit) {
        this.isInit = isInit;
    }

    @Override
    public void init(FilterConfig conf) throws ServletException {
        if (!isInit) {
            refererUrlPrefix = getParamStr(conf, "referer_url_prefix", "note.youdao.com/yws/");
            product = getParamStr(conf, "product", "YNOTE");
        }
        store = DataStore.getInstance();
    }

    public String getPrefix() {
        return refererUrlPrefix;
    }

    public void setPrefix(String prefix) {
        this.refererUrlPrefix = prefix;
    }
    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }
}
