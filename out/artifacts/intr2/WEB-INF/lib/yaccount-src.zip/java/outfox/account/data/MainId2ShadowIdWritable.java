/**
 * @(#)AccountBindingWritable.java, Mar 8, 2012.
 * Copyright 2012 Yodao, Inc. All  rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.lib.StringWritable;

/**
 * Account binding information, each binding appears in a ID pair style like:
 * (shadowUserId : mainUserId).
 * 
 * @author TanTian
 */
public class MainId2ShadowIdWritable extends AbstractWritable {

    private static final long serialVersionUID = 656500752033907350L;

    /**
     * The source ID in a binding relationship. This should always be an account
     * of other organizations, for example QQ, WeiBo, etc.
     */
    private String shadowUserId;

    /**
     * The target ID in a binding relationship. This is always an account of the
     * NetEase passport.
     */
    private String mainUserId;

    /**
     * The creating time of this account binding.
     */
    private long bindingTimeStamp;

    public MainId2ShadowIdWritable() {
        super();
    }

    /**
     * Construct a AccountBindingWritable whose binding time is right now.
     * 
     * @param shadowUserId
     * @param mainUserId
     */
    public MainId2ShadowIdWritable(String mainUserId, String shadowUserId) {
        this(mainUserId, shadowUserId, System.nanoTime());
    }

    public MainId2ShadowIdWritable(String mainUserId, String shadowUserId, long bindingTimeStamp) {
        this();
        this.shadowUserId = shadowUserId;
        this.mainUserId = mainUserId;
        this.bindingTimeStamp = bindingTimeStamp;

    }

    /**
     * @return the mainUserId
     */
    public String getMainUserId() {
        return mainUserId;
    }

    /**
     * @param mainUserId
     *        the mainUserId to set
     */
    public void setMainUserId(String mainUserId) {
        this.mainUserId = mainUserId;
    }

    /**
     * @return the shadowUserId
     */
    public String getShadowUserId() {
        return shadowUserId;
    }

    /**
     * @param shadowUserId
     *        the shadowUserId to set
     */
    public void setShadowUserId(String shadowUserId) {
        this.shadowUserId = shadowUserId;
    }

    /**
     * @return the bindingTimeStamp
     */
    public long getBindingTimeStamp() {
        return bindingTimeStamp;
    }

    /**
     * @param bindingTimeStamp
     *        the bindingTimeStamp to set
     */
    public void setBindingTimeStamp(long bindingTimeStamp) {
        this.bindingTimeStamp = bindingTimeStamp;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (bindingTimeStamp ^ (bindingTimeStamp >>> 32));
        result = prime * result + ((mainUserId == null) ? 0 : mainUserId.hashCode());
        result = prime * result + ((shadowUserId == null) ? 0 : shadowUserId.hashCode());
        return result;
    }

    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        shadowUserId = StringWritable.readStringNull(in);
        mainUserId = StringWritable.readStringNull(in);
        bindingTimeStamp = in.readLong();
    }

    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, shadowUserId);
        StringWritable.writeStringNull(out, mainUserId);
        out.writeLong(bindingTimeStamp);
    }

}
