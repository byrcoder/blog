/**
 * @(#)ICoremailDB.java, 2013-2-25. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.data.coremail.CoremailDataWritable;
import outfox.account.db.in.ICoremailDB.ICoremailIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface ICoremailDB extends IteratorService<ICoremailIter>{
    public interface ICoremailIter extends Iterator<CoremailDataWritable>{
        public CoremailDataWritable next() throws AccException;
        public void close();
    }
    public ICoremailIter getIter(String domain) throws AccException;
    CoremailDataWritable read(String domain) throws AccException;
    void writeCoremailDomainURL(String domain, String url) throws AccException;
    void removeCoremailDomainURL(String domain) throws AccException;
}
