/**
 * @(#)URSTokenVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.AccCookies;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.URSVerifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.CipherUtils;
import outfox.account.utils.SecurityUtils;
import outfox.account.utils.UrsUtils;
import outfox.account.utils.UrsUtils.WapperURSCookieInfo;
import outfox.account.utils.client.AccHttpClient;

/**
 * @author chen-chao
 */
public class URSTokenVerifier extends URSVerifier {
    private String initUrl = null;

    private String safeLoginUrl = null;

    private String verifierUrl = null;

    private String removeUrl = null;

    private String sessUrl = null;

    private static final String UNKNOWN = "unknown";

    public URSTokenVerifier(Properties props) {
        super(props);
        initUrl = getAndCheck(props, NAME + VerifierConfConst.URS_TOKEN_INIT_URL);
        safeLoginUrl = getAndCheck(props, NAME + VerifierConfConst.URS_TOKEN_SAFE_LOGIN_URL);
        verifierUrl = getAndCheck(props, NAME + VerifierConfConst.URS_TOKEN_VERIFIER_URL);
        removeUrl = getAndCheck(props, NAME + VerifierConfConst.URS_TOKEN_REMOVE_TOKEN_URL);
        sessUrl = getAndCheck(props, NAME + VerifierConfConst.URS_TOKEN_GET_SESS_URL);
        ursProductName = getAndCheck(props, NAME + VerifierConfConst.URS_TOKEN_PRODUCT_NAME);
    }

    public static final String NAME = VerifierConfConst.URS_TOKEN_VERIFIER_NAME;

    @Override
    public String getVerifierName() {
        return NAME;
    }

    public static final String URS_PRODUCT_VERSION = "pdtVersion";

    public static final String URS_MAC = "mac";

    public static final String URS_DEVICE_TYPE = "deviceType";

    public static final String URS_SYSTEM_NAME = "systemName";

    public static final String URS_SYSTEM_VERSION = "systemVersion";

    public static final String URS_RESOLUTION = "resolution";

    private static final String URS_ID = "id";

    private static final String URS_PARAMS = "params";

    public static final String URS_USERNAME = AccConst.PARAM_URS_USERNAME;

    public static final String URS_PASSWORD = AccConst.PARAM_URS_PASSWORD;

    private static final String URS_USERIP = "userip";

    private static final String URS_PRODUCT = "product";

    private String ursProductName = null;

    private static final String URS_TOKEN = "token";
    
    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        String pci = AuthUtils.getReqVal(req, AccConst.PARAM_PCINDEX_NAME);
        List<Parameter> params = new ArrayList<Parameter>();
        String username = null;
        String password = null;
        String syname = AuthUtils.getReqParamVal(req, URS_SYSTEM_NAME, UNKNOWN);
        String syversion = AuthUtils.getReqParamVal(req, URS_SYSTEM_VERSION, UNKNOWN);
        String resolution = AuthUtils.getReqParamVal(req, URS_RESOLUTION, UNKNOWN);
        String productVersion = AuthUtils.getReqParamVal(req, URS_PRODUCT_VERSION, UNKNOWN);
        String mac = AuthUtils.getReqParamVal(req, URS_MAC, UNKNOWN);
        String devType = AuthUtils.getReqParamVal(req, URS_DEVICE_TYPE, UNKNOWN);
        String priKeyHex = (String)req.getAttribute(AccConst.ATTR_PRIVATE_KEY_HEX);
        if (StringUtils.isBlank(pci) && priKeyHex == null) {
            AuthUtils.checkHttpsProtocal(req);
            // web login
            username = AuthUtils.getReqVal(req, URS_USERNAME);
            password = AuthUtils.getReqVal(req, URS_PASSWORD);
        } else {
            String info = null;
            if (priKeyHex != null) {
                String alogrithm = (String)req.getAttribute(AccConst.ATTR_ALOGRITHM);
                info = CipherUtils.decryptInfo(req, alogrithm, priKeyHex);
            } else {
                info = CipherUtils.decryptInfo(req, pci);
            }
            Map<String, String> infoMap = AuthUtils.genInfoMap(info);
            username = infoMap.get(URS_USERNAME);
            password = infoMap.get(URS_PASSWORD);
            LOG.info(String.format("username: %s and password: %s is using http URS login",username, SecurityUtils.secretString(password)));
        }
        // init 

        params.add(new Parameter(URS_PRODUCT, ursProductName));
        params.add(new Parameter(URS_PRODUCT_VERSION, productVersion));
        params.add(new Parameter(URS_MAC, mac));
        params.add(new Parameter(URS_DEVICE_TYPE, devType));
        params.add(new Parameter(URS_SYSTEM_NAME, syname));
        params.add(new Parameter(URS_SYSTEM_VERSION, syversion));
        params.add(new Parameter(URS_RESOLUTION, resolution));
        HttpResponse response = null;
        String result = null;
        AccHttpClient client = AccHttpClient.getInstance();
        try {
            response = client.doGet(initUrl, null, params);
            result = parseResponse(response, AccExpType.URS_TOKEN_INIT_EXCPTION);
        } finally {
            AccHttpClient.closeQuiet(response);
        }
        String id = null;
        String key = null;

        String[] infos = result.split("&");
        id = infos[0].split("=")[1];
        key = infos[1].split("=")[1];

        // safe login
        // for other server inner-call
        String requestIP = AuthUtils.getRequestIPIncludeInner(req);
        String param = AuthUtils
                .aesEncrypt(key, new Parameter(URS_USERNAME, username),
                        new Parameter(URS_PASSWORD, password), new Parameter(URS_USERIP, requestIP),
                        new Parameter("passtype", "0"));
        params.clear();
        params.add(new Parameter(URS_ID, id));
        params.add(new Parameter(URS_PARAMS, param.toUpperCase()));
        try {
            response = client.doGet(safeLoginUrl, null, params);
            result = parseResponse(response, AccExpType.URS_TOKEN_SAFE_LOGIN_EXCPTION);
        } finally {
            AccHttpClient.closeQuiet(response);
        }
        String token = null;
        String[] resultOfSafeLogin = result.split("=");
        String info = AuthUtils.aesDecryptString(resultOfSafeLogin[1], key);
        Map<String, String> infoMap = AuthUtils.genInfoMap(info);
        token = infoMap.get(URS_TOKEN);
        TpToken tp = new TpToken();
        final String ursUserId = getUserId(infoMap.get(URS_USERNAME));
        tp.userId = ursUserId;
        tp.setExpiredTime(-1L);
        tp.token = token;
        tp.secret = key;
        tp.ip = requestIP;
        tp.product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        tp.app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
        tp.verifierName = NAME;
        tp.setProperty(URS_ID, id);
        
        if (StringUtils.isBlank(tp.userId)) {
            throw new AccException("userid is Empty?", AccExpType.URS_TOKEN_SAFE_LOGIN_EXCPTION);
        }
        if (AuthUtils.getReqBoolean(req, AccConst.PARAM_URS_MEMORY_COOKIE, false)) {
            // gen urs session cookie
            genURSMemoryCompleteTpToken(getSessCookieValue(tp),tp);
        } else {
            TokenUtils.genCompleteTpToken(this, tp);
        }

        UserInfoWritable userInfo = genUserInfo(ursUserId, NAME);

        store.writeUserInfo(userInfo);
        Map<String, Object> returnInfo = new HashMap<String, Object>();
        userInfo.putInfoMap(returnInfo);

        AccCookies cookies = TokenUtils.tpTokenGenCookie(req, resp, returnInfo, tp);
        // write persist cookie into resultInfo 
        shouldPutPersTokenInReturnInfo(returnInfo, cookies.getProduct(), tp.app, cookies.getPerTokenV2());

        return returnInfo;

    }

    private static final String DOMAIN_163 = "@163.com";
    private String getUserId(String usernameUrs) {
        if (usernameUrs.indexOf("@") != -1) {
            return usernameUrs;
        } else {
            return usernameUrs + DOMAIN_163;
        }
    }

    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        String token = thirdPartyTokens.get(AccConst.TOKEN);
        String id = thirdPartyTokens.get(AccConst.OPEN_ID);
        String ip = thirdPartyTokens.get(AccConst.IP_ADDRESS);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(URS_TOKEN, token));
        params.add(new Parameter(URS_ID, id));
        params.add(new Parameter(URS_USERIP, ip));
        HttpResponse resp = null;
        String result = null;
        try {
            resp = AccHttpClient.getInstance().doGet(verifierUrl, null, params);
            result = parseResponse(resp, AccExpType.URS_TOKEN_VERIFIER_EXCPTION);
        } finally {
            AccHttpClient.closeQuiet(resp);
        }

        String username = null;

        // username=&loginTime=&product=

        int andIndex = result.indexOf("&");
        int equalIndex = result.indexOf("=");
        username = result.substring(equalIndex + 1, andIndex);

        if (StringUtils.isBlank(username)) {
            throw new AccException("username is null ", AccExpType.URS_TOKEN_VERIFIER_EXCPTION);
        }
        if (username.indexOf('@') < 0) {
            username += "@163.com";
        }
        return genUserInfo(username, NAME);
    }

    @SuppressWarnings("unused")
    private String getValDef(Map<String, String> map, String key, String defaultVal) {
        String value = map.get(key);
        if (value == null) {
            return defaultVal;
        }
        return value;
    }

    @Override
    public void remove(TpToken tpToken) throws AccException {
        if (!tpToken.verifierName.equals(NAME)) {
            throw new AccException(tpToken.verifierName + " is not equals with " + NAME,
                    AccExpType.VERIFIER_MISS_MATCH_TOKEN);
        }
        String token = tpToken.token;
        if (StringUtils.isBlank(token)) {
            SessionCookieWritable sessCookieWritable = store.readSessCookie(tpToken.sessIndex);
            if (sessCookieWritable == null) {
                // not exist
                return;
            }
            tpToken = sessCookieWritable.getTpToken();
            token = tpToken.token;
        }
        String id = tpToken.getProperty(URS_ID);
        String key = tpToken.secret;
        String param = AuthUtils.aesEncrypt(key, new Parameter(URS_TOKEN, token));
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(URS_ID, id));
        params.add(new Parameter(URS_PARAMS, param));
        HttpResponse resp = null;
        try {
            resp = AccHttpClient.getInstance().doGet(removeUrl, null, params);
            parseResponse(resp, AccExpType.URS_TOKEN_REMOVE_EXCPTION, 200);
        } finally {
            AccHttpClient.closeQuiet(resp);
        }
    }
    
    private static String parseResponse(HttpResponse resp, AccExpType type, int successCode) throws AccException {
        int statusCode = resp.getStatusLine().getStatusCode();
        Throwable ex = null;
        if (statusCode == 200) {
            String content = AuthUtils.getStringResponse(resp);
            String[] result = content.split("\n");
            int code = 0;
            try {
                code = Integer.parseInt(result[0].trim());
            } catch (Exception e) {
                throw new AccException(AccExpType.LOGIC_ERROR, e, "return content:%s",content);
            }
            if (code != successCode) {
                
                throw new AccException(type, ex, code, "error code:%s, return content: %s.", code, content);
            } else {
                // Some result may be null.
                if (result.length >= 4) {
                    return result[3];
                } else {
                    return null;
                }
            }

        } else {
            throw new AccException(
                    AccExpType.URS_TOKEN_URL_EXCEPTION, ex,statusCode,"error status code:%s.",statusCode);
        }
    }

    private static String parseResponse(HttpResponse resp, AccExpType type) throws AccException {
        return parseResponse(resp, type, 201);
    }

    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp,
            String token, long expiredTime) throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expiredTime);
        // set access token
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        TpToken tpToken = tokenWritable.getTpToken();
        thirdPartyTokens.put(AccConst.TOKEN, tpToken.token);
        thirdPartyTokens.put(AccConst.OPEN_ID, tpToken.getProperty(URS_ID));
        thirdPartyTokens.put(AccConst.IP_ADDRESS, AuthUtils.getRequestIP(req));
        
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        userInfo.putInfoMap(result);
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        return result;
    }

    private static final String NAME_COOKIE = "cookie";

    public Map<String, String> getUrsCookieBySessionCookie(SessionCookieWritable sess, HttpServletRequest req,
            HttpServletResponse resp) throws AccException {
        final TpToken tpToken = sess.getTpToken();
        if (StringUtils.isBlank(tpToken.token) && tpToken.sessIndex.startsWith(AccConst.URS_MEMORY_CHECK)) {
            // usr cookie wapper, decode it and get sessCookie.
            WapperURSCookieInfo cookieInfo = UrsUtils.getInfoFromCookieValue(tpToken.sessIndex);
            Map<String,String> map = new HashMap<String, String>();
            map.put(UrsUtils.NTES_SESS, cookieInfo.sessCookieVal);
            
            return map;
        }
        return getSessCookie(tpToken, false);
    }

    private Map<String, String> getSessCookie(final TpToken tpToken, boolean removeSession) throws AccException {
        String token = tpToken.token;
        if (removeSession && StringUtils.isNotBlank(tpToken.sessIndex)
                && tpToken.sessIndex.startsWith(AccConst.URS_MEMORY_CHECK)) {
            // remove old one
            store.removeSessIndexOnly(tpToken.sessIndex);
        }
        String id = tpToken.getProperty(URS_ID);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(URS_ID, id));
        params.add(new Parameter(URS_TOKEN, token));
        HttpResponse response = null;
        String result = null;
        Map<String,org.apache.http.cookie.Cookie> cookies = null;
        try {
            response = AccHttpClient.getInstance().doGet(sessUrl, null, params);
            cookies = AuthUtils.extractCookieHeader(response);
            result = parseResponse(response, AccExpType.URS_TOKEN_GET_SESS_EXCPTION);
        } finally {
            AccHttpClient.closeQuiet(response);
        }
        Map<String, String> resultMap = AuthUtils.parseQuery(result);
        /**
         * username=abc&cookie=sfasfsaf&loginTime=&product=
         * If user is abc@163.com, username will be abc
         * If user is abc@126.com, username will be abc@126.com
         */
        final String cookieValue = resultMap.get(NAME_COOKIE);
        if (cookies != null && cookies.size() >= 3 && ursProductName.equals(resultMap.get(URS_PRODUCT)) && StringUtils.isNotBlank(cookieValue)) {
            resultMap.put(UrsUtils.NTES_SESS, cookies.get(UrsUtils.NTES_SESS).getValue());
            resultMap.put(UrsUtils.S_INFO, cookies.get(UrsUtils.S_INFO).getValue());
            resultMap.put(UrsUtils.P_INFO, cookies.get(UrsUtils.P_INFO).getValue());
        } else {
            boolean isEmpty = StringUtils.isNotBlank(cookieValue);
            resultMap.remove(NAME_COOKIE);
            throw new AccException(
                    String.format(
                            "Can not get valid sess cookie. \n" +
                            "product or username or cookie information is error. \n" +
                            "result:%s (has removed cookie value, cookieValue is empty: %s), token product is %s.",
                            resultMap, isEmpty, tpToken.product), AccExpType.URS_TOKEN_GET_SESS_EXCPTION);
        }
        return resultMap;
    }
    
    public String getSessCookieValue(final TpToken tpToken) throws AccException {
        Map<String, String> map = getSessCookie(tpToken, true);
        return map.get(UrsUtils.NTES_SESS);
    }
    
    public static final String SESS_COOKIE_VALUE = "sessCookieVal";
    
    public static final String SIGN_STRING = "YnoyoudAo";
    public TpToken genURSMemoryCompleteTpToken(String ursSessCookieValue, TpToken tp) throws AccException {
        if (StringUtils.isBlank(ursSessCookieValue)) {
            throw new AccException("session cookie value is empty.", AccExpType.URS_TOKEN_GET_SESS_EXCPTION);
        }
        TokenUtils.encode(this, tp);
        
        tp.sessIndex = generateURSMemorySessVal(ursSessCookieValue, tp, this.getSessAliveTime());
        tp.setSessAliveTime(this.getSessAliveTime());
        return tp;
    }
    
    public static String generateURSMemorySessVal(String ursSessCookieValue, TpToken tp, long sessAliveTime) {
        StringBuilder sb = new StringBuilder(AccConst.URS_MEMORY_CHECK);
        sb.append(tp.product).append(TokenUtils.SPLIT_CHARS).append(tp.userId).append(TokenUtils.SPLIT_CHARS)
                .append(tp.verifierName).append(TokenUtils.SPLIT_CHARS).append(ursSessCookieValue)
                .append(TokenUtils.SPLIT_CHARS).append(sessAliveTime);
        final String baseString = sb.toString();
        String sign = AuthUtils.sign(baseString, SIGN_STRING);
        return baseString + TokenUtils.SPLIT_CHARS + sign;
    }
    
    public static void checkSign(String cookieValue) throws AccException {
        
        int index = cookieValue.lastIndexOf(TokenUtils.SPLIT_CHARS);
        if (index == -1) {
            throw new AccException("cookie value is fake. value:"+cookieValue, AccExpType.FAKE_TOKEN);
        }
        String sign = cookieValue.substring(index + TokenUtils.SPLIT_CHARS.length());
        String base = cookieValue.substring(0, index);
        String computeSign = AuthUtils.sign(base, SIGN_STRING);
        if (!computeSign.equals(sign)) {
            throw new AccException("sign error.", AccExpType.FAKE_TOKEN);
        }
    }
}
