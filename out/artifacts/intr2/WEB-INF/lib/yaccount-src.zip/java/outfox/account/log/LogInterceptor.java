/**
 * @(#)VaqueroInterceptor.java, 2012-2-1. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.log;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.utils.SecurityUtils;
import outlog.http.RequestLogger;
import account.app.CheckFilter;
/**
 * @author chen-chao
 */
public class LogInterceptor extends HandlerInterceptorAdapter {
    private static final Log LOG = LogFactory.getLog(LogInterceptor.class);
    
    private static final String ATTRIBUTE_HTTP_COST = "Cost";
    private static final String ATTRIBUTE_HTTP_EXCEPTIONAL = "Exceptional";
    private static final String ATTRIBUTE_HTTP_EXCEPTION_NAME = "ExName";
    public static final String IDENTIFICATION_STRING = "@@ANALYSIS@@";
    public static final String HTTP_REQUEST_START_TIMESTAMP = "Start_TimeStamp";
    private RequestLogger analyzerLog = new RequestLogger();
    private boolean enableAnalyzer = false;
    private boolean enableVaquero = false;
    private static final String PRODUCT_NAME = AccConfig.getPros().getString(AccConfig.NAME_ANALYZER_PRODUCT_NAME);
    private Set<String> visibleAttributes = new HashSet<String>();

    private Set<String> unloggedParameters = new HashSet<String>();
    public void setVisibleAttributes(List<String> visibleAttributes) {
        this.visibleAttributes = new HashSet<String>();
        if (visibleAttributes != null) {
            for (String attr : visibleAttributes) {
                this.visibleAttributes.add(attr);
            }
        }
    }

    public void setUnloggedParameters(List<String> unloggedParameters) {
        this.unloggedParameters = new HashSet<String>();
        if (unloggedParameters != null) {
            for (String param : unloggedParameters) {
                this.unloggedParameters.add(param);
            }
        }
    }
    public void setSinkAddr(String addrString) {
        analyzerLog.setSinkAddr(addrString);
    }
    
    public void init() {
        enableAnalyzer = AccConfig.getPros().getBoolean(AccConfig.NAME_ENABLE_ANALYZER);
        enableVaquero = AccConfig.getPros().getBoolean(AccConfig.NAME_ENABLE_VAQUERO);
        if (enableVaquero){
            LOG.info("vaquero log init");
        }
        addNewAttributeName(ATTRIBUTE_HTTP_COST, ATTRIBUTE_HTTP_EXCEPTIONAL, ATTRIBUTE_HTTP_EXCEPTION_NAME, AccConst.ATTR_NICK_NAME);
        if (enableAnalyzer){
            analyzerLog.setUserNameAttributeName(CheckFilter.EMAIL_ATTR);
            analyzerLog.setProductName(PRODUCT_NAME);
            String sinkAddress = AccConfig.getPros().getString(AccConfig.NAME_ANALYZER_SINK_ADDRESS);
            if (StringUtils.isBlank(sinkAddress)){
                enableAnalyzer = false;
                return;
            }
            analyzerLog.setSinkAddr(sinkAddress);
            analyzerLog.init();
            LOG.info("anaylzer log init");
        }
    }

    @Override
    public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler) throws Exception {
        request.setAttribute(HTTP_REQUEST_START_TIMESTAMP, System
                .currentTimeMillis());
        return super.preHandle(request, response, handler);
    }

    private void addNewAttributeName(String ...names){
        for (String name: names) {
            if (!visibleAttributes.contains(name)){
                visibleAttributes.add(name);
            }
        }
        // reset visible attribute
        List<String> attr = new ArrayList<String>(visibleAttributes);
        analyzerLog.setVisibleAttributes(attr);
    }
    
    @Override
    public void afterCompletion(HttpServletRequest request,
            HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        try {
            Object name = request.getAttribute(AccConst.REQUEST_NAME);
            if (name == null) {
                return;
            }
            Long start = (Long) request.getAttribute(HTTP_REQUEST_START_TIMESTAMP);
            long cost = System.currentTimeMillis() - start;
            request.setAttribute(ATTRIBUTE_HTTP_COST, cost);
            boolean exStat = (ex != null);
            request.setAttribute(ATTRIBUTE_HTTP_EXCEPTIONAL, exStat);
            StringBuilder log = new StringBuilder();
            log.append("request:").append(SecurityUtils.escapeSecurityQuery(request));
            if (exStat) {
                log.append(" error:").append(ex.getClass().getName());
                ErrorLogger.print(log.toString(), ex);
                
                if (ex instanceof AccException) {
                    request.setAttribute(ATTRIBUTE_HTTP_EXCEPTION_NAME, ((AccException) ex).getExceptionType()
                            .getName());
                } else {
                    request.setAttribute(ATTRIBUTE_HTTP_EXCEPTION_NAME, ex.getClass().getName());
                }
            }
            
            SessionLogger.print(request, log.toString(), ex);
            if (enableVaquero){
                LOG.info(IDENTIFICATION_STRING + " " + name + ".cost=" + cost);
                LOG.info(IDENTIFICATION_STRING + " " + name + ".ex=" + exStat);
            }
            if (enableAnalyzer){
                analyzerLog.log((String) name, request, response);
            }
            FakeAnalyzerLog.print((String) name, request, response, visibleAttributes, unloggedParameters);
        } catch(Exception e) {
            SessionLogger.print(e);
        }
    }
}
