/**
 * @(#)AccCookies.java, 2012-9-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.mortbay.log.Log;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.LOGIN_STAT;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.TokenUtils;
import outfox.account.utils.AuthUtils;

/**
 * Stores all cookies of product. A set for multi-cookies.
 * @author chen-chao
 */
public class AccCookies implements Serializable{
    private static final long serialVersionUID = -5813497682203134501L;

    protected static final int MAX_AGE = AccConfig.getPros().getInt(AccConfig.NAME_COOKIE_PRESIST_MAX_AGE);
    private Map<String, Cookie> cookies;
    private String product;
    private String domain;
    private String path;
    private String app;
    private int loginInfo;
    private boolean notSendToResponse;


    private String sessCookieName;
    private String bindCookieName;
    private String persCookieName;
    
    public AccCookies(String product, HttpServletRequest req) {
        this(product, AuthUtils.getCookieDomain(req),
                AccConst.URL_ROOT, AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME, AccConfig.CLIENT_TYPE_PC));
    }
    
    public AccCookies(HttpServletRequest req) {
        this(AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME), AuthUtils.getCookieDomain(req),
                AccConst.URL_ROOT, AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME, AccConfig.CLIENT_TYPE_PC));
    }
    
    public AccCookies(String product, HttpServletRequest req, String app) {
        this(product, AuthUtils.getCookieDomain(req),
                AccConst.URL_ROOT, app);
    }

    public AccCookies(String product, String domain, String path, String app) {
        this.domain = domain;
        this.path = path;
        this.app = app;
        this.loginInfo = 0;
        cookies = new HashMap<String, Cookie>(8);
        setProduct(product);
    }

    public boolean isNotSendToResponse() {
        return notSendToResponse;
    }

    public void setNotSendToResponse(boolean notSendToResponse) {
        this.notSendToResponse = notSendToResponse;
    }
    public String getApp() {
        return app;
    }

    public void setProduct(String product) {
        this.product = product;
        sessCookieName = getSessCookieName(product);
        bindCookieName = getBindCookieName(product);
        persCookieName = getPersCookieName(product);
    }
    
    public String getProduct() {
        return product;
    }
    
    public void addCookieToResponse(HttpServletResponse resp) {
        if (notSendToResponse) {
            return;
        }
        resp.addHeader("P3P",
                "CP=\"CAO CONi ONL OUR\"");
        cookieToResponse(resp);
        
        resp.addCookie(genShadowCookie());
    }
    
    private void genLoginInfo() {
        Cookie cookie = cookies.get(sessCookieName);
        shadowCookieValue(cookie, LOGIN_STAT.sess);
        if (AuthUtils.isWeb(app)) {
            cookie = cookies.get(persCookieName);
            shadowCookieValue(cookie, LOGIN_STAT.pers);
        }
        cookie = cookies.get(bindCookieName);
        shadowCookieValue(cookie, LOGIN_STAT.bind);
    }

    private void cookieToResponse(HttpServletResponse resp) {
        addV2Cookie(sessCookieName, resp);
        
        if (AuthUtils.isWeb(app)) {
            addV2Cookie(persCookieName, resp);
        }
        addV2Cookie(bindCookieName, resp);
    }

    protected void addV2Cookie(String cookieName, HttpServletResponse resp) {
        Cookie cookie;  
        cookie = cookies.get(cookieName);
        if (cookie != null) {
            Cookie tmp = (Cookie)cookie.clone();
            tmp.setValue(AccConst.V2_FLAG+cookie.getValue());
            resp.addCookie(tmp);
        }
    }
    
    public void cleanAllCookiesInResponse(HttpServletResponse resp) {

        resp.addCookie(AuthUtils.genCookie(getSessCookieName(product), "", domain, path, 0, true));
        resp.addCookie(AuthUtils.genCookie(getPersCookieName(product), "", domain, path, 0, true));
        resp.addCookie(AuthUtils.genCookie(getBindCookieName(product), "", domain, path, 0, true));
        resp.addCookie(AuthUtils.genCookie(getKeepTokenCookieName(product), "false", domain, path, 0, false));
        loginInfo = 0;
        forceLogin(true);
        resp.addCookie(genShadowCookie());
    }
    
    public int relogin(boolean isRelogin) {
        return isRelogin ? (loginInfo = LOGIN_STAT.relogin.add(loginInfo))
                : (loginInfo = LOGIN_STAT.relogin.remove(loginInfo));
    }
    
    public int forceLogin(boolean isforce) {
        return isforce ? (loginInfo = LOGIN_STAT.forcelogin.add(loginInfo))
                : (loginInfo = LOGIN_STAT.forcelogin.remove(loginInfo));
    }
    
    public int reBind(boolean isRebind) {
        return isRebind ? (loginInfo = LOGIN_STAT.rebind.add(loginInfo))
                : (loginInfo = LOGIN_STAT.rebind.remove(loginInfo));
    }
    
    private int shadowCookieValue(Cookie cookie, LOGIN_STAT stat) {
        
        if (cookie ==null || cookie.getMaxAge() == 0) {
            loginInfo = stat.remove(loginInfo);
        } else {
            loginInfo = stat.add(loginInfo);
        }
        return loginInfo;
    }
    
    /**
     * Shadow cookie has the same life cycle with session cookie, but it's not 
     * HttpOnly. Client can read its value to know login status which indicated 
     * by {@code LOGIN_STAT} and when session cookie is created.
     * @return
     */
    public Cookie genShadowCookie() {
        genLoginInfo();
        int maxAge = -1;
        if (loginInfo == 0) {
            maxAge = 0;
        }
        String cookieValue = Integer.toString(loginInfo) + 
                TokenUtils.SPLIT_CHARS + System.currentTimeMillis();
        return AuthUtils.genCookie(getLoginCookieName(product), cookieValue, 
                domain, path, maxAge, false);
    }
    
    /**
     * Check whether to force login by shadow cookie's value.
     * Shadow cookie's content can be (YNOTE_LOGIN = true) or 
     * (YNOTE_LOGIN = true||timestamp) or 
     * (YNOTE_LOGIN = int) or 
     * (YNOTE_LOGIN = int||timestamp)
     * @param shadowCookie
     * @return
     */
    public static boolean isForceLoginByShadowCookie(Cookie shadowCookie) {
        // remove tailing timestamp if it exists.
        String cookieValue = shadowCookie.getValue();
        int splitCharIndex = -1;
        if ((splitCharIndex = cookieValue.indexOf(TokenUtils.SPLIT_CHARS)) != -1 ) {
            cookieValue = cookieValue.substring(0, splitCharIndex);
        }
        int loginVal = LOGIN_STAT.forcelogin.value();
        try {
            loginVal = Integer.parseInt(cookieValue);
        }catch(Exception e) {
            // maybe old cookie.(YNOTE_LOGIN = true), force login to get new cookie.
        }
        return LOGIN_STAT.forcelogin.isContainedIn(loginVal);
    }
    
    public Cookie genPersCookie(String value, long expiredTime) {
        if (expiredTime < 0) {
            expiredTime = MAX_AGE;
        }
        Cookie cookie = AuthUtils.genCookie(persCookieName, value, domain, path,
                AuthUtils.milliApproxSecond(expiredTime), true);
        cookies.put(persCookieName, cookie);
        loginInfo = LOGIN_STAT.pers.add(loginInfo);
        return cookie;
    }
    
    public String getPerToken() {
        Cookie cookie = cookies.get(persCookieName);
        return cookie == null ? null : cookie.getValue();
    }
    
    public String getPerTokenV2() {
        Cookie cookie = cookies.get(persCookieName);
        return cookie == null ? null : AccConst.V2_FLAG+cookie.getValue();
    }
    
    public Cookie genSessCookie(String value){
        Cookie cookie = AuthUtils.genCookie(sessCookieName, value, domain, path, -1, true);
        cookies.put(sessCookieName, cookie);
        loginInfo = LOGIN_STAT.sess.add(loginInfo);
        return cookie;
    }
    public Cookie genBindCookie(String value){
        Cookie cookie = AuthUtils.genCookie(bindCookieName, value, domain, path, -1, true);
        cookies.put(bindCookieName, cookie);
        loginInfo = LOGIN_STAT.bind.add(loginInfo);
        return cookie;
    }
    
    /**
     * This cookie is created in cross step only. The cookie value is true always.
     * If the cookie is exist, the reset interface will not remove token.
     * The cookie is not http-only.
     * @param value
     * @return
     */
    public Cookie genKeepTokenCookie() {
        return AuthUtils.genCookie(getKeepTokenCookieName(product), "true", domain, path, -1, false);
    }
    
    public Cookie getPersCookie() {
        return cookies.get(persCookieName); 
    }
    
    public Cookie getSessionCookie() {
        return cookies.get(sessCookieName); 
    }
    
    public Cookie getBindCookie() {
        return cookies.get(bindCookieName); 
    }
    
    public void setSessCookie(Cookie sessCookie) {
        if (sessCookie == null) {
            loginInfo = LOGIN_STAT.sess.remove(loginInfo);
        } else {
            loginInfo = LOGIN_STAT.sess.add(loginInfo);
        }
        cookies.put(sessCookieName, sessCookie);
    }
    public void setBindCookie(Cookie bindCookie) {
        if (bindCookie == null) {
            loginInfo = LOGIN_STAT.bind.remove(loginInfo);
        } else {
            loginInfo = LOGIN_STAT.bind.add(loginInfo);
        }
        cookies.put(bindCookieName, bindCookie);
    }
    
    public void setPersCookie(Cookie persCookie) {
        if (AuthUtils.isWeb(app)) {
            if (persCookie == null) {
                loginInfo = LOGIN_STAT.pers.remove(loginInfo);
            } else {
                loginInfo = LOGIN_STAT.pers.add(loginInfo);
            }
        }
        cookies.put(persCookieName, persCookie);
    }
    
    private void setCookie(Cookie cookie, String cookieProduct, String cookiePostfix) {
        if (!cookieProduct.equals(product)) {
            throw new AccRunTimeException("product is not match cookieProduct:" + cookieProduct + " self product:" + product);
        }
        if (AccConst.COOKIE_PERSISTENT.equals(cookiePostfix)) {
            if (StringUtils.isBlank(app)) {
                app = AccConfig.CLIENT_TYPE_WEB;
            } else if (!AuthUtils.isWeb(app)) {
                Log.warn("cookie error. Persist cookie is in other client-type. It only be used in web");
                return;
            }
            setPersCookie(cookie);
        } else if (AccConst.COOKIE_SESSION.equals(cookiePostfix)) {
            setSessCookie(cookie);
        } else if (AccConst.COOKIE_SESSION_BIND.equals(cookiePostfix)) {
            setBindCookie(cookie);
        }
    }
    
    
    public static String getLoginCookieName(String product){
        return product + AccConst.COOKIE_LOGIN;
    }
    public static String getSessCookieName(String product) {
        return product + AccConst.COOKIE_SESSION;
    }
    public static String getPersCookieName(String product) {
        return product + AccConst.COOKIE_PERSISTENT;
    }
    
    public static String getBindCookieName(String product) {
        return product + AccConst.COOKIE_SESSION_BIND;
    }
    
    public static String getKeepTokenCookieName(String product){
        return product + AccConst.COOKIE_KEEP_TOKEN;
    }
    
    public byte[] toBytes() throws AccException {
        return AuthUtils.obj2bytes(this);
    }
    
    public static CacheInfo byte2CacheInfo(byte[] bytes) throws AccException {
        return (CacheInfo) AuthUtils.byte2Obj(bytes, CacheInfo.class);
    }

    /**
     * extract yaccount project cookies. 
     * many products cookies are mixed.
     * @param req
     * @return
     */
    public static Map<String,AccCookies> extractCookies(HttpServletRequest req) {
        Map<String, AccCookies> map = new HashMap<String, AccCookies>();
        for (Cookie cookie : req.getCookies()) {
            int index = cookie.getName().indexOf("_");
            if (index > 0) {
                String postfix = cookie.getName().substring(index);
                String product = cookie.getName().substring(0, index);
                
                if (AuthUtils.isContain(postfix) && AccConfig.getProductSet().contains(product)) {
                    AccCookies cookies = map.get(product);
                    if (cookies == null) {
                        cookies = new AccCookies(product, AuthUtils.getCookieDomain(req), AccConst.URL_ROOT,
                                AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME));
                        cookies.setProduct(product);
                        cookies.setCookie(cookie, product, postfix);
                    } else {
                        cookies.setCookie(cookie, product, postfix);
                    }
                    map.put(product, cookies);
                }
            }
        }
        return map;
    }
    /**
     * extract yaccount project cookies with special product.
     * @param req
     * @return
     */
    public static AccCookies extractCookies(HttpServletRequest req, String product) {
        AccCookies cookies = new AccCookies(product, AuthUtils.getCookieDomain(req), AccConst.URL_ROOT,
                req.getParameter(AccConst.PARAM_APP_NAME));
        Cookie[] reqCookies = req.getCookies();
        if (reqCookies == null) {
            return cookies;
        }
        for (Cookie cookie : reqCookies) {
            int index = cookie.getName().indexOf("_");
            if (index > 0) {
                String postfix = cookie.getName().substring(index);
                String cookieProduct = cookie.getName().substring(0, index);
                
                if (AuthUtils.isContain(postfix) && product.equals(cookieProduct)) {
                    cookies.setCookie(cookie, cookieProduct, postfix);
                }
            }
        }
        return cookies;
    }
    
    public boolean isLogin() {
        return isSess() || isPers(); 
    }
    
    public boolean isPers() {
        return (LOGIN_STAT.pers.isContainedIn(loginInfo) && (cookies.get(persCookieName) != null));
    }
    
    public boolean isSess() {
        return LOGIN_STAT.sess.isContainedIn(loginInfo) && (cookies.get(sessCookieName) != null);
    }
    
    public boolean isRelogin() {
        return LOGIN_STAT.relogin.isContainedIn(loginInfo);
    }
    public boolean isBind() {
        return LOGIN_STAT.bind.isContainedIn(loginInfo) && (cookies.get(bindCookieName) != null);
    }
    public boolean isRebind() {
        return LOGIN_STAT.rebind.isContainedIn(loginInfo);
    }
    public boolean isForceLogin() {
        return LOGIN_STAT.forcelogin.isContainedIn(loginInfo);
    }
    
    public int getLoginInfo() {
        return loginInfo;
    }
}
