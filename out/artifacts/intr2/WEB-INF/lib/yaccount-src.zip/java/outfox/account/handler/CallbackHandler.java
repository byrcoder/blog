/**
 * @(#)CallbackHandler.java, 2012-9-11. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.CookieIndex;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenManager;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;

/**
 * for third party callback
 * @author chen-chao
 *
 */
@Controller
public class CallbackHandler extends BaseHandler {
    private static final long serialVersionUID = -3865064213366162074L;

    /**
     * /login/acc/callback?code=
     * 
     * @throws AccException
     */
    @RequestMapping(AccConst.CALLBACK_URL)
    public void callback(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        // get params
        setName(req, "callback");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        OAuth2Utils.checkStat(req);
        String queryString = OAuth2Utils.getQueryAttribute(req, resp);
        if (queryString == null) {
            throw new AccException("no query attribute?", AccExpType.QUERY_ATTRUBITE_MISSING);
        }
        HashMap<String, String> querytable = AuthUtils.parseQuery(queryString);
        String product = querytable.get(AccConst.PARAM_PRODUCT_NAME);
        AccConfig.checkProduct(product);
        
        String pc = getPc(querytable);
        req.setAttribute(AccConst.ATTR_PC_NAME, pc);
        for (Entry<String, String> entry : querytable.entrySet()) {
            req.setAttribute(entry.getKey(), entry.getValue());
        }
        
        Map<String,Object> response = TokenManager.genAuthToken(req, resp);
        List<Parameter> params = AuthUtils.convertMap2List(response);
        
        //Remove Query Attribute here
        HttpSession session = null;
        try {
            session = req.getSession(false);
        } catch (Exception e) {
            LOG.warn(e, e);
        } finally {
            if (session != null) {
                session.removeAttribute(AccConst.ATTR_QUERY);
            }
        }        
        
        if (AuthUtils.isWeb(req)
           && AuthUtils.getReqVal(req, AccConst.PARAM_FORCE_REDIRECT) == null) {
            write(req, resp, params, HttpStatus.OK);
        } else {
            String tp = querytable.get(AccConst.PARAM_THIRD_PARTY_NAME);
            String redirectUrl = (String) req.getSession().getAttribute(AccConst.PARAM_REDIRECT_URL_NAME);
            if (StringUtils.isNotBlank(redirectUrl)) {
                safeRedirect(redirectUrl, resp);
            } else {
                // not web or no force redirect parameter, only redirect
                safeRedirect(req, resp, generateRedirectUrl(AccConst.LOGIN_DONE_LOCATION, product, tp, true, null));
            }            
        }
    }
    
    private String getPc(HashMap<String, String> querytable) throws AccException {
        String pci = querytable.get(AccConst.PARAM_PCINDEX_NAME);
        String app = querytable.get(AccConst.PARAM_APP_NAME);
        if (pci == null) {
            if (AccConfig.CLIENT_TYPE_WEB.equals(AccConfig.getMappingType(app))) {
                // web application
                return AuthUtils.genUniqueToken();
            } else {
                throw new AccException("pci is empty.", AccExpType.PCI_NOT_EXIST);
            }
        }
        // TODO change to get/remove two step
        //TODO: should use decode3 when al parameter is given?
        CookieIndex index = CookieIndex.decode2(GlobalCache.getInstance().remove(pci));
        if (index == null) {
            throw new AccException("no exist pci.", AccExpType.PCI_NOT_EXIST);
        }
        HashMap<String, String> reqPCIQueryTable = AuthUtils.parseQuery(index.msg);
        checkQueryEquals(app, reqPCIQueryTable.get(AccConst.PARAM_APP_NAME));
        checkQueryEquals(querytable.get(AccConst.PARAM_THIRD_PARTY_NAME), reqPCIQueryTable.get(AccConst.PARAM_THIRD_PARTY_NAME));
        checkQueryEquals(querytable.get(AccConst.PARAM_PRODUCT_NAME), reqPCIQueryTable.get(AccConst.PARAM_PRODUCT_NAME));
        return index.pc;
    }
    /**
     * if a == b, return true, else return false;
     * @param a
     * @param b
     * @throws AccException 
     */
    private void checkQueryEquals(String a, String b) throws AccException {
        if (a == null ) {
            if (b == null) {
                return;
            } 
        } else if (a.equals(b)) {
            return;
        } 
        throw new AccException("query:" + a +" is not equal with " + b, AccExpType.PARAM_NOT_EQUAL_TAGET_ERROR);
    }
    
}
