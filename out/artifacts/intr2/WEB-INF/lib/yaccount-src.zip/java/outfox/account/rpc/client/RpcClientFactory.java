/**
 * @(#)RpcClientFactory.java, 2012-9-3. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.client;

import java.util.HashMap;

import outfox.account.rpc.protocol.ICacheService;
import outfox.account.rpc.protocol.IRpcVerifierService;

/**
 * @author chen-chao
 */
public class RpcClientFactory {
    private static final HashMap<Class<?>, AccRpcClient> cache =
            new HashMap<Class<?>, AccRpcClient>();
    /**
     * create once
     * @param clazz
     * @return
     */
    public static AccRpcClient getClient(Class<?> clazz) {
        
        AccRpcClient client = null;
        if((client = cache.get(clazz)) == null) {
            synchronized (AccRpcClient.class) {
                if ((client = cache.get(clazz)) == null) {
                    client = initClient(clazz);
                    cache.put(clazz, client);
                }
            }
        }
        return client;
    }
    
    /**
     * thread safe, re-init client.
     * @param clazz
     * @return
     */
    public static synchronized AccRpcClient refresh(Class<?> clazz) {
        AccRpcClient client = initClient(clazz);
        AccRpcClient old = cache.remove(clazz);
        old.stop("refresh");
        cache.put(clazz, client);
        return client;
    }
    
    private static AccRpcClient initClient(Class<?> clazz) {
        if(ICacheService.class.isAssignableFrom(clazz)) {
            return new RpcCacheClient();
        } else if (IRpcVerifierService.class.isAssignableFrom(clazz)){
            return new RpcVerifyClient();
        } else {
            return null;
        }
    }

}
