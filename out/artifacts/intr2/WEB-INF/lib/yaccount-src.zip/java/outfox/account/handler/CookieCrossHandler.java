/**
 * @(#)CookieCrossHandler.java, 2011-9-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.AccCookies;
import outfox.account.data.AuthInfo;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.utils.AuthUtils;
/**
 * <pre>
 * In cross process function:
 * The class is used for replace pc cookies into web cookies (change domain of cookie).
 * And the solution is safer than setting cookie into request parameter.
 * First, client accesses /cross/first url with its cookies and domain. Then client will get a cookie index
 * in server response.
 * Second, client set the cookie index and redirect URL into request parameter (open web-browser) and request
 * /cross/sencod url. redirect URL should contain the /cross/first domain parameter
 * Third, server will set the real cookie into response and redirect to the URL.
 * 
 * 
 * In cross domain function:
 * note.163.com/a.html will use 
 * &lt;script src="login.youdao.com/login/acc/se/cross/domain" &gt;&lt;/script&gt; 
 * </pre>
 * @author chen-chao
 *
 */
@Controller
public class CookieCrossHandler extends BaseHandler{
    private static final long serialVersionUID = -1808253152346260606L;
    private static final Log LOG = LogFactory.getLog(CookieCrossHandler.class);
    private GlobalCache cache;
    private DataStore store;
    public void init(){
        cache = GlobalCache.getInstance();
        store = DataStore.getInstance();
    }
    /**
     * used for cross domain cookie set.
     * use pci param to get cookie in cache, and rewrite cookie
     * into response.
     * @param req
     * @param resp
     * @throws IOException
     */
    @RequestMapping(AccConst.CROSS_COOKIE_DOMAIN_URL)
    protected void cross(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "cross-domain");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        AuthInfo authInfo = checkLogin(req);
        AccCookies accCookies = TokenUtils.genCookieByCookieParam(req, authInfo.tpToken, COOKIE_FORMAT.se.value());
        resp.addHeader("P3P",
                "CP=\"CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR\"");
        accCookies.addCookieToResponse(resp);
        boolean keepToken = AuthUtils.getReqBoolean(req, AccConst.PARAM_KEEP_TOKEN, false);
        if (keepToken) {
            resp.addCookie(accCookies.genKeepTokenCookie());
        }
        int cookieParam = AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value());
        if (COOKIE_FORMAT.info.isContain(cookieParam)) {
            UserInfoWritable userInfo = null;
            if (authInfo.userInfo != null) {
                userInfo = authInfo.userInfo;
            } else {
                userInfo = store.readUserInfo(authInfo.userId);
            }
            if (userInfo == null) {
                throw new AccException("can not get userInfo of userId:"+authInfo.userId, AccExpType.LOGIC_ERROR);
            }
            write(req, resp,userInfo.getInfoMap(), HttpStatus.OK);
        }
    }
    
    /**
     * if session cookie is exist, generate cookie index of the session cookie.
     * And store cookie index into cache. Response cookie index back.
     * @return if session cookie is null, return emtpy string. Else return a non-emtpy cookie index.
     * @param req
     * @param resp
     * @throws IOException
     * @throws AccException 
     */
    @RequestMapping(AccConst.CROSS_PROCESS_FIRST_URL)
    public void first(HttpServletRequest req,
            HttpServletResponse resp) throws AccException {
        setName(req, "cross-process-first");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        AuthInfo authInfo = checkLogin(req);
        LOG.info(String.format("user %s want to cross domain/processor.", authInfo.userId));
        JSONObject ret = new JSONObject();
        String tempIndex = AuthUtils.genUniqueToken(authInfo.tpToken.sessIndex);
        
        ret.put(AccConst.PARAM_PCINDEX_NAME, tempIndex);
        authInfo.removeAllExcludeSessionAndUserInfo();
        
        cache.put(tempIndex, AuthUtils.obj2bytes(authInfo));
        
        writeJSON(req, resp, ret, HttpStatus.OK);
        LOG.info(String.format("user %s cross domain/processor first step DONE.", authInfo.userId));
    }
    
    /**
     * if not add "http://" or "https://", url will be relative url.
     * If error occur, it will redirect to error page.
     * only url in client cookie domain can work. 
     * @param req
     * @param resp
     * @throws IOException
     * @throws AccException 
     */
    @RequestMapping(AccConst.CROSS_PROCESS_SECOND_URL)
    public void second(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "cross-process-second");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkParam(req, AccConst.PARAM_PCINDEX_NAME, NO_MISS);
        String pci = req.getParameter(AccConst.PARAM_PCINDEX_NAME);
        
        byte[] content = cache.remove(pci);
        if (content == null) {
            throw new AccException("request is not correct. pci is not exist.", AccExpType.FAKE_PCI);
        }
        AuthInfo authInfo = (AuthInfo) AuthUtils.byte2Obj(content, AuthInfo.class);
        AccCookies accCookies = TokenUtils.genCookieByCookieParam(req, authInfo.tpToken, COOKIE_FORMAT.se.value());
        accCookies.addCookieToResponse(resp);
        boolean keepToken = AuthUtils.getReqBoolean(req, AccConst.PARAM_KEEP_TOKEN, false);
        if (keepToken) {
            resp.addCookie(accCookies.genKeepTokenCookie());
        }
        safeRedirect(req, resp);
        LOG.info(String.format("user %s cross domain/processor second step DONE.", authInfo.userId));
    }
}
