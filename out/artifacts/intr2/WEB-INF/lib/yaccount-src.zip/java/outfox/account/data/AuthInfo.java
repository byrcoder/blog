/**
 * @(#)AuthTokens.java, 2012-10-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.Serializable;

import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;

/**
 * FOR getting login info or bind info.
 * @author chen-chao
 */
public class AuthInfo implements Serializable{
    private static final long serialVersionUID = -1554630989689626065L;

    public SessionCookieWritable sess;

    public PersistTokenWritable pers;

    public TpToken tpToken;

    public String product;

    public SessionCookieWritable bind;

    public UserInfoWritable userInfo;

    public String userId;
    
    public String bindUserId;

    /**
     * @param product
     * @param sess
     * @param pers
     * @throws AccException 
     */
    public AuthInfo(String product, SessionCookieWritable sess, PersistTokenWritable pers,
            SessionCookieWritable bind, UserInfoWritable loginUserInfo, String userId, String bindUserId) {
        this.product = product;
        this.sess = sess;
        this.pers = pers;
        //TODO: use the same tpToken?
        if (sess != null) {
            this.tpToken = sess.getTpToken();
        }
        if (pers != null) {
            this.tpToken = pers.getTpToken();
        }
        this.bind = bind;
        this.userInfo = loginUserInfo;
        this.userId = userId;
        this.bindUserId = bindUserId;
    }
    
    public boolean isBind() {
        return bind != null;
    }
    
    public boolean isLogin() {
        return sess != null || pers != null;
    }
    
    public void removeAllExcludeSessionAndUserInfo() {
        this.pers = null;
        this.bind = null;
        this.bindUserId = null;
    }
}
