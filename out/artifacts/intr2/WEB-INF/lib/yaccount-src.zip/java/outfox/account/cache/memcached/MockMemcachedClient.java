/**
 * @(#)MockMemcachedClient.java, 2012-10-22. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache.memcached;

import java.net.SocketAddress;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import net.spy.memcached.CASResponse;
import net.spy.memcached.CASValue;
import net.spy.memcached.ConnectionObserver;
import net.spy.memcached.MemcachedClientIF;
import net.spy.memcached.NodeLocator;
import net.spy.memcached.internal.BulkFuture;
import net.spy.memcached.transcoders.Transcoder;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * A Mock memcached client whose underlying implementation is a concurrent
 * hash map. Only a few interfaces of <code>MemcachedClientIF</code> is
 * implemented for unit test.
 * <p>
 * If any of the Unsupported operations are required in the unit test,
 * implements them following the <code>MemcachedClientIF</code> comments.
 *
 * @author licx
 */
public class MockMemcachedClient implements MemcachedClientIF {
    private static final Log LOG = LogFactory.getLog(MockMemcachedClient.class);

    public static final String NAME = "MockMemcachedClient";

    private Object lock = new Object();

    private ConcurrentHashMap<String, CacheItem> cacheMap =
        new ConcurrentHashMap<String, CacheItem>();

    private SortedMap<Long, CacheItem> expireMap = new TreeMap<Long, CacheItem>();

    private static class CacheItem {
        public CacheItem(String key, Object value, long exp) {
            this.key = key;
            this.value = value;
            if (exp != 0) {
                this.expireTime = System.currentTimeMillis()/1000 + exp;
            }
        }

        private String key;
        private Object value;
        private long expireTime;

        private boolean isExpired() {
            return expireTime != 0 && expireTime <= (System.currentTimeMillis()/1000);
        }
    }

    /**
     * Clean thread is executed every seconds and cleans up the expired items. 
     */
    private class CleanThrad extends Thread {
        public void run() {
            synchronized (lock) {
                do {
                    Iterator<CacheItem> iterator = expireMap.values().iterator();
                    while (iterator.hasNext()) {
                        CacheItem item = iterator.next();
                        if (item.isExpired()) {
                            // item expire, remove it from the expire list as well
                            // as cache map
                            iterator.remove();
                            cacheMap.remove(item.key);
                            LOG.debug("Remove expired cache item, key=" + item.key);
                        } else {
                            // expire map is sorted by expire time, so when the item
                            // expire time is greater than current time, just stop
                            break;
                        }
                    }
                    try {
                        lock.wait(1000);
                    } catch (InterruptedException e) {
                    }
                } while(true);
            }
        }
    }

    public MockMemcachedClient() {
        CleanThrad cleanThread = new CleanThrad();
        cleanThread.start();
    }

    /**
     * Clear the cached data in memory
     */
    public void clear() {
        cacheMap.clear();
        expireMap.clear();
    }

    @Override
    public Future<Boolean> add(String key, int exp, Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<Boolean> add(String key, int exp, T o, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean addObserver(ConnectionObserver obs) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Boolean> append(long cas, String key, Object val) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<Boolean> append(long cas, String key, T val,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<CASResponse> asyncCAS(String key, long casId, Object value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<CASResponse> asyncCAS(String key, long casId, T value,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Long> asyncDecr(String key, long by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Long> asyncDecr(String key, int by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Object> asyncGet(String key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<T> asyncGet(String key, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<CASValue<Object>> asyncGetAndTouch(String key, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<CASValue<T>> asyncGetAndTouch(String key, int exp,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public BulkFuture<Map<String, Object>> asyncGetBulk(Iterator<String> keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public BulkFuture<Map<String, Object>> asyncGetBulk(Collection<String> keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public BulkFuture<Map<String, Object>> asyncGetBulk(String... keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> BulkFuture<Map<String, T>> asyncGetBulk(Iterator<String> keys,
            Iterator<Transcoder<T>> tcs) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> BulkFuture<Map<String, T>> asyncGetBulk(Collection<String> keys,
            Iterator<Transcoder<T>> tcs) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> BulkFuture<Map<String, T>> asyncGetBulk(Iterator<String> keys,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> BulkFuture<Map<String, T>> asyncGetBulk(Collection<String> keys,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> BulkFuture<Map<String, T>> asyncGetBulk(Transcoder<T> tc,
            String... keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<CASValue<Object>> asyncGets(String key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<CASValue<T>> asyncGets(String key, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Long> asyncIncr(String key, long by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Long> asyncIncr(String key, int by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public CASResponse cas(String key, long casId, Object value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> CASResponse cas(String key, long casId, int exp, T value,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long decr(String key, long by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long decr(String key, int by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long decr(String key, long by, long def) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long decr(String key, int by, long def) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long decr(String key, long by, long def, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long decr(String key, int by, long def, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Boolean> delete(String key) {
        synchronized (lock) {
            CacheItem item = cacheMap.get(key);
            if (item.expireTime != 0) {
                expireMap.remove(item.expireTime);
            }
            cacheMap.remove(key);
        }
        return new MockFuture<Boolean>() {
            @Override
            public Boolean get() throws InterruptedException,
                    ExecutionException {
                return true;
            }
        };
    }

    @Override
    public Future<Boolean> flush() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Boolean> flush(int delay) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Object get(String key) {
        CacheItem item = cacheMap.get(key);
        if (item == null || item.isExpired()) {
            return null;
        }
        return item.value;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T get(String key, Transcoder<T> tc) {
        CacheItem item = cacheMap.get(key);
        if (item == null || item.isExpired()) {
            return null;
        }
        return (T)item.value;
    }

    @Override
    public CASValue<Object> getAndTouch(String key, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> CASValue<T> getAndTouch(String key, int exp, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Collection<SocketAddress> getAvailableServers() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<String, Object> getBulk(Iterator<String> keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<String, Object> getBulk(Collection<String> keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<String, Object> getBulk(String... keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Map<String, T> getBulk(Iterator<String> keys, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Map<String, T> getBulk(Collection<String> keys, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Map<String, T> getBulk(Transcoder<T> tc, String... keys) {
        throw new UnsupportedOperationException();
    }

    @Override
    public NodeLocator getNodeLocator() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<SocketAddress, Map<String, String>> getStats() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<SocketAddress, Map<String, String>> getStats(String prefix) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Transcoder<Object> getTranscoder() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Collection<SocketAddress> getUnavailableServers() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<SocketAddress, String> getVersions() {
        throw new UnsupportedOperationException();
    }

    @Override
    public CASValue<Object> gets(String key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> CASValue<T> gets(String key, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long incr(String key, long by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long incr(String key, int by) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long incr(String key, long by, long def) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long incr(String key, int by, long def) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long incr(String key, long by, long def, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long incr(String key, int by, long def, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Set<String> listSaslMechanisms() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Boolean> prepend(long cas, String key, Object val) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<Boolean> prepend(long cas, String key, T val,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean removeObserver(ConnectionObserver obs) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Boolean> replace(String key, int exp, Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<Boolean> replace(String key, int exp, T o,
            Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Future<Boolean> set(String key, int exp, Object o) {
        synchronized (lock) {
            CacheItem item = new CacheItem(key, o, exp);
            cacheMap.put(key, item);
            if (exp != 0) {
                expireMap.put(item.expireTime, item);
            }
        }
        return new MockFuture<Boolean>() {
            @Override
            public Boolean get() throws InterruptedException,
                    ExecutionException {
                return true;
            }
        };
    }

    @Override
    public <T> Future<Boolean> set(String key, int exp, T o, Transcoder<T> tc) {
        synchronized (lock) {
            CacheItem item = new CacheItem(key, o, exp);
            cacheMap.put(key, item);
            if (exp != 0) {
                expireMap.put(item.expireTime, item);
            }
        }
        return new MockFuture<Boolean>() {
            @Override
            public Boolean get() throws InterruptedException,
                    ExecutionException {
                return true;
            }
        };
    }

    @Override
    public void shutdown() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean shutdown(long timeout, TimeUnit unit) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<Boolean> touch(String key, int exp) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<Boolean> touch(String key, int exp, Transcoder<T> tc) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean waitForQueues(long timeout, TimeUnit unit) {
        throw new UnsupportedOperationException();
    }

    /**
     * Mock future which is used for return value. 
     */
    private static abstract class MockFuture<T> implements Future<T> {
        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            throw new UnsupportedOperationException();
        }

        @Override
        public T get(long timeout, TimeUnit unit) throws InterruptedException,
                ExecutionException, TimeoutException {
            return get();
        }

        @Override
        public boolean isCancelled() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isDone() {
            throw new UnsupportedOperationException();
        }
    }
}
