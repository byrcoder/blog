/**
 * @(#)v.java, 2013-2-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

/**
 * @author chen-chao
 */
public class PhoneQJUserInfoWritable extends UserInfoWritable {
    private static final long serialVersionUID = -4623423996115378305L;
    public static final String QJ = "qj";
    public PhoneQJUserInfoWritable() {
        
    }
    
    public PhoneQJUserInfoWritable(String userId, String originalId) {
        this.userId = userId;
        this.userName = userId;
        this.originalId = originalId;
        this.from = QJ;
    }
}
