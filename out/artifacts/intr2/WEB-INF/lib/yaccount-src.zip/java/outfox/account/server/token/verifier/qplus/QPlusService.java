/**
 * @(#)QPlusService.java, 2012-3-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.qplus;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.List;

import javax.crypto.spec.SecretKeySpec;

import org.springframework.http.HttpMethod;

import outfox.account.conf.AccConst;

/**
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 * 
 * @author chen-chao
 */
abstract class QPlusService {

    private static final char hex[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
    };

    private static final int CONN_TIME_OUT = 30000;

    private static final int READ_TIME_OUT = 30000;

    private static final int CONTENT_BUFFER_SIZE = 1024 * 8;

    private static final int READ_BUFFER_SIZE = 256;

    protected int appid;

    protected javax.crypto.Mac mac = null;

    private static final String SIGN_METHOD = "HmacSHA1";

    protected QPlusService(int appid, String appsecret) {
        this.appid = appid;
        if (appsecret != null) {
            try {
                mac = javax.crypto.Mac.getInstance(SIGN_METHOD);
                mac.init(new SecretKeySpec((appsecret).getBytes(), SIGN_METHOD));
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    protected String send(final String url, final String param) throws IOException {
        HttpURLConnection conn = null;
        String content = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestProperty("Cache-Control", "no-cache");
            conn.setRequestProperty("Content-type", "application/x-www-form-urlencoded");
            conn.setRequestMethod(HttpMethod.GET.toString());
            conn.setConnectTimeout(CONN_TIME_OUT);
            conn.setReadTimeout(READ_TIME_OUT);
            conn.setInstanceFollowRedirects(false);
            if (isNotEmpty(param)) {
                conn.setUseCaches(false);
                conn.setRequestMethod(HttpMethod.POST.toString());
                conn.setRequestProperty("Content-Length", "" + param.length());
                conn.setDoOutput(true);
                conn.getOutputStream().write(param.getBytes());
            }
            conn.connect();
            int code = conn.getResponseCode();
            if (code != 200) {
                throw new IOException("error http code(" + code + ")");
            }
            content = new String(read(conn.getInputStream()), AccConst.UTF8);

        } finally {
            if (conn != null) {
                
                conn.disconnect();
            }
        }
        return content;
    }

    protected String toHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b: bytes) {
            sb.append(hex[((b >> 4) & 0xF)]).append(hex[(b & 0xF)]);
        }
        return sb.toString();
    }

    protected byte[] read(InputStream in) throws IOException {
        int pos = -1;
        byte[] buf = new byte[CONTENT_BUFFER_SIZE];
        ByteArrayOutputStream out = new ByteArrayOutputStream(READ_BUFFER_SIZE);
        while ((pos = in.read(buf)) != -1) {
            out.write(buf, 0, pos);
        }
        return out.toByteArray();
    }

    protected boolean isEmpty(CharSequence str) {
        return str == null || str.length() == 0;
    }

    protected boolean isNotEmpty(CharSequence str) {
        return str != null && str.length() > 0;
    }

    protected String createSigValue(String value) {
        if (mac == null || value == null) {
            return null;
        }
        return toHexString(mac.doFinal((value).getBytes()));
    }

    protected String createHttpParam(List<String> list) {
        Collections.sort(list);
        // speed up construction of stringbuilder
        StringBuilder str = new StringBuilder(list.size() << 4);
        for (String param: list) {
            if (str.length() > 0)
                str.append('&');
            str.append(param);
        }
        return str.toString();
    }

    protected String encode(String value) {
        if (value == null) {
            return null;
        }
        try {
            return java.net.URLEncoder.encode(value, AccConst.UTF8);
        } catch (IOException ex) {
            return value;
        }
    }

    protected int intNow() {
        return (int) (System.currentTimeMillis() / 1000);
    }

    protected long random() {
        return (long) (Math.random() * System.nanoTime());
    }
}
