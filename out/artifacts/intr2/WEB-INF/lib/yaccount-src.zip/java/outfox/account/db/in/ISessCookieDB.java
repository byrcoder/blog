/**
 * @(#)ISessCookieDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.ISessCookieDB.ISessCookieIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface ISessCookieDB extends IteratorService<ISessCookieIter>{
    SessionCookieWritable write(TpToken tp) throws AccException;
    public SessionCookieWritable read(String sessIndex) throws AccException;
    public SessionCookieWritable read(TpToken tp) throws AccException;
    public void remove(TpToken tp) throws AccException;
    public void remove(String sessIndex) throws AccException;
    public interface ISessCookieIter extends Iterator<SessionCookieWritable>{
        public SessionCookieWritable next() throws AccException;
        public void close();
    }
    
    public ISessCookieIter getIter(String sessIndex) throws AccException;
}
