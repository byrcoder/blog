/**
 * @(#)DeviceStore.java, 2013-6-4. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.Cache.ValueWrapper;

import outfox.account.cache.memcached.MemcachedManager;
import outfox.account.conf.AccConfig;
import outfox.account.data.device.DeviceInfoWritable;
import outfox.account.data.device.DeviceStatusWritable;
import outfox.account.data.device.DeviceToDeleteWritable;
import outfox.account.db.kv.KeyPairPool;
import outfox.account.db.kv.OmapKeyValueStore;
import outfox.account.db.kv.IKeyValueStore.Iter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.omap.data.KeyPair;

/**
 * Device Store supply methods to update device info which optimized using memcached
 * according to different invoking scenarios. 
 * @author zhanglz
 *
 */
public class DeviceStore {
    private static final Log LOG = LogFactory.getLog(DeviceStore.class);
    private static final String NAME_MEMCACHED_DEVICE_STATUS = "deviceStatus@global";
    private static final String NAME_MEMCACHED_USER_LIST_TO_DELETE = "userListToDelete@global";
    private static final DeviceStore instance = new DeviceStore();
    /**
     * Memcached client.
     */
    private MemcachedManager memcached;
    
    /**
     * Memcached.
     * userId, deviceId -> device status.
     */
    private OmapKeyValueStore statusStore;
    
    /**
     * Memcached.
     * device id -> user list to be deleted on this device.
     */
    private OmapKeyValueStore toDeleteStore;;
    
    /**
     * device id -> device detail information.
     */
    private OmapKeyValueStore infoStore;
    
    /**
     * Store used to query online users by device id. 
     */
    private OmapKeyValueStore onlineUserStore;
    
    private KeyPairPool productDevicePool;
    private KeyPairPool productUserDevicePool;
    
    private DeviceStore() {
        initOmapStore();
        memcached = MemcachedManager.getInstance();
    }
    
    @SuppressWarnings("unchecked")
    private void initOmapStore() {
        String storeSpace = (String) AccConfig.getPros().getProperty(
                AccConfig.NAME_OMAP_STORE_SPACE);
        String productUserDeviceKey = "TPKEY(VINTSTRING TPKEY(VINTSTRING VINTSTRING))";
        statusStore = new OmapKeyValueStore(storeSpace, "ACC_DEVICE_STATUS", 
                new String[] {productUserDeviceKey, 
                "CUSTOM(outfox.account.device.data.DeviceStatusWritable)"});
        productUserDevicePool = KeyPairPool.getKeyPairPool(StringWritable.class,
                StringWritable.class, StringWritable.class);
        
        String productDeviceKey = "TPKEY(VINTSTRING VINTSTRING)";
        infoStore = new OmapKeyValueStore(storeSpace, "ACC_DEVICE_INFO", 
                new String[] {productDeviceKey, 
                "CUSTOM(outfox.account.device.data.DeviceInfoWritable)"});
        toDeleteStore = new OmapKeyValueStore(storeSpace, "ACC_DEVICE_DELETE", 
                new String[] {productDeviceKey, 
                "CUSTOM(outfox.account.device.data.DeviceToDeleteWritable)"});
        productDevicePool = KeyPairPool.getKeyPairPool(StringWritable.class,
                StringWritable.class);
        
        String productDeviceUserKey = "TPKEY(VINTSTRING TPKEY(VINTSTRING VINTSTRING))";
        onlineUserStore = new OmapKeyValueStore(storeSpace, "ACC_DEVICE_ONLINE_USERS",
                new String[]{productDeviceUserKey,
                "CUSTOM(outfox.account.device.data.DeviceStatusWritable)"});
        
    }
    
    public static DeviceStore getInstance() {
        return instance;
    }
    
    /**
     * Delete all relevant information about user's one device.
     * NOTE: just for convience testing.
     * @param product
     * @param userid
     * @param deviceId
     * @throws AccException 
     */
    public void resetDevice(String product, String userId, String deviceId) 
        throws AccException {
        KeyPair productDeviceKp = composeKeyPair(product, deviceId);
        KeyPair productUserDeviceKp = composeKeyPair(product, userId, deviceId);
        try {
            // 1. remove from omap.
            statusStore.deleteKey(productUserDeviceKp);
            toDeleteStore.deleteKey(productDeviceKp);
            // 2. remove from memcached.
            memcached.getCache(NAME_MEMCACHED_DEVICE_STATUS).evict(productUserDeviceKp);
            memcached.getCache(NAME_MEMCACHED_USER_LIST_TO_DELETE).evict(productDeviceKp);
        } finally {
            returnKeyPair(productDeviceKp);
            returnKeyPair(productUserDeviceKp);
        }
        
    }
    
    /**
     * List used devices of given user.
     * @param product
     * @param userId
     * @return
     * @throws AccException
     */
    public List<DeviceInfoWritable> listDevices(String product, String userId) 
        throws AccException {
        List<DeviceInfoWritable> result = new ArrayList<DeviceInfoWritable>();
        Iter<IWritableComparable, IWritable> iter = null;
        List<KeyPair> tmpKeys = new ArrayList<KeyPair>();
        KeyPair key = null;
        try {
            key = composeKeyPair(product, userId, StringUtils.EMPTY);
            tmpKeys.add(key);
            iter = statusStore.getIter();
            iter.seekTo(key, false);
            DeviceStatusWritable status = new DeviceStatusWritable();
            DeviceInfoWritable info = new DeviceInfoWritable();
            while (iter.next(key, status)) {
                if (!userId.equals(status.getUserId())) {
                    break;
                }
                KeyPair tmpKey = composeKeyPair(product, status.getDeviceId());
                tmpKeys.add(tmpKey);
                if (infoStore.readValue(tmpKey, info)) {
                    info.setDeviceStatus(status.getStatus());
                    DeviceInfoWritable copy = new DeviceInfoWritable();
                    copy.copyFields(info);
                    result.add(copy);
                } else {
                    LOG.error("Device exist in status store but not in info store."
                            + "key=" + tmpKey);
                }
            }
        } finally {
            if (null != iter) {
                iter.close();
            }
            for (KeyPair tmpKey : tmpKeys) {
                returnKeyPair(tmpKey);
            }
        }
        return result;
    }
    
    /**
     * Update device info.
     * @param info
     * @throws AccException
     */
    public void updateDeviceInfo(DeviceInfoWritable info) throws AccException {
        KeyPair key = null;
        try {
            key = composeKeyPair(info.getProduct(), info.getDeviceId());
            infoStore.writeKeyValue(key, info);
        } finally {
            returnKeyPair(key);
        }
    }
    
    /**
     * Read device info.
     * @param deviceId
     * @return
     * @throws AccException
     */
    public DeviceInfoWritable getDeviceInfo(String product, String deviceId) 
        throws AccException {
        KeyPair key = null;
        try {
            key = composeKeyPair(product, deviceId);
            DeviceInfoWritable value = new DeviceInfoWritable();
            if (infoStore.readValue(key, value)) {
                return value;
            } else {
                return null;
            }
        } finally {
            returnKeyPair(key);
        }
    }
    
    /**
     * Read device status from omap with memcached.
     * 
     * @param userId
     * @param deviceId
     * @param forceReadOmap whether to read omap when memcached crashes.
     * @return
     * @throws AccException
     */
    public DeviceStatus getDeviceStatus(String product, String userId, 
            String deviceId, boolean forceReadOmap) throws AccException {
        KeyPair key = null;
        try {
            key = composeKeyPair(product, userId, deviceId);
            boolean memcachedFailed = false;
            Short cachedDeviceStatus = null;
            // 1. read from memcached.
            try {
                cachedDeviceStatus = (Short)readFromMemcached(
                        NAME_MEMCACHED_DEVICE_STATUS, key);
            } catch (Exception e) {
                LOG.error("Fail to read from memcached.key=" + key, e);
                memcachedFailed = true;
            }
            // 2. cache miss or memcached crash.
            if (null == cachedDeviceStatus) {
                // cases that we must read omap.
                if (!memcachedFailed || forceReadOmap) {
                    DeviceStatusWritable value = new DeviceStatusWritable();
                    if (statusStore.readValue(key, value)) {
                        cachedDeviceStatus = value.getStatus().getState();
                    }
                }
                // cases that we need to update memcached.
                if (null != cachedDeviceStatus && !memcachedFailed) {
                    try {
                        writeIntoMemcached(NAME_MEMCACHED_DEVICE_STATUS, key, 
                                cachedDeviceStatus);
                    } catch (Exception e) {
                        LOG.error("Fail to write into memcached.key=" + key +
                                "value=" + cachedDeviceStatus, e);
                        memcachedFailed = true;
                    }
                }
            }
            
            if (null != cachedDeviceStatus) {
                return DeviceStatus.valueOf(cachedDeviceStatus);
            } else {
                return null;
            }
        } finally {
            returnKeyPair(key);
        }
    }
    
    
    /**
     * Update omap and then update memcached. 
     * If given status is delete related, update user-deleting store.
     * If given status is online-offline related, update device -> online user store.
     * 
     * @param userId
     * @param deviceId
     * @param status
     * @throws AccException
     */
    public void updateDeviceStatus(String product, String userId, String deviceId, 
            DeviceStatus status) throws AccException {
        KeyPair key = null;
        try {
            key = composeKeyPair(product, userId, deviceId);
            // 1. write into omap.
            DeviceStatusWritable value = new DeviceStatusWritable(product, 
                    userId, deviceId, status);
            statusStore.writeKeyValue(key, value);
            try {
                // 2. write into memcache.
                writeIntoMemcached(NAME_MEMCACHED_DEVICE_STATUS, key, 
                        status.getState());
            } catch (Exception e) {
                LOG.error("Fail to write into memcached. key=" + key, e);
            }
            // If object status makes a user online.
            if (status == DeviceStatus.ONLINE) {
                updateOnlineUser(value, true);
            }
            // if object status makes a user offline.
            if (status == DeviceStatus.EMPTY || status == DeviceStatus.LOGOUT) {
                updateOnlineUser(value, false);
            }
            // if object status want to remove user's data.
            if (status == DeviceStatus.DELETING) {
                updateDeletingUser(product, deviceId, userId, true);
            } 
            // if object status has removed user's data.
            if (status == DeviceStatus.EMPTY) {
                updateDeletingUser(product, deviceId, userId, false);
            }
            LOG.debug("Update device status,id=" + deviceId + ", status=" + status.name());
        } finally {
            returnKeyPair(key);
        }
    }
    
    /**
     * Read deleting user list for given device.
     * If memcached acts abnormally, return empty list.
     * If there is no data in omap, write an empty user list into memcached to avoid accessing omap again.
     * Else write omap value into memcached.
     * @param deviceId
     * @return
     * @throws AccException
     */
    public List<String> getDeletingUsers(String product, String deviceId) throws AccException {
        List<String> result = new ArrayList<String>();
        KeyPair key = null;
        try {
            key = composeKeyPair(product, deviceId);
            String userIds = null;
            try {
                userIds = (String)readFromMemcached(
                    NAME_MEMCACHED_USER_LIST_TO_DELETE, key);
            } catch (Exception e) {
                // if memcached is not working, return empty list but not access omap.
                LOG.error("Fail to read from memcached. key=" + key, e);
                return result;
            }
            
            // if cache is missed
            if (null == userIds) {
                // Pass empty string into 'updateDeletingUser' to read omap value into memcached.
                userIds = StringUtils.EMPTY;
                updateDeletingUser(product, deviceId, userIds, true);
            }
            for (String user : DeviceToDeleteWritable.decodeUserIds(userIds)) {
                result.add(user);
            }
            return result;
        } finally {
            returnKeyPair(key);
        }
    }
    
    /**
     * List online user on given device whose status is ONLINE, DELETING or LOGOUTING.
     * 
     * NOTE: In the senario when the device do some operation which can make 
     * user offline without notifying the server, the result may contain users 
     * who have logged out without connecting network.
     * 
     * @param product
     * @param deviceId
     * @return
     * @throws AccException
     */
    public List<String> listOnlineUsers(String product, String deviceId) 
        throws AccException {
        List<String> result = new ArrayList<String>();
        KeyPair kp = null;
        Iter<IWritableComparable, IWritable>  iter = null;
        DeviceStatusWritable value = new DeviceStatusWritable();
        try {
            kp = composeKeyPair(product, deviceId, StringUtils.EMPTY);
            iter = onlineUserStore.getIter();
            iter.seekTo(kp, false);
            while(iter.next(kp, value)) {
                if (!value.getProduct().equals(product)) {
                    break;
                }
                if (!value.getDeviceId().equals(deviceId)) {
                    break;
                }
                result.add(value.getUserId());
            }
        } finally {
            returnKeyPair(kp);
            if (iter != null) {
                iter.close();
            }
        }
        return result;
    }
    
    private void updateOnlineUser(DeviceStatusWritable deviceStatus, boolean isAdd) 
        throws AccException {
        KeyPair key = null;
        try {
            key = composeKeyPair(deviceStatus.getProduct(), deviceStatus.getDeviceId(), 
                    deviceStatus.getUserId());
            if (isAdd) {
                onlineUserStore.writeKeyValue(key, deviceStatus);
            } else {
                onlineUserStore.deleteKey(key);
            }
        } finally {
            returnKeyPair(key);
        }
    }
    
    /**
     * Read deleting users for given 'deviceId' from omap. 
     * If given 'userId' is not empty, add into or remove from deleting users set of the given 'deviceId' then write into omap.
     * If given 'userId' is empty, do nothing.
     * Finally write into memcached to make cached value consistent with omap.
     * @param deviceId
     * @param userId
     * @param isAdd
     * @return
     * @throws AccException
     */
    private Set<String> updateDeletingUser(String product, String deviceId, 
            String userId, boolean isAdd) throws AccException {
        KeyPair key = null;
        try {
            key = composeKeyPair(product, deviceId);
            DeviceToDeleteWritable value = new DeviceToDeleteWritable(
                    product, deviceId);
            toDeleteStore.readValue(key, value);
            if (StringUtils.isNotBlank(userId)) {
                if (isAdd) {
                    value.putUserId(userId);
                } else {
                    value.removeUserId(userId);
                }
                toDeleteStore.writeKeyValue(key, value);
            }
            try {
                Set<String> users = value.getUserIdSet();
                writeIntoMemcached(NAME_MEMCACHED_USER_LIST_TO_DELETE, key,
                        DeviceToDeleteWritable.encodeUserIds(users));
            } catch (Exception e) {
                LOG.error("Fail to write into memcached. key=" + key, e);
            }
            return value.getUserIdSet();
        } finally {
            returnKeyPair(key);
        }
    }
    
    /**
     * Simple method to read a key-value from named memcached.
     * NOTE: When memcached acts abnormally, runtime exception will be thrown, 
     * so that invoker can catch the exception and decide what to do.
     * @param cacheName
     * @param key
     * @param value
     */
    private Object readFromMemcached(String cacheName, Object key) {
        Cache cache = memcached.getCache(cacheName);
        ValueWrapper valueWrapper = cache.get(key);
        if (null == valueWrapper) {
            return null;
        } else {
            return valueWrapper.get();
        }
    }
    
    /**
     * Simple method to write a key-value into named memcached.
     * NOTE: When memcached acts abnormally, runtime exception will be thrown, 
     * so that invoker can catch the exception and decide what to do.
     * @param cacheName
     * @param key
     * @param value
     */
    private void writeIntoMemcached(String cacheName, Object key, Object value) {
        Cache cache = memcached.getCache(cacheName);
        cache.put(key, value);
    }
    
    private KeyPair composeKeyPair(String product, String userId, String deviceId) throws AccException {
        if (StringUtils.isBlank(product) || null == userId || null == deviceId) {
            throw new AccException("empty product:" + product + " or userId:" + userId + ", or deviceId:"
                    + deviceId, AccExpType.PARAM_MISSING_ERROR);
        }
        KeyPair kp = productUserDevicePool.borrowKey();
        ((StringWritable) kp.getKey1()).set(product);
        KeyPair kp2 = (KeyPair) kp.getKey2();
        ((StringWritable) kp2.getKey1()).set(userId);
        ((StringWritable) kp2.getKey2()).set(deviceId);
        return kp;
    }

    private KeyPair composeKeyPair(String product, String deviceId) throws AccException {
        if (StringUtils.isBlank(product) || null == deviceId) {
            throw new AccException("empty product:" + product + " , or deviceId:" + deviceId,
                    AccExpType.PARAM_MISSING_ERROR);
        }
        KeyPair kp = productDevicePool.borrowKey();
        ((StringWritable) kp.getKey1()).set(product);
        ((StringWritable) kp.getKey2()).set(deviceId);
        return kp;
    }
    
    /**
     * Util method to return key pair used in this class.
     * There are only two kinds of KeyPair different by second key's type.
     * @param kp
     */
    private void returnKeyPair(KeyPair kp) {
        if (null == kp) {
            return;
        }
        if (kp.getKey2() instanceof StringWritable) {
            productDevicePool.returnKey(kp);
        } else {
            productUserDevicePool.returnKey(kp);
        }
    }
    
}
