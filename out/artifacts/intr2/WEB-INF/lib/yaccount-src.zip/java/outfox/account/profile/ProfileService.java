package outfox.account.profile;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @author yangzhe
 * @version created on 15/2/3 by yangzhe.
 */
public class ProfileService {

    private static RedisService redisService = new RedisService();

    private static ProfileDAO profileDAO = new ProfileDAO();

    private static LoadingCache<String, String> useridToNickname = CacheBuilder.newBuilder()
            .maximumSize(1000000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .build(
                    new CacheLoader<String, String>() {
                        public String load(String key) throws Exception {
                            String nick = getNicknameByUseridGlobal(key);
                            return nick == null ? "" : nick;
                        }
                    }
            );
    private static LoadingCache<String, String> nicknameToUserid = CacheBuilder.newBuilder()
            .maximumSize(1000000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .build(
                    new CacheLoader<String, String>() {
                        public String load(String key) throws Exception {
                            String userid = getUseridByNicknameGlobal(key);
                            return userid == null ? "" : userid;
                        }
                    }
            );

    private static LoadingCache<String, String> useridToAvatar = CacheBuilder.newBuilder()
            .maximumSize(1000000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .build(
                    new CacheLoader<String, String>() {
                        public String load(String key) throws Exception {
                            String avatar = profileDAO.getTextValue(key,"option_avatar");
                            return avatar == null ? "" : avatar;
                        }
                    }
            );

    private static LoadingCache<String, String> useridToGender = CacheBuilder.newBuilder()
            .maximumSize(1000000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .build(
                    new CacheLoader<String, String>() {
                        public String load(String key) throws Exception {
                            String avatar = profileDAO.getTextValue(key,"option_gender");
                            return avatar == null ? "" : avatar;
                        }
                    }
            );

    private static String getNicknameByUseridGlobal(String userid) {
        String nick = redisService.getString("nick:userid:" + userid);
        if (nick == null) {
            nick = profileDAO.getNicknameByUserid(userid);
            if (nick != null) {
                redisService.setValueOneMonth("nick:userid:" + userid, nick);
            }
        }
        return nick;
    }

    private static String getUseridByNicknameGlobal(String nickname) {
        String userid = redisService.getString("nick:nickname:" + nickname);
        if (userid == null) {
            userid = profileDAO.getUseridByNickname(nickname);
            if (userid != null) {
                redisService.setValueOneMonth("nick:nickname:" + nickname, userid);
            }
        }
        return userid;
    }

    public String getNicknameByUserid(String userid) {
        return useridToNickname.getUnchecked(userid);
    }

    public String getUseridByNickname(String nickname) {
        return nicknameToUserid.getUnchecked(nickname);
    }

    public String getAvatarByUserid(String userid){
        return useridToAvatar.getUnchecked(userid);
    }

    public String getGenderByUserid(String userid){
        return useridToGender.getUnchecked(userid);
    }
}
