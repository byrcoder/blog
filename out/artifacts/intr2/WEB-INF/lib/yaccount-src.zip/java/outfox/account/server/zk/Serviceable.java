/**
 * @(#)ZKServiceable.java, 2011-7-26. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.zk;



/**
 * Defines the set of shared functions for services which uses ZooKeeper.
 * (Master, StoreServers and Clients)
 * @author licx
 */
public interface Serviceable  {

    /**
     * Gets the ZooKeeper instance for this server.
     */
    public ZooKeeperWatcher getZooKeeper();

    /**
     * Shutdown the whole service and close everything related.
     */
    public void shutdown();
    
    /**
     * Recover the server or RPC client
     *
     * @param why recover reason
     * @param cause exception that causes the recovery
     */
    public void recover(String why, Exception cause);
    
    /**
     * Stop this service
     *
     * @param why stop reason
     */
    public void stop(String why);

    /**
     * @return true if the service is stopped
     */
    public boolean isStopped();
}
