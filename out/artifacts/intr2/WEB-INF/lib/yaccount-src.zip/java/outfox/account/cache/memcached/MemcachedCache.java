/**
 * @(#)MemcachedCache.java, 2012-10-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache.memcached;

import net.spy.memcached.MemcachedClientIF;
import net.spy.memcached.transcoders.Transcoder;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.support.SimpleValueWrapper;

/**
 * {@link Cache} implementation on top of Memcached.
 *
 * <p>
 * Actually different instances of this class share the same Memcached cluster,
 * they differs in the configurations of the cached value, e.g. expiration time,
 * transcoder.
 *
 * @author licx
 */
public class MemcachedCache implements Cache {
    private static final Log LOG = LogFactory.getLog(MemcachedCache.class);

    /**
     * Name of this memcached cache
     */
    private final String name;

    /**
     * Memcached RPC client.
     * MemcachedClient uses nio to send request/receive response, so each process
     * should only have one MemcachedClient.
     */
    private MemcachedClientIF memcachedClient;

    /**
     * Transcoder to be used when get/set data. If not specified, transcoder
     * set in MemcachedClient would be used.
     */
    private Transcoder<Object> transcoder;

    /**
     * Default expiration time for cached data. If not specified, cached data
     * would not be expired but would only be evicted out of the cache via
     * LRU policy.
     */
    private int expirationTime = 0;

    public MemcachedCache(String name) {
        this.name = name;
    }

    /**
     * @return the memcachedClient
     */
    public MemcachedClientIF getMemcachedClient() {
        return memcachedClient;
    }

    /**
     * @param memcachedClient the memcachedClient to set
     */
    public void setMemcachedClient(MemcachedClientIF memcachedClient) {
        this.memcachedClient = memcachedClient;
    }

    /**
     * @return the transcoder
     */
    public Transcoder<Object> getTranscoder() {
        return transcoder;
    }

    /**
     * @param transcoder the transcoder to set
     */
    public void setTranscoder(Transcoder<Object> transcoder) {
        this.transcoder = transcoder;
    }

    /**
     * @return the expirationTime
     */
    public int getExpirationTime() {
        return expirationTime;
    }

    /**
     * @param expirationTime the expirationTime to set
     */
    public void setExpirationTime(int expirationTime) {
        this.expirationTime = expirationTime;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Object getNativeCache() {
        return memcachedClient;
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException(
                "Could not clear the cache data in memcached");
    }

    /* 
     * NOTE: this method will throw RuntimeException if some fatal 
     * error happens when connecting memcached, outside invoker should catch 
     * this kind of exception to handle memcached failure.
     */
    @Override
    public void evict(Object key) {
        if (key != null) {
            memcachedClient.delete(getMemcachedKey(key));
        } else {
            LOG.warn("Could not evict the cached value for null key");
        }
    }

    /* 
     * NOTE: this method will throw RuntimeException if some fatal 
     * error happens when connecting memcached, outside invoker should catch 
     * this kind of exception to handle memcached failure.
     */
    @Override
    public ValueWrapper get(Object key) {
        if (key != null) {
            Object value = null;
            if (transcoder == null) {
                value = memcachedClient.get(getMemcachedKey(key));
            } else {
                value = memcachedClient.get(getMemcachedKey(key), transcoder);
            }
            // only return the value wrapper when cache hit
            if (value != null) {
                return new SimpleValueWrapper(value);
            }
        } else {
            LOG.warn("Could not get the cached value for null key");
        }
        return null;
    }

    /* 
     * NOTE: this method will throw RuntimeException if some fatal 
     * error happens when connecting memcached, outside invoker should catch 
     * this kind of exception to handle memcached failure.
     */
    @Override
    public void put(Object key, Object value) {
        if (key != null) {
            if (transcoder == null) {
                memcachedClient.set(getMemcachedKey(key), expirationTime, value);
            } else {
                memcachedClient.set(getMemcachedKey(key), expirationTime,
                        value, transcoder);
            }
        } else {
            LOG.warn("Could not put the cached value for null key");
        }
    }

    /**
     * Memcached only allows string keys 
     */
    private String getMemcachedKey(Object key) {
        return key.toString() + "@" + name;
    }
}
