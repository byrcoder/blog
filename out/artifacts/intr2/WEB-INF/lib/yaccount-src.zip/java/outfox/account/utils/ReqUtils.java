/**
 * @(#)ReqUtils.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.util.Enumeration;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;

/**
 * @author chen-chao
 */
public class ReqUtils {
    public static final String NO_MISS = "NO_MISS";
    public static String getUserIdOldVersion(HttpServletRequest req) {
        return (String) req.getAttribute(AccConst.ATTR_URS_EMAIL);
    }
    
    public static String getUserId(HttpServletRequest req) {
        return (String)req.getAttribute(AccConst.USER_ID_ATTR);
    }
    
    public static String getUserIdByProduct(HttpServletRequest req, String product) {
        String userId = getUserId(req, product);
        if (StringUtils.isBlank(userId)) {
            return getUserId(req);
        }
        return userId;
    }
    
    public static String getBindUserIdByProduct(HttpServletRequest req, String product) {
        return (String) req.getAttribute(product + AccConst.ATTR_PART_BIND_USER_ID);
    }
    
    public static String getUserId(HttpServletRequest req, String product) {
        return (String) req.getAttribute(product + AccConst.ATTR_PART_USER_ID);
    }
    
    public static SessionCookieWritable getSessionCookieWritable(HttpServletRequest req, String product) {
        return (SessionCookieWritable) req.getAttribute(product + AccConst.ATTR_PART_SESS_WRITABLE);
    }
    
    public static PersistTokenWritable getPersTokenWritable(HttpServletRequest req, String product) {
        return (PersistTokenWritable) req.getAttribute(product + AccConst.ATTR_PART_PERSTOKEN_WRITABLE);
    }
    
    public static SessionCookieWritable getBindCookieWritable(HttpServletRequest req, String product) {
        return (SessionCookieWritable) req.getAttribute(product + AccConst.ATTR_PART_BIND_WRITABLE);
    }
    
    public static UserInfoWritable getBindUserInfo(HttpServletRequest req, String product) {
        return (UserInfoWritable) req.getAttribute(product + AccConst.ATTR_PART_BIND_USER_ID_WRITABLE);
    }
    
    public static UserInfoWritable getUserInfo(HttpServletRequest req, String product) {
        return (UserInfoWritable) req.getAttribute(product + AccConst.ATTR_PART_USER_ID_WRITABLE);
    }
    
    public static String getQueryString(HttpServletRequest req) {
        Map<String,String[]> params = req.getParameterMap();
        StringBuilder sb = new StringBuilder();
        
        if (params != null) {
            boolean notFirst = false;
            for (Entry<String,String[]> param : params.entrySet()) {
                if (notFirst) {
                    sb.append("&");
                }
                String[] values = param.getValue();
                if (values != null) {
                    for (String value : values) {
                        sb.append(param.getKey()).append("=").append(value);
                    }
                    notFirst = true;    
                }
            }
        }
        return sb.toString();
    }
    
    /**
     * check parameter
     * @param req
     * @param paramKey
     * @param target
     * <li>
     * targe is null, the parameter should not exist;
     * </li><li>
     * target is "NO_MISS", the parameter should not miss;
     * </li><li>
     * target is other case, the parameter should be equal with the target string.
     * </li>
     * @throws AccException
     */
    public static void checkParam(HttpServletRequest req, String paramKey, String target) throws AccException {
        if (target == null) {
            // param MUST NOT exist
            if (!isBlankParam(req, paramKey)) {
                throw new AccException("Exist param:" + paramKey, AccExpType.PARAM_EXIST_ERROR);
            }
        } else if (NO_MISS.equals(target)) {
            // param MUST exist
            if (isBlankParam(req, paramKey)) {
                throw new AccException("MISS param:" + paramKey, AccExpType.PARAM_MISSING_ERROR);
            }
        } else if (!isSameParam(req, paramKey, target)) {
            throw new AccException(String.format("param %s=%s is not equal with target %s.",paramKey, req.getParameter(paramKey),target), AccExpType.PARAM_NOT_EQUAL_TAGET_ERROR);
        }
    }
    
    public static boolean isSameParam(HttpServletRequest req, String paramKey, String target) {
        if (!isBlankParam(req, paramKey) && target.equals(req.getParameter(paramKey))) {
            return true;
        }
        return false;
    }
    
    public static boolean isBlankParam(HttpServletRequest req, String paramKey) {
        if (StringUtils.isBlank(req.getParameter(paramKey))){
            return true;
        }
        return false;
    }
    
    /**
     * check header
     * @param req
     * @param headkey
     * @param target
     * <li>
     * targe is null, the parameter should not exist;
     * </li><li>
     * target is "NO_MISS", the parameter should not miss;
     * </li><li>
     * target is other case, the parameter should be equal with the target string.
     * </li>
     * @throws AccException
     */
    public static void checkHeader(HttpServletRequest req, String headKey, String target) throws AccException {
        if (target == null) {
            // param MUST NOT exist
            if (!isBlankHeader(req, headKey)) {
                throw new AccException("Exist param:" + headKey, AccExpType.PARAM_EXIST_ERROR);
            }
        } else if (NO_MISS.equals(target)) {
            // param MUST exist
            if (isBlankHeader(req, headKey)) {
                throw new AccException("MISS param:" + headKey, AccExpType.PARAM_MISSING_ERROR);
            }
        } else if (!isSameHeader(req, headKey, target)) {
            throw new AccException("param:" + headKey +" is not equal with " + target, AccExpType.PARAM_NOT_EQUAL_TAGET_ERROR);
        }
    }
    
    public static void checkParamOrHeader(HttpServletRequest req, String key, String target) throws AccException {
        boolean isOk = false;
        try {
            checkParam(req, key, target);
            isOk = true;
        } catch(AccException e) {
            
        }
        if (isOk) {
            return;
        }
        try {
            checkHeader(req, key, target);
            isOk = true;
        } catch(AccException e) {
            
        }
        if (!isOk) {
            throw new AccException(String.format("no param or header %s equals with target %s", key, target), AccExpType.PARAM_EXIST_ERROR);
        }
    }
    
    public static boolean isBlankHeader(HttpServletRequest req, String headKey) {
        if (StringUtils.isBlank(req.getHeader(headKey))) {
            return true;
        }
        return false;
    }
    
    public static boolean isSameHeader(HttpServletRequest req, String headKey, String targe) {
        if (!isBlankHeader(req, headKey) && req.getHeader(headKey).equals(targe)) {
            return true;
        }
        return false;
    }
    
    /**
     * If the request is dangerous for our application. DUMP IT.
     * @param req
     * @return
     */
    public static String dumpRequest(HttpServletRequest req) {
        StringBuilder sb = new StringBuilder();
        String query = SecurityUtils.escapeSecurityQuery(req);
        sb.append(query);
        sb.append("\n\r");
        sb.append("PROTOCOL:").append(req.getProtocol());
        sb.append("\n\r");
        sb.append("HEADER:\n\r");
        Enumeration<String> names = req.getHeaderNames();
        while(names.hasMoreElements()) {
            String name = names.nextElement();
            sb.append("    ").append(name).append(":\n\r");
            Enumeration<String> values = req.getHeaders(name);
            while(values.hasMoreElements()) {
                String value = values.nextElement();
                if ("Cookie".equals(name)) {
                    String[] cookies = value.split(";");
                    for (String cookie : cookies) {
                        sb.append("        ").append(cookie).append("\n\r");
                    }
                } else {
                    sb.append("        ").append(value).append("\n\r");
                }
            }
        }
        sb.append("\n\r");
        sb.append("PARAMETER:\n\r");
        names = req.getParameterNames();
        while(names.hasMoreElements()) {
            String name = names.nextElement();
            sb.append("    ").append(name).append("=").append(req.getParameter(name)).append("\n\r");
        }
        sb.append("\n\r");
        sb.append("ATTRIBUTE:\n\r");
        names = req.getAttributeNames();
        while(names.hasMoreElements()) {
            String name = names.nextElement();
            sb.append("    ").append(name).append("=").append(req.getAttribute(name)).append("\n\r");
        }
        return sb.toString();
    }
    
    public static String getUserAgent(HttpServletRequest req) {
        return req.getHeader("User-Agent");
    }
}
