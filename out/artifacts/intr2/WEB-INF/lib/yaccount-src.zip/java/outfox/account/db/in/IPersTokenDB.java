/**
 * @(#)IPersTokenDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB.IPersTokenIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IPersTokenDB extends IteratorService<IPersTokenIter>{
    /**
     * write TpToken into database
     * @param tpToken
     * @throws AccException 
     */
    public void write(TpToken tpToken) throws AccException;
    
    public void write(PersistTokenWritable tw) throws AccException;
    
    public PersistTokenWritable read(TpToken tpToken) throws AccException;
    
    public PersistTokenWritable read(String userId, String app, String product, String verifierName, String signature) throws AccException;
    public void remove(String userId, String app, String product, String verifierName, String signature) throws AccException;
    public void remove(TpToken tpToken) throws AccException;
    public interface IPersTokenIter extends Iterator<PersistTokenWritable>{
        public PersistTokenWritable next() throws AccException;
        public void close();
    }
    public IPersTokenIter getIter(String userId) throws AccException;
}
