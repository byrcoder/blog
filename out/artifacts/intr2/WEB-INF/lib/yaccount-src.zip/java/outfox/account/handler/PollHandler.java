/**
 * @(#)PollHandler.java, 2012-9-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.AccCookies;
import outfox.account.data.CacheInfo;
import outfox.account.data.Parameter;
import outfox.account.device.DeviceManager;
import outfox.account.exceptions.AccException;
import outfox.account.logic.event.AccEvent;
import outfox.account.utils.AuthUtils;

/**
 * Poll cookies or information from global cache. 
 * @author chen-chao
 */
@Controller
public class PollHandler extends BaseHandler{
    private static final long serialVersionUID = 4975046432719774256L;
    GlobalCache glcache = GlobalCache.getInstance();
    private static final List<Parameter> RESULT_FLASE = new ArrayList<Parameter>();
    static {
        RESULT_FLASE.add(AccConst.LOGIN_FALSE);
    }
    @RequestMapping(AccConst.POLL_URL)
    public void pollCookies(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        // setName in analyzer and vaquero.
        setName(req, "poll");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkHeader(req, AccConst.PARAM_PC_NAME, NO_MISS);
        String pc = req.getHeader(AccConst.PARAM_PC_NAME);
        byte[] cookies = glcache.get(pc);
        if (cookies != null) {
            CacheInfo info = AccCookies.byte2CacheInfo(cookies);
            info.addCookieIntoResponse(resp);
            List<Parameter> loginInfo = AuthUtils.convertMap2List(info.getProperties());
            loginInfo.add(AccConst.LOGIN_TRUE);
            // check device status.
            String product = AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME);
            List<AccEvent> eventList = new ArrayList<AccEvent>();
            List<Parameter> deviceCheckResult = new ArrayList<Parameter>();
            if (!DeviceManager.tryTransferStatus(product, getUserId(info.getProperties()), 
                    OPERATOR.POLL, null, req, deviceCheckResult, eventList)) {
                write(req, resp, deviceCheckResult, HttpStatus.SERVICE_UNAVAILABLE);
                return;
            } 
            DeviceManager.handleEvents(eventList);
            // TODO in other thread.
            glcache.remove(pc);
            write(req, resp, loginInfo, HttpStatus.OK);
        } else {
            write(req, resp, RESULT_FLASE, HttpStatus.OK);
        }
    }
}
