/**
 * @(#)AccountRPCServerWapper.java, 2012-9-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author chen-chao
 */
public class AccountRPCServerWapper {
    private static final Log LOG = LogFactory.getLog(AccountRPCServerWapper.class);
    private AccountRPCServer server;

    public AccountRPCServerWapper() {
        
    }
    public AccountRPCServerWapper(AccountRPCServer server) {
        this();
        this.server = server;
    }
    public void init() {
        LOG.info("Start rpc server thread ...");
        try{
            if (server == null ) {
                server = new AccountRPCServer();
            } else if (server!=null && !server.isStopped()) {
                server.stopServer();
            }
            server.start();
            LOG.info("Start rpc server thread DONE.");
        } catch (Throwable e) {
            LOG.fatal("Fail to start rpc server thread", e);
        }
    }
}
