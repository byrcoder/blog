/**
 * @(#)OmapUserMappingDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.db.in.IUserMappingDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.db.kv.IKeyValueStore.Iter;
import outfox.account.db.kv.KeyPairPool;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;
import outfox.omap.data.KeyPair;

/**
 * @author chen-chao
 */
public class KVUserMappingDB extends BaseKVDB implements IUserMappingDB{
    private static final String STORE_NAME = "accMapping";
    /**
     * key: sessIndex 
     * value : SessionCookieWritable
     */
    private static final String[] types = {
        "TPKEY(VINTSTRING LONG)",
        "CUSTOM(outfox.account.data.MainId2ShadowIdWritable)"
    };
    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;
    
    @SuppressWarnings("unchecked")
    public KVUserMappingDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }
    @Override
    public MainId2ShadowIdWritable read(String userId, Long timestamp) throws AccException {
        if (StringUtils.isBlank(userId)) {
            return null;
        }
        KeyPair key = null;
        try {
            MainId2ShadowIdWritable value = new MainId2ShadowIdWritable();
            key = composeOmapKey(userId, timestamp);
            return kvStore.readValue(key, value) ? value : null;
        } finally {
            keypairPool.returnKey(key);
        }
    }

    @Override
    public void write(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        try {
            writeShadowOnly(mainId2ShadowIdWritable);
        } catch(Exception e) {
            throw new AccException("write shadow id crash.", e ,AccExpType.ADD_BIND_ERROR);
        }
        try {
            writeMainOnly(mainId2ShadowIdWritable);
        } catch(Exception e) {
            throw new AccException("write main id crash.", e ,AccExpType.ADD_BIND_PART_ERROR);
        }
    }
    
    public void writeShadowOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        if (mainId2ShadowIdWritable != null) {
            KeyPair key = null;
            try {
                key = composeOmapKey(mainId2ShadowIdWritable.getShadowUserId());
                kvStore.writeKeyValue(key, mainId2ShadowIdWritable);
            } finally {
                keypairPool.returnKey(key);
            }
        }
        
    }
    
    public void writeMainOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        if (mainId2ShadowIdWritable != null) {
            KeyPair key = null;
            try {
                key = composeOmapKey(mainId2ShadowIdWritable.getMainUserId(), mainId2ShadowIdWritable.getBindingTimeStamp());
                kvStore.writeKeyValue(key, mainId2ShadowIdWritable);
            } finally {
                keypairPool.returnKey(key);
            }
        }
    }

    @Override
    public void remove(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        try {
            removeMainOnly(mainId2ShadowIdWritable);
        } catch(Exception e) {
            throw new AccException("remove main id crash.", e ,AccExpType.REMOVE_BIND_ERROR);
        }
        try {
            removeShadowOnly(mainId2ShadowIdWritable);
        } catch(Exception e) {
            throw new AccException("remove shadow id crash.", e ,AccExpType.REMOVE_BIND_PART_ERROR);
        }
        
    }
    
    public void removeShadowOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        if (mainId2ShadowIdWritable != null) {
            KeyPair key = null;
            try {
                key = composeOmapKey(mainId2ShadowIdWritable.getShadowUserId(), AccConst.DEFAULT_TIME);
                kvStore.deleteKey(key);
            } finally {
                keypairPool.returnKey(key);
            }
        }
    }
    
    public void removeMainOnly(MainId2ShadowIdWritable mainId2ShadowIdWritable) throws AccException {
        if (mainId2ShadowIdWritable != null) {
            KeyPair key = null;
            try {
                key = composeOmapKey(mainId2ShadowIdWritable.getMainUserId(), mainId2ShadowIdWritable.getBindingTimeStamp());
                kvStore.deleteKey(key);
            } finally {
                keypairPool.returnKey(key);
            }
        }
    }

    @Override
    public IUserMappingIter getIter(String userId) throws AccException {
        return new KVUserMappingIter(userId, AccConst.DEFAULT_TIME);
    }
    
    @Override
    public IUserMappingIter getIter(String userId, Long timestamp) throws AccException {
        return new KVUserMappingIter(userId, timestamp);
    }
    
    /**
     * The pool for KeyPair The object is only referred below
     */
    @SuppressWarnings("unchecked")
    private static KeyPairPool keypairPool = KeyPairPool.getKeyPairPool(
            StringWritable.class, LongWritable.class);
    
    private static KeyPair composeOmapKey(String userId) {
        return composeOmapKey(userId, AccConst.DEFAULT_TIME);
    }
    
    /**
     * thread unsafe
     *
     * @author chen-chao
     *
     */
    private class KVUserMappingIter implements IUserMappingIter {
        private Iter<IWritableComparable, IWritable> iter = null;

        private KeyPair key = null;
        private String userid = null;

        public KVUserMappingIter(String userid, Long timestamp)
                throws AccException {
            try {
                this.userid = userid;
                iter = kvStore.getIter();
                key = composeOmapKey(userid, timestamp);
                iter.seekTo(key, false);
            } catch (AccException e) {
                AuthUtils.disposeException(e,
                        AccExpType.STORE_SERVICE_EXCEPTION);
            } 
        }
        
        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         * @throws AccException 
         */
        @Override
        public MainId2ShadowIdWritable next() throws AccException {
            MainId2ShadowIdWritable value = new MainId2ShadowIdWritable();
            if (iter.next(key, value) && isEnd(userid, value)) {
                return value;
            }
            return null;
        }
        
        private boolean isEnd(String userid, MainId2ShadowIdWritable value) {
            if (StringUtils.isBlank(userid)) {
                // want all 
                return true;
            } else {
                return value.getMainUserId().equals(userid) || value.getShadowUserId().equals(userid);
            }
            
        }

        @Override
        public void close() {
            AuthUtils.closeQuiet(iter);
            keypairPool.returnKey(key);
        }
    }
    
    /**
     * Create omap key for user file, the key is composed by three part: userId,
     * entry path, and version return returned keyPair is pooled, should call
     * {@link #returnOmapKey} after usage
     * 
     * @param userId
     * @param entry
     * @param version
     * @return
     */
    private static KeyPair composeOmapKey(String userId, Long timestamp) {
        KeyPair kp = keypairPool.borrowKey();
        if (userId == null) {
            userId = "";
        }
        
        if (timestamp == null) {
            timestamp = 0L;
        }
        
        ((StringWritable) kp.getKey1()).set(userId);
        ((LongWritable) kp.getKey2()).set(timestamp);
        
        return kp;
    }

    @Override
    public MainId2ShadowIdWritable readOne(String userId) throws AccException {
        IUserMappingIter iter = null;
        try {
            iter = getIter(userId);
            return iter.next();
        } finally {
            AuthUtils.closeQuiet(iter);
        }
    }
    @Override
    public MainId2ShadowIdWritable readShadow(String shadowId) throws AccException {
        return read(shadowId, AccConst.DEFAULT_TIME);
    }
    @Override
    public IUserMappingIter getIter(Object... startKeys) throws AccException {
        if (startKeys != null) {
            if (startKeys.length == 1) {
                return getIter((String)startKeys[0]);
            } else if (startKeys.length == 2) {
                return getIter((String)startKeys[0], (Long)startKeys[1]);
            }
        }
        throw new AccException("no start keys or start keys are too many.", AccExpType.NOT_SUPPORT);
    }

}
