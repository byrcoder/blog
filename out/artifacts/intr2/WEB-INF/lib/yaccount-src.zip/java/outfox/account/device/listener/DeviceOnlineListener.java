/**
 * @(#)DeviceOnlineListener.java, 2013-10-10. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device.listener;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.device.DeviceEvent;
import outfox.account.device.DeviceStatus;
import outfox.account.device.DeviceStore;
import outfox.account.exceptions.AccException;
import outfox.account.conf.AccConst.OPERATOR;

/**
 * Listener to handle do logic needed when users log in on a device.
 * For now, server must kick off other still online users on the same device 
 * when some user log in.
 * @author zhanglz
 *
 */
public class DeviceOnlineListener implements IDeviceEventListener {
    private static final Log LOG = LogFactory.getLog(DeviceOnlineListener.class);
    @Override
    public void handleEvent(DeviceEvent event) {
        try {
            //TODO: maybe should add OPERATOR.POLL for this if.
            if ((event.getOp() == OPERATOR.LOGIN ||
                    event.getOp() == OPERATOR.CQ )&& 
                    event.getTo() == DeviceStatus.ONLINE) {
                String product = event.getProduct();
                String deviceId = event.getDeviceId();
                DeviceStore store = DeviceStore.getInstance();
                List<String> onlineUsers = store.listOnlineUsers(
                        product, deviceId);
                for (String onlineUser : onlineUsers) {
                    if (onlineUser.equals(event.getUserId())) {
                       continue;
                    }
                    // let other online users on this device log out.
                    DeviceStatus status = store.getDeviceStatus(product, 
                            onlineUser, deviceId, true);
                    if (status == DeviceStatus.ONLINE) {
                        store.updateDeviceStatus(product, onlineUser, 
                                deviceId, DeviceStatus.LOGOUT);
                    }
                }

            }
        } catch (AccException e) {
            LOG.warn("Kick off other online user on the same device failed.", e);
        }
    }
    
}
