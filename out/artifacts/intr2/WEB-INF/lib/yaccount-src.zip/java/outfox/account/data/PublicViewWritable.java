/**
 * @(#)PublicViewWritable.java, 2013-2-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.lib.StringWritable;

/**
 * For luojisiwei, the user's notes will be published. 
 * Anybody can see the published notes.
 * @author chen-chao
 */
public class PublicViewWritable extends AbstractWritable {
    private static final long serialVersionUID = -154362693883201967L;
    public String urlSuffix;
    public String getUrlSuffix() {
        return urlSuffix;
    }

    public void setUrlSuffix(String urlSuffix) {
        this.urlSuffix = urlSuffix;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getAuthorize() {
        return authorize;
    }

    public void setAuthorize(int authorize) {
        this.authorize = authorize;
    }
    public String userId;
    public int authorize;
    public PublicViewWritable(String urlSuffix, String userId, int authorize) {
        this.urlSuffix = urlSuffix;
        this.userId = userId;
        this.authorize = authorize;
    }
    
    public PublicViewWritable() {
        // TODO Auto-generated constructor stub
    }
    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        urlSuffix = StringWritable.readStringNull(in);
        userId = StringWritable.readStringNull(in);
        authorize = in.readInt();        
    }
    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, urlSuffix);
        StringWritable.writeStringNull(out, userId);
        out.writeInt(authorize);
    }
    
}
