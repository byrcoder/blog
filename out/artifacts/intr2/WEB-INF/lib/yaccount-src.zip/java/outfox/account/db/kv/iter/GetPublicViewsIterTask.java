/**
 * @(#)GetPublicViewsIterTask.java, 2013-2-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import java.util.ArrayList;
import java.util.List;

import outfox.account.data.PublicViewWritable;
import outfox.account.db.in.IPublicViewMappingDB.IPublicViewMappingIter;
import outfox.account.db.in.IteratorService;
import outfox.account.exceptions.AccException;

/**
 * only return MAX_COUNT number of parameter.
 * @author chen-chao
 */
public class GetPublicViewsIterTask extends AbstractIteratorTask<IPublicViewMappingIter>{
    private List<PublicViewWritable> publicViews;
    private int count;
    private static final int MAX_COUNT = 100;
    public GetPublicViewsIterTask(IteratorService<IPublicViewMappingIter> iterService, String startKey) {
        super(iterService,startKey);
    }
    
    @Override
    protected boolean isEnd(Object value) {
        return count >= MAX_COUNT;
    }

    @Override
    protected void preTask() {
        publicViews = new ArrayList<PublicViewWritable>();
        count = 0;
    }

    @Override
    protected void runTask(Object value) throws AccException {
        PublicViewWritable param = (PublicViewWritable)value;
        publicViews.add(param);
        count++;
    }

    @Override
    public Object returnValue() {
        return publicViews;
    }
}
