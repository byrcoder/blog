/**
 * @(#)SessionCookieVerifier.java, 2012-9-25. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc.protocol.impl;

import java.util.HashMap;
import java.util.Map;

import odis.rpc2.RpcException;
import outfox.account.conf.AccConst;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.exceptions.AccException;
import outfox.account.rpc.protocol.IRpcVerifierService;
import outfox.account.server.token.TokenManager;

/**
 * @author chen-chao
 */
public class RpcVerifierService implements IRpcVerifierService {

    private static class Holder {
        private static final RpcVerifierService instance = new RpcVerifierService();
    }
    
    public static RpcVerifierService getInstance() {
        return Holder.instance;
    }
    
    private RpcVerifierService() {
        
    }
    
    @Override
    public SessionCookieWritable verifySessionCookie(String sessionCookie, long expireTimeInMilli)
            throws RpcException, AccException {
        return TokenManager.verifySessionCookie(sessionCookie, expireTimeInMilli);
    }
    @Override
    public SessionCookieWritable verifySessionCookie(String sessionCookie, String product, long expireTimeInMilli)
            throws RpcException, AccException {
        SessionCookieWritable cookieWritable = verifySessionCookie(sessionCookie, expireTimeInMilli);
        if (cookieWritable != null) {
            if (!cookieWritable.getTpToken().product.equals(product)) {
                return null;
            }
        }
        return cookieWritable;
    }
    
    @Override
    public PersistTokenWritable verifyAuthToken(String token, long expireTimeInMilli, String ip) throws RpcException, AccException{
        Map<String, Object> info = new HashMap<String, Object>();
        info.put(AccConst.IP_ADDRESS, ip);
        return verifyAuthToken(info, token, expireTimeInMilli);
    }
    
    @Override
    public PersistTokenWritable verifyAuthToken(Map<String, Object> info, String token, long expireTimeInMilli)
            throws RpcException, AccException {
        
        Map<String, Object> result = TokenManager.verifyAuthToken(info, token, expireTimeInMilli);
        if (result == null) {
            return null;
        }
        return (PersistTokenWritable)result.get(AccConst.THIRD_PARTY_PERS_TOKEN);
    }
    
    @Override
    public PersistTokenWritable verifyAuthToken(String token, String product, long expireTimeInMilli)
            throws RpcException, AccException {
        Map<String, Object> result = null;
        PersistTokenWritable pw = verifyAuthToken(result, token, expireTimeInMilli);
        if (pw != null) {
            if (!pw.getTpToken().product.equals(product)) {
                return null;
            }
        }
        return pw;
    }

    @Override
    public PersistTokenWritable verifyAuthToken(String token, long expireTimeInMilli) throws RpcException,
            AccException {
        Map<String, Object> result = null;
        return verifyAuthToken(result, token, expireTimeInMilli);
    }
    
}
