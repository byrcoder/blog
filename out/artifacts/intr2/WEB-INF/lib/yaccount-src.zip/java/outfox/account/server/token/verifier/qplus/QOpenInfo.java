/**
 * @(#)QOpenInfo.java, 2012-3-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.qplus;

import net.sf.json.JSONObject;

/**
 * @author chen-chao
 */
public class QOpenInfo {

    private final String NAME_FACE = "face";

    private final String NAME_GENDER = "gender";

    private final String NAME_NICK = "nick";

    private final String NAME_OUTH = "outh";

    private String face;

    private String gender;

    private String nick;

    private String outh;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(QOpenInfo.class.getSimpleName());
        sb.append("[").append(NAME_FACE).append("=").append(this.face);
        sb.append(",").append(NAME_GENDER).append("=").append(this.gender);
        sb.append(",").append(NAME_NICK).append("=").append(this.nick);
        sb.append(",").append(NAME_OUTH).append("=").append(this.outh).append(
                "]");
        return sb.toString();
    }

    public JSONObject toJSONObject() {
        JSONObject json = new JSONObject();
        json.put(NAME_FACE, this.face);
        json.put(NAME_GENDER, this.gender);
        json.put(NAME_NICK, this.nick);
        json.put(NAME_OUTH, this.outh);
        return json;
    }

    public QOpenInfo() {}

    public String getFace() {
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getOuth() {
        return outh;
    }

    public void setOuth(String outh) {
        this.outh = outh;
    }
}
