/**
 * @(#)AliYunOSUserInfoWritable.java, 2013-8-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.user;

import net.sf.json.JSONObject;

/**
 * @author chen-chao
 */
public class AliYunOSUserInfoWritable extends UserInfoWritable {
    private static final long serialVersionUID = 7409947394330095376L;
    public static final String YUNOS = "yunos";
    public static final String DATA = "data";
    public static final String LOGIN_ID = "loginId";
    public AliYunOSUserInfoWritable(){
        super();
    }
    public AliYunOSUserInfoWritable(String userId,String originalId, JSONObject obj) {
        this.userId = userId;
        this.originalId = originalId;
        this.from = YUNOS;
        final JSONObject data = obj.getJSONObject("data");
        this.userName = data.getString(LOGIN_ID);
    }
}
