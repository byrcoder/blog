/**
 * @(#)OmapKeyValueStore.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv;
/**
 * @(#)OmapKeyValueStore.java, 2010-6-22. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

import java.util.Arrays;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.omap.client.protocol.DataSourceFactory;
import outfox.omap.client.protocol.Row;
import outfox.omap.client.protocol.Table;
import outfox.omap.client.protocol.TableCursor;
import outfox.omap.client.protocol.TableSpace;
import outfox.omap.exceptions.OmapException;
import outfox.omap.util.OmapUtils;

/**
 *
 * @author wangfk
 *
 */
public class OmapKeyValueStore extends AbstractKeyValueStore<IWritableComparable, IWritable> {
    private static final Log LOG = LogFactory.getLog(OmapKeyValueStore.class);
    
    public static final String KEY_COLUMN = "key";
    public static final String VALUE_COLUMN = "value";
    
    private static final String DEFUALT_DATA_SOURCE =
        AccConfig.getPros().getString(
                AccConfig.NAME_OMAP_DATA_SOURCE);
    
    private static final int DEFAULT_CURSOR_PREFETCH_SIZE = 20;
    
    private Table table;
    
    private String dataSource;
    
    private String[] types;
    
    /**
     * Open an omap table with its space and name, using default datasource
     * 
     * @param storeSpace table space
     * @param storeName table name
     * @param types
     * @throws YDriveServerStoreException 
     */
    public OmapKeyValueStore(String storeSpace, String storeName, String[] types
            ) {
        this(storeSpace, storeName, DEFUALT_DATA_SOURCE, types);
    }
    
    /**
     * Open an omap table with its space and name
     * 
     * @param storeSpace table space
     * @param storeName table name
     * @param dataSource
     * @param types
     * @throws YDriveServerStoreException 
     */
    public OmapKeyValueStore(String storeSpace, String storeName,
            String dataSource, String[] types
            ) {
        this.storeSpace = storeSpace;
        this.storeName = storeName;
        this.dataSource = dataSource;
        this.types = Arrays.copyOf(types, types.length);
        
        openTable();
    }
    
    /**
     * Open the table, create a new one iff not exists
     * @throws YDriveServerStoreException
     */
    public void openTable() {
        if(table != null) {
            LOG.warn("Table is opened, can not open again, table name = "
                    + getTableNameWithSpace());
        }
        TableSpace tableSpace;
        try {
            tableSpace = DataSourceFactory.getNamed(dataSource, AccConfig.isReuseTableMode()).openTableSpace(storeSpace);
            if(tableSpace.findTable(storeName) != null ) {
                table = tableSpace.openTable(storeName);
            }else {
                LOG.debug("There is no table defined: " + getTableNameWithSpace() + ". " +
                                "Maybe this is the first time for store data, just create it.");
                String[] columns = {KEY_COLUMN, VALUE_COLUMN};
                table = tableSpace.createTable(storeName, columns, types);
            }
            LOG.info("Table is open or created: " + getTableNameWithSpace());
        } catch (OmapException e) {
            throw new AccRunTimeException("Open or create table failure, " +
                        "table name = " + getTableNameWithSpace(), e);
        }
    }
    
    /**
     * Adapter to {@link IKeyValueStore.Iter}
     * @author wangfk
     *
     */
    private class IterImpl implements IKeyValueStore.Iter<IWritableComparable, IWritable> {

        private TableCursor tableCursor;

        private IterImpl() throws AccException {
            try {
                tableCursor = table.getTableCursor();
                tableCursor.setPrefetch(DEFAULT_CURSOR_PREFETCH_SIZE);
            } catch (OmapException e) {
                throw new AccException(
                        "Create table iterator failure", e,
                        AccExpType.STORE_SERVICE_EXCEPTION);
            }
        }

        @Override
        public void close(){
            try {
                tableCursor.close();
            } catch (OmapException e) {
                LOG.warn("Close table iterator failure. Table Name ="
                        + getTableNameWithSpace(), e);
            }
        }

        @Override
        public boolean next(IWritableComparable key, IWritable value)
                throws AccException {
            try {
                Row row = table.newRow();
                if(tableCursor.next(row)) {
                    if(key != null) {
                        row.get(KEY_COLUMN, key);
                    }
                    if(value != null) {
                        row.get(VALUE_COLUMN, value);
                    }
                    return true;
                }
                return false;
            } catch (OmapException e) {
                throw new AccException(
                        "Cursor exception, table name = " + getTableNameWithSpace(),
                        e, AccExpType.STORE_SERVICE_EXCEPTION);
            }
        }

        @Override
        public boolean seekTo(IWritableComparable key, boolean accurate)
                throws AccException {
            try {
                return tableCursor.moveTo(key, accurate);
            } catch (OmapException e) {
                throw new AccException(
                        "Seek exception, table name = " + getTableNameWithSpace(),
                        e, AccExpType.STORE_SERVICE_EXCEPTION);
            }
        }
    }


    @Override
    public boolean readValue(IWritableComparable key, IWritable value)
            throws AccException {
        try {
            Row row = table.newRow();
            if(table.lookup(key, row)) {
                row.get(VALUE_COLUMN, value);
                return true;
            }
        } catch (OmapException e) {
            throw new AccException(
                    "Lookup exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
        return false;
    }

    @Override
    public void writeKeyValue(IWritableComparable key, IWritable value)
            throws AccException {
        try {
            Row row = table.newRow();
            row.set(KEY_COLUMN, key);
            row.set(VALUE_COLUMN, value);
            table.update(row);
        } catch (OmapException e) {
            throw new AccException(
                    "Update exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
    }

    @Override
    public void writeKeyValues(IWritableComparable[] keys, IWritable[] values) 
            throws AccException {
        if(keys.length != values.length) {
            throw new AccRunTimeException(
                    "Keys number is not consistent with values.");
        }
        try {
            Row[] rows = new Row[keys.length];
            for (int i = 0; i < keys.length; i++) {
                rows[i] = table.newRow();
                rows[i].set(KEY_COLUMN, keys[i]);
                rows[i].set(VALUE_COLUMN, values[i]);
            }
            table.update(rows);
        } catch (OmapException e) {
            throw new AccException(
                    "Update exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
    }

    @Override
    public void deleteKeys(IWritableComparable[] keys)
            throws AccException {
        try {
            table.delete(keys);
        } catch (OmapException e) {
            throw new AccException(
                    "Delete keys exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
    }

    private String getTableNameWithSpace() {
        return OmapUtils.toInternalTableName(storeSpace, storeName);
    }

    @Override
    public void close() {
        table.close();
    }

    @Override
    public void deleteKey(IWritableComparable key)
            throws AccException {
        try {
            table.delete(key);
        } catch (OmapException e) {
            throw new AccException(
                    "Delete exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
    }

    @Override
    public void readValues(IWritableComparable[] keys, IWritable[] values)
            throws AccException {
        Row[] rows = new Row[keys.length];
        try {
            for(int i = 0; i < rows.length; ++ i) {
                rows[i] = table.newRow();
            }
            boolean[] lookup = table.lookup(keys, rows);
            for(int i = 0; i < rows.length; ++ i) {
                if(lookup[i]) {
                    rows[i].get(VALUE_COLUMN, values[i]);
                }else {
                    values[i] = null;
                }
            }
        } catch (OmapException e) {
            throw new AccException(
                    "Read values exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
    }
    
    

    @Override
    public IKeyValueStore.Iter<IWritableComparable, IWritable> getIter() 
            throws AccException {
        return new IterImpl();
    }

    @Override
    public boolean containsKey(IWritableComparable key)
            throws AccException {
        try {
            return table.contains(key);
        } catch (OmapException e) {
            throw new AccException(
                    "Contains check exception, table name = " + getTableNameWithSpace(),
                    e, AccExpType.STORE_SERVICE_EXCEPTION);
        }
    }
}
