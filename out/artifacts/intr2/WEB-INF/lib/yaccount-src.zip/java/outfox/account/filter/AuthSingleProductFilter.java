/**
 * @(#)AuthSingleProductFilter.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.AccCookies;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.device.DeviceManager;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.handler.BaseHandler;
import outfox.account.logic.event.AccEvent;
import outfox.account.server.token.TokenManager;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;
import outfox.account.utils.UrsUtils;
import toolbox.web.CookieUtil;
import account.app.CheckFilter;
import account.app.WebUtil;

import com.netease.urs.CookieNames;

/**
 * @author chen-chao
 */
public class AuthSingleProductFilter extends BaseHandler implements Filter{
    private static final long serialVersionUID = 8579425310318281432L;
    private String product;
    public static final String NICK_NAME_ATTR = AccConst.ATTR_NICK_NAME;
    public static final String URS_EMAIL_ATTR = AccConst.ATTR_URS_EMAIL;
    private static final String NAME_FORCE_TO_PUT_PASSWORD = "forcepassword";
    private boolean ursLoginCompatible;
    private String loginUrl;
    private boolean inputPasswordEnable=false;
    private String backendReloginDomain;
    private boolean isInit = false;
    private boolean checkPersToken;
    private boolean ursMemoryCheck;
    private boolean wantUserInfo = true;
    private static final DataStore store = DataStore.getInstance();
    private static final TokenVerifierFactory tf = TokenVerifierFactory.getInstance();
    @Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain) throws IOException,
            ServletException {
        HttpServletRequest req = (HttpServletRequest) arg0;
        HttpServletResponse resp = (HttpServletResponse) arg1;
        String userId = null;
        try {
            if (StringUtils.isNotBlank(loginUrl) && inputPasswordEnable
                    && Boolean.parseBoolean(req.getParameter(NAME_FORCE_TO_PUT_PASSWORD))) {
                // redirect to login page
                // clean cookie first.
                AuthUtils.cleanCookies(req, resp, product);
                resp.sendRedirect(getRedirectLoginUrl(req));
                return;
            }
            if (!StringUtils.isBlank((String)req.getAttribute(AccConst.USER_ID_ATTR))) {
                chain.doFilter(req, resp);
                return;
            }
            TokenManager.verifySessionCookie(product, req, resp);
            String id = product + AccConst.ATTR_PART_USER_ID;
            if (AuthUtils.isDebug(req)) {
                // debug here.
                LOG.debug("");
            }
            
            if (StringUtils.isBlank((String)req.getAttribute(id))) {
                // If this is not required to check persist token, please set checkPersToken to false
                // because persist token may conflict with session cookie
                // try persist token
                if (checkPersToken) {
                    Map<String, Object> result = TokenManager.verifyAuthToken(product, req, resp);
                    if (result != null) {
                        PersistTokenWritable pers = (PersistTokenWritable) req.getAttribute(product + AccConst.ATTR_PART_PERSTOKEN_WRITABLE);
                        if (pers != null) {
                            //set request attribute here
                            req.setAttribute(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value());
                            req.setAttribute(AccConst.PARAM_URS_MEMORY_COOKIE, ursMemoryCheck);
                            
                            TpToken token = pers.getTpToken();
                            IVerifier verifier = tf.getTokenVerifier(token.product, token.verifierName);
                            TokenUtils.encode(verifier, token);
                            AccCookies accCookies = TokenUtils.genCookieByCookieParam(req, token);
                            if (accCookies != null) {
                                accCookies.addCookieToResponse(resp);
                            }
                        }
                    }
                    
                    if (AuthUtils.isDebug(req)) {
                        // debug here.
                        LOG.debug(result);
                    }
                }
                
                if (StringUtils.isBlank((String)req.getAttribute(id))) {
                    // try urs cookies
                    if (ursLoginCompatible) {
                        String email = UrsUtils.extractInfoFromCookie(req, resp,
                                backendReloginDomain, -1, true,
                                true)[0];
                        if (AuthUtils.isDebug(req)) {
                            // debug here.
                            LOG.debug(email);
                        }
                        userId = email;
                    }
                } else {
                    userId = (String)req.getAttribute(id);
                }
            } else {
                userId = (String)req.getAttribute(id);
            }
            req.setAttribute(id, userId);
            req.setAttribute(AccConst.USER_ID_ATTR, userId);
            // set EMAIL_ATTR, for analyzer log
            req.setAttribute(CheckFilter.EMAIL_ATTR, userId);
            if (userId != null && wantUserInfo) {
                UserInfoWritable userInfo = ReqUtils.getUserInfo(req, product);
                if (userInfo == null) {
                    userInfo = store.readUserInfo(userId);
                }
                if (userInfo == null) {
                    throw new AccException("error user id:"+userId, AccExpType.LOGIC_ERROR);
                }
                req.setAttribute(NICK_NAME_ATTR, userInfo.userName);
                req.setAttribute(URS_EMAIL_ATTR, userInfo.email);
                req.setAttribute(product + AccConst.ATTR_PART_USER_ID_WRITABLE, userInfo);
            }
            // check device status.
            List<AccEvent> eventList = new ArrayList<AccEvent>();
            List<Parameter> deviceCheckResult = new ArrayList<Parameter>();
            if (!DeviceManager.tryTransferStatus(product, userId, OPERATOR.FILTER, 
                    null, req, deviceCheckResult, eventList)) {
                AuthUtils.writeJSONChunked(resp, params2JSON(deviceCheckResult), 
                        HttpStatus.SERVICE_UNAVAILABLE);
                return;
            }
            
            if (StringUtils.isNotBlank(loginUrl) && StringUtils.isBlank((String)req.getAttribute(AccConst.USER_ID_ATTR))) {
                // redirect
                resp.sendRedirect(getRedirectLoginUrl(req));
                return;
            } 
        } catch (Throwable e) {
            if (AuthUtils.isDebug(req)) {
                // debug here.
                LOG.debug("");
            }
            String errInfo = getQueryUrl(req);
            LOG.warn("request:" + errInfo, e);
        }
        chain.doFilter(req, resp);
    }

    @Override
    public void init(FilterConfig conf) throws ServletException {
        if (!isInit) {
            product = getParamStr(conf, "product", "ynote");
            ursLoginCompatible = getParamBoolean(conf, "urs_login", false);
            backendReloginDomain = getParamStr(conf, "backend_relogin_domain", ".youdao.com");
            checkPersToken = getParamBoolean(conf, "checkPersToken", false);
            ursMemoryCheck = getParamBoolean(conf, "ursMemoryCheck", false);
            loginUrl = getParamStr(conf, "login_url", null);
            wantUserInfo = getParamBoolean(conf,"want_user_info", true);
            inputPasswordEnable = getParamBoolean(conf, "input_password_enable", false);
        }
    }
    
    public String getProduct() {
        return product;
    }

    public void setInit(boolean isInit) {
        this.isInit = isInit;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public void setUrsLoginCompatible(boolean ursLoginCompatible) {
        this.ursLoginCompatible = ursLoginCompatible;
    }

    public void setBackendReloginDomain(String backendReloginDomain) {
        this.backendReloginDomain = backendReloginDomain;
    }
    
    public void setUrsMemoryCheck(boolean ursMemoryCheck) {
        this.ursMemoryCheck = ursMemoryCheck;
    }

    public void setCheckPersToken(boolean checkPersToken) {
        this.checkPersToken = checkPersToken;
    }
    public void setLoginUrl(String loginUrl) {
        this.loginUrl = loginUrl;
    }
    
    public void setWantUserInfo(boolean wantUserInfo) {
        this.wantUserInfo = wantUserInfo;
    }
    
    public static final String RELOGIN = "relogin";
    public static final String BACK_URL = "back_url";
    private String getRedirectLoginUrl(HttpServletRequest req)
            throws AccException, IOException {
        // Redirect to the login page.
        String backUrl = CheckFilter.getBackUrl(req, AccConst.UTF8);
        String referer = req.getHeader("Referer");
        if (referer != null) {
            backUrl = WebUtil.appendPara(backUrl, "oreferer", referer);
        }
        List<Parameter> params = new ArrayList<Parameter>();
        backUrl = protocalReplace(req, backUrl);
        if (backUrl != null) {
            backUrl = backUrl.replace(NAME_FORCE_TO_PUT_PASSWORD + "=true", NAME_FORCE_TO_PUT_PASSWORD
                    + "=false");
        }
        
        params.add(new Parameter(BACK_URL, backUrl));
        
        if (CookieUtil.findCookie(req, CookieNames.NTES_PASSPORT) != null) {
            // If exist Persistent Cookie
            params.add(new Parameter(RELOGIN, "1"));
        } 
        String otherLoginUrl = loginUrl;
        if (otherLoginUrl.startsWith(AccConst.URL_ROOT)) {
            String scheme = null;
            if (AuthUtils.isHttpsProtocal(req)) {
                scheme = AccConst.HTTPS_PROTOCAL;
            }
            otherLoginUrl = AuthUtils.generateAbsoluteUrl(req, "", otherLoginUrl, scheme);
        }
        String url = AuthUtils.composeQueryUrl(otherLoginUrl, params);
       
        LOG.info("not login, redirect to " + url);
        return url;
    }
    
    private String protocalReplace(HttpServletRequest req, String url) throws AccException {
        if (AuthUtils.isHttpsProtocal(req)) {
            if (url != null && !url.startsWith(AccConst.HTTPS_PROTOCAL)) {
                // replace it as https protocal
                url = url.replace("http://", "https://");
            }
        }
        return url;
    }
}
