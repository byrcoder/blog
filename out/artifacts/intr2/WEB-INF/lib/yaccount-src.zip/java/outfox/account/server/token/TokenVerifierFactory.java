/**
 * @(#)TokenVerifierFactory.java, 2012-8-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.VerifierType;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.verifier.IOauthVerifier;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.server.token.verifier.PluginFinder;
import outfox.account.server.token.verifier.Verifier;
import outfox.account.server.token.verifier.impl.TSinaVerifier;
import outfox.account.server.token.verifier.loader.VerifierLoader;
import outfox.account.utils.AuthUtils;

/**
 * you should write configure file first, then write your third-party plugin.
 * @author wangfk
 * @author chen-chao
 */
public class TokenVerifierFactory {
    private static final int INIT_SIZE = 1024;
    private static final Log LOG = LogFactory.getLog(TokenVerifierFactory.class);
    private Hashtable<String, IVerifier> cache = null;
    private TokenVerifierFactory() {
        cache = new Hashtable<String, IVerifier>(INIT_SIZE);
        
        init();
    }
    
    private Set<Class<? extends Verifier>> getPlugins() {
        Set<Class<? extends Verifier>> verifiers = new HashSet<Class<? extends Verifier>>();
        Set<Class<? extends Verifier>> tmp = PluginFinder.getPluginsInSameDir(TSinaVerifier.class);
        if (tmp != null) {
            verifiers.addAll(tmp);
        }
        String[] classNames = AccConfig.getPros().getString(AccConfig.NAME_PLUGIN_CLASS_NAMES).split(";");
        for (String name : classNames) {
            if (StringUtils.isBlank(name)) {
                continue;
            }
            tmp = null;
            try {
                tmp = PluginFinder.getPluginsInSameDir(name);
            } catch(AccRunTimeException e) {
                LOG.warn("get plugin from config wrong, check config:"+ AccConfig.NAME_PLUGIN_CLASS_NAMES, e.getCause());
                System.out.println("get plugin from config wrong, check "+ AccConfig.NAME_PLUGIN_CLASS_NAMES + e.getCause());
                continue;
            }
            if (tmp != null) {
                verifiers.addAll(tmp);
            }
        }
        return verifiers;
    }
    
    private void init() {
        Map<String, Properties> props = VerifierLoader.init();
        Set<Class<? extends Verifier>> verifiers = getPlugins();
        if (verifiers.size() == 0) {
            System.out.println("no plugin!!");
            throw new AccRunTimeException(new AccException("no plugin!!", AccExpType.NOT_SUPPORT));
        }
        for (Entry<String, Properties> entry : props.entrySet()) {
            String product = entry.getKey();
            for (Class<?> cls : verifiers) {
                Constructor<?> cons = null;
                try {
                    cons = cls.getDeclaredConstructor(Properties.class);
                } catch (Exception e) {
                    LOG.warn("cannot get constructor of " + cls.getCanonicalName(), e);
                    continue;
                }
                // if can not access. it will throw exceptions.
                if ((cons.getModifiers() & Modifier.PUBLIC) == 0) {
                    LOG.warn("can not access the constructor of " + cls.getCanonicalName());
                    continue;
                }
                Properties properties = entry.getValue();
                properties.setProperty(AccConst.NAME_PRODUCT, product);
                try {
                    Verifier verifier = (Verifier)cons.newInstance(properties);
                    cache.put(getVerifierID(product, verifier.getVerifierName()), verifier);
                } catch (InvocationTargetException e) {
                    // some product may remove some third-party, it will throw some AccException
                    Throwable t = e.getTargetException();
                    if (t instanceof AccRunTimeException) {
                        t = ((AccRunTimeException)t).getCause();
                        if (t instanceof AccException) {
                            if (((AccException)t).getExceptionType() == AccExpType.NOT_SUPPORT) {
                                // do nothing.
                                continue;
                            }
                        }
                    }
                    LOG.warn("can not create instance of ", t);
                    throw new AccRunTimeException("can not create instance of " + cls.getCanonicalName(), t);
                } catch (Exception e) {
                    LOG.warn("can not create instance of ", e);
                    throw new AccRunTimeException("can not create instance of " + cls.getCanonicalName(), e);
                }
            }
        }
    }
    
    public void reload() {
        // check if file is change. 
        synchronized (this) {
            cache = null;
            cache = new Hashtable<String, IVerifier>(INIT_SIZE);
            init();
        }
    }

    private static class FactoryHolder {
        private static final TokenVerifierFactory instance = new TokenVerifierFactory();
    }
    
    public static TokenVerifierFactory getInstance() {
        return FactoryHolder.instance;
    }
    
    public IVerifier getTokenVerifier(HttpServletRequest req, HttpServletResponse resp) {
        String product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        String tp = AuthUtils.getReqVal(req, AccConst.PARAM_THIRD_PARTY_NAME);
        return getTokenVerifier(product, tp);
    }
    
    public String getVerifierID(String product, String thirdPartyName) {
        return product + "-" + thirdPartyName;
    }
    
    public IVerifier getTokenVerifier(String product, String thirdPartyName) {
        IVerifier verifier = cache.get(getVerifierID(product, thirdPartyName));
        if ( verifier == null) {
            throw new AccRunTimeException("product: " + product + " not support the tp: " + thirdPartyName);
        }
        return verifier;
    }
    
    public VerifierType getVerifierType(HttpServletRequest req, HttpServletResponse resp) {
        IVerifier verifier = getTokenVerifier(req, resp);
        return getVerifierType(verifier);
    }

    public VerifierType getVerifierType(IVerifier verifier) {
        if (verifier instanceof Oauth2Verifier) {
            return VerifierType.Oauth2;
        } else if (verifier instanceof IOauthVerifier) {
            return VerifierType.Oauth;
        } else {
            return VerifierType.Common;
        }
    }

    /**
     * for testcase
     * @param product
     * @param thirdPartyName
     * @param verifier
     */
    public void setTokenVerifier(String product, String thirdPartyName, IVerifier verifier) {
        final String verifierID = getVerifierID(product, thirdPartyName);
        LOG.info(String.format("add verifier ID: %s.", verifierID));
        cache.put(verifierID, verifier);
    }
}
