/**
 * @(#)SessionCookieWritable.java, 2012-8-15. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 *
 * @author wangfk
 * @author chen-chao
 *
 */
public class SessionCookieWritable extends AbstractWritable {
    private static final long serialVersionUID = -5025227363021605886L;
    
    public void setSessAliveTime(Long aliveTime) {
        tpToken.setSessAliveTime(aliveTime);
    }
    
    public long getSessAliveTime() {
        return tpToken.getSessAliveTime();
    }
    
    private long sessCreateTime;
    public long getSessCreateTime() {
        return sessCreateTime;
    }

    public void setSessCreateTime(long sessCreateTime) {
        this.sessCreateTime = sessCreateTime;
    }

    public TpToken getTpToken() {
        return tpToken;
    }

    public void setTpToken(TpToken tpToken) {
        this.tpToken = tpToken;
    }
    private TpToken tpToken;
    public SessionCookieWritable(TpToken tp) {
        if (tp != null) {
            this.tpToken = tp;
        } else {
            this.tpToken = new TpToken();
        }
        sessCreateTime = System.currentTimeMillis();
    }
    
    public SessionCookieWritable() {
        this(null);
    }
    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        sessCreateTime = in.readLong();
        tpToken.readFields(in);
    }
    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        out.writeLong(sessCreateTime);
        tpToken.writeFields(out);
    }
    
}
