/**
 * @(#)TokenManager.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.AccConst.VerifierType;
import outfox.account.data.AccCookies;
import outfox.account.data.CacheInfo;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TokenData;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.db.DataStore.MappingRelationship;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.verifier.IOauthVerifier;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.server.token.verifier.Verifier.TwoPart;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;
import outfox.account.utils.UrsUtils.WapperURSCookieInfo;
import toolbox.web.CookieUtil;
import account.app.CheckFilter;

/**
 * @author chen-chao
 */
public class TokenManager {
    protected static final Log LOG = LogFactory.getLog(TokenManager.class);
    private static DataStore datastore = DataStore.getInstance();
    private static TokenVerifierFactory tf = TokenVerifierFactory.getInstance();
    
    /**
     * request third party to authorize
     */
    public static Map<String, Object> authReq(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        IVerifier verifier = tf.getTokenVerifier(req, resp);
        if (!AccConfig.isStressTest() || VerifierType.Oauth2.equals(tf.getVerifierType(verifier))) {
            return verifier.authRequest(req, resp);
        }
        // stress test
        return verifier.stress(req, resp);
    }
    
    public static VerifierType getVerifierType(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        return tf.getVerifierType(req, resp);
    }
    /**
     * this function is only used in callback handler
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    public static UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp)throws AccException {
        IVerifier verifier = tf.getTokenVerifier(req, resp);
        return verifier.getUserInfo(req, resp);
    }
    
    
    public static SessionCookieWritable verifySessionCookie(String cookieValue, long expiredTime) throws AccException {
        if (cookieValue != null) {
            String orgCookieValue = getOriginalToken(cookieValue);
            if (orgCookieValue.startsWith(AccConst.URS_MEMORY_CHECK)) {
                WapperURSCookieInfo cookieInfo= UrsUtils.getInfoFromCookieValue(orgCookieValue);
                String product = cookieInfo.product;
                
                String ursSessCookieValue = cookieInfo.sessCookieVal;
                
                AccConfig.checkURSTokenMemoryProduct(product);
                // urs session cookie check.
                long defaultExpTime = AccConfig.getPros().getLong(AccConfig.NAME_COOKIE_SESS_MAX_AGE);
                long expTime = (expiredTime == -1) ? defaultExpTime : Math.min(defaultExpTime, expiredTime);
                expTime = (cookieInfo.expiredTime == -1) ? expTime : Math.min(cookieInfo.expiredTime, expTime);
                
                String[] info = UrsUtils.extractInfoBySessionCookie(ursSessCookieValue, expTime);
                
                final String userId = info[0];
                if (info != null && StringUtils.isNotBlank(userId) && cookieInfo.userId.equals(userId)) {
                    // generate fake tpToken and sessionCookieWritable
                    TpToken tp = new TpToken();
                    tp.setSessAliveTime(expTime);
                    tp.setExpiredTime(expTime);
                    tp.userId = userId;
                    tp.sessIndex = orgCookieValue;
                    tp.product = product;
                    tp.verifierName = cookieInfo.verifierName;
                    return new SessionCookieWritable(tp);
                }
                
            } else {
                return datastore.getAliveSession(orgCookieValue, expiredTime);    
            }
        }
        return null;
    }
    
    private static void skipOlderFilterOrNot(AccCookies cookies, HttpServletRequest req, HttpServletResponse resp) {
        Cookie sessionCookie = cookies.getSessionCookie();
        if (sessionCookie != null && AuthUtils.isV2Token(sessionCookie.getValue())){
            req.setAttribute(AccConst.ATTR_NOT_CHECK_V1_SESS_COOKIE, true);
        } 
        Cookie bindCookie = cookies.getBindCookie();
        if (bindCookie != null && AuthUtils.isV2Token(bindCookie.getValue())){
            req.setAttribute(AccConst.ATTR_NOT_CHECK_V1_BIND_COOKIE, true);
        }
        String persToken = cookies.getPerToken();
        if (isCheckNewPersToken(req, persToken)){
            req.setAttribute(AccConst.ATTR_NOT_CHECK_V1_PERS_COOKIE, true);
        }
    }

    protected static boolean isCheckNewPersToken(HttpServletRequest req, String persToken) {
        return persToken != null && AuthUtils.isV2Token(persToken) && ((req == null) || (req != null &&  StringUtils.isBlank(req.getHeader(AccConst.PARAM_PC_NAME))));
    }
    
    public static void verifySessionCookie(String product, HttpServletRequest req, HttpServletResponse resp) throws AccException {
        Cookie c = CookieUtil.findCookie(req, product + AccConst.COOKIE_LOGIN);
        if (c == null) {
            // not login return.
            return;
        }
        
        AccCookies accCookies = AccCookies.extractCookies(req, product);
        Cookie sessionCookie = accCookies.getSessionCookie();
        Cookie bindCookie = accCookies.getBindCookie();
        // if has new version cookie, old filter should not work.
        skipOlderFilterOrNot(accCookies, req, resp);
        
        if (req.getAttribute(AccConst.ATTR_LOGIN_SET) == null) {
            Set<String> loginProducts = new HashSet<String>();
            req.setAttribute(AccConst.ATTR_LOGIN_SET, loginProducts);
        }
        if (req.getAttribute(AccConst.ATTR_BIND_SET) == null) {
            Set<String> bindProducts = new HashSet<String>();
            req.setAttribute(AccConst.ATTR_BIND_SET, bindProducts);
        }

        if (AuthUtils.getBooleanAttr(req, AccConst.ATTR_NOT_CHECK_V1_SESS_COOKIE, false)) {
            getUserInfoFromCookie(req, sessionCookie, product, AccConst.ATTR_PART_USER_ID, AccConst.ATTR_PART_SESS_WRITABLE,
                    AccConst.ATTR_LOGIN_SET);
        }
        
        if (AuthUtils.getBooleanAttr(req, AccConst.ATTR_NOT_CHECK_V1_BIND_COOKIE, false)) {
            getUserInfoFromCookie(req, bindCookie, product, AccConst.ATTR_PART_BIND_USER_ID, AccConst.ATTR_PART_BIND_WRITABLE,
                    AccConst.ATTR_BIND_SET);
        }
    }
    
    public static void verifySessionCookie(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        for (String product : AccConfig.getProductSet()) {
            verifySessionCookie(product, req, resp);
        }
        Set<?> set = (Set<?>)req.getAttribute(AccConst.ATTR_LOGIN_SET);
        if (set.size() == 0) {
            throw new AccException(AccExpType.NO_LOGIN);
        }
    }
    
    private static SessionCookieWritable getSessCookieWritableBySessCookie(HttpServletRequest req,Cookie sessionCookie,String product) throws AccException {
        if (sessionCookie != null) {
            String sessIndex = sessionCookie.getValue();
            if (sessIndex != null) {
                long expiredTimeInMilli = AuthUtils.getReqLong(req, product + AccConst.ATTR_PART_SESSION_EXPIRE_TIME, -1);
                SessionCookieWritable session = verifySessionCookie(sessIndex, expiredTimeInMilli);
                if (!AuthUtils.isDebug(req)) {
                    // debug here.
                    LOG.debug("");
                }
                return session;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static void getUserInfoFromCookie(HttpServletRequest req, Cookie sessionCookie, String product,
            String partUserId, String partWritableName, String setName) throws AccException {
        SessionCookieWritable session = getSessCookieWritableBySessCookie(req, sessionCookie, product);
        if (session != null) {
            Set<String> set = (Set<String>) req.getAttribute(setName);
            set.add(product);
            AuthUtils.setAttributeIfNull(req, product + partUserId, session.getTpToken().userId);
            if (AccConst.ATTR_PART_USER_ID.equals(partUserId)) {
                // only sess cookie can set this attribute. Bind cookie can not set the attribute.
                AuthUtils.setAttributeIfNull(req, AccConst.USER_ID_ATTR, session.getTpToken().userId);
                // set EMAIL_ATTR, for analyzer log
                AuthUtils.setAttributeIfNull(req, CheckFilter.EMAIL_ATTR, session.getTpToken().userId);
            }
            req.setAttribute(product + partWritableName, session);
        }
    }
    
    public static Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expiredTime) throws AccException {
        // token is not null, old filter should not check again
        if (!isCheckNewPersToken(req, token)){
            return null;
        }
        req.setAttribute(AccConst.ATTR_NOT_CHECK_V1_PERS_COOKIE, true);
        token = getOriginalToken(token);
        // there should check database again and again, it won't use any cache.
        TwoPart tw = TokenUtils.getProductAndVerifierName(token);
        String product = tw.first;
        IVerifier verifier = tf.getTokenVerifier(product, tw.second);
        return verifier.verifyAuthToken(req, resp, token, expiredTime);
    }
    
    public static Map<String, Object> verifyAuthToken(Map<String,Object> information , String token, long expiredTime) throws AccException {
        token = getOriginalToken(token);
        // there should check database again and again, it won't use any cache.
        TwoPart tw = TokenUtils.getProductAndVerifierName(token);
        String product = tw.first;
        IVerifier verifier = tf.getTokenVerifier(product, tw.second);
        return verifier.verifyAuthToken(information, token, expiredTime);
    }

    private static String getOriginalToken(String token) {
        return token.substring(AccConst.V2_FLAG_LENGTH);
    }
    
    /**
     * 
     * @param product
     * @param req
     * @param resp
     * @return
     * if no token, the function will return null.
     * @throws AccException
     */
    public static Map<String, Object> verifyAuthToken(String product, HttpServletRequest req, HttpServletResponse resp)throws AccException {
        if (req.getAttribute(AccConst.ATTR_LOGIN_SET) == null) {
            Set<String> loginProducts = new HashSet<String>();
            req.setAttribute(AccConst.ATTR_LOGIN_SET, loginProducts);
        }
        TokenData token = TokenData.extractTokenDataFromReq(req, product);
        Map<String, Object> map = null;
        if (token == null) {
            AccCookies extractCookies = AccCookies.extractCookies(req, product);
            Cookie persCookie = extractCookies.getPersCookie();
            if (persCookie != null) {
                token = new TokenData(persCookie.getValue(), -1L);
            }
        }
        if (token != null) {
            req.setAttribute(AccConst.ATTR_CHECKED_PC, token.token);
            map = verifyAuthToken(req, resp, token.token, token.expireTime);
            fillReqAttr(product, req, map, token.token);
        }
        return map;
    }

    public static void fillReqAttr(String product, HttpServletRequest req, Map<String, Object> map,
            String persToken) {
        if (map != null) {
            req.setAttribute(product + AccConst.ATTR_PART_PC, persToken);
            req.setAttribute(product + AccConst.ATTR_PART_PERSTOKEN_WRITABLE, map.get(AccConst.THIRD_PARTY_PERS_TOKEN));
            
            UserInfoWritable userInfoWritable = (UserInfoWritable)map.get(AccConst.USER_INFO_WRITABLE);
            if (userInfoWritable != null) {
                AuthUtils.setAttributeIfNull(req, product + AccConst.ATTR_PART_USER_ID_WRITABLE, userInfoWritable);
                AuthUtils.setAttributeIfNull(req, product + AccConst.ATTR_PART_USER_ID, userInfoWritable.userId);
                if (req.getAttribute(AccConst.USER_ID_ATTR) == null) {
                    req.setAttribute(AccConst.USER_ID_ATTR, userInfoWritable.userId);
                    // set EMAIL_ATTR, for analyzer log
                    req.setAttribute(CheckFilter.EMAIL_ATTR, userInfoWritable.userId);
                    //set nickname
                    req.setAttribute(AccConst.ATTR_NICK_NAME, userInfoWritable.userName);
                }
            }
            // add login
            @SuppressWarnings("unchecked")
            Set<String> set = (Set<String>)req.getAttribute(AccConst.ATTR_LOGIN_SET);
            set.add(product);
        }
    }
    
    /**
     * 
     * @param req
     * @param resp
     * @return
     * if no token, the function will throw exception
     * @throws AccException
     */
    public static Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp)throws AccException {
        Map<String, Object> result = new HashMap<String, Object>();
        for (String product : AccConfig.getProductSet()) {
            Map<String,Object> map = verifyAuthToken(product, req, resp);
            if (map != null) {
                result.put(product, map);
            }
        }
        if (result.size() == 0) {
            throw new AccException(AccExpType.NO_PERS_TOKEN);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> genSessionByAuthToken(HttpServletRequest req, HttpServletResponse resp)throws AccException {
        Map<String,Object> result = verifyAuthToken(req, resp);
        if (result != null && result.size() != 0) {
            for (Entry<String,Object> tokenInfo : result.entrySet()) {
                Object value = tokenInfo.getValue();
                
                Map<String,Object> map = (Map<String,Object>)value;
                PersistTokenWritable tokenWritable = (PersistTokenWritable)map.get(AccConst.THIRD_PARTY_PERS_TOKEN);
                AccCookies cookies = new AccCookies(tokenInfo.getKey(), req, AccConfig.CLIENT_TYPE_PC);
                cookies.genSessCookie(tokenWritable.getTpToken().sessIndex);
                cookies.addCookieToResponse(resp);
            }
            
        } else {
            throw new AccException(AccExpType.NO_PERS_TOKEN);
        }
        return result;
    }
    /**
     * only used in callback handler
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    public static Map<String, Object> genAuthToken(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        GlobalCache glcache = GlobalCache.getInstance();
        IVerifier verifier = tf.getTokenVerifier(req, resp);
        if (!(verifier instanceof Oauth2Verifier)) {
            throw new AccException("verifier:" + verifier.getVerifierName() + " can not support genAuthToken.", AccExpType.NOT_SUPPORT);
        }
        
        IOauthVerifier oauthVerifier = (IOauthVerifier)verifier;
        Map<String, Object> result = null;
        if (AccConfig.isStressTest()) {
            result = oauthVerifier.genStressAuthInfo();
        } else {
            result = oauthVerifier.getAuthInfo(req, resp);
        }
         
        
        for (Entry<String, Object> entry : result.entrySet()) {
            req.setAttribute(entry.getKey(), entry.getValue());
        }
        UserInfoWritable userInfo = null;
        if (AccConfig.isStressTest()) {
            userInfo = oauthVerifier.genStressUser();
        } else {
            userInfo = oauthVerifier.getUserInfo(req, resp);
        }
         
        datastore.writeUserInfo(userInfo);
        // if want userInfo
        int cookieParam = AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value());
        Map<String, Object> response = null;
        response = new HashMap<String, Object>();
        
        if (COOKIE_FORMAT.info.isContain(cookieParam)) {
            response.putAll(oauthVerifier.removeAuthToken(result));
            userInfo.putInfoMap(response);
            cookieParam = COOKIE_FORMAT.info.remove(cookieParam);
            if (cookieParam == 0) {
                // only want user info
                if (!AuthUtils.isWeb(req)) {
                    // userinfo should be get from poll interface.
                    CacheInfo info = new CacheInfo(null, response);
                    glcache.put(AuthUtils.getReqVal(req, AccConst.ATTR_PC_NAME), AuthUtils.obj2bytes(info));
                }
                return response;
            }
        }
        
        TpToken tpToken = genTpTokenComplete(req, oauthVerifier, result, userInfo);
        AccCookies accCookie = TokenUtils.tpTokenGenCookie(req, resp, response, tpToken);
        if (!AuthUtils.isWeb(req)) {
            // put into cache
            CacheInfo info = new CacheInfo(accCookie, response);
            glcache.put(AuthUtils.getReqVal(req, AccConst.ATTR_PC_NAME), AuthUtils.obj2bytes(info));
        } 
        return response;
    }
    
    private static TpToken genTpToken(HttpServletRequest req, Map<String, Object> result, UserInfoWritable userInfo) {
        TpToken tp = new TpToken();
        tp.userId = userInfo.userId;
        tp.setExpiredTime((Long)result.remove(AccConst.EXPIRED));
        tp.token = (String)result.remove(AccConst.ACCESS_TOKEN);
        tp.secret = (String)result.remove(AccConst.ACCESS_SECRET);
        tp.ip = AuthUtils.getRequestIP(req);
        tp.product = AuthUtils.getReqVal(req, AccConst.PARAM_PRODUCT_NAME);
        tp.app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
        tp.verifierName = AuthUtils.getReqVal(req, AccConst.PARAM_THIRD_PARTY_NAME);
        tp.refresh = (String)result.remove(AccConst.REFRESH_TOKEN);
        
        tp.authid = userInfo.originalId;
        for (Entry<String, Object> entry : result.entrySet()) {
            tp.setProperty(entry.getKey(), AuthUtils.toString(entry.getValue()));
        }
        
        return tp;
    }
    
    public static TpToken genTpTokenComplete(HttpServletRequest req, IVerifier verifier, Map<String, Object> result, UserInfoWritable userInfo) throws AccException {
        TpToken tpToken = genTpToken(req, result, userInfo);
        return TokenUtils.genCompleteTpToken(verifier, tpToken);
    }
    
    public static void remove(TpToken tpToken) throws AccException {
        IVerifier verifier = tf.getTokenVerifier(tpToken.product, tpToken.verifierName);
        verifier.remove(tpToken);
        datastore.removeTokenWhichNoSessIndex(tpToken);
    }
    
    public static void revokeAuthorizeBind(String userId, Set<String> products, Set<String> apps, Set<String> tps, Map<String,Set<String>> condition) throws AccException {
        MappingRelationship relationShip = datastore.getAllMapping(userId);
        if (relationShip != null) {
            datastore.revokeAuthorize(relationShip.getMainId(), products, apps, tps, condition);
            List<String> shadowIds = relationShip.getShadowIds();
            for (String id : shadowIds) {
                datastore.revokeAuthorize(id, products, apps, tps, condition);
            }
        } else {
            datastore.revokeAuthorize(userId, products, apps, tps, condition);
        }
    }
    
    public static void revokeAuthorize(String userId, Set<String> products, Set<String> apps, Set<String> tps, Map<String,Set<String>> condition) throws AccException {
        datastore.revokeAuthorize(userId, products, apps, tps, condition);
    }
}
