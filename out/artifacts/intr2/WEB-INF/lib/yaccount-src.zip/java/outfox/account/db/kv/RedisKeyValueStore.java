/**
 * @(#)RedisKeyValueStore.java, 2012-3-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv;

import outfox.account.exceptions.AccException;
import odis.serialize.lib.StringWritable;

/**
 * TODO: implementation
 *
 * @author wangfk
 *
 */
public class RedisKeyValueStore extends AbstractKeyValueStore<String, StringWritable> {

    @Override
    public void writeKeyValue(String key, StringWritable value)
            throws AccException {
        // TODO Auto-generated method stub
        
    }

    @Override
    public boolean readValue(String key, StringWritable value)
            throws AccException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void deleteKey(String key) throws AccException {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean containsKey(String key) throws AccException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void close() throws AccException {
        // TODO Auto-generated method stub

    }

    @Override
    public IKeyValueStore.Iter<String, StringWritable> getIter()
            throws AccException {
        // TODO Auto-generated method stub
        return null;
    }

}
