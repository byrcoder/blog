/**
 * @(#)ConsistentHashSynchronizer.java, 2011-7-11. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.ch;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.zk.Serviceable;
import outfox.account.server.zk.ZooKeeperListener;
import outfox.account.server.zk.ZooKeeperWatcher;
import outfox.account.utils.ConsistentHash;
import outfox.account.utils.ZKUtils;


/**
 * Handles everything related to the synchronization of consistent hash circle.
 * 
 * <p>When the synchronization is in process, listens to ZooKeeper notifications
 * <code>NodeDataChanged</code> on store server znodes and then check the 
 * synchronization status.
 *
 * @author licx
 */
public abstract class ConsistentHashSynchronizer extends ZooKeeperListener {
    private static final Log LOG = LogFactory.getLog(ConsistentHashSynchronizer.class);
    private static final long HASH_WAIT_TIME_PERIOD = 1000;

    // Service that is associated with this synchronizer
    protected Serviceable service;

    // Hash circle read write lock with fairness policy
    protected ReentrantReadWriteLock hashCircleLock = new ReentrantReadWriteLock(true);
    // The time to wait for the hashCircleLock timeout
    protected long timeout;

    protected ConsistentHash hashCircle;

    // whether the current hash circle is out of date
    protected AtomicBoolean obsolete = new AtomicBoolean(true);
    // whether the consistent hash is synchronized over the cluster
    protected AtomicBoolean updated = new AtomicBoolean(false);

    /**
     * @param watcher zookeeper watcher reference
     * @param serverNum number of servers
     */
    public ConsistentHashSynchronizer(Serviceable service,
            ZooKeeperWatcher watcher, int serverNum) {
        super(watcher);
        this.service = service;
        this.hashCircle = new ConsistentHash(serverNum);
        this.timeout = AccConfig.getPros().getLong(
                AccConfig.NAME_LOCK_EXPIRE);
    }

    @Override
    public void nodeDataChanged(String path) {
        // store server updates its version during synchronization 
        // notify synchronization thread and check whether the consistent
        // hash is synchronized
        if (path.startsWith(watcher.accountServerDirZNode) && !updated.get()
                && !service.isStopped()) {
            LOG.debug(watcher.prefix("Store server " + ZKUtils.getNodeName(path)
                + " has updated its version"));
            synchronized (updated) {
                updated.notifyAll();
            }
        }
    }

    /**
     * Lookup the consistent hash circle to find out which server is responsible
     * for the specified userId.
     *
     * @param key
     * @return address of the server which is responsible for the given user
     * @throws InterruptedException 
     */
    public ServerAddress lookup(String key) throws AccException,
            InterruptedException {
        boolean locked = hashCircleLock.readLock().tryLock(timeout,
                TimeUnit.MILLISECONDS);
        if (locked) {
            try {
                 String address = hashCircle.get(key);
                 if (!StringUtils.isBlank(address)) {
                     return new ServerAddress(address);
                 } else {
                     return null;
                 }
            } finally {
                hashCircleLock.readLock().unlock();
            }
        } else {
            throw new AccException(
                    "Expired to obtain the hash circle read lock",
                    AccExpType.LOCK_EXPIRED_EXCEPTION);
        }
    }

    /**
     * Get current consistent hash circle in ZooKeeper.
     * @return consistent hash circle in ZooKeeper
     * @throws AccException if unexpected ZooKeeper exception happens
     * @throws KeeperException 
     */
    protected ConsistentHash getCurrentHashCircle() throws KeeperException {
        ConsistentHash currentHashCircle = new ConsistentHash();
        try {
            // read data and check the version
            byte[] currentData = ZKUtils.getDataAndWatch(watcher,
                    watcher.consistentHashZNode);
            if (currentData != null && currentData.length != 0) {
                currentHashCircle.fromByteArray(currentData);
                return currentHashCircle;
            }
            return null;
        } catch (IOException e) {
            LOG.fatal(watcher.prefix("Fail to deserialize hash circle"), e);
            throw new AccRunTimeException("Hash circle deserialization error", e);
        }
    }

    /**
     * Blocking until the consistent hash circle is synchronized over
     * the cluster.
     * This method would not return unless any of the following conditions
     * happen:
     * 1. Consistent hash is synchronized.
     * 2. Current consistent hash that is being synchronized is out of date.
     * 3. Associated service is stopped.
     *
     * @param timeout max time to block before consistent hash is synchronized
     * @return whether the consistent hash is synchronized
     * @throws AccException 
     * @throws KeeperException 
     */
    protected boolean blockUntilSynchronized(long timeout) throws KeeperException {
        synchronized (updated) {
            long waitTime = 0;
            while (!service.isStopped() && !obsolete.get()
                    && !hasSynchronized()) {
                try {
                    updated.wait(HASH_WAIT_TIME_PERIOD);
                    waitTime += HASH_WAIT_TIME_PERIOD;
                    if (waitTime >= timeout) break;
                } catch (InterruptedException e) {
                    LOG.fatal(watcher.prefix("Interrupted waiting for " +
            		"consistent hash synchronization to finish"), e);
                    throw new AccRunTimeException(
                        "Consistent hash synchronization interrupted", e);
                }
            }
        }

        if (updated.get()) {
            LOG.info(watcher.prefix("All store servers have updated " +
    		"hash-circle successfully"));
            return true;
        } else if (service.isStopped()) {
            LOG.warn(watcher.prefix("Give up consistent hash synchronization " +
                "because the service is stopped"));
        } else if (obsolete.get()) {
            LOG.info(watcher.prefix("Consistent hash is out of date during " +
                "the synchronization, probably because another " +
                "store server is added/deleted from zookeeper, " +
                "will re-synchronize later..."));
        }
        return false;
    }

    /**
     * Whether the consistent hash is synchronized in zookeeper, that is
     * the version of all store servers come to the same version as that of
     * consistent hash circle znode.
     *
     * @return true if the cluster is synchronized, false otherwise
     * @throws AccException 
     * @throws KeeperException 
     */
    private boolean hasSynchronized() throws KeeperException {
        List<String> servers = ZKUtils.listChildrens(watcher,
                watcher.accountServerDirZNode);
        ConsistentHash currentHashCircle = new ConsistentHash();
        try {
            // deserialize current consistent hash
            byte[] currentHash = ZKUtils.getDataAndWatch(watcher,
                    watcher.consistentHashZNode);
            currentHashCircle.fromByteArray(currentHash);
            for (String node: servers) {
                // also set a watcher so that we will be notified when the
                // data of store server is changed
                byte[] data = ZKUtils.getDataAndWatch(watcher,
                        ZKUtils.joinZNode(watcher.accountServerDirZNode, node));
                if (data == null || data.length == 0) {
                    LOG.info("Version of store server " + node + " is empty" +
                        " while expected version is " + currentHashCircle.getVersion());
                    return false;
                }
                long version = Long.decode(new String(data, ZKUtils.ZK_ENCODING));
                if (version != currentHashCircle.getVersion()) {
                    LOG.info("Version of store server " + node + " is " + version
                         + " while expected version is " + currentHashCircle.getVersion());
                    return false;
                }
            }
            updated.set(true);
            // change hash circle atomically
            hashCircle = currentHashCircle;
            return true;
        } catch (UnsupportedEncodingException e) {
            LOG.fatal("Server does not support encoding " + ZKUtils.ZK_ENCODING, e);
            throw new AccRunTimeException("Unsupported encoding "
                    + ZKUtils.ZK_ENCODING, e);
        } catch (IOException e) {
            LOG.fatal(watcher.prefix("Fail to deserialize hash circle"), e);
            throw new AccRunTimeException("Hash circle deserialization error", e);
        }
    }
}
