/**
 * @(#)LoadUtils.java, 2012-10-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.Properties;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.verifier.loader.VerifierLoader;

/**
 * @author chen-chao
 */
public class LoadUtils {
    private static final Log LOG = LogFactory.getLog(LoadUtils.class);

    public static Properties initFromClassPackage(Class<?> clazz, String filename) {

        // use default
        String resourceName = clazz.getPackage().getName().replace(".", "/") + "/"
                + filename;
        LOG.info("Use default consumer file:" + resourceName);
        Properties props = null;
        try {
            props = getProperties(getResource(resourceName, VerifierLoader.class.getClassLoader()));
        } catch (IOException e) {
            LOG.fatal("Default consumer file can not load:" + resourceName);
            throw new AccRunTimeException("Default consumer file can not load:" + resourceName, e);
        }
        return props;
    }

    private static URL getResource(String name, ClassLoader loader) throws IOException {

        URL resource = loader.getResource(name);
        if (resource == null) {
            throw new IOException("resource not found: " + name);
        }
        return resource;
    }

    private static Properties getProperties(URL source) throws IOException {
        InputStream input = source.openStream();
        try {
            Properties p = new Properties();
            p.load(input);
            return p;
        } finally {
            input.close();
        }
    }

    /**
     * read config file into properties
     * 
     * @param home
     * @param configFileName
     * @return
     */
    public static Properties initFromConfFile(String configFileName) {
        File confFile = AccConfig.getConfigFile(configFileName);
        PropertiesConfiguration properties = null;
        LOG.info("load file:" + confFile.getAbsolutePath());
        try {
            properties = new PropertiesConfiguration(confFile.getAbsolutePath());
        } catch (Exception e) {
            // create config file failure
            LOG.info("file path:" + confFile.getAbsolutePath() + " create properties failure.");
        }
        Properties props = new Properties();
        if (properties != null) {
            Iterator<?> iter = properties.getKeys();
            while (iter.hasNext()) {
                String key = (String) iter.next();
                props.put(key, (String) properties.getProperty(key));
            }
        }
        return props;
    }
}
