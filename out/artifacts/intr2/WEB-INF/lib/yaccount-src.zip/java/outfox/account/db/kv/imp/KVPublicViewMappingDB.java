/**
 * @(#)KVShowKey.java, 2012-12-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.data.PublicViewWritable;
import outfox.account.db.in.IPublicViewMappingDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.db.kv.IKeyValueStore.Iter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class KVPublicViewMappingDB extends BaseKVDB implements IPublicViewMappingDB{
    private static final String STORE_NAME = "accPublicViewMapping";
    /**
     * key: suffix of url 
     * value : {@link PublicViewWritable}
     */
    private static final String[] types = {
        "VINTSTRING",
        "CUSTOM(outfox.account.data.PublicViewWritable)"
    };
    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;
    @SuppressWarnings("unchecked")
    public KVPublicViewMappingDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }
    
    public void write(String urlSuffix, PublicViewWritable publicView) throws AccException {
        if (urlSuffix == null) {
            return;
        }
        StringWritable keyWritable = new StringWritable(urlSuffix);
        kvStore.writeKeyValue(keyWritable, publicView);
    }
    
    public PublicViewWritable read(String urlSuffix) throws AccException {
        PublicViewWritable value = new PublicViewWritable();
        if (kvStore.readValue(new StringWritable(urlSuffix), value)) {
            return value;
        } else {
            return null;
        }
    }
    
    public void remove(String urlSuffix) throws AccException {
        kvStore.deleteKey(new StringWritable(urlSuffix));
    }
    
    /**
     * thread unsafe
     *
     * @author chen-chao
     *
     */
    private class KVPublicViewMappingIter implements IPublicViewMappingIter {
        private Iter<IWritableComparable, IWritable> iter = null;
        private StringWritable key = null;
        public KVPublicViewMappingIter(String startKey) throws AccException {
            try {
                iter = kvStore.getIter();
                if (StringUtils.isBlank(startKey)) {
                    key = new StringWritable();
                } else {
                    key = new StringWritable(startKey);
                    iter.seekTo(key, false);
                }
            } catch (AccException e) {
                AuthUtils.disposeException(e, AccExpType.STORE_SERVICE_EXCEPTION);
            }
        }

        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         * @throws AccException 
         */
        @Override
        public PublicViewWritable next() throws AccException {
            PublicViewWritable value = new PublicViewWritable();
            if (!iter.next(key, value)) {
                return null;
            }
            return value;
        }

        @Override
        public void close() {
            AuthUtils.closeQuiet(iter);
        }
    }
    
    @Override
    public IPublicViewMappingIter getIter(Object... startKeys) throws AccException {
        if (startKeys == null || startKeys.length == 0) {
            return new KVPublicViewMappingIter(null);
        }
        return new KVPublicViewMappingIter((String)startKeys[0]);
    }
}
