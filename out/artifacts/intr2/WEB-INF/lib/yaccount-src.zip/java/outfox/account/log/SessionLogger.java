/**
 * @(#)UserLog.java, 2012-12-4. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.log;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;
import outfox.account.utils.SecurityUtils;
import toolbox.web.CookieUtil;

/**
 * @author chen-chao
 */
public class SessionLogger {
    private static final Log LOG = LogFactory.getLog(SessionLogger.class);
    private static final String UNKNOWN_USER = "(null)";
    public static void print(Exception e) {
        LOG.error("LOG exception occur.",e);
    }
    @SuppressWarnings("unchecked")
    public static void print(HttpServletRequest req, String log, Exception e) throws AccException {
        String product = AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME);
        String userId = null;
        try {
            if (product != null) {
                userId = (String) req.getAttribute(product + AccConst.ATTR_PART_USER_ID);
            }
            if (userId == null) {
                userId = (String) req.getAttribute(AccConst.USER_ID_ATTR);
            }
        } catch(ClassCastException ex) {
            // something error. XXX FIX IT
            userId = null;
            LOG.error("ClassCastException error. Why? "+ ReqUtils.dumpRequest(req), ex);
            return;
        }
        
        
        if (StringUtils.isBlank(userId)){
            userId = UNKNOWN_USER;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(log).append("\n");
        final Object result = req.getAttribute(AccConst.ATTR_RESULT);
        String resultPlain = "null";
        if (result != null) {
            if (result instanceof List) {
                resultPlain = SecurityUtils.escapeSecurity((List<Parameter>)result).toString();
            } else if (result instanceof JSONObject){
                resultPlain = SecurityUtils.escapeSecurity((JSONObject) result).toString();
            } else if (result instanceof String){
                resultPlain = result.toString();
            }
        }
        sb.append("response:").append(resultPlain);
        sb.append("\n");

        sb.append("Cookie:\t");
        printCookieInfo(sb, req, product + AccConst.COOKIE_LOGIN);
        printCookieInfoSecurity(sb, req, product + AccConst.COOKIE_SESSION);
        printCookieInfoSecurity(sb, req, product + AccConst.COOKIE_SESSION_BIND);
        printCookieInfoSecurity(sb, req, product + AccConst.COOKIE_PERSISTENT);
        sb.append("\n");
        if (e != null) {
            LOG.error(String.format("sessId:%s [user=%s]  %s", req.getSession().getId(), userId, sb.toString()), e);
        } else {
            LOG.info(String.format("sessId:%s  [user=%s] %s", req.getSession().getId(), userId, sb.toString()));
        }
        
    }
    private static void printCookieInfo(StringBuilder log, HttpServletRequest req, String key) {
        Cookie cookie = CookieUtil.findCookie(req, key);
        if (cookie != null) {
            log.append(cookie.getName()).append("=").append(cookie.getValue()).append(" ").append(cookie.getDomain()).append(";");
        }
    }
    
    private static void printCookieInfoSecurity(StringBuilder log, HttpServletRequest req, String key) throws AccException {
        Cookie cookie = CookieUtil.findCookie(req, key);
        if (cookie != null) {
            log.append(cookie.getName()).append("=").append(SecurityUtils.secretString(cookie.getValue())).append(" ").append(cookie.getDomain()).append(";");
        }
    }
}
