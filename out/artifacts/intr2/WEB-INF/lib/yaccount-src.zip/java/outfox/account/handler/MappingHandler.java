/**
 * @(#)AccountBindingHandler.java, 2012-4-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.AccConst;
import outfox.account.data.AuthInfo;
import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.db.DataStore.MappingRelationship;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;

/**
 * @author JiaRu
 */
@Controller
public class MappingHandler extends BaseHandler {
    private static final long serialVersionUID = 4477838832238782065L;

    private DataStore store = DataStore.getInstance();;

    /**
     * Add a account binding relationship from shadowUserId to mainUserId.
     * shadowUserId is hold by the cookie of type COOKIE_BINDING_SESSION,
     * mainUserId is hold by the cookie of type COOKIE_SESSION.
     * 
     * @param request
     * @param response
     * @throws AccException 
     */
    @RequestMapping(value=AccConst.ACCOUNT_BINDING_ADD_URL, method = RequestMethod.POST)
    protected void addAccountBinding(HttpServletRequest request, HttpServletResponse response)
            throws AccException {
        setName(request, "add-bind");
        setErrorAttribute(request, HttpStatus.INTERNAL_SERVER_ERROR);
        AuthInfo authInfo = checkLogin(request);
        if (authInfo.userId == null || authInfo.bindUserId == null) {
            throw new AccException("mainId is null or bindId is null", AccExpType.NO_BIND_AUTHORIZE);
        }

        String userA = authInfo.userId;
        String userB = authInfo.bindUserId;
        MainId2ShadowIdWritable mappingA = store.getUserMapping(userA);
        MainId2ShadowIdWritable mappingB = store.getUserMapping(userB);
        if (mappingA == null && mappingB == null) {
            bindUser(userA, userB);
        } else {

            if (mappingA != null && mappingB != null) {
                final String mainIdB = mappingB.getMainUserId();
                final String mainIdA = mappingA.getMainUserId();
                if (!mainIdA.equals(mainIdB)) {
                    // error, bind different main account
                    throw new AccException(String.format(
                            "userA: %s and userB %s is already bind %s and %s respective", userA, userB,
                            mainIdA, mainIdB));
                }
                // already bind.
            } else {
                // mappingA or mappingB is not null.
                boolean isBMapping = (mappingB != null);
                if (isBMapping) {
                    // swap userA and userB
                    String tmpUser = userA;
                    userA = userB;
                    userB = tmpUser;

                    mappingA = mappingB;
                }
                // mapping A is not empty.

                final String mainIdA = mappingA.getMainUserId();
                if (mainIdA.equals(userA)) {
                    // case 1. userA is mapping main id
                    bindUser(mainIdA, userB);
                } else {

                    if (mainIdA.equals(userB)) {
                        // case 2. is not delete partly of shadowId -> mainId2shadowIdMapping in omap
                        // add again
                        bindUser(userB, mainIdA);
                    } else {
                        // userA and userB are both shadowIds. Is the mappingA deleted partly?
                        MainId2ShadowIdWritable mainMapping = store.getMainMapping(mappingA);
                        if (mainMapping != null) {
                            // case 3. userA is a shadowId. and mainId -> shadowId in omap
                            bindUser(mainIdA, userB);
                        } else {
                            // case 4. userA is a shadowId, and mainId -> shadowId is not exist.
                            // remove userA from mapping. wait for next binding request.
                            store.removeUserMapping(mappingA);
                        }
                    }
                }
            }
        }
        
        replyOK(request, response);
    }

    private void bindUser(String userA, String userB) throws AccException {
        boolean aIsEmail = AuthUtils.isValidEmailAddress(userA);
        boolean bIsEmail = AuthUtils.isValidEmailAddress(userB);
        if (aIsEmail ^ bIsEmail) {
            // either userA or userB is an email address account 
            if (aIsEmail) {
                // userA is main account
                store.addUserMapping(userA, userB);
            } else {
                store.addUserMapping(userB, userA);
            }
        } else {
            throw new AccException(AccExpType.LOGIC_ERROR, "userA %s and userB %s can not bind.", userA,
                    userB);
        }
    }

    /**
     * Get the list of account binding information related to the given user ID.
     * Result is returned in json.
     * 
     * @param request
     * @param response
     * @throws UnsupportedEncodingException
     * @throws IOException
     */
    @RequestMapping(AccConst.ACCOUNT_BINDING_GET_INFO_URL)
    protected void getAccountBindingInfo(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        setName(req, "get-bind-info");
        setErrorAttribute(req, HttpStatus.UNAUTHORIZED);
        AuthInfo authInfo = checkLogin(req);
        String queryUserId = req.getParameter(AccConst.PARAM_USER_ID);
        if (StringUtils.isBlank(queryUserId) || queryUserId.equals(authInfo.userId)) {
            // return user itself.
            if (authInfo.userInfo == null) {
                authInfo.userInfo = store.readUserInfo(authInfo.userId);
            }
            write(req, resp, authInfo.userInfo.getInfoMap(), HttpStatus.OK);
            return;
        }

        checkSameUser(queryUserId, authInfo.userId);
        UserInfoWritable userinfo = store.readUserInfo(queryUserId);
        write(req, resp, userinfo.getInfoMap(), HttpStatus.OK);
    }

    /**
     * Find the binded main user ID according to the given user ID.
     * 
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(AccConst.ACCOUNT_BINDING_GET_MAIN_ID_URL)
    protected void getMainUserId(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "get-main-id");
        setErrorAttribute(req, HttpStatus.UNAUTHORIZED);
        AuthInfo authInfo = checkLogin(req);

        String mainUser = getSafeMainUserId(authInfo.userId);
        if (mainUser == null) {
            throw new AccException(AccExpType.NO_BIND_ERROR, "no bind for user %s.", authInfo.userId);
        }
        UserInfoWritable userinfo = store.readUserInfo(mainUser);

        write(req, resp, userinfo.getInfoMap(), HttpStatus.OK);
    }

    /**
     * no bind info will throw an exception.
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(AccConst.ACCOUNT_BINDING_GET_ALL_URL)
    protected void getAll(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "get-all-bind-info");
        setErrorAttribute(req, HttpStatus.UNAUTHORIZED);
        AuthInfo authInfo = checkLogin(req);
        MappingRelationship relationship = store.getAllMapping(authInfo.userId);
        JSONObject ret = new JSONObject();
        if (relationship == null) {
            throw new AccException(AccExpType.NO_BIND_ERROR, "no bind for user %s.", authInfo.userId);
        }

        ret.put(AccConst.FLAG_MAIN_ID, relationship.getMainId());
        JSONArray array = new JSONArray();
        for (String id: relationship.getShadowIds()) {
            array.add(id);
        }
        ret.put(AccConst.FLAG_BIND, array);
        writeJSON(req, resp, ret, HttpStatus.OK);
    }

    /**
     * Remove the account binding record specified by shadowUserId and
     * mainUserId pair.
     * 
     * @param request
     * @param response
     * @throws AccException 
     * @throws AuthStoreException
     */
    @RequestMapping(value=AccConst.ACCOUNT_BINDING_REMOVE_URL, method = RequestMethod.POST)
    protected void removeAccountBinding(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "remove-bind");
        setErrorAttribute(req, HttpStatus.UNAUTHORIZED);
        AuthInfo authInfo = checkLogin(req);
        if(StringUtils.isNotBlank(req.getParameter(AccConst.PARAM_ALL))) {
            // remove all bind info from mainId
            removeAllMapping(authInfo.userId);
            return;
        }
        
        String removeUserId = req.getParameter(AccConst.PARAM_USER_ID);
        if (StringUtils.isBlank(removeUserId)) {
            removeUserId = authInfo.userId;
        }
        // 1. login userid == removeUserId , if bind exist, return mainId
        // 2. login userid != removeUserId, if bind exist, return mainId
        // 3. if bind not exist, throw exception
        String mainId = checkAndGetIfSameMainId(removeUserId, authInfo.userId);
        if (AuthUtils.isValidEmailAddress(removeUserId)) {
            // remove userid is main id
            if (!store.isOnlyOneBindInfo(mainId)) {
                // will remove login id from bind information
                if (AuthUtils.isValidEmailAddress(authInfo.userId)) {
                    throw new AccException(AccExpType.LOGIC_ERROR,
                            "can not remove bind for removeid: %s and loginid: %s.", removeUserId,
                            authInfo.userId);
                }
                // remove login id.
                removeUserId = authInfo.userId;
            }
        } 
        store.removeUserMapping(removeUserId);
        replyOK(req, resp);
    }

    /**
     * get mainUserId
     * @param userId
     * @return
     * @throws AccException 
     */
    private String getSafeMainUserId(String userId) throws AccException {
        MainId2ShadowIdWritable mainId2ShadowIdWritable = store.safeUserMapping(userId);
        return mainId2ShadowIdWritable == null ? null : mainId2ShadowIdWritable.getMainUserId();
    }

    private void checkSameUser(String userIdA, String userIdB) throws AccException {
        if (StringUtils.isNotBlank(userIdA) && StringUtils.isNotBlank(userIdB)) {
            if (userIdA.equals(userIdB)) {
                return;
            }
        }
        checkAndGetIfSameMainId(userIdA, userIdB);
    }

    protected String checkAndGetIfSameMainId(String userIdA, String userIdB) throws AccException {
        String mainId = getIfSameMainId(userIdA, userIdB);
        if (mainId == null) {
            throw new AccException(
                    AccExpType.NO_BIND_ERROR, "userA: %s and userB: %s are not binding relationship.", userIdA, userIdB);
        }
        return mainId;
    }

    private String getIfSameMainId(String userIdA, String userIdB) throws AccException {
        if (StringUtils.isNotBlank(userIdA) && StringUtils.isNotBlank(userIdB)) {

            String mainIdA = getSafeMainUserId(userIdA);
            if (userIdA.equals(userIdB)) {
                return mainIdA;
            }
            String mainIdB = getSafeMainUserId(userIdB);
            if (mainIdA != null && mainIdA.equals(mainIdB)) {
                return mainIdA;
            }
        }
        return null;
    }

    private void removeAllMapping(String userId) throws AccException {
        if (AuthUtils.isValidEmailAddress(userId)) {
            MainId2ShadowIdWritable mapping = store.getUserMapping(userId);
            if (mapping != null && mapping.getMainUserId().equals(userId)) {
                store.removeAllMapping(userId);
            } else {
                throw new AccException(AccExpType.NO_BIND_ERROR, "userid: %s is not bind.", userId);
            }
            
        } else {
            throw new AccException(AccExpType.NO_BIND_AUTHORIZE,
                    "userid: %s is not mainId, can not remove bind relationship", userId);
        }
        
    }
    // TODO: rpc interface check two user is bind or not
    // TODO: rpc interface get user bind info.

}
