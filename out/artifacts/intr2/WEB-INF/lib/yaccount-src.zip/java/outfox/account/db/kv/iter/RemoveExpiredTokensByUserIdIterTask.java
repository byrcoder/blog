/**
 * @(#)RemoveExpiredTokens.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class RemoveExpiredTokensByUserIdIterTask extends RevokeUserTokenIteratorTask{
    private long expireTimeInMilli;
    public RemoveExpiredTokensByUserIdIterTask(IPersTokenDB persTokenDB, ISessCookieDB sessCookieDB, String userId, Long expireTimeInMilli) {
        super(persTokenDB, sessCookieDB, userId, null, null, null, null);
        if (expireTimeInMilli == null) {
            this.expireTimeInMilli = -1L;
        } else {
            this.expireTimeInMilli = expireTimeInMilli;
        }
    }

    @Override
    protected void runTask(Object value) throws AccException {
        PersistTokenWritable pers = (PersistTokenWritable)value;
        TpToken tpToken = pers.getTpToken();
        if (tpToken.isExpired() || tpToken.isExpired(expireTimeInMilli)) {
            persTokenDB.remove(tpToken);
            sessCookieDB.remove(tpToken);
        }
    }
}
