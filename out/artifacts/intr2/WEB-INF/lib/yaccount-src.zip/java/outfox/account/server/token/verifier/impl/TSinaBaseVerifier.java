/**
 * @(#)TSinaBaseVerifier.java, Nov 7, 2013. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.http.Header;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.Oauth2Verifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 * @author wangzhen
 *
 */
public abstract class TSinaBaseVerifier extends Oauth2Verifier {

    public TSinaBaseVerifier(Properties props, String name) {
        super(props, name);
    }

    public static final String FORCE_LOGIN = "forcelogin";
    public static final String FORCE_LOGIN_VALUE = "true";
    

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // set query cookie and redirect to third-party
        OAuth2Utils.addQueryAttribute(req, resp);
        
        // prepare params
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.RESPONSE_TYPE, OAuthConstant.AUTHORIZED_CODE));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        
        String stat = OAuth2Utils.genState(req);        
        params.add(new Parameter(OAuthConstant.CALLBACK_STATE_CODE, stat));
        if (AuthUtils.getReqBoolean(req, AccConst.ATTR_FORCE_LOGIN, false)) {
            params.add(new Parameter(FORCE_LOGIN, FORCE_LOGIN_VALUE));
        }
        if (AuthUtils.isMobile(req)) {
            params.add(new Parameter(OAuthConstant.DISPLAY, OAuthConstant.DISPLAY_MODE_MOBILE));
        }
        
        // redirect
        if (AccConfig.isStressTest()) {
            stressRedirect(req, resp);
            
        } else {
         
            AuthUtils.redirect(resp, getAbsoluteAuthorizeUrl(), params);
        }
        return null;
    }

    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        Map<String, Object> userInfo = getUserId(req, resp);
        String accToken = (String) req.getAttribute(OAuthConstant.ACCESS_TOKEN);
        return getUserInfoById(accToken, userInfo);
    }

    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        String accToken = thirdPartyTokens.get(AccConst.TOKEN);
        Map<String, Object> userInfo = getUserId(accToken);

        return getUserInfoById(accToken, userInfo);
    }

    private UserInfoWritable getUserInfoById(String accToken, Map<String, Object> userInfo)
            throws AccException {
        List<Header> headers = new ArrayList<Header>();
        headers.add(authorizeHeader(accToken));
        List<Parameter> params = new ArrayList<Parameter>();
        UserInfoWritable info = new UserInfoWritable();
        info.originalId = (String) userInfo.get(AccConst.USER_ID);
        info.userId = tpId2ownId(info.originalId);
        params.add(new Parameter("uid", info.originalId));
        JSONObject obj = JSONObject.fromObject(AccHttpClient.getInstance().getString(Method.GET,
                getAbsoluteUrl(properties.get("accountInfoURL")), headers, params, null));
        throwErrorException(obj);
        info.userName = obj.getString("screen_name");
        info.imageUrl = obj.getString("profile_image_url");
        info.setBigImageUrl(obj.getString("avatar_large"));
        info.from = getVerifierName();
        return info;
    }

    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        // get access token, expire time, remain, others
        String code = req.getParameter(OAuthConstant.OAUTH2_CODE);
        
        List<Parameter> params = new ArrayList<Parameter>();

        params.add(new Parameter(OAuthConstant.GRANT_TYPE, OAuthConstant.GRANT_TYPE_VALUE_AUTHOR_CODE));
        params.add(new Parameter(OAuthConstant.OAUTH2_CODE, code));
        params.add(new Parameter(OAuthConstant.REDIRECT_URI, getAbsoluteCallbackUrl(req)));
        params.add(new Parameter(OAuthConstant.CLIENT_ID, appkey));
        params.add(new Parameter(OAuthConstant.CLIENT_SECRET, secret));
        JSONObject obj = JSONObject.fromObject(AccHttpClient.getInstance().getString(Method.POST, getAbsoluteAccessUrl(), null,
                params, null));
        throwErrorException(obj);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(OAuthConstant.ACCESS_TOKEN, obj.getString(OAuthConstant.ACCESS_TOKEN));
        result.put(OAuthConstant.REMAIN, obj.getLong(OAuthConstant.SINA_REMIND_IN) * 1000L);
        result.put(OAuthConstant.EXPIRED, obj.getLong(OAuthConstant.EXPIRES_IN) * 1000L);
        return result;
    }

    public Map<String, Object> getUserId(String accToken) throws AccException {
        List<Header> headers = new ArrayList<Header>();
        headers.add(authorizeHeader(accToken));
        JSONObject obj = JSONObject.fromObject(AccHttpClient.getInstance().getString(Method.GET,
                getAbsoluteUrl(properties.get("accountURL")), headers, null, null));
        throwErrorException(obj);
        Map<String, Object> userInfo = new HashMap<String, Object>();
        userInfo.put(AccConst.USER_ID, obj.getString("uid"));
        return userInfo;
    }

    public Map<String, Object> getUserId(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        String accToken = (String) req.getAttribute(OAuthConstant.ACCESS_TOKEN);
        return getUserId(accToken);
    }

    @Override
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expireTime) throws AccException {
        // check in memory, DB
        Map<String, Object> result = super.verifyAuthToken(req, resp, token, expireTime);
        
        // set access token
        Map<String, String> thirdPartyTokens = new HashMap<String, String>();
        PersistTokenWritable tokenWritable = (PersistTokenWritable) result
                .get(AccConst.THIRD_PARTY_PERS_TOKEN);
        TpToken tpToken = tokenWritable.getTpToken();
        thirdPartyTokens.put(AccConst.TOKEN,
                tpToken.token);
        
        // check in third party.
        UserInfoWritable userInfo = getUserInfo(thirdPartyTokens);
        // TODO update userInfo in other thread
        result.put(AccConst.USER_INFO_WRITABLE, userInfo);
        // update userInfo

        store.writeUserInfo(userInfo);
        // AccConst.THIRD_PARTY_PERS_TOKEN should not remove
        // has checked in thrid party, but now it is expired
        result.put(AccConst.EXPIRED, TokenUtils.checkTokenExpired(tpToken));
        return result;
    }

    public void throwErrorException(JSONObject obj) throws AccException {
//        {
//            "error":"unsupported_response_type",
//            "error_code":21329
//            "error_description":"不支持的 ResponseType."
//        }
        if (obj.containsKey("error")) {
            throw new AccException(obj.toString(), null, AccExpType.TP_ERROR, obj.getInt("error_code"));
        }
    }

    @Override
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException {
        Map<String,Object> newMap = new HashMap<String, Object>(authInfo);
        newMap.remove(OAuthConstant.ACCESS_TOKEN);
        newMap.remove(OAuthConstant.REMIND);
        return newMap;
    }

}
