/**
 * @(#)ITokenVerifier.java, 2013-2-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.util.Map;

import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface ITokenVerifier extends IVerifier {

    public UserInfoWritable getUserInfo(Map<String,String> tokens)throws AccException;
}
