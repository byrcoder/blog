package outfox.account.db.kv.cassandra;

import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.in.IUserInfoDB;
import outfox.account.db.kv.imp.KVUserInfoDB;
import outfox.account.exceptions.AccException;

/**
 * @author yangzhe
 * @version created on 14-9-4.
 */
public class UserInfoDual implements IUserInfoDB {

    //private static final Log LOG = LogFactory.getLog(SessCookieDual.class);

    private UserInfoTable cassandra = new UserInfoTable();
    private KVUserInfoDB omap = new KVUserInfoDB();

    @Override
    public UserInfoWritable write(UserInfoWritable userinfo) throws AccException {
        UserInfoWritable res1 = cassandra.write(userinfo);
        UserInfoWritable res2 = omap.write(userinfo);
        return res1 != null ? res1 : res2;
    }

    @Override
    public UserInfoWritable read(String userId) throws AccException {
        UserInfoWritable res = cassandra.read(userId);
        if (res != null) {
            return res;
        }
        res = omap.read(userId);
        if (res != null) {
            cassandra.write(res);
        }
        return res;
    }
}
