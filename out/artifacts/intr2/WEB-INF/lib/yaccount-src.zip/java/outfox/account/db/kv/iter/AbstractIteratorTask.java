/**
 * @(#)AbstractIteratorTask.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import outfox.account.db.in.Iterator;
import outfox.account.db.in.IteratorService;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public abstract class AbstractIteratorTask<Type> {
    protected Object[] startKeys;
    protected IteratorService<Type> dbIterService;
    protected long scanCount;
    public void setScanCount(long scanCount) {
        this.scanCount = scanCount;
    }
    public long getScanCount() {
        return scanCount;
    }
    protected boolean isEnd(Object value){
        return false;
    }
    protected void preTask(){}
    
    protected abstract void runTask(Object value) throws AccException;
    
    protected void postTask(){}
    public AbstractIteratorTask(IteratorService<Type> dbIterService, Object ... startKeys) {
        this.dbIterService = dbIterService;
        this.startKeys = startKeys;
        this.scanCount = 0;
    }
    public void doIter() throws AccException{
        preTask();
        Iterator<?> iter = null;
        try {
            if (startKeys == null || startKeys.length == 0 ) {
                iter = (Iterator<?>) dbIterService.getIter();
            } else {
                iter = (Iterator<?>) dbIterService.getIter(startKeys);
            }
            Object value = null;
            while((value = iter.next()) != null ) {
                ++scanCount;
                if (isEnd(value)) {
                    break;
                }
                runTask(value);
            }
            postTask();
        } finally {
            AuthUtils.closeQuiet(iter);
        }
    }
    
    public Object returnValue() {
        return null;
    }
}
