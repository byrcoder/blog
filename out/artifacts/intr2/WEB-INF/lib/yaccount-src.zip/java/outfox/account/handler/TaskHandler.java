/**
 * @(#)TaskHandler.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import outfox.account.conf.AccConfig;
import outfox.account.task.clean.CleanTokenTask;


/**
 * The handler will not process any request.
 * Only start task
 * @author chen-chao
 */
public class TaskHandler extends BaseHandler{
    
    private static final long serialVersionUID = -3925409931350128341L;
    
    public void init() {
        boolean cleanTokenEnable = AccConfig.getPros().getBoolean(AccConfig.NAME_TASK_CLEAN_TOKEN_ENABLE); 
        if (cleanTokenEnable) {
            long interval = AccConfig.getPros().getLong(AccConfig.NAME_TASK_CLEAN_TOKEN_INTERVAL);
            long delay = AccConfig.getPros().getLong(AccConfig.NAME_TASK_CLEAN_TOKEN_DELAY);
            long expire = AccConfig.getPros().getLong(AccConfig.NAME_TASK_CLEAN_TOKEN_EXPIRE);
            CleanTokenTask.doTask(expire, delay, interval);
        }
    }
    
    public void destroy(){
        CleanTokenTask.cancelTask();
    }
}
