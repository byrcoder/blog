/**
 * @(#)ConsistentHashManager.java, 2011-7-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.ch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.zk.RetriableZKOperation;
import outfox.account.server.zk.Serviceable;
import outfox.account.server.zk.ZooKeeperWatcher;
import outfox.account.utils.ZKUtils;

/**
 * Handles everything related to consistent hash synchronization on master-side.
 *
 * <p>Listens to ZooKeeper notifications <code>NodeChildrenChanged</code>
 * on the store server dir znode and then manages the synchronization of
 * consistent hash over the cluster.
 *
 * <p>This manager should not be started until this server becomes the active
 * master.
 *
 * @author licx
 */
public class ConsistentHashManager extends ConsistentHashSynchronizer {
    private static final Log LOG = LogFactory.getLog(ConsistentHashManager.class);

    /**
     * @param watcher
     */
    public ConsistentHashManager(Serviceable service, ZooKeeperWatcher watcher,
            int vnodeNum) {
        super(service, watcher, vnodeNum);
        watcher.registerListener(this);
    }

    /**
     * Notice: This method should not be called unless this server
     * becomes the master.
     */
    @Override
    public void start() {
        LOG.info("Start consistent hash manager on master");
        // TODO assert this server is the active master?
        try {
            updateClusterHashCircle();
        } catch (KeeperException e) {
            throw new AccRunTimeException(new AccException(
                    "Fail to start ConsistentHashManager", e,
                    AccExpType.DISTRIBUTE_SERVICE_EXCEPTION));
        }
    }

    @Override
    public void nodeChildrenChanged(String path) {
        if (path.equals(watcher.accountServerDirZNode) && !service.isStopped()) {
            // store server is added or deleted from zookeeper so previous
            // consistent hash is out of date, if there is a synchronization
            // ongoing, interrupt the previous synchronization and start another one
            obsolete.set(true);
            updated.set(false);
            synchronized (updated) {
                updated.notifyAll();
            }
            LOG.info("Store server is added/deleted in zookeeper," +
    		" start to update the consistent hash...");
            // update the consistent hash circle in another thread because
            // the synchronization might take sometime and this method is
            // supposed to return fast
            new RetriableZKOperation(getClass().getSimpleName(), service) {
                @Override
                public void execute() throws KeeperException {
                    updateClusterHashCircle();
                }
            }.start();
        }
    }

    /**
     * Update consistent hash circle over the cluster. The updating
     * works in following steps:
     * 1. Master resets the consistent hash znode in zookeeper.
     * 2. Store servers get notified about the change of hash circle and
     * then update its store server znode version
     * 3. Both master and store server wait for all the store servers coming
     * to the same version and synchronization is finished.
     * 4. If any store server drops down during synchronization, both master
     * and the rest store servers interrupt the waiting and restart the process.
     *
     * <p>This method might wait sometime during the synchronization, so DON'T
     * use this method in {@link Watcher#process(WatchedEvent)}, which is
     * supposed to return fast.
     *
     * @see org.apache.zookeeper.Watcher#process(WatchedEvent)
     * @throws YDriveException
     */
    private void updateClusterHashCircle() throws KeeperException {
        hashCircleLock.writeLock().lock();
        try {
            LOG.debug("Starting consistent hash circle synchronization...");
            // read the old hash-circle to get the start version number
            // usually after Master failover
            byte[] data = ZKUtils.getData(watcher, watcher.consistentHashZNode);
            if (data != null && data.length != 0) {
                hashCircle.fromByteArray(data);
            }

            // this also set a watcher on the store server dir znode
            // store server added/deleted subsequently would cause a
            // notification to this manager
            List<String> servers = ZKUtils.listChildrensAndWatch(watcher,
                    watcher.accountServerDirZNode);
            // following logic is based on this server list, set obsolete
            // to false right after obtaining servers from zookeeper so that
            // subsequent update of servers in zookeeper would change this
            // value to true and interrupt the blocking
            obsolete.set(false);
            List<ServerAddress> rpcServerList = new ArrayList<ServerAddress>();
            for (String node: servers) {
                rpcServerList.add(new ServerAddress(node));
            }

            if (!rpcServerList.isEmpty()) {
                // reconstruct the hash circle based on the store server list
                // and set it in zookeeper
                hashCircle.update(rpcServerList);
                ZKUtils.setData(watcher, watcher.consistentHashZNode,
                        hashCircle.toByteArray());
                LOG.info("Waiting for all the store servers to update their " +
            		"hash circle data to version " + hashCircle.getVersion());
                // blocking to wait for the synchronization, we take the
                // timeout which the same as zookeeper timeout here
                long timeout = AccConfig.getPros().getLong(
                        AccConfig.NAME_HASHSYNC_TIMEOUT);
                if (!blockUntilSynchronized(timeout) && !service.isStopped()
                        && !obsolete.get()) {
                    // Master fail to synchronize the consistent hash, wait
                    // for a while to let the store server synchronization
                    // timeout and then trigger another update of hash circle
                    LOG.info("Consistent hash is not synchronized yet, " +
            		    "will trigger another synchronization later");
                    Thread.sleep(3000);
                    updateClusterHashCircle();
                }
            } else {
                LOG.warn("Would not synchronize the consistent hash because " +
            		"there is no store server in zookeeper right now");
            }
        } catch (IOException e) {
            LOG.fatal(watcher.prefix("Fail to serialize hash circle"), e);
            throw new AccRunTimeException("Hash circle serialization error", e);
        } catch (InterruptedException e) {
            LOG.warn(watcher.prefix("Interrupted waiting for " +
                    "consistent hash synchronization to finish"), e);
        } finally {
            hashCircleLock.writeLock().unlock();
        }
    }
}
