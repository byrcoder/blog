/**
 * @(#)URSCookieVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Map;
import java.util.Properties;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import outfox.account.exceptions.AccException;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import toolbox.web.CookieUtil;

import com.netease.urs.CookieNames;

/**
 * @author chen-chao
 */
public class URSCookieVerifier extends URSCookieVerifierBase {
    public static final String NAME = VerifierConfConst.URS_COOKIE_VERIFIER_NAME;
    public URSCookieVerifier(Properties props) {
        super(props, NAME);
    }
    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        Cookie sess = CookieUtil.findCookie(req, CookieNames.NTES_SESS);
        Cookie pers = CookieUtil.findCookie(req, CookieNames.NTES_PASSPORT);
        return super.authRequest(sess, pers, req, resp);
    }
}
