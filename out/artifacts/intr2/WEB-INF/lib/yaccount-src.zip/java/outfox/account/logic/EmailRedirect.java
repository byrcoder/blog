/**
 * @(#)EmailRedirect.java, 2012-12-24. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;

/**
 * @author chen-chao
 */
public class EmailRedirect {
    private static final String FLAG_AT = "@";
    private static final HashMap<String,String> EMAIL_DOMAIN_MAP = new HashMap<String,String>();
    public static Map<String, String> getEmailDomainMap() {
        return EMAIL_DOMAIN_MAP;
    }
    static {
        EMAIL_DOMAIN_MAP.put("163.com", "mail.163.com");
        EMAIL_DOMAIN_MAP.put("188.com", "mail.188.com");
        EMAIL_DOMAIN_MAP.put("yeah.net", "mail.yeah.net");
        EMAIL_DOMAIN_MAP.put("126.com", "mail.126.com");
        EMAIL_DOMAIN_MAP.put("vip.163.com", "vip.163.com");
        EMAIL_DOMAIN_MAP.put("vip.126.com", "vip.126.com");
    }
    public static String emailRedirctUrl(HttpServletRequest req, HttpServletResponse resp, Map<String,String> ursInfo) throws AccException {
        String userId = ursInfo.get(AccConst.USER_ID);
        Parameter pair = getEmailPrefixDomainPairEx(userId);
        String emailDomain = pair.getStrVal();
        String entryDomain = null;
        /**
         * entry.mail.163.com
         * entry.mail.188.com
         * entry.mail.yeah.net
         * entry.mail.126.com
         * entry.vip.163.com
         * entry.vip.126.com
         */
        entryDomain = EMAIL_DOMAIN_MAP.get(emailDomain);
        if (entryDomain == null) {
            throw new AccException("NOT SUPPORT email domain of "+emailDomain, AccExpType.NOT_SUPPORT);
        }
        /**
         * like:
         * http://passport.126.com/next.jsp?username=friends_test1@126.com&loginCookie=OH9cB8EeQcYaa598LC.6KQOCLWGcmvYFAOBLabTON4LRa5dR1a4dE8UxKRM_5qPVy5lYaqPu0zJfsNz8pxt8KVLOKDwS.3DB6iQ3y1DTObDTM.EQ0gIEU14EMxbCOSXszXl65UiRXRAPj9E_KsDzGnanCOZ7kTST0&sInfoCookie=1355985874%7C0%7C%231%2625%23%7Cfriends_test1%40126.com%23liangzijie85%40126.com%23lzjman%40126.com%23friends_test1%40yeah.net&pInfoCookie=friends_test1%40126.com%7C1355985874%7C0%7Curs%7C11%266%7Czhj%261355985786%26urs%23zhj%26330100%2310%230%230%7C%260&next=126.com&url=http%3A%2F%2Fentry.mail.126.com%2Fentry%2Fdoor%3Fusername%3Dfriends_test1%40126.com
         */
        List<Parameter> entryParam = new ArrayList<Parameter>();
        entryParam.add(new Parameter("username", userId));
        
        entryParam.add(new Parameter("loginCookie", ursInfo.get(UrsUtils.NTES_SESS)));
        entryParam.add(new Parameter("sInfoCookie", ursInfo.get(UrsUtils.S_INFO)));
        entryParam.add(new Parameter("pInfoCookie", ursInfo.get(UrsUtils.P_INFO)));
        entryParam.add(new Parameter("next", emailDomain));
        entryParam.add(new Parameter("url", String.format("http://entry.%s/entry/door?username=%s", entryDomain,userId)));
        String passportUrl = null;
        if ("163.com".equals(emailDomain)) {
            passportUrl = "http://reg.163.com/next.jsp";
        } else {
            passportUrl = String.format("http://passport.%s/next.jsp", emailDomain);
        }
        return AuthUtils.composeQueryUrl(passportUrl, entryParam);
    }
    public static Parameter getEmailPrefixDomainPairEx(String email) throws AccException {
        if (StringUtils.isBlank(email)) {
            throw new AccException(AccExpType.LOGIC_ERROR,"userId %s is error.", email);
        }
        int index = email.indexOf(FLAG_AT);
        if (index == -1) {
            throw new AccException(AccExpType.LOGIC_ERROR,"userId %s is error.", email);
        }
        return new Parameter(email.substring(0, index), email.substring(index + 1));
    }
    
    public static Parameter getEmailPrefixDomainPair(String email) {
        if (StringUtils.isBlank(email)) {
            return null;
        }
        int index = email.indexOf(FLAG_AT);
        if (index == -1) {
            return null;
        }
        return new Parameter(email.substring(0, index), email.substring(index + 1));
    }
    
    public static String getDomain(String email) throws AccException {
        Parameter pair = getEmailPrefixDomainPairEx(email);
        return pair.getStrVal();
    }
}
