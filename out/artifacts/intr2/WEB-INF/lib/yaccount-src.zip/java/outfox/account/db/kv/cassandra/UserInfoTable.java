package outfox.account.db.kv.cassandra;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.QueryOptions;
import com.datastax.driver.core.Session;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.in.IUserInfoDB;
import outfox.account.exceptions.AccException;
import toolbox.cassandra.client.CassandraClient;
import toolbox.cassandra.client.exception.CassandraRuntimeException;
import toolbox.cassandra.client.exception.NotFoundException;
import toolbox.cassandra.client.protocol.Keyspace;
import toolbox.cassandra.client.protocol.Table;

import java.util.List;

/**
 * @author yangzhe
 * @version created on 14-9-3.
 */
public class UserInfoTable implements IUserInfoDB {

    Keyspace keyspace;
    Table<UserInfoEntity> table;
    Session session;

    public UserInfoTable() {
        try {
            keyspace = CassandraClient.getInstance(new QueryOptions().setConsistencyLevel(ConsistencyLevel.QUORUM))
                    .getKeyspace("dict_account_server");
        } catch (NotFoundException e) {
            e.printStackTrace();
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
        table = keyspace.openTable("userinfo");
        session = keyspace.getGlobalSession();
    }

    @Override
    public UserInfoWritable write(UserInfoWritable userinfo) throws AccException {
        if (userinfo == null) {
            return null;
        }
        try {
            table.update(new UserInfoEntity(userinfo));
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }
        return userinfo;
    }

    @Override
    public UserInfoWritable read(String userId) throws AccException {
        try {
            List<UserInfoEntity> list = table.resultSetToEntityList(table.get(userId), new UserInfoEntity());
            if (list.size() > 0) {
                return list.get(0).toWritable();
            }
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }
        return null;
    }
}
