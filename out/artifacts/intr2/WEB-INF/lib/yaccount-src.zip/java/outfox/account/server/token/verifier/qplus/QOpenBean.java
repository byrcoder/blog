/**
 * @(#)QOpenBean.java, 2012-3-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.qplus;

import javax.servlet.http.HttpServletRequest;

import outfox.account.utils.AuthUtils;


/**
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 * 
 * @author chen-chao
 */
public class QOpenBean implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    private String appopenid = "";

    private String appopenkey = "";

    private String useripaddr = "";

    public QOpenBean() {
    // TODO: nothing
    }

    public QOpenBean(String appopenid, String appopenkey, String useripaddr) {
        this.setAppopenid(appopenid);
        this.setAppopenkey(appopenkey);
        this.setUseripaddr(useripaddr);
    }

    /**
     * just for login
     * 
     * @param request
     */
    public QOpenBean(HttpServletRequest request) {
        this("", "", AuthUtils.getRequestIP(request));
    }

    @Override
    public String toString() {
        return QOpenBean.class.getSimpleName() + "[appopenid=" + this.appopenid
                + ", appopenkey=" + this.appopenkey + ", useripaddr="
                + this.useripaddr + "]";
    }

    public String getAppopenid() {
        return appopenid;
    }

    public void setAppopenid(String appopenid) {
        this.appopenid = appopenid;
    }

    public String getAppopenkey() {
        return appopenkey;
    }

    public void setAppopenkey(String appopenkey) {
        this.appopenkey = appopenkey;
    }

    public String getUseripaddr() {
        return useripaddr;
    }

    public void setUseripaddr(String useripaddr) {
        this.useripaddr = useripaddr;
    }
}
