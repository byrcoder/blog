/**
 * @(#)DeviceInfo.java, 2013-5-30. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.device;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import outfox.account.data.AbstractWritable;
import outfox.account.device.DeviceStatus;

/**
 * @author chen-chao
 */
public class DeviceInfoWritable extends AbstractWritable {
    private static final long serialVersionUID = -6861934547902999922L;
    private static final String PROP_STATUS = "status";
    /**
     * Required members.
     */
    private String deviceId;
    private String product;
    
    /**
     * Unrequired members.
     */
    private String os;
    private String osVer;
    private String name;
    private String model;
    private String clientVer;
    private String type;
    
    /**
     * Properties set temporarily, won't be persisted.But should be copied in copyFields method.
     */
    private Map<String, Object> tempProps = new HashMap<String, Object>();
    
    public DeviceInfoWritable(){}
    
    public DeviceInfoWritable(String product, String deviceId) {
        this.product = product;
        this.deviceId = deviceId;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * @param deviceId the deviceId to set
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * @return the os
     */
    public String getOs() {
        return os;
    }

    /**
     * @param os the os to set
     */
    public void setOs(String os) {
        this.os = os;
    }

    /**
     * @return the osVer
     */
    public String getOsVer() {
        return osVer;
    }

    /**
     * @param osVer the osVer to set
     */
    public void setOsVer(String osVer) {
        this.osVer = osVer;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }
    
    /**
     * @return the clientVer
     */
    public String getClientVer() {
        return clientVer;
    }

    /**
     * @param clientVer the clientVer to set
     */
    public void setClientVer(String clientVer) {
        this.clientVer = clientVer;
    }
    
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    public DeviceStatus getDeviceStatus() {
        return (DeviceStatus)tempProps.get(PROP_STATUS);
    }
    
    public void setDeviceStatus(DeviceStatus status) {
        tempProps.put(PROP_STATUS, status);
    }

    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        deviceId = StringWritable.readStringNull(in);
        product = StringWritable.readStringNull(in);
        clientVer = StringWritable.readStringNull(in);
        model= StringWritable.readStringNull(in);
        name = StringWritable.readStringNull(in);
        osVer = StringWritable.readStringNull(in);
        os = StringWritable.readStringNull(in);
        type = StringWritable.readStringNull(in);
    }

    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, deviceId);
        StringWritable.writeStringNull(out, product);
        StringWritable.writeStringNull(out, clientVer);
        StringWritable.writeStringNull(out, model);
        StringWritable.writeStringNull(out, name);
        StringWritable.writeStringNull(out, osVer);
        StringWritable.writeStringNull(out, os);
        StringWritable.writeStringNull(out, type);
    }
    
    @Override
    public IWritable copyFields(IWritable other) {
        DeviceInfoWritable that = (DeviceInfoWritable)other;
        DeviceInfoWritable result = (DeviceInfoWritable)super.copyFields(other);
        result.tempProps.clear();
        result.tempProps.putAll(that.tempProps);
        return result;
    }
    
    
    public JSONObject toJSONObject() {
        JSONObject result = toJson();
        result.put("status", getDeviceStatus().getState());
        return result;
    }
}
