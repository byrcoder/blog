/**
 * @(#)CookieIndex.java, 2012-9-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import outfox.account.exceptions.AccRunTimeException;

/**
 * objects of the class will be put into global cache. It is used in "rp" interface
 * @author chen-chao
 */
public class CookieIndex {
    public String pci;
    public String pc;
    public String priKeyHex;
    public String msg;
    public String cipherType;
    public CookieIndex(String pci, String pc, String msg) {
        this(pci, pc, msg, null, null);
    }
    public CookieIndex(String pci, String pc, String msg, String priKeyHex, String cipherType) {
        this.pc = pc;
        this.pci = pci;
        this.msg = msg;
        this.priKeyHex = priKeyHex;
        this.cipherType = cipherType;
    }
    
    public static byte[] encode3(CookieIndex index) {
        StringBuilder s = new StringBuilder(index.pc);
        s.append("|").append(index.msg).append("|").append(index.priKeyHex).append("|").append(index.cipherType);
        return s.toString().getBytes();
    }
    
    public static byte[] encode2(CookieIndex index) {
        StringBuilder s = new StringBuilder();
        s.append(index.pc).append("|").append(index.msg);
        return s.toString().getBytes();
    }
    
    public static CookieIndex decode2(byte[] data) {
        if (data == null) {
            return null;
        }
        String dataStr = new String(data);
        String[] parts = dataStr.split("\\|");
        if (parts.length != 2) {
            throw new AccRunTimeException("data is not CookieIndex!! dataStr:" + dataStr);
        }
        return new CookieIndex(null, parts[0], parts[1]);
    }
    
    public static CookieIndex decode3(byte[] data) {
        if (data == null) {
            return null;
        }
        String dataStr = new String(data);
        String[] parts = dataStr.split("\\|");
        if (parts.length != 4 && parts.length != 5) {
            throw new AccRunTimeException("data is not CookieIndex!! dataStr:" + dataStr);
        }
        if (parts.length == 4) {
            return new CookieIndex(null, parts[0], parts[1], parts[2], parts[3]);
        } else {
            return new CookieIndex(null, parts[0], parts[1]+"|"+parts[2], parts[3], parts[4]);
        }
        
    }
}
