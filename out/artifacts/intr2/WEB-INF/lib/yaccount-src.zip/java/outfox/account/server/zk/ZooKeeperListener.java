/**
 * @(#)ZooKeeperListener.java, 2011-7-5. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.zk;

import outfox.account.exceptions.AccException;


/**
 * Base class for internal listeners of ZooKeeper events.
 *
 * <p>In order to receive events from the watcher, every listener must register
 * itself via {@link ZooKeeperWatcher#registerListener}. Subclasses need only
 * override those methods in which they are interested.
 *
 * <p>Note that the watcher will be blocked when invoking methods in listeners
 * so they must not be long-running.
 *
 * @author licx
 */
public abstract class ZooKeeperListener {
    // Reference to the zk watcher
    protected ZooKeeperWatcher watcher;

    /**
     * Construct a ZooKeeper event listener.
     */
    public ZooKeeperListener(ZooKeeperWatcher watcher) {
      this.watcher = watcher;
    }

    /**
     * Start this listener when the zookeeper connection is ready. Relevant
     * watchers would be set so that this listener would be notified when
     * corresponding events happen.
     *
     * @throws YDriveException
     */
    public void start() throws AccException {
        // no-op
    }

    /**
     * Stop this listener when stopping the service. Relevant znodes would
     * be removed from ZooKeeper.
     */
    public void stop() {
        watcher.removeListener(this);
    }

    /**
     * Called when a new node has been created.
     * @param path full path of the new node
     */
    public void nodeCreated(String path) {
      // no-op
    }

    /**
     * Called when a node has been deleted
     * @param path full path of the deleted node
     */
    public void nodeDeleted(String path) {
      // no-op
    }

    /**
     * Called when an existing node has changed data.
     * @param path full path of the updated node
     */
    public void nodeDataChanged(String path) {
      // no-op
    }

    /**
     * Called when an existing node has a child node added or removed.
     * @param path full path of the node whose children have changed
     */
    public void nodeChildrenChanged(String path) {
      // no-op
    }
}
