/**
 * @(#)AbstractKeyValueStore.java, 2010-6-20. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;


/**
 *
 * @author wangfk
 *
 */
public abstract class AbstractKeyValueStore<Key, Value> implements IKeyValueStore<Key, Value> {
    private static Log LOG = LogFactory.getLog(AbstractKeyValueStore.class); 
    
    protected String storeName;
    protected String storeSpace;
    
    @Override
    public void writeKeyValues(Key[] keys, Value[] values) 
            throws AccException {
        if(keys.length != values.length) {
            LOG.warn("Keys number is not consistent with values.");
            throw new AccRunTimeException(
                    "Keys number is not consistent with values.");
        }
        for(int i = 0; i < keys.length; ++ i) {
            writeKeyValue(keys[i], values[i]);
        }
    }
    
    @Override
    public void readValues(Key[] keys, Value[] values)
            throws AccException {
        
        for(int i = 0; i < keys.length; ++ i) {
            if(!readValue(keys[i], values[i])) {
                values[i] = null;
            }
        }
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public void setStoreSpace(String storeSpace) {
        this.storeSpace = storeSpace;
    }
    
    @Override
    public void deleteKeys(Key[] keys) throws AccException {
        for(Key key : keys) {
            deleteKey(key);
        }
    }

    @Override
    public String toString() {
        return "[" + this.getClass() + " StoreSpace=" + storeSpace + " StoreName=" + this.storeName + "]";
    }
}