/**
 * @(#)AbstractZkHashDistributeStragtegy.java, 2012-5-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.zk;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.SessionExpiredException;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.ch.ConsistentHashTracker;
import outfox.account.utils.ZKUtils;

/**
 * Keeps track of the consistent hash in zookeeper.
 *
 * <p>Listens to ZooKeeper notifications <code>NodeDataChanged</code>
 * on consistent hash znode and keeps track of consistent hash synchronization
 * status.
 * 
 * @author wangfk
 *
 */
public class ZkHashDistributeStrategy implements Serviceable {
    private static final Log LOG = LogFactory.getLog(ZkHashDistributeStrategy.class);

    protected ZooKeeperWatcher zooKeeper;

    protected ConsistentHashTracker hashCircleTracker;

    protected volatile boolean stopped;

    public ZkHashDistributeStrategy() throws AccException {
        initZooKeeper();
    }

    public List<ServerAddress> listService() throws AccException {
        if (stopped) {
            throw new AccException(
                    "AccountServer connection is closed already",
                    AccExpType.DISTRIBUTE_SERVICE_EXCEPTION);
        }

        try {
            List<String> nodes = ZKUtils.listChildrens(zooKeeper,
                    zooKeeper.accountServerDirZNode);
            List<ServerAddress> servers = new ArrayList<ServerAddress>();
            for (String node : nodes) {
                servers.add(new ServerAddress(node));
            }
            return servers;
        } catch (KeeperException e) {
            throw new AccException(
                    "Fail to get list account servers because ZooKeeper exception",
                    e, AccExpType.DISTRIBUTE_SERVICE_EXCEPTION);
        }
    }

    public ServerAddress lookupService(String key) throws AccException {
        if (stopped) {
            throw new AccException(
                    "Account connection is closed already",
                    AccExpType.DISTRIBUTE_SERVICE_EXCEPTION);
        }
        try {
            ServerAddress address = hashCircleTracker.lookup(key);
            if (address == null) {
                LOG.warn("No account server at present");
                throw new AccException(
                        "No account server at present",
                        AccExpType.DISTRIBUTE_SERVICE_EXCEPTION);
            }
            return address;
        } catch (InterruptedException e) {
            LOG.warn("Interrupted waiting for data store lookup");
            throw new AccRunTimeException(e);
        }
    }

    @Override
    public ZooKeeperWatcher getZooKeeper() {
        return zooKeeper;
    }

    @Override
    public void shutdown() {
        stop("AccConnection is shutdown");
        if (zooKeeper != null) {
            zooKeeper.close();
        }
    }

    @Override
    public boolean isStopped() {
        return stopped;
    }

    @Override
    public void stop(String why) {
        if (stopped) {
            LOG.info("This service distribute stragtegy has already been stopped...");
            return;
        }

        LOG.info("Stop service distribute stragtegy because " + why);
        stopped = true;
        if (hashCircleTracker != null) {
            hashCircleTracker.stop();
        }
    }

    @Override
    public void recover(String why, Exception cause) {
        LOG.warn("Recover because " + why);
        // shutdown the old zookeeper connection
        shutdown();
        if (cause != null && cause instanceof SessionExpiredException) {
            LOG.info("SessionExpiredException try to recover from ZooKeeper session expiration");
            try {
                // Notice: stopped flag must be set before ConsistentHashTracker
                // is started. Otherwise, we might receive consistent hash update
                // event before the stopped flag is set. This event would get
                // lost because the connection is treated as stopped
                
                initZooKeeper();
                
            } catch (AccException e) {
                LOG.error("Fail to recover from zk session expiration", e);
                shutdown();
            }
        } else {
            LOG.fatal("Could not recover from this kind of exception", cause);
        }
    }

    private void initZooKeeper() throws AccException {
        stopped = false;
        int vnodeNum = AccConfig.getPros().getInt(
                AccConfig.NAME_HASH_VNODENUM);
        zooKeeper = new ZooKeeperWatcher("AccRpcClient", this);
        System.out.println("init hash tracker ....");
        hashCircleTracker = new ConsistentHashTracker(this, zooKeeper, vnodeNum);
        hashCircleTracker.start();
        System.out.println("init hash tracker .... done");
    }
}
