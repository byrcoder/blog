/**
 * @(#)CleanTokenThread.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.task.clean;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.db.DataStore;
import outfox.account.db.DataStore.ScanCount;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class CleanTokenTask extends TimerTask {
    private static final Log LOG = LogFactory.getLog(CleanTokenTask.class);

    private static final char[] chars = AuthUtils.getMappingChars();

    private static final CleanTokenThread[] threads = new CleanTokenThread[chars.length];

    private static final DataStore dataStore = DataStore.getInstance();

    private CleanTokenTask(Long expiredTimeInMilli) {
        for (int i = 0; i < chars.length; i++) {
            threads[i] = new CleanTokenThread(chars[i], dataStore, expiredTimeInMilli);
        }
    }

    private static final Timer t = new Timer();

    private static boolean isRunning = false;
    
    private static AtomicBoolean isFinished = new AtomicBoolean(true);

    public static boolean isFinished() {
        return isFinished.get();
    }

    /**
     * If not call {@link #cancelTask()}, call the function second time is no effect.
     * @param expiredTime
     * @param timeDelayInMilli
     * @param timeIntervalInMilli
     */
    public static void doTask(Long expiredTime, Long timeDelayInMilli, Long timeIntervalInMilli) {
        synchronized (CleanTokenTask.class) {
            if (!isRunning) {
                isRunning = true;
                if (timeDelayInMilli == null) {
                    timeDelayInMilli = 0L;
                }
                LOG.info("expireTime set:"+expiredTime + " delayTime set:"+timeDelayInMilli + " interval set:"+timeIntervalInMilli);
                if (timeIntervalInMilli == null) {
                    t.schedule(new CleanTokenTask(expiredTime), timeDelayInMilli);
                } else {
                    t.schedule(new CleanTokenTask(expiredTime), timeDelayInMilli, timeIntervalInMilli);
                }
            }
        }
    }

    /**
     * if not call {@link #doTask(Long, Long, Long)}, call the function is no effect.
     */
    public static void cancelTask() {
        synchronized (CleanTokenTask.class) {
            if (isRunning) {
                t.cancel();
                isRunning = false;
            }

        }

    }

    @Override
    public void run() {
        if (!isFinished()) {
            return;
        }
        synchronized (CleanTokenTask.class) {
            // only one instance iter database.
            isFinished.set(false);
            for (CleanTokenThread thread: threads) {
                thread.start();
            }

            for (CleanTokenThread thread: threads) {
                try {
                    thread.join();
                } catch (Exception e) {
                    LOG.error("clan token thread can not run.", e);
                }
            }
            LOG.info("clean token task is finished.");
            isFinished.set(true);
        }
    }
    
    public static ScanCount totalCount() {
        ScanCount count = new ScanCount();
        if (isFinished()) {
            for (CleanTokenThread thread: threads) {
                System.out.println("thread "+thread.startChar+" scan:"+thread.getCount().scanCount + " process:"+thread.getCount().processCount);
                count.add(thread.getCount());
            }
        }
        return count;
    }

    private static class CleanTokenThread extends Thread {
        private static final Log LOG = LogFactory.getLog(CleanTokenThread.class);

        private char startChar;

        private DataStore store;

        private Long expiredTimeInMilli;
        private ScanCount count;
        public ScanCount getCount() {
            return count;
        }

        public CleanTokenThread(char startChar, DataStore store, Long expiredTimeInMilli) {
            this.startChar = startChar;
            this.store = store;
            this.expiredTimeInMilli = expiredTimeInMilli;
            this.count = new ScanCount();
        }

        @Override
        public void run() {
            try {
                count = store.removeTokenByStartChars("" + startChar, expiredTimeInMilli);
            } catch (AccException e) {
                LOG.error(String.format("remove start char %s, expired time %s error.", startChar,
                        expiredTimeInMilli), e);
            }
            LOG.info("DONE " + startChar + " cleaned. iter count:"+count);
        }
    }
}
