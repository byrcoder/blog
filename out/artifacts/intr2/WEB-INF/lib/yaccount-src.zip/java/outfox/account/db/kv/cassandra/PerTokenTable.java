package outfox.account.db.kv.cassandra;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.QueryOptions;
import com.datastax.driver.core.Session;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.exceptions.AccException;
import toolbox.cassandra.client.CassandraClient;
import toolbox.cassandra.client.exception.CassandraRuntimeException;
import toolbox.cassandra.client.exception.NotFoundException;
import toolbox.cassandra.client.protocol.Keyspace;
import toolbox.cassandra.client.protocol.Table;

import java.util.List;

/**
 * @author yangzhe
 * @version created on 14-9-2.
 */
public class PerTokenTable implements IPersTokenDB {

    Keyspace keyspace;
    Table<PerTokenEntity> table;
    Session session;

    public PerTokenTable() {
        try {
            keyspace = CassandraClient.getInstance(new QueryOptions().setConsistencyLevel(ConsistencyLevel.QUORUM))
                    .getKeyspace("dict_account_server");
        } catch (NotFoundException e) {
            e.printStackTrace();
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
        table = keyspace.openTable("pertoken");
        session = keyspace.getGlobalSession();
    }

    @Override
    public void write(TpToken tpToken) throws AccException {
        PerTokenEntity entity = new PerTokenEntity(tpToken);
        try {
            table.update(entity);
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }
    }

    @Override
    public void write(PersistTokenWritable tw) throws AccException {
        PerTokenEntity entity = new PerTokenEntity(tw);
        try {
            table.update(entity);
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }
    }

    @Override
    public PersistTokenWritable read(TpToken tpToken) throws AccException {
        try {
            List<PerTokenEntity> list = table.get(new PerTokenEntity(tpToken));
            if (list.size() != 0) {
                return list.get(0).toWritable();
            }
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public PersistTokenWritable read(String userId, String app, String product, String verifierName, String signature) throws AccException {
        try {
            List<PerTokenEntity> list = table.resultSetToEntityList(table.get(userId, app, product, verifierName, signature), new PerTokenEntity());
            if (list.size() != 0) {
                return list.get(0).toWritable();
            }
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void remove(String userId, String app, String product, String verifierName, String signature) throws AccException {
        try {
            table.delete(userId, app, product, verifierName, signature);
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }

    }

    @Override
    public void remove(TpToken tpToken) throws AccException {
        try {
            table.delete(tpToken.userId, tpToken.app, tpToken.product, tpToken.verifierName, tpToken.signature);
        } catch (CassandraRuntimeException e) {
            e.printStackTrace();
            throw new AccException(e);
        }

    }


    //iter是为了定期执行清理数据的task的，cassandra不这么搞，留空

    private class KVPersTokenIter implements IPersTokenIter {

        public KVPersTokenIter(String userid) throws AccException {
        }

        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         *
         * @throws AccException
         */
        @Override
        public PersistTokenWritable next() throws AccException {
            return null;
        }

        @Override
        public void close() {
        }
    }

    @Override
    public IPersTokenIter getIter(String userId) throws AccException {
        return new KVPersTokenIter(userId);
    }

    @Override
    public IPersTokenIter getIter(Object... startKeys) throws AccException {
        if (startKeys != null) {
            return getIter((String) startKeys[0]);
        }
        throw new AccException("no start keys", AccException.AccExpType.NOT_SUPPORT);
    }
}
