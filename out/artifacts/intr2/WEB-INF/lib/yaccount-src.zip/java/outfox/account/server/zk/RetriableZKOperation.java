/**
 * @(#)RetriableZKOperation.java, 2011-7-11. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.zk;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;

import outfox.account.conf.AccConfig;

/**
 * Executes retriable zookeeper operation in a separate thread. Operation would
 * be retried if recoverable zookeeper errors happen, such as
 * ConnectionLossException.
 *
 * <p>This thread would not terminate until the zookeeper operation is finished
 * successfully or 'zookeeer.recoverable.wait-time' has elapsed.
 *
 * @author licx
 */
public abstract class RetriableZKOperation extends Thread {
    private static final Log LOG = LogFactory.getLog(RetriableZKOperation.class);
    private static final long ZK_WAIT_INTERVAL = 1000;

    // operation name
    private String operation;
    private Object lock = new Object();

    // Service which execute this zk operation
    private Serviceable service;

    public RetriableZKOperation(String operation, Serviceable service) {
        super(operation);
        this.operation = operation;
        this.service = service;
    }

    @Override
    public void run() {
        long wait = AccConfig.getPros().getLong(
                AccConfig.NAME_ZK_RECOVERABLE_WAITTIME);
        long finished = System.currentTimeMillis() + wait;
        KeeperException ke = null;
        try {
            do {
                try {
                    execute();
                    ke = null;
                    break;
                } catch (KeeperException.ConnectionLossException e) {
                    // ConnectionLossException is a recoverable error for zookeeper
                    LOG.debug("Retrying operation " + operation + " for another " +
                            (finished - System.currentTimeMillis()) + "ms; " +
                            "set 'zookeeper.recoverable.wait-time' to change " +
                            "wait time; " + e.getMessage());
                    ke = e;
                    synchronized (lock) {
                        lock.wait(ZK_WAIT_INTERVAL);
                    }
                }
            } while (!isFinishedRetrying(finished));
            if (ke != null) {
                LOG.error("Fail to execute zookeeper operation " + operation
                        + " because retry timeout", ke);
                // TODO just stop the service if retry timeout?
                service.stop("ZooKeeper operation retry failure");
            }
        } catch (KeeperException.SessionExpiredException e) {
            // should rarely come here, let the ZooKeeperWatcher deals with
            // the state related events
            LOG.warn("Fail to execute zookeeper operation " + operation
                    + " because session is expired", e);
        } catch (Throwable t) {
            // should not be here, mostly run time exception
            LOG.fatal("Fail to execute zookeeper operation " + operation, t);
            // TODO just stop the service if retry timeout?
            service.stop("ZooKeeper operation retry failure");
        }
    }

    private boolean isFinishedRetrying(final long finished) {
        return System.currentTimeMillis() >= finished;
    }

    /**
     * Do ZooKeeper related operations here.
     *
     * <p>Notice: this method would be retries when recoverable zookeeper
     * error happen, so zookeeper operations in this method should be
     * retriable, that is executing the operations multiple times would not
     * change the result or throw unexpected exceptions.
     *
     * @throws KeeperException
     */
    public abstract void execute() throws KeeperException;
}
