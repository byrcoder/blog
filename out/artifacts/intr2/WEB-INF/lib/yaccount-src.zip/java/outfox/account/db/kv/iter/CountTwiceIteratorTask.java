/**
 * @(#)CountIteratorTask.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import outfox.account.db.in.IteratorService;

/**
 * @author chen-chao
 */
public class CountTwiceIteratorTask<Type> extends AbstractIteratorTask<Type>{
    private int count;
    public CountTwiceIteratorTask(IteratorService<Type> dbIterService, Object... startKeys) {
        super(dbIterService, startKeys);
    }

    @Override
    protected boolean isEnd(Object value) {
        return count > 1;
    }

    @Override
    protected void preTask() {
        count = 0;
    }

    @Override
    protected void runTask(Object value) {
        count++;
    }

    @Override
    public Object returnValue() {
        return count;
    }
    
    
}
