/**
 * @(#)IEvent.java, 2013-6-4. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.logic.event;

import java.util.EventListener;
import java.util.EventObject;

import outfox.account.exceptions.AccException;

/**
 * Generic event class used to fired to listeners.
 * @author chen-chao, zhanglz
 */
public abstract class AccEvent extends EventObject{
    private static final long serialVersionUID = 3432470584190863362L;
    
    public AccEvent(Object source) {
        super(source);
    }
    
    /**
     * Invoked between when this event is generated and fired to listeners.
     * Used to do some logic synchronously with controller threads. 
     * @throws AccException
     */
    public abstract void process() throws AccException;

    /**
     * Invoked after this event is fired to listeners.
     * Used to do some logic asynchronously in thread executors.
     * @param obj
     * @throws AccException
     */
    public abstract void notify(EventListener obj)throws AccException;
}