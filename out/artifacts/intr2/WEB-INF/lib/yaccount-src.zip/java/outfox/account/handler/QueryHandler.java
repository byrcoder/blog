/**
 * @(#)QueryHandler.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.AccCookies;
import outfox.account.data.AuthInfo;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.device.DeviceManager;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.logic.event.AccEvent;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.server.token.verifier.impl.TSinaCourseVerifier;
import outfox.account.server.token.verifier.impl.TSinaNormalVerifier;
import outfox.account.server.token.verifier.impl.TSinaThirdVerifier;
import outfox.account.server.token.verifier.impl.TSinaVerifier;
import outfox.account.server.token.verifier.impl.WQQVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;
import outfox.account.utils.UrsUtils;
import toolbox.web.CookieUtil;

/**
 * @author chen-chao
 */
@Controller
public class QueryHandler extends BaseHandler {
    private static final long serialVersionUID = 356378422269925319L;
    private TokenVerifierFactory tf = TokenVerifierFactory.getInstance();
    private DataStore datastore = DataStore.getInstance();
    
    private Set<String> nameSet =  new HashSet<String>(Arrays.asList(new String[]{
            TSinaVerifier.NAME,
            TSinaNormalVerifier.NAME,
            TSinaThirdVerifier.NAME,
            TSinaCourseVerifier.NAME,
            WQQVerifier.NAME
    }));
    /**
     * using persist token to get a session cookie
     * and also can ge userinfo.
     * if no userId, it will clean all cookies.
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(AccConst.COOKIE_QUERY_URL)
    public void query(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "query");
        setErrorAttribute(req, HttpStatus.UNAUTHORIZED);
        checkParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        SessionCookieWritable sess = null;
        PersistTokenWritable pers = null;
        boolean isLogin = false;
        boolean isBind = false;
        String product = AuthUtils.getParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME);
        String userId = ReqUtils.getUserIdByProduct(req, product);
        
        if (!StringUtils.isBlank(userId)) {
            isLogin = true;
            AuthInfo tokens = getLoginInfo(req);
            if (tokens.tpToken.sessIndex.contains(AccConst.URS_MEMORY_CHECK)) {
                // read database again.
                SessionCookieWritable sessCookieWritable = DataStore.getInstance().readSessCookie(tokens.tpToken.sessIndex);
                if (sessCookieWritable == null) {
                    // cookie is deleted.
                    isLogin = false;
                }
            }
        }
        String bindUserId = ReqUtils.getBindUserIdByProduct(req, product);
        if (!StringUtils.isBlank(bindUserId)) {
            isBind = true;
        }
        List<Parameter> result = new ArrayList<Parameter>();
        result.add(new Parameter(AccConst.FLAG_LOGIN, false));
        cleanCookie(isLogin, isBind, product, req, resp);
        if (!(isLogin || isBind)) {
            result.add(new Parameter(AccConst.FLAG_LOGIN, false));
            Cookie sessCookie = CookieUtil.findCookie(req, product+AccConst.COOKIE_SESSION);
            Cookie loginCookie = CookieUtil.findCookie(req, product+AccConst.COOKIE_LOGIN);
            Cookie persCookie = CookieUtil.findCookie(req, product + AccConst.COOKIE_PERSISTENT);
            String persHeader = req.getHeader(product + AccConst.ATTR_PART_PC);
            Cookie bindCookie = CookieUtil.findCookie(req, product + AccConst.COOKIE_SESSION_BIND);
            String persToken = (String)req.getAttribute(AccConst.ATTR_CHECKED_PC);
            String app = req.getParameter(AccConst.PARAM_APP_NAME);
            String wantUserId = req.getParameter(AccConst.PARAM_USER_ID);
            StringBuilder sb = new StringBuilder();
            sb.append(cookie2String(sessCookie)).append(cookie2String(loginCookie))
                    .append(cookie2String(persCookie)).append(cookie2String(bindCookie))
                    .append("persHeader:").append(persHeader).append(" token:").append(persToken)
                    .append(" app:").append(app).append(" product:").append(product).append(" want id:")
                    .append(wantUserId);

            LOG.warn("Not login. print cookies:"+sb.toString());
                    
            write(req, resp, result, HttpStatus.OK);
            return;
        } 
        
        // check current device status
        List<AccEvent> eventList = new ArrayList<AccEvent>();
        if (!DeviceManager.tryTransferStatus(product, userId, OPERATOR.CQ, 
                null, req, result, eventList)) {
            write(req, resp, result, HttpStatus.SERVICE_UNAVAILABLE);
            return;
        }

        String persToken = null;
        TpToken token = null;
        // only login should write cookie back
        int cookieParam = AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value());
        cookieParam = COOKIE_FORMAT.pe.remove(cookieParam);
        req.setAttribute(AccConst.PARAM_COOKIE_FORMAT, cookieParam);
        if (isLogin) {
            AccCookies accCookies = null;
            if ((sess = (SessionCookieWritable) req.getAttribute(product + AccConst.ATTR_PART_SESS_WRITABLE)) != null) {
                token = sess.getTpToken();
                IVerifier verifier = tf.getTokenVerifier(token.product, token.verifierName);
                TokenUtils.encode(verifier, token);
                accCookies = TokenUtils.genCookieByCookieParam(req, token);
            } else if ((pers = (PersistTokenWritable) req.getAttribute(product
                    + AccConst.ATTR_PART_PERSTOKEN_WRITABLE)) != null) {
                token = pers.getTpToken();
                IVerifier verifier = tf.getTokenVerifier(token.product, token.verifierName);
                TokenUtils.encode(verifier, token);
                accCookies = TokenUtils.genCookieByCookieParam(req, token);
            }
            if (accCookies != null) {
                accCookies.addCookieToResponse(resp);
                if (!AuthUtils.isWeb(accCookies.getApp())) {
                    persToken = accCookies.getPerToken();
                }
            }
        } 
        
        
        JSONObject ret = new JSONObject();
        if (COOKIE_FORMAT.info.isContain(cookieParam)) {
            if (isLogin || isBind) {
                UserInfoWritable userInfo = null;
                UserInfoWritable bindUserInfo = null;
                
                if (isLogin) {
                    userInfo = ReqUtils.getUserInfo(req, product);
                    if (userInfo == null) {
                        // read from db
                        userInfo = datastore.readUserInfo(userId);
                        if (userInfo == null) {
                            throw new AccException("userInfo is not found? userId:" + userId, AccExpType.UNKNOWN_EXCEPTION);
                        }
                        
                    }
                    userInfo.putIntoJSON(ret);
                } 
                if (isBind) {
                    bindUserInfo = ReqUtils.getBindUserInfo(req, product);
                    if (bindUserInfo == null) {
                        bindUserInfo = datastore.readUserInfo(bindUserId);
                        if (bindUserInfo == null) {
                            throw new AccException("bind userInfo is not found? userId:" + bindUserId, AccExpType.UNKNOWN_EXCEPTION);
                        }
                    }
                    
                    ret.put(AccConst.FLAG_BIND_USER, bindUserInfo.getJSON());
                }
                
            } 
            
        }
        if (persToken != null && token != null) {
            ret.put(token.product + AccConst.ATTR_PART_PC, persToken);
        }
        if (isLogin) {
            ret.put(AccConst.FLAG_LOGIN, true);
            if (StringUtils.isNotBlank(req.getParameter(AccConst.PARAM_GET_ACCESS_TOKEN))) {
                if (nameSet.contains(token.verifierName)) {
                    // XXX  tricky cookie. only for IPhone, Android
                    resp.addCookie(AuthUtils.tickyCookie(product + AccConst.COOKIE_TOKEN, token.token, AuthUtils.getCookieDomain(req), true));
                    if (WQQVerifier.NAME.equals(token.verifierName)) {
                        // get openId and expired time
                        ret.put(AccConst.OPEN_ID, token.authid);
                        ret.put(AccConst.EXPIRED, token.getExpiredTime());
                    }
                }
            }
        }
        if (isBind) {
            ret.put(AccConst.FLAG_BIND, true);
            SessionCookieWritable bindCookie = ReqUtils.getBindCookieWritable(req, product);
            if (bindCookie != null && StringUtils.isNotBlank(req.getParameter(AccConst.PARAM_GET_ACCESS_TOKEN))) {
                if (nameSet.contains(bindCookie.getTpToken().verifierName)) {
                    // XXX  tricky cookie. only for IPhone, Android
                    resp.addCookie(AuthUtils.tickyCookie(product + AccConst.COOKIE_BIND_TOKEN, bindCookie.getTpToken().token, AuthUtils.getCookieDomain(req), true));
                }
            }
        }
        
        // handle generated event.
        DeviceManager.handleEvents(eventList);
        writeJSON(req,resp, ret, HttpStatus.OK);
    }

    protected void sendAccessTokenBack(HttpServletRequest req, HttpServletResponse resp, String product,
            TpToken token, JSONObject ret, String cookieName) {

        final String userId = token.userId;
        if (!is163Account(userId)) {
            if (userId.startsWith("sina") || userId.startsWith("wqq")) {
                // XXX  tricky cookie. only for IPhone, Android
                resp.addCookie(AuthUtils.tickyCookie(product + cookieName, token.token,
                        AuthUtils.getCookieDomain(req), true));
                if (userId.startsWith("wqq")) {
                    // get openId and expired time
                    ret.put(AccConst.OPEN_ID, token.authid);
                    ret.put(AccConst.EXPIRED, token.getExpiredTime());
                }
            }
        }
    }
    
    private boolean is163Account(String userId){
        return userId.contains("@");
    }
    
    private String cookie2String(Cookie cookie) {
        StringBuilder sb = new StringBuilder();
        if (cookie != null) {
            sb.append("[").append("name:").append(cookie.getName()).append(" value:")
                    .append(cookie.getValue()).append("]");

        }
        return sb.toString();
    }
    
    private void cleanCookie(boolean isLogin, boolean isBind, String product, HttpServletRequest req, HttpServletResponse resp){
        if (!(isLogin || isBind)) {
            cleanLoginCookie(product, req, resp);
            // TODO is new login deploy, remove clean OldCookies
            AuthUtils.cleanOldCookies(req, resp, product);
        } else if (!isLogin) {
            // clean cookies
            cleanLoginCookie(product, req, resp);
        } else if (!isBind) {
            UrsUtils.cleanURSCookies(resp);
            AuthUtils.cleanOldCookies(req, resp, product);
        }
        
    }

    protected void cleanLoginCookie(String product, HttpServletRequest req, HttpServletResponse resp) {
        AccCookies cookie = new AccCookies(product, req, AccConfig.CLIENT_TYPE_WEB);
        cookie.cleanAllCookiesInResponse(resp);
        UrsUtils.cleanURSCookies(resp);
    }
}
