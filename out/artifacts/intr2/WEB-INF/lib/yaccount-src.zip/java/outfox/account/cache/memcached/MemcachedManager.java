/**
 * @(#)GlobalCacheManager.java, 2012-10-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache.memcached;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccRunTimeException;

/**
 * Cache manager which provides only global cache services.
 * A dedicated Memcached server cluster is used to provides
 * the global cache. Cached items must be serialized/deserialized when put/get
 * from the global cache server. So primitive types (including Date and String)
 * as well as <code>IWritable</code> are preferred as the global cached value.
 * <p>
 * Usually data items of the same type would have the similar behavior, so it is
 * recommended using the class name as the cache name, e.g. UserMetaWritable@global
 *
 * @see outfox.ynote.cache.memcached.MemcachedCache
 * @author licx,chen-chao
 */
public class MemcachedManager implements CacheManager, InitializingBean {
    private static final Log LOG = LogFactory.getLog(MemcachedManager.class);
    private static final String GLOBAL_CACHE = "global";
    private static final String DEFAULT_SEPARATOR = "@";

    /**
     * Config file locations for memcached
     */
    private static final String MEMCACHED_CONFIG_FILE = "acc-memcached.xml";

    /**
     * Caches for memcached cache
     */
    private final ConcurrentMap<String, Cache> memcachedMap =
        new ConcurrentHashMap<String, Cache>();

    /**
     * Separator between cache name and cache type, by default we use character @
     * So the whole cache name is in the format of name@type, e.g. UserMetaWritable@local
     */
    private String separator = DEFAULT_SEPARATOR;

    public void setSeparator(String separator) {
        this.separator = separator;
    }
    private static final Object lock = new Object();
    private static volatile MemcachedManager instance = null;
    public static MemcachedManager getInstance(){
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new MemcachedManager();
                    instance.afterPropertiesSet();
                }
            }
        }
        return instance;
    }
    
    /**
     * Load the memcached cache from configuration file. Memcached caches are
     * configured as spring beans, so the configuration file is the same format
     * as spring configuration file.
     *
     * @return a collection of memcached cache.
     */
    private Collection<? extends Cache> loadMemcachedCaches(File memcachedConfigFile) {
        // load the memcache caches using the spring bean factory
        Resource configFile = new FileSystemResource(memcachedConfigFile);
        DefaultListableBeanFactory factory = new DefaultListableBeanFactory(null);
        XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(factory);
        reader.loadBeanDefinitions(configFile);
        String[] cacheNames = factory.getBeanNamesForType(MemcachedCache.class);
        Collection<Cache> caches = new LinkedHashSet<Cache>(cacheNames.length);
        for (String name : cacheNames) {
            caches.add((MemcachedCache)factory.getBean(name));
        }
        LOG.info("Load global memcached caches " + Arrays.toString(cacheNames));
        return caches;
    }

    @Override
    public void afterPropertiesSet() {
        // load memcached caches if the config file is not empty
        Collection<? extends Cache> memcachedCaches =  new HashSet<Cache>();
        
        if (AccConfig.isTestCaseMode()) {
            String configFile = MEMCACHED_CONFIG_FILE+".template";
            File tmpConfigFile = AccConfig.getConfigFile(configFile);
            System.out.println("memcached config file:" +tmpConfigFile.getAbsolutePath());
            if (tmpConfigFile.exists()){
                FileInputStream fis = null;
                FileOutputStream fos = null;
                try {
                    fis = new FileInputStream(AccConfig.getConfigFile(configFile));
                    fos = new FileOutputStream(AccConfig.getConfigFile(MEMCACHED_CONFIG_FILE));
                    IOUtils.copy(fis, fos);
                } catch (Exception e) {
                    LOG.warn("memcache file load error.", e);
                } finally {
                    IOUtils.closeQuietly(fis);
                    IOUtils.closeQuietly(fos);
                }
            }
        } 
        File memcachedConfig = AccConfig.getConfigFile(MEMCACHED_CONFIG_FILE);
        if (memcachedConfig.exists()) {
            memcachedCaches = loadMemcachedCaches(memcachedConfig);
        }

        // put memcached cache into the cache map, cache name is in the format of
        // cache_name@global
        memcachedMap.clear();
        for (Cache cache : memcachedCaches) {
            String cacheName = cache.getName() + separator + GLOBAL_CACHE;
            memcachedMap.put(cacheName, cache);
        }
        if (AccConfig.isTestCaseMode()) {
            // remove MEMCACHED_CONFIG_FILE
            File f = AccConfig.getConfigFile(MEMCACHED_CONFIG_FILE);
            f.delete();
        }
        LOG.info("Load caches " + memcachedMap.keySet().toString());
    }

    @Override
    public Collection<String> getCacheNames() {
        return Collections.unmodifiableSet(this.memcachedMap.keySet());
    }

    /**
     * Get the cache for the given cache name. Cache name is composed of
     * exact cache name and the cache type, e.g. 
     * FileMetaWritable@global. 
     */
    @Override
    public Cache getCache(String name) {
        Cache cache = memcachedMap.get(name);
        if (cache == null) {
            throw new AccRunTimeException("No cache is defined for name " + name);
        }
        return cache;
    }
}
