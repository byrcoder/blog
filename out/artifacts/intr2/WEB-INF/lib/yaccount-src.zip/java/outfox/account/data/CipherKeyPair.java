/**
 * @(#)CipherKeyPair.java, 2013-3-13. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.security.KeyPair;

import org.apache.commons.codec.binary.Hex;

/**
 * decrypt - encrypt key pair
 * @author chen-chao
 */
public class CipherKeyPair {
    private String decryptKey;
    private String encryptKey;
    private KeyPair keypair;
    public CipherKeyPair(String encryptKey, String decryptKey) {
        this.decryptKey = decryptKey;
        this.encryptKey = encryptKey;
    }
    public CipherKeyPair(KeyPair keypair) {
        this.keypair = keypair;
        this.encryptKey = Hex.encodeHexString(keypair.getPublic().getEncoded());
        this.decryptKey = Hex.encodeHexString(keypair.getPrivate().getEncoded());
    }
    
    public KeyPair getKeyPair() {
        return keypair;
    }
    
    public String getDecryptKey() {
        return decryptKey;
    }
    public String getEncryptKey() {
        return encryptKey;
    }
    
}
