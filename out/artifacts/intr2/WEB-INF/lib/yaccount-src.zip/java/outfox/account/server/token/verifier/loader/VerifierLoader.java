/**
 * @(#)ConsumerLoader.java, 2012-9-11. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.loader;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import outfox.account.conf.AccConfig;
import outfox.account.utils.LoadUtils;

/**
 * @author chen-chao
 */
public class VerifierLoader {

    private static final String CONSUMER_FILE_NAME = "tp.properties";

    private static final HashMap<String, Properties> props = new HashMap<String, Properties>();
    
    /**
     * first load configure from configure directory, if not exist.
     * Then load configure from class package.
     * @return
     */
    public static Map<String, Properties> init() {
        // use local consumer file first
        Set<String> products = AccConfig.getProductSet();
        for (String product : products) {
            Properties properties = LoadUtils.initFromConfFile(product + "." + CONSUMER_FILE_NAME);
            if (properties.size() == 0) {
                properties = LoadUtils.initFromClassPackage(VerifierLoader.class, product + "." + CONSUMER_FILE_NAME);
            }
            props.put(product, properties);
        }
        
        return props;
    }
    
}
