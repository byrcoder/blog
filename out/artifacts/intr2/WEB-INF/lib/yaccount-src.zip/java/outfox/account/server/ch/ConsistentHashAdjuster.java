/**
 * @(#)ConsistentHashAdjuster.java, 2011-7-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.ch;

import java.io.UnsupportedEncodingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.zk.RetriableZKOperation;
import outfox.account.server.zk.Serviceable;
import outfox.account.server.zk.ZooKeeperWatcher;
import outfox.account.utils.ConsistentHash;
import outfox.account.utils.ZKUtils;

/**
 * Handles everything related with consistent hash circle in store server.
 * Adjusts the consistent hash version according to the update of consistent
 * hash by master.
 *
 * <p>Listens to ZooKeeper notifications <code>NodeDataChanged</code>
 * on consistent hash znode and then updates the consistent hash version
 * of this store server in ZooKeeper.
 *
 * <p>This class should be started at the very beginning of store server.
 *
 * @author licx
 */
public class ConsistentHashAdjuster extends ConsistentHashSynchronizer {
    private static final Log LOG = LogFactory.getLog(ConsistentHashAdjuster.class);

    // Znode name of this store server
    private String serverZnode;
    
    /**
     * @param service store server reference
     * @param watcher zookeeper watcher reference
     * @param serverNum number of store servers
     */
    public ConsistentHashAdjuster(Serviceable service,
            ServerAddress address, ZooKeeperWatcher watcher, int serverNum) {
        super(service, watcher, serverNum);
        this.serverZnode = ZKUtils.joinZNode(watcher.accountServerDirZNode,
                address.toString());
        watcher.registerListener(this);
    }
    
    /**
     * Notice: Store server uses its address to register in ZooKeeper,
     * So DON'T start two store servers process on the same server.
     *
     * @throws YDriveException
     */
    @Override
    public void start() {
        try {
            // 1. set a watcher on consistent hash znode first
            ZKUtils.getDataAndWatch(watcher, watcher.consistentHashZNode);
            // 2. add this server to zookeeper to register
            LOG.info("Register " + serverZnode + " in ZooKeeper");
            ZKUtils.createEphemeralNodeInsistent(watcher, serverZnode, new byte[0]);
            LOG.info("ConsistentHashAdjuster is started");
        } catch (KeeperException e) {
            throw new AccRunTimeException(new AccException(
                    "Fail to start ConsistentHashAdjuster", e,
                    AccExpType.DISTRIBUTE_SERVICE_EXCEPTION));
        }
    }

    @Override
    public void stop() {
        try {
            // remove the registered znode of this store server from zk
            ZKUtils.deleteNodeFailSilent(watcher, serverZnode);
            LOG.info("ConsistentHashAdjuster is stopped");
        } catch (KeeperException e) {
            LOG.warn("Ignore any ZooKeeper exceptions " +
    		"when stopping ConsistentHashAdjuster");
        }
        super.stop();
    }

    @Override
    public void nodeDataChanged(String path) {
        if (path.equals(watcher.consistentHashZNode) && !service.isStopped()) {
            // consistent hash circle znode is reset by the master so previous
            // consistent hash is out of date, if there is a synchronization thread
            // ongoing, interrupt the previous synchronization and start a new one
            obsolete.set(true);
            updated.set(false);
            synchronized (updated) {
                updated.notifyAll();
            }
            LOG.info("Consistent hash circle is updated by master, " +
                "start to update the consistent hash...");
            // update the consistent hash circle in another thread because
            // the synchronization might take sometime and this method is
            // supposed to return fast
            new RetriableZKOperation(getClass().getSimpleName(), service) {
                @Override
                public void execute() throws KeeperException {
                    updateServerHashCircle();
                }
            }.start();
        } else {
            super.nodeDataChanged(path);
        }
    }

    /**
     * Updates the consistent hash version of this server in zookeeper when
     * the master updates the data of consistent hash znode. This method would
     * not return until consistent hash is synchronized over the cluster.
     *
     * <p>This method might wait sometime during the synchronization, so DON'T
     * use this method in {@link Watcher#process(WatchedEvent)}, which is
     * supposed to return fast.
     *
     * @throws YDriveException
     */
    private void updateServerHashCircle() throws KeeperException {
        hashCircleLock.writeLock().lock();
        try {
            ConsistentHash currentHashCircle = getCurrentHashCircle();
            // following logic is based on this local hash circle, set obsolete
            // to false right after obtaining hash circle from zookeeper so that
            // subsequent update of hash circle in zookeeper would change this
            // value to true and interrupt the blocking
            obsolete.set(false);
            if (currentHashCircle == null ||
                    currentHashCircle.getVersion() == hashCircle.getVersion()) {
                LOG.info("Consistent hash circle is not changed, "
                        + "version=" + hashCircle.getVersion());
                return;
            }

            // update the version number of this server to the latest hash
            // circle version
            byte[] latestVersion = Long.valueOf(currentHashCircle.getVersion()).toString()
                    .getBytes(ZKUtils.ZK_ENCODING);
            ZKUtils.setData(watcher, serverZnode, latestVersion);
            LOG.info("Update the version of " + serverZnode + " to "
                    + currentHashCircle.getVersion());
            // blocking to wait for the synchronization. Do nothing if the
            // synchronization timeout because master will trigger another
            // synchronization later
            long timeout = AccConfig.getPros().getLong(
                    AccConfig.NAME_HASHSYNC_TIMEOUT);
            blockUntilSynchronized(timeout);
        } catch (UnsupportedEncodingException e) {
            LOG.fatal("Server does not support encoding " + ZKUtils.ZK_ENCODING, e);
            throw new AccRunTimeException("Unsupported encoding "
                    + ZKUtils.ZK_ENCODING, e);
        } finally {
            hashCircleLock.writeLock().unlock();
        }
    }
}
