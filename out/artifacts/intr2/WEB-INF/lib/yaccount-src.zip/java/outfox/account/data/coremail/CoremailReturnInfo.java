/**
 * @(#)CoremailReturnInfo.java, 2012-11-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.coremail;

/**
 *
 * @author wangxin
 *
 */
public class CoremailReturnInfo {

    private int code;
    private String message;
    private String result;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }


    public final String toString() {
        StringBuilder out = new StringBuilder();
        out.append("Coremail.API.ReturnInfo [");
        out.append(code);
        out.append(']');
        out.append((message != null) ? ('[' + message + ']') : "");
        out.append(((result != null) ? (": " + result) : ""));
        return out.toString();
    }
    
    public void testFOR_SAMPLE_SimpleAPI_DEFAULT() throws Exception {
        // 只兼容 JAX-WS RI 2.1.6 以上版本， java 1.6.0_20 以上
        System.out.println("==========================================================================");
        System.out.println("Testing DOCUMENT style soap....");
        System.out.println("==========================================================================");

        CoremailAPI api = javax.xml.ws.Service.create(
                new java.net.URL("http://cm4.icoremail.net/apiws/services/API?wsdl"),
                new javax.xml.namespace.QName("http://coremail.cn/apiws", "API")
        ).getPort(CoremailAPI.class);

        System.out.println("Invoke getVersionInfo()....");
        System.out.println(api.getVersionInfo());
        System.out.println("Invoke getAttrs(\"admin\", \"truename\")....");
        System.out.println(api.getAttrs("admin", "true_name"));
        System.out.println("Invoke getAttrs(\"foo@bar.com\", \"\")....");
        System.out.println(api.getAttrs("foo@bar.com", ""));
    }
}
