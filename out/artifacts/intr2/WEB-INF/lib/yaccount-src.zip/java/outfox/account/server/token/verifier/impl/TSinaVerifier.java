/**
 * @(#)TSinaVerifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Properties;
import outfox.account.server.token.verifier.loader.VerifierConfConst;

/**
 * @author wangzhen
 */
public class TSinaVerifier extends TSinaBaseVerifier {

    public static final String NAME = VerifierConfConst.TSINA_VERIFIER_NAME;
    public TSinaVerifier(Properties props) {
        super(props, NAME);
    }
    
    @Override
    public String getVerifierName() {
        return NAME;
    }
    
    
}
