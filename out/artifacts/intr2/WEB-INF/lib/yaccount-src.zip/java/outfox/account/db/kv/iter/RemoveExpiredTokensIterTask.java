/**
 * @(#)RemoveExpiredTokens.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import outfox.account.data.SessionCookieWritable;
import outfox.account.db.DataStore;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.db.in.ISessCookieDB.ISessCookieIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class RemoveExpiredTokensIterTask extends AbstractIteratorTask<ISessCookieIter>{
    private long expireTimeInMilli;
    private String startChars;
    private DataStore store;
    private long count;
    public RemoveExpiredTokensIterTask(DataStore store, ISessCookieDB sessDB, String startChars, Long expireTimeInMilli) {
        super(sessDB, startChars);
        if (expireTimeInMilli == null) {
            this.expireTimeInMilli = -1L;
        } else {
            this.expireTimeInMilli = expireTimeInMilli;
        }
        this.startChars = startChars;
        this.store = store;
        this.count = 0;
    }

    @Override
    protected boolean isEnd(Object value) {
        SessionCookieWritable sess = (SessionCookieWritable)value;
        return !sess.getTpToken().sessIndex.startsWith(startChars);
    }

    @Override
    protected void runTask(Object value) throws AccException {
        SessionCookieWritable sess = (SessionCookieWritable)value;
        if (sess.getTpToken().isExpired() || sess.getTpToken().isExpired(expireTimeInMilli)) {
            store.removeTokenWithoutCleanCache(sess.getTpToken());
        }
        ++count;
    }

    @Override
    public Object returnValue() {
        return count;
    }
    
}
