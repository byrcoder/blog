/**
 * @(#)AccountException.java, 2012-8-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.exceptions;

import org.apache.log4j.Level;
import org.springframework.http.HttpStatus;

/**
 *
 * @author wangfk, chen-chao
 *
 */
public class AccException extends Exception {
    private static final long serialVersionUID = -2323156653252880707L;
    protected static final AccExpType DEFAULT_EXCEPTION_TYPE =
            AccExpType.UNKNOWN_EXCEPTION;
    protected AccExpType exceptionType;
    protected String message;
    protected int thirdPartyErrorCode = 0;
    public AccException() {
        this("", AccExpType.UNKNOWN_EXCEPTION);
    }

    public AccException(String message, Throwable cause) {
        this(message, cause, AccExpType.UNKNOWN_EXCEPTION);
    }

    public AccException(String message) {
        this(message, AccExpType.UNKNOWN_EXCEPTION);
    }

    public AccException(Throwable cause) {
        this(null, cause, AccExpType.UNKNOWN_EXCEPTION);
    }

    public AccException(String message, Throwable cause,
            AccExpType exceptionType) {
        this(message, cause, exceptionType, 0);
    }
    
    public AccException(
            AccExpType exceptionType, Throwable cause, String format, Object...objects) {
        this(exceptionType, cause, 0, format, objects);
    }
    
    public AccException(
            AccExpType exceptionType,Throwable cause, int tpErrorCode, String format, Object...objects) {
        this(String.format(format, objects), cause, exceptionType, tpErrorCode);
    }
    
    public AccException(String message, Throwable cause,
            AccExpType exceptionType, int tpErrorCode) {
        super(composeMessage(exceptionType, message), cause);
        this.message = message;
        this.exceptionType = exceptionType;
        this.thirdPartyErrorCode = tpErrorCode;
    }
    
    public AccException(AccExpType exceptionType) {
        this("", exceptionType);
    }

    public AccException(String message, AccExpType exceptionType) {
        this(composeMessage(exceptionType, message), null, exceptionType);
    }
    
    public AccException(AccExpType exceptionType, String format, Object ...objects) {
        this(String.format(format, objects), exceptionType);
    }

    public AccException(Throwable cause, AccExpType exceptionType) {
        this(null, cause, exceptionType);
    }
    
    
    public AccExpType getExceptionType(){
        return exceptionType;
    }
    
    public enum AccExpType {
        OK {
            public int getErrorCode() {
                return 0;
            }

            public Level getLogLevel() {
                return Level.DEBUG;
            }
        },
        UNKNOWN_EXCEPTION {
            public int getErrorCode() {
                return 2000;
            }
        },
        RUNTIME_EXCEPTION {
            public int getErrorCode() {
                return 2002;
            }

            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        NOT_SUPPORT {
            public int getErrorCode() {
                return 2005;
            }
        },
        CACHE_ITEM_SIZE_EXCEED {
            public int getErrorCode() {
                return 2006;
            }
        },
        DISTRIBUTE_SERVICE_EXCEPTION {
            public int getErrorCode() {
                return 2007;
            }
        },
        CONFIG_ERROR {
            public int getErrorCode() {
                return 2008;
            }
            
            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        SERVER_RPC_EXCEPTION {
            public int getErrorCode() {
                return 2009;
            }
        },
        FAKE_THIRD_PARTY_SERVER_ERROR {
            public int getErrorCode() {
                return 2010;
            }

            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        HTTP_HTTPS_PROTOCAL_ERROR {
            public int getErrorCode() {
                return 2011;
            }

            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        RESPONSE_WRITE_BYTE_ERROR {
            public int getErrorCode() {
                return 2012;
            }

            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        PARAM_EXIST_ERROR {
            public int getErrorCode() {
                return 2013;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        PARAM_MISSING_ERROR {
            public int getErrorCode() {
                return 2014;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        NOT_IMPLEMENT_METHOD {
            public int getErrorCode() {
                return 2015;
            }
            public Level getLogLevel() {
                return Level.INFO;
            }
        },
        ENCODING_ERROR {
            public int getErrorCode() {
                return 2016;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        GET_REQUEST_ERROR {
            public int getErrorCode() {
                return 2017;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        POST_MULTIPART_ERROR {
            public int getErrorCode() {
                return 2018;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        URI_ERROR {
            public int getErrorCode() {
                return 2019;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        RESPONSE_TO_BYTES_ERROR {
            public int getErrorCode() {
                return 2020;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        NO_SUCH_CLASS {
            public int getErrorCode() {
                return 2021;
            }
            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        PCI_NOT_EXIST {
            public int getErrorCode() {
                return 2022;
            }
            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        POST_URL_FORM_ENCODE_ERROR {
            public int getErrorCode() {
                return 2023;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        FAKE_TOKEN {
            public int getErrorCode() {
                return 2024;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        PARAM_NOT_EQUAL_TAGET_ERROR {
            public int getErrorCode() {
                return 2025;
            }
            
            public Level getLogLevel() {
                return Level.ERROR;
            }
            
        },
        UNKNOWN_URI {
            public int getErrorCode() {
                return 2026;
            }
        },
        TP_ERROR {
            public int getErrorCode() {
                return 2027;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        VERIFIER_MISS_MATCH_TOKEN {
            public int getErrorCode() {
                return 2028;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        NO_SUCH_PRODUCT {
            public int getErrorCode() {
                return 2029;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        REDIRECT_URL_ERROR {
            public int getErrorCode() {
                return 2030;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        LOGIC_ERROR {
            public int getErrorCode() {
                return 2031;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        STORE_SERVICE_EXCEPTION {
            public int getErrorCode() {
                return 2032;
            }

            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        BYTES_NO_MATCH_OBJ_EXCEPTION {
            public int getErrorCode() {
                return 2033;
            }
        },
        QUERY_ATTRUBITE_MISSING {
            public int getErrorCode() {
                return 2034;
            }
        },
        NO_LOGIN {
            public int getErrorCode() {
                return 2035;
            }
        },
        NO_PERS_TOKEN {
            public int getErrorCode() {
                return 2036;
            }
        },
        COOKIE_HEADER_ERROR {
            public int getErrorCode() {
                return 2037;
            }
        },
        LOCK_EXPIRED_EXCEPTION{
            public int getErrorCode() {
                return 2038;
            }
        },
        ZOOKEEP_SERVER_INVALID{
            public int getErrorCode() {
                return 2039;
            }
            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        ZOOKEEP_SERVER_NETWORK_FAILED{
            public int getErrorCode() {
                return 2040;
            }
            public Level getLogLevel() {
                return Level.FATAL;
            }
        },
        ZOOKEEP_SERVER_EXCEPTION{
            public int getErrorCode() {
                return 2041;
            }
        },
        UPDATE_LOCAL_HASH_CIRCLE_FAILED{
            public int getErrorCode() {
                return 2042;
            }
        },
        URS_TOKEN_INIT_EXCPTION{
            public int getErrorCode() {
                return 2043;
            }
        },
        URS_TOKEN_SAFE_LOGIN_EXCPTION{
            public int getErrorCode() {
                return 2044;
            }
        },
        URS_TOKEN_VERIFIER_EXCPTION{
            public int getErrorCode() {
                return 2045;
            }
        },
        URS_TOKEN_REMOVE_EXCPTION{
            public int getErrorCode() {
                return 2046;
            }
        },
        URS_TOKEN_URL_EXCEPTION{
            public int getErrorCode() {
                return 2047;
            }
        },
        FAKE_PCI {
            public int getErrorCode() {
                return 2048;
            }
        }, XSS_FILTER_FAILED {
            public int getErrorCode() {
                return 2049;
            }
        }, NO_BIND_AUTHORIZE {
            public int getErrorCode() {
                return 2050;
            }
        }, NO_BIND_ERROR {
            public int getErrorCode() {
                return 2051;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        }, REMOVE_BIND_ERROR {
            public int getErrorCode() {
                return 2052;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        }, REMOVE_BIND_PART_ERROR {
            public int getErrorCode() {
                return 2053;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        }, ADD_BIND_ERROR {
            public int getErrorCode() {
                return 2054;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        }, ADD_BIND_PART_ERROR {
            public int getErrorCode() {
                return 2055;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        }, URS_CHECK_EXIST_ERROR {
            public int getErrorCode() {
                return 2056;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        }, URS_TOKEN_GET_SESS_EXCPTION{
            public int getErrorCode() {
                return 2057;
            }
        }, QJ_SERVER_ERROR {
            public int getErrorCode() {
                return 2058;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        IO_ERROR {
            public int getErrorCode() {
                return 2059;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        /**
         * Register exceptions
         */
        CAPTCHA_CODE_ERROR {
            public int getErrorCode() {
                return 2100;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        CAPTCHA_CODE_NOT_FOUND_ERROR {
            public int getErrorCode() {
                return 2101;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        CAPTCHA_CODE_EXPIRED_ERROR {
            public int getErrorCode() {
                return 2102;
            }
            public Level getLogLevel() {
                return Level.ERROR;
            }
        },COREMAIL_SID_ERROR {
            // 2100 => 2200
            public int getErrorCode() {
                return 2200;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        COREMAIL_API_ERROR {
            // 2101 => 2201
            public int getErrorCode() {
                return 2201;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        COREMAIL_USER_REUSE_ERROR {
            // 2102 => 2202
            public int getErrorCode() {
                return 2202;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        },
        COREMAIL_ILLEGAL_REQUEST_ERROR {
            // 2103 => 2203
            public int getErrorCode() {
                return 2203;
            }

            public Level getLogLevel() {
                return Level.ERROR;
            }
        };
        
        public int getErrorCode() {
            return 2000;
        }
        
        public Level getLogLevel() {
            return Level.WARN;
        }

        public String getName() {
            return name();
        }
        
        public HttpStatus getStateCode() {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }
    
    public String getSelfMessage() {
        return message;
    }
    
    public int getThirdPartyErrorCode() {
        return thirdPartyErrorCode;
    }
    
    protected static String composeMessage(AccExpType exceptionType, String message) {
        return "Message[" + exceptionType.getName() + "]: " + message;
    }
    
    public static void main(String[] args) {
        AccException e = new AccException(AccExpType.CONFIG_ERROR);
        System.out.println(e.getExceptionType().getStateCode());
        System.out.println(e.getExceptionType().getErrorCode());
    }
}
