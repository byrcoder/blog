/**
 * @(#)QOpenResult.java, 2012-3-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.qplus;

import net.sf.json.JSONObject;
import net.sf.json.util.JSONTokener;

/**
 * @author chen-chao
 */
public class QOpenResult {

    private static final String NAME_RETURN_CODE = "ret";

    private static final String NAME_INFO_FACE = "face";

    private static final String NAME_INFO_GENDER = "gender";

    private static final String NAME_INFO_OUTH = "outh";

    private static final String NAME_INFO_NICKNAME = "nick";

    private static final String NAME_INFO = "info";

    private JSONObject jsonResult;

    QOpenResult(String json) {
        jsonResult = JSONObject.fromObject(new JSONTokener(json));
    }

    public String toString() {
        return QOpenResult.class.getSimpleName() + "[" + jsonResult.toString()
                + "]";
    }

    public QOpenInfo getQPlusInfo() {
        if (!isSuccess())
            return null;
        QOpenInfo info = new QOpenInfo();
        JSONObject information = getInfo();

        info.setFace((String) information.get(NAME_INFO_FACE));
        info.setGender((String) information.get(NAME_INFO_GENDER));
        info.setOuth((String) information.get(NAME_INFO_OUTH));
        info.setNick((String) information.get(NAME_INFO_NICKNAME));
        return info;
    }

    public int getResultCode() {
        return (Integer) getValue(NAME_RETURN_CODE);
    }

    private JSONObject getInfo() {
        return (JSONObject) getValue(NAME_INFO);
    }

    public Object getValue(String key) {
        return jsonResult.get(key);
    }

    public Object getValue(String key, Object defaultValue) {
        Object v = jsonResult.get(key);
        return v == null ? defaultValue : v;
    }

    public boolean isSuccess() {
        return getResultCode() == 0;
    }
}
