/**
 * @(#)RequestPCIHandler.java, 2012-9-3. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.rpc2.RpcException;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.data.CipherKeyPair;
import outfox.account.data.CookieIndex;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;

/**
 * @author chen-chao
 */
@Controller
public class RequestPCIHandler extends BaseHandler {

    private static final long serialVersionUID = 6102791589518239258L;
    private GlobalCache glcache = GlobalCache.getInstance();
    /**
     * /login/acc/rp?app=&product=&tp=&format=&al=&js=
     * 
     * @throws AccException
     * @throws RpcException
     */
    @RequestMapping(AccConst.REQUEST_PCI_URL)
    public void requestPCI(HttpServletRequest req, HttpServletResponse resp) throws 
            AccException {
        // 0. setName in analyzer and vaquero.
        setName(req, "request-pci");
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkParam(req, AccConst.PARAM_APP_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_PRODUCT_NAME, NO_MISS);
        checkParam(req, AccConst.PARAM_THIRD_PARTY_NAME, NO_MISS);
        // 1. generate a token
        String msg = ReqUtils.getQueryString(req);
        String pci = AuthUtils.genUniqueToken(msg);
        String pc = null;
        String algorithm = req.getParameter(AccConst.PARAM_ALOGRITHM);
        // 2. put token into global cache.
        
        
        if (StringUtils.isBlank(algorithm)) {
            pc = AuthUtils.genUniqueToken(msg);
            CookieIndex index = new CookieIndex(pci, pc, msg);
            glcache.put(pci, CookieIndex.encode2(index));    
        } else {
            
            CookieIndex index = RequestPCIHandler.genCipher(pci, msg, algorithm);
            
            glcache.put(pci, CookieIndex.encode3(index));
            pc = index.pc;
        }
        
        // 3. return token back using format
        
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        params.add(new Parameter(AccConst.PARAM_PC_NAME, pc));
        write(req, resp, params, HttpStatus.OK);
    }
    public static final int RADIX16 = 16;
    public static CookieIndex genCipher(String pci, String msg, String algorithm) throws AccException {
        
        CIPHER_ALGORITHM_TYPE cipher = CIPHER_ALGORITHM_TYPE.NONE.defaultValueOf(algorithm);
        String cipherType = cipher.getAlias();
        CipherKeyPair cipherkeyPair = AuthUtils.genCipherKeysByAlogrithm(cipher);
        switch (cipher) {
            case RSA_ECB_PKCS1_SPLIT_EXP_MODULUS: // no break
            case RSA_ECB_NOPADING_SPLIT_EXP_MODULUS:
                RSAPublicKey rsaPubKey = (RSAPublicKey) cipherkeyPair.getKeyPair().getPublic();
                String publicKey = rsaPubKey.getModulus().toString(RADIX16) + "|"
                        + rsaPubKey.getPublicExponent().toString(RADIX16);
                return new CookieIndex(pci, publicKey, msg, cipherkeyPair.getDecryptKey(), cipherType);
            default:
                return new CookieIndex(pci, cipherkeyPair.getEncryptKey(), msg, cipherkeyPair.getDecryptKey(), cipherType);
        }
    }
}
