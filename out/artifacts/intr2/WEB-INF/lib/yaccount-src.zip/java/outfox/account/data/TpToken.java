/**
 * @(#)TpToken.java, 2012-9-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import odis.serialize.lib.StringWritable;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TpToken extends AbstractWritable{
    private static final long serialVersionUID = -531281334121077892L;
    public String app;
    public String product;
    public String verifierName;
    private long createTime;  // millisecond
    private long expiredTime; // millisecond
    public String signature;
    public String token; // access token or other token
    public String refresh; // refresh token or other refresh information
    public String authid; // a kind of access key
    public String secret; // access secret or other secret (like password)
    public String ip;
    public String srcToken; // not write into database
    public String parseToken; // not write into database
    public String userId;     // own id(not third-party openId)
    public String sessIndex;  // session cookie index (session cookie value in omap stored session cookie)
    public static final String ALIVE_TIME = "aliveTime";
    public TpToken(){
        this(null);
    }
    
    public TpToken(String token){
        this(token, null);
    }
    
    public TpToken(String token, List<Parameter> params){
        super(params);
        srcToken = token;
        parseToken = token;
        createTime = System.currentTimeMillis();
    }

    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        app = StringWritable.readStringNull(in);
        product = StringWritable.readStringNull(in);
        verifierName = StringWritable.readStringNull(in);
        createTime = in.readLong();
        expiredTime = in.readLong();
        signature = StringWritable.readStringNull(in);
        token = StringWritable.readStringNull(in);
        secret = StringWritable.readStringNull(in);
        refresh = StringWritable.readStringNull(in);
        authid = StringWritable.readStringNull(in);
        ip = StringWritable.readStringNull(in);
        userId = StringWritable.readStringNull(in);
        sessIndex = StringWritable.readStringNull(in);
    }

    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, app);
        StringWritable.writeStringNull(out, product);
        StringWritable.writeStringNull(out, verifierName);
        out.writeLong(createTime);
        out.writeLong(expiredTime);
        StringWritable.writeStringNull(out, signature);
        StringWritable.writeStringNull(out, token);
        StringWritable.writeStringNull(out, secret);
        StringWritable.writeStringNull(out, refresh);
        StringWritable.writeStringNull(out, authid);
        StringWritable.writeStringNull(out, ip);
        StringWritable.writeStringNull(out, userId);
        StringWritable.writeStringNull(out, sessIndex);
    }
    
    public void setCreateTime(Long createTime) {
        if (createTime == null || createTime < 0) {
            this.createTime = 0;
        } else {
            this.createTime = createTime;
        }
    }
    public long getCreateTime() {
        return createTime;
    }

    public long getExpiredTime() {
        return expiredTime;
    }
    public void setExpiredTime(Long expiredTime) {
        if (expiredTime == null) {
            this.expiredTime = -1;
        } else if (expiredTime < 0 && expiredTime != -1) {
            this.expiredTime = 0;
        } else {
            this.expiredTime = expiredTime;
        }
    }
    
    public boolean isExpired() {
        return AuthUtils.isExpired(createTime, expiredTime);
    }
    
    /**
     * Then use parameter expiredTime to compute whether it is expired.
     * @param expiredTime
     * @return
     */
    public boolean isExpired(long expiredTime) {
        return AuthUtils.isExpired(createTime, expiredTime);
    }

    @Override
    public boolean equals(Object obj) {
        
        if (obj ==null || !(obj instanceof TpToken)) {
            return false;
        }
        
        TpToken that = (TpToken)obj;
        return nullOrEqual(app, that.app) && nullOrEqual(product, that.product)
        && nullOrEqual(verifierName, that.verifierName)
        && nullOrEqual(authid, that.authid)
        && nullOrEqual(token, that.token)
        && nullOrEqual(refresh, that.refresh)
        && nullOrEqual(secret, that.secret)
        && nullOrEqual(ip, that.ip)
        && nullOrEqual(signature, that.signature)
        && nullOrEqual(sessIndex, that.sessIndex)
        && nullOrEqual(userId, that.userId)
        && createTime == that.createTime
        && expiredTime == that.expiredTime
        && stringPropertiesEquals(that)
        && bytePropertiesEquals(that);
    }
    
    private boolean bytePropertiesEquals(TpToken that) {
        return getBytePropertiesCopy().equals(that.getBytePropertiesCopy());
    }
    
    private boolean stringPropertiesEquals(TpToken that){
        Map<String, String> map = this.getPropertiesMapCopy();
        Map<String, String> thatMap = that.getPropertiesMapCopy();
        
        return map.equals(thatMap);
    }

    
    protected boolean nullOrEqual(String a, String b) {
        if (a == null && b == null) {
            return true;
        } else if (a != null) {
            return a.equals(b);
        } else {
            return b.equals(a);
        }
    }
    public void setSessAliveTime(Long aliveTime) {
        setLongProperty(ALIVE_TIME, aliveTime);
    }
    
    public long getSessAliveTime() {
        return getLongProperty(ALIVE_TIME);
    }

    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return (verifierName + product + signature).hashCode();
    }
}
