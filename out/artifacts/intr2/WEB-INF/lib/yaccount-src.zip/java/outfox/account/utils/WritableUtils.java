/**
 * @(#)OauthWritableUtils.java, 2011-11-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import odis.serialize.IWritable;

/**
 * utils for some classes
 * 
 * @author chen-chao
 */
public class WritableUtils {
    /**
     * This method will make {@link odis.serialize.IMutable#copyFields} function
     * simplely.
     * 
     * @param <T>
     *        extends {@link odis.serialize.IWritable}
     * @param src
     *        original object
     * @param dest
     *        target object
     * @return
     */
    public static <T extends IWritable> T copyTo(T src, T dest) {
        try {
            ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
            DataOutput output = new DataOutputStream(byteArrayOut);

            src.writeFields(output);

            DataInput input = new DataInputStream(new ByteArrayInputStream(
                    byteArrayOut.toByteArray()));
            dest.readFields(input);
            return dest;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Instantiation", e);
        }
    }

    /**
     * find all fields of clazz include fields of parent class
     * 
     * @param clazz
     * @return a list of fields
     */
    public static List<Field> findAllField(Class<?> clazz) {
        return findAllField(clazz, null);
    }

    /**
     * find all fields of clazz include fields of parent classes, until parent
     * class is equals endClazz. fields contains fields of endClazz.
     * <p>
     * if
     * 
     * @param clazz
     * @param endClazz
     * @return
     */
    public static List<Field> findAllField(Class<?> clazz, Class<?> endClazz) {
        if (clazz == null) {
            return null;
        }
        if (endClazz == null) {
            endClazz = Object.class;
        }
        List<Field> list = null;
        if (!clazz.equals(endClazz)) {
            List<Field> suplist = findAllField(clazz.getSuperclass(), endClazz);

            if (suplist != null) {
                list = new ArrayList<Field>(suplist);
            }
        }
        if (list == null) {
            list = new ArrayList<Field>();
        }
        for (Field f: clazz.getDeclaredFields()) {
            if (!f.getName().equalsIgnoreCase("this$0")
                    && !f.getName().equalsIgnoreCase("LOG")) {
                list.add(f);
            }
        }
        return list;
    }

    /**
     * convert a object to string
     * 
     * @param t
     * @return
     * @throws IllegalArgumentException
     * @throws IllegalAccessException
     */
    @SuppressWarnings("unchecked")
    public static <T extends IWritable, E, F, G> String toString(T t)
            throws IllegalArgumentException, IllegalAccessException {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (Field f: findAllField(t.getClass())) {
            f.setAccessible(true);
            
            sb.append(f.getName()).append("=");
            Object value = f.get(t);
            if (value == null) {
                sb.append("null");
            } else if (Map.class.isAssignableFrom(f.getType())) {
                Map<E, F> newMap = new HashMap<E, F>();
                for (Map.Entry<E, F> entry : ((Map<E, F>) value).entrySet()){
                    
                    newMap.put(entry.getKey(), entry.getValue());
                }
                
                sb.append(newMap.toString());
            } else if (List.class.isAssignableFrom(f.getType())) {
                sb.append(((List<G>) value).toString());
            } else {
                sb.append(value);
            }
            sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }
    
    /**
     * convert a object to string
     * 
     * @param t
     * @return
     * @throws IllegalArgumentException
     * @throws IllegalAccessException
     */
    @SuppressWarnings("unchecked")
    public static <T extends IWritable, E, F, G> JSONObject toJSONObject(T t)
            throws IllegalArgumentException, IllegalAccessException {
        JSONObject obj = new JSONObject();
        for (Field f: findAllField(t.getClass())) {
            f.setAccessible(true);
            
            Object value = f.get(t);
            if (value == null) {
                continue;
            } else if (Map.class.isAssignableFrom(f.getType())) {
                JSONObject mapJson = new JSONObject();
                for (Map.Entry<E, F> entry : ((Map<E, F>) value).entrySet()){
                    mapJson.put(entry.getKey(), entry.getValue());
                }
                
                obj.put(f.getName(), mapJson);
            } else if (List.class.isAssignableFrom(f.getType())) {
                JSONArray array = new JSONArray();
                for (G element : (List<G>) value) {
                    array.add(element);
                }
                obj.put(f.getName(), array);
            } else {
                obj.put(f.getName(), value);
            }
        }
        return obj;
    }
}
