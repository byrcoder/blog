package outfox.account.db.kv.cassandra;

import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.db.kv.imp.KVPersTokenDB;
import outfox.account.exceptions.AccException;

/**
 * @author yangzhe
 * @version created on 14-9-4.
 */
public class PerTokenDual implements IPersTokenDB {
    //private static final Log LOG = LogFactory.getLog(PerTokenDual.class);

    private PerTokenTable cassandra = new PerTokenTable();
    private KVPersTokenDB omap = new KVPersTokenDB();

    @Override
    public void write(PersistTokenWritable tw) throws AccException {
        cassandra.write(tw);
        try {
            omap.write(tw);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void write(TpToken tpToken) throws AccException {
        cassandra.write(tpToken);
        try {
            omap.write(tpToken);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * if persist token is expired, will remove session cookies.
     */
    public PersistTokenWritable read(TpToken tpToken) throws AccException {
        PersistTokenWritable res = cassandra.read(tpToken);
        if (res != null) {
            return res;
        }
        try {
            res = omap.read(tpToken);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (res != null) {
            cassandra.write(res);
        }
        return res;
    }

    public PersistTokenWritable read(String userId, String app, String product, String verifierName,
                                     String signature) throws AccException {
        PersistTokenWritable res = cassandra.read(userId, app, product, verifierName, signature);
        if (res != null) {
            return res;
        }
        try {
            res = omap.read(userId, app, product, verifierName, signature);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (res != null) {
            cassandra.write(res);
        }
        return res;
    }

    public void remove(TpToken tpToken) throws AccException {
        cassandra.remove(tpToken);
        try {
            omap.remove(tpToken);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void remove(String userId, String app, String product, String verifierName, String signature)
            throws AccException {
        cassandra.remove(userId, app, product, verifierName, signature);
        try {
            omap.remove(userId, app, product, verifierName, signature);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public IPersTokenIter getIter(String userId) throws AccException {
        return omap.getIter(userId);
    }

    @Override
    public IPersTokenIter getIter(Object... startKeys) throws AccException {
        return omap.getIter(startKeys);
    }
}
