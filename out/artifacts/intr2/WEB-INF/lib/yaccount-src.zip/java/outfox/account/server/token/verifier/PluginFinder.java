/**
 * @(#)PluginFinder.java, 2012-9-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.reflect.Modifier;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class PluginFinder {
    
    public static Set<Class<? extends Verifier>> getPluginsInSameDir(String className) {
        Class<?> z = null;
        try {
            z = Class.forName(className);
        } catch (ClassNotFoundException e) {
            throw new AccRunTimeException(new AccException("no class found:" + className, AccExpType.NO_SUCH_CLASS));
        }
        return getPluginsInSameDir(z);
    }
    
    /**
     * find plugin only in the class file path. Not package path.
     * @param clazz
     * @return
     */
    public static Set<Class<? extends Verifier>> getPluginsInSameDir(Class<?> clazz) {
        ProtectionDomain pd = clazz.getProtectionDomain();
        CodeSource cs = pd.getCodeSource();
        String location = cs.getLocation().getFile();
        
        if (location.endsWith(".jar!/")) {
            // maybe "/xxx.jar!/ format"
            location = location.substring(0, location.length() - 2);
        }
        if (location.startsWith("file://")) {
            // maybe "file://xxxx.jar"
            location = location.substring("file://".length());
        }
        if (location.startsWith("file:")) {
            // maybe "file:/xxxx.jar"
            location = location.substring("file:".length());
        }
        System.out.println("location:"+location);
        if (location.endsWith(".jar") || location.endsWith(".zip")) {
            return searchVerifierInJar(clazz, location);
        } else {
            return searchVerifierInFileDir(clazz, cs);
        }
    }

    private static Set<Class<? extends Verifier>> searchVerifierInJar(Class<?> clazz, String fileLocation) {
        // load in jar or zip
        ZipFile zip = null;
        String file = fileLocation;
        try {
           
            zip = new ZipFile(file);
        } catch (IOException e) {
            throw new AccRunTimeException(new AccException("can not unzip the file. file:" + file,
                    AccExpType.UNKNOWN_URI));
        }
        Enumeration<?> entries = zip.entries();
        Set<Class<? extends Verifier>> set = new HashSet<Class<? extends Verifier>>();
        while (entries.hasMoreElements()) {
            ZipEntry entry = (ZipEntry) entries.nextElement();
            String thisClassName = entry.getName().replace('/', '.');
            if (thisClassName.startsWith(clazz.getPackage().getName()) && thisClassName.endsWith(".class")
                    && thisClassName.indexOf("$") == -1) {
                String className = AuthUtils.removeSuffix(thisClassName);
                Class<? extends Verifier> plugIn = getVerifierPluginImplement(className);
                if (plugIn != null) {
                    set.add(plugIn);
                }
            }
        }
        return set;
    }

    private static Set<Class<? extends Verifier>> searchVerifierInFileDir(Class<?> clazz,
            CodeSource cs) {
        String dirPath = clazz.getPackage().getName().replace(".", "/");
        URL path = null;
        try {
            path = new URL(cs.getLocation(), dirPath);
        } catch (MalformedURLException e1) {
            throw new AccRunTimeException(new AccException("url error? parent:" + cs.getLocation()
                    + " subpath:" + dirPath, AccExpType.UNKNOWN_URI));
        }
        System.out.println("class name:" + clazz.getName() + " " +path.toExternalForm());
        File file = new File(path.getFile());
        File[] files = file.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                // it is a class file and not an inner class. 
                return (name.endsWith(".class") && name.indexOf("$") == -1) ? true : false;
            }
        });
        Set<Class<? extends Verifier>> set = new HashSet<Class<? extends Verifier>>();
        searchVeriferInFiles(clazz, files, set);
        return set;
    }
    

    private static Set<Class<? extends Verifier>> searchVeriferInFiles(Class<?> clazz, File[] files, Set<Class<? extends Verifier>> set) {
        String className = null;
        if (files != null) {
            for (File f: files) {
                String classAbsName = AuthUtils.removeSuffix(f.getName());
                className = (clazz.getPackage().getName() + "." + classAbsName);
                Class<? extends Verifier> pluginImplement = getVerifierPluginImplement(className);
                if (pluginImplement != null) {
                    set.add(pluginImplement);
                }
            }
        }
        return set;
    }
    
    
    /**
     * if a class is interface or is abstracted, it can not be instanced.
     * @param clazz
     * @return
     */
    public static boolean canInstance(Class<?> clazz) {
        
        if (clazz.isInterface() || Modifier.isAbstract(clazz.getModifiers())) {
            return false;
        }
        return true;
    }
    
    @SuppressWarnings("unchecked")
    public static Class<? extends Verifier> getVerifierPluginImplement(String className) {
        Class<?> aClass;
        try {
            aClass = Class.forName(className);
        } catch (ClassNotFoundException e) {
            throw new AccRunTimeException(new AccException("no class found:" + className, AccExpType.NO_SUCH_CLASS));
        }
        if (Verifier.class.isAssignableFrom(aClass) && canInstance(aClass)){
            return (Class<? extends Verifier>) aClass;
        }
        return null;
    }
}
