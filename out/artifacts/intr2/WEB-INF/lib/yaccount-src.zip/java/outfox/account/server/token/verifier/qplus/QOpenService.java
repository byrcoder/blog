/**
 * @(#)QOpenService.java, 2012-3-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.qplus;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 * 
 * @author chen-chao
 */
public class QOpenService extends QPlusService {

    public static final String VERSION = "1.0.1";

    public static final String NAME_APP_USERIP = "app_userip";

    public static final String NAME_APP_LANG = "app_lang";

    public static final String NAME_SIGNATURE = "sig";

    public static final String FUN_APP_LOGIN = "app_qqlogin";

    public static final String NAME_APP_OPENID = "app_openid";

    public static final String NAME_APP_OPENKEY = "app_openkey";

    public static final String NAME_APP_ID = "app_id";

    public static final String NAME_APP_TS = "app_ts";

    public static final String NAME_APP_NONCE = "app_nonce";

    private static final String FLAG_SIGN = NAME_SIGNATURE + "=";

    private static final String FLAG_OPENID = NAME_APP_OPENID + "=";

    private static final String FLAG_OPENKEY = NAME_APP_OPENKEY + "=";

    private static final String FLAG_LANG = NAME_APP_LANG + "=";

    private static final String FLAG_USERIP = NAME_APP_USERIP + "=";

    private static final String FLAG_APP_ID = NAME_APP_ID + "=";

    private static final String FLAG_APP_TS = NAME_APP_TS + "=";

    private static final String FLAG_APP_NONCE = NAME_APP_NONCE + "=";

    private static final String FUN_APP_VERIFY = "app_verify";

    private static final String FUN_APP_LOG_OUT = "app_logout";

    private static final String FUN_APP_GET_USER_INFO = "app_get_userinfo";

    private int applang = 2052;

    private String baseUrl = null;

    public static final QOpenService createInstance(String appKey, String secret, String lang, String baseUrl) {
        return new QOpenService(Integer.parseInt(appKey),
                secret, Integer.parseInt(lang), baseUrl);
    }

    public String getLoginParams(String userIp) {
        String param1 = FLAG_USERIP + userIp;
        String param2 = FLAG_LANG + this.applang;
        return createQPlusParams(FUN_APP_LOGIN, null, param1, param2);
    }

    public String getLoginParams(final QOpenBean bean) {
        String param1 = FLAG_USERIP + bean.getUseripaddr();
        String param2 = FLAG_LANG + this.applang;
        return createQPlusParams(FUN_APP_LOGIN, null, param1, param2);
    }

    private QOpenService(int appid, String appkey, int applang, String url) {
        super(appid, appkey + "&");
        this.applang = applang;
        this.baseUrl = url;
    }

    public boolean checkSig(String url) throws IOException {
        if (url == null || url.indexOf('?') < 0 || url.indexOf(FLAG_SIGN) < 0)
            return false;
        url = url.substring(url.indexOf('?') + 1);
        String sig = url.substring(url.indexOf(FLAG_SIGN) + FLAG_SIGN.length());
        if (sig.indexOf('&') > 0)
            sig = sig.substring(0, sig.indexOf('&'));
        return sig.equalsIgnoreCase(createSigValue(url.replaceFirst(
                "(^sig=[^&]+&)|(&sig=[^&]+)", "")));
    }

    public QOpenResult checkLogin(final QOpenBean bean) throws IOException {
        return send(FUN_APP_VERIFY, bean);
    }

    public QOpenResult logOut(final QOpenBean bean) throws IOException {
        return send(FUN_APP_LOG_OUT, bean);
    }

    public QOpenResult getUserInfo(final QOpenBean bean) throws IOException { //
        return send(FUN_APP_GET_USER_INFO, bean);
    }

    private String createQPlusParams(final String action, final QOpenBean bean,
            final String... params) {
        List<String> list = new ArrayList<String>(8 + params.length);
        if (bean != null) {
            list.add(FLAG_OPENID + bean.getAppopenid());
            list.add(FLAG_OPENKEY + bean.getAppopenkey());
            list.add(FLAG_USERIP + bean.getUseripaddr());
        }
        list.add(FLAG_APP_ID + this.appid);
        list.add(FLAG_APP_TS + intNow());
        list.add(FLAG_APP_NONCE + random());
        for (String param: params) {
            list.add(param);
        }
        String str = createHttpParam(list);
        return str + "&sig=" + createSigValue(action + "&" + str);
    }

    private QOpenResult send(final String action, final QOpenBean bean,
            final String... params) throws IOException {
        final String url = this.baseUrl + action;
        final String paramstr = createQPlusParams(action, bean, params);
        String content = send(url, paramstr);
        return new QOpenResult(content);
    }
}
