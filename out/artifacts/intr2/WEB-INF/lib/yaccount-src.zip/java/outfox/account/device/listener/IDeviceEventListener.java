/**
 * @(#)AbstractDeviceStatusHandler.java, 2013-6-4. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device.listener;

import java.util.EventListener;

import outfox.account.device.DeviceEvent;


/**
 * Listener to handle device status change event.
 * @author chen-chao
 */
public interface IDeviceEventListener extends EventListener{
    public void handleEvent(DeviceEvent event);
}
