/**
 * @(#)SecurityUtils.java, 2012-12-4. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;

import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;


/**
 * @author chen-chao
 */
public class SecurityUtils {
    private enum SECURITY_PARAM {
        PASSWORD("password"),YNOTE_PERS("ynote_pers"),ACCESS_TOKEN("access_token"),TOKEN("token"),YNOTE_PC("YNOTE-PC");
        private String value;
        private SECURITY_PARAM(String value) {
            this.value = value;
        }
        public static SECURITY_PARAM defaultValueOf(String key) {
            for (SECURITY_PARAM param : values()) {
                if (param.value.toLowerCase().equals(key)) {
                    return param;
                }
            }
            return null;
        }
    }
    
    private static final String SECURITY_STRING = "%s***";
    
    private static final int SECRIT_LENGTH = 10;
    private static final String NULL_STRING = "(null)";
    public static String escapeSecurityQuery(HttpServletRequest req) {
        StringBuffer url = req.getRequestURL();
        String query = escapeSecurityQuery(ReqUtils.getQueryString(req));
        if (!StringUtils.isBlank(query)) {
            url.append("?").append(query);
        } 
        return url.toString();
    }
    
    public static boolean isSecretKey(String key) {
        try {
            return SECURITY_PARAM.defaultValueOf(key.toLowerCase()) != null;
        } catch (Throwable t) {

        }
        return false;
    }
    public static String secretString(String str) {
        return secretString(str, SECRIT_LENGTH);
    }
    
    /**
     * infolen should more than 2
     * @param str
     * @param infolen
     * @return
     * @throws AccException 
     */
    public static String secretString(String str, int infolen) {
        if (str == null) {
            return NULL_STRING;
        }
        if (infolen > str.length()) {
            infolen = str.length();
        } else if (infolen <= 0 ) {
            infolen = 0;
        } 
        
        return String.format(SECURITY_STRING, str.substring(0, str.length() - infolen));
    }
    
    public static final JSONObject EMPTY_JSON_OBJ = new JSONObject();
    public static JSONObject escapeSecurity(List<Parameter> params) throws AccException {
        if (params == null || params.size() == 0) {
            return EMPTY_JSON_OBJ;
        }
        JSONObject obj = new JSONObject();
        for (Parameter p : params) {
            if (isSecretKey(p.key)) {
                obj.put(p.key, secretString(p.getStrVal()));
            } else {
                obj.put(p.key, p.val);
            }
        }
        return obj;
    }

    public static JSONObject escapeSecurity(JSONObject obj) throws AccException {
        if (obj == null) {
            return EMPTY_JSON_OBJ;
        }
        JSONObject ret = new JSONObject();
        for (Object key : obj.keySet()) {
            final String keyStr = key.toString();
            if (isSecretKey(keyStr)) {
                Object value = obj.get(key);
                ret.put(keyStr, secretString(value.toString()));
            } else {
                ret.put(keyStr, obj.get(key));
            }
        }
        return ret;
    }
    
    public static Map<String,String[]> escapeSecurityQuery(Map<String,String[]> queryParameterMap)  {
        if (queryParameterMap != null) {
            for (SECURITY_PARAM securityParam : SECURITY_PARAM.values()) {
                if (queryParameterMap.containsKey(securityParam.name().toLowerCase())) {
                    String[] values = queryParameterMap.get(securityParam.name());
                    if (values != null) {
                        for (int i = 0; i < values.length; i++) {
                            if (StringUtils.isNotBlank(values[i])) {
                                values[i] = secretString(values[i]);
                            }
                        }
                    }
                }
            }
        }
        
        return queryParameterMap;
    }
    
    public static String escapeSecurityQuery(String queryString)  {
        if (queryString == null) {
            return queryString;
        }
        String[] queryParams = queryString.split("&");
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (String param: queryParams) {
            String[] keyValue = param.split("=");
            if (keyValue.length == 2) {
                if (isSecretKey(keyValue[0])) {
                    param = keyValue[0]+"="+secretString(keyValue[1]);
                } 
            }
            if ((first ? sb.append(param) : sb.append("&").append(param)) != null) {
                first = false;
            }
        }
        return sb.toString();
    }
}
