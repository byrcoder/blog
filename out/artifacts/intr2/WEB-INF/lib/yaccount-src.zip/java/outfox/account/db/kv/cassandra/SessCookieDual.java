/**
 * @(#)OmapSessCookieDB.java, 2012-9-19. 
 *
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.cassandra;

import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.db.kv.imp.KVSessCookieDB;
import outfox.account.exceptions.AccException;

/**
 * @author yangzhe
 */
public class SessCookieDual implements ISessCookieDB {

    //private static final Log LOG = LogFactory.getLog(SessCookieDual.class);

    private SessCookieTable cassandra = new SessCookieTable();
    private KVSessCookieDB omap = new KVSessCookieDB();

    @Override
    public SessionCookieWritable write(TpToken tp) throws AccException {
        SessionCookieWritable res1 = cassandra.write(tp);
        SessionCookieWritable res2=null;
        try {
            res2 = omap.write(tp);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return res1 != null ? res1 : res2;
    }

    public SessionCookieWritable read(TpToken tpToken) throws AccException {
        SessionCookieWritable res = cassandra.read(tpToken);
        if (res != null) {
            return res;
        }
        res = omap.read(tpToken);
        if (res != null) {
            cassandra.write(tpToken);
            return res;
        }
        return null;
    }

    public SessionCookieWritable read(String sessIndex) throws AccException {
        SessionCookieWritable res = cassandra.read(sessIndex);
        if (res != null) {
            return res;
        }
        res = omap.read(sessIndex);
        if (res != null) {
            cassandra.write(res.getTpToken());
            return res;
        }
        return null;
    }

    public void remove(TpToken tp) throws AccException {
        cassandra.remove(tp);
        omap.remove(tp);
    }

    public void remove(String sessIndex) throws AccException {
        cassandra.remove(sessIndex);
        omap.remove(sessIndex);
    }

    @Override
    public ISessCookieIter getIter(String sessIndex) throws AccException {
        return omap.getIter(sessIndex);
    }

    @Override
    public ISessCookieIter getIter(Object... startKeys) throws AccException {
        return omap.getIter(startKeys);
    }
}
