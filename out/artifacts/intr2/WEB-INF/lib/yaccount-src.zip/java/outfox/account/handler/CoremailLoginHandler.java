/**
 * @(#)CoremailLoginHandle.java, 2012-10-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.coremail.CoremailDataWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.server.token.verifier.impl.CoremailVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;
/**
 * @author wangxin
 */

@Controller
public class CoremailLoginHandler extends BaseHandler {
    
    private static final long serialVersionUID = 5649742633941366244L;
    private static final Log LOG = LogFactory.getLog(CoremailLoginHandler.class);
    
    public void init() {
    }

    /**
     * register urs
     * @param request
     * @param response
     * @throws IOException
     * @throws HttpException
     * @throws AccException 
     * @throws YDriveException 
     */
    @RequestMapping(AccConst.COREMAIL_LOGIN_REGISTER)
    protected void registerURS(HttpServletRequest req, HttpServletResponse resp) throws HttpException,
            IOException, AccException {
        setName(req, "coremail-reg");
        AuthUtils.checkHttpsProtocal(req);
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        checkParam(req, AccConst.PARAM_COREMAIL_SID, NO_MISS);
        checkParam(req, AccConst.PARAM_COREMAIL_DOMAIN, NO_MISS);
        checkParam(req, AccConst.PARAM_COREMAIL_PASSWORD, NO_MISS);
        final String domain = req.getParameter(AccConst.PARAM_COREMAIL_DOMAIN);
        CoremailDataWritable url = CoremailVerifier.getWsdlUrl(domain);
        if (url == null || url.getWsdlURL() == null) {
            throw new AccException(AccExpType.COREMAIL_API_ERROR,
                    "don't have this domain %s. wsdlUrl is NULL.", domain);
        }

        String userId = CoremailVerifier.getUserMailAddress(req.getParameter(AccConst.PARAM_COREMAIL_SID),
                url.getWsdlURL());

        String ursProduct = AuthUtils.getReqParamVal(req, AccConst.PARAM_URS_PRODUCT_NAME,
                AccConst.PARAM_URS_PRODUCT_DEFAULT_VALUE);
        JSONObject json = new JSONObject();
        String product = req.getParameter(AccConst.PARAM_PRODUCT_NAME);
        if (StringUtils.isBlank(product)) {
            product = AccConst.PARAM_PRODUCT_DEFALUT_VALUE;
        }
        String result = AuthUtils.registerURS(userId, req.getParameter(AccConst.PARAM_COREMAIL_PASSWORD)
                .toString(), ursProduct, AuthUtils.getRequestIP(req));
        json.put("URSReturnValue", result);
        LOG.info(String.format("register user %s done.", userId));
        writeJSON(req, resp, json, HttpStatus.OK);
    }

    /**
     * if had register and session id legal ,response  ynote session cookie
     * only for ynote.
     * @param request
     * @param response
     * @throws IOException
     * @throws HttpException
     * @throws YDriveException
     */
    @RequestMapping(AccConst.COREMAIL_LOGIN_AUTH)
    protected void getAuthCookie(HttpServletRequest req, HttpServletResponse resp) throws HttpException,
            IOException, AccException {
        setName(req, "coremail-auth");
        AuthUtils.checkHttpsProtocal(req);
        setErrorAttribute(req, HttpStatus.INTERNAL_SERVER_ERROR);
        String product = req.getParameter(AccConst.PARAM_PRODUCT_NAME);
        if (StringUtils.isBlank(product)) {
            product = AccConst.PARAM_PRODUCT_DEFALUT_VALUE;
        }
        String app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME, AccConfig.CLIENT_TYPE_WEB);
        req.setAttribute(AccConst.ATTR_PRODUCT_NAME, product);
        req.setAttribute(AccConst.ATTR_APP_NAME, app);
        req.setAttribute(AccConst.ATTR_THIRD_PARTY_NAME, CoremailVerifier.NAME);
        req.setAttribute(AccConst.ATTR_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value());
        req.setAttribute(AccConst.ATTR_FORCE_REDIRECT, "true");
        req.setAttribute(AccConst.ATTR_REDICT_SCHEME, "https");
        IVerifier verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product,
                CoremailVerifier.NAME);
        Map<String, Object> authResult = verifier.authRequest(req, resp);
        if (authResult != null) {
            // force clean URS cookie, in order to force login coremail (if URS login first)
            UrsUtils.cleanURSCookies(resp);
        }
        LoginHandler.returnResult(req, resp, product, CoremailVerifier.NAME, authResult);
    }
}
