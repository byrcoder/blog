/**
 * @(#)LocalCache.java, 2011-12-19. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache;

import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import toolbox.collections.CacheMap;

/**
 * get() will not change map structure if map will be full, remove the first
 * insert key-value or key-value which is accessed last by access order. If access order
 * is true, remove key-value which is accessed last.
 * 
 * thread-safe
 * @author chen-chao
 * @param <T>
 */
public class LocalWriteCache<K,V> {
    protected ReentrantLock lock;
    protected Map<K, V> cache;

    protected boolean realCache;
    public LocalWriteCache(boolean realCache, int init, float load, int limit) {
        this.realCache = realCache;
        if (realCache) {
            cache = new CacheMap<K, V>(init, load, false, limit);
            lock = new ReentrantLock();
        } else {
            cache = null;
            lock = null;
        }
    }

    public LocalWriteCache(boolean realCache, int limit) {
        this(realCache, (int) (limit / 0.5), 0.75f, limit);
    }
    
    /**
     * <b>NO</b> synchronized. Because get() will not change map structure.
     * 
     * @param key
     * @return
     */
    public V get(K key) {
        if (realCache) {
            return cache.get(key);
        }
        return null;
    }

    public V remove(K key) {
        if (realCache) {
            lock.lock();
            try {
                return cache.remove(key);
            } finally {
                lock.unlock();
            }
        }
        return null;
    }

    public void put(K key, V value) {
        if (realCache) {
            lock.lock();
            try {
                cache.put(key, value);
            } finally {
                lock.unlock();
            }
        }
    }

    public int size() {
        if (realCache) {
            if (cache != null) {
                return cache.size();
            }
        }
        return 0;
    }
}
