/**
 * @(#)ZKUtils.java, 2011-7-5. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.KeeperException.NoNodeException;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

import outfox.account.server.zk.ZooKeeperWatcher;

/**
 * Internal utility class for ZooKeeper.
 *
 * <p>Contains only static methods and constants.
 *
 * <p>Methods all throw {@link KeeperException} if there is an unexpected
 * zookeeper exception, so callers of these methods must handle appropriately.
 * 
 * @author licx
 */
public class ZKUtils {
    private static final Log LOG = LogFactory.getLog(ZKUtils.class);

    private static final char ZNODE_PATH_SEPARATOR = '/';

    public static final String ZK_ENCODING = "UTF-8";

    /**
     * Creates a new connection to ZooKeeper.
     *
     * @param quorumServers zookeeper quorum servers
     * @param timeout zookeeper session timeout in milliseconds
     * @param watcher watcher to monitor connection changes
     * @param descriptor descriptor of the connection
     * @return connection to the zookeeper
     * @throws IOException
     */
    public static ZooKeeper connect(String quorumServers, int timeout,
            Watcher watcher, final String descriptor) throws IOException {
        if (StringUtils.isBlank(quorumServers)) {
            throw new IllegalArgumentException("Illegal ZooKeeper servers");
        }
        LOG.debug(descriptor + " opening connection to ZooKeeper");
        return new ZooKeeper(quorumServers, timeout, watcher);
    }

    // Helper methods
    /**
     * Join the prefix znode name with the suffix znode name to generate a proper
     * full znode name.
     *
     * Assumes prefix does not end with slash and suffix does not begin with it.
     *
     * @param prefix beginning of znode name
     * @param suffix ending of znode name
     * @return result of properly joining prefix with suffix
     */
    public static String joinZNode(String prefix, String suffix) {
        return prefix + ZNODE_PATH_SEPARATOR + suffix;
    }

    /**
     * Returns the full path of the immediate parent of the specified node.
     * @param node path to get parent of
     * @return parent of path, null if passed the root node or an invalid node
     */
    public static String getParent(String node) {
        int idx = node.lastIndexOf(ZNODE_PATH_SEPARATOR);
        return idx <= 0 ? null : node.substring(0, idx);
    }

    /**
     * Get the name of the current node from the specified fully-qualified path.
     * @param path fully-qualified path
     * @return name of the current node
     */
    public static String getNodeName(String path) {
        return path.substring(path.lastIndexOf("/") + 1);
    }

    //
    // Existence checks and watches
    //

    /**
     * Check if the specified node exists.  Sets no watches.
     *
     * @param zkw zk reference
     * @param znode path of node to watch
     * @return true if node exists, false if not.
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static boolean checkExists(ZooKeeperWatcher zkw, String znode)
            throws KeeperException {
        try {
            Stat s = zkw.getZooKeeper().exists(znode, null);
            return s != null ? true : false;
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to set watcher on znode (" + znode
                    + ")"), e);
            zkw.keeperException(e);
            return false;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to set watcher on znode (" + znode
                    + ")"), e);
            zkw.interruptedException(e);
            return false;
        }
    }

    /**
     * Watch the specified znode for delete/create/change events. The watcher is
     * set whether or not the node exists.
     * 
     * @param zkw zk reference
     * @param znode path of node to watch
     * @return true if znode exists, false if does not exist or error
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static boolean checkExistsAndWatch(ZooKeeperWatcher zkw,
            String znode) throws KeeperException {
        try {
            Stat s = zkw.getZooKeeper().exists(znode, zkw);
            LOG.debug(zkw.prefix("Set watcher on existing znode " + znode));
            return s != null ? true : false;
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to set watcher on znode " + znode), e);
            zkw.keeperException(e);
            return false;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to set watcher on znode " + znode), e);
            zkw.interruptedException(e);
            return false;
        }
    }
    
    //
    // Node listings
    //

    /**
     * Lists the children of the specified znode without setting any watches.
     *
     * @param zkw zookeeper reference
     * @param znode path of node to list children of
     * @return list of data of children of specified znode, empty if no children,
     *         null if parent does not exist
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static List<String> listChildrens(ZooKeeperWatcher zkw, String znode)
            throws KeeperException {
        try {
            // List the children without watching
            List<String> children = zkw.getZooKeeper().getChildren(znode, null);
            return children;
        } catch (KeeperException.NoNodeException nne) {
            LOG.debug(zkw.prefix("Unable to list children of znode " + znode
                    + " " + "because node does not exist (not an error)"));
            return null;
        } catch(KeeperException e) {
            LOG.warn(zkw.prefix("Unable to list children of znode " + znode), e);
            zkw.keeperException(e);
            return null;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to list children of znode " + znode), e);
            zkw.interruptedException(e);
            return null;
        }
    }

    /**
     * Lists the children znodes of the specified znode.  Also sets a watch on
     * the specified znode which will capture a NodeDeleted event on the specified
     * znode as well as NodeChildrenChanged if any children of the specified znode
     * are created or deleted.
     *
     * @param zkw zk reference
     * @param znode path of node to list and watch children of
     * @return list of children of the specified node, an empty list if the node
     *          exists but has no children, and null if the node does not exist
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static List<String> listChildrensAndWatch(ZooKeeperWatcher zkw,
            String znode) throws KeeperException {
        try {
            List<String> children = zkw.getZooKeeper().getChildren(znode, zkw);
            return children;
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to list children of znode " + znode
                    + " "), e);
            zkw.keeperException(e);
            return null;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to list children of znode " + znode
                    + " "), e);
            zkw.interruptedException(e);
            return null;
        }
    }

    //
    // Data retrievals and settings
    //

    /**
     * Get the data of the specified znode without setting a watcher.
     * @param zkw zk reference
     * @param znode path of node to get data
     * @return data of the specified znode or null
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static byte[] getData(ZooKeeperWatcher zkw, String znode)
            throws KeeperException{
        try {
            byte[] data = zkw.getZooKeeper().getData(znode, null, null);
            LOG.debug(zkw.prefix("Retrieved " + ((data == null)? 0: data.length)
                    + " byte(s) of data from znode " + znode));
            return data;
        } catch (KeeperException.NoNodeException e) {
            LOG.debug(zkw.prefix("Unable to get data of znode " + znode + " "
                    + "because node does not exist (not an error)"));
            return null;
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to get data of znode " + znode), e);
            zkw.keeperException(e);
            return null;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to get data of znode " + znode), e);
            zkw.interruptedException(e);
            return null;
        }
    }

    /**
     * Get the data at the specified znode and set a watch.
     * 
     * @param zkw zk reference
     * @param znode path of node
     * @return the data and sets a watch if the node exists. Returns null and no
     *         watch is set if the node does not exist or there is an exception.
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static byte[] getDataAndWatch(ZooKeeperWatcher zkw, String znode)
            throws KeeperException {
        try {
            byte[] data = zkw.getZooKeeper().getData(znode, zkw, null);
            LOG.debug(zkw.prefix("Retrieved " + ((data == null)? 0: data.length)
                    + " byte(s) of data from znode " + znode + " and set watcher"));
            return data;
        } catch (KeeperException.NoNodeException e) {
            LOG.debug(zkw.prefix("Unable to get data of znode " + znode + " "
                    + "because node does not exist (not an error)"));
            return null;
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to get data of znode " + znode), e);
            zkw.keeperException(e);
            return null;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to get data of znode " + znode), e);
            zkw.interruptedException(e);
            return null;
        }
    }

    /**
     * Sets the data of the existing znode to be the specified data.  The node
     * must exist but no checks are done on the existing data or version.
     *
     * <p>If the node does not exist, a {@link NoNodeException} will be thrown.
     *
     * <p>No watches are set but setting data will trigger other watchers of this
     * node.
     *
     * <p>If there is another problem, a KeeperException will be thrown.
     *
     * @param zkw zk reference
     * @param znode path of node
     * @param data data to set for node
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static void setData(ZooKeeperWatcher zkw, String znode, byte[] data)
            throws KeeperException{
        try {
            zkw.getZooKeeper().setData(znode, data, -1);
            LOG.debug(zkw.prefix("Set data on znode " + znode));
        } catch (KeeperException e ) {
            LOG.warn(zkw.prefix("Unable to set data of znode " + znode), e);
            zkw.keeperException(e);
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to set data of znode " + znode), e);
            zkw.interruptedException(e);
        }
    }

    //
    // Node creations
    //

    /**
     * Creates a persistent node with the specified path if the node does
     * not exist, and fails silently if the node already exists. No watcher
     * is set.
     *
     * <p>The node created is persistent and open access.
     *
     * @param zkw zk reference
     * @param znode path of node
     * @param data data of node
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static void createPersistentAndFailSilent(ZooKeeperWatcher zkw,
            String znode, byte [] data) throws KeeperException {
        try {
            zkw.getZooKeeper().create(znode, data, Ids.OPEN_ACL_UNSAFE,
                    CreateMode.PERSISTENT);
        } catch (KeeperException.NodeExistsException nee) {
        } catch (KeeperException e ) {
            LOG.warn(zkw.prefix("Unable to create persistent node " + znode), e);
            zkw.keeperException(e);
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to create persistent node " + znode), e);
            zkw.interruptedException(e);
        }
    }

    /**
     * Create the specified znode to be an ephemeral node carrying the specified
     * data insistently. If this ephemeral node already exists, remove this node
     * and create a new one. This method makes sure an ephemeral node is created
     * by this ZooKeeper session. No watcher is set.
     *
     * @param zkw zk reference
     * @param znode path of node
     * @param data data of node
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static void createEphemeralNodeInsistent(ZooKeeperWatcher zkw,
            String znode, byte[] data) throws KeeperException {
        try {
            if (checkExists(zkw, znode)) {
                LOG.warn(zkw.prefix("There is an ephemeral znode " + znode
                        + " exist, delete it and re-create"));
                deleteNodeFailSilent(zkw, znode);
            }
            zkw.getZooKeeper().create(znode, data, Ids.OPEN_ACL_UNSAFE,
                    CreateMode.EPHEMERAL);
        } catch (KeeperException e ) {
            LOG.warn(zkw.prefix("Unable to create ephemeral znode " + znode), e);
            zkw.keeperException(e);
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to create ephemeral znode " + znode), e);
            zkw.interruptedException(e);
        }
    }

    /**
     * Create the specified znode to be an ephemeral node carrying the specified
     * data. If the node is created successfully, a watcher is also set on the
     * node. If the node is not created successfully because it already exists,
     * this method will also set a watcher on the node. If there is another
     * problem, a KeeperException will be thrown.
     * 
     * @param zkw zk reference
     * @param znode path of node
     * @param data data of node
     * @return true if node created, false if not, watch set in both cases
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static boolean createEphemeralNodeAndWatch(ZooKeeperWatcher zkw,
            String znode, byte [] data) throws KeeperException {
        try {
            zkw.getZooKeeper().create(znode, data, Ids.OPEN_ACL_UNSAFE,
                    CreateMode.EPHEMERAL);
            return true;
        } catch (KeeperException.NodeExistsException nee) {
            if (!checkExistsAndWatch(zkw, znode)) {
                // It did exist but now it doesn't, try again
                return createEphemeralNodeAndWatch(zkw, znode, data);
            }
            return false;
        } catch (KeeperException e ) {
            LOG.warn(zkw.prefix("Unable to create ephemeral znode " + znode), e);
            zkw.keeperException(e);
            return false;
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to create ephemeral znode " + znode), e);
            zkw.interruptedException(e);
            return false;
        }
    }

    //
    // Node deletes
    //

    /**
     * Deletes the specified node. Sets no watches.
     *
     * @param zkw zk reference
     * @param znode path of the node to delete
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static void deleteNode(ZooKeeperWatcher zkw, String znode)
            throws KeeperException{
        try {
            zkw.getZooKeeper().delete(znode, -1);
            LOG.debug(zkw.prefix("Delete znode " + znode));
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to delete znode " + znode), e);
            zkw.keeperException(e);
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to delete znode " + znode), e);
            zkw.interruptedException(e);
        }
    }

    /**
     * Deletes the specified node.  Fails silent if the node does not exist.
     * No watcher is set.
     *
     * @param zkw zk reference
     * @param znode path of the node to delete
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static void deleteNodeFailSilent(ZooKeeperWatcher zkw, String znode)
            throws KeeperException{
        try {
            zkw.getZooKeeper().delete(znode, -1);
            LOG.warn(zkw.prefix("Delete znode " + znode));
        } catch (KeeperException.NoNodeException nne) {
            LOG.debug(zkw.prefix("Znode " + znode + " does not exist " +
            		"when delete, ignoring..."));
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to delete znode " + znode), e);
            zkw.keeperException(e);
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to delete znode " + znode), e);
            zkw.interruptedException(e);
        }
    }

    /**
     * Delete the specified node and all of it's children. No watcher is set.
     *
     * @param zkw zk reference
     * @param znode path of the node to delete
     * @throws KeeperException if unexpected zookeeper exception
     */
    public static void deleteNodeRecursively(ZooKeeperWatcher zkw, String znode)
            throws KeeperException {
        try {
            List<String> children = zkw.getZooKeeper().getChildren(znode, null);
            if (children != null && !children.isEmpty()) {
                for (String child: children) {
                    deleteNodeRecursively(zkw, joinZNode(znode, child));
                }
            }
            zkw.getZooKeeper().delete(znode, -1);
            LOG.debug(zkw.prefix("Delete znode " + znode + " and all its children"));
        } catch (KeeperException e) {
            LOG.warn(zkw.prefix("Unable to recursively delete znode " + znode), e);
            zkw.keeperException(e);
        } catch (InterruptedException e) {
            LOG.warn(zkw.prefix("Unable to recursively delete znode " + znode), e);
            zkw.interruptedException(e);
        }
    }
}
