/**
 * @(#)ShowHandler.java, 2012-12-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
@Controller
public class ShowHandler extends BaseHandler {
    private static final long serialVersionUID = 2603267856614131810L;
    
    @RequestMapping(AccConst.SHOW_PROTOCOL_URL)
    public void showHttpProtocal(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "show-protocol");
        if (AuthUtils.isHttpsProtocal(req)) {
            AuthUtils.writePlainChunked(resp, "HTTPS", HttpStatus.OK);
        } else {
            AuthUtils.writePlainChunked(resp, "HTTP", HttpStatus.OK);
        }
    }
}
