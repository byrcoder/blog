/**
 * @(#)IShowKeyDB.java, 2012-12-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.in;

import outfox.account.data.PublicViewWritable;
import outfox.account.db.in.IPublicViewMappingDB.IPublicViewMappingIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public interface IPublicViewMappingDB extends IteratorService<IPublicViewMappingIter>{

    void write(String urlSuffix, PublicViewWritable publicView) throws AccException;
    PublicViewWritable read(String urlSuffix) throws AccException;
    void remove(String urlSuffix) throws AccException;
    public interface IPublicViewMappingIter extends Iterator<PublicViewWritable>{
        public PublicViewWritable next() throws AccException;
        public void close();
    }
}
