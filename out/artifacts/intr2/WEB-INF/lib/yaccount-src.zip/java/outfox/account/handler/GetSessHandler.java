/**
 * @(#)GetURSSessHandler.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.AccCookies;
import outfox.account.data.AuthInfo;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.logic.EmailRedirect;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.IVerifier;
import outfox.account.server.token.verifier.impl.URSTokenVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;
import outfox.account.conf.AccConst.METHOD_NAMES;
/**
 * @author chen-chao
 */
@Controller
public class GetSessHandler extends BaseHandler{
    private static final long serialVersionUID = -4964467982934240445L;
    private static final TokenVerifierFactory factory = TokenVerifierFactory.getInstance();
    
    @RequestMapping(AccConst.GET_URS_SESS_URL)
    protected void getUrsSess(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "get-urs-sess");
        checkParam(req, AccConst.PARAM_METHOD, NO_MISS);
        checkParamOrHeader(req, AccConst.PARAM_PRODUCT_NAME,NO_MISS);
        AuthInfo tokens = checkLogin(req);
        String methodName = req.getParameter(AccConst.PARAM_METHOD);
        METHOD_NAMES method = METHOD_NAMES.valueOf(methodName.toUpperCase());
        final String product = tokens.product;
        final String verifierName = tokens.tpToken.verifierName;
        IVerifier verifier = factory.getTokenVerifier(product, verifierName);
        URSTokenVerifier ursTokenVerifier = null;
        if (verifier instanceof URSTokenVerifier) {
            ursTokenVerifier = (URSTokenVerifier)verifier;
        } else {
            throw new AccException(String.format("not urs token verifer. using product: %s, verifier: %s", product, verifierName), AccExpType.LOGIC_ERROR);
        }
        
        Map<String, String> sessInfo = ursTokenVerifier.getUrsCookieBySessionCookie(tokens.sess, req, resp);
        sessInfo.put(AccConst.USER_ID, tokens.userId);
        switch (method) {
            case EMAIL:
                String redirectUrl = EmailRedirect.emailRedirctUrl(req, resp, sessInfo);
                redirect(req, resp, redirectUrl);
                break;
                
            case WRITE_COOKIE:
                Cookie cookie = AuthUtils.genCookie(UrsUtils.NTES_SESS, sessInfo.get(UrsUtils.NTES_SESS), ".youdao.com", AccConst.URL_ROOT, -1,
                        true);
                resp.addCookie(cookie);
                
                cookie = AuthUtils.genCookie(UrsUtils.P_INFO, sessInfo.get(UrsUtils.P_INFO), ".youdao.com", AccConst.URL_ROOT, -1,
                        false);
                resp.addCookie(cookie);
                
                cookie = AuthUtils.genCookie(UrsUtils.S_INFO, sessInfo.get(UrsUtils.S_INFO), ".youdao.com", AccConst.URL_ROOT, -1,
                        false);
                resp.addCookie(cookie);
                break;

            default:
                break;
        }
    }

    /**
     * re
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(AccConst.GET_SESS_URL)
    protected void getSess(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        setName(req, "get-sess");
        AuthInfo tokens = checkLogin(req);
        AccCookies accCookies = TokenUtils.genCookieByCookieParam(req, tokens.pers.getTpToken(), COOKIE_FORMAT.se.value());
        accCookies.addCookieToResponse(resp);
        if (StringUtils.isNotBlank(req.getParameter(AccConst.PARAM_GET_USER_INFO))) {
            List<Parameter> params = AuthUtils.convertMap2List(tokens.userInfo.getInfoMap());
            params.add(AccConst.LOGIN_TRUE);
            write(req, resp, params, HttpStatus.OK);
        }
    }
}
