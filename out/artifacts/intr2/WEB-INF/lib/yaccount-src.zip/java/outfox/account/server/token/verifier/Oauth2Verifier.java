/**
 * @(#)IOauth2Verifier.java, 2012-9-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;

import outfox.account.conf.OAuthConstant;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public abstract class Oauth2Verifier extends Verifier implements IOauthVerifier{
    protected String appkey;
    protected String secret;
    protected String baseUrl;
    protected String authorizeUrl;
    protected String accessUrl;
    protected String callbackUrl;
    
    
    public Oauth2Verifier(Properties props, String name) {
        super(props);
        if (props == null || props.getProperty(name + VerifierConfConst.BASE_URL) == null) {
            throw new AccRunTimeException(new AccException("init tsina error", AccExpType.NOT_SUPPORT));
        }
        baseUrl = getAndCheck(props, name + VerifierConfConst.BASE_URL);
        authorizeUrl = getAndCheck(props, name + VerifierConfConst.AUTH_URL);
        accessUrl = getAndCheck(props, name + VerifierConfConst.ACCESS_URL);
        callbackUrl = getAndCheck(props, name + VerifierConfConst.CALLBACK_URL);
        appkey = getAndCheck(props, name + VerifierConfConst.KEY);
        secret = getAndCheck(props, name + VerifierConfConst.SECRET);
        idPattern = getAndCheck(props, name + VerifierConfConst.ID);
        
        initProps(props);
        initAbsoluteUrl();
        getIdPrefix();
    }
    
    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp) throws AccException{
        throw new AccRunTimeException(new AccException(AccExpType.NOT_IMPLEMENT_METHOD));
    }

    /**
     * should put access token into it.
     */
    @Override
    public UserInfoWritable getUserInfo(HttpServletRequest req, HttpServletResponse resp)throws AccException {
        throw new AccRunTimeException(new AccException(AccExpType.NOT_IMPLEMENT_METHOD));
    }
    
    public Map<String, Object> verifyAuthToken(HttpServletRequest req, HttpServletResponse resp, String token, long expiredTime)throws AccException {
        return super.verifyAuthToken(req, resp, token, expiredTime);
    }
    
    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        throw new AccRunTimeException(new AccException(AccExpType.NOT_IMPLEMENT_METHOD));
    }

    public String getAbsoluteAuthorizeUrl() throws AccException {
        return authorizeUrl;
    }
    public String getAbsoluteAccessUrl() throws AccException {
        return accessUrl;
    }
    
    /**
     * the function can get absolutely URL of third party. If the relative URL has
     * the same base URL. 
     * @param relativeUrl
     * @return
     * @throws AccException
     */
    public String getAbsoluteUrl(String relativeUrl) throws AccException {
        try {
            URL url = new URL(baseUrl);
            return new URL(url, relativeUrl).toExternalForm();
        } catch (MalformedURLException e) {
            throw new AccException("baseUrl is not url format. baseUrl : " + baseUrl + " relativeUrl:"
                    + relativeUrl, AccExpType.URI_ERROR);
        }
    }
    /**
     * req can set to null. it will return initial callback URL.
     * @param req
     * @return
     */
    public String getAbsoluteCallbackUrl(HttpServletRequest req) {
        if (callbackUrl.startsWith("/") && req != null) {
            return AuthUtils.generateAbsoluteUrl(req, callbackUrl);
        }
        return callbackUrl;
    }
    
    public void initAbsoluteUrl() {
        try {
            accessUrl = getAbsoluteUrl(accessUrl);
            authorizeUrl = getAbsoluteUrl(authorizeUrl);
        } catch (AccException e) {
            throw new AccRunTimeException("init url error", e);
        }
    }
    
    public Header authorizeHeader(String accessToken) {
        return new BasicHeader(OAuthConstant.AUTHORIZED_HEAD_NAME, "OAuth2 " + accessToken);
    }
    
    public String getAppkey() {
        return appkey;
    }

    public String getSecret() {
        return secret;
    }

    public String getBaseUrl() {
        return baseUrl;
    }
}
