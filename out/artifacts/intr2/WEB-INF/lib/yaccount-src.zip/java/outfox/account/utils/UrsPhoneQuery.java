/**
 * @(#)UrsPhoneQuery.java, 2012-06-15. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConfig;
import outfox.account.data.Parameter;
/**
 * This class is used for query main email by a phone number.
 * If your program want use the class, your machine IP should be in
 * Query phone (reg.163.com) white-list first.
 * usage:
 * UrsPhoneQuery.getInstance().query(13333333333)
 * 
 * The class is also used for check username and password correct.
 * @author chen-chao
 *
 */
public class UrsPhoneQuery {
    private HttpClient client;

    private static final String phoneQueryUrl = AccConfig.getPros().getString(
            AccConfig.NAME_URS_PHONE_QUERY_URL);

    private static final String phoneQueryFormat = phoneQueryUrl + "?username=%s&product=note";
    
    private static final String ursLoginQueryUrlPrefix = AccConfig.getPros().getString(
            AccConfig.NAME_URS_LOGIN_QUERY_URL);

    private static final String SUFFIX = "@163.com";
    
    private interface DEFAULT_VALUE_TYPE{
        public String getValue();
    }
    
    public static final String NAME_USERNAME = "username";
    /**
     *  set cookie or not
     */
    public static final String NAME_TYPE = "type";
    public enum VALUE_TYPE implements DEFAULT_VALUE_TYPE {
        SET_COOKIE {
            public String getValue(){return "1";}},
        UNSET_COOKIE {
            public String getValue(){return "0";}};
    }
    /**
     * raw password or md5 password
     */
    public static final String NAME_PASSWORD = "password"; 
    public static final String NAME_PRODUCT = "product";
    public enum VALUE_PRODUCT implements DEFAULT_VALUE_TYPE {
        NOTE {
            public String getValue(){return "note";}};
    }
    /**
     * presist cookie set or not
     */
    public static final String NAME_SAVE_LOGIN = "savelogin";
    
    public enum VALUE_SAVE_LOGIN implements DEFAULT_VALUE_TYPE {
        SAVE_LOGIN {
            public String getValue(){return "1";}};
    }
    
    public static final String NAME_PASS_TYPE = "passtype";
    /**
     * if set "" or null, use raw password in yeah account,
     * and use md5 password in other account.
     *
     * @author chen-chao
     *
     */
    public enum VALUE_PASS_TYPE implements DEFAULT_VALUE_TYPE {
        RAW_PASSWORD {
            public String getValue(){return "1";}},
        MD5_PASSWORD {
            public String getValue(){return "0";}};
      
    }
    
    /**
     * the parameter has effect only in game product.
     */
    public static final String NAME_IGNORE_LOCK = "ignorelock";
    
    public enum VALUE_IGNORE_LOCK implements DEFAULT_VALUE_TYPE {
        IGNORE_LOCK {
            public String getValue(){return "1";}},
        LOCK {
            public String getValue(){return "0";}};
    }
    
    /**
     * get user phone account.
     * <b>suggest</b> use "needmainaccount" parameter instead.
     */
    public static final String NAME_IGNORE_ALIAS = "ignorealias";
    
    public enum VALUE_IGNORE_ALIAS implements DEFAULT_VALUE_TYPE {
        NEED_ALIAS {
            public String getValue(){return "1";}},
        IGNORE {
            public String getValue(){return "0";}};
    }
    /**
     * return login exception
     */
    public static final String NAME_LOGIN_EXCEPTION = "loginException";
    public enum VALUE_LOGIN_EXCEPTION implements DEFAULT_VALUE_TYPE {
        NORMAL_INFO {
            public String getValue(){return "1";}},
        BE_STOLEN {
            public String getValue(){return "3";}};
    }
    
    /**
     * return user status.
     * 420 user not exist
     */
    public static final String NAME_USER_STATUS = "userStatus";
    public enum VALUE_USER_STATUS implements DEFAULT_VALUE_TYPE {
        NORMAL_INFO {
            public String getValue(){return "1";}};
    }
    
    /**
     * related account relate time refresh or not
     */
    public static final String NAME_RELATE = "relate";
    public enum VALUE_RELATE implements DEFAULT_VALUE_TYPE {
        REFRESH {
            public String getValue(){return "1";}},
        NO_REFRESH {
            public String getValue(){return "0";}},
    }
    
    /**
     * return secure info
     */
    public static final String NAME_SECURE_INFO ="secuInfo";
    public enum VALUE_SECURE_INFO implements DEFAULT_VALUE_TYPE {
        SECURE_INFO_RETURN {
            public String getValue(){return "1";}},
        NO_SECURE_INFO_RETURN {
            public String getValue(){return "0";}},
    }
    
    public static final String NAME_NEED_MAIN_ACCOUNT = "needmainaccount";
    public enum VALUE_NEED_MAIN_ACCOUNT implements DEFAULT_VALUE_TYPE {
        MAIN_ALAIS_ACCOUNT_RETURN {
            public String getValue(){return "1";}},
        NO_ACCOUNT_RETURN {
            public String getValue(){return "0";}},
    }
    
    /**
     * need return information about the account is leak or not
     */
    public static final String NAME_NEED_LEAK_INFO = "needLeakInfo";
    public enum VALUE_NEED_LEAK_INFO implements DEFAULT_VALUE_TYPE {
        NEED {
            public String getValue(){return "1";}},
        IGNORE {
            public String getValue(){return "0";}},
    }
    /**
     * http referer
     */
    public static final String NAME_REFERER = "referer";
    
    private static Log LOG = LogFactory.getLog(UrsPhoneQuery.class);
    private UrsPhoneQuery() {
//        client = MultiThreadHttpClient.getInstance();
    }
    /**
     * Check the account's user name and password.
     * If correct, return true; else return false.
     * @param name
     * @param passwordMD5
     * @return
     * @throws UnsupportedEncodingException 
     */
    public boolean checkAccountMD5(String name, String passwordMD5) {
        ArrayList<Parameter> params= new ArrayList<Parameter>();
        params.add(new Parameter(NAME_USERNAME, name));
        params.add(new Parameter(NAME_IGNORE_ALIAS, VALUE_IGNORE_ALIAS.IGNORE.getValue()));
        params.add(new Parameter(NAME_IGNORE_LOCK, VALUE_IGNORE_LOCK.IGNORE_LOCK.getValue()));
        params.add(new Parameter(NAME_LOGIN_EXCEPTION, VALUE_LOGIN_EXCEPTION.NORMAL_INFO.getValue()));
        params.add(new Parameter(NAME_NEED_LEAK_INFO, VALUE_NEED_LEAK_INFO.IGNORE.getValue()));
        params.add(new Parameter(NAME_NEED_MAIN_ACCOUNT, VALUE_NEED_MAIN_ACCOUNT.NO_ACCOUNT_RETURN.getValue()));
        params.add(new Parameter(NAME_PASSWORD, passwordMD5));
        params.add(new Parameter(NAME_PASS_TYPE, VALUE_PASS_TYPE.MD5_PASSWORD.getValue()));
        params.add(new Parameter(NAME_PRODUCT, VALUE_PRODUCT.NOTE.getValue()));
        params.add(new Parameter(NAME_REFERER, null));
        params.add(new Parameter(NAME_RELATE, VALUE_RELATE.NO_REFRESH.getValue()));
        params.add(new Parameter(NAME_SAVE_LOGIN, null));
        params.add(new Parameter(NAME_SECURE_INFO, VALUE_SECURE_INFO.NO_SECURE_INFO_RETURN.getValue()));
        params.add(new Parameter(NAME_TYPE, VALUE_TYPE.UNSET_COOKIE.getValue()));
        params.add(new Parameter(NAME_USER_STATUS, VALUE_USER_STATUS.NORMAL_INFO.getValue()));
        
        try {
            String url = AuthUtils.composeQueryUrl(ursLoginQueryUrlPrefix, params);
            GetMethod method = new GetMethod(url);
            method.setFollowRedirects(false);
            int code = client.executeMethod(method);
            int returnCode = 0;
            if (code == 200) {
                String result = method.getResponseBodyAsString();
                returnCode = getReturnCode(result);
                if (returnCode == 200){
                    return true;
                }
                LOG.warn(result);
            } else {
                LOG.warn("httpstatus code:"+code);
            }
        } catch (Throwable e) {
            LOG.warn("query urs login error.", e);
        }
        return false;
    }
    
    /**
     * only get return code in http body
     * @param result
     * @return
     */
    private static int getReturnCode(String result){
        int returnCode = 0;
        if (!StringUtils.isBlank(result)){
        
            String[] lines = result.split("\n");
            returnCode = Integer.parseInt(lines[0].trim());
            
        }
        return returnCode;
    }
    
    /**
     * If success, return main account(email account).
     * Else return null;
     * @param phone
     */
    public String query(String phone){
        String email = null;
        if (StringUtils.isNumeric(phone)){
            String query = String.format(phoneQueryFormat, phone);
            GetMethod method = new GetMethod(query);
            method.setFollowRedirects(true);
            
            try {
                int code = client.executeMethod(method);
                if (code == 200) {
                    String result = method.getResponseBodyAsString();
                    email = parsePhoneQueryResult(result);
                } else {
                    LOG.warn("return code:"+code+" query: " + query);
                }
            } catch (Throwable t){
                LOG.warn("query phone "+phone+" error:", t);
            }
            
        }
        return email;
    }
    
    public static UrsPhoneQuery getInstance(){
        return UrsPhoneQueryHolder.INSTANCE;
    }
    
    private static class UrsPhoneQueryHolder{
        private static final UrsPhoneQuery INSTANCE = new UrsPhoneQuery();
    }
    
    /**
     * <pre>
     * parse response body. if ok, return email address, else
     * return null, and write warning log.
     * </pre> 
     * @param result
     * <pre>
     * like :
     * 201
     * Ok and more information returned
     * aaaa|1333333333
     * </pre>
     * @return
     */
    private static String parsePhoneQueryResult(String result){
        String email = null;
        if (!StringUtils.isBlank(result)){
        
            String[] lines = result.split("\n");
            int returnCode = Integer.parseInt(lines[0].trim());
            
            switch(returnCode){
                case 201:
                    /**
                     * normal
                     */
                    email = getEmail(lines[2]);
                    break;
                case 410:
                    LOG.fatal("Query phone IP is not allowed!! And ip into reg.163.com white-list." + result);
                    break;
                default:
                    LOG.warn("Query phone error: "+result);
                    break;
            }
        }
        return email;
    }
    
    /**
     * get email from response line.
     * @param line 
     * <pre>
     * like :
     * aaa|1333333333  => aaa@163.com
     * abc@126.com|1333333333 => abc@126.com
     * </pre>
     * @return
     */
    private static String getEmail(String line){
        
        int end = line.indexOf("|");
        String emailPrefix = line.substring(0, end);
        if (emailPrefix.indexOf("@") != -1){
            return emailPrefix;
        } else {
            return emailPrefix + SUFFIX;
        }
    }
}
