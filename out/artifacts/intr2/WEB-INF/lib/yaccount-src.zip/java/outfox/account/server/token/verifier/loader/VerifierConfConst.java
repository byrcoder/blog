/**
 * @(#)VerifierConfigConst.java, 2012-9-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.loader;

/**
 * @author chen-chao
 */
public interface VerifierConfConst {
    static final String BASE_URL = ".serviceProvider.baseURL";
    static final String REQUEST_URL = ".serviceProvider.requestTokenURL";
    static final String AUTH_URL = ".serviceProvider.userAuthorizationURL";
    static final String ACCESS_URL = ".serviceProvider.accessTokenURL";
    static final String KEY = ".consumerKey";
    static final String SECRET = ".consumerSecret";
    static final String ID = ".consumer.idPattern";
    static final String SESS_ALIVE_TIME = ".consumer.sessAlive";
    static final String CALLBACK_URL = ".callbackURL";
    static final String ACCOUNT_URL = ".consumer.accountURL";
    static final String REFRESH_TIME_IN_MILLI = ".refreshInMill";
    static final String EXPIRE_TIME_IN_MILLI = ".expireInMill";
    static final String VERIFIER_SUPPORT = ".consumer.support";
    
    static final String URS_TOKEN_INIT_URL = ".initURL";
    static final String URS_TOKEN_SAFE_LOGIN_URL = ".safeloginURL";
    static final String URS_TOKEN_VERIFIER_URL = ".verifierURL";
    static final String URS_TOKEN_REMOVE_TOKEN_URL = ".removeURL";
    static final String URS_TOKEN_GET_SESS_URL = ".sessURL";
    static final String URS_TOKEN_PRODUCT_NAME = ".productName";
    
    static final String URS_COOKIE_SESS_EXPIRE = ".sessExpireMillis";
    static final String URS_COOKIE_PERS_EXPIRE = ".persExpireMillis";
    
    static final String TSINA_VERIFIER_NAME = "tsina";
    static final String ACCESS_TOKEN_VERIFIER_NAME = "tpac";
    static final String URS_VERIFIER_PERFIX = "urs";
    
    static final String URS_COOKIE_VERIFIER_NAME = URS_VERIFIER_PERFIX+"cookie";
    static final String URS_TOKEN_VERIFIER_NAME = URS_VERIFIER_PERFIX+"token";
    static final String URS_PROXY_COOKIE_VERIFIER_NAME = URS_VERIFIER_PERFIX+"proxy";
}
