/**
 * @(#)URSVerifier.java, 2012-10-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.util.Properties;

import outfox.account.data.user.UserInfoWritable;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public abstract class URSVerifier extends Verifier implements ITokenVerifier{
    public URSVerifier(Properties props) {
        super(props);
    }

    protected UserInfoWritable genUserInfo(String username, String from) {
        UserInfoWritable userInfo = new UserInfoWritable();
        userInfo.userId = username;
        userInfo.from = from;
        userInfo.originalId = username;
        userInfo.userName = username;
        return userInfo;
    }

    public String ownId2tp(String ownId) {
        if (AuthUtils.isValidEmailAddress(ownId)) {
            return getVerifierName();
        }
        return null;
    }
}
