/**
 * @(#)OmapPersTokenDB.java, 2012-9-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.db.kv.IKeyValueStore;
import outfox.account.db.kv.IKeyValueStore.Iter;
import outfox.account.db.kv.KeyPairPool;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.utils.AuthUtils;
import outfox.omap.data.KeyPair;

/**
 * @author chen-chao
 */
public class KVPersTokenDB extends BaseKVDB implements IPersTokenDB {
    private static final String STORE_NAME = "accPerstoken";

    /**
     * key: userid, signature value, product+app+verifer 
     * value: PersistTokenWritable
     */
    private static final String[] types = {
        "TPKEY(VINTSTRING TPKEY(VINTSTRING VINTSTRING))", "CUSTOM(outfox.account.data.PersistTokenWritable)"
    };

    protected IKeyValueStore<IWritableComparable, IWritable> kvStore;

    @SuppressWarnings("unchecked")
    public KVPersTokenDB() {
        super(AccConfig.OMAP, STORE_NAME, types);
        kvStore = (IKeyValueStore<IWritableComparable, IWritable>) keyValueStore;
    }

    @Override
    public void write(PersistTokenWritable tw) throws AccException {
        if (tw == null) {
            return;
        }
        KeyPair key = null;
        try {
            TpToken tpToken = tw.getTpToken();
            key = composeOmapKey(tpToken.userId, tpToken.app, tpToken.product, tpToken.verifierName,
                    tpToken.signature);
            kvStore.writeKeyValue(key, tw);
        } finally {
            keypairPool.returnKey(key);
        }
    }

    public void write(TpToken tpToken) throws AccException {
        if (tpToken == null) {
            return;
        }
        KeyPair key = null;
        try {
            PersistTokenWritable value = new PersistTokenWritable(tpToken);
            key = composeOmapKey(tpToken.userId, tpToken.app, tpToken.product, tpToken.verifierName,
                    tpToken.signature);
            kvStore.writeKeyValue(key, value);
        } finally {
            keypairPool.returnKey(key);
        }
    }

    /**
     * if persist token is expired, will remove session cookies.
     */
    public PersistTokenWritable read(TpToken tpToken) throws AccException {
        if (tpToken == null) {
            return null;
        }
        return read(tpToken.userId, tpToken.app, tpToken.product, tpToken.verifierName, tpToken.signature);
    }

    public PersistTokenWritable read(String userId, String app, String product, String verifierName,
            String signature) throws AccException {
        if (StringUtils.isBlank(userId) || StringUtils.isBlank(app) || StringUtils.isBlank(product)
                || StringUtils.isBlank(verifierName) || StringUtils.isBlank(signature)) {
            return null;
        }
        KeyPair key = null;
        try {
            PersistTokenWritable value = new PersistTokenWritable();

            key = composeOmapKey(userId, app, product, verifierName, signature);
            return kvStore.readValue(key, value) ? value : null;
        } finally {
            keypairPool.returnKey(key);
        }

    }

    public void remove(TpToken tpToken) throws AccException {
        if (tpToken == null) {
            return;
        }
        
        remove(tpToken.userId, tpToken.app, tpToken.product, tpToken.verifierName, tpToken.signature);
    }

    public void remove(String userId, String app, String product, String verifierName, String signature)
            throws AccException {
        if (StringUtils.isBlank(userId) || StringUtils.isBlank(app) || StringUtils.isBlank(product)
                || StringUtils.isBlank(verifierName) || StringUtils.isBlank(signature)) {
            throw new AccException("invalid persToken.", AccExpType.LOGIC_ERROR);
        }
        KeyPair key = null;
        try {
            key = composeOmapKey(userId, app, product, verifierName, signature);
            kvStore.deleteKey(key);
        } finally {
            keypairPool.returnKey(key);
        }
    }

    /**
     * The pool for KeyPair The object is only referred below
     */

    @SuppressWarnings("unchecked")
    private static KeyPairPool keypairPool = KeyPairPool.getKeyPairPool(StringWritable.class,
            StringWritable.class, StringWritable.class);

    private static final String SPLIT_CHAR = "|";

    /**
     * Create omap key for user file, the key is composed by three part: userId,
     * entry path, and version return returned keyPair is pooled, should call
     * {@link #returnOmapKey} after usage
     * 
     * @param userId
     * @param entry
     * @param version
     * @return
     */
    public static KeyPair composeOmapKey(String userId, String app, String product, String verifierName,
            String signature) {
        KeyPair kp = keypairPool.borrowKey();
        if (userId == null) {
            userId = "";
        }

        ((StringWritable) kp.getKey1()).set(userId);
        if (signature == null) {
            signature = "";
        }
        ((StringWritable) ((KeyPair) kp.getKey2()).getKey1()).set(signature);
        String mid = "";
        if (product != null || app != null || verifierName != null) {
            mid = product + SPLIT_CHAR + app + SPLIT_CHAR + verifierName;
        }

        ((StringWritable) ((KeyPair) kp.getKey2()).getKey2()).set(mid);

        return kp;
    }

    /**
     * thread unsafe
     *
     * @author chen-chao
     *
     */
    private class KVPersTokenIter implements IPersTokenIter {
        private Iter<IWritableComparable, IWritable> iter = null;

        private KeyPair key = null;

        private String userid = null;

        public KVPersTokenIter(String userid) throws AccException {
            try {
                this.userid = userid;
                iter = kvStore.getIter();
                key = composeOmapKey(userid, null, null, null, null);
                iter.seekTo(key, false);
            } catch (AccException e) {
                AuthUtils.disposeException(e, AccExpType.STORE_SERVICE_EXCEPTION);
            }
        }

        /**
         * if value is not owned by userid, next() will return null.
         * if no more value, it will return null.
         * @throws AccException 
         */
        @Override
        public PersistTokenWritable next() throws AccException {
            PersistTokenWritable value = new PersistTokenWritable();
            if (!iter.next(key, value) || (!StringUtils.isBlank(userid) && !value.getTpToken().userId.equals(userid))) {
                return null;
            }
            return value;
        }

        @Override
        public void close() {
            AuthUtils.closeQuiet(iter);
            keypairPool.returnKey(key);
        }
    }

    @Override
    public IPersTokenIter getIter(String userId) throws AccException {
        // TODO Auto-generated method stub
        return new KVPersTokenIter(userId);
    }

    @Override
    public IPersTokenIter getIter(Object... startKeys) throws AccException {
        if (startKeys != null) {
            return getIter((String) startKeys[0]);
        }

        throw new AccException("no start keys", AccExpType.NOT_SUPPORT);
    }
}
