/**
 * @(#)AccountConfig.java, 2012-8-16. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.conf;

import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;

/**
 * This class is Configure class. All configure values should be write in (NAME_*, DEFAULT_*) pair.
 * It will load the value from file "account.xml" first, then load it from default. 
 * @author wangfk, chen-chao
 *
 */
public class AccConfig {
    private static final Log LOG = LogFactory.getLog(AccConfig.class);

    private static boolean testCaseMode = false;
    private static boolean isReuseMode = true;
    private static boolean isAuthFilterFake = false;
    private static String ursUserName = "";
    private static boolean isStartCoremailWS = false;

    private static String homePath;
    
    // never use AccConst.ACCOUNT_HOME.
    private static final String ACCOUNT_HOME = "yaccount.home";

    public static String getHomePath() {
        return homePath;
    }
    /**
     * this functin is only for testcase.
     * @param homePath
     */
    @Deprecated
    public static void setHomePath(String homePath) {
        AccConfig.homePath = homePath;
    }

    private static Configuration authConf;

    private static File confPath;

    private static final String filename = "account.xml";
    
    // set apps (client, web, mobile)
    private static Set<String> appSet;
    
    private static Set<String> productSet;
    
    private static Set<String> productUrsMemoryCheckSet;

    static {
        init(null);
    }

    public static final boolean isTestCaseMode() {
        return testCaseMode;
    }
    public static String getUrsUserName() {
        return ursUserName;
    }
    public static void setUrsUserName(String ursUserName) {
        AccConfig.ursUserName = ursUserName;
    }
    public static final boolean isReuseTableMode() {
        return isReuseMode;
    }
    
    public static final void setReuseTableMode(boolean isReuse) {
        isReuseMode = isReuse;
    }

    public static final boolean isAuthFilterFake() {
        return isAuthFilterFake;
    }
    
    public static final boolean isStartCoremailWS() {
        return isStartCoremailWS;
    }
    
    public static final void setStartCoremailWS(boolean isStart) {
        isStartCoremailWS = isStart;
    }

    @SuppressWarnings("unused")
    private static final void setAuthFilterFake(boolean isFake) {
        isAuthFilterFake = isFake;
    }

    public static final void setTestCaseMode(boolean testCaseMode) {
        AccConfig.testCaseMode = testCaseMode;
        AccConfig.getPros().setProperty(NAME_RPC_SERVICE_HANDLER_COUNT, 5);
        AccConfig.getPros().setProperty(NAME_RPC_MAX_CONNECTION_PER_CLIENT, 2);
        configDataStore();
    }
    
    public static File getConfigFile(String filename) {
        return new File(confPath,filename); 
    }

    private static final String MOCK_OMAP_DATA_SOURCE = "MockOmapDataSource";

    private static final void configDataStore() {
        if (OMAP.equals(AccConfig.getPros().getProperty(NAME_DATA_SOURCE))) {
            if (testCaseMode) {
                AccConfig.getPros().setProperty(NAME_OMAP_DATA_SOURCE, MOCK_OMAP_DATA_SOURCE);
            } else {
                AccConfig.getPros().setProperty(NAME_OMAP_DATA_SOURCE, DEFAULT_OMAP_DATA_SOURCE);
            }
        }
    }

    public static synchronized void init(String homePath) {
        AccConfig.homePath = homePath;
        if (StringUtils.isBlank(AccConfig.homePath)) {
            AccConfig.homePath = System.getProperty(ACCOUNT_HOME);
        }
        if (StringUtils.isBlank(AccConfig.homePath)) {
            AccConfig.homePath = ".";
        }
        System.err.println("Set native.home=" + AccConfig.homePath);
        System.setProperty("native.home", AccConfig.homePath);
        System.err.println("Set odis.home=" + AccConfig.homePath);
        System.setProperty("odis.home", AccConfig.homePath);
        System.err.println("Set omap.home=" + AccConfig.homePath);
        System.setProperty("omap.home", AccConfig.homePath);
        
        File authHome = new File(AccConfig.homePath);

        System.setProperty(ACCOUNT_HOME, authHome.getAbsolutePath());
        
        confPath = new File(authHome, "conf");
        File log4j = new File(confPath, "log4j.properties");
        System.out.println("read log4j file at " + log4j.getAbsolutePath());
        PropertyConfigurator.configureAndWatch(log4j.getAbsolutePath());
        LOG.info("Auth server configure path: " + confPath.getAbsolutePath());
        
        Configuration tempConf = null;
        try {
            tempConf = new XMLConfiguration(new File(confPath, filename));
        } catch (Exception e) {
            LOG.warn("parse auth configuration failed, use default");
            tempConf = new PropertiesConfiguration();
        }
        
        if (isTestCaseMode()) {
            // not read from file.
            tempConf = new PropertiesConfiguration();
        }
        
        if (authConf == null) {
            // first init
            // print local config
            authConf = tempConf;
            Iterator<?> iter = authConf.getKeys();
            String key = null;
            while (iter.hasNext()) {
                key = (String)iter.next();
                LOG.info("add auth conf key=" + key + ", value="
                        + authConf.getProperty(key));
            }
            String apps = AccConfig.getPros().getString(
                    AccConfig.NAME_GLOBAL_APP_LIST,
                    AccConfig.DEFAULT_GLOBAL_APP_LIST);

            appSet = new HashSet<String>();
            for (String app: apps.split("\\|")) {
                LOG.info("add app name:" + app);
                appSet.add(app.trim());
            }
            appMapping = new HashMap<String, String>();
        } else {
            Iterator<?> iter = tempConf.getKeys();
            String key = null;
            while (iter.hasNext()) {
                key = (String)iter.next();
                System.err.println("add auth conf key=" + key + ", value="
                        + tempConf.getProperty(key));
                LOG.info("add auth conf key=" + key + ", value="
                        + tempConf.getProperty(key));
                authConf.setProperty(key, tempConf.getProperty(key));
            }
        }

        Set<String> validKeys = getValidKeys();
        Set<String> existKeys = new HashSet<String>();

        // check validity of configuration file
        for (Iterator<?> it = authConf.getKeys(); it.hasNext();) {
            String key = (String)it.next();
            if (validKeys.contains(key)) {
                System.err.println("Read configuration: " + key + "="
                        + authConf.getProperty(key));
                LOG.info("Read configuration: " + key + "="
                        + authConf.getProperty(key));
                existKeys.add(key);
            } else {
                System.err.println("new key read. " + key + "="
                        + authConf.getProperty(key));
                LOG.info("new key read. " + key + "="
                        + authConf.getProperty(key));
            }
        }
        validKeys.removeAll(existKeys);
        for (String key: validKeys) {
            Object defaultValue = getDefaultValue(key);
            System.err.println("default key read. key=" + key + " value=" + defaultValue);
            LOG.info("default key read. key=" + key + " value=" + defaultValue);
            authConf.setProperty(key, defaultValue);
        }

        // config app mapping. For example: iphone, htc => mobile
        configMapping();
        if (isTestCaseMode()) {
            setTestCaseMode(true);
        }
        
        productSet = new HashSet<String>();
        String productStr = authConf.getString(NAME_PRODUCTS);
        String[] products = productStr.split(";");
        for (String product: products) {
            product = product.trim();
            productSet.add(product);
            configUrlMapping(product, SUCCESS_URL, authConf.getString(NAME_GLOBAL_SUCCESS_REDIRECT_URL));
            
            configUrlMapping(product, ERROR_URL,
                    authConf.getString(NAME_GLOBAL_ERROR_REDIRECT_URL));
            
            configUrlMapping(product, REGISTER_URL,
                    authConf.getString(NAME_GLOBAL_REGISTER_REDIRECT_URL));
            
            configUrlMapping(product, REGISTER_RETURN_URL,
                    authConf.getString(NAME_GLOBAL_REGISTER_RETURN_URL));
            
            configUrlMapping(product, GET_USER_META_URL,
                    authConf.getString(NAME_GLOBAL_GET_USER_META_URL));
        }
        
        productUrsMemoryCheckSet = new HashSet<String>();
        productStr = authConf.getString(NAME_PRODUCTS_URS_TOKEN_MEMORY_CHECKS);
        products = productStr.split(";");
        for (String product: products) {
            product = product.trim();
            if (!productSet.contains(product)) {
                LOG.warn("product:"+product+" is not exist in product set!!");
                System.err.println("product:"+product+" is not exist in product set!!");
            } else {
                productUrsMemoryCheckSet.add(product);
            }
           
        }
        
        System.err.println("Init done.");
        LOG.info("Init done.");
        
        System.err.println(configToString(authConf));
        LOG.info(configToString(authConf));
    }

    public static Set<String> getProductSet() {
        return productSet;
    }
    
    public static Set<String> getProductURSTokenMemoryCheckSet() {
        return productUrsMemoryCheckSet;
    }
    
    public static Configuration getPros() {
        return authConf;
    }

    private static final String PREFIX_NAME = "NAME_";

    private static final String PREFIX_DEFAULT_VALUE = "DEFAULT_";

    public static Set<String> getValidKeys() {
        return getValidKeys(AccConfig.class, PREFIX_NAME);
    }

    public static Object getDefaultValue(String key) {
        Object object = getDefaultValue(AccConfig.class, PREFIX_NAME,
                PREFIX_DEFAULT_VALUE, key);
        if (object == null) {
            throw new RuntimeException("no default value of " + key);
        }
        return object;
    }

    public static final long getLongProperty(String name) {
        return authConf.getLong(name);
    }

    public static boolean isStressTest() {
        return authConf.getBoolean(NAME_STRESS_TEST, DEFAULT_STRESS_TEST);
    }

    /**
     * app mapping
     */

    public static final String NAME_GLOBAL_APP_LIST = "global.app_list";

    public static final String DEFAULT_GLOBAL_APP_LIST = "web|client|mobile";

    public static final String CLIENT_TYPE_WEB = "web";

    public static final String CLIENT_TYPE_PC = "client";

    public static final String CLIENT_TYPE_MOBILE = "mobile";

    public static final String CLIENT_TYPE_WEB_163MAIL = "163mail";

    private static final String APP_MAPPING_SUFFIX = "app_mapping";

    public static final String NAME_MAPPING_WEB = "web." + APP_MAPPING_SUFFIX;

    public static final String DEFAULT_MAPPING_WEB = "163mail;osx";

    public static final String NAME_MAPPING_MOBILE = "mobile."
            + APP_MAPPING_SUFFIX;

    public static final String DEFAULT_MAPPING_MOBILE = "iphone; htc; ipad; android; winphone";

    public static final String NAME_MAPPING_CLIENT = "client."
            + APP_MAPPING_SUFFIX;

    public static final String DEFAULT_MAPPING_CLIENT = "";

    private static HashMap<String, String> appMapping;

    /**
     * convert
     * <p>
     * &lt;web&gt;
     * <p>
     * &lt;app-mapping&gt;
     * <p>
     * web; unknown
     * <p>
     * &lt;/app-mapping&gt;
     * <p>
     * &lt;/web&gt;
     * <p>
     * to
     * <p>
     * web => web
     * <p>
     * unknown => web
     * <p>
     * HashMap
     * 
     * @return
     */
    public static void configMapping() {
        Iterator<?> keyIter = authConf.getKeys();
        while (keyIter.hasNext()) {
            String key = (String) keyIter.next();
            if (key.endsWith(APP_MAPPING_SUFFIX)) {

                String value = authConf.getString(key);
                String[] fields = key.split("\\.");
                String type = fields[0];
                for (String app: value.split(";")) {
                    if (!StringUtils.isBlank(app)) {

                        appMapping.put(app.trim().toLowerCase(), type.trim()
                                .toLowerCase());
                    }
                }
                appMapping.put(type.trim().toLowerCase(), type.trim().toLowerCase());
            }
        }
    }
    
    /**
     * about register and captcha
     */
    public static final String NAME_REGISTER_PRODUCT_NAME = "register.product";

    public static final String DEFAULT_REGISTER_PRODUCT_NAME = "note";

    public static final String NAME_CAPTCHA_WIDTH = "register.captcha.width";

    public static final int DEFAULT_CAPTCHA_WIDTH = 138;

    public static final String NAME_CAPTCHA_HEIGHT = "register.captcha.height";

    public static final int DEFAULT_CAPTCHA_HEIGHT = 36;

    public static final String NAME_CAPTCHA_MIN_LENGTH = "register.captcha.min";

    public static final int DEFAULT_CAPTCHA_MIN_LENGTH = 5;

    public static final String NAME_CAPTCHA_MAX_LENGTH = "register.captcha.max";

    public static final int DEFAULT_CAPTCHA_MAX_LENGTH = 5;

    public static final String NAME_CAPTCHA_CODE_TIMEOUT = "register.timeout";
    
    public static final long DEFAULT_CAPTCHA_CODE_TIMEOUT = 5 * 60 * 1000;
    
    /**
     * used in PollHandler load will be 0.5
     */
    public static final String NAME_POLL_COOKIE_CACHE_LIMIT_SIZE = "poll.cache-limit";

    public static final int DEFAULT_POLL_COOKIE_CACHE_LIMIT_SIZE = 262144;

    public static final String NAME_POLL_COOKIE_CACHE_SIZE = "poll.cache-size";

    /**
     * used in AuthCookieStore load will be limit/size = 0.7 1024 * 512
     */
    public static final int DEFAULT_POLL_COOKIE_CACHE_SIZE = 524288;

    public static final String NAME_COOKIE_STORE_CACHE_LIMIT_SIZE = "store.cache-limit";

    /**
     * 1024 * 256 + 100000
     */
    public static final int DEFAULT_COOKIE_STORE_CACHE_LIMIT_SIZE = 362144;

    public static final String NAME_COOKIE_STORE_CACHE_SIZE = "store.cache-size";

    /**
     * 1024 * 512
     */
    public static final int DEFAULT_COOKIE_STORE_CACHE_SIZE = 524288;

    /**
     * used in userInfoGenerate to generate session cookie
     */
    public static final String NAME_GLOBAL_PCI_COOKIE_CACHE_SIZE = "global.pci-cache_size";

    public static final int DEFAULT_GLOBAL_PCI_COOKIE_CACHE_SIZE = DEFAULT_COOKIE_STORE_CACHE_SIZE;

    public static final String NAME_GLOBAL_PCI_COOKIE_CACHE_LIMIT_SIZE = "global.pci-cache-limit";

    public static final int DEFAULT_GLOBAL_PCI_COOKIE_CACHE_LIMIT_SIZE = DEFAULT_COOKIE_STORE_CACHE_LIMIT_SIZE;
    
    
    public static final String NAME_DATA_SOURCE = "server.store.data-source";
    public static final String DEFAULT_DATA_SOURCE = "omap";
    
    public static final String OMAP = "omap";
    public static final String DATA_SOURCE_NAME = "server.store.data-source-";
    public static final String DATA_SPACE_NAME = "server.store.spacename-";

    public static final String NAME_OMAP_DATA_SOURCE = "server.store.data-source-omap";

    public static final String DEFAULT_OMAP_DATA_SOURCE = "OmapDataSource";

    public static final String NAME_OMAP_STORE_SPACE = "server.store.spacename-omap";

    public static final String DEFAULT_OMAP_STORE_SPACE = "ydrive";

    public static final String NAME_ANALYZER_SINK_ADDRESS = "server.analyzer-sink-address";

    public static final String DEFAULT_ANALYZER_SINK_ADDRESS = "";
    
    public static final String NAME_ANALYZER_PRODUCT_NAME = "server.analyzer-product";
    public static final String DEFAULT_ANALYZER_PRODUCT_NAME = "yaccount";

    public static final String NAME_STRESS_TEST = "stress";

    public static final boolean DEFAULT_STRESS_TEST = false;
    
    public static final String NAME_GLOBAL_TESTING = "global.testing";
    
    public static final boolean DEFAULT_GLOBAL_TESTING = false;
    
    public static final String NAME_GLOBAL_DOMAIN = "global.domain";
    
    public static final boolean DEFAULT_GLOBAL_DOMAIN = false;
    
    public static final String NAME_GLOBAL_DOMAIN_NAME = "global.domain-name";
    
    public static final String DEFAULT_GLOBAL_DOMAIN_NAME = ".youdao.com";
    
    public static final String NAME_GLOBAL_TESTING_FIX_DOMAIN = "global.testing-fix-domain";
    
    public static final String DEFAULT_GLOBAL_TESTING_FIX_DOMAIN = ".corp.youdao.com";

    public static final String NAME_GLOBAL_DEBUG_ENABLED = "global.debug_enabled";

    public static final boolean DEFAULT_GLOBAL_DEBUG_ENABLED = true;

    public static final String NAME_GLOBAL_ERROR_REDIRECT_URL = "global.error_redirect_url";
    
    public static final String DEFAULT_GLOBAL_ERROR_REDIRECT_URL = "http://note.youdao.com/weibo2note-fail.html";
    
    public static final String NAME_GLOBAL_SUCCESS_REDIRECT_URL = "global.success_redirect_url";

    public static final String DEFAULT_GLOBAL_SUCCESS_REDIRECT_URL = "http://note.youdao.com/weibo2note-succ.html";
    
    public static final String NAME_GLOBAL_REGISTER_REDIRECT_URL = "global.register_redirect_url";
    
    public static final String DEFAULT_GLOBAL_REGISTER_REDIRECT_URL = "http://reg.163.com";
    
    public static final String NAME_GLOBAL_REGISTER_RETURN_URL = "global.register_return_url";
    
    public static final String DEFAULT_GLOBAL_REGISTER_RETURN_URL = "http://note.youdao.com";
    
    public static final String NAME_GLOBAL_GET_USER_META_URL = "global.get_user_meta_url";
    
    public static final String DEFAULT_GLOBAL_GET_USER_META_URL = "http://note014:8090/back/user/query";

    public static final String NAME_COOKIE_DELETE_SAFE_BUFFER_TIME = "clearcookietask.delay_in_milli";
    
    public static final String NAME_GLOBAL_URS_REGISTER_URL = "global.register-urs-url";
    public static final String DEFAULT_GLOBAL_URS_REGISTER_URL = "http://reg.163.com/services/fastRegPassport";

    // 1 days in milli
    public static final long DEFAULT_COOKIE_DELETE_SAFE_BUFFER_TIME = 24 * 60 * 60 * 1000L;

    public static final String NAME_COOKIE_DELETE_LOG = "clearcookietask.log_print";

    public static final long DEFAULT_COOKIE_DELETE_LOG = 1000;

    public static final String NAME_CROSS_PROCESS_CACHE_LIMIT = "server.cross.process_limit_size";

    public static final int DEFAULT_CROSS_PROCESS_CACHE_LIMIT = 2000;

    public static final String NAME_CROSS_PROCESS_ERROR_PAGE = "server.cross.process_error_page";

    public static final String DEFAULT_CROSS_PROCESS_ERROR_PAGE = "http://note.corp.youdao.com/404";

    public static final String NAME_CROSS_DOMAIN_CACHE_SIZE = "server.cross.domain_cache_size";

    public static final int DEFAULT_CROSS_DOMAIN_CACHE_SIZE = 2000;

    public static final String NAME_CROSS_DOMAIN_CACHE_LIMIT = "server.cross.domain_cache_limit";

    public static final int DEFAULT_CROSS_DOMAIN_CACHE_LIMIT = (int) (2000 * 0.7);

    public static final String NAME_ENABLE_VAQUERO = "server.enable.vaquero";

    public static final boolean DEFAULT_ENABLE_VAQUERO = false;

    public static final String NAME_ENABLE_ANALYZER = "server.enable.analyzer";

    public static final boolean DEFAULT_ENABLE_ANALYZER = false;
    
    public static final String NAME_RPC_SLEEP_TIME = "server.rpc.sleep";
    public static final int DEFAULT_RPC_SLEEP_TIME = 20000;
    
    public static final String NAME_RPC_SERVICE_TIMEOUT = "server.rpc.timeout";
    public static final long DEFAULT_RPC_SERVICE_TIMEOUT = 15 * 1000;
    
    public static final String NAME_RPC_CACHE_SERVER_ITEM_COUNT_LIMITS = "server.rpc.cache-limit";
    public static final int DEFAULT_RPC_CACHE_SERVER_ITEM_COUNT_LIMITS = 102400;
    
    public static final String NAME_RPC_CACHE_SERVER_ITEM_SIZE_LIMITS = "server.rpc.cache-item-size-limit";

    public static final int DEFAULT_RPC_CACHE_SERVER_ITEM_SIZE_LIMITS = 10240;
    
    public static final String NAME_RPC_CACHE_SERVER_LOAD_FACTOR = "server.rpc.load-factor";
    public static final float DEFAULT_RPC_CACHE_SERVER_LOAD_FACTOR = 0.6f;
    
    public static final String NAME_RPC_SERVICE_START = "server.rpc.start";
    public static final boolean DEFAULT_RPC_SERVICE_START = true;
    
    public static final String NAME_RPC_SERVICE_PORT = "server.rpc.port";
    public static final int DEFAULT_RPC_SERVICE_PORT = 12346;
    
    public static final String NAME_RPC_SERVICE_HANDLER_COUNT = "server.rpc.handler-count";
    public static final int DEFAULT_RPC_SERVICE_HANDLER_COUNT = 500;
    
    public static final String NAME_RPC_MAX_CONNECTION_PER_CLIENT = "server.rpc.max-conn-per-client";
    public static final int DEFAULT_RPC_MAX_CONNECTION_PER_CLIENT = 20;
    
    public static final String NAME_RPC_CLIENT_DISCONNECT_TIME = "server.rpc.client-disconnect-time";
    public static final long DEFAULT_RPC_CLIENT_DISCONNECT_TIME = 0;
    
    public static final String NAME_RPC_QUEUE_SIZE = "server.rpc.queue-size";
    public static final int DEFAULT_RPC_QUEUE_SIZE = DEFAULT_RPC_SERVICE_HANDLER_COUNT * 2;
    
    public static final String NAME_RPC_RETRIES_NUM = "server.rpc.retry";
    public static final int DEFAULT_RPC_RETRIES_NUM = 1;
    
        
    // urs phone query
    public static final String NAME_URS_PHONE_QUERY_URL = "urs.phone.query-url";
    public static final String DEFAULT_URS_PHONE_QUERY_URL = "http://reg.163.com/services/queryAliasBind";
    
    public static final String NAME_URS_LOGIN_QUERY_URL = "urs.login.query-url";
    public static final String DEFAULT_URS_LOGIN_QUERY_URL = "http://reg.163.com/services/userlogin";
    
    public static final String NAME_CHECK_URS_EXIST_URL = "urs.check-user-url";
    public static final String DEFAULT_CHECK_URS_EXIST_URL = "http://reg.163.com/services/checkUsername";
    
    public static final String NAME_PRODUCTS = "products.names";
    public static final String DEFAULT_PRODUCTS = "YNOTE;FANFAN;DICT";
    
    /**
     * for special URS token login. using URS-session cookie check
     */
    public static final String NAME_PRODUCTS_URS_TOKEN_MEMORY_CHECKS = "products.urs-token-memory-check";
    public static final String DEFAULT_PRODUCTS_URS_TOKEN_MEMORY_CHECKS = " DICT ;";
    
    public static final String NAME_CHECK_TOKEN_LENGTH = "check.token.length";
    public static final int DEFAULT_CHECK_TOKEN_LENGTH = 1024;
    
    public static final String NAME_COOKIE_PRESIST_MAX_AGE = "cookie.persist.maxage";
    /**
     * 30 days seconds
     */
    public static final int DEFAULT_COOKIE_PRESIST_MAX_AGE = 30 * 24 * 60 * 60; 
    
    public static final String NAME_COOKIE_SESS_MAX_AGE = "cookie.sess.maxage";
    /**
     * 7 days milli-seconds
     */
    public static final long DEFAULT_COOKIE_SESS_MAX_AGE = 7 * 24 * 60 * 60 * 1000;
    
    public static final String NAME_USER_INFO_EXPIRE_TIME = "cache.local.user.refresh";
    /**
     * 24 hours
     */
    public static final long DEFAULT_USER_INFO_EXPIRE_TIME = 24 * 60 * 60 * 1000L; 
    
    public static final String NAME_LOCAL_CACHE_EXPIRE_TIME = "cache.local.refresh";
    /**
     * 1 hours
     */
    public static final long DEFAULT_LOCAL_CACHE_EXPIRE_TIME = 1 * 60 * 60 * 1000L; 
    
    public static final String NAME_LOCAL_CACHE_RANDOM_EXPIRE_TIME = "cache.local.random-refresh";
    /**
     * 10 minutes
     */
    public static final long DEFAULT_LOCAL_CACHE_RANDOM_EXPIRE_TIME = 10 * 60 * 1000L; 
    /**
     * account server and other filter server should set the value both.
     */
    public static final String NAME_ENABLE_MEMCACHED_IN_FILTER = "cache.memcached.enable";
    
    public static final boolean DEFAULT_ENABLE_MEMCACHED_IN_FILTER = false;
    
    public static final String NAME_MEMCACHED_CACHE_REFRESH_TIME = "cache.memcached.refresh";
    
    /**
     * 1 hour seconds
     */
    public static final int DEFAULT_MEMCACHED_CACHE_REFRESH_TIME = 1 * 60 * 60;
    
    public static final String NAME_ENABLE_READ_DATASTORE_CACHE = "server.enable.read-cache";
    
    public static final boolean DEFAULT_ENABLE_READ_DATASTORE_CACHE = true;
    
    public static final String NAME_READ_CACHE_LIMITS = "server.read-cache.cache-limit";
    public static final int DEFAULT_READ_CACHE_LIMITS = DEFAULT_RPC_CACHE_SERVER_ITEM_COUNT_LIMITS;
    
    public static final String NAME_READ_CACHE_LOAD_FACTOR = "server.read-cache.load-factor";
    public static final float DEFAULT_READ_CACHE_LOAD_FACTOR = DEFAULT_RPC_CACHE_SERVER_LOAD_FACTOR;
    
    public static final String NAME_RPC_USE_LOCAL_SERVICE = "server.rpc.use-local-service";
    public static final boolean DEFAULT_RPC_USE_LOCAL_SERVICE = false;
    /**
     * Memcached client to be used
     */
    public static final String NAME_CACHE_MEMCACHED_CLIENT = "server.cache.memcached.client";
    public static final String DEFAULT_CACHE_MEMCACHED_CLIENT = "MemcachedClient";
    /**
     * RSA keys cache
     */
    public static final String NAME_RSA_KEY_CACHE_LIMITS = "server.rsa.cache-limit";
    public static final int DEFAULT_RSA_KEY_CACHE_LIMITS = 4096;
    
    /**
     * this is for add new plugs. for example: your has a new plugin aa.bb.cc.X and aa.bb.cc.Y. you can write aa.bb.cc.X only. 
     * The system will load X and Y automatic. And you should use ";" to split different class name which is in different package.
     */
    public static final String NAME_PLUGIN_CLASS_NAMES = "plugin.class-names";

    public static final String DEFAULT_PLUGIN_CLASS_NAMES = "";
    
    /**
     * Wait time for recoverable zookeeper operations
     */
    public static final String NAME_ZK_RECOVERABLE_WAITTIME = "zookeeper.recoverable.wait-time";
    public static final long DEFAULT_ZK_RECOVERABLE_WAITTIME = 5 * 1000;      // in millisecond
    
    // zoo keeper parameters
    public static final String NAME_ZK_SERVER_NODE = "zookeeper.server.node";
    public static final String DEFAULT_ZK_SERVER_NODE = "127.0.0.1:12499;";
    
    public static final String NAME_ZK_SESSION_TIMEOUT = "zookeeper.session.timeout";
    public static final int DEFAULT_ZK_SESSION_TIMEOUT = 60 * 1000;      // in millisecond
    
    public static final String NAME_ZK_ZNODE_ROOT = "zookeeper.znode.root";
    public static final String DEFAULT_ZK_ZNODE_ROOT = "/acc";
    
    /**
     * Lock expire time for store server, in millisecond
     */
    public static final String NAME_LOCK_EXPIRE = "server.lock-expire";
    public static final long DEFAULT_LOCK_EXPIRE = 5 * 1000;
    
    /**
     * Maximum time to wait for the consistent hash to synchronize. Start
     * a new circle of synchronization if timeout.
     */
    public static final String NAME_HASHSYNC_TIMEOUT = "server.hashsync.timeout";
    public static final long DEFAULT_HASHSYNC_TIMEOUT = DEFAULT_ZK_SESSION_TIMEOUT; // 5 seconds, the same as zk timeout
    
    public static final String NAME_ZK_ZNODE_ACCOUNT_SERVER = "zookeeper.znode.account-server-dir";
    public static final String DEFAULT_ZK_ZNODE_ACCOUNT_SERVER = "account";
    
    public static final String NAME_ZK_ZNODE_MASTER = "zookeeper.znode.master";
    public static final String DEFAULT_ZK_ZNODE_MASTER = "master";
    
    public static final String NAME_ZK_ZNODE_HASH = "zookeeper.znode.hashcircle.name";
    public static final String DEFAULT_ZK_ZNODE_HASH = "hash-circle";
    
    public static final String NAME_MASTER_PORT = "server.master.port";
    public static final int DEFAULT_MASTER_PORT = 11303;
    
    // default virtual node number of each physical node
    public static final String NAME_HASH_VNODENUM = "server.master.hash-vnodenum";
    public static final int DEFAULT_HASH_VNODENUM = 10;
    
    public static final String NAME_XSS_FILTER_TIMEOUT = "xss_filter_timeout";
    public static final long DEFAULT_XSS_FILTER_TIMEOUT = 30000;
    
    /**
     * fake stress parameters
     */
    public static final String NAME_FAKE_EXPIRE_TIME = "fake.expire";
    public static final long DEFAULT_FAKE_EXPIRE_TIME = 100000L;
    
    /**
     * task configuration
     */
    public static final String NAME_TASK_CLEAN_TOKEN_ENABLE = "task.clean-token.enable";
    public static final boolean DEFAULT_TASK_CLEAN_TOKEN_ENABLE = false;
    
    public static final String NAME_TASK_CLEAN_TOKEN_DELAY = "task.clean-token.delay";
    /**
     * delay 20 minutes
     */
    public static final long DEFAULT_TASK_CLEAN_TOKEN_DELAY = 20 * 60 * 1000L;
    
    public static final String NAME_TASK_CLEAN_TOKEN_INTERVAL = "task.clean-token.interval";
    /**
     * execute clean every 2 days
     */
    public static final long DEFAULT_TASK_CLEAN_TOKEN_INTERVAL = 2 * 24 * 60 * 60 * 1000L;
    
    public static final String NAME_TASK_CLEAN_TOKEN_EXPIRE = "task.clean-token.expire";
    /**
     * natural expired
     */
    public static final long DEFAULT_TASK_CLEAN_TOKEN_EXPIRE= -1L;
    
    public static final String NAME_DEVICE_PING_DEVIATION = "device.ping.deviation";
    public static final long DEFAULT_DEVICE_PING_DEVIATION = 10L * 60 * 1000; // 10 seconds.
    
    public static final String NAME_DEVICE_WS_NOTIFY = "device.ws.notify";
    public static final String DEFAULT_DEVICE_WS_NOTIFY = "http://note.youdao.com/yws/device_internal/notify";
    
    public static final String NAME_EVENT_NOTIFY_QUEUE_SIZE = "event.notify.queue-size";
    /**
     * natural expired
     */
    public static final long DEFAULT_EVENT_NOTIFY_QUEUE_SIZE= 10240L;
    
    /**
     * @param app
     *        app is processed by {@link #getMappingType} function
     * @param name
     * @return
     */
    public static String composeKey(String app, String name) {
        StringBuilder sb = new StringBuilder();
        sb.append(app).append('.').append(name);
        return sb.toString();
    }

    public static final String getStringProperty(String app, String name) {
        String key = composeKey(app, name);
        return authConf.getString(key, null);
    }

    public static final int getIntProperty(String app, String name) {
        String key = composeKey(app, name);
        return authConf.getInt(key, 0);
    }

    public static final long getLongProperty(String app, String name) {
        String key = composeKey(app, name);
        return authConf.getLong(key, 0);
    }

    public static final boolean getBooleanProperty(String app, String name) {
        String key = composeKey(app, name);
        return authConf.getBoolean(key, false);
    }

    /**
     * @param app
     *        app is processed by {@link #getMappingType} function
     * @return
     */
    public static final boolean checkAppName(String app) {
        return appSet.contains(app);
    }

    /**
     * use {@link #appMapping} to replace apps with real type(client, web, and
     * so on).
     * 
     * @param appName
     * @return
     */
    public static final String getMappingType(String appName) {

        return appName == null ? appName : appMapping.get(appName.trim());
    }
    /**
     * convert configure properties to string
     * @param config
     * @return
     */
    public static String configToString(Configuration config) {
        StringBuilder sb = new StringBuilder();
        for (Iterator<?> it = config.getKeys(); it.hasNext();) {
            String key = (String)it.next();
            sb.append(key).append('=').append(config.getProperty(key)).append('\n');
        }
        return sb.toString();
    }
    /**
     * get valid keys which are started with "NAME_"
     * @param clazz
     * @param keyPrefix
     * @return
     */
    public static Set<String> getValidKeys(Class<?> clazz, String keyPrefix) {
        Set<String> validKeys = new HashSet<String>();
        for (Field field: clazz.getFields()) {
            if (field.getType().equals(String.class) && field.getName().startsWith("NAME_")) {
                try {
                    validKeys.add((String) field.get(null));
                } catch (Exception e) {}
            }
        }
        return validKeys;
    }

    /**
     * get valid value which is a default value of "validkey" {@link AccConfig#getValidKeys(Class, String)}   
     * the value should be started with "DEFAULT_";
     * @param clazz
     * @param keyPrefix
     * @return
     */
    public static Object getDefaultValue(Class<?> clazz, String keyPrefix, String valuePrefix, String key) {
        for (Field field: clazz.getFields()) {
            if (field.getType().equals(String.class) && field.getName().startsWith("NAME_")) {
                try {
                    String configKey = (String) field.get(null);
                    if (key.equals(configKey)) {
                        Field defaultField = clazz.getField("DEFAULT_"
                                + field.getName().substring("NAME_".length()));
                        if (defaultField != null) {
                            return defaultField.get(null);
                        }
                    }
                } catch (Exception e) {
                    LOG.warn("Get default value error.", e);
                }
            }
        }
        return null;
    }
    
    private static final String SUCCESS_URL = ".succ-url";
    
    private static final String ERROR_URL = ".err-url";
    
    private static final String REGISTER_URL = ".reg-url";
    
    private static final String REGISTER_RETURN_URL = ".reg-ret-url";
    
    private static final String GET_USER_META_URL = ".user-meta-url";
    
    public static void configUrlMapping(String product, String nameSuffix, String defaultUrl) {
        final String successUrl = product + nameSuffix;
        authConf.setProperty(successUrl, authConf.getString(successUrl, defaultUrl));
    }
    
    public static String getUserMetaUrl(String product, String tp) {
        return getConfigUrl(product, tp, GET_USER_META_URL);
    }
    
    public static String getLoginSuccessUrl(String product, String tp) {
        return getConfigUrl(product, tp, SUCCESS_URL);
    }
    public static String getErrorUrl(String product, String tp) {
        return getConfigUrl(product, tp, ERROR_URL);
    }
    
    public static String getRegisterUrl(String product, String tp) {
        return getConfigUrl(product, tp, REGISTER_URL);
    }
    
    public static String getRegisterReturnUrl(String product, String tp) {
        return getConfigUrl(product, tp, REGISTER_RETURN_URL);
    }
    
    public static String getConfigUrl(String product, String tp, String urlSuffix) {
        if (StringUtils.isBlank(tp)) {
            return getUrl(product, urlSuffix);
        }
        String url = authConf.getString(product+"."+tp+urlSuffix);
        if (StringUtils.isBlank(url)) {
            return getUrl(product, urlSuffix);
        }
        return url;
    }
    
    public static String getUrl(String product, String suffix) {
        return authConf.getString(product + suffix);
    }
    
    public static void checkProduct(String product) throws AccException {
        if (!productSet.contains(product)) {
            throw new AccException(AccExpType.NO_SUCH_PRODUCT, "product %s is not exist.", product);
        }
    }
    
    public static void checkURSTokenMemoryProduct( String product) throws AccException {
        if (!productUrsMemoryCheckSet.contains(product)) {
            throw new AccException(AccExpType.NO_SUCH_PRODUCT, "product %s can not using urs token memory check.", product);
        }
    }
}
