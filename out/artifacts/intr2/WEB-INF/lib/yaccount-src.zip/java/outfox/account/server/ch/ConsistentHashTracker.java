/**
 * @(#)ConsistentHashTracker.java, 2011-7-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.ch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;

import outfox.account.conf.AccConfig;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.zk.RetriableZKOperation;
import outfox.account.server.zk.Serviceable;
import outfox.account.server.zk.ZooKeeperWatcher;
import outfox.account.utils.ConsistentHash;

/**
 * Keeps track of the consistent hash in zookeeper.
 *
 * <p>Listens to ZooKeeper notifications <code>NodeDataChanged</code>
 * on consistent hash znode and keeps track of consistent hash synchronization
 * status.
 *
 * @author licx
 */
public class ConsistentHashTracker extends ConsistentHashSynchronizer {
    private static final Log LOG = LogFactory.getLog(ConsistentHashTracker.class);

    /**
     * @param watcher
     */
    public ConsistentHashTracker(Serviceable service, ZooKeeperWatcher watcher,
            int serverNum) {
        super(service, watcher, serverNum);
        watcher.registerListener(this);
    }

    @Override
    public void start() throws AccException {
        try {
            updateLocalHashCircle();
        } catch (KeeperException e) {
            throw new AccException("update local HashCircle error",
                    AccExpType.UPDATE_LOCAL_HASH_CIRCLE_FAILED);
        }
    }

    @Override
    public void nodeDataChanged(String path) {
        if (path.equals(watcher.consistentHashZNode) && !service.isStopped()) {
            // consistent hash circle znode is reset by the master so previous
            // consistent hash is out of date, if there is a synchronization
            // ongoing, interrupt the previous synchronization and start a new one
            obsolete.set(true);
            updated.set(false);
            synchronized (updated) {
                updated.notifyAll();
            }
            LOG.info("Consistent hash circle is updated by master, " +
                "start to update the consistent hash...");
            // update the consistent hash circle in another thread because
            // the synchronization might take sometime and this method is
            // supposed to return fast
            new RetriableZKOperation(getClass().getSimpleName(), service) {
                @Override
                public void execute() throws KeeperException {
                    updateLocalHashCircle();
                }
            }.start();
        } else {
            super.nodeDataChanged(path);
        }
    }

    /**
     * Updates local consistent hash circle when the master updates consistent
     * hash in zookeeper. This method would not return until the consistent
     * hash is synchronized over the cluster.
     * 
     * @throws AccException 
     * @throws KeeperException 
     */
    private void updateLocalHashCircle() throws KeeperException {
        hashCircleLock.writeLock().lock();
        try {
            ConsistentHash currentHashCircle = getCurrentHashCircle();
            obsolete.set(false);
            if (currentHashCircle == null ||
                    currentHashCircle.getVersion() == hashCircle.getVersion()) {
                LOG.info("Consistent hash circle is not changed, "
                        + "version=" + hashCircle.getVersion());
                return;
            }

            // blocking to wait for the synchronization. Do nothing if the
            // synchronization timeout because master will trigger another
            // synchronization later
            long timeout = AccConfig.getPros().getLong(
                    AccConfig.NAME_HASHSYNC_TIMEOUT);
            blockUntilSynchronized(timeout);
        } finally {
            hashCircleLock.writeLock().unlock();
        }
    }
}
