/**
 * @(#)FakeAnalyzerLog.java, 2012-2-1. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.log;

import java.util.Enumeration;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import account.app.CheckFilter;
/**
 * print analyzer log into local log
 *
 * @author chen-chao
 *
 */
public class FakeAnalyzerLog {
    private static final Log LOG = LogFactory.getLog(FakeAnalyzerLog.class);
    public static void print(String category, HttpServletRequest req, HttpServletResponse resp, Set<String> visiables, Set<String> unlogged){
     // copied from RequestLogger
        StringBuilder buffer = new StringBuilder("@@ANALYSIS@@ ");
        buffer.append("\t");

        buffer.append(category);
        buffer.append("\t[username=");
        String userName = (String) req.getAttribute(CheckFilter.EMAIL_ATTR);
        buffer.append(userName);
        buffer.append("]");
        for (Enumeration<?> attrNames = req.getParameterNames(); attrNames.hasMoreElements();) {
            String attrName = (String) attrNames.nextElement();
            if (!unlogged.contains(attrName)) {
                String value = req.getParameter(attrName);
                buffer.append("\t");
                buffer.append(escape(attrName));
                buffer.append("=");
                buffer.append(escape(value));
            }
        }
        for (Enumeration<?> attrNames = req.getAttributeNames(); attrNames.hasMoreElements();) {
            String attrName = (String) attrNames.nextElement();
            if (visiables.contains(attrName)) {
                buffer.append("\t[@");
                buffer.append(escape(attrName));
                buffer.append("=");
                buffer.append(escape(req.getAttribute(attrName).toString()));
                buffer.append("]");
            }
        }
        LOG.info(buffer.toString());
    }
    
    private static String escape(String text) {
        if (text == null) {
            return "NULL";
        }
        int length = text.length();
        StringBuilder buffer = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            char ch = text.charAt(i);
            switch (ch) {
                case '\t':
                    buffer.append("\\t");
                    break;
                case '\n':
                    buffer.append("\\n");
                    break;
                case '\r':
                    buffer.append("\\r");
                    break;
                case '[':
                    buffer.append("\\[");
                    break;
                case ']':
                    buffer.append("\\]");
                    break;
                case '\\':
                    buffer.append("\\\\");
                    break;
                default:
                    buffer.append(ch);
            }
        }
        return buffer.toString();
    }
}
