/**
 * @(#)DeviceEvent.java, 2013-6-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device;

import java.util.EventListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.device.DeviceInfoWritable;
import outfox.account.device.listener.IDeviceEventListener;
import outfox.account.exceptions.AccException;
import outfox.account.logic.event.AccEvent;

/**
 * @author chen-chao, zhanglz
 */
public class DeviceEvent extends AccEvent{
    private static final long serialVersionUID = -7400435476934269551L;
    private static final Log LOG = LogFactory.getLog(DeviceEvent.class);
    private String deviceId;
    private String userId;
    private String product;
    private DeviceStatus from;
    private DeviceStatus to;
    private OPERATOR op;
    private DeviceInfoWritable deviceInfo;
    
    public DeviceEvent(Object source, String userId, String deviceId, 
            String product, DeviceStatus from, DeviceStatus to, OPERATOR op) {
        super(source);
        this.userId = userId;
        this.deviceId = deviceId;
        this.product = product;
        this.from = from;
        this.to = to;
        this.op = op;
    }

    @Override
    public void notify(EventListener obj) throws AccException {
        // notify device status changes.
        if (obj instanceof IDeviceEventListener) {
            IDeviceEventListener listener = (IDeviceEventListener) obj;
            listener.handleEvent(this);
        }
    }
    
    @Override
    public void process() throws AccException {
        // update device status.
        DeviceStore store = DeviceStore.getInstance();
        store.updateDeviceStatus(product, userId, deviceId, to);
        // update device info if there is any.
        if (null != deviceInfo) {
            store.updateDeviceInfo(deviceInfo);
        }
        LOG.info("Device status changed: " + dump());
    }
    
    public String getDeviceId() {
        return deviceId;
    }

    public String getUserId() {
        return userId;
    }

    public String getProduct() {
        return product;
    }

    public DeviceStatus getFrom() {
        return from;
    }

    public DeviceStatus getTo() {
        return to;
    }

    public OPERATOR getOp() {
        return op;
    }
    
    public String dump() {
        return "userId=" + userId + ", deviceId=" + deviceId + ", from=" + from.name()
        + ", to=" + to.name() + ", op=" + op.name();
    }
    
    public void setDeviceInfo(DeviceInfoWritable deviceInfo) {
        this.deviceInfo = deviceInfo;
    }
}
