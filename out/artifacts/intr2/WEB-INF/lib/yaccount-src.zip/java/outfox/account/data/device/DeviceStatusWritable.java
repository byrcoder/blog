/**
 * @(#)DeviceStatus.java, 2013-5-30. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data.device;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.lib.StringWritable;
import outfox.account.data.AbstractWritable;
import outfox.account.device.DeviceStatus;

/**
 * @author chen-chao
 */
public class DeviceStatusWritable extends AbstractWritable {
    private static final long serialVersionUID = 5992836445031366310L;
    private String product;
    private String userId;
    private String deviceId;
    private DeviceStatus status;
    public DeviceStatusWritable() {}
    
    
    /**
     * @param product
     * @param userId
     * @param deviceId
     * @param status
     */
    public DeviceStatusWritable(String product, String userId, String deviceId,
            DeviceStatus status) {
        super();
        this.product = product;
        this.userId = userId;
        this.deviceId = deviceId;
        this.status = status;
    }


    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * @param deviceId the deviceId to set
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * @return the status
     */
    public DeviceStatus getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(DeviceStatus status) {
        this.status = status;
    }

    @Override
    protected void readFieldsInner(DataInput in) throws IOException {
        product=  StringWritable.readStringNull(in);
        userId=  StringWritable.readStringNull(in);
        deviceId=  StringWritable.readStringNull(in);
        status = DeviceStatus.valueOf(in.readShort());
    }

    @Override
    protected void writeFieldsInner(DataOutput out) throws IOException {
        StringWritable.writeStringNull(out, product);
        StringWritable.writeStringNull(out, userId);
        StringWritable.writeStringNull(out, deviceId);
        out.writeShort(status.getState());
    }

}
