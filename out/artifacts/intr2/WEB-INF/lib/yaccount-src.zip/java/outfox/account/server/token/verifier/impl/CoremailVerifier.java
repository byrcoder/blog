/**
 * @(#)CoremailVerifier.java, 2013-2-25. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.AccCookies;
import outfox.account.data.Parameter;
import outfox.account.data.TpToken;
import outfox.account.data.coremail.CoremailAPI;
import outfox.account.data.coremail.CoremailDataWritable;
import outfox.account.data.coremail.CoremailReturnInfo;
import outfox.account.data.user.CoremailUserInfoWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.logic.EmailRedirect;
import outfox.account.server.token.TokenUtils;
import outfox.account.server.token.verifier.ITokenVerifier;
import outfox.account.server.token.verifier.Verifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class CoremailVerifier extends Verifier implements ITokenVerifier {
    public static final String NAME = "coremail";
    public CoremailVerifier(Properties props) {
        super(props);
    }

    @Override
    public String getVerifierName() {
        return NAME;
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        AuthUtils.checkHttpsProtocal(req);
        ReqUtils.checkParam(req, AccConst.PARAM_COREMAIL_SID, ReqUtils.NO_MISS);
        ReqUtils.checkParam(req, AccConst.PARAM_COREMAIL_USERID, ReqUtils.NO_MISS);
        
        final String sid = req.getParameter(AccConst.PARAM_COREMAIL_SID);
        final String coremailUserId = req.getParameter(AccConst.PARAM_COREMAIL_USERID);
        String domain = EmailRedirect.getDomain(coremailUserId);
        final String product = AuthUtils.getReqParamVal(req, AccConst.PARAM_PRODUCT_NAME,
                AccConst.PARAM_PRODUCT_DEFALUT_VALUE);
        LOG.info(String.format("product=%s, domain=%s, sid=%s, email=%s want login by coremail API.",
                product, domain, sid, coremailUserId));
        
        String ursProduct = AuthUtils.getReqParamVal(req, AccConst.PARAM_URS_PRODUCT_NAME,
                AccConst.PARAM_URS_PRODUCT_DEFAULT_VALUE);
        Map<String,String> tokens = new HashMap<String,String>();
        tokens.put(AccConst.TOKEN, sid);
        tokens.put(AccConst.OPEN_ID, coremailUserId);
        tokens.put(AccConst.URS_PRODUCT, ursProduct);
        tokens.put(AccConst.PRODUCT, product);
        UserInfoWritable userInfo = getUserInfo(tokens);
        Map<String,Object> retMap = new HashMap<String, Object>();
        if (userInfo == null) {
            // check URS is exist or not
            URSCheckAccountReturn checkInfo = getAccountExistInfo(coremailUserId, ursProduct);
            boolean registerNow = AuthUtils.getReqBoolean(req, AccConst.PARAM_REGISTER, true);
            if (!checkInfo.isExist && registerNow) {
                // register
                retMap.put(AccConst.REGISTER, AccConst.REGISTER);
                retMap.put(AccConst.RETURN_STR, urlParam(checkInfo.returnCode, coremailUserId, sid));
                return retMap;
            } else {
                throw new AccException(AccExpType.NO_LOGIN, "user %s is not exist. should login first.", coremailUserId);
            }
        } 
        store.writeUserInfo(userInfo);
        shouldPutUserInfoInReturnInfo(retMap, AuthUtils.getReqInt(req, AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value()), userInfo);
        TpToken tp = new TpToken();
        tp.userId = coremailUserId;
        tp.setExpiredTime(-1L);
        tp.token = sid;
        tp.product = product;
        String app = AuthUtils.getReqVal(req, AccConst.PARAM_APP_NAME);
        if (StringUtils.isNotBlank(app)) {
            tp.app = app;
        } else {
            tp.app = AccConfig.CLIENT_TYPE_WEB;
        }
        tp.verifierName = NAME;
        TokenUtils.genCompleteTpToken(this, tp);
        AccCookies cookies = TokenUtils.tpTokenGenCookie(req, resp, retMap, tp);
        // no persist cookie.
        cookies.setPersCookie(null);

        return retMap;
    }
    
    /**
     * @param req
     * @param returnCode
     * @return
     * @throws AccException 
     */
    private String urlParam(String returnCode,
            String userId, String token) throws AccException {
        StringBuilder url = new StringBuilder("sid=");
        url.append(token);
        url.append("&domain=");
        url.append(EmailRedirect.getDomain(userId));
        url.append("&userid=");
        url.append(userId);
        url.append("&code=");
        url.append(returnCode);
        return url.toString();
    }
    
    /**
     * yyyy-mm-dd hh:mm:ss
     * @param dateStr
     * @return
     * @throws AccException 
     */
    private long getTime(String dateStr) throws AccException {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
            return format.parse(dateStr).getTime();
        } catch(Exception e) {
            throw new AccException(String.format("dataStr is %s. is not yyyy-mm-dd hh:mm:ss", dateStr), AccExpType.ENCODING_ERROR);
        }
        
    }
    
    @Override
    public UserInfoWritable getUserInfo(Map<String,String> tokens) throws AccException {
        String coremailId = tokens.get(AccConst.OPEN_ID);
        String coremailToken = tokens.get(AccConst.TOKEN);
        String ursProduct = tokens.get(AccConst.URS_PRODUCT);
        String product = tokens.get(AccConst.PRODUCT);
        if (StringUtils.isBlank(ursProduct)) {
            ursProduct = AccConst.PARAM_URS_PRODUCT_DEFAULT_VALUE;
        }
        if (StringUtils.isBlank(product)) {
            product = AccConst.PARAM_PRODUCT_DEFALUT_VALUE;
        }
       
        String domain = EmailRedirect.getDomain(coremailId);
        if (isURSDomain(domain)) {
            throw new AccException(AccExpType.COREMAIL_API_ERROR, "fake userId %s. Can not use netease domain.", coremailId);
        }
        
        CoremailDataWritable coremailData = getWsdlUrl(domain);
        String wsdlURL = coremailData.getWsdlURL();
        String userId = getUserMailAddress(coremailToken, wsdlURL);
        if (userId == null || !userId.equals(coremailId)) {
            throw new AccException(AccExpType.COREMAIL_SID_ERROR,
                    "coremail return userid is %s. request userid is %s. Thses are not same.", userId,
                    coremailId);
        }
        // check URS is exist or not
        URSCheckAccountReturn checkInfo = getAccountExistInfo(coremailId, ursProduct);
        if (checkInfo.isExist) {
            // check PRODUCT register time.
            //init coremail api
            CoremailAPI api = getCoremailAPI(wsdlURL);
            CoremailReturnInfo ret = api.getAttrs(coremailId, "user_creation_date");
            
            //get coremail user creatation time
            if (ret.getCode() != 0) {
                throw new AccException(AccExpType.COREMAIL_API_ERROR, "coremail api user_creation_date error. request url:%s, return:%s",wsdlURL,ret);
            } 
            String coremailCreateDate = "";
            try {
                
                coremailCreateDate = URLDecoder.decode(
                        ret.getResult().split("=")[1], AccConst.UTF8);
            } catch (UnsupportedEncodingException e) {
                throw new AccException(AccExpType.ENCODING_ERROR,"return string %s, can not decode.", ret);
            }
            
            long ynoteRegisterTime = getYnoteRegisterTime(product, coremailId);
            long coremailRegisterTime = getTime(coremailCreateDate);
            
            //if coremail create time is older than ynote create time, someone reuse the account. 
            if (coremailRegisterTime > ynoteRegisterTime) {
                // someone want to reuse the account.
                throw new AccException(
                        AccExpType.COREMAIL_USER_REUSE_ERROR,"user %s reuse",coremailId);
            } 
            return new CoremailUserInfoWritable(coremailId);
        }
        return null;
    }
    
    private long getYnoteRegisterTime(String product, String userId) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("user", userId));
        String getUserMetaUrl = AccConfig.getUserMetaUrl(product, NAME);
        JSONObject obj = AccHttpClient.getInstance().getJSON(Method.GET, getUserMetaUrl, null, params, null);
        if (obj.containsKey("rt")) {
            return obj.getLong("rt");
        }
        
        return Long.MAX_VALUE;
    }
    
    /**
     * @param req
     * @return
     * @throws YDriveException
     */
    public static CoremailDataWritable getWsdlUrl(String domain)
            throws AccException {
        return DataStore.getInstance().readCoremailData(domain);
    }
    /**
     * @param id
     * @return
     * @throws IOException
     * @throws UnknownHostException
     * @throws AuthException
     */
    public static String getUserMailAddress(String sid, String url)
            throws AccException {
        CoremailAPI api = getCoremailAPI(url);
        CoremailReturnInfo ret = api.sesTimeOut(sid);
        if (ret.getCode() == 0) {
            return AuthUtils.getParameter(ret.getResult(), "uid");
        } else {
            throw new AccException(AccExpType.COREMAIL_SID_ERROR, "session id %s error. ret is :%s.", sid, ret);
        }
    }
    
    private static CoremailAPI getCoremailAPI(String url) throws AccException {
        try {
            return Service.create(
                    new URL(url),
                    new QName(AccConst.COREMAIL_API_URL,
                            AccConst.PARAM_API_NAME))
                    .getPort(CoremailAPI.class);
        } catch (MalformedURLException e) {
            throw new AccException(AccExpType.LOGIC_ERROR, "coremail api url error:%s.",url);
        }
    }
    
    private boolean isURSDomain(String domain) {
        return EmailRedirect.getEmailDomainMap().containsKey(domain);
    }
    
    private static class URSCheckAccountReturn {
        boolean isExist;
        String returnCode;
        public URSCheckAccountReturn(boolean isExist, String returnCode) {
            this.isExist = isExist;
            this.returnCode = returnCode;
        }
        
    }
    
    private URSCheckAccountReturn getAccountExistInfo(String userMail, String ursProduct) throws AccException {
        String checkUrl = AccConfig.getPros().getString(AccConfig.NAME_CHECK_URS_EXIST_URL);
        String result = AccHttpClient.getInstance().getString(Method.GET, checkUrl, null,
                createCheckParam(userMail,ursProduct), null);
        if (result == null) {
            throw new AccException(AccExpType.URS_CHECK_EXIST_ERROR,
                    "check account exist in URS api %s error.", checkUrl);
        }
        LOG.info("check account exist in URS api return:"+result);
        String[] returnInfos = result.split(AccConst.NEW_LINE);
        
        return new URSCheckAccountReturn(AccConst.URS_CODE_OK.equals(returnInfos[0]),
                returnInfos.length >= 2 ? returnInfos[0] + returnInfos[1] : returnInfos[0]);
    }
    
    private List<Parameter> createCheckParam(
            String userMail, String ursProduct) {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("username", userMail));
        params.add(new Parameter("product", ursProduct));
        return params;
    }
}
