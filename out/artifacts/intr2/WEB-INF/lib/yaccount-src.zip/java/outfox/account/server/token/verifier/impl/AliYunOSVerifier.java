/**
 * @(#)AliYunOSVerifier.java, 2013-8-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.data.user.AliYunOSUserInfoWritable;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.server.token.verifier.IOauthVerifier;
import outfox.account.server.token.verifier.Verifier;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * the life of Session cookie may be shorter than usual (7 days).
 * @author chen-chao
 */
public class AliYunOSVerifier extends Verifier implements IOauthVerifier{
    private String baseUrl;
    private String appKey;
    private String appSecret;
    static final String YUN_STATUS = "status";
    static final String YUN_MESS = "message";
    static final String YUN_DATA = "data";
    static final String YUN_KP = "kp";
    static final String YUN_LOGINID = "loginId";
    static final String YUN_API = "api";
    static final String YUN_KEY = "key";
    static final String YUN_TIMESTAMP = "timestamp";
    static final String YUN_SIGN =  "sign";
    static final String YUN_VERSION = "v";
    static final String YUN_ACCESS_TOKEN ="access_token";
    static final String YUN_USER_ID_API = "account.get_loginid_by_access_token";
    public AliYunOSVerifier(Properties props) {
        super(props);
        baseUrl = getAndCheck(props, NAME + VerifierConfConst.BASE_URL);
        appKey = getAndCheck(props, NAME + VerifierConfConst.KEY);
        appSecret = getAndCheck(props, NAME + VerifierConfConst.SECRET);
        idPattern = getAndCheck(props, NAME + VerifierConfConst.ID);
    }

    private static final String NAME = "yunos";
    @Override
    public String getVerifierName() {
        return NAME;
    }

    @Override
    public Map<String, Object> authRequest(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        throw new AccException("not support", AccExpType.NOT_SUPPORT);
    }

    @Override
    public Map<String, Object> getAuthInfo(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        throw new AccException("not support", AccExpType.NOT_SUPPORT);
    }

    @Override
    public Map<String, Object> removeAuthToken(Map<String, Object> authInfo) throws AccException {
        throw new AccException("not support", AccExpType.NOT_SUPPORT);
    }
    
    public static String genSign(List<Parameter> params, String secret) {
        Collections.sort(params);
        StringBuilder sb = new StringBuilder();
        for(Parameter p : params) {
            sb.append(p.getKey()).append(p.getStrVal());
        }
        sb.append(secret);
        return DigestUtils.md5Hex(sb.toString());
    }

    @Override
    public UserInfoWritable getUserInfo(Map<String, String> thirdPartyTokens) throws AccException {
        if (thirdPartyTokens == null) {
            throw new AccException("no token, can not get userinfo", AccExpType.FAKE_TOKEN);
        }
        if (AccConfig.isStressTest()) {
            return genStressUser();
        }
        
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(YUN_API, YUN_USER_ID_API));
        params.add(new Parameter(YUN_TIMESTAMP,System.currentTimeMillis()/1000));
        params.add(new Parameter(YUN_ACCESS_TOKEN, thirdPartyTokens.get(AccConst.TOKEN)));
        params.add(new Parameter(YUN_KEY, appKey));
        params.add(new Parameter(YUN_VERSION, 1));
        params.add(new Parameter(YUN_SIGN, genSign(params, appSecret)));
        JSONObject obj = AccHttpClient.getInstance().getJSON(Method.POST, baseUrl, null,
                params, null);
        throwAPIError(obj);
        JSONObject data = obj.getJSONObject(YUN_DATA);
        String id = data.getString(YUN_KP);
        return new AliYunOSUserInfoWritable(tpId2ownId(id), id, obj);
    }
    private void throwAPIError(JSONObject obj) throws AccException {
        int ret = obj.getInt(YUN_STATUS);
        if (200 != ret) {
            throw new AccException(obj.toString(), null, AccExpType.TP_ERROR, ret);
        }
    }
}
