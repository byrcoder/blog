/**
 * @(#)ActiveMasterManager.java, 2011-7-6. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.ch;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.zookeeper.KeeperException;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.rpc.ServerAddress;
import outfox.account.server.zk.RetriableZKOperation;
import outfox.account.server.zk.ZooKeeperListener;
import outfox.account.server.zk.ZooKeeperWatcher;
import outfox.account.utils.ZKUtils;

/**
 * Handles everything on master-side related to master election.
 *
 * <p>Listens and responds to ZooKeeper notifications on the master znode,
 * both <code>NodeCreated</code> and <code>NodeDeleted</code>.
 *
 * <p>Contains blocking methods which will hold up backup masters, waiting
 * for the active master to fail.
 *
 * <p>This class is instantiated in the YMaster constructor and the method
 * {@link #blockUntilBecomingActiveMaster()} is called to wait until becoming
 * the active master of the cluster.
 *
 * @author licx
 */
public class ActiveMasterManager extends ZooKeeperListener {
    private static final Log LOG = LogFactory.getLog(ActiveMasterManager.class);

    // whether there is an active master right now, notify thread waiting to be active manager when set to false.
    final AtomicBoolean hasActiveMaster = new AtomicBoolean(false);

    // Master service
    private final YMaster master;
    // Server address of master
    private final ServerAddress address;

    /**
     * @param watcher
     * @param masterAddr
     * @param master
     */
    ActiveMasterManager(ZooKeeperWatcher watcher, YMaster master,
            ServerAddress address) {
        super(watcher);
        this.master = master;
        this.address = address;
    }

    @Override
    public void start() throws AccException {
        try {
            blockUntilBecomingActiveMaster();
        } catch (KeeperException e) {
            throw new AccException(
                    "Fail to start ActiveMasterManager", e);
        }
    }

    @Override
    public void stop() {
        try {
            // If our address is in ZK, delete it on our way out
            byte[] bytes = ZKUtils.getData(watcher, watcher.masterAddressZNode);
            if (bytes == null) {
                // master is another server and that server has been stopped
                return;
            }
            ServerAddress masterAddr = new ServerAddress(
                    new String(bytes, ZKUtils.ZK_ENCODING));
            if (masterAddr != null && masterAddr.equals(address)) {
                ZKUtils.deleteNodeFailSilent(watcher, watcher.masterAddressZNode);
            }
        } catch (Throwable e) {
            LOG.warn("Ignore errors when stopping the active master manager");
        }
        super.stop();
    }

    /**
     * Block until becoming the active master.
     *
     * Method blocks until there is not another active master and our attempt
     * to become the new active master is successful. We are watching the
     * master znode so will be notified if another master dies.
     *
     * @return True if no issue becoming active master else false if another
     * master was running or if some other problem (e.g. stop flag has been
     * set on this master)
     *
     * @throws KeeperException 
     */
    boolean blockUntilBecomingActiveMaster() throws KeeperException {
        try {
            if (ZKUtils.createEphemeralNodeAndWatch(watcher,
                    watcher.masterAddressZNode,
                    address.toString().getBytes(ZKUtils.ZK_ENCODING))) {
                // write master address successfully, we are the master
                LOG.info("Successfully registered as active master, "
                        + "master=" + address);
                hasActiveMaster.set(true);
                return true;
            }

            hasActiveMaster.set(true);
            // current master address
            byte [] bytes = ZKUtils.getDataAndWatch(watcher,
                    watcher.masterAddressZNode);
            ServerAddress masterAddr = new ServerAddress(
                    new String(bytes, ZKUtils.ZK_ENCODING));
            if (masterAddr.equals(address)) {
                // master restart but the master address znode has not been expired
                LOG.warn("Current master has this server address, " + masterAddr +
                        "; master was restarted?  Waiting on znode to expire...");
                // manually delete the master address znode and re-compete
                ZKUtils.deleteNode(watcher, watcher.masterAddressZNode);
            } else {
                // another server became the active master
                LOG.info("Another master is the active master " + masterAddr +
                        "; will be waiting to become the next active master");
            }
        } catch (UnsupportedEncodingException e) {
            // should never come to here
            LOG.fatal("ZooKeeper does not support encoding " + ZKUtils.ZK_ENCODING, e);
            throw new AccRunTimeException("Unsupported zookeeper encoding", e);
        }

        synchronized (hasActiveMaster) {
            while (hasActiveMaster.get() && !master.isStopped()) {
                try {
                    hasActiveMaster.wait();
                } catch (InterruptedException e) {
                    throw new AccRunTimeException(
                            "Interrupted waiting for master to die", e);
                }
            }
            if (master.isStopped()) {
                return false;
            }
        }
        // Try to become active master again now that there is no active master
        return blockUntilBecomingActiveMaster();
    }

    @Override
    public void nodeCreated(String path) {
        if (path.equals(watcher.masterAddressZNode) && !master.isStopped()) {
            new RetriableZKOperation(getClass().getSimpleName(), master) {
                @Override
                public void execute() throws KeeperException {
                    handleMasterNodeChange();
                }
            }.start();
        }
    }

    @Override
    public void nodeDeleted(String path) {
        if (path.equals(watcher.masterAddressZNode) && !master.isStopped()) {
            new RetriableZKOperation(getClass().getSimpleName(), master) {
                @Override
                public void execute() throws KeeperException {
                    handleMasterNodeChange();
                }
            }.start();
        }
    }

    /**
     * Handle a change in the master node.
     *
     * <p>Uses the checkExistsAndWatch method which watches the master address node
     * regardless of whether it exists or not.  If it does exist (there is an
     * active master), it returns true.  Otherwise it returns false.
     *
     * <p>A watcher is set which guarantees that this method will get called again if
     * there is another change in the master node.
     * @throws KeeperException 
     */
    private void handleMasterNodeChange() throws KeeperException {
        synchronized (hasActiveMaster) {
            if (ZKUtils.checkExistsAndWatch(watcher, watcher.masterAddressZNode)) {
                // A master node exists, there is an active master
                LOG.debug("A master is now available");
                hasActiveMaster.set(true);
            } else {
                // Node is no longer there, cluster does not have an active
                // master
                LOG.debug("No master available. Notifying waiting threads");
                hasActiveMaster.set(false);
                // Notify any thread waiting to become the active master
                hasActiveMaster.notifyAll();
            }
        }
    }
}
