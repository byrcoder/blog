/**
 * @(#)AbstractOauthWritable.java, 2011-11-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.json.JSONObject;
import odis.serialize.IWritable;
import odis.serialize.lib.ByteArrayWritable;
import odis.serialize.lib.StringPropertiesWritable;
import odis.serialize.lib.StringWritable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import outfox.account.utils.WritableUtils;

/**
 * This class supplies a property and some common methods, in order to construct
 * a subClass of IWritable easily. SubClass no need to care about the property
 * field.
 * 
 * @author chen-chao
 */
public abstract class AbstractWritable implements IWritable, Serializable {
    private static final long serialVersionUID = 1177111234947256853L;

    private static final Log LOG = LogFactory.getLog(AbstractWritable.class);

    /**
     * reserved properties
     */
    private StringPropertiesWritable properties;
    
    private Map<String, ByteArrayWritable> byteProperties;
    public AbstractWritable() {
        initProperties(null);
    }

    public AbstractWritable(List<Parameter> paraList) {
        initProperties(paraList);
    }

    @Override
    public IWritable copyFields(IWritable other) {
        return WritableUtils.copyTo(other, this);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        readFieldsInner(in);
        properties.clear();
        properties.readFields(in);
        byteProperties.clear();
        int size = in.readInt();
        for (int i = 0; i < size; i++) {
            byteProperties.put(StringWritable.readString(in), 
                    new ByteArrayWritable(ByteArrayWritable.readByteArray(in)));
        }
    }
 
    /**
     * this method will be execute in readFields, after executing the method,
     * {@link #properties} and {@link #byteProperties} will be read.
     * @param in
     * @throws IOException
     */
    protected abstract void readFieldsInner(DataInput in) throws IOException;

    /**
     * this method will be execute in writeFields, after executing the method,
     * {@link #properties} and {@link #byteProperties} will be written.
     * @param out
     * @throws IOException
     */
    protected abstract void writeFieldsInner(DataOutput out) throws IOException;

    @Override
    public void writeFields(DataOutput out) throws IOException {
        writeFieldsInner(out);
        properties.writeFields(out);
        out.writeInt(byteProperties.size());
        for (Map.Entry<String, ByteArrayWritable> entry: byteProperties.entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            entry.getValue().writeBytes(out);
        }
    }

    /**
     * if toString() method dosen't work, a string "" will return.
     */
    @Override
    public String toString() {
        try {
            return WritableUtils.toString(this);
        } catch (Exception e) {
            LOG.error("ConvertString error");
        }
        return "";
    }
    
    public JSONObject toJson() {
        try {
            return WritableUtils.toJSONObject(this);
        } catch (Exception e) {
            LOG.error("ConvertString error");
        } 
        return new JSONObject();
    }

    /**
     * init properties by paraList
     * 
     * @param paraList
     */
    private void initProperties(List<Parameter> paraList) {
        properties = new StringPropertiesWritable();
        if (paraList != null && paraList.size() != 0) {
            for (Parameter p: paraList) {
                properties.put(p.getKey(), p.getStrVal());
            }
        }
        byteProperties = new HashMap<String, ByteArrayWritable>();
    }

    public void setProperty(String name, String value) {
        this.properties.put(name, value);
    }
    
    public void setBooleanProperty(String key, boolean value) {
        this.properties.put(key, Boolean.toString(value));
    }
    
    public boolean getBooleanProperty(String key) {
        return Boolean.parseBoolean(properties.get(key));
    }

    public String getProperty(String name) {
        return properties.get(name);
    }

    public List<Parameter> getProperties() {
        List<Parameter> list = new ArrayList<Parameter>();
        for (Entry<String, String> entry: properties.entrySet()) {
            list.add(new Parameter(entry.getKey(), entry.getValue()));
        }
        return list;
    }
    
    public Map<String,String> getPropertiesMapCopy() {
        return new HashMap<String,String>(properties);
    }

    public void setProperties(List<Parameter> param) {
        if (param != null) {
            for (Parameter p: param) {
                properties.put(p.getKey(), p.getStrVal());
            }
        }
    }
    
    public void setLongProperty(String key, Long l) {
        if (l != null) {
            properties.put(key, l.toString());
        }
    }
    
    public long getLongProperty(String key) {
        String value = properties.get(key);
        if (value != null) {
            return Long.parseLong(value);
        }
        return 0L;
    }
    
    public void setByteProperty(String key, byte[] bytes) {
        if (bytes != null) {
            byteProperties.put(key, new ByteArrayWritable(bytes));
        }
        
    }
    
    public byte[] getByteProperty(String key) {
        ByteArrayWritable byteArray =  byteProperties.get(key);
        if (byteArray != null) {
            return byteArray.getBytes();
        } 
        return null;
    }
    
    public Map<String, ByteArrayWritable> getBytePropertiesCopy() {
        return new HashMap<String, ByteArrayWritable>(byteProperties);
    }
}
