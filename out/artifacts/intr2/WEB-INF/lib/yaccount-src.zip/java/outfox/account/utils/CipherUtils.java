/**
 * @(#)CipherUtils.java, 2013-1-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.UnsupportedEncodingException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.conf.AccConst.CIPHER_TYPE;
import outfox.account.data.CookieIndex;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;

/**
 * @author chen-chao
 */
public class CipherUtils {
    protected static final Log LOG = LogFactory.getLog(CipherUtils.class);
    public static final String AES = "AES";

    public static final String RSA = "RSA";

    public static final String BC_PROVIDER = "BC";

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    /**
     * ALL parameter is Hex string.
     * @param type
     * @param contentHex
     * @param secretHex
     * @param ivHex
     * @return
     * @throws AccException 
     */
    public static String aesDecryptHex(CIPHER_TYPE type, String contentHex, String secretHex, String ivHex)
            throws AccException {
        return new String(aesDecrypt(type, AuthUtils.strHex(contentHex), AuthUtils.strHex(secretHex),
                AuthUtils.strHex(ivHex))).trim();
    }

    /**
     * The function is only used in client AES check. It will not be used for urs AES.
     * @param type
     * @param content
     * @param secret
     * @throws AccException 
     */
    public static byte[] aesDecrypt(CIPHER_TYPE type, byte[] content, byte[] secret, byte[] iv)
            throws AccException {
        if (type == null) {
            type = CIPHER_TYPE.AES_DEFAULT;
        }
        SecretKeySpec key = new SecretKeySpec(secret, AES);
        Cipher cipher = null;
        if (secret == null || secret.length != 16) {
            throw new AccException("secret length is not 128 bit.", AccExpType.NOT_SUPPORT);
        }
        try {
            switch (type) {
                case AES_DEFAULT:
                    cipher = Cipher.getInstance(type.getType());
                    cipher.init(Cipher.DECRYPT_MODE, key);
                    break;
                case AES_CBC_PKCS7:
                    cipher = Cipher.getInstance(type.getType(), BC_PROVIDER);
                    checkIvExist(iv);
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
                    break;
                case AES_CBC_PKCS5:
                    cipher = Cipher.getInstance(type.getType());
                    checkIvExist(iv);
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
                    break;
                default:
                    throw new AccException(AccExpType.NOT_SUPPORT, "Type is error?");
            }
            return cipher.doFinal(content);
        } catch (Throwable e) {
            throw new AccException(AccExpType.NOT_SUPPORT, e,
                    "DECRYPT FAILED. content is %s, secret is %s, iv is %s. type is %s.",
                    AuthUtils.showBytes(content), AuthUtils.showBytes(secret), AuthUtils.showBytes(iv),
                    type.getType());
        }

    }
    
    private static void checkIvExist(byte[] iv) throws AccException {
        if (iv == null) {
            throw new AccException("iv is null.");
        }
    }

    public static class AESEncryptResult {
        public byte[] encryptResult;

        public byte[] iv;

        public AESEncryptResult(byte[] encryptResult, byte[] iv) {
            this.encryptResult = encryptResult;
            this.iv = iv;
        }
    }

    public static AESEncryptResult aesEncrypt(CIPHER_TYPE type, byte[] content, byte[] secret)
            throws AccException {
        if (type == null) {
            type = CIPHER_TYPE.AES_DEFAULT;
        }
        SecretKeySpec key = new SecretKeySpec(secret, AES);
        Cipher cipher = null;
        byte[] iv = null;
        if (secret.length != 16) {
            throw new AccException("secret length is not 128 bit.", AccExpType.NOT_SUPPORT);
        }
        try {
            switch (type) {
                case AES_DEFAULT:
                    cipher = Cipher.getInstance(type.getType());
                    cipher.init(Cipher.ENCRYPT_MODE, key);
                    break;
                case AES_CBC_PKCS7:
                    cipher = Cipher.getInstance(type.getType(), BC_PROVIDER);
                    cipher.init(Cipher.ENCRYPT_MODE, key);
                    iv = cipher.getIV();
                    break;
                case AES_CBC_PKCS5:
                    cipher = Cipher.getInstance(type.getType());
                    cipher.init(Cipher.ENCRYPT_MODE, key);
                    iv = cipher.getIV();
                    break;
                default:
                    throw new AccException(AccExpType.NOT_SUPPORT, " type is error?");
            }
            byte[] result = cipher.doFinal(content);
            return new AESEncryptResult(result, iv);
        } catch (Throwable e) {
            throw new AccException(AccExpType.NOT_SUPPORT, e,
                    "ENCRYPT FAILED. content is %s, secret is %s, iv is %s. type is %s.",
                    AuthUtils.showBytes(content), AuthUtils.showBytes(secret), AuthUtils.showBytes(iv),
                    type.getType());
        }
    }

    public static KeyPair genRSAKey(CIPHER_TYPE type, byte[] secret) throws AccException {
        if (type == null) {
            type = CIPHER_TYPE.RSA_DEFAULT;
        }
        try {
            KeyPairGenerator kpg = null;
            if (type.withBC()) {
                kpg = KeyPairGenerator.getInstance(RSA, BC_PROVIDER);
            } else {
                kpg = KeyPairGenerator.getInstance(RSA);
            }
            if (secret == null) {

                kpg.initialize(1024, new SecureRandom(AuthUtils.genUniqueToken().getBytes()));

            } else {
                kpg.initialize(1024, new SecureRandom(secret));
            }
            return kpg.genKeyPair();
        } catch (Throwable e) {
            throw new AccException(AccExpType.NOT_SUPPORT, e, "GEN RSA KEY FAILED. secret is %s, type is %s",
                    AuthUtils.showBytes(secret), type);
        }
    }

    public static String rsaDecryptHex(CIPHER_TYPE type, String contentHex, String priKeyHex)
            throws AccException {
        try {
            return new String(rsaDecrypt(type, AuthUtils.strHex(contentHex), AuthUtils.strHex(priKeyHex)), AccConst.UTF8).trim();
        } catch (UnsupportedEncodingException e) {
            throw new AccException("can not using UTF-8", AccExpType.ENCODING_ERROR);
        }
    }

    public static byte[] rsaDecrypt(CIPHER_TYPE type, byte[] content, byte[] priKey) throws AccException {
        if (type == null) {
            type = CIPHER_TYPE.RSA_DEFAULT;
        }
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(priKey);

        try {
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
            Cipher cipher = null;
            if (type.withBC()) {
                cipher = Cipher.getInstance(type.getType(), BC_PROVIDER);
            } else {
                cipher = Cipher.getInstance(type.getType());
            }
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            return cipher.doFinal(content);
        } catch (Throwable e) {
            throw new AccException(AccExpType.NOT_SUPPORT, e,
                    "DECRYPT FAILED. content is %s, priKey is %s, type is %s.", AuthUtils.showBytes(content),
                    AuthUtils.showBytes(priKey), type.getType());
        }
    }

    public static byte[] rsaEncrypt(CIPHER_TYPE type, byte[] content, byte[] pubKey) throws AccException {
        if (type == null) {
            type = CIPHER_TYPE.RSA_DEFAULT;
        }
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(pubKey);

        try {
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            PublicKey publicKey = keyFactory.generatePublic(x509KeySpec);
            Cipher cipher = null;
            if (type.withBC()) {
                cipher = Cipher.getInstance(type.getType(), BC_PROVIDER);
            } else {
                cipher = Cipher.getInstance(type.getType());
            }
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);

            return cipher.doFinal(content);
        } catch (Throwable e) {
            throw new AccException(AccExpType.NOT_SUPPORT, e,
                    "ENCRYPT FAILED. content is %s, pubKey is %s, type is %s.", AuthUtils.showBytes(content),
                    AuthUtils.showBytes(pubKey), type.getType());
        }
    }

    public static String paramsCompose(Parameter... params) {
        StringBuilder sb = new StringBuilder();
        boolean isfirst = true;
        for (Parameter p: params) {
            if (!isfirst) {
                sb.append("&");
            }
            String strVal = p.getStrVal();
            String value = strVal == null ? "" : strVal;
            sb.append(p.getKey()).append("=").append(value);
            isfirst = false;
        }
        String src = sb.toString();
        return src;
    }
    
    public static String decryptInfo(HttpServletRequest req, String pci) throws AccException {
        GlobalCache glcache = GlobalCache.getInstance();
        CookieIndex index = CookieIndex.decode3(glcache.remove(pci));
        
        if (index == null) {
            throw new AccException("Index is not exist", AccExpType.FAKE_PCI);
        }
        return decryptInfo(req, index.cipherType, index.priKeyHex);
    }
    
    public static String decryptInfo(HttpServletRequest req, String algorthm, String priKeyHex) throws AccException {
        
        String loginInfo = AuthUtils.getParamOrHeader(req, AccConst.PARAM_LOGIN_INFO);
        
        if (StringUtils.isBlank(loginInfo)) {
            throw new AccException(AccExpType.PARAM_MISSING_ERROR, "lo header/param is MISSING.");
        }
        CIPHER_ALGORITHM_TYPE cipherType = CIPHER_ALGORITHM_TYPE.NONE.defaultValueOf(algorthm);
        
        String info = null;
        switch(cipherType.getAlgorithm()) {
            case AES:
                String iv = req.getHeader(AccConst.PARAM_AES_IV);
                info = CipherUtils.aesDecryptHex(cipherType.getCipherType(), loginInfo, priKeyHex, iv);
                break;
            case RSA:
                info = CipherUtils.rsaDecryptHex(cipherType.getCipherType(), loginInfo, priKeyHex);
                break;
            default:
                throw new AccException(AccExpType.NOT_SUPPORT,"can not support decrypt type %s", cipherType);
        }
        String debug = req.getParameter(AccConst.PARAM_DEBUG_NAME);
        if (StringUtils.isNotBlank(debug)) {
            LOG.info(String.format("Type is %s. Decrypt info is %s. key is: %s", cipherType, info, priKeyHex));
        } else {
            LOG.info(String.format("Type is %s. Decrypt info is %s.", cipherType, SecurityUtils.secretString(info)));
        }
        return info;
    }
}
