/**
 * @(#)FakeCoremailConst.java, 2013-3-4. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.coremail;

/**
 * @author chen-chao
 */
public interface FakeCoremailConst {
    static final String SID_VALID = "sdf20349va23";
    static final String SID_VALID2 = "i8r34xa23";
    static final String SID_INVALID = "sdf20349va";
    static final String USER_ID_OLD = "x09z092@fake.com";
    static final String USER_ID_NEW = "13xw31@fake.com";
}
