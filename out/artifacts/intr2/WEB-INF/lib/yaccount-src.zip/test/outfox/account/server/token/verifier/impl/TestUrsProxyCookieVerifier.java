/**
 * @(#)TestUrsProxyCookieVerifier.java, 2012-11-9. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpResponse;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.UrsUtils;
import outfox.account.utils.client.AccHttpClient;

/**
 * @author chen-chao
 */
public class TestUrsProxyCookieVerifier extends VerifierTestCaseBase{
    public static final String username = "urstest_ynote@163.com";
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setUrsUserName(username);
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        caseRestart();
        init("YNOTE"); 
    }
    public void init(String product) {
        super.init(product, VerifierConfConst.URS_PROXY_COOKIE_VERIFIER_NAME);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName);
    }
    
    @Override
    protected void tearDown() throws Exception {
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, verifier);
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    @Test
    public void test() throws AccException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(box.persToken != null);
        assertTrue(box.ret.get(AccConst.USER_ID) != null);
        
        checkQueryPrefix(box, UrsUtils.FAKE_URS_ID_PREFIX);
    }
    
    public TokenBox getTokens(String clientType, int cookieformat) throws AccException {
        final String username = "urstest_ynote@163.com";
        return getUrsCookieTokens(clientType, username, "test123", cookieformat);
    }
    
    public TokenBox getUrsCookieTokens(String clientType, String username, String password, int cookieFormat) throws AccException {
        cookieStore.clear();
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_URS_USERNAME, username));
        params.add(new Parameter(AccConst.PARAM_URS_PASSWORD, DigestUtils.md5Hex(password).replace("\\", "\\\\").replace("'", "\\'")));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        HttpResponseAndJSON result = doLoginWithTestDevice(null, params);
        HttpResponse resp = result.response;
        JSONObject obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        
        // 4. get information
        System.err.println(obj);
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
}
