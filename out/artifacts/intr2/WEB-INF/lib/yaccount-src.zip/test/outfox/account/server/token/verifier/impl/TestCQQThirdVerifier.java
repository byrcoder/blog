/**
 * @(#)TestCQQThirdVerifier.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.qq.QQConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 *
 * @author chen-chao
 *
 */
public class TestCQQThirdVerifier extends VerifierTestCaseBase{
    
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("DICT");
    }

    public void init(String product) {
        super.init(product, "cqq-third");
        Properties pros = genCQQThirdProperty(getLocalHostHttpsUrl("/cqq/"));
        QConnThirdVerifier cqqThirdVerifier = genQConnThirdVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, cqqThirdVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    @Test
    public void testCQQ() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(QQConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(box, QQConst.FAKE_ID);
    }
}
