/**
 * @(#)TestCleanTokenTask.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.task.clean;

import org.junit.After;
import org.junit.Before;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.data.TpToken;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestCleanTokenTask extends AccTestCase{
    DataStore dataStore;
    @Before
    protected void setUp() throws Exception {
        AccConfig.setReuseTableMode(true);
        AccConfig.getPros().setProperty(AccConfig.NAME_ENABLE_READ_DATASTORE_CACHE, false);
        super.setUp();
        dataStore = DataStore.getInstance();
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    
    public void test() throws AccException, InterruptedException {
        TpToken tp = new TpToken();
        tp.app = "client";
        tp.product = "ynote";
        tp.verifierName = "cqq";
        tp.userId = "userA";
        tp.setExpiredTime(0L);
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.signature = AuthUtils.genUniqueToken();
        dataStore.writeToken(tp);
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.signature = AuthUtils.genUniqueToken();
        dataStore.writeToken(tp);
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.signature = AuthUtils.genUniqueToken();
        dataStore.writeToken(tp);
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.signature = AuthUtils.genUniqueToken();
        dataStore.writeToken(tp);
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.signature = AuthUtils.genUniqueToken();
        dataStore.writeToken(tp);
        
        long count = dataStore.getPersTokenCount();
        assertEquals(5, count);
        count = dataStore.getSessCookieCount();
        assertEquals(5, count);
        System.out.println();
        System.out.println();
        CleanTokenTask.doTask(-1L, 0L, null);
        Thread.sleep(5000);
        while (!CleanTokenTask.isFinished()) {
            Thread.sleep(5000);
        }
        System.out.println();
        System.out.println();
        CleanTokenTask.cancelTask();
        count = dataStore.getSessCookieCount();
        assertEquals(0, count);
        count = dataStore.getPersTokenCount();
        assertEquals(0, count);
    }
}
