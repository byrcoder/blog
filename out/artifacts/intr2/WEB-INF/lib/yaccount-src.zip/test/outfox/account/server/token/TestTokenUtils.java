/**
 * @(#)TestTokenUtils.java, 2012-10-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.TpToken;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.verifier.IVerifier;

/**
 * @author chen-chao
 */
public class TestTokenUtils extends AccTestCase{
    
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        stopMockServer();
        stopMiniZKCluster();
        super.tearDown();
    }
    @Test
    public void test() throws AccException {
        String product = "YNOTE";
        String tpName = "urstoken";
        TokenVerifierFactory tf = TokenVerifierFactory.getInstance();
        IVerifier verifier = tf.getTokenVerifier(product, tpName);
        TpToken tp = new TpToken();
        tp.app = "client";
        tp.product = product;
        tp.verifierName = tpName;
        tp.ip="1.10.1.100";
        tp.userId = "fake";
        tp.setExpiredTime(1000L);
        String encode = TokenUtils.encode(verifier, tp);
        TpToken tmp= TokenUtils.decode(encode);
        assertEquals(tp, tmp);
        String[] token = TokenUtils.checkToken(encode);
        assertEquals(tp.signature, token[0]);
        assertEquals(product, token[1]);
        assertEquals(tpName, token[2]);
        String base = TokenUtils.getBaseString(encode);
        String sign = encode.substring(base.length());
        assertEquals(tp.signature, sign);
        tp.signature = null;
        TokenUtils.genCompleteTpToken(verifier, tp);
        assertNotNull(tp.signature);
        assertNotNull(tp.sessIndex);
        assertEquals(sign, tp.signature);
    }
}
