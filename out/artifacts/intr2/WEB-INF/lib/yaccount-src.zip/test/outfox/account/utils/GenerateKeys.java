/**
 * @(#)GenerateKeys.java, 2013-1-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.security.KeyPair;

import org.apache.commons.codec.binary.Hex;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_TYPE;

/**
 * @author chen-chao
 */
public class GenerateKeys {
    public static void main(String[] args) throws Exception {
            
        String lo = "username=sssssaaaaasssssaaa@163.com&password=822d2890d1c4632185d92e6b1e2e00d0";
        KeyPair key = CipherUtils.genRSAKey(CIPHER_TYPE.RSA_ECB_PKCS1, null);
        String x = new String(CipherUtils.rsaDecrypt(null, CipherUtils.rsaEncrypt(null, lo.getBytes(), key.getPublic().getEncoded()), key.getPrivate().getEncoded()));
        System.out.println(x);
        FileOutputStream fos = new FileOutputStream("./rsa.test");
        BufferedOutputStream out = new BufferedOutputStream(fos);
        for (int i = 0; i < 1; i++) {
            System.out.println(i);
            String content = AuthUtils.genUniqueToken();
            KeyPair pair = AuthUtils.genRSAKeys(null);
            String privateKey = Hex.encodeHexString(pair.getPrivate().getEncoded());
            String publicKey = Hex.encodeHexString(pair.getPublic().getEncoded());
            String en = AuthUtils.rsaEncryptHex(content, publicKey);
            
            StringBuilder sb = new StringBuilder("=====\n");
            sb.append("content:"+content+"\n");
            sb.append("\n");
            sb.append("privateKey hex:"+privateKey+"\n");
            sb.append("\n");
            
            sb.append("publicKey hex:"+publicKey+"\n");
            sb.append("\n");
            
            sb.append("encoded content hex:"+en+"\n");
            sb.append("\n");
            
            out.write(sb.toString().getBytes(AccConst.UTF8));
            sb = null;
        }
        out.close();
        System.out.println(Hex.encodeHexString(key.getPublic().getEncoded()));
        System.out.println();
        System.out.println(Hex.encodeHexString(key.getPrivate().getEncoded()));
        System.out.println();
        String privateKey = "30820277020100300d06092a864886f70d0101010500048202613082025d020100028181008e54f21d70199c98bcf946afd7a1825aecd49c9e7dd119cef129e0fa8061c01f649571eee58907b03e607a62bb3eb839443a78fff579cba22abebe4dcde3c9b14be918473064ac172637a70d8be84f6b442d27c409f09aebd03ab47c0ce146dd3e7d9c5aae44bce1659e72923535769dbbb32370d6925d5b186262d52771d1a502030100010281803764b3fde4fcf2c736f4c51ff689f313b40c631003e37769e4cde9b35477b6b00113708e0b63334cd259f607aadc1412a58d243e69a907298bfd444f3f8c21987c565383ebb482fb3d9be80132993d66d5159253f01c77c34831ddfddbba691be2262758d566049438f9475e3d78c96877d198a3252f09e2cb11f6fa9c042781024100c339f2a4ba61bfd97dd8951d178104d8e818a36be9e0dbd8e921fe9c1e7700b64a941333c39bc2421168ddd579ef47faa784288e5587c71e92ece6e76a282db1024100baa3b4dba8a72dd81e741753f95e098d606455ffbc7de9831d7c17f0035e900a6011ab0bee1aad3c5ebba13a5828f22eb8251963ae2003cce6e39ba3ad711c350241009f032003d45bb1ebf078ec5b99bd58b963b24dc9a3e1a6aff293e1d23f6e268254146fdf85bfe465f3d03a7f9aa5af371622aaf5e3ec87defb45427dd3158ec102404cfba965d132e3ddf8f1b98d9196102a984fca89299e65eb07066079476a81cf45c103e46fd9e10abda876e031ecf1b8038c89e46bb618db33813e794cd912e1024100be58bb3e0558eca86a1d91c3b20af9e865b9928008b3884365610c70a4f147474b49408e4056170fc83628492c24e721bd1df2d9b452163b8a25e2e97a8c2b16";
        String enc = "5B862F22B0B0D37685802542C7697C82F5C4AEE35BED48094F610D9529362F37D00CB4C7C225FE8A8DA36195AABA71BF3FF54E149C71415444E5340436D86791AA8A401F1DD077C06DD4A5AF3ABC6AF91542B1407F0B23A7BA4FCEF8C18589912A380A1D4AE875302639B2C15812EEAF33F388710B642AE95DDC51CB7FD19008";
        System.out.println(privateKey.length());
        System.out.println(enc.length());
        System.out.println(AuthUtils.strHex(enc));
        System.out.println(CipherUtils.rsaDecryptHex(CIPHER_TYPE.RSA_ECB_PKCS1, enc, privateKey));
        String s = Hex.encodeHexString(new String("k").getBytes("utf-8"));
        System.out.println(s);
        System.out.println(new String(Hex.decodeHex(s.toCharArray())));
        System.out.println(new String(Hex.decodeHex(s.toUpperCase().toCharArray())));
    }
}
