/**
 * @(#)AuthMockServer.java, 2011-9-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server;

import java.io.File;
import java.util.TimeZone;

import org.mortbay.jetty.Connector;
import org.mortbay.jetty.NCSARequestLog;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.handler.RequestLogHandler;
import org.mortbay.jetty.nio.SelectChannelConnector;
import org.mortbay.jetty.security.SslSocketConnector;
import org.mortbay.jetty.servlet.FilterHolder;
import org.mortbay.jetty.servlet.ServletHolder;
import org.mortbay.jetty.webapp.WebAppContext;

import outfox.account.AccTestCase;
import outfox.account.faketp.server.FakeServletTest;
import outfox.account.faketp.server.HelloServletTest;
import outfox.account.faketp.server.ProductController;
import outfox.account.faketp.server.baidu.FakeBaiduController;
import outfox.account.faketp.server.qq.FakeCQQController;
import outfox.account.faketp.server.qq.FakeQplusController;
import outfox.account.faketp.server.qq.FakeWQQController;
import outfox.account.faketp.server.renren.FakeRenRenController;
import outfox.account.faketp.server.sina.FakeSinaController;
import outfox.account.faketp.server.urs.FakeTokenController;
import outfox.account.faketp.server.ynote.FakeYNoteController;
import outfox.account.faketp.server.yunos.FakeYunOSController;
import outfox.account.filter.AuthSingleProductFilter;
import outfox.account.filter.NoCacheFilter;
import outfox.account.filter.PublicViewFilter;


/**
 * @author chen-chao
 */
public class AccountMockServer extends Thread{
    
    public static final String CONTEXT_PATH = "/fake";
    public static final String DEFAULT_TEST_DIRECTORY = "build/test/";
    private Server server = null;
    private int httpPort;

    private int httpsPort;
    public void setHttpPort(int httpPort) {
        this.httpPort = httpPort;
    }

    public void setHttpsPort(int httpsPort) {
        this.httpsPort = httpsPort;
    }
    
    public AccountMockServer(int httpPort, int httpsPort) {
        this.httpPort = httpPort;
        this.httpsPort = httpsPort;
    }
    
    public int getHttpPort() {
        return httpPort;
    }

    public int getHttpsPort() {
        return httpsPort;
    }
    /**
     * start server
     * 
     * @param port
     *        an interger port number for listening
     * @throws Exception
     */
    public void startServerWait() throws Exception {
        
        startServer();
        server.join();
    }
    
    private void startServer() throws Exception {
        // start http server
        server = new Server();
        
        RequestLogHandler requestLogHandler = new RequestLogHandler();
        File logDir = new File("./logs");
        logDir.getParentFile().mkdirs();
        NCSARequestLog requestLog = new NCSARequestLog("logs/access.log.yyyy-mm-dd");
        requestLog.setRetainDays(90);
        requestLog.setAppend(true);
        requestLog.setExtended(true);
        requestLog.setLogTimeZone(TimeZone.getDefault().getID());
        requestLog.setLogDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
        requestLogHandler.setRequestLog(requestLog);
        server.setHandler(requestLogHandler);
        
        //init http listener.
        SelectChannelConnector http = new SelectChannelConnector();
        http.setPort(httpPort);
        //init https listener.
        SslSocketConnector https = new SslSocketConnector();
        https.setKeyPassword("111111");
        https.setPort(httpsPort);
        https.setPassword("111111");
        
        WebAppContext webapp = new WebAppContext();
        webapp.setContextPath(CONTEXT_PATH);
        webapp.setWar("./web/");
        webapp.setDescriptor("/WEB-INF/web.xml");
        webapp.setLogUrlOnStart(true);
        webapp.setServer(server);
        NoCacheFilter noCacheFilter = new NoCacheFilter();
        webapp.addFilter(new FilterHolder(noCacheFilter), "/*", 5);
        
        AuthSingleProductFilter filter = new AuthSingleProductFilter();
        filter.setProduct("YNOTE");
        filter.setUrsLoginCompatible(true);
        filter.setBackendReloginDomain(".youdao.com");
        filter.setInit(true);
        filter.setCheckPersToken(true);
        webapp.addFilter(new FilterHolder(filter), "/product/*", 5);
        PublicViewFilter publicViewFilter = new PublicViewFilter();
        publicViewFilter.setPrefix("/product/publicView/");
        publicViewFilter.setProduct("YNOTE");
        publicViewFilter.setInit(true);
        webapp.addFilter(new FilterHolder(publicViewFilter), "/product/*", 5);
        
        webapp.addServlet(new ServletHolder(new ProductController()), "/product/*");
        webapp.addServlet(new ServletHolder(new HelloServletTest()), "/aa/*");
        webapp.addServlet(new ServletHolder(new FakeRenRenController()), "/renren/*");
        webapp.addServlet(new ServletHolder(new FakeSinaController()), "/sina/*");
        webapp.addServlet(new ServletHolder(new FakeCQQController()), "/cqq/*");
        webapp.addServlet(new ServletHolder(new FakeQplusController()), "/qplus/*");
        webapp.addServlet(new ServletHolder(new FakeWQQController()), "/wqq/*");
        webapp.addServlet(new ServletHolder(new FakeServletTest()), "/FakeServletTest/*");
        webapp.addServlet(new ServletHolder(new FakeTokenController()), "/urstoken/*");
        webapp.addServlet(new ServletHolder(new FakeYNoteController()), "/ynote/*");
        webapp.addServlet(new ServletHolder(new FakeBaiduController()), "/baidu/*");
        webapp.addServlet(new ServletHolder(new FakeYunOSController()), "/yunos/*");
        server.setConnectors(new Connector[] {http, https});  
        server.setHandler(webapp);
        server.start();
    }
    
    public void run() {
        try {
            startServer();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void interrupt() {
        try {
            stopServer();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.interrupt();
        
    }

    /**
     * stop server for testcase
     * 
     * @throws Exception
     */
    public void stopServer() throws Exception {
        
        if (server != null && !server.isStopped()) {
            server.stop();
        }
    }

    public static void main(String args[]) throws Exception {
        if (args.length != 2) {
            System.err.println("USAGE: AccMockServer <httpPort> <httpsPort>");
            return;
        }
        
        int httpPort = Integer.parseInt(args[0]);
        int httpsPort = Integer.parseInt(args[1]);
        MiniZooKeeperCluster zkCluster = null;
        AccountMockServer mockserver = null;
        try {
            AccTestCase.startMiniZKCluster();
            mockserver = new AccountMockServer(httpPort, httpsPort);
            mockserver.startServerWait();    
        } finally {
            if (mockserver != null) {
                mockserver.stopServer();
            }
            if (zkCluster != null) {
                zkCluster.shutdown();
            }
            
        }
        
    }
}
