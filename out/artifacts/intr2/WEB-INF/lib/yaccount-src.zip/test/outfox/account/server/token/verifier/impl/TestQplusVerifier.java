/**
 * @(#)TestQplusVerifier.java, 2012-11-8. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.qq.QQConst;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;
import outfox.account.utils.client.AccHttpClient;

/**
 * @author chen-chao
 */
public class TestQplusVerifier extends VerifierTestCaseBase{
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        
        init("YNOTE");
    }

    public void init(String product) {
        super.init(product, "qplus");
        Properties pros = genQplusProperty(getLocalHostHttpUrl("/qplus/"));
        QplusVerifier qplusVerifier = genQPlusVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, qplusVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    @Test
    public void testQplusLogin() throws AccException {
        String clientType = "client";
        TokenBox box = getQplusTokens(clientType, COOKIE_FORMAT.se.value());
        assertTrue(box.sess != null);
        assertEquals(verifier.tpId2ownId(QQConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        tokenBoxQuery(box.getSessBox(), QQConst.FAKE_ID);
        tokenBoxQueryNone(box.getEmptyBox());
    }
    
    public TokenBox getTokens(String clientType, int cookieformat) throws AccException {
        if (COOKIE_FORMAT.pe.isContain(cookieformat)) {
            throw new AccException("can not generate pers cookie or pers token.");
        }
        return getQplusTokens(clientType, cookieformat);
    }
    
    public TokenBox getQplusTokens(String clientType, int cookieFormat) throws AccException {
        cookieStore.clear();
        String fakeOpenID = SinaConst.FAKE_ID;
        String fakeOpenKey = "cb2jg";
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        params.add(new Parameter(AccConst.PARAM_OPEN_ID, fakeOpenID));
        params.add(new Parameter(AccConst.PARAM_OPEN_KEY, fakeOpenKey));
        HttpResponseAndJSON result = doLoginWithTestDevice(null, params);
        HttpResponse resp = result.response;
        JSONObject obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
}
