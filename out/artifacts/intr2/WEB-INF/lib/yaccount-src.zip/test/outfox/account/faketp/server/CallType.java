/**
 * @(#)CallType.java, 2012-9-3. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * The annotation only used in fake services.
 * @author chen-chao
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface CallType {
    public enum Type {
        Oauth, OpenAPI, StrictIpAPI
    }
    
    Type type() default Type.OpenAPI;
    
}
