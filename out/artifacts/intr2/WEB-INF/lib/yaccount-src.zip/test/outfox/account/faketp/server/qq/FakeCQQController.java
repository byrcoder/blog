/**
 * @(#)FakecqqController.java, 2012-8-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.qq;

import java.io.IOException;
import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.faketp.server.FakeConst;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class FakeCQQController extends BaseFakeController {

    private static final long serialVersionUID = 1L;
    public FakeCQQController() {
        super();
    }

    @Override
    protected Object processOauthError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        JSONObject obj = new JSONObject();
        /*
        callback( {
        "error":"21329",
        "error_description":"no support ResponseType."
        } );
         */
        obj.put(QQConst.KEY_ERROR, QQConst.RETURN_CODE);
        obj.put(QQConst.KEY_ERROR_DESCRIPTION, QQConst.ERROR_MESSAGE);
        AuthUtils.writePlainChunked(resp, String.format("callback( %s );", obj.toString()), HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }

    @Override
    protected Object processOpenAPIError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {
           "ret" : "12323",
           "msg" : "Need you follow uid.",
        } 
         */
       obj.put(QQConst.KEY_RETURN, QQConst.RETURN_CODE);
       obj.put(QQConst.KEY_MESSAGE, QQConst.ERROR_MESSAGE);
       AuthUtils.writeJSONChunked(resp, obj, HttpStatus.INTERNAL_SERVER_ERROR);
       return null;
    }
    /**
     * request HTTPS /fake/cqq/oauth2/authorize
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type=Type.Oauth)
    @RequestMapping(value = "/cqq/oauth2.0/authorize")
    protected void authorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkParam(req, FakeConst.KEY_CLIENT_ID, NO_MISS);
        checkParam(req, FakeConst.KEY_RESPONSE_TYPE, FakeConst.KEY_CODE);
        checkParam(req, FakeConst.KEY_REDIRECT_URI, NO_MISS);
        try {
            resp.sendRedirect(String.format("%s?code=%s&state=%s",
                    req.getParameter(SinaConst.KEY_REDIRECT_URI), SinaConst.FAKE_AUTHORIZE_CODE,
                    req.getParameter(OAuthConstant.CALLBACK_STATE_CODE)));
        } catch (IOException e) {
            throw new AccException("Redirect error:" + req.getParameter(FakeConst.KEY_REDIRECT_URI),
                    AccExpType.FAKE_THIRD_PARTY_SERVER_ERROR);
        }
    }

    /**
     * request HTTPS /fake/cqq/oauth2/access_token
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type=Type.Oauth)
    @RequestMapping(value = "/cqq/oauth2.0/token")
    protected void access(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkReqMethod(req, RequestMethod.GET);
        checkParam(req, FakeConst.KEY_CLIENT_ID, NO_MISS);
        checkParam(req, FakeConst.KEY_CLIENT_SECRET, NO_MISS);
        checkParam(req, FakeConst.KEY_GRANT_TYPE, NO_MISS);
        checkParam(req, FakeConst.KEY_REDIRECT_URI, NO_MISS);
        checkParam(req, FakeConst.KEY_STATE, NO_MISS);
        checkParam(req, FakeConst.KEY_CODE, FakeConst.FAKE_AUTHORIZE_CODE);
        
        // { "access_token":"SlAV32hkKG", "expires_in":3600 }
        JSONObject object = new JSONObject();
        object.put(FakeConst.KEY_ACCESS_TOKEN, FakeConst.FAKE_ACCESS_TOKEN);
        object.put(QQConst.KEY_EXPRIES_IN, 3600);
        AuthUtils.writeJSONChunked(resp, object, HttpStatus.ACCEPTED);
    }
    
    /**
     * request HTTPS /fake/cqq/user/get_user_info
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/cqq/user/get_user_info")
    protected void show(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkParam(req, QQConst.KEY_ACCESS_TOKEN, QQConst.FAKE_ACCESS_TOKEN);
        checkParam(req, QQConst.KEY_OPEN_ID, QQConst.FAKE_ID);
        /*
             {
                "ret":0,
                "msg":"",
                "nickname":"Peter",
                "figureurl":"http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/30",
                "figureurl_1":"http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/50",
                "figureurl_2":"http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100",
                "gender":"男",
                "vip":"1",
                "level":"7",
                "is_yellow_year_vip":"1"
            }
         */
        JSONObject obj = new JSONObject();
        obj.put(QQConst.KEY_RETURN, QQConst.SUCCESS_CODE);
        obj.put(QQConst.ERROR_MESSAGE, "");
        obj.put(QQConst.NICK_NAME, FakeConst.FAKE_NAME);
        obj.put(QQConst.FIGURE_URL, QQConst.FAKE_FIGURE_URL);
        obj.put(QQConst.GENDER, QQConst.FAKE_GENDER);
        obj.put(QQConst.VIP, QQConst.FAKE_VIP);
        obj.put(QQConst.LEVEL, QQConst.FAKE_LEVEL);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }
    
    /**
     * request HTTPS /fake/cqq/user/get_simple_userinfo
     * some attribute will be missing.
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/cqq/user/get_simple_userinfo")
    protected void getSimpleUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkParam(req, QQConst.KEY_ACCESS_TOKEN, QQConst.FAKE_SSO_ACCESS_TOKEN);
        checkParam(req, QQConst.KEY_OPEN_ID, QQConst.FAKE_ID);
        /*
             {
                "ret":0,
                "msg":"",
                "nickname":"Peter",
                "figureurl":"http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/30",
                "figureurl_1":"http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/50",
                "figureurl_2":"http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100",
                "gender":"男",
                "vip":"1",
                "level":"7",
                "is_yellow_year_vip":"1"
            }
         */
        JSONObject obj = new JSONObject();
        obj.put(QQConst.KEY_RETURN, QQConst.SUCCESS_CODE);
        obj.put(QQConst.ERROR_MESSAGE, "");
        obj.put(QQConst.NICK_NAME, FakeConst.FAKE_NAME);
        obj.put(QQConst.FIGURE_URL, QQConst.FAKE_FIGURE_URL);
        obj.put(QQConst.VIP, QQConst.FAKE_VIP);
        obj.put(QQConst.LEVEL, QQConst.FAKE_LEVEL);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }
    
    /**
     * request HTTPS /fake/cqq/2/account/get_uid.json?access_token=
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/cqq/oauth2.0/me")
    protected void getUID(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkParam(req, QQConst.KEY_ACCESS_TOKEN, QQConst.FAKE_ACCESS_TOKEN);
        /*
             "openid":"3456676543"
         */
        JSONObject obj = new JSONObject();
        BigInteger b = new BigInteger(FakeConst.FAKE_ID);
        obj.put(QQConst.KEY_OPEN_ID, b);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }
    
}
