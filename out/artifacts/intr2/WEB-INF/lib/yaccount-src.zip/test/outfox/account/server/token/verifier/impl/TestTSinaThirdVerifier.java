/**
 * @(#)TestTSinaThirdVerifier.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 *
 * @author chen-chao
 *
 */
public class TestTSinaThirdVerifier extends VerifierTestCaseBase{

    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("DICT");
    }

    public void init(String product) {
        super.init(product, "tsina-third");
        Properties pros = genTSinaThirdProperty(getLocalHostHttpsUrl("/sina/"));
        TSinaThirdVerifier tsinaThirdVerifier = genTSinaThirdVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, "tsina-third", tsinaThirdVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    @Test
    public void testTSina() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(SinaConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(box, SinaConst.FAKE_ID);
    }
    
    @Test
    public void testTSinaGetAccessToken() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(SinaConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(box, SinaConst.FAKE_ID);
        assertTrue(queryGetAccessToken(box) != null);
    }
    
    @Test
    public void testTSinaBindGetAccessToken() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.b.value());
        assertTrue(box.bind != null);
        assertTrue(queryGetBindAccessToken(box.getBindBox()) != null);
    }
}
