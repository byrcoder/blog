/**
 * @(#)TestNoCacheFilter.java, 2013-1-14. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import org.apache.http.HttpResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.utils.client.AccHttpClient;

/**
 * @author chen-chao
 */
public class TestNoCacheFilter extends AccTestCase{
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    
    @Test
    public void test() throws AccException {
        AccHttpClient client = AccHttpClient.getInstance();
        HttpResponse resp = client.doGet(getLocalHostHttpUrlWithPerfix(AccConst.ERROR_URL), null, null);
        assertEquals("no-cache, no-store, must-revalidate",resp.getFirstHeader("Cache-Control").getValue());
        assertEquals("no-cache",resp.getFirstHeader("Pragma").getValue());
    }
}
