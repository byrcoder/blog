/**
 * @(#)TestServerAddress.java, 2012-9-25. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestServerAddress extends AccTestCase{
    @Test
    public void testLocal() {
        ServerAddress sa1 = new ServerAddress("local",8080);
        ServerAddress sa2 = new ServerAddress("localhost",8080);
        System.out.println(sa1.getDomainName());
        assertEquals(sa1.getHost(), sa2.getHost());
        System.out.println(sa1.getIP());
        System.out.println(sa1.getHost());
        assertEquals(sa1.getHost(), AuthUtils.getLocalIP());
    }
}
