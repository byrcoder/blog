/**
 * @(#)TestDataStoreRevokeAuthorize.java, 2012-12-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Before;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.db.in.IPersTokenDB.IPersTokenIter;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.db.in.ISessCookieDB.ISessCookieIter;
import outfox.account.db.kv.iter.CountIteratorTask;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestDataStoreRevokeAuthorize extends AccTestCase{
    private DataStore store;
    private static final String CLIENT = "client";
    private static final String MOBILE = "mobile";
    private static final String WEB = "web";
    private static final String PRODUCT_FANFAN = "FANFAN";
    private static final String PRODUCT_DICT = "DICT";
    private static final String PRODUCT_YNOTE = "YNOTE";
    private static final String VERIFER_163 = "ursproxy";
    private static final String VERIFER_163_COOKIE = "urscookie";
    private static final String VERIFER_163_TOKEN = "urstoken";
    private IPersTokenDB persTokenDB;
    private ISessCookieDB sessCookieDB;
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setReuseTableMode(false);
        ReflectConstruct dataStoreConstruct = new ReflectConstruct(DataStore.class);
        store = (DataStore) dataStoreConstruct.call();
        
        ReflectMethod method = new ReflectMethod(DataStore.class, "getPersTokenDB");
        persTokenDB = (IPersTokenDB)method.call(store);
        
        method = new ReflectMethod(DataStore.class, "getSessCookieDB");
        sessCookieDB = (ISessCookieDB)method.call(store);
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    public void testRevokeSameUser() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(6L, counter.returnValue());
        
        store.revokeAuthorize("userA@163.com", null, null, null, null);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(1L, counter.returnValue());
    }
    
    
    public void testRevokeSameUserOneClient() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(6L, counter.returnValue());
        HashSet<String> app = new HashSet<String>();
        app.add(CLIENT);
        
        store.revokeAuthorize("userA@163.com", null, app , null, null);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(4L, counter.returnValue());
    }
    
    public void testRevokeSameUserTwoClient() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(6L, counter.returnValue());
        HashSet<String> app = new HashSet<String>();
        app.add(CLIENT);
        app.add(MOBILE);
        store.revokeAuthorize("userA@163.com", null, app , null, null);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(3L, counter.returnValue());
    }
    
    public void testRevokeSameUserOneTp() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(6L, counter.returnValue());
        HashSet<String> tps = new HashSet<String>();
        tps.add(VERIFER_163_TOKEN);
        
        store.revokeAuthorize("userA@163.com", null, null , tps, null);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(2L, counter.returnValue());
    }
    
    public void testRevokeSameUserTwoTps() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(6L, counter.returnValue());
        HashSet<String> tps = new HashSet<String>();
        tps.add(VERIFER_163_TOKEN);
        tps.add(VERIFER_163);
        store.revokeAuthorize("userA@163.com", null, null , tps, null);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(1L, counter.returnValue());
    }
    
    
    public void testRevokeSameUserTwoProducts() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         *      web   , fanfan, ursproxy
         *      web   , fanfan, urstoken
         *      client, dict, urstoken
         *      web   , dict, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.product = PRODUCT_FANFAN;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.verifierName = VERIFER_163_TOKEN;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.product = PRODUCT_DICT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(10L, counter.returnValue());
        HashSet<String> products = new HashSet<String>();
        products.add(PRODUCT_DICT);
        products.add(PRODUCT_YNOTE);
        store.revokeAuthorize("userA@163.com", products, null , null, null);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(3L, counter.returnValue());
    }
    
    public void testRevokeNothing() throws AccException {
        store.revokeAuthorize("userA@163.com", null, null , null, null);
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(0L, counter.returnValue());
    }
    
    public void testRevokeCondition() throws AccException {
        /**
         * userA@163.com
         *      mobile, ynote, urstoken
         *      mobile, ynote, ursproxy
         *      client, ynote, urstoken
         *      client, ynote, urstoken
         *      web   , ynote, urstoken
         *      web   , ynote, ursproxy
         *      web   , ynote, urscookie
         *      web   , fanfan, ursproxy
         *      web   , fanfan, urstoken
         *      client, dict, urstoken
         *      web   , dict, ursproxy
         * userB@163.com
         *      web   , ynote, ursproxy
         */
        TpToken tp = new TpToken();
        tp.userId = "userA@163.com";
        tp.app = MOBILE;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.product = PRODUCT_YNOTE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        writeSessPers(tp);
        
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.verifierName = VERIFER_163_TOKEN;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163_COOKIE;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.product = PRODUCT_FANFAN;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.verifierName = VERIFER_163_TOKEN;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = CLIENT;
        tp.product = PRODUCT_DICT;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.app = WEB;
        tp.verifierName = VERIFER_163;
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        tp.userId = "userB@163.com";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        writeSessPers(tp);
        
        
        CountIteratorTask<IPersTokenIter> counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(12L, counter.returnValue());
        Map<String, Set<String>> map = new HashMap<String, Set<String>>();
        // mobile|urstoken;web|urstoken,urscookie
        HashSet<String> mobileTp = new HashSet<String>();
        mobileTp.add(VERIFER_163_TOKEN);
        map.put(MOBILE, mobileTp);
        
        HashSet<String> webTp = new HashSet<String>();
        webTp.add(VERIFER_163_TOKEN);
        webTp.add(VERIFER_163_COOKIE);
        map.put(WEB, webTp);
        
        store.revokeAuthorize("userA@163.com", null, null , null, map);
        counter = new CountIteratorTask<IPersTokenDB.IPersTokenIter>(persTokenDB, "");
        counter.doIter();
        assertEquals(8L, counter.returnValue());
        
        CountIteratorTask<ISessCookieIter> counter2 = new CountIteratorTask<ISessCookieIter>(sessCookieDB, "");
        counter2.doIter();
        assertEquals(8L, counter2.returnValue());
    }
    
    protected void writeSessPers(TpToken tp) throws AccException {
        store.writePersToken(tp);
        store.writeSessToken(tp);
    }
}
