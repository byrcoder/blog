/**
 * @(#)TestVerifierBase.java, 2012-9-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.cookie.Cookie;
import org.apache.http.message.BasicHeader;
import org.springframework.http.HttpStatus;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.impl.AccessTokenVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

import com.netease.urs.CookieNames;

/**
 * @author chen-chao
 */
public class VerifierTestCaseBase extends AccTestCase{

    
    public String thirdPartyName = "UNKNOWN";
    public IVerifier verifier = null;
    
    public void setProduct(String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }

    public void init(String product, String thirdPartyName) {
        this.product = product;
        this.thirdPartyName = thirdPartyName;
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName);
    }
    
    public void destory() {
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, verifier);
    }
    protected JSONObject getPciAndPc(String clientType, String thirdPartyName) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        JSONObject obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null, params, null);
        assertTrue(obj.get(AccConst.PARAM_PCINDEX_NAME) != null);
        assertTrue(obj.get(AccConst.PARAM_PC_NAME) != null);
        return obj;
    }
    
    protected void checkQueryPrefix(TokenBox tb, String perfix) throws AccException {
        tokenBoxQueryPerfix(tb, perfix);
        tokenBoxQueryPerfix(tb.getSessBox(), perfix);
        tokenBoxQueryPerfix(tb.getPersTokenBox(), perfix);
        tokenBoxQueryNone(tb.getEmptyBox());
    }
    
    protected void checkQuery(TokenBox tb, String wantID) throws AccException {
        tokenBoxQuery(tb, wantID);
        tokenBoxQuery(tb.getSessBox(), wantID);
        tokenBoxQuery(tb.getPersTokenBox(), wantID);
        tokenBoxQueryNone(tb.getEmptyBox());
    }

    protected void tokenBoxQueryNone(TokenBox tb) throws AccException {
        JSONObject obj = queryInfo(tb);
        assertFalse(obj.getBoolean(AccConst.FLAG_LOGIN));
    }
    
    protected void tokenBoxQueryPerfix(TokenBox tb, String prefix) throws AccException {
        JSONObject obj = queryInfo(tb);
        assertTrue(obj.get(AccConst.USER_ID) != null);
        assertTrue(obj.getString(AccConst.USER_ID).startsWith(prefix));
    }

    protected JSONObject queryInfo(TokenBox tb) throws AccException {
        JSONObject obj;
        cookieStore.clear();
        // only sess
        obj = query(tb, COOKIE_FORMAT.info.value());
        return obj;
    }
    
    protected String queryGetAccessToken(TokenBox tb) throws AccException {
        
        cookieStore.clear();
        return queryGetAccessToken(product, tb, COOKIE_FORMAT.info.value());
    }
    
    protected String queryGetBindAccessToken(TokenBox tb) throws AccException {
        cookieStore.clear();
        return queryGetBindAccessToken(product, tb, COOKIE_FORMAT.info.value());
    }

    protected void tokenBoxQuery(TokenBox tb, String wantID) throws AccException {
        JSONObject obj = queryInfo(tb);
        assertEquals(verifier.tpId2ownId(wantID), obj.get(AccConst.USER_ID));
    }
    
    protected void loginRedirect(String clientType, String thirdPartyName, String pci, int cookieFormat, String ru) throws AccException {
        loginRedirect(clientType, thirdPartyName, null, null, pci, cookieFormat, ru);
    }
    
    /**
     * This method will generate userInfo
     * @param clientType
     * @param thirdPartyName
     * @param pci
     * @param cookieFormat
     * @throws AccException
     */
    protected void loginRedirect(String clientType, String thirdPartyName, String accessTokenVerifierName, String accessToken, String pci, int cookieFormat, String ru) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        params.add(new Parameter(AccConst.PARAM_FORCE_REDIRECT, 1));
        params.add(new Parameter(AccConst.PARAM_REDIRECT_URL_NAME, ru));
        List<Header> headers = new ArrayList<Header>();
        
        if (accessTokenVerifierName != null) {
            params.add(new Parameter(AccConst.PARAM_ACCESS_TOKEN_VERIFIER, accessTokenVerifierName));
            headers.add(new BasicHeader(AccConst.ACCESS_TOKEN, accessToken));
        }
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | cookieFormat));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result2.response;
        // 302 redirect to sina
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        String location = getRedirectLocation(resp);
        // send request to fake sina
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        AccHttpClient.closeQuiet(resp);
        
        resp = client.doGet(location, cookieHeader(extractCookieHeaderSetStore(resp)), params);
        // 302 sina will callback to account server. 
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        location = getRedirectLocation(resp);
        assertTrue(location.indexOf(SinaConst.KEY_CODE) > 0);
        AccHttpClient.closeQuiet(resp);
        // send request to account server with code.
        resp = client.doGet(location, cookieHeader(cookieStore.getCookies()), null);
        // set fr param, call back will redirect.
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        if (StringUtils.isNotBlank(ru) && 
                (ru.startsWith("http://") || ru.startsWith("http://"))) {
            assertEquals(ru, getRedirectLocation(resp));
        }        
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(false, hasCookiesInStore(AccConst.ATTR_QUERY));
        AccHttpClient.closeQuiet(resp);
    }
    
    /**
     * This method will <b>NOT</b> generate userInfo
     * @param clientType
     * @param thirdPartyName
     * @param pci
     * @param cookieFormat
     * @throws AccException
     */
    protected void loginRedirectWithoutInfo(String clientType, String thirdPartyName, String pci, int cookieFormat) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.remove(cookieFormat)));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(null, params);
        HttpResponse resp = result2.response;
        // 302 redirect to sina
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        String location = getRedirectLocation(resp);
        // send request to fake sina
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        AccHttpClient.closeQuiet(resp);
        resp = client.doGet(location, cookieHeader(extractCookieHeaderSetStore(resp)), params);
        // 302 sina will callback to account server. 
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        location = getRedirectLocation(resp);
        assertTrue(location.indexOf(SinaConst.KEY_CODE) > 0);
        AccHttpClient.closeQuiet(resp);
        // send request to account server with code.
        resp = client.doGet(location, cookieHeader(cookieStore.getCookies()), null);
        // no set fr param, call back will not redirect.
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(false, hasCookiesInStore(AccConst.ATTR_QUERY));
        AccHttpClient.closeQuiet(resp);
    }
    
    
    /**
     * This method will generate and get userInfo only. <b>NO</b> cookies
     * @param clientType
     * @param thirdPartyName
     * @param pci
     * @return
     * @throws AccException
     */
    protected JSONObject loginGetInfoOnly(String clientType, String thirdPartyName, String pci) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value() | COOKIE_FORMAT.info.value()));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(null, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        
        // 302 redirect to sina
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        String location = getRedirectLocation(resp);
        // send request to fake sina
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        AccHttpClient.closeQuiet(resp);
        resp = client.doGet(location, cookieHeader(extractCookieHeaderSetStore(resp)), params);
        // 302 sina will callback to account server. 
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        location = getRedirectLocation(resp);
        assertTrue(location.indexOf(SinaConst.KEY_CODE) > 0);
        
        // send request to account server with code.
        resp = client.doGet(location, cookieHeader(cookieStore.getCookies()), null);
        // no set fr param, call back will not redirect.
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(false, hasCookiesInStore(AccConst.ATTR_QUERY));
        AccHttpClient.closeQuiet(resp);
        return obj;
    }
    
    protected JSONObject poll(String pc) throws AccException {
        List<Header> pcHeader = new ArrayList<Header>();
        pcHeader.add(new BasicHeader(AccConst.PARAM_PC_NAME, pc));
        HttpResponse resp = client.doGet(getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.POLL_URL), pcHeader, null);
        
        assertEquals(HttpStatus.OK.value(), resp.getStatusLine().getStatusCode());
        extractCookieHeaderSetStore(resp);
        JSONObject obj = getJson(resp);
        AccHttpClient.closeQuiet(resp);
        return obj;
    }

    
    protected Cookie getNeteaseSessCookie(String userName, String password) throws AccException {
        HashMap<String,Object> map = new HashMap<String,Object>();
        map.put("username", userName);
        map.put("password", password);
        UrlEncodedFormEntity entity = AccHttpClient.composeUrlEncodingEntity(map, AccConst.UTF8);
        HttpResponse resp = client.doPost("https://reg.163.com/logins.jsp", null, null, entity);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        AccHttpClient.closeQuiet(resp);
        Cookie cookie = getCookieInStore(CookieNames.NTES_SESS);
        if (cookie == null) {
            throw new AccException("username:"+userName+", password:"+password+" can not get cookie", AccExpType.NO_LOGIN);
        }
        return cookie;
    }
    
    public JSONObject query(TokenBox tb, int cookieFormat) throws AccException {
        return query(product, tb, cookieFormat);
    }
    
    public void logout(TokenBox tb) throws AccException {
        logout(product, tb);
    }
    
    public void revokeAuthorizeBind(boolean removeAllProduct, TokenBox tb, String products, String clientTypes, String tps, String condition) throws AccException {
        revokeAuthorize(product, removeAllProduct, true, tb, products, clientTypes, tps, condition);
    }
    
    public void revokeAuthorize(boolean removeAllProduct, TokenBox tb, String products, String clientTypes, String tps, String condition) throws AccException {
        revokeAuthorize(product, removeAllProduct, false, tb, products, clientTypes, tps, condition);
    }
    
    public void checkLogin(TokenBox box) throws AccException {
        checkLogin(product, box);
    }

    public void checkNoLogin(TokenBox box) throws AccException {
        checkNoLogin(product, box);
    }
    
    protected TokenBox makeTokenBox(JSONObject obj) {
        String persToken = null;
        final String persTokenName = product + AccConst.ATTR_PART_PC;
        if (obj.containsKey(persTokenName)) {
            persToken = obj.getString(persTokenName);
        }
        Cookie sess = getCookieInStore(product+AccConst.COOKIE_SESSION);
        TokenBox tb = new TokenBox(sess, null, persToken, obj);
        tb.login = getCookieInStore(product + AccConst.COOKIE_LOGIN);
        tb.bind = getCookieInStore(product + AccConst.COOKIE_SESSION_BIND);
        if (StringUtils.isBlank(tb.persToken)) {
            tb.pers = getCookieInStore(product + AccConst.COOKIE_PERSISTENT);
            if (tb.pers != null) {
                tb.persToken = tb.pers.getValue();
            }
        }
        return tb;
    }
    
    public TokenBox getTokens(String clientType, int cookieformat, String ru) throws AccException {
        return getTokens(clientType, null, null, cookieformat, ru);
    }
    
    public TokenBox getTokens(String clientType, int cookieformat) throws AccException {
        return getTokens(clientType, null, null, cookieformat, null);
    }
    
    /**
     * Oauth get tokens
     * @param clientType
     * @param cookieformat
     * @return
     * @throws AccException
     */
    public TokenBox getTokens(String clientType, String thirdParty, String accessToken, int cookieformat, String ru) throws AccException {
        // 1. get pci and pc
        JSONObject obj = getPciAndPc(clientType, thirdPartyName);
        String pci = obj.getString(AccConst.PARAM_PCINDEX_NAME);
        String pc = obj.getString(AccConst.PARAM_PC_NAME);
        // 2. use pci to login
        loginRedirect(clientType, thirdPartyName, thirdParty, accessToken, pci, cookieformat, ru);
        cookieStore.clear();
        // 3. poll cookies
        obj = poll(pc);
        
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
    
    public TokenBox getAccessVerifierTokenBox(String clientType, String accessTokenFrom, int cookieFormat, Map<String,String> map) throws AccException {
        cookieStore.clear();
        // 1. use access token login in HTTPS protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        params.add(new Parameter(AccConst.PARAM_ACCESS_TOKEN_VERIFIER, accessTokenFrom));
        for(Entry<String,String> entry: map.entrySet()) {
            params.add(new Parameter(entry.getKey(), entry.getValue()));
        }
        
        HttpResponseAndJSON result2 = doLoginWithTestDevice(null, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
    
    public TokenBox getAccessVerifierTokenBoxHTTP(String clientType, String accessTokenFrom, int cookieFormat, Map<String,String> map) throws AccException {
        cookieStore.clear();
        // 1. get pc and pci
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.RSA_DEFAULT.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. use access token login in HTTP protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        params.add(new Parameter(AccConst.PARAM_ACCESS_TOKEN_VERIFIER, accessTokenFrom));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        
        List<Header> headers = new ArrayList<Header>();
        List<Parameter> encrypt = new ArrayList<Parameter>();
        for (Entry<String, String> entry: map.entrySet()) {
            encrypt.add(new Parameter(entry.getKey(), entry.getValue()));
        }
        Parameter[] encryptArray = new Parameter[encrypt.size()];
        encrypt.toArray(encryptArray);
        String loginInfo = AuthUtils.rsaEncryptHex(pc, encryptArray);
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        
        HttpResponseAndJSON result2 = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
    
    protected void checkQuery(AccessTokenVerifier accVerifier, TokenBox tb, String thirdParty, String wantID) throws AccException {
        tokenBoxQuery(accVerifier, tb, thirdParty, wantID);
        tokenBoxQuery(accVerifier, tb.getSessBox(), thirdParty, wantID);
        tokenBoxQuery(accVerifier, tb.getPersTokenBox(), thirdParty, wantID);
        tokenBoxQueryNone(tb.getEmptyBox());
    }
    
    protected void tokenBoxQuery(AccessTokenVerifier accVerifier, TokenBox tb, String thirdParty, String wantID) throws AccException {
        JSONObject obj = queryInfo(tb);
        assertEquals(accVerifier.tpId2ownId(thirdParty, wantID), obj.get(AccConst.USER_ID));
    }
}
