/**
 * @(#)TestDeviceStatusLogic.java, 2013-6-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.logic;

import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.device.DeviceStatus;
import outfox.account.device.DeviceManager;

/**
 * @author chen-chao
 */
public class TestDeviceStatusLogic extends AccTestCase{
    @Test
    public void testDeviceStatusMove() {
        assertEquals(DeviceStatus.ONLINE, DeviceManager.nextStatus(DeviceStatus.EMPTY, OPERATOR.CQ));
        assertEquals(DeviceStatus.LOGOUTING, DeviceManager.nextStatus(DeviceStatus.ONLINE, OPERATOR.REQUEST_LOGOUT));
        assertEquals(DeviceStatus.DELETING, DeviceManager.nextStatus(DeviceStatus.ONLINE, OPERATOR.REQUEST_DELETE));
        assertEquals(DeviceStatus.LOGOUT, DeviceManager.nextStatus(DeviceStatus.ONLINE, OPERATOR.FINSIH_LOGOUT));
        assertEquals(DeviceStatus.LOGOUT, DeviceManager.nextStatus(DeviceStatus.LOGOUTING, OPERATOR.FINSIH_LOGOUT));
        assertEquals(DeviceStatus.ONLINE, DeviceManager.nextStatus(DeviceStatus.LOGOUT, OPERATOR.LOGIN));
        
        assertEquals(DeviceStatus.EMPTY, DeviceManager.nextStatus(DeviceStatus.DELETING, OPERATOR.FINISH_DELETE));
    }
}
