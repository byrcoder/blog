/**
 * @(#)TestDataStorePartlyCrash.java, 2012-11-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db;

import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.db.DataStore.MappingRelationship;
import outfox.account.db.in.IUserMappingDB;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestDataStorePartlyCrash extends AccTestCase{
    private String mainId = "main@163.com";
    private String shadowA = "a";
    private String shadowB = "b";
    private String shadowC = "c";
    private Set<String> ids;
    private DataStore store;
    private IUserMappingDB mappingDB;
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setReuseTableMode(false);
        ReflectConstruct dataStoreConstruct = new ReflectConstruct(DataStore.class);
        store = (DataStore) dataStoreConstruct.call();
        ids = new HashSet<String>();
        ids.add(shadowA);
        ids.add(shadowB);
        ids.add(shadowC);
        ReflectMethod getUserMapping = new ReflectMethod(DataStore.class, "getUserMappingDB");
        mappingDB = (IUserMappingDB) getUserMapping.call(store);
       
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    @Test
    public void testAddPart() throws AccException {
        /**
         * mainId -> b
         * b -> mainId
         * a -> mainId
         */
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(mainId, shadowA);
        mappingDB.writeShadowOnly(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(mainId, shadowB);
        mappingDB.write(mainId2ShadowIdWritable);
        
        MappingRelationship relationship = store.getAllMapping(shadowA);
        assertTrue(relationship == null);
        relationship = store.getAllMapping(shadowB);
        assertEquals(mainId, relationship.getMainId());
        assertEquals(shadowB, relationship.getShadowIds().get(0));
        
        assertTrue(store.isOnlyOneBindInfo(mainId));
        assertTrue(store.isOnlyOneBindInfo(shadowB));
        assertFalse(store.isOnlyOneBindInfo(shadowA));
        
        assertEquals(0, store.getMappingCount(shadowA));
        assertEquals(1, store.getMappingCount(shadowB));
        
        MainId2ShadowIdWritable mapping = store.getUserMapping(shadowA);
        assertEquals(mainId, mapping.getMainUserId());
        assertEquals(shadowA, mapping.getShadowUserId());
        
        mapping = store.safeUserMapping(shadowA);
        assertTrue(mapping == null);
    }
    
    @Test
    public void testDelPart() throws AccException {
        /**
         * mainId -> b
         * b -> mainId
         * a -> mainId
         */
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(mainId, shadowA);
        mappingDB.write(mainId2ShadowIdWritable);
        mappingDB.removeMainOnly(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(mainId, shadowB);
        mappingDB.write(mainId2ShadowIdWritable);
        
        MappingRelationship relationship = store.getAllMapping(shadowA);
        assertTrue(relationship == null);
        relationship = store.getAllMapping(shadowB);
        assertEquals(mainId, relationship.getMainId());
        assertEquals(shadowB, relationship.getShadowIds().get(0));
        
        assertTrue(store.isOnlyOneBindInfo(mainId));
        assertTrue(store.isOnlyOneBindInfo(shadowB));
        assertFalse(store.isOnlyOneBindInfo(shadowA));
        
        assertEquals(0, store.getMappingCount(shadowA));
        assertEquals(1, store.getMappingCount(shadowB));
        
        MainId2ShadowIdWritable mapping = store.getUserMapping(shadowA);
        assertEquals(mainId, mapping.getMainUserId());
        assertEquals(shadowA, mapping.getShadowUserId());
        
        mapping = store.safeUserMapping(shadowA);
        assertTrue(mapping == null);
    }
    
}
