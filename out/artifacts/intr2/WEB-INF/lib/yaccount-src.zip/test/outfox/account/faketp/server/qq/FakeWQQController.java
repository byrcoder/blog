/**
 * @(#)FakeWQQController.java, 2012-11-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.qq;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.ReqUtils;

/**
 * @author chen-chao
 */
public class FakeWQQController extends BaseFakeController {
    private static final long serialVersionUID = 1L;

    public FakeWQQController() {
        super();
    }

    @Override
    protected Object processOauthError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        AuthUtils.writePlainChunked(resp, "errorCode=123&errorMsg=something", HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }

    @Override
    protected Object processOpenAPIError(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {
           "ret":"234134" // not 0
           "data" : "null",
           "dataerror" : "something",
        } 
         */
        obj.put(QQConst.RET, QQConst.RET_ERROR);
        obj.put(QQConst.DATA, "null");
        obj.put(QQConst.DATAERROR, "something");
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }

    /**
     * request HTTPS /fake/sina/oauth2/authorize
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/wqq/cgi-bin/oauth2/authorize")
    protected void authorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        if (!isBlankParam(req, QQConst.KEY_CLIENT_ID)
                && isSameParam(req, QQConst.KEY_RESPONSE_TYPE, QQConst.KEY_CODE)
                && !ReqUtils.isBlankParam(req, QQConst.KEY_REDIRECT_URI)) {
            try {
                checkParam(req, QQConst.KEY_STATE, NO_MISS);
                String state = req.getParameter(OAuthConstant.CALLBACK_STATE_CODE);
                resp.sendRedirect(String.format("%s?code=%s&openid=%s&openkey=%s&state=%s",
                        req.getParameter(QQConst.KEY_REDIRECT_URI), QQConst.FAKE_AUTHORIZE_CODE,
                        QQConst.FAKE_OPEN_ID_VALUE, QQConst.FAKE_OPEN_KEY_VALUE, state));
            } catch (IOException e) {
                throw new AccException("Redirect error:" + req.getParameter(QQConst.KEY_REDIRECT_URI),
                        AccExpType.FAKE_THIRD_PARTY_SERVER_ERROR);
            }

            return;
        }
        throw new AccException("params error", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
    }

    /**
     * request HTTPS /fake/sina/oauth2/access_token
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/wqq/cgi-bin/oauth2/access_token")
    protected void access(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        if (OAuthConstant.GRANT_TYPE_REFRESH.equals(req.getParameter(OAuthConstant.GRANT_TYPE))) {
            checkParam(req, QQConst.KEY_CLIENT_ID, NO_MISS);
            checkParam(req, QQConst.KEY_REFRESH_TOKEN, QQConst.FAKE_QQ_REFRESH_TOKEN);
            checkParam(req, QQConst.KEY_STATE, NO_MISS);
            String state = req.getParameter(QQConst.KEY_STATE);
            // refresh token
            // "access_token=ACCESS_TOKEN&expires_in=60&refresh_token=REFRESH_TOKEN&name=NAME"
            AuthUtils.writePlainChunked(resp, String.format(
                    "access_token=%s&expires_in=60&refresh_token=%s&name=NAME&state=%s", QQConst.FAKE_ACCESS_TOKEN,
                    QQConst.FAKE_QQ_REFRESH_TOKEN, state), HttpStatus.OK);
        } else {
            checkParam(req, QQConst.KEY_CLIENT_ID, NO_MISS);
            checkParam(req, QQConst.KEY_CLIENT_SECRET, NO_MISS);
            checkParam(req, QQConst.KEY_GRANT_TYPE, NO_MISS);
            checkParam(req, QQConst.KEY_REDIRECT_URI, NO_MISS);
            checkParam(req, QQConst.KEY_CODE, QQConst.FAKE_AUTHORIZE_CODE);
            checkParam(req, QQConst.KEY_STATE, NO_MISS);
            String state = req.getParameter(QQConst.KEY_STATE);
            // "access_token=ACCESS_TOKEN&expires_in=60&refresh_token=REFRESH_TOKEN&state=%s"
            AuthUtils.writePlainChunked(resp, String.format(
                    "access_token=%s&expires_in=60&refresh_token=%s&state=%s", QQConst.FAKE_ACCESS_TOKEN,
                    QQConst.FAKE_QQ_REFRESH_TOKEN, state), HttpStatus.OK);
        }

    }
    
    /**
     * request HTTPS 
     * https://open.t.qq.com/api/user/info?format=json&oauth_consumer_key=xx&access_token=xx&openid=xx&clientip=xx&oauth_version=2.a&scope=xx
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/wqq/api/user/info")
    protected void show(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkReqMethod(req, RequestMethod.GET);
        
        checkParam(req, QQConst.KEY_FORMAT, QQConst.FORMAT_VALUE);
        checkParam(req, QQConst.KEY_OAUTH_CONSUMER_KEY, NO_MISS);
        
        checkParam(req, QQConst.KEY_ACCESS_TOKEN, NO_MISS);
        checkParam(req, QQConst.KEY_OPEN_ID, NO_MISS);
        
        checkParam(req, QQConst.KEY_CLIENT_IP, NO_MISS);
        checkParam(req, QQConst.KEY_OAUTH_VERSION, NO_MISS);
        JSONObject obj = new JSONObject();
        obj.put(QQConst.RET, QQConst.RET_SUCC);
        JSONObject data = new JSONObject();
        data.put(QQConst.KEY_BIRTH_DAY, QQConst.FAKE_BIRTH_DAY);
        data.put(QQConst.KEY_BIRTH_MONTH, QQConst.FAKE_BIRTH_MONTH);
        data.put(QQConst.KEY_BIRTH_YEAR, QQConst.FAKE_BIRTH_YEAR);
        data.put(QQConst.KEY_HEAD, QQConst.FAKE_HEAD);
        data.put(QQConst.KEY_IS_REAL_NAME, QQConst.FAKE_IS_REAL_NAME);
        data.put(QQConst.KEY_IS_VIP, QQConst.FAKE_IS_VIP);
        data.put(QQConst.KEY_NICK, QQConst.FAKE_NICK);
        data.put(QQConst.KEY_NAME, QQConst.FAKE_NAME);
        data.put(QQConst.KEY_OPEN_ID, QQConst.FAKE_OPEN_ID_VALUE);
        data.put(QQConst.KEY_SEX, QQConst.FAKE_SEX);
        data.put(QQConst.KEY_LOCATION, QQConst.FAKE_LOCATION);
        obj.put(QQConst.DATA, data);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.OK);
    }
}
