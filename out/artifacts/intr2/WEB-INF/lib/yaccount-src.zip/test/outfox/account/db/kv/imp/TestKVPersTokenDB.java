/**
 * @(#)TestPersDB.java, 2012-10-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.Parameter;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.IPersTokenDB;
import outfox.account.db.in.IPersTokenDB.IPersTokenIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestKVPersTokenDB extends AccTestCase{
    IPersTokenDB db;
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        db = new KVPersTokenDB();
    }
    @After
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    @Test
    public void testReadWrite() throws AccException {
        String userA = "aa";
        cleanUser(userA);
        TpToken tp = new TpToken();
        tp.userId = userA;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        tp.signature = "1";
        List<Parameter> params = new ArrayList<Parameter>();
        final String key = "AA";
        params.add(new Parameter(key, "BB"));
        
        PersistTokenWritable perstoken = new PersistTokenWritable(tp,params);
        db.write(perstoken);
        PersistTokenWritable tmp = db.read(tp);
        assertEquals(perstoken.getProperty(key), tmp.getProperty(key));
        
        tmp = db.read(tp.userId, tp.app, tp.product, tp.verifierName, tp.signature);
        assertEquals(perstoken.getProperty(key), tmp.getProperty(key));
        cleanUser(userA);
    }
    
    @Test
    public void testBaseFunction() throws AccException {
        
        String userA = "aa";
        String userB = "bb";
        cleanUser(userA);
        cleanUser(userB);
        TpToken tp = new TpToken();
        tp.userId = userA;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        int count = 10;
        for (int i = 0; i < count; i++) {
            tp.signature = "" + i;
            db.write(tp);
        }
        tp.app = "mobile";
        for (int i = 0; i < count; i++) {
            
            tp.signature = "" + i;
            db.write(tp);
        }
        
        tp.app = "htc";
        for (int i = 0; i < count; i++) {
            
            tp.signature = "" + i;
            db.write(tp);
        }
        
        tp.product = "fanfan";
        for (int i = 0; i < count; i++) {
            
            tp.signature = "" + i;
            db.write(tp);
        }
        
        tp.verifierName = "urscookie";
        for (int i = 0; i < count; i++) {
            
            tp.signature = "" + i;
            db.write(tp);
        }
        tp = new TpToken();
        tp.userId = "aa";
        tp.app = "htc";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        for (int i = 0; i < count; i++) {
            tp.signature = "" + i;
            PersistTokenWritable pers = db.read(tp);
            assertTrue(pers != null);
            assertEquals(""+i, pers.getTpToken().signature);
            db.remove(tp);
        }
        
        tp = new TpToken();
        tp.userId = userB;
        tp.app = "htc";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        for (int i = 0; i < count; i++) {
            tp.signature = "" + i;
            db.write(tp);
        }
        
        int cnt = countUser(userB);
        assertEquals(count, cnt);
        
        cnt = countUser(userA);
        assertEquals(4*count, cnt);
        // cleaned User A
        cleanUser(userA);
        
        cleanUser(userB);
    }
    private int countUser(String userA) throws AccException {
        IPersTokenIter iter;
        int cnt;
        PersistTokenWritable ps;
        iter = db.getIter(userA);
        cnt = 0;
        while((ps = iter.next()) != null) {
            ps.setLastActiveTime(3000);
            cnt++;
        }
        return cnt;
    }
    private void cleanUser(String userA) throws AccException {
        IPersTokenIter iter;
        PersistTokenWritable ps;
        iter = db.getIter(userA);
        while((ps = iter.next()) != null) {
            db.remove(ps.getTpToken());
        }
    }
    
    @Test
    public void testIter() throws AccException {
        
        String userA = "aa";
        String userB = "bb";
        cleanUser(userA);
        cleanUser(userB);
        TpToken tp = new TpToken();
        tp.userId = userA;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        writeSeq(tp);
        tp.userId = userA;
        tp.app = "moblie";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        writeSeq(tp);
        tp.userId = userA;
        tp.app = "htc";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        writeSeq(tp);
        tp.userId = userB;
        tp.app = "htc";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        writeSeq(tp);
        tp.userId = userA;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="urstoken";
        writeSeq(tp);
        tp.userId = userA;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="urscookie";
        writeSeq(tp);
        
        tp.userId = userA;
        tp.app = "mobile";
        tp.product="YNOTE";
        tp.verifierName="urscookie";
        writeSeq(tp);
        
        tp.userId = userA;
        tp.app = "mobile";
        tp.product="FANFAN";
        tp.verifierName="urscookie";
        writeSeq(tp);
        
        tp.userId = userA;
        tp.app = "client";
        tp.product="FANFAN";
        tp.verifierName="urstoken";
        writeSeq(tp);
        
        IPersTokenIter iter = db.getIter(userA);
        int seqNum = 8;
        int cnt = 0;
        PersistTokenWritable ps = null;
        while((ps = iter.next()) != null) {
            ps.setLastActiveTime(2003);
            cnt++;
        }
        
        assertEquals(8*seqNum, cnt);
        
        iter = db.getIter(userB);
        cnt = 0;
        while((ps = iter.next()) != null) {
            cnt++;
        }
        assertEquals(1*seqNum, cnt);
        cleanUser(userA);
        cleanUser(userB);
        

    }
    private void writeSeq(TpToken tp) throws AccException {
        writeTp(tp, "0");
        writeTp(tp, "9");
        writeTp(tp, "-");
        writeTp(tp, "_");
        writeTp(tp, "A");
        writeTp(tp, "Z");
        writeTp(tp, "a");
        writeTp(tp, "z");
    }
    private void writeTp(TpToken tp, String signature) throws AccException {
        tp.signature = signature;
        db.write(tp);
    }
}
