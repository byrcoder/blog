/**
 * @(#)TestConsistentHashSynchronizer.java, 2011-7-26. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.zk;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.utils.ZKUtils;

/**
 * @author licx
 */
public class TestZooKeeperWatcher extends AccTestCase {

    private ZooKeeperWatcher zooKeeper;

    @Before
    public void setUp() throws Exception {
        startMiniZKCluster();
    }

    @After
    public void tearDown() throws Exception {
        if (zooKeeper != null) {
            zooKeeper.close();
        }
        stopMiniZKCluster();
    }

    @Test
    public void test() throws Exception {
        zooKeeper = new ZooKeeperWatcher("TestZooKeeperWatcher", null);
        boolean exist = ZKUtils.checkExists(zooKeeper, zooKeeper.rootZNode);
        assertTrue(exist);
        exist = ZKUtils.checkExists(zooKeeper, zooKeeper.consistentHashZNode);
        assertTrue(exist);
        exist = ZKUtils.checkExists(zooKeeper, zooKeeper.accountServerDirZNode);
        assertTrue(exist);
        exist = ZKUtils.checkExists(zooKeeper, "/adfasf/sdfwef");
        assertFalse(exist);
        List<String> ss = ZKUtils.listChildrens(zooKeeper, zooKeeper.accountServerDirZNode);
        for (String s : ss) {
            System.out.println(s);
        }
    }
}
