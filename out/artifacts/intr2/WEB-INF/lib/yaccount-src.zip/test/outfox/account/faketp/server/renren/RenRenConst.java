/**
 * @(#)QQConst.java, 2012-10-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.renren;

import outfox.account.faketp.server.FakeConst;

/**
 * @author chen-chao
 */
public interface RenRenConst extends FakeConst{
    static final String KEY_ERROR_CODE = "error_code";
    static final String KEY_MESSAGE = "error_msg";
    static final String FAKE_ERROR_CODE = "12345";
    static final String FAKE_ERROR_MESSAGE = "no support ResponseType.";
    static final String KEY_EXPRIES_IN = "expires_in";
    static final String KEY_ID = "id";
    static final String KEY_UIDS = "uids";
           
    
    static final String FAKE_RENREN_REFRESH_TOKEN = "dsf23r23gdasdf";
    
    static final String KEY_FORMAT = "format";
    static final String FORMAT_VALUE = "json";
    
    // name,sex,vip,birthday,headurl,star,zidou
    static final String KEY_BIRTH_DAY = "birthday";
    
    static final String FAKE_BIRTH_DAY = "1989-03-14";
    
    static final String KEY_HEAD = "headurl";
    static final String FAKE_HEAD = "http://app.qlogo.cn/mbloghead/8df62426cf2873508634";
    static final String KEY_NAME = "name";
    static final String FAKE_NAME = "c230923";
    static final String KEY_SEX = "sex";
    static final String FAKE_SEX = "0";
    
    static final String KEY_IS_VIP = "vip";
    static final String FAKE_IS_VIP = "1";
    static final String KEY_ZIDOU = "zidou";
    static final String FAKE_ZIDOU = "1";
    
    static final String KEY_STAR = "star";
    static final String FAKE_STAR = "0";
    static final String KEY_UID = "uid";
    static final String FAKE_UID = "3293041";
}
