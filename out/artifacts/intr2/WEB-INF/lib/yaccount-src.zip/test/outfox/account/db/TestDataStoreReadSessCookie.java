/**
 * @(#)TestDataStoreReadSessCookie.java, 2013-3-6. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db;

import java.lang.reflect.InvocationTargetException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.cache.Cache;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestDataStoreReadSessCookie extends AccTestCase{
    private DataStore store;
    @Before
    protected void setUp() throws Exception {
        // set expired in 5 seconds
        AccConfig.getPros().setProperty(AccConfig.NAME_MEMCACHED_CACHE_REFRESH_TIME, 5);
        AccConfig.getPros().setProperty(AccConfig.NAME_ENABLE_MEMCACHED_IN_FILTER, true);
        super.setUp();
        ReflectConstruct dataStoreConstruct = new ReflectConstruct(DataStore.class);
        store = (DataStore) dataStoreConstruct.call();
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    @Test
    public void test() throws AccException, InterruptedException, SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        TpToken tp = new TpToken();
        tp.userId = "userA";
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        tp.signature = AuthUtils.genUniqueToken();
        tp.sessIndex = AuthUtils.genUniqueToken();
        tp.setExpiredTime(-1L);
        tp.setSessAliveTime(-1L);
        store.writeToken(tp);
        
        SessionCookieWritable sessionWritable = store.getAliveSession(tp.sessIndex, -1);
        assertEquals(tp.userId, sessionWritable.getTpToken().userId);
        // not expired
        Thread.sleep(2000);
        ReflectMethod m = new ReflectMethod(DataStore.class, "getSessCache");
        Cache cache = (Cache) m.call(store);
        SessionCookieWritable sess = (SessionCookieWritable) cache.get(tp.sessIndex).get();
        assertEquals(tp.userId, sess.getTpToken().userId);
        assertEquals(tp.signature, sess.getTpToken().signature);
        // expired
        Thread.sleep(4000);
        sess = (SessionCookieWritable) cache.get(tp.sessIndex);
        assertEquals(null, sess);
    }
}
