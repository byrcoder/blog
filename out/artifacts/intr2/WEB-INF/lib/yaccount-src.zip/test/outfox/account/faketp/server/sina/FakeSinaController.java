/**
 * @(#)FakeSinaController.java, 2012-8-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.sina;

import java.io.IOException;
import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class FakeSinaController extends BaseFakeController {

    private static final long serialVersionUID = 1L;

    public FakeSinaController() {
        super();
    }

    @Override
    protected Object processOauthError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {
        "error":"unsupported_response_type",
        "error_code":21329
        "error_description":"不支持的 ResponseType."
        "error_url" : "xxx"
        }
         */
        obj.put(SinaConst.KEY_ERROR, SinaConst.FAKE_ERROR);
        obj.put(SinaConst.KEY_ERROR_CODE, SinaConst.FAKE_ERROR_CODE);
        obj.put(SinaConst.KEY_ERROR_DESCRIPTION, SinaConst.FAKE_ERROR_DESCRIPTION);
        obj.put(SinaConst.KEY_ERROR_URL, SinaConst.FAKE_ERROR_URL);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }

    @Override
    protected Object processOpenAPIError(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {
           "request" : "/statuses/home_timeline.json",
           "error_code" : "20502",
           "error" : "Need you follow uid."
        } 
         */
        obj.put(SinaConst.KEY_REQUEST, SinaConst.FAKE_REQUEST);
        obj.put(SinaConst.KEY_ERROR_CODE, SinaConst.FAKE_ERROR_CODE);
        obj.put(SinaConst.KEY_ERROR, SinaConst.FAKE_ERROR);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }

    /**
     * request HTTPS /fake/sina/oauth2/authorize
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/sina/oauth2/authorize")
    protected void authorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        if (!isBlankParam(req, SinaConst.KEY_CLIENT_ID)
                && isSameParam(req, SinaConst.KEY_RESPONSE_TYPE, SinaConst.KEY_CODE)
                && !isBlankParam(req, SinaConst.KEY_REDIRECT_URI)) {
            try {
                resp.sendRedirect(String.format("%s?code=%s&state=%s",
                        req.getParameter(SinaConst.KEY_REDIRECT_URI), SinaConst.FAKE_AUTHORIZE_CODE,
                        req.getParameter(OAuthConstant.CALLBACK_STATE_CODE)));
            } catch (IOException e) {
                throw new AccException("Redirect error:" + req.getParameter(SinaConst.KEY_REDIRECT_URI),
                        AccExpType.FAKE_THIRD_PARTY_SERVER_ERROR);
            }

            return;
        }
        throw new AccException("params error", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
    }

    /**
     * request HTTPS /fake/sina/oauth2/access_token
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/sina/oauth2/access_token")
    protected void access(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkReqMethod(req, RequestMethod.POST);
        if (!isBlankParam(req, SinaConst.KEY_CLIENT_ID) && !isBlankParam(req, SinaConst.KEY_CLIENT_SECRET)
                && !isBlankParam(req, SinaConst.KEY_GRANT_TYPE)
                && !isBlankParam(req, SinaConst.KEY_REDIRECT_URI)
                && isSameParam(req, SinaConst.KEY_CODE, SinaConst.FAKE_AUTHORIZE_CODE)) {
            // { "access_token":"SlAV32hkKG", "remind_in ":3600, "expires_in":3600 }
            JSONObject object = new JSONObject();
            object.put(SinaConst.KEY_ACCESS_TOKEN, SinaConst.FAKE_ACCESS_TOKEN);
            object.put(SinaConst.KEY_REMIND_IN, 3600);
            object.put(SinaConst.KEY_EXPRIES_IN, 3600);
            AuthUtils.writeJSONChunked(resp, object, HttpStatus.ACCEPTED);
            return;
        }
        throw new AccException("params error", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
    }

    /**
     * request HTTPS /fake/sina/2/users/show.json
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/sina/2/users/show.json")
    protected void show(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkOauth2AccessToken(req, SinaConst.KEY_ACCESS_TOKEN_HEADER, SinaConst.FAKE_ACCESS_TOKEN);
        checkParam(req, SinaConst.KEY_UID, SinaConst.FAKE_ID);
        /*
             id      int64   用户UID
             screen_name     string  用户昵称
             name       string 用户名
         */
        JSONObject obj = new JSONObject();
        BigInteger b = new BigInteger(SinaConst.FAKE_ID);
        obj.put(SinaConst.KEY_ID, b);
        obj.put(SinaConst.KEY_NAME, SinaConst.FAKE_NAME);
        obj.put(SinaConst.KEY_SCREEN_NAME, SinaConst.FAKE_SCREEN_NAME);
        obj.put(SinaConst.KEY_PROFILE_URL, SinaConst.FAKE_SCREEN_NAME);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }

    /**
     * request HTTPS /fake/sina/2/account/get_uid.json?access_token=
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/sina/2/account/get_uid.json")
    protected void getUID(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkOauth2AccessToken(req, SinaConst.KEY_ACCESS_TOKEN_HEADER, SinaConst.FAKE_ACCESS_TOKEN);
        /*
             "uid":"3456676543"
         */
        JSONObject obj = new JSONObject();
        BigInteger b = new BigInteger(SinaConst.FAKE_ID);
        obj.put(SinaConst.KEY_UID, b);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }

}
