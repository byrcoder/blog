/**
 * @(#)TestAccessTokenVerifier.java, 2013-1-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.yunos.YunOSConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 * @author chen-chao
 */
public class TestAccessTokenVerifierYunOS extends VerifierTestCaseBase{
    public AccessTokenVerifier accVerifier = null;
    Map<String, String> parameterMap = new HashMap<String,String>();
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
        parameterMap.put(OAuthConstant.ACCESS_TOKEN, YunOSConst.YUN_VALUE_ACCESS_TOKEN);
    }

    public void init(String product){
        thirdPartyName = "tpac";
        super.init(product, thirdPartyName);
        Properties pros = genAliYunOSProperty(getLocalHostHttpsUrl("/yunos/openapi"));
        AliYunOSVerifier aliyunosVerifier = genAliYunOSVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, "yunos", aliyunosVerifier);
        
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, new AccessTokenVerifier(genAccTokenVerifierProperties(product)));
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        accVerifier = (AccessTokenVerifier)verifier;
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    @Test
    public void testAccessTokenHTTPSLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        
        final String thirdParty = "yunos";
        TokenBox box = getAccessVerifierTokenBox(clientType, thirdParty, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), parameterMap);
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(accVerifier.tpId2ownId(thirdParty, YunOSConst.YUN_VALUE_KP), box.ret.get(AccConst.USER_ID));
        checkQuery(accVerifier, box, thirdParty, YunOSConst.YUN_VALUE_KP);
    }
    @Test
    public void testAccessTokenHTTPLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        
        final String thirdParty = "yunos";
        TokenBox box = getAccessVerifierTokenBoxHTTP(clientType, thirdParty, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), parameterMap);
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(accVerifier.tpId2ownId(thirdParty, YunOSConst.YUN_VALUE_KP), box.ret.get(AccConst.USER_ID));
        checkQuery(accVerifier, box, thirdParty, YunOSConst.YUN_VALUE_KP);
    }
    
}
