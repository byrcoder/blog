/**
 * @(#)AuthTestCase.java, 2011-11-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import junit.framework.TestCase;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import odis.util.MiscUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.MalformedCookieException;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.cookie.BrowserCompatSpec;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.http.HttpStatus;

import outfox.account.cache.GlobalCache;
import outfox.account.cache.memcached.MockMemcachedClient;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.db.DataStore;
import outfox.account.device.DeviceStatus;
import outfox.account.device.DeviceStore;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.rpc.AccountRPCServer;
import outfox.account.server.AccountMockServer;
import outfox.account.server.MiniZooKeeperCluster;
import outfox.account.server.ch.YMaster;
import outfox.account.server.token.verifier.impl.AccessTokenVerifier;
import outfox.account.server.token.verifier.impl.AliYunOSVerifier;
import outfox.account.server.token.verifier.impl.BaiduVerifier;
import outfox.account.server.token.verifier.impl.PhoneQJVerifier;
import outfox.account.server.token.verifier.impl.QConnCourseVerifier;
import outfox.account.server.token.verifier.impl.QConnNormalVerifier;
import outfox.account.server.token.verifier.impl.QConnThirdVerifier;
import outfox.account.server.token.verifier.impl.QConnVerifier;
import outfox.account.server.token.verifier.impl.QplusVerifier;
import outfox.account.server.token.verifier.impl.RenRenVerifier;
import outfox.account.server.token.verifier.impl.TSinaCourseVerifier;
import outfox.account.server.token.verifier.impl.TSinaNormalVerifier;
import outfox.account.server.token.verifier.impl.TSinaThirdVerifier;
import outfox.account.server.token.verifier.impl.TSinaVerifier;
import outfox.account.server.token.verifier.impl.URSTokenVerifier;
import outfox.account.server.token.verifier.impl.WQQVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * The base class of all account server testcases.
 *
 * @author chen-chao
 *
 */
public class AccTestCase extends TestCase {
    protected AccHttpClient client = new AccHttpClient(10, 10, 3000, 3000,
            CookiePolicy.IGNORE_COOKIES, false, false);

    private static final Log LOG = LogFactory.getLog(AccTestCase.class);

    public static final String DEFAULT_TEST_DIRECTORY = "build/test/";

    // root path
    protected static String homePath = getRandomPath();

    // conf dir
    protected static String confPath = homePath + "/conf";

    protected String zookeeperServerNode = null;
    
    protected String product = "UNKNOWN";

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        zookeeperServerNode = AccConfig.getPros().getString(
                AccConfig.NAME_ZK_SERVER_NODE);
        AccConfig.getPros().setProperty(AccConfig.NAME_ZK_SERVER_NODE, 
                AccConfig.DEFAULT_ZK_SERVER_NODE);
        AccConfig.getPros().setProperty(AccConfig.NAME_CACHE_MEMCACHED_CLIENT, 
                MockMemcachedClient.NAME);
        AccConfig.getPros().setProperty(AccConfig.NAME_RPC_SERVICE_TIMEOUT, 1000);
    }

    @Override
    protected void tearDown() throws Exception {
        AccConfig.getPros().setProperty(AccConfig.NAME_ZK_SERVER_NODE, zookeeperServerNode);
        super.tearDown();
    }

    // auth config file
    protected static String confFile = "account.xml";

    // app config file
    protected static String appConfFile = confFile;

    public AccTestCase() {
        AccConfig.setTestCaseMode(true);
        File log4jFile = new File("log4j.properties");
        PropertyConfigurator.configureAndWatch(log4jFile.getAbsolutePath());
    }

    /**
     * create file user dir + "/" + filename
     * 
     * @param dir
     *            relative path or absolute path
     * @param filename
     *            relative path of dir
     * @see joinPath
     * @return joinPath(dir, filename)
     * @throws IOException
     */
    protected static String createFile(String dir, String filename) throws IOException {
        new File(dir).mkdirs();
        String path = joinPath(dir, filename);
        File file = new File(path);
        if (!file.createNewFile()) {
            LOG.warn("file can not create");
        }
        return path;
    }

    /**
     * join two path into one
     * 
     * @param rootPath
     * @param subPath
     * @return
     */
    protected static String joinPath(String rootPath, String subPath) {
        return new File(rootPath, subPath).toString();
    }

    /**
     * generate random path
     * 
     * @return
     */
    protected static String getRandomPath() {

        return joinPath(DEFAULT_TEST_DIRECTORY, AuthUtils.generateFileId());
    }

    /**
     * create random file
     * 
     * @return
     * @throws IOException
     */
    protected static String createFile() throws IOException {
        String dirPath = getRandomPath();
        String name = AuthUtils.generateFileId();
        return createFile(dirPath, name);
    }

    /**
     * delete file or dir (even if dir is not emtpy)
     * 
     * @param path
     *            relative or absolute path
     * @return delete successfully or not
     */
    protected static boolean deleteFile(String path) {
        File f = new File(path);
        return MiscUtils.deleteDir(f);
    }

    /**
     * write content to a file(using absolutely file path), if isAppend is
     * false, then rewrite the file. Or else, append content into the file.
     * 
     * @param absFileName
     *            absolutely file path
     * @param content
     *            you want to write
     * @param isAppend
     *            is append method or not
     * @throws IOException
     */
    protected static void writeStringToFile(String absFileName, String content, boolean isAppend)
            throws IOException {
        FileWriter writer = null;
        try {
            writer = new FileWriter(absFileName, isAppend);
            writer.write(content + "\n");
        } finally {
            writer.close();
        }
    }

    List<AccountRPCServer> rpcServers = new ArrayList<AccountRPCServer>();

    /**
     * start rpc cache server with random port.
     * @return
     * @throws IOException
     * @throws InterruptedException
     */
    protected AccountRPCServer startRpcServer() throws IOException, InterruptedException {
        // start consistent hash master.
        try {
            YMaster consistentHashMaster = new YMaster();
            consistentHashMaster.start();
        } catch (AccException e) {
            throw new AccRunTimeException("YMaster init failed.", e);
        }
        // start rpc server which contains consistent hash adjuster.
        return startRpcServer(AuthUtils.getFreePort());
    }

    private AccountRPCServer startRpcServer(int port) throws InterruptedException {
        System.out.println("Start rpc server at port:" + port);
        AccountRPCServer server = new AccountRPCServer(port);
        server.start();
        server.join();
        rpcServers.add(server);
        return server;
    }

    /**
     * stop rpc server.
     * @param server
     */
    protected void stopRpcCacheServer(AccountRPCServer server) {
        if (server != null) {
            server.stopServer();
            rpcServers.remove(server);
        }
    }

    /**
     * Stop all rpc servers.
     */
    protected void stopAllRpcCacheServer() {
        for (AccountRPCServer cacheServer: rpcServers) {
            cacheServer.stopServer();
        }
        rpcServers.clear();
    }

    /**
     * get server address from rpc server config. And compose them as a string.
     * Using "," split.
     * @return
     */
    protected String getServerAddressString() {
        StringBuilder sb = new StringBuilder(1024);
        for (AccountRPCServer server: rpcServers) {
            sb.append(server.getAddress()).append(",");
        }
        return sb.toString();
    }

    /**
     * GET query a url
     * @param url
     * @param urlParam
     * @return
     * @throws AccException 
     */
    protected HttpResponse doGet(String url, List<Parameter> urlParam) throws AccException {
        return client.doGet(url, null, urlParam);
    }
    
    /**
     * Post query using url-form encoding
     * @param url
     * @param postParam
     * @return
     * @throws UnsupportedEncodingException
     */
    protected HttpResponse doPostUrlEncoding(String url, Map<String, Object> postParam)
            throws AccException {
        return client.doPostUrlEncoding(url, postParam, AccConst.UTF8);
    }

    /**
     * Post a query using multi-part
     * @param url
     * @param postParam
     * @return
     * @throws AccException 
     */
    protected HttpResponse doPostByMultipart(String url, Map<String, Object> postParam) throws AccException {
        return client.doPostByMultipart(url, postParam, AccConst.UTF8);
    }

    protected AccountMockServer mockServer = null;

    public AccountMockServer getMockServer() {
        return mockServer;
    }

    /**
     * start a mock server with random ports(http/https)
     * @return
     * @throws IOException
     * @throws InterruptedException
     */
    public AccountMockServer startMockServer() throws IOException, InterruptedException {
        List<Integer> ports = AuthUtils.getFreePorts(2);
        AccountMockServer mockserver = new AccountMockServer(ports.get(0), ports.get(1));
        System.out.println("mockserver start at port:"+ports.get(0)+", "+ports.get(1));
        mockserver.start();
        mockserver.join();
        mockServer = mockserver;
        return mockserver;
    }

    /**
     * stop a mock server.
     */
    public void stopMockServer() {
        if (mockServer != null) {
            mockServer.interrupt();
        }
    }
    
    protected void cleanDataStore() throws NoSuchMethodException, IllegalAccessException,
            InvocationTargetException {
        AccConfig.setReuseTableMode(false);
        ReflectMethod method = new ReflectMethod(DataStore.class, "init");
        method.call(DataStore.getInstance());
    }

    /**
     * used in two or more test cases in one class file. 
     * this function should be put after mockserver, rpcserver and zookeeper started.
     * @throws InvocationTargetException 
     * @throws IllegalAccessException 
     * @throws NoSuchMethodException 
     */
    protected void caseRestart() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        GlobalCache.getInstance().reInit();
        cleanDataStore();
        cookieStore.clear();
    }

    protected String getLocalHostHttpUrlWithPerfix(String subUrl) {
        return getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + subUrl);
    }
    
    /**
     * using the start mock server to get <b>HTTP</b> request.
     * @param subUrl
     * @return
     */
    protected String getLocalHostHttpUrl(String subUrl) {
        return getLocalHostHttpUrl(mockServer, subUrl);
    }

    /**
     * using the start mock server to get <b>HTTP</b> request.
     * @param subUrl
     * @return
     */
    protected String getLocalHostHttpUrl(AccountMockServer mockServer, String subUrl) {
        if (mockServer != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(AccConst.HTTP_PROTOCAL).append("://").append(AccConst.LOCAL_HOST).append(":")
                    .append(mockServer.getHttpPort()).append(AccountMockServer.CONTEXT_PATH).append(subUrl);
            return sb.toString();
        }
        return null;
    }

    /**
     * using the start mock server to get <b>HTTPS</b> request.
     * @param subUrl
     * @return
     */
    protected String getLocalHostHttpsUrl(String subUrl) {
        return getLocalHostHttpsUrl(mockServer, subUrl);
    }

    public void setMockServer(AccountMockServer mockServer) {
        this.mockServer = mockServer;
    }

    /**
     * using the start mock server to get <b>HTTPS</b> request.
     * @param subUrl
     * @return
     */
    protected String getLocalHostHttpsUrl(AccountMockServer mockServer, String subUrl) {
        if (mockServer != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(AccConst.HTTPS_PROTOCAL).append("://").append(AccConst.LOCAL_HOST).append(":")
                    .append(mockServer.getHttpsPort()).append(AccountMockServer.CONTEXT_PATH).append(subUrl);
            return sb.toString();
        }
        return null;
    }

    /**
     * convert a object to string
     * @param from
     * @return
     */
    public static final String toString(Object from) {
        return (from == null) ? null : from.toString();
    }

    public static final byte[] JSON2bytes(JSONObject obj, String key) {
        JSONArray array = obj.getJSONArray(key);

        Object[] contents = array.toArray();
        byte[] bytes = new byte[contents.length];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = Byte.parseByte(contents[i].toString());
        }
        return bytes;
    }

    public static final String escapCRLF(String str) {
        return str.replace("\r", "").replace("\n", "");
    }

    public static Properties genTSinaProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("tsina.serviceProvider.baseURL", baseUrl);
        pros.put("tsina.serviceProvider.userAuthorizationURL", "oauth2/authorize");
        pros.put("tsina.serviceProvider.accessTokenURL", "oauth2/access_token");
        pros.put("tsina.consumerKey", "4260441337");
        pros.put("tsina.consumerSecret", "eff8eae36d3249c434e9b19ac0391e8a");
        pros.put("tsina.consumer.idPattern", "sina{id}");
        pros.put("tsina.consumer.accountURL", "2/account/get_uid.json");
        pros.put("tsina.consumer.accountInfoURL", "2/users/show.json");
        pros.put("tsina.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genTSinaNormalProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("tsina-normal.serviceProvider.baseURL", baseUrl);
        pros.put("tsina-normal.serviceProvider.userAuthorizationURL", "oauth2/authorize");
        pros.put("tsina-normal.serviceProvider.accessTokenURL", "oauth2/access_token");
        pros.put("tsina-normal.consumerKey", "3637953042");
        pros.put("tsina-normal.consumerSecret", "0175d7f7a9b61f21ee4dc9b0cede9cef");
        pros.put("tsina-normal.consumer.idPattern", "sina{id}");
        pros.put("tsina-normal.consumer.accountURL", "2/account/get_uid.json");
        pros.put("tsina-normal.consumer.accountInfoURL", "2/users/show.json");
        pros.put("tsina-normal.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genTSinaThirdProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("tsina-third.serviceProvider.baseURL", baseUrl);
        pros.put("tsina-third.serviceProvider.userAuthorizationURL", "oauth2/authorize");
        pros.put("tsina-third.serviceProvider.accessTokenURL", "oauth2/access_token");
        pros.put("tsina-third.consumerKey", "2859126288");
        pros.put("tsina-third.consumerSecret", "ecb103c50ce426b7ca08efec00054b2f");
        pros.put("tsina-third.consumer.idPattern", "sina{id}");
        pros.put("tsina-third.consumer.accountURL", "2/account/get_uid.json");
        pros.put("tsina-third.consumer.accountInfoURL", "2/users/show.json");
        pros.put("tsina-third.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genTSinaCourseProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("tsina-course.serviceProvider.baseURL", baseUrl);
        pros.put("tsina-course.serviceProvider.userAuthorizationURL", "oauth2/authorize");
        pros.put("tsina-course.serviceProvider.accessTokenURL", "oauth2/access_token");
        pros.put("tsina-course.consumerKey", "3878994075");
        pros.put("tsina-course.consumerSecret", "c6da3e484bdcb5079cdf61f5ff34befc");
        pros.put("tsina-course.consumer.idPattern", "sina{id}");
        pros.put("tsina-course.consumer.accountURL", "2/account/get_uid.json");
        pros.put("tsina-course.consumer.accountInfoURL", "2/users/show.json");
        pros.put("tsina-course.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genAliYunOSProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("yunos.serviceProvider.baseURL", baseUrl);
        pros.put("yunos.consumerKey", "sdafxsadf144vsdq3r21fxcbxbzsfdw12312cbv");
        pros.put("yunos.consumerSecret", "zsdfwe1214tzdxgabaetr231sasdf23rfvzxcvz");
        pros.put("yunos.consumer.idPattern", "yunos{id}");
        return pros;
    }
    
    public static Properties genBaiduProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("baidu.serviceProvider.baseURL", baseUrl);
        pros.put("baidu.serviceProvider.accessTokenURL", "oauth/2.0/token");
        pros.put("baidu.serviceProvider.userAuthorizationURL", "oauth/2.0/authorize");
        pros.put("baidu.consumerKey", "596540109");
        pros.put("baidu.consumerSecret", "xxxxxxxxx");
        pros.put("baidu.consumer.idPattern", "baidu{id}");
        pros.put("baidu.consumer.accountURL", "rest/2.0/passport/users/getInfo");
        pros.put("baidu.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genCQQProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("cqq.serviceProvider.baseURL", baseUrl);
        pros.put("cqq.serviceProvider.userAuthorizationURL", "oauth2.0/authorize");
        pros.put("cqq.serviceProvider.accessTokenURL", "oauth2.0/token");
        pros.put("cqq.consumerKey", "13233");
        pros.put("cqq.consumerSecret", "964f7asdfq232r46fbe3c958fbf4");
        pros.put("cqq.consumer.idPattern", "qq{id}");
        pros.put("cqq.consumer.accountURL", "oauth2.0/me");
        pros.put("cqq.consumer.accountInfoURL", "user/get_user_info");
        pros.put("cqq.consumer.ssoAccountURL", "user/get_simple_userinfo");
        pros.put("cqq.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genCQQNormalProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("cqq-normal.serviceProvider.baseURL", baseUrl);
        pros.put("cqq-normal.serviceProvider.userAuthorizationURL", "oauth2.0/authorize");
        pros.put("cqq-normal.serviceProvider.accessTokenURL", "oauth2.0/token");
        pros.put("cqq-normal.consumerKey", "100492669");
        pros.put("cqq-normal.consumerSecret", "f3c2c0cb6ae3bccf7e726a22a8f931fa");
        pros.put("cqq-normal.consumer.idPattern", "qq{id}");
        pros.put("cqq-normal.consumer.accountURL", "oauth2.0/me");
        pros.put("cqq-normal.consumer.accountInfoURL", "user/get_user_info");
        pros.put("cqq-normal.consumer.ssoAccountURL", "user/get_simple_userinfo");
        pros.put("cqq-normal.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genCQQThirdProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("cqq-third.serviceProvider.baseURL", baseUrl);
        pros.put("cqq-third.serviceProvider.userAuthorizationURL", "oauth2.0/authorize");
        pros.put("cqq-third.serviceProvider.accessTokenURL", "oauth2.0/token");
        pros.put("cqq-third.consumerKey", "100586700");
        pros.put("cqq-third.consumerSecret", "3bc5127eb183725252a38bb4e2d21eb3");
        pros.put("cqq-third.consumer.idPattern", "qq{id}");
        pros.put("cqq-third.consumer.accountURL", "oauth2.0/me");
        pros.put("cqq-third.consumer.accountInfoURL", "user/get_user_info");
        pros.put("cqq-third.consumer.ssoAccountURL", "user/get_simple_userinfo");
        pros.put("cqq-third.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genCQQCourseProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("cqq-course.serviceProvider.baseURL", baseUrl);
        pros.put("cqq-course.serviceProvider.userAuthorizationURL", "oauth2.0/authorize");
        pros.put("cqq-course.serviceProvider.accessTokenURL", "oauth2.0/token");
        pros.put("cqq-course.consumerKey", "101143044");
        pros.put("cqq-course.consumerSecret", "b98867bdc7f12d9371e792cb41036c2a");
        pros.put("cqq-course.consumer.idPattern", "qq{id}");
        pros.put("cqq-course.consumer.accountURL", "oauth2.0/me");
        pros.put("cqq-course.consumer.accountInfoURL", "user/get_user_info");
        pros.put("cqq-course.consumer.ssoAccountURL", "user/get_simple_userinfo");
        pros.put("cqq-course.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genCoremailProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("cqq.serviceProvider.baseURL", baseUrl);
        pros.put("cqq.serviceProvider.userAuthorizationURL", "oauth2.0/authorize");
        pros.put("cqq.serviceProvider.accessTokenURL", "oauth2.0/token");
        pros.put("cqq.consumerKey", "13233");
        pros.put("cqq.consumerSecret", "964f7asdfq232r46fbe3c958fbf4");
        pros.put("cqq.consumer.idPattern", "qq{id}");
        pros.put("cqq.consumer.accountURL", "oauth2.0/me");
        pros.put("cqq.consumer.accountInfoURL", "user/get_user_info");
        pros.put("cqq.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genUrsTokenProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("urstoken.initURL", "http://reg.163.com/services/initMobApp");
        pros.put("urstoken.safeloginURL", "https://reg.163.com/services/safeUserLoginForMob");
        pros.put("urstoken.verifierURL", "http://reg.163.com/services/checkMobToken");
        pros.put("urstoken.removeURL", "http://reg.163.com/services/safeRemoveMobToken");
        pros.put("urstoken.sessURL", baseUrl+"getCookieFromMobToken");
        pros.put("urstoken.productName", "note_client");
        return pros;
    }
    
    public static Properties genCQQSessAliveProperty(String baseUrl, long aliveTime) {
        Properties pros = new Properties();
        pros.put("cqq.serviceProvider.baseURL", baseUrl);
        pros.put("cqq.serviceProvider.userAuthorizationURL", "oauth2.0/authorize");
        pros.put("cqq.serviceProvider.accessTokenURL", "oauth2.0/token");
        pros.put("cqq.consumerKey", "13233");
        pros.put("cqq.consumerSecret", "964f7asdfq232r46fbe3c958fbf4");
        pros.put("cqq.consumer.idPattern", "qq{id}");
        pros.put("cqq.consumer.sessAlive", ""+aliveTime);    
        pros.put("cqq.consumer.accountURL", "oauth2.0/me");
        pros.put("cqq.consumer.accountInfoURL", "user/get_user_info");
        pros.put("cqq.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genRenRenProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("renren.serviceProvider.baseURL", baseUrl);
        pros.put("renren.serviceProvider.userAuthorizationURL", "oauth/authorize");
        pros.put("renren.serviceProvider.accessTokenURL", "oauth/token");
        pros.put("renren.consumerKey", "13233");
        pros.put("renren.consumerSecret", "964f7asdfq232r46fbe3c958fbf4");
        pros.put("renren.consumer.idPattern", "renren{id}");
        pros.put("renren.consumer.apiURL", baseUrl + "restservice.do");
        pros.put("renren.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genQplusProperty(String baseUrl) {
        Properties pros = new Properties();
        pros.put("qplus.serviceProvider.baseURL", baseUrl);
        pros.put("qplus.consumerKey", "200202649");
        pros.put("qplus.consumerSecret", "iyevsA7PHUaz7iFh");
        pros.put("qplus.consumer.idPattern", "qq{id}");
        pros.put("qplus.consumer.lang", "2052");
        return pros;
    }
    
    public static Properties genWQQProperties(String baseUrl) {
        Properties pros = new Properties();
        pros.put("wqq.serviceProvider.baseURL", baseUrl);
        pros.put("wqq.serviceProvider.userAuthorizationURL", "cgi-bin/oauth2/authorize");
        pros.put("wqq.serviceProvider.accessTokenURL", "cgi-bin/oauth2/access_token");
        pros.put("wqq.consumerKey", "801090168");
        pros.put("wqq.consumerSecret", "cc270c08b540008e7f1bad7395d8d586");
        pros.put("wqq.consumer.idPattern", "wqq{id}");
        pros.put("wqq.consumer.accountURL", "api/user/info");
        pros.put("wqq.callbackURL", "/acc/callback");
        return pros;
    }
    
    public static Properties genAccTokenVerifierProperties(String product) {
        Properties pros = new Properties();
        pros.put(AccConst.NAME_PRODUCT, product);
        pros.put("tpac.consumer.support", "tsina,cqq,tsina-normal,cqq-normal,tsina-third,cqq-third,tsina-course,cqq-course,wqq,qj,coremail,yunos");
        return pros;
    }
    
    public static AccessTokenVerifier genAccessTokenVerifier(Properties properties) {
        return new AccessTokenVerifier(properties);
    }

    public static TSinaVerifier genTSinaVerifier(Properties properties) {
        return new TSinaVerifier(properties);
    }
    
    public static TSinaNormalVerifier genTSinaNormalVerifier(Properties properties) {
        return new TSinaNormalVerifier(properties);
    }
    
    public static TSinaThirdVerifier genTSinaThirdVerifier(Properties properties) {
        return new TSinaThirdVerifier(properties);
    }
    
    public static TSinaCourseVerifier genTSinaCourseVerifier(Properties properties) {
        return new TSinaCourseVerifier(properties);
    }
    
    public static AliYunOSVerifier genAliYunOSVerifier(Properties properties) {
        return new AliYunOSVerifier(properties);
    }
    
    public static RenRenVerifier genRenRenVerifier(Properties properties) {
        return new RenRenVerifier(properties);
    }
    
    public static QConnVerifier genQConnVerifier(Properties properties) {
        return new QConnVerifier(properties);
    }
    
    public static QConnNormalVerifier genQConnNormalVerifier(Properties properties) {
        return new QConnNormalVerifier(properties);
    }
    
    public static QConnThirdVerifier genQConnThirdVerifier(Properties properties) {
        return new QConnThirdVerifier(properties);
    }
    
    public static QConnCourseVerifier genQConnCourseVerifier(Properties properties) {
        return new QConnCourseVerifier(properties);
    }
    
    public static PhoneQJVerifier genPhoneQJVerifier(Properties properties) {
        return new PhoneQJVerifier(properties);
    }
    
    public static URSTokenVerifier genURSTokenVerifier(Properties properties) {
        return new URSTokenVerifier(properties);
    }
    
    public static QplusVerifier genQPlusVerifier(Properties properties) {
        return new QplusVerifier(properties);
    }
    
    public static WQQVerifier genWQQVerifier(Properties properties) {
        return new WQQVerifier(properties);
    }
    
    public static BaiduVerifier genBaiduVerifier(Properties properties) {
        return new BaiduVerifier(properties);
    }

    protected BrowserCompatSpec cookieSpec = new BrowserCompatSpec();

    public List<Header> cookieHeader(List<Cookie> cookieList) {
        cookieList = removeExpireCookiesFromStore(cookieList);
        if (cookieList.size() == 0) {
            return new ArrayList<Header>();
        }
        return cookieSpec.formatCookies(cookieList);
    }

    public List<Header> cookieHeader(Cookie... cookies) {
        List<Cookie> cookieList = addCookieIntoList(cookies);
        return cookieHeader(cookieList);
    }
    
    public List<Header> cookieHeaderOnly(Cookie... cookies) {
        List<Cookie> cookieList = addCookieIntoList(cookies);
        return cookieSpec.formatCookies(cookieList);
    }

    private List<Cookie> addCookieIntoList(Cookie... cookies) {
        List<Cookie> cookieList = new ArrayList<Cookie>();
        for (Cookie c: cookies) {
            if (c != null) {
                cookieList.add(c);
            }
            
        }
        return cookieList;
    }

    protected BasicCookieStore cookieStore = new BasicCookieStore();

    public List<Cookie> extractCookieHeaderSetStore(HttpResponse resp) throws AccException {
        Header[] headers = resp.getHeaders("Set-Cookie");
        CookieOrigin origin = new CookieOrigin("localhost", mockServer.getHttpsPort(), "/", false);

        List<Cookie> cookies = new ArrayList<Cookie>();
        for (Header h: headers) {
            try {
                cookies.addAll(cookieSpec.parse(h, origin));
            } catch (MalformedCookieException e) {
                throw new AccException(AccExpType.COOKIE_HEADER_ERROR);
            }
        }
        Cookie[] array = new Cookie[cookies.size()];
        cookieStore.addCookies(cookies.toArray(array));
        return cookies;
    }

    public List<Cookie> removeExpireCookiesFromStore(List<Cookie> cookies) {
        if (cookies.size() == 0) {
            return cookies;
        }
        Cookie[] array = new Cookie[cookies.size()];
        cookieStore.addCookies(cookies.toArray(array));
        cookieStore.clearExpired(new Date(System.currentTimeMillis()));
        return cookieStore.getCookies();
    }

    public String getRedirectLocation(HttpResponse resp) {
        Header location = resp.getFirstHeader("Location");
        if (location == null) {
            return null;
        }
        return location.getValue();
    }

    public Cookie getCookieInStore(String cookieName) {
        for (Cookie c: cookieStore.getCookies()) {
            if (c.getName().equals(cookieName)) {
                return c;
            }
        }
        return null;
    }

    public boolean hasCookiesInStore(String... cookieNames) {
        int count = 0;
        for (Cookie c: cookieStore.getCookies()) {
            for (String name: cookieNames) {
                if (c.getName().equals(name)) {
                    count++;
                }
            }
        }
        return count == cookieNames.length;
    }

    protected void checkStatusCode(HttpResponse resp, HttpStatus status) {
        assertEquals(status.value(), resp.getStatusLine().getStatusCode());
    }

    // mini zookeeper cluster
    private static MiniZooKeeperCluster zkCluster;

    /**
     * Start a mini zookeeper cluster only
     * @return
     * @throws Exception
     */
    public static MiniZooKeeperCluster startMiniZKCluster() throws Exception {
        return startMiniZKCluster(setupZKClusterTestDir(), 1);
    }

    /**
     * Start a mini zookeeper cluster only
     * @return
     * @throws Exception
     */
    public static MiniZooKeeperCluster startMiniZKCluster(int number) throws Exception {
        return startMiniZKCluster(setupZKClusterTestDir(), number);
    }

    public static MiniZooKeeperCluster startMiniZKCluster(final File dir, int zooKeeperServerNum)
            throws Exception {
        if (zkCluster != null) {
            throw new IOException("Cluster already running at " + dir);
        }
        zkCluster = new MiniZooKeeperCluster();
        zkCluster.startup(dir, zooKeeperServerNum);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < zooKeeperServerNum; i++) {
            sb.append("127.0.0.1:").append(zkCluster.getClientPortList().get(i)).append(";");
        }
        AccConfig.getPros().setProperty(AccConfig.NAME_ZK_SERVER_NODE, sb.toString());
        return zkCluster;
    }

    /**
     * Set up the home directory for zookeeper test cluster
     * @return
     */
    protected static File setupZKClusterTestDir() {
        String randomStr = UUID.randomUUID().toString();
        String dirStr = getTestDir(randomStr).toString();
        File dir = new File(dirStr).getAbsoluteFile();
        // Have it cleaned up on exit
        dir.deleteOnExit();
        return dir;
    }

    public static String getTestDir(final String subdir) {
        return AuthUtils.joinPath(DEFAULT_TEST_DIRECTORY, subdir);
    }

    /**
     * 
     * @throws Exception
     */
    public static void stopMiniZKCluster() throws Exception {
        if (zkCluster != null) {
            zkCluster.shutdown();
            zkCluster = null;
        }
    }

    protected static class TokenBox {
        public Cookie sess;
        public Cookie login;
        public Cookie pers;
        public Cookie bind;

        public String persToken;
        
        public JSONObject ret;

        public TokenBox(Cookie sess, Cookie pers) {
            this(sess, pers, null);
        }

        public TokenBox(Cookie sess, String persToken) {
            this(sess, null, persToken);
        }

        public TokenBox(Cookie sess, Cookie pers, String persToken) {
            this(sess, pers, persToken, null);
        }

        public TokenBox(Cookie sess, Cookie pers, String persToken, JSONObject ret) {
            this(null, sess, pers, null, persToken, ret);
        }
        
        public TokenBox(TokenBox sess, TokenBox bind) {
            this(sess.login, sess.sess, null, bind.bind, null, null);
        }
        
        public TokenBox(Cookie login, Cookie sess, Cookie pers, Cookie bind, String persToken, JSONObject ret) {
            this.sess = sess;
            this.pers = pers;
            this.persToken = persToken;
            this.ret = ret;
            this.login = login;
            this.bind = bind;
        }
        
        public TokenBox getPersTokenBox() {
            return new TokenBox(null, pers, persToken);
        }
        
        public TokenBox getSessBox() {
            return new TokenBox(login, sess, null, null, null, null);
            
        }
        
        public TokenBox getBindBox() {
            return new TokenBox(login, null,  null,bind, null, null);
            
        }
        
        public TokenBox getEmptyBox() {
            return new TokenBox(null, null, null);
        }
        
        public String toString() {
            String login = this.login == null ? "(null)": this.login.toString();
            String sess = this.sess == null ? "(null)": this.sess.toString();
            String pers = this.pers == null ? "(null)": this.pers.toString();
            String bind = this.bind == null ? "(null)": this.bind.toString();
            String persToken = this.persToken == null ? "(null)": this.persToken;
            String ret = this.ret == null ? "(null)" : this.ret.toString();
            return String.format("login-%s sess-%s pers-%s bind-%s persToken-%s ret-%s", login, sess, pers, bind, persToken, ret);
        }
    }

    /**
     * use session cookie first, if session cookie is null, read from cookie store.
     * If cookie store has no session cookie, use persist token.
     * Here just test.
     * In your application, you can add session cookie and persToken both.
     * 
     * @param session
     * @param persToken
     * @return
     */
    public List<Header> composeAuthHeader(String product, Cookie login, Cookie sess, String persToken, Cookie bind) {
        List<Header> headers = composeTokenHeader(product, login, sess, persToken, bind);
        if (headers == null) {
            // not login
            return null;
        }
        headers.add(new BasicHeader(AccConst.PARAM_PRODUCT_NAME, product));
        return headers;
    }
    
    public List<Header> composeAuthHeader(String product, TokenBox tb) {
        return composeAuthHeader(product, tb.login, tb.sess, tb.persToken, tb.bind);
    }

    protected List<Header> composeTokenHeader(String product, Cookie login, Cookie session, String persToken, Cookie bind) {
        List<Header> headers = null;
        if (session == null) {
            session = getCookieInStore(product + AccConst.COOKIE_SESSION);
        } 
        if (bind == null) {
            bind = getCookieInStore(product + AccConst.COOKIE_SESSION_BIND);
        }
        headers = cookieHeader(session, login, bind);
        
        if (persToken != null) {
            headers.add(new BasicHeader(product + AccConst.ATTR_PART_PC, persToken));
        }
        
        return headers;
    }
    
    public JSONObject query(String product, TokenBox tb, int cookieFormat) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        List<Header> headers = composeAuthHeader(product, tb);
        return doCqWithTestDevice(headers, params).jsonObj;
    }
    
    protected JSONObject getJson(HttpResponse resp) throws AccException {
        JSONObject obj = null;
        try {
            final String string = EntityUtils.toString(resp.getEntity(), AccConst.UTF8);
            if (StringUtils.isNotBlank(string)) {
                obj = JSONObject.fromObject(string);
            }
        } catch (ParseException e) {
            throw new AccException(e, AccExpType.UNKNOWN_EXCEPTION);
        } catch (IOException e) {
            throw new AccException(e, AccExpType.UNKNOWN_EXCEPTION);
        }
        return obj;
    }
    
    public String queryGetAccessToken(String product, TokenBox tb, int cookieFormat) throws AccException {
        return queryGetAccessToken(product, tb, cookieFormat, product + AccConst.COOKIE_TOKEN);
    }
    
    public String queryGetBindAccessToken(String product, TokenBox tb, int cookieFormat) throws AccException {
        return queryGetAccessToken(product, tb, cookieFormat, product + AccConst.COOKIE_BIND_TOKEN);
    }
    
    private String queryGetAccessToken(String product, TokenBox tb, int cookieFormat, String cookieName) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        params.add(new Parameter(AccConst.PARAM_GET_ACCESS_TOKEN, "1"));
        List<Header> headers = composeAuthHeader(product, tb);
        //TODO:
        HttpResponse resp = doCqWithTestDevice(headers, params).response;
        List<Cookie> cookies = extractCookieHeaderSetStore(resp);
        Cookie accessCookie = null;
        for (Cookie c : cookies) {
            if (cookieName.equals(c.getName())) {
                accessCookie = c;
            }
        }
        return accessCookie == null ? null : accessCookie.getValue();
    }
    
    /**
     * <pre>
     * if removeAllProduct == true, remove products include product itself.
     * else only remove product authorize. you can clean all apps, all tps,
     * or special condition.
     * 
     * </pre> 
     * @param product
     * @param removeAllProduct
     * @param sess
     * @param pers
     * @param clientTypes
     * @param tps
     * @throws AccException
     */
    public void revokeAuthorize(String product, boolean removeAllProduct, boolean bindRemove, TokenBox tb, String products, String clientTypes, String tps, String condition) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        if (removeAllProduct) {
            params.add(new Parameter(AccConst.PARAM_ALL, true));
        }
        if (bindRemove) {
            params.add(new Parameter(AccConst.PARAM_WANT_CLEAN_BIND, true));
        }
        
        if (clientTypes != null) {
            params.add(new Parameter(AccConst.PARAM_WANT_CLEAN_APPS_NAME, clientTypes));
        } 
        if (tps != null) {
            params.add(new Parameter(AccConst.PARAM_WANT_CLEAN_TPS_NAME, tps));
        }
        if (condition != null) {
            params.add(new Parameter(AccConst.PARAM_WANT_CLEAN_CONDITION, condition));
        }
        List<Header> headers = composeAuthHeader(product, tb);
        HttpResponse resp = client.doGet(getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.REMOVE_URL)), headers, params);
        assertEquals(HttpStatus.OK.value(), resp.getStatusLine().getStatusCode());
        AccHttpClient.closeQuiet(resp);
    }
    
    
    public void logout(String product, TokenBox tb) throws AccException{
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        List<Header> headers = composeAuthHeader(product, tb);
        client.getBytes(Method.GET, getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.RESET_URL)), headers, params, null);
    }
    
    public void checkLogin(String product, TokenBox box) throws AccException {
        JSONObject obj = query(product, box, COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
    }

    public void checkNoLogin(String product, TokenBox box) throws AccException {
        JSONObject obj = query(product, box, COOKIE_FORMAT.info.value());
        assertFalse(obj.getBoolean(AccConst.FLAG_LOGIN));
    }
    
    protected void bind(String product, TokenBox box) throws AccException {
        HttpResponse resp;
        resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_ADD_URL), composeAuthHeader(product, box), null, null);
        checkStatusCode(resp, HttpStatus.OK);
        AccHttpClient.closeQuiet(resp);
    }
    
    public static class ReflectMethod {
        private java.lang.reflect.Method method;
        public ReflectMethod(Class<?> className, String methodName, Class<?> ... paramTypes ) throws SecurityException, NoSuchMethodException {
            method = className.getDeclaredMethod(methodName, paramTypes);
            method.setAccessible(true);
        }
        
        public Object call(Object instance, Object...paramValues) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
            return method.invoke(instance, paramValues);
        }
    }
    
    public static class ReflectConstruct {
        private java.lang.reflect.Constructor<?> method;
        public ReflectConstruct(Class<?> className, Class<?> ... paramTypes ) throws SecurityException, NoSuchMethodException {
            method =  className.getDeclaredConstructor(paramTypes);
            method.setAccessible(true);
        }
        
        public Object call(Object...paramValues) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, InstantiationException {
            return method.newInstance(paramValues);
        }
    }
    
    public static class PciPc {
        public String pci;
        public String pc;
        public PciPc(String pci, String pc) {
            this.pci = pci;
            this.pc = pc;
        }
    }
    
    public PciPc getPciPc(String app, String product, String thirdPartyName, String alg) throws AccException {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, app));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_ALOGRITHM, alg));
        JSONObject obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null, params, null);
        assertTrue(obj.containsKey(AccConst.PARAM_PCINDEX_NAME));
        assertTrue(obj.containsKey(AccConst.PARAM_PC_NAME));
        String pci = obj.getString(AccConst.PARAM_PCINDEX_NAME);
        String pc = obj.getString(AccConst.PARAM_PC_NAME);
        return new PciPc(pci, pc);
    }
    
    /**
     * do login request and check device status if possible.
     * @param headers
     * @param params
     * @return
     * @throws AccException
     */
    protected HttpResponseAndJSON doLoginWithTestDevice(List<Header> headers, 
            List<Parameter> params) throws AccException {
        boolean revert = false;
        if (StringUtils.isBlank(AccConfig.getUrsUserName())) {
            String fakedUrsName = String.format(UrsUtils.FAKE_URS_ID_FORMAT, AuthUtils.generateFileId());
            AccConfig.setUrsUserName(fakedUrsName);
            revert = true;
        }
        try {
            String subUrl = AccConst.URL_AUTH_PREFIX + AccConst.LOGIN_URL;
            String deviceId = "device_test";
            params.add(new Parameter(AccConst.PARAM_DEVICE_ID, deviceId));
            HttpResponse resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
            // response is not ok at the beginning, just return.
            if (resp.getStatusLine().getStatusCode() != HttpStatus.OK.value()){
                return new HttpResponseAndJSON(resp);
            }
            // login request with 'pic' can only be done once.
            for (Parameter para : params) {
                if (para.getKey().equals(AccConst.PARAM_PCINDEX_NAME)) {
                    return new HttpResponseAndJSON(resp);
                }
                if (para.getKey().equals("cf")) {
                    int cfValue = Integer.parseInt(para.getStrVal());
                    if (!COOKIE_FORMAT.se.isContain(cfValue)) {
                        return new HttpResponseAndJSON(resp);
                    }
                }
            }
            checkStatusCode(resp, HttpStatus.OK);
            JSONObject obj = getJson(resp);
            String userId = null;
            try {
                userId = obj.getString(AccConst.USER_ID);
            } catch (Exception e){}
            if (StringUtils.isBlank(userId)) {
                return new HttpResponseAndJSON(resp, obj);
            }
            DeviceStore store = DeviceStore.getInstance();
            // request logout. logouting -> online.
            store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.LOGOUTING);
            resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
            checkStatusCode(resp, HttpStatus.OK);
            // request deleting.
            store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.DELETING);
            resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
            checkStatusCode(resp, HttpStatus.SERVICE_UNAVAILABLE);
            obj = getJson(resp);
            assertEquals(obj.get(AccConst.ERROR_CODE), AccConst.ERROR_DEVICE_DELETE);
            // refresh login and return.

            store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.EMPTY);
            resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
            return new HttpResponseAndJSON(resp);
        } finally {
            if (revert) {
                AccConfig.setUrsUserName("");
            }
        }
    }
    

    /**
     * do cq request and check device status if possible.
     * @param headers
     * @param params
     * @return
     * @throws AccException
     */
    protected HttpResponseAndJSON doCqWithTestDevice(List<Header> headers, 
            List<Parameter> params) throws AccException {
        String subUrl = AccConst.URL_AUTH_PREFIX + AccConst.COOKIE_QUERY_URL;
        String deviceId = "device_test";
        params.add(new Parameter(AccConst.PARAM_DEVICE_ID, deviceId));
        HttpResponse resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
        checkStatusCode(resp, HttpStatus.OK);
        //begin with device status check. check only when cq claims session 
        for (Parameter param : params) {
            if (param.getKey().equals("cf")) {
                int cfValue = Integer.parseInt(param.getStrVal());
                if (!COOKIE_FORMAT.se.isContain(cfValue)) {
                    return new HttpResponseAndJSON(resp);
                }
            }
        }
        JSONObject obj = getJson(resp);
        String userId = null;
        try {
            userId = obj.getString(AccConst.USER_ID);
        } catch (Exception e){}
        if (StringUtils.isBlank(userId)) {
            return new HttpResponseAndJSON(resp, obj);
        }
        DeviceStore store = DeviceStore.getInstance();
        // request logout. logouting -> online.
        store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.LOGOUTING);
        resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
        checkStatusCode(resp, HttpStatus.SERVICE_UNAVAILABLE);
        obj = getJson(resp);
        assertEquals(obj.get(AccConst.ERROR_CODE), AccConst.ERROR_DEVICE_OFFLINE);
        // request deleting.
        store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.DELETING);
        resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
        checkStatusCode(resp, HttpStatus.SERVICE_UNAVAILABLE);
        obj = getJson(resp);
        assertEquals(obj.get(AccConst.ERROR_CODE), AccConst.ERROR_DEVICE_DELETE);
        // refresh login and return.
        store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.EMPTY);
        resp = client.doGet(getLocalHostHttpUrl(subUrl), headers, params);
        return new HttpResponseAndJSON(resp);
    }
    
    public class HttpResponseAndJSON {
        public HttpResponse response;
        public JSONObject jsonObj;
        public HttpResponseAndJSON(HttpResponse response) throws AccException {
            this.response = response;
            this.jsonObj = getJson(response);
        }
        
        HttpResponseAndJSON(HttpResponse response, JSONObject jsonObj) {
            this.response = response;
            this.jsonObj = jsonObj;
        }
    }
    
    
}
