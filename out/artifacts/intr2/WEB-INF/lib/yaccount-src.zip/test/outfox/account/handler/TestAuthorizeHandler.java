/**
 * @(#)TestAuthorizeHandler.java, 2012-10-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import net.sf.json.JSONObject;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;
import outfox.account.server.token.verifier.impl.TestUrsCookieVerifier;
import outfox.account.server.token.verifier.impl.TestUrsTokenVerifier;

/**
 * @author chen-chao
 */
public class TestAuthorizeHandler extends AccTestCase{
    TestTSinaVerifier sinaVerifier = null;
    TestTSinaVerifier fanfanVerifier = null;
    TestUrsCookieVerifier ursCookieVerifier = null;
    TestUrsTokenVerifier ursTokenVerifier = null;
    String fakeUrsUserName = "ynote_urs@163.com";
    String ynote = "YNOTE";
    String fanfan = "FANFAN";
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setUrsUserName(fakeUrsUserName);
        product = ynote;
        AccConfig.getPros().setProperty(AccConfig.NAME_ENABLE_READ_DATASTORE_CACHE, false);
        AccConfig.getPros().setProperty(AccConfig.NAME_ENABLE_MEMCACHED_IN_FILTER, false);
        startMiniZKCluster();
        startMockServer();
        sinaVerifier = new TestTSinaVerifier();
        sinaVerifier.setMockServer(mockServer);
        sinaVerifier.init(ynote);
        ursCookieVerifier = new TestUrsCookieVerifier();
        ursTokenVerifier = new TestUrsTokenVerifier();
        
        ursCookieVerifier.setMockServer(mockServer);
        ursCookieVerifier.init(ynote);
        ursTokenVerifier.setMockServer(mockServer);
        ursTokenVerifier.init(ynote);
        fanfanVerifier = new TestTSinaVerifier();
        fanfanVerifier.setMockServer(mockServer);
        fanfanVerifier.init(fanfan);
        caseRestart();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        sinaVerifier.destory();
        fanfanVerifier.destory();
        stopMockServer();
        stopMiniZKCluster();
        super.tearDown();
    }
    
    @Test
    public void testLogout() throws AccException {
        String clientType = "client";
        TokenBox box = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        assertTrue(box.sess != null);
        
        JSONObject obj = sinaVerifier.query(box.getSessBox(), COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        assertEquals(sinaVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.get(AccConst.USER_ID));
        // logout
        sinaVerifier.logout(box.getSessBox());
        // check , login=false
        checkNoLogin(ynote, box);
    }
    
    @Test
    public void testLogoutWithPrestoken() throws AccException {
        String clientType = "client";
        TokenBox box = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.pe.value());
        assertTrue(box.persToken != null);
        
        JSONObject obj = sinaVerifier.query(box.getPersTokenBox(), COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        assertEquals(sinaVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.get(AccConst.USER_ID));
        // logout
        sinaVerifier.logout(box.getPersTokenBox());
        // check , login=false
        checkNoLogin(ynote, box);
    }
    
    @Test
    public void testRemoveAuthorizeSelfApps() throws AccException {
        String clientType = "client";
        TokenBox box = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        
        // add mobiles
        String mobileType = "mobile";
        TokenBox boxMobile1 = sinaVerifier.getTokens(mobileType, COOKIE_FORMAT.se.value());
        
        String HtcType = "htc";
        TokenBox boxMobile2 = sinaVerifier.getTokens(HtcType, COOKIE_FORMAT.se.value());

        TokenBox boxMobile3 = sinaVerifier.getTokens(HtcType, COOKIE_FORMAT.se.value()|COOKIE_FORMAT.pe.value());
        
        // remove htc authorize
        sinaVerifier.revokeAuthorize(false, box.getSessBox(), null, HtcType, null, null);
        checkNoLogin(ynote,boxMobile2);
        checkNoLogin(ynote,boxMobile3);
        checkLogin(ynote,boxMobile1);
        
        boxMobile3 = sinaVerifier.getTokens(HtcType, COOKIE_FORMAT.se.value()|COOKIE_FORMAT.pe.value());
        sinaVerifier.revokeAuthorize(false, box.getSessBox(), null, mobileType, null, null);
        checkNoLogin(ynote,boxMobile3);
        checkNoLogin(ynote,boxMobile1);
        checkLogin(ynote,box);
        
        // remove self authorize
        sinaVerifier.revokeAuthorize(false, box.getSessBox(), null, clientType, null, null);
        checkNoLogin(ynote,box);
    }

    @Test
    public void testRemoveAuthorizeSelfTps() throws AccException {
        // client|urscookie , client|urstoken, mobile|urscookie, htc|urscookie, htc|urstoken
        AccConfig.setUrsUserName(TestUrsTokenVerifier.username);
        String clientType = "client";
        TokenBox box1 = ursCookieVerifier.getUrsCookieTokens(clientType, COOKIE_FORMAT.se.value());
        TokenBox box2 = ursTokenVerifier.getUrsToken(clientType, COOKIE_FORMAT.se.value());
        
        // add mobiles
        String mobileType = "mobile";
        TokenBox mobile1 = ursCookieVerifier.getUrsCookieTokens(mobileType, COOKIE_FORMAT.se.value());
        
        String HtcType = "htc";
        TokenBox htc1 = ursCookieVerifier.getUrsCookieTokens(HtcType, COOKIE_FORMAT.se.value());

        TokenBox htc2 = ursTokenVerifier.getUrsToken(HtcType, COOKIE_FORMAT.se.value()| COOKIE_FORMAT.pe.value());
        
        // remove htc authorize
        ursCookieVerifier.revokeAuthorize(false, box2.getSessBox(), null, null,"urstoken,tsina", null);
        checkLogin(ynote,box1);
        checkNoLogin(ynote,box2);
        checkLogin(ynote,mobile1);
        checkLogin(ynote,htc1);
        checkNoLogin(ynote,htc2);
        
        // login again
        box1 = ursCookieVerifier.getUrsCookieTokens(clientType, COOKIE_FORMAT.se.value());
        mobile1 = ursCookieVerifier.getUrsCookieTokens(mobileType, COOKIE_FORMAT.se.value());
        htc2 = ursTokenVerifier.getUrsToken(HtcType, COOKIE_FORMAT.se.value()| COOKIE_FORMAT.pe.value());
        
        ursCookieVerifier.revokeAuthorize(false, box1.getSessBox(), null, "client,htc", "urstoken,urscookie", null);
        checkNoLogin(ynote,box1);
        checkLogin(ynote,mobile1);
        checkNoLogin(ynote,htc1);
        checkNoLogin(ynote,htc2);
        AccConfig.setUrsUserName("");
    }
    
    @Test
    public void testRemoveAuthorizeBindTps() throws AccException {
        // client|urscookie , client|sina
        String clientType = "client";
        TokenBox tbUrs = ursCookieVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        TokenBox tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        TokenBox tbSinaLogin = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        TokenBox tbUrsBindSina = new TokenBox(tbUrs, tbSina);
        bind(ynote, tbUrsBindSina);
        
        // remove htc authorize
        ursCookieVerifier.revokeAuthorizeBind(false, tbUrs.getSessBox(), null, null,"urscookie,tsina", null);
        checkNoLogin(ynote,tbSinaLogin);
        checkNoLogin(ynote,tbUrs);
    }
}
