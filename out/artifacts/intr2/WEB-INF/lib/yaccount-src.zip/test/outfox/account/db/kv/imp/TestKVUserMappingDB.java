/**
 * @(#)TestKVUserMappingDB.java, 2012-11-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.data.MainId2ShadowIdWritable;
import outfox.account.db.in.IUserMappingDB;
import outfox.account.db.in.IUserMappingDB.IUserMappingIter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestKVUserMappingDB extends AccTestCase{
    private IUserMappingDB db;
    private String userMainA = "mainA@163.com";
    private String userA = "a";
    private String userB = "b";
    private String userC = "c";
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setReuseTableMode(false);
        db = new KVUserMappingDB();
        
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    @Test
    public void testWriteReadOne() throws AccException {
        /**
         * <pre>
         * mainA -> a
         * mainA -> b
         * 
         * </pre>
         */
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userA);
        db.write(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userB);
        db.write(mainId2ShadowIdWritable);
        
        mainId2ShadowIdWritable = db.readOne(userA);
        assertEquals(userMainA, mainId2ShadowIdWritable.getMainUserId());
        mainId2ShadowIdWritable = db.readOne(userB);
        assertEquals(userMainA, mainId2ShadowIdWritable.getMainUserId());
    }
    
    @Test
    public void testWriteRead() throws AccException {
        /**
         * <pre>
         * mainA -> a
         * mainA -> b
         * 
         * </pre>
         */
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userA);
        System.out.println(mainId2ShadowIdWritable.getBindingTimeStamp());
        db.write(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userB);
        db.write(mainId2ShadowIdWritable);
        System.out.println(mainId2ShadowIdWritable.getBindingTimeStamp());
        mainId2ShadowIdWritable = db.readShadow(userA);
        
        assertEquals(userMainA, mainId2ShadowIdWritable.getMainUserId());
        assertEquals(userA, mainId2ShadowIdWritable.getShadowUserId());
        System.out.println(mainId2ShadowIdWritable.getBindingTimeStamp());
        mainId2ShadowIdWritable = db.read(userMainA, mainId2ShadowIdWritable.getBindingTimeStamp());
        assertEquals(userMainA, mainId2ShadowIdWritable.getMainUserId());
        assertEquals(userA, mainId2ShadowIdWritable.getShadowUserId());
    }
    
    
    @Test
    public void testWriteRemove() throws AccException {
        /**
         * <pre>
         * mainA -> a
         * mainA -> b
         * 
         * </pre>
         */
        // case 1. remove mainA -> a && a -> mainA
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userA);
        db.write(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userB);
        db.write(mainId2ShadowIdWritable);
        
        mainId2ShadowIdWritable = db.readShadow(userA);
        
        db.remove(mainId2ShadowIdWritable);
        
        mainId2ShadowIdWritable = db.read(userMainA, mainId2ShadowIdWritable.getBindingTimeStamp());
        assertTrue(mainId2ShadowIdWritable == null);
        mainId2ShadowIdWritable = db.readShadow(userA);
        assertTrue(mainId2ShadowIdWritable == null);
        
        // case 2. remove a->mainA first, then remove mainA->a
        mainId2ShadowIdWritable = db.readShadow(userB);
        db.removeShadowOnly(mainId2ShadowIdWritable);
        MainId2ShadowIdWritable tmp = db.readShadow(userB);
        assertTrue(tmp == null);
        
        db.removeMainOnly(mainId2ShadowIdWritable);
        tmp = db.read(mainId2ShadowIdWritable.getMainUserId(), mainId2ShadowIdWritable.getBindingTimeStamp());
        assertTrue(tmp == null);
    }
    
    
    @Test
    public void testWriteIter() throws AccException {
        /**
         * <pre>
         * mainA -> a
         * mainA -> b
         * mainA -> c
         * </pre>
         */
        // case 1. from beginning
        MainId2ShadowIdWritable mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userA);
        db.write(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userB);
        db.write(mainId2ShadowIdWritable);
        mainId2ShadowIdWritable = new MainId2ShadowIdWritable(userMainA, userC);
        db.write(mainId2ShadowIdWritable);
        
        IUserMappingIter iter = db.getIter(userMainA);
        int cnt = 0;
        while(iter.next() != null) {
            cnt++;
        }
        iter.close();
        assertEquals(3, cnt);
        
        // case 2. from middle
        mainId2ShadowIdWritable = db.readShadow(userB);
        
        iter = db.getIter(mainId2ShadowIdWritable.getMainUserId(), mainId2ShadowIdWritable.getBindingTimeStamp());
        cnt = 0;
        while(iter.next() != null) {
            cnt++;
        }
        iter.close();
        assertEquals(2, cnt);
    }
}
