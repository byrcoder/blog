/**
 * @(#)TestConfig.java, 2011-11-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.config;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;

/**
 * Config class must read from auth.conf file All fields should prefix with "GLOBAL" or "APPNAME" if some fields miss
 * prefix, it should be used in no less than one case. for example: in auth.conf file, there are global.temp and
 * web.temp. so TEMP can be a field name
 * 
 * @author chen-chao
 */
public class TestConfig extends AccTestCase {
    @Before
    protected void setUp() throws Exception {
        AccConfig.setTestCaseMode(false);
        init();
    }

    @After
    protected void tearDown() throws Exception {
        deleteFile(appConfFile);
        AccConfig.setTestCaseMode(true);
    }

    public static void init() throws IOException {

        confFile = createFile(confPath, confFile);

        StringBuilder sb = new StringBuilder();
        sb.append("<auth><conf><file>home</file></conf>")
          .append("<client><cookie_expire>30</cookie_expire></client>")
          .append("<web><check>true</check>")
          .append("<cookie_expire>")
          .append(Long.MAX_VALUE)
          .append("</cookie_expire></web>")
          .append("</auth>\n");
        writeStringToFile(confFile, sb.toString(), false);
    }

    @Test
    public void test() {
        AccConfig.init(homePath);
        assertEquals("home", AccConfig.getPros().getString("conf.file"));
        AccConfig.init(homePath);
        assertEquals(Long.MAX_VALUE, AccConfig.getLongProperty("web", "cookie_expire"));
        assertEquals(30, AccConfig.getIntProperty("client", "cookie_expire"));
        assertEquals(true, AccConfig.checkAppName("web"));
        assertEquals(true, AccConfig.checkAppName("client"));
    }
}
