/**
 * @(#)TestTSinaVerifier.java, 2012-9-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 *
 * @author chen-chao
 *
 */
public class TestTSinaCallbackWithRu extends VerifierTestCaseBase{

    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
    }

    public void init(String product) {
        super.init(product, "tsina");
        Properties pros = genTSinaProperty(getLocalHostHttpsUrl("/sina/"));
        TSinaVerifier tsinaVerifier = genTSinaVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, "tsina", tsinaVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    
    @Test
    public void testTSinaBindGetAccessToken() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.b.value(), "http://dict.youdao.com/search");
        assertTrue(box.bind != null);
        assertTrue(queryGetBindAccessToken(box.getBindBox()) != null);
    }
    
    @Test
    public void testTSinaBindGetAccessTokenWithRu() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.b.value(), "http://dict.youdao.com/search?q=test&keyfrom=dict.index");
        assertTrue(box.bind != null);
        assertTrue(queryGetBindAccessToken(box.getBindBox()) != null);
    }
}
