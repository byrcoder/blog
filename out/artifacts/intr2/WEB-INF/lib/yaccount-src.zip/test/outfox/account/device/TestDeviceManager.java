/**
 * @(#)TestDeviceStore.java, 2013-6-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.device;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.OPERATOR;
import outfox.account.data.Parameter;
import outfox.account.logic.event.AccEvent;

/**
 *
 * @author zhanglz
 *
 */
public class TestDeviceManager extends AccTestCase {
    private static final long deviation = 1000;
    private static List<File> confFiles;
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.getPros().setProperty(AccConfig.NAME_DEVICE_PING_DEVIATION, deviation);
        confFiles = prepareTemplateConfFile("./conf");
    }
    
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
        for (File file : confFiles) {
            file.delete();
        }
    }
    
    @Test
    public void testDeviceStore() throws Exception {
        String product = "YNOTE";
        String deviceId = "device1";
        String userId = "user";
        String userId2 = "user2";
        DeviceStore store = DeviceStore.getInstance();
        List<String> deletingUsers = store.getDeletingUsers(product, deviceId);
        assertEquals(0, deletingUsers.size());
        DeviceStatus status = store.getDeviceStatus(product, userId, deviceId, true);
        assertEquals(null, status);
        store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.ONLINE);
        status = store.getDeviceStatus(product, userId, deviceId, true);
        assertEquals(DeviceStatus.ONLINE, status);
        store.updateDeviceStatus(product, userId, deviceId, DeviceStatus.DELETING);
        status = store.getDeviceStatus(product, userId, deviceId, true);
        assertEquals(DeviceStatus.DELETING, status);
        deletingUsers = store.getDeletingUsers(product, deviceId);
        assertEquals(1, deletingUsers.size());
        store.updateDeviceStatus(product, userId2, deviceId, DeviceStatus.DELETING);
        deletingUsers = store.getDeletingUsers(product, deviceId);
        assertEquals(2, deletingUsers.size());
    }
    
    @Test
    public void testDeviceManager() throws Exception {
        String product = "YNOTE";
        String deviceId = "deviceId2";
        String userId = "userId";
        String userId2 = "userId2";
        List<Parameter> result = new ArrayList<Parameter>();
        List<AccEvent> eventList = new ArrayList<AccEvent>();
        MockHttpServletRequest req = new MockHttpServletRequest();
        req.setParameter(AccConst.PARAM_DEVICE_ID, deviceId);
        // 0. cq a not exists device.
        boolean checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.CQ, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertEquals(0, result.size());
        result.clear();
        eventList.clear();
        DeviceManager.handleEvents(eventList);
        
        // 1. a new device login.
        checkRes = DeviceManager.tryTransferStatus(product, userId2, 
                OPERATOR.LOGIN, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertEquals(0, result.size());
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 1.1 another user login, kick off previous user.
        List<String> onlineUsers = DeviceStore.getInstance().listOnlineUsers(
                product, deviceId);
        assertEquals(1, onlineUsers.size());
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.LOGIN, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertEquals(0, result.size());
        DeviceManager.handleEvents(eventList);
        onlineUsers = DeviceStore.getInstance().listOnlineUsers(
                product, deviceId);
        assertEquals(2, onlineUsers.size());
        // wait for kicking off.
        Thread.sleep(3000);
        onlineUsers = DeviceStore.getInstance().listOnlineUsers(
                product, deviceId);
        assertEquals(1, onlineUsers.size());
        result.clear();
        eventList.clear();
        
        
        // 2. cq login device.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.CQ, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertEquals(0, result.size());
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 4. request logout.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.REQUEST_LOGOUT, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertEquals(0, result.size());
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 5. cq logouting device.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.CQ, null, req, result, eventList);
        assertEquals(false, checkRes);
        assertEquals(0, eventList.size());
        assertTrue(result.size() > 0);
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 6. finish logout.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.FINSIH_LOGOUT, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertTrue(result.size() == 0);
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 7. request delete.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.REQUEST_DELETE, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertTrue(result.size() == 0);
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 8. finish delete.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.FINISH_DELETE, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertTrue(result.size() == 0);
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
        
        // 9. login deleted device.
        checkRes = DeviceManager.tryTransferStatus(product, userId, 
                OPERATOR.LOGIN, null, req, result, eventList);
        assertEquals(true, checkRes);
        assertEquals(1, eventList.size());
        assertEquals(0, result.size());
        DeviceManager.handleEvents(eventList);
        result.clear();
        eventList.clear();
    }
    
    private List<File> prepareTemplateConfFile(String dir) throws Exception {
        File confDir = new File(dir);
        List<File> result = new ArrayList<File>();
        File[] confFiles = confDir.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.getName().endsWith("template");
            }
        });

        for (File file: confFiles) {
            String name = file.getName();
            File dstFile = new File(confDir, name.substring(0, name.length() - ".template".length()));
            FileOutputStream fos = null;
            FileInputStream fis = null;
            try {
                fos = new FileOutputStream(dstFile);
                fis = new FileInputStream(file);
                IOUtils.copy(fis, fos);
                result.add(dstFile);
            } finally {
                IOUtils.closeQuietly(fos);
                IOUtils.closeQuietly(fis);
            }

        }

        return result;
    }
}
