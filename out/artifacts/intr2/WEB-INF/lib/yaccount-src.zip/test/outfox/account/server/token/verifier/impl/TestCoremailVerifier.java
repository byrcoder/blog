/**
 * @(#)TestCoremailVerifier.java, 2013-3-4. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Endpoint;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.coremail.FakeCoremailConst;
import outfox.account.faketp.server.coremail.FakeCoremailWebService.API;
import outfox.account.server.token.verifier.VerifierTestCaseBase;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient;
/**
 * @author chen-chao
 */
public class TestCoremailVerifier extends VerifierTestCaseBase{
    int freePort = 0;
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        freePort = AuthUtils.getFreePort();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        Endpoint.publish("http://localhost:"+freePort+"/coremail/services/API", new API());
        AccConfig.getPros().setProperty(AccConfig.NAME_CHECK_URS_EXIST_URL, getLocalHostHttpsUrl("/urstoken/checkUsername"));
        AccConfig.getPros().setProperty("YNOTE.coremail.user-meta-url", getLocalHostHttpsUrl("/ynote/getusermeta"));
        init("YNOTE");
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    public void init(String product) {
        super.init(product, "coremail");
    }
    
    @Test
    public void test() throws AccException {
        String clientType = "client";
        DataStore.getInstance().writeCoremailDomainURL("fake.com", "http://localhost:"+freePort+"/coremail/services/API?wsdl");
        TokenBox box = getCoremailToken(clientType, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), FakeCoremailConst.SID_VALID, FakeCoremailConst.USER_ID_OLD);
        
        assertTrue(box.sess != null);
        assertEquals(FakeCoremailConst.USER_ID_OLD, box.ret.get(AccConst.USER_ID));
        // MUST not have persToken
        assertTrue(StringUtils.isBlank(box.persToken));
        tokenBoxQuery(box, FakeCoremailConst.USER_ID_OLD);
        tokenBoxQuery(box.getSessBox(), FakeCoremailConst.USER_ID_OLD);
        
        tokenBoxQueryNone(box.getEmptyBox());
    }
    
    @Test
    public void testReuseAccount() throws AccException, ParseException, IOException {
        String clientType = "client";
        DataStore.getInstance().writeCoremailDomainURL("fake.com", "http://localhost:"+freePort+"/coremail/services/API?wsdl");
        TokenBox box = getCoremailToken(clientType, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), FakeCoremailConst.SID_VALID, FakeCoremailConst.USER_ID_OLD);
        
        assertTrue(box.sess != null);
        assertEquals(FakeCoremailConst.USER_ID_OLD, box.ret.get(AccConst.USER_ID));
    }
    
    @Test
    public void testUserCoremailHandlerLogin() throws AccException, ParseException, IOException {
        DataStore.getInstance().writeCoremailDomainURL("fake.com", "http://localhost:"+freePort+"/coremail/services/API?wsdl");
        TokenBox box = getCoremailTokenFromCoremailHandler( FakeCoremailConst.SID_VALID, FakeCoremailConst.USER_ID_OLD);
        assertTrue(box.sess != null);
        assertTrue(StringUtils.isBlank(box.persToken));
        tokenBoxQuery(box.getSessBox(), FakeCoremailConst.USER_ID_OLD);
    }
    
    
    public TokenBox getCoremailToken(String clientType, int cookieFormat, String sid, String userId) throws AccException {
        cookieStore.clear();
        // 1. use user name and password to login in HTTPS protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_COREMAIL_SID, sid));
        params.add(new Parameter(AccConst.PARAM_COREMAIL_USERID, userId));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(null, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
    
    public TokenBox getCoremailTokenFromCoremailHandler(String sid, String userId) throws AccException {
        cookieStore.clear();
        // 1. use user name and password to login in HTTPS protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_COREMAIL_SID, sid));
        params.add(new Parameter(AccConst.PARAM_COREMAIL_USERID, userId));
        HttpResponse resp = client.doGet(getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.COREMAIL_LOGIN_AUTH)), null, params);
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(new JSONObject());
        cookieStore.clear();
        return tb;
    }
    
    
    public void LoginFail(String clientType, int cookieFormat, String sid, String userId,AccExpType errType) throws AccException, ParseException, IOException {
        cookieStore.clear();
        // 1. use user name and password to login in HTTPS protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_COREMAIL_SID, sid));
        params.add(new Parameter(AccConst.PARAM_COREMAIL_USERID, userId));
        params.add(new Parameter(AccConst.PARAM_SHOW_ERROR, true));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        HttpResponseAndJSON result = doLoginWithTestDevice(null, params);
        HttpResponse resp = result.response;
        JSONObject obj = result.jsonObj;
        // error
        checkStatusCode(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        int ecode = obj.getInt(AccConst.ERROR_CODE);
        assertEquals(errType.getErrorCode(), ecode);
    }
}
