/**
 * @(#)TestCrossHandler.java, 2013-8-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.cookie.Cookie;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class TestCookieCrossHandler extends AccTestCase{
    TestTSinaVerifier testVerifier = null;

    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        
        testVerifier = new TestTSinaVerifier();
        testVerifier.setUp();
        setMockServer(testVerifier.getMockServer());
        caseRestart();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        testVerifier.tearDown();
        
        super.tearDown();
    }
    @Test
    public void test() throws AccException {
        String clientType = "client";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        assertTrue(box.sess != null);
        String pci = crossFirst(box);
        crossSecond(pci, true);
    }
    
    public String crossFirst(TokenBox box) throws AccException {
        cookieStore.clear();
        List<Header> headers = composeAuthHeader(testVerifier.getProduct(), box.getSessBox());
        JSONObject obj = client.getJSON(Method.GET,getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.CROSS_PROCESS_FIRST_URL)), headers, null, null);
        assertTrue(obj.containsKey(AccConst.PARAM_PCINDEX_NAME));
        return obj.getString(AccConst.PARAM_PCINDEX_NAME);
    }
    
    public void crossSecond(String pci, boolean isKeepToken) throws AccException {
        cookieStore.clear();
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        if (isKeepToken){
            params.add(new Parameter(AccConst.PARAM_KEEP_TOKEN, true));
        }
        HttpResponse resp = null;
        try {
            resp = client.doGet(getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.CROSS_PROCESS_SECOND_URL)), null, params);
            removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
            Cookie sess = getCookieInStore(testVerifier.getProduct() + AccConst.COOKIE_SESSION);
            assertTrue(sess != null);
            if (isKeepToken){
                Cookie keepTokenCookie = getCookieInStore(testVerifier.getProduct() + AccConst.COOKIE_KEEP_TOKEN);
                assertTrue(keepTokenCookie != null);
            }
        } finally {
            AccHttpClient.closeQuiet(resp);
        }
    }
}
