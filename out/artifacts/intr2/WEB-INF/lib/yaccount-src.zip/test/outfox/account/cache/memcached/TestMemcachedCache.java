/**
 * @(#)TestMemcachedCache.java, 2012-10-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache.memcached;

import org.junit.Test;
import org.springframework.cache.Cache.ValueWrapper;

import outfox.account.AccTestCase;
import outfox.account.data.Parameter;

/**
 *
 * @author licx
 */
public class TestMemcachedCache extends AccTestCase {

    @Test
    public void test() throws Exception {
        MemcachedCache cache = new MemcachedCache("Test");
        cache.setMemcachedClient(new MockMemcachedClient());
        cache.setTranscoder(new SerializationTranscoder());
        // put 2 values
        cache.put("key1", 123);
        Parameter p = new Parameter("key2", "ooo");
        cache.put("key2", p);
        // get these 2 values
        Parameter p2 = (Parameter)cache.get("key2").get();
        Integer num = (Integer)cache.get("key1").get();
        assertEquals(123, num.intValue());
        assertEquals(p.key, p2.key);
        assertEquals(p.val, p2.val);
        // evict these 2 values
        cache.evict("key1");
        cache.evict("key2");
        // get these 2 values again
        ValueWrapper value1 = cache.get("key1");
        ValueWrapper value2 = cache.get("key2");
        assertNull(value1);
        assertNull(value2);
    }

    @Test
    public void testExpiration() throws Exception {
        MemcachedCache cache = new MemcachedCache("Test");
        cache.setMemcachedClient(new MockMemcachedClient());
        cache.setTranscoder(new SerializationTranscoder());
        // set the expiration time to 2 seconds
        cache.setExpirationTime(2);
        cache.put("key1", 123);
        // sleep for 1 second and get the value
        Thread.sleep(1000);
        Integer num = (Integer)cache.get("key1").get();
        assertEquals(123, num.intValue());
        // sleep for another 1.5 seconds and get the value, the value is expire
        Thread.sleep(1500);
        ValueWrapper value = cache.get("key1");
        assertNull(null, value);
    }
}
