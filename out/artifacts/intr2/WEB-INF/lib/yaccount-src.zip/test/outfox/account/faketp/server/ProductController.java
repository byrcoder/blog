/**
 * @(#)ProductController.java, 2012-10-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.conf.AccConst;
import outfox.account.exceptions.AccException;
import outfox.account.utils.ReqUtils;

/**
 * @author chen-chao
 */
public class ProductController extends BaseFakeController{
    private static final long serialVersionUID = 8503676609573258769L;

    public ProductController() {
        super();
    }
    
    public void doGet(HttpServletRequest req, HttpServletResponse resp) {
        
        Method m = cache.get(getMappingURI(req));
        try {
            if (m != null) {
                m.invoke(this, req, resp);
            }
            
        } catch (Exception e) {
          System.out.println("Exceptin: " + e);
        }
    }
    @RequestMapping("/product/query")
    public void query(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        String userId = ReqUtils.getUserId(req);
        
        String productUserId = ReqUtils.getUserId(req, "YNOTE");
        Map<String,Object> params = new HashMap<String, Object>();
        if (StringUtils.isBlank(userId)) {
            userId = "null";
        } 
        if (StringUtils.isBlank(productUserId)) {
            productUserId = "null";
        }
        params.put(AccConst.USER_ID_ATTR, userId);
        params.put(AccConst.USER_ID, productUserId);
        
        write(req, resp, params, HttpStatus.OK);
    }
    
    @RequestMapping("/product/publicView")
    public void publicView(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        String userId = (String)req.getAttribute(AccConst.ATTR_PUBLIC_VIEW_USER_ID);
        
        Map<String,Object> params = new HashMap<String, Object>();
        if (StringUtils.isBlank(userId)) {
            userId = "null";
        } 
        params.put(AccConst.ATTR_PUBLIC_VIEW_USER_ID, userId);
        write(req, resp, params, HttpStatus.OK);
    }
    
    public void doPost(HttpServletRequest req, HttpServletResponse resp) {
        doGet(req, resp);
    }
}
