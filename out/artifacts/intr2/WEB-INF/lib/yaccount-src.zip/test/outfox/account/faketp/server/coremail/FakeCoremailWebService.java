/**
 * @(#)WB.java, 2013-3-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.coremail;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import outfox.account.conf.AccConst;

/**
 * @author chen-chao
 */

public class FakeCoremailWebService {
    @WebService(
            targetNamespace=AccConst.COREMAIL_API_URL,
            serviceName = AccConst.PARAM_API_NAME,
            portName = "APIPort")
    public static class API {
        @WebMethod
        @WebResult(name="return")
        public ReturnInfo sesTimeOut(@WebParam(name="ses_id")String ses_id) {
            ReturnInfo ret = new ReturnInfo();
            if (FakeCoremailConst.SID_VALID.equals(ses_id)) {
                ret.code = 0;
                
                ret.result = "uid="+FakeCoremailConst.USER_ID_OLD;
                
            } else if (FakeCoremailConst.SID_VALID2.equals(ses_id)) {
                ret.code = 0;
                
                ret.result = "uid="+FakeCoremailConst.USER_ID_NEW;
                
            } else if (FakeCoremailConst.SID_INVALID.equals(ses_id)) {
                // invalid
            } else {
                // fake
            }
            return ret;
        }
        
        /**
         * return Coremail API Service Version 4.0.5a build 20121109(17793.5019.5013)
         * @param user_at_domain
         * @param attrs
         * @return
         */
        @WebMethod
        public String getVersionInfo() {
            return "Coremail API Service Version 4.0.5a build 20121109(17793.5019.5013)";
        }
        @WebMethod
        @WebResult(name="return")
        public ReturnInfo getAttrs(
                @WebParam(name="user_at_domain")String user_at_domain, 
                @WebParam(name="attrs")String attrs) {
            ReturnInfo ret = new ReturnInfo();
            if ("user_creation_date".equals(attrs)) {
                
                if (FakeCoremailConst.USER_ID_OLD.equals(user_at_domain)) {
                    ret.code = 0;
                    ret.result = "user_creation_date=1970-01-01 14:30:23.000";
                } else if (FakeCoremailConst.USER_ID_NEW.equals(user_at_domain)) {
                    ret.code = 0;
                    ret.result = "user_creation_date=2333-01-01 14:30:23.000";
                } 
            }
            return ret;
        }
        @XmlRootElement  
        @XmlAccessorType(XmlAccessType.FIELD)  
        public static class ReturnInfo {
            int code;
            String message;
            String result;
            public ReturnInfo () {
                code = 1;
                message = "";
                result = "";
            }
        }
    }
        
}
