/**
 * @(#)HelloServletTest.java, 2012-8-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.OAuth2Utils;

/**
 * @author chen-chao
 */
@Controller
public class HelloServletTest extends BaseFakeController {
    
    /**
     * 
     */
    private static final long serialVersionUID = 3029350343120220050L;

    public HelloServletTest(){
        super();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        System.out.println("absoluteUrl:" + AuthUtils.generateAbsoluteUrl(req, ""));
        System.out.println("pathInfo:" + req.getPathInfo());
        System.out.println("reqURI:" + req.getRequestURI());
        System.out.println("reqURL:" + req.getRequestURL());
        System.out.println("queryString:" + req.getQueryString());
        System.out.println("context path:" + req.getContextPath());
        System.out.println("mappingURI:" + getMappingURI(req));
        System.out.println("localAddress:" + req.getLocalAddr());
        System.out.println("local port:" + req.getLocalPort());
        System.out.println("remote host:" + req.getRemoteHost());
        System.out.println("remote port:" + req.getRemotePort());
        System.out.println("servername:" + req.getServerName());
        Method m = cache.get(getMappingURI(req));
        try {
            if (m != null) {
                m.invoke(this, req, resp);
            }
            
        } catch (Exception e) {
          System.out.println("Exceptin: " + e);
        }
    }

    public void hello(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException {
        resp.setContentType("text/plain");
        resp.getOutputStream().write("hello".getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping("/aa/test1")
    public void test1(HttpServletRequest req, HttpServletResponse resp){
        
    }
    @RequestMapping(value ="/aa/test2", method=RequestMethod.GET)
    public void test2(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException {
        resp.setContentType("text/plain");
        resp.getOutputStream().write("cc".getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping(value ="/aa/test3", method=RequestMethod.GET, params="method=test3")
    public void test3(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException {
        resp.setContentType("text/plain");
        OAuth2Utils.addQueryAttribute(req, resp);
        resp.getOutputStream().write("test3".getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping(value ="/aa/test4", method=RequestMethod.POST, params="method=test4")
    public void test4(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException {
        resp.setContentType("text/plain");
        OAuth2Utils.getQueryAttribute(req, resp);
        resp.getOutputStream().write("test4".getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping(value ="/aa/test5")
    public void test5(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException {
        resp.setContentType("text/plain");
        OAuth2Utils.addQueryAttribute(req, resp);
        resp.addCookie(AuthUtils.genCookie(AccConst.ATTR_QUERY, req.getQueryString()+"-recover", AuthUtils.getCookieDomain(req),
                AccConst.URL_ROOT, -1, true));
        resp.getOutputStream().write("test5".getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping(value ="/aa/test6")
    public void test6(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException, AccException {
        checkParam(req, "zz", "uu");
        resp.setContentType("text/plain");
        String zz = req.getParameter("zz");
        System.out.println(req.getQueryString());
        System.out.println(req.getQueryString());
        System.out.println(req.getQueryString());
        System.out.println(req.getQueryString());
        resp.getOutputStream().write(("test6 " + zz).getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping("/aa/map2list")
    public void map2List(HttpServletRequest req, HttpServletResponse resp) throws AccException{
        List<Parameter> params = new ArrayList<Parameter>();
        List<Parameter> params1 = new ArrayList<Parameter>();
        List<Parameter> params2 = new ArrayList<Parameter>();
        params1.add(new Parameter("1.1-key", "1.1"));
        params1.add(new Parameter("1.2-key", "1.2"));
        params1.add(new Parameter("1.3-key", "1.3"));
        params2.add(new Parameter("2.1-key", "2.1"));
        params.add(new Parameter("1", params1));
        params.add(new Parameter("2", params2));
        write(req, resp, params, HttpStatus.OK);
    }
}
