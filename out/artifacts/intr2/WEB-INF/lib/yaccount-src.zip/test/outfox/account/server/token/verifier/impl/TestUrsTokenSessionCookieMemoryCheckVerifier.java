/**
 * @(#)TestUrsTokenVerifier.java, 2012-10-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import static com.netease.urs.CookieNames.NTES_SESS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.MalformedCookieException;
import org.apache.http.message.BasicHeader;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.AccConst.METHOD_NAMES;
import outfox.account.data.Parameter;
import outfox.account.data.SessionCookieWritable;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;
/**
 * @author chen-chao
 */
public class TestUrsTokenSessionCookieMemoryCheckVerifier extends VerifierTestCaseBase{
    public static final String username = "urstest_ynote@163.com";
    public static final String password = "test123";
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        caseRestart();
        init("DICT"); 
    }
    public void init(String product) {
        super.init(product, VerifierConfConst.URS_TOKEN_VERIFIER_NAME);
        Properties pros = genUrsTokenProperty(getLocalHostHttpsUrl("/urstoken/"));
        URSTokenVerifier tokenVerifier = genURSTokenVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, tokenVerifier);
    }
    @Override
    protected void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobile() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, "mobile"));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_ALOGRITHM, CIPHER_ALGORITHM_TYPE.RSA_DEFAULT.getAlias()));
        JSONObject obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null, params, null);
        assertTrue(obj.containsKey(AccConst.PARAM_PCINDEX_NAME));
        assertTrue(obj.containsKey(AccConst.PARAM_PC_NAME));
        String pci = obj.getString(AccConst.PARAM_PCINDEX_NAME);
        String pc = obj.getString(AccConst.PARAM_PC_NAME);
        // 2. pc convert to key.
        String loginInfo = AuthUtils.rsaEncryptHex(pc, 
                new Parameter(URSTokenVerifier.URS_USERNAME, "18311097506"),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex("test123")));
        // 3. use pci to login
        params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        params.add(new Parameter(AccConst.PARAM_URS_MEMORY_COOKIE, true));
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result.response;
        obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        Cookie session = getCookieInStore(product + AccConst.COOKIE_SESSION);
        assertTrue(session != null);
        assertTrue(session.getValue().startsWith(AccConst.V2_FLAG+AccConst.URS_MEMORY_CHECK));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        assertTrue(obj.getString(AccConst.USER_ID).startsWith("m18311097506_"));
        assertTrue(obj.containsKey(product + AccConst.ATTR_PART_PC));
        
    }
    @Test
    public void testQueryGetDifferentCookies() throws AccException {
        // 5. query again
        String clientType = "web";
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value();
        TokenBox box = getUrsToken(clientType, format);
        cookieStore.clear();
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, format));
        params.add(new Parameter(AccConst.PARAM_URS_MEMORY_COOKIE, true));
        List<Header> headers = composeAuthHeader(product, box.getPersTokenBox());
        HttpResponse resp = client.doGet(getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.COOKIE_QUERY_URL)), headers, params);
        checkStatusCode(resp, HttpStatus.OK);
        
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        Cookie session = getCookieInStore(product + AccConst.COOKIE_SESSION);
        assertTrue(StringUtils.isNotBlank(session.getValue()));
        // do again. must get two different session cookie.
        cookieStore.clear();
        headers = composeAuthHeader(product, box.getPersTokenBox());
        resp = client.doGet(getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.COOKIE_QUERY_URL)), headers, params);
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        Cookie session2 = getCookieInStore(product + AccConst.COOKIE_SESSION);
        assertTrue(StringUtils.isNotBlank(session2.getValue()));
        assertTrue(!session.getValue().equals(session2.getValue()));
    }
    
    @Test
    public void testGetSessCookie() throws AccException{
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value();
        String clientType = "client";
        AccConfig.setUrsUserName(username);
        TokenBox box = getUrsToken(clientType, format, username, password);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_METHOD, METHOD_NAMES.WRITE_COOKIE.name()));
        List<Header> header = composeAuthHeader(product, box.getSessBox());
        HttpResponse resp = client.doGet(getLocalHostHttpUrlWithPerfix(AccConst.GET_URS_SESS_URL), header, params);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        Cookie c = getCookieInStore(NTES_SESS);
        assertTrue(c != null);
        cookieStore.clear();
    }
    
    public TokenBox getUrsToken(String clientType, int cookieFormat) throws AccException {
        return getUrsToken(clientType, cookieFormat, username, password);
    }
    
    public TokenBox getUrsToken(String clientType, int cookieFormat, String username, String password) throws AccException {
        cookieStore.clear();
        // 1. use user name and password to login in HTTPS protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(URSTokenVerifier.URS_USERNAME, username));
        params.add(new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex(password)));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        params.add(new Parameter(AccConst.PARAM_URS_MEMORY_COOKIE, true));
        HttpResponseAndJSON result = doLoginWithTestDevice(null, params);
        HttpResponse resp = result.response;
        JSONObject obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
    @Test
    public void testExpiredSessionCookie() throws AccException {
        AccConfig.getPros().setProperty(AccConfig.NAME_MEMCACHED_CACHE_REFRESH_TIME, 10);
        AccConfig.setUrsUserName(username);
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value();
        String clientType = "client";
        TokenBox tb = getUrsToken(clientType, format);
        checkQuery(tb, username);
        String sessVal = tb.sess.getValue();
        final DataStore instance = DataStore.getInstance();
        sessVal = sessVal.substring("v2|".length());
        SessionCookieWritable sessWritable = instance.getAliveSession(sessVal, -1);
        
        sessWritable.setSessAliveTime(0L);
        instance.writeSessToken(sessWritable.getTpToken());
        cookieStore.clear();
        JSONObject obj = queryInfo(tb.getSessBox());
        // without cache or omap check ( so always be true)
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
    }
    
    @Test
    public void testRevokeAuthorizeOfMemoryCookie() throws AccException {
        AccConfig.setUrsUserName(username);
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value() ;
        String clientType = "client";
        TokenBox tb = getUrsToken(clientType, format);
        checkQuery(tb, username);
        logout(product, tb);
        checkNoLogin(product,tb);
    }
}
