/**
 * @(#)TestGetSessHandler.java, 2012-12-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class TestGetSessHandler extends AccTestCase{
    TestTSinaVerifier testVerifier = null;

    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        
        testVerifier = new TestTSinaVerifier();
        testVerifier.setUp();
        setMockServer(testVerifier.getMockServer());
        caseRestart();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        testVerifier.tearDown();
        
        super.tearDown();
    }
    @Test
    public void testGetSessCookie() throws AccException {
        String clientType = "client";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.pe.value());
        assertTrue(box.persToken != null);
        List<Header> headers = composeAuthHeader(testVerifier.getProduct(), box.getPersTokenBox());
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_GET_USER_INFO, true));
        JSONObject obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AuthUtils.makeUrl(AccConst.GET_SESS_URL)), headers, params, null);
        assertEquals(testVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.get(AccConst.USER_ID));
    }
}
