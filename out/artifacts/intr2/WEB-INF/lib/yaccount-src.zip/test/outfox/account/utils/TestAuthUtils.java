/**
 * @(#)TestAuthUtils.java, 2012-9-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.security.KeyPair;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.data.CipherKeyPair;
import outfox.account.data.Parameter;
import outfox.account.data.SerializableA;
import outfox.account.data.SerializableB;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.rpc.protocol.impl.MemoryCacheService;

/**
 * @author chen-chao
 */
public class TestAuthUtils extends AccTestCase{
    
    @Test 
    public void testRSAKeyCache() throws AccException {
        KeyPair kp1 = AuthUtils.genRSAKeysCache("1".getBytes());
        assertTrue(kp1.getPrivate().getEncoded() != null);
        assertTrue(kp1.getPublic().getEncoded() != null);
    }
    
    @Test
    public void testCipherKeysByAlogrithm() throws AccException {
        String secretContent = "username=ynote_test001&password=test123&userip=127.0.0.1";
        CipherKeyPair keyPair = AuthUtils.genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE.AES_DEFAULT);
        assertEquals(keyPair.getDecryptKey(), keyPair.getEncryptKey());
        aesEnDeCipher(secretContent, keyPair.getEncryptKey());
        keyPair = AuthUtils.genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE.AES_CBC_PKCS5);
        assertEquals(keyPair.getDecryptKey(), keyPair.getEncryptKey());
        aesEnDeCipher(secretContent, keyPair.getEncryptKey());
        keyPair = AuthUtils.genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE.AES_CBC_PKCS7);
        assertEquals(keyPair.getDecryptKey(), keyPair.getEncryptKey());
        aesEnDeCipher(secretContent, keyPair.getEncryptKey());
        keyPair = AuthUtils.genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE.RSA_DEFAULT);
        rsaEnDeCipher(secretContent, keyPair.getEncryptKey(), keyPair.getDecryptKey());
        keyPair = AuthUtils.genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE.RSA_ECB_PKCS1);
        rsaEnDeCipher(secretContent, keyPair.getEncryptKey(), keyPair.getDecryptKey());
        try {
            AuthUtils.genCipherKeysByAlogrithm(CIPHER_ALGORITHM_TYPE.NONE);
        } catch (AccException e) {
            assertEquals(AccExpType.PARAM_NOT_EQUAL_TAGET_ERROR, e.getExceptionType());
        }
    }
    
    @Test
    public void testgetParameter() throws AccException {
        final String NAME_UID = "uid";
        String uid = AuthUtils.getParameter(null, NAME_UID);
        assertEquals(null, uid);
        uid = AuthUtils.getParameter("", NAME_UID);
        assertEquals(null, uid);
        uid = AuthUtils.getParameter("uid=", NAME_UID);
        assertEquals("", uid);
        uid = AuthUtils.getParameter("uid=1", NAME_UID);
        assertEquals("1", uid);
        uid = AuthUtils.getParameter("uid=1&32309=32", NAME_UID);
        assertEquals("1", uid);
        uid = AuthUtils.getParameter("32309=32&uid=1&230", NAME_UID);
        assertEquals("1", uid);
        uid = AuthUtils.getParameter("32309=32&uid=1", NAME_UID);
        assertEquals("1", uid);
    }
    
    @Test 
    public void testRSAKeyGen() throws AccException {
        int count = 5;
        KeyPair kp1 = AuthUtils.genRSAKeys("1".getBytes());
        KeyPair kp2 = AuthUtils.genRSAKeys("1".getBytes());
        String privateKey = Hex.encodeHexString(kp1.getPrivate().getEncoded());
        assertEquals(privateKey, Hex.encodeHexString(kp2.getPrivate().getEncoded()));
        Set<String> keys = new HashSet<String>();
        for (int i = 0; i < count; i++) {
            kp1 = AuthUtils.genRSAKeys(null);
            kp2 = AuthUtils.genRSAKeys(null);
            privateKey = Hex.encodeHexString(kp1.getPrivate().getEncoded());
            keys.add(privateKey);
            keys.add(Hex.encodeHexString(kp1.getPublic().getEncoded()));
            // keys will not equals
            assertTrue(!privateKey.equals(Hex.encodeHexString(kp2.getPrivate().getEncoded())));    
        }
        assertEquals(count * 2, keys.size());
    }
    
    @Test 
    public void testRSA() throws AccException {
        KeyPair kp = AuthUtils.genRSAKeys(null);
        String privateKey = Hex.encodeHexString(kp.getPrivate().getEncoded());
        String rawContent = "12,34,sda";
        byte[] encode = AuthUtils.rsaEncrypt(rawContent.getBytes(), kp.getPublic().getEncoded());
        String decode = AuthUtils.rsaDecryptHex(Hex.encodeHexString(encode), privateKey);
        assertEquals(rawContent, decode);
    }
    
    @Test
    public void testCreateInstance() throws AccException {
        MemoryCacheService memory = (MemoryCacheService)AuthUtils.getInstance(MemoryCacheService.class);
        memory.putBytesValue("2", new byte[] {1});
        byte[] x = memory.getBytesValue("2");
        assertEquals(1, x[0]);
    }
    
    @Test
    public void testAES() throws AccException, DecoderException {
        String a = "absadf";
        String secret = "6167e2ACC8f1452e49ee573d8ce404a34";
        String encrypt = AuthUtils.aesEncryptAnyKey(a, secret);
        assertTrue(!a.equals(encrypt));
        String decrypt = AuthUtils.aesDecryptAnyKey(encrypt, secret);
        assertEquals(a, decrypt);
        
        String content = "username=ynote_test001&password=test123&userip=127.0.0.1";
        String key = "398a52fb40a33b8bab59424e52ec474a";
        byte[] k = Hex.decodeHex(key.toCharArray());
        System.out.println(k.length);
        byte[] x = AuthUtils.aesURSEncrypt(content.getBytes(), k);
        encrypt = "C5CB7A984A3DE3019694F1947ACEFA14F2CAA7254A4F7EC62B8C7AA57281C218E3094CB853DD3EBF787D5A97C1DF8160887B2CF847F27792C5745045A6CC2001";
        assertEquals(encrypt.toLowerCase(), Hex.encodeHexString(x));
    }
    
    @Test
    public void testUniqueToken() {
        Set<String> tokens = new HashSet<String>();
        int number = 100000;
        for (int i = 0; i < number; i++) {
            tokens.add(AuthUtils.genUniqueToken());
        }
        assertEquals(number, tokens.size());
    }
    
    @Test
    public void testUniqueToken2() {
        Set<String> tokens = new HashSet<String>();
        int number = 100000;
        for (int i = 0; i < number; i++) {
            tokens.add(AuthUtils.genUniqueToken("aa"));
        }
        assertEquals(number, tokens.size());
    }
    @Test
    public void testComposeUrl() throws AccException {
        String base = "note.youdao.com";
        String url = AuthUtils.composeQueryUrl(base, new Parameter("aa", "bb"));
        assertEquals(base + "?aa=bb", url);
        url = AuthUtils.composeQueryUrl(url, new Parameter("cc", "dd"));
        assertEquals(base + "?aa=bb&cc=dd", url);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("zz", "xx"));
        params.add(new Parameter("yy", "uu"));
        url = AuthUtils.composeQueryUrl(url, params);
        assertEquals(base + "?aa=bb&cc=dd&zz=xx&yy=uu", url);
    }
    @Test
    public void testByte2Obj() throws AccException {
        
        SerializableA objA = new SerializableA();
        objA.a = 3;
        objA.c = new byte[] {1, 3, 5};
        SerializableB objB = new SerializableB();
        objB.a = new byte[] {2,4,6};
        objB.setB(4);
        objB.c = "helo";
        objB.d = objA;
        byte[] content = AuthUtils.obj2bytes(objB);
        SerializableB x = (SerializableB)AuthUtils.byte2Obj(content, SerializableB.class);
        assertEquals(objB.a[1], x.a[1]);
        assertEquals(objB.getB(), x.getB());
        assertEquals(objB.c, x.c);
        assertEquals(objB.d.a, x.d.a);
        assertEquals(objB.d.c[1], x.d.c[1]);
    }
    
    private void aesEnDeCipher(String secretContent, String key) throws AccException {
        String encrypt =AuthUtils.aesEncryptAnyKey(secretContent, key);
        String decrypt = AuthUtils.aesDecryptAnyKey(encrypt, key);
        assertEquals(secretContent, decrypt);
    }
    
    private void rsaEnDeCipher(String secretContent, String enKey, String deKey) throws AccException {
        String encrypt = AuthUtils.rsaEncryptHex(secretContent, enKey);
        String decrypt = AuthUtils.rsaDecryptHex(encrypt, deKey);
        assertEquals(secretContent, decrypt);
    }
}
