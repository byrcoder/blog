/**
 * @(#)FakeRenRenController.java, 2012-11-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.renren;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.faketp.server.FakeConst;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class FakeRenRenController extends BaseFakeController{
    private static final long serialVersionUID = 1L;

    public FakeRenRenController() {
        super();
    }
    
    @Override
    protected Object processOauthError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {
        "error":"unsupported_response_type",
        "error_code":21329
        "error_description":"不支持的 ResponseType."
        "error_url" : "xxx"
        }
         */
        obj.put(RenRenConst.KEY_ERROR, SinaConst.FAKE_ERROR);
        obj.put(RenRenConst.KEY_ERROR_DESCRIPTION, SinaConst.FAKE_ERROR_DESCRIPTION);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }

    @Override
    protected Object processOpenAPIError(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {
           "error_code" : "20502",
           "error" : "Need you follow uid."
        } 
         */
        obj.put(RenRenConst.KEY_ERROR, SinaConst.FAKE_ERROR);
        obj.put(RenRenConst.KEY_ERROR_DESCRIPTION, SinaConst.FAKE_ERROR_DESCRIPTION);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.INTERNAL_SERVER_ERROR);
        return null;
    }
    
    /**
     * request HTTPS /fake/cqq/oauth2/authorize
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type=Type.Oauth)
    @RequestMapping(value = "/renren/oauth/authorize")
    protected void authorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkParam(req, FakeConst.KEY_CLIENT_ID, NO_MISS);
        checkParam(req, FakeConst.KEY_RESPONSE_TYPE, FakeConst.KEY_CODE);
        checkParam(req, FakeConst.KEY_REDIRECT_URI, NO_MISS);
        checkParam(req, FakeConst.KEY_STATE, NO_MISS);
        try {
            resp.sendRedirect(String.format("%s?code=%s&state=%s",
                    req.getParameter(SinaConst.KEY_REDIRECT_URI), SinaConst.FAKE_AUTHORIZE_CODE,
                    req.getParameter(OAuthConstant.CALLBACK_STATE_CODE)));
        } catch (IOException e) {
            throw new AccException("Redirect error:" + req.getParameter(FakeConst.KEY_REDIRECT_URI),
                    AccExpType.FAKE_THIRD_PARTY_SERVER_ERROR);
        }
    }

    /**
     * request HTTPS /fake/cqq/oauth2/access_token
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type=Type.Oauth)
    @RequestMapping(value = "/renren/oauth/token")
    protected void access(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        if (OAuthConstant.GRANT_TYPE_REFRESH.equals(req.getParameter(OAuthConstant.GRANT_TYPE))) {
            checkParam(req, RenRenConst.KEY_CLIENT_ID, NO_MISS);
            checkParam(req, RenRenConst.KEY_REFRESH_TOKEN, RenRenConst.FAKE_RENREN_REFRESH_TOKEN);
            checkParam(req, RenRenConst.KEY_CLIENT_SECRET, NO_MISS);
        } else {
            checkParam(req, RenRenConst.KEY_CLIENT_ID, NO_MISS);
            checkParam(req, RenRenConst.KEY_CLIENT_SECRET, NO_MISS);
            checkParam(req, RenRenConst.KEY_GRANT_TYPE, NO_MISS);
            checkParam(req, RenRenConst.KEY_REDIRECT_URI, NO_MISS);
            checkParam(req, RenRenConst.KEY_CODE, FakeConst.FAKE_AUTHORIZE_CODE);
            
        }
        // { "access_token":"SlAV32hkKG", "expires_in":3600, "refresh_token":"xxxx", "user":{"id" : "sdafasf"} }
        JSONObject object = new JSONObject();
        object.put(RenRenConst.KEY_ACCESS_TOKEN, RenRenConst.FAKE_ACCESS_TOKEN);
        object.put(RenRenConst.KEY_EXPRIES_IN, 3600);
        object.put(RenRenConst.KEY_REFRESH_TOKEN, RenRenConst.FAKE_RENREN_REFRESH_TOKEN);
        JSONObject user = new JSONObject();
        user.put(RenRenConst.KEY_ID, RenRenConst.FAKE_UID);
        object.put("user", user);
        AuthUtils.writeJSONChunked(resp, object, HttpStatus.OK);
        
    }
    
    /**
     * request HTTPS /fake/renren/2/users/show.json
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType
    @RequestMapping(value = "/renren/restservice.do")
    protected void show(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkReqMethod(req, RequestMethod.POST);
        checkParam(req, "method", NO_MISS);
        checkParam(req, FakeConst.KEY_ACCESS_TOKEN, FakeConst.FAKE_ACCESS_TOKEN);
        checkParam(req, "v", "1.0");
        checkParam(req, "format", "JSON");
        checkParam(req, "sig", NO_MISS);
        String method = req.getParameter("method");
        JSONObject obj = new JSONObject();
        if (method.equals("users.getLoggedInUser")) {
            obj.put(RenRenConst.KEY_UID, RenRenConst.FAKE_UID);
        } else if (method.equals("users.getInfo")) {
            obj.put(RenRenConst.KEY_HEAD, RenRenConst.FAKE_HEAD);
            obj.put(RenRenConst.KEY_NAME, RenRenConst.FAKE_NAME);
            obj.put(RenRenConst.KEY_BIRTH_DAY, RenRenConst.FAKE_BIRTH_DAY);
            obj.put(RenRenConst.KEY_SEX, RenRenConst.FAKE_SEX);
            obj.put(RenRenConst.KEY_STAR, RenRenConst.FAKE_STAR);
            obj.put(RenRenConst.KEY_IS_VIP, RenRenConst.FAKE_IS_VIP);
            obj.put(RenRenConst.KEY_ZIDOU, RenRenConst.FAKE_ZIDOU);
        }
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }
    
}
