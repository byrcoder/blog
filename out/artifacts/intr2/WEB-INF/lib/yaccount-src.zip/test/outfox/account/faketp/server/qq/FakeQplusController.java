/**
 * @(#)FakeQplusController.java, 2012-11-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.qq;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.server.token.verifier.qplus.QOpenService;

/**
 * @author chen-chao
 */
public class FakeQplusController extends BaseFakeController{
    private static final long serialVersionUID = 1L;
    public FakeQplusController() {
        super();
    }
    /**
     * request HTTPS /fake/cqq/oauth2/authorize
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type=Type.Oauth)
    @RequestMapping(value = "/qplus/app_get_userinfo")
    protected void authorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkParam(req, QOpenService.NAME_APP_ID, NO_MISS);
        checkParam(req, QOpenService.NAME_APP_NONCE, NO_MISS);
        checkParam(req, QOpenService.NAME_APP_OPENID, NO_MISS);
        checkParam(req, QOpenService.NAME_APP_OPENKEY, NO_MISS);
        checkParam(req, QOpenService.NAME_APP_TS, NO_MISS);
        checkParam(req, QOpenService.NAME_APP_USERIP, NO_MISS);
        checkParam(req, QOpenService.NAME_SIGNATURE, NO_MISS);
        JSONObject obj = new JSONObject();
        obj.put("ret", 0);
        JSONObject info = new JSONObject();
        info.put("face", "http://qq.com/face");
        info.put("gender", "0");
        info.put("outh", "auth");
        info.put("nick", "nickname");
        obj.put("info", info);
        writeJSON(req, resp, obj, HttpStatus.OK);
    }
    
}
