/**
 * @(#)FakeTokenController.java, 2012-12-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.urs;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.faketp.server.FakeConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.UrsUtils;

/**
 * @author chen-chao
 */
public class FakeTokenController extends BaseFakeController {
    private static final long serialVersionUID = 6106055706143537086L;
    public FakeTokenController(){
        
    }
    @Override
    protected Object processStrictIpAPIError(HttpServletRequest req, HttpServletResponse resp)
            throws AccException {
        AuthUtils.writePlainChunked(resp, "500\nServer error.\n", HttpStatus.OK);
        return null;
    }
    /**
     * request HTTPS /urstoken/
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type = Type.StrictIpAPI)
    @RequestMapping(value = "/urstoken/getCookieFromMobToken")
    protected void getCookie(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkParam(req, "token", NO_MISS);
        checkParam(req, "id", NO_MISS);
        String cookieValue = AuthUtils.generateFileId();
        resp.addCookie(new Cookie(UrsUtils.NTES_SESS, cookieValue));
        resp.addCookie(new Cookie(UrsUtils.S_INFO, FakeConst.FAKE_ID+"@126.com"));
        resp.addCookie(new Cookie(UrsUtils.P_INFO, FakeConst.FAKE_ID+"@126.com"));
        
        AuthUtils.writePlainChunked(resp, "201\nok\n\nusername="+FakeConst.FAKE_ID+"@126.com&cookie="+cookieValue+"&loginTime=12-01-01&product=note_client", HttpStatus.OK);
    }
    
    @RequestMapping(value="/urstoken/checkUsername") 
    protected void checkUserExist(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkParam(req, "username", NO_MISS);
        checkParam(req, "product", NO_MISS);
        String username = req.getParameter("username");
        AuthUtils.writePlainChunked(resp, "200\nok\n\nusername="+username+"&cookie=asfasdf&loginTime=12-01-01&product=note_client", HttpStatus.OK);
    }
}
