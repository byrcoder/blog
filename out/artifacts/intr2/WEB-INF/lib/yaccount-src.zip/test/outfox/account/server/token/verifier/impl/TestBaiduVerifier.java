/**
 * @(#)TestBaiduVerifier.java, 2013-4-23. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.baidu.BaiduConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 *
 * @author zhanglz
 *
 */
public class TestBaiduVerifier extends VerifierTestCaseBase {
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
    }

    public void init(String product) {
        super.init(product, "baidu");
        Properties pros = genBaiduProperty(getLocalHostHttpsUrl("/baidu/"));
        BaiduVerifier baiduVerifier = genBaiduVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, "baidu", baiduVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    
    @Test
    public void testNormalLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(BaiduConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(box, BaiduConst.FAKE_ID);
    }
    
    @Test
    public void testRefreshTokenLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        Properties pros = genBaiduProperty(getLocalHostHttpsUrl("/baidu/"));
        pros.put("baidu.refreshInMill", 0);
        
        BaiduVerifier baiduVerifier = genBaiduVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, baiduVerifier);
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(BaiduConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(box, BaiduConst.FAKE_ID);
    }
    
    
    
    @Test
    public void testBind() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.b.value());
        assertTrue(box.bind != null);
    }
}
