/**
 * @(#)TestDataStorePublicView.java, 2013-2-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.PublicViewWritable;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestDataStorePublicView extends AccTestCase{
    private DataStore store;
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setReuseTableMode(false);
        ReflectConstruct dataStoreConstruct = new ReflectConstruct(DataStore.class);
        store = (DataStore) dataStoreConstruct.call();
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    @Test
    public void testReadWriteGetPublicViewMapping() throws AccException {
        String key1= "key1";
        String val1 = "value1";
        String key2 = "key2";
        String val2 = "value2";
        int authorize1 = AccConst.AUTHORIZE_TYPE.READ.value();
        int authorize2 = AccConst.AUTHORIZE_TYPE.READ.value() | AccConst.AUTHORIZE_TYPE.REMOVE.value(); 
        store.writePublicViewMapping(key1, val1, authorize1);
        PublicViewWritable p = store.readPublicViewMapping(key1);
        assertEquals(key1, p.urlSuffix);
        assertEquals(val1, p.userId);
        assertEquals(authorize1, p.authorize);
        
        store.writePublicViewMapping(key2, val2, authorize2);
        List<PublicViewWritable> params = store.getAllPublicViewMapping(null);
        assertEquals(2, params.size());
    }
    @Test
    public void testGetManyPublicViewMapping() throws AccException {
        int count = 100;
        for (int i = 0; i < count * 2; i++) {
            store.writePublicViewMapping(""+i, ""+i, i);
        }
        List<PublicViewWritable> params = store.getAllPublicViewMapping(null);
        assertEquals(count, params.size());
        
        List<PublicViewWritable> nextParams = store.getAllPublicViewMapping(params.get(params.size()-1).urlSuffix);
        assertEquals(count, nextParams.size());
        // left 2
        params = store.getAllPublicViewMapping(nextParams.get(params.size()-1).urlSuffix);
        assertEquals(2, params.size());
    }
}
