/**
 * @(#)TestRemoveExpiredTokensIterTask.java, 2013-3-6. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.iter;

import java.lang.reflect.InvocationTargetException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.TpToken;
import outfox.account.db.DataStore;
import outfox.account.db.DataStore.ScanCount;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.verifier.impl.TSinaVerifier;
import outfox.account.task.clean.CleanTokenTask;

/**
 * @author chen-chao
 */
public class TestRemoveExpiredTokensIterTask extends AccTestCase{
    private DataStore store;
    private final String MOBILE = "mobile";
    private final String PRODUCT_YNOTE = "YNOTE";
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        ReflectConstruct dataStoreConstruct = new ReflectConstruct(DataStore.class);
        store = (DataStore) dataStoreConstruct.call();
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    @Test
    public void testRemoveExpiredTokens() throws AccException, SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, InstantiationException {
        int num = 20;
        for (int i = 0; i < 20; i ++) {
            TpToken tp = new TpToken();
            tp.userId = "userA@163.com";
            tp.app = MOBILE;
            tp.verifierName = TSinaVerifier.NAME;
            tp.product = PRODUCT_YNOTE;
            tp.signature = "a"+i;
            tp.sessIndex = "a"+i;
            tp.setExpiredTime(0L);
            store.writeToken(tp);
        }
        ReflectConstruct c = new ReflectConstruct(CleanTokenTask.class, Long.class);
        CleanTokenTask task = (CleanTokenTask) c.call(20L);
        task.run();
        ScanCount scanCount = CleanTokenTask.totalCount();
        System.out.println("scan count:"+scanCount.scanCount);
        assertEquals(num, scanCount.processCount);
        
    }
}
