/**
 * @(#)TestSSLClient.java, 2012-8-31. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils.client;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.message.BasicHeader;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.OAuthConstant;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class TestAccHttpClient extends AccTestCase {
    @Before
    public void setUp() throws Exception {
        startMiniZKCluster();
        startMockServer();
    }

    @After
    @Override
    protected void tearDown() throws Exception {
        stopMockServer();
        stopMiniZKCluster();
    }

    @Test
    public void testPost() throws AccException, FileNotFoundException, IOException {
        AccHttpClient client = AccHttpClient.getInstance();
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("aa", "bb"));
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader("cc", "dd"));
        byte[] bytes = client.getBytes(Method.POST, getLocalHostHttpUrl("/FakeServletTest/post"), headers,
                params, null);
        String content = new String(bytes, AccConst.UTF8);
        JSONObject json = JSONObject.fromObject(content);
        assertEquals("bb", json.getString("aa"));
        assertEquals("dd", json.getString("cc"));

        Map<String, Object> ps = new HashMap<String, Object>();
        ps.put("zz", "uu");
        UrlEncodedFormEntity urlEntity = AccHttpClient.composeUrlEncodingEntity(ps, AccConst.UTF8);
        bytes = client.getBytes(Method.POST, getLocalHostHttpsUrl("/FakeServletTest/post"), null, null,
                urlEntity);
        content = new String(bytes, AccConst.UTF8);
        json = JSONObject.fromObject(content);
        assertEquals("uu", json.get("zz"));
        assertEquals("application/x-www-form-urlencoded; charset=UTF-8", json.get("Content-Type"));

        ps = new HashMap<String, Object>();
        ps.put("zz", "uu");
        byte[] sendBytes = new byte[] {
            1, 3, 7
        };
        ps.put("bytes", sendBytes);
        ps.put("file", new File("./data/test/testFile.txt"));
        ps.put("kk", "");
        ps.put("zz", "mm");
        ps.put("zz", new File("./data/test/testFile.txt"));
        MultipartEntity multiEntity = AccHttpClient.composeMultiPartEntity(ps, AccConst.UTF8);
        bytes = client.getBytes(Method.POST, getLocalHostHttpsUrl("/FakeServletTest/post"), null, null,
                multiEntity);
        content = new String(bytes, AccConst.UTF8);
        json = JSONObject.fromObject(content);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        IOUtils.copy(new FileInputStream(new File("./data/test/testFile.txt")), out);
        byte[] xx = out.toByteArray();
        assertEquals(escapCRLF(new String(xx, AccConst.UTF8)),
                escapCRLF(new String(JSON2bytes(json,"zz"), AccConst.UTF8)));
        byte[] bb = JSON2bytes(json,"bytes");
        assertEquals(bb[0], sendBytes[0]);
        assertEquals(bb[2], sendBytes[2]);
        assertEquals(true, json.getString("Content-Type").startsWith("multipart/form-data"));
    }
    @Test
    public void testMultiPartPost() throws AccException, UnsupportedEncodingException {
        String content = "【欢迎使用有道云笔记】欢迎来到有道云笔记——免费，可在桌面版、网页版、手机版之间同步的笔记软件开始使用有道云笔记，只需四步：点击软件左上角的...... FW2bYr 来自@有道云笔记 Android版";
        content = new String(content.getBytes(), AccConst.UTF8);
        HashMap<String, Object>ps = new HashMap<String, Object>();
        ps.put("content", content);
        
        MultipartEntity multiEntity = AccHttpClient.composeMultiPartEntity(ps, AccConst.UTF8);
        JSONObject result = client.getJSON(Method.POST, getLocalHostHttpsUrl("/FakeServletTest/multipartPost"), null, null,
                multiEntity);
        String res = result.getString(AccConst.RETURN_STR);
        System.out.println("aa:好");
        System.out.println("res:"+res);
        System.out.println("content:"+content);
        assertEquals(content, res);
        assertEquals(content.length(), res.length());
    }

    @Test
    public void testGet() throws AccException, UnsupportedEncodingException {
        AccHttpClient client = AccHttpClient.getInstance();
        List<Header> header = new ArrayList<Header>();
        header.add(new BasicHeader(OAuthConstant.AUTHORIZED_HEAD_NAME, "OAuth2 " + SinaConst.FAKE_ACCESS_TOKEN));
        byte[] bytes = client.getBytes(Method.GET, getLocalHostHttpsUrl("/sina/2/users/show.json"), header,
                null, null);
        String content = new String(bytes, AccConst.UTF8);
        JSONObject json = JSONObject.fromObject(content);
        assertEquals(true, json.getJSONObject(SinaConst.KEY_ERROR_DESCRIPTION).isNullObject());

        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(SinaConst.KEY_UID, SinaConst.FAKE_ID));
        
        bytes = client.getBytes(Method.GET, getLocalHostHttpsUrl("/sina/2/users/show.json"), header, params,
                null);
        content = new String(bytes, AccConst.UTF8);
        json = JSONObject.fromObject(content);
        assertEquals(SinaConst.FAKE_NAME, json.get(SinaConst.KEY_NAME));
    }

}
