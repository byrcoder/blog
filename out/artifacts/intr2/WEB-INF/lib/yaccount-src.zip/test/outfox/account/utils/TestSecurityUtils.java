/**
 * @(#)TestSecurityUtils.java, 2013-6-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestSecurityUtils extends AccTestCase{
    @Test
    public void test() throws AccException {
            String x = SecurityUtils.secretString("");
            assertEquals("***", x);
            x = SecurityUtils.secretString("sdfa");
            assertEquals("***", x);
            x = SecurityUtils.secretString("sdfasf124r12343222");
            assertEquals("sdfasf12***", x);
            x = SecurityUtils.secretString(null);
            assertEquals("(null)", x);
            JSONObject obj = new JSONObject();
            obj.put("YNOTE-PC", "YOUO1234567890");
            obj.put("access_token", "token");
            obj = SecurityUtils.escapeSecurity(obj);
            assertEquals("YOUO***", obj.getString("YNOTE-PC"));
            assertEquals("***", obj.getString("access_token"));
            List<Parameter> params = new ArrayList<Parameter>();
            params.add(new Parameter("token","safasfasf"));
            params.add(new Parameter("YNOTE-PC", "YOUO1234567890"));
            obj = SecurityUtils.escapeSecurity(params);
            assertEquals("YOUO***", obj.getString("YNOTE-PC"));
            assertEquals("***", obj.getString("token"));
    }
}
