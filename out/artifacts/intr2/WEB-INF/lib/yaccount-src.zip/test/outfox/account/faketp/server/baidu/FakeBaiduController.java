/**
 * @(#)FakeBaiduController.java, 2013-4-23. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.baidu;

import java.io.IOException;
import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.utils.AuthUtils;

/**
 *
 * @author zhanglz
 *
 */
public class FakeBaiduController extends BaseFakeController {
    private static final long serialVersionUID = 1L;

    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/baidu/oauth/2.0/authorize")
    protected void authorize(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        if (!isBlankParam(req, BaiduConst.KEY_CLIENT_ID)
                && isSameParam(req, BaiduConst.KEY_RESPONSE_TYPE, BaiduConst.KEY_CODE)
                && !isBlankParam(req, BaiduConst.KEY_REDIRECT_URI)) {
            try {
                resp.sendRedirect(String.format("%s?code=%s&state=%s",
                        req.getParameter(BaiduConst.KEY_REDIRECT_URI), BaiduConst.FAKE_AUTHORIZE_CODE,
                        req.getParameter(OAuthConstant.CALLBACK_STATE_CODE)));
            } catch (IOException e) {
                throw new AccException("Redirect error:" + req.getParameter(BaiduConst.KEY_REDIRECT_URI),
                        AccExpType.FAKE_THIRD_PARTY_SERVER_ERROR);
            }

            return;
        }
        throw new AccException("params error", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
    }
    
    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/baidu/oauth/2.0/token")
    protected void access(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkReqMethod(req, RequestMethod.POST);
        if (!isBlankParam(req, BaiduConst.KEY_CLIENT_ID) && !isBlankParam(req, BaiduConst.KEY_CLIENT_SECRET)
                && !isBlankParam(req, BaiduConst.KEY_GRANT_TYPE)
                && !isBlankParam(req, BaiduConst.KEY_REDIRECT_URI)
                && isSameParam(req, BaiduConst.KEY_CODE, BaiduConst.FAKE_AUTHORIZE_CODE)) {
            // { "access_token":"SlAV32hkKG", "expires_in":3600 }
            JSONObject object = new JSONObject();
            object.put(BaiduConst.KEY_ACCESS_TOKEN, BaiduConst.FAKE_ACCESS_TOKEN);
            object.put(BaiduConst.KEY_EXPRIES_IN, 3600);
            object.put(BaiduConst.KEY_REFRESH_TOKEN, BaiduConst.FAKE_REFRESH_TOKEN);
            AuthUtils.writeJSONChunked(resp, object, HttpStatus.ACCEPTED);
            return;
        }
        throw new AccException("params error", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
    }
    
    @CallType(type = Type.OpenAPI)
    @RequestMapping(value = "/baidu/rest/2.0/passport/users/getInfo")
    protected void getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        /*
             userid      int64   用户UID
             username     string  用户昵称
             portrait       string url
         */
        JSONObject obj = new JSONObject();
        BigInteger b = new BigInteger(BaiduConst.FAKE_ID);
        obj.put(BaiduConst.KEY_USER_ID, b);
        obj.put(BaiduConst.KEY_USER_NAME, BaiduConst.FAKE_NAME);
        obj.put(BaiduConst.KEY_PORTRAIT, BaiduConst.KEY_PORTRAIT);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.ACCEPTED);
    }
}
