/**
 * @(#)QQConst.java, 2012-10-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.qq;

import outfox.account.faketp.server.FakeConst;

/**
 * @author chen-chao
 */
public interface QQConst extends FakeConst{
    static final String KEY_RETURN = "ret";
    static final String KEY_MESSAGE = "msg";
    static final String RETURN_CODE = "12345";
    static final String ERROR_MESSAGE = "no support ResponseType.";
    static final String KEY_EXPRIES_IN = "expires_in";
    
    static final String SUCCESS_CODE = "0";
    
    static final String NICK_NAME ="nickname";
    
    static final String FIGURE_URL = "figureurl";
    
    static final String FAKE_FIGURE_URL = "http://qzapp.qlogo.cn/qzapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/30";
    
    static final String GENDER = "gender";
    
    static final String FAKE_GENDER = "男";
    
    static final String VIP = "vip";
    
    static final String FAKE_VIP = "1";
    
    static final String LEVEL = "level";
    
    static final String FAKE_LEVEL = "7";
    
    static final String DATA = "data";
    
    static final String DATAERROR = "dataerror";
    
    static final String RET = "ret";
    
    static final String RET_ERROR = "234";
    
    static final String RET_SUCC = "0";
    
    
    static final String KEY_OPEN_ID = "openid";
    
    static final String KEY_OPEN_KEY = "openkey";
    
    static final String FAKE_OPEN_ID_VALUE = "sdafwqeqg1234";
    
    static final String FAKE_OPEN_KEY_VALUE = "dsf332rg";
    
    static final String FAKE_QQ_REFRESH_TOKEN = "dsf23r23gdasdf";
    
    static final String KEY_FORMAT = "format";
    static final String FORMAT_VALUE = "json";
    
    static final String KEY_OAUTH_CONSUMER_KEY = "oauth_consumer_key";
    
    static final String KEY_OAUTH_VERSION = "oauth_version";
    
    static final String KEY_CLIENT_IP = "clientip";
    
    static final String KEY_BIRTH_DAY = "birth_day";
    
    static final String KEY_BIRTH_MONTH = "birth_month";
    
    static final String KEY_BIRTH_YEAR = "birth_year";
    
    static final String FAKE_BIRTH_DAY = "1";
    
    static final String FAKE_BIRTH_MONTH = "1";
    
    static final String FAKE_BIRTH_YEAR = "2003";
    
    static final String KEY_HEAD = "head";
    
    static final String FAKE_HEAD = "http://app.qlogo.cn/mbloghead/8df62426cf2873508634";
    static final String KEY_NICK = "nick";
    static final String FAKE_NICK = "me";
    
    static final String FAKE_NAME = "c230923";
    
    static final String KEY_NAME = "name";
    static final String KEY_SEX = "sex";
    
    static final String FAKE_SEX = "1";
    static final String KEY_IS_VIP = "isvip";
    static final String FAKE_IS_VIP = "1";
    static final String KEY_IS_REAL_NAME = "isrealname";
    static final String FAKE_IS_REAL_NAME = "1";
    
    static final String KEY_LOCATION = "location";
    static final String FAKE_LOCATION = "fakeLocation:dafsdf";
    
    static final String FAKE_SSO_ACCESS_TOKEN = "33SlAV32hkKG";
}
