/**
 * @(#)FakeAliCloudController.java, 2013-8-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.yunos;

import java.util.Arrays;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.faketp.server.CallType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class FakeYunOSController  extends BaseFakeController {
    private static final long serialVersionUID = -5471347568917874115L;

    /**
     * request HTTPS /fake/sina/oauth2/access_token
     * @param req
     * @param resp
     * @throws AccException
     */
    @CallType(type = Type.Oauth)
    @RequestMapping(value = "/yunos/openapi")
    protected void access(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        checkHttpsProtocal(req);
        checkReqMethod(req, RequestMethod.POST);
        if (!isBlankParam(req, YunOSConst.YUN_API) && !isBlankParam(req, YunOSConst.YUN_TIMESTAMP)
                && !isBlankParam(req, YunOSConst.YUN_SIGN)
                && !isBlankParam(req, YunOSConst.YUN_VERSION)
                && !isBlankParam(req, YunOSConst.YUN_KEY)
                && isSameParam(req, YunOSConst.YUN_API, YunOSConst.YUN_VALUE_API_NAME)
                && isSameParam(req, YunOSConst.YUN_ACCESS_TOKEN, YunOSConst.YUN_VALUE_ACCESS_TOKEN)
                && isSameParam(req, YunOSConst.YUN_KEY, YunOSConst.YUN_FAKE_KEY)) {
            // {"status":200,"message":"SUCCESS","data":{"kp":"5989367838909828","loginId":"18668166925"}}
            String sign = generateSign(req.getParameterMap(), YunOSConst.YUN_FAKE_SECRET);
            if (isSameParam(req, YunOSConst.YUN_SIGN, sign)) {
                JSONObject object = new JSONObject();
                object.put(YunOSConst.YUN_STATUS, 200);
                object.put(YunOSConst.YUN_MESS, "SUCCESS");
                JSONObject data = new JSONObject();
                data.put(YunOSConst.YUN_KP, YunOSConst.YUN_VALUE_KP);
                data.put(YunOSConst.YUN_LOGINID, YunOSConst.YUN_VALUE_LOGINID);
                object.put(YunOSConst.YUN_DATA, data);
                AuthUtils.writeJSONChunked(resp, object, HttpStatus.OK);
                return;
            }
        }
        throw new AccException("params error", AccExpType.HTTP_HTTPS_PROTOCAL_ERROR);
    }
    
    public String generateSign(Map<String, String[]> paramsMap, String secret) {
        String sign = "";
        String params = "";
        Object[] keyArray = paramsMap.keySet().toArray();
        Arrays.sort(keyArray);
        for (int i = 0; i < keyArray.length; i++) {
            if (keyArray[i].equals("sign")) {
                continue;
            }
            Object values = paramsMap.get(keyArray[i]);
            String[] value = new String[1];
            if (values instanceof String[]) {
                value = (String[]) values;
            } else {
                value[0] = values.toString();
            }
            params += keyArray[i] + value[0];
        }

        sign = DigestUtils.md5Hex(params + secret);
        return sign;
    }
    
    @Override
    protected Object processOauthError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        JSONObject obj = new JSONObject();
        /*
        {"status":201,"message":"FAIL"}
         */
        obj.put(YunOSConst.YUN_STATUS, 201);
        obj.put(YunOSConst.YUN_MESS, "FAIL");
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.OK);
        return null;
    }
}
