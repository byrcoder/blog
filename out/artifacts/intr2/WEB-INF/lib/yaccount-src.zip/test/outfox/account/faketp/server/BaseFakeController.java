/**
 * @(#)BaseFakeController.java, 2012-8-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.CallType.Type;
import outfox.account.handler.BaseHandler;
import outfox.account.utils.ReqUtils;

/**
 * All Fake Services should extends this class.
 * @author chen-chao
 */
public class BaseFakeController extends BaseHandler{
    private static final long serialVersionUID = -9102575053684714147L;
    protected static final Log LOG = LogFactory.getLog(BaseFakeController.class);
    protected HashMap<String, Method> cache;
    /**
     * put all request mapping into cache.
     */
    public BaseFakeController() {
        cache = new HashMap<String, Method>();
        for (Method m : getClass().getDeclaredMethods() ) {
            RequestMapping mapping = m.getAnnotation(RequestMapping.class);
            if (mapping != null) {
                for (String url : mapping.value()) {
                    m.setAccessible(true);
                    cache.put(url, m);
                }
            }
        }
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
            IOException {
        System.out.println();
        System.out.println(req.getRequestURL());
        Map<String, String[]> params = req.getParameterMap();
        if (params != null) {
            for(Entry<String, String[]> entry : params.entrySet()) {
                System.out.println("param key:"+entry.getKey());
                for(String val : entry.getValue()) {
                    System.out.println("\t value:" + val);
                }
            }
        }
        Enumeration<String> names = req.getHeaderNames();
        String name = null;
        while(names.hasMoreElements()) {
            name = names.nextElement();
            String val = req.getHeader(name);
            System.out.println("header " + name + " : " + val);
        }
        
        try {
            invoke(req, resp);
        } catch (AccException e) {
            // do nothing.
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
            IOException {
        doGet(req, resp);
    }
    
    /**
     * invoke services by request mapping.
     * @param req
     * @param resp
     * @return
     * @throws AccException
     */
    protected Object invoke(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        Method m = cache.get(getMappingURI(req));
        try {
            if (m != null) {
                return m.invoke(this, req, resp);
            }
        } catch (Exception e) {
            
            if ( e instanceof InvocationTargetException) {
                CallType type = m.getAnnotation(CallType.class);
                if (type != null) {
                    if (type.type().equals(Type.Oauth)) {
                        processOauthError(req, resp);
                    } else if (type.type().equals(Type.OpenAPI)) {
                        processOpenAPIError(req, resp);
                    } else if (type.type().equals(Type.StrictIpAPI)) {
                        processStrictIpAPIError(req, resp);
                    }
                }
                Throwable t = ((InvocationTargetException)e).getTargetException();
                wrappedException(t);
            }
            wrappedException(e);
        }
        return null;
    }
    
    protected Object processOauthError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        return null;
    }
    
    protected Object processOpenAPIError(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        return null;
    }
    
    
    protected Object processStrictIpAPIError(HttpServletRequest req, HttpServletResponse resp) throws AccException{
        return null;
    }
    /**
     * the method will remove context path of request URI
     * @param req
     * @return
     */
    protected String getMappingURI(HttpServletRequest req) {
        int length = req.getContextPath().length();
        return req.getRequestURI().substring(length);
    }
    
    
    /**
     * wrapped all exception only throw an AccException
     * @param t
     * @throws AccException
     */
    private void wrappedException(Throwable t) throws AccException {
        System.out.println("invoke request mapping error. cause:" + t.getMessage());
        t.printStackTrace();
        throw new AccException("invoke request mapping error", t, AccExpType.FAKE_THIRD_PARTY_SERVER_ERROR);
    }
    
    protected boolean isSameParam(HttpServletRequest req, String paramKey, String target) {
        return ReqUtils.isSameParam(req, paramKey, target);
    }
    
    public boolean isBlankParam(HttpServletRequest req, String paramKey) {
        return ReqUtils.isBlankParam(req, paramKey);
    }

}
