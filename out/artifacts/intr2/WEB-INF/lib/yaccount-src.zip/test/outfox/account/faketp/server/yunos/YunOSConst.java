/**
 * @(#)AliCloudConst.java, 2013-8-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.yunos;

import outfox.account.faketp.server.FakeConst;

/**
 * @author chen-chao
 */
public interface YunOSConst extends FakeConst{
    static final String YUN_STATUS = "status";
    static final String YUN_MESS = "message";
    static final String YUN_DATA = "data";
    static final String YUN_KP = "kp";
    static final String YUN_VALUE_KP = "5989367838909828";
    static final String YUN_LOGINID = "loginId";
    static final String YUN_VALUE_LOGINID = "18668166925";
    static final String YUN_API = "api";
    static final String YUN_KEY = "key";
    static final String YUN_FAKE_KEY = "sdafxsadf144vsdq3r21fxcbxbzsfdw12312cbv";
    static final String YUN_VALUE_KEY = "key";
    static final String YUN_TIMESTAMP = "timestamp";
    static final String YUN_SIGN =  "sign";
    static final String YUN_VERSION = "v";
    static final String YUN_ACCESS_TOKEN ="access_token";
    static final String YUN_VALUE_ACCESS_TOKEN = "dsf09q23rds1rfvxbzc124125rgfnbvn3224";
    static final String YUN_VALUE_API_NAME = "account.get_loginid_by_access_token";
    static final String YUN_FAKE_SECRET = "zsdfwe1214tzdxgabaetr231sasdf23rfvzxcvz";
}
