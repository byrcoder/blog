/**
 * @(#)TestAgentRegisterHandler.java, 2012-9-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mortbay.log.Log;
import org.springframework.http.HttpStatus;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccRunTimeException;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author wangxin
 */
public class TestAgentRegisterHandler extends AccTestCase {

    AccHttpClient atc = new AccHttpClient(10, 10, 10000, 10000,
            CookiePolicy.BROWSER_COMPATIBILITY, false, false);

    CookieStore cookieStore;

    Header[] headers;

    @Before
    public void setUp() throws Exception {
        startMiniZKCluster();
        startMockServer();
    }

    @After
    @Override
    protected void tearDown() throws Exception {
        stopMockServer();
        stopMiniZKCluster();
    }

    @Test
    public void test() throws AccException {
        query();
        change();
        send();
    }

    /**
     * test captcha query, server send a cookie and the captcha pic
     * 
     * @throws AccException
     */
    public void query() throws AccException {
        HttpResponse resp = atc.doGet(
                getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                        + AccConst.REGISTER_QUERY_URL), null, null);
        
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp
                .getStatusLine().getStatusCode());
        AccHttpClient.closeQuiet(resp);
        resp = atc.doGet(getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                + AccConst.REGISTER_QUERY_URL), null, createDefaultParam(false));
        checkStatusCode(resp, HttpStatus.OK);
        System.out.println(resp.toString());
        headers = resp.getAllHeaders();
        assertTrue(checkCaptchaPic(resp));
        AccHttpClient.closeQuiet(resp);

    }

    /**
     * test change captcha, the cookie value should not change.
     * 
     * @throws AccException
     */
    public void change() throws AccException {
        List<Header> list = atc.getHeader(headers, "Set-Cookie", "Cookie");
        //test no params
        HttpResponse resp = atc.doGet(
                getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                        + AccConst.REGISTER_QUERY_URL), list, null);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp
                .getStatusLine().getStatusCode());
        AccHttpClient.closeQuiet(resp);
        //test doPost
        byte[] bytes = atc.getBytes(Method.POST,
                getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                        + AccConst.REGISTER_QUERY_URL), list,
                createDefaultParam(false), null);
        assertTrue(bytes!=null);
        //test doGet
        resp = atc.doGet(getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                + AccConst.REGISTER_QUERY_URL), list,
                createDefaultParam(false));
        checkStatusCode(resp, HttpStatus.OK);
        assertTrue(checkCaptchaPic(resp));
    }

    /**
     * @throws AccException 
     * 
     */
    private void send() throws AccException {
        List<Header> list = new ArrayList<Header>();
        for (Header header: headers) {
            if (header.getName().equals("Set-Cookie")) {
                list.add(new BasicHeader("Cookie", header.getValue()));
            }
        }
        HttpResponse resp = atc.doGet(
                getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                        + AccConst.REGISTER_SEND_URL), list, null);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp
                .getStatusLine().getStatusCode());
        AccHttpClient.closeQuiet(resp);
        resp = atc.doGet(getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX
                + AccConst.REGISTER_SEND_URL), list, createDefaultParam(true));
        Log.info(resp.toString());
        try {
            HttpEntity entity = resp.getEntity();   
            String stat=EntityUtils.toString(entity);
            Log.info(stat);
        } catch (IOException e) {
            throw new AccRunTimeException("to string error", e);
        }
        AccHttpClient.closeQuiet(resp);
    }
    
    /**
     * @return
     */
    private List<Parameter> createDefaultParam(boolean isSend) {
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME,
                AccConst.PARAM_PC_NAME));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME,
                AccConst.PARAM_PC_NAME));
        if (isSend) {
            params.add(new Parameter(AccConst.PARAM_USER_CAPTCHA, "12345"));
            params.add(new Parameter(AccConst.PARAM_USER_ID, "ynote_test_reg001@163.com"));
            params.add(new Parameter(AccConst.PARAM_PASSWORD, "1234567890"));
        }
        return params;
    }

    /**
     * @param resp
     */
    public boolean checkCaptchaPic(HttpResponse resp) {
        byte[] image = null;
        try {
            image = EntityUtils.toByteArray(resp.getEntity());
        } catch (IOException e) {
            throw new AccRunTimeException("to byte[] error", e);
        }
        return image!=null;
    }
}
