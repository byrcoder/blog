/**
 * @(#)TestWritableUtils.java, 2012-9-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import outfox.account.AccTestCase;
import outfox.account.data.user.UserInfoWritable;

/**
 * @author chen-chao
 */
public class TestWritableUtils extends AccTestCase {
    
    class MockWritableClass implements IWritable {

        private String testString;

        private int testInt;

        private long testLong;

        private byte testByte;

        private boolean testBoolean;

        public MockWritableClass() {

        }

        public MockWritableClass(String testString, int testInt, long testLong,
                byte testByte, boolean testBoolean) {
            this.testString = testString;
            this.testInt = testInt;
            this.testLong = testLong;
            this.testByte = testByte;
            this.testBoolean = testBoolean;
        }

        @Override
        public IWritable copyFields(IWritable value) {
            return WritableUtils.copyTo(value, this);
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            StringWritable.writeStringNull(out, testString);

            out.writeInt(testInt);
            out.writeLong(testLong);
            out.writeByte(testByte);
            out.writeBoolean(testBoolean);
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            testString = StringWritable.readStringNull(in);
            testInt = in.readInt();
            testLong = in.readLong();
            testByte = in.readByte();
            testBoolean = in.readBoolean();
        }

        public String getTestString() {
            return testString;
        }

        public int getTestInt() {
            return testInt;
        }

        public long getTestLong() {
            return testLong;
        }

        public byte getTestByte() {
            return testByte;
        }

        public boolean isTestBoolean() {
            return testBoolean;
        }
    }
    @Test
    public void testCopyTo() {
        MockWritableClass mocka = new MockWritableClass("a", 1, 20L, (byte) 3,
                true);
        MockWritableClass mockb = new MockWritableClass("b", 2, 30L, (byte) 4,
                false);
        MockWritableClass mockc = new MockWritableClass();
        mockc.copyFields(mocka);
        assertEquals(mocka.getTestString(), mockc.getTestString());
        assertEquals(mocka.getTestByte(), mockc.getTestByte());
        assertEquals(mocka.getTestInt(), mockc.getTestInt());
        assertEquals(mocka.getTestLong(), mockc.getTestLong());
        assertEquals(mocka.isTestBoolean(), mockc.isTestBoolean());
        mockc.copyFields(mockb);
        assertEquals(mockb.getTestString(), mockc.getTestString());
        assertEquals(mockb.getTestByte(), mockc.getTestByte());
        assertEquals(mockb.getTestInt(), mockc.getTestInt());
        assertEquals(mockb.getTestLong(), mockc.getTestLong());
        assertEquals(mockb.isTestBoolean(), mockc.isTestBoolean());
    }
    
    @Test
    public void testCopyTo2() {
        UserInfoWritable userInfo = new UserInfoWritable();
        userInfo.email = "abc@email.com";
        userInfo.userId = "xxxAxxx";
        userInfo.userName = null;
        UserInfoWritable userInfo2 = new UserInfoWritable();
        WritableUtils.copyTo(userInfo, userInfo2);
        assertEquals(userInfo.email, userInfo2.email);
        assertEquals(userInfo.userId, userInfo2.userId);
        assertEquals(userInfo.userName, userInfo2.userName);
    }

    class TestA implements IWritable {
        protected int a;

        public int b;

        @Override
        public IWritable copyFields(IWritable value) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
        // TODO Auto-generated method stub

        }

        @Override
        public void readFields(DataInput in) throws IOException {
        // TODO Auto-generated method stub

        }
    }

    class TestB extends TestA {
        protected int c;

        @SuppressWarnings("unused")
        private int d;
    }

    class TestC extends TestB {
        @SuppressWarnings("unused")
        private long e;

        public String f;
    }
    @Test
    public void testFindFields() {
        List<Field> fields = WritableUtils.findAllField(TestC.class);
        assertEquals(6, fields.size());
        assertEquals(4, WritableUtils.findAllField(TestC.class,
                TestB.class).size());
    }

    class TestD extends TestB {
        public Map<String, String> property = new HashMap<String, String>();

        public List<String> other = new ArrayList<String>();
    }
    @Test
    public void testToString() throws IllegalArgumentException,
            IllegalAccessException {
        TestD d = new TestD();
        assertEquals("[a=0,b=0,c=0,d=0,property={},other=[],]",
                WritableUtils.toString(d));
        d.property.put("aa", "zzz");
        d.property.put("cc", "zzz");
        d.other.add("cc");
        d.other.add("zz");
        assertEquals(
                "[a=0,b=0,c=0,d=0,property={aa=zzz, cc=zzz},other=[cc, zz],]",
                WritableUtils.toString(d));
    }
    
}
