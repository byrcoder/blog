/**
 * @(#)BaiduConst.java, 2013-4-23. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.baidu;

import outfox.account.faketp.server.FakeConst;

/**
 *
 * @author zhanglz
 *
 */
public interface BaiduConst extends FakeConst {
    static final String KEY_EXPRIES_IN = "expires_in"; 
    static final String KEY_USER_ID = "userid"; 
    static final String KEY_USER_NAME = "username"; 
    static final String KEY_PORTRAIT = "portrait"; 
    static final String FAKE_REFRESH_TOKEN = "baidu_refresh_token";
}
