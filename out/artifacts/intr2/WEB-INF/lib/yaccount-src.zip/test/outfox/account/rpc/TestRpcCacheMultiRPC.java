/**
 * @(#)TestRpcCacheMultiRPC.java, 2012-11-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConst;

/**
 * @author chen-chao
 */
public class TestRpcCacheMultiRPC extends AccTestCase{
    @Before
    @Override
    public void setUp() throws Exception {
        startMiniZKCluster();
        for (int i = 0; i < 3; i++) {
            startRpcServer();
        }
    }

    @After
    @Override
    public void tearDown() throws Exception {
        stopMiniZKCluster();
        stopAllRpcCacheServer();
    }

    @Test
    public void testMultiRpcCache() throws Exception {
        Thread.sleep(2000);
        GlobalCache cache = GlobalCache.getInstance();
        int number = 100;
        // put
        for (int i = 0; i < number; i++) {
            cache.put("" + i, ("" + i).getBytes(AccConst.UTF8));
        }
        // get
        for (int i = 0; i < number; i++) {
            byte[] value = cache.get("" + i);
            assertEquals(i, Integer.parseInt(new String(value, AccConst.UTF8)));
        }
        // remove
        for (int i = 0; i < number; i++) {
            byte[] value = cache.remove("" + i);
            assertEquals(i, Integer.parseInt(new String(value, AccConst.UTF8)));
        }

        // get
        for (int i = 0; i < number; i++) {
            assertEquals(null, cache.get("" + i));
        }
    }
}
