/**
 * @(#)TestAuthSingleProductFilter.java, 2012-10-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import java.util.List;

import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.cookie.Cookie;
import org.junit.After;
import org.junit.Before;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;

/**
 * @author chen-chao
 */
public class TestAuthSingleProductFilter extends AccTestCase{
    TestTSinaVerifier sinaVerifier = null;
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        product = "YNOTE";
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        sinaVerifier = new TestTSinaVerifier();
        sinaVerifier.setMockServer(mockServer);
        sinaVerifier.init(product);
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        sinaVerifier.destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    
    public void testLogin() throws AccException {
        TokenBox tb =sinaVerifier.getTokens("client", COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        String userId = tb.ret.getString(AccConst.USER_ID);
        // query both sess and persToken
        JSONObject obj = queryProductController(tb).jsonObj;
        checkUserID(obj, userId);
        // query only sess
        obj = queryProductController(tb.getSessBox()).jsonObj;
        checkUserID(obj, userId);
        cookieStore.clear();
        // query only persToken
        HttpResponseAndJSON respAndJson = queryProductController(tb.getPersTokenBox());
        obj = respAndJson.jsonObj;
        checkUserID(obj, userId);
        //session cookie should be set
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(respAndJson.response));
        Cookie sess = getCookieInStore(product + AccConst.COOKIE_SESSION);
        Cookie login = getCookieInStore(product + AccConst.COOKIE_LOGIN);
        assertTrue(sess != null);
        assertTrue(login != null);
        cookieStore.clear();
        //query and check with just got sess cookie
        TokenBox getNewToken = new TokenBox(login, sess, null, null, null, null);
        obj = queryProductController(getNewToken.getSessBox()).jsonObj;
        checkUserID(obj, userId);
        cookieStore.clear();
        // query with nothing
        obj = queryProductController(tb.getEmptyBox()).jsonObj;
        checkUserID(obj, "null");
    }
    
    private void checkUserID(JSONObject obj, String userId) {
        assertEquals(userId, obj.getString(AccConst.USER_ID));
        assertEquals(userId, obj.getString(AccConst.USER_ID_ATTR));
    }
    
    private HttpResponseAndJSON queryProductController(TokenBox tb) throws AccException {
        List<Header> headers = composeTokenHeader(product, tb.login, tb.sess, tb.persToken, null);
        HttpResponse resp = client.doGet(getLocalHostHttpUrl("/product/query"), headers, null);
        return new HttpResponseAndJSON(resp);
    }
}
