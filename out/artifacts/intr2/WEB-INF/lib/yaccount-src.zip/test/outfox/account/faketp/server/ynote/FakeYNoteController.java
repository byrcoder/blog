/**
 * @(#)FakeYNoteController.java, 2013-3-5. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.ynote;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;

import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.BaseFakeController;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class FakeYNoteController extends BaseFakeController{
    private static final long serialVersionUID = 2229036566423503345L;

    public FakeYNoteController(){
        
    }
    
    /**
     * request HTTPS /ynote/
     * @param req
     * @param resp
     * @throws AccException
     */
    @RequestMapping(value = "/ynote/getusermeta")
    protected void getUserMeta(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        final String NAME_USER = "user";
        checkParam(req, NAME_USER, NO_MISS);
        JSONObject obj = new JSONObject();
        obj.put("rt", 1311296732973L);
        final String userId = req.getParameter(NAME_USER);
        obj.put("uid", userId);
        AuthUtils.writeJSONChunked(resp, obj, HttpStatus.OK);
    }
}
