/**
 * @(#)TestAccessTokenVerifierQJ.java, 2013-2-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 * @author chen-chao
 */
public class TestAccessTokenVerifierQJ extends VerifierTestCaseBase{
    public AccessTokenVerifier accVerifier = null;
    Map<String, String> parameterMap = new HashMap<String,String>();
    final String FAKE_TOKEN = "fake_token";
    final String FAKE_ID = "fake_id";
    final String QJ_TOKEN = "e1eed6392c1bad28f7042c1200a702ef";
    final String QJ_ID = "7e8d8f36541955671061e48371b858d8";
            
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
        parameterMap.put(OAuthConstant.ACCESS_TOKEN, QJ_TOKEN);
        parameterMap.put(AccConst.PARAM_OPEN_ID, QJ_ID);
    }

    public void init(String product){
        thirdPartyName = "tpac";
        super.init(product, thirdPartyName);
        
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, new AccessTokenVerifier(genAccTokenVerifierProperties(product)));
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        accVerifier = (AccessTokenVerifier)verifier;
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    
    @Test
    public void testAccessTokenHTTPSLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        
        final String thirdParty = "qj";
        TokenBox box = getAccessVerifierTokenBox(clientType, thirdParty, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), parameterMap);
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(accVerifier.tpId2ownId(thirdParty, QJ_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(accVerifier, box, thirdParty, QJ_ID);
    }
    
}
