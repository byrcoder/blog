/**
 * @(#)TestSerializationTranscoder.java, 2012-10-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache.memcached;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.AuthInfo;
import outfox.account.data.TpToken;

/**
 *
 * @author licx,chen-chao
 */
public class TestSerializationTranscoder extends AccTestCase {

    @Test
    public void testIWritable() throws Exception {
        // encode and decode IWritable objects
        SerializationTranscoder transcoder = new SerializationTranscoder();
        
        TpToken tp = new TpToken("asdfasfasf");
        tp.ip="123.23.1.1";
        TpToken tp2 = (TpToken)transcoder.decode(transcoder.encode(tp));
        assertEquals(tp.token, tp2.token);
        assertEquals(tp.ip, tp2.ip);
        AuthInfo p = new AuthInfo("YNOTE", null, null, null, null, "sdfasf", "zzxcsad");
        System.out.println(p);
        AuthInfo p2 = (AuthInfo)transcoder.decode(transcoder.encode(p));
        System.out.println(p2);
        assertEquals(p.userId, p2.userId);
        assertEquals(p.bindUserId, p2.bindUserId);
        assertEquals(p.product, p2.product);
    }

    @Test
    public void testCompress() throws Exception {
        String data = FileUtils.readFileToString(new File("build.xml"));
        System.out.println(data.length());
        SerializationTranscoder transcoder = new SerializationTranscoder();
        transcoder.setCompressionThreshold(1024);
        String data2 = (String)transcoder.decode(transcoder.encode(data));
        assertEquals(data, data2);
    }
}
