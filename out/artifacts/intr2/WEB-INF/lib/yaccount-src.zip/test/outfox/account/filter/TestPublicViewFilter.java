/**
 * @(#)TestPublicViewFilter.java, 2013-2-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.filter;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;

import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class TestPublicViewFilter extends AccTestCase{
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    
    @Test
    public void test() throws AccException {
        DataStore store = DataStore.getInstance();
        String suffix = "userSuffix";
        String userId = "userA";
        int authorize = AccConst.AUTHORIZE_TYPE.READ.value();
        
        store.writePublicViewMapping(suffix, userId, authorize);
        
        AccHttpClient client = AccHttpClient.getInstance();
        Cookie cookie = new Cookie("YNOTE"+AccConst.COOKIE_PUBLIC_VIEW, "http://note.youdao.com/product/publicView/"+suffix);
        List<Header> headers = new ArrayList<Header>();
        headers.add(AccHttpClient.makeCookies2Header(cookie));
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter("keyfrom",suffix));
        UrlEncodedFormEntity entity = AccHttpClient.composeUrlEncodingEntity(params, AccConst.UTF8);
        JSONObject obj = client.getJSON(Method.POST, getLocalHostHttpUrl("/product/publicView"), headers, null, entity);
        assertEquals(userId, obj.getString(AccConst.ATTR_PUBLIC_VIEW_USER_ID));
        
        obj = client.getJSON(Method.POST, getLocalHostHttpUrl("/product/publicView"), headers, null, null);
        assertEquals("null", obj.getString(AccConst.ATTR_PUBLIC_VIEW_USER_ID));
    }
}
