/**
 * @(#)TestLoginDoneHandler.java, 2012-11-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestLoginDoneHandler extends AccTestCase{
    private static final String PRODUCT = "YNOTE";
    @Before
    public void setUp() throws Exception {
        startMiniZKCluster();
        startMockServer();
    }

    @After
    protected void tearDown() throws Exception {
        stopMockServer();
        stopMiniZKCluster();
    }
    @Test
    public void testSuccess() throws AccException {
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_SUCCESS, true));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, PRODUCT));
        HttpResponse resp = doGet(getLocalHostHttpUrlWithPerfix(AccConst.LOGIN_DONE_URL), params);
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        String location = getRedirectLocation(resp);
        assertEquals(AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_SUCCESS_REDIRECT_URL), location);
    }
    
    @Test
    public void testFail() throws AccException {
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_SUCCESS, false));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, PRODUCT));
        HttpResponse resp = doGet(getLocalHostHttpUrlWithPerfix(AccConst.LOGIN_DONE_URL), params);
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        String location = getRedirectLocation(resp);
        assertEquals(AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_ERROR_REDIRECT_URL), location);
    }
    
    @Test
    public void testEmpty() throws AccException {
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, PRODUCT));
        HttpResponse resp = doGet(getLocalHostHttpUrlWithPerfix(AccConst.LOGIN_DONE_URL), params);
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        String location = getRedirectLocation(resp);
        assertEquals(AccConfig.getPros().getString(AccConfig.NAME_GLOBAL_ERROR_REDIRECT_URL), location);
    }
}
