/**
 * @(#)TestMappingHandler.java, 2012-11-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;


import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.exceptions.AccException.AccExpType;
import outfox.account.faketp.server.qq.QQConst;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.verifier.impl.TestCQQVerifier;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;
import outfox.account.server.token.verifier.impl.TestUrsProxyCookieVerifier;
import outfox.account.utils.UrsUtils;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */
public class TestMappingHandler  extends AccTestCase{
    TestTSinaVerifier sinaVerifier = null;
    TestUrsProxyCookieVerifier proxyVerifier = null;
    TestCQQVerifier cqqVerifier = null;
    String ynote = "YNOTE";
    @Before
    public void setUp() throws Exception {
        super.setUp();
        startMiniZKCluster();
        startMockServer();
        sinaVerifier = new TestTSinaVerifier();
        sinaVerifier.setMockServer(mockServer);
        sinaVerifier.init(ynote);
        proxyVerifier = new TestUrsProxyCookieVerifier();
        proxyVerifier.setMockServer(mockServer);
        proxyVerifier.init(ynote);
        
        cqqVerifier = new TestCQQVerifier();
        cqqVerifier.setMockServer(mockServer);
        cqqVerifier.init(ynote);
        caseRestart();
    }

    @After
    public void tearDown() throws Exception {
        setMockServer(null);
        sinaVerifier.destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    protected void bind(TokenBox box) throws AccException {
        bind(ynote, box);
    }
    
    protected void checkNoBind(TokenBox box) throws AccException {
        JSONObject ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_MAIN_ID_URL), composeAuthHeader(ynote, box), null, null);
        assertEquals(AccExpType.NO_BIND_ERROR.getErrorCode(), ret.get(AccConst.ERROR_CODE));
    }
    @Test
    public void testAddBind() throws AccException {
        String clientType = "client";
        /**
         * urs -> sina
         * urs -> qq
         */
        // case 1. urs is main, sina is shadow
        TokenBox tbUrs = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.b.value());
        TokenBox tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        TokenBox tbCqq = cqqVerifier.getTokens(clientType, COOKIE_FORMAT.b.value());
        TokenBox tbUrs2 = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        TokenBox box = new TokenBox(tbSina, tbUrs);
        
        HttpResponse resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_ADD_URL), composeAuthHeader(ynote, box), null, null);
        checkStatusCode(resp, HttpStatus.OK);
        AccHttpClient.closeQuiet(resp);
        
        // case 2. bind again
        bind(box);
        
        // case 3. bind qq
        
        box = new TokenBox(tbSina, tbCqq);
        bind(box);
        
        // print bind info
        JSONObject ret = client.getJSON(Method.POST, getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_ALL_URL), composeAuthHeader(ynote, box.getSessBox()), null, null);
        assertTrue(ret.getString(AccConst.FLAG_MAIN_ID).startsWith(UrsUtils.FAKE_URS_ID_PREFIX));
        JSONArray array = ret.getJSONArray(AccConst.FLAG_BIND);
        assertTrue(array.contains("qq"+QQConst.FAKE_ID));
        assertTrue(array.contains("sina"+SinaConst.FAKE_ID));
        
        // case 4. bind other urs, crash
        
        box = new TokenBox(tbUrs2, tbCqq);
        resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_ADD_URL), composeAuthHeader(ynote, box), null, null);
        checkStatusCode(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        ret = client.getJSON(Method.POST,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_ADD_URL), composeAuthHeader(ynote, box), null, null);
        assertTrue(ret.containsKey("ecode"));
    }

    
    @Test
    public void testGetBindInfo() throws AccException {
        String clientType = "client";
        // case 1. not bind get itself
        TokenBox tbUrs = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        
        JSONObject ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_INFO_URL), composeAuthHeader(ynote, tbUrs), null, null);
        assertEquals(tbUrs.ret.get(AccConst.USER_ID), ret.get(AccConst.USER_ID));
        
        TokenBox tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        TokenBox box = new TokenBox(tbUrs, tbSina);
        TokenBox tbCqq = cqqVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        // case 2. bind urs -> sina, get sina info
        bind(box);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_USER_ID, tbSina.ret.getString(AccConst.USER_ID)));

        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_INFO_URL), composeAuthHeader(ynote, tbUrs), params, null);
        assertEquals(tbSina.ret.get(AccConst.USER_ID), ret.get(AccConst.USER_ID));
        
        // case 3. bind urs -> sina, get cqq info
        params.clear();
        params.add(new Parameter(AccConst.PARAM_USER_ID, tbCqq.ret.getString(AccConst.USER_ID)));
        HttpResponse resp = client.doGet(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_INFO_URL), composeAuthHeader(ynote, tbUrs), params);
        checkStatusCode(resp, HttpStatus.UNAUTHORIZED);
        
        // case 4. bind urs -> cqq, get cqq info using sina cookie
        box = new TokenBox(tbUrs, tbCqq);
        bind(box);
        tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_INFO_URL), composeAuthHeader(ynote, tbSina), params, null);
        assertEquals(tbCqq.ret.get(AccConst.USER_ID), ret.get(AccConst.USER_ID));
        
        // case 5. use another urs id, want get cqq info. crash
        TokenBox tbUrs2 = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_INFO_URL), composeAuthHeader(ynote, tbUrs2), params, null);
        assertTrue(ret.containsKey(AccConst.ERROR_CODE));
    }
    
    @Test
    public void testGetBindAll() throws AccException {
        String clientType = "client";
        // case 1. not bind get all, error
        TokenBox tbUrs = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        JSONObject ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_ALL_URL), composeAuthHeader(ynote, tbUrs), null, null);
        System.err.println(ret);
        assertEquals(AccExpType.NO_BIND_ERROR.getErrorCode(), ret.get(AccConst.ERROR_CODE));
        // case 2. bind sina
        TokenBox tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        TokenBox box = new TokenBox(tbUrs, tbSina);
        bind(box);
        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_ALL_URL), composeAuthHeader(ynote, tbUrs), null, null);
        assertEquals(tbUrs.ret.getString(AccConst.USER_ID), ret.getString(AccConst.FLAG_MAIN_ID));
        assertEquals(tbSina.ret.getString(AccConst.USER_ID), ret.getJSONArray(AccConst.FLAG_BIND).get(0));
        
        // case 3. use sina session cookie to get all info
        tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_ALL_URL), composeAuthHeader(ynote, tbSina), null, null);
        assertEquals(tbUrs.ret.getString(AccConst.USER_ID), ret.getString(AccConst.FLAG_MAIN_ID));
        assertEquals(tbSina.ret.getString(AccConst.USER_ID), ret.getJSONArray(AccConst.FLAG_BIND).get(0));
    }
    
    @Test
    public void testGetMainId() throws AccException {
        String clientType = "client";
        // case 1. not bind get itself
        TokenBox tbUrs = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        JSONObject ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_MAIN_ID_URL), composeAuthHeader(ynote, tbUrs), null, null);
        assertEquals(AccExpType.NO_BIND_ERROR.getErrorCode(), ret.get(AccConst.ERROR_CODE));
        
        // case 2. bind sina, use urs to get main user info
        TokenBox tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        TokenBox box = new TokenBox(tbUrs, tbSina);
        bind(box);
        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_MAIN_ID_URL),
                composeAuthHeader(ynote, tbUrs), null, null);
        assertEquals(tbUrs.ret.getString(AccConst.USER_ID), ret.getString(AccConst.USER_ID));
        
        // case 3. use sina to get main user info
        tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        ret = client.getJSON(Method.GET,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_GET_MAIN_ID_URL),
                composeAuthHeader(ynote, tbSina), null, null);
        assertEquals(tbUrs.ret.getString(AccConst.USER_ID), ret.getString(AccConst.USER_ID));
    }
    
    @Test
    public void testRemoveBind() throws AccException {
        String clientType = "client";
        // case 1. not bind, want remove, error
        TokenBox tbUrs = proxyVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        JSONObject ret = client.getJSON(Method.POST,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL), composeAuthHeader(ynote, tbUrs), null, null);
        assertEquals(AccExpType.NO_BIND_ERROR.getErrorCode(), ret.get(AccConst.ERROR_CODE));
        
        // case 2. bind sina, use urs id login to remove sina bind
        TokenBox tbSina = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        TokenBox ursBindSinaBox = new TokenBox(tbUrs, tbSina);
        bind(ursBindSinaBox);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_USER_ID, tbSina.ret.getString(AccConst.USER_ID)));
        HttpResponse resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL),
                composeAuthHeader(ynote, tbUrs), params, null);
        checkStatusCode(resp, HttpStatus.OK);
        checkNoBind(tbUrs);
        
        // case 3. bind sina, use sina login to remove urs bind
        bind(ursBindSinaBox);
        params.clear();
        params.add(new Parameter(AccConst.PARAM_USER_ID, tbUrs.ret.getString(AccConst.USER_ID)));
        TokenBox tbSinaLogin = sinaVerifier.getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.info.value());
        resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL),
                composeAuthHeader(ynote, tbSinaLogin), params, null);
        checkStatusCode(resp, HttpStatus.OK);
        checkNoBind(tbUrs);
        
        
        // case 4. bind sina, use urs login to remove urs bind
        bind(ursBindSinaBox);
        params.clear();
        params.add(new Parameter(AccConst.PARAM_USER_ID, tbUrs.ret.getString(AccConst.USER_ID)));
        resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL),
                composeAuthHeader(ynote, tbUrs), params, null);
        checkStatusCode(resp, HttpStatus.OK);
        checkNoBind(tbUrs);
        
        // case 5. bind sina, use sina login to remove sina bind
        bind(ursBindSinaBox);
        params.clear();
        params.add(new Parameter(AccConst.PARAM_USER_ID, tbSina.ret.getString(AccConst.USER_ID)));
        resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL),
                composeAuthHeader(ynote, tbSinaLogin), params, null);
        checkStatusCode(resp, HttpStatus.OK);
        checkNoBind(tbUrs);
        
        // case 6. no bind, want remove all, error
        params.clear();
        params.add(new Parameter(AccConst.PARAM_ALL, true));
        ret = client.getJSON(Method.POST,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL), composeAuthHeader(ynote, tbUrs), params, null);
        assertEquals(AccExpType.NO_BIND_ERROR.getErrorCode(), ret.get(AccConst.ERROR_CODE));
        
        // case 7. bind sina, cqq, use urs login to remove all.
        bind(ursBindSinaBox);
        TokenBox tbCqq = cqqVerifier.getTokens(clientType, COOKIE_FORMAT.b.value() | COOKIE_FORMAT.info.value());
        TokenBox ursBindCqqBox = new TokenBox(tbUrs, tbCqq);
        bind(ursBindCqqBox);
        resp = client.doPost(getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL),
                composeAuthHeader(ynote, tbUrs), params, null);
        checkStatusCode(resp, HttpStatus.OK);
        checkNoBind(tbUrs);
        
        // case 8. bind sina, cqq, use sina to login to remove all. fail.
        bind(ursBindSinaBox);
        bind(ursBindCqqBox);
        ret = client.getJSON(Method.POST,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL), composeAuthHeader(ynote, tbSinaLogin), params, null);
        assertEquals(AccExpType.NO_BIND_AUTHORIZE.getErrorCode(), ret.get(AccConst.ERROR_CODE));
        
        // case 9. bind sina, cqq already, use urs login to remove urs. error
        ret = client.getJSON(Method.POST,getLocalHostHttpUrlWithPerfix(AccConst.ACCOUNT_BINDING_REMOVE_URL), composeAuthHeader(ynote, tbUrs), null, null);
        assertEquals(AccExpType.LOGIC_ERROR.getErrorCode(), ret.get(AccConst.ERROR_CODE));
    }
    
}
