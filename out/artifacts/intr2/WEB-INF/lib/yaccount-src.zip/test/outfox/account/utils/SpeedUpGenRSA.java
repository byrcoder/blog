/**
 * @(#)SpeedUpCache.java, 2013-1-22. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class SpeedUpGenRSA {
    public static void main(String[] args) throws AccException {
        int count = 500;
        long start = System.currentTimeMillis();
        for (int i = 0; i < count; i++) {
            AuthUtils.genRSAKeys(null);
        }
        long end = System.currentTimeMillis();
        System.out.println(end-start);
        start = System.currentTimeMillis();
        for (int i = 0; i < count; i++) {
            AuthUtils.genRSAKeysCache(null);
        }
        end = System.currentTimeMillis();
        System.out.println(end-start);
    }
}
