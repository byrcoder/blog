/**
 * @(#)TestPluginFinder.java, 2012-9-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import java.util.Set;

import org.apache.http.cookie.Cookie;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.server.token.verifier.impl.TSinaVerifier;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestPluginFinder extends AccTestCase{
    @Test
    public void test() throws ClassNotFoundException {
        // has plug-ins
        Set<Class<? extends Verifier>> set = PluginFinder.getPluginsInSameDir(TSinaVerifier.class);
        assertTrue(set.size() > 0);
        
        set = PluginFinder.getPluginsInSameDir(Cookie.class);
        assertTrue(set.size() == 0);
        // no plug-in
        set = PluginFinder.getPluginsInSameDir(AuthUtils.class);
        assertTrue(set.size() == 0);
        // has file and abstract class
        set = PluginFinder.getPluginsInSameDir(Verifier.class);
        assertTrue(set.size() == 0);
    }
}
