/**
 * @(#)TestRpcCache.java, 2012-8-27. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.cache.GlobalCache;
import outfox.account.conf.AccConst;

/**
 * @author chen-chao
 */
public class TestRpcCache extends AccTestCase {
    @Before
    @Override
    public void setUp() throws Exception {
        startMiniZKCluster();
        startRpcServer();
    }

    @After
    @Override
    public void tearDown() throws Exception {
        stopMiniZKCluster();
        stopAllRpcCacheServer();
    }
    @Test
    public void test() throws Exception {
        Thread.sleep(2000);
        GlobalCache cache = GlobalCache.getInstance();
        int number = 10;
        // put
        for (int i = 0; i < number; i++) {
            cache.put("" + i, ("" + i).getBytes(AccConst.UTF8));
        }
        // get
        for (int i = 0; i < number; i++) {
            byte[] value = cache.get("" + i);
            assertEquals(i, Integer.parseInt(new String(value, AccConst.UTF8)));
        }
        // remove
        for (int i = 0; i < number; i++) {
            byte[] value = cache.remove("" + i);
            assertEquals(i, Integer.parseInt(new String(value, AccConst.UTF8)));
        }

        // get
        for (int i = 0; i < number; i++) {
            assertEquals(null, cache.get("" + i));
        }

    }
    
   
    
}
