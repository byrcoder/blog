/**
 * @(#)SinaConst.java, 2012-8-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.sina;

import outfox.account.conf.AccConst;
import outfox.account.faketp.server.FakeConst;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public interface SinaConst extends FakeConst{
    
    static final String KEY_REMIND_IN = "remind_in";

    static final String KEY_EXPRIES_IN = "expires_in";

    static final String KEY_UID = "uid";

    static final String KEY_ID = "id";

    static final String KEY_NAME = "name";

    static final String KEY_SCREEN_NAME = "screen_name";
    
    static final String KEY_PROFILE_URL = "profile_image_url";

    static final String FAKE_SCREEN_NAME = "screen_me";
    
    static final String FAKE_PROFILE_URL = "http://note.youdao.com";

    static final String KEY_ERROR_CODE = "error_code";

    static final String KEY_ERROR_URL = "error_url";

    static final String FAKE_ERROR = "redirect_uri_mismatch";

    static final String FAKE_ERROR_CODE = "21322";

    /**
     * 重定向地址不匹配
     */
    static final String FAKE_ERROR_DESCRIPTION = AuthUtils.getStringFromBytes(new byte[] {
        -23, -121, -115, -27, -82, -102, -27, -112, -111, -27, -100, -80, -27, -99, -128, -28, -72, -115,
        -27, -116, -71, -23, -123, -115
    }, AccConst.UTF8);

    static final String FAKE_ERROR_URL = "http://note.youdao.com";
    
    static final String KEY_REQUEST = "request";
    static final String FAKE_REQUEST = "/statuses/home_timeline.json";
}
