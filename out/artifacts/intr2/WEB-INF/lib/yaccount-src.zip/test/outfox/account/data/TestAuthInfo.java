/**
 * @(#)TestAuthInfo.java, 2012-11-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.user.UserInfoWritable;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestAuthInfo extends AccTestCase{
    @Test
    public void testSerializable() throws AccException {
        TpToken tp = new TpToken("asd");
        SessionCookieWritable sess = new SessionCookieWritable(tp);
        PersistTokenWritable pers = new PersistTokenWritable(tp);
        SessionCookieWritable bind = new SessionCookieWritable(tp);
        UserInfoWritable loginUserInfo  = new UserInfoWritable();
        loginUserInfo.userId = "a";
        UserInfoWritable bindUserInfo = new UserInfoWritable();
        bindUserInfo.userId = "b";
        String product = "YNOTE";
        AuthInfo authInfo = new AuthInfo(product, sess, pers, bind, loginUserInfo, loginUserInfo.userId, bindUserInfo.userId);
        byte[] content = AuthUtils.obj2bytes(authInfo);
        AuthInfo retAuthInfo = (AuthInfo) AuthUtils.byte2Obj(content, AuthInfo.class);
        assertEquals(authInfo.product, retAuthInfo.product);
        assertEquals(authInfo.tpToken.token, retAuthInfo.tpToken.token);
        assertEquals(authInfo.userInfo.userId, retAuthInfo.userInfo.userId);
        assertEquals(authInfo.bindUserId, retAuthInfo.bindUserId);
    }
    
    @Test
    public void testEmpty() throws AccException {
        TpToken tp = new TpToken("asd");
        SessionCookieWritable sess = new SessionCookieWritable(tp);
        String product = "YNOTE";
        AuthInfo authInfo = new AuthInfo(product, sess, null, null, null, null, null);
        byte[] content = AuthUtils.obj2bytes(authInfo);
        AuthInfo retAuthInfo = (AuthInfo) AuthUtils.byte2Obj(content, AuthInfo.class);
        assertEquals(authInfo.product, retAuthInfo.product);
        assertEquals(authInfo.tpToken.token, retAuthInfo.tpToken.token);
    }
}
