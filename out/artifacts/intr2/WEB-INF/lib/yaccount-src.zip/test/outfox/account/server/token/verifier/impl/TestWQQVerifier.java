/**
 * @(#)TestWQQVerifier.java, 2012-11-13. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Properties;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.qq.QQConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 * @author chen-chao
 */
public class TestWQQVerifier extends VerifierTestCaseBase{
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
    }

    public void init(String product) {
        super.init(product, "wqq");
        Properties pros = genWQQProperties(getLocalHostHttpsUrl("/wqq/"));
        WQQVerifier wqqVerifier = genWQQVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, wqqVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }
    @Test
    public void test() throws AccException {
        login(true);
    }

    protected TokenBox login(boolean needQuey) throws AccException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(QQConst.FAKE_OPEN_ID_VALUE.toUpperCase()), box.ret.get(AccConst.USER_ID));
        if (needQuey) {
            checkQuery(box, QQConst.FAKE_OPEN_ID_VALUE.toUpperCase());
        }
        return box;
    }
    @Test
    public void testRefreshToken() throws AccException {
        Properties pros = genWQQProperties(getLocalHostHttpsUrl("/wqq/"));
        pros.put("wqq.refreshInMill", "0");
        
        WQQVerifier wqqVerifier = genWQQVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, wqqVerifier);
        login(true);
    }
   
    @Test
    public void testRefreshTokenExpired() throws AccException {
        Properties pros = genWQQProperties(getLocalHostHttpsUrl("/wqq/"));
        pros.put("wqq.expireInMill", "0");
        
        WQQVerifier wqqVerifier = genWQQVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, wqqVerifier);
        TokenBox box = login(false);
        JSONObject obj;
        cookieStore.clear();
        obj = query(box, COOKIE_FORMAT.info.value());
        assertFalse(obj.getBoolean(AccConst.FLAG_LOGIN));
    }
    
}
