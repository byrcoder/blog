/**
 * @(#)TestRequestPCIHandler.java, 2012-9-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.conf.AccConst.ENCRYPT_ALGORITHM;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.utils.client.AccHttpClient;
import outfox.account.utils.client.AccHttpClient.Method;

/**
 * @author chen-chao
 */

public class TestRequestPCIHandler extends AccTestCase {
    
    @Before
    public void setUp() throws Exception {
        super.setUp();
        AccTestCase.startMiniZKCluster();
        startMockServer();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        stopMockServer();
        AccTestCase.stopMiniZKCluster();
        super.tearDown();
    }
    @Test
    public void test() throws AccException {
        HttpResponse resp = doGet(getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(),resp.getStatusLine().getStatusCode());
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, "mobile"));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, "YNOTE"));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, "tsina"));
        AccHttpClient.closeQuiet(resp);
        
        resp = doGet(getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), params);
        checkStatusCode(resp, HttpStatus.OK);
        AccHttpClient.closeQuiet(resp);
        
        params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, "mobile"));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, "YNOTE"));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, "tsina"));
        params.add(new Parameter(AccConst.PARAM_ALOGRITHM, ENCRYPT_ALGORITHM.RSA));
        JSONObject obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null, params, null);
        assertTrue(obj.containsKey(AccConst.PARAM_PCINDEX_NAME));
        assertTrue(obj.containsKey(AccConst.PARAM_PC_NAME));
        System.out.println(obj.getString(AccConst.PARAM_PC_NAME));
        
        params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, "mobile"));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, "YNOTE"));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, "tsina"));
        params.add(new Parameter(AccConst.PARAM_ALOGRITHM, CIPHER_ALGORITHM_TYPE.RSA_ECB_PKCS1_SPLIT_EXP_MODULUS.getAlias()));
        obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null, params, null);
        assertTrue(obj.containsKey(AccConst.PARAM_PCINDEX_NAME));
        assertTrue(obj.containsKey(AccConst.PARAM_PC_NAME));
        assertTrue(obj.getString(AccConst.PARAM_PC_NAME).contains("|"));
        System.out.println(obj.getString(AccConst.PARAM_PC_NAME));
        
        params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, "mobile"));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, "YNOTE"));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, "tsina"));
        params.add(new Parameter(AccConst.PARAM_ALOGRITHM, CIPHER_ALGORITHM_TYPE.RSA_ECB_NOPADING_SPLIT_EXP_MODULUS.getAlias()));
        obj = client.getJSON(Method.GET, getLocalHostHttpUrl(AccConst.URL_AUTH_PREFIX + AccConst.REQUEST_PCI_URL), null, params, null);
        assertTrue(obj.containsKey(AccConst.PARAM_PCINDEX_NAME));
        assertTrue(obj.containsKey(AccConst.PARAM_PC_NAME));
        assertTrue(obj.getString(AccConst.PARAM_PC_NAME).contains("|"));
        System.out.println(obj.getString(AccConst.PARAM_PC_NAME));
    }
}
