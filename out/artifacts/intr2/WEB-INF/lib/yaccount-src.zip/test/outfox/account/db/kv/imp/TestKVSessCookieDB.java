/**
 * @(#)TestKVSessCookieDB.java, 2012-10-26. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db.kv.imp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.SessionCookieWritable;
import outfox.account.data.TpToken;
import outfox.account.db.in.ISessCookieDB;
import outfox.account.db.in.ISessCookieDB.ISessCookieIter;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestKVSessCookieDB extends AccTestCase{
    ISessCookieDB db;
    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        db = new KVSessCookieDB();
    }
    @After
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    @Test
    public void test() throws AccException {
        String userA = "aa";
        cleanAll();
        TpToken tp = new TpToken();
        tp.userId = userA;
        tp.app = "client";
        tp.product="YNOTE";
        tp.verifierName="tsina";
        tp.signature = "1";
        tp.sessIndex = AuthUtils.genUniqueToken();
                
        SessionCookieWritable sess = new SessionCookieWritable(tp);
        db.write(sess.getTpToken());
        SessionCookieWritable tmp = db.read(tp);
        final String sessIndex = sess.getTpToken().sessIndex;
        assertEquals(sessIndex, tmp.getTpToken().sessIndex);
        
        tmp = db.read(sessIndex);
        assertEquals(sess.getTpToken().userId, tmp.getTpToken().userId);
        cleanAll();
        int cnt = count();
        assertEquals(0, cnt);
        
    }
    private void cleanAll() throws AccException {
        ISessCookieIter iter;
        SessionCookieWritable se;
        String sessIndex = null;
        iter = db.getIter(sessIndex);
        while((se = iter.next()) != null) {
            db.remove(se.getTpToken());
        }
    }
    
    private int count() throws AccException {
        ISessCookieIter iter;
        String sessIndex = null;
        iter = db.getIter(sessIndex);
        int cnt = 0;
        while(iter.next() != null) {
            cnt++;
        }
        return cnt;
    }
}

