/**
 * @(#)TestSessHandler.java, 2012-10-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.handler;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.apache.http.cookie.Cookie;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;
import outfox.account.utils.client.AccHttpClient;

/**
 * @author chen-chao
 */
public class TestQueryHandler extends AccTestCase{
    TestTSinaVerifier testVerifier = null;

    @Before
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        this.product = "YNOTE";
        testVerifier = new TestTSinaVerifier();
        testVerifier.setUp();
        setMockServer(testVerifier.getMockServer());
        caseRestart();
    }
    
    @After
    @Override
    protected void tearDown() throws Exception {
        setMockServer(null);
        testVerifier.tearDown();
        
        super.tearDown();
    }
    @Test
    public void testTsinaQuery() throws AccException {
        String clientType = "client";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        assertTrue(box.sess != null);
        JSONObject obj = testVerifier.query(box.getSessBox(), COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        assertEquals(testVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.get(AccConst.USER_ID));
    }
    
    @Test
    public void testTsinaPersTokenQuery() throws AccException {
        String clientType = "client";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.pe.value());
        assertTrue(box.persToken != null);
        cookieStore.clear();
        JSONObject obj = testVerifier.query(box.getPersTokenBox(), COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        assertEquals(testVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.get(AccConst.USER_ID));
    }
    
    @Test
    public void testTsinaBindTokenQuery() throws AccException {
        String clientType = "client";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.b.value());
        assertTrue(box.bind != null);
        cookieStore.clear();
        JSONObject obj = testVerifier.query(box.getBindBox(), COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_BIND));
        assertEquals(testVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.getJSONObject(AccConst.FLAG_BIND_USER).getString(AccConst.USER_ID));
    }
    
    @Test
    public void testTsinaHtcQuery() throws AccException {
        String clientType = "htc";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.pe.value());
        assertTrue(box.persToken != null);
        System.out.println(box.persToken);
        cookieStore.clear();
        JSONObject obj = testVerifier.query(box.getPersTokenBox(), COOKIE_FORMAT.info.value());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        assertEquals(testVerifier.verifier.tpId2ownId(SinaConst.FAKE_ID), obj.get(AccConst.USER_ID));
    }
    @Test
    public void testSessCanNotGetTokenQuery() throws AccException {
        String clientType = "htc";
        TokenBox box = testVerifier.getTokens(clientType, COOKIE_FORMAT.se.value());
        assertTrue(box.sess != null);
        cookieStore.clear();
        
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_APP_NAME, "web"));
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.pe.value() | COOKIE_FORMAT.info.value()));
        
        List<Header> headers = composeAuthHeader(product, box.getSessBox());
        HttpResponseAndJSON respAndJson = doCqWithTestDevice(headers, params);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(respAndJson.response));
        Cookie pers = getCookieInStore(product + AccConst.COOKIE_PERSISTENT);
        assertTrue(pers == null);
        AccHttpClient.closeQuiet(respAndJson.response);
        assertTrue(respAndJson.jsonObj.getBoolean(AccConst.FLAG_LOGIN));
    }
}
