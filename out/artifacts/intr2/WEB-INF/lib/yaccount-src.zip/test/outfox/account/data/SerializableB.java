/**
 * @(#)TestSerializableB.java, 2012-9-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.Serializable;


/**
 * @author chen-chao
 */
public class SerializableB implements Serializable{
    private static final long serialVersionUID = 3163819342445371430L;
    public byte[] a;
    private int b;
    public int getB() {
        return b;
    }
    public void setB(int b) {
        this.b = b;
    }
    public String c;
    public SerializableA d;
}
