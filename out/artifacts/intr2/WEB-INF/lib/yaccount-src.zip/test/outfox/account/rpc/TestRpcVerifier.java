/**
 * @(#)TestRpcVerifier.java, 2012-10-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.rpc;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.data.PersistTokenWritable;
import outfox.account.data.SessionCookieWritable;
import outfox.account.rpc.client.RpcVerifyClient;
import outfox.account.rpc.protocol.IRpcVerifierService;
import outfox.account.server.token.verifier.impl.TestTSinaVerifier;

/**
 * @author chen-chao
 */
public class TestRpcVerifier extends AccTestCase {
    TestTSinaVerifier sinaVerifier = null;
    String ynote = "YNOTE";
    @Before
    @Override
    protected void setUp() throws Exception {
        // TODO Auto-generated method stub
        super.setUp();
        startMiniZKCluster();
        startMockServer();
        sinaVerifier = new TestTSinaVerifier();
        sinaVerifier.setMockServer(mockServer);
        sinaVerifier.init(ynote);
        for (int i = 0; i < 5; i++) {
            startRpcServer();
        }
    }
    @After
    @Override
    protected void tearDown() throws Exception {
        // TODO Auto-generated method stub
        super.tearDown();
        stopMockServer();
        stopMiniZKCluster();
        sinaVerifier.destory();
        stopAllRpcCacheServer();
    }
    @Test
    public void test() throws Exception{
        Thread.sleep(2000);
        RpcVerifyClient client = new RpcVerifyClient();
        for (int i = 0; i < 10; i++) {
            TokenBox tb = sinaVerifier.getTokens("client", 7);
            cookieStore.clear();
            IRpcVerifierService rpcVerifier = client.lookup(tb.sess.getValue());
            SessionCookieWritable sess = rpcVerifier.verifySessionCookie(tb.sess.getValue(), -1);
            assertTrue(sess != null);
            assertEquals(ynote, sess.getTpToken().product);
            sess = rpcVerifier.verifySessionCookie(tb.sess.getValue(), ynote, -1);
            assertTrue(sess != null);
            assertEquals(ynote, sess.getTpToken().product);
            
            PersistTokenWritable pers = rpcVerifier.verifyAuthToken(tb.persToken, -1);
            assertTrue(pers != null);
            assertEquals(ynote, pers.getTpToken().product);
            pers = rpcVerifier.verifyAuthToken(tb.persToken, ynote, -1);
            assertTrue(pers != null);
            assertEquals(ynote, pers.getTpToken().product);
        }
    }
}
