/**
 * @(#)TestAccessTokenVerifier.java, 2013-1-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.ParseException;
import org.apache.http.cookie.MalformedCookieException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.OAuthConstant;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.qq.QQConst;
import outfox.account.faketp.server.sina.SinaConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 * @author chen-chao
 */
public class TestAccessTokenVerifierQConn extends VerifierTestCaseBase{
    public AccessTokenVerifier accVerifier = null;
    Map<String, String> parameterMap = new HashMap<String,String>();
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
        parameterMap.put(OAuthConstant.ACCESS_TOKEN, QQConst.FAKE_SSO_ACCESS_TOKEN);
        parameterMap.put(AccConst.PARAM_OPEN_ID, QQConst.FAKE_ID);
    }

    public void init(String product){
        thirdPartyName = "tpac";
        super.init(product, thirdPartyName);
        Properties pros = genCQQProperty(getLocalHostHttpsUrl("/cqq/"));
        QConnVerifier qconnVerifier = genQConnVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, "cqq", qconnVerifier);
        
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, new AccessTokenVerifier(genAccTokenVerifierProperties(product)));
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        accVerifier = (AccessTokenVerifier)verifier;
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    @Test
    public void testAccessTokenHTTPSLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        final String thirdParty = "cqq";
        
        TokenBox box = getAccessVerifierTokenBox(clientType, thirdParty, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), parameterMap);
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(accVerifier.tpId2ownId(thirdParty, SinaConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(accVerifier, box, thirdParty, SinaConst.FAKE_ID);
    }
    @Test
    public void testAccessTokenHTTPLogin() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "client";
        
        final String thirdParty = "cqq";
        TokenBox box = getAccessVerifierTokenBoxHTTP(clientType, thirdParty, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value(), parameterMap);
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(accVerifier.tpId2ownId(thirdParty, QQConst.FAKE_ID), box.ret.get(AccConst.USER_ID));
        checkQuery(accVerifier, box, thirdParty, SinaConst.FAKE_ID);
    }
}
