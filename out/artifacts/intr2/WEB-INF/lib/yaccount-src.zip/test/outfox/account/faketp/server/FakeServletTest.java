/**
 * @(#)FakeServletTest.java, 2012-9-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import outfox.account.conf.AccConst;
import outfox.account.data.Parameter;
import outfox.account.exceptions.AccException;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.AuthUtils.MultiPartValue;

/**
 * @author chen-chao
 */
public class FakeServletTest extends BaseFakeController{
    
    public FakeServletTest() {
        super();
    }
    private static final long serialVersionUID = 1261407019512833562L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
            IOException {
        System.out.println(req.getRequestURL());
        try {
            invoke(req, resp);
        } catch(AccException e) {
            // do nothing.
        }
    }

    @RequestMapping(value ="/FakeServletTest/post", method=RequestMethod.POST)
    public void test2(HttpServletRequest req, HttpServletResponse resp)
            throws UnsupportedEncodingException, IOException, ServletException, AccException {
        
        Enumeration<String> names = req.getParameterNames();
        Map<String, Object> kv = new HashMap<String, Object>();
        while(names.hasMoreElements()) {
            String key = names.nextElement();
            String value = req.getParameter(key);
            kv.put(key, value);
        }
        
        names = req.getHeaderNames();
        while (names.hasMoreElements()) {
            String key = names.nextElement();
            String value = req.getHeader(key);
            kv.put(key, value);
        }
        String contentType = req.getContentType();
        if (contentType != null
                && contentType.toLowerCase().startsWith(
                        "multipart/form-data")) {
            Map<String, MultiPartValue> map = AuthUtils.simpleParseMultiPart(req);
            for(Entry<String, MultiPartValue> entry : map.entrySet()) {
                kv.put(entry.getKey(), entry.getValue().value);
            }
        }
        
        resp.setContentType(AccConst.JSON_CONTENT_TYPE);
        JSONObject obj = JSONObject.fromObject(kv);
        names = req.getParameterNames();
        while(names.hasMoreElements()) {
            String key = names.nextElement();
            String value = req.getParameter(key);
            System.out.println(value);
        }
        resp.getOutputStream().write(obj.toString().getBytes(AccConst.UTF8));
        resp.getOutputStream().close();
    }
    
    @RequestMapping("/FakeServletTest/multipartPost")
    public void multipartPost(HttpServletRequest req, HttpServletResponse resp) throws AccException {
        String contentType = req.getContentType();
        Map<String, Object> kv = new HashMap<String, Object>();
        if (contentType != null
                && contentType.toLowerCase().startsWith(
                        "multipart/form-data")) {
            Map<String, MultiPartValue> map = AuthUtils.simpleParseMultiPart(req);
           
            for(Entry<String, MultiPartValue> entry : map.entrySet()) {
                kv.put(entry.getKey(), entry.getValue().value);
            }
        }
        String content = (String)kv.get("content");
        content = content == null ? "" : content;
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.RETURN_STR, content));
        write(req, resp, params, HttpStatus.OK);
    }
}
