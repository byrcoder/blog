/**
 * @(#)FakeConst.java, 2012-10-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server;

/**
 * @author chen-chao
 */
public interface FakeConst {
    static final String KEY_CLIENT_ID = "client_id";

    static final String KEY_RESPONSE_TYPE = "response_type";

    static final String KEY_REDIRECT_URI = "redirect_uri";

    static final String KEY_CODE = "code";

    static final String KEY_CLIENT_SECRET = "client_secret";

    static final String KEY_GRANT_TYPE = "grant_type";

    static final String KEY_ACCESS_TOKEN = "access_token";
    
    static final String KEY_STATE = "state";
    
    static final String KEY_ACCESS_TOKEN_HEADER = "Authorization";
    
    static final String KEY_ERROR_DESCRIPTION = "error_description";
    
    static final String KEY_ERROR = "error";
    
    static final String FAKE_AUTHORIZE_CODE = "123";

    static final String FAKE_ACCESS_TOKEN = "SlAV32hkKG";

    static final String FAKE_ID = "72057594037927936";

    static final String FAKE_NAME = "me";
    
    static final String KEY_REFRESH_TOKEN = "refresh_token";
    
}
