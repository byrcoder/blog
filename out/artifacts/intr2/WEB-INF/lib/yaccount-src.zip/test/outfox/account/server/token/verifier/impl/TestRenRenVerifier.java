/**
 * @(#)TestRenRenVerifier.java, 2012-11-14. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import java.util.Properties;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.exceptions.AccException;
import outfox.account.faketp.server.renren.RenRenConst;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;

/**
 * @author chen-chao
 */
public class TestRenRenVerifier extends VerifierTestCaseBase{
    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        init("YNOTE");
    }

    public void init(String product) {
        super.init(product, "renren");
        Properties pros = genRenRenProperty(getLocalHostHttpsUrl("/renren/"));
        RenRenVerifier renrenVerifier = genRenRenVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, renrenVerifier);
    }
    
    @After
    @Override
    public void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    @Test
    public void testNormalLogin() throws AccException {
        login(true);
    }
   
    protected TokenBox login(boolean needQuey) throws AccException {
        String clientType = "client";
        TokenBox box = getTokens(clientType, COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value());
        assertTrue(box.sess != null);
        assertTrue(!StringUtils.isBlank(box.persToken));
        assertEquals(verifier.tpId2ownId(RenRenConst.FAKE_UID), box.ret.get(AccConst.USER_ID));
        if (needQuey) {
            checkQuery(box, RenRenConst.FAKE_UID);
        }
        return box;
    }
    
    @Test
    public void testRefreshToken() throws AccException {
        Properties pros = genRenRenProperty(getLocalHostHttpsUrl("/renren/"));
        pros.put("renren.refreshInMill", "0");
        
        RenRenVerifier renrenVerifier = genRenRenVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, renrenVerifier);
        login(true);
    }
   
    @Test
    public void testRefreshTokenExpired() throws AccException {
        Properties pros = genRenRenProperty(getLocalHostHttpsUrl("/renren/"));
        pros.put("renren.expireInMill", "0");
        
        RenRenVerifier renrenVerifier = genRenRenVerifier(pros);
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, renrenVerifier);
        TokenBox box = login(false);
        JSONObject obj;
        cookieStore.clear();
        obj = query(box, COOKIE_FORMAT.info.value());
        assertFalse(obj.getBoolean(AccConst.FLAG_LOGIN));
    }
}
