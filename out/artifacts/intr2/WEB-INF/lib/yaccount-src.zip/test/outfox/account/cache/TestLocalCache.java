/**
 * @(#)TestAuthCookieCache.java, 2011-12-21. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.cache;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.utils.AuthUtils;

/**
 * @author chen-chao
 */
public class TestLocalCache extends AccTestCase {

    @Test
    public void testRealCache() throws InterruptedException {
        int limit = (int) (16 * 0.75);
        LocalWriteCache<String, String> cache = new LocalWriteCache<String, String>(true, limit);
        int threadNum = 20;
        CacheThread[] threads = new CacheThread[threadNum];
        int stringNum = 300;
        Set<String> strings = new HashSet<String>();
        for (int i = 0; i < stringNum; i++) {
            strings.add(AuthUtils.generateFileId());
        }
        for (int i = 0; i < threadNum; i++) {
            threads[i] = new CacheThread(1000, cache, strings);
            threads[i].start();
            threads[i].join();
        }
        assertEquals(limit, cache.size());
        int count = 0;
        Iterator<String> iter = strings.iterator();
        while (iter.hasNext()) {
            if (cache.get(iter.next()) != null) {
                count++;
            }
        }
        assertEquals(limit, count);
        for (int i = 0; i < threadNum; i++) {
            threads[i] = new CacheThread(1000, cache, strings);
            threads[i].setTask(1);
            threads[i].start();
            threads[i].join();
        }
        assertEquals(0, cache.size());
    }

    @Test
    public void testFakeCache() throws InterruptedException {
        int limit = (int) (16 * 0.75);
        LocalWriteCache<String, String> cache = new LocalWriteCache<String, String>(false, limit);
        int threadNum = 20;
        CacheThread[] threads = new CacheThread[threadNum];
        int stringNum = 300;
        Set<String> strings = new HashSet<String>();
        for (int i = 0; i < stringNum; i++) {
            strings.add(AuthUtils.generateFileId());
        }
        for (int i = 0; i < threadNum; i++) {
            threads[i] = new CacheThread(1000, cache, strings);
            threads[i].start();
            threads[i].join();
        }
        Iterator<String> iter = strings.iterator();
        while (iter.hasNext()) {
            assertEquals(null, cache.get(iter.next()));
        }
    }

    @Test
    public void testRealResizeCache() throws InterruptedException {
        int limit = (int) (32 * 0.75);
        LocalWriteCache<String, String> cache = new LocalWriteCache<String, String>(true, limit);
        int threadNum = 20;
        CacheThread[] threads = new CacheThread[threadNum];
        int stringNum = 300;
        Set<String> strings = new HashSet<String>();
        for (int i = 0; i < stringNum; i++) {
            strings.add(AuthUtils.generateFileId());
        }
        for (int i = 0; i < threadNum; i++) {
            threads[i] = new CacheThread(1000, cache, strings);
            threads[i].start();
            threads[i].join();
        }
        assertEquals(limit, cache.size());
        int count = 0;
        Iterator<String> iter = strings.iterator();
        while (iter.hasNext()) {
            if (cache.get(iter.next()) != null) {
                count++;
            }
        }
        assertEquals(limit, count);
        for (int i = 0; i < threadNum; i++) {
            threads[i] = new CacheThread(1000, cache, strings);
            threads[i].setTask(1);
            threads[i].start();
            threads[i].join();
        }
        assertEquals(0, cache.size());
    }

    private class CacheThread extends Thread {
        private int times;

        private LocalWriteCache<String, String> cache;

        private Set<String> strings;

        private int task;

        public void setTask(int task) {
            this.task = task;
        }

        public CacheThread(int times, LocalWriteCache<String, String> cache, Set<String> strings) {
            this.times = times;
            this.cache = cache;
            this.strings = strings;
            task = 0;
        }

        @Override
        public void run() {
            switch (task) {
                case 0:
                    for (int i = 0; i < times; i++) {
                        Iterator<String> iter = strings.iterator();
                        while (iter.hasNext()) {
                            String value = iter.next();
                            cache.put(value, value);
                            cache.get(value);
                        }
                    }
                    break;
                case 1:
                    for (int i = 0; i < times; i++) {
                        Iterator<String> iter = strings.iterator();
                        while (iter.hasNext()) {
                            String key = iter.next();
                            cache.put(key, key);
                            cache.get(key);
                            cache.remove(key);
                        }
                    }
                    break;
                default:
                    break;
            }

        }
    }
}
