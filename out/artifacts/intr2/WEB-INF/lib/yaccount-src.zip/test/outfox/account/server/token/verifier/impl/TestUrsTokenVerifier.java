/**
 * @(#)TestUrsTokenVerifier.java, 2012-10-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier.impl;

import static com.netease.urs.CookieNames.NTES_SESS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.sf.json.JSONObject;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.MalformedCookieException;
import org.apache.http.message.BasicHeader;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import outfox.account.conf.AccConfig;
import outfox.account.conf.AccConst;
import outfox.account.conf.AccConst.CIPHER_ALGORITHM_TYPE;
import outfox.account.conf.AccConst.CIPHER_TYPE;
import outfox.account.conf.AccConst.COOKIE_FORMAT;
import outfox.account.conf.AccConst.METHOD_NAMES;
import outfox.account.data.Parameter;
import outfox.account.data.SessionCookieWritable;
import outfox.account.db.DataStore;
import outfox.account.exceptions.AccException;
import outfox.account.server.token.TokenVerifierFactory;
import outfox.account.server.token.verifier.VerifierTestCaseBase;
import outfox.account.server.token.verifier.loader.VerifierConfConst;
import outfox.account.utils.AuthUtils;
import outfox.account.utils.CipherUtils;
import outfox.account.utils.CipherUtils.AESEncryptResult;
import outfox.account.utils.client.AccHttpClient;
/**
 * @author chen-chao
 */
public class TestUrsTokenVerifier extends VerifierTestCaseBase{
    public static final String username = "urstest_ynote@163.com";
    public static final String password = "test123";
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        cookieStore.clear();
        startMiniZKCluster();
        startMockServer();
        caseRestart();
        init("YNOTE"); 
    }
    public void init(String product) {
        super.init(product, VerifierConfConst.URS_TOKEN_VERIFIER_NAME);
        Properties pros = genUrsTokenProperty(getLocalHostHttpsUrl("/urstoken/"));
        URSTokenVerifier tokenVerifier = genURSTokenVerifier(pros);
        verifier = TokenVerifierFactory.getInstance().getTokenVerifier(product, thirdPartyName); 
        TokenVerifierFactory.getInstance().setTokenVerifier(product, thirdPartyName, tokenVerifier);
    }
    @Override
    protected void tearDown() throws Exception {
        destory();
        stopMockServer();
        stopMiniZKCluster();
        cookieStore.clear();
        super.tearDown();
    }

    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobile() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.RSA_DEFAULT.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. pc convert to key.
        String loginInfo = AuthUtils.rsaEncryptHex(pc, 
                new Parameter(URSTokenVerifier.URS_USERNAME, "18311097506"),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex("test123")));
        // 3. use pci to login
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result.response;
        JSONObject obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(true, hasCookiesInStore(product + AccConst.COOKIE_SESSION));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        assertTrue(obj.getString(AccConst.USER_ID).startsWith("m18311097506_"));
        assertTrue(obj.containsKey(product + AccConst.ATTR_PART_PC));
    }
    
    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobileWithRu() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.RSA_DEFAULT.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. pc convert to key.
        String loginInfo = AuthUtils.rsaEncryptHex(pc, 
                new Parameter(URSTokenVerifier.URS_USERNAME, "18311097506"),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex("test123")));
        // 3. use pci to login
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        params.add(new Parameter(AccConst.PARAM_FORCE_REDIRECT, 1));
        String ru = "http://dict.youdao.com/search";
        params.add(new Parameter(AccConst.PARAM_REDIRECT_URL_NAME, ru));
        
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result.response;
        //JSONObject obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        assertEquals(ru + "?product=" + product + "&tp=urstoken&s=true", getRedirectLocation(resp));
    }
    
    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobileWithNewRu() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.RSA_DEFAULT.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. pc convert to key.
        String loginInfo = AuthUtils.rsaEncryptHex(pc, 
                new Parameter(URSTokenVerifier.URS_USERNAME, "18311097506"),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex("test123")));
        // 3. use pci to login
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        params.add(new Parameter(AccConst.PARAM_FORCE_REDIRECT, 1));
        String ru = "http://dict.youdao.com/search?q=test&keyfrom=dict.index";
        params.add(new Parameter(AccConst.PARAM_REDIRECT_URL_NAME, ru));
        
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result.response;
        //JSONObject obj = result.jsonObj;
        checkStatusCode(resp, HttpStatus.MOVED_TEMPORARILY);
        assertEquals(ru + "&product=" + product + "&tp=urstoken&s=true", getRedirectLocation(resp));
    }
    
    
    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobileAES() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.AES_CBC_PKCS7.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. pc convert to key.
        String loginInfo = CipherUtils.paramsCompose(
                new Parameter(URSTokenVerifier.URS_USERNAME, username),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex(password)));
        AESEncryptResult result = CipherUtils.aesEncrypt(CIPHER_TYPE.AES_CBC_PKCS7, loginInfo.getBytes(), AuthUtils.strHex(pc));
        loginInfo = Hex.encodeHexString(result.encryptResult);
        String iv = Hex.encodeHexString(result.iv);
        
        // 3. use pci to login
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        headers.add(new BasicHeader(AccConst.PARAM_AES_IV, iv));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(true, hasCookiesInStore(product + AccConst.COOKIE_SESSION));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        assertEquals(verifier.tpId2ownId(username), obj.get(AccConst.USER_ID));
        assertTrue(obj.containsKey(product + AccConst.ATTR_PART_PC));
    }
    
    
    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobileAESCBC5() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.AES_CBC_PKCS5.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. pc convert to key.
        String loginInfo = CipherUtils.paramsCompose(
                new Parameter(URSTokenVerifier.URS_USERNAME, username),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex(password)));
        AESEncryptResult result = CipherUtils.aesEncrypt(CIPHER_TYPE.AES_CBC_PKCS5, loginInfo.getBytes(), AuthUtils.strHex(pc));
        loginInfo = Hex.encodeHexString(result.encryptResult);
        String iv = Hex.encodeHexString(result.iv);
        // 3. use pci to login
        List<Parameter>params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        headers.add(new BasicHeader(AccConst.PARAM_AES_IV, iv));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(true, hasCookiesInStore(product + AccConst.COOKIE_SESSION));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        assertEquals(verifier.tpId2ownId(username), obj.get(AccConst.USER_ID));
        assertTrue(obj.containsKey(product + AccConst.ATTR_PART_PC));
    }
    
    
    /**
     * test mobile client login in HTTP protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenMobileRSAEBC1() throws AccException, MalformedCookieException, ParseException, IOException {
        String clientType = "mobile";
                
        // 1. get pci and pc
        PciPc pciAndPc = getPciPc("mobile", product, thirdPartyName, CIPHER_ALGORITHM_TYPE.RSA_ECB_PKCS1.getAlias());
        String pci = pciAndPc.pci;
        String pc = pciAndPc.pc;
        // 2. pc convert to key.
        String loginInfo = CipherUtils.paramsCompose(
                new Parameter(URSTokenVerifier.URS_USERNAME, username),
                new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex(password)));
        byte[] result = CipherUtils.rsaEncrypt(CIPHER_TYPE.RSA_ECB_PKCS1, loginInfo.getBytes(), AuthUtils.strHex(pc));
        loginInfo = Hex.encodeHexString(result);
        // 3. use pci to login
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(AccConst.PARAM_PCINDEX_NAME, pci));
        
        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader(AccConst.PARAM_LOGIN_INFO, loginInfo));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value()));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(headers, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        assertEquals(true, hasCookiesInStore(product + AccConst.COOKIE_SESSION));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        assertEquals(verifier.tpId2ownId(username), obj.get(AccConst.USER_ID));
        assertTrue(obj.containsKey(product + AccConst.ATTR_PART_PC));
    }
    
    /**
     * test pc client login in HTTPS protocol
     * @throws AccException
     * @throws MalformedCookieException
     * @throws ParseException
     * @throws IOException
     */
    @Test
    public void testUrsTokenClient() throws AccException, MalformedCookieException, ParseException, IOException {
        
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value();
        String clientType = "client";
        TokenBox box = getUrsToken(clientType, format, username, password);
        assertTrue(box.sess != null);
        assertTrue(box.persToken != null);
        assertEquals(verifier.tpId2ownId(username), box.ret.get(AccConst.USER_ID));
        
        checkQuery(box, username);
        
        // use 126 to test.
        final String username2 = "ynote_test001@126.com";
        box = getUrsToken(clientType, format, username2, "test123");
        assertTrue(box.sess != null);
        assertTrue(box.persToken != null);
        assertEquals(verifier.tpId2ownId(username2), box.ret.get(AccConst.USER_ID));
        
        checkQuery(box, username2);
        
    }
    
    @Test
    public void testGetSessCookie() throws AccException{
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value();
        String clientType = "client";
        TokenBox box = getUrsToken(clientType, format, username, password);
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_METHOD, METHOD_NAMES.WRITE_COOKIE.name()));
        List<Header> header = composeAuthHeader(product, box.getSessBox());
        HttpResponse resp = client.doGet(getLocalHostHttpUrlWithPerfix(AccConst.GET_URS_SESS_URL), header, params);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        Cookie c = getCookieInStore(NTES_SESS);
        assertTrue(c != null);
        cookieStore.clear();
    }
    
    public TokenBox getUrsToken(String clientType, int cookieFormat) throws AccException {
        return getUrsToken(clientType, cookieFormat, username, password);
    }
    
    public TokenBox getUrsToken(String clientType, int cookieFormat, String username, String password) throws AccException {
        cookieStore.clear();
        // 1. use user name and password to login in HTTPS protocal
        List<Parameter> params = new ArrayList<Parameter>();
        params.add(new Parameter(AccConst.PARAM_APP_NAME, clientType));
        params.add(new Parameter(AccConst.PARAM_PRODUCT_NAME, product));
        params.add(new Parameter(AccConst.PARAM_THIRD_PARTY_NAME, thirdPartyName));
        params.add(new Parameter(URSTokenVerifier.URS_USERNAME, username));
        params.add(new Parameter(URSTokenVerifier.URS_PASSWORD, DigestUtils.md5Hex(password)));
        // want session cookie,  persist cookie and info
        params.add(new Parameter(AccConst.PARAM_COOKIE_FORMAT, cookieFormat));
        HttpResponseAndJSON result2 = doLoginWithTestDevice(null, params);
        HttpResponse resp = result2.response;
        JSONObject obj = result2.jsonObj;
        checkStatusCode(resp, HttpStatus.OK);
        removeExpireCookiesFromStore(extractCookieHeaderSetStore(resp));
        // 4. get information
        AccHttpClient.closeQuiet(resp);
        TokenBox tb = makeTokenBox(obj);
        cookieStore.clear();
        return tb;
    }
    @Test
    public void testExpiredSessionCookie() throws AccException {
        AccConfig.getPros().setProperty(AccConfig.NAME_MEMCACHED_CACHE_REFRESH_TIME, 10);
        int format = COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value() | COOKIE_FORMAT.pe.value();
        String clientType = "client";
        TokenBox tb = getUrsToken(clientType, format);
        checkQuery(tb, username);
        String sessVal = tb.sess.getValue();
        final DataStore instance = DataStore.getInstance();
        sessVal = sessVal.substring("v2|".length());
        SessionCookieWritable sessWritable = instance.getAliveSession(sessVal, -1);
        
        sessWritable.setSessAliveTime(0L);
        instance.writeSessToken(sessWritable.getTpToken());
        cookieStore.clear();
        JSONObject obj = queryInfo(tb.getSessBox());
        assertFalse(obj.getBoolean(AccConst.FLAG_LOGIN));
        sessWritable.setSessAliveTime(-1L);
        instance.writeSessToken(sessWritable.getTpToken());
        cookieStore.clear();
        obj = queryInfo(tb.getSessBox());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        sessWritable.setSessAliveTime(0L);
        instance.writeSessToken(sessWritable.getTpToken());
        cookieStore.clear();
        obj = queryInfo(tb.getSessBox());
        assertFalse(obj.getBoolean(AccConst.FLAG_LOGIN));
        cookieStore.clear();
        obj = query(tb.getPersTokenBox(), COOKIE_FORMAT.info.value() | COOKIE_FORMAT.se.value());
        obj = queryInfo(tb.getSessBox());
        assertTrue(obj.getBoolean(AccConst.FLAG_LOGIN));
        
    }
}
