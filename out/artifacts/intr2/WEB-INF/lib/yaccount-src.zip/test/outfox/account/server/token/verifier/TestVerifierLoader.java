/**
 * @(#)TestVerifierLoader.java, 2012-9-12. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.server.token.verifier;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;

/**
 * @author chen-chao
 */
public class TestVerifierLoader extends AccTestCase{
    String home;
    @Before
    @Override
    protected void setUp() throws Exception {
        // TODO Auto-generated method stub
        super.setUp();
        
    }
    @After
    @Override
    protected void tearDown() throws Exception {
        // TODO Auto-generated method stub
        super.tearDown();
    }
    @Test
    public void test() {
        
    }
}
