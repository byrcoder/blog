/**
 * @(#)TestDataStore.java, 2012-11-28. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.db;

import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import outfox.account.AccTestCase;
import outfox.account.conf.AccConfig;
import outfox.account.db.DataStore.MappingRelationship;
import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class TestDataStoreMapping extends AccTestCase{
    private String mainId = "main@163.com";
    private String shadowA = "a";
    private String shadowB = "b";
    private String shadowC = "c";
    private Set<String> ids;
    private DataStore store;
    @Before
    protected void setUp() throws Exception {
        super.setUp();
        AccConfig.setReuseTableMode(false);
        ReflectConstruct dataStoreConstruct = new ReflectConstruct(DataStore.class);
        store = (DataStore) dataStoreConstruct.call();
        ids = new HashSet<String>();
        ids.add(shadowA);
        ids.add(shadowB);
        ids.add(shadowC);
    }
    @After
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    @Test
    public void testIterMappingMain() throws AccException {
        store.addUserMapping(mainId, shadowA);
        store.addUserMapping(mainId, shadowB);
        store.addUserMapping(mainId, shadowC);
        MappingRelationship relationship = store.getAllMappingByMainId(mainId);
        assertEquals(mainId, relationship.getMainId());
        assertEquals(ids.size(), relationship.getShadowIds().size());
        for(String id : relationship.getShadowIds()) {
            assertTrue(ids.contains(id));
        }
    }
    
    @Test
    public void testIterMappingShadow() throws AccException {
        store.addUserMapping(mainId, shadowA);
        store.addUserMapping(mainId, shadowB);
        store.addUserMapping(mainId, shadowC);
        MappingRelationship relationship = store.getAllMapping(shadowA);
        assertEquals(mainId, relationship.getMainId());
        assertEquals(ids.size(), relationship.getShadowIds().size());
        for(String id : relationship.getShadowIds()) {
            assertTrue(ids.contains(id));
        }
    }
    
    @Test
    public void testRemoveAllMapping() throws AccException {
        store.addUserMapping(mainId, shadowA);
        store.addUserMapping(mainId, shadowB);
        store.addUserMapping(mainId, shadowC);
        int cnt = store.getMappingCount(shadowA);
        assertEquals(3, cnt);
        store.removeAllMapping(mainId);
        cnt = store.getMappingCount(shadowA);
        assertEquals(0, cnt);
        cnt = store.getMappingCount(mainId);
        assertEquals(0, cnt);
    }
    
    @Test
    public void testIsOneMapping() throws AccException {
        store.addUserMapping(mainId, shadowA);
        assertTrue(store.isOnlyOneBindInfo(shadowA));
        assertTrue(store.isOnlyOneBindInfo(mainId));
        store.addUserMapping(mainId, shadowB);
        assertFalse(store.isOnlyOneBindInfo(shadowA));
        assertFalse(store.isOnlyOneBindInfo(mainId));
    }
}
