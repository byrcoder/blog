/**
 * @(#)URSConst.java, 2013-3-21. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.faketp.server.urs;

import outfox.account.faketp.server.FakeConst;

/**
 * @author chen-chao
 */
public interface URSConst extends FakeConst{
    static final String FAKE_URS_SESS_COOKIE = "asfasdf";
}
