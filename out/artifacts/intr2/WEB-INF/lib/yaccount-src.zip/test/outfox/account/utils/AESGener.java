/**
 * @(#)AESGener.java, 2013-8-7. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.utils;

import outfox.account.exceptions.AccException;

/**
 * @author chen-chao
 */
public class AESGener {
    public static void main(String[] args) throws AccException {
        System.out.println(AuthUtils.aesEncryptAnyKey("----", "----ccc"));
    }
}
