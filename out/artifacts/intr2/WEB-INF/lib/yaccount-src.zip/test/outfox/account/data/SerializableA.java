/**
 * @(#)TestSerializableA.java, 2012-9-21. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outfox.account.data;

import java.io.Serializable;

/**
 * @author chen-chao
 */
public class SerializableA implements Serializable{
    private static final long serialVersionUID = -3492973483561960622L;
    public int a;
    public byte[] c;
}
