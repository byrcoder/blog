package odis.cowork;

import java.util.HashSet;
import java.util.TreeMap;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import static odis.cowork.IJobMasterProtocol.*;

public class TaskStatus {
    private static final Logger LOG = LogFormatter.getLogger(TaskStatus.class);
    // basic information
    protected TaskDef task;        // task definition
    // running information
    protected String worker;       // representive worker running this task      
    volatile protected int state;           // state of representive worker
    protected float progress;      // progress of representive worker
    protected CounterMap counters; // counters of representive worker
    protected String doneMsg;      // the done message from representive work
    protected int[] resultPartCount;
    // failure information
    protected int failure;
    protected HashSet<Long> failCursors, skipCursors; // failed cursors
    protected HashSet<String> failMachs, skipMachs;   // failed machines
    // backup executing information
    protected HashSet<String> backupWorkers; // backup executing tmId
    // process time
    protected long processTime;

    // expect failure: when a skip cursor is added while some workers have
    // already begun with previous version of skip cursor list
    protected int expectFailure;      
    protected JobMaster jobMaster;
    protected TreeMap<String, Integer> lastEventIdxMap;
//    protected int lastPreStageEventIdx;
//    protected String[] completionPaths;
    /**
     * Create task running status of a task: will keep all states during the
     * life time of this task 
     * @param task  The definition of the task
     */
    public TaskStatus(TaskDef task, JobMaster tmMgr) {
        // task
        this.task = task;
        // initialize as unassigned
        worker = null;
        state = TASK_STATE_UNASSIGNED; 
        processTime = 0; progress=0f;
        counters = null; doneMsg = null;
        resultPartCount=null;
        // failure sets
        failure = 0;
        failCursors = new HashSet<Long>();
        skipCursors = new HashSet<Long>();
        failMachs = new HashSet<String>();
        skipMachs = new HashSet<String>();
        // back machines
        backupWorkers = new HashSet<String>();
        // expect failure
        expectFailure = 0;
        this.jobMaster = tmMgr;
        lastEventIdxMap = new TreeMap<String, Integer>();
    }
    
    protected TaskStatus(TaskStatus that) {
        this.task = that.task; this.worker = that.worker;
        this.state = that.state; 
        this.processTime = that.processTime; this.progress = that.progress;
        this.counters = that.counters; this.doneMsg = that.doneMsg;
        this.resultPartCount = that.resultPartCount;
        this.failure = that.failure;
        this.failCursors = new HashSet<Long>(that.failCursors);
        this.skipCursors = new HashSet<Long>(that.skipCursors);
        this.failMachs = new HashSet<String>(that.failMachs);
        this.skipMachs = new HashSet<String>(that.skipMachs);
        this.backupWorkers = new HashSet<String>(that.backupWorkers);
        this.jobMaster = that.jobMaster;
        this.lastEventIdxMap = new TreeMap<String, Integer>(that.lastEventIdxMap);
    }
    
    /**
     * Start a running instance of the task at this worker
     * @param worker  The task master id of the worker
     */
    public void start(String worker) {
        if (this.worker==null || state==TASK_STATE_FAIL) {
                                 // major worker: remember all progress
            this.worker = worker;
            this.state = TASK_STATE_RUNNING; 
            this.processTime = 0; this.progress = 0f;
            this.counters = null; this.doneMsg = null;
        } else {                 // backup worker: remember only tmId
            LOG.info("Start backup worker " + worker + " for " + task);
            backupWorkers.add(worker);
        }
    }          
    
    /**
     * Status update from a running instance of the task
     * @param tmId  The task master id of the worker
     * @param report task report
     */    
    public void update(String tmId, TaskReport report) {
        assert this.worker!=null && this.isRunning();
        float f = report.getProgress();
        if (this.worker.equals(tmId)) { // major worker: update progress
            if ( f<0f || f>1f ) {
                LOG.warning("Progress out of range: progress="+f);
                f = Math.max(0f,Math.min(f,1f));                  
            }
            processTime = report.getProcessTime(); progress = f; counters = report.getCounters();
            resultPartCount = report.getResultPartCount();
            
            lastEventIdxMap.put(tmId, report.getLastPreStageEventIdx());
//            completionPaths = report.getCompletionPaths();
        }                               // otherwise: skip
    }
    
    /**
     * Success returned from a running instance of the task: after receive
     * this, all other running instance will be interrupted and the status
     * of the task will be set as success. 
     * @param tmId  The task master id of the worker
     * @param t  Time consumed by worker of this task so far
     * @param f  The progress of this running instance
     * @param cm  The counters of this running instance
     * @param msg  The finish message of this running instance
     */
    public String[] success(String tmId, long t, float f, CounterMap cm, String msg, int[] resultCount) {
        assert this.worker!=null && this.isRunning();
        // switch representive worker if success from backup execution
        if (!this.worker.equals(tmId)) {
            if (backupWorkers.remove(tmId)) {
                backupWorkers.add(this.worker); this.worker = tmId;                  
            } else LOG.warning("BUG: worker is is not assigned for task: " + tmId);
        }
        // set success status
        state = TASK_STATE_SUCCESS; 
        processTime = t; progress = f; counters = cm; doneMsg = msg;
        resultPartCount = resultCount;
        // delete other backup workers and clear backup workers set
        String[] ws = new String[1+backupWorkers.size()];
        int i=0; ws[i++] = this.worker;
        jobMaster.getTaskMaster(worker).decRunningCount(task);
        for (String w:backupWorkers) {
            LOG.info("Deleting backup worker " + w + " for task " + task + " (succ="+tmId+")");
            jobMaster.getTaskMaster(w).delete(task, true);
            ws[i++] = w;
        }
        backupWorkers.clear();
        //jobMaster.getTaskMaster(tmId).delete(task, false);
        return ws;
    }
    
    /**
     * Fail returned from a running instance of the task
     *  - if there are other instance running, switch to that
     *  - otherwise, mark the task and fail and remember the failing info. 
     * @param tmId  The task master id of the worker
     * @param t  Time consumed by worker of this task so far
     * @param f  The progress of this running instance
     * @param cm  The counters of this running instance
     * @param msg  The finish message of this running instance
     * @param cursor  The fail cursor position
     * @return  Whether this results in a "real" failure
     */
    public boolean fail(String tmId, long t, float f, CounterMap cm, String msg, long cursor) {
        lastEventIdxMap.put(tmId, 0);
        boolean real = false;
        // switch worker
        if (this.worker.equals(tmId)) {
            this.worker = null;
            for (String bk:backupWorkers) {
                this.worker = bk;
                if (this.worker!=null) {
                    LOG.info("Task " + this.task + " is switching from " + tmId 
                            + " to backup worker " + worker + " due to fail().");
                    if (worker.equals(tmId))
                        LOG.severe("BUG: no switching really happens");
                    break;
                }
            }
            if (this.worker==null) {  // no backup: remember last fail status
                this.worker = tmId;
                state = TASK_STATE_FAIL; processTime = t; progress = f;
                counters = cm; doneMsg = msg;
                real = true;
            } else {  // yes! I have backup
                backupWorkers.remove(worker);
            }
        } else backupWorkers.remove(tmId);
        // delete running task at task master
        jobMaster.getTaskMaster(tmId).delete(task, true);
        // set fail cursor 
        if (cursor==TaskRunnable.NON_CURSOR) {
            if (skipMachs.contains(tmId)) {    // BUG: skip machine returned
                LOG.warning("Asked to skip " + tmId + " for " + task 
                        + " but was still there.");
                failure++;
            } else if (failMachs.remove(tmId)) {
                skipMachs.add(tmId); 
            } else {
                failMachs.add(tmId);
                failure++;
            }
        } else {
            if (skipCursors.contains(cursor)) { 
                if (expectFailure>0) {  // This is not a BUG.  When a backup 
                    // task was initialized and it took a earlier list of 
                    // skipped cursors.  It could fail at the same position 
                    // after previously returned worker set this as skip. 
                    expectFailure--;
                } else {                 // BUG: skip cursor returned
                    LOG.warning("Asked to skip " + cursor + " in " + task 
                            + " but was still there.");
                    failure++;
                }
            } else if (skipMachs.contains(tmId)) { // BUG: skip machine returned
                LOG.warning("Asked to skip " + tmId + " for " + task 
                        + " but was still there.");
                failure++;
            } else {
                boolean isRepeat = false;
                // repeat cursor failure of not?
                if (failCursors.remove(cursor)) { // repeat cursor
                    skipCursors.add(cursor); isRepeat = true;
                    // these running workers must fail since they don't know
                    // this cursor has to be skipped.
                    expectFailure = real? 0: backupWorkers.size()+1;
                } else failCursors.add(cursor);   // non-repeat cursor
                // repeat machine failure or not?
                if (failMachs.remove(tmId)) {           // repeat cursor
                    skipMachs.add(tmId); isRepeat = true;
                } else failMachs.add(tmId);   // non-repeat cursor
                // count only non-repeat failures
                if (!isRepeat) failure++;
            }
                
        }
        // skip failed cursors
        task.setSkip(skipCursors);
        return real;
    }
    
    public int getLastEventIdx(String tmId) {
        return lastEventIdxMap.get(tmId);        
    }
    
    public boolean using(String tmId) {
        lastEventIdxMap.put(tmId, 0);
        if (tmId.equals(worker)) return true;
        if (backupWorkers != null) {
            for (String bw : backupWorkers) {
                if (tmId.equals(bw)) return true;
            }
        }
        return false;
    }
        
    /**
     * Lost task master which was running an instance of this task
     * @param tmId  The id of task master
     * @return  Whether this result in the lost of this task
     */
    public boolean lost(String tmId) {
        if (worker==null) {  // FIXME: debug code, pretend to be real lost
            LOG.warning("Claim to lost/kill " + tmId + ", but no worker got for " + this.task 
                    + ", status="+state);
            return true;
        }
        
        lastEventIdxMap.put(tmId, 0);
        boolean isLost = false;
        // switch worker
        if (this.worker.equals(tmId)) {
            this.worker = null;
            for (String bk:backupWorkers) {
                this.worker = bk;
                if (this.worker!=null) {
                    LOG.info("Task " + this.task + " is switching from " + tmId 
                            + " to backup worker " + worker + " due to lost().");
                    if (worker.equals(tmId))
                        LOG.severe("BUG: no switching really happens");
                    break;
                }
            }
            if (this.worker == null) {  // no backup: reset state as unassigned
                this.counters=null; this.doneMsg=null;
                state = TASK_STATE_UNASSIGNED; processTime=0; progress=0f;
                isLost = true;
            } else // have backup: need to remove "worker" from backup
                backupWorkers.remove(worker);
        } else backupWorkers.remove(tmId);
        return isLost;
    }
    
    public String[] abort() {
        String[] ws = new String[backupWorkers.size()+1];
        jobMaster.getTaskMaster(this.worker).delete(task, true);
        int i=0; ws[i++] = this.worker; 
        for (String w:this.backupWorkers) {
            jobMaster.getTaskMaster(w).delete(task, true);
            ws[i++] = w;
        }
        worker = null;
        state = TASK_STATE_UNASSIGNED; processTime=0; progress=0f;
        counters = null; doneMsg = null;
        backupWorkers.clear();
        lastEventIdxMap.clear();
        return ws;
    }
    
    public boolean isRunning() { return state==TASK_STATE_RUNNING; }
    public boolean isSuccess() { return state==TASK_STATE_SUCCESS; }
    public boolean isPreparing() { return state==TASK_STATE_PREPARING; }
    
    public int getRetries() { return failure; }
    
    public boolean skip(String tmId) {        
        return skipMachs != null && skipMachs.contains(tmId); 
    }

    public String toString() {
        return task+" ["+TaskState.getState(state)+":"+worker+":"+
            (Math.round(progress*100)/100.0) +":retry="+getRetries()+"] [TotalTime=" +
            (Math.round(processTime/100.0)/10.0)+"s]";
    }

    public long getProcessTime() {
        return processTime;
    }

    public void setProcessTime(long processTime) {
        this.processTime = processTime;
    }

    public TaskDef getTask() {
        return task;
    }

    public void setTask(TaskDef task) {
        this.task = task;
    }

    public String getWorker() {
        return worker;
    }

    public void setWorker(String worker) {
        this.worker = worker;
    }
}