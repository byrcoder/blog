/**
 * @(#)ResManagerUpdater.java, 2013-1-16. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.rpc2.RpcException;
import toolbox.misc.LogFormatter;
import toolbox.web.WebServer;

/**
 * 
 * monitor for res manager
 * 
 * @author chenheng
 * 
 */
public class ResManagerUpdater extends Thread {

    private static final Logger LOG = LogFormatter.getLogger(ResManagerUpdater.class);
    private static final long UPDATE_INTERVAL = 10 * 1000; //10s
    private Map<String, ClusterNodeInfo> resMapSnapshot = new TreeMap<String, ClusterNodeInfo>();
    private volatile boolean isRunning = true;
    protected Date lastUpdateTime = new Date();
    private ResourceManager rm = null;
    private WebServer web = null;
    private int webPort = -1;
    private String jmWebHost;
    private String jmWebPort;
    
    public ResManagerUpdater() {}
    
    public ResManagerUpdater(ResourceManager rm, int webPort, String jmWebHost, String jmWebPort) throws Throwable {
        super.setDaemon(true);
        super.setName("ResourceManagerUpdater");
        this.rm = rm;
        this.webPort = webPort;
        this.jmWebHost = jmWebHost;
        this.jmWebPort = jmWebPort;
        web = new WebServer(webPort);
        File tmpDir = new File(CoworkConfig.get().getOdisTmpDir(), "Jetty_Monitor_RM");
        tmpDir.delete();
        tmpDir.mkdirs();
        web.addAppContext(CoworkConfig.getWebDir().getPath(), "/resManager", tmpDir);
        web.start();
    }
    
    @Override
    public void run() {
        LOG.info("ResManagerUpdater is start!");
        while(isRunning) {
            
            synchronized(resMapSnapshot) {
                rm.getResMapSnapshot(resMapSnapshot);
            }
            LOG.info("the snapshot is" + resMapSnapshot);
            lastUpdateTime.setTime(System.currentTimeMillis());
            
            try {
                Thread.sleep(UPDATE_INTERVAL);
            } catch (InterruptedException e) {
                
            }
        }
        LOG.info("ResManagerUpdater is stopped!");
    }
    
    public Map<String, ClusterNodeInfo> getResMap() {
        Map<String, ClusterNodeInfo> resMap = new HashMap<String, ClusterNodeInfo>();
        synchronized(resMapSnapshot) {
            resMap.putAll(resMapSnapshot);
        }
        return resMap;
    }
    
    public int getWebPort() {
        return webPort;
    }
    
    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    public String getReswebAddr() {
        StringBuilder sb = new StringBuilder();
        sb.append("http://").append(jmWebHost).append(":").append(webPort);
        return sb.toString();
    }

    public String getJMAddr() {
        return "http://" + jmWebHost + ":" + jmWebPort;
    }

    public void returnResource(String tmid, String resourceID) {
        try {
            rm.returnResource(tmid, resourceID);
        } catch (RpcException e) {
            LOG.log(Level.WARNING, "", e);
        }
    }
    
    
}
