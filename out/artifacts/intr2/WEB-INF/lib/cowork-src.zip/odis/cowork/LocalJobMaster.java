/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.cowork.CounterMap.Counter;
import odis.cowork.ITaskMasterProtocol.TaskCompletionEventsUpdate;
import odis.io.ReadWriteUtils;
import odis.rpc2.RpcException;
import toolbox.misc.EmptyInstance;
import toolbox.misc.LogFormatter;

/**
 * Local job master & task master for debug use only.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public class LocalJobMaster implements IJobSubmissionProtocol {

  private static final Logger LOG =
    LogFormatter.getLogger(LocalJobMaster.class.getName());

  private static final long PRINT_PROGRESS_INTERVAL = 5000;

  // "job master" state
  protected String jobId;
  private JobDef jobDef;
  private JobStatus jobStatus;
  private TaskDef[][] tasks;
  private String[][] doneMsgs;
  private CounterMap[][] counters;
  private boolean isAbort;

  // "task master" state
  private File localTmpRoot;
  private ThreadTaskWorker[] workers;
  private Thread[] taskThreads;  

  TaskMaster tm;
  
  private class ThreadTaskWorker extends TaskWorker implements Runnable {    
    private int stage, part;
    public TaskRunnable tr;
    public Throwable throwable = null;
    
    public ThreadTaskWorker(int stage, int part) throws IOException { 
      super();

      File localDirFile = new File(localTmpRoot, tasks[stage][part].getTaskId());
      ReadWriteUtils.fullyDelete(localDirFile);
      localDirFile.mkdirs();
      this.localDir = localDirFile.getPath();

      this.stage = stage; this.part = part;
      tr = tasks[stage][part].getTaskRunnable();
    }
    
    @Override
    public TaskRunnable getTaskRunnable() {
        return tr;
    }
    
    public TaskDef getTaskDef() {
        return tasks[stage][part];
    }
    
    @Override
    public ITaskMasterProtocol getTaskMaster() {
        return tm;
    }

    public void run() {
      throwable = null;
      try {
        tr.setCursor(new CursorBuffer(new File(localDir,CURSOR_FILE), "rw"));
        tr.configure(jobDef, this);
        tr.run();
        doneMsgs[stage][part] = tr.getDoneMsg();
        counters[stage][part] = tr.getCounters();
        tr.closeCursor();
      } catch (Throwable t) {
        throwable = t;
        if (t instanceof Exception) {
          LOG.log(Level.WARNING, "Exception in Task", (Exception)t);
          if (t instanceof RuntimeException)
            throw (RuntimeException)t;
        } // if
      }
    }
    
//    public String[] getPrevWorkers() throws RpcException {
//        if (stage==0) return null;
//        String[] result = new String[tasks[stage-1].length];
//        Arrays.fill(result, "local:"+localTmpRoot);
//        return result;
//    }
    
    
    @Override
    public TaskCompletionEventsUpdate requestPreStageTaskUpdate(String tipId, int from, int max) throws RpcException {
        TaskCompletionEvent[] es = new TaskCompletionEvent[tasks[stage-1].length];
        for (int i = 0; i < tasks[stage-1].length; ++i) {
            TaskDef task = tasks[stage-1][i];
                TaskCompletionEvent e = new TaskCompletionEvent(i,
                        task.getTaskId(), task.getPartIdx(), tm.getHostname()
                                + ":" + tm.getFilePort(),
                        TaskCompletionEvent.TASK_SUCCESS);
            es[i] = e;            
        }
        return new TaskCompletionEventsUpdate(es, false);
    }
    
    @Override
    public boolean getAndClearUpdate() {
        return true;
    }

    public long getPingInterval() { return 10; }

  }
  
  public JobStatus submitJob(JobConfig job) {
    try {
      // initialize "job master" and job
      isAbort = false;
      this.jobDef = job.jobDef;      
  
      jobId = CoWorkUtils.generateJobID(jobDef.getJobName(), jobDef.getUser());
      tasks = new TaskDef[jobDef.getTotalStage()][];
      doneMsgs = new String[jobDef.getTotalStage()][];
      counters = new CounterMap[jobDef.getTotalStage()][];
      for (int stage=0; stage<tasks.length; stage++) {
        tasks[stage] = this.jobDef.getTaskDefs(jobId,stage);
        doneMsgs[stage] = new String[tasks[stage].length];
        counters[stage] = new CounterMap[tasks[stage].length];
      }
      
      // initialize and start "task master"
      String[] tmpDirs = CoworkConfig.get().getTaskMasterTmpDir("local");
      if (tmpDirs==null)
        throw new IOException("Cannot get tmp directory for cowork \"local\" " +
            "instance. Please check odis.xml.");
      localTmpRoot = new File(tmpDirs[0]);      
      ReadWriteUtils.fullyDelete(localTmpRoot);
      tm = new TaskMaster(new File[]{localTmpRoot}, localTmpRoot);
      jobStatus = new JobStatus(jobId, tasks.length);
      jobStatus.setRun();
      for (int stage = 0; stage < tasks.length; stage ++) {
          LOG.info(jobDef.getStageName(stage) + " 0%");        
        jobStatus.setProgress(jobStatus.getStage(), 0f);
        if (isAbort) break;
        taskThreads = new Thread[tasks[stage].length];
        workers = new ThreadTaskWorker[tasks[stage].length];
        for (int part = 0; part < taskThreads.length; part ++) {
          workers[part] = new ThreadTaskWorker(stage,part);
          taskThreads[part] = new Thread(workers[part], "Thread for worker of stage " 
              + stage + " part " + part);
          taskThreads[part].start();          
        } // for part
        for (int part=0; part<taskThreads.length; part++) {
            while (taskThreads[part].isAlive()) {
                taskThreads[part].join(PRINT_PROGRESS_INTERVAL);
                float p = 0;
                for (int i = 0; i < taskThreads.length; i++) {
                    p += workers[i].tr.getProgress() / workers.length; 
                }
                LOG.info(String.format("%s: %5.1f%%", jobDef.getStageName(stage), p * 100));
            }
        } // for part
        for (int part = 0; part < taskThreads.length; part ++)
          if (workers[part].throwable != null)
            throw workers[part].throwable;
        float jobProgress = 0;
        for (int i=0; i<taskThreads.length; i++)
          jobProgress += workers[i].tr.getProgress();
        jobProgress /= tasks[stage].length;
        jobStatus.setProgress(jobStatus.getStage(), jobProgress);
        jobStatus.incStage();
      } // for stage
      
      JobStatus js = getJobStatus(jobId);      
      // delete temp dir
      ReadWriteUtils.fullyDelete(localTmpRoot);
      return js;
    } catch (Throwable e) {
      LOG.log(Level.WARNING, "Throwing error/exception", e);
      return null;
    }
  }

  public void abortJob(String jobId) { isAbort = true; }
  public boolean removeJob(String jobId) { return true; }

  public JobStatus getJobStatus(String jobId) { return jobStatus; }
  public String getJobMsg(String jobId) { return null; }
  public String[][] getTaskMsgs(String jobId) { return doneMsgs; }  
  public CounterMap[] getJobCounters(String jobId) {
      CounterMap[] cts = new CounterMap[jobDef.getTotalStage()];
      for (int stage=0; stage<cts.length; stage++) {
          cts[stage] = new CounterMap();
          for (int i=0; i<counters[stage].length; i++) {
              if (counters[stage][i]==null) continue;
              for (Map.Entry<String, Counter> entry:counters[stage][i].entrySet()) {
                  Counter c = cts[stage].get(entry.getKey());
                  if (c==null)
                      cts[stage].put(entry.getKey(), new Counter(entry.getValue().get()));
                  else c.inc(entry.getValue().get());
              }
          }
      }
      return cts;
  }

  public long getUpdateInterval(int version) { return Long.MAX_VALUE; }
  
  public String [] getAllowedUsers() throws RpcException { return EmptyInstance.STRINGS; }
  public void setAllowedUsers(String [] users) throws RpcException { return; }
  
  @Override
  public String getCUID() throws RpcException {
      return "local";
  }

@Override
public void setDebug(boolean flag) throws RpcException {
}

@Override
public void addBlacklisted(String tmId) throws RpcException {
    // TODO Auto-generated method stub
    
}

@Override
public void removeBlacklisted(String tmId) throws RpcException {
    // TODO Auto-generated method stub
    
}

@Override
public void setPriorityValue(String jobPrefix, int value) throws RpcException {
    // TODO Auto-generated method stub
    
}
}
