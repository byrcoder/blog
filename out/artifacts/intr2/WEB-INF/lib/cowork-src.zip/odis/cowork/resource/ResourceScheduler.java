/**
 * @(#)ResourceScheduler.java, 2012-12-10. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import odis.cowork.JobConfig;
import toolbox.misc.LogFormatter;

/**
 *
 * @author chenheng
 *
 */
public class ResourceScheduler {

    private static final Logger LOG = LogFormatter.getLogger(ResourceScheduler.class);
    
    public List<Resource> schedule(JobConfig job, Map<String, ClusterNodeInfo> resourceMap, int num) {
        List<Resource> resources = new ArrayList<Resource>();
        int resourceNum = 0;
        for (Entry<String, ClusterNodeInfo> entry : resourceMap.entrySet()) {
            ClusterNodeInfo nodeInfo = entry.getValue();
            int taskHeap = job.getJobDef().getHeapSize(nodeInfo.getTaskHeapLimit());
            if (nodeInfo.getStatus() == ClusterNodeInfo.ABNORMAL 
                    || nodeInfo.getLoadRate() > ClusterNodeInfo.MAX_LOAD_RATE) {
                LOG.info("@@RESOURCE@@ " + nodeInfo + " is abnormal! the load is " + nodeInfo.getOneMinLoad());
                continue;
            }
            int tpm = job.getJobDef().minTaskPerMachine();
            if (tpm > 0) {
                int alreadyRunning = getAlreadyRunning(nodeInfo, job);
                LOG.info("@@RESOURCE@@ jobTpm=" + tpm + ", alreadyRunning=" + alreadyRunning + ", job=" + job.getJobDef().getJobID()
                        + ", tmid=" + entry.getKey());
                for (int i = tpm - alreadyRunning; i > 0 && resourceNum < num; i--) {
                    if (nodeInfo.satisfy(taskHeap, 1)) {
                        ComputeSpecs oneResource = getResourcePerTask(taskHeap, 1);
                        Resource resource = buildResource(entry.getKey(), oneResource, job, nodeInfo.getResourceNum());
                        resources.add(resource);
                        nodeInfo.reserve(resource.resourceID, oneResource);
                        resourceNum++;
                    }
                }
            } else {
                while (nodeInfo.satisfy(taskHeap, 1) && resourceNum < num) {
                    ComputeSpecs oneResource = getResourcePerTask(taskHeap, 1);
                    Resource resource = buildResource(entry.getKey(), oneResource, job, nodeInfo.getResourceNum());
                    resources.add(resource);
                    nodeInfo.reserve(resource.resourceID, oneResource);
                    resourceNum++;
                }
            }

            if (resourceNum == num) {
                break;
            }
        }
        return resources;
    }
    
    private int getAlreadyRunning(ClusterNodeInfo nodeInfo, JobConfig job) {
        String jobID = job.getJobDef().getJobID();
        int num = 0;
        for (Entry<String, ComputeSpecs> entry : nodeInfo.getUsingMap().entrySet()) {
            if (entry.getKey().contains(jobID)) {
                num++;
            }
        }
        for (Entry<String, ComputeSpecs> entry : nodeInfo.getReserveMap().entrySet()) {
            if (entry.getKey().contains(jobID)) {
                num++;
            }
        }
        return num;
    }

    private ComputeSpecs getResourcePerTask(int taskHeap, int cpuNum) {
        ComputeSpecs cs = new ComputeSpecs();
        cs.setCpuNums(cpuNum);
        cs.setMemoryMB(taskHeap);
        cs.setDiskGB(-1);
        cs.setNetworkMBps(-1);
        return cs;
    }

    private String buildResourceID(JobConfig job, String tmid, int resourceNum) {
        StringBuilder sb = new StringBuilder();
        sb.append(tmid).append("_").append(job.getJobDef().getJobID()).append("_").append(resourceNum);
        return sb.toString();
    } 
    
    private Resource buildResource(String tmid, ComputeSpecs oneResource, JobConfig job, int resourceNum) {
        Resource resource = new Resource();
        resource.tmid = tmid;
        resource.resourceID = buildResourceID(job, tmid, resourceNum);
        resource.setResource(oneResource);
        return resource;
    }
    
    public static void main(String[] args) {
        Thread t = new Thread(new Runnable(){

            @Override
            public void run() {
                while(true) {
                    System.out.println("!!");
                }
            }
            
        });
        t.setDaemon(false);
        t.start();
        
        System.out.println("haha");
        //System.exit(1);
    }
}
