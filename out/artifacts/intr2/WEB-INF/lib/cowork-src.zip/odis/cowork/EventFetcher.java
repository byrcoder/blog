package odis.cowork;

import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.ITaskMasterProtocol.TaskCompletionEventsUpdate;
import odis.serialize.IWritable;
import toolbox.misc.LogFormatter;

/**
 * fetch task completion event of pre stage
 * @author tuqc
 *
 * @param <K>
 * @param <V>
 */
public class EventFetcher<K extends IWritable,V extends IWritable> extends Thread{
    private static final long SLEEP_TIME = 1000;
    private static final int MAX_EVENTS_TO_FETCH = 10000;
    private static final int MAX_RETRIES = 10;
    private static final int RETRY_PERIOD = 5000;
    private static final Logger LOG = LogFormatter.getLogger(EventFetcher.class);

    private final String tipId;
    private final ShuffleScheduler<K,V> scheduler;
    private int fromEventId = 0;
    private ExceptionReporter exceptionReporter = null;
    
    private int maxMapRuntime = 0;
    private TaskWorker taskWorker;
    private int totalReceived = 0;
    
    public EventFetcher(TaskWorker worker,
                        ITaskMasterProtocol tm,
                        ShuffleScheduler<K,V> scheduler,
                        ExceptionReporter reporter) {
      setName("EventFetcher for fetching Map Completion Events");
      setDaemon(true);   
      this.taskWorker = worker;
      this.tipId = worker.getTaskInProgressId();
      this.scheduler = scheduler;
      exceptionReporter = reporter;
    }

    @Override
    public void run() {
      int failures = 0;
      LOG.info(tipId + " Thread started: " + getName());
      
      try {
        while (!stop) {
          try {
            int numNewMaps = getMapCompletionEvents();
            failures = 0;
            if (numNewMaps > 0) {
              totalReceived += numNewMaps;
              LOG.info(tipId + ": " + "Got " + numNewMaps + " new map-outputs, total=" + numNewMaps);
            }
            LOG.info("GetMapEventsThread about to sleep for " + SLEEP_TIME);
            Thread.sleep(SLEEP_TIME);
          } catch (IOException ie) {
            LOG.log(Level.WARNING, "Exception in getting events", ie);
            // check to see whether to abort
            if (++failures >= MAX_RETRIES) {
              throw new IOException("too many failures downloading events", ie);
            }
            // sleep for a bit
            Thread.sleep(RETRY_PERIOD);
          }
        }
      } catch (InterruptedException e) {
        return;
      } catch (Throwable t) {
        exceptionReporter.reportException(t);
        return;
      }
    }
    
    volatile boolean stop = false;
    public void shutdown() {
        stop = true;
        this.interrupt();
    }
    
    /** 
     * Queries the {@link TaskTracker} for a set of map-completion events 
     * from a given event ID.
     * @throws IOException
     */  
    private int getMapCompletionEvents() throws IOException {
      
      int numNewMaps = 0;
      
      TaskCompletionEventsUpdate update = taskWorker.requestPreStageTaskUpdate(tipId,
              fromEventId, 100); 
//          taskMaster.getMapCompletionEvents((org.apache.hadoop.mapred.JobID)
//                                         reduce.getJobID(), 
//                                         fromEventId, 
//                                         MAX_EVENTS_TO_FETCH,
//                                         (org.apache.hadoop.mapred.TaskAttemptID)
//                                           reduce);
      TaskCompletionEvent events[] = update.getMapTaskCompletionEvents();
      if (events.length > 0)
          LOG.info("Got " + events.length + " map completion events from " + fromEventId);
        
      // Check if the reset is required.
      // Since there is no ordering of the task completion events at the 
      // reducer, the only option to sync with the new jobtracker is to reset 
      // the events index
      if (update.shouldReset()) {
        fromEventId = 0;
        scheduler.resetKnownMaps();
      }
      
      // Update the last seen event ID
      fromEventId += events.length;
      
      // Process the TaskCompletionEvents:
      // 1. Save the SUCCEEDED maps in knownOutputs to fetch the outputs.
      // 2. Save the OBSOLETE/FAILED/KILLED maps in obsoleteOutputs to stop 
      //    fetching from those maps.
      // 3. Remove TIPFAILED maps from neededOutputs since we don't need their
      //    outputs at all.
      for (TaskCompletionEvent event : events) {
          
          if (event.isSuccess()) {
              URI u = getBaseURI(event.getHttp());
              scheduler.addKnownMapOutput(event.getFileHost(),
                                          u.toString(),
                                          event.getTaskID());
              numNewMaps ++;
              int duration = event.getTaskRunTime();
              if (duration > maxMapRuntime) {
                maxMapRuntime = duration;
                scheduler.informMaxMapRunTime(maxMapRuntime);
              }              
          }else if(event.isLost()){
              scheduler.tipLost(event.getFileHost(), event.getTaskID());
//              scheduler.tipFailed(event.getTaskId());
              LOG.info("Ignoring output of failed map TIP: '" + 
                      event.getTaskID() + "'");              
          }else {
//              scheduler.obsoleteMapOutput(event.getTaskId());
              LOG.info("Ignoring obsolete output of map-task: " + event.getTaskID());
          }
          
          /*
        switch (event.getTaskStatus()) {
          case SUCCEEDED:
            URI u = getBaseURI(event.getTaskTrackerHttp());
            scheduler.addKnownMapOutput(u.getHost() + ":" + u.getPort(),
                                        u.toString(),
                                        event.getTaskAttemptId());
            numNewMaps ++;
            int duration = event.getTaskRunTime();
            if (duration > maxMapRuntime) {
              maxMapRuntime = duration;
              scheduler.informMaxMapRunTime(maxMapRuntime);
            }
            break;
          case FAILED:
          case KILLED:
          case OBSOLETE:
            scheduler.obsoleteMapOutput(event.getTaskAttemptId());
            LOG.info("Ignoring obsolete output of " + event.getTaskStatus() + 
                     " map-task: '" + event.getTaskAttemptId() + "'");
            break;
          case TIPFAILED:
            scheduler.tipFailed(event.getTaskAttemptId().getTaskID());
            LOG.info("Ignoring output of failed map TIP: '" +  
                 event.getTaskAttemptId() + "'");
            break;
        }
        */
      }
      return numNewMaps;
    }
    
    private URI getBaseURI(String url) {
      StringBuffer baseUrl = new StringBuffer(url);
      if (!url.endsWith("/")) {
        baseUrl.append("/");
      }
      baseUrl.append("mapout?reduce=");
      baseUrl.append(taskWorker.getTaskDef().getPartIdx());
      baseUrl.append("&map=");
      URI u = URI.create(baseUrl.toString());
      return u;
    }
}
