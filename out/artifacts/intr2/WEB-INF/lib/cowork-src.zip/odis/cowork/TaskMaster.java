/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.channels.FileLock;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import odis.conf.CoworkConfig;
import odis.cowork.IJobMasterProtocol.TaskState;
import odis.cowork.TaskMasterStatus.ResourceStatus;
import odis.cowork.http.HttpServer;
import odis.cowork.resource.ClusterNodeInfo;
import odis.cowork.resource.ComputeSpecs;
import odis.cowork.resource.IResource;
import odis.io.ReadWriteUtils;
import odis.mapred.IndexCache;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.tools.ResourceInfo;
import odis.util.IOUtils;

import org.apache.commons.lang.StringUtils;

import toolbox.misc.FileUtils;
import toolbox.misc.EmptyInstance;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import bsh.Interpreter;

/**
 * The task master 1). hello/heartbeat/goodbye to job master; 2). start
 * TaskThread; 3). serve files to other task master.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 * @author chenheng  refactor and add code about communication with RM
 */
public class TaskMaster implements ITaskMasterProtocol, Runnable {
    protected static final Logger LOG = LogFormatter.getLogger(TaskMaster.class);
    public static final String LOG_DIR = "taskmaster";
    public static final long WAIT_FOR_DONE = CoworkConfig.conf()
            .getLong("cowork.taskmaster.wait.for-done", 2500); // 2.5s
    public static final long WAIT_FOR_KILL = CoworkConfig.conf()
            .getLong("cowork.taskmaster.wait.for-kill", 1500); // 1.5s
    protected static final long WAIT_FOR_CLEANUP = CoworkConfig.conf()
            .getLong("cowork.taskmaster.wait.for-clean",
                    WAIT_FOR_KILL + WAIT_FOR_DONE + UnitUtils.SECOND * 1); // 5s
    protected static final int MAX_RESTART_NUM = CoworkConfig.conf()
            .getInt("cowork.taskmaster.restart.max-num", 10);
    
    protected static final int RESOURCE_DUMP_INTERVAL = CoworkConfig.conf()
            .getInt("cowork.taskmaster.resDump.interval", 6);  //表示几个heatBeat的时间

    protected static final long RESTART_INTERVAL = CoworkConfig
            .conf()
            .getLong("cowork.taskmaster.restart.interval", UnitUtils.SECOND * 6); // 6
                                                                                  // s

    protected static final float REPORT_INTERVAL = 0.05f;
    protected static final long TASK_EXPIRY_LIMIT = CoworkConfig.conf()
            .getLong("cowork.taskmaster.task-expiry-limit", UnitUtils.MINUTE * 10);
    protected static final long LOG_KEEP_TIME = CoworkConfig.conf()
            .getLong("cowork.taskmaster.log.keep-time", UnitUtils.DAY * 10);
    protected static final long LOG_DELETE_INTERVAL = CoworkConfig.conf()
            .getLong("cowork.taskmaster.log.delete-interval", UnitUtils.DAY);
    protected static final long DMESG_CHECK_TIME = CoworkConfig.conf()
            .getLong("cowork.taskmaster.dmesg-check-time",
                    UnitUtils.MINUTE * 10);
    protected static final long RES_CHECK_TIME = CoworkConfig.conf()
            .getLong("cowork.taskmaster.resource-check-time",
                    UnitUtils.MINUTE * 1);
    protected static final int HIGH_IOWAIT_THRESHOLD_RATE = CoworkConfig
            .conf().getInt("cowork.taskmaster.high-iowait-rate", 3);
    final Random RAND = new Random();
    // task master properties
    protected String id; // id name
    protected String hostname; // hostname
    protected String volume; // volume string (handshake with jm)
    protected int taskPort, filePort; // ports for serve tasks and files
    protected AbstractRpcServer taskServer; // server for serving task worker
    protected int taskLimit, fileLimit; // limit server threads
    protected int heapLimit; // limit task worker heap size
    protected boolean isInProcess; // run tasks in task thread
    // task in progress: running and deleting / success and fail
    protected ConcurrentHashMap<String, TaskInProgress> tips;
    protected Lock tipsLock = new ReentrantLock(); //用于同步Task的运行状态
    protected Object stateChange = new Object();
    // non-deleting task in progress
    protected ConcurrentHashMap<String, String> activeTips;
    // resesources used by task master
    protected InetSocketAddress jobmasterAddr;// jobmaster address
    protected IJobMasterProtocol jobmaster; // jobmaster RPC client
    protected InetSocketAddress resManagerAddr;
    IResource resourceClient = null;
    public File[] taskTmpDirs; // temp dir root in local
    protected int[] taskTmpDirsCount; // usage count
    protected File logDir; // log dir at local
    // TODO init it
    public IndexCache indexCache;
    protected HttpServer httpServer;
    // task master running states
    protected volatile boolean isRestart, isRun, isDmesgError;
    // doneKnob: used to do a instant heartbeat after task is done
    protected final byte[] doneKnob = new byte[0];
    ResourceChecker resChecker;
    volatile boolean highIOWait = false;
    Map<String, Semaphore> diskTokens = new HashMap<String, Semaphore>();
    public int taskTotalMemory;
    HeartBeat2RM heartBeatThread;

    private static final String FORMAT = "yyMMdd HHmmss";
    private static final Date date = new Date();
    private static final SimpleDateFormat formatter = new SimpleDateFormat(FORMAT);
    protected final static int EXEC_CONTINUE = 0;
    protected final static int EXEC_UNKNOWN = 1;
    protected final static int EXEC_QUIT_ALL = 2;
    protected final static int EXEC_QUIT_FILE = 3;
    private static String LOCK_FILE_NAME = "tm.lock";
    private static Interpreter interpreter = null;
    private static Options options = new Options();
    
    static {
        options.withOption("l", "log to file");
        options.withOption("t", "concurrent-task",
                "maximum concurrent running tasks").hasDefault();
        options.withOption("f", "concurrent-file",
                "maximum concurrent transferring files").hasDefault();
        options.withOption("i", "instance-name", "set instance name");
        options.withOption("v", "volume-num", "set volume number");
        options.withOption("p", "jobmaster-port", "job master port to connect")
                .hasDefault();
        options.withOption("h", "jobmaster-host", "job master host").hasDefault();
        options.withOption("rp", "resManager-port", "res manager port").hasDefault();
        options.withOption("rh", "resmanager-host", "res manager host").hasDefault();
    }
    
    
    public TaskMaster(InetSocketAddress jmAddr, InetSocketAddress rmAddr, 
            File[] tmpRootDir, File logDir,
            int taskLimit, int fileLimit, int heapLimit, int totalMem, String vol)
            throws IOException {
        this.jobmasterAddr = jmAddr;
        this.resManagerAddr = rmAddr;
        this.taskTmpDirs = tmpRootDir;
        taskTmpDirsCount = new int[taskTmpDirs.length];
        for (int i = 0; i < taskTmpDirs.length; i++)
            taskTmpDirsCount[i] = 0;
        LOG.info("@@TASKMASTER@@" + taskTmpDirsCount.length);
        this.logDir = logDir;
        if (logDir != null && !logDir.exists() && !logDir.mkdirs()) {
            LOG.severe("ERROR: Dir " + logDir + " failed.");
        }
        isRestart = true;
        isDmesgError = false;
        this.taskLimit = taskLimit;
        this.fileLimit = fileLimit;
        this.taskTotalMemory = totalMem;
        for (File dir: tmpRootDir) {
            LOG.info("Init disk concurrent with limit " + this.fileLimit);
            diskTokens.put(IOUtils.getDiskName(dir.getCanonicalPath()),
                    new Semaphore(this.fileLimit, true));
        }
        this.heapLimit = heapLimit;
        this.volume = vol;
        this.isInProcess = false;
        indexCache = new IndexCache(CoworkConfig.conf().getInt(
                "cowork.taskmaster.max-index-cache", 32 * 1024 * 1024));
        this.hostname = InetAddress.getLocalHost().getHostName();
    }

    /**
     * Just for local cowork, only start http
     * 
     * @param tmpRootDir
     * @param logDir
     * @throws IOException
     */
    @Deprecated
    public TaskMaster(File[] tmpRootDir, File logDir) throws IOException {
        this.taskTmpDirs = tmpRootDir;
        this.logDir = logDir;
        if (logDir != null && !logDir.exists() && !logDir.mkdirs()) {
            LOG.severe("ERROR: Dir " + logDir + " failed.");
        }
        indexCache = new IndexCache(CoworkConfig.conf().getInt(
                "cowork.taskmaster.max-index-cache", 32 * 1024 * 1024));
        this.hostname = "127.0.0.1";
        initTestCaseHttp(RAND.nextInt(10240) + 1024);
    }


    /**
     * Main loop of task master. Communication types in task master: 1.
     * JobMaster <--> TaskMaster 2. TaskMaster <--> TaskWorker Possible
     * exceptional situations 1. JobMaster exception: temporarily loses
     * heartbeats; down. 2. TaskMaster itself runs into problem For both
     * situations above, run() will jump out of the exec() loop, clean up the
     * left over files and states, and then reinitialize after 6s. If If this is
     * a persistant error like JobMaster is consitantly not avaiable for more
     * than 10 retries, the run() loop will end.
     */
    public void run() {
        int tried = 0;
        // start dmesg checker: check error in dmesg every 10 minutes
        DmesgChecker dmesgChecker = new DmesgChecker(this);
        dmesgChecker.start();

        resChecker = new ResourceChecker();
        resChecker.setTaskTmpDirs(taskTmpDirs);
        resChecker.start();

        
        // loop: start real service

        while (isRestart) {
            LOG.info("Starting a new task master service ...");
            try {
                // offer service
                service(JobMaster.HEARTBEAT_INTERVAL);
                tried = 0;

            } catch (Exception e) {
                LOG.log(Level.WARNING, "TaskMaster.run() failed: ", e);
                if (tried++ <= MAX_RESTART_NUM) {
                    try {
                        Thread.sleep(RESTART_INTERVAL);
                    } catch (InterruptedException ie) {}
                    continue;
                } else
                    break;
            } finally {
                if (!isInProcess)
                    LogFormatter.setPrefix("");

                // don't start right now, wait for a while, other program will
                // start it
                isRestart = false;
            }
        }
        LOG.info("Task master is halt");
    }
    /**
     * The whole life of a task master service. About record LHB (last heart
     * beat) location: |--- iteration 1 --|--- iteration 2 --| hello wait1 run1
     * wait2 run2 |+++++x-----------|++++++x-----------|++++++x ... ^ ^ ^ LHB
     * LHB LHB We record each time at "|" as LHB, use the time at "x" to compare
     * with it, and wait the leftover time in HEARTBEAT_INTERVAL. Suppose the
     * "run" time will not exceed HEARTBEAT_INTERVAL, the next heartbeat would
     * start after HEARTBEAT_INTERVAL time. Previous nutch code record LHB as
     * following |-- iteration 1 ---| it 2 |--- iteration 3 --| hello
     * |+++++|-----------x++++++|++++++|-----------x++++++| ^ ^ ^ ^ ^ This looks
     * not reasonable and weird. This service() always heartbeat at the same
     * rate: once per 3s.
     */
    protected void service(long heartbeatInterval) throws IOException {
        // get task master instance name
        Random r = new Random();
        taskPort = 32768 + r.nextInt(32768);
        initialize();

        // new task master id
        id = "tm_" + hostname + "_" + filePort;
        if (!isInProcess)
            LogFormatter.setPrefix(id);

        // initialize a new task master service
        // background elete old logs
        long lastLogDelete = System.currentTimeMillis();
        if (logDir != null)
            lastLogDelete = bgCleanTaskLog(LOG_KEEP_TIME);

        // hello to job master
        long lastHeartbeat = System.currentTimeMillis();
        if (!jobmaster.hello(id, hostname, volume, taskPort, filePort,
                taskLimit)) {
            LOG.info("Hello rejected, may be collision of task master id");
            return;
        }

        try {
            heartBeatThread = new HeartBeat2RM();
            heartBeatThread.start();
        } catch (UnknownHostException e1) {
            LOG.log(Level.WARNING, "", e1);
            return;
        } catch (RpcException e) {
            LOG.log(Level.SEVERE, "", e);
            return;
        }
        
        // add exit hook: when it is forcefully killed
        ExitHookThread hook = new ExitHookThread(jobmaster, id);
        Runtime.getRuntime().addShutdownHook(hook);

        // service loop
        int execCode = EXEC_CONTINUE;
        try {
            while (isRun) {
                // check last exec() time
                long lastExecT = System.currentTimeMillis() - lastHeartbeat;
                if (lastExecT > JobMaster.RPC_LATE_LIMIT)
                    LOG.warning("Last exec() took long time: " + lastExecT
                            + "ms");

                // wait enough time for the next heartbeat: always heartbeat at
                // the same rate
                synchronized (doneKnob) {
                    if (lastExecT < heartbeatInterval)
                        try {
                            doneKnob.wait(heartbeatInterval - lastExecT);
                        } catch (InterruptedException e) {}
                }

                // execute a heartbeat with job master, record start of this
                // heartbeat
                long now = System.currentTimeMillis();
                long late = now - lastHeartbeat - heartbeatInterval;
                if (late > JobMaster.LATE_WARNING_LIMIT) {
                    LOG.warning("Sending heartbeat late for " + late
                            + " ms, last exec() took " + lastExecT + "ms");
                } // if
                execCode = exec();
                lastHeartbeat = now;
                if (execCode != EXEC_CONTINUE || isDmesgError) {
                    LOG.warning("Break the running loop code=" + execCode
                            + ", dmsgError=" + isDmesgError);
                    break;
                }
                // check progress of all TaskInProgress
                check();
                // delete old log
                if (logDir != null
                        && lastLogDelete + LOG_DELETE_INTERVAL < System
                                .currentTimeMillis())
                    lastLogDelete = bgCleanTaskLog(LOG_KEEP_TIME);
            } // while
        } finally {
            LOG.info("TaskMaster Service is stopped, may will be restart. execCode:"
                            + execCode
                            + ", dmsgError="
                            + isDmesgError
                            + ", isRun=" + isRun);
            
            // goodbye
            switch (execCode) {
                case EXEC_UNKNOWN:
                    jobmaster.goodbye(id,
                            "Quit as unknown taskmaster, may restart");
                    break;
                case EXEC_QUIT_FILE:
                    jobmaster.goodbye(id,
                            "Quit due to file server down, may restart");
                    break;
                case EXEC_QUIT_ALL:
                    jobmaster.goodbye(id,
                            "Quit taskmaster for disk writing problem");
                    isRestart = false;
                    break;
                default:
                    if (isDmesgError) {
                        jobmaster.goodbye(id,
                                "Quit taskmaster for I/O error in dmesg");
                        isRestart = false;
                    } else
                        jobmaster.goodbye(id,
                                        "Quit taskmaster for some exception/error, may restart");
                    break;
            }

            // remove exit hook: already said goodbye
            Runtime.getRuntime().removeShutdownHook(hook);
            cleanup(); // clean up leftover states of this service
        }

    }

    /**
     * Heartbeat current status of all tasks to job master and execute commands
     * returned by the task master. The function should not block at any place
     * 
     * @throws RpcException
     */
    protected int exec() throws RpcException {
        // get task status reports
        ArrayList<TaskReport> status = new ArrayList<TaskReport>();
        
        for (TaskInProgress tip: tips.values()) {
            if (tip.runningThread.isQuitAll)
                return EXEC_QUIT_ALL;
            status.add(tip.copyStatus());
            // sign the task to make sure each task resource usage information
            // is reported only once
            if (tip.status.getInput() != -1)
                tip.status.setIsReported(true);
        }

        // heartbeat RPC
        long before = System.currentTimeMillis();
        TaskCommand[] cmd = jobmaster.heartbeat(id, status
                .toArray(new TaskReport[status.size()]), resChecker
                .getResourceStatus());
        long after = System.currentTimeMillis();
        if (after - before > JobMaster.RPC_LATE_LIMIT)
            LOG.warning("Heartbeat RPC take long time: " + (after - before)
                    + "ms");

        // execute command
        boolean isUnknown = false;
        for (int i = 0; i < cmd.length; i++) {
            JobConfig job = cmd[i].getJobConf();
            TaskDef task = cmd[i].getTaskDef();

            if (task != null)
                task.setResourceNeed(cmd[i].getResNeed());

            TaskCompletionEvent[] newEvents = cmd[i].getPrevTaskEvents();
            switch (cmd[i].getCmdCode()) {
                case IJobMasterProtocol.TASK_CMD_NULL:
                    break;
                case IJobMasterProtocol.TASK_CMD_NEW_TASK:
                    newTask(job, task, newEvents);
                    break;
                case IJobMasterProtocol.TASK_CMD_DEL_TASK:
                    delTask(job, task, newEvents);
                    break;
                case IJobMasterProtocol.TASK_CMD_UPD_TASK:
                    updTask(job, task, newEvents);
                    break;
                case IJobMasterProtocol.TASK_CMD_UNKNOWN_TM:
                    LOG.warning("Job master recognized me as unknown.");
                    isUnknown = true;
                    break;
            }
        }
        // return whether this execution means the break of this task master
        if (isUnknown)
            return EXEC_UNKNOWN;
        // if (!fileServer.isRunning()) return EXEC_QUIT_FILE;
        return EXEC_CONTINUE;
    }

    
    /**
     * Initialize a new task master service - need "synchronized" because this
     * changes the "isRun" to true - need to throw IOException because this must
     * make sure the local dir empty before claiming a success initialization.
     * The IOException will throw to run() loop and result in a restart.
     */
    protected synchronized void initialize() throws IOException {
        // task master states
        for (int i = 0; i < taskTmpDirs.length; i++) {
            ReadWriteUtils.fullyDelete(taskTmpDirs[i]);
            taskTmpDirs[i].mkdirs();
        }
        LOG.info("Use local directory: " + Arrays.toString(taskTmpDirs));
        tips = new ConcurrentHashMap<String, TaskInProgress>();
        activeTips = new ConcurrentHashMap<String, String>();

        // start RPC server for TaskThread/TaskRunner to report result
        while (true) {
            try {
                taskServer = RPC.getServer(ITaskMasterProtocol.class, this,
                        taskPort, taskLimit, taskLimit * 2, 1, 0);
                taskServer.start();
                break;
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Cannot bind to port " + taskPort
                        + ", try another", e);
                taskPort++;
            }
        }
        LOG.info("Started task server at " + hostname + ":" + taskPort);

        initHttp(taskPort + 1);

        // start RPC client for JobMaster to get task, heartbeating, etc.
        jobmaster = RPC.getProxy(IJobMasterProtocol.class, jobmasterAddr);
        LOG.info("Connected job master " + jobmasterAddr);
        resourceClient = RPC.getProxy(IResource.class, resManagerAddr);
        LOG.info("Connected res master " + resManagerAddr);
        isRun = true;
        LOG.info("Task master initialized");
    }

    /**
     * Execute command of TASK_CMD_NEW_TASK
     * 
     * @param job
     *            Job config
     * @param task
     *            Task definition
     * @param lastEvents
     *            Workers of task in the previous stage
     */
    private void newTask(JobConfig job, TaskDef task,
            TaskCompletionEvent[] lastEvents) {
        // check task runnable class okay
        assert (task.runnableClass.equals(job.jobDef.taskClasses[task.stage]));
        LOG.info("Task " + task.getTaskId()
                + " recevied. Last stage machines: "
                + Arrays.toString(lastEvents) + ". Launching ...");
        // check no previous non-deleting task-in-progress
        if (activeTips.get(task.getTaskId()) != null)
            LOG.warning("BUG: already got active instance: "
                    + activeTips.get(task.getTaskId()));
        // create task-in-progress, update tips and active-tips
        LOG.info("@@TASKMASTER@@" + taskTmpDirsCount.length);
        TaskInProgress tip = new TaskInProgress(task, lastEvents, job, this);
        activeTips.put(task.getTaskId(), tip.getId());
        tipsLock.lock();
        tips.put(tip.getId(), tip);
        tip.state = TaskInProgress.STARTING;
        tip.start();
        tipsLock.unlock();
        try {
            LOG.info("useResource id " + task.getResourceID());
            resourceClient.useResource(id, task.getResourceID());
        } catch (RpcException e) {
            LOG.log(Level.WARNING, "", e);
        }
    }

    /**
     * Execute command of TASK_CMD_DEL_TASK
     * 
     * @param job
     *            Job config
     * @param task
     *            Task definition
     * @param newEvents
     *            Workers of task in the previous stage
     */
    private void delTask(JobConfig job, TaskDef task,
            TaskCompletionEvent[] newEvents) {
        LOG.info("Receive command for removing " + task.getTaskId()
                + " from queue");
        // find active task in progress
        String atip = activeTips.remove(task.getTaskId());
        TaskInProgress tip = null;
        tipsLock.lock();
        if (atip != null)
            tip = tips.remove(atip);
        // process deleting
        if (tip != null && tip.task.equals(task)) {
            int taskState = tip.getState();
            assert (TaskState.isAssigned(taskState));
            if (!TaskState.isFinished(taskState))
                tip.interrupt(); // finishTask() was not executed
            else
                tip.close(); // finishTask() was executed
            tip.state = TaskInProgress.CLOSE;
        } else
            LOG.warning("BUG: No active instance of " + task + " (tip=" + tip
                    + ") for deleting.");
        tipsLock.unlock();
        indexCache.removeMap(task.getTaskId());
        try {
            LOG.info("releaseResource id " + task.getResourceID());
            resourceClient.releaseResource(id, task.getResourceID());
        } catch (RpcException e) {
            LOG.log(Level.WARNING, "", e);
        }
    }

    /**
     * Execute command of TASK_CMD_DEL_TASK
     * 
     * @param job
     *            Job config
     * @param task
     *            Task definition
     * @param newEvents
     *            Workers of task in the previous stage
     */
    private void updTask(JobConfig job, TaskDef task,
            TaskCompletionEvent[] newEvents) {
        LOG.info("Receive command for updating " + task.getTaskId()
                + ", events:" + Arrays.toString(newEvents));
        // find active task in progress
        String atip = activeTips.get(task.getTaskId());
        TaskInProgress tip = null;
        if (atip != null)
            tip = tips.get(atip);
        // updating task
        if (tip != null && tip.task.equals(task)) {
            tip.setUpdate(newEvents);
        } else
            LOG.warning("BUG: No active instance of " + task + " (tip=" + tip
                    + ") for updating.");
    }
    
    private static int resDumpLoop = 0;
    
    //check the tasks every heartbeat
    protected void check() {
        if (resDumpLoop % RESOURCE_DUMP_INTERVAL == 1) {
            dumpTaskStatus();
        } 
        resDumpLoop++;
        if (resDumpLoop == Integer.MAX_VALUE) {
            resDumpLoop = 0;
        }
        for (Map.Entry<String, TaskInProgress> entry: tips.entrySet()) {
            TaskInProgress tip = entry.getValue();
            long last = System.currentTimeMillis() - tip.reportTime;
            // abort those task that didn't make progress for a long time
            if (TaskState.isRunning(tip.getState()) && last > TASK_EXPIRY_LIMIT) {
                // do "kill -3 pid"
                tipsLock.lock();
                if (tip.getPID() != null) {
                    String bashCmd = "kill -3 " + tip.getPID();
                    try {
                        Process proc = Runtime.getRuntime().exec(new String[] {
                            "/bin/bash", "-c", bashCmd
                        });
                        int error = proc.waitFor();
                        if (error != 0)
                            LOG.warning("\"" + bashCmd + "\": error=" + error);
                        tip.setJvmDumpTime(System.currentTimeMillis());
                    } catch (Exception e) {
                        LOG.log(Level.SEVERE,
                                "Cannot exec \"" + bashCmd + "\"", e);
                    }
                } else
                    LOG.warning("\"kill -3\": No pid found for " + tip);
                // interrupt the task
                LOG.warning("Interrupting expired task: " + tip.getId());
                tip.interrupt();
                tip.state = TaskInProgress.CLOSE;
                tipsLock.unlock();
                try {
                    LOG.info("releaseResource id " + tip.task.getResourceID());
                    resourceClient.releaseResource(id, tip.task.getResourceID());
                } catch (RpcException e) {
                    LOG.log(Level.WARNING, "", e);
                }
            }
        }
    }
    
    class TaskMasterResourceStatus {
        public static final String SPIT = "  ";
        String tid = EmptyInstance.STRING;
        String pid = EmptyInstance.STRING;
        String cpu = EmptyInstance.STRING;
        String mem = EmptyInstance.STRING;
        String vsz = EmptyInstance.STRING;
        String rss = EmptyInstance.STRING;
        String start = EmptyInstance.STRING;
        String time = EmptyInstance.STRING;
        
        public TaskMasterResourceStatus(String pid, String cpu, String mem,
                String vsz, String rss, String start, String time) {
            this.pid = pid;
            this.cpu = cpu;
            this.mem = mem;
            this.vsz = vsz;
            this.rss = rss;
            this.start = start;
            this.time = time;
        }
        
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(tid).append(SPIT).append(pid).append(SPIT)
            .append(cpu).append(SPIT).append(mem).append(SPIT)
            .append(vsz).append(SPIT).append(rss).append(SPIT)
            .append(start).append(SPIT).append(time);
            return sb.toString();
        }
        
        public JSON toJSON() {
            JSONObject json = new JSONObject();
            json.put("TID", tid);
            json.put("PID", pid);
            json.put("CPU", cpu);
            json.put("MEM", mem);
            json.put("VSZ", vsz);
            json.put("RSS", rss);
            json.put("START", start);
            json.put("TIME", time);
            return json;
        }
    }
    
    
    private void dumpTaskStatus() {
        String bashCmd = "ps ux";
        Map<String, TaskMasterResourceStatus> rsmap = new HashMap<String, TaskMasterResourceStatus>();
        try {
            Process proc = Runtime.getRuntime().exec(new String[]{"/bin/bash", "-c", bashCmd});
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new InputStreamReader(proc
                        .getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] str = line.split("\\s+");
                    if (str.length >= 11) {
                        rsmap.put(str[1], new TaskMasterResourceStatus(str[1], str[2], str[3], str[4], str[5], str[8], str[9]));
                    }
                }
            } finally {
                if (reader != null)
                    reader.close();
            }
            
        } catch (IOException e) {
            LOG.log(Level.WARNING, "", e);
            return;
        }
        
        for(Map.Entry<String, TaskInProgress> entry: tips.entrySet()) {
            TaskInProgress tip = entry.getValue();
            TaskMasterResourceStatus rs = rsmap.get(tip.getPID());
            if (rs != null) {
                rs.tid = tip.getId();
            }
        }
        JSONObject json = new JSONObject();
        json.put("host", hostname);
        json.put("time", System.currentTimeMillis());
        JSONArray array = new JSONArray();
        for (Entry<String, TaskMasterResourceStatus> entry : rsmap.entrySet()) {
            if (!EmptyInstance.STRING.equals(entry.getValue().tid)) {
                array.add(entry.getValue().toJSON());
            }
        }
        json.put("resources:", array);
        LOG.info("@@RESOURCE@@ " + json.toString());
    }

    /**
     * Clean up a task master service after returned from service() 1. Clear up
     * tasks - interrupt all tasks that are still running ( TaskThread=alive ) -
     * clear all tasks returned ( TaskThread=not-alive ) Then, wait 3s for all
     * interruptted tasks to finish. 2. Clear local directory 3. Shutdown task
     * server and file server
     */
    protected void cleanup() {
        // 1. Clean up tasks
        // interrupt task in progress
        Iterator<TaskInProgress> it = tips.values().iterator();
        while (it.hasNext()) {
            TaskInProgress t = it.next();
            if (t.runningThread.isAlive()) {
                t.interrupt();
            } else { // returned success/fail tasks
                it.remove();
                t.close();
            }
        }
        LOG.info("All tasks are interrupted, wait for finishing: " + tips);
        // wait WAIT_FOR_CLEANUP time for interruptted task to return
        long now = System.currentTimeMillis();
        synchronized (tips) {
            while (tips.size() != 0) {
                if (System.currentTimeMillis() - now > WAIT_FOR_CLEANUP) {
                    LOG.warning("Task master is not fully cleaned up.");
                    break;
                } // should be at least the second while
                try {
                    tips.wait(WAIT_FOR_CLEANUP);
                } catch (InterruptedException e) {}
                // clear those interrupted TaskThread
                it = tips.values().iterator();
                while (it.hasNext()) {
                    TaskInProgress t = it.next();
                    if (!t.runningThread.isAlive()) {
                        it.remove();
                        t.close();
                    }
                }
            }
        }
        // 2. Clean up local directory for this task master
        int i = 0;
        try {
            for (i = 0; i < taskTmpDirs.length; i++)
                ReadWriteUtils.fullyDelete(taskTmpDirs[i]);
        } catch (IOException e) {
            LOG.log(Level.WARNING,
                    "Cannot delete local dir: " + taskTmpDirs[i], e);
        }
        //5. shutdown HeartBeatThread to RM
        if (heartBeatThread != null) {
            heartBeatThread.shutdown();
            try {
                heartBeatThread.join(3000);
            } catch (InterruptedException e) {
                LOG.log(Level.WARNING, "", e);
            }
        }
        
        // 3. Shutdown task server (called by my TaskWorker)
        if (taskServer != null) {
            taskServer.stop();
            taskServer = null;
        }
        // 4. Shutdown file server (called by other's TaskWorker)
        if (httpServer != null) {
            try {
                httpServer.stop();
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Stop http server error.", e);
            } finally {
                httpServer = null;
            }
        }

    }

    /** Stop current task master service() and reinitialize one */
    public synchronized void restart() {
        isRun = false;
    }

    /** Stop the whole task master completely and exit */
    public synchronized void stop() {
        isRun = false;
        isRestart = false;
    }
    
    private void initHttp(int expectPort) throws IOException {
        httpServer = new HttpServer("tmweb", hostname, expectPort, true,
                CoworkConfig.conf());
        httpServer.setAttribute("taskMaster", this);
        httpServer.addInternalServlet("mapout", "/mapout",
                MapOutputServlet.class);
        httpServer.start();

        filePort = httpServer.getPort();
        if (filePort <= 0) {
            throw new IOException("HttpServer start failed.");
        }
        LOG.info("Started http server at " + hostname + ":" + filePort);
    }

    private void initTestCaseHttp(int expectPort) throws IOException {
        httpServer = new HttpServer(hostname, expectPort, CoworkConfig
                .conf());
        httpServer.setAttribute("taskMaster", this);
        httpServer.addInternalServlet("mapout", "/mapout",
                MapOutputServlet.class);
        httpServer.start();
        filePort = httpServer.getPort();
        if (filePort <= 0) {
            throw new IOException("HttpServer start failed.");
        }
        LOG.info("Started http server at " + hostname + ":" + filePort);
    }
    
    // ////////////////////////////////////////////////////////
    // RPC calls by the child process: TaskWorker
    // ////////////////////////////////////////////////////////

    /** get task master id */
    @Override
    public String getId() {
        return id;
    }

    /** request task definition of taskid */
    @Override
    public TaskDef requestTask(String tipId, String pid) {
        tipsLock.lock();
        try {
            TaskInProgress tip = tips.get(tipId);
            if (tip != null) {
                tip.setPID(pid);
                tip.state = TaskInProgress.RUNNING;
                synchronized(stateChange) {
                    stateChange.notify(); //当有task变为running， 立马发送心跳
                }
                return tip.task;
            } else
                return null;
        } finally {
            tipsLock.unlock();
        }
    }

    @Override
    public TaskInfoUpdate pingTask(String tipId, float progress, CounterMap c,
            boolean isCheck, int[] resultPartCount) {
        TaskInProgress tip = tips.get(tipId);
        if (tip == null)
            throw new RuntimeException("No active instance of " + tipId
                    + ", force child to exit.");
        else {
            float prev = tip.status.getProgress();
            tip.progress(progress, c, isCheck, resultPartCount);
            if (progress - prev >= REPORT_INTERVAL)
                LOG.info("Task(" + tipId + ") - " + Math.round(progress * 1000)
                        / 1000.0);
        }
        boolean flag = tip.update;
        if (tip.update) {
            tip.clearUpdate();
        }

        TaskInfoUpdate info = new TaskInfoUpdate(flag, tip.getState());
        return info;
    }

    @Override
    public TaskCompletionEventsUpdate requestPreStageTaskUpdate(String tipId,
            int from, int max) throws RpcException {
        TaskInProgress tip = tips.get(tipId);
        if (tip == null) {
            LOG.warning("BUG: get null TaskInProgress:" + tipId);
            return null;
        }
        return new TaskCompletionEventsUpdate(tip.getTaskEvents(from, max),
                false);
    }

    /** task is done (successfully or fatally) */
    @Override
    public void doneTask(String tipId, int doneCode, String msg) {
        TaskInProgress tip = tips.get(tipId);
        if (tip == null)
            throw new RuntimeException("No active instance of " + tipId
                    + ", force child to exit.");
        else
            tip.done(doneCode, msg);
    }

    @Override
    public long getUpdateInterval() {
        return JobMaster.HEARTBEAT_INTERVAL;
    }
    
    @Override
    public CounterMap[] getGlobalCounters(String jobId) {
        try {
            return jobmaster.getJobCounters(jobId);
        } catch (RpcException e) {
            LOG.warning("GetGlobalCounter from jobmaster error." + e);
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public String[] getTmpDirs() {
        String[] dirPaths = new String[taskTmpDirs.length];
        for (int i = 0; i < taskTmpDirs.length; ++i) {
            dirPaths[i] = taskTmpDirs[i].getAbsolutePath();
        }
        return dirPaths;
    }

    @Override
    public void statTask(String taskId) {
        TaskInProgress tip = null;
        for (TaskInProgress t: tips.values())
            if (t.getId().startsWith(taskId)) {
                tip = t;
                break;
            }
        if (tip == null) {
            LOG.info("Cannot find task-in-progress for " + taskId);
        } else if (tip.getPID() != null) {
            tipsLock.lock();
            String bashCmd = "kill -3 " + tip.getPID();
            try {
                Process proc = Runtime.getRuntime().exec(new String[] {
                    "/bin/bash", "-c", bashCmd
                });
                int error = proc.waitFor();
                if (error != 0)
                    LOG.warning("\"" + bashCmd + "\": error=" + error);
                tip.setJvmDumpTime(System.currentTimeMillis());
                tip.state = TaskInProgress.CLOSE;
            } catch (Exception e) {
                LOG.log(Level.SEVERE, "Cannot exec \"" + bashCmd + "\"", e);
            } finally {
                tipsLock.unlock();
            }
        } else
            LOG.warning("\"kill -3\": No pid found for " + tip);
    }
    
    @Override
    public int getTaskStatus(String tipId) {
        TaskInProgress tip = tips.get(tipId);
        if (tip == null)
            throw new RuntimeException("No active instance of " + tipId
                    + ", force child to exit.");
        return tip.getTaskStatus();
    }

    public void taskOutputLost(String taskId, String msg) {
        LOG.info("@@TASK_MASTER@@ tid=" + taskId + ", " + msg);
    }
    

    protected Semaphore getDiskToken(String filename) {
        return diskTokens.get(IOUtils.getDiskName(filename));
    }

    protected boolean isHighIOWait() {
        return highIOWait;
    }
    

    public void setInProcess(boolean b) {
        this.isInProcess = b;
    }

    public String getHostname() {
        return hostname;
    }

    public int getFilePort() {
        return filePort;
    }

    public String getHttpBase() {
        return "http://" + hostname + ":" + filePort + "/";
    }

    public IndexCache getIndexCache() {
        return indexCache;
    }

    protected ResourceStatus getResourceStatus() {
        return resChecker.getResourceStatus();
    }

    
    private long bgCleanTaskLog(final long limit) {
        assert logDir != null;
        final long current = System.currentTimeMillis();
        LOG.info("Background cleaning log at: " + current);
        Thread cleanThread = new Thread() {
            public void run() {
                try {
                    while (true) {
                        for (File file: logDir.listFiles()) {
                            if (file.isDirectory()) {
                                for (File subFile: file.listFiles()) {
                                    long last = subFile.lastModified();
                                    if (last + limit < current) {
                                        subFile.delete();
                                        date.setTime(last);
                                        LOG.info("Delete " + subFile
                                                + " (last-modified="
                                                + formatter.format(date) + ")");
                                    }
                                }
                            } else {
                                LOG.info("Delete " + file + " (last-modified="
                                        + formatter.format(date) + ")");
                                file.delete();
                            }
                        }
                        Thread.sleep(UnitUtils.MINUTE * 15);
                    }
                } catch (InterruptedException e) {}
            }
        };
        cleanThread.setDaemon(true);
        cleanThread.start();
        return current;
    }
    
    private static class DmesgChecker extends Thread {

        private TaskMaster taskmaster;

        public DmesgChecker(TaskMaster taskmaster) {
            super();
            this.taskmaster = taskmaster;
            setDaemon(true);
            setName("Cowork TaskMaster Dmesg Checker");
        }

        public void checkIO() throws IOException {
            // if dmesg is not marked as error, check ...
            if (!taskmaster.isDmesgError) {
                Process process = Runtime.getRuntime().exec("dmesg");
                BufferedReader reader = null;
                try {
                    reader = new BufferedReader(new InputStreamReader(process
                            .getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        //dm-0是odfs测试时mount的一个虚拟坏盘， 忽略掉
                        if (line.contains("dm-0")) {
                            continue;
                        }
                        if (line.contains("I/O error")
                                || line.contains("translated ATA stat/err")
                                || line.contains("error=0x01 { AddrMarkNotFound }")) {
                            LOG.severe("Found disc io error in dmesg: " + line);
                            LOG.severe("Mark dmesg error, task master will exit soon.");
                            taskmaster.isDmesgError = true;
                        }
                    }
                } finally {
                    if (reader != null)
                        reader.close();
                }
            } // already marked? just do nothing

            // 判断offlinedisk文件是否有下线磁盘
            if (!taskmaster.isDmesgError) {
                File offlineFile = new File(CoworkConfig.conf().getString(
                        "datanode.offlinedisks_file", "/var/odis/offlinedisks"));
                if (offlineFile.exists()) {
                    BufferedReader reader = null;
                    try {
                        reader = new BufferedReader(new FileReader(offlineFile));
                        String line = reader.readLine();
                        while (line != null) {
                            line = line.trim();
                            if (!line.isEmpty()) {
                                LOG.severe("exists a disk offline!");
                                LOG.severe("Mark dmesg error, task master will exit soon.");
                                taskmaster.isDmesgError = true;
                                break;
                            }
                            line = reader.readLine();
                        }
                    } finally {
                        if (reader != null)
                            reader.close();
                    }
                }
            } // end check
        }

        public void run() {
            while (true) {
                try {
                    checkIO();
                    sleep(TaskMaster.DMESG_CHECK_TIME); // check every 10 mins
                } catch (IOException e) {
                    LOG.log(Level.WARNING,
                            "Caught IOException when check disc error.", e);
                } catch (InterruptedException e) {}
            }
        }
    }

    class ExitHookThread extends Thread {
        private IJobMasterProtocol jobmaster;
        private String tmId;

        public ExitHookThread(IJobMasterProtocol jobmaster, String tmId) {
            super();
            this.jobmaster = jobmaster;
            this.tmId = tmId;
        }

        public void run() {
            try {
                jobmaster.goodbye(tmId, "Quit taskmaster from exit hook.");
                TaskMaster.this.resourceClient.goodbye(TaskMaster.this.hostname, "");
            } catch (RpcException e) {
                LOG.log(Level.WARNING, "RPC error when aborting job: " + tmId,
                        e);
            }
        }
    }

    class HeartBeat2RM extends Thread {
        
        private static final int HEART_BEAT_INTERVAL = 15 * 1000; //15s
        private ClusterNodeInfo nodeInfo = null;
        private final Pattern memPattern = Pattern.compile("VmRSS: (\\d+)kB");
        private volatile boolean isRunning = true;
        
        public HeartBeat2RM() throws UnknownHostException, RpcException {
            super();
            setDaemon(true);
            setName("Heart beat to Resource Manager");
            initClusterNodeInfo();
           
        }

        private void initClusterNodeInfo() throws UnknownHostException, RpcException {
            String ip = InetAddress.getLocalHost().getHostAddress();
            ComputeSpecs total = getTotalResource();
            nodeInfo = new ClusterNodeInfo(TaskMaster.this.id, new InetSocketAddress(ip, TaskMaster.this.taskPort), total, TaskMaster.this.heapLimit);
            LOG.info("@@RESOURCE@@ " + nodeInfo);
            TaskMaster.this.resourceClient.hello(nodeInfo, TaskMaster.this.volume);   
           
        }

        public void run() {
            long now = System.currentTimeMillis();
            long lastHeartBeat = now;

            while(isRunning) {
                now = System.currentTimeMillis();
                long lastExecT = now - lastHeartBeat;
                if (lastExecT > HEART_BEAT_INTERVAL) {
                    LOG.info("rm heart beat late :" + (lastExecT - HEART_BEAT_INTERVAL)
                            + ", it took " + lastExecT + " ms!");
                }
                //Make the heart beat as the same rate
                synchronized(stateChange) {
                    if (lastExecT < HEART_BEAT_INTERVAL) {
                        try {
                            stateChange.wait(HEART_BEAT_INTERVAL - lastExecT);
                        } catch (InterruptedException e) {
                            continue;
                        }
                    }
                }

                tipsLock.lock();
                boolean flag = shouldHeartBeat();
                ComputeSpecs currComputeSpecs = null;
                if (flag) {
                    currComputeSpecs = getCurrentResource();
                }
                tipsLock.unlock();
                if (flag && currComputeSpecs != null) {
                    nodeInfo.setRemaining(currComputeSpecs);
                    nodeInfo.setOneMinLoad(TaskMaster.this.resChecker.getResourceStatus().getOneMinLoad());
                    nodeInfo.setSwapUsed(TaskMaster.this.resChecker.getResourceStatus().getSwapUsed());
                    try {
                        LOG.info("heart beart to rm, nodeInfo remaining is " + nodeInfo.getRemaining());
                        TaskMaster.this.resourceClient.heartBeat(nodeInfo, TaskMaster.this.volume);
                        lastHeartBeat = System.currentTimeMillis();
                    } catch (RpcException e) {
                        continue;
                    }
                }
            }
            LOG.info("HeartBeat to rm stop");
            try {
                TaskMaster.this.resourceClient.goodbye(TaskMaster.this.id, "the taskmaster top!");
            } catch (RpcException e) {
                LOG.log(Level.WARNING, "", e);
            }
        }

        private boolean shouldHeartBeat() {
            for (Entry<String, TaskInProgress> entry : TaskMaster.this.tips.entrySet()) {
                TaskInProgress tip = entry.getValue();
                if (tip.state == TaskInProgress.STARTING) {
                    LOG.info("can't heartbeat because of " + tip);
                    return false;
                }
            }
            return true;
        }
        //为了防止有些进程刚刚启动， 资源消耗一直在进行， 需要对现在获得的资源进行修正
        private ComputeSpecs getCurrentResource() {
            int memDiff = 0;
            int slotUsed = 0;
            for (Entry<String, TaskInProgress> entry : TaskMaster.this.tips.entrySet()) {
                TaskInProgress tip = entry.getValue();
                if (tip.state == TaskInProgress.RUNNING) {
                    slotUsed++;
                    String pid = tip.getPID();
                    if (!StringUtils.isEmpty(pid)) {
                        String fileName = "/proc/" + pid + "/status";
                        try {
                            BufferedReader reader = FileUtils.createReader(fileName);
                            if (reader != null) {
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    Matcher m = memPattern.matcher(line);
                                    if (m.find()) {
                                        String memSize = m.group(1);
                                        if (!StringUtils.isEmpty(memSize)) {
                                            try {
                                                int size = Integer.valueOf(memSize) / 1024; //MB
                                                int taskHeap = tip.getJobConf().jobDef.getHeapSize(TaskMaster.this.heapLimit);
                                                if (taskHeap > size) {
                                                    memDiff += (taskHeap - size);
                                                }
                                            } catch(NumberFormatException e) {
                                                
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (IOException e) {
                            LOG.log(Level.WARNING, "", e);
                        }
                    }
                }
            }
            int currentMem = ResourceInfo.getAvailableMemory();
            ComputeSpecs curr = new ComputeSpecs();
            curr.setCpuNums(TaskMaster.this.taskLimit - slotUsed);
            if (currentMem != -1) {
                currentMem += memDiff;
            }
            curr.setMemoryMB(currentMem);
            return curr;
        }
        
        private ComputeSpecs getTotalResource() {
            int totalMemoryMB = TaskMaster.this.taskTotalMemory;
            ComputeSpecs total = new ComputeSpecs(TaskMaster.this.taskLimit);
            total.setNetworkMBps((short)100);
            total.setMemoryMB(totalMemoryMB);
            total.setDiskGB(-1);
            return total;
        }

        public void shutdown() {
            this.isRunning = false;
        }
    }
    
    private class ResourceChecker extends Thread {
        private ResourceStatus resStatus = new ResourceStatus();

        private File[] taskTmpDirs = new File[0];

        public ResourceChecker() {
            super();
            setDaemon(true);
            setName("TaskMaster resource checker");
            resStatus.setProcessers(ResourceInfo.getAvailableProcessors());
        }

        public void run() {
            while (true) {
                try {
                    resStatus.setSwapUsed(ResourceInfo.getSwapUsed());
                    resStatus.setAvailableMemory(ResourceInfo
                            .getAvailableMemory());
                    for (int i = 0; i < taskTmpDirs.length; ++i)
                        resStatus.setAvailableSpace(i, taskTmpDirs[i]
                                .getFreeSpace());

                    if (ResourceInfo.getSystemLoadAverage() > ResourceInfo
                            .getAvailableProcessors()
                            * HIGH_IOWAIT_THRESHOLD_RATE) {
                            LOG.warning("TaskMaster enter high iowait status. load="
                                        + ResourceInfo.getSystemLoadAverage());
                        TaskMaster.this.highIOWait = true;
                    } else if (TaskMaster.this.highIOWait == true) {
                        LOG.warning("TaskMaster leave high iowait status. load="
                                        + ResourceInfo.getSystemLoadAverage());
                        TaskMaster.this.highIOWait = false;
                    }

                    sleep(RES_CHECK_TIME);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "resource checker error.", e);
                }
                LOG.info("System resource: " + resStatus);
            }
        }


        public ResourceStatus getResourceStatus() {
            resStatus.setOneMinLoad(ResourceInfo.getSystemLoadAverage());
            return resStatus;
        }

        public void setTaskTmpDirs(File[] taskTmpDirs) {
            this.taskTmpDirs = taskTmpDirs;
            resStatus.setAvailableSpace(new long[taskTmpDirs.length]);
        }

    }

    private static void usage() {
        options.printHelpInfo(System.out, "taskmaster");
    }

    private static int startBeanshell(TaskMaster tm) {
        // start bean shell
        interpreter = new Interpreter();
        int port = CoworkConfig.conf().getInt("cowork.jobmaster.web-port",
                7777) - 10;
        try {
            interpreter.set("taskmaster", tm);
            interpreter.set("portnum", port);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            LOG.info("Start bean shell at port=" + port);
            return port;
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Failed start bean shell at port" + port, e);
        }
        return -1;
    }

    public static void main(String[] args) throws IOException {
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            System.out.println("param error:" + e.getMessage());
            usage();
        }

        String instance = options.getStringOpt("i");
        String vol = options.getStringOpt("v");
        int taskLimit = options.getIntOpt("t", CoworkConfig.get()
                .getTaskMasterTaskLimit(instance));
        int fileLimit = options.getIntOpt("f", CoworkConfig.get()
                .getTaskMasterFileLimit(instance));
        int port = options.getIntOpt("p", CoworkConfig.get()
                .getJobMasterPort());
        boolean isLogToFile = options.isOptSet("l");
        String host = options.getStringOpt("h");        
        String jmAddr = host + ":" + port;
        
        int rPort = options.getIntOpt("rp", CoworkConfig.get().getRMPort());
        String rHost = options.getStringOpt("rh", CoworkConfig.get().getRMHost());
        
        
        // logger
        if (isLogToFile) { // log to file
            File logDir = new File(CoworkConfig.get().getCoworkLogDir(),
                    LOG_DIR);
            if (!logDir.exists())
                logDir.mkdirs();
            String hostname = InetAddress.getLocalHost().getHostName();
            LogFormatter.clearLoggerHandlers("");
            LogFormatter.setRotateFileLogger("", logDir.getPath(), "tm-"
                    + hostname + ".log",
                    CoworkConfig.conf().getInt(
                            "cowork.taskmaster.log.file-limit", 100000000), // 100
                                                                            // M
                    CoworkConfig.conf().getInt(
                            "cowork.taskmaster.log.file-count", 100),
                    CoworkConfig.conf().getBoolean(
                            "cowork.taskmaster.log.is-append", true));
        }

        // prepare local tmp directory
        File[] tmpDirs = null;
        String[] tmpDirStr = CoworkConfig.get().getTaskMasterTmpDir(
                instance);
        tmpDirs = new File[tmpDirStr.length];
        for (int j = 0; j < tmpDirs.length; j++) {
            tmpDirs[j] = new File(tmpDirStr[j]);
            ReadWriteUtils.fullyDelete(tmpDirs[j]);
            if (!tmpDirs[j].mkdirs()) {
                LOG.log(Level.SEVERE, "!!Error: tmpDirs " + tmpDirs[j]
                        + " make failed!");
            } else {
                LOG.info(tmpDirs[j] + " make success!");
            }
        } // for j
        ///LogFormatter.setLogLevel(CoworkConfig.get().getServiceLogLevel(),
        // Level.INFO);

        // starting
        File taskLogDir = null;
        if (isLogToFile)
            taskLogDir = new File(CoworkConfig.get().getCoworkLogDir(),
                    TaskWorker.LOG_DIR);
        System.out.println("Starting TaskMaster of instance " + instance
                + "(t=" + taskLimit + ",f=" + fileLimit + ")");
        TaskMaster tm = new TaskMaster(CoworkConfig.getAddress(jmAddr),
                new InetSocketAddress(rHost, rPort),
                tmpDirs, taskLogDir, taskLimit, fileLimit, CoworkConfig
                        .get().getTaskHeapLimit(instance), 
                        CoworkConfig.get().getTaskMasterMemory(instance),
                        vol);
        System.out.println("TaskMaster was initialized.");

        int beanShellPort = startBeanshell(tm);

        TaskMasterServlet.setTaskMaster(tm);
        FileOutputStream lockFileOS = null;
        FileLock lock = null;
        try {
            // get the lock
            lockFileOS = new FileOutputStream(new File(CoworkConfig.get()
                    .getCoworkLogDir(), LOCK_FILE_NAME));
            lock = lockFileOS.getChannel().tryLock();
            if (lock == null) {
                LOG.info("Get taskmaster lock failed, exit...");
                System.exit(1);
            }
            tm.run();
            System.out.println("TaskMaster was returned.");
        } finally {
            if (lock != null)
                lock.release();
            if (lockFileOS != null)
                lockFileOS.close();
        }
        System.exit(0);
    }

    public boolean isRunning() {
        return this.isRun;
    }

    //以下两个接口只是为了与旧的客户端的rpc协议兼容
    @Override
    public void updateTaskCompletionPath(String tipId, String[] paths)
            throws RpcException {
        // TODO Auto-generated method stub
        
    }

    
}
