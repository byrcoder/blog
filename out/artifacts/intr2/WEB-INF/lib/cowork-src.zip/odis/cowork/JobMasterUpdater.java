package odis.cowork;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.cowork.analyzer.AnalyzerTool;
import odis.cowork.analyzer.CoWorkAnalyzer;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import toolbox.misc.LogFormatter;
import toolbox.web.WebServer;

/**
 * Server that periodically update job master status
 * 
 * @author Li Zhuang (zl@cs.berkeley.edu, zl@rd.netease.com) Created on Oct 13,
 *         2006 Copyright (c) 2006 Outfox Team
 */
public class JobMasterUpdater extends Thread implements ICoWorkShellProtocol {
    public static final String ANALYZER_EMAIL_SEND_TIME = CoworkConfig
            .conf().getString("cowork.jobmaster.analyzer.daily-email-time",
                    "11");

    private static Logger LOG = LogFormatter.getLogger(JobMasterUpdater.class);

    private long peroid;

    protected JobMaster jm;

    private int port, webPort;

    // last update time
    protected Date lastUpdateTime = new Date();

    protected long statFreq = 0;

    // status to be displayed in jobmaster
    protected LinkedHashMap<String, JobInProgress> jobQueue;

    protected LinkedHashMap<String, TaskMasterStatus> taskmasterPool;

    // RPC & web server goes here
    private AbstractRpcServer server;

    private WebServer web;

    public JobMasterUpdater() {}
    
    public JobMasterUpdater(JobMaster jm, int port, long peroid,
            int webPort) throws Throwable {
        this.setDaemon(true);
        this.jm = jm;
        this.peroid = peroid;
        this.port = port;
        this.webPort = webPort;
        this.jobQueue = new LinkedHashMap<String, JobInProgress>();
        this.taskmasterPool = new LinkedHashMap<String, TaskMasterStatus>();
        server = RPC.getServer(
                ICoWorkShellProtocol.class,
                this,
                this.port,
                CoworkConfig.conf().getInt("cowork.jobmaster.rpc-conn-num",
                        10),
                CoworkConfig.conf().getInt(
                        "cowork.jobmaster.rpc-queue-size", 10000), 1, 0);
        server.start();
        web = new WebServer(webPort);
        File tmpDir = new File(CoworkConfig.get().getOdisTmpDir(),
                "Jetty_Monitor");
        tmpDir.delete();
        tmpDir.mkdirs();
        web.addAppContext(CoworkConfig.getWebDir().getPath(), "/monitor",
                tmpDir);
        tmpDir = new File(CoworkConfig.get().getOdisTmpDir(), "Jetty_Log");
        tmpDir.delete();
        tmpDir.mkdirs();
        web.addAppContext(new File(CoworkConfig.get().getCoworkLogDir(),
                JobMaster.JOB_DIR).getPath(), "/log", tmpDir);
        tmpDir = new File(CoworkConfig.get().getOdisTmpDir(),
                "Jetty_Archive");
        tmpDir.delete();
        tmpDir.mkdirs();
        web.addAppContext(new File(CoworkConfig.get().getCoworkLogDir(),
                JobMaster.JOB_ARCHIVE_DIR).getPath(), "/archive",
                tmpDir);
        web.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                LinkedHashMap<String, JobInProgress> newJQ = new LinkedHashMap<String, JobInProgress>();
                LinkedHashMap<String, TaskMasterStatus> newTP = new LinkedHashMap<String, TaskMasterStatus>();
                jm.snapshot(newJQ, newTP);
                // make a switch
                if (jobQueue.size() != newJQ.size()
                        && LOG.isLoggable(Level.FINE))
                    LOG.fine("Job queue was updated: " + newJQ + " | "
                            + jobQueue);
                if (taskmasterPool.size() != newTP.size()
                        && LOG.isLoggable(Level.FINE))
                    LOG.fine("Taskmaster pool was updated: " + newTP + " | "
                            + taskmasterPool);
                jobQueue = newJQ;
                taskmasterPool = newTP;
                // log status summary
                HashMap<String, AtomicInteger> jobStatusCounts = new HashMap<String, AtomicInteger>();
                int tmVacancy = 0, tmCapacity = 0, workersRequested = 0;
                int tmBusy = 0;
                for (TaskMasterStatus tms: taskmasterPool.values()) {
                    tmVacancy += tms.vacancy();
                    tmCapacity += tms.capacity();
                    if (tms.vacancy() < tms.capacity()) {
                        tmBusy++;
                    }
                }
                for (JobInProgress jip: jobQueue.values()) {
                    workersRequested += jip.deserveWorker();
                    String status = jip.jobStatus.getStateString();
                    AtomicInteger count = jobStatusCounts.get(status);
                    if (count == null) {
                        count = new AtomicInteger(0);
                        jobStatusCounts.put(status, count);
                    }
                    count.incrementAndGet();
                }

                // do free worker analyzer
                if (statFreq++ % 6 == 0) {
                    CoWorkAnalyzer.getCoWorkAnalyzer().takeFreeWorkerSample(
                            System.currentTimeMillis(), tmVacancy);
                    checkDailyEmail();
                }

                // remove the oldest job every 10 minitue
                if (statFreq % 60 == 0) {
                    CoWorkAnalyzer.getCoWorkAnalyzer().listTodayJobDetail();
                }

                LOG.info("@@ANALYSIS@@ workers.total=" + tmCapacity
                        + " workers.busy=" + (tmCapacity - tmVacancy)
                        + " workers.requested=" + workersRequested);
                LOG.info("@@ANALYSIS@@ machines.total=" + taskmasterPool.size()
                        + " machines.busy=" + tmBusy);
                StringBuilder buffer = new StringBuilder();
                for (Entry<String, AtomicInteger> entry: jobStatusCounts
                        .entrySet()) {
                    buffer.append(" jobs." + entry.getKey() + "="
                            + entry.getValue());
                }
                LOG.info("@@ANALYSIS@@ jobs.total=" + jobQueue.size()
                        + buffer.toString());
                lastUpdateTime.setTime(System.currentTimeMillis());
                Thread.sleep(peroid);
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "JobMasterUpdater exit for exception", e);
        }
    }

    public String getJobMaster() {
        return jm.hostname + ":" + jm.port;
    }

    public static String getJobListFormat() {
        return String.format("%1$35s %2$8s %3$10s %4$15s", "Job ID", "Dur(H)",
                "W/Mach", "Progress(%)");
        // Job ID Dur(H) W/Mach Progress(%)
        // zl_updatedb_abcde 3.3 100/63 Reduce-64%
        // river_reparse_are34 12.8 60/34 Map-89%
    }

    public static String getJobListString(JobInProgress jip) {
        float d = (System.currentTimeMillis() - jip.startTime) / 3600000f;
        int cw = 0, cm = 0;

        cw = jip.totalRunningSize();
        Map<String, HashSet<TaskDef>> runningTM = jip.runningTaskMasters();
        cm = runningTM.size();

        int s = jip.jobStatus.stage;
        String p = "(Done)";
        if (s < 0)
            p = "(Pre)";
        else if (!jip.jobStatus.isEnd(s))
            p = jip.jobDef.getStageName(s) + "-"
                    + Math.round(jip.jobStatus.getProgress(s) * 100) + "%";
        return String.format("%1$35s %2$8.1f %3$10s %4$15s", jip.jobId, d, cw
                + "/" + cm, p);
    }

    public static String getJobDetailString(JobInProgress jip) {
        StringBuffer sb = new StringBuffer("-== Detail of " + jip.jobId
                + " ==-\n");
        sb.append("Start at: " + new Date(jip.startTime) + "\n");
        sb.append("Stage: " + jip.jobStatus.stage + "/" + jip.taskStatus.length
                + "\n");
        sb.append("Running Task at each stage: \n");
        for (Map.Entry<Integer, LinkedHashSet<TaskDef>> entry: jip.runningTasks
                .entrySet())
            sb.append(jip.jobDef.getStageName(entry.getKey()) + ":"
                    + entry.getValue() + "\n");
        sb.append("Progress at each stage: "
                + Arrays.toString(jip.jobStatus.getProgress()));
        return sb.toString();
    }

    public String getJobDetail(String jobId) {
        JobInProgress jip = jobQueue.get(jobId);
        if (jip == null)
            return "No such job found: " + jobId;
        return getJobDetailString(jip);
    }

    public String[] listJobInfo() {
        String[] list = new String[jobQueue.size() + 1];
        int i = 0;
        list[i++] = getJobListFormat();
        for (Map.Entry<String, JobInProgress> entry: jobQueue.entrySet()) {
            list[i++] = getJobListString(entry.getValue());
        }
        return list;
    }

    public static String getTaskMasterListFormat() {
        return String.format("%1$35s %2$10s %3$10s %4$10s", "Task Master ID",
                "Port", "Capacity", "Vacancy");
        // Task Master ID Port Capacity Vacancy
        // tm_tb001_78f0j 32343 2 1
        // tm_sb002_fda7n 32893 4 4
    }

    public static String getTaskMasterListString(TaskMasterStatus tms) {
        return String.format("%1$35s %2$10s %3$10d %4$10s", tms.getId(), tms
                .fileAddr().split(":")[1], tms.capacity(), tms.vacancy());
    }

    public static String getTaskMasterDetailString(TaskMasterStatus tms) {
        StringBuffer sb = new StringBuffer("-== Detail of " + tms.getId()
                + " ==-\n");
        sb.append("Address: " + tms.fileAddr() + "\n");
        sb.append("Vacancy/Capacity: " + tms.vacancy() + "/" + tms.capacity()
                + "\n");
        // sb.append("Reservation Detail: " + tms.reservation() + "\n");
        sb.append("Running Detail: " + tms.running());
        sb.append("Resource Detail: ").append(tms.getResourceStatus());
        return sb.toString();
    }

    public String getTaskMasterDetail(String tmId) {
        TaskMasterStatus tms = taskmasterPool.get(tmId);
        if (tms == null) {
            return "No such task master found for id " + tmId;
        }
        return getTaskMasterDetailString(tms);
    }

    public String[] listTaskMasterInfo() {
        String[] list = new String[taskmasterPool.size() + 1];
        int i = 0;
        list[i++] = getTaskMasterListFormat();
        for (Map.Entry<String, TaskMasterStatus> entry: taskmasterPool
                .entrySet()) {
            list[i++] = getTaskMasterListString(entry.getValue());
        }
        return list;
    }

    public String getTaskMasterAddr(String tmId) {
        TaskMasterStatus tms = taskmasterPool.get(tmId);
        if (tms == null)
            return null;
        return tms.rpcAddr();
    }

    public static final SimpleDateFormat hourFormatter = new SimpleDateFormat(
            "yyyy/MM/dd HH");

    public String hourTime = "";

    public void checkDailyEmail() {
        try {
            long cur = System.currentTimeMillis();
            String nowHour = hourFormatter.format(cur);
            if (!nowHour.equals(hourTime)
                    && nowHour.endsWith(ANALYZER_EMAIL_SEND_TIME)) {
                LOG.info("Send cowork analyzer report !");
                try {
                    AnalyzerTool.sendDailyReportMail(getJobMaster(),
                            AnalyzerTool.composeDailyReportMail(CoWorkAnalyzer
                                    .getCoWorkAnalyzer()));
                } catch (Exception e) {
                    LOG.warning("Send analyzer report error!" + e.getMessage());
                }
                hourTime = nowHour;
            }
        } catch (Throwable e) {
            LOG.log(Level.WARNING, "send email error.", e);
        }
    }

    public String getReswebAddr() {
        return jm.getResManagerWebAddr();
    }
    
    public String getJMAddr() {
        StringBuilder sb = new StringBuilder();
        sb.append("http://").append(jm.getResAddr().getHostName()).append(":").append(webPort);
        return sb.toString();
    }

}
