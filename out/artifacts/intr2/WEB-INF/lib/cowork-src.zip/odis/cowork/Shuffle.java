package odis.cowork;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicPartitioner;
import odis.mapred.CombineOutputCollector;
import odis.mapred.MRConfig;
import odis.mapred.MapRedUtil;
import odis.mapred.RawKeyValueIterator;
import odis.serialize.IWritable;
import odis.util.LocalDirAllocator;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import toolbox.misc.LogFormatter;

/**
 * 
 * @author tuqc
 *
 * @param <K>
 * @param <V>
 */
public class Shuffle<K extends IWritable, V extends IWritable> implements ExceptionReporter{
    protected static final Logger LOG = LogFormatter.getLogger(Shuffle.class);
    
    private static final int PROGRESS_FREQUENCY = 2000;
    public static final String SHUFFLEED_FILES = "ShuffledFiles";
    public static final String SHUFFLEED_BYTES= "ShuffledBytes";
    public static final String SHUFFLEED_FAILURE= "ShuffleFailure";
    
    public static final String MERGE_IN_RECORD = "MergedInRecord";
    public static final String MERGE_COMBINE_IN_RECORD = "ReduceCombineInRecord";
    public static final String MERGE_OUT_RECORD = "MergedOutRecord";
    TaskWorker worker;
    BasicInOutJobDef job;
    TaskRunnable taskRunnable;
    LocalDirAllocator dirAlloc;
    CompressAlgo algo = null;
    int phase;
    ShuffleScheduler<K,V> scheduler;
    MergeManager<K,V> merger;
    int totalMaps;
    IFileSystem localFs;
    
    private Throwable throwable = null;
    private String throwingThreadName = null;
    
    public Shuffle(JobDef job, TaskWorker worker, CombineOutputCollector<K,V> combineCollector) throws IOException{
        this.worker = worker;
        this.job = (BasicInOutJobDef)job;
        this.taskRunnable = worker.getTaskRunnable();
        this.dirAlloc = worker.getLocalDirAllocator();
        this.totalMaps = job.getTaskNumber(taskRunnable.getStageIdx() - 1);
        
        phase = MapRedUtil.getMrMergePhase(taskRunnable.getStageIdx(), this.job);
        if (BasicPartitioner.getCompress(this.job, phase)) {
            algo = BasicPartitioner.getCompressAlgo(this.job, phase);
        }
        
        localFs = FileSystem.getNamed("local");
        scheduler = new ShuffleScheduler<K,V>(job, totalMaps, this,
                taskRunnable.getCounter(SHUFFLEED_FILES), 
                taskRunnable.getCounter(SHUFFLEED_BYTES), 
                taskRunnable.getCounter(SHUFFLEED_FAILURE));
        
        merger = new MergeManager<K, V>(this.job, taskRunnable, localFs, dirAlloc,
                algo, combineCollector, this, 
                taskRunnable.getCounter(MERGE_OUT_RECORD), 
                taskRunnable.getCounter(MERGE_COMBINE_IN_RECORD), 
                taskRunnable.getCounter(MERGE_IN_RECORD)); //counter
    }
    
    @SuppressWarnings("unchecked")
    public RawKeyValueIterator run() throws IOException, InterruptedException {
      // Start the map-completion events fetcher thread
      final EventFetcher<K,V> eventFetcher =           
        new EventFetcher<K,V>(worker, worker.getTaskMaster(), scheduler, this);
      eventFetcher.start();
      
      // Start the map-output fetcher threads
      final int numFetchers = job.getConfig().getInt(MRConfig.SHUFFLE_PARALLEL_COPIES, 2);
      Fetcher<K,V>[] fetchers = new Fetcher[numFetchers];
      for (int i=0; i < numFetchers; ++i) {
        fetchers[i] = new Fetcher<K,V>(job, taskRunnable, scheduler, merger, this);
        fetchers[i].start();
      }
      
      // Wait for shuffle to complete successfully
      while (!scheduler.waitUntilDone(PROGRESS_FREQUENCY)) {
//        reporter.progress();
        
        synchronized (this) {
          if (throwable != null) {
            throw new ShuffleError("error in shuffle in " + throwingThreadName,
                                   throwable);
          }
        }
      }

      // Stop the event-fetcher thread
      eventFetcher.shutdown();
//      eventFetcher.interrupt();
      try {
        eventFetcher.join();
      } catch(Throwable t) {
        LOG.log(Level.SEVERE,"Failed to stop " + eventFetcher.getName(), t);
      }
      
      // Stop the map-output fetcher threads
      for (Fetcher<K,V> fetcher : fetchers) {
        fetcher.shutdown();
      }
      for (Fetcher<K,V> fetcher : fetchers) {
        fetcher.join();
      }
      fetchers = null;
      
      // stop the scheduler
      scheduler.close();

//      copyPhase.complete(); // copy is already complete
//      taskStatus.setPhase(TaskStatus.Phase.SORT);
//      reduceTask.statusUpdate(umbilical);

      // Finish the on-going merges...
      RawKeyValueIterator kvIter = null;
      try {
        kvIter = merger.close();
      } catch (IOException e) {
          LOG.log(Level.SEVERE, "Error while doing final merge ", e);
          throw e;
      } catch (InterruptedException e) {
          throw e;
      }

      // Sanity check
      synchronized (this) {
        if (throwable != null) {
          throw new ShuffleError("error in shuffle in " + throwingThreadName,
                                 throwable);
        }
      }
      
      return kvIter;
    }

    public synchronized void reportException(Throwable t) {
      if (throwable == null) {
        throwable = t;
        throwingThreadName = Thread.currentThread().getName();
        // Notify the scheduler so that the reporting thread finds the 
        // exception immediately.
        synchronized (scheduler) {
          scheduler.notifyAll();
        }
      }
    }
    
    public static class ShuffleError extends IOException {
      private static final long serialVersionUID = 5753909320586607881L;

      ShuffleError(String msg, Throwable t) {
        super(msg, t);
      }
    }

}
