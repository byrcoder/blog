package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 *  Shuffle Header information that is sent by the TaskTracker and 
 *  deciphered by the Fetcher thread of Reduce task
 * 
 * @author tuqc
 *
 */
public class ShuffleHeader implements IWritable{

    public String mapName;
    long uncompressedLength;
    long compressedLength;
    int forReduce;
    
    public ShuffleHeader() { }
    
    public ShuffleHeader(String mapId, long compressedLength,
        long uncompressedLength, int forReduce) {
      this.mapName = mapId;
      this.compressedLength = compressedLength;
      this.uncompressedLength = uncompressedLength;
      this.forReduce = forReduce;
    }
    
    public void readFields(DataInput in) throws IOException {
      mapName = StringWritable.readString(in);
      compressedLength = in.readLong();
      uncompressedLength = in.readLong();
      forReduce = in.readInt();
    }

    public void writeFields(DataOutput out) throws IOException {
      StringWritable.writeString(out, mapName);
      out.writeLong(compressedLength);
      out.writeLong(uncompressedLength);
      out.writeInt(forReduce);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        ShuffleHeader that = (ShuffleHeader)value;
        this.mapName = that.mapName;
        this.compressedLength = that.compressedLength;
        this.uncompressedLength = that.uncompressedLength;
        this.forReduce = that.forReduce;
        return this;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("mapName=").append(mapName)
        .append(",cLength=").append(this.compressedLength)
        .append(",ucLength=").append(this.uncompressedLength)
        .append(",forReduce=").append(this.forReduce);
        return sb.toString();
    }
}
