package odis.cowork;

import static odis.cowork.IJobMasterProtocol.TASK_STATE_FAIL;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_FATAL;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_RUNNING;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_SUCCESS;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.cowork.CounterMap.Counter;
import odis.cowork.IJobSubmissionProtocol.JobStatus;
import odis.cowork.analyzer.CoWorkAnalyzer.JobDetail;
import odis.cowork.analyzer.CoWorkAnalyzer.TaskDetail;
import toolbox.misc.LogFormatter;

public class JobInProgress {    
    private static final Logger LOG = LogFormatter.getLogger(JobInProgress.class);
    // basic information
    final protected String jobId;   // job id
    final public JobDef jobDef;  // job definition
    public JobConfig jobConfig = null;
    // running status
    protected JobStatus jobStatus;  // job status
    protected String jobMsg;        // job message at end 
    protected long startTime;       // start/submission time of this job
    protected long endTime;         // closing or aborting time
    protected long taskTime;        // total time used in each task
    protected long submitTime;      // the time when job submit
    
//    private int eventIdCount = 0;
    TreeMap<Integer, List<TaskCompletionEvent>> stageTaskEvents = new TreeMap<Integer, List<TaskCompletionEvent>>();
    protected TreeMap<Integer, List<TaskDef>> largeReducers = new TreeMap<Integer, List<TaskDef>>(); //这个是做什么用的？
    protected JobPriority priority;    
    JobMaster jobMaster;

    /**
     * Create a new job (and put it in the JobQueue)
     *  - set job and and create time
     *  - set the state as idle (not start() yet)
     * @param conf The JobConf that defines this job 
     */
    public JobInProgress(JobConfig conf, JobMaster jm) {
      jobDef = conf.jobDef;
      jobConfig = conf;
      if (jobDef.getUser()==null)
          throw new RuntimeException("Bug: JobClient forgot to set username");
      startTime = System.currentTimeMillis();
      submitTime = startTime;
      jobId = CoWorkUtils.generateJobID(jobDef.getJobName(), jobDef.getUser());
      jobStatus = new JobStatus(jobId,jobDef.getTotalStage());
      taskTime = 0;      
      jobMaster = jm;
      priority = jm.getPriority(jobId, jobDef.getWorkerNumber(Integer.MAX_VALUE));
    }
    
    /**
     * Shadow copy from another JobInProgress.  Just ensure there will not be
     * ConcurrentModificationException from maps and sets.
     * @param that
     */
    private JobInProgress(String jobId, JobDef job, JobMaster jm) {
      this.jobId = jobId; this.jobDef = job; 
      this.jobMaster = jm;
    }
    
    protected JobInProgress getShadowCopy() {
      // job definition
      JobInProgress jip = new JobInProgress(this.jobId, this.jobDef, jobMaster);
      // job status
      jip.jobStatus = this.jobStatus; jip.jobMsg = this.jobMsg;
      jip.startTime = this.startTime; jip.endTime = this.endTime;
      jip.submitTime = this.submitTime;
      // running task status
//      jip.scheduleStage = this.scheduleStage;
      jip.taskStatus = null;
      if (this.taskStatus!=null) {
          jip.taskStatus = new TaskStatus[this.taskStatus.length][];
          for (int i=0; i<jip.taskStatus.length; i++) {
              jip.taskStatus[i] = new TaskStatus[taskStatus[i].length];
              for (int j=0; j<jip.taskStatus[i].length; j++)
                  jip.taskStatus[i][j] = new TaskStatus(taskStatus[i][j]);
          }
      }
      jip.pendingTasks = null;
      if (this.pendingTasks!=null) {
          jip.pendingTasks = new TreeMap<Integer,PriorityQueue<TaskDef>>();
          for (Map.Entry<Integer, PriorityQueue<TaskDef>> entry:this.pendingTasks.entrySet())
              jip.pendingTasks.put(entry.getKey(), new PriorityQueue<TaskDef>(entry.getValue()));
      }
      jip.runningTasks = null;
      if (this.runningTasks!=null) {
          jip.runningTasks = new TreeMap<Integer,LinkedHashSet<TaskDef>>();
          for (Map.Entry<Integer, LinkedHashSet<TaskDef>> entry:this.runningTasks.entrySet())
              jip.runningTasks.put(entry.getKey(), new LinkedHashSet<TaskDef>(entry.getValue()));
      }
      
      if (this.usedWorkers != null) {
          jip.usedWorkers = new TreeMap<String, HashSet<TaskDef>>();
          for (Map.Entry<String, HashSet<TaskDef>> entry : this.usedWorkers.entrySet())
              jip.usedWorkers.put(entry.getKey(), new LinkedHashSet<TaskDef>(entry.getValue()));
      }      
      jip.priority = this.priority;
      jip.failureReports = new ArrayList<TaskReport>(this.failureReports);
      return jip;
    }
    
    public JobStatus getJobStatus() { return jobStatus; }
    public JobDef getJobDef() { return jobDef; }
        
    public String toString() { return jobId + "("+jobDef.getTypeName()+")"; }
    
    //////////////////////////////////////////////////////////////////////////
    // reserved workers for tasks
    //////////////////////////////////////////////////////////////////////////

    // given the JobDef, do I still need more reservation? do I need to check reservation?
    protected boolean noCheck;
    // workers that ever run tasks
    protected TreeMap<String, HashSet<TaskDef>> usedWorkers;
            
    public int getActualWorkerNum() {
        return totalRunningSize();
    }
    String user =  null;
    String programName = null;
    public String getUserName() {
        if (user == null) user = CoWorkUtils.getJobUser(jobId);
        return user;
    }
    public String getProgramName() {
        if (programName == null) programName = CoWorkUtils.getProgramName(jobId);
        return programName;
    }
    
    //////////////////////////////////////////////////////////////////////////
    // Task scheduling: major instance only
    //////////////////////////////////////////////////////////////////////////
    
    // task definition and the worker machines
//    protected int scheduleStage;    
    // task definition and status
    protected TaskStatus[][] taskStatus; // taskStatus[i][j]: running status    
    // scheduled tasks: stage-idx <--> a set of tasks
    protected TreeMap<Integer, PriorityQueue<TaskDef>> pendingTasks;
    // running tasks: stage-idx <--> a set of tasks
    protected TreeMap<Integer, LinkedHashSet<TaskDef>> runningTasks;    
    
    protected List<TaskReport> failureReports = new ArrayList<TaskReport>();

    public void addFailureReport(TaskReport report) {
        synchronized(failureReports) {
            TaskReport r = new TaskReport();
            r.copyFields(report);
            failureReports.add(r);
            jobMaster.getClusterStatus().reportFailure(report);            
        }
    }
    
    public TaskReport[] getFailureReports() {
        synchronized(failureReports) {
            return failureReports.toArray(new TaskReport[failureReports.size()]);
        }
    }
    
    public int finishedSize(int stage) {
      PriorityQueue<TaskDef> sSet = pendingTasks.get(stage);
      HashSet<TaskDef> rSet = runningTasks.get(stage);
      if (stage>jobStatus.stage && sSet==null && rSet==null)
          return 0; // not yet reach stage yet, even not scheduled
      return taskStatus[stage].length - (sSet==null?0:sSet.size()) 
        - (rSet==null?0:rSet.size());        
    }
    public int runningSize(int stage) {
      HashSet<TaskDef> rSet = runningTasks.get(stage);
      return (rSet==null?0:rSet.size());
    }
    public int pendingSize(int stage) {
        Collection<TaskDef> pset = pendingTasks.get(stage);
        return (pset == null? 0 : pset.size());
    }
    public int totalRunningSize() {
        int total = 0;
        for (HashSet<TaskDef> s : runningTasks.values())
            total += s.size();
        return total;
    }
    public int totalPendingSize() {
        int total = 0;
        int stage = jobStatus.getStage();
        for (int i : pendingTasks.keySet()) {
            if (i <= stage + 1) {
                total += pendingTasks.get(i).size();
            }
        }
        return total;
    }
    
    public int currentStage() {
        return jobStatus.getStage();
    }
    
    public int firstPendingStage() {
        if (pendingTasks.isEmpty()) return -1;
        Integer first = pendingTasks.firstKey();
        return first ==  null ? -1 : first;
    }
    
    public int firstRunningStage() {
        if (runningTasks.isEmpty()) return -1;
        Integer first = runningTasks.firstKey();
        return first ==  null ? -1 : first;
    }
    
    public boolean hasNextStage() { 
        return !jobStatus.isEnd(currentStage() + 1); 
    }
    
    public float getStageProgress() {
        int finished = finishedSize(currentStage());
        return (float)finished/taskStatus[currentStage()].length;        
    }
    
    public boolean needScheduleNextStage() {
        return hasNextStage() && (getStageProgress() >= jobDef.getNextStageStartThreshold());
    }
    
    public void setPriority(JobPriority priority) { 
        this.priority = priority; 
    }
    public JobPriority getPriority() { return priority; }
    
    public int deserveWorker() { return jobDef.getWorkerNumber(Integer.MAX_VALUE); }
        
    public Map<String, HashSet<TaskDef>> runningTaskMasters() {
        Map<String, HashSet<TaskDef>> runningTM = new TreeMap<String, HashSet<TaskDef>>();
        for (LinkedHashSet<TaskDef> tasks : runningTasks.values()) {
            for (TaskDef task : tasks) {
                TaskStatus ts = taskStatus[task.stage][task.getPartIdx()];
                if (ts.worker != null) {
                    HashSet<TaskDef> hs = runningTM.get(ts.worker);
                    if (hs == null) {
                        hs = new LinkedHashSet<TaskDef>();
                        runningTM.put(ts.worker, hs);
                    }
                    hs.add(task);
                }
                if (ts.backupWorkers != null) {
                    for (String worker : ts.backupWorkers) {
                        HashSet<TaskDef> hs = runningTM.get(worker);
                        if (hs == null) {
                            hs = new LinkedHashSet<TaskDef>();
                            runningTM.put(worker, hs);
                        }
                        hs.add(task);
                    }
                }
            }
        }
        return runningTM;
    }
    
    public boolean killTask(String tmId, TaskDef task) {
        LOG.info("Kill " + task + " on " + tmId);
        TaskStatus ts = getTaskStatus(task);
        if (!ts.isRunning()) return false;
        jobMaster.getTaskMaster(tmId).delete(task, true);
        LOG.info("DEBUG: before fix, ts.progress:" + ts.progress + ", jobStatus.progress:" + jobStatus.getProgress(task.stage));
        float delta = ts.progress;
        jobStatus.setProgress(task.stage, 
                jobStatus.getProgress(task.stage) - delta/taskStatus[task.stage].length);  
        LOG.info("DEBUG: after fix, jobStatus.progress:" + jobStatus.getProgress(task.stage));
        
        boolean isLost = ts.lost(tmId);
        if (isLost) {
            finishTask(task);
            queueTask(task);
        }
        return true;
    }
    
    /**
     * check if the job is unfair
     * @author chenqi
     */
    private static final long MAX_WAIT = CoworkConfig.conf().getLong("cowork.master.scheduler.occupy.max-wait",30 * 60 * 1000);
    public boolean isUnfair() {
//        if(!jobMaster.getEnableOccupy())
//            return false;
        
        long duration = System.currentTimeMillis() - startTime;
//        int pendingSize = totalPendingSize();
//        int maxWorker =jobDef.getWorkerNumber(jobMaster.scheduler.getMaxAssignWorker(this));
//        int notSatisfiedSize = maxWorker - getActualWorkerNum();
//        
//        if(notSatisfiedSize <= 0 || pendingSize <= 0)
//            return false;
        
        if(duration < MAX_WAIT)
            return false;
        return true;
    }
    
    /**
     * get the number of workers to occupy
     * @return
     * @author chenqi
     */
//    public int getOccupyNum() {
//        if(pendingTasks == null || runningTasks == null)
//            return 0;
//        
//        int pendingSize = totalPendingSize();
//        int maxWorker =jobDef.getWorkerNumber(jobMaster.scheduler.getMaxAssignWorker(this));
//        int notSatisfiedSize = maxWorker - getActualWorkerNum();
//        
//        if(pendingSize >= 0 && notSatisfiedSize >= 0)
//            return Math.min(pendingSize, notSatisfiedSize);
//        else
//            return 0;
//    }
    
    volatile int inited = -1;
    private void initStage(int stage) {       
        if (jobStatus.isEnd(stage)) return;
        if (stage <= inited) {
            return;
        }
        LOG.info("Init stage " + stage + " of " + jobId);
        PriorityQueue<TaskDef> tset = new PriorityQueue<TaskDef>(
                taskStatus[stage].length,
                new Comparator<TaskDef>() {
                    @Override
                    public int compare(TaskDef o1, TaskDef o2) {
                        return o2.priority - o1.priority;
                    }
                });

        if (stage >= 1) {
            int[] prioritys = new int[taskStatus[stage].length];
            Arrays.fill(prioritys, 0);
            for (int i=0; i<taskStatus[stage-1].length; ++i) {
                int[] partcount = taskStatus[stage-1][i].resultPartCount;
                if (partcount != null ) {
                    assert partcount.length == prioritys.length || partcount.length == 0;
                    for (int k=0; k < partcount.length; ++k) {                        
                        prioritys[k] += (partcount[k]/100); //pretend the value overflow
                    }
                }
            }
            LOG.info("All task priority: " + Arrays.toString(prioritys));
            for (int i=0; i<taskStatus[stage].length; i++) {
                TaskDef t = taskStatus[stage][i].task;
                t.setPriority(prioritys[t.getPartIdx()]);
            }
        }
        for (int i=0; i<taskStatus[stage].length; i++)
            tset.add(taskStatus[stage][i].task);
        
        pendingTasks.put(stage, tset);
        inited = stage;
        
        ArrayList<TaskDef> taskList = new ArrayList<TaskDef>(tset);        
        largeReducers.put(stage, taskList);
    }
           
    /**
     * Queue a task in the scheduled tasks list
     * @param task  the task to be queued
     * @return  whether succeeded
     */
    private boolean queueTask(TaskDef task) {
      PriorityQueue<TaskDef> tset = pendingTasks.get(task.stage);
      if (tset==null) tset = new PriorityQueue<TaskDef>(10,new Comparator<TaskDef>() {
          @Override
          public int compare(TaskDef o1, TaskDef o2) {
              return o2.priority - o1.priority;
          }
      });
      if (tset.contains(task)) return false;
      else tset.add(task);
      pendingTasks.put(task.stage, tset);
      LOG.info(jobId + ": Add " + task + " to queue");
      return true;
    }
    
    /**
     * Put a task in running list
     * @param task  the task to be put in running list
     */
    public void runTask(String tmId, TaskDef task) {
      // put in running tasks set
      LinkedHashSet<TaskDef> tset = runningTasks.get(task.stage);
      if (tset==null) tset = new LinkedHashSet<TaskDef>();
      tset.add(task);
      runningTasks.put(task.stage, tset);
      // set running status
      taskStatus[task.stage][task.part].start(tmId);
    }
    
    /**
     * Remove a task from running list
     * @param task  the task to be removed from running list
     */
    private void finishTask(TaskDef task) {
      HashSet<TaskDef> tset = runningTasks.get(task.stage);
      if (tset == null) {
          LOG.info("BUG: task " + task + " is not in running tasks.");
          return;
      }
      if (!tset.remove(task))
        LOG.warning("BUG: At finishTask " + task.getTaskId() 
          + " is not in runningTasks");
      if (tset.size()==0)
        runningTasks.remove(task.stage);
      
    }
    
    //////////////////////////////////////////////////////////////////////////
    // main methods
    //////////////////////////////////////////////////////////////////////////

    /**
     * Preparing to run a job:
     *  1. Reserved enough task slots? If required task slots is larger than
     *     slots from all machines, set the task slots number as total slots
     *  2. If no in 1, start() failed and return; else, plan tasks at stages
     * @throws IOException 
     */
    public boolean start() throws Throwable {
      LOG.info("--=== Trying to start " + jobId + " ===--");
      noCheck = false;
      
      //workers
      usedWorkers = new TreeMap<String, HashSet<TaskDef>>();

      // prepare stage status
      pendingTasks = new TreeMap<Integer, PriorityQueue<TaskDef>>();
      runningTasks = new TreeMap<Integer, LinkedHashSet<TaskDef>>();

      // create plannedTasks
//      scheduleStage = -1;
      try {
        taskStatus = new TaskStatus[jobDef.getTotalStage()][];
        for (int stage=0; stage<taskStatus.length; stage++) {
          assert jobDef.getTaskNumber(stage)>0||jobDef.getTaskNumber(stage)==-1 
              : "task-num="+jobDef.getTaskNumber(stage);
          TaskDef[] defs = jobDef.getTaskDefs(jobId,stage); // task defs of this stage
          taskStatus[stage] = new TaskStatus[defs.length];
          for (int part=0; part<defs.length; part++)
            taskStatus[stage][part] = new TaskStatus(defs[part], jobMaster);
          
          //init stage event
          stageTaskEvents.put(stage, new ArrayList<TaskCompletionEvent>());
        }
      } catch (Throwable e) { // sepcial handling to clear taskStatus
        taskStatus = null; throw e;
      }

      // init a stage
      initStage(0);
      
      jobStatus.setRun();
      startTime = System.currentTimeMillis();
      
      return true;
    }    
    
    private void addSuccessTaskEvent(TaskReport report, String tmId) {
        String hostname = jobMaster.getTaskMaster(tmId).fileAddr();
        int stage = report.getStageIdx();
        List<TaskCompletionEvent> events = stageTaskEvents.get(stage);
        TaskCompletionEvent event = new TaskCompletionEvent(events.size(),
                report.getTaskDef().getTaskId(), report.getPartIdx(), hostname,
                TaskCompletionEvent.TASK_SUCCESS, (int) report.getProcessTime());
//        ++eventIdCount;
        events.add(event);
    }
    
    private void addLostTaskEvent(TaskDef task, String tmId) {
        String hostname = jobMaster.getTaskMaster(tmId).fileAddr();
        int stage = task.getStageIdx();
        List<TaskCompletionEvent> events = stageTaskEvents.get(stage);
        TaskCompletionEvent event = new TaskCompletionEvent(events.size(),
                task.getTaskId(), task.getPartIdx(), hostname,
                TaskCompletionEvent.TASK_LOST);
        events.add(event);        
    }
    
    /**
     * update task status according to <code>report</code> from task master 
     * <code>tmId</code>.
     */
    public void update(String tmId, TaskReport report) {
      // 1. whether this job is in runnning state?
      if (!jobStatus.isRunning()) {
        assert jobStatus.isFinished() : "job-state="+jobStatus.getState();
        LOG.info("Skipping to update " + jobStatus.getStateString() + " job " + jobId);
        return;
      }
      
      // 2. update state of running job 
      TaskStatus ts = taskStatus[report.getStageIdx()][report.getPartIdx()];
      TaskDef tr = ts.task;
      assert jobId.equals(report.getJobId()) : jobId + "!=" + report.getJobId();
      // remember previous & current progress
      float prevProgress = ts.progress;
      float curProgress = prevProgress;
      
      switch (report.getState()) {

        case TASK_STATE_RUNNING:  // report running from task master: must be 
          // set as running before sent to task master: just set new status.
          assert ts.isRunning() : "task-status="+ts;
          ts.update(tmId, report);
          curProgress = ts.progress;
          //TODO task event
          break;

        case TASK_STATE_SUCCESS:
          // not running, already succeed
          if (ts.isSuccess()){
              //deal with some accident
              if (!jobStatus.isFinished()) {
                  if (jobStatus.isInLastStage() || jobStatus.isEnd(jobStatus.getStage())) {
                      int lastStage = taskStatus.length - 1;
                      initStage(lastStage);
                      if (finishedSize(lastStage)==taskStatus[lastStage].length) {
                          LOG.info("Close in accident situation.");
                          printStatus();
                          close(true);
                      }                      
                  }
              }
              return;
          }
          assert ts.isRunning() : "task-status="+ts;
          // set status as success
          taskTime += report.getProcessTime();
          String[] ws = ts.success(tmId, report.getProcessTime(), report.getProgress(), 
              report.getCounters(), report.getMsg(), report.getResultPartCount());
          curProgress = ts.progress;
          // remove from running set
          finishTask(tr);
          // add tm to usedWorkers
          HashSet<TaskDef> runnedTask = usedWorkers.get(tmId);
          if (runnedTask == null) {
              runnedTask = new LinkedHashSet<TaskDef>();
              usedWorkers.put(tmId, runnedTask);
          }
          runnedTask.add(report.getTaskDef());          
          
          addSuccessTaskEvent(report, tmId);
//          addTaskEvent(report.getTaskDef(), TaskCompletionEvent.TASK_SUCCESS);
          
          // print information
          LOG.info("Task " + tr.getTaskId() + " succeeded from " + tmId);
//          LOG.info("Task " + tr.getTaskId() + " result part count: " + Arrays.toString(report.getResultPartCount()));
          printStatus();
          // finished all tasks in this stage --> move to the next one
          if ( tr.stage==jobStatus.getStage() &&
               finishedSize(tr.stage)==taskStatus[tr.stage].length )
            jobStatus.incStage();
          // close or notice running task in next stage
          if (jobStatus.isEnd(jobStatus.getStage())) { // finished all stages --> close
            if (jobStatus.getFailTimes()==0)
              jobMsg = "Congratulations! Your job " + jobId + " has finished!";
            else
              jobMsg = "Be careful! Your job " + jobId + " finished with " 
                + jobStatus.getFailTimes() + " failures";
            close(true);
          } else {  // notify running tasks in the next stage, including backups
            HashSet<TaskDef> tset=runningTasks.get(tr.stage+1);
            if (tset!=null) {              
              for (TaskDef ntd: tset) {  // get workers running tasks in the next stage
                TaskStatus nts = taskStatus[ntd.stage][ntd.part];
                if (jobMaster.getTaskMaster(nts.worker) != null)
                    jobMaster.getTaskMaster(nts.worker).notice(ntd);
                else {
                    LOG.warning("BUG, " + ntd + " should not in running tasks, use worker:" + nts.worker);
                    System.err.println("BUG, " + ntd + " should not in running tasks, use worker:" + nts.worker);
                }
                for (String w:nts.backupWorkers) {
                    if (jobMaster.getTaskMaster(w) != null)
                        jobMaster.getTaskMaster(w).notice(ntd);
                }
              }
            }           
            // release worker
          }
          break;

        case TASK_STATE_FAIL:
          assert ts.isRunning() : "task-status="+ts;
          addFailureReport(report);
          taskTime += report.getProcessTime();
          // set status as fail: remove from run-set for a real failure (i.e. no backup)
          boolean isFail = ts.fail(tmId, report.getProcessTime(), report.getProgress(), 
                  report.getCounters(), report.getMsg(), report.getCursor());
          // exceeds max number of failure
          if (ts.getRetries()>=jobDef.getMaxFailurePerTask()) isFail = true;
          if (isFail) {
            // set current progress
            curProgress = 0f; jobStatus.fail();
            // remove from running queue
            finishTask(tr);
            // abort or reschedule the task
            LOG.info("Task " + tr.getTaskId() + " failed (retry=" 
                    + ts.getRetries() + ", tm=" + tmId + ")");
            if ( tr.stage+1==jobDef.getTotalStage() && jobDef.isIgnoreLastFailure() ) {
              jobStatus.ignore();  // count ignore times
              // last stage & ignore failures here for some task
              LOG.info("Ignore failure of " + tr + " according to job setting");
              printStatus();
              // finished all tasks in this stage --> move to the next one
              assert tr.stage==jobStatus.getStage();
              if ( finishedSize(tr.stage)==taskStatus[tr.stage].length )
                jobStatus.incStage();
              // close job if already advanced to finish stage
              if (jobStatus.isEnd(jobStatus.stage)) { // finished all stages --> close
                if (jobStatus.getIgnoreTimes()==taskStatus[tr.stage].length) {
                  jobMsg = "Your job " + jobId + " failed since all tasks in last stage failed";
                  close(false);
                } else {
                  jobMsg = "Be careful! Your job " + jobId + " finished with " 
                      + jobStatus.getFailTimes() + " failures, "
                      + jobStatus.getIgnoreTimes() + " ignores";
                  close(true);
                }
              } 
            } else if (ts.getRetries()>=jobDef.getMaxFailurePerTask() ) {
              LOG.info("Skip records: " + ts.skipCursors + ", skip machines: " 
                      + ts.skipMachs);
              // abort the job if failed too many times or skipped all machines
              jobMsg = "Some task (" + tr.getTaskId() + ") failed " 
                  + ts.getRetries() + " times and job will be aborted. "
                  + "Last try at " + tmId + ", please check log on that machine.";
              close(false); // abort all running tasks
            } else {
              LOG.warning("Requeue task " + tr.getTaskId());
              // requeue the task
              queueTask(tr);
              // whether to retreat?
              if (retreatStage())
                LOG.warning("Failure of " + tr.getTaskId() + " introduces a retreat.");
              // print information            
              printStatus();            
            }
          } else {  // not a real fail? just free the worker
            LOG.info("Task " + tr.getTaskId() + " failed (retry=" 
                + ts.getRetries() + ", tm=" + tmId + ", switch-to=" + ts.worker +")");
            curProgress = ts.progress;
          }
          break;

        case TASK_STATE_FATAL: // fatal exception in task
          assert ts.isRunning() : "task-status="+ts;
          taskTime += report.getProcessTime();
          // set task status as fail
          // remove from running set if this is a real failure (i.e. no backup)
          if (ts.fail(tmId, report.getProcessTime(), report.getProgress(), 
                  report.getCounters(), report.getMsg(), report.getCursor())) {
            // set current progress of this task "tr"
            curProgress = 0f;
            finishTask(tr);
          } else curProgress = ts.progress;
          // print information
          LOG.info("Task " + tr.getTaskId() + " fatal from " + tmId);
          printStatus();
          // abort the job
          jobMsg = "Some task (" + tr.getTaskId() 
              + ") encountered fatal exception and job will be aborted.";
          close(false); // abort all running tasks
          break;
          
        default:
          LOG.warning("State of " + tr.getTaskId() + " is invalid:" + report.getState());
      }
            
      // 4. update progress in job status
      float delta = curProgress - prevProgress;
      jobStatus.setProgress(tr.stage, 
          jobStatus.getProgress(tr.stage) + delta/taskStatus[tr.stage].length);      

    }
        
    /**
     * close this job as success or aborting
     */
    public void close(boolean isSuccess)  {      
      if (taskStatus!=null) {           // already planned tasks
        // delete all tasks with task master in this job
        for (int s=0; s< taskStatus.length; s++)
          for (int p=0; p<taskStatus[s].length; p++) {
            TaskStatus ts = taskStatus[s][p];
            if (ts.isSuccess()) {
              TaskMasterStatus tmStatus = jobMaster.getTaskMaster(ts.worker);
              // tmStatus is null when it is lost after success (not rescheduled)
              if (tmStatus!=null) tmStatus.delete(ts.task, false);
            } else if (ts.isRunning()) {
              TaskMasterStatus tms = jobMaster.getTaskMaster(ts.worker);
              if (tms != null) tms.delete(ts.task, true);
              for (String w:ts.backupWorkers)
                if (jobMaster.getTaskMaster(w) != null)
                    jobMaster.getTaskMaster(w).delete(ts.task,true);
            }
          }
      }
      if (isSuccess) {
          if ((runningTasks != null && !runningTasks.isEmpty()) || 
                  (pendingTasks!= null && !pendingTasks.isEmpty())) {
              LOG.warning("BUG! job is sucess, but running:" + runningTasks + ", pending:" + pendingTasks);
          }
      }else {
          if (runningTasks != null) runningTasks.clear();
          if (pendingTasks != null) pendingTasks.clear();
      }
      
//      if (reservedWorkers!=null) { // already reserved workers
//        // release all reserved workers
//        for (Map.Entry<String,Integer> entry: reservedWorkers.entrySet())
//          JobMaster.this.releaseWorker(jobId,entry.getKey(),entry.getValue());
//        reservedWorkers.clear(); freeWorkers.clear();
//      }
      
      if (isSuccess) jobStatus.setClose();
      else jobStatus.setAbort();
      endTime = System.currentTimeMillis();
      if (isSuccess) LOG.info("Closing job " + this.jobId + " at " + endTime);
      else LOG.info("Aborting job " + jobId + " at " + endTime);
      // write summary
      bgWriteSummary();
    }
     
    private void bgWriteSummary() {
      Thread writeThread = new Thread () {
        private String formatArray(float[] array) {
          StringBuffer sb = new StringBuffer();
          for (int i=0; i<array.length; i++) {
            sb.append(String.format("%1$.2g", array[i]) + ", ");
          }
          return "["+sb.substring(0, sb.length()-2)+"]";
        }
        
        private static final long SECOND = 1000;
        private static final long MINUTE = 60 * SECOND;
        private static final long HOUR = 60 * MINUTE;
        private static final long DAY = 24 * HOUR;
        private String getTime(long t) {
            StringBuffer time = new StringBuffer();
            long left = t;
            long day = left/DAY; left = left%DAY;
            long hour = left/HOUR; left = left%HOUR;
            long min = left/MINUTE; left = left%MINUTE;
            long second = left/SECOND;
            if (day!=0) time.append(day+"d");
            if (hour!=0) time.append(hour+"h");
            if (min!=0) time.append(min+"m");
            if (second!=0) time.append(second+"s");
            return time.toString();
        }
        
            public void run() {
                File dir = new File(new File(
                        CoworkConfig.get().getCoworkLogDir(),
                        JobMaster.JOB_DIR), jobId);
                if (!dir.exists())
                    dir.mkdirs();
                File file = new File(dir, "index.html");
                BufferedWriter writer = null;
                try {
                    try {
                        writer = new BufferedWriter(new FileWriter(file));
                        writer.write("<!-- :" + jobStatus.state + ":" + endTime
                                + ":"
                                + jobDef.getWorkerNumber(Integer.MAX_VALUE)
                                + ":" + getTime(endTime - startTime)
                                + ": -->\n");
                        writer.write("<HTML><BODY>\n");
                        // job
                        writer.write("<H2>Job Summary</H2>\n");
                        writer.write("<B>Finish Status: </B><A HREF=\"jm_log.html\">"
                                + jobStatus + "</A><BR>\n");
                        writer.write("<B>Submit Time: </B>"
                                + new Date(submitTime) + "<BR>\n");
                        writer.write("<B>Start: </B>" + new Date(startTime)
                                + "<BR>\n");
                        writer.write("<B>End: </B>" + new Date(endTime)
                                + "<BR>\n");
                        writer.write("<B>Elapsed Time: </B>"
                                + getTime(endTime - startTime) + "<BR>\n");
                        writer.write("<B>Worker Number Claimed: </B>"
                                + jobDef.getWorkerNumber(Integer.MAX_VALUE)
                                + "<BR>\n");
                        if (jobStatus.getFailTimes() > 0)
                            writer.write("<font color=red><B>Failed/Skipped Times: </B>"
                                    + jobStatus.getFailTimes()
                                    + "</font> (search \"Failed\" and \"Skipped\" below)<BR>\n");
                        if (jobStatus.getIgnoreTimes() > 0)
                            writer.write("<font color=red><B>Ignored Tasks in the Last Stage: </B>"
                                    + jobStatus.getIgnoreTimes()
                                    + "</font> (search \"Failed\" and \"Skipped\" below)<BR>\n");
                        writer.write("<B>Concurrency: </B>"
                                + ((double) taskTime / (endTime - startTime))
                                + "\n");
                        // task
                        writer.write("<H2>Tasks Details</H2>\n");
                        if (taskStatus == null)
                            writer.write("No task status available\n");
                        else {
                            writer.write("\n<B>Task Status: </B>"
                                    + taskStatus.length + " stages "
                                    + formatArray(jobStatus.progress) + "\n");
                            writer.write("<UL>\n");
                            for (int s = 0; s < taskStatus.length; s++) {
                                CounterMap counters = aggregateCounter(s);
                                writer.write("<LI><B>Counters in Stage " + s
                                        + ": </B>" + counters + "</LI>\n");
                            }
                            writer.write("</UL>\n");
                            for (int s = 0; s < taskStatus.length; s++)
                                for (int t = 0; t < taskStatus[s].length; t++) {
                                    writer.write("<H3>============== task-" + s
                                            + "-" + t
                                            + " ==============</H3>\n");
                                    writer.write("<B>Status: </B>"
                                            + taskStatus[s][t].toString()
                                            + "<BR>\n");
                                    writer.write("<B>Message: </B>"
                                            + taskStatus[s][t].doneMsg
                                            + "<BR>\n");
                                    writer.write("<B>Counters: </B>"
                                            + taskStatus[s][t].counters
                                            + "<BR>\n");
                                    if (taskStatus[s][t].skipCursors.size() > 0)
                                        writer.write("<font color=red><B>Skipped Cursor: </B>"
                                                + taskStatus[s][t].skipCursors
                                                + "</font><BR>\n");
                                    if (taskStatus[s][t].failCursors.size() > 0)
                                        writer.write("<font color=red><B>Failed Cursor: </B>"
                                                + taskStatus[s][t].failCursors
                                                + "</font><BR>\n");
                                    if (taskStatus[s][t].skipMachs.size() > 0)
                                        writer.write("<font color=red><B>Skipped Machine: </B>"
                                                + taskStatus[s][t].skipMachs
                                                + "</font><BR>\n");
                                    if (taskStatus[s][t].failMachs.size() > 0)
                                        writer.write("<font color=red><B>Failed Machine: </B>"
                                                + taskStatus[s][t].failMachs
                                                + "</font><BR>\n");
                                }
                        }
                        writer.write("</BODY></HTML>\n");
                        file.setReadOnly();

                        //write job meta
                        JobDetail jDetail = new JobDetail(jobId);
                        jDetail.setEndTime(endTime);
                        jDetail.setStartTime(startTime);
                        jDetail.setClaimedWorkerNum(jobDef.workerNum);
                        jDetail.setStageNum(taskStatus.length);
                        jDetail.setStatus(jobStatus.state);
                        jDetail.setElapsedTime(endTime - startTime);
                        jDetail.setSubmitTime(submitTime);
                        for (int s = 0; s < taskStatus.length; s++)
                            for (int t = 0; t < taskStatus[s].length; t++) {
                                if (!taskStatus[s][t].isSuccess()) {
                                    continue;
                                }
                                TaskDetail td = new TaskDetail();
                                td.stage = s;
                                td.successFlag = taskStatus[s][t].isSuccess();
                                td.machine = taskStatus[s][t].worker;
                                Counter mappedInSizeCounter = taskStatus[s][t].counters.get("MappedInSize");
                                td.mapInSize = mappedInSizeCounter == null ? -1
                                        : mappedInSizeCounter.get() / 1024;
                                Counter reduceInSizeCounter = taskStatus[s][t].counters.get("ReduceInSize");
                                td.reduceInSize = reduceInSizeCounter == null ? -1
                                        : reduceInSizeCounter.get();
                                td.runningTime = (Math.round(taskStatus[s][t].processTime / 100.0) / 10.0);
                                jDetail.addTaskDetail(td);
                            }
                        File destDir = new File(dir, jobId);
                        destDir.mkdirs();
                        jDetail.writeMetaFile(new File(destDir,
                                JobDetail.Job_Meta_File));
                    } finally {
                        if (writer != null)
                            writer.close();
                    }
                } catch (IOException e) {
                    LOG.log(Level.WARNING,
                            "Error writing summary for " + jobId, e);
                }
            }
        };
        writeThread.start();
    }
    
    /*
     * check if tm success run some task  
     */
    public void lostTaskMaster(String tmId) {
        LOG.info(jobId + " deal " + tmId + " lost, status:" + jobStatus);        
        printStatus();
        if (jobStatus.isFinished()) return;
        HashSet<TaskDef> lostTasks = new HashSet<TaskDef>();
        
        HashSet<TaskDef> finishedLost = usedWorkers.get(tmId);
        if (finishedLost != null) {
            LOG.info("Lost " + tmId + " which has successd run " + finishedLost);
            lostTasks.addAll(finishedLost);
        } 

        HashSet<TaskDef> runningLost =  null;
        for (LinkedHashSet<TaskDef> tset : runningTasks.values()) {
            for (TaskDef t : tset) {
                TaskStatus ts = getTaskStatus(t);
                if (ts.using(tmId)) {
                    if (runningLost == null) {
                        runningLost = new HashSet<TaskDef>();
                    }
                    runningLost.add(t);
                }
            }
        }
        if (runningLost != null) {
            lostTasks.addAll(runningLost);
            LOG.info("Lost " + tmId + " which need deal running " + runningLost);
        }
        lostTasks(tmId, lostTasks);
        /*
        for (TaskDef lt : lostTasks) {
            TaskStatus ts = getTaskStatus(lt);
            boolean isLost = ts.lost(tmId);
            boolean isRunning = ts.isRunning();
            if (isRunning) finishTask(lt);
            
            if (lt.stage >= jobStatus.getStage()) {
                LOG.warning("Queue task " + lt + " after " + tmId + " lost.");
                if (isLost) queueTask(lt);
            }else if (lt.stage == jobStatus.getStage() - 1){
                LOG.warning("Abort job becase task " + lt + " can't recover after " + tmId + " lost.");
                close(false);
            } else {
                LOG.warning("Ignore task " + lt + " when "+ tmId +" lost.");
            }
        }
        */
    }
    
    /**
     * A task master who has workers in this job was lost
     * @param tmId  name of the task master
     * @param lostTasks a list of tasks in this job which was assigned to tmId, add task is not finished
     */
    public void lostTasks(String tmId, HashSet<TaskDef> lostTasks) {
        if (lostTasks == null || lostTasks.isEmpty()) {
            LOG.info("Lost " + tmId + " is fine to " + jobId);
            return;
        }
      LOG.info("Lost " + tmId + " should redo " + lostTasks + " in job " + jobId);
      // If lostTasks==null, skip setting workers[][]=null and retreat() since
      // no task is lost
      assert jobStatus.isRunning() : "jobState="+jobStatus.getStage();
      if (lostTasks!=null) {
        // 1. set corresponding worker in taskStatus[][] as null
        for (TaskDef tr:lostTasks) { // lost task must be running or success
          // get status
          TaskStatus ts = taskStatus[tr.stage][tr.part];
          // success task in the last stage: skip (no re-execution is needed)
          if (ts.isSuccess() && tr.stage+1==jobDef.getTotalStage()) continue;
          // if this job wants to ignore failure in last stage: skip
          if (tr.stage+1==jobDef.getTotalStage() && jobDef.isIgnoreLastFailure()) {
              boolean isRunning = ts.isRunning();
              boolean isLost = ts.lost(tmId);
              if ( isLost&&isRunning ) finishTask(tr);
              continue;
          }
          
          if (ts.isSuccess()) {
              addLostTaskEvent(ts.task, tmId); //lost task event
          }
          // update job progress
          float delta = ts.isRunning()||ts.isSuccess()? ts.progress:0f;
          jobStatus.setProgress(tr.stage, 
            jobStatus.getProgress(tr.stage)-delta/taskStatus[tr.stage].length);
          // if not a suceeded task in the last stage: finish/requeue the task          
          if ( !(ts.isSuccess()&&tr.stage+1==jobDef.getTotalStage()) ) {
            // finish running task which was really lost
            boolean isRunning = ts.isRunning();
            boolean isLost = ts.lost(tmId);
            if ( isLost&&isRunning ) finishTask(tr);
            // requeue lost task
            if ( isLost ) queueTask(tr);
            if (!isRunning) {
                HashSet<TaskDef> tSet = usedWorkers.get(tmId);
                if(tSet!=null) {
                    boolean f = tSet.remove(tr);
                    if (!f) LOG.info("Can't find finished task " + tr + " in usedworker " + tmId);
                }
            }
          }
        }
        // 2. check whether need to retreat (need to check retreat at "FAIL" too)
        if (retreatStage())
          LOG.warning("Losing task master " + tmId + " introduces a retreat in job " + jobId);
      }
      // 4. set state as need more reservation      
    }
    
    /** 
     * Is this job removable from queue? Only when at closing/aborting state,
     * and endTime has been passed for at least 10 times 
     * of JobClient.PROGRESS_CHECK_INTERVAL long.  The last condition means
     * that JobClient has already got this CLOSING/ABORTING state
     */
    public boolean isRemovable() {
        long time = System.currentTimeMillis();
        return jobStatus.isFinished()
                && (time - endTime > jobMaster.getUpdateInterval(JobMaster.VERSION) * 10);
    }
    

    /**
     * 
     * @param stage
     * @param from >= 0
     * @return
     */
    public TaskCompletionEvent[] getStageTaskEvents(int stage, int from) {
        if (stage < 0) return TaskCompletionEvent.EMPTY_EVENTS;
        
        List<TaskCompletionEvent> eventList = stageTaskEvents.get(stage);               
        if (eventList.size() < from + 1) {
            return TaskCompletionEvent.EMPTY_EVENTS;
        }
        
        List<TaskCompletionEvent> subList = eventList.subList(from, eventList.size());
        return subList.toArray(new TaskCompletionEvent[subList.size()]);        
    }               
    
    /**
     * Aggregate counters of a stage
     * @param stage  The stage to aggregate
     * @return  The counters
     */
    public CounterMap aggregateCounter(int stage) {
        CounterMap counter = new CounterMap();
        if (taskStatus==null) return counter;
        for (int i=0; i<taskStatus[stage].length; i++) {
            if (taskStatus[stage][i].counters==null) continue;
            for (Map.Entry<String, Counter> entry:taskStatus[stage][i].counters.entrySet()) {
                Counter c = counter.get(entry.getKey());
                if (c==null)
                    counter.put(entry.getKey(), new Counter(entry.getValue().get()));
                else c.inc(entry.getValue().get());
            }
        }
        return counter;
    }
    
    /** 
     * Check whether some tasks in previous stages are lost and if these lost
     * tasks contains status required by upcoming scheduled tasks, then retreat
     * to previous stages.  Return if a new retreat introduced.
     */
    private boolean retreatStage() {
      // find the latest un-broken stage
      int cur= Math.min(jobStatus.getStage(), taskStatus.length - 1);
      boolean isBroken = false;
      for (;cur>=0;cur--) {
        isBroken = false;
        for (int i=0; i<taskStatus[cur].length;i++) {
          if (!taskStatus[cur][i].isSuccess() && !taskStatus[cur][i].isRunning()) {
            isBroken=true; break;
          }
        }
        if (!isBroken) break;
      }      
      cur++; // cur=-1 ==> next one; not broken at cur ==> broken since next one
      if (cur>=jobStatus.getStage()) return false;  // broken at current/next stage: no retreat
      
      // requeue broken tasks: not success && not running
      boolean isNewRetreat = false;
      for (int s=cur; s<jobStatus.getStage(); s++)
        for (int i=0; i<taskStatus[s].length; i++) {
          if (!taskStatus[s][i].isSuccess() && !taskStatus[s][i].isRunning()) {
              queueTask(taskStatus[s][i].task);
              isNewRetreat = true;
          }
        }
      return isNewRetreat;
    }
    
   
    public List<TaskDef> obtainCurStageTasks(TaskMasterStatus tms, ClusterStatus cs, int max) throws IOException {
        initStage(jobStatus.getStage());
        if (pendingTasks.isEmpty()) return new LinkedList<TaskDef>();
        
        int firstKey = pendingTasks.firstKey();
        int stage = jobStatus.getStage();        
        if (firstKey < stage) {
            LOG.warning("Pre-stage " + firstKey +" tasks exist when schedule stage " +  stage + ", tasks:" + pendingTasks.get(firstKey));
            LinkedList<TaskDef> assignedTask = new LinkedList<TaskDef>();
            List<TaskDef> preStageTasks = obtainNewTasks(firstKey, tms, cs, max);
            assignedTask.addAll(preStageTasks);
            if (assignedTask.size() < max) {
                List<TaskDef> curStageTasks = obtainNewTasks(stage, tms, cs, max - assignedTask.size());
                assignedTask.addAll(curStageTasks);
            }   
            LOG.info("2 stage task assigned:" + assignedTask );
            return assignedTask;
        } else if (firstKey > stage) {
            LOG.warning("Current stage " + stage + " has no task.");
            return new LinkedList<TaskDef>();
        } else {
            return obtainNewTasks(stage, tms, cs, max);            
        } 
    }
    
    public List<TaskDef> obtainNextStageTasks(TaskMasterStatus tms, ClusterStatus cs, int max) throws IOException {
        if (jobStatus.isInLastStage()) {
            LOG.warning("Job " + toString() +" is in last stage, can't obtain next stage task.");
            return new LinkedList<TaskDef>();
        }
        initStage(jobStatus.getStage() + 1);
        return obtainNewTasks(jobStatus.getStage() + 1, tms, cs, max);
    }
    
    protected List<TaskDef> obtainNewTasks(int stage, TaskMasterStatus tms, ClusterStatus cs, int max) throws IOException{
        printStatus();
        int taskPerMachine = jobDef.minTaskPerMachine();
        String stageId = TaskRunnable.getStageId(this.jobId, stage);
        int runningCount = tms.getRunningCount(stageId);
        
        List<TaskDef> assignedTasks = new LinkedList<TaskDef>();
        Queue<TaskDef> taskQueue = pendingTasks.get(stage);
        if (taskQueue == null) return assignedTasks;
        
        HashSet<TaskDef> skipedTasks = null;
        while (!taskQueue.isEmpty()) {
            if (taskPerMachine > 0 && runningCount + assignedTasks.size() >= taskPerMachine) break;
            TaskDef task = taskQueue.remove();
            if (!taskStatus[task.getStageIdx()][task.getPartIdx()].skip(tms.getId()))
                assignedTasks.add(task);
            else {
                if (skipedTasks == null) skipedTasks = new LinkedHashSet<TaskDef>();
                skipedTasks.add(task);
            }                
            if (assignedTasks.size() >= max) break;                 
        }
        
        if (skipedTasks != null) {
            LOG.info("Assign " + tms + " skip tasks " + skipedTasks);
            taskQueue.addAll(skipedTasks);
        }
       
        LOG.info("Scheduled: TPM=" + taskPerMachine + ", runningCount=" + runningCount + ", firstStageId=" +
                stageId + ", max=" + max + ", stage=" + stage + ", results=" + assignedTasks);
        for (TaskDef task : assignedTasks) {
            runTask(tms.getId(), task);
        }
        
        if (taskQueue.isEmpty()) pendingTasks.remove(stage);
        return assignedTasks;
    }
    
    public List<TaskDef> obtainNewLocalMapTasks(TaskMasterStatus tms, ClusterStatus cs) throws IOException{
        return null;
    }
    
    private boolean makeWayForUrgentTask(TaskDef urgentTask) {
        LOG.info("Try to make way for urgent task " + urgentTask);
        int nextStage = urgentTask.stage + 1;
        LinkedHashSet<TaskDef> rtasks = runningTasks.get(nextStage);
        if (rtasks == null || rtasks.size() == 0) return false;
        TaskDef abortTask = null;
        for (TaskDef task : rtasks){
            if (!getTaskStatus(urgentTask).skip(getTaskStatus(task).worker))
                abortTask = task;
        }
        if (abortTask == null) return false;
        String[] ws = taskStatus[abortTask.part][abortTask.part].abort();
        finishTask(abortTask);
        queueTask(abortTask);
        if (ws.length < 1) {
            LOG.log(Level.WARNING, "abort task have some bugs in makeWayForUrgentTask");
            return false;
        }
        jobMaster.getTaskMaster(ws[0]).assign(urgentTask);
        runTask(ws[0], urgentTask);
        LOG.info("Abort " + abortTask + " for " + urgentTask);
        return true;
    }
        
    private TaskStatus getTaskStatus(TaskDef task) {
        return taskStatus[task.stage][task.part];
    }    
    
    protected void printStatus() {
      int stage = jobStatus.getStage();
      if (jobStatus.isEnd(stage)) {
          LOG.info(jobId + " is at end.");
          return;
      }
      StringBuffer sb = new StringBuffer(jobId + " at stage " + stage + ": ");
      sb.append(finishedSize(stage) + "/" + taskStatus[stage].length +"\n");
      sb.append("  Running:  ");
      for (int s:runningTasks.keySet())
        sb.append(" " + jobDef.getStageName(s) + "(" + runningSize(s) + ")");
      sb.append("\n");
      sb.append("  Pending:  ");
      for (int s:pendingTasks.keySet()) {
        sb.append(" " + jobDef.getStageName(s) + "(" + pendingSize(s) + ")");
      }      
      LOG.info(sb.toString());
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public List<TaskStatus> getRunningTasks() {
        List<TaskStatus> results = new ArrayList<TaskStatus>();
        for (LinkedHashSet<TaskDef> tasks : runningTasks.values()) {
            for (TaskDef task : tasks) {
                TaskStatus ts = taskStatus[task.stage][task.getPartIdx()];
                results.add(ts);
            }
        }
        return results;
    }
    
    public int getTotalTasksNum() {
        int num = 0;
        int stageNum = jobDef.getTotalStage();
        for (int i =0; i < stageNum; i++) {
            num += jobDef.getTaskNumber(i);
        }
        return num;
    }

    /**
     * @return the jobId
     */
    public String getJobId() {
        return jobId;
    }

    public boolean isDeadLock() {
        if (firstPendingStage() == -1) {
            return false;
        }
        return firstPendingStage() < firstRunningStage();
    }
    
    /**
     * 从当前running的task中挑出用来用于释放worker的task, 数目不大于当前pending第一个stage的task总数
     * */
    public List<TaskDef> getRunningTasksRelease4PendingTasks() {
        int firstPendingStage = firstPendingStage();
        List<TaskDef> results = new ArrayList<TaskDef>();
        if (firstPendingStage != -1) {
            PriorityQueue<TaskDef> q = pendingTasks.get(firstPendingStage);
            for (int i = runningTasks.lastKey(); i > firstPendingStage; i --) {
                for (TaskDef task : runningTasks.get(i)) {
                    results.add(task);
                    if (results.size() == q.size()) {
                        return results;
                    }
                }
            }
        }
        return results;
    }
    
    
    public void moveFromRunning2Pending(TaskDef task) {
        finishTask(task);
        PriorityQueue<TaskDef> tasks = pendingTasks.get(task.stage);
        int lastStage = pendingTasks.lastKey();
        if (tasks != null) {
            tasks.add(task);
        } else if (task.stage > lastStage) {
            PriorityQueue<TaskDef> newQ = new PriorityQueue<TaskDef>();
            newQ.add(task);
            pendingTasks.put(task.stage, newQ);
        }
    }
    
    public String getGeneralJobID() {
        return CoWorkUtils.generateJobGeneralID(jobDef.getJobName(), jobDef.getUser());
    }

    public double getWeight() {
        double weight = 1.0;
        int deserveWorker = Math.min(getTotalTasksNum(), jobDef.getJobWorkerNumLimit());
        weight *= 1 / Math.log1p(deserveWorker);
        weight *= this.priority.getValue();
        long eclipseTime = (System.currentTimeMillis() - this.submitTime)/1000;
        weight *= Math.log1p(eclipseTime);
        return weight;
    }
  }
