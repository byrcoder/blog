/**
 * @(#)InetSocketAddressWritable.java, 2012-11-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.StringWritable;

/**
 *
 * @author chenheng
 *
 */
public class InetSocketAddressWritable implements IWritable {
    
    private StringWritable host = new StringWritable();
    private IntWritable port = new IntWritable();

    public InetSocketAddressWritable(String host, int port) {
        this.host.set(host);
        this.port.set(port);
    }
    
    public InetSocketAddressWritable() {}
    
    @Override
    public IWritable copyFields(IWritable value) {        
        InetSocketAddressWritable that = (InetSocketAddressWritable)value;
        this.host.copyFields(that.host);
        this.port.copyFields(that.port);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        host.writeFields(out);
        port.writeFields(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        host.readFields(in);
        port.readFields(in);
    }
    
    public String getHost() {
        return host.get();
    }
    
    public int getPort() {
        return port.get();
    }

    public void setHostAndPort(String host, int port) {
        this.host.set(host);
        this.port.set(port);
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("host:").append(host).append(",port:").append(port);
        return sb.toString();
    }
}
