/**
 * @(#)ResourceManager.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.cowork.CoWorkServlet;
import odis.cowork.JobConfig;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;

/**
 *
 * @author chenheng
 *
 */
public class ResourceManager implements IResource, IResourceService, Runnable {

    private static final Logger LOG = LogFormatter.getLogger(ResourceManager.class);
    public static final long HEARTBEAT_INTERVAL = CoworkConfig.conf().getLong("cowork.resourceManager.heartbeat.interval", 15 * 1000);// 15s
    public static final long HEARTBEAT_EXPIRE_LIMIT = CoworkConfig.conf().getLong("cowork.resourceManager.heartbeat.expire-limit", 50 * HEARTBEAT_INTERVAL);
    public static final String LOG_DIR = "resManager";
    public int  port;
    public String hostname;
    private String vol;
    private Clock clock = new Clock();
    private AbstractRpcServer server;
    private Map<String, ClusterNodeInfo> resourceMap = new LinkedHashMap<String, ClusterNodeInfo>();
    private ResourceScheduler scheduler = new ResourceScheduler();
    private boolean isTest = false;
    private CheckExpireNodeThread checkExpireThread = null;
    
    public ResourceManager() {}
    
    public ResourceManager(int port, String vol) throws IOException {
        this.port = port;
        this.vol = vol;
        this.hostname = InetAddress.getLocalHost().getHostName();
        this.isTest = "true".equals(System.getProperty("IS_TEST") == null ? "" : System.getProperty("IS_TEST"));
        List<Class<?>> interfaces = new ArrayList<Class<?>>();
        interfaces.add(IResource.class);
        interfaces.add(IResourceService.class);
        List<Object> instances = new ArrayList<Object>();
        instances.add(this);
        instances.add(this);
        int handlerCount = CoworkConfig.conf().getInt("cowork.resManager.handleCount", 100);
        server = RPC.getNIOServer(interfaces, instances, this.port, handlerCount);
        server.start();         

        checkExpireThread = new CheckExpireNodeThread();
        checkExpireThread.start();
        
        LOG.info("resource Manager started!");
    }
    
    @Override
    public List<Resource> getResource(JobConfig job, int num)
            throws RpcException {
        synchronized(resourceMap) {
            dumpResourceMap();
            LOG.info("@@RESOURCE@ get resource for job " + job.getJobDef().getJobName() + ", num = " + num);
            List<Resource> resources = scheduler.schedule(job, resourceMap, num);
            LOG.info("@@RESOURCE@@ resource is " + resources);
            return resources;
        }
    }

    @Override
    public void notExist(String tmid) throws RpcException {
        synchronized(resourceMap) {
            if (resourceMap.containsKey(tmid)) {
                resourceMap.get(tmid).setStatus(ClusterNodeInfo.ABNORMAL);
                LOG.info("@@RESOURCE@@ " + tmid + " set to be abnormal!");
            }
        }
    }
    
    @Override
    public boolean returnResource(String tmid, String resourceID)
            throws RpcException {
        synchronized(resourceMap) {
            dumpResourceMap();
            LOG.info("@@RESOURCE@@ " + tmid + " res " + resourceID+ " was notUsed!");
            ClusterNodeInfo nodeInfo = resourceMap.get(tmid);
            if (nodeInfo != null) {
                ComputeSpecs resource = nodeInfo.getReserveMap().get(resourceID);
                if (resource != null) {
                    nodeInfo.getReserve().delComputeSpecs(resource);
                    nodeInfo.getReserveMap().remove(resourceID);
                    resourceMap.remove(tmid);
                    resourceMap.put(tmid, nodeInfo);
                    dumpResourceMap();
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public boolean hello(ClusterNodeInfo nodeInfo, String v) throws RpcException {
        synchronized(resourceMap) {
            if (vol.equals(v)) {
                resourceMap.put(nodeInfo.getName().get(), nodeInfo);
                LOG.info("@@RESOURCE@@" + nodeInfo.getName().get() + " was added!");
            } else {
                LOG.info("@@RESOURCE@@" + nodeInfo.getName().get() + " version is not match!");
            }
        }
        return true;
    }

    @Override
    public boolean goodbye(String tmid, String reseaon) throws RpcException {
        synchronized(resourceMap) {
            resourceMap.remove(tmid);
            LOG.info("@@RESOURCE@@" + tmid + " was deleted!");
        }
        return true;
    }

    @Override
    public boolean heartBeat(ClusterNodeInfo nodeInfo, String v) throws RpcException {
        synchronized(resourceMap) {
            if (vol.equals(v)) {
                String tid = nodeInfo.getName().get();
                long now = clock.getTime();
                ClusterNodeInfo currNodeInfo = resourceMap.get(tid);
                if (currNodeInfo != null) {
                    if (!isTest && nodeInfo.isValid()) {
                        currNodeInfo.setRemaining(nodeInfo.getRemaining());
                    }
                    currNodeInfo.setLastHeartBeatTime(now);
                    currNodeInfo.setOneMinLoad(nodeInfo.getOneMinLoad());
                    currNodeInfo.setSwapUsed(nodeInfo.getSwapUsed());
                } else {
                    nodeInfo.setLastHeartBeatTime(now);
                    resourceMap.put(nodeInfo.getName().get(), nodeInfo);
                }
                LOG.info("@@RESOURCE@@" + nodeInfo.getName().get() + " was updated!");
            } else {
                LOG.info("@@RESOURCE@@" + nodeInfo.getName().get() + " version is not match!");
            }
        }
        return true;
    }

    @Override
    public void run() {
        try {
            server.join();
        } catch (InterruptedException e) {
            LOG.log(Level.WARNING, "", e);
        }
    }
    
    class Clock {
        public long getTime() {
            return System.currentTimeMillis();
        }
    }

    @Override
    public boolean useResource(String tmID, String resourceID)
            throws RpcException {
        synchronized(resourceMap) {
            LOG.info("@@RESOURCE@@ useResource, tmID=" + tmID + ", resourceID=" + resourceID);
            ClusterNodeInfo nodeInfo = resourceMap.get(tmID);
            if (nodeInfo != null) {
                ComputeSpecs resource = nodeInfo.getReserveMap().get(resourceID);
                if (resource != null) {
                    nodeInfo.getRemaining().delComputeSpecs(resource);
                    nodeInfo.getReserve().delComputeSpecs(resource);
                    nodeInfo.getReserveMap().remove(resourceID);
                    nodeInfo.getUsingMap().put(resourceID, resource);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean releaseResource(String tmID, String resourceID)
            throws RpcException {
        synchronized(resourceMap) {
            LOG.info("@@RESOURCE@@ releaseResource, tmID=" + tmID + ", resourceID=" + resourceID);
            ClusterNodeInfo nodeInfo = resourceMap.get(tmID);
            if (nodeInfo != null) {
                ComputeSpecs resource = nodeInfo.getUsingMap().get(resourceID);
                if (resource != null) {
                    nodeInfo.getRemaining().addComputeSpecs(resource);
                    nodeInfo.getUsingMap().remove(resourceID);
                    return true;
                } else {
                    if (nodeInfo.getReserveMap().containsKey(resourceID)) {
                        LOG.info("@@RESOURCE@@ BUG: not use but release resourceID " + resourceID);
                        resource = nodeInfo.getReserveMap().get(resourceID);
                        nodeInfo.getReserveMap().remove(resourceID);
                        nodeInfo.getReserve().delComputeSpecs(resource);
                        nodeInfo.getRemaining().addComputeSpecs(resource);
                        return true;
                    } else {
                        LOG.info("@@RESOURCE@@ BUG: can't find resourceID " + resourceID);
                    }
                }
            }
        }
        return false;
    }
    
    public void stop() {
        checkExpireThread.shutdown();
        checkExpireThread.interrupt();
        server.stop();
        LOG.info("res Manager stop!");
    }

    public int getResourceNum() {
        synchronized(resourceMap) {
            return resourceMap.size();
        }
    }
    
    private void dumpResourceMap() {
        if (isTest) {
            LOG.info("@@RESOURCE@@" + resourceMap);
        }
    }
    
    public void getResMapSnapshot(Map<String, ClusterNodeInfo> snapshot) {
        synchronized(resourceMap) {
            if (snapshot != null) {
                snapshot.clear();
                snapshot.putAll(resourceMap);
            }
        }
    }
    
    class CheckExpireNodeThread extends Thread {
        private static final int CHECK_INTERVAL = 20*1000; //20s 
        private volatile boolean isRunning = true;
        
        public CheckExpireNodeThread() {
            setName("CheckExpireNodeThread");
            setDaemon(true);
        }
        
        public void run() {
            while(isRunning) {
                synchronized(resourceMap) {
                    Iterator<Map.Entry<String, ClusterNodeInfo>> it = resourceMap.entrySet().iterator();  
                    while (it.hasNext()) {
                        Entry<String, ClusterNodeInfo> entry = it.next();
                        ClusterNodeInfo nodeInfo = entry.getValue();
                        LOG.info("@@RESOURCE@@ " + entry.getKey() + ": heartbeart eclipse:" + (clock.getTime() - nodeInfo.getLastHeartBeatTime()));
                        if ((clock.getTime() - nodeInfo.getLastHeartBeatTime()) > HEARTBEAT_EXPIRE_LIMIT) {
                            it.remove();
                            LOG.log(Level.WARNING, entry.getKey() + " heartbeat expired, remove this node");
                        }
                    }
                }
                try {
                    Thread.sleep(CHECK_INTERVAL);
                } catch (InterruptedException e) {
                    isRunning = false;
                    LOG.info("CheckExpireNodeThread was Interruptted!");
                }
            }
            LOG.info("CheckExpireNodeThread stopped!");
        }
        
        public void shutdown() {
            this.isRunning = false;
        }
    }
    
    
    
    private static Options options = new Options();
    static {
        options.withOption("p", "port", "set port of resourceManager")
                .setType(Options.TYPE_NUMBER).hasDefault();
        options.withOption("v", "volume", "set volume(random)");
        options.withOption("l", "set if log to file");
        options.withOption("jwebhost", "jobMaster web host", "jobMaster web host");
        options.withOption("jwebport", "jobMaster web port", "jobMaster web port");
    }
    
    public static void main(String[] args) throws Throwable {
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            System.out.println("error:" + e.getMessage());
            usage();
        }
        boolean isLogToFile = options.isOptSet("l");
        String vol = options.getStringOpt("v");
        int port = options.getIntOpt("p", CoworkConfig.get().getRMPort());
        String jmWebhost = options.getStringOpt("jwebhost");
        String jmWebPort = options.getStringOpt("jwebport");
        String hostname = InetAddress.getLocalHost().getHostName();
        if (isLogToFile) { // log to file
            File logDir = new File(CoworkConfig.get().getCoworkLogDir(),
                    LOG_DIR);
            if (!logDir.exists())
                logDir.mkdirs();
            LogFormatter.clearLoggerHandlers("");
            LogFormatter.setRotateFileLogger(
                    "",
                    logDir.getPath(),
                    "rm-" + hostname + ".log",
                    CoworkConfig.conf().getInt(
                            "cowork.resManager.log.file-limit", 100000000), // 100M
                    CoworkConfig.conf().getInt(
                            "cowork.resManager.log.file-count", 300),
                    CoworkConfig.conf().getBoolean(
                            "cowork.resManager.log.is-append", true));
            System.out.println("Log to file: " + logDir + File.separator
                    + "rm-" + hostname + ".log.*");
        }
        LogFormatter.setLogLevel(CoworkConfig.get().getServiceLogLevel(), Level.INFO);
        LOG.info("Starting resManager at " + hostname + ":" + port);
        ResourceManager rm = new ResourceManager(port, vol);
        ResManagerUpdater rmu = new ResManagerUpdater(rm, rm.port + 1, jmWebhost, jmWebPort);
        CoWorkServlet.setResInfo(rmu);
        rmu.start();
        rm.run();
    }

    private static void usage() {
        
    }




}
