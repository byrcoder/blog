package odis.cowork;

import static odis.mapred.MapTaskRunnable.CT_MAPPED_IN_SIZE;
import static odis.mapred.MapTaskRunnable.CT_MAPPED_OUT_SIZE;
import static odis.mapred.ReduceTaskRunnable.CT_MERGE_IN_SIZE;
import static odis.mapred.ReduceTaskRunnable.CT_REDUCE_IN_SIZE;
import static odis.mapred.ReduceTaskRunnable.CT_REDUCE_OUT_SIZE;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.conf.CoworkConfig;
import odis.cowork.analyzer.AnalyzerTool;
import odis.cowork.analyzer.CoWorkAnalyzer;
import odis.cowork.analyzer.CoWorkAnalyzer.DaySummary;
import odis.cowork.analyzer.CoWorkAnalyzer.JobDetail;
import odis.cowork.analyzer.CoWorkAnalyzer.ProgramDetail;
import odis.cowork.analyzer.CoWorkAnalyzer.TaskDetail;
import odis.cowork.analyzer.CoWorkAnalyzer.UserDetail;
import odis.cowork.resource.ClusterNodeInfo;
import odis.cowork.resource.ResManagerUpdater;
import odis.io.ReadWriteUtils;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.rpc2.RpcException;

import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.apache.velocity.servlet.VelocityServlet;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import toolbox.misc.LogFormatter;
import toolbox.text.util.StringUtils;
import toolbox.web.WebServer;

/**
 * TODO add java doc
 * 
 * @author zl
 */
public class CoWorkServlet extends VelocityServlet {

    private static final Logger LOG = LogFormatter.getLogger(CoWorkServlet.class);
    
    private static final long serialVersionUID = 1L;

    private static JobMasterUpdater jmInfo = null;
    
    private static ResManagerUpdater resInfo = null;

    private static CoWorkAnalyzer analyzer = CoWorkAnalyzer.getCoWorkAnalyzer();

    private static final String HTTP_PROXY_DOMAIN = "infra.corp.youdao.com";

    public static void setJobMasterInfo(JobMasterUpdater jmu) {
        jmInfo = jmu;
    }

    public static void setResInfo(ResManagerUpdater rmu) {
        resInfo = rmu;
    }
    
    protected Properties loadConfiguration(ServletConfig conf)
            throws FileNotFoundException, IOException {
        // setup Velocity
        Properties p = super.loadConfiguration(conf);
        System.out.println("Absolute path: "
                + conf.getServletContext().getRealPath("."));
        p.setProperty("file.resource.loader.path", conf.getServletContext()
                .getRealPath("."));
        return p;
    }

    protected Template handleRequest(HttpServletRequest req,
            HttpServletResponse resp, Context ctx) throws Exception {
        req.setCharacterEncoding("UTF-8"); // default is ISO8859
        String cmd = req.getServletPath();
        if (cmd != null)
            cmd = WebServer.trimSlashes(cmd);
        if (cmd == null || cmd.equals("")) {
            cmd = "cwhome.s";
        }

        ctx.put("cmd", cmd);
        ctx.put("navbar", "cwleftbar.vm");
       

        if (jmInfo != null) {
            ctx.put("title", "CoWork [" + jmInfo.getJobMaster() + "]");
            ctx.put("resAddr", jmInfo.getReswebAddr());
            ctx.put("jmAddr", jmInfo.getJMAddr());
        } else if (resInfo != null) {
            ctx.put("resAddr", resInfo.getReswebAddr());
            ctx.put("jmAddr", resInfo.getJMAddr());
        }
        if (cmd.equals("cwhome.s")) {
            doSummary(req, resp, ctx);
        } else if (cmd.equals("cwtms.s")) {
            doTaskMasterList(req, resp, ctx);
        } else if (cmd.equals("cwjobs.s")) {
            doJobList(req, resp, ctx);
        } else if (cmd.equals("cwjob.s")) {
            doJobDetail(req, resp, ctx);
        } else if (cmd.equals("cwstat.s")) {
            doGlobalStat(req, resp, ctx);
        } else if (cmd.equals("cwjobstat.s")) {
            doJobStat(req, resp, ctx);
        } else if (cmd.equals("cwprogramstat.s")) {
            doProgramStat(req, resp, ctx);
        } else if (cmd.equals("cwtrends.s")) {
            doTrends(req, resp, ctx);
        } else if (cmd.equals("cwsetting.s")) {
            doSetting(req, resp, ctx);
        } else if (cmd.equals("cwemail.s")) {
            doSendDailyEmail(req, resp, ctx);
        } else if (cmd.equals("cwsummary.s")) {
            // doCoWorkSummary(req,resp,ctx);
            return getTemplate("cwsummary.vm");
        } else if (cmd.equals("rebuildmeta.s")) {
            int num = analyzer.rebuildTotalJobDetail();
            ctx.put("content", "message.vm");
            ctx.put("error", "Has rebuild " + num + " files' metadata ");
        } else if (cmd.equals("rebuildday.s")) {
            String mes = analyzer.rebuildDaySummary(CoWorkAnalyzer.jobArchive);
            ctx.put("content", "message.vm");
            ctx.put("error", "Has rebuild " + mes + " files' metadata ");
        } else if (cmd.equals("cwjoblog.s")) {
            doJobLog(req, resp, ctx);
        } else if (cmd.equals("cwresManager.s")) {
            doResManager(req, resp, ctx);
        } else if (cmd.equals("cwresdetail.s")) {
            doResDetail(req, resp, ctx);
        } else {
            ctx.put("content", "cwhome.vm");
            doSummary(req, resp, ctx);
        }

        return getTemplate("template.vm");
    }

    private void doResDetail(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        ctx.put("content", "cwresdetail.vm");
        String tmid = req.getParameter("tmid");
        if (tmid == null) {
            ctx.put("content", "message.vm");
            ctx.put("error", "You must specify a job!");
            return;
        }
        String resourceID = req.getParameter("resourceID");
        if (!StringUtils.isEmptyString(resourceID)) {
            resInfo.returnResource(tmid, resourceID);
        }
        ClusterNodeInfo node = resInfo.getResMap().get(tmid);
        ctx.put("node", node);
        ctx.put("lastUpdateTime", resInfo.getLastUpdateTime());
    }

    private void doResManager(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        ctx.put("content", "cwresmanager.vm");
        ctx.put("resmap", resInfo.getResMap());
        int freeCpu = 0, freeMem = 0; 
        for (Entry<String, ClusterNodeInfo> entry : resInfo.getResMap().entrySet()) {
            ClusterNodeInfo node = entry.getValue();
            freeCpu += node.getRemaining().getCpuNums().get();
            freeMem += node.getRemaining().getMemoryMB().get();
        }
        ctx.put("freeCpu", freeCpu);
        ctx.put("freeMem", freeMem);
        ctx.put("lastUpdateTime", resInfo.getLastUpdateTime());
    }

    private static final Date date = new Date();

    private static final DateTimeFormatter formatter2 = DateTimeFormat.forPattern("yyyy/MM/dd HH:mm:ss");

    private void doSummary(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        ctx.put("content", "cwhome.vm");
        date.setTime(System.currentTimeMillis());
        ctx.put("systime", formatter2.print(date.getTime()));
        ctx.put("jobmaster", jmInfo.getJobMaster());
        ctx.put("jobs", jmInfo.jobQueue.values());
        ctx.put("taskmasters", jmInfo.taskmasterPool.values());
        ctx.put("odislocal", CoworkConfig.get().getOdisServiceLocal());
        ctx.put("allowedusers", "all");
        TreeMap<Long, String> jobMap = new TreeMap<Long, String>();
        TreeMap<Long, Integer> statusMap = new TreeMap<Long, Integer>();
        TreeMap<Long, Integer> workerNumMap = new TreeMap<Long, Integer>();
        TreeMap<Long, String> elapsedMap = new TreeMap<Long, String>();
        int succCount = 0, failCount = 0;
        HashMap<String, JobDetail> js = analyzer.listTodayJobDetail();
        for (Map.Entry<String, JobDetail> entry: js.entrySet()) {
            JobDetail j = entry.getValue();
            jobMap.put(j.getEndTime(), j.getJobName());
            statusMap.put(j.getEndTime(), j.getStatus());
            workerNumMap.put(j.getEndTime(), j.getClaimedWorkerNum());
            elapsedMap.put(j.getEndTime(),
                    CoWorkUtils.fromSecond2String(j.getElapsedTime()));
            if (j.isSuccess())
                ++succCount;
            else
                ++failCount;
        }  
        if (jobMap.size() > 0) {
            Long[] times = jobMap.keySet().toArray(new Long[jobMap.size()]);
            ArrayList<HashMap<String, Object>> jobList = new ArrayList<HashMap<String, Object>>();
            for (int i = times.length - 1; i >= 0; i--) {
                HashMap<String, Object> item = new HashMap<String, Object>();
                item.put("name", jobMap.get(times[i]));
                date.setTime(times[i]);
                item.put("time", formatter2.print(date.getTime()));
                item.put("status", statusMap.get(times[i]));
                item.put("workernum", workerNumMap.get(times[i]));
                item.put("elapsed", elapsedMap.get(times[i]));
                jobList.add(item);
            }
            ctx.put("doneJobs", jobList);
            ctx.put("succCount", succCount);
            ctx.put("failCount", failCount);
        }
    }


    private void doGlobalStat(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        int period = req.getParameter("period") == null ? 1 : Integer
                .parseInt(req.getParameter("period"));
//        long statTime = period * UnitUtils.DAY;
        ctx.put("content", "cwstat.vm");
        ctx.put("period", period);
        date.setTime(System.currentTimeMillis());
        ctx.put("systime", formatter2.print(date.getTime()));
        ctx.put("jobmaster", jmInfo.getJobMaster());
        ctx.put("jobs", jmInfo.jobQueue.values());
        ctx.put("taskmasters", jmInfo.taskmasterPool.values());
        ctx.put("odislocal", CoworkConfig.get().getOdisServiceLocal());
        // long current = System.currentTimeMillis();
        HashMap<String, UserDetail> userMap = analyzer.listTodayUserDetails();
        HashMap<String, ProgramDetail> programMap = analyzer
                .listTodayProgramDetails();

        ArrayList<UserDetail> userDetailList = new ArrayList<UserDetail>(
                userMap.values());
        ArrayList<ProgramDetail> programDetailList = new ArrayList<ProgramDetail>(
                programMap.values());
        Collections.sort(userDetailList, new Comparator<UserDetail>() {
            @Override
            public int compare(UserDetail o1, UserDetail o2) {
                double h2 = o2.getClaimedUsedWorkerHour();
                double h1 = o1.getClaimedUsedWorkerHour();
                if (h2 > h1)
                    return 1;
                else if (h2 < h1)
                    return -1;
                else
                    return 0;
            }
        });
        Collections.sort(programDetailList, new Comparator<ProgramDetail>() {
            @Override
            public int compare(ProgramDetail o1, ProgramDetail o2) {
                return o2.getJobsNumber() - o1.getJobsNumber();
            }
        });

        ctx.put("userDetails", userDetailList);
        ctx.put("programDetails", programDetailList);

    }

    private static NumberFormat doubleNumberFormat = NumberFormat
            .getNumberInstance();

    private void doJobStat(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        String jobid = req.getParameter("jobid");
        String archiveDate = req.getParameter("archive");
        if (jobid == null) {
            ctx.put("content", "message.vm");
            ctx.put("error", "You must specify a job!");
            return;
        }
        try {
            JobDetail jobDetail = (archiveDate == null ? analyzer
                    .getJobDetail(jobid) : analyzer.getJobDetail(jobid,
                    archiveDate));
            ArrayList<HashMap<String, Object>> stageStatList = new ArrayList<HashMap<String, Object>>();
            doubleNumberFormat.setMaximumFractionDigits(2);
            for (int i = 0; i < jobDetail.getStageNum(); ++i) {
                // stageList.add(jobDetail.getTasks(i));
                TaskDetail[] detailTasks = jobDetail.getTasks(i);
                HashMap<String, Object> stageStat = new HashMap<String, Object>();
                double maxTaskRunTime = -1;
                double sumTaskRunTime = 0;
                ArrayList<Double> taskRuntimes = new ArrayList<Double>();
                ArrayList<Long> taskInputSize = new ArrayList<Long>();

                for (TaskDetail task: detailTasks) {
                    sumTaskRunTime += task.getRunningTime();
                    if (task.getRunningTime() > maxTaskRunTime)
                        maxTaskRunTime = task.getRunningTime();
                    taskRuntimes.add(task.getRunningTime());
                    taskInputSize.add(task.getInputSize());
                }
                double avgTaskRunTime = sumTaskRunTime / detailTasks.length;
                double longTailRation = Math
                        .round((maxTaskRunTime / avgTaskRunTime) * 100)
                        / (double) 100;
                stageStat.put("maxTaskTime",
                        doubleNumberFormat.format(maxTaskRunTime));
                stageStat.put("avgTaskTime",
                        doubleNumberFormat.format(avgTaskRunTime));
                stageStat.put("longTailRatio", longTailRation);
                stageStat.put("tasksTime", getPlotKitDrawDataSet(taskRuntimes));
                stageStat.put("tasksInput",
                        getPlotKitDrawDataSet(taskInputSize));
                stageStat.put("taskNum", detailTasks.length);
                stageStatList.add(stageStat);
            }

            ctx.put("content", "cwjobstat.vm");
            ctx.put("job", jobDetail);
            ctx.put("stageStatList", stageStatList);
        } catch (Exception e) {
            ctx.put("content", "message.vm");
            ctx.put("error", e.getMessage());
            return;
        }
    }

    private void doProgramStat(HttpServletRequest req,
            HttpServletResponse resp, Context ctx) {
        String pid = req.getParameter("pid");
        if (pid == null) {
            ctx.put("content", "message.vm");
            ctx.put("error", "You must specify a Program!");
            return;
        }
        int period = req.getParameter("period") == null ? 7 : Integer
                .parseInt(req.getParameter("period"));
        ProgramDetail pDetail = analyzer.getProgramDetailInPeriod(pid, period);
        if (pDetail.getJobsNumber() == 0) {
            ctx.put("content", "message.vm");
            ctx.put("error", pid + " not run ant times in " + period
                    + " days. please check job's name!");
            return;
        }
        pDetail.sortByDate(false);
        ArrayList<JobDetail> jobs = pDetail.getJobs();

        ArrayList<Double> jobUtilities = new ArrayList<Double>();
        ArrayList<Long> jobRuntimes = new ArrayList<Long>();
        ArrayList<Double> weightedRuntimes = new ArrayList<Double>(); // consider
                                                                      // worker
                                                                      // numbers
                                                                      // and
                                                                      // input
                                                                      // files
        ArrayList<Long> jobInputSizes = new ArrayList<Long>(); // sum input size

        int maxWorkerNum = 0;
        long maxInputSize = 0;
        long maxRunTime = 0;
        long sumRunTime = 0;
        for (JobDetail job: jobs) {
            jobUtilities.add(job.getUtilityRatio());
            jobRuntimes.add(job.getElapsedTime());
            jobInputSizes.add(job.getTotalMapInSize() / 1024);
            if (job.getClaimedWorkerNum() > maxWorkerNum)
                maxWorkerNum = job.getClaimedWorkerNum();
            if (job.getTotalMapInSize() > maxInputSize)
                maxInputSize = job.getTotalMapInSize();
            maxRunTime = Math.max(maxRunTime, job.getElapsedTime());
            sumRunTime += job.getElapsedTime();
        }
        double avgRunTime = (double) sumRunTime / jobs.size();
        avgRunTime = Math.round(avgRunTime * 100) / (double) 100;

        for (int i = 0; i < jobRuntimes.size(); ++i) {
            long t = jobRuntimes.get(i);
            JobDetail j = jobs.get(i);
            if (j.getTotalMapInSize() == 0) {
                weightedRuntimes.add((double) t);
                continue;
            }
            double w = t * (j.getClaimedWorkerNum() / maxWorkerNum)
                    * (maxInputSize / j.getTotalMapInSize());
            w = (Math.round(w * 100)) / (double) 100;
            weightedRuntimes.add(w);
        }
        ArrayList<JobDetail> js = pDetail.getJobs();
        ctx.put("content", "cwprogramstat.vm");
        ctx.put("period", period);
        ctx.put("programDetail", pDetail);
        ctx.put("jobDetails", js);
        ctx.put("avgRunTime", avgRunTime);
        ctx.put("maxRunTime", maxRunTime);
        ctx.put("jobUtils", getPlotKitDrawDataSet(jobUtilities));
        ctx.put("jobRunTimes", getPlotKitDrawDataSet(jobRuntimes));
        ctx.put("jobWeightRunTimes", getPlotKitDrawDataSet(weightedRuntimes));
        ctx.put("jobInputSizes", getPlotKitDrawDataSet(jobInputSizes));
    }

    private void doTrends(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        int period = req.getParameter("period") == null ? 30 : Integer
                .parseInt(req.getParameter("period"));
        List<DaySummary> daySummarys = analyzer.getDaySummaryInPeriod(period);

        ArrayList<Integer> jobNums = new ArrayList<Integer>();
        ArrayList<Double> workHours = new ArrayList<Double>();
        ArrayList<Long> inputSizes = new ArrayList<Long>();
        ArrayList<Integer> abortJobs = new ArrayList<Integer>();
        for (DaySummary s: daySummarys) {
            jobNums.add(s.getJobsNumber());
            workHours.add(s.getActualUsedWorkerHour());
            // M size
            long t = s.getTotalMapInSize() / (1024 * 1024 * 1024);
            // double t =
            // Math.round(100*(s.getTotalMapInSize()/(1024*1024)))/(double)100;
            inputSizes.add(t);
            abortJobs.add(s.getAbortJobNumber());
        }

        ctx.put("content", "cwtrends.vm");
        ctx.put("period", period);
        ctx.put("days", daySummarys);
        ctx.put("jobNums", getPlotKitDrawDataSet(jobNums));
        ctx.put("workHours", getPlotKitDrawDataSet(workHours));
        ctx.put("inputSizes", getPlotKitDrawDataSet(inputSizes));
        ctx.put("abortJobs", getPlotKitDrawDataSet(abortJobs));
    }

    private void doSetting(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        // set job limit for a job
        String jobtag = req.getParameter("jobtag");
        String worker = req.getParameter("worker");
        String msg1 = "";
        if (jobtag != null && worker != null) {
            try {
                int workerNum = Integer.parseInt(worker);
                if (workerNum < 0) {
                    jmInfo.jm.removeJobLimit(jobtag);
                } else
                    jmInfo.jm.addJobLimit(jobtag, workerNum);
            } catch (Exception e) {
                msg1 = e.getMessage();
            }
        }
        ctx.put("joblimits", jmInfo.jm.snapshotJobLimit());
        ctx.put("workerMessage", msg1);

        // set the blacklist taskmaster
        String blackList = req.getParameter("blacklist");
        String action = req.getParameter("action");
        if (blackList != null && !blackList.trim().equals("")) {
            blackList = blackList.trim();
            String[] blackTmGroups = blackList.split(" ");
            for (String blackTmGroup: blackTmGroups){
                String[] blackTms = blackTmGroup.split(":");
                assert blackTms.length == 2;
                String machineGroup = blackTms[0];
                String[] machine = blackTms[1].trim().split("-");
                assert machine.length == 2;
                int startMachine = Integer.parseInt(machine[0]);
                int endMachine = Integer.parseInt(machine[1]);
                for (int i = startMachine; i <= endMachine; ++i){
                    String host = String.format("%s%03d", machineGroup, i);
                    String tmId = jmInfo.jm.getTmIdByHost(host);
                    try {
                        if (action.equals("add")){
                            jmInfo.jm.addBlacklisted(tmId);
                        }else{
                            jmInfo.jm.removeBlacklisted(tmId);
                        }
                    } catch (RpcException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        ctx.put("blackMachines", jmInfo.jm.getClusterStatus().getBlacklistedTaskMasters());
        
        // set the priority of task
        String prefix = req.getParameter("priorityPrefix");
        String priorityLevelStr = req.getParameter("priorityLevel");
        int priorityLevel = -1;
        try {
            priorityLevel = Integer.parseInt(priorityLevelStr);
        } catch (NumberFormatException e) {
            priorityLevel = -1;
        }
        if (prefix != null && priorityLevel != -1) {
            try {
                jmInfo.jm.setPriorityValue(prefix, priorityLevel);
            } catch (RpcException e) {
                LOG.log(Level.INFO, "Set priority of " + prefix + " failed",
                        e);
            }
        }
        Map<String, Integer> priorityMap = jmInfo.jm.clonePriorities();
        ctx.put("priorityPrefixes", priorityMap);
        
        ctx.put("content", "cwsetting.vm");
    }

    private void doSendDailyEmail(HttpServletRequest req,
            HttpServletResponse resp, Context ctx) {
        String receiver = req.getParameter("receiver");
        if (receiver != null) {
            try {
                AnalyzerTool.sendDailyReportMail(jmInfo.getJobMaster(),
                        receiver, AnalyzerTool
                                .composeDailyReportMail(CoWorkAnalyzer
                                        .getCoWorkAnalyzer()));
                ctx.put("status", "发送成功! 接受者:" + receiver);
            } catch (Exception e) {
                ctx.put("status", e.getMessage());
            }
        }
        ctx.put("content", "cwemail.vm");
    }

    private void doJobList(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        String jobId = req.getParameter("job");
//        if (jobId != null && !jmInfo.jm.isOccupyJob(jobId)) {
//            JobInProgress occupyJip = jmInfo.jm.getJob(jobId);
//            if (occupyJip != null)
//                jmInfo.jm.addOccupyJob(jobId, occupyJip.getOccupyNum());
//        }
        ctx.put("content", "cwjobs.vm");
        ArrayList<HashMap<String, Object>> jobs = new ArrayList<HashMap<String, Object>>();
        for (JobInProgress jip: jmInfo.jobQueue.values()) {
            // workers & machines
//            int cw = jip.totalRunningSize();
            Map<String, HashSet<TaskDef>> runningTM = jip.runningTaskMasters();
            int cm = runningTM.size();
            // running & queueing
            int rn = jip.totalRunningSize();
            int qn = jip.totalPendingSize();
            // progress
            int s = jip.jobStatus.stage;
            String p = "(Done)";
            if (s < 0)
                p = "(Pre)";
            else if (!jip.jobStatus.isEnd(s))
                p = jip.jobDef.getStageName(s) + "-"
                        + Math.round(jip.jobStatus.getProgress(s) * 100) + "%";
            // format objects
            HashMap<String, Object> obj = new HashMap<String, Object>();
            obj.put("id", jip.jobId);
            obj.put("state", jip.jobStatus.getStateString());
            obj.put("duration", longToDuration(System.currentTimeMillis()
                    - jip.startTime));
            obj.put("worker", jip.jobDef.getWorkerNumber(Integer.MAX_VALUE));
            obj.put("machine", cm);
            obj.put("stage", jip.jobDef.getTotalStage());
            obj.put("progress", p);
            obj.put("fail", jip.jobStatus.getFailTimes());
            obj.put("runtask", rn);
            obj.put("queuetask", qn);
            obj.put("actualWorker", jip.getActualWorkerNum());
            obj.put("priority", jip.getPriority().toString());
//            obj.put("isUnfair", jip.isUnfair());
//            obj.put("isOccupyJob", jmInfo.jm.isOccupyJob(jip.jobId));
            jobs.add(obj);
        }
        ctx.put("jobs", jobs);
        ctx.put("joblimits", jmInfo.jm.snapshotJobLimit());
    }

    private void doTaskMasterList(HttpServletRequest req,
            HttpServletResponse resp, Context ctx) {
        ctx.put("content", "cwtms.vm");
        // we do three columes on the page
        ArrayList<HashMap<String, Object>> tm1 = new ArrayList<HashMap<String, Object>>();
        ArrayList<HashMap<String, Object>> tm2 = new ArrayList<HashMap<String, Object>>();
        ArrayList<HashMap<String, Object>> tm3 = new ArrayList<HashMap<String, Object>>();
        int count = 0, tmVacancy = 0;
        String[] tmNames = jmInfo.taskmasterPool.keySet().toArray(
                new String[jmInfo.taskmasterPool.size()]);
        Arrays.sort(tmNames); // sort taskmaster according to the name
        for (String tmName: tmNames) {
            TaskMasterStatus tms = jmInfo.taskmasterPool.get(tmName);
            HashMap<String, Object> obj = new HashMap<String, Object>();
            obj.put("id", getTaskHomeHref(tms.getId()));
            obj.put("capacity", tms.capacity());
            obj.put("vacancy", tms.vacancy());
            obj.put("load", tms.getResourceStatus().getOneMinLoad());
            obj.put("cpus", tms.getResourceStatus().getProcessers());
            long swap = tms.getResourceStatus().getSwapUsed();
            swap = -1L == swap ? -1 : (int)(swap / 1048576);
            obj.put("swap", swap);
            tmVacancy += tms.vacancy();
            if (count % 3 == 0)
                tm1.add(obj);
            else if (count % 3 == 1)
                tm2.add(obj);
            else if (count % 3 == 2)
                tm3.add(obj);
            count++;
        }
        if (tm1.size() > 0)
            ctx.put("taskmasters1", tm1);
        if (tm2.size() > 0)
            ctx.put("taskmasters2", tm2);
        if (tm3.size() > 0)
            ctx.put("taskmasters3", tm3);
        ctx.put("tmsize", jmInfo.taskmasterPool.size());
        ctx.put("tmvacancy", tmVacancy);
        ctx.put("lastupdatetime",
                formatter2.print(jmInfo.lastUpdateTime.getTime()));
        ctx.put("vacancyIndex", jmInfo.jm.getVacancyIndex());
    }

    private static final NumberFormat numberFormat = NumberFormat
            .getNumberInstance();

    private void doJobDetail(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        String jobId = req.getParameter("jobid");
        if (jobId == null) {
            error(ctx, "你没有向这个页面输入需要查看的Job.");
            return;
        }
        JobInProgress jip = jmInfo.jobQueue.get(jobId);
        if (jip == null) {
            error(ctx, "找不到你需要查看的Job: " + jobId);
            return;
        }
        ctx.put("content", "cwjob.vm");
        ctx.put("nav", "Job Details");
        ctx.put("jobid", jobId);
        ctx.put("start", new Date(jip.startTime));
        ctx.put("duration", longToDuration(System.currentTimeMillis()
                - jip.startTime));

        // global progress
        int s = jip.jobStatus.stage;
        String p = "(Done)";
        if (s < 0)
            p = "(Pre)";
        else if (!jip.jobStatus.isEnd(s))
            p = jip.jobDef.getStageName(s) + "-"
                    + Math.round(jip.jobStatus.getProgress(s) * 100) + "%";
        ctx.put("progress", p);

        // workers & machines
        int cw = jip.totalRunningSize();
        Map<String, HashSet<TaskDef>> runningTM = jip.runningTaskMasters();
        int cm = runningTM.size();

        ctx.put("realworker", cw);
        ctx.put("realmachine", cm);
        ctx.put("askworker", jip.jobDef.getWorkerNumber(Integer.MAX_VALUE));
        // running tasks & machines
        if (jip.runningTasks != null) {
            StringBuffer sb = new StringBuffer();
            for (LinkedHashSet<TaskDef> tasks: jip.runningTasks.values())
                for (TaskDef task: tasks) {
                    String tm = jip.taskStatus[task.stage][task.part].worker;
                    sb.append(task).append("(")
                    .append(getTaskLogHref(tm, task.getTaskId()))
                    .append(",").append(getTaskJstackHref(tm, task.getTaskId()))
                    .append(");<br>");
                }
            if (sb.length() - 2 > 0)
                ctx.put("runningtasks", sb.substring(0, sb.length() - 2));
        }

        if (jip.failureReports.size() > 0) {
            StringBuffer sb = new StringBuffer();
            for (TaskReport failReport: jip.failureReports) {
                sb.append(getTaskLogHref(failReport.getTaskMasterId(), failReport.getTaskDef().getTaskId())).append(" ;<br> ");
            }
            ctx.put("errorReport", sb.toString());            
        }
        
        // running progress
        if (jip.jobDef instanceof MapReduceJobDef)
            ctx.put("mapreduces", getMapReduce(jip));
        else if (jip.jobDef instanceof MapOnlyJobDef)
            ctx.put("maponly", getMapOnly(jip));
        else {
            ctx.put("generic", getGeneric(jip));
        }
    }

    private void doJobLog(HttpServletRequest req, HttpServletResponse resp,
            Context ctx) {
        String jobId = req.getParameter("jobid");
        if (jobId == null) {
            error(ctx, "你没有向这个页面输入需要查看的Job.");
            return;
        }

        StringBuilder log = new StringBuilder();
        BufferedReader in = null;
        try {
            File logDir = new File(CoworkConfig.get().getCoworkLogDir(),
                    JobMaster.JOB_DIR);
            in = new BufferedReader(new FileReader(new File(
                    new File(logDir, jobId), "index.html")));

            JobMaster jm = jmInfo.jm;
            String line;
            String taskId = null;
            while ((line = in.readLine()) != null) {
                // task start
                if (line.startsWith("<B>Status: </B>")) {
                    int index = "<B>Status: </B>".length();
                    taskId = line.substring(index, line.indexOf(' ', index));
                }

                if (taskId != null) {
                    int index = line.indexOf("tm_");
                    while (index >= 0) {
                        // String tm = line.substring(index + 3, index + 8);
                        int b = line.indexOf(":", index + 1);
                        if (b < 0) {
                            b = line.indexOf(",", index + 1);
                            if (b < 0) {
                                b = line.indexOf("]", index + 1);
                                if (b < 0)
                                    break;
                            }
                        }
                        if (b - index > 30)
                            break;
                        String tmId = line.substring(index, b);
                        String currentTmId = jm.getTmIdByHost(CoWorkUtils
                                .getMachineName(tmId));
                        if (currentTmId == null)
                            break;
                        line = line.substring(0, index) + "<a href=\"http://"
                                + HTTP_PROXY_DOMAIN + "/" + currentTmId
                                + "/tmtasklog.s?task=" + taskId
                                + "&line=500\" target=_blank>" + tmId + "</a>"
                                + line.substring(b);
                        index = line.indexOf("</a>", index) + 4;
                        index = line.indexOf("tm_", index);
                    }
                }
                log.append(line);
            }
        } catch (Exception e) {
            ctx.put("content", "message.vm");
            ctx.put("error", "Can not read the log of the job(" + jobId + ")!");
            LOG.log(Level.WARNING, "do job log failed", e);
            return;
        } finally {
            ReadWriteUtils.safeClose(in);
        }

        ctx.put("job", jobId);
        ctx.put("log", log.toString());
        ctx.put("content", "cwjoblog.vm");
    }

    private HashMap<String, Object> getGeneric(JobInProgress jip) {
        GenericJobDef def = (GenericJobDef) (jip.jobDef);
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("totalstage", def.getTotalStage());
        ArrayList<HashMap<String, Object>> stages = new ArrayList<HashMap<String, Object>>();
        ArrayList<HashMap<String, Object>> counter = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < def.getTotalStage(); i++) {
            HashMap<String, Object> m = new HashMap<String, Object>();
            stages.add(m);
            // set value of m
            m.put("stage", i);
            m.put("progress", Math.round(jip.jobStatus.getProgress(i) * 100)
                    + "%");
            m.put("running", jip.runningTasks == null ? 0 : jip.runningSize(i));
            m.put("total", def.getTaskNumber(i));
            CounterMap ct = jip.aggregateCounter(i);
            if (ct == null)
                continue;
            String[] ctNames = ct.keySet().toArray(new String[ct.size()]);
            for (String name: ctNames) {
                HashMap<String, Object> obj = new HashMap<String, Object>();
                obj.put("name", name);
                obj.put("value", numberFormat.format(ct.get(name).get()));
                counter.add(obj);
            }
        }
        map.put("counter", counter);
        map.put("stages", stages);
        return map;
    }

    private HashMap<String, Object> getMapOnly(JobInProgress jip) {
        MapOnlyJobDef def = (MapOnlyJobDef) (jip.jobDef);
        HashMap<String, Object> map = new HashMap<String, Object>();
        // fake
        map.put("fake", "[[0,1],[" + (def.getMapNumber() - 1) + ",1]]");
        // map
        CounterMap counters = jip.aggregateCounter(0);
        CounterMap.Counter ct = null;
        StringBuffer sb = new StringBuffer();
        if (jip.taskStatus != null) {
            for (int t = 0; t < def.getMapNumber(); t++)
                // use map number
                sb.append("[" + t + "," + jip.taskStatus[0][t].progress + "],");
        } else {
            for (int t = 0; t < def.getMapNumber(); t++)
                // use reduce number
                sb.append("[" + t + ",0],");
        }
        sb.delete(sb.length() - 1, sb.length());
        map.put("progress", "[" + sb.toString() + "]");
        map.put("totaltask",
                def.getMapNumber() < 0 ? "(per-unit)" : def.getMapNumber() + "");
        map.put("donetask", jip.runningTasks == null ? 0 : jip.finishedSize(0));
        map.put("runningtask",
                jip.runningTasks == null ? 0 : jip.runningSize(0));
        ct = counters.getTotal(CT_MAPPED_IN_SIZE);
        map.put("totalinput", ct == null ? "n/a" : byteToMegabyte(ct.get()));
        ct = counters.get(CT_MAPPED_IN_SIZE);
        map.put("doneinput", ct == null ? "n/a" : byteToMegabyte(ct.get()));
        ct = counters.get(CT_MAPPED_OUT_SIZE);
        map.put("output", ct == null ? "n/a" : byteToMegabyte(ct.get()));
        // detail with counters
        String[] ctNames = counters.keySet().toArray(
                new String[counters.size()]);
        Arrays.sort(ctNames);
        ArrayList<HashMap<String, Object>> counter = new ArrayList<HashMap<String, Object>>();
        for (String name: ctNames) {
            HashMap<String, Object> obj = new HashMap<String, Object>();
            obj.put("name", name);
            obj.put("value", numberFormat.format(counters.get(name).get()));
            counter.add(obj);
        }
        map.put("counter", counter);
        // add to mapreduce list
        return map;
    }

    private ArrayList<HashMap<String, Object>> getMapReduce(JobInProgress jip) {
        ArrayList<HashMap<String, Object>> mrList = new ArrayList<HashMap<String, Object>>();
        MapReduceJobDef def = (MapReduceJobDef) (jip.jobDef);
        for (int i = 0; i < def.getIoPhaseNum(); i++) {
            HashMap<String, Object> mr = new HashMap<String, Object>();
            // fake
            mr.put("fake", "[[0,1],[" + (def.getTaskNumber(i + 1) - 1) + ",1]]");
            // map
            int stage = i;
            CounterMap rCounters = new CounterMap();
            CounterMap counters = jip.aggregateCounter(stage);
            CounterMap.Counter ct = null;
            StringBuffer sb = new StringBuffer();
            HashMap<String, Object> map = new HashMap<String, Object>();
            for (int t = 0; t < def.getTaskNumber(stage + 1); t++)
                // use reduce number
                sb.append("[" + t + "," + jip.jobStatus.getProgress(stage)
                        + "],");
            sb.delete(sb.length() - 1, sb.length());
            map.put("progress", "[" + sb.toString() + "]");
            map.put("totaltask", def.getTaskNumber(stage) < 0 ? "(per-unit)"
                    : def.getTaskNumber(stage) + "");
            map.put("donetask",
                    jip.runningTasks == null ? 0 : jip.finishedSize(stage));
            map.put("runningtask",
                    jip.runningTasks == null ? 0 : jip.runningSize(stage));
            ct = counters.getTotal(CT_MAPPED_IN_SIZE);
            map.put("totalinput", ct == null ? "n/a" : byteToMegabyte(ct.get()));
            ct = counters.get(CT_MAPPED_IN_SIZE);
            map.put("doneinput", ct == null ? "n/a" : byteToMegabyte(ct.get()));
            ct = counters.get(CT_MAPPED_OUT_SIZE);
            map.put("output", ct == null ? "n/a" : byteToMegabyte(ct.get()));
            mr.put("map", map);
            rCounters.putAll(counters);
            // merge
            stage++;
            float mapOut = (ct == null) ? 0 : ct.get();
            counters = jip.aggregateCounter(stage);
            HashMap<String, Object> merge = new HashMap<String, Object>();
            int mdt = 0, mrt = 0;
            sb = new StringBuffer();
            if (jip.taskStatus != null) {
                for (int t = 0; t < def.getTaskNumber(stage); t++) {
                    CounterMap cmap = jip.taskStatus[stage][t].counters;
                    if (cmap == null) {
                        sb.append("[" + t + ",0],");
                        continue;
                    }
                    CounterMap.Counter ctm = cmap.get(CT_MERGE_IN_SIZE);
                    CounterMap.Counter ctr = cmap.get(CT_REDUCE_IN_SIZE);
                    if (ctr != null) {
                        mdt++;
                        sb.append("[" + t + ",1],");
                    } else if (ctm != null) {
                        mrt++;
                        sb.append("[" + t + "," + (ctm.get() / mapOut) + "],");
                    } else
                        sb.append("[" + t + ",0],");
                }
            } else {
                for (int t = 0; t < def.getTaskNumber(stage); t++)
                    sb.append("[" + t + ",0],");
            }
            sb.delete(sb.length() - 1, sb.length());
            merge.put("progress", "[" + sb.toString() + "]");
            merge.put("totaltask", def.getTaskNumber(stage));
            merge.put("donetask", mdt);
            merge.put("runningtask", mrt);
            merge.put("totalinput", map.get("output"));
            ct = counters.get(CT_MERGE_IN_SIZE);
            merge.put("doneinput", ct == null ? "n/a"
                    : byteToMegabyte(ct.get()));
            merge.put("output", ct == null ? "n/a" : byteToMegabyte(ct.get()));
            mr.put("merge", merge);
            // reduce
            HashMap<String, Object> reduce = new HashMap<String, Object>();
            sb = new StringBuffer();
            if (jip.taskStatus != null) {
                for (int t = 0; t < def.getTaskNumber(stage); t++)
                    // use reduce number
                    sb.append("[" + t + "," + jip.taskStatus[stage][t].progress
                            + "],");
            } else {
                for (int t = 0; t < def.getTaskNumber(stage); t++)
                    // use reduce number
                    sb.append("[" + t + ",0],");
            }
            sb.delete(sb.length() - 1, sb.length());
            reduce.put("progress", "[" + sb.toString() + "]");
            reduce.put("totaltask", def.getTaskNumber(stage));
            reduce.put("donetask",
                    jip.runningTasks == null ? 0 : jip.finishedSize(stage));
            reduce.put("runningtask",
                    jip.runningTasks == null ? 0 : jip.runningSize(stage));
            ct = counters.getTotal(CT_REDUCE_IN_SIZE);
            reduce.put("totalinput",
                    ct == null ? "n/a" : byteToMegabyte(ct.get()));
            ct = counters.get(CT_REDUCE_IN_SIZE);
            reduce.put("doneinput",
                    ct == null ? "n/a" : byteToMegabyte(ct.get()));
            ct = counters.get(CT_REDUCE_OUT_SIZE);
            reduce.put("output", ct == null ? "n/a" : byteToMegabyte(ct.get()));
            mr.put("reduce", reduce);
            rCounters.putAll(counters);
            // detail with counters
            String[] ctNames = rCounters.keySet().toArray(
                    new String[rCounters.size()]);
            Arrays.sort(ctNames);
            ArrayList<HashMap<String, Object>> counter = new ArrayList<HashMap<String, Object>>();
            for (String name: ctNames) {
                HashMap<String, Object> obj = new HashMap<String, Object>();
                obj.put("name", name);
                obj.put("value", numberFormat.format(rCounters.get(name).get()));
                counter.add(obj);
            }
            mr.put("counter", counter);
            // add to mapreduce list
            mrList.add(mr);
        }
        return mrList;
    }

    protected void error(Context ctx, String message) {
        ctx.put("nav", "出错");
        ctx.put("error", message);
        ctx.put("content", "message.vm");
    }

    protected void message(Context ctx, String message) {
        ctx.put("nav", "信息");
        ctx.put("message", message);
        ctx.put("content", "message.vm");
    }

    private static String longToDuration(long l) {
        long min = l / 1000 / 60;
        long hour = min / 60;
        min = min - hour * 60;
        return hour + "h" + min + "m";
    }

    private static String byteToMegabyte(long l) {
        if (l < 1000)
            return l + "B";
        if (l < 1000000)
            return (l / 1000) + "." + (l / 100 % 10) + "KB";
        else
            return l / 1000000 + "." + (l / 100000 % 10) + "MB";
    }

    private static String getTaskLogHref(String tmId, String taskId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<a href=\"http://")
        .append(HTTP_PROXY_DOMAIN)
        .append("/")
        .append(tmId)
        .append("/tmtasklog.s?task=")
        .append(taskId)
        .append("&line=500\" target=_blank>")
        .append(tmId)
        .append("</a>");
        return sb.toString();
    }
    
    private static String getTaskJstackHref(String tmId, String taskId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<a href=\"http://")
        .append(HTTP_PROXY_DOMAIN).append("/").append(tmId)
        .append("/tmtaskstack.s?task=")
        .append(taskId)
        .append("\" target=_blank>stack</a>");
        return sb.toString();
    }
    
    private static String getTaskHomeHref(String tmId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<a href=\"http://")
        .append(HTTP_PROXY_DOMAIN)
        .append("/")
        .append(tmId)
        .append("/tmhome.s?\" target=_blank>")
        .append(tmId)
        .append("</a>");
        return sb.toString();
    }
    
    public static String getPlotKitDrawDataSet(Collection<?> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        int i = 0;
        for (Object o: list) {
            sb.append("[").append(i++).append(",").append(o.toString())
                    .append("]");
            if (i != list.size()) {
                sb.append(",");
            }
        }
        sb.append("]");
        return sb.toString();
    }

}
