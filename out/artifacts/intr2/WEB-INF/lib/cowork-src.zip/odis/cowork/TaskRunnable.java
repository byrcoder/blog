/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.IOException;
import java.util.logging.Logger;

import odis.cowork.CounterMap.Counter;
import odis.mapred.MRConfig;
import odis.tools.GlobalCounterUpdater;
import toolbox.misc.LogFormatter;

/**
 * The abstract class of a task.  The subclasses define different types of task
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public abstract class TaskRunnable {
  protected static final Logger LOG = LogFormatter.getLogger(TaskRunnable.class);
  
  protected static final long NON_CURSOR = -1;
  
  // basic information
  protected String jobId;
  protected int stage;
  protected int part;
  // extened information
  /*
   * XXX ???
   */
  protected long[] skips;
  protected int skipIdx;
  // runner
  protected TaskWorker worker;            // task runner of this task
  // running progress states
  protected volatile float progress;      // current progress [0,1]  
  protected CounterMap counters;          // counter map
  protected CursorBuffer cursor;          // buffer to share current cursor
  protected volatile String doneMsg;      // msg returned when task is done
  // progress flag
  private volatile boolean progressFlag;  // local progress update flag
  // start/end states
  protected long startTime;
  protected boolean toEnd = false;
  protected int[] resultPartCount;
  /**
   * Composes a task-id.
   * @param jobId  the ID of the job
   * @param stage  the stage of the task
   * @param part  the partition index of the task
   * @return a task-id
   */
  public static String getTaskId(String jobId, int stage, int part) {
    return jobId+"."+stage+"."+part;
  }
  /**
   * Composes a stage-id
   * @param jobId  the ID of the job
   * @param stage  the stage index
   * @return a stage-id
   */
  public static String getStageId(String jobId, int stage) {
    return jobId+"."+stage;
  }
  /**
   * Returns a counter with a specified name. If this counter was not in current
   * counter map, it will be created.
   * @param name  the name of the counter
   * @return a counter with a specified name
   */
  public Counter getCounter(String name) {
      Counter c = counters.get(name);
      if (c==null) {
          c = new Counter();
          counters.put(name, c);
      }
      return c;
  }
  
  public int[] getResultPartCount() {
      if (resultPartCount == null)  return new int[0];
      else return resultPartCount;
  }
  
  public void setResultPartCount(int[] partCount) {
      resultPartCount = partCount;
  }

  ////////////////////////////////////////////
  // Constructors
  ////////////////////////////////////////////
  protected TaskRunnable() {}
  
  public void init(String jobId, int stageIdx, int partIdx) {
    this.jobId = jobId;  this.stage = stageIdx; this.part = partIdx;
    this.skips = null; this.skipIdx = 0;
    this.progress = 0f; this.progressFlag = false;
    this.cursor = null;
    this.counters = new CounterMap();
    this.doneMsg = "";
  }
  
  public void setSkip(long[] cursors) { this.skips = cursors; }
  public void setCursor(CursorBuffer cb) {
      this.cursor=cb; cursor.write(cursor(), 0);
  }
  public void closeCursor() throws IOException {
      if (cursor!=null) cursor.close();
  }

  public int hashCode() { return getTaskId().hashCode(); }
  
  public boolean equals(Object o) {
    if (o instanceof TaskRunnable) {
      TaskRunnable that = (TaskRunnable) o;
      if (this.jobId.equals(that.jobId) && this.stage==that.stage && 
          this.part==that.part) {
        return true;
      } else return false;
    } else return false;
  }
  
  public String toString() { return getTaskId(); }
  
  ////////////////////////////////////////////
  // Accessors
  ////////////////////////////////////////////
  public String getJobId() { return jobId; }
  public int getStageIdx() { return this.stage; }
  public int getPartIdx() { return this.part; }  
  public String getTaskId() { return getTaskId(jobId,stage,part); }
  
  public boolean isSkip() {
    if (skips==null) return false;
    if (skipIdx>=0 && skipIdx<skips.length) {
      if (cursor()==skips[skipIdx]) {
          skipIdx++; return true;
      } else return false;
    }
    return false;
  }
  
  public TaskWorker getWorker() { return worker; }

  public void setProgressFlag(boolean b) { this.progressFlag = b; }
  public boolean getProgressFlag(JobDef job) { return progressFlag&&job.isCheckProgress(stage); }

  public float getProgress() { return progress; }
  public CounterMap getCounters() { return counters; }
  public String getDoneMsg() { return doneMsg; }
  
  public void setDoneMsg(String msg) { 
      if (msg.length() > MRConfig.MAX_DONE_MSG_LENGTH) {
          msg = msg.substring(0, MRConfig.MAX_DONE_MSG_LENGTH);
      }
      doneMsg = msg;
  }
    
  public void endTask() { toEnd = true; }  /** End task */
  
  /**
   * add by tuqc@rd 2009-9-7
   * use GlobalCounterUpdater can get the global counter info
   * @return
   */  
  public GlobalCounterUpdater getGlobalCounterUpdater() {
	  return new GlobalCounterUpdater(worker.getTaskMaster());
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // Abstract methods
  // Note: These two methods should not throw exception other than Runtime ones.
  // Basically, the task.run should be success and no error/exception inside.
  // If there is any, the specific task should handle it inside.
  /////////////////////////////////////////////////////////////////////////////
  public abstract void configure(JobDef job, TaskWorker runner);
  public abstract void run();
  
  protected abstract long cursor();
  protected long time() { return System.currentTimeMillis()-startTime; }
  
  protected void clean(String jobId, int stage, JobDef job) { }

}
