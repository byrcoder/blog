/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

/**
 * Fatal exception in TaskRunnable.run() causing the whole job to fail. 
 * This is defined as a runtime exception
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
@SuppressWarnings("serial")
public class TaskFatalException extends RuntimeException {

  public TaskFatalException(String s) { super(s); }
    
  public TaskFatalException(String s, Throwable cause) { super(s, cause); }
  
  public TaskFatalException(Throwable cause) { super(cause); }

}
