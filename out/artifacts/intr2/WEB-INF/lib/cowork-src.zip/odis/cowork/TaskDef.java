/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.Set;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.StringsWritable;
import toolbox.misc.ClassUtils;

/**
 * Task definition specifying interface class, runnable class, job ID and other
 * information.
 * 
 * @author zl
 */
public class TaskDef implements IWritable {

    // persistent basic states
    protected String xfaceClass;

    protected String runnableClass;

    protected String jobId;

    protected int stage;

    protected int part;

    protected int resourceNeed = 1; // the number of resource copies which the
                                    // task need

    public int priority; // priority number, which is a relative value

    // persistent extended stages
    protected long[] skips; // cursors to be skipped

    protected String resourceID = ""; // resourceID
    
    protected String taskMasterID = ""; //TaskMasterID
    
    public TaskDef() {}

    public TaskDef(String xfaceCls, String runCls, String jobId, int stage,
            int part) {
        this.xfaceClass = xfaceCls;
        this.runnableClass = runCls;
        this.jobId = jobId;
        this.stage = stage;
        this.part = part;
        this.skips = null;
        this.priority = 0;
    }

    public void setSkip(Set<Long> cursors) {
        if (cursors.size() == 0)
            this.skips = null;
        skips = new long[cursors.size()];
        int i = 0;
        for (Long item: cursors)
            skips[i++] = item;
        Arrays.sort(skips); // from the smallest to the largest
    }

    // //////////////////////////////////////////
    // Accessors
    // //////////////////////////////////////////
    public String getJobId() {
        return jobId;
    }

    public int getStageIdx() {
        return this.stage;
    }

    public int getPartIdx() {
        return this.part;
    }

    public String getStageId() {
        return TaskRunnable.getStageId(jobId, stage);
    }

    public String getTaskId() {
        return TaskRunnable.getTaskId(jobId, stage, part);
    }

    public TaskRunnable getTaskRunnable() {
        TaskRunnable task = (TaskRunnable) ClassUtils.newInstance(ClassUtils
                .getClass(runnableClass,
                        ClassUtils.getClass(xfaceClass, TaskRunnable.class)));
        task.init(jobId, stage, part);
        if (skips != null)
            task.setSkip(skips);
        return task;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int p) {
        priority = p;
    }

    public int hashCode() {
        return getTaskId().hashCode();
    }

    public boolean equals(Object o) {
        if (o instanceof TaskDef) {
            TaskDef that = (TaskDef) o;
            if (this.jobId.equals(that.jobId) && this.stage == that.stage
                    && this.part == that.part) {
                return true;
            } else
                return false;
        } else
            return false;
    }

    public String toString() {
        return getTaskId();
    }

    public IWritable copyFields(IWritable value) {
        TaskDef that = (TaskDef) value;
        this.xfaceClass = that.xfaceClass;
        this.runnableClass = that.runnableClass;
        this.jobId = that.jobId;
        this.stage = that.stage;
        this.part = that.part;
        if (that.skips != null) {
            this.skips = new long[that.skips.length];
            System.arraycopy(that.skips, 0, this.skips, 0, this.skips.length);
        }
        this.priority = that.priority;
        //this.resourceNeed = that.resourceNeed;
        this.resourceID = that.resourceID;
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        xfaceClass = in.readUTF();
        runnableClass = in.readUTF();
        jobId = in.readUTF();
        stage = in.readInt();
        part = in.readInt();
        priority = in.readInt();
        int c = in.readInt();
        if (c != 0)
            skips = new long[c];
        else
            skips = null;
        for (int i = 0; i < c; i++)
            skips[i] = in.readLong();
        this.resourceID = StringWritable.readString(in);
        // resourceNeed = in.readInt();
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(xfaceClass);
        out.writeUTF(runnableClass);
        out.writeUTF(jobId);
        out.writeInt(stage);
        out.writeInt(part);
        out.writeInt(priority);
        if (skips == null)
            out.writeInt(0);
        else {
            out.writeInt(skips.length);
            for (int i = 0; i < skips.length; i++)
                out.writeLong(skips[i]);
        }
        StringWritable.writeString(out, this.resourceID);
        // out.writeInt(resourceNeed);
    }

    /**
     * get the resource copies of the task
     * 
     * @return
     * @author chenqi
     */
    public int getResourceNeed() {
        return this.resourceNeed;
    }

    /**
     * set the resource copies of the task
     * 
     * @param num
     * @author chenqi
     */
    public void setResourceNeed(int num) {
        // need at least one copy
        if (num < 1)
            return;
        this.resourceNeed = num;
    }

    public String getResourceID() {
        return resourceID;
    }

    public void setResourceID(String resourceID) {
        this.resourceID = resourceID;
    }
}
