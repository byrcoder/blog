/**
 * @(#)JobsExtraParamsManager.java, 2013-1-10. 
 * 
 * Copyright 2013 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * 
 * 用于人工对于job运行参数的配置与干预
 * 
 * @author chenheng
 *
 */
public class JobsExtraParamsManager {

    //key: user+jobName, value: workerNumLimit
    private Map<String, Integer> jobWorkerLimit = new HashMap<String, Integer>();
    
    public void addJobWorkerLimit(String key, Integer v) {        
        if (!StringUtils.isEmpty(key) && v != null) {
            synchronized(jobWorkerLimit) {
                jobWorkerLimit.put(key, v);
            }
        }
    }
    
    public void delJobWorkerLimit(String key) {
        if (!StringUtils.isEmpty(key)) {
            synchronized(jobWorkerLimit) {
                jobWorkerLimit.remove(key);
            }
        }
    }
    
    public int getJobWorkerLimit(String key) {
        synchronized(jobWorkerLimit) {
            if (jobWorkerLimit.containsKey(key)) {
                return jobWorkerLimit.get(key);
            } else {
                return Integer.MAX_VALUE;
            }
        }
    }

    public Map<String, Integer> getJobWorerLimitSnapshot() {
        synchronized(jobWorkerLimit) {
            return jobWorkerLimit;
        }
    }
    
}
