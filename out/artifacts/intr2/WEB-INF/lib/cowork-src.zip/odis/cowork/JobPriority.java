package odis.cowork;


/**
 * 
 * @author Tu Qichen
 *
 */
public enum JobPriority{
    VERY_HIGH (5),
    HIGH (4),
    NORMAL (3),
    LOW (2),
    VERY_LOW (1);
    
    private int value;
    private JobPriority(int v) {
        value = v;
    }
    
    public static JobPriority valueOf(int v) {
        switch(v) {
            case 5:
                return VERY_HIGH;
            case 4:
                return HIGH;
            case 3:
                return NORMAL;
            case 2:
                return LOW;
            case 1:
                return VERY_LOW;
        }
        return NORMAL;
    }
    
    public static int value(JobPriority p) {
        return p.value;
    }

    public int getValue() {
        return value;
    }

}
