/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import toolbox.misc.ClassUtils;


/**
 * Defines an type of job:
 *   1) consists of n stage.
 *   2) run stages of tasks which are a general task.
 * This is the most flexible job. You can run any stage of job here by defining
 * tasks as subclasses of TaskRunnable.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public class GenericJobDef extends JobDef {
  
  private static final int TASK_STAGE_0 = 0;
  private static final String GENERIC_STAGE_NUM = "jobdef.generic.stage_num";
  
  protected String getTypeName() { return "GenericJob"; }
  protected String getTypeClass() { return GenericJobDef.class.getName(); }

  /**
   * The default constructor with 1 stage.
   */
  public GenericJobDef() { this(1); }
  /**
   * The constructor.
   * @param stageNum  the number of stages
   */
  public GenericJobDef(int stageNum) {
    initialize(stageNum);
  }
  
  private void initialize(int stageNum) {
    // definitions
    this.stageNames = new String[stageNum];
    this.stageXfaces = new String[stageNum];
    for (int i=0; i<stageNum; i++) {
      stageNames[i] = "generic-"+i;
      stageXfaces[i] = TaskRunnable.class.getName();
    }
    // default parameters
    this.jobName = "job";
    this.taskClasses = new String[stageNum];
    this.taskNumbers = new int[stageNum];
    this.workerNum = 1;
    this.taskPerMachine = new int[stageNum];
    this.exclusiveOwn = new boolean[stageNum];
    for (int i=0; i<stageNum; i++) {
      taskNumbers[i] = 1; taskPerMachine[i] = 0; exclusiveOwn[i] = false;
    }
  }

  /** This is a dynamic class, no static definitions */
  @Override
  protected void staticDefine() { }  
  
  protected void loadConfig(JobConfig conf) {
    int stageNum = conf.getInt(GENERIC_STAGE_NUM,1);
    initialize(stageNum);
    super.loadConfig(conf);
  }
  @Override
  protected void saveConfig() {
    JobConfig conf = getConfig();
    conf.setInt(GENERIC_STAGE_NUM,getTotalStage());
    super.saveConfig();
  }

  // set & get task class
  /**
   * Set the class of the task for a specified stage
   */
  public void setTaskClass(int stage, Class<? extends TaskRunnable> c) {
    super.setTaskClass(stage,c);
  }
  
  // set & get task number
  /**
   * Set the number of tasks for a specified stage
   */
  public void setTaskNumber(int stage, int num) {
    super.setTaskNumber(stage,num);
  }
  /**
   * Get the number of tasks for a specified stage
   */
  public int getTaskNumber(int stage) {
    return super.getTaskNumber(stage);
  }
  /**
   * Set the maximum number of backup task for a specified stage
   */
  public void setMaxBackupNum(int stage, int num) {
    super.setMaxBackupNum(stage, num);
  }
  /**
   * Set the task class of the first stage
   * @param c  the task class
   */
  public void setTaskClass(Class<? extends TaskRunnable> c) {
    super.setTaskClass(TASK_STAGE_0,c);
  }
  public void setTaskNumber(int num) {
    super.setTaskNumber(TASK_STAGE_0,num);
  }
  public int getTaskNumber() {
    return super.getTaskNumber(TASK_STAGE_0);
  }  
  public void setMaxBackupNum(int num) {
    super.setMaxBackupNum(TASK_STAGE_0, num);
  }

  protected void cleanup(String jobId) {
    for (int i=0; i<taskClasses.length; i++) {
      ((TaskRunnable)ClassUtils.newInstance(getTaskClass(i))).clean(jobId, i, this);
    }
  }
  
}
