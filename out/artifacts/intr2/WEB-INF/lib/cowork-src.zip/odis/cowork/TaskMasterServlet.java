package odis.cowork;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.cowork.TaskMasterStatus.ResourceStatus;
import odis.io.ReadWriteUtils;
import odis.tools.ResourceInfo;

import org.apache.velocity.Template;
import org.apache.velocity.context.Context;
import org.apache.velocity.servlet.VelocityServlet;

import toolbox.web.WebServer;

public class TaskMasterServlet extends VelocityServlet {
    
    private static final long serialVersionUID = 1L;
    private static TaskMaster tm = null;
    
    public static void setTaskMaster(TaskMaster tmu) { tm = tmu; }
    
    protected Properties loadConfiguration(ServletConfig conf) throws FileNotFoundException, IOException {
        // setup Velocity        
        Properties p = super.loadConfiguration(conf);
        System.out.println("Absolute path: "+conf.getServletContext().getRealPath("."));
        p.setProperty("file.resource.loader.path", conf.getServletContext().getRealPath("."));
        return p;
    }
    
    protected Template handleRequest(HttpServletRequest req, HttpServletResponse resp, Context ctx) throws Exception {
        req.setCharacterEncoding("UTF-8");  // default is ISO8859
        String cmd = req.getServletPath();
        if (cmd != null)
            cmd = WebServer.trimSlashes(cmd);
        if (cmd == null || cmd.equals("")) { cmd = "tmhome.s"; }
        
        ctx.put("cmd", cmd);
        ctx.put("navbar", "tmleftbar.vm");
        if (tm!=null)
            ctx.put("title", "TaskMaster [" + tm.getHostname() + "]");
        if (cmd.equals("tmhome.s")) {
            doSummary(req, resp, ctx);
        } else if (cmd.equals("tmtaskstack.s")) {
            doShowStack(req, resp, ctx);
        } else if (cmd.equals("tmtasklog.s")) {
            doTaskLog(req, resp, ctx);
        } else {
            doSummary(req, resp, ctx);            
        }
        
        return getTemplate("template.vm");
    }
    
    private static final Date date = new Date();
    private static final SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private void doSummary(HttpServletRequest req, HttpServletResponse resp, Context ctx) {
        ctx.put("content", "tmhome.vm");
        date.setTime(System.currentTimeMillis());
        ctx.put("systime", formatter.format(date));
        ctx.put("taskmaster", tm.getId());
        ResourceStatus rs = tm.getResourceStatus();
        ctx.put("memory", ResourceInfo.byteToMegabit(rs.getAvailableMemory()));
        long[] spaceByte = rs.getAvailableSpace();
        String[] space = new String[spaceByte.length];
        for (int i = 0; i < spaceByte.length; ++i) {
            space[i] = ResourceInfo.byteToMegabit(spaceByte[i]);
        }
        ctx.put("space", space);
        ctx.put("oneMinLoad", rs.getOneMinLoad());
        ctx.put("swap", ResourceInfo.byteToMegabit(rs.getSwapUsed()));
        ctx.put("processers", rs.getProcessers());
        ctx.put("loadRate", rs.getLoadRate());
    }    
    
    synchronized private void doShowStack(HttpServletRequest req, HttpServletResponse resp, Context ctx) {
        String taskId = req.getParameter("task");
        if(taskId == null) {
            ctx.put("content", "message.vm");
            ctx.put("error", "You must specify a task!");
            return;
        }
        ctx.put("task", taskId);
        
        TaskInProgress tip = null;
        for(String tid : tm.tips.keySet()) {
            if(tid.startsWith(taskId)) {
                tip = tm.tips.get(tid);
                break;
            }
        }
        if(tip == null) {
            ctx.put("content", "message.vm");
            ctx.put("error", "Task is not running!");
            return;
        }
        
        StringBuilder message = new StringBuilder();
        BufferedReader reader = null;
        try {
            Runtime runtime = Runtime.getRuntime();
            String[] args = new String[] {
                "/bin/bash", "-c", "jstack " + tip.getPID()
            };
            Process proc = runtime.exec(args);

            reader = new BufferedReader(new InputStreamReader(
                    proc.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.replaceAll("at ", "<font color=\"red\">at </font>");
                message.append(line).append("<BR>\n");
            }
        } catch (Exception e) {
            ctx.put("content", "message.vm");
            ctx.put("error", "jstack the task error!");
            return;
        } finally {
            ReadWriteUtils.safeClose(reader);
        }
        
        ctx.put("stack", message);
        ctx.put("content", "tmtaskstack.vm");
    }
    
    private static String taskId = null;
    private void doTaskLog(HttpServletRequest req, HttpServletResponse resp, Context ctx) {
        String lineLimit = req.getParameter("line");
        int lineNum = 500;
        if(lineLimit != null)
            lineNum = Integer.parseInt(lineLimit);
        
        taskId = req.getParameter("task");
        if(taskId == null) {
            ctx.put("content", "message.vm");
            ctx.put("error", "You must specify a task!");
            return;
        }
        ctx.put("task", taskId);
        
        File[] logPaths = null;
        try {
            File taskLogDir = new File(tm.logDir,
                    CoWorkUtils.getTaskLogSubDirName(taskId));
            logPaths = taskLogDir.listFiles(new FileFilter() {
                @Override
                public boolean accept(File file) {
                    if (file.getName().startsWith(taskId)
                            && (file.getName().equals(taskId) || file.getName().charAt(
                                    taskId.length()) == '-'))
                        return true;
                    return false;
                }
            });
        } catch (Exception e) {
            ctx.put("content", "message.vm");
            ctx.put("error", "Can not list files of task log dir!");
            return;
        }
        
        StringBuilder log = new StringBuilder();
        if(logPaths.length == 0) {
            ctx.put("content", "message.vm");
            ctx.put("error", "Can not find any log file of task(" + taskId + ")!");
            return;
        }
        else if(logPaths.length > 1) {
            log.append("<h3>请选择log文件：</h3><ul>");
            for(int i = 0; i < logPaths.length; i++) {
                String link = "<li><a href=\"tmtasklog.s?task=" + logPaths[i].getName() + "&line=500\">" + logPaths[i].getName() + "</a></li>";
                log.append(link);
            }
            log.append("</ul>");
        }
        else {
            BufferedReader in = null;
            try {
                in = new BufferedReader(new InputStreamReader(new FileInputStream(logPaths[0]), "UTF-8"));

                int index = logPaths[0].getName().lastIndexOf('-');
                String task = logPaths[0].getName().substring(0, index);

                int count = 0;
                String line;
                while ((line = in.readLine()) != null) {
                    line = line.replaceAll(task, "<font class=\"important\">"
                            + task + "</font>");
                    line = line.replaceAll("Exception",
                            "<font class=\"error\">Exception</font>");
                    line = line.replaceAll("Error",
                            "<font class=\"error\">Error</font>");
                    log.append(line).append("<BR>");
                    count++;
                    if (count > lineNum) {
                        log.delete(0, log.indexOf("<BR>") + 4);
                        count--;
                    }
                }
            } catch (Exception e) {
                ctx.put("content", "message.vm");
                ctx.put("error", "Can not read the file(" + taskId + ")!");
                return;
            } finally {
                ReadWriteUtils.safeClose(in);
            }
        }
        ctx.put("log", log.toString());
        ctx.put("content", "tmtasklog.vm");
    }
}
