/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.LogFormatter;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import toolbox.misc.ClassUtils;

/**
 * A writable class which contains configuration of a specific job <code>
 * hack: JobConfig MUST extend {@link PropertiesConfiguration} for cluster evaluation to run properly.
 * hack: Becaue only {@link PropertiesConfiguration} uses {@link org.apache.commons.configuration.SubsetConfiguration}
 * hack: for subset method.
 * hack: See <code>TestJobConfig</code> in test case </code>
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */

@SuppressWarnings("serial")
public class JobConfig extends PropertiesConfiguration implements IWritable {

    protected static final Logger LOG = LogFormatter.getLogger(JobConfig.class
            .getName());

    protected JobDef jobDef;

    // //////////////////////////////////////////////////////////////////////////
    // constructor
    // //////////////////////////////////////////////////////////////////////////
    public JobConfig() { // must be followed by loadXml() or use as Writable
        super();
    }

    protected JobConfig(JobDef jobDef) {
        super();
        this.jobDef = jobDef;
    }

    public void setBoolean(String name, boolean value) {
        setProperty(name, value + "");
    }

    public void setInt(String name, int value) {
        setProperty(name, value + "");
    }

    public void setLong(String name, long value) {
        setProperty(name, value + "");
    }

    public void setFloat(String name, float value) {
        setProperty(name, value + "");
    }

    public void setDouble(String name, double value) {
        setProperty(name, value + "");
    }

    public void setConfig(String name, Configuration config) {
        Iterator it = config.getKeys();
        while (it.hasNext()) {
            String key = (String) it.next();
            setProperty(name + "." + key, config.getProperty(key));
        }
    }

    public Configuration getConfig(String name) {
        return subset(name);
    }

    public Class getPropClass(String propertyName, Class xface,
            Class defaultValue) {
        String clsName = this.getString(propertyName);
        if (clsName == null)
            return defaultValue;
        return ClassUtils.getClass(clsName, xface);
    }

    @SuppressWarnings("unchecked")
    public void setPropClass(String propertyName, Class theClass, Class xface) {
        if (!xface.isAssignableFrom(theClass))
            throw new RuntimeException(theClass + " is not " + xface.getName());
        setProperty(propertyName, theClass.getName());
    }

    private static final String PROP_JOBDEF_CLASS = "jobconf.jobdef_class";

    private static final String UTF_MAGIC_STRING = "COWORK_IS_A_MAGIC_PLATFORM";

    // 这个字符串用来决定writeField()/readFields()的读入版本

    protected StringWriter writeToString() throws IOException {
        // write registry data
        StringWriter writer = new StringWriter();
        try {
            // NOTE: in JobMaster, when task masters come to get a task, job
            // master
            // use RPC to send back JobConfig. The JobConfig object there is
            // shared
            // by all tasks. Here, saveConfig() will modify JobConfig and save()
            // will
            // read JobConfig. The read/write are came from different RPC
            // threads
            // this cause ConcurrentModificaitonException.
            synchronized (this) {
                this.jobDef.saveConfig();
                if (!containsKey(PROP_JOBDEF_CLASS))
                    setProperty(PROP_JOBDEF_CLASS, jobDef.getClass().getName());
                save(writer);
            }
            return writer;
        } catch (ConfigurationException e) {
            throw new IOException(e.toString());
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        // write job definition class name
        out.writeUTF(jobDef.getTypeClass());
        StringWriter writer = writeToString();
        out.writeUTF(UTF_MAGIC_STRING);
        StringWritable.writeString(out, writer.toString()); // out.writeUTF(writer.toString());
    }

    // load only type class
    public void readFields(DataInput in) throws IOException {
        // type class instead of real class: for job master to load only type
        // class
        Class typeClass = ClassUtils.getClass(in.readUTF(), JobDef.class);
        jobDef = (JobDef) ClassUtils.newInstance(typeClass);
        String conf = in.readUTF();
        if (UTF_MAGIC_STRING.equals(conf))
            conf = StringWritable.readString(in);
        StringReader reader = new StringReader(conf);
        try {
            load(reader);
        } catch (ConfigurationException e) {
            throw new IOException(e.toString());
        }
        this.jobDef.loadConfig(this);
    }

    public IWritable copyFields(IWritable value) {
        JobConfig that = (JobConfig) value;
        // properties
        StringWriter writer = new StringWriter();
        try {
            that.save(writer);
        } catch (ConfigurationException e) {
            throw new RuntimeException(e);
        }
        StringReader reader = new StringReader(writer.toString());
        try {
            load(reader);
        } catch (ConfigurationException e) {
            throw new RuntimeException(e);
        }
        // jobDef
        this.jobDef = (JobDef) ClassUtils.newInstance(that.jobDef.getClass());
        this.jobDef.loadConfig(this);
        return this;
    }

    // load real class
    protected void loadPropertiesConf(File config) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(config));
        try {
            load(reader);
        } catch (ConfigurationException e) {
            throw new IOException(e.toString());
        }
        String confClassName = getString(PROP_JOBDEF_CLASS, null);
        Class defClass = ClassUtils.getClass(confClassName, JobDef.class);
        this.jobDef = (JobDef) ClassUtils.newInstance(defClass);
        this.jobDef.loadConfig(this);
    }

    protected void savePropertiesConf(File config) throws IOException {
        // save all configuration
        this.jobDef.saveConfig();
        // save real class if it is not set
        if (!containsKey(PROP_JOBDEF_CLASS))
            setProperty(PROP_JOBDEF_CLASS, jobDef.getClass().getName());
        BufferedWriter writer = new BufferedWriter(new FileWriter(config));
        try {
            save(writer);
        } catch (ConfigurationException e) {
            throw new IOException(e.toString());
        }
    }

    public JobDef getJobDef() {
        return jobDef;
    }

    public void setJobDef(JobDef jobDef) {
        this.jobDef = jobDef;
    }
    
    
}
