package odis.cowork;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import odis.io.InterProcessBuffer;
import toolbox.misc.LogFormatter;

/**
 * TODO Add java-doc
 * 
 * @author zl
 *
 */
public class CursorBuffer extends InterProcessBuffer {

    private Logger LOG = LogFormatter.getLogger(CursorBuffer.class);
    private final static int RETRY_LIMIT = 1000;

    private long cursor, time;

    /**
     * The constructor.
     * 
     * @param file
     * @param mode
     * @throws IOException
     */
    public CursorBuffer(File file, String mode) throws IOException {
        super(file, mode, Integer.SIZE + Long.SIZE + Long.SIZE);
    }
    /**
     * Read the buffer.
     */
    public void read() {
        long prevVersion, afterVersion;
        int retry = 0;
        while (true) {
          prevVersion = super.readVersion();
          cursor = buffer.getLong();
          time = buffer.getLong();
          afterVersion = super.readVersion();
          if (prevVersion==afterVersion) return;
          if (retry++>RETRY_LIMIT) {
              LOG.severe("BUG: retried " + RETRY_LIMIT + " times for cursor");
              cursor = TaskRunnable.NON_CURSOR;
              // we don't reset time here since time is not very critical
          }
        }        
    }
    /**
     * Write cursor and time to the buffer
     * @param c
     * @param t
     */
    public void write(long c, long t) {
        super.writeVersion();
        buffer.putLong(c);
        buffer.putLong(t);
    }
    
    public long getCursor() { return cursor; }
    public long getTime() { return time; }
      
  }
