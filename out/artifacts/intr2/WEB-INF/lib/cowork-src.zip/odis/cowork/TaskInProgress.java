/**
 * @(#)TaskInProgress.java, 2012-12-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.cowork.IJobMasterProtocol.TaskState;
import odis.io.ReadWriteUtils;
import odis.rpc2.RpcException;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

/**
 * Move from TaskMaster
 * 
 * @author chenheng
 *
 */
class TaskInProgress {

    private static final Logger LOG = LogFormatter.getLogger(TaskInProgress.class);
    protected static final long JVM_DUMP_TIME = CoworkConfig.conf()
            .getLong("cowork.taskmaster.jvm-dump-time", UnitUtils.SECOND * 10);
    protected static final long TASK_LOG_LIMIT = CoworkConfig.conf()
            .getLong("cowork.taskmaster.log.task-log", UnitUtils.M * 25);

    public static final int STARTING = 0;
    public static final int RUNNING = 1;
    public static final int CLOSE = 2;
    
    // definitions
    final TaskDef task;

    private TaskMaster taskMaster = null;
    
    private final JobConfig jobConf;

    private final String sessionId;

    // running thread
    final TaskThread runningThread;

    // private final CheckThread checkThread; //the thread to check task
    // process's resource usage
    private String pid; // pid of the running process

    // information from jobmaster
    // private String[] prevWorkers; // input of this task
    private List<TaskCompletionEvent> preStageEvents = new ArrayList<TaskCompletionEvent>();

    boolean update; // received update command just now?

    // status related information (from task worker)
    TaskReport status; // status that will be report to jobmaster

    private CursorBuffer cursor; // cursor information from task worker

    long reportTime; // last report time, last cursor position
    // private int taskStatus;

    // set where done() is called
    private int doneCode; // done code: success of fail

    private String doneMsg; // message returned along with done code

    private long jvmDumpTime; // time that start to dump jvm
    // private String[] completionPaths;
    public int state = CLOSE;
    
    public TaskInProgress(TaskDef t, TaskCompletionEvent[] lastEvents,
            JobConfig jc, boolean preparing, TaskMaster taskMaster) {
        // definition
        task = t;
        jobConf = jc;
        sessionId = CoWorkUtils.generate();
        this.taskMaster = taskMaster;
        // running thread
        runningThread = new TaskThread(this);
        // checkThread = new CheckThread(this);
        pid = null;
        // status info
        // prevWorkers = lastMachs;
        update = true;
        // status info

        status = new TaskReport(task);
        status.setRunning();
        status.setTaskMasterId(this.taskMaster.id);
        setUpdate(lastEvents);
        reportTime = System.currentTimeMillis();
        cursor = null;
        // done info
        doneCode = -1;
        doneMsg = null;
        jvmDumpTime = 0;
        if (preparing) {
            status.setPreparing();
        }
    }

    public TaskInProgress(TaskDef t, TaskCompletionEvent[] lastEvents,
            JobConfig jc, TaskMaster tm) {
        this(t, lastEvents, jc, false, tm);
    }

    // start running thread
    public void start() {
        runningThread.start();
        // checkThread.start();
    }

    public String getId() {
        return task.getTaskId() + "-" + sessionId;
    }

    public synchronized void setPID(String pid) {
        this.pid = pid;
    }

    public synchronized String getPID() {
        return this.pid;
    }

    public synchronized void setJvmDumpTime(long t) {
        this.jvmDumpTime = t;
    }

    public synchronized long getJvmDumpTime() {
        return this.jvmDumpTime;
    }

    /**
     * Get the snapshot of current status (reported by TaskWorker last time)
     * of this task. Called from both the task master main thread and
     * TaskThread.
     */
    public synchronized TaskReport copyStatus() {
        TaskReport report = new TaskReport();
        report.copyFields(status);
        return report;
    }

    public synchronized void setPreparingFinished() {
        status.setRunning();
    }

    public synchronized void setTaskCancel() {
        status.setCancel();
    }

    public synchronized int getTaskStatus() {
        return status.getState();
    }

    /**
     * @return the task is running job or preparing job.
     */
    public synchronized boolean isPreparing() {
        return status.isPreparing();
    }

    /**
     * Snapshot current state: Called from both the task master main thread
     * and TaskThread.
     */
    public synchronized int getState() {
        return status.getState();
    }

    public synchronized void setUpdate(TaskCompletionEvent[] newEvents) {
        if (newEvents.length == 0)
            return;
        // 为什么上一次的最后一个元素要和当前事件的第一个一致
        int lastIdx = getLastEventIdx();
        if (lastIdx != newEvents[0].getEventIdx()) {
            LOG.warning("BUG: Cueent events:" + preStageEvents.toString());
            LOG.warning("New Coming:" + Arrays.toString(newEvents));
        }

        // FIX: not add the first element, by chenheng
        if (preStageEvents.size() > 0) {
            for (int i = 1; i < newEvents.length; i++) {
                preStageEvents.add(newEvents[i]);
            }
        } else {
            for (int i = 0; i < newEvents.length; i++) {
                preStageEvents.add(newEvents[i]);
            }
        }

        status.setLastPreStageEventIdx(getLastEventIdx());
        update = true;

        LOG.info("@@TaskMaster_setUpdate@@ taskId = "
                + this.task.getTaskId() + ", preStageEvents is "
                + preStageEvents);
    }

    public synchronized int getLastEventIdx() {
        int lastIdx = 0;
        if (preStageEvents.size() > 0)
            lastIdx = preStageEvents.get(preStageEvents.size() - 1)
                    .getEventIdx();
        return lastIdx;
    }

    protected synchronized TaskCompletionEvent[] getTaskEvents(int from,
            int max) {
        if (preStageEvents.size() < from + 1) {
            return TaskCompletionEvent.EMPTY_EVENTS;
        } else {
            List<TaskCompletionEvent> events = preStageEvents.subList(from,
                    preStageEvents.size());
            LOG.info("@@TaskMaster_getTaskEvents@@ taskId = "
                    + this.task.getTaskId() + "," + events + ", from "
                    + from + " to " + preStageEvents.size());
            return events.toArray(new TaskCompletionEvent[events.size()]);
        }
    }

    // public synchronized void setUpdate(String[] lastMachs) {
    // prevWorkers = lastMachs; update = true;
    // }
    public synchronized void clearUpdate() {
        update = false;
    }

    /** Force this task to end. Called from main thread */
    public synchronized void interrupt() {
        assert (runningThread != null);
        final long waitT = (jvmDumpTime + JVM_DUMP_TIME)
                - System.currentTimeMillis();
        new Thread() {
            public void run() {
                if (waitT > 0)
                    try {
                        Thread.sleep(waitT);
                    } catch (InterruptedException e) {}
                runningThread.kill();
                if (runningThread.getKilledCounter() > 2)
                    runningThread.interrupt();
            }
        }.start();
    }

    /**
     * Update progress of this task. Called from RPC thread for TaskWorker
     */
    public synchronized void progress(float f, CounterMap counter,
            boolean isCheck, int[] partResultCount) {
        if (!(status.isRunning() || status.isPreparing()))
            // Occassionally, we get this warning because we first get this
            // RPC call
            // and put it inqueue and RPC thread is swap out from CPU; then
            // we
            // execute delete() in the main thread and set status as delete.
            // Later, the RPC thread grabs CPU again and try to progress().
            // It
            // finds that the status is not running anymore.
            // So, this warning is not a big issue. -- Li
            LOG.info("Skip updating task (" + task.getTaskId()
                    + ") which is not running/preparing: "
                    + status.getStateString());
        else {
            long prevCursor = status.getCursor();
            readCursor();
            status.setProgress(f);
            status.addCounters(counter);
            status.setPartResultCount(partResultCount);
            // only update report time when no progress check is needed or
            // cursor moved
            if (status.getCursor() > prevCursor || !isCheck)
                reportTime = System.currentTimeMillis();
        }
    }

    /** Set this task as done. Called from RPC thread from TaskWorker */
    public synchronized void done(int doneCode, String msg) {
        if (!status.isRunning())
            throw new RuntimeException("BUG: done() for task ("
                    + task.getTaskId() + ") which is not running.");
        if (TaskState.isFinished(this.doneCode))
            throw new RuntimeException("BUG: done() for task ("
                    + task.getTaskId()
                    + ") whose done code was set as finished.");
        this.doneCode = doneCode;
        this.doneMsg = msg;
        if (!TaskState.isFinished(doneCode))
            throw new RuntimeException(
                    "BUG: The doneCode is not a valid finish code: "
                            + status.getStateString());
        this.notify(); // in case some one is waitForDone()
    }

    /**
     * Wait 3s for the isDone flag and set the status either success of
     * fail. Called from the TaskThread after the child worker process is
     * returned. Notice that we donot update any status before the end of
     * waitForDone().
     */
    public synchronized void finish() {
        long start = System.currentTimeMillis();
        // Wait until task reports as done. If it hasn't reported in,
        // wait for a second and try again.
        while (!TaskState.isFinished(this.doneCode)) {
            if (System.currentTimeMillis() - start > taskMaster.WAIT_FOR_DONE)
                break;
            try {
                this.wait(taskMaster.WAIT_FOR_DONE);
            } catch (InterruptedException e) {}
        }
        if (!TaskState.isFinished(this.doneCode)) {
            // done code is not set, which means done() is not called
            String msg = this.task.getTaskId() + " returned at state "
                    + status.getStateString();
            status.setState(IJobMasterProtocol.TASK_STATE_FAIL);
            status.setMsg(msg);
        } else {
            // use the previously set done code
            status.setState(this.doneCode);
            status.setMsg(this.doneMsg);
            if (status.isSuccess()) {
                if (!runningThread.installFiles()) {
                    LOG.warning("Failed to install task dir from: "
                            + runningThread.taskRunDir);
                    status.setState(IJobMasterProtocol.TASK_STATE_FAIL);
                    status.setMsg(this.doneMsg
                            + ": failed to install dir after success");
                }
            }
        }
        // read cursor to get the done position
        readCursor();
    }

    /**
     * Close this task and clear files. Called by main thread and
     * TaskThread. Do background deleting
     */
    public synchronized void close() {
        try {
            if (cursor != null)
                cursor.close();
        } catch (IOException e) {
            LOG.log(Level.WARNING,
                    "Failed to close cursorBuffer for reading task "
                            + this.getId());
        }
        LOG.info("Background deleting " + runningThread.taskRunDir);
        final File dir = runningThread.taskRunDir;
        Thread thread = new Thread() {
            public void run() {
                try {
                    ReadWriteUtils.fullyDelete(dir);
                } catch (IOException e) {
                    LOG.log(Level.WARNING, "Cannot delete localTaskDir: "
                            + dir, e);
                }
            }
        };
        thread.start();
    }

    private void readCursor() {
        if (cursor == null)
            try {
                LOG.info("Create cursor buffer for read at "
                        + System.currentTimeMillis());
                cursor = new CursorBuffer(new File(
                        runningThread.taskRunDir, TaskWorker.CURSOR_FILE),
                        "r");
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Interrupting task " + this.getId()
                        + " because cursor cannot be read.", e);
                this.interrupt();
                return;
            }
        cursor.read();
        status.setCursorTime(cursor.getCursor(), cursor.getTime());
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("id:").append(this.getId())
        .append(", status:").append(this.status)
        .append(", state:").append(this.state);
        
        return sb.toString();
    }
    
    
    /**
     * @return the jobConf
     */
    public JobConfig getJobConf() {
        return jobConf;
    }

    /**
     * The thread used to start a new task. TaskThread exist in the process of
     * TaskMaster and can access local states of task master. Each TaskThread
     * belongs to exactly one TaskInProgress.
     */
    public class TaskThread extends Thread {
        private File taskLogDir;

        // running states
        private Process process; // worker process (not run in process)

        private TaskWorker worker; // worker object (run in process)

        // definitions
        private final TaskInProgress tip;// task-inprogress that will start me

        // session information
        private int taskTmpDirsIdx; // the temp directory used

        private File taskRunDir; // local temp directory for the task

        private File logRunFile; // log, std out & err file for this task

        // task master flag
        boolean isQuitAll; // quit the whole taskmaster

        protected boolean isInterrupt; // whether this task was interrupted

        protected final byte[] isInterruptLock = new byte[0];

        protected volatile int killedCounter = 0;

        public TaskThread(TaskInProgress tip) {
            this.tip = tip;
            setName(tip.task.getStageId());
            isQuitAll = false;
            process = null;
            worker = null;
            isInterrupt = false;
            // use the most least used temp directory
            // 起点随机：保证如果disk个数多于cpu/worker个数的时候所有的磁盘都能用到
            LOG.info(taskMaster.taskTmpDirsCount.length + "");
            int startIdx = taskMaster.RAND.nextInt(taskMaster.taskTmpDirsCount.length);
            taskTmpDirsIdx = startIdx;
            for (int i = 0; i < taskMaster.taskTmpDirsCount.length; i++) {
                int idx = (startIdx + i) % taskMaster.taskTmpDirsCount.length;
                if (taskMaster.taskTmpDirsCount[idx] < taskMaster.taskTmpDirsCount[taskTmpDirsIdx])
                    taskTmpDirsIdx = idx;
            }
            taskMaster.taskTmpDirsCount[taskTmpDirsIdx]++;
            // note: for atomic write, use a random directory as taskDir
            taskRunDir = new File(taskMaster.taskTmpDirs[taskTmpDirsIdx], this.tip.getId());
            if (taskMaster.logDir != null) {
                taskLogDir = new File(taskMaster.logDir, CoWorkUtils
                        .getTaskLogSubDirName(tip.getId()));
                if (!taskLogDir.exists() && !taskLogDir.mkdirs()) // in case of
                                                                  // manual
                                                                  // deleting
                    LOG.severe("Error: Dir " + taskLogDir + " make failed.");
                logRunFile = new File(taskLogDir, this.tip.getId());
            } else
                logRunFile = null;
        }

        /** main process of TaskThread */
        public void run() {

            // prepare
            try {
                LOG.info("Starting TaskThread of " + tip.getId() + " ...");

                // 1. clear local dir
                if (taskRunDir.exists()) {
                    ReadWriteUtils.fullyDelete(taskRunDir);
                    LOG.info("Local directory " + taskRunDir + " is cleared");
                } else if (!taskRunDir.mkdirs()) {
                    LOG.severe("ERROR: Dir " + taskRunDir + " make failed.");
                }
                if (!taskMaster.isRun)
                    return; // checkpoint

                // 2. save job.conf to local
                File localJobFile = new File(taskRunDir, "job.conf");
                tip.jobConf.savePropertiesConf(localJobFile);
                LOG.info("JobConf is saved to local: " + localJobFile);
            } catch (Throwable t) {
                LOG.log(Level.WARNING, "TaskThread preparing error: ", t);
                isQuitAll = true;
            }
            
            if (!resourceSatify(task)) {
                return;
            }
            
            
            // real running
            try {
                if (isQuitAll)
                    return; // task master dis problem, return!!
                // 3. run inside this thread or run in child process
                if (taskMaster.isInProcess) { // run in process
                    LOG.fine("Run task " + tip.getId() + " in progress");
                    runInProcess();
                } else { // run in child
                    // use same jvm as parent
                    File jvm = new File(new File(System
                            .getProperty("java.home"), "bin"), "java");
                    // run java
                    JobDef job = tip.jobConf.jobDef;
                    String[] commandLine = new String[] {
                        jvm.toString(),
                        "-server",
                        "-Dfile.encoding=UTF-8",
                        "-Dodis.local="
                                + CoworkConfig.get().getOdisServiceLocal(), // odis
                                                                                // .
                                                                                // local
                        job.getTaskJavaConfig(taskMaster.heapLimit,
                                tip.task.getResourceNeed()), // jvm config (e.g.
                                                             // heap size)
                        job.getTaskHeapProfile(tip.task.getTaskId()),// heap
                                                                     // profile?
                        job.getTaskRemoteDebug(tip.task.part), // remote debug?
                        "-Dpid=$$", // for child to get its pid
                        "-cp", job.getTaskClassPath(), // class path
                        TaskWorker.class.getName(), // running class
                        taskMaster.taskPort + "", // pass umbilical port
                        tip.getId(), // pass task-in-progress identifier
                        taskRunDir.getPath(), // local tmp dir
                        logRunFile == null ? null : logRunFile.getPath()
                    // log file for this task
                    };
                    String cmd = concatString(commandLine, " ");
                    LOG.fine("Child command line: " + cmd);
                    // set working directory as the taskLogDir such that JVM
                    // crash error
                    // log will be written there -- Li 1/25/2007
                    runInChild(new String[] {
                        "/bin/bash", "-c", cmd
                    }, this.taskLogDir);
                    LOG.info("Worker process of " + tip.getId() + " returned.");
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "TaskThread of " + tip + " wrong: ", e);
            } finally {
                finishTask();
                taskMaster.taskTmpDirsCount[taskTmpDirsIdx]--;
                synchronized (taskMaster.doneKnob) {
                    taskMaster.doneKnob.notify();
                }
            }

        }

        private boolean resourceSatify(TaskDef task) {
            // TODO Auto-generated method stub
            return true;
        }

        protected int getKilledCounter() {
            return killedCounter;
        }

        /**
         * Kill the child worker if not run in process. Kill must be succeed in
         * any case. In order to guanrantee this, we first do process.destroy()
         * and then "kill -9".
         * 
         * @throws IOException
         */
        private void kill() {
            if (taskMaster.isInProcess) {
                if (this.isAlive())
                    LOG.info("Cannot stop IN_PROCESS TaskThread of " + tip
                            + ", let it be.");
                else
                    LOG.info("IN_PROCESS TaskThread is not alive any more.");
            } else {
                ++killedCounter;
                if (process == null) {
                    LOG.info("kill (" + tip.getId()
                            + ") failed for process is NULL!");
                    return;
                }
                // only one killing-in-progress (set isInterrupt) at a time
                synchronized (isInterruptLock) {
                    if (!isInterrupt) {
                        // try to destroy process normally
                        process.destroy();
                        isInterrupt = true;
                    } // if isInterrupt ...
                }
                // isInterrupt must be true here: check whether process's
                // exitValue
                try {
                    // wait 1.5s for the process to be destroyed
                    try {
                        Thread.sleep(taskMaster.WAIT_FOR_KILL);
                    } catch (InterruptedException e) {}
                    int error = process.exitValue();
                    LOG.info("TaskWorker process (" + tip.getId()
                            + ") was destroyed normally (code=" + error + ")");
                } catch (IllegalThreadStateException ie) {
                    LOG.warning("Failed to destroy TaskWorker process ("
                            + tip.getId()
                            + ") normally, use \"kill -9\" instead");
                    // process was not destroyed, try to use kill -9
                    if (tip.getPID() == null) {
                        LOG.warning("\"kill -9\": No pid found for " + tip
                                + ", killedCounter=" + killedCounter);
                    } else {
                        String bashCmd = "kill -9 " + tip.getPID();
                        try {
                            Process proc = Runtime.getRuntime().exec(
                                    new String[] {
                                        "/bin/bash", "-c", bashCmd
                                    });
                            int error = proc.waitFor();
                            if (error != 0)
                                LOG.warning("\"" + bashCmd + "\": error="
                                        + error);
                        } catch (Exception e) {
                            LOG.log(Level.SEVERE, "Cannot exec \"" + bashCmd
                                    + "\"", e);
                        }
                    }
                } // catch exception
            } // else
        }

        /** Run task worker in this thread */
        private void runInProcess() throws IOException {
            worker = new TaskWorker(taskMaster, tip.getId(), taskRunDir
                    .getPath(), logRunFile != null, true);
            worker.run();
        }

        /** Run the child process */
        private void runInChild(String[] args, File dir) throws Exception {
            boolean finished = false;
            this.process = Runtime.getRuntime().exec(args, tip.jobConf.jobDef.getEnvp(), dir);
            PrintWriter writer = null;
            if (logRunFile != null) // write log, std out & err
                writer = new PrintWriter(new FileWriter(logRunFile), true);

            try {
                logStream(process.getErrorStream(), writer); // copy log output
                logStream(process.getInputStream(), writer); // normally empty
                int error = this.process.waitFor();
                if (error != 0) {
                    synchronized (isInterruptLock) {
                        if (isInterrupt)
                            LOG.warning("Task process " + tip.getId()
                                    + " was forcefully interrupted");
                        else
                            throw new RuntimeException(
                                    "Worker process terminate abnormally, error="
                                            + error);
                    }
                }
                finished = true;
            } finally {
                if (!finished)
                    kill(); // kill child process
                if (writer != null)
                    writer.close();
            }
        }

        /**
         * The process of child worker in this TaskThread has already
         * terminated. At this time, the task-in-progress is still in
         * runningTasks. Use this function to change the state of the task in
         * task master: - Task is terminated because of some forcefully
         * interruption - Task is terminated because of child returned
         * successfully or failed. In this situation, wait 3s for the done()
         * flag.
         */
        private void finishTask() {
            int taskState = tip.getState();
            assert TaskState.isAssigned(taskState);
            if (taskMaster.tips.get(tip.getId()) == null) { // was removed from tips by DEL
                                                 // command
                LOG.info("Finished TaskThread of " + tip
                        + " after it was forcefully removed from queue.");
                tip.close();
            } else { // is now in tips
                // task worker (process) instance was returned normally without
                // getting
                // any DEL command. Need to wait for at most 3s for the done()
                // is
                // called -- delay might be introduced by RPC, abort(), etc.
                long now = System.currentTimeMillis();
                tip.finish();
                LOG.info("Finished TaskThread of " + tip + " as "
                        + TaskState.getState(taskState) + ". (wait-for-done="
                        + (System.currentTimeMillis() - now) + "ms)");
                // notify tips who might be waiting me finish
                synchronized (taskMaster.tips) {
                    taskMaster.tips.notify();
                }
            }
            taskMaster.tipsLock.lock();
            tip.state = TaskInProgress.CLOSE;
            taskMaster.tipsLock.unlock();
            try {
                LOG.info("release resource id " + task.getResourceID());                
                taskMaster.resourceClient.releaseResource(taskMaster.id, task.getResourceID());
            } catch (RpcException e) {
                LOG.log(Level.WARNING, "", e);
            }
            
        }

        /**
         * Install task run dir and log file
         * 
         * @return whether successfully installed
         */
        private boolean installFiles() {
            File targetTaskDir = new File(taskMaster.taskTmpDirs[taskTmpDirsIdx], tip.task
                    .getTaskId());
            if (targetTaskDir.exists()) {
                LOG.warning("Target tempory dir " + targetTaskDir
                        + " already exists, ignore session tempory dir "
                        + taskRunDir);
                return true;
            }
            boolean isSuccess = taskRunDir.renameTo(targetTaskDir);
            if (isSuccess) { // succeed in moving task dir? then also move
                             // log/std file
                if (logRunFile != null) {
                    // log file
                    File targetLogFile = new File(taskLogDir, tip.task
                            .getTaskId()
                            + "-" + taskMaster.id);
                    boolean isSuccLog = logRunFile.renameTo(targetLogFile);
                    if (isSuccLog)
                        logRunFile = targetLogFile;
                    else
                        LOG.warning("Cannot move log file from " + logRunFile
                                + " to " + targetLogFile);
                }
                taskRunDir = targetTaskDir;
            }
            return isSuccess;
        }

        /** Log stream of "output" to this process */
        private void logStream(final InputStream output,
                final PrintWriter writer) {
            Thread t = new Thread() {
                public void run() {
                    try {
                        long logSize = 0;
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(output));
                        String line;
                        while (in != null && (line = in.readLine()) != null) {
                            if (logSize >= TASK_LOG_LIMIT)
                                continue; // reach log limit
                            if (writer == null)
                                LOG.info(line);
                            else {
                                writer.println(line);
                            }
                            logSize += line.length();
                        }
                        if (logSize >= TASK_LOG_LIMIT) {
                            String msg = "Task log was trucated (size-limit="
                                    + TASK_LOG_LIMIT + " characters) to "
                                    + logSize + " characters";
                            if (writer != null)
                                writer.println(msg);
                            LOG.info(msg);
                        }
                    } catch (IOException e) {
                        LOG.log(Level.WARNING,
                                "Error in logging child process stream", e);
                    }
                }
            };
            t.setDaemon(true);
            t.start();
        }

        private String concatString(String[] ss, String delim) {
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < ss.length; i++) {
                if (ss[i] != null) {
                    if (i != 0)
                        sb.append(delim);
                    sb.append(ss[i]);
                }
            }
            return sb.toString();
        }

    }
}