/**
 * @(#)ComputeSpecs.java, 2012-11-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.IntWritable;

/**
 * 
 * 
 * @author chenheng
 *
 */
public class ComputeSpecs implements IWritable {
    
    private IntWritable cpuNums = new IntWritable(0);
    private IntWritable memoryMB = new IntWritable(0);
    private IntWritable diskGB = new IntWritable(0);
    private IntWritable networkMBps = new IntWritable(0);
    
    public ComputeSpecs(int numCpus) {
        cpuNums.set(numCpus);
    }
    
    public ComputeSpecs() {
    }
    
    @Override
    public IWritable copyFields(IWritable value) {
        if (this == value) {
            return this;
        }
        if (value == null || !(value instanceof ComputeSpecs)) {
            throw new RuntimeException("bad value : " + value);
        }
        ComputeSpecs that = (ComputeSpecs)value;
        this.cpuNums.copyFields(that.cpuNums);
        this.memoryMB.copyFields(that.memoryMB);
        this.diskGB.copyFields(that.diskGB);
        this.networkMBps.copyFields(that.networkMBps);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        this.cpuNums.writeFields(out);
        this.memoryMB.writeFields(out);
        this.diskGB.writeFields(out);
        this.networkMBps.writeFields(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        this.cpuNums.readFields(in);
        this.memoryMB.readFields(in);
        this.diskGB.readFields(in);
        this.networkMBps.readFields(in);
    }

    public IntWritable getCpuNums() {
        return cpuNums;
    }

    public void setCpuNums(int cpuNums) {
        this.cpuNums.set(cpuNums);
    }

    public IntWritable getMemoryMB() {
        return memoryMB;
    }

    public void setMemoryMB(int memoryMB) {
        this.memoryMB.set(memoryMB);
    }

    public IntWritable getDiskGB() {
        return diskGB;
    }

    public void setDiskGB(int diskGB) {
        this.diskGB.set(diskGB);
    }

    public IntWritable getNetworkMBps() {
        return networkMBps;
    }

    public void setNetworkMBps(int networkMBps) {
        this.networkMBps.set(networkMBps);
    }
    
    public void addComputeSpecs(ComputeSpecs cs) {
        setCpuNums(getCpuNums().get() + cs.getCpuNums().get());
        setMemoryMB(getMemoryMB().get() + cs.getMemoryMB().get());
    }
    
    public void delComputeSpecs(ComputeSpecs cs) {
        setCpuNums(getCpuNums().get() - cs.getCpuNums().get());
        setMemoryMB(getMemoryMB().get() - cs.getMemoryMB().get());
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.cpuNums.get()).append(",")
        .append(this.memoryMB.get()).append(",")
        .append(this.diskGB.get()).append(",")
        .append(this.networkMBps.get());
        return sb.toString();
    }
}
