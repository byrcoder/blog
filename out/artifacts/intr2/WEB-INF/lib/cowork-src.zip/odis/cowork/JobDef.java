/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

/**
 * An abstract class that defines a type of a job.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public abstract class JobDef {

    protected static final Logger LOG = LogFormatter.getLogger(JobDef.class
            .getName());

    private static final int DEFAULT_HEAP_SIZE;
    static {
        String arch = System.getProperty("os.arch", "i386");
        if (arch.equalsIgnoreCase("amd64")) {
            DEFAULT_HEAP_SIZE = 1200;
        } else {
            DEFAULT_HEAP_SIZE = 800;
        }
    }

    // Mostly static definitions (some times dynamic, e.g. MrStarJobDef)
    protected String[] stageNames; // the name of each stage

    protected String[] stageXfaces; // the interface class at each stage

    // Dynamic parameters
    // - job name
    // - processing definitions
    // - task definition at each stage
    // - devide the task into taskNumbers[i] pieces at stage i
    // - running parameters
    // - # number of workers and machines
    // - constraints of assigning task onw workers
    protected String jobName; // name of this job

    // parameters defines how the job will be procosed:
    protected String[] taskClasses; // task instance classes at each stage

    protected int[] taskNumbers; // number of tasks at each stage

    // running parameters of this job
    protected int workerNum; // # of workers wanted by this job

    protected int[] taskPerMachine; // max # of tasks on a machine at each stage
                                    // if set as 0, means no limit

    protected boolean[] exclusiveOwn; // if exclusive own the machine

    // Registry of configuration parameters: contains all information about
    // dynamic parameters and the dynamic information related to static
    // definitions.
    private JobConfig config;

    /**
     * Create a JobDef instance. - Static configurations such as "stageNames"
     * and "stageClasses" of the job types with fixed number of stages is
     * speicified in staticDefine() by sub-classes of JobDef. - Dynamic
     * configurations will be loaded by loadConfig() or a clean new "config"
     * will be created. Subclasses should override the {@link #staticDefine()}
     * or {@link #loadConfig(JobConfig) } to define the static/dynamic
     * definitions of a JobDef. There are two ways to load a JobDef: - new
     * ****JobDef(...) and use set****() to set static definition and dynamic
     * parameters. - new ****JobDef() to get an empty JobDef with static
     * definition only and then use loadConfig() to load all dynamic definition
     * and parameters into variables above. After a JobDef is created/setted or
     * loaded, user can change the settings of it. Then, can save the all
     * informations to disk. The storing of a JobDef is by storing the registry
     * "JobConfig". Before registry of JobConfig is saved on disk, the JobConfig
     * will call {@link #saveConfig()} to update the registry.
     */
    public JobDef() {
        staticDefine();
    }

    protected abstract void staticDefine();

    private static final String PROP_JOB_NAME = "jobconf.job_name";

    private static final String PROP_JOB_ID = "jobconf.job.id";

    private static final String PROP_TASK_CLASS = "jobconf.task_class";

    private static final String PROP_TASK_NUMBER = "jobconf.task_number";

    private static final String PROP_WORKER_NUMBER = "jobconf.worker_number";

    private static final String PROP_TASK_PER_MACH = "jobconf.task_per_machine";

    private static final String PROP_EXCLUSIVE_OWN = "jobconf.exclusive_own";

    /**
     * subclass who override this method must first load dynamic definition from
     * conf before call super.loadConfig();
     */
    @SuppressWarnings("unchecked")
    protected void loadConfig(JobConfig conf) {
        assert conf.jobDef == this;
        this.config = conf;
        assert config.getProperty(PROP_JOB_NAME) != null;
        assert config.getProperty(PROP_TASK_CLASS) != null;
        assert config.getProperty(PROP_TASK_NUMBER) != null;
        assert config.getProperty(PROP_WORKER_NUMBER) != null;
        assert config.getProperty(PROP_TASK_PER_MACH) != null;
        assert config.getProperty(PROP_EXCLUSIVE_OWN) != null;

        this.jobName = config.getString(PROP_JOB_NAME, null);

        this.taskClasses = config.getString(PROP_TASK_CLASS, null).split(";");
        assert taskClasses.length == getTotalStage();

        String[] strTaskNum = config.getString(PROP_TASK_NUMBER, null).split(
                ";");
        assert strTaskNum.length == getTotalStage();
        this.taskNumbers = new int[strTaskNum.length];
        for (int i = 0; i < strTaskNum.length; i++)
            this.taskNumbers[i] = Integer.parseInt(strTaskNum[i]);

        this.workerNum = config.getInt(PROP_WORKER_NUMBER, 1);

        String[] strTaskPerMach = config.getString(PROP_TASK_PER_MACH, null)
                .split(";");
        assert strTaskPerMach.length == getTotalStage();
        this.taskPerMachine = new int[strTaskPerMach.length];
        for (int i = 0; i < strTaskPerMach.length; i++)
            this.taskPerMachine[i] = Integer.parseInt(strTaskPerMach[i]);

        String[] strExclOwn = config.getString(PROP_EXCLUSIVE_OWN, null).split(
                ";");
        assert strExclOwn.length == getTotalStage();
        this.exclusiveOwn = new boolean[strExclOwn.length];
        for (int i = 0; i < strExclOwn.length; i++)
            this.exclusiveOwn[i] = Boolean.parseBoolean(strExclOwn[i]);

        // NOTE: remove following: isValid should be checked at JobClient, but
        // this
        // code is running at the server side. should be removed.
        // if (!isValid())
        // throw new
        // RuntimeException("Job definition is not consistant: please check!");
    }

    protected void saveConfig() {
        JobConfig conf = getConfig();
        // NOTE: remove following: isValid should be checked at JobClient, but
        // this
        // code is running at the server side. should be removed.
        // if (!isValid())
        // throw new
        // RuntimeException("Job definition is not consistant: please check!");
        StringBuffer sbTaskClass = new StringBuffer(), sbTaskNumber = new StringBuffer(), sbTaskPerMach = new StringBuffer(), sbExclOwn = new StringBuffer();
        int i;
        for (i = 0; i < getTotalStage() - 1; i++) {
            sbTaskNumber.append(taskNumbers[i] + ";");
            sbTaskClass.append(taskClasses[i] + ";");
            sbTaskPerMach.append(taskPerMachine[i] + ";");
            sbExclOwn.append(exclusiveOwn[i] + ";");
        }
        sbTaskNumber.append(taskNumbers[i]);
        sbTaskClass.append(taskClasses[i]);
        sbTaskPerMach.append(taskPerMachine[i]);
        sbExclOwn.append(exclusiveOwn[i]);

        conf.setProperty(PROP_JOB_NAME, jobName);
        conf.setProperty(PROP_TASK_CLASS, sbTaskClass.toString());
        conf.setProperty(PROP_TASK_NUMBER, sbTaskNumber.toString());
        conf.setProperty(PROP_TASK_PER_MACH, sbTaskPerMach.toString());
        conf.setProperty(PROP_EXCLUSIVE_OWN, sbExclOwn.toString());

        conf.setInt(PROP_WORKER_NUMBER, workerNum);
    }

    /**
     * Get the type name of a job definition
     */
    protected abstract String getTypeName();

    protected abstract String getTypeClass();

    /**
     * Get stage properties. Note that we do not allow any method to set
     * stageNames or stageClasses. Since these are the two properties define a
     * type of "JobDef". They the "nature" of a JobDef such that they are born
     * with a subclass of JobDef after staticDefine() and loadConfig();
     */
    public int getTotalStage() {
        return stageXfaces.length;
    }

    protected String getStageName(int stage) {
        return stageNames[stage];
    }

    @SuppressWarnings("unchecked")
    protected Class<? extends TaskRunnable> getStageXfaceClass(int stage) {
        return (Class<? extends TaskRunnable>) ClassUtils.getClass(
                stageXfaces[stage], TaskRunnable.class);
    }

    /**
     * Get the configuration registry. If the registry is not created yet,
     * create it. The sub-class of JobDef can only access "config" through this
     * method.
     */
    public JobConfig getConfig() {
        if (config == null) {
            config = new JobConfig(this);
        }
        return config;
    }

    // ///////////////////////////////////////////////////////////////////////////
    // Setting/Getting dynamic parameters
    // ///////////////////////////////////////////////////////////////////////////

    // job name
    public void setJobName(String s) {
        if (s.indexOf(' ') > 0)
            throw new RuntimeException("Spaces are not allowed in job names.");
        this.jobName = s;
    }

    public String getJobName() {
        return this.jobName;
    }

    // task class instance at each stage
    @SuppressWarnings("unchecked")
    protected void setTaskClass(int stage, Class<? extends TaskRunnable> c) {
        if (stage >= getTotalStage())
            throw new RuntimeException("Only support " + getTotalStage()
                    + " stage of computing.");
        if (!getStageXfaceClass(stage).isAssignableFrom(c))
            throw new RuntimeException("Class " + c.getName()
                    + " is not assignable to " + getStageXfaceClass(stage));
        taskClasses[stage] = c.getName();
    }

    @SuppressWarnings("unchecked")
    protected Class<? extends TaskRunnable> getTaskClass(int stage) {
        return (Class<? extends TaskRunnable>) ClassUtils.getClass(
                taskClasses[stage], getStageXfaceClass(stage));
    }

    public TaskDef[] getTaskDefs(String jobId, int stage) throws IOException {
        TaskDef[] result = new TaskDef[getTaskNumber(stage)];
        for (int i = 0; i < result.length; i++)
            try {
                result[i] = new TaskDef(stageXfaces[stage], taskClasses[stage],
                        jobId, stage, i);
            } catch (Exception e) {
                throw new IOException(
                        "Wrong definition in job conf: cannot get task instance: "
                                + e);
            }
        return result;
    }

    // number of task pieces at each stage
    protected void setTaskNumber(int stage, int num) {
        if (stage >= getTotalStage())
            throw new RuntimeException("Only support " + getTotalStage()
                    + " stage of computing.");
        taskNumbers[stage] = num;
    }

    public int getTaskNumber(int stage) {
        return taskNumbers[stage];
    }

    // worker numbers
    public void setWorkerNumber(int wn) {
        workerNum = wn;
    }

    public int getWorkerNumber(int max) {
        return workerNum > max ? max : workerNum;
    }

    // task concurrently running on a machine
    public void setTaskPerMachine(int stage, int num) {
        if (stage >= getTotalStage())
            throw new RuntimeException("Only support " + getTotalStage()
                    + " stage of computing.");
        taskPerMachine[stage] = num;
    }

    protected int getTaskPerMachine(int stage) {
        if (stage >= getTotalStage())
            throw new RuntimeException("Only support " + getTotalStage()
                    + " stage of computing.");
        return (taskPerMachine[stage] > 0 ? taskPerMachine[stage]
                : Integer.MAX_VALUE);
    }

    // whether to do exclusive reservation
    public void setExclusiveOwn(int stage) {
        exclusiveOwn[stage] = true;
    }

    protected boolean isExclusiveOwn(int stage) {
        return exclusiveOwn[stage];
    }

    // compute minimum task per machine requirement
    public int minTaskPerMachine() {
        int taskNum = Integer.MAX_VALUE;
        for (int i = 0; i < getTotalStage(); i++) {
            int t = getTaskPerMachine(i);
            if (t < taskNum)
                taskNum = t;
        }
        return taskNum == Integer.MAX_VALUE ? 0 : taskNum;
    }

    protected int minExclTaskPerMachine() {
        int taskNum = Integer.MAX_VALUE;
        for (int i = 0; i < getTotalStage(); i++) {
            int t = getTaskPerMachine(i);
            if (isExclusiveOwn(i) && t < taskNum)
                taskNum = t;
        }
        return taskNum == Integer.MAX_VALUE ? 0 : taskNum;
    }

    // check whether the static definition and dynamic parameters are consistant
    protected boolean isValid() {
        if (stageXfaces == null) {
            LOG.warning("Invalid JobDef: stageXfaces==null");
            return false;
        } else if (stageNames == null
                || stageNames.length != stageXfaces.length) {
            LOG.warning("Invalid JobDef: check stageNames.");
            return false;
        } else if (taskNumbers == null
                || taskNumbers.length != stageXfaces.length) {
            LOG.warning("Invalid JobDef: check taskNumbers.");
            return false;
        } else if (taskClasses == null
                || taskClasses.length != stageXfaces.length) {
            LOG.warning("Invalid JobDef: check taskClasses.");
            return false;
        } else if (taskPerMachine == null
                || taskPerMachine.length != stageXfaces.length) {
            LOG.warning("Invalid JobDef: check taskPerMachine.");
            return false;
        } else {
            for (int i = 0; i < stageNames.length; i++)
                if (stageNames[i] == null) {
                    LOG.warning("Invalid: name at stage " + i
                            + " is not assigned");
                    return false; // stages must be assigned names
                }
            for (int i = 0; i < taskClasses.length; i++)
                if (taskClasses[i] == null) {
                    LOG.warning("Invalid: task class at stage " + i
                            + " is not assigned");
                    return false; // stages must be assigned task classes
                }
        }
        try {
            StringWriter writer = getConfig().writeToString();
            if (writer.toString().length() > (256 * 1024)) { // 256K
                LOG.warning("Invalid: job config size extends 256K -- too many "
                        + "input/output dirs?");
                return false;
            } // if
        } catch (IOException e) {
            LOG.warning("Cannot convert configuration to string: "
                    + e.toString());
            return false;
        }
        return true;
    }

    // //////////////////////////////////////////////////////////////////////////
    // protected methods to access some states
    // //////////////////////////////////////////////////////////////////////////
    protected final static String PROP_TASK_MAX_FAILURE = "jobdef.task.max_failure";

    protected final static String PROP_TASK_CLASSPATH = "jobdef.task.classpath";

    protected final static String PROP_TASK_JVM_CONFIG = "jobdef.task.jvm_config";

    protected final static String PROP_TASK_HEAP_SIZE = "jobdef.task.heap_size";

    protected final static String PROP_TASK_ODIS_HOME = "jobdef.task.odis_home";

    protected final static String PROP_TASK_ODIS_LOCAL = "jobdef.task.odis_local";

    protected final static String PROP_TASK_HEAP_PROF = "jobdef.task.heap_prof";

    protected final static String PROP_TASK_REMOTE_DEBUG = "jobdef.task.remote_debug";

    protected final static String PROP_TASK_VERBOSE_GC = "jobdef.task.verbose_gc";
    
    protected final static String PROP_JOB_ENVP = "jobdef.envp";
    
    protected final static String PROP_JOB_WORKERNUM_LIMIT = "jobdef.workerNum-limit";

    public void setMaxFailurePerTask(int mf) {
        getConfig().setInt(PROP_TASK_MAX_FAILURE, mf);
    }

    protected int getMaxFailurePerTask() {
        return getConfig().getInt(PROP_TASK_MAX_FAILURE, 3);
    }

    public void setTaskClassPath(String cp) {
        getConfig().setProperty(PROP_TASK_CLASSPATH, cp);
    }

    protected String getTaskClassPath() {
        return getConfig().getString(PROP_TASK_CLASSPATH,
                System.getProperty("java.class.path"));
    }

    public void addTaskJavaConfig(String jc) {
        String config = getConfig().getString(PROP_TASK_JVM_CONFIG, null);
        if (config == null)
            getConfig().setProperty(PROP_TASK_JVM_CONFIG, jc);
        else
            getConfig().setProperty(PROP_TASK_JVM_CONFIG, config + " " + jc);
    }

    public void setTaskHeapSize(int hs) {
        getConfig().setInt(PROP_TASK_HEAP_SIZE, hs);
    }

    public void setTaskOdisHome(String home) {
        getConfig().setProperty(PROP_TASK_ODIS_HOME, home);
    }

    public void setTaskVerboseGC(boolean b) {
        getConfig().setBoolean(PROP_TASK_VERBOSE_GC, b);
    }

    protected String getTaskJaveConfig(int maxHeap) {
        String config = getConfig().getString(PROP_TASK_JVM_CONFIG, null);
        String odis = getConfig().getString(PROP_TASK_ODIS_HOME, null);
        odis = odis == null ? "" : " -Dodis.home=" + odis;
        String fullgc = getConfig().getBoolean(PROP_TASK_VERBOSE_GC, true) ? " -verbose:gc"
                : "";
        int heap = Math.min(
                getConfig().getInt(PROP_TASK_HEAP_SIZE, DEFAULT_HEAP_SIZE),
                maxHeap);
        if (config == null)
            return "-Xmx" + heap + "m" + odis + fullgc;
        else
            return "-Xmx" + heap + "m " + config + odis + fullgc;
    }

    protected String getTaskJavaConfig(int maxHeap, int resNeed) {
        String config = getConfig().getString(PROP_TASK_JVM_CONFIG, null);
        String odis = getConfig().getString(PROP_TASK_ODIS_HOME, null);
        odis = odis == null ? "" : " -Dodis.home=" + odis;
        String fullgc = getConfig().getBoolean(PROP_TASK_VERBOSE_GC, true) ? " -verbose:gc"
                : "";
        int heap = Math.min(
                getConfig().getInt(PROP_TASK_HEAP_SIZE, DEFAULT_HEAP_SIZE),
                maxHeap);
        heap = heap * resNeed;
        if (config == null)
            return "-Xmx" + heap + "m" + odis + fullgc;
        else
            return "-Xmx" + heap + "m " + config + odis + fullgc;
    }

    public void setTaskRemoteDebug(int basePort) {
        getConfig().setInt(PROP_TASK_REMOTE_DEBUG, basePort);
    }

    protected String getTaskRemoteDebug(int partIdx) {
        int port = getConfig().getInt(PROP_TASK_REMOTE_DEBUG, -1);
        if (port < 0)
            return null;
        else
            return "-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=0.0.0.0:"
                    + (port + partIdx);
    }

    public void setTaskHeapProfile(String prefix) {
        getConfig().setProperty(PROP_TASK_HEAP_PROF, prefix);
    }

    protected String getTaskHeapProfile(String suffix) {
        String prefix = getConfig().getString(PROP_TASK_HEAP_PROF, null);
        if (prefix != null) {
            return "-agentlib:hprof=heap=all,depth=20,file=" + prefix + "-"
                    + suffix;
        } else
            return null;
    }

    protected static final String PROP_DEBUG_LEVEL = "jobdef.debug_level";

    public void addTaskDebugConfig(Properties prop) {
        for (Map.Entry<Object, Object> entry: prop.entrySet())
            getConfig().addProperty(PROP_DEBUG_LEVEL, entry.toString());
    }

    protected Properties getTaskDebugConfig() {
        return getConfig().getProperties(PROP_DEBUG_LEVEL, null);
    }

    /**
     * Backup exeuction parameters
     */
    protected final static String PROP_BACKUP_LAG = "jobdef.backup.lag";

    protected final static String PROP_BACKUP_COPY = "jobdef.backup.copy";

    protected void setMaxBackupNum(int stage, int copy) {
        getConfig().setInt(PROP_BACKUP_COPY + "." + stage, copy);
    }

    protected int getMaxBackupNum(int stage) {
        return getConfig().getInt(PROP_BACKUP_COPY + "." + stage, 1);
    }

    protected void setMaxProgressLag(int stage, float lag) {
        getConfig().setFloat(PROP_BACKUP_LAG + "." + stage, lag);
    }

    protected float getMaxProgressLag(int stage) { // no backup as default
        return getConfig().getFloat(PROP_BACKUP_LAG + "." + stage, 2f);
    }

    protected final static String PROP_USER = "jobdef.username";

    protected void setUser(String user) {
        getConfig().setProperty(PROP_USER, user);
    }

    public String getUser() {
        return getConfig().getString(PROP_USER, null);
    }

    // ///////////////////////////////////////////////////////////////////////////
    // other stage related properties
    // ///////////////////////////////////////////////////////////////////////////

    /**
     * Whether to check progress for a stage
     */
    protected static final String PR_PROGRESS_CHECK = "jobdef.progress";

    protected void setCheckProgress(int stage, boolean b) {
        String prop = PR_PROGRESS_CHECK + "." + stage;
        getConfig().setProperty(prop, b);
    }

    protected boolean isCheckProgress(int stage) {
        String prop = PR_PROGRESS_CHECK + "." + stage;
        return getConfig().getBoolean(prop, true);
    }

    protected static final String PR_IGNORE_LAST_FAILURE = "jobdef.ignore_last_failure";

    public void setIgnoreLastFailure(boolean b) {
        getConfig().setProperty(PR_IGNORE_LAST_FAILURE, b);
    }

    protected boolean isIgnoreLastFailure() {
        return getConfig().getBoolean(PR_IGNORE_LAST_FAILURE, false);
    }

    protected static final String PR_NEXT_STAGE_PREPARING = "jobdef.next_stage_preparing";

    public void setNextStagePreparing(boolean b) {
        getConfig().setProperty(PR_NEXT_STAGE_PREPARING, b);
    }

    public boolean getNextStagePreparing() {
        return getConfig().getBoolean(PR_NEXT_STAGE_PREPARING, false);
    }

    public static JobDef loadConf(File conf) throws IOException {
        JobConfig jc = new JobConfig();
        jc.loadPropertiesConf(conf);
        return jc.jobDef;
    }

    protected static final String PR_NEXT_STAGE_THRESSHOLD = "jobdef.next_stage.threshold";

    public float getNextStageStartThreshold() {
        return getConfig().getFloat(PR_NEXT_STAGE_THRESSHOLD, 0.2f);
    }

    public void setNextStageStartThreshold(float value) {
        getConfig().setFloat(PR_NEXT_STAGE_THRESSHOLD, value);
    }

    protected static final String PR_BOOST_FACTOR = "jobdef.scheduler.boostfactor";

    public float getBoostFactor(float max) {
        return getConfig().getFloat(PR_BOOST_FACTOR, max);
    }

    public void setBoostFactor(float factor) {
        getConfig().setFloat(PR_BOOST_FACTOR, factor);
    }

    public void disableScheduleBoost() {
        setBoostFactor(1.0f);
    }

    public boolean getKeepFailedTaskFiles() {
        return false;
    }

    protected abstract void cleanup(String jobId);

    /**
     * Do some prepration work before submitting.
     * 
     * @throws IOException
     */
    protected void prepareBeforeSubmit() throws IOException {}

    public int getHeapSize(int maxHeap) {
        int heap = Math.min(
                getConfig().getInt(PROP_TASK_HEAP_SIZE, DEFAULT_HEAP_SIZE),
                maxHeap);
        return heap;
    }

    public String getJobID() {
        return getConfig().getString(PROP_JOB_ID, "");
    }

    public void setJobID(String jobID) {
        getConfig().setProperty(PROP_JOB_ID, jobID);
    }
    
    public int getJobWorkerNumLimit() {
        return getConfig().getInt(PROP_JOB_WORKERNUM_LIMIT, Integer.MAX_VALUE);
    }
  
    public void setJobWorkerNumLimit(int limit) {
        if (limit > 0) {
            getConfig().setInt(PROP_JOB_WORKERNUM_LIMIT, limit);
        }
    }
    
    public String[] getEnvp() {
        try {
            String[] envp = getConfig().getStringArray(PROP_JOB_ENVP);
            if (envp.length == 0) {
                return null;
            }
            return envp;
        } catch(Throwable e) {
            LOG.log(Level.SEVERE, "", e);
        }
        return null;
    }
    
    public void setEnvp(String[] envp) {
        getConfig().setProperty(PROP_JOB_ENVP, envp);
    }
  
}
