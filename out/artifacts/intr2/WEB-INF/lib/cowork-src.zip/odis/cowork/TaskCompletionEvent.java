package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.mapred.TaskID;
import odis.serialize.IWritable;

/**
 * @author tuqc
 */
public class TaskCompletionEvent implements IWritable {
    public final static TaskCompletionEvent[] EMPTY_EVENTS = new TaskCompletionEvent[0];

    public final static int TASK_SUCCESS = 0;

    public final static int TASK_LOST = 1;

    int eventIdx;

    int part;

    String fileHost;

    int status;

    String taskId;

    int taskRunTime;

    long timestamp;

    public TaskCompletionEvent() {}

    public TaskCompletionEvent(int id, String taskId, int part, String host,
            int status) {
        this(id, taskId, part, host, status, -1);
    }

    public TaskCompletionEvent(int id, String taskId, int part, String host,
            int status, int taskRunTime) {
        this.eventIdx = id;
        this.taskId = taskId;
        this.part = part;
        this.fileHost = host;
        this.status = status;
        this.taskRunTime = taskRunTime;
        timestamp = System.currentTimeMillis();
    }

    public boolean isSuccess() {
        return status == TASK_SUCCESS;
    }

    public boolean isLost() {
        return status == TASK_LOST;
    }

    public int getEventIdx() {
        return eventIdx;
    }

    public int getPart() {
        return part;
    }

    public String getFileHost() {
        return fileHost;
    }

    public int getTaskRunTime() {
        return taskRunTime;
    }

    public String getHttp() {
        return "http://" + fileHost + "/";
    }

    public TaskID getTaskID() {
        return new TaskID(taskId, part);
    }

    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public IWritable copyFields(IWritable o) {
        TaskCompletionEvent that = (TaskCompletionEvent) o;
        this.eventIdx = that.eventIdx;
        this.taskId = that.taskId;
        this.part = that.part;
        this.fileHost = that.fileHost;
        this.status = that.status;
        this.taskRunTime = that.taskRunTime;
        this.timestamp = that.timestamp;
        return this;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        eventIdx = in.readInt();
        taskId = in.readUTF();
        part = in.readInt();
        fileHost = in.readUTF();
        status = in.readInt();
        taskRunTime = in.readInt();
        timestamp = in.readLong();
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(eventIdx);
        out.writeUTF(taskId);
        out.writeInt(part);
        out.writeUTF(fileHost);
        out.writeInt(status);
        out.writeInt(taskRunTime);
        out.writeLong(timestamp);
    }

    @Override
    public int hashCode() {
        return part ^ fileHost.hashCode() ^ taskId.hashCode();
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof TaskCompletionEvent) {
            TaskCompletionEvent e = (TaskCompletionEvent) o;
            return this.part == e.part && this.fileHost.equals(e.fileHost)
                    && this.taskId.equals(e.taskId);
        }
        return false;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("eid=").append(eventIdx).append(", etask=").append(taskId).append(
                ", success=").append(this.isSuccess());
        return sb.toString();
    }
}
