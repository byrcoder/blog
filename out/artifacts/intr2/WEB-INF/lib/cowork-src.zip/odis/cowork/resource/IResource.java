/**
 * @(#)IResource.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import odis.rpc2.RpcException;

/**
 *
 * @author chenheng
 *
 */
public interface IResource {

    public boolean hello(ClusterNodeInfo nodeInfo, String v) throws RpcException;
    
    public boolean goodbye(String tmid, String reseaon) throws RpcException;
    
    public boolean heartBeat(ClusterNodeInfo nodeInfo, String v) throws RpcException;
    
    public boolean useResource(String tmID, String resourceID) throws RpcException;
    
    public boolean releaseResource(String tmID, String resourceID) throws RpcException;
} 
