package odis.cowork;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.TaskID;
import odis.serialize.IWritable;
import odis.util.BoundedByteArrayOutputStream;
import odis.util.LocalDirAllocator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import toolbox.misc.LogFormatter;

public class MapOutput<K extends IWritable, V extends IWritable> {
    protected static final Logger LOG = LogFormatter.getLogger(MapOutput.class);

    private static AtomicInteger ID = new AtomicInteger(0);

    public static enum Type {
        WAIT, MEMORY, DISK
    }

    private final int id;

    private final MergeManager<K, V> merger;

    private final TaskID mapId;

    private final long size;

    private final byte[] memory;

    private BoundedByteArrayOutputStream byteStream;

    private final IFileSystem localFS;

    private final Path tmpOutputPath;

    private final Path outputPath;

    private final OutputStream disk;

    private final Type type;

    private final boolean primaryMapOutput;

    MapOutput(TaskID mapId, MergeManager<K, V> merger, long size,
            LocalDirAllocator localDirAllocator, int fetcher,
            boolean primaryMapOutput) throws IOException {
        this.id = ID.incrementAndGet();
        this.mapId = mapId;
        this.merger = merger;

        type = Type.DISK;

        memory = null;
        byteStream = null;

        this.size = size;

        this.localFS = FileSystem.getNamed("local");
        String filename = mapId + ".out";
        String tmpOutput = filename + "." + fetcher;

        tmpOutputPath = new Path(localDirAllocator.getLocalFileForWrite(tmpOutput, size));
        outputPath = new Path(tmpOutputPath.getParent(), filename);
        disk = localFS.create(tmpOutputPath);

        this.primaryMapOutput = primaryMapOutput;
    }

    MapOutput(TaskID mapId, MergeManager<K, V> merger, int size,
            boolean primaryMapOutput) {
        this.id = ID.incrementAndGet();
        this.mapId = mapId;
        this.merger = merger;

        type = Type.MEMORY;
        byteStream = new BoundedByteArrayOutputStream(size);
        memory = byteStream.getBuffer();

        this.size = size;

        localFS = null;
        disk = null;
        outputPath = null;
        tmpOutputPath = null;

        this.primaryMapOutput = primaryMapOutput;
    }

    public MapOutput(TaskID mapId) {
        this.id = ID.incrementAndGet();
        this.mapId = mapId;

        type = Type.WAIT;
        merger = null;
        memory = null;
        byteStream = null;

        size = -1;

        localFS = null;
        disk = null;
        outputPath = null;
        tmpOutputPath = null;

        this.primaryMapOutput = false;
    }

    public boolean isPrimaryMapOutput() {
        return primaryMapOutput;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MapOutput) {
            return id == ((MapOutput) obj).id;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return id;
    }

    public Path getOutputPath() {
        return outputPath;
    }

    public byte[] getMemory() {
        return memory;
    }

    public BoundedByteArrayOutputStream getArrayStream() {
        return byteStream;
    }

    public OutputStream getDisk() {
        return disk;
    }

    public TaskID getMapId() {
        return mapId;
    }

    public Type getType() {
        return type;
    }

    public long getSize() {
        return size;
    }

    public void commit() throws IOException {
        if (type == Type.MEMORY) {
            merger.closeInMemoryFile(this);
        } else if (type == Type.DISK) {
            localFS.rename(tmpOutputPath, outputPath);
            merger.closeOnDiskFile(outputPath);
        } else {
            throw new IOException("Cannot commit MapOutput of type WAIT!");
        }
    }

    public void abort() {
        if (type == Type.MEMORY) {
            merger.unreserve(memory.length);
        } else if (type == Type.DISK) {
            try {
                localFS.delete(tmpOutputPath);
            } catch (IOException ie) {
                LOG.log(Level.WARNING, "failure to clean up " + tmpOutputPath,
                        ie);
            }
        } else {
            throw new IllegalArgumentException(
                    "Cannot commit MapOutput with of type WAIT!");
        }
    }

    public String toString() {
        return "MapOutput(" + mapId + ", " + type + ")";
    }

    public static class MapOutputComparator<K extends IWritable, V extends IWritable>
            implements Comparator<MapOutput<K, V>> {
        public int compare(MapOutput<K, V> o1, MapOutput<K, V> o2) {
            if (o1.id == o2.id) {
                return 0;
            }

            if (o1.size < o2.size) {
                return -1;
            } else if (o1.size > o2.size) {
                return 1;
            }

            if (o1.id < o2.id) {
                return -1;
            } else {
                return 1;

            }
        }
    }

}
