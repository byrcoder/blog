package odis.cowork;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.BindException;
import java.net.InetSocketAddress;
import java.util.LinkedHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import junit.framework.TestCase;
import odis.cowork.resource.ResourceManager;
import odis.io.FileSystem;
import odis.io.LocalFileSystem;
import odis.io.Path;
import toolbox.misc.LogFormatter;

public abstract class TestCaseCoWork extends TestCase {
    protected static final Logger LOG = LogFormatter.getLogger(TestCaseCoWork.class);
    static {
        // set the TEST sysenv, so some settings,
        // such as task heap size should be set to proper value for single
        // machine
        System.setProperty("IS_TEST", "true");
    }

    protected File testDir; // the home directory of all

    protected File inputDir, outputDir, tempDir;

    protected LocalFileSystem lfs;

    protected FileSystem fs;

    protected PrintWriter out;
        
    protected String vol;
    // jobmaster
    protected JobMaster jm;
    protected ResourceManager rm;
    protected InetSocketAddress jmAddr;
    protected InetSocketAddress rmAddr;
    protected Thread jmThread;
    protected Thread rmThread;
    protected long stopWait;
    // taskmaster
    protected TaskMaster[] tm;
    protected Thread[] tmThread;
    // temp dir for cowork
    protected File coworkDir;
    
    @SuppressWarnings("deprecation")
    @Override
    protected void setUp() throws Exception {
        LogFormatter.setShowThreadIDs(true);
        LogFormatter.setDebugLevel(Level.FINE, "odis");

        super.setUp();

        // lfs & nfs
        lfs = new LocalFileSystem();
        fs = lfs;

        // test dir
        testDir = new File(System.getProperty("test.build.data", "."), this.getClass().getName());
        System.out.println("Using test directory: " + testDir);
        if (lfs.exists(testDir) && !lfs.delete(testDir))
            throw new IOException("Cannot clean test directory: " + testDir);
        lfs.mkdirs(testDir);

        // other dir
        inputDir = new File(testDir, "input");
        outputDir = new File(testDir, "output");
        tempDir = new File(testDir, "temp");
        lfs.mkdirs(tempDir);

        out = new PrintWriter(System.out, true);
        
        /*
        ToolContext.addApp("test-app", "local", testDir.getPath(), "temp");
        ToolContext.getConfig().setProperty("app.default", "test-app");
        context = new ToolContext() {
            public void configJob(JobDef job, String jobName, int nWorker) {
                super.configJob(job, jobName, nWorker);
                if (job instanceof BasicInOutJobDef) {
                    BasicInOutJobDef ioJob = (BasicInOutJobDef) job;
                    ioJob.setFsOvaryDir(tempDir.getPath());
                }
            }
        };
        context.setCoWork("local");
        */
        
        this.stopWait = JobMaster.HEARTBEAT_INTERVAL;
        this.vol = CoWorkUtils.generate();
    }
    
    @Override
    protected void tearDown() throws Exception {
        if (lfs.exists(new Path(testDir)))
            if (!lfs.delete(new Path(testDir))) {
                System.err.println("error: cannot remove test directory, some file could be open without close");
            }
    }
    
    protected void startResManager() throws IOException {
        int rmPort = 5555;
        System.out.println("Starting ResManager In a Thread ...");
        int bindErrorNum = 0;
        for (; ; rmPort++) { 
            try {
                rm = new ResourceManager(rmPort, vol);
                break;
            } catch (IOException e) {
                if (e instanceof BindException) {
                    bindErrorNum++;
                    if (bindErrorNum> 10) 
                        throw e;
                }
            }
        }
        rmThread = new Thread(rm);
        rmThread.start();
        
    }
    
    protected void startJobMaster() throws IOException {
        int jmPort = 4444;
        rmAddr = new InetSocketAddress(rm.hostname, rm.port);
        System.out.println("STARTING JobMaster IN A THREAD ...");
        for (; ; jmPort++) try {
            jm = new JobMaster(rmAddr, jmPort, vol);
            break;
        } catch (BindException e) {
            if (jmPort > 4544)
                throw e;
        }
        jmThread = new Thread(jm);
        jmThread.start();        
    }
    
    protected void startTaskMasters(int tmNum, int taskLimit, int fileLimit) throws IOException{
        jmAddr = new InetSocketAddress(jm.hostname,jm.port);
        rmAddr = new InetSocketAddress(rm.hostname, rm.port);
        tm = new TaskMaster[tmNum];
        tmThread = new Thread[tmNum];
        for (int i=0; i<tmNum; i++) {
            System.out.println("STARTING TaskMaster " +i + " IN A THREAD ...");
            tm[i] = new TaskMaster(jmAddr, rmAddr, new File[]{getTaskMasterRoot(i)}, 
                    null, taskLimit, fileLimit, 200, 400, vol);
            tm[i].setInProcess(true);
            tmThread[i] = new Thread(tm[i]);
            tmThread[i].start();
            try { Thread.sleep(250); } catch (InterruptedException e) {}
        }
    }

    protected void start(int tmNum, int taskLimit, int fileLimit) throws IOException {
        // cowork dir
        coworkDir = new File(testDir, "cowork");
        //start resManager
        startResManager();
        // start jobmaster
        startJobMaster();
        // start taskmaster
        startTaskMasters(tmNum,taskLimit,fileLimit);
    }    
    
    protected void stop() {
        // stop task masters
        for (int i=0; i<tm.length; i++) tm[i].stop();
        // stop job master
        System.out.println("WAITING " + stopWait + "ms FOR GRACEFUL SHUTDOWN ...");
        try { Thread.sleep(stopWait); }
        catch (InterruptedException e) { }    
        jm.stop();
        // wait for job master to exit
        try { Thread.sleep(500); } catch (InterruptedException e) {}
        rm.stop();
        try { Thread.sleep(500); } catch (InterruptedException e) {}
        
    }
    
    protected String getJobMaster() { return jm.hostname+":"+jm.port; }
    
    protected InetSocketAddress getJobMasterAddr() {
        return new InetSocketAddress(jm.hostname, jm.port);
    }
    
    protected InetSocketAddress getRmManagerAddr() {
        return new InetSocketAddress(rm.hostname, rm.port);
    }
    
    protected File getTaskMasterRoot(int idx) {
        return new File(coworkDir,"tm"+idx);
    }
    
    protected void assertEmptyJobQueue() {
        assertTrue("JobQueue is not empty: " + jm.jobs, jm.jobs.size()==0);
    }
    
    protected void assertFreeTaskMasterPool() {
        LinkedHashMap<String, JobInProgress> newJQ = new LinkedHashMap<String, JobInProgress>();
        LinkedHashMap<String, TaskMasterStatus> newTP = new LinkedHashMap<String, TaskMasterStatus>();
        jm.snapshot(newJQ, newTP);
        for (TaskMasterStatus tms:newTP.values()) {
            assertEquals("TaskMaster " + tms + " is not empty", 
                    tms.capacity(),tms.vacancy());
        }
    }
    
    protected void printJobMasterStatus() {
        jm.logStatus(); // FIXME
    }

}
