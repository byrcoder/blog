package odis.cowork;

import java.io.PrintWriter;
import java.net.InetSocketAddress;

import odis.conf.OdisLibConfig;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import toolbox.misc.cli.ITool;

/**
 * The tool providing some cowork related functionality.
 * 
 * @author xxx
 *
 */
public class CoWorkShell implements ITool {

    private String jmAddr;
    private IJobMasterProtocol jobServer;
    private ICoWorkShellProtocol infoServer;
    private PrintWriter out;

    /**
     * The constructor.
     */
    public CoWorkShell() {
        jmAddr = OdisLibConfig.conf().getString("cowork.address", "localhost:4444");
    }
    
    private boolean init(String jmAddrStr) throws RpcException {
        String[] jmStr = jmAddrStr.split(":");
        if (jmStr.length!=2) { return false; }
        String host = jmStr[0];
        int port = Integer.parseInt(jmStr[1]);
        jobServer = RPC.getProxy(IJobMasterProtocol.class, 
                new InetSocketAddress(host,port));
        infoServer = RPC.getProxy(ICoWorkShellProtocol.class, 
                new InetSocketAddress(host,port+1));
        return true;
    }
    
    public String comment() {
        return "CoWork command line managment and monitoring";
    }

    public boolean exec(String[] args) throws RpcException {        
        out = new PrintWriter(System.out, true);
        if (args.length<1) { usage(out); return false; }
        if ( !init(jmAddr) ) {
            out.println("[ERROR] Invalid job master address: " + jmAddr);
            usage(out); return false;
        }
        String cmd = args[0];
        if ("job-list".equals(cmd)) {
            if (args.length!=1) { usage(out); return false; }
            jobList();
        } else if ("job-detail".equals(cmd)) {
            if (args.length!=2) { usage(out); return false; }
            jobDetail(args[1]);
        } else if ("job-kill".equals(cmd)) {
            if (args.length!=2) { usage(out); return false; }
            return jobKill(args[1]);
        } else if ("job-allow".equals(cmd)) {
        } else if ("tm-list".equals(cmd)) {
            if (args.length!=1) { usage(out); return false; }
            tmList();
        } else if ("tm-detail".equals(cmd)) {
            if (args.length!=2) { usage(out); return false; }
            tmDetail(args[1]);
        } else if ("tm-stat".equals(cmd)) {
            if (args.length!=3) { usage(out); return false; }
            tmStat(args[1],args[2]);
        } else { usage(out); return false; }
        return true;
    }
    
    private void jobList() throws RpcException {
        String[] list = infoServer.listJobInfo();
        out.println("Totally " + (list.length-1) + " jobs in queue.");
        for (int i=0; i<list.length; i++)
            out.println(list[i]);
    }
    
    private void jobDetail(String jobId) throws RpcException {
        String detail = infoServer.getJobDetail(jobId);
        out.println(detail);
    }
    
    private boolean jobKill(String jobId) throws RpcException {
        String user = CoWorkUtils.trimUserName(System.getProperty("user.name"));
        if ((!jobId.startsWith(user)) && (!user.equals("outback"))) {
            out.println("Your user name start with: " + user);
            out.println("You don't have permission to kill: " + jobId);
            return false;
        }
        jobServer.abortJob(jobId);
        jobServer.removeJob(jobId);
        return true;
    }    
    
    private void tmList() throws RpcException {
        String[] list = infoServer.listTaskMasterInfo();
        out.println("Totally " + (list.length-1) + " task masters in pool.");
        for (int i=0; i<list.length; i++)
            out.println(list[i]);
    }
    
    private void tmDetail(String tmId) throws RpcException {
        String detail = infoServer.getTaskMasterDetail(tmId);
        System.out.println(detail);        
    }
    
    private void tmStat(String tmId, String tipId) throws RpcException {
        String addr = infoServer.getTaskMasterAddr(tmId);
        if (addr==null) {
            System.out.println("Unknow taskmaster " + tmId + " in this cowork service");
            return;
        }
        ITaskMasterProtocol tm = (ITaskMasterProtocol) RPC.getProxy(
                ITaskMasterProtocol.class, OdisLibConfig.getAddress(addr));
        tm.statTask(tipId);
    }
    
    public void usage(PrintWriter out) {
        out.println("odis.sh cowork <cmd>");
        out.println("Commands:");
        out.println("  help                      Print help message");
        out.println("  job-list                  List all jobs in queue");
        out.println("  job-detail <job-id>       Print details of a job");
        out.println("  job-kill <job-id>         Kill a job");
        out.println("  job-allow <users>         Set the allowed users, users shoule be seperated by \",\"");
        out.println("  tm-list                   List all task masters");
        out.println("  tm-detail <tm-id>         Print details of a task master");
        out.println("  tm-stat <tm-id> <task-id> Execute \"kill -3\" for a task");
    }
    
    public static void main(String[] args) throws RpcException {
        CoWorkShell shell = new CoWorkShell();        
        shell.exec(args);
    }

}
