/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.ITaskMasterProtocol.TaskCompletionEventsUpdate;
import odis.cowork.ITaskMasterProtocol.TaskInfoUpdate;
import odis.dfs.client.LocalBackupManager;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import odis.util.DF;
import odis.util.LocalDirAllocator;
import odis.util.SysInfo;
import toolbox.misc.LogFormatter;
import toolbox.misc.ThreadUtils;
import toolbox.misc.UnitUtils;
import toolbox.text.util.StringUtils;

/**
 * A worker (process) spawned by <code>TaskThread</code> in
 * {@link odis.cowork.TaskMaster}.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public class TaskWorker {

    public static final String LOG_DIR = "tasks";

    public static final String CURSOR_FILE = "cursor";

    private static final String DFS_DIR = "dfs";

    protected JobDef job;

    protected TaskRunnable task;

    protected TaskDef taskDef;

    protected String tipId, localDir, pid; // task-in-progid, local dir, process
                                           // id

    protected ITaskMasterProtocol taskMaster;

    protected boolean inProcess, isLogFile;

    protected Thread pingThread;

    protected long pingInterval;

    protected volatile boolean update;

    protected volatile boolean terminate;

    private static final Logger LOG = LogFormatter.getLogger(TaskWorker.class);

    /**
     * The main part.
     * 
     * @param args
     *            <port> <taskId> <local> [<log>]
     * @throws Throwable
     */
    public static void main(String[] args) throws Throwable {
        int port = Integer.parseInt(args[0]);
        String taskId = args[1];
        ITaskMasterProtocol master = RPC.getProxy(ITaskMasterProtocol.class,
                new InetSocketAddress(port));
        String local = args[2];
        String log = null;
        if (args.length >= 4)
            log = args[3];

        // start system information logger to dump sys info in 1 minute period
        if (SysInfo.isLinux()) {
            SysInfoLogThread sysInfoLogger = new SysInfoLogThread(
                    30 * UnitUtils.SECOND);
            sysInfoLogger.start();
        }

        // start worker
        TaskWorker worker = new TaskWorker(master, taskId, local, log != null,
                false);
        worker.run();
    }

    protected TaskWorker() {}

    public TaskWorker(ITaskMasterProtocol master, String tip, String local,
            boolean logFile, boolean in) {
        this.task = null;
        this.taskMaster = master;
        this.tipId = tip;
        this.localDir = local;
        this.isLogFile = logFile;
        this.inProcess = in;
        // set this for odfs
        LocalBackupManager.setTempRoot(new File(localDir, DFS_DIR).getPath());
    }

    public ITaskMasterProtocol getTaskMaster() {
        return taskMaster;
    }

    public TaskCompletionEventsUpdate requestPreStageTaskUpdate(String tipId,
            int from, int max) throws RpcException {
        return taskMaster.requestPreStageTaskUpdate(tipId, from, max);
    }

    public void run() {

        long start = System.currentTimeMillis();

        try {
            pingThread = null;
            try {
                job = JobDef.loadConf(new File(localDir, "job.conf"));
                if (!inProcess)
                    configLogger(job);
                LOG.info("Load job conf complete, use time "
                        + (System.currentTimeMillis() - start) + " ms");

                // get to know my pid and let task master know this
                pid = System.getProperty("pid");
                LOG.info("Requesting task from task master "
                        + taskMaster.getId() + " (pid=" + pid + ")");
                taskDef = taskMaster.requestTask(tipId, pid);
                task = taskDef.getTaskRunnable();
                LOG.info("Skipping list: " + Arrays.toString(task.skips));

                // set cursor
                CursorBuffer cursor = new CursorBuffer(new File(localDir,
                        CURSOR_FILE), "rw");
                task.setCursor(cursor);
                LOG.info("Write cursor buffer at "
                                + System.currentTimeMillis());

                // start pinging parent process, i.e. TaskThread
                LOG.info("Pinging and running.");
                pingInterval = taskMaster.getUpdateInterval();
                update = true;
                terminate = false;
                startPinging();

                // configure task according to job definition
                task.configure(job, this);
                LOG.info("Checking progress flag: "
                                + task.getProgressFlag(job));

                // extecute task
                task.run();

                // update current time (and cursor position)
                cursor.write(task.cursor(), task.time());
                // a synchronized ping
                taskMaster.pingTask(tipId, task.getProgress(), task
                        .getCounters(), task.getProgressFlag(job), task
                        .getResultPartCount());
                // reporting finish status: SUCCESS
                LOG.info("Reporting " + tipId + " as SUCCESS");
                taskMaster.doneTask(tipId,
                        IJobMasterProtocol.TASK_STATE_SUCCESS, task
                                .getDoneMsg());
            } catch (TaskFatalException e) {
                // a synchronized ping
                taskMaster.pingTask(tipId, task.getProgress(), task
                        .getCounters(), task.getProgressFlag(job), task
                        .getResultPartCount());
                // reporting finish status: FATAL
                LOG.log(Level.WARNING, "Reporting " + tipId + " as FATAL: ", e);
                taskMaster.doneTask(tipId, IJobMasterProtocol.TASK_STATE_FATAL,
                        "FATAL:" + e);
            } catch (Throwable throwable) {
                LOG.log(Level.WARNING, "Reporting " + tipId + " as FAIL",
                        throwable);
                // a synchronized ping
                taskMaster.pingTask(tipId, task.getProgress(), task
                        .getCounters(), task.getProgressFlag(job), task
                        .getResultPartCount());
                // reporting finish status: FAIL
                taskMaster.doneTask(tipId, IJobMasterProtocol.TASK_STATE_FAIL,
                        "FAIL:" + throwable);
            } finally {
                if (task != null)
                    task.closeCursor();
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING,
                    "Error in calling doneTask() or close cursor buffer", e);
        } finally {
            terminate = true;
            if (pingThread != null)
                pingThread.interrupt();
            // list all threads left in the worker process: user should take a
            // look
            // at the threads left and be careful with possible data loss
            Thread[] leftThreads = ThreadUtils.getThreadsInCurrentVM();
            StringBuffer buffer = new StringBuffer("Exiting with "
                    + leftThreads.length + " threads left inside:");
            for (int i = 0; i < leftThreads.length; i++) {
                buffer.append("\n  " + leftThreads[i].getId() + ":"
                        + leftThreads[i].getName() + ":"
                        + (leftThreads[i].isDaemon() ? "daemon" : "non-daemon")
                        + ":" + leftThreads[i].getState());
            }
            LOG.fine(buffer.toString());

            LOG.info("Took " + (System.currentTimeMillis() - start)
                    + "ms in TaskWorker");
        }

    }

    public String getLocalDir() {
        return localDir;
    }

    public LocalDirAllocator getLocalDirAllocator() {
        return new LocalDirAllocator(new File(localDir));
    }

    File[] tmpDirs = null;

    ArrayList<File> dataDirs = null;

    Random rand = null;

    public File getUsableDataDir(long estimateSize) throws RpcException {
        if (tmpDirs == null) {
            String[] dirPaths = taskMaster.getTmpDirs();
            LOG.info("Get all tmp dirs:" + Arrays.toString(dirPaths));
            tmpDirs = new File[dirPaths.length];
            for (int i = 0; i < dirPaths.length; ++i) {
                tmpDirs[i] = new File(dirPaths[i]);
            }
        }
        if (dataDirs == null)
            dataDirs = new ArrayList<File>();
        if (rand == null)
            rand = new Random();

        dataDirs.clear();
        for (File file: tmpDirs) {
            if (!file.exists())
                file.mkdirs();
            if (file.getUsableSpace() >= estimateSize) {
                dataDirs.add(file);
            } else {
                LOG.warning(file.getAbsolutePath() + " is full, usable:"
                        + file.getUsableSpace() + ", free:"
                        + file.getFreeSpace());
            }
        }
        if (dataDirs.size() == 0) {
            LOG.severe("No disks can write " + estimateSize + " byte");
            try {
                for (File file: tmpDirs) {
                    DF df = new DF(file.getCanonicalPath());
                    LOG
                            .warning(file.getAbsolutePath() + " -> "
                                    + df.toString());
                }
            } catch (Exception e) {
                LOG.warning(CoWorkUtils.getStrackTrace(e));
            }
            return null;
        }
        File dataDir = dataDirs.get(rand.nextInt(dataDirs.size()));
        File tipDataDir = new File(dataDir, tipId);
        if (!tipDataDir.exists()) {
            tipDataDir.mkdirs();
        }
        return tipDataDir;
    }

    public TaskRunnable getTaskRunnable() {
        return task;
    }

    public TaskDef getTaskDef() {
        return taskDef;
    }

    public String getTaskInProgressId() {
        return tipId;
    }

    public boolean getAndClearUpdate() {
        synchronized (this) {
            boolean result = update;
            update = false;
            return result;
        }
    }

    public void recordUpdate(boolean v) {
        synchronized (this) {
            update = update || v;
            if (update) {
                this.notify();
            }
        }
    }

    public long getPingInterval() {
        return pingInterval;
    }

    private void configLogger(JobDef job) throws IOException {
        // set logger
        if (isLogFile) {
            LogFormatter.setPrefix(taskMaster.getId() + ":" + tipId);
        } else {
            LogFormatter.setPrefix(tipId);
            LogFormatter.setShowTime(false);
        }
        LogFormatter.setLogLevel(job.getTaskDebugConfig(), Level.INFO);
    }

    private void startPinging() {
        pingThread = new Thread(new Runnable() {
            public void run() {
                while (!terminate) {
                    try {
                        Thread.sleep(pingInterval);
                    } catch (InterruptedException e) {}
                    try {
                        TaskInfoUpdate taskInfo = taskMaster.pingTask(tipId,
                                task.getProgress(), task.getCounters(), 
                                task.getProgressFlag(job), 
                                task.getResultPartCount());
                        recordUpdate(taskInfo.update);
                    } catch (Throwable t) {
                        LOG.log(Level.WARNING,
                                "Error in pingTask, maybe parent error or died.  Exiting "
                                        + tipId, t);
                        if (inProcess) {
                            LOG.warning("Running IN_PROCESS. No way to kill running task if any exists.");
                            terminate = true;
                            // return;
                        } else
                            System.exit(1);
                    }
                } // while
                LOG.fine("Pinger exit normally");
            }
        }, "Pinger for " + tipId);

        pingThread.setDaemon(true);
        pingThread.start();
    }

    /**
     * Thread to print system info (such as swap used) into log periodically.
     * 
     * @author river
     */
    private static class SysInfoLogThread extends Thread {
        private long interval;

        public SysInfoLogThread(long interval) {
            super("System Information Logger");
            this.interval = interval;
            if (this.interval < 10 * UnitUtils.SECOND) {
                this.interval = 10 * UnitUtils.SECOND;
            }
            setDaemon(true);
        }

        public void run() {
            LOG.log(Level.INFO, "Start system information logger");
            while (true) {
                try {
                    long swapUsed = SysInfo.getSwapUsed();
                    LOG.log(Level.INFO, "Swap used : "
                            + StringUtils.bytesAbbr(swapUsed));

                    Thread.sleep(interval);
                } catch (IOException e) {
                    LOG.log(Level.WARNING,
                            "Caught IOException when retrieving system information",
                            e);
                } catch (InterruptedException e) {}
            }
        }

    }

}
