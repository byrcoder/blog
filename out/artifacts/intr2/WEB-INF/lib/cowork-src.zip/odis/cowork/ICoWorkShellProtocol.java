package odis.cowork;

import odis.rpc2.RpcException;

/**
 * The RPC protocol interface for getting information from a cowork jobmaster.
 * 
 * @author zl
 *
 */
public interface ICoWorkShellProtocol {
    /**
     * Gets all jobs.
     */
    public String[] listJobInfo() throws RpcException;
    /**
     * Gets the detail information of a job
     */
    public String getJobDetail(String jobId) throws RpcException;
    /**
     * Lists all task-master informations 
     */
    public String[] listTaskMasterInfo() throws RpcException;
    /**
     * Gets the detail information of a task-master
     */
    public String getTaskMasterDetail(String tmId) throws RpcException;
    /**
     * Gets the address of a specified task-master
     */
    public String getTaskMasterAddr(String tmId) throws RpcException;

}
