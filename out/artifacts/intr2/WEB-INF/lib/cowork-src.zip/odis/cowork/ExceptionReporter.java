package odis.cowork;

/**
 * report exception
 * @author tuqc
 *
 */
public interface ExceptionReporter {
    void reportException(Throwable t);
}
