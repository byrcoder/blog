package odis.cowork;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;

import odis.cowork.MapOutput.MapOutputComparator;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.DataInputBuffer;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.CombineOutputCollector;
import odis.mapred.CombinerRunner;
import odis.mapred.IFile;
import odis.mapred.IFileMerger;
import odis.mapred.IReducer;
import odis.mapred.MRConfig;
import odis.mapred.MapOutputFile;
import odis.mapred.MapRedUtil;
import odis.mapred.RawKeyValueIterator;
import odis.mapred.TaskID;
import odis.serialize.IWritable;
import odis.serialize.comparator.BinaryComparator;
import odis.util.LocalDirAllocator;
import toolbox.misc.LogFormatter;

public class MergeManager<K extends IWritable, V extends IWritable> {   
    protected static final Logger LOG = LogFormatter.getLogger(MergeManager.class);
    
    /* Maximum percentage of the in-memory limit that a single shuffle can 
     * consume*/ 
    private static final float MAX_SINGLE_SHUFFLE_SEGMENT_FRACTION = 0.25f;
    public static final String MERGED_OUTPUT_PREFIX = ".m";
    
    private final String reduceId;
    
    private final BasicInOutJobDef job;
    private final IFileSystem localFS;
    private final LocalDirAllocator localDirAllocator;
    
    protected MapOutputFile mapOutputFile;
    
    Set<MapOutput<K, V>> inMemoryMergedMapOutputs = 
      new TreeSet<MapOutput<K,V>>(new MapOutputComparator<K, V>());
    private final IntermediateMemoryToMemoryMerger memToMemMerger;

    Set<MapOutput<K, V>> inMemoryMapOutputs = 
      new TreeSet<MapOutput<K,V>>(new MapOutputComparator<K, V>());
    private final InMemoryMerger inMemoryMerger;
    
    Set<Path> onDiskMapOutputs = new TreeSet<Path>();
    private final OnDiskMerger onDiskMerger;
    
    private final long memoryLimit;
    private long usedMemory;
    private final long maxSingleShuffleLimit;
    
    private final int memToMemMergeOutputsThreshold; 
    private final long mergeThreshold;
    
    private final int ioSortFactor;

//    private final Reporter reporter;
    private final ExceptionReporter exceptionReporter;
    
    /**
     * Combiner class to run during in-memory merge, if defined.
     */
    private final IReducer combiner;

    /**
     * Resettable collector used for combine.
     */
    private final CombineOutputCollector<K,V> combineCollector;

    private final CounterMap.Counter spilledRecordsCounter;

    private final CounterMap.Counter reduceCombineInputCounter;

    private final CounterMap.Counter mergedMapOutputsCounter;
    
    private final CompressAlgo compressAlgo;
    
    Class<K> keyClass;
    Class<V> valueClass;
    int ioPhase;
    TaskRunnable task;      

    public MergeManager(BasicInOutJobDef job, TaskRunnable task,
                        IFileSystem localFS,
                        LocalDirAllocator localDirAllocator,  
                        CompressAlgo codec,
                        CombineOutputCollector<K,V> combineCollector,
                        ExceptionReporter exceptionReporter,
                        CounterMap.Counter spilledRecordsCounter,
                        CounterMap.Counter reduceCombineInputCounter,
                        CounterMap.Counter mergedMapOutputsCounter) {
      this.task = task;
      this.ioPhase = MapRedUtil.getMrMergePhase(task.getStageIdx(), job);
      this.reduceId = task.getTaskId();
      this.job = job;
      this.localDirAllocator = localDirAllocator;
      this.exceptionReporter = exceptionReporter;
      
      this.compressAlgo = codec;
      combiner = job.getCombiner(ioPhase);
      if (null != combineCollector) {
    	  this.combineCollector = combineCollector;
      } else {
    	  this.combineCollector = new CombineOutputCollector<K, V>(null);
      }
      this.reduceCombineInputCounter = reduceCombineInputCounter;
      this.spilledRecordsCounter = spilledRecordsCounter;
      this.mergedMapOutputsCounter = mergedMapOutputsCounter;
      assert mergedMapOutputsCounter != null;
      
      this.mapOutputFile = new MapOutputFile(localDirAllocator);      
      this.localFS = localFS;
      
      final float maxInMemCopyUse = job.getConfig().getFloat(MRConfig.SHUFFLE_INPUT_BUFFER_PERCENT, 0.60f);
      if (maxInMemCopyUse > 1.0 || maxInMemCopyUse < 0.0) {
        throw new IllegalArgumentException("Invalid value for " +
            MRConfig.SHUFFLE_INPUT_BUFFER_PERCENT + ": " +
            maxInMemCopyUse);
      }

      // Allow unit tests to fix Runtime memory
      this.memoryLimit =  (long)(job.getConfig().getLong(MRConfig.REDUCE_MEMORY_TOTAL_BYTES,
            Math.min(Runtime.getRuntime().maxMemory(), Integer.MAX_VALUE))
          * maxInMemCopyUse);
   
      this.ioSortFactor = job.getConfig().getInt(MRConfig.IO_SORT_FACTOR, 100);

      this.maxSingleShuffleLimit = (long)(memoryLimit * MAX_SINGLE_SHUFFLE_SEGMENT_FRACTION);
      this.memToMemMergeOutputsThreshold = job.getConfig().getInt(MRConfig.REDUCE_MEMTOMEM_THRESHOLD, ioSortFactor);
      this.mergeThreshold = (long)(this.memoryLimit * 
                            job.getConfig().getFloat(MRConfig.SHUFFLE_MERGE_EPRCENT, 0.75f));
      LOG.info("MergerManager: memoryLimit=" + memoryLimit + ", " +
               "maxSingleShuffleLimit=" + maxSingleShuffleLimit + ", " +
               "mergeThreshold=" + mergeThreshold + ", " + 
               "ioSortFactor=" + ioSortFactor + ", " +
               "memToMemMergeOutputsThreshold=" + memToMemMergeOutputsThreshold);

      boolean allowMemToMemMerge = job.getConfig().getBoolean(MRConfig.REDUCE_MEMTOMEM_ENABLED, false);
      if (allowMemToMemMerge) {
        this.memToMemMerger = 
          new IntermediateMemoryToMemoryMerger(this,
                                               memToMemMergeOutputsThreshold);
        this.memToMemMerger.start();
      } else {
        this.memToMemMerger = null;
      }
      
      this.inMemoryMerger = new InMemoryMerger(this);
      this.inMemoryMerger.start();
      
      this.onDiskMerger = new OnDiskMerger(this);
      this.onDiskMerger.start();
      
      keyClass = job.getMergeKeyClass(ioPhase);
      valueClass = job.getMergeValClass(ioPhase);      
//      this.mergePhase = mergePhase;
    }
    

    String getReduceId() {
      return reduceId;
    }

    public void waitForInMemoryMerge() throws InterruptedException {
      inMemoryMerger.waitForMerge();
    }
    
    private boolean canShuffleToMemory(long requestedSize) {
      return (requestedSize < maxSingleShuffleLimit); 
    }
    
    final private MapOutput<K,V> stallShuffle = new MapOutput<K,V>(null);

    public synchronized MapOutput<K,V> reserve(TaskID mapId, 
                                               long requestedSize,
                                               int fetcher
                                               ) throws IOException {
      if (!canShuffleToMemory(requestedSize)) {
        LOG.info(mapId + ": Shuffling to disk since " + requestedSize + 
                 " is greater than maxSingleShuffleLimit (" + 
                 maxSingleShuffleLimit + ")");
        return new MapOutput<K,V>(mapId, this, requestedSize,
                                  localDirAllocator, fetcher, true);
      }
      
      // Stall shuffle if we are above the memory limit

      // It is possible that all threads could just be stalling and not make
      // progress at all. This could happen when:
      //
      // requested size is causing the used memory to go above limit &&
      // requested size < singleShuffleLimit &&
      // current used size < mergeThreshold (merge will not get triggered)
      //
      // To avoid this from happening, we allow exactly one thread to go past
      // the memory limit. We check (usedMemory > memoryLimit) and not
      // (usedMemory + requestedSize > memoryLimit). When this thread is done
      // fetching, this will automatically trigger a merge thereby unlocking
      // all the stalled threads
      
      if (usedMemory > memoryLimit) {
        LOG.fine(mapId + ": Stalling shuffle since usedMemory (" + usedMemory + 
                 ") is greater than memoryLimit (" + memoryLimit + ")"); 
        
        return stallShuffle;
      }
      
      // Allow the in-memory shuffle to progress
      LOG.fine(mapId + ": Proceeding with shuffle since usedMemory (" +
          usedMemory + 
          ") is lesser than memoryLimit (" + memoryLimit + ")"); 
      return unconditionalReserve(mapId, requestedSize, true);
    }
    
    /**
     * Unconditional Reserve is used by the Memory-to-Memory thread
     * @return
     */
    private synchronized MapOutput<K, V> unconditionalReserve(
            TaskID mapId, long requestedSize, boolean primaryMapOutput) {
      usedMemory += requestedSize;
      return new MapOutput<K,V>(mapId, this, (int)requestedSize, 
          primaryMapOutput);
    }
    
    synchronized void unreserve(long size) {
      usedMemory -= size;
    }
    
    public synchronized void closeInMemoryFile(MapOutput<K,V> mapOutput) { 
      if (mapOutput.getSize() > 0) {
          inMemoryMapOutputs.add(mapOutput);
      }
      LOG.info("closeInMemoryFile -> map-output of size: " + mapOutput.getSize()
          + ", inMemoryMapOutputs.size() -> " + inMemoryMapOutputs.size());
      
      synchronized (inMemoryMerger) {
        if (!inMemoryMerger.isInProgress() && usedMemory >= mergeThreshold) {
          LOG.info("Starting inMemoryMerger's merge since usedMemory=" +
              usedMemory + " > mergeThreshold=" + mergeThreshold);
          inMemoryMapOutputs.addAll(inMemoryMergedMapOutputs);
          inMemoryMergedMapOutputs.clear();
          inMemoryMerger.startMerge(inMemoryMapOutputs);
        } 
      }
      
      if (memToMemMerger != null) {
        synchronized (memToMemMerger) {
          if (!memToMemMerger.isInProgress() && 
              inMemoryMapOutputs.size() >= memToMemMergeOutputsThreshold) {
            memToMemMerger.startMerge(inMemoryMapOutputs);
          }
        }
      }
    }
    
    
    public synchronized void closeInMemoryMergedFile(MapOutput<K,V> mapOutput) {
      inMemoryMergedMapOutputs.add(mapOutput);
      LOG.info("closeInMemoryMergedFile -> size: " + mapOutput.getSize() + 
               ", inMemoryMergedMapOutputs.size() -> " + 
               inMemoryMergedMapOutputs.size());
    }
    
    public synchronized void closeOnDiskFile(Path file) {
      onDiskMapOutputs.add(file);
      
      synchronized (onDiskMerger) {
        if (!onDiskMerger.isInProgress() && 
            onDiskMapOutputs.size() >= (2 * ioSortFactor - 1)) {
          onDiskMerger.startMerge(onDiskMapOutputs);
        }
      }
    }
    
    public RawKeyValueIterator close() throws IOException, InterruptedException {
      // Wait for on-going merges to complete
      if (memToMemMerger != null) { 
        memToMemMerger.close();
      }
      inMemoryMerger.close();
      onDiskMerger.close();
      
      inMemoryMerger.join();
      onDiskMerger.join();
      
      List<MapOutput<K, V>> memory = 
        new ArrayList<MapOutput<K, V>>(inMemoryMergedMapOutputs);
      memory.addAll(inMemoryMapOutputs);
      List<Path> disk = new ArrayList<Path>(onDiskMapOutputs);
      RawKeyValueIterator iter =  finalMerge(job, localFS, memory, disk);
      
      memory.clear();
      memory = null;
      return iter;
    }
     
    private class IntermediateMemoryToMemoryMerger 
    extends MergeThread<MapOutput<K, V>, K, V> {
      
      public IntermediateMemoryToMemoryMerger(MergeManager<K, V> manager, 
                                              int mergeFactor) {
        super(manager, mergeFactor, exceptionReporter);
        setName("InMemoryMerger - Thread to do in-memory merge of in-memory " +
                      "shuffled map-outputs");
        setDaemon(true);
      }

      @Override
      public void merge(List<MapOutput<K, V>> inputs) throws IOException {
        if (inputs == null || inputs.size() == 0) {
          return;
        }

        TaskID dummyMapId = inputs.get(0).getMapId(); 
        List<IFileMerger.Segment<K, V>> inMemorySegments = new ArrayList<IFileMerger.Segment<K, V>>();
        
        long mergeOutputSize = createInMemorySegments(inputs, inMemorySegments, 0);
        int noInMemorySegments = inMemorySegments.size();
        
        MapOutput<K, V> mergedMapOutputs = 
          unconditionalReserve(dummyMapId, mergeOutputSize, false);
        
        IFile.Writer<K, V> writer = new IFile.InMemoryWriter<K, V>(mergedMapOutputs.getArrayStream());
        
        LOG.info("Initiating Memory-to-Memory merge with " + noInMemorySegments +
                 " segments of total-size: " + mergeOutputSize);

        BinaryComparator keyComparator = job.getMergeKeyComparator(ioPhase);
        BinaryComparator valueCompartor = job.getMergeValComparator(ioPhase);

        int mergeFactor = job.getConfig().getInt(MRConfig.MAP_SORT_MERGE_FACTOR, 100); 
        boolean sortSegments = inMemorySegments.size() > mergeFactor;
        RawKeyValueIterator rIter = IFileMerger.merge(job.getConfig(), localDirAllocator, localFS,
                       keyClass, valueClass,
                       null, //not compress in mid
                       inMemorySegments,mergeFactor, inMemorySegments.size(),
                       keyComparator, valueCompartor,
                       sortSegments, null,null);
//                       new Path(reduceId.toString()),
//                       (RawComparator<K>)job.getOutputKeyComparator(),
//                       reporter, null, null, null);
        IFileMerger.writeFile(rIter, writer, job.getConfig());
        writer.close();

        LOG.info(reduceId +  
                 " Memory-to-Memory merge of the " + noInMemorySegments +
                 " files in-memory complete.");

        // Note the output of the merge
        closeInMemoryMergedFile(mergedMapOutputs);
      }
    }
    
    private class InMemoryMerger extends MergeThread<MapOutput<K,V>, K,V> {
      
      public InMemoryMerger(MergeManager<K, V> manager) {
        super(manager, Integer.MAX_VALUE, exceptionReporter);
        setName
        ("InMemoryMerger - Thread to merge in-memory shuffled map-outputs");
        setDaemon(true);
      }
      
      @Override
      public void merge(List<MapOutput<K,V>> inputs) throws IOException {
        if (inputs == null || inputs.size() == 0) {
          return;
        }
        
        //name this output file same as the name of the first file that is 
        //there in the current list of inmem files (this is guaranteed to
        //be absent on the disk currently. So we don't overwrite a prev. 
        //created spill). Also we need to create the output file now since
        //it is not guaranteed that this file will be present after merge
        //is called (we delete empty files as soon as we see them
        //in the merge method)

        //figure out the mapId 
        TaskID mapId = inputs.get(0).getMapId();
//        TaskID mapTaskId = mapId.getTaskID();

        List<IFileMerger.Segment<K, V>> inMemorySegments = new ArrayList<IFileMerger.Segment<K, V>>();
        long mergeOutputSize = 
          createInMemorySegments(inputs, inMemorySegments,0);
        int noInMemorySegments = inMemorySegments.size();

        Path outputPath = new Path(localDirAllocator.getLocalFileForWrite(mapId + MERGED_OUTPUT_PREFIX, mergeOutputSize));
//          mapOutputFile.getInputFileForWrite(mapId,
//                                             mergeOutputSize).suffix(
//                                                 Task.MERGED_OUTPUT_PREFIX);

        IFile.Writer<K,V> writer = 
          new IFile.Writer<K,V>(localFS, outputPath,
                          keyClass, valueClass,
                          compressAlgo, null);

        RawKeyValueIterator rIter = null;
        try {
          LOG.info("Initiating in-memory merge with " + noInMemorySegments + 
                   " segments...");
          
          BinaryComparator keyComparator = job.getMergeKeyComparator(ioPhase);
          BinaryComparator valueCompartor = job.getMergeValComparator(ioPhase);
          
          rIter = IFileMerger.merge(job.getConfig(), localDirAllocator, localFS,                  
                               keyClass, valueClass,
                               null,
                               inMemorySegments, ioSortFactor, inMemorySegments.size(),
                               keyComparator, valueCompartor,
                               false,null, null);
//                               new Path(reduceId.toString()),
//                               (RawComparator<K>)job..getOutputKeyComparator(),
//                               reporter, spilledRecordsCounter, null, null);
          
          if (null == combiner) {
            IFileMerger.writeFile(rIter, writer, job.getConfig());
          } else {
            combineCollector.setWriter(writer);
            combineAndSpill(rIter, reduceCombineInputCounter);
          }
          writer.close();

          LOG.info(reduceId +  
              " Merge of the " + noInMemorySegments +
              " files in-memory complete." +
              " Local file is " + outputPath + " of size " + 
              localFS.getLength(outputPath));
        } catch (IOException e) { 
          //make sure that we delete the ondisk file that we created 
          //earlier when we invoked cloneFileAttributes
          localFS.delete(outputPath);
          throw e;
        }

        // Note the output of the merge
        closeOnDiskFile(outputPath);
      }

    }
    
    private class OnDiskMerger extends MergeThread<Path,K,V> {
      
      public OnDiskMerger(MergeManager<K, V> manager) {
        super(manager, Integer.MAX_VALUE, exceptionReporter);
        setName("OnDiskMerger - Thread to merge on-disk map-outputs");
        setDaemon(true);
      }
      
      @Override
      public void merge(List<Path> inputs) throws IOException {
        // sanity check
        if (inputs == null || inputs.isEmpty()) {
          LOG.info("No ondisk files to merge...");
          return;
        }
        
        long approxOutputSize = 0;
//        int bytesPerSum = 
//          job.getConfig().getInt("io.bytes.per.checksum", 512);
        
        LOG.info("OnDiskMerger: We have  " + inputs.size() + 
                 " map outputs on disk. Triggering merge...");
        
        // 1. Prepare the list of files to be merged. 
        for (Path file : inputs) {
          approxOutputSize += localFS.getLength(file);
        }

        // add the checksum length

        // 2. Start the on-disk merge process
        Path outputPath = new Path(localDirAllocator.getLocalFileForWrite(inputs.get(0).toString(), approxOutputSize))
                    .cat(MERGED_OUTPUT_PREFIX); 
        IFile.Writer<K,V> writer = 
          new IFile.Writer<K,V>(localFS, outputPath,
                          keyClass, valueClass,
                          compressAlgo, null);
        RawKeyValueIterator iter  = null;

        try {
         BinaryComparator keyComparator = job.getMergeKeyComparator(ioPhase);
         BinaryComparator valueCompartor = job.getMergeValComparator(ioPhase);

         iter = IFileMerger.merge(job.getConfig(),localDirAllocator, localFS,
                              keyClass, valueClass,
                              compressAlgo,
                              inputs.toArray(new Path[inputs.size()]), ioSortFactor, 0, true,
                              keyComparator, valueCompartor, 
                              mergedMapOutputsCounter, null, null);

          IFileMerger.writeFile(iter, writer, job.getConfig());
          writer.close();
        } catch (IOException e) {
          localFS.delete(outputPath);
          throw e;
        }

        closeOnDiskFile(outputPath);

        LOG.info(reduceId +
            " Finished merging " + inputs.size() + 
            " map output files on disk of total-size " + 
            approxOutputSize + "." + 
            " Local output file is " + outputPath + " of size " +
            localFS.getLength(outputPath));
      }
    }
    
    private void combineAndSpill(
        RawKeyValueIterator kvIter,
        CounterMap.Counter inCounter) throws IOException {
//      JobConf job = job.;
//      IReducer combiner = job.getCombiner(ioPhase); 
//          ReflectionUtils.newInstance(combinerClass, job);
//      Class<K> keyClass = (Class<K>) job.getMapOutputKeyClass();
//      Class<V> valClass = (Class<V>) job.getMapOutputValueClass();
      
        CombinerRunner combinerRunner = CombinerRunner.create(job, task, ioPhase, inCounter);
        combinerRunner.combine(new CombinerRunner.RawKeyValueRecordReader(kvIter, keyClass, valueClass), combineCollector);
//      RawComparator<K> comparator = 
//        (RawComparator<K>)job.getOutputKeyComparator();
//      try {
//        CombineValuesIterator values = new CombineValuesIterator(
//            kvIter, comparator, keyClass, valClass, job, Reporter.NULL,
//            inCounter);
//        while (values.more()) {
//          combiner.reduce(values.getKey(), values, combineCollector,
//                          Reporter.NULL);
//          values.nextKey();
//        }
//      } finally {
//        combiner.close();
//      }
    }

    private long createInMemorySegments(List<MapOutput<K,V>> inMemoryMapOutputs,
                                        List<IFileMerger.Segment<K, V>> inMemorySegments, 
                                        long leaveBytes
                                        ) throws IOException {
      long totalSize = 0L;
      // We could use fullSize could come from the RamManager, but files can be
      // closed but not yet present in inMemoryMapOutputs
      long fullSize = 0L;
      for (MapOutput<K,V> mo : inMemoryMapOutputs) {
        fullSize += mo.getMemory().length;
      }
      while(fullSize > leaveBytes) {
        MapOutput<K,V> mo = inMemoryMapOutputs.remove(0);
        byte[] data = mo.getMemory();
        long size = data.length;
        totalSize += size;
        fullSize -= size;
        IFile.Reader<K,V> reader = new InMemoryReader<K,V>(MergeManager.this, 
                                                     mo.getMapId(),
                                                     data, 0, (int)size);
        inMemorySegments.add(new IFileMerger.Segment<K,V>(reader, true, 
                                              (mo.isPrimaryMapOutput() ? mergedMapOutputsCounter : null)));
      }
      return totalSize;
    }

    
    class RawKVIteratorReader extends IFile.Reader<K,V> {

      private final RawKeyValueIterator kvIter;

      public RawKVIteratorReader(RawKeyValueIterator kvIter, long size)
          throws IOException {
        super(null, 0, size, null, spilledRecordsCounter);
        this.kvIter = kvIter;
      }
      public boolean nextRawKey(DataInputBuffer key) throws IOException {
        if (kvIter.next()) {
          final DataInputBuffer kb = kvIter.getKey();
          final int kp = kb.getPosition();
          final int klen = kb.getSize() - kp;
          key.reset(kb.getBuffer(), kp, klen);
          bytesRead += klen;
          return true;
        }
        return false;
      }
      public void nextRawValue(DataInputBuffer value) throws IOException {
        final DataInputBuffer vb = kvIter.getValue();
        final int vp = vb.getPosition();
        final int vlen = vb.getSize() - vp;
        value.reset(vb.getBuffer(), vp, vlen);
        bytesRead += vlen;
      }
      public long getPosition() throws IOException {
        return bytesRead;
      }

      public void close() throws IOException {
        kvIter.close();
      }
    }
    

    private RawKeyValueIterator finalMerge(BasicInOutJobDef job, IFileSystem fs,
                                         List<MapOutput<K,V>> inMemoryMapOutputs,
                                         List<Path> onDiskMapOutputs
                                         ) throws IOException {
      LOG.info("finalMerge called with " + 
               inMemoryMapOutputs.size() + " in-memory map-outputs and " + 
               onDiskMapOutputs.size() + " on-disk map-outputs");
      
      BinaryComparator keyComparator = job.getMergeKeyComparator(ioPhase);
      BinaryComparator valueCompartor = job.getMergeValComparator(ioPhase);
      final float maxRedPer = job.getConfig().getFloat(MRConfig.REDUCE_INPUT_BUFFER_PERCENT, 0f);
      if (maxRedPer > 1.0 || maxRedPer < 0.0) {
        throw new IOException(MRConfig.REDUCE_INPUT_BUFFER_PERCENT +
                              maxRedPer);
      }
      int maxInMemReduce = (int)Math.min(
          Runtime.getRuntime().maxMemory() * maxRedPer, Integer.MAX_VALUE);
      

      // merge config params
      boolean keepInputs = job.getKeepFailedTaskFiles();

      // segments required to vacate memory
      List<IFileMerger.Segment<K,V>> memDiskSegments = new ArrayList<IFileMerger.Segment<K,V>>();
      long inMemToDiskBytes = 0;
      boolean mergePhaseFinished = false;
      if (inMemoryMapOutputs.size() > 0) {
        TaskID mapId = inMemoryMapOutputs.get(0).getMapId();
        inMemToDiskBytes = createInMemorySegments(inMemoryMapOutputs, 
                                                  memDiskSegments,
                                                  maxInMemReduce);
        final int numMemDiskSegments = memDiskSegments.size();
        if (numMemDiskSegments > 0 &&
              ioSortFactor > onDiskMapOutputs.size()) {
          
          // If we reach here, it implies that we have less than io.sort.factor
          // disk segments and this will be incremented by 1 (result of the 
          // memory segments merge). Since this total would still be 
          // <= io.sort.factor, we will not do any more intermediate merges,
          // the merge of all these disk segments would be directly fed to the
          // reduce method
          
          mergePhaseFinished = true;
          // must spill to disk, but can't retain in-mem for intermediate merge
          final Path outputPath = new Path(localDirAllocator.getLocalFileForWrite(mapId + MERGED_OUTPUT_PREFIX,inMemToDiskBytes));
          
          final RawKeyValueIterator rIter = IFileMerger.merge(job.getConfig(), localDirAllocator, fs,
              keyClass, valueClass,
              null,
              memDiskSegments, ioSortFactor, numMemDiskSegments,
              keyComparator, valueCompartor,
              false, null, null);
//              tmpDir, comparator, reporter, spilledRecordsCounter, null, 
//              mergePhase);
          final IFile.Writer<K,V> writer = new IFile.Writer<K,V>(fs, outputPath,
              keyClass, valueClass, compressAlgo, null);
          try {
            IFileMerger.writeFile(rIter, writer, job.getConfig());
            // add to list of final disk outputs.
            onDiskMapOutputs.add(outputPath);
          } catch (IOException e) {
            if (null != outputPath) {
              try {
                fs.delete(outputPath);
              } catch (IOException ie) {
                // NOTHING
              }
            }
            throw e;
          } finally {
            if (null != writer) {
              writer.close();
            }
          }
          LOG.info("Merged " + numMemDiskSegments + " segments, " +
                   inMemToDiskBytes + " bytes to disk to satisfy " +
                   "reduce memory limit");
          inMemToDiskBytes = 0;
          memDiskSegments.clear();
        } else if (inMemToDiskBytes != 0) {
          LOG.info("Keeping " + numMemDiskSegments + " segments, " +
                   inMemToDiskBytes + " bytes in memory for " +
                   "intermediate, on-disk merge");
        }
      }

      // segments on disk
      List<IFileMerger.Segment<K,V>> diskSegments = new ArrayList<IFileMerger.Segment<K,V>>();
      long onDiskBytes = inMemToDiskBytes;
      Path[] onDisk = onDiskMapOutputs.toArray(new Path[onDiskMapOutputs.size()]);
      for (Path file : onDisk) {
        onDiskBytes += fs.getLength(file);
        LOG.fine("Disk file: " + file + " Length is " + fs.getLength(file));
        
        LOG.warning("DEBUG: mergedMapOutputsCounter=" + mergedMapOutputsCounter + ", file=" + file.toString());
        diskSegments.add(new IFileMerger.Segment<K, V>(job.getConfig(), fs, file, compressAlgo, keepInputs,
                                           (file.toString().endsWith( MERGED_OUTPUT_PREFIX) ?
                                                   null : mergedMapOutputsCounter)
                                          ));
      }
      LOG.info("Merging " + onDisk.length + " files, " +
               onDiskBytes + " bytes from disk");
      Collections.sort(diskSegments, new Comparator<IFileMerger.Segment<K,V>>() {
        public int compare(IFileMerger.Segment<K, V> o1, IFileMerger.Segment<K, V> o2) {
          if (o1.getLength() == o2.getLength()) {
            return 0;
          }
          return o1.getLength() < o2.getLength() ? -1 : 1;
        }
      });

      // build final list of segments from merged backed by disk + in-mem
      List<IFileMerger.Segment<K,V>> finalSegments = new ArrayList<IFileMerger.Segment<K,V>>();
      long inMemBytes = createInMemorySegments(inMemoryMapOutputs, 
                                               finalSegments, 0);
      LOG.info("Merging " + finalSegments.size() + " segments, " +
               inMemBytes + " bytes from memory into reduce");
      if (0 != onDiskBytes) {
        final int numInMemSegments = memDiskSegments.size();
        diskSegments.addAll(0, memDiskSegments);
        memDiskSegments.clear();
        // Pass mergePhase only if there is a going to be intermediate
        // merges. See comment where mergePhaseFinished is being set
        RawKeyValueIterator diskMerge = IFileMerger.merge(
            job.getConfig(), localDirAllocator, fs, 
            keyClass, valueClass,
            null,
            diskSegments, ioSortFactor, numInMemSegments,
            keyComparator, valueCompartor,
            false, null, null);
        diskSegments.clear();
        if (0 == finalSegments.size()) {
          return diskMerge;
        }
        finalSegments.add(new IFileMerger.Segment<K,V>(
              new RawKVIteratorReader(diskMerge, onDiskBytes), true));
      }
      return IFileMerger.merge(job.getConfig(), localDirAllocator, fs,
              keyClass, valueClass,
              null,
              finalSegments, ioSortFactor, finalSegments.size(),
              keyComparator, valueCompartor,
              false, null, null);
    
    }
  }

