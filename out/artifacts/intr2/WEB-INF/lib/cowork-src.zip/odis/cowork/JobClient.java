/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.cowork.IJobSubmissionProtocol.JobStatus;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import toolbox.misc.LogFormatter;

/**
 * The job client that provide method to submit job to job master.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public class JobClient {
  
  private static final Logger LOG = 
    LogFormatter.getLogger(JobClient.class.getName());
 
  public static final long RETRY_WAITING_INTERVAL = 
    OdisLibConfig.conf().getLong("cowork.retry-wait",60000); // 60s
  public static final int RETRY_MAX_NUMBER = 
    OdisLibConfig.conf().getInt("cowork.retry-num", 10);  // retry 10 times
  public static final int MAX_WORKER_CROSS_CU = 
	OdisLibConfig.conf().getInt("cowork.max-worker-cross-cu",512); // can't submit big than 128
  
  public static JobResult runJob(InetSocketAddress jmAddr, JobDef job) { 
    if (!job.isValid()) {
      LOG.severe("The job is not submitted, missing/invalid settings.");
      return new JobResult(false, null, null);
    }
    
    // prepare before submit
    try {
        job.prepareBeforeSubmit();
    } catch(IOException e) {
        LOG.log(Level.SEVERE, "prepare before submit failed", e);
        return new JobResult(false, null, null);
    }
    
    job.setUser(System.getProperty("user.name"));
    if (jmAddr==null) {
      LocalJobMaster jm = new LocalJobMaster();
      boolean isSucc = (jm.submitJob(job.getConfig())!=null);
      job.cleanup(jm.jobId);
      return new JobResult(isSucc,jm.getTaskMsgs(null),jm.getJobCounters(null));
    } else
      try {
        return runRemote(jmAddr, job);
      } catch (RpcException e) {
        LOG.log(Level.WARNING, "RPC error when submitting job.", e);
        return new JobResult(false, null, null);
      }
  }

  private static JobResult runRemote(InetSocketAddress jmAddr, JobDef job) throws RpcException {

    IJobMasterProtocol jsp = RPC.getProxy(
        IJobMasterProtocol.class, jmAddr);

    long updateInterval = 0;
    try {
      updateInterval = jsp.getUpdateInterval(JobMaster.VERSION);
    } catch (IllegalArgumentException e) {
      LOG.log(Level.SEVERE, "Version mismatch", e);
      throw new RpcException("Abort job submission because of odis.jar version mismatch");
    }
    
    JobStatus js;
    try {
        js = jsp.submitJob(job.getConfig());
    } catch(IllegalAccessError e) {
        LOG.log(Level.SEVERE, "user rejected : " + e.getMessage());
        js = null;
    }
    if (js == null) return new JobResult(false,null,null);
    
    String jobId = js.getJobId();
    
    ExitHookThread hook = new ExitHookThread(jsp,job,jobId, updateInterval);
    Runtime.getRuntime().addShutdownHook(hook);
    
    JobStatus prevStatus = null;
    
    int retry=0;
    while (!js.isFinished()) {
      if (js.isIdle()) {
        if (prevStatus==null)
          LOG.info("Job " + js.getJobId() + " preparing ...");
        else {
          LOG.info("Still waiting for workers, retry no. " + retry);
          retry++;
          if (retry > RETRY_MAX_NUMBER) {
            throw new JobSubmitTimeoutException(
                    "job timeout after retry for " + RETRY_MAX_NUMBER + " times");
          }
          try { Thread.sleep(RETRY_WAITING_INTERVAL); }
          catch (InterruptedException e) { }
        }
        prevStatus = js;
      } else LOG.info(getStatusString(job,js));

      try {
        Thread.sleep(updateInterval);
      } catch (InterruptedException e) {
        LOG.finest("Thread.sleep() exception in JobConf.run().");
      }

      js = jsp.getJobStatus(jobId);
      
      if (js==null) break;
    } // while

    if (js==null) {
      LOG.warning("Lost job finish status, you must check job master log or report a bug.");
      return new JobResult(false, null, null);
    }
    
    // get return status
    String jobMsg = jsp.getJobMsg(jobId);
    String[][] msgs = jsp.getTaskMsgs(jobId);
    CounterMap[] counters = jsp.getJobCounters(jobId);
    
    // output information
    boolean isSuccess = true;    
    StringBuffer sb = new StringBuffer();
    if (js.isIdle())
        sb.append("Preparing for " + jobId + " ... ");
    else if (js.isFinished())
        sb.append(getStatusString(job,js));
    if (js.getState()==IJobSubmissionProtocol.JOB_STATE_CLOSING) {
        sb.append(" (Done)"); isSuccess = true;
    } else {
        sb.append(" (Abort)"); isSuccess = false;
    }
    LOG.info(sb.toString());
    if ( jobMsg!=null && !"".equals(jobMsg))
        LOG.info(jobMsg);
    
    // remove job from queue
    jsp.removeJob(jobId);
    
    // cleanup ovary directories by this job
    LOG.info("Wait for " + (updateInterval/1000+1) + "s in order to clean temporary files.");
    try { Thread.sleep(updateInterval+1000); } catch (InterruptedException e) { }
    job.cleanup(jobId);

    Runtime.getRuntime().removeShutdownHook(hook);

    return new JobResult(isSuccess,msgs, counters, js.getJobId());
  }
  
  private static String getStatusString(JobDef job, JobStatus js) {
      int stage = Math.min(job.getTotalStage()-1,js.getStage());
      float[] progress = js.getProgress();
      int[] iProgress = new int[progress.length];
      StringBuffer sb = new StringBuffer();        
      for (int i=0; i<progress.length; i++)
        iProgress[i] = Math.round(progress[i]*100);
      sb.append(job.getStageName(stage) + " " + iProgress[stage]+"% -- ");
      sb.append(Arrays.toString(iProgress));
      return sb.toString();
  }
  
  private static class ExitHookThread extends Thread {
    private IJobSubmissionProtocol jobmaster;
    private String jobId;
    private JobDef job;
    private long updateInterval;
      
    public ExitHookThread(IJobSubmissionProtocol jobmaster, JobDef job, 
        String jobId, long upInterval) throws RpcException {
      super();
      this.jobmaster = jobmaster;
      this.updateInterval = upInterval;
      this.jobId = jobId;
      this.job = job;
    }
      
    public void run() {
      try {
        LOG.info("JobClient is now in exiting hook");
        jobmaster.abortJob(jobId);
        // remove job from queue
        jobmaster.removeJob(jobId);
        // cleanup ovary directories by this job
        LOG.info("Wait for " + (updateInterval/1000+1) + "s in order to clean temporary files.");
        try { Thread.sleep(updateInterval+1000); } catch (InterruptedException e) { }
        job.cleanup(jobId);
      } catch (RpcException e) {
        LOG.log(Level.WARNING, "RPC error when aborting job: "+jobId, e);
      }
    }    
  }

}
