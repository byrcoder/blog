/**
 * @(#)ClusterNodeInfo.java, 2012-11-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * 
 * Todo:
 * 
 * 
 * @author chenheng
 *
 */
public class ClusterNodeInfo implements IWritable {

    public static final float MAX_LOAD_RATE = 1.25f;
    private StringWritable name = new StringWritable(); 
    private InetSocketAddressWritable address = new InetSocketAddressWritable(); 
    private ComputeSpecs total = new ComputeSpecs(); 
    private ComputeSpecs remaining = new ComputeSpecs(); 
    private double oneMinLoad = -1;
    private long swapUsed = -1;
    private int taskHeapLimit = -1;
    
    //No need to tranfer
    private ComputeSpecs reserve = new ComputeSpecs();
    private long lastHeartBeatTime = 0; 
    private Map<String, ComputeSpecs> reserveMap = new HashMap<String, ComputeSpecs>();
    private Map<String, ComputeSpecs> usingMap = new HashMap<String, ComputeSpecs>();
    private int status = NORMAL;
    
    public static final int NORMAL = 0;
    public static final int ABNORMAL = -1;
    private int resourceNum = 0;
    
    public ClusterNodeInfo() {
        this.status = NORMAL;
    }
    
    public ClusterNodeInfo(String name, InetSocketAddress address, ComputeSpecs total, int limit) {
        this.name.set(name);
        this.address.setHostAndPort(address.getHostName(), address.getPort());
        this.total.copyFields(total);
        this.remaining.copyFields(total);
        this.taskHeapLimit = limit;
        this.status = NORMAL;
    }
    
    @Override
    public IWritable copyFields(IWritable value) {
        if (this == value) {
            return this;
        }
        if (value == null || !(value instanceof ClusterNodeInfo)) {
            throw new RuntimeException("bad value:" + value);
        }
        ClusterNodeInfo that = (ClusterNodeInfo) value;
        this.name.copyFields(that.name);
        this.address.copyFields(that.address);
        this.total.copyFields(that.total);
        this.remaining.copyFields(that.remaining);
        this.oneMinLoad = that.oneMinLoad;
        this.swapUsed = that.swapUsed;
        this.taskHeapLimit = that.taskHeapLimit;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        this.name.writeFields(out);
        this.address.writeFields(out);
        this.total.writeFields(out);
        this.remaining.writeFields(out);
        out.writeDouble(this.oneMinLoad);
        out.writeLong(this.swapUsed);
        out.writeInt(this.taskHeapLimit);
    }
    @Override
    public void readFields(DataInput in) throws IOException {
        this.name.readFields(in);
        this.address.readFields(in);
        this.total.readFields(in);
        this.remaining.readFields(in);
        this.oneMinLoad = in.readDouble();
        this.swapUsed = in.readLong();
        this.taskHeapLimit = in.readInt();
    }

    public ComputeSpecs getRemaining() {
        return this.remaining;
    }

    public StringWritable getName() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public InetSocketAddressWritable getAddress() {
        return address;
    }

    public void setAddress(InetSocketAddressWritable address) {
        this.address.copyFields(address);
    }

    public ComputeSpecs getTotal() {
        return total;
    }

    public void setTotal(ComputeSpecs total) {
        this.total.copyFields(total);
    }

    public void setRemaining(ComputeSpecs remaining) {
        this.remaining.copyFields(remaining);
    }

    public double getOneMinLoad() {
        return oneMinLoad;
    }

    public void setOneMinLoad(double oneMinLoad) {
        this.oneMinLoad = oneMinLoad;
    }

    public long getSwapUsed() {
        return swapUsed;
    }

    public void setSwapUsed(long swapUsed) {
        this.swapUsed = swapUsed;
    }

    public int getTaskHeapLimit() {
        return taskHeapLimit;
    }

    public void setTaskHeapLimit(int limit) {
        this.taskHeapLimit = limit;
    }

    public boolean satisfy(int taskHeap, int cpuNum) {
        if (getDiff(remaining.getMemoryMB().get(), reserve.getMemoryMB().get()) >= taskHeap
                && getDiff(remaining.getCpuNums().get(), reserve.getCpuNums().get()) >= cpuNum) {
            return true;
        }
        return false;
    }

    public int getDiff(int remaining, int reserve) {
        return remaining - reserve;
    }
    
    public void reserve(String resourceID, ComputeSpecs resourcePerTask) {
        reserve.setCpuNums(reserve.getCpuNums().get() + resourcePerTask.getCpuNums().get());
        reserve.setMemoryMB(reserve.getMemoryMB().get() + resourcePerTask.getMemoryMB().get());
        reserveMap.put(resourceID, resourcePerTask);
    }

    public void unreserve(String resourceID, ComputeSpecs resourcePerTask) {
        reserve.setCpuNums(reserve.getCpuNums().get() - resourcePerTask.getCpuNums().get());
        reserve.setMemoryMB(reserve.getMemoryMB().get() - resourcePerTask.getMemoryMB().get());
        reserveMap.remove(resourceID);
    }

    public ComputeSpecs getReserve() {
        return this.reserve;
    }
    
    public int getResourceNum() {
        if (resourceNum % 100001 == 0) {
            resourceNum = 0;
        }
        return resourceNum++;
    }
    
    public double getLoadRate() {
        if (total.getCpuNums().get() <= 0)
            return 0;
        return oneMinLoad / total.getCpuNums().get();
    }
    
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Map<String, ComputeSpecs> getReserveMap() {
        return reserveMap;
    }

    public void setReserveMap(Map<String, ComputeSpecs> reserveMap) {
        this.reserveMap = reserveMap;
    }

    public Map<String, ComputeSpecs> getUsingMap() {
        return usingMap;
    }

    public void setUsingMap(Map<String, ComputeSpecs> usingMap) {
        this.usingMap = usingMap;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("name:").append(this.name.get())
        .append(", address:").append(this.address.toString())
        .append(", total:").append(this.total.toString())
        .append(", remaining:").append(this.remaining.toString())
        .append(", oneMinLoad:").append(this.oneMinLoad)
        .append(", swapUsed:").append(this.swapUsed)
        .append(", taskHeapLimit:").append(this.taskHeapLimit)
        .append(", status:").append(this.status)
        .append(", reserve:").append(this.reserve.toString()).append("\n")
        .append(", reserveMap:").append(this.reserveMap).append("\n")
        .append(", usingMap:").append(this.usingMap).append("\n"); 
        
        return sb.toString();
    }
    
    public boolean isValid() {
        if (remaining.getMemoryMB().get() == -1) {
            return false;
        }
        return true;
    }

    /**
     * @return the lastHeartBeatTime
     */
    public long getLastHeartBeatTime() {
        return lastHeartBeatTime;
    }

    /**
     * @param lastHeartBeatTime the lastHeartBeatTime to set
     */
    public void setLastHeartBeatTime(long lastHeartBeatTime) {
        this.lastHeartBeatTime = lastHeartBeatTime;
    }
}
