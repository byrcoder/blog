package odis.cowork.analyzer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.logging.Logger;
import odis.conf.CoworkConfig;
import odis.cowork.analyzer.CoWorkAnalyzer.JobDetail;
import odis.cowork.analyzer.CoWorkAnalyzer.ProgramDetail;
import odis.cowork.analyzer.CoWorkAnalyzer.UserDetail;
import toolbox.maintain.alarm.Emailer;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

public class AnalyzerTool {
    private static final Logger LOG = LogFormatter.getLogger(AnalyzerTool.class);

    public static final SimpleDateFormat HHFormatter = new SimpleDateFormat(
            "HH");

    public static final Date HHDate = new Date();

    //hour of time
    public static String parseHour(long time) {
        HHDate.setTime(time);
        return HHFormatter.format(HHDate);
    }

    @SuppressWarnings({
        "unchecked", "unchecked", "unchecked"
    })
    public static String composeDailyReportMail(CoWorkAnalyzer analyzer)
            throws Exception {
        HashMap<String, UserDetail> userMap = analyzer.listTodayUserDetails();
        HashMap<String, ProgramDetail> programMap = analyzer.listTodayProgramDetails();
        ArrayList<UserDetail> userDetailList = new ArrayList<UserDetail>();
        ArrayList<ProgramDetail> programDetailList = new ArrayList<ProgramDetail>();
        for(Map.Entry<String, UserDetail> entry : userMap.entrySet()) {
            userDetailList.add(entry.getValue());
        }
        for(Map.Entry<String, ProgramDetail> entry : programMap.entrySet()) {
            programDetailList.add(entry.getValue());
        }
        Collections.sort(userDetailList, new Comparator() {
            @Override
            public int compare(final Object o1, final Object o2) {
                double h2 = ((UserDetail) o2).getClaimedUsedWorkerHour();
                double h1 = ((UserDetail) o1).getClaimedUsedWorkerHour();
                if (h2 > h1)
                    return 1;
                else if (h2 < h1)
                    return -1;
                else
                    return 0;
            }
        });

        HashMap<String, JobDetail> js = analyzer.listTodayJobDetail();
        PriorityQueue<JobDetail> maxInputSizeHeap = new PriorityQueue<JobDetail>(
                js.size(), new Comparator<JobDetail>() {
                    @Override
                    public int compare(JobDetail o1, JobDetail o2) {
                        double s1 = o1.getTotalMapInSize();
                        double s2 = o2.getTotalMapInSize();
                        if (s2 > s1)
                            return 1;
                        else if (s1 > s2)
                            return -1;
                        return 0;
                    }
                });

        PriorityQueue<JobDetail> maxResourceHeap = new PriorityQueue<JobDetail>(
                js.size(), new Comparator<JobDetail>() {
                    @Override
                    public int compare(JobDetail o1, JobDetail o2) {
                        double s1 = o1.getClaimedUsedWorkerHour();
                        double s2 = o2.getClaimedUsedWorkerHour();
                        if (s2 > s1)
                            return 1;
                        else if (s1 > s2)
                            return -1;
                        return 0;
                    }
                });

        PriorityQueue<JobDetail> minUsedRatio = new PriorityQueue<JobDetail>(
                js.size(), new Comparator<JobDetail>() {
                    @Override
                    public int compare(JobDetail o1, JobDetail o2) {
                        double s1 = o1.getUtilityRatio();
                        double s2 = o2.getUtilityRatio();
                        if (s1 > s2)
                            return 1;
                        else if (s2 > s1)
                            return -1;
                        return 0;
                    }
                });

        int succCount = 0, failCount = 0;
        for (Map.Entry<String, JobDetail> entry: js.entrySet()) {
            JobDetail j = entry.getValue();
            if (j.isSuccess())
                ++succCount;
            else {
                ++failCount;
                continue;
            }
            maxInputSizeHeap.add(j);
            maxResourceHeap.add(j);
            minUsedRatio.add(j);
        }
        StringBuilder content = new StringBuilder();
        content.append("<html>\n");
        content.append("<h2> 24小时内成功执行了<font color=red> " + succCount
                + "</font> Job, 失败: <font color=red>" + failCount
                + "</font></h2>");
        content.append("<li>用户共申请的资源 : ").append(
                CoWorkAnalyzer.getClaimedUsedWorkerHour(js.values())).append(
                " worker*hour</li>");
        content.append("<li>实际使用了 : ").append(
                CoWorkAnalyzer.getActualUsedWorkerHour(js.values())).append(
                " worker*hour").append("; 资源利用率:").append(
                CoWorkAnalyzer.getUtilityRatio(js.values())).append("</li>");
        content.append("<li>处理的数据总量: ").append(
                CoWorkAnalyzer.getTotalMapInSize(js.values()) / (1024 * 1024)).append(
                "M</li>");

        content.append("<hr>");

        content.append("<li>各时间段的Worker空闲状况</li>\n");

        ArrayList<String> timeAxis = new ArrayList<String>();
        ArrayList<Integer> workerAxis = new ArrayList<Integer>();
        analyzer.buildFreeWorkerDistribute(getYesterdayStartTime(), 30,
                timeAxis, workerAxis);

        int loop = 0;
        String timeTD = "<td>时间</td>";
        String workerTD = "<td>平均空闲Worker</td>";
        while (loop < timeAxis.size()) {
            timeTD = timeTD + "<td>" + timeAxis.get(loop) + "</td>";
            workerTD = workerTD + "<td align=center>" + workerAxis.get(loop)
                    + "</td>";
            ++loop;
            if (loop % 16 == 0 || loop == timeAxis.size()) {
                content.append("<table>");
                content.append("<tr>").append(timeTD).append("</tr>");
                content.append("<tr>").append(workerTD).append("</tr>");
                content.append("</table>");
                timeTD = "<td>时间</td>";
                workerTD = "<td>平均空闲Worker</td>";
            }
        }

        content.append("<hr>");
        content.append("<li>Top10 用户</li>\n");
        content.append("<table align=center> <tr> <td>用户</td> <td>完成的Job数</td> <td>统计</td> </tr>");
        int i = 0;
        for (UserDetail user: userDetailList) {
            content.append("<tr>");
            content.append("<td>").append(user.getUser()).append("</td>");
            content.append("<td>").append(user.getJobsNumber()).append("</td>");
            content.append("<td>").append("申请的资源: <font color=\"green\">").append(
                    user.getClaimedUsedWorkerHour()).append("</font></BR>");
            content.append("<td>").append("实际使用: <font color=\"green\">").append(
                    user.getActualUsedWorkerHour()).append("</font></BR>");
            content.append("<td>").append("资源利用率: <font color=\"green\">").append(
                    user.getUtilityRatio()).append("</font></BR>");
            content.append("</td></tr>");
            ++i;
            if (i >= 10)
                break;
        }
        content.append("</table><hr>\n");

        content.append("<li>占用资源最多的Top10 Job</li>\n");
        content.append("<table align=center> <tr> <td>Job 名称</td> <td>使用资源 (worker * hour)</td> <td> Worker数目 </td> <td> 资源利用率 </td> <td>开始时间</td> <td> 结束时间 </td> </tr>");
        i = 0;
        while (maxResourceHeap.peek() != null) {
            JobDetail j = maxResourceHeap.poll();
            content.append("<tr>");
            content.append("<td>").append(j.getJobName()).append("</td>");
            content.append("<td>").append(j.getClaimedUsedWorkerHour()).append(
                    "</td>");
            content.append("<td>").append(j.getClaimedWorkerNum()).append(
                    "</td>");
            content.append("<td>").append(j.getUtilityRatio()).append("</td>");
            content.append("<td>").append(new Date(j.getStartTime()).toString()).append(
                    "</td>");
            content.append("<td>").append(new Date(j.getEndTime()).toString()).append(
                    "</td>");
            content.append("</tr>");
            ++i;
            if (i >= 10)
                break;
        }
        content.append("</table><hr>\n");

        content.append("\n<li>输入数据量最多的Top10 Job</li>\n");
        content.append("<table align=center> <tr> <td>Job 名称</td> <td>数据量(M)</td> <td> Worker数目 </td> <td> 资源利用率 </td> <td>开始时间</td> <td> 结束时间 </td> </tr>");
        i = 0;
        while (maxInputSizeHeap.peek() != null) {
            JobDetail j = maxInputSizeHeap.poll();
            content.append("<tr>");
            content.append("<td>").append(j.getJobName()).append("</td>");
            content.append("<td>").append(j.getTotalMapInSize() / (1024 * 1024)).append(
                    "</td>");
            content.append("<td>").append(j.getClaimedWorkerNum()).append(
                    "</td>");
            content.append("<td>").append(j.getUtilityRatio()).append("</td>");
            content.append("<td>").append(new Date(j.getStartTime()).toString()).append(
                    "</td>");
            content.append("<td>").append(new Date(j.getEndTime()).toString()).append(
                    "</td>");
            content.append("</tr>");
            ++i;
            if (i >= 10)
                break;
        }
        content.append("</table><hr>\n");

        content.append("\n<li>利用率最低的Bottom20 Job</li>\n");
        content.append("<table align=center> <tr> <td>Job 名称</td> <td>资源利用率</td> <td> Worker数目 </td> <td> 资源利用率 </td> <td>开始时间</td> <td> 结束时间 </td> </tr>");
        i = 0;
        while (minUsedRatio.peek() != null) {
            JobDetail j = minUsedRatio.poll();
            content.append("<tr>");
            content.append("<td>").append(j.getJobName()).append("</td>");
            content.append("<td>").append(j.getUtilityRatio()).append("</td>");
            content.append("<td>").append(j.getClaimedWorkerNum()).append(
                    "</td>");
            content.append("<td>").append(j.getUtilityRatio()).append("</td>");
            content.append("<td>").append(new Date(j.getStartTime()).toString()).append(
                    "</td>");
            content.append("<td>").append(new Date(j.getEndTime()).toString()).append(
                    "</td>");
            content.append("</tr>");
            ++i;
            if (i >= 20)
                break;
        }
        content.append("</table><hr>\n");
        content.append("</html>");
        return content.toString();
    }

    public static void sendDailyReportMail(String jobMaster, String content) {
        Emailer.refreshConfig();
        Emailer mailer = new Emailer();
        String receiver = CoworkConfig.conf().getString(
                "cowork.jobmaster.analyzer.email-receiver",
                "infra@rd.netease.com");
        mailer.sendEmail("postmaster@rd.netease.com", receiver,
                "Cowork daily report of " + jobMaster + " on "
                        + getCurrentDay(), content, null);
    }

    public static void sendDailyReportMail(String jobMaster, String receiver,
            String content) {
        Emailer.refreshConfig();
        Emailer mailer = new Emailer();
        mailer.sendEmail("postmaster@rd.netease.com", receiver,
                "Cowork daily report of " + jobMaster + " on "
                        + getCurrentDay(), content, null);
    }

    public static long getYesterdayStartTime() throws Exception {
        return getDayStartTime(CoWorkAnalyzer.formatter1.format(new Date(
                System.currentTimeMillis() - UnitUtils.DAY)));
    }

    protected static final SimpleDateFormat formatter4 = new SimpleDateFormat(
            "yyMMdd HH:mm:ss");

    /**
     * day is like 091125
     * 
     * @param day
     * @return
     * @throws Exception
     */
    public static long getDayStartTime(String day) throws Exception {
        return formatter4.parse(day + " 00:00:00").getTime();
    }

    public static String getCurrentDay() {
        return CoWorkAnalyzer.formatter1.format(new Date(
                System.currentTimeMillis()));
    }

    private static void makeFakeFreeWorker(CoWorkAnalyzer analyzer) {
        long cur = System.currentTimeMillis();
        for (int i = 0; i < 24 * 60; ++i) {
            analyzer.takeFreeWorkerSample(cur + i * UnitUtils.MINUTE, i);
        }
    }

    public static void printHelp() {
        System.out.println("Usage:");
        System.out.println("  daily-mail xxx@rd.netease.com /path/of/jobmaster/log");
    }

    public static void main(String[] args) {
        try {
            if (args[0].equals("daily-mail")) {
                CoWorkAnalyzer.setupLogDir(args[2]);
                CoWorkAnalyzer analyzer = new CoWorkAnalyzer();
                makeFakeFreeWorker(analyzer);
                sendDailyReportMail("tbxxx", args[1],
                        composeDailyReportMail(analyzer));
            } else {
                printHelp();
            }
        } catch (Exception e) {
            e.printStackTrace();
            printHelp();
        }
    }
}
