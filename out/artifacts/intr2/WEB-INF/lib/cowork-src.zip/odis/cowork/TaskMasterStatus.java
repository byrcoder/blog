package odis.cowork;

import static odis.cowork.IJobMasterProtocol.TASK_CMD_DEL_TASK;
import static odis.cowork.IJobMasterProtocol.TASK_CMD_NEW_TASK;
import static odis.cowork.IJobMasterProtocol.TASK_CMD_NULL;
import static odis.cowork.IJobMasterProtocol.TASK_CMD_UPD_TASK;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.serialize.IWritable;
import toolbox.misc.LogFormatter;

/**
 * Elements in task master queue. Record status of task masters TaskMasterStatus
 * can be vied as the "agent" of TaskMaster in JobMaster: Once a task is
 * assigned/deleted to TaskMasterStatus or any command is given to
 * TaskMasterStatus, JobMaster regard it as a notice to TaskMaster (and assume
 * the notice has been delivered). Later in case TaskMaster didn't get the
 * notice because of lost, we do rollback all undelivered notice.
 */
public class TaskMasterStatus {
    private static final Logger LOG = LogFormatter
            .getLogger(TaskMasterStatus.class);

    public static final long RPC_EXEC_LIMIT = CoworkConfig.conf().getLong(
            "cowork.jobmaster.heartbeat.rpc-exec-limit", 150); // 150ms

    // basic task master information
    protected final String id; // task master id

    protected final String hostname; // hostname of the task master

    private final int filePort, rpcPort; // ports of the task master

    protected final int capacity; // # of workers avaiable at the task master

    private final JobMaster jobMaster;

    private ResourceStatus reStatus;

    /** create a record of task master (when the hello() message is received) */
    public TaskMasterStatus(String tid, String hostname, int rpcPort,
            int filePort, int slot, JobMaster tmMgr) {
        id = tid;
        capacity = slot;
        this.hostname = hostname;
        this.filePort = filePort;
        this.rpcPort = rpcPort;
        lastHeartbeat = System.currentTimeMillis();
        preRunningTasks = new HashSet<TaskDef>();
        preDeletingTasks = new HashSet<TaskDef>();
        preUpdatingTasks = new HashSet<TaskDef>();
        livingTasks = new HashSet<TaskDef>();
        deletingTasks = new HashSet<TaskDef>();
        runningCount = new HashMap<String, Integer>();
        this.jobMaster = tmMgr;
        reStatus = new ResourceStatus();
    }

    protected TaskMasterStatus getShadowCopy() {
        TaskMasterStatus tms = new TaskMasterStatus(id, hostname, rpcPort,
                filePort, capacity, jobMaster);
        tms.lastHeartbeat = this.lastHeartbeat;
        tms.preRunningTasks = new HashSet<TaskDef>(this.preRunningTasks);
        tms.preDeletingTasks = new HashSet<TaskDef>(this.preDeletingTasks);
        tms.preUpdatingTasks = new HashSet<TaskDef>(this.preUpdatingTasks);
        tms.livingTasks = new HashSet<TaskDef>(this.livingTasks);
        tms.deletingTasks = new HashSet<TaskDef>(this.deletingTasks);
        tms.runningCount = new HashMap<String, Integer>(this.runningCount);
        tms.totalRunning = this.totalRunning;
        tms.reStatus.copyFields(this.reStatus);
        return tms;
    }

    public String toString() {
        return id + "(" + fileAddr() + " x " + capacity + ")";
    }

    ////////////////////////////////////////////////////////////////////////////
    // Access Method
    ////////////////////////////////////////////////////////////////////////////
    public String getId() {
        return id;
    }

    public String rpcAddr() {
        return hostname + ":" + rpcPort;
    }

    public String fileAddr() {
        return hostname + ":" + filePort;
    }

    public int vacancy() {
        return capacity - totalRunningCount();
    }

    public int capacity() {
        return capacity;
    }

    // public int reservedNum() {return reservedNum; }
    public HashMap<String, Integer> running() {
        return runningCount;
    }

    private boolean resourceUpdataed = false;

    public void setResourceUpdated(boolean flag) {
        resourceUpdataed = flag;
    }

    public boolean isResourceUpdated() {
        return resourceUpdataed;
    }

    public ResourceStatus getResourceStatus() {
        return reStatus;
    }

    public void updateResourceStatus(ResourceStatus rs) {
        resourceUpdataed = true;
        reStatus.copyFields(rs);
    }

    ////////////////////////////////////////////////////////////////////////////
    // methods to used in hash map or hash set
    ////////////////////////////////////////////////////////////////////////////

    public int hashCode() {
        return id.hashCode();
    }

    public boolean equals(Object o) {
        if (o instanceof TaskMasterStatus) {
            TaskMasterStatus that = (TaskMasterStatus) o;
            if (this.id.equals(that.id)) {
                assert this.hostname.equals(that.hostname)
                        && this.filePort == that.filePort
                        && this.capacity == that.capacity;
                return true;
            } else
                return false;
        } else
            return false;
    }

    // parameters
    protected long lastHeartbeat; // last heart beat time

    // ////////////////////////////////////////////////////////////////////////
    // reserve or release workers.
    // ////////////////////////////////////////////////////////////////////////

    // ////////////////////////////////////////////////////////////////////////
    // undelivered notices (to TaskMaster) and TaskMaster recent states
    // ////////////////////////////////////////////////////////////////////////

    protected HashMap<String, Integer> runningCount; // stageId --> assigned #

    protected int totalRunning = 0;

    protected void decRunningCount(TaskDef task) {
        String stageId = task.getStageId();
        int c = getRunningCount(stageId);
        if (c < 1)
            LOG.warning(id + ": can't decrease running count of " + stageId
                    + "(c=" + c + ")");
        else
            totalRunning -= task.getResourceNeed();

        if (c == 1)
            runningCount.remove(stageId);
        else
            runningCount.put(stageId, c - 1);
    }

    public int getRunningCount(String stageId) {
        Integer c = runningCount.get(stageId);
        if (c == null)
            return 0;
        else
            return c;
    }

    public int totalRunningCount() {
        return totalRunning;
    }

    // undelivered notices: running/deleting/updating plans since last heartbeat
    // -- will be picked up and begin to run it at the next heartbeat()
    private HashSet<TaskDef> preRunningTasks; // need to send "new" commands

    private HashSet<TaskDef> preDeletingTasks; // need to send "delete" commands

    private HashSet<TaskDef> preUpdatingTasks; // need to send "update" commands

    // states after sending out ast heartbeat: running/success + deleting
    private HashSet<TaskDef> livingTasks; // running & success

    private HashSet<TaskDef> deletingTasks; // deleting tasks

    // private Map<String, HashSet<TaskDef>> assignedTasks;

    /**
     * Assign a new task to this master. This master will pick up this taks next
     * heartbeating time.
     * 
     * @param task
     *            The task assigned to this task master
     */
    public void assign(TaskDef task) {
        if (preRunningTasks.contains(task))
            LOG.info("Task " + task + " is already in pre-running set of "
                            + id);
        else {
            runningCount.put(task.getStageId(), getRunningCount(task
                    .getStageId()) + 1);
            totalRunning += task.getResourceNeed();
            preRunningTasks.add(task);
        }
    }

    /**
     * Notice new updates about this task (which is running on me)
     * 
     * @param task
     *            The task that was updated
     */
    public void notice(TaskDef task) {
        if (preRunningTasks.contains(task)) {
            if (LOG.isLoggable(Level.FINE))
                LOG.info("Skipping to update " + task
                        + " which is pre-running/preparing in " + id);
        } else if (preDeletingTasks.contains(task)) {
            if (LOG.isLoggable(Level.FINE))
                LOG.info("Skipping to update " + task
                        + " which is pre-deleting in " + id);
        } else if (livingTasks.contains(task)) {
            preUpdatingTasks.add(task);
        } else
            LOG.warning(id + ": Task "
                            + task
                            + " is not prepRunning/living/preparing, why UPDATE command?");
    }

    /**
     * Delete a pre-running or living (i.e. running or success) task on me - in
     * prep-running set ==> delete directly without any next step - in living
     * set ==> add to the pre-deleting set
     * 
     * @param task
     *            The task to be deleted from this task master
     * @param isRunning
     *            Whether the task is running
     */
    public void delete(TaskDef task, boolean isRunning) {
        if (preRunningTasks.contains(task)) { // pre-running --> delete from
                                              // list
            if (LOG.isLoggable(Level.FINE))
                LOG.info("Delete " + task + " from pre-running set of " + id);
            assert isRunning;
            preRunningTasks.remove(task);
            jobMaster.returnResource(task.taskMasterID, task.resourceID);
            decRunningCount(task);
        } else if (livingTasks.contains(task)) { // living --> delete from list
            if (preDeletingTasks.contains(task)) {
                assert !preUpdatingTasks.contains(task);
                LOG.warning("Won't delete " + task
                        + ": already in pre-deleting set of " + id);
            } else {
                // remove if in pre-updating set
                if (preUpdatingTasks.contains(task)) {
                    if (LOG.isLoggable(Level.FINE))
                        LOG.info("Delete " + task
                                + " from pre-updating set of " + id);
                    preUpdatingTasks.remove(task);
                }
                // remove task from living set
                // if (LOG.isLoggable(Level.FINE))
                LOG.info("Delete " + task + " from living set of " + id);
                preDeletingTasks.add(task);
                if (isRunning)
                    decRunningCount(task);
            }
        } else
            LOG.warning("Task(" + task
                    + ") is not pre-running/living, why DELETE command?");
    }

    /**
     * Update the lastHeartbeat only.
     */
    public void ping() {
        this.lastHeartbeat = System.currentTimeMillis();
    }

    /**
     * Process repots from this task master: update self status and job status
     * according to reports
     * 
     * @param reports
     *            Task reports from this task master
     */
    public void processReports(TaskReport[] reports) {
        // 1. update this task master: taskMasters is a LinkedHashMap, sorted
        // according to inserting time (eldest->newest)
        lastHeartbeat = System.currentTimeMillis();
        jobMaster.reQueueTaskMaster(this);
        // 2. update job-in-progress of those living (but not pre-deleting)
        // tasks
        int count = 0, prevCount = livingTasks.size();
        HashSet<TaskDef> reportTasks = new HashSet<TaskDef>();
        for (int i = 0; i < reports.length; i++) {
            // LOG.info("Begin process " + i +" report " + reports[i]);
            JobInProgress jip = jobMaster.getJob(reports[i].getJobId());
            TaskDef tr = null;
            if (jip != null)
                tr = jip.taskStatus[reports[i].getStageIdx()][reports[i]
                        .getPartIdx()].task;
            else {
                tr = reports[i].getTaskDef();
                LOG.warning("Some task can't find father job " + reports[i]);
                continue;
            }
            reportTasks.add(tr);
            assert reports[i].isRunning() || reports[i].isFinished();
            if (livingTasks.contains(tr)) { // in living task set
                count++;
                if (!preDeletingTasks.contains(tr)) { // living but not to be
                                                      // deleted
                    long start = System.currentTimeMillis();
                    assert jip != null: tr;
                    jip.update(id, reports[i]);
                    long end = System.currentTimeMillis();
                    if (end - start > RPC_EXEC_LIMIT)
                        LOG.warning("JobInProgress " + jip + " took "
                                + (end - start) + "ms to update " + reports[i]);
                } else if (!reports[i].isFinished()) { // Some unfinished task
                                                       // was
                    // marked as deleting. This is not wrong, but let us what
                    // happened.
                    LOG.info("Task " + tr
                            + " was marked as deleting, ignore report of "
                            + reports[i].getStateString() + " from " + id);
                    // You may want to assign task for this jip, since the
                    // purpose of
                    // deleting might be reassign some task and if there is no
                    // report
                    // updating for this jip in the future, this is the last
                    // chance! - Li
                }
            } else { // not in living task set
                LOG.warning("Unknown task(" + tr + ") is returned to " + id
                        + " as " + reports[i].getStateString()
                        + ", set as deleting...");
                assert !preDeletingTasks.contains(tr);
                preDeletingTasks.add(tr);
            }
        }
        // 3. check all previous living tasks returned
        if (count != prevCount) {
            LOG.warning("Expecting " + prevCount + " reports, but received "
                    + count + " reports from " + id + ": "
                    + Arrays.toString(reports));
            for (TaskDef task: livingTasks) {
                if (!reportTasks.contains(task))
                    LOG.warning("Missing task " + task + " from TaskMaster "
                            + id);
            }
        }
        // 4. check whether deleting tasks are really deleted
        Iterator<TaskDef> it = deletingTasks.iterator();
        while (it.hasNext()) {
            TaskDef task = it.next();
            if (reportTasks.contains(task)) // still not deleted
                LOG.warning("BUG: TaskMaster " + id + " didn't delete " + task
                        + " as I asked");
            else { // this pending deleted is actually done
                it.remove(); // not pending any more
            }
        }
    }

    /**
     * Generate commands list given sets: - preRunningTasks; // need to send
     * "new" commands - preDeletingTasks; // need to send "delete" commands -
     * preUpdatingTasks; // need to send "update" commands Note that there could
     * be a "delete" before "reassign", so, must process pre-deleting set first.
     */
    public TaskCommand[] generateCmds() {
        int n = preRunningTasks.size() + preDeletingTasks.size()
                + preUpdatingTasks.size();
        if (n == 0) // no work to do!
            return new TaskCommand[] {
                new TaskCommand(TASK_CMD_NULL, null, null, null, 1)
            };
        TaskCommand[] cmd = new TaskCommand[n];
        int i = 0;
        // pre-deleting tasks
        for (TaskDef tr: preDeletingTasks) {
            cmd[i++] = new TaskCommand(TASK_CMD_DEL_TASK, tr, null, null, tr
                    .getResourceNeed());
            livingTasks.remove(tr); // remove from livingTasks
            deletingTasks.add(tr); // add to deletingTasks (wait to clear)
            if (LOG.isLoggable(Level.FINE))
                LOG.fine(this.id + " is asked to delete " + tr.getTaskId()
                        + " ...");
        }
        preDeletingTasks.clear();
        // pre-running tasks
        for (TaskDef tr: preRunningTasks) {
            JobInProgress jip = jobMaster.getJob(tr.jobId);
            // String[] lastStageMachines = jip.getLastStageMachines(tr.stage);
            assert tr.equals(jip.taskStatus[tr.stage][tr.part].task);
            cmd[i++] = new TaskCommand(TASK_CMD_NEW_TASK, tr, jip
                    .getStageTaskEvents(tr.stage - 1, 0), jip.jobDef
                    .getConfig(), tr.getResourceNeed());
            assert !livingTasks.contains(tr): livingTasks + ":" + tr;
            deletingTasks.remove(tr); // not in deleting-set: special dealing
                                      // for
            // restart on the same machine
            livingTasks.add(tr); // add to living task
            LOG.info(this.id + " is asked to take " + tr.getTaskId() + " ...");
        }
        preRunningTasks.clear();
        // pre-updating tasks
        for (TaskDef tr: preUpdatingTasks) {
            JobInProgress jip = jobMaster.getJob(tr.jobId);
            // String[] lastStageMachines = jip.getLastStageMachines(tr.stage);
            assert tr.equals(jip.taskStatus[tr.stage][tr.part].task);
            TaskStatus ts = jip.taskStatus[tr.stage][tr.part];
            cmd[i++] = new TaskCommand(TASK_CMD_UPD_TASK, tr, jip
                    .getStageTaskEvents(tr.stage - 1, ts
                            .getLastEventIdx(this.id)), null, tr
                    .getResourceNeed());
            assert livingTasks.contains(tr) && !deletingTasks.contains(tr);
            LOG.info(this.id + " is asked to notice " + tr.getTaskId()
                    + " from event " + ts.getLastEventIdx(this.id));
        }
        preUpdatingTasks.clear();
        return cmd;
    }

    /**
     * This task master is lost, clear up and reset related states
     */
    @Deprecated
    public void cleanAfterLost() {
        // collect tasks according to job id
        HashMap<String, HashSet<TaskDef>> lostTasks = new HashMap<String, HashSet<TaskDef>>();
        for (TaskDef tr: preRunningTasks) { // pre-running set
            HashSet<TaskDef> taskSet = lostTasks.get(tr.jobId);
            if (taskSet == null)
                taskSet = new HashSet<TaskDef>();
            assert !taskSet.contains(tr);
            taskSet.add(tr);
            lostTasks.put(tr.jobId, taskSet);
            LOG.info("Losing pre-running task " + tr.getTaskId());
        }
        preRunningTasks.clear();
        for (TaskDef tr: livingTasks) { // living set
            HashSet<TaskDef> taskSet = lostTasks.get(tr.jobId);
            if (taskSet == null)
                taskSet = new HashSet<TaskDef>();
            assert !taskSet.contains(tr);
            taskSet.add(tr);
            lostTasks.put(tr.jobId, taskSet);
            LOG.info("Losing living task " + tr.getTaskId());
        }
        livingTasks.clear();

        // Notify those who reserved me that I am dead now
        // These jobs who reserve me must be running
        for (Map.Entry<String, HashSet<TaskDef>> entry: lostTasks.entrySet()) {
            String jobId = entry.getKey();
            HashSet<TaskDef> lTasks = entry.getValue();
            LOG.info("Notify job(" + jobId + ") about losing " + lTasks);
            JobInProgress jip = jobMaster.getJob(jobId);
            if (jip != null)
                jip.lostTasks(id, lTasks);
            else
                LOG.warning("Why jip is null???" + lTasks);
        }

        // beside jobs that reserves me, what else in lostTasks?
        if (!lostTasks.isEmpty())
            LOG.warning("LostTask is not empty: lost:reservation - "
                    + lostTasks + ":" + lostTasks);

        // clear pre-deleting and deleting tasks: since this task master was
        // lost
        // the deleting requests are automatically done!
        preDeletingTasks.clear();
        deletingTasks.clear();
    }

    public static class ResourceStatus implements IWritable {

        private long totalPhysicalMemory;

        private long[] availableSpace;

        private long availableMemory;

        private long swapUsed;

        private double oneMinLoad;

        private int cpus;

        public ResourceStatus() {
            totalPhysicalMemory = -1L;
            availableMemory = -1L;
            availableSpace = new long[0];
            cpus = -1;
            oneMinLoad = -1;
            swapUsed = -1;
        }

        void setTotalPhysicalMemory(long totalRAM) {
            totalPhysicalMemory = totalRAM;
        }

        long getTotalPhysicalMemory() {
            return totalPhysicalMemory;
        }

        long getSwapUsed() {
            return swapUsed;
        }

        void setSwapUsed(long swap) {
            this.swapUsed = swap;
        }

        void setAvailableSpace(long[] availSpace) {
            availableSpace = availSpace;
        }

        void setAvailableSpace(int index, long availSpace) {
            if (index < 0 || index > availableSpace.length)
                return;
            availableSpace[index] = availSpace;
        }

        long[] getAvailableSpace() {
            return availableSpace;
        }

        long getAvailableMemory() {
            return availableMemory;
        }

        void setAvailableMemory(long mem) {
            availableMemory = mem;
        }

        void setOneMinLoad(double load) {
            oneMinLoad = load;
        }

        double getOneMinLoad() {
            return oneMinLoad;
        }

        public double getLoadRate() {
            if (cpus <= 0)
                return 0;
            return oneMinLoad / cpus;
        }

        void setProcessers(int cpus) {
            this.cpus = cpus;
        }

        int getProcessers() {
            return cpus;
        }

        double getOneMinLoadPercent() {
            return oneMinLoad / cpus;
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(totalPhysicalMemory);
            out.writeLong(availableMemory);
            out.writeInt(availableSpace.length);
            for (Long oneDisk: availableSpace) {
                out.writeLong(oneDisk);
            }
            out.writeDouble(oneMinLoad);
            out.writeLong(swapUsed);
            out.writeInt(cpus);
        }

        public void readFields(DataInput in) throws IOException {
            totalPhysicalMemory = in.readLong();
            availableMemory = in.readLong();
            int length = in.readInt();
            availableSpace = new long[length];
            for (int i = 0; i < length; ++i) {
                availableSpace[i] = in.readLong();
            }
            oneMinLoad = in.readDouble();
            swapUsed = in.readLong();
            cpus = in.readInt();
        }

        @Override
        public IWritable copyFields(IWritable arg) {
            ResourceStatus that = (ResourceStatus) arg;
            this.availableMemory = that.availableMemory;
            this.totalPhysicalMemory = that.totalPhysicalMemory;
            this.availableSpace = new long[that.availableSpace.length];
            for (int i = 0; i < this.availableSpace.length; ++i) {
                this.availableSpace[i] = that.availableSpace[i];
            }
            this.oneMinLoad = that.oneMinLoad;
            this.swapUsed = that.swapUsed;
            this.cpus = that.cpus;
            return this;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("{1-min-load:").append(oneMinLoad);
            sb.append(", cpus:").append(cpus);
            sb.append(", total_mem:").append(totalPhysicalMemory);
            sb.append(", avail_mem:").append(availableMemory);
            sb.append(", swap_use:").append(swapUsed);
            sb.append(", disk_space:").append(Arrays.toString(availableSpace));
            sb.append("}");
            return sb.toString();
        }
    }

}
