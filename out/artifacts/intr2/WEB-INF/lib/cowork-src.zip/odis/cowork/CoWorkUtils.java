/*
 * Copyright (c) 2005-2006, Outfox Team. Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.mapred.ITaskInputSplit;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import toolbox.misc.ClassUtils;
import toolbox.misc.UnitUtils;

/**
 * Utility class for odis.cowork.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
/**
 * @author Administrator
 */
public class CoWorkUtils {

    private static Random r = new Random();

    /**
     * Construct output file names so that, when an output directory listing is
     * sorted lexicographically, positions correspond to output partitions.
     */
    private static final NumberFormat NUMBER_FORMAT = NumberFormat
            .getInstance();
    static {
        NUMBER_FORMAT.setMinimumIntegerDigits(5);
        NUMBER_FORMAT.setGroupingUsed(false);
    }

    /**
     * Generates a random id
     * 
     * @return the generated random id
     */
    public static String generate() {
        int randomInt = r.nextInt();
        if (randomInt == Integer.MIN_VALUE)
            randomInt++;
        return Integer.toString(Math.abs(randomInt), 36);
    }

    /**
     * Generates a task-master's ID
     * 
     * @return the generated task-master's ID
     */
    public static String generateTaskMasterID() {
        int i = NUMBER_FORMAT.getMinimumIntegerDigits();
        NUMBER_FORMAT.setMinimumIntegerDigits(4);
        int randomInt = r.nextInt();
        if (randomInt == Integer.MIN_VALUE)
            randomInt++;
        String id = NUMBER_FORMAT.format(Math.abs(randomInt) % 10000);
        NUMBER_FORMAT.setMinimumIntegerDigits(i);
        return id;
    }

    /**
     * Generates a session's ID
     * 
     * @return the generated session's ID
     */
    public static String generateSessionID() {
        return "session_" + generate();
    }

    /**
     * Generates a job's ID
     * 
     * @return the generated job's ID
     */
    public static String generateJobID(String jobName, String user) {
        return  generateJobGeneralID(jobName, user) + "_" + generate();
    }

    public static String generateJobGeneralID(String jobName, String user) {
        return trimUserName(user) + "_"
                + jobName.substring(0, Math.min(jobName.length(), 25));
    }
    
    /**
     * Returns the file-name for one part of a file folder
     * 
     * @param idx
     *            the index of the part in the folder
     * @return the file-name for one part of a file folder
     */
    public static String getPartID(int idx) {
        return "part-" + NUMBER_FORMAT.format(idx);
    }

    /**
     * Formats a number
     * 
     * @param i
     *            the number to be formatted
     * @return the formatted string
     */
    public static String formatNumber(int i) {
        return NUMBER_FORMAT.format(i);
    }

    /**
     * Limits the number of username to 10
     * 
     * @param user
     *            the user's name
     * @return the trimmed name
     */
    public static String trimUserName(String user) {
        return user.substring(0, Math.min(user.length(), 10));
    }

    private static String bufToString(byte[] buf, int offset, int size)
            throws IOException {
        // compress the serialized data
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        GZIPOutputStream gzout = new GZIPOutputStream(bos);
        gzout.write(buf, 0, size);
        gzout.close();

        // return the base64 encoded string
        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encode(bos.toByteArray());
    }

    private static DataInputBuffer stringToBuf(String s) throws IOException {
        // decode and uncompress the data into buffer
        BASE64Decoder decoder = new BASE64Decoder();
        byte[] bytes = decoder.decodeBuffer(s);
        GZIPInputStream gzin = new GZIPInputStream(new ByteArrayInputStream(
                bytes));
        DataOutputBuffer obuf = new DataOutputBuffer();
        byte[] buf = new byte[1024];
        int len;
        while ((len = gzin.read(buf)) > 0) {
            obuf.write(buf, 0, len);
        }

        return new DataInputBuffer(obuf);
    }

    /**
     * Save the input splits as string.
     * 
     * @param splits
     * @return
     */
    public static String splitsToString(ITaskInputSplit[][] splits)
            throws IOException {

        // serialize the splits into bytes
        DataOutputBuffer obuf = new DataOutputBuffer();
        if (splits == null) {
            obuf.writeInt(-1);
        } else {
            obuf.writeInt(splits.length);
            for (ITaskInputSplit[] stage: splits) {
                if (stage == null) {
                    obuf.writeInt(-1);
                } else {
                    obuf.writeInt(stage.length);
                    if (stage.length > 0) {
                        StringWritable.writeString(obuf, stage[0].getClass()
                                .getName());
                        for (ITaskInputSplit split: stage) {
                            split.writeFields(obuf);
                        }
                    }
                }
            }
        }

        return bufToString(obuf.getData(), 0, obuf.size());
    }

    /**
     * read splits out from encoded string.
     * 
     * @param s
     * @return
     * @throws IOException
     */
    public static ITaskInputSplit[][] stringToSplits(String s)
            throws IOException {
        DataInputBuffer ibuf = stringToBuf(s);

        int size = ibuf.readInt();
        if (size < 0) {
            return null;
        } else {
            ITaskInputSplit[][] result = new ITaskInputSplit[size][];
            for (int i = 0; i < size; i++) {
                int size1 = ibuf.readInt();
                if (size1 < 0) {
                    result[i] = null;
                } else {
                    result[i] = new ITaskInputSplit[size1];
                    if (size1 > 0) {
                        String classname = StringWritable.readString(ibuf);
                        Class cls;
                        try {
                            cls = Class.forName(classname);
                        } catch (Exception e) {
                            throw new RuntimeException(
                                    "initialize split class " + classname
                                            + " failed", e);
                        }
                        for (int j = 0; j < size1; j++) {
                            result[i][j] = (ITaskInputSplit) ClassUtils
                                    .newInstance(cls);
                            result[i][j].readFields(ibuf);
                        }
                    }
                }
            }
            return result;
        }
    }

    /**
     * Convert one writable object to string.
     * 
     * @return
     * @throws IOException
     */
    public static String writableToString(IWritable writable)
            throws IOException {
        DataOutputBuffer obuf = new DataOutputBuffer();
        StringWritable.writeString(obuf, writable.getClass().getName());
        writable.writeFields(obuf);
        return bufToString(obuf.getData(), 0, obuf.size());
    }

    /**
     * Convert encoded string to IWritable.
     * 
     * @param s
     * @return
     * @throws IOException
     */
    public static IWritable stringToWritable(String s) throws IOException {
        DataInputBuffer ibuf = stringToBuf(s);
        String classname = StringWritable.readString(ibuf);
        Class cls;
        try {
            cls = Class.forName(classname);
        } catch (Exception e) {
            throw new RuntimeException("cannot initialize class for name "
                    + classname, e);
        }
        IWritable obj = (IWritable) ClassUtils.newInstance(cls);
        obj.readFields(ibuf);
        return obj;
    }

    /**
     * 1d2h3m4s -> xxx seconds
     * 
     * @param timeStr
     * @return seconds in long value
     */
    public static long fromString2Second(String timeStr) throws IOException {
        long time = 0;
        int d = 0, h = 0, m = 0, s = 0;
        char[] cs = timeStr.toCharArray();
        StringBuilder sb = new StringBuilder();
        for (char c: cs) {
            if (c == 'd') {
                d = Integer.parseInt(sb.toString());
                sb.delete(0, sb.length());
            } else if (c == 'h') {
                h = Integer.parseInt(sb.toString());
                sb.delete(0, sb.length());
            } else if (c == 'm') {
                m = Integer.parseInt(sb.toString());
                sb.delete(0, sb.length());
            } else if (c == 's') {
                s = Integer.parseInt(sb.toString());
                sb.delete(0, sb.length());
                break;
            } else {
                sb.append(c);
            }
        }

        time = UnitUtils.DAY_SEC * d + UnitUtils.HOUR_SEC * h
                + UnitUtils.MINUTE_SEC * m + s;
        return time;
    }

    public static String fromSecond2String(long sec) {
        StringBuffer time = new StringBuffer();
        long left = sec;
        long day = left / UnitUtils.DAY_SEC;
        left = left % UnitUtils.DAY_SEC;
        long hour = left / UnitUtils.HOUR_SEC;
        left = left % UnitUtils.HOUR_SEC;
        long min = left / UnitUtils.MINUTE_SEC;
        left = left % UnitUtils.MINUTE_SEC;
        long second = left;
        if (day != 0)
            time.append(day + "d");
        if (hour != 0)
            time.append(hour + "h");
        if (min != 0)
            time.append(min + "m");
        if (second != 0)
            time.append(second + "s");
        return time.toString();
    }

    private static Pattern tmPattern = Pattern.compile("tm_(.*)\\.corp.*");

    public static String getMachineName(String tmId) {
        Matcher m = tmPattern.matcher(tmId);
        if (m.find()) {
            return m.group(1);
        } else {
            return tmId;
        }
    }

    public static String getJobUser(String jobId) {
        int pos = jobId.indexOf("_");
        if (pos != -1) {
            return jobId.substring(0, pos);
        } else
            return jobId;
    }

    public static String getProgramName(String jobId) {
        int fpos = jobId.indexOf("_");
        int bpos = jobId.lastIndexOf("_");
        if (fpos != -1 && bpos != -1 && fpos != bpos) {
            return jobId.substring(fpos + 1, bpos);
        } else
            return jobId;
    }

    public static String getStrackTrace(Throwable e) {
        StringBuilder sb = new StringBuilder();
        StackTraceElement[] elems = e.getStackTrace();
        for (StackTraceElement elem: elems) {
            sb.append(elem.toString()).append("\n");
        }
        return sb.toString();
    }
    
    public static String getTaskLogSubDirName(String jobOrTaskName) {
        int p = 0;
        char id = jobOrTaskName.charAt(jobOrTaskName.length() - 1);
        for (int i = jobOrTaskName.length() - 1; i > 0; --i) {
            char c = jobOrTaskName.charAt(i);
            if (c == '.') ++p;
            if (p == 2) {
                id = jobOrTaskName.charAt( i - 1);
                break;
            }            
        }
        return String.valueOf(id);
    }
}
