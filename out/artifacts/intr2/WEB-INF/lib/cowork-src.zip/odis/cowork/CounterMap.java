package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import odis.serialize.IWritable;
import odis.serialize.lib.LongWritable;

/**
 * A map holding may counters.
 * 
 * @author zl
 *
 */
@SuppressWarnings("serial")
public class CounterMap extends ConcurrentHashMap<String,CounterMap.Counter> 
        implements IWritable {
    
    /**
     * The counter class.
     * @author zl
     *
     */
    public static class Counter extends LongWritable {
        /**
         * The constructor.
         */
        public Counter() { value=0; }
        /**
         * The constructor with an intialized value
         * @param v  the init value
         */
        public Counter(long v) { value=v; }
        /**
         * Increments the counter by 1
         */
        public synchronized void inc() { value++; }
        /**
         * Increments the counter by l
         */
        public synchronized void inc(long l) { value += l; }
        /**
         * Decrements the counter by 1
         */
        public synchronized void dec() { value--; }
        /**
         * Decrements the counter by l
         */
        public synchronized void dec(long l) { value -= l; }
    }    

    public IWritable copyFields(IWritable value) {
        this.clear();
        for (Map.Entry<String,Counter> entry:((CounterMap)value).entrySet())
            put(entry.getKey(), new Counter(entry.getValue().get()));
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        int c = in.readInt();
        for (int i=0; i<c; i++) {
            String name = in.readUTF();
            Counter ct = new Counter(in.readLong());
            put(name,ct);
        }
    }

    public void writeFields(DataOutput out) throws IOException {
        int count = size();
        out.writeInt(count);
        int index = 0;
        for (Map.Entry<String,Counter> entry:entrySet()) {
            // because entrySet could be changed during output
            // we can output at most entries of previously outputed count
            if (index >= count) break;
            index ++;
            out.writeUTF(entry.getKey());
            out.writeLong(entry.getValue().get());
        }
    }
    
    private static final String PREFIX_TOTAL = "Total";

    public Counter get(Object key) {
        String name = (String) key;
        if (name.startsWith(PREFIX_TOTAL))
            throw new IllegalArgumentException("Prefix \"" + PREFIX_TOTAL + 
                "\" is reserved. Please select another name for your counter");
        return super.get(name);
    }
    /**
     * Returns a total-counter.
     * 
     * @param key  the name of the total-counter
     * @return  the total-counter.
     */
    public Counter getTotal(Object key) {
        String name = (String) key;
        return super.get(PREFIX_TOTAL+name);
    }
    
    private static final NumberFormat numberFormat = NumberFormat.getNumberInstance();
    public String toString() {
        StringBuilder buf = new StringBuilder();
        for (Map.Entry<String, Counter> entry : this.entrySet()) {
            buf.append(entry.getKey()).append("=").append(
                    numberFormat.format(entry.getValue().get())).append("; \n");
        }
        return buf.toString();
    }

}
