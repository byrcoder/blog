/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;

import odis.rpc2.RpcException;
import odis.serialize.IWritable;


/**
 * Protocol implemented at TaskMaster.  TaskMaster acts as a RPC server
 * Includes two parts:
 * <code>
 *   - (this)  TaskRunner <----(task)----> TaskMaster
 *   - (other) TaskRunner <----(file)----> TaskMaster
 * </code>
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public interface ITaskMasterProtocol {
  
    /////////////////////////////////////////////////////////////////////////////
    // (this)  TaskWorker <----(task)----> TaskMaster
    /////////////////////////////////////////////////////////////////////////////

    /** Call to get the Id of this task master */
    public String getId() throws RpcException;

    /** Called when a child task process starts, to get its task.*/
    public TaskDef requestTask(String tipId, String pid) throws RpcException;
     

    /**
     * Periodically called by child to check if parent is still alive,
     * with more information about task result distribution
     * @param tipId
     * @param progress
     * @param c
     * @param isCheck
     * @param resultPartCount
     * @return
     * @throws RpcException
     */
    
    public TaskInfoUpdate pingTask(String tipId, float progress, CounterMap c, boolean isCheck, int[] resultPartCount)
    throws RpcException;


    //public TaskCompletionEvent[] requestPrevStageEvents(String tipId, int from, int max) throws RpcException;
    
    
    /**
     * 
     * @param tipId
     * @param from
     * @param max
     * @return
     * @throws RpcException
     */
    public TaskCompletionEventsUpdate requestPreStageTaskUpdate(String tipId, int from, int max) throws RpcException;
    
    
    //只是为了与以前的客户端兼容
    public void updateTaskCompletionPath(String tipId, String[] paths) throws RpcException;
    
    /** Report that the task is successfully completed, failed or fatal ended.
     * If this function is not called but the task worker process is ended, then
     * the task worker ended with the TaskInProgress as running -- but actually
     * failed unexpected.  We will fill the status as 'fail'. */
    public void doneTask(String tipId, int doneCode, String msg) 
            throws RpcException;
    
    /**
     * Returns the interval in milli-seconds.
     * @return the interval in milli-seconds
     * @throws RpcException  if an error occurs.
     */
    public long getUpdateInterval() throws RpcException;

    /**
     * Kill -3 for a running task
     * @param tipId  task-in-progress id
     * @throws RpcException
     */
    public void statTask(String tipId) throws RpcException;
    
    /**
     * return global counter of a job
     * @param jobId
     * @return
     * @throws RpcException
     */
    public CounterMap[] getGlobalCounters(String jobId) throws RpcException;
    
    public int getTaskStatus(String tipId) throws RpcException;
    
    public String[] getTmpDirs() throws RpcException;
    
    public static class TaskInfoUpdate implements IWritable{
        protected boolean update;
        protected int status;
        public TaskInfoUpdate() {
        }        
        public TaskInfoUpdate(boolean update, int status) {
            this.update = update;
            this.status = status;
        }
        
        @Override
        public void readFields(DataInput in) throws IOException {
            update = in.readBoolean();
            status = in.readInt();
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeBoolean(update);
            out.writeInt(status);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            TaskInfoUpdate that = (TaskInfoUpdate)value;
            this.update = that.update;
            this.status = that.status;
            return this;
        }
    }
    
    public static class TaskCompletionEventsUpdate implements IWritable {
        TaskCompletionEvent[] events;
        boolean reset;
        public TaskCompletionEventsUpdate() {}

        public TaskCompletionEventsUpdate(TaskCompletionEvent[] events,
                boolean reset) {
            this.events = events;
            this.reset = reset;
        }

        public boolean shouldReset() {
            return reset;
        }

        public TaskCompletionEvent[] getMapTaskCompletionEvents() {
            return events;
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeBoolean(reset);
            out.writeInt(events.length);
            for (TaskCompletionEvent event: events) {
                event.writeFields(out);
            }
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            reset = in.readBoolean();
            events = new TaskCompletionEvent[in.readInt()];
            for (int i = 0; i < events.length; ++i) {
                events[i] = new TaskCompletionEvent();
                events[i].readFields(in);
            }
        }

        @Override
        public IWritable copyFields(IWritable value) {
            TaskCompletionEventsUpdate that = (TaskCompletionEventsUpdate)value;
            this.reset = that.reset;
            if (that.events != null) {
                this.events = new TaskCompletionEvent[that.events.length];
                for (int i = 0; i < this.events.length; ++i) {
                    this.events[i] = new TaskCompletionEvent();
                    this.events[i].copyFields(that.events[i]);
                }
            }else {
                this.events = null;
            }
            return this;
        }
    }
}
