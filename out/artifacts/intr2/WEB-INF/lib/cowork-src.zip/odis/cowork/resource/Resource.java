/**
 * @(#)Resouce.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.EmptyInstance;

/**
 *
 * @author chenheng
 *
 */
public class Resource implements IWritable {

    public String resourceID = EmptyInstance.STRING;
    public String tmid = EmptyInstance.STRING;
    public ComputeSpecs resource = new ComputeSpecs();
    
    @Override
    public IWritable copyFields(IWritable value) {
        Resource that = (Resource) value;
        this.resourceID = that.resourceID;
        this.tmid = that.tmid;
        this.resource.copyFields(that.resource);
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, resourceID);
        StringWritable.writeString(out, tmid);
        resource.writeFields(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        this.resourceID = StringWritable.readString(in);
        this.tmid = StringWritable.readString(in);
        this.resource.readFields(in);
    }


    public void setResource(ComputeSpecs oneResource) {
        this.resource.copyFields(oneResource);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(resourceID).append(",").append(tmid).append(",").append(resource);
        return sb.toString();
    }
}
