/**
 * @(#)MapOutputServlet.java, 2012-12-17. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import odis.io.FSDataInputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.MapOutputFile;
import odis.mapred.SpillRecord.IndexRecord;
import toolbox.misc.LogFormatter;

/**
 *
 * move it from TaskMaster
 * 
 * @author chenheng
 */


public class MapOutputServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final Logger LOG = LogFormatter.getLogger(MapOutputServlet.class); 
    
    private static final int MAX_BYTES_TO_READ = 64 * 1024;

    private TaskMaster tm = null;

    @Override
    public void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        long start = System.currentTimeMillis();
        String mapIdxs = request.getParameter("map");
        String reduceId = request.getParameter("reduce");
        // String stageId = request.getParameter("stage");

        LOG.fine("Shuffle started for maps (mapIds=" + mapIdxs
                + ") to reduce " + reduceId);

        if (reduceId == null || mapIdxs == null) {
            throw new IOException(
                    "stage/map/reduce parametera are required");
        }

        if (mapIdxs == null || reduceId == null) {
            throw new IOException("map and reduce parameters are required");
        }

        int reduce = Integer.parseInt(reduceId);
        DataOutputStream outStream = null;

        ServletContext context = getServletContext();
        tm = (TaskMaster) context.getAttribute("taskMaster");
        int numMaps = 0;
        try {
            outStream = new DataOutputStream(response.getOutputStream());
            // use the same buffersize as used for reading the data from
            // disk
            response.setBufferSize(MAX_BYTES_TO_READ);
            // Split the map ids, send output for one map at a time
            StringTokenizer itr = new StringTokenizer(mapIdxs, ",");
            while (itr.hasMoreTokens()) {
                String mapIdx = itr.nextToken();
                ++numMaps;
                sendMapFile(mapIdx, reduce, outStream, tm);
            }
        } catch (IOException ie) {
            String errorMsg = ("getMapOutputs(" + mapIdxs + "," + reduceId + ") failed");
            LOG.log(Level.WARNING, errorMsg, ie);
            if (!response.isCommitted())
                response.sendError(HttpServletResponse.SC_GONE, errorMsg);
            // shuffleMetrics.failedOutput();
            throw ie;
        } finally {
            
            
            // shuffleMetrics.serverHandlerFree();
            if (outStream != null)
                outStream.close();
        }
        // shuffleMetrics.successOutput();
        long timeElapsed = (System.currentTimeMillis() - start);
        LOG.info("Shuffled " + numMaps + "maps (mapIds=" + mapIdxs
                + ") to reduce " + reduceId + " in " + timeElapsed + "ms");
    }

    private void sendMapFile(String mapId, int reduce,
            DataOutputStream outStream, TaskMaster taskMaster) throws IOException {

        LOG.fine("sendMapFile called for " + mapId + " to reduce " + reduce);
        // true iff IOException was caused by attempt to access input
        boolean isInputException = false;
        FSDataInputStream mapOutputIn = null;
        byte[] buffer = new byte[MAX_BYTES_TO_READ];
        long totalRead = 0;

        // Index file
        Path mapOutputFileName = new Path(getMapoutFileToRead(mapId));
        Path indexFileName = MapOutputFile.getFileIndex(mapOutputFileName);

        /**
         * Read the index file to get the information about where the
         * map-output for the given reducer is available.
         */
        IndexRecord info = tm.getIndexCache().getIndexInformation(
                mapId, reduce, indexFileName);
        Semaphore diskToken = tm.getDiskToken(mapOutputFileName
                .getAbsolutePath());
        int acquireTokenTimes = 0;
        try {
            FileSystem localfs = FileSystem.getNamed("local");
            /**
             * Read the data from the single map-output file and send it to
             * the reducer.
             */
            // open the map-output file
            mapOutputIn = localfs.open(mapOutputFileName);
            // seek to the correct offset for the reduce
            mapOutputIn.seek(info.startOffset);

            // write header for each map output
            ShuffleHeader header = new ShuffleHeader(mapId,
                    info.partLength, info.rawLength, reduce);
            header.writeFields(outStream);

            // read the map-output and stream it out
            isInputException = true;
            long rem = info.partLength;
            if (rem == 0) {
                throw new IOException("Illegal partLength of 0 for mapId "
                        + mapId + " to reduce " + reduce);
            }
            int len = mapOutputIn.read(buffer, 0, (int) Math.min(rem,
                    MAX_BYTES_TO_READ));
            while (len >= 0) {
                rem -= len;
                try {
                    // shuffleMetrics.outputBytes(len);

                    if (len > 0) {
                        outStream.write(buffer, 0, len);
                    } else {
                        LOG.info("Skipped zero-length read of map " + mapId
                                + " to reduce " + reduce);
                    }

                } catch (IOException ie) {
                    isInputException = false;
                    throw ie;
                }
                totalRead += len;
                if (rem == 0) {
                    break;
                }

                boolean useToken = false;
                try {
                    if (tm.isHighIOWait()) {
                        useToken = true;
                        if (diskToken != null)
                            diskToken.acquire(1);
                        ++acquireTokenTimes;
                    }
                    len = mapOutputIn.read(buffer, 0, (int) Math.min(rem,
                            MAX_BYTES_TO_READ));
                } catch (InterruptedException e) {
                    isInputException = false;
                    throw new IOException(e);
                } finally {
                    if (useToken && diskToken != null) {
                        diskToken.release(1);
                    }
                }
            } // while
            try {
                outStream.flush();
            } catch (IOException ie) {
                isInputException = false;
                throw ie;
            }
        } catch (IOException ie) {
            
            String errorMsg = "error on sending map " + mapId
                    + " to reduce " + reduce;
            LOG.log(Level.WARNING, errorMsg, ie);
            if (isInputException) {
                tm.taskOutputLost(mapId, errorMsg
                        + stringifyException(ie));
            }
            throw new IOException(errorMsg, ie);
        } finally {
            if (mapOutputIn != null) {
                try {
                    mapOutputIn.close();
                } catch (IOException ioe) {
                    LOG.log(Level.WARNING,
                            "problem closing map output file", ioe);
                }
            }
        }

        LOG.info("Sent out " + totalRead + " bytes to reduce " + reduce
                + " from map: " + mapId + " given " + info.partLength + "/"
                + info.rawLength + ", acquire token times="
                + acquireTokenTimes);
    }
    
    private String stringifyException(Throwable e) {
        StringWriter stm = new StringWriter();
        PrintWriter wrt = new PrintWriter(stm);
        e.printStackTrace(wrt);
        wrt.close();
        return stm.toString();
    }

    public File getMapoutFileToRead(String mapId) {
        String name = mapId + File.separatorChar
                + MapOutputFile.getOutputFileName();
        for (File dir: tm.taskTmpDirs) {
            File file = new File(dir, name);
            if (file.exists())
                return file;
        }

        LOG.warning("Can't find map file " + name);
        for (File dir: tm.taskTmpDirs) {
            File file = new File(dir, mapId);
            if (file.exists()) {
                LOG.warning("Debug: " + Arrays.deepToString(file.listFiles()));
            }
        }
        return null;
    }
}
