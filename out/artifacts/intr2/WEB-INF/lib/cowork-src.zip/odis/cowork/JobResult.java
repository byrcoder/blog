/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

/**
 * Result of executing a job.
 * 
 * @author zl, David
 */
public class JobResult {
    private boolean isSuccess;

    private String[][] msg;

    private CounterMap[] counters;
    
    private String jobid;
    /**
     * The constructor.
     * 
     * @param isSuccess  whether the job was sucessfully executed
     * @param msg  an 2-d array for messages from collect.collectDoneMsg()
     * @param counters  the counter-map array
     */
    public JobResult(boolean isSuccess, String[][] msg, CounterMap[] counters) {
        this.isSuccess = isSuccess;
        this.msg = msg;
        this.counters = counters;
    }
    
    public JobResult(boolean isSuccess, String[][] msg, CounterMap[] counters, String jobid) {
        this.isSuccess = isSuccess;
        this.msg = msg;
        this.counters = counters;
        this.jobid = jobid;
    }
    
    /**
     * Returns whether the job was sucessfully executed.
     * @return whether the job was sucessfully executed
     */
    public boolean isSuccess() {
        return isSuccess;
    }
    /**
     * Returns an 2-d array for messages from collect.collectDoneMsg(). The
     * first dimention is stage, and the second dimention is individual task. 
     * @return an 2-d array for messages from collect.collectDoneMsg()
     */
    public String[][] getMsg() {
        return msg;
    }
    /**
     * Returns the counter-map array. The length of the array is the number of
     * stages. E.g. for a map-reduce job, the returned array is of length 2, and
     * the first element corresponds to map-stage, and the second to reduce-
     * stage.
     * 
     * @return the counter-map array
     */
    public CounterMap[] getCounters() {
        return counters;
    }
    
    /**
     * Returns the job's id
     * @return Returns the job's id
     */
	public String getJobid() {
		return jobid;
	}
}
