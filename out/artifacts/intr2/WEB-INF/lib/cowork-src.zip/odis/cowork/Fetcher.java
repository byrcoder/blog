package odis.cowork;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.crypto.SecretKey;

import odis.file.CompressUtils.CompressAlgo;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicPartitioner;
import odis.mapred.IFile;
import odis.mapred.MRConfig;
import odis.mapred.MapHost;
import odis.mapred.MapRedUtil;
import odis.mapred.TaskID;
import odis.serialize.IWritable;
import odis.util.IOUtils;
import toolbox.misc.LogFormatter;


class Fetcher<K extends IWritable,V extends IWritable> extends Thread {
    protected static final Logger LOG = LogFormatter.getLogger(Fetcher.class);
    
    /** Number of ms before timing out a copy */
    private static final int DEFAULT_STALLED_COPY_TIMEOUT = 3 * 60 * 1000;
    
    /** Basic/unit connection timeout (in milliseconds) */
    private final static int UNIT_CONNECT_TIMEOUT = 2 * 60 * 1000;
    
    /* Default read timeout (in milliseconds) */
    private final static int DEFAULT_READ_TIMEOUT = 3 * 60 * 1000;

    private static enum ShuffleErrors{IO_ERROR, WRONG_LENGTH, BAD_ID, WRONG_MAP,
                                      CONNECTION, WRONG_REDUCE}
    
    private final static String SHUFFLE_ERR_GRP_NAME = "ERR_";
    private final String connectionErrs;
    private final String ioErrs;
    private final String wrongLengthErrs;
    private final String badIdErrs;
    private final String wrongMapErrs;
    private final String wrongReduceErrs;
    private final MergeManager<K,V> merger;
    private final ShuffleScheduler<K,V> scheduler;
//    private final ShuffleClientMetrics metrics;
    private final ExceptionReporter exceptionReporter;
    private final int id;
    private static int nextId = 0;
    private final int reduce;
    
    private final int connectionTimeout;
    private final int readTimeout;
    
    // Decompression of map-outputs
    private final CompressAlgo compressAlgo;
    private final TaskRunnable task;

    public Fetcher(BasicInOutJobDef job, TaskRunnable task, 
                   ShuffleScheduler<K,V> scheduler, MergeManager<K,V> merger,
//                   ShuffleClientMetrics metrics,
                   ExceptionReporter exceptionReporter) {
      this.task = task;
      this.scheduler = scheduler;
      this.merger = merger;
//      this.metrics = metrics;
      this.exceptionReporter = exceptionReporter;
      this.id = ++nextId;
      this.reduce = task.getPartIdx();
//      this.jobTokenSecret = jobTokenSecret;
      ioErrs = SHUFFLE_ERR_GRP_NAME + ShuffleErrors.IO_ERROR.toString();
      wrongLengthErrs = SHUFFLE_ERR_GRP_NAME + ShuffleErrors.WRONG_LENGTH.toString();
      badIdErrs = SHUFFLE_ERR_GRP_NAME + ShuffleErrors.BAD_ID.toString();
      wrongMapErrs = SHUFFLE_ERR_GRP_NAME + ShuffleErrors.WRONG_MAP.toString();
      connectionErrs = SHUFFLE_ERR_GRP_NAME + ShuffleErrors.CONNECTION.toString();
      wrongReduceErrs = SHUFFLE_ERR_GRP_NAME + ShuffleErrors.WRONG_REDUCE.toString();      
      
      int ioPhase = MapRedUtil.getMrMergePhase(task.getStageIdx(), job);
      boolean useCompress = BasicPartitioner.getCompress(job, ioPhase);
      if (useCompress)
          compressAlgo = BasicPartitioner.getCompressAlgo(job, ioPhase);
      else compressAlgo = null;

      
      
//      if (job.getCompressMapOutput()) {
//        Class<? extends CompressionCodec> codecClass =
//          job.getMapOutputCompressorClass(DefaultCodec.class);
//        codec = ReflectionUtils.newInstance(codecClass, job);
//        decompressor = CodecPool.getDecompressor(codec);
//      } else {
//        codec = null;
//        decompressor = null;
//      }

      this.connectionTimeout = job.getConfig().getInt(MRConfig.SHUFFLE_CONNECT_TIMEOUT, DEFAULT_STALLED_COPY_TIMEOUT);
      this.readTimeout = job.getConfig().getInt(MRConfig.SHUFFLE_READ_TIMEOUT, DEFAULT_READ_TIMEOUT);
      
      setName("fetcher#" + id);
      setDaemon(true);
    }
    
    public void run() {
      try {
        while (!stop) {
          MapHost host = null;
          try {
            // If merge is on, block
            merger.waitForInMemoryMerge();

            // Get a host to shuffle from
            host = scheduler.getHost();
//            metrics.threadBusy();

            // Shuffle
            copyFromHost(host);
          } finally {
            if (host != null) {
              scheduler.freeHost(host);
//              metrics.threadFree();            
            }
          }
        }
      } catch (InterruptedException ie) {
        return;
      } catch (Throwable t) {
        exceptionReporter.reportException(t);
      }
    }
    
    volatile boolean stop = false;
    public void shutdown() {
        stop = true;
        this.interrupt();
    }
    
    /**
     * The crux of the matter...
     * 
     * @param host {@link MapHost} from which we need to  
     *              shuffle available map-outputs.
     */
    private void copyFromHost(MapHost host) throws IOException {
      // Get completed maps on 'host'
      List<TaskID> maps = scheduler.getMapsForHost(host);
      
      // Sanity check to catch hosts with only 'OBSOLETE' maps, 
      // especially at the tail of large jobs
      if (maps.size() == 0) {
        return;
      }
      
      StringBuilder sb = new StringBuilder();
      sb.append("Fetcher ").append(id).append(" ask ").append(host).append(" for maps:[");
      for (TaskID tmp: maps) {
          sb.append(tmp.getPartIdx()).append(",");
        }
      sb.append("]");      
      LOG.info(sb.toString());
            
      // List of maps to be fetched yet
      Set<TaskID> remaining = new HashSet<TaskID>(maps);
      
      // Construct the url and connect
      DataInputStream input = null;
      boolean connectSucceeded = false;
      
      try {
        URL url = getMapOutputURL(host, maps);
        URLConnection connection = url.openConnection();
        
        // generate hash of the url
//        String msgToEncode = SecureShuffleUtils.buildMsgFrom(url);
//        String encHash = SecureShuffleUtils.hashFromString(msgToEncode, jobTokenSecret);
//        
//        // put url hash into http header
//        connection.addRequestProperty(
//            SecureShuffleUtils.HTTP_HEADER_URL_HASH, encHash);
        // set the read timeout
        connection.setReadTimeout(readTimeout);
        connect(connection, connectionTimeout);
        connectSucceeded = true;
        input = new DataInputStream(connection.getInputStream());
        
        // get the replyHash which is HMac of the encHash we sent to the server
//        String replyHash = connection.getHeaderField(SecureShuffleUtils.HTTP_HEADER_REPLY_URL_HASH);
//        if(replyHash==null) {
//          throw new IOException("security validation of TT Map output failed");
//        }
//        LOG.debug("url="+msgToEncode+";encHash="+encHash+";replyHash="+replyHash);
        // verify that replyHash is HMac of encHash
//        SecureShuffleUtils.verifyReply(replyHash, encHash, jobTokenSecret);
//        LOG.info("for url="+msgToEncode+" sent hash and receievd reply");
      } catch (IOException ie) {
        task.getCounter(ioErrs).inc(1);
        LOG.warning("Failed to connect to " + host + " with " + remaining.size() + " maps, connected=" + connectSucceeded + ", error:" + ie.getMessage());

        // If connect did not succeed, just mark all the maps as failed,
        // indirectly penalizing the host
        if (!connectSucceeded) {
            Iterator<TaskID> rIt = remaining.iterator();
            if (rIt.hasNext()) {
                scheduler.copyFailed(rIt.next(), host, connectSucceeded);
            }
        } else {
          // If we got a read error at this stage, it implies there was a problem
          // with the first map, typically lost map. So, penalize only that map
          // and add the rest
            TaskID firstMap = maps.get(0);
            scheduler.copyFailed(firstMap, host, connectSucceeded);
        }
        
        // Add back all the remaining maps, WITHOUT marking them as failed
        for(TaskID left: remaining) {
          scheduler.putBackKnownMapOutput(host, left);
        }
        
        return;
      }finally {
          if (!connectSucceeded && input != null) {
              input.close();
              input = null;              
          }
      }
      
      try {
        // Loop through available map-outputs and fetch them
        // On any error, good becomes false and we exit after putting back
        // the remaining maps to the yet_to_be_fetched list
        boolean good = true;
        while (!remaining.isEmpty() && good) {
          good = copyMapOutput(host, input, remaining);
        }
        
//        IOUtils.cleanup(LOG, input);
        
        // Sanity check
        if (good && !remaining.isEmpty()) {
          throw new IOException("server didn't return all expected map outputs: "
              + remaining.size() + " left.");
        }
      } finally {
        for (TaskID left : remaining) {
          scheduler.putBackKnownMapOutput(host, left);
        }
        if (input != null) {
            input.close();
            input = null;
        }
      }
        
     }
    
    private boolean copyMapOutput(MapHost host,
                                  DataInputStream input,
                                  Set<TaskID> remaining) {
      MapOutput<K,V> mapOutput = null;
      TaskID mapId = null;
      long decompressedLength = -1;
      long compressedLength = -1;
      
      try {
        long startTime = System.currentTimeMillis();
        int forReduce = -1;
        //Read the shuffle header
        try {
          ShuffleHeader header = new ShuffleHeader();
          header.readFields(input);
          for (TaskID tid : remaining) {
              if (tid.getId().equals(header.mapName))
                  mapId = tid;
          }
          
          compressedLength = header.compressedLength;
          decompressedLength = header.uncompressedLength;
          forReduce = header.forReduce;
        } catch (IllegalArgumentException e) {
          task.getCounter(badIdErrs).inc(1);
          LOG.log(Level.WARNING, "Invalid map id ", e);
          return false;
        }

   
        // Do some basic sanity verification
        if (!verifySanity(compressedLength, decompressedLength, forReduce,
            remaining, mapId)) {
          return false;
        }
        
        LOG.fine("header: " + mapId + ", len: " + compressedLength + 
                 ", decomp len: " + decompressedLength);
        
        // Get the location for the map output - either in-memory or on-disk
        mapOutput = merger.reserve(mapId, decompressedLength, id);
        
        // Check if we can shuffle *now* ...
        if (mapOutput.getType() == MapOutput.Type.WAIT) {
          LOG.info("fetcher#" + id + " - MergerManager returned Status.WAIT ...");
          return false;
        } 
        
        // Go!
        LOG.info("fetcher#" + id + " about to shuffle output of map " + 
                 mapOutput.getMapId() + " decomp: " +
                 decompressedLength + " len: " + compressedLength + " to " +
                 mapOutput.getType());
        if (mapOutput.getType() == MapOutput.Type.MEMORY) {
          shuffleToMemory(host, mapOutput, input, 
                          (int) decompressedLength, (int) compressedLength);
        } else {
          shuffleToDisk(host, mapOutput, input, compressedLength);
        }
        
        // Inform the shuffle scheduler
        long endTime = System.currentTimeMillis();
        scheduler.copySucceeded(mapId, host, compressedLength, 
                                endTime - startTime, mapOutput);
        // Note successful shuffle
        remaining.remove(mapId);
//        metrics.successFetch();
        return true;
      } catch (IOException ioe) {
        task.getCounter(ioErrs).inc(1);
        if (mapId == null || mapOutput == null) {
          LOG.log(Level.WARNING, "fetcher#" + id + " failed to read map header" + 
                   mapId + " decomp: " + 
                   decompressedLength + ", " + compressedLength, ioe);
          return false;
        }
        
        LOG.log(Level.WARNING, "Failed to shuffle output of " + mapId + 
                 " from " + host.getHostName(), ioe); 

        // Inform the shuffle-scheduler
        mapOutput.abort();
        scheduler.copyFailed(mapId, host, true);
//        metrics.failedFetch();
        return false;
      }

    }
    
    /**
     * Do some basic verification on the input received -- Being defensive
     * @param compressedLength
     * @param decompressedLength
     * @param forReduce
     * @param remaining
     * @param mapId
     * @return true/false, based on if the verification succeeded or not
     */
    private boolean verifySanity(long compressedLength, long decompressedLength,
        int forReduce, Set<TaskID> remaining, TaskID mapId) {
      if (compressedLength < 0 || decompressedLength < 0) {
        task.getCounter(wrongLengthErrs).inc(1);
        LOG.warning(getName() + " invalid lengths in map output header: id: " +
                 mapId + " len: " + compressedLength + ", decomp len: " + 
                 decompressedLength);
        return false;
      }
      
      if (forReduce != reduce) {
        task.getCounter(wrongReduceErrs).inc(1);
        LOG.warning(getName() + " data for the wrong reduce map: " +
                 mapId + " len: " + compressedLength + " decomp len: " +
                 decompressedLength + " for reduce " + forReduce);
        return false;
      }

      // Sanity check
      if (!remaining.contains(mapId)) {
        task.getCounter(wrongMapErrs).inc(1);
        LOG.warning("Invalid map-output! Received output for " + mapId);
        return false;
      }
      
      return true;
    }

    /**
     * Create the map-output-url. This will contain all the map ids
     * separated by commas
     * @param host
     * @param maps
     * @return
     * @throws MalformedURLException
     */
    private URL getMapOutputURL(MapHost host, List<TaskID> maps
                                )  throws MalformedURLException {
      // Get the base url
      StringBuffer url = new StringBuffer(host.getBaseUrl());
      
      boolean first = true;
      for (TaskID mapId : maps) {
        if (!first) {
          url.append(",");
        }
        url.append(mapId.getId());
        first = false;
      }
     
      LOG.fine("MapOutput URL for " + host + " -> " + url.toString());
      return new URL(url.toString());
    }
    
    /** 
     * The connection establishment is attempted multiple times and is given up 
     * only on the last failure. Instead of connecting with a timeout of 
     * X, we try connecting with a timeout of x < X but multiple times. 
     */
    private void connect(URLConnection connection, int connectionTimeout)
    throws IOException {
      int unit = 0;
      if (connectionTimeout < 0) {
        throw new IOException("Invalid timeout "
                              + "[timeout = " + connectionTimeout + " ms]");
      } else if (connectionTimeout > 0) {
        unit = Math.min(UNIT_CONNECT_TIMEOUT, connectionTimeout);
      }
      // set the connect timeout to the unit-connect-timeout
      connection.setConnectTimeout(unit);
      while (true) {
        try {
          connection.connect();
          break;
        } catch (IOException ioe) {
          // update the total remaining connect-timeout
          connectionTimeout -= unit;

          // throw an exception if we have waited for timeout amount of time
          // note that the updated value if timeout is used here
          if (connectionTimeout == 0) {
            throw ioe;
          }

          // reset the connect timeout for the last try
          if (connectionTimeout < unit) {
            unit = connectionTimeout;
            // reset the connect time out for the final connect
            connection.setConnectTimeout(unit);
          }
        }
      }
    }

    private void shuffleToMemory(MapHost host, MapOutput<K,V> mapOutput, 
                                 InputStream input, 
                                 int decompressedLength, 
                                 int compressedLength) throws IOException {    
//      IFileInputStream checksumIn = 
//        new IFileInputStream(input, compressedLength);

//      input = checksumIn;       

      if (compressAlgo != null) {
          input = IFile.getDecompressInputStream(compressAlgo, input);
      }
      
      // Are map-outputs compressed?
//      if (codec != null) {
//        decompressor.reset();
//        input = codec.createInputStream(input, decompressor);
//      }
    
      // Copy map-output into an in-memory buffer
      byte[] shuffleData = mapOutput.getMemory();
      
      try {
        IOUtils.readFully(input, shuffleData, 0, shuffleData.length);
//        metrics.inputBytes(shuffleData.length);
//        task.progress();
        LOG.info("Read " + shuffleData.length + " bytes from map-output for " +
                 mapOutput.getMapId());
      } catch (IOException ioe) {      
        // Close the streams
//        IOUtils.cleanup(LOG, input);

        // Re-throw
        throw ioe;
      }

    }
    
    private void shuffleToDisk(MapHost host, MapOutput<K,V> mapOutput, 
                               InputStream input, 
                               long compressedLength) 
    throws IOException {
      // Copy data to local-disk
      OutputStream output = mapOutput.getDisk();
      long bytesLeft = compressedLength;
      try {
        final int BYTES_TO_READ = 64 * 1024;
        byte[] buf = new byte[BYTES_TO_READ];
        while (bytesLeft > 0) {
          int n = input.read(buf, 0, (int) Math.min(bytesLeft, BYTES_TO_READ));
          if (n < 0) {
            throw new IOException("read past end of stream reading " + 
                                  mapOutput.getMapId());
          }
          output.write(buf, 0, n);
          bytesLeft -= n;
//          metrics.inputBytes(n);
//          task.progress();
        }

        LOG.info("Read " + (compressedLength - bytesLeft) + 
                 " bytes from map-output for " +
                 mapOutput.getMapId());

        output.close();
      } catch (IOException ioe) {
        // Close the streams
//        IOUtils.cleanup(LOG, input, output);

        // Re-throw
        throw ioe;
      }

      // Sanity check
      if (bytesLeft != 0) {
        throw new IOException("Incomplete map output received for " +
                              mapOutput.getMapId() + " from " +
                              host.getHostName() + " (" + 
                              bytesLeft + " bytes missing of " + 
                              compressedLength + ")"
        );
      }
    }
  }
