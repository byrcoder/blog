package odis.cowork;

import static odis.cowork.IJobMasterProtocol.TASK_STATE_CANCEL;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_FAIL;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_PREPARING;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_RUNNING;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_SUCCESS;
import static odis.cowork.IJobMasterProtocol.TASK_STATE_UNASSIGNED;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import odis.cowork.CounterMap.Counter;
import odis.cowork.IJobMasterProtocol.TaskState;
import odis.mapred.MRConfig;
import odis.serialize.IWritable;

public class TaskReport implements IWritable {
    private String tmId = "";
    private TaskDef task;

    private int state;

    private float progress;

    private long cursor, time; // current cursor and procssed time

    private long input, output;

    private float cpu, mem;

    private boolean isReported;

    private CounterMap counters;

    private String msg;

    private int[] resultPartCount; // number record of every result partition

    // private String[] completionPaths;

    private int lastPreStageEventIdx = 0;

    public TaskReport() {
        this.task = new TaskDef();
        this.state = TASK_STATE_UNASSIGNED;
        this.progress = 0f;
        this.cursor = TaskRunnable.NON_CURSOR;
        this.time = 0;
        this.input = -1;
        this.output = -1;
        this.cpu = 0f;
        this.mem = 0f;
        this.isReported = false;
        this.counters = new CounterMap();
        this.msg = "";
        this.lastPreStageEventIdx = 0;
        resultPartCount = new int[0];
    }

    public TaskReport(TaskDef task) {
        this.task = task;
        this.state = TASK_STATE_UNASSIGNED;
        this.progress = 0f;
        this.cursor = TaskRunnable.NON_CURSOR;
        this.time = 0;
        this.input = -1;
        this.output = -1;
        this.cpu = 0f;
        this.mem = 0f;
        this.isReported = false;
        this.counters = new CounterMap();
        this.msg = "";
        this.lastPreStageEventIdx = 0;
        resultPartCount = new int[0];

    }

    public String toString() {
        return task + ":" + TaskState.getState(state) + ":" + progress;
    }

    public int hashCode() {
        return toString().hashCode();
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (null == o) return false;
        if (o instanceof TaskReport) {
            TaskReport that = (TaskReport)o;
            return this.toString().equals(that.toString())
            && this.msg.equals(that.msg);
        }
        return false;
    }

    public TaskDef getTaskDef() {
        return task;
    }

    public int getState() {
        return state;
    }

    public String getStateString() {
        return TaskState.getState(state);
    }

    public float getProgress() {
        return progress;
    }

    public long getCursor() {
        return cursor;
    }

    public long getProcessTime() {
        return time;
    }

    public long getInput() {
        return input;
    }

    public long getOutput() {
        return output;
    }

    public float getCpu() {
        return cpu;
    }

    public float getMem() {
        return mem;
    }

    public boolean getIsReported() {
        return isReported;
    }

    public CounterMap getCounters() {
        return counters;
    }

    public String getMsg() {
        return msg;
    }

    public int[] getResultPartCount() {
        return resultPartCount;
    }

    // public String[] getCompletionPaths() {return completionPaths; }

    public String getJobId() {
        return task.jobId;
    }

    public int getStageIdx() {
        return task.stage;
    }

    public int getPartIdx() {
        return task.part;
    }

    public int getLastPreStageEventIdx() {
        return lastPreStageEventIdx;
    }

    public void setLastPreStageEventIdx(int idx) {
        this.lastPreStageEventIdx = idx;
    }

    public boolean isCanceled() {
        return TaskState.isCancel(state);
    }

    public boolean isPreparing() {
        return TaskState.isPreparing(state);
    }

    public boolean isRunning() {
        return TaskState.isRunning(state);
    }

    public boolean isAssigned() {
        return TaskState.isAssigned(state);
    }

    public boolean isFinished() {
        return TaskState.isFinished(state);
    }

    public boolean isSuccess() {
        return TaskState.isSuccess(state);
    }

    public String getTaskMasterId() {
        return tmId;
    }
    public void setTaskMasterId(String tmId) {
        this.tmId = tmId;
    }
    
    public void setState(int s) {
        state = s;
    }

    public void setProgress(float f) {
        assert isRunning() || isPreparing();
        progress = f;
    }

    public void setCursorTime(long c, long t) {
        cursor = c;
        time = t;
    }

    public void setInputOutput(long in, long out) {
        input = in;
        output = out;
    }

    public void setCpuMem(float c, float m) {
        cpu = c;
        mem = m;
    }

    public void setIsReported(boolean b) {
        isReported = b;
    }

    public void addCounters(CounterMap c) {
        counters.putAll(c);
    }

    public void setMsg(String s) {
        assert isFinished();
        this.msg = (s == null ? "" : s);
        if (msg.length() > MRConfig.MAX_DONE_MSG_LENGTH) {
            msg = msg.substring(0, MRConfig.MAX_DONE_MSG_LENGTH);
        }
    }

    public void setPartResultCount(int[] partCount) {
        this.resultPartCount = partCount;
    }

    public void setCancel() {
        state = TASK_STATE_CANCEL;
        progress = 0f;
    }

    public void setPreparing() {
        state = TASK_STATE_PREPARING;
        progress = 0f;
    }

    public void setRunning() {
        state = TASK_STATE_RUNNING;
        progress = 0f;
    }

    public void setSuccess() {
        state = TASK_STATE_SUCCESS;
        progress = 1f;
    }

    public void setFail() {
        state = TASK_STATE_FAIL;
        progress = 0f;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(tmId);
        task.writeFields(out);
        out.writeInt(state);
        out.writeFloat(progress);
        out.writeLong(cursor);
        out.writeLong(time);
        out.writeLong(input);
        out.writeLong(output);
        out.writeFloat(cpu);
        out.writeFloat(mem);
        out.writeBoolean(isReported);
        out.writeInt(counters.size());
        for (Map.Entry<String, Counter> entry: counters.entrySet()) {
            out.writeUTF(entry.getKey());
            entry.getValue().writeFields(out);
        }
        out.writeUTF(msg);
        out.writeInt(resultPartCount.length);
        for (int i = 0; i < resultPartCount.length; ++i) {
            out.writeInt(resultPartCount[i]);
        }
        out.writeInt(lastPreStageEventIdx);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        tmId = in.readUTF();
        task.readFields(in);
        state = in.readInt();
        progress = in.readFloat();
        cursor = in.readLong();
        time = in.readLong();
        input = in.readLong();
        output = in.readLong();
        cpu = in.readFloat();
        mem = in.readFloat();
        isReported = in.readBoolean();
        int c = in.readInt();
        for (int i = 0; i < c; i++) {
            String name = in.readUTF();
            Counter ct = new Counter();
            ct.readFields(in);
            counters.put(name, ct);
        }
        msg = in.readUTF();
        int partLen = in.readInt();
        resultPartCount = new int[partLen];
        for (int i = 0; i < partLen; ++i) {
            resultPartCount[i] = in.readInt();
        }
        lastPreStageEventIdx = in.readInt();
    }

    @Override
    public IWritable copyFields(IWritable value) {
        TaskReport that = (TaskReport) value;
        this.tmId = that.tmId;
        this.task.copyFields(that.task);
        this.state = that.state;
        this.progress = that.progress;
        this.cursor = that.cursor;
        this.time = that.time;
        this.input = that.input;
        this.output = that.output;
        this.cpu = that.cpu;
        this.mem = that.mem;
        this.isReported = that.isReported;
        for (Map.Entry<String, Counter> entry: that.counters.entrySet()) {
            Counter ct = new Counter();
            ct.copyFields(entry.getValue());
            this.counters.put(entry.getKey(), ct);
        }
        this.msg = that.msg;
        this.lastPreStageEventIdx = that.lastPreStageEventIdx;
        this.resultPartCount = Arrays.copyOf(that.resultPartCount,
                that.resultPartCount.length);
        return this;
    }
}
