/**
 * @(#)IResourceService.java, 2012-12-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork.resource;

import java.util.List;

import odis.cowork.JobConfig;
import odis.rpc2.RpcException;

/**
 *
 * @author chenheng
 *
 */
public interface IResourceService {

    public List<Resource> getResource(JobConfig job, int num) throws RpcException;
    
    public void notExist(String tmid) throws RpcException;
    
    public boolean returnResource(String tmid, String resourceID) throws RpcException; 
}
