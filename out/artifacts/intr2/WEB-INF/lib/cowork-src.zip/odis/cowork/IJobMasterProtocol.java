/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.cowork.TaskMasterStatus.ResourceStatus;
import odis.rpc2.RpcException;
import odis.serialize.IWritable;

/**
 * Protocol implemented at JobMaster. JobMaster acts as a RPC server
 * Includes two parts:
 * <code>
 *                    TaskReport[]
 *  - TaskMaster ----------------------> JobMaster
 *               <--- TaskCommand[] ----
 * 
 *  - JobClient <----------------------> JobMaster
 * </code>              
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public interface IJobMasterProtocol extends IJobSubmissionProtocol {
    
  /////////////////////////////////////////////////////////////////////////////
  // RPC Communication: TaskMaster->JobMaster 
  /////////////////////////////////////////////////////////////////////////////
  /**
   * Says hello from the task-master to the job-master
   */
  public boolean hello(String tmId, String hostname, String volume, 
          int rpcPort, int filePort, int slot) throws RpcException;
  /**
   * heartbeats the job-master from a task-master
   */  
  public TaskCommand[] heartbeat(String tmId, TaskReport[] tasks, ResourceStatus rsStatus) 
          throws RpcException;  
  /**
   * Tells the job-master that the task-master is quitting
   */
  public boolean goodbye(String tmId, String reason) throws RpcException;  

  public int getVacancyIndex() throws RpcException;
  
  /////////////////////////////////////////////////////////////////////////////
  // Task Report (TaskMaster->JobMaster)
  /////////////////////////////////////////////////////////////////////////////
  public static final int TASK_STATE_UNASSIGNED = 0;
  public static final int TASK_STATE_RUNNING = 1;
  public static final int TASK_STATE_SUCCESS = 2;
  public static final int TASK_STATE_FAIL = 3;
  public static final int TASK_STATE_FATAL = 4;
  public static final int TASK_STATE_PREPARING = 5; //copy data but don't run
  public static final int TASK_STATE_CANCEL = 6; //copy data but don't run
  
  
  public static class TaskMasterInfo implements odis.serialize.IWritable {
    protected String tmId;
    protected String hostname;
    protected String volume;
    protected int slot;
    protected int rpcPort;
    protected int webPort;
    protected int filePort;
    protected int debugPort;
    

    @Override
    public IWritable copyFields(IWritable value) {
        TaskMasterInfo that = (TaskMasterInfo)value;
        this.tmId = that.tmId;
        this.hostname = that.hostname;
        this.volume = that.volume;
        this.slot = that.slot;
        this.rpcPort = that.rpcPort;
        this.webPort = that.webPort;
        this.filePort = that.filePort;
        this.debugPort = that.debugPort;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeUTF(tmId);
        out.writeUTF(hostname);
        out.writeUTF(volume);
        out.writeInt(slot);
        out.writeInt(rpcPort);
        out.writeInt(webPort);
        out.writeInt(filePort);
        out.writeInt(debugPort);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        tmId = in.readUTF();
        hostname = in.readUTF();
        volume = in.readUTF();
        slot = in.readInt();
        rpcPort = in.readInt();
        webPort = in.readInt();
        filePort = in.readInt();
        debugPort = in.readInt();
    }
      
  }
  /**
   * The class containing some static methods for a state of a task.
   * 
   * @author david
   *
   */
  public static class TaskState {
    /**
     * Returns the text representation for a state.
     * @param state  the state
     * @return the text representation for a state
     */
    public static String getState(int state) {
      switch (state) {
        case TASK_STATE_UNASSIGNED:
          return "UNASSIGNED";
        case TASK_STATE_PREPARING:
          return "PREPARING";
        case TASK_STATE_RUNNING:
          return "RUNNING";
        case TASK_STATE_SUCCESS:
          return "SUCCESS";
        case TASK_STATE_FAIL:
          return "FAIL";
        case TASK_STATE_FATAL:
          return "FATAL";
        case TASK_STATE_CANCEL:
          return "CANCEL";
        default:
          return null;
      }
    }
    
    public static boolean isPreparing(int state) {
        return state == TASK_STATE_PREPARING;
    }
    /**
     * Returns whether the state means the task is running.
     * @param state  the state of the task
     * @return whether the state means the task is running
     */
    public static boolean isRunning(int state) {
      return state==TASK_STATE_RUNNING;
    }
    /**
     * Returns whether the state means the task is assigned.
     * @param state  the state of the task
     * @return whether the state means the task is assigned.
     */
    public static boolean isAssigned(int state) {
      return state!=TASK_STATE_UNASSIGNED;
    }
    /**
     * Returns whether the state means the task has finished.
     * @param state  the state of the task
     * @return whether the state means the task has finished
     */
    public static boolean isFinished(int state) {
      return state==TASK_STATE_SUCCESS || state==TASK_STATE_FAIL || 
             state==TASK_STATE_FATAL;
    }
    /**
     * Returns whether the state means the task is a success.
     * @param state  the state of the task
     * @return whether the state means the task is a success
     */
    public static boolean isSuccess(int state) {
      return state==TASK_STATE_SUCCESS;
    }

    public static boolean isCancel(int state) {
        return state==TASK_STATE_CANCEL;
    }
  }


  
  /////////////////////////////////////////////////////////////////////////////
  // Task Command (JobMaster->TaskMaster)
  /////////////////////////////////////////////////////////////////////////////
  public static final int TASK_CMD_NULL = 0;
  public static final int TASK_CMD_NEW_TASK = 1;
  public static final int TASK_CMD_DEL_TASK = 2;
  public static final int TASK_CMD_UPD_TASK = 3;
  public static final int TASK_CMD_UNKNOWN_TM = 4;
  public static final int TASK_CMD_PREPARE_TASK = 5;
  
  /**
   * THe data-structure for task-command.
   * 
   * @author zl
   *
   */

}
