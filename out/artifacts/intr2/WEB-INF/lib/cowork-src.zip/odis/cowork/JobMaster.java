package odis.cowork;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.CoworkConfig;
import odis.cowork.TaskMasterStatus.ResourceStatus;
import odis.cowork.resource.IResourceService;
import odis.cowork.resource.Resource;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import bsh.Interpreter;


/**
 * 
 * Split Resource Management from JobMaster, and refactor the JobMaster code
 * @author chenheng
 * */
public class JobMaster implements IJobMasterProtocol, Runnable, TaskMasterManager {
    
    public static final int VERSION = 6;
    private static final Logger LOG = LogFormatter.getLogger(JobMaster.class);
    
    public static final long HEARTBEAT_INTERVAL = CoworkConfig.conf().getLong("cowork.jobmaster.heartbeat.interval", 10 * 1000);// 10s
    public static final long EXPIRY_LIMIT = CoworkConfig.conf().getLong("cowork.jobmaster.heartbeat.expiry-limit", 50 * HEARTBEAT_INTERVAL); // 500s
    public static final long LATE_WARNING_LIMIT = CoworkConfig.conf().getLong("cowork.jobmaster.heartbeat.late-warning-limit", 100); // 100ms
    public static final long RPC_LATE_LIMIT = CoworkConfig.conf().getLong("cowork.jobmaster.heartbeat.rpc-late-limit", 150); // 150ms
    
    public static final String LOG_DIR = "jobmaster";
    public static final String JOB_DIR = "job";
    public static final String JOB_ARCHIVE_DIR = "job_archive";

    // job master definitions
    protected String hostname;
    protected int port;
    protected String volume;
    private AbstractRpcServer server;
    protected String cuid;
    // all masters: sorted by last update time (oldest->newest)
    protected LinkedHashMap<String, TaskMasterStatus> taskMasters;
    Map<String, JobInProgress> jobs = new TreeMap<String, JobInProgress>();
    protected ClusterStatus clusterStatus = new ClusterStatus();
    private IResourceService resourceManager = null;
    private Map<String, String> machineMap = new TreeMap<String, String>();
    private Map<String, Integer> priorityMap = new HashMap<String, Integer>();
    private JobsExtraParamsManager jobExtraParamsManager = new JobsExtraParamsManager();
    private InetSocketAddress resAddr = null;
    private ExpiryChecker expiryChecker;
    //private UDPRpcServer pingServer;
    private static Options options = new Options();
    static {
        options.withOption("p", "port", "set port of jobmaster")
                .setType(Options.TYPE_NUMBER).hasDefault();
        options.withOption("w", "port", "set web port of jobmaster")
                .setType(Options.TYPE_NUMBER).hasDefault();
        options.withOption("v", "volume", "set volume(random)");
        options.withOption("l", "set if log to file");
        options.withOption("allow", "allowed_users", "Set allowed users")
                .hasDefault();
        options.withOption("rp", "resManager Port", "port of resManager")
                .setType(Options.TYPE_NUMBER).hasDefault();
        options.withOption("rh", "resManager host", "host of resManger").hasDefault();
    }

    public JobMaster(InetSocketAddress rmAddr, int port, String vol) throws IOException {
        LOG.info("Creating job master ...");
        taskMasters = new LinkedHashMap<String, TaskMasterStatus>();
        // Set ports, start RPC servers, etc.
        hostname = InetAddress.getLocalHost().getHostName();
        this.port = port;
        this.volume = vol;
        this.cuid = CoworkConfig.conf().getString("cowork.jobmaster.cuid",
                "default-cu");
        server = RPC.getNIOServer(IJobMasterProtocol.class, this, this.port,
                CoworkConfig.conf().getInt(
                        "cowork.jobmaster.rpc-conn-num",10),
                CoworkConfig.conf().getInt(
                        "cowork.jobmaster.rpc-queue-size", 10000), 1, 0);
        server.start();
        LOG.info("  Job master RPC server started at " + hostname + ":"
                + this.port);
        
        resourceManager = RPC.getProxy(IResourceService.class, rmAddr);
        
        // Expiry checking thread.
        expiryChecker = new ExpiryChecker();
        new Thread(this.expiryChecker).start();
        LOG.info("  Started a seperate thread to check task master expiry.");

        AssignThread assignThread = new AssignThread();
        assignThread.start();
        LOG.info("Started assigh Thread to assign tasks");
        
        this.resAddr = rmAddr;
        LOG.info("Job master created.");
    }

    
    public class AssignThread extends Thread {
        
        public AssignThread() {
            this.setName("AssignThread");
            this.setDaemon(true);
        }
        
        private volatile boolean running = true;
        
        @Override
        public void run() {
            while (running) {
                synchronized(JobMaster.this) {
                    List<Entry<String, JobInProgress>> jobsList = new ArrayList<Entry<String, JobInProgress>>(jobs.entrySet());
                    Collections.sort(jobsList, JOB_COMPARATOR);
                    dump(jobsList);
                    for (Entry<String, JobInProgress> job : jobsList) {
                        JobInProgress jip = job.getValue();
                        try {
                            jip.printStatus();
                            int num = getRequestNum(jip);
                            LOG.info("@@JOBMASTER_ASSIGN@@ jobid=" + jip.getJobDef().jobName + ", requestNum=" + num);
                            List<Resource> resources = resourceManager.getResource(jip.jobConfig, num);
                            LOG.info("@@JOBMASTER_ASSIGN@@ jobid=" + jip.getJobDef().jobName + ", responseNum=" + resources.size());
                            if (resources.size() > 0) {
                                Map<String, List<Resource>> tmid2ResourcesMap = getResourceMap(resources);
                                for (Entry<String, List<Resource>> entry : tmid2ResourcesMap.entrySet()) {
                                    LOG.info("@@JOBMASTER_ASSIGN@@ tmid=" + entry.getKey() + ", resources=" + entry.getValue());
                                    TaskMasterStatus tm = getTaskMaster(entry.getKey());
                                    if (tm == null || clusterStatus.isBlanklisted(tm.getId())) {
                                        resourceManager.notExist(entry.getKey());
                                        continue;
                                    }
                                    List<TaskDef> tasks;
                                    try {
                                        tasks = getJobTasks(tm, jip, entry.getValue().size());
                                        Set<String> dispatchedResource = new HashSet<String>();
                                        for (int i = 0; i < tasks.size(); i++) {
                                            TaskDef task = tasks.get(i);
                                            task.resourceID = entry.getValue().get(i).resourceID;
                                            task.taskMasterID = tm.id;
                                            LOG.info("@@JOBMASTER_ASSIGN@@" + task.getTaskId());
                                            tm.assign(task);
                                            dispatchedResource.add(task.resourceID);
                                        }
                                        //本次未使用的resource归还给resManager
                                        for (Resource res : entry.getValue()) {
                                            if (!dispatchedResource.contains(res.resourceID)) {
                                                LOG.info(res.resourceID + " is returning!");
                                                returnResource(entry.getKey(), res.resourceID);
                                            }
                                        }
                                    } catch (IOException e) {
                                        LOG.log(Level.WARNING, "", e);
                                        continue;
                                    }
                                }
                            } else {
                                //检查当前的job有没有发生死锁， 例如：Map(1), reduce(10), workers(10)
                                //当前10个workers运行10个reduce， 所有的reduce在等待map, map在等待workers， worker在等待reduce
                                if (jip.isDeadLock()) {
                                    LOG.info("@@JOBMASTER_ASSIGN@@ deadLock occured!!");
                                    jip.printStatus();
                                    List<TaskDef> tasks = jip.getRunningTasksRelease4PendingTasks();
                                    for (TaskDef task : tasks) {
                                        TaskMasterStatus tm = getTaskMaster(task.taskMasterID);
                                        if (tm != null) {
                                            tm.delete(task, true);
                                            jip.moveFromRunning2Pending(task);
                                        }
                                    }
                                }
                            }
                        } catch (RpcException e) {
                            LOG.log(Level.WARNING, "", e);
                            continue;
                        }
                    }
                }
                
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    continue;
                }
            }
            
        }

        private void dump(List<Entry<String, JobInProgress>> jobsList) {
            for (Entry<String, JobInProgress> entry : jobsList) {
                LOG.info(entry.getKey() + ":" + entry.getValue().getWeight());
            }
        }

        private Map<String, List<Resource>> getResourceMap(
                List<Resource> resources) {
            Map<String, List<Resource>> tmid2ResMap = new HashMap<String, List<Resource>>();
            for (Resource res : resources) {
                if (tmid2ResMap.containsKey(res.tmid)) {
                    tmid2ResMap.get(res.tmid).add(res);
                } else {
                    List<Resource> resList = new ArrayList<Resource>();
                    resList.add(res);
                    tmid2ResMap.put(res.tmid, resList);
                }
            }
            return tmid2ResMap;
        }
        
        private int getRequestNum(JobInProgress jip) {
            int curStageRunning = jip.runningSize(jip.currentStage());
            int limit = jobExtraParamsManager.getJobWorkerLimit(jip.getGeneralJobID());
            limit = Math.min(limit, jip.getJobDef().getJobWorkerNumLimit());
            if (curStageRunning < limit) {
                int num = jip.totalPendingSize();
                if (num == 0 && !jip.jobStatus.isFinished()) {
                    if (jip.hasNextStage()) {
                        num = jip.taskStatus[jip.jobStatus.getStage()].length;
                    }
                }
                num = Math.min(num, limit - curStageRunning);
                return num;
            } 
            return 0;
        }
        
    } 


    @Override
    public TaskCommand[] heartbeat(String tmId,
            TaskReport[] tasks, ResourceStatus rsStatus) throws RpcException {
        LOG.info("Heartbeat from " + tmId + ", report number=" + tasks.length);
        LOG.fine("Task report from " + tmId + ", " + Arrays.deepToString(tasks)+ ", resource status: " + rsStatus);
        try {
            long arrive = System.currentTimeMillis(); // arrive time
            synchronized (this) {                
//                long begin = System.currentTimeMillis();
                TaskMasterStatus tmStatus = getTaskMaster(tmId);
                
                if (tmStatus==null) {
                    LOG.info("Unknown task master (" + tmId + ")");
                    return new TaskCommand[] {new TaskCommand(TASK_CMD_UNKNOWN_TM,null,null,null,1)};
                }
                
                if (rsStatus != null) { 
                    tmStatus.updateResourceStatus(rsStatus);
                }

                long late = (arrive - tmStatus.lastHeartbeat) - HEARTBEAT_INTERVAL;
                if (late > LATE_WARNING_LIMIT) {
                    LOG.warning("Heartbeat from " + tmId + " arrives late for " + late + "ms");
                }
                
                tmStatus.processReports(tasks);
                TaskCommand[] cmd = tmStatus.generateCmds();
                if (cmd.length > 0) {
                    LOG.info("Taking " + cmd.length + " commands: " + Arrays.toString(cmd));
                }
                return cmd;
            }
        }catch (Exception e) {
            LOG.log(Level.WARNING, "Heart beat failed.", CoWorkUtils.getStrackTrace(e));
            throw new RpcException("heart beat failed",e);
        }
    }

    @Override
    public synchronized JobStatus submitJob(JobConfig job) throws RpcException {
        checkFinishedButNoClientJob();
        String username = job.jobDef.getUser();
        if (username == null) {
            LOG.log(Level.WARNING, "job " + job.jobDef.getJobName()
                    + " from null user rejected");
            throw new IllegalAccessError("username null is not allowed");
        }

        JobInProgress jip = new JobInProgress(job, this);
        jobs.put(jip.jobId,jip);
        job.getJobDef().setJobID(jip.jobId);
        
        try {
            jip.start();
        } catch (Throwable e1) {
            throw new RpcException(e1);
        }

        LOG.info("Received job submission " + jip.jobId);
        return jip.getJobStatus();
    }


    @Override
    public synchronized boolean hello(String tmId, String hostname, String vol,
            int rpcPort, int filePort, int slot) throws RpcException {
        addTaskMachine(tmId);
        if (vol == null || !vol.equals(this.volume)) {
            LOG.warning("Received hello from " +tmId + " with unmatched volume " + vol);
            return false;
        }
        
        // Already have this task master registered? clear previous states.
        if (getTaskMaster(tmId) != null) {
          LOG.warning(tmId + " already exists before this hello, rejecting hello");
          return false;
        }
        // add new task master 
        TaskMasterStatus tmStatus = new TaskMasterStatus(tmId, hostname, rpcPort, filePort, slot, this);
        addTaskMaster(tmStatus);
        LOG.info("Hello from " + tmId + " (" + 
            tmStatus.lastHeartbeat + ") - total tm = " + taskMasters.size());
        return true;         
    }
    
    @Override
    public synchronized boolean goodbye(String tmId, String reason) throws RpcException {
        if (!taskMasters.containsKey(tmId)) {
            LOG.info("Goodbye from unknown " + tmId 
                + " (" + System.currentTimeMillis() + "): " + reason);
            return false;
        }
        LOG.info("Goodbye from " + tmId +" (" + System.currentTimeMillis() + "): " + reason);
        lostTaskMaster(tmId);
        return true;
    }
    
    
    
    private List<TaskDef> getJobTasks(TaskMasterStatus tms, JobInProgress jip, int num) throws IOException {
        List<TaskDef> tasks = new ArrayList<TaskDef>();
        List<TaskDef> currTasks = jip.obtainCurStageTasks(tms, clusterStatus, num);
        tasks.addAll(currTasks);
        if (currTasks.size() < num) {
            List<TaskDef> nextStageTasks = jip.obtainNextStageTasks(tms, clusterStatus, num - currTasks.size());
            tasks.addAll(nextStageTasks);
        }
        return tasks;
    }

    @Override
    public void run() {
        try {
            server.join();
        } catch (InterruptedException e) {
            LOG.log(Level.SEVERE, "JobMaster.run(): server.join() exception.", e);
        }
    }

    @Override
    public ClusterStatus getClusterStatus() {
        return clusterStatus;
    }

    @Override
    public JobInProgress getJob(String jobid) {
        return jobs.get(jobid);
    }

    public synchronized List<JobInProgress> getJobList() {
        return new ArrayList<JobInProgress>(jobs.values());            
    }
    @Override
    public int getNextHeartbeatInterval() {
        return 0;
    }

    @Override
    public int getNumberOfUniqueHosts() {
        return machineMap.size();
    }

    @Override
    public TaskMasterStatus getTaskMaster(String tmId) {
        if (tmId == null) { 
            return null;
        }
        TaskMasterStatus tmStatus = taskMasters.get(tmId);
        if (tmStatus == null)
            LOG.warning("Cannot get taskmaster " + tmId + ", taskMasters is" + taskMasters);
        return tmStatus;
    }

    @Override
    public void killJob(String jobid) throws IOException {
        abortJob(jobid);
    }

    @Override
    public Collection<TaskMasterStatus> taskMasters() {
        return taskMasters.values();
    }
    
    public synchronized int getVacancyIndex() {
        int vacancyNum = 0;
        for (Entry<String, TaskMasterStatus> entry : taskMasters.entrySet()) {
            TaskMasterStatus tms = entry.getValue();
            if (tms.getResourceStatus().getLoadRate() <= 1.25) {
                vacancyNum += tms.vacancy();
            }
        }
        return vacancyNum;
    }
    
    public String getResManagerWebAddr() {
        StringBuilder sb = new StringBuilder();
        sb.append("http://").append(resAddr.getHostName()).append(":").append(resAddr.getPort()+1);
        return sb.toString();
    }
    
    protected void checkFinishedButNoClientJob() {
        List<JobInProgress> rlist = null;
        for (JobInProgress jip : jobs.values()) {
            if (jip.isRemovable()) {
                if (rlist == null) rlist = new LinkedList<JobInProgress>();
                rlist.add(jip);
            }                
        }
        if (rlist != null) {
            LOG.info("Force remove job " + rlist);
            for (JobInProgress jip : rlist) {
                try {
                    removeJob(jip.jobId);
                }catch (Throwable e) {
                    LOG.log(Level.WARNING, "check removeable job exception", e);
                }
            }            
        }
    }
    
    protected void reQueueTaskMaster(TaskMasterStatus tm) {
        taskMasters.remove(tm.getId());
        taskMasters.put(tm.getId(), tm);
    }

    private boolean isMachineExist(String tmId) {
        synchronized (machineMap) {
            String machine = CoWorkUtils.getMachineName(tmId);
            if (machineMap.containsKey(machine)) {
                LOG.warning("Machine " + machine
                        + " aleady live in the jobmaster: "
                        + machineMap.get(machine));
                return true;
            }
            return false;
        }
    }

    private void addTaskMachine(String tmId) {        
        String machine = CoWorkUtils.getMachineName(tmId);
        synchronized(machineMap) {
            machineMap.put(machine, tmId);
        }
    }
    
    public String getTmIdByHost(String host) {
        synchronized(machineMap) {
            return machineMap.get(host);
        }
    }

    protected void deleteTaskMachine(String tmId) {
        LOG.info("Delete machine " + tmId);        
        String machine = CoWorkUtils.getMachineName(tmId);
        synchronized(machineMap) {
            String tm = machineMap.remove(machine);
            if (tm == null) {
                LOG.warning("BUG: " + machine + " don't exist in machine.");
            }
        }
    }

    /** Add a task master currently not exists */
    private void addTaskMaster(TaskMasterStatus tmStatus) {
        assert !taskMasters.containsKey(tmStatus.id);
        taskMasters.put(tmStatus.id, tmStatus);
        clusterStatus.totalWorkers += tmStatus.capacity();
        ++clusterStatus.totalMachines;
    }

    /**
     * Delete a task master. Must ensure that tmId exists before calling this
     * function
     */
    private void delTaskMaster(String tmId) {
        LOG.info("Delete taskmaster " + tmId);
        TaskMasterStatus tmStatus = taskMasters.remove(tmId);
        assert tmStatus != null;
        clusterStatus.totalWorkers -= tmStatus.capacity();
        --clusterStatus.totalMachines;
    }

    /** Set a task master as lost */
    private void lostTaskMaster(String tmId) {
        TaskMasterStatus tmStatus = taskMasters.get(tmId);
        LOG.info("Lost task master " + tmId + " (last heartbeat at "
                + (new Date(tmStatus.lastHeartbeat)).toString() + ") when total tm = "
                + taskMasters.size() + " ...");
        //tmStatus.cleanAfterLost();
        
        //check every job lost this tm
        for (JobInProgress jip : jobs.values()) {
            try {
                jip.lostTaskMaster(tmId);
            }catch (Throwable e) {
                LOG.warning("Lost " + tmId + " for " + jip + ", Trace:" + CoWorkUtils.getStrackTrace(e));
                System.err.println(CoWorkUtils.getStrackTrace(e));
            }
        }
        
        delTaskMaster(tmId);
        deleteTaskMachine(tmId);
    }

    public synchronized void snapshot(LinkedHashMap<String, JobInProgress> newJQ,
        LinkedHashMap<String, TaskMasterStatus> newTP) {
        // snapshot data
        for (Map.Entry<String,JobInProgress> entry:jobs.entrySet())
            newJQ.put(entry.getKey(), entry.getValue().getShadowCopy());
        for (Map.Entry<String,TaskMasterStatus> entry:taskMasters.entrySet())
            newTP.put(entry.getKey(),entry.getValue().getShadowCopy());
    }
    


    public void stop() {
        LOG.info("JobMaster is halting");
        expiryChecker.stop();
        server.stop();
        //pingServer.stop();
    }

    public static void usage() {
        options.printHelpInfo(System.out, "jobmaster");
    }

    // ///////////////////////////////////////////////////////////////////////////
    // Interface for test cases
    // ///////////////////////////////////////////////////////////////////////////
    synchronized void logStatus() {
        StringBuffer sb = new StringBuffer("JobMaster Status:");
        sb.append("\nJob in queue: " + jobs.size() + " (s:s - rw)");
        Iterator<String> it = jobs.keySet().iterator();
        while (it.hasNext()) {
            JobInProgress jip = jobs.get(it.next());
            sb.append("\n  " + jip.jobStatus);
            sb.append("\n Running " + jip.totalRunningSize());
        }
        sb.append("\nTaskMaster in queue: " + taskMasters.size() + ":"
                + getClusterStatus().getTotalWorkers() + " - tasks(pr:r:d:pd)");
        it = taskMasters.keySet().iterator();
        while (it.hasNext()) {
            TaskMasterStatus tmStatus = taskMasters.get(it.next());
            sb.append("\n ").append(tmStatus.id).append("(")
                    .append(tmStatus.capacity() - tmStatus.vacancy())
                    .append("/").append(tmStatus.vacancy());
            sb.append(" on ").append(tmStatus.running());
        }
        LOG.info(sb.toString());
    }

    @Override
    public void setPriorityValue(String jobPrefix, int value) throws RpcException {
        synchronized (priorityMap) {
            if (value > 0) {
                LOG.info("Set job " + jobPrefix + " priority. v=" + value);
                value = Math.min(value, 5);
                Integer currentValue = priorityMap.put(jobPrefix, value);
                if (null != currentValue && currentValue == value)
                    return;
            } else {
                LOG.info("Clear job " + jobPrefix + " priority. v=" + value);
                priorityMap.remove(jobPrefix);
            }
        }
        
        //change the status of running job
        synchronized (this) {
            for (JobInProgress jip: jobs.values()) {
                JobPriority currentPriority = getPriority(jip.jobId, jip.deserveWorker());
                if (jip.getPriority() == currentPriority){
                    continue;
                }
                jip.setPriority(currentPriority);
            }
        }
    }

    protected JobPriority getPriority(String jobId, int askWorker) {
        synchronized(priorityMap) {
            for (String prefix : priorityMap.keySet()) {
                if (jobId.indexOf(prefix) >= 0) {
                    return JobPriority.valueOf(priorityMap.get(prefix));
                }
            }
            if (askWorker <= 64) 
                return JobPriority.HIGH;
            else if (askWorker > 2048) 
                return JobPriority.LOW;
            else
                return JobPriority.NORMAL;
        }
    }
    
    protected Map<String, Integer> clonePriorities() {
        synchronized(priorityMap) {
            return new HashMap<String, Integer>(priorityMap);
        }
    }

    @Override
    public void setDebug(boolean flag) throws RpcException {
        
    }

    @Override
    public void addBlacklisted(String tmId) throws RpcException {
        if (null == tmId){
            return;
        }
        LOG.info("Add task master to black list: " + tmId);
        synchronized (clusterStatus) {
            this.clusterStatus.addBlacklisted(tmId);
        }
    }

    @Override
    public void removeBlacklisted(String tmId) throws RpcException {
        if (null == tmId){
            return;
        }
        LOG.info("Remove task master from black list: " + tmId);
        synchronized (clusterStatus) {
            this.clusterStatus.removeBlacklisted(tmId);
        }
    }
    

    @Override
    public String getCUID() throws RpcException {
        return cuid;
    }

    @Override
    public synchronized CounterMap[] getJobCounters(String jobId) throws RpcException {
        JobInProgress jip = getJob(jobId);
        if (jip!=null) {
            CounterMap[] result = new CounterMap[jip.jobDef.getTotalStage()];
            for (int stage=0; stage<result.length; stage++)
                result[stage] = jip.aggregateCounter(stage);
            return result;
        } else {
            LOG.warning("Request counter of job (" + jobId + ") which does not exist.");
            return null;
        }
    }

    @Override
    public synchronized String getJobMsg(String jobId) throws RpcException {
        JobInProgress jip = getJob(jobId);
        if (jip != null) {
            return jip.jobMsg;
        } else {
            LOG.warning("Request message of job (" + jobId + ") which does not exist.");
            return null;
        } 
    }

    @Override
    public synchronized JobStatus getJobStatus(String jobId) throws RpcException {       
        JobInProgress jip = getJob(jobId);
        if (jip != null) {
            return jip.getJobStatus();
        } else {
            LOG.warning("Request status of job (" + jobId + ") which does not exist.");
            return null;
        }
    }

    @Override
    public synchronized String[][] getTaskMsgs(String jobId)
            throws RpcException {
        JobInProgress jip = getJob(jobId);
        if (jip != null) {
            if (jip.taskStatus == null)
                return null; // not started yet
            String[][] msgs = new String[jip.taskStatus.length][];
            for (int i = 0; i < jip.taskStatus.length; i++) {
                msgs[i] = new String[jip.taskStatus[i].length];
                for (int j = 0; j < jip.taskStatus[i].length; j++)
                    msgs[i][j] = jip.taskStatus[i][j].doneMsg;
            }
            return msgs;
        } else {
            LOG.warning("Request return messages of job (" + jobId
                    + ") which does not exist.");
            return null;
        }
    }

    @Override
    public long getUpdateInterval(int version) {
        if (version != VERSION)
            throw new IllegalArgumentException("JobMaster (version=" + VERSION 
                + ") and JobClient (version=" + version 
                + ") doesn't match.  Please restart cowork and \"svn up\"");
        return HEARTBEAT_INTERVAL;
    }

    /*
     * Cann't be removed when job not finished
     * @see odis.cowork.IJobSubmissionProtocol#removeJob(java.lang.String)
     */
    @Override
    public synchronized boolean removeJob(String jobId) throws RpcException {
        LOG.info("Receive remove job " + jobId);
        JobInProgress jip = getJob(jobId);
        if (jip == null) {
            return true;
        } else if (jip.getJobStatus().isFinished()) {
            jobs.remove(jobId);
            LOG.info("Job " + jobId + " removed from the queue.");
            return true;
        } else {
            LOG.warning("Request removing job (" + jobId + ") which has not finished.");
            return false;
        }
    }

    @Override
    public synchronized void abortJob(String jobId) throws RpcException {
        LOG.info("Received client call for aborting " + jobId);
        JobInProgress jip = getJob(jobId);
        if (jip != null) {
            jip.jobMsg = "Job will be aborted as per request by the user.";
            jip.close(false);
            jobs.remove(jobId);
        } else {
            LOG.warning("Request aborting job (" + jobId + ") which does not exist.");
        }
    }
    

    public void returnResource(String tmid, String resourceID) {
        try {
            resourceManager.returnResource(tmid, resourceID);
        } catch (RpcException e) {
            LOG.log(Level.WARNING, "", e);
        }
    }
    
    public void removeJobLimit(String jobtag) {
        jobExtraParamsManager.delJobWorkerLimit(jobtag);
    }

    public void addJobLimit(String jobtag, int workerNum) {
        jobExtraParamsManager.addJobWorkerLimit(jobtag, workerNum);
    }
    
    public Map<String, Integer> snapshotJobLimit() {
        return jobExtraParamsManager.getJobWorerLimitSnapshot();
    }

    public InetSocketAddress getResAddr() {
        return resAddr;
    }

    public void setResAddr(InetSocketAddress resAddr) {
        this.resAddr = resAddr;
    }

    //按照权重降序
    public static final Comparator<Entry<String, JobInProgress>> JOB_COMPARATOR = 
            new Comparator<Entry<String, JobInProgress>>() {
        @Override
        public int compare(Entry<String, JobInProgress> o1, Entry<String, JobInProgress> o2) {
            if (o1 != null && o2 != null) {
                JobInProgress jip1 = o1.getValue();
                JobInProgress jip2 = o2.getValue();
                return -Double.compare(jip1.getWeight(), jip2.getWeight());
            } else if (o1 != null) {
                return 1;
            } else if (o2 != null) {
                return -1;
            }
            return 0;
        }
       
    };
    
    // ////////////////////////////////////////////////////////////
    // Task master expiry checking
    // ////////////////////////////////////////////////////////////

    private class ExpiryChecker implements Runnable {
        private volatile boolean shouldRun = true;
        private long expiryInterval = EXPIRY_LIMIT;
        private static final long QUICK_CHECK = 1000; // 1s
        private long nextSleep = expiryInterval / 3;

        public void run() {
            while (shouldRun) {
                // Thread runs periodically to check whether masters should be
                // expired.
                // The sleep interval must be no more than half the maximum
                // expiry time
                // for a task tracker. -- Li: why?
                try {
                    Thread.sleep(nextSleep);
                } catch (InterruptedException ie) {
                }
                checkExpiry();

                // for debug, tuqc
                // changeWorkerAssignEveryDay();
            }
        }

        /** check wether any expired task masters */
        private void checkExpiry() {
            synchronized (JobMaster.this) {
                long now = System.currentTimeMillis();
                Iterator<String> it = taskMasters.keySet().iterator();
                if (!it.hasNext())
                    return;
                String tmId = it.next();
                try {
                    TaskMasterStatus eldestTaskMaster = taskMasters.get(tmId);
                    if (now - eldestTaskMaster.lastHeartbeat > expiryInterval) {
                        lostTaskMaster(tmId);
                        nextSleep = QUICK_CHECK; // already lost one, could be
                                                 // more? let us check it
                                                 // quickly
                    } else
                        nextSleep = expiryInterval / 3;
                } catch (Throwable t) { // FIXME: bug catching code
                    LOG.log(Level.WARNING, "Check expiry of " + tmId + " at: "
                            + now, t);
                    delTaskMaster(tmId);
                }
            }
        }

        public void stop() {
            shouldRun = false;
        }
    }    
    

    public static void main(String[] args) throws Throwable {
        try {
            options.parse(args);
        } catch (OptionParseException e) {
            System.out.println("error:" + e.getMessage());
            usage();
        }

        boolean isLogToFile = options.isOptSet("l");
        String vol = options.getStringOpt("v");
        int port = options.getIntOpt("p", CoworkConfig.get()
                .getJobMasterPort());
        int webPort = options.getIntOpt(
                "w",
                CoworkConfig.conf().getInt("cowork.jobmaster.web-port",
                        7777));
        String allowedUsers = options.getStringOpt("allow");
        int rPort = options.getIntOpt("rp", CoworkConfig.get().getRMPort());
        String rHost = options.getStringOpt("rh", CoworkConfig.get().getRMHost());
        
        // logger
        String hostname = InetAddress.getLocalHost().getHostName();
        if (isLogToFile) { // log to file
            File logDir = new File(CoworkConfig.get().getCoworkLogDir(),
                    LOG_DIR);
            if (!logDir.exists())
                logDir.mkdirs();
            LogFormatter.clearLoggerHandlers("");
            LogFormatter.setRotateFileLogger(
                    "",
                    logDir.getPath(),
                    "jm-" + hostname + ".log",
                    CoworkConfig.conf().getInt(
                            "cowork.jobmaster.log.file-limit", 100000000), // 100M
                    CoworkConfig.conf().getInt(
                            "cowork.jobmaster.log.file-count", 300),
                    CoworkConfig.conf().getBoolean(
                            "cowork.jobmaster.log.is-append", true));
            System.out.println("Log to file: " + logDir + File.separator
                    + "jm-" + hostname + ".log.*");
        }
        LogFormatter.setLogLevel(CoworkConfig.get().getServiceLogLevel(),
                Level.INFO);

        System.out.println("Starting JobMaster at " + hostname + ":" + port);
        JobMaster jm = new JobMaster(new InetSocketAddress(rHost, rPort), port, vol);
        System.out.println("Starting JobMasterUpdater at port: "
                + (jm.port + 1));
        JobMasterUpdater jmu = new JobMasterUpdater(jm, jm.port + 1,
                CoworkConfig.conf().getLong(
                        "cowork.jobmaster.info-up-interval", 10000), webPort);
        CoWorkServlet.setJobMasterInfo(jmu);

        // start bean shell
        Interpreter interpreter = new Interpreter();
        try {
            int beanPort = CoworkConfig.conf().getInt(
                    "cowork.jobmaster.web-port", 7777) + 10;
            interpreter.set("jobmaster", jm);
            interpreter.set("jobupdater", jmu);
            // interpreter.set("scheduler", jm.getTaskScheduler());
            interpreter.set("portnum", beanPort);
            interpreter.eval("setAccessibility(true)");
            interpreter.eval("server(portnum)");
            LOG.info("Start beanshell at port=" + beanPort + ", telnet port="
                    + (beanPort + 1));
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Bean shell not started.", e);
        }

        System.out.println("JobMaster was initialized.");
        jmu.start();
        jm.run();
    }

    
}
