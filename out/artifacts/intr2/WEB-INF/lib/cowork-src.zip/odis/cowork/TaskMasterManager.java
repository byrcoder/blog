package odis.cowork;

import java.io.IOException;
import java.util.Collection;

public interface TaskMasterManager {
    /** 
     * @param tmId
     * @return null if don't have tmId
     */
    public TaskMasterStatus getTaskMaster(String tmId);
    
    /**
     * @return A collection of the {@link TaskMasterStatus} for the taskmasters
     * being managed.
     */
    public Collection<TaskMasterStatus> taskMasters();
    
    /**
     * @return The number of unique hosts running taskmasters.
     */
    public int getNumberOfUniqueHosts();
    
    /**
     * @return a summary of the cluster's status.
     */
    public ClusterStatus getClusterStatus();

    /**
     * Return the {@link QueueManager} which manages the queues in this
     * {@link TaskMasterManager}.
     *
     * @return the {@link QueueManager}
     */
    //public QueueManager getQueueManager();
    
    /**
     * Return the current heartbeat interval that's used by {@link TaskTracker}s.
     *
     * @return the heartbeat interval used by {@link TaskTracker}s
     */
    public int getNextHeartbeatInterval();

    /**
     * Kill the job identified by jobid
     * 
     * @param jobid
     * @throws IOException
     */
    public void killJob(String jobid)
        throws IOException;

    /**
     * Obtain the job object identified by jobid
     * 
     * @param jobid
     * @return jobInProgress object
     */
    public JobInProgress getJob(String jobid);
    
    
}
