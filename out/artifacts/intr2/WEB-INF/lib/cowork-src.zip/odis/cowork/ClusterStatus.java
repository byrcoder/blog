package odis.cowork;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class ClusterStatus {

    protected int totalWorkers;
    protected int usedWorkers;
    protected int totalMachines;
    
    HashSet<String> blacklist = new HashSet<String>();
    
    public int getTotalWorkers() { return totalWorkers; }
    
    public int getUsedWorkers() { return usedWorkers; }
    
    public int getTotalTaskMasters() { return totalMachines; }
    
    public synchronized List<String> getBlacklistedTaskMasters() {
        return new ArrayList<String>(blacklist);
    }
    
    public synchronized void addBlacklisted(String tmId) {
        blacklist.add(tmId); 
    }
    
    public synchronized boolean isBlanklisted(String tmId) {
        return blacklist.contains(tmId);
    }
    
    public synchronized void removeBlacklisted(String tmId) {
        blacklist.remove(tmId);
    }
    
    public void reportFailure(TaskReport report) {
        //TODO
    }
    
    public long getUsedMemory() {
        return 0;        
    }
    
    public long getTotalMemory() {
        return 0;
    }    

}
