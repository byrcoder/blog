package odis.cowork.analyzer;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import odis.conf.CoworkConfig;
import odis.cowork.CoWorkUtils;
import odis.cowork.JobMaster;
import odis.io.ReadWriteUtils;
import odis.serialize.IWritable;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

public class CoWorkAnalyzer {
    private static final Logger LOG = LogFormatter.getLogger(CoWorkAnalyzer.class);

    public static final int MAX_JOBS_PER_PROGRAM = 2046;

    protected static final HashMap<String, JobDetail> todayJobDetailMap = new HashMap<String, JobDetail>();

    protected static long jobDirLMT = 0;

    public static File jobDir = new File(
            CoworkConfig.get().getCoworkLogDir(), JobMaster.JOB_DIR);

    public static File jobArchive = new File(
            CoworkConfig.get().getCoworkLogDir(), JobMaster.JOB_ARCHIVE_DIR);

    public static final SimpleDateFormat formatter1 = new SimpleDateFormat(
            "yyMMdd");

    public static final SimpleDateFormat formatter2 = new SimpleDateFormat(
            "yyyy/MM/dd HH:mm:ss");

    //Mon Aug 17 13:50:55 CST 2009
    private static final SimpleDateFormat formatter3 = new SimpleDateFormat(
            "EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);

    public static final SimpleDateFormat formatter4 = new SimpleDateFormat(
            "yyMMdd HH:mm");

    private static final NumberFormat numFormatter = NumberFormat.getNumberInstance();

    private static final Date date = new Date();

    protected static volatile CoWorkAnalyzer instance = null;

    public static CoWorkAnalyzer getCoWorkAnalyzer() {
        if (instance == null) {
            synchronized (CoWorkAnalyzer.class) {
                if (instance == null) {
                    instance = new CoWorkAnalyzer();
                }
            }
        }
        return instance;
    }

    protected CoWorkAnalyzer() {}

    static class FreeWorkerStatus {
        public long time;

        public int freeWorker;

        public FreeWorkerStatus(long t, int n) {
            time = t;
            freeWorker = n;
        }
    }

    PriorityQueue<FreeWorkerStatus> freeWorkerSample = new PriorityQueue<FreeWorkerStatus>(
            3 * 24 * 60, new Comparator<FreeWorkerStatus>() {
                @Override
                public int compare(FreeWorkerStatus o1, FreeWorkerStatus o2) {
                    if (o1.time > o2.time)
                        return 1;
                    else if (o1.time < o2.time)
                        return -1;
                    else
                        return 0;
                }

            });

    public void takeFreeWorkerSample(long time, int workerNum) {
        synchronized (freeWorkerSample) {
            freeWorkerSample.add(new FreeWorkerStatus(time, workerNum));
            while (freeWorkerSample.peek() != null) {
                FreeWorkerStatus status = freeWorkerSample.peek();
                if (System.currentTimeMillis() - status.time > 3 * UnitUtils.DAY)
                    freeWorkerSample.poll();
                else
                    break;
            }
        }
    }

    public void buildFreeWorkerDistribute(long fromTime, int intervalMin,
            ArrayList<String> timeAxis, ArrayList<Integer> workerAxis) {
        long interval = intervalMin * UnitUtils.MINUTE;
        ArrayList<FreeWorkerStatus> statList = new ArrayList<FreeWorkerStatus>();
        synchronized (freeWorkerSample) {
            statList.addAll(freeWorkerSample);
        }

        Collections.sort(statList, new Comparator<FreeWorkerStatus>() {
            @Override
            public int compare(FreeWorkerStatus o1, FreeWorkerStatus o2) {
                if (o1.time > o2.time)
                    return 1;
                else if (o1.time < o2.time)
                    return -1;
                else
                    return 0;
            }
        });

        long start = fromTime;
        long end = fromTime + interval;

        int num = 0;
        int sum = 0;
        int i = 0;
        while (i < statList.size()) {
            FreeWorkerStatus stat = statList.get(i);
            if (stat.time < start) {
                ++i;
                continue;
            } else if (stat.time >= start && stat.time < end) {
                ++num;
                sum = sum + stat.freeWorker;
                ++i;
                continue;
            } else if (stat.time >= end) {
                if (sum > 0) {
                    assert num > 0;
                    workerAxis.add(sum / num);
                    timeAxis.add(formatter4.format(new Date(start)));
                    sum = 0;
                    num = 0;
                }

                start = end;
                end = end + interval;
            }
        }

        if (sum > 0) {
            assert num > 0;
            workerAxis.add(sum / num);
            timeAxis.add(formatter4.format(new Date(start)));
            sum = 0;
            num = 0;
        }
    }

    public static void setupLogDir(String logDir) {
        jobDir = new File(logDir, JobMaster.JOB_DIR);
        jobArchive = new File(logDir, JobMaster.JOB_ARCHIVE_DIR);
    }

    public int rebuildTotalJobDetail() throws IOException {
        int num = 0;
        File[] files = jobDir.listFiles();
        for (File f: files) {
            JobDetail j = new JobDetail(f.getName());
            if (j.rebuildMetaFile(f))
                ++num;
        }

        File[] dirs = jobDir.listFiles();
        for (File dir: dirs) {
            File[] fs = dir.listFiles();
            for (File f: fs) {
                JobDetail j = new JobDetail(f.getName());
                if (j.rebuildMetaFile(f))
                    ++num;
            }
        }
        return num;
    }

    public String rebuildDaySummary(File arcDir) throws IOException {
        File[] files = arcDir.listFiles();
        StringBuilder sb = new StringBuilder();
        for (File file: files) {
            try {
                DaySummary summary = new DaySummary(file.getName());
                summary.parseFromJobs(file);
                sb.append("Processed ").append(file.getPath()).append("[").append(
                        summary.toString()).append("]<BR>\n");
            } catch (Exception e) {
                sb.append(e).append("<BR>\n");
            }
        }
        return sb.toString();
    }

    public JobDetail getJobDetail(String jobid) throws IOException {
        //		if (jobDetailMap.containsKey(jobid))
        //			return jobDetailMap.get(jobid);
        JobDetail detail = new JobDetail(jobid);
        detail.parseFromJobDir(new File(jobDir, jobid));
        //		jobDetailMap.put(jobid, detail);
        return detail;
    }

    public JobDetail getJobDetail(String jobid, String archiveDateDir)
            throws IOException {
        File jobDir = new File(new File(jobArchive, archiveDateDir), jobid);
        JobDetail detail = new JobDetail(jobid);
        detail.parseFromJobDir(jobDir);
        return detail;
    }

    public ProgramDetail getProgramDetailInPeriod(String programName, int period) {
        //today
        ProgramDetail pDetails = getProgramDetail(jobDir, programName);

        if (period > 1) {
            for (int i = 2; i <= period; ++i) {
                String dateDirName = getArchiveDirNameByDay(i);
                File dayDir = new File(jobArchive, dateDirName);
                if (dayDir.exists())
                    pDetails.add(getProgramDetail(dayDir, programName));
                if (pDetails.getJobsNumber() > MAX_JOBS_PER_PROGRAM)
                    break;
            }
        }
        return pDetails;
    }

    //example: 090807
    public DaySummary getDaySummary(String day) {
        File dayDir = new File(jobArchive, day);
        if (!dayDir.exists())
            return null;
        DaySummary summary = new DaySummary(day);
        summary.parse(dayDir);
        return summary;
    }

    //from old -> new
    public List<DaySummary> getDaySummaryInPeriod(int period) {
        ArrayList<DaySummary> summarys = new ArrayList<DaySummary>();
        long currentTime = System.currentTimeMillis();
        Date date = new Date();
        for (int i = period; i >= 1; --i) {
            date.setTime(currentTime - UnitUtils.DAY * i);
            String dirName = formatter1.format(date);
            File dir = new File(jobArchive, dirName);
            DaySummary summary = new DaySummary(dirName);
            if (!dir.exists()) {
                summarys.add(summary);
                continue;
            }
            try {
                summary.parse(dir);
                summarys.add(summary);
            } catch (Exception e) {
                //				continue;
            }

        }
        return summarys;
    }

    public String getArchiveDirNameByDay(int preDays) {
        long currentTime = System.currentTimeMillis();
        date.setTime(currentTime - UnitUtils.DAY * preDays);
        return formatter1.format(date);
    }

    public String getArchiveDirNameByTime(long time) {
        date.setTime(time);
        return formatter1.format(date);
    }

    public ProgramDetail getProgramDetail(File dir, String program) {
        File[] files = listFileByProgram(dir, program);
        ProgramDetail ps = new ProgramDetail(program);
        for (File file: files) {
            JobDetail j = new JobDetail(file.getName());
            try {
                j.parseFromJobDir(file);
                if (j.getProgramName().equals(program))
                    ps.add(j);
            } catch (Exception e) {
                ;
            }
        }
        return ps;
    }

    public UserDetail getUserDetail(File dir, String username) {
        File[] files = listFileByUser(dir, username);
        UserDetail us = new UserDetail(username);
        for (File file: files) {
            JobDetail j = new JobDetail(file.getName());
            try {
                j.parseFromJobDir(file);
                if (j.getProgramName().equals(username))
                    us.add(j);
            } catch (Exception e) {
                ;
            }
        }
        return us;
    }

    public HashMap<String, JobDetail> listTodayJobDetail() {
        synchronized (todayJobDetailMap) {
            if (jobDir.lastModified() == jobDirLMT)
                return todayJobDetailMap;
            long currentTime = System.currentTimeMillis();
            File[] files = jobDir.listFiles(new FileFilter() {
                @Override
                public boolean accept(File file) {
                    if (file.lastModified() >= jobDirLMT)
                        return true;
                    return false;
                }
            });
            for (File f: files) {
                try {
                    JobDetail j;
                    if (!todayJobDetailMap.containsKey(f.getName())) {
                        j = new JobDetail(f.getName());
                        j.parseFromJobDir(f);
                        todayJobDetailMap.put(f.getName(), j);
                    } 
                } catch (Exception e) {
                    ;
                }
            }
            jobDirLMT = jobDir.lastModified();

            ArrayList<String> delKeys = new ArrayList<String>();
            for (Map.Entry<String, JobDetail> entry: todayJobDetailMap.entrySet()) {
                if (entry.getValue().getEndTime() < currentTime - UnitUtils.DAY) {
                    File src = new File(jobDir, entry.getKey());
                    if (!src.exists()) {
                        LOG.warning("source file don't exist:" + src.getPath());
                        continue;
                    }
                    File arch = new File(jobArchive,
                            formatter1.format(new Date(
                                    entry.getValue().getEndTime())));
                    arch.mkdirs();
                    File destFile = new File(arch, src.getName());
                    if (destFile.exists()) {
                        if (destFile.isDirectory()) {
                            File[] infiles = destFile.listFiles();
                            for (File infile: infiles) {
                                infile.delete();
                            }
                        }
                        destFile.delete();
                    }
                    src.renameTo(destFile);
                    LOG.info("Move file " + src.getPath() + " to: " + destFile);
                    delKeys.add(entry.getKey());
                }
            }
            for (String key: delKeys) {
                todayJobDetailMap.remove(key);
            }
            HashMap<String, JobDetail> maps = new HashMap<String, JobDetail>(todayJobDetailMap);
            return maps;
        }
    }

    public HashMap<String, JobDetail> listJobDetails(File dir) {
        HashMap<String, JobDetail> js = new HashMap<String, JobDetail>();
        //cache today's job 
        if (dir.equals(jobDir)) {
            return listTodayJobDetail();
        }
        File[] files = dir.listFiles();
        for (File file: files) {
            JobDetail j = new JobDetail(file.getName());
            try {
                j.parseFromJobDir(file);
                js.put(j.getJobName(), j);
            } catch (Exception e) {
                ;
            }
        }
        return js;
    }

    public HashMap<String, ProgramDetail> listAllProgramDetails(File dir) {
        HashMap<String, JobDetail> js = listJobDetails(dir);
        HashMap<String, ProgramDetail> ps = new HashMap<String, ProgramDetail>();
        for (Map.Entry<String, JobDetail> entry: js.entrySet()) {
            if (!entry.getValue().isSuccess())
                continue;
            if (ps.containsKey(entry.getValue().getProgramName())) {
                ps.get(entry.getValue().getProgramName()).add(entry.getValue());
            } else {
                ProgramDetail p = new ProgramDetail(
                        entry.getValue().getProgramName());
                p.add(entry.getValue());
                ps.put(entry.getValue().getProgramName(), p);
            }
        }
        return ps;
    }

    public HashMap<String, UserDetail> listAllUserDetails(File dir) {
        HashMap<String, JobDetail> js = listJobDetails(dir);
        HashMap<String, UserDetail> us = new HashMap<String, UserDetail>();
        for (Map.Entry<String, JobDetail> entry: js.entrySet()) {
            if (!entry.getValue().isSuccess())
                continue;
            if (us.containsKey(entry.getValue().getUser())) {
                us.get(entry.getValue().getUser()).add(entry.getValue());
            } else {
                UserDetail p = new UserDetail(entry.getValue().getUser());
                p.add(entry.getValue());
                us.put(entry.getValue().getUser(), p);
            }
        }
        return us;
    }

    public HashMap<String, ProgramDetail> listTodayProgramDetails() {
        return listAllProgramDetails(jobDir);
    }

    public HashMap<String, UserDetail> listTodayUserDetails() {
        return listAllUserDetails(jobDir);
    }

    public static File[] listFileByUser(File dir, final String username) {
        return dir.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                if (file.getName().startsWith(username))
                    return true;
                return false;
            }

        });
    }

    public static File[] listFileByProgram(File dir, final String proname) {
        return dir.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                if (file.getName().indexOf(proname) != -1)
                    return true;
                return false;
            }

        });
    }

    public static byte[] readFileToByteArray(File file) throws IOException {
        if (!file.exists() || file.isDirectory()) {
            throw new IOException("Can't read file:" + file.getAbsolutePath());
        }
        long size = file.length();
        if (size > 16 * 1024 * 1024) {
            throw new IOException("File is to large to read fully!");
        }
        byte[] b = new byte[(int) size];
        FileInputStream fileInput = null;
        try {
            fileInput = new FileInputStream(file);
            fileInput.read(b, 0, (int) size);
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            if (fileInput != null)
                fileInput.close();
        }
        return b;
    }

    public static double getClaimedUsedWorkerHour(Collection<JobDetail> jobs) {
        double sum = 0;
        for (JobDetail job: jobs) {
            sum += job.getClaimedUsedWorkerHour();
        }
        return Math.round(sum * 100) / (double) 100;
    }

    public static double getActualUsedWorkerHour(Collection<JobDetail> jobs) {
        double sum = 0;
        for (JobDetail job: jobs) {
            sum += job.getActualUsedWorkerHour();
        }
        return Math.round(sum * 100) / (double) 100;
    }

    public static double getUtilityRatio(Collection<JobDetail> jobs) {
        if (getClaimedUsedWorkerHour(jobs) == 0)
            return 0;
        double num = getActualUsedWorkerHour(jobs)
                / getClaimedUsedWorkerHour(jobs);
        return Math.round(num * 100) / (double) 100;
    }

    public static long getTotalMapInSize(Collection<JobDetail> jobs) {
        long size = 0;
        for (JobDetail job: jobs) {
            size += job.getTotalMapInSize();
        }
        return size;
    }

    public static class JobDetail implements IWritable {
        protected final static int Job_Detail_Version = 0x1001;

        public final static String Job_Meta_File = "job.meta";

        public final static String Job_Html_File = "index.html";

        protected String jobName;

        protected int jobStatus;

        protected int workerNum, stageNum;

        protected long submitTime = -1;

        protected long startTime, endTime;

        protected long elapsedTime; // second

        ArrayList<TaskDetail> tasks = new ArrayList<TaskDetail>();

        ArrayList<Long> preRelease = new ArrayList<Long>();

        public JobDetail(String jobName) {
            this.jobName = jobName;
        }

        public String getJobName() {
            return jobName;
        }

        public int getStatus() {
            return jobStatus;
        }

        public void setStatus(int status) {
            this.jobStatus = status;
        }

        public String getUser() {
            int pos = jobName.indexOf("_");
            if (pos != -1) {
                return jobName.substring(0, pos);
            }
            return null;
        }

        public void addPreRelease(ArrayList<Long> rs) {
            this.preRelease.addAll(rs);
        }

        public long getTotalMapInSize() {
            long sum = 0;
            for (TaskDetail task: tasks) {
                if (task.getStage() == 0)
                    sum += task.getInputSize();
            }
            return sum;
        }

        public double getClaimedUsedWorkerHour() {
            return (elapsedTime * workerNum) / (double) UnitUtils.HOUR_SEC;
        }

        public double getActualUsedWorkerHour() {
            double sum = 0.0;
            for (TaskDetail task: tasks) {
                sum += (task.getRunningTime() > elapsedTime ? elapsedTime
                        : task.getRunningTime());
            }
            return sum / UnitUtils.HOUR_SEC;
        }

        public double getUtilityRatio() {
            double ratio = getActualUsedWorkerHour()
                    / getClaimedUsedWorkerHour();
            return Math.round(ratio * 100) / (double) 100;
        }

        public String getProgramName() {
            int fpos = jobName.indexOf("_");
            int bpos = jobName.lastIndexOf("_");
            if (fpos != -1 && bpos != -1 && fpos != bpos) {
                return jobName.substring(fpos + 1, bpos);
            }
            return null;
        }

        public TaskDetail[] getTasks(int stage) {
            ArrayList<TaskDetail> taskList = new ArrayList<TaskDetail>();
            for (TaskDetail detail: tasks) {
                if (detail.getStage() == stage)
                    taskList.add(detail);
            }
            TaskDetail[] ts = new TaskDetail[taskList.size()];
            taskList.toArray(ts);
            return ts;
        }

        public boolean parseFromJobDir(File jobDir) throws IOException {
            File metaFile = new File(jobDir, Job_Meta_File);
            if (metaFile.exists())
                return parseFromMetaFile(metaFile);
            else {
                File htmlFile = new File(jobDir, Job_Html_File);
                boolean flag = parseFromHtmlFile(htmlFile);
                writeMetaFile(metaFile);
                return flag;
            }
        }

        public boolean rebuildMetaFile(File jobDir) throws IOException {
            File metaFile = new File(jobDir, Job_Meta_File);
            File htmlFile = new File(jobDir, Job_Html_File);
            if (!htmlFile.exists())
                return false;
            parseFromHtmlFile(htmlFile);
            writeMetaFile(metaFile);
            return true;
        }

        public boolean parseFromMetaFile(File metaFile) throws IOException {
            DataInputStream in = new DataInputStream(new FileInputStream(
                    metaFile));
            this.readFields(in);
            in.close();
            return true;
        }

        public boolean writeMetaFile(File metaFile) throws IOException {
            DataOutputStream out = new DataOutputStream(new FileOutputStream(
                    metaFile, false));
            writeFields(out);
            out.close();
            return true;
        }

        //		protected static SimpleDateFormat
        public boolean parseFromHtmlFile(File htmlFile) throws IOException {
            if (!htmlFile.exists())
                return false;
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new FileReader(
                        htmlFile));
                String line = reader.readLine();
                String[] splits = line.split(":");;
                jobStatus = Integer.parseInt(splits[1]); // job status
                endTime = Long.parseLong(splits[2]); // job finish date
                if (splits.length == 6) {
                    workerNum = Integer.parseInt(splits[3]); // job worker num
                    String elapsed = splits[4];
                    elapsedTime = CoWorkUtils.fromString2Second(elapsed);
                }
                Pattern pWorkerNum = Pattern.compile("Worker Number Claimed: </B>(.+)<BR>");
                Pattern pElapsedTime = Pattern.compile("Elapsed Time: </B>(.+)<BR>");
                Pattern pStartTime = Pattern.compile("<B>Start: </B>(.+)<BR>");
                Pattern pEndTime = Pattern.compile("<B>End: </B>(.+)<BR>");
                Pattern pStage = Pattern.compile("Task Status: </B>(.+).stages");
                Pattern pSubmitTime = Pattern.compile("<B>Submit Time: </B>(.+)<BR>");

                while ((line = reader.readLine()) != null) {
                    Matcher m = pWorkerNum.matcher(line);
                    if (m.find()) {
                        workerNum = Integer.parseInt(m.group(1));
                        if (jobStatus != 3)
                            return false;
                        continue;
                    }
                    m = pElapsedTime.matcher(line);
                    if (m.find()) {
                        elapsedTime = CoWorkUtils.fromString2Second(m.group(1));
                        continue;
                    }
                    m = pSubmitTime.matcher(line);
                    if (m.find()) {
                        submitTime = formatter3.parse(m.group(1)).getTime();
                        continue;
                    }
                    m = pStartTime.matcher(line);
                    if (m.find()) {
                        startTime = formatter3.parse(m.group(1)).getTime();
                        continue;
                    }
                    m = pEndTime.matcher(line);
                    if (m.find()) {
                        endTime = formatter3.parse(m.group(1)).getTime();
                        continue;
                    }
                    m = pStage.matcher(line);
                    if (m.find()) {
                        stageNum = Integer.parseInt(m.group(1));
                        continue;
                    }
                    if (line.indexOf("<H3>====") != -1) {
                        ArrayList<String> strList = new ArrayList<String>();
                        while (!line.startsWith("<BR>")) {
                            strList.add(line);
                            line = reader.readLine();
                            if (line == null) {
                                break;
                            }
                        }

                        String[] strs = new String[strList.size()];
                        strList.toArray(strs);
                        TaskDetail detail = new TaskDetail();
                        if (detail.parseFromHtml(strs) && detail.isSuccess()) {
                            tasks.add(detail);
                        } else {
                            // assert false;
                        }
                    }
                }
                return true;
            } catch (Exception e) {
                throw new IOException(e.getMessage() + " When parse file:"
                        + htmlFile.getPath() + "\n" + this.toString());
            } finally {
                ReadWriteUtils.safeClose(reader);
            }
        }

        public boolean isSuccess() {
            return jobStatus == JobMaster.JOB_STATE_CLOSING;
        }

        public boolean isAbort() {
            return jobStatus == JobMaster.JOB_STATE_ABORTING;
        }

        public void setStartTime(long t) {
            this.startTime = t;
        }

        public long getStartTime() {
            return startTime;
        }

        public void setEndTime(long t) {
            this.endTime = t;
        }

        public long getEndTime() {
            return endTime;
        }

        public void setSubmitTime(long t) {
            this.submitTime = t;
        }

        public long getSubmitTime() {
            return submitTime;
        }

        public Date getSubmitDate() {
            return new Date(submitTime);
        }

        //return waiting time, s
        public long getWaitingTime() {
            return submitTime == -1 ? 0 : (startTime - submitTime) / 1000;
        }

        public Date getEndDate() {
            return new Date(endTime);
        }

        public void setElapsedTime(long t) {
            this.elapsedTime = t;
        }

        public long getElapsedTime() {
            return elapsedTime;
        }

        public void setClaimedWorkerNum(int n) {
            this.workerNum = n;
        }

        public int getClaimedWorkerNum() {
            return workerNum;
        }

        public void setStageNum(int n) {
            this.stageNum = n;
        }

        public int getStageNum() {
            return stageNum;
        }

        public void addTaskDetail(TaskDetail t) {
            this.tasks.add(t);
        }

        public TaskDetail getTask(int i) {
            return tasks.get(i);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Job: ").append(jobName).append("\n status:").append(
                    jobStatus);
            sb.append("Worker: ").append(workerNum).append(", stage: ").append(
                    stageNum).append("\n");
            sb.append("submit: ").append(
                    formatter2.format(new Date(submitTime)));
            sb.append("start: ").append(formatter2.format(new Date(startTime))).append(
                    ", end: ").append(formatter2.format(new Date(endTime)));
            sb.append(", elapse: ").append(elapsedTime).append("\n");
            sb.append("Tasks number: ").append(tasks.size()).append("\n");
            for (TaskDetail task: tasks) {
                sb.append("[").append(task.toString()).append("]\n");
            }
            return sb.toString();
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            int v = in.readInt();
            if (v != Job_Detail_Version)
                throw new IOException(
                        "Job detail file version is tooooooooold.");
            jobName = in.readUTF();
            jobStatus = in.readInt();
            workerNum = in.readInt();
            stageNum = in.readInt();
            submitTime = in.readLong();
            startTime = in.readLong();
            endTime = in.readLong();
            elapsedTime = in.readLong();

            int loop = in.readInt();
            for (int i = tasks.size() - 1; i > loop - 1; --i)
                tasks.remove(i);

            for (int i = 0; i < loop; ++i) {
                if (i < tasks.size())
                    tasks.get(i).readFields(in);
                else {
                    TaskDetail td = new TaskDetail();
                    td.readFields(in);
                    tasks.add(td);
                }
            }

            loop = in.readInt();
            preRelease.clear();
            for (int i = 0; i < loop; ++i) {
                preRelease.add(in.readLong());
            }

        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeInt(Job_Detail_Version);
            out.writeUTF(jobName);
            out.writeInt(jobStatus);
            out.writeInt(workerNum);
            out.writeInt(stageNum);
            out.writeLong(submitTime);
            out.writeLong(startTime);
            out.writeLong(endTime);
            out.writeLong(elapsedTime);

            out.writeInt(tasks.size());
            for (TaskDetail task: tasks)
                task.writeFields(out);

            out.writeInt(preRelease.size());
            for (Long l: preRelease)
                out.writeLong(l);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            JobDetail that = (JobDetail) value;
            this.jobName = that.jobName;
            this.jobStatus = that.jobStatus;
            this.workerNum = that.workerNum;
            this.stageNum = that.stageNum;
            this.submitTime = that.submitTime;
            this.startTime = that.startTime;
            this.endTime = that.endTime;
            this.elapsedTime = that.elapsedTime;

            for (int i = 0; i < that.tasks.size(); ++i) {
                if (i < this.tasks.size())
                    this.tasks.get(i).copyFields(that.tasks.get(i));
                else {
                    TaskDetail td = new TaskDetail();
                    td.copyFields(that.tasks.get(i));
                    this.tasks.add(td);
                }
            }
            for (int i = this.tasks.size() - 1; i > that.tasks.size() - 1; --i)
                this.tasks.remove(i);

            this.preRelease.clear();
            for (int i = 0; i < that.preRelease.size(); ++i)
                this.preRelease.add(that.preRelease.get(i));

            return this;
        }

        //		public File getDefaultMetaFile(){
        //			return new File(new File(jobDir,jobName),Job_Meta_File);
        //		}
    }

    public static class TaskDetail implements IWritable {
        public double runningTime = 0;

        public String machine = "";

        public long mapInSize = -1, reduceInSize = -1, outputSize = -1;

        public int stage = -1;

        public boolean successFlag = false;

        public boolean parseFromHtml(String[] lines) throws Exception {
            numFormatter.setGroupingUsed(true);
            Pattern pTaskTime = Pattern.compile("TotalTime=(.+)s");
            Pattern pMachine = Pattern.compile("SUCCESS:tm_(.+).corp");
            Pattern pStage = Pattern.compile("==== task-(.+)-");
            Pattern pMapInSize = Pattern.compile("MappedInSize=(.*)$");
            Pattern pReduceInSize = Pattern.compile("ReduceInSize=(.*)$");

            for (String line: lines) {
                Matcher m = pMachine.matcher(line);
                if (m.find()) {
                    machine = m.group(1);
                    successFlag = true;
                }
                m = pTaskTime.matcher(line);
                if (m.find()) {
                    runningTime = numFormatter.parse(m.group(1)).doubleValue();
                }
                m = pStage.matcher(line);
                if (m.find())
                    stage = Integer.parseInt(m.group(1));
                m = pMapInSize.matcher(line);
                if (m.find())
                    mapInSize = numFormatter.parse((m.group(1))).longValue();
                m = pReduceInSize.matcher(line);
                if (m.find())
                    reduceInSize = numFormatter.parse((m.group(1))).longValue();
            }
            if (machine == null || runningTime == -1)
                return false;
            return true;
        }

        public boolean isSuccess() {
            return successFlag;
        }

        public double getRunningTime() {
            return runningTime;
        }

        public String getMachine() {
            return machine;
        }

        public long getInputSize() {
            return reduceInSize == -1 ? mapInSize : reduceInSize;
        }

        public long getOutputSize() {
            return outputSize;
        }

        public int getStage() {
            return stage;
        }

        public void setStage(int s) {
            stage = s;
        }

        public String toString() {
            return "Use time:" + runningTime + ", at " + machine + ", stage:"
                    + stage + ", input size:" + getInputSize();
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            runningTime = in.readDouble();
            machine = in.readUTF();
            stage = in.readInt();
            successFlag = in.readBoolean();
            mapInSize = in.readLong();
            reduceInSize = in.readLong();
            outputSize = in.readLong();
        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeDouble(runningTime);
            out.writeUTF(machine);
            out.writeInt(stage);
            out.writeBoolean(successFlag);
            out.writeLong(mapInSize);
            out.writeLong(reduceInSize);
            out.writeLong(outputSize);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            TaskDetail that = (TaskDetail) value;
            this.runningTime = that.runningTime;
            this.machine = that.machine;
            this.stage = that.stage;
            this.successFlag = that.successFlag;
            this.mapInSize = that.mapInSize;
            this.reduceInSize = that.reduceInSize;
            this.outputSize = that.outputSize;
            return this;
        }
    }

    public static class JobListDetail {
        protected ArrayList<JobDetail> jobs = new ArrayList<JobDetail>();

        public void add(JobDetail job) {
            jobs.add(job);
        }

        public void add(JobListDetail jList) {
            jobs.addAll(jList.jobs);
        }

        //form old -> new, can reverse
        public void sortByDate(boolean reverse) {
            if (reverse) {
                Collections.sort(jobs, new Comparator<JobDetail>() {
                    @Override
                    public int compare(JobDetail o1, JobDetail o2) {
                        return (int) (o2.getEndTime() - o1.getEndTime());
                    }
                });
            } else {
                Collections.sort(jobs, new Comparator<JobDetail>() {
                    @Override
                    public int compare(JobDetail o1, JobDetail o2) {
                        return (int) (o1.getEndTime() - o2.getEndTime());
                    }
                });
            }
        }

        public ArrayList<JobDetail> getJobs() {
            return jobs;
        }

        public int getJobsNumber() {
            return jobs.size();
        }

        public double getClaimedUsedWorkerHour() {
            double sum = 0;
            for (JobDetail job: jobs) {
                sum += job.getClaimedUsedWorkerHour();
            }
            return Math.round(sum * 100) / (double) 100;
        }

        public double getActualUsedWorkerHour() {
            double sum = 0;
            for (JobDetail job: jobs) {
                sum += job.getActualUsedWorkerHour();
            }
            return Math.round(sum * 100) / (double) 100;
        }

        public double getUtilityRatio() {
            if (getClaimedUsedWorkerHour() == 0)
                return 0;
            double num = getActualUsedWorkerHour() / getClaimedUsedWorkerHour();
            return Math.round(num * 100) / (double) 100;
        }

        public long getTotalMapInSize() {
            long size = 0;
            for (JobDetail job: jobs) {
                size += job.getTotalMapInSize();
            }
            return size;
        }

        public long getTotalReduceOutSize() {
            //@TODO
            long size = 0;
            //			for (JobDetail job : jobs) {
            //				size += job.get;
            //			}
            return size;
        }
    }

    public static class UserDetail extends JobListDetail {
        private String username;

        public UserDetail(String username) {
            super();
            this.username = username;
        }

        public String getUser() {
            return username;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(username).append(" has run ").append(jobs.size()).append(
                    " jobs").append("\n");
            for (JobDetail job: jobs) {
                sb.append(job.getJobName()).append("\n");
            }
            return sb.toString();
        }
    }

    public static class ProgramDetail extends JobListDetail {
        private String program;

        public ProgramDetail(String programName) {
            this.program = programName;
        }

        public String getProgram() {
            return program;
        }

    }

    public static class DaySummary extends JobListDetail implements IWritable {
        public static final String DAY_SUMMARY_DEFAULT_FILENAME = "day.meta";

        public static final int DAY_SUMMARY_FILE_VERSION = 2;

        protected String day;

        protected int jobNum;

        protected long inputSize;

        protected long outputSize;

        protected double totalWorkHour;

        protected int abortJobNum;

        //like 090805
        public DaySummary(String day) {
            jobNum = 0;
            totalWorkHour = 0;
            inputSize = 0;
            outputSize = 0;
            this.day = day;
            abortJobNum = 0;
        }

        public DaySummary(long time) {
            day = formatter1.format(new Date(time));
        }

        public void parse(File archiveDir) throws RuntimeException {
            File metaFile = new File(archiveDir, DAY_SUMMARY_DEFAULT_FILENAME);
            if (metaFile.exists()
                    && metaFile.lastModified() >= archiveDir.lastModified()) { //if it don't changed
                try {
                    DataInputStream in = new DataInputStream(
                            new FileInputStream(metaFile));
                    readFields(in);
                    in.close();
                    return;
                } catch (Exception e) {
                    LOG.warning("read meta file error." + e);
                }
            }
            parseFromJobs(archiveDir);
        }

        //parse from job meta
        public void parseFromJobs(File archiveDir) throws RuntimeException {
            File metaFile = new File(archiveDir, DAY_SUMMARY_DEFAULT_FILENAME);
            File[] files = archiveDir.listFiles();
            for (File file: files) {
                LOG.info("Process " + file.getPath());
                if (!file.isDirectory())
                    continue;
                JobDetail j = new JobDetail(file.getName());
                try {
                    j.parseFromJobDir(file);
                    if (j.isSuccess())
                        this.add(j);
                    else
                        ++abortJobNum;
                } catch (Exception e) {
                    LOG.warning("parse day summay error." + e);
                    continue;
                    //throw new RuntimeException("parse day summay meta error.",e);					
                }
            }

            jobNum = super.getJobsNumber();
            inputSize = super.getTotalMapInSize();
            outputSize = super.getTotalReduceOutSize();
            totalWorkHour = super.getActualUsedWorkerHour();

            try {
                DataOutputStream out = new DataOutputStream(
                        new FileOutputStream(metaFile));
                writeFields(out);
                out.close();
            } catch (Exception e) {
                LOG.warning("write day summary meta error." + e);
                throw new RuntimeException("write day summary meta error.", e);
            }

            super.jobs.clear();

        }

        @Override
        public int getJobsNumber() {
            return jobNum;
        }

        public int getAbortJobNumber() {
            return abortJobNum;
        }

        @Override
        public long getTotalMapInSize() {
            return inputSize;
        }

        @Override
        public long getTotalReduceOutSize() {
            return outputSize;
        }

        @Override
        public double getActualUsedWorkerHour() {
            return totalWorkHour;
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            int v = in.readInt();
            if (v != DAY_SUMMARY_FILE_VERSION)
                throw new IOException("meta version is error. v = " + v);
            jobNum = in.readInt();
            inputSize = in.readLong();
            outputSize = in.readLong();
            totalWorkHour = in.readDouble();
            abortJobNum = in.readInt();

        }

        @Override
        public void writeFields(DataOutput out) throws IOException {
            out.writeInt(DAY_SUMMARY_FILE_VERSION);
            out.writeInt(jobNum);
            out.writeLong(inputSize);
            out.writeLong(outputSize);
            out.writeDouble(totalWorkHour);
            out.writeInt(abortJobNum);
        }

        @Override
        public IWritable copyFields(IWritable value) {
            DaySummary that = (DaySummary) value;
            this.day = that.day;
            this.jobNum = that.jobNum;
            this.inputSize = that.inputSize;
            this.outputSize = that.outputSize;
            this.totalWorkHour = that.totalWorkHour;
            this.abortJobNum = that.abortJobNum;
            return this;
        }

        public String toString() {
            return day + " sumamry: jobnum:" + jobNum + " inputsize: "
                    + inputSize + " outputsize:" + outputSize
                    + " total work hour:" + totalWorkHour + ", abort job:"
                    + abortJobNum;

        }

    }

    public static void main(String[] args) throws IOException {
        JobDetail job = new JobDetail("one job");
//        try {
//            job.parseFromHtmlFile(new File("job_detail.html"));
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//        //		System.out.println(System.currentTimeMillis() - UnitUtils.DAY * 7);
//        //		System.out.println(job.getEndTime()
//        //				- (System.currentTimeMillis() - UnitUtils.DAY * 7));
//        System.out.println(job);
        job.parseFromMetaFile(new File("C:\\Documents and Settings\\Administrator\\桌面\\diff\\job.meta"));
        System.out.println(job);
    }
}
