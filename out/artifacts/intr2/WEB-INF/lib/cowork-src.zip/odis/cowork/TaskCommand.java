
package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import static odis.cowork.IJobMasterProtocol.*;
import odis.serialize.IWritable;
import odis.serialize.lib.UTF8Writable;

public class TaskCommand implements IWritable {
    private int cmd;              // command definition
    private TaskDef task;         // task definition: values
//    private String[] prevWorkers; // machines used in last stage
    private TaskCompletionEvent [] preTaskEvents = TaskCompletionEvent.EMPTY_EVENTS;
    private JobConfig jobConf;    // configuration of job
    private int resNeed = 1;      // resource copies
    
    public int getCmdCode() { return cmd; }
    public TaskDef getTaskDef() { return task; }
    public TaskCompletionEvent[] getPrevTaskEvents() {return preTaskEvents; }
//    public String[] getPrevWorkers() { return prevWorkers; }
    public JobConfig getJobConf() { return jobConf; }
    public int getResNeed() { return resNeed; }
    
    public TaskCommand() {}
    public TaskCommand(int cmd, TaskDef task, TaskCompletionEvent[] lastEvents, JobConfig jc) { this(cmd, task, lastEvents, jc, 1); }
    public TaskCommand(int cmd, TaskDef task, TaskCompletionEvent[] lastEvents, JobConfig jc, int resNeed) {
      this.cmd = cmd;
      assert ( ( (cmd==TASK_CMD_NEW_TASK||cmd==TASK_CMD_DEL_TASK||cmd==TASK_CMD_UPD_TASK||cmd==TASK_CMD_PREPARE_TASK) && task!=null ) 
            || ( (cmd==TASK_CMD_NULL||cmd==TASK_CMD_UNKNOWN_TM) && task==null) );
      this.task = task;
      if (lastEvents != null) {
          this.preTaskEvents = lastEvents;          
      }
//      this.prevWorkers = lastMachs;
      this.jobConf = jc;
      this.resNeed = resNeed;
      assert ( (cmd!=TASK_CMD_NEW_TASK || cmd!=TASK_CMD_PREPARE_TASK) && jobConf==null )
          || ( cmd==TASK_CMD_NEW_TASK && jobConf!=null )
          || (cmd==TASK_CMD_PREPARE_TASK && jobConf!=null);
    }

    public void writeFields(DataOutput out) throws IOException {
      assert ( (cmd!=TASK_CMD_NEW_TASK || cmd!=TASK_CMD_PREPARE_TASK) && jobConf==null )
        || ( cmd==TASK_CMD_NEW_TASK && jobConf!=null )
        || (cmd==TASK_CMD_PREPARE_TASK && jobConf!=null);
      out.writeInt(cmd);
      if (cmd==TASK_CMD_NULL||cmd==TASK_CMD_UNKNOWN_TM) return;
      task.writeFields(out);
      if (cmd==TASK_CMD_DEL_TASK) return;
      out.writeInt(preTaskEvents.length);
      for (TaskCompletionEvent e : preTaskEvents) {
          e.writeFields(out);
      }
      if (cmd!=TASK_CMD_NEW_TASK && cmd!=TASK_CMD_PREPARE_TASK) return;
      jobConf.writeFields(out);
      out.writeInt(resNeed);
    }

    public void readFields(DataInput in) throws IOException {
      cmd = in.readInt();
      if (cmd==TASK_CMD_NULL||cmd==TASK_CMD_UNKNOWN_TM) return;
      task = new TaskDef(); task.readFields(in);
      if (cmd==TASK_CMD_DEL_TASK) return;
      int c = in.readInt();
      preTaskEvents = new TaskCompletionEvent[c];
      for (int i =0; i < c; ++i) {
          preTaskEvents[i] = new TaskCompletionEvent();
          preTaskEvents[i].readFields(in);
      }
      if (cmd!=TASK_CMD_NEW_TASK && cmd!=TASK_CMD_PREPARE_TASK) return;
      jobConf = new JobConfig(); jobConf.readFields(in);
      resNeed = in.readInt();
    }
    
    public IWritable copyFields(IWritable value) {
      TaskCommand that = (TaskCommand) value;
      // cmd
      this.cmd = that.cmd;
      if (cmd==TASK_CMD_NULL||cmd==TASK_CMD_UNKNOWN_TM) return this;
      // taskClass & task
      this.task = new TaskDef(); task.copyFields(that.task);
      if (cmd==TASK_CMD_DEL_TASK) return this;
      // input
      if (that.preTaskEvents.length ==0) {
          this.preTaskEvents = TaskCompletionEvent.EMPTY_EVENTS;
      }else {
          this.preTaskEvents = new TaskCompletionEvent[that.preTaskEvents.length];
          for (int i=0; i < this.preTaskEvents.length; ++i) {
              this.preTaskEvents[i] = new TaskCompletionEvent();
              this.preTaskEvents[i].copyFields(that.preTaskEvents[i]);
          }          
      }
      if (cmd!=TASK_CMD_NEW_TASK && cmd!=TASK_CMD_PREPARE_TASK) return this;
      // jobConf
      this.jobConf = (JobConfig) new JobConfig().copyFields(that.jobConf);
      this.resNeed = that.resNeed;
      return this;
    }
    
    public String toString() {
      switch (cmd) {
        case TASK_CMD_NULL: return "null";
        case TASK_CMD_UNKNOWN_TM: return "unknown_tm";
        case TASK_CMD_NEW_TASK: return "new:"+task+","+Arrays.toString(preTaskEvents);
        case TASK_CMD_PREPARE_TASK: return "prepare:"+task+","+Arrays.toString(preTaskEvents);
        case TASK_CMD_UPD_TASK: return "upd:"+task+","+Arrays.toString(preTaskEvents);
        case TASK_CMD_DEL_TASK: return "del:"+task;
        default: return "wrong_cmd";
      }
    }

    @Override
    public int hashCode() {
      final int PRIME = 31;
      int result = 1;
      result = PRIME * result + cmd;
      result = PRIME * result + ((jobConf == null) ? 0 : jobConf.hashCode());
      result = PRIME * result + Arrays.hashCode(preTaskEvents);
      result = PRIME * result + ((task == null) ? 0 : task.hashCode());
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (getClass() != obj.getClass()) return false;
      final TaskCommand other = (TaskCommand) obj;
      
      if (cmd != other.cmd) return false;
      
      if (jobConf == null) {
        if (other.jobConf != null) return false;
      } else if (!jobConf.equals(other.jobConf)) return false;
      
      if (preTaskEvents.length != other.preTaskEvents.length) return false;
      for (int i = 0; i < preTaskEvents.length; ++i) {
          if (!preTaskEvents[i].equals(other.preTaskEvents[i]))
              return false;
      }      
//      if (!Arrays.deepEquals(preTaskEvents, other.preTaskEvents)) return false;
      
      if (task == null) {
        if (other.task != null) return false;
      } else if (!task.equals(other.task)) return false;
      
      return true;
    }

  }
