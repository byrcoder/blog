/**
 * @(#)JobSubmitTimeoutException.java, 2007-6-3. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.cowork;

/**
 * Timeout when submit one job, main cause is that there's no enough available
 * workers.
 * 
 * @author river
 * 
 */
public class JobSubmitTimeoutException extends RuntimeException {

    private static final long serialVersionUID = -6474117505121243351L;

    public JobSubmitTimeoutException() {
        super();
    }

    public JobSubmitTimeoutException(String message) {
        super(message);
    }

    public JobSubmitTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}
