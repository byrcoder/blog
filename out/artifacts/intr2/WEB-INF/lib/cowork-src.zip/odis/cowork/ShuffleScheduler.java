package odis.cowork;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import odis.mapred.MRConfig;
import odis.mapred.MapHost;
import odis.mapred.TaskID;
import odis.serialize.IWritable;
import odis.serialize.lib.IntWritable;

import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

class ShuffleScheduler<K extends IWritable, V extends IWritable> {
    
    static ThreadLocal<Long> shuffleStart = new ThreadLocal<Long>() {
        protected Long initialValue() {
            return 0L;
        }
    };

    protected static final Logger LOG = LogFormatter
            .getLogger(ShuffleScheduler.class);

    private static final int MAX_MAPS_AT_ONCE = 20;

    private static final long INITIAL_PENALTY = 3 * UnitUtils.SECOND;
    private static final long MAX_PENALTY = 10 * UnitUtils.SECOND;

    private static final float PENALTY_GROWTH_RATE = 1.3f;

    private final static int REPORT_FAILURE_LIMIT = 30;
     
    private final byte MAP_UNKNOW = 0;
    private final byte MAP_READY = 1;
    private final byte MAP_FETCHING = 2;
    private final byte MAP_COPIED = 3;
    
//    private final boolean[] finishedMaps;
//    private final Set<String> finishedMaps = new HashSet<String>();

    private final int totalMaps;

    private volatile int remainingMaps;

    private Map<String, MapHost> mapLocations = new HashMap<String, MapHost>();

    private Set<MapHost> pendingHosts = new HashSet<MapHost>();
    
    private final Random random = new Random(System.currentTimeMillis());

    private final DelayQueue<Penalty> penalties = new DelayQueue<Penalty>();

    private final Referee referee = new Referee();

    private final Map<TaskID, IntWritable> failureCounts = new HashMap<TaskID, IntWritable>();

    private final Map<MapHost, IntWritable> hostFailures = new HashMap<MapHost, IntWritable>();

    byte[] mapStatus;

    private final ExceptionReporter reporter;

    private final int abortFailureLimit;

//    private final Progress progress;

    private final CounterMap.Counter shuffledMapsCounter;

    private final CounterMap.Counter reduceShuffleBytes;

    private final CounterMap.Counter failedShuffleCounter;

    private final long startTime;

    private long lastProgressTime;

    private int maxMapRuntime = 0;

    private int maxFailedUniqueFetches = 30;

    private int maxFetchFailuresBeforeReporting;

    private long totalBytesShuffledTillNow = 0;

    private DecimalFormat mbpsFormat = new DecimalFormat("0.00");

    private boolean reportReadErrorImmediately = true;

    public ShuffleScheduler(JobDef job, int totalMaps,
            ExceptionReporter reporter,
            CounterMap.Counter shuffledMapsCounter,
            CounterMap.Counter reduceShuffleBytes,
            CounterMap.Counter failedShuffleCounter) {
        this.totalMaps = totalMaps;
        mapStatus = new byte[totalMaps];
        Arrays.fill(mapStatus, MAP_UNKNOW);
        abortFailureLimit = Math.max(1024, totalMaps / 10);
        remainingMaps = totalMaps;
        this.reporter = reporter;
        this.shuffledMapsCounter = shuffledMapsCounter;
        this.reduceShuffleBytes = reduceShuffleBytes;
        this.failedShuffleCounter = failedShuffleCounter;
        this.startTime = System.currentTimeMillis();
        lastProgressTime = startTime;
        referee.start();
        this.maxFailedUniqueFetches = Math.min(totalMaps,
                this.maxFailedUniqueFetches);
        this.maxFetchFailuresBeforeReporting = job.getConfig().getInt(
                MRConfig.SHUFFLE_MAX_FETCH_FAILURES, REPORT_FAILURE_LIMIT);
        this.reportReadErrorImmediately = job.getConfig().getBoolean(
                MRConfig.SHUFFLE_READ_ERROR_REPORT, true);
    }

    public synchronized void copySucceeded(TaskID mapId, MapHost host,
            long bytes, long millis, MapOutput<K, V> output) throws IOException {
        failureCounts.remove(mapId);
        hostFailures.remove(host);
//        int mapIndex = mapId.getTaskID().getId();
        
        if (mapStatus[mapId.getPartIdx()] != MAP_COPIED) {
            output.commit();
            mapStatus[mapId.getPartIdx()] = MAP_COPIED;
            shuffledMapsCounter.inc(1);
            if (--remainingMaps == 0) {
                notifyAll();
            }

            // update the status
            totalBytesShuffledTillNow += bytes;
            float mbs = (float) totalBytesShuffledTillNow / (1024 * 1024);
            int mapsDone = totalMaps - remainingMaps;
            long secsSinceStart = (System.currentTimeMillis() - startTime) / 1000 + 1;

            float transferRate = mbs / secsSinceStart;
//            progress.set((float) mapsDone / totalMaps);
            String statusString = mapsDone + " / " + totalMaps + " copied.";
//            status.setStateString(statusString);
//            progress.setStatus("copy(" + mapsDone + " of " + totalMaps + " at "
//                    + mbpsFormat.format(transferRate) + " MB/s)");

            reduceShuffleBytes.inc(bytes);
            lastProgressTime = System.currentTimeMillis();
            LOG.info("map " + mapId + " done " + statusString);
        }
        
        LOG.info("Shuffle map " + mapId + " report success. bytes=" + bytes + ", time=" + millis + ", mapout=" + output + ", remain=" + remainingMaps);
    }

    public synchronized void copyFailed(TaskID mapId, MapHost host,
            boolean readError) {
        mapStatus[mapId.getPartIdx()] = MAP_READY;
        host.markPenalized();
        int failures = 1;
        if (failureCounts.containsKey(mapId)) {
            IntWritable x = failureCounts.get(mapId);
            x.set(x.get() + 1);
            failures = x.get();
        } else {
            failureCounts.put(mapId, new IntWritable(1));
        }
        if (hostFailures.containsKey(host)) {
            IntWritable x = hostFailures.get(host);
            x.set(x.get() + 1);
        } else {
            hostFailures.put(host, new IntWritable(1));
        }
        if (failures >= abortFailureLimit) {
            try {
                throw new IOException(failures + " failures downloading "
                        + mapId);
            } catch (IOException ie) {
                reporter.reportException(ie);
            }
        }

        checkAndInformJobTracker(failures, mapId, readError);

        checkReducerHealth();

//        long delay = (long) (Math.min(PENALTY_GROWTH_RATE * failures * INITIAL_PENALTY, MAX_PENALTY));
        long delay = INITIAL_PENALTY + random.nextInt((int)INITIAL_PENALTY * 3);
        LOG.info("Penalty " + host + " for " + delay +"ms");
        penalties.add(new Penalty(host, Math.min(delay, MAX_PENALTY)));

        failedShuffleCounter.inc(1);
    }
    
    // Notify the JobTracker
    // after every read error, if 'reportReadErrorImmediately' is true or
    // after every 'maxFetchFailuresBeforeReporting' failures
    private void checkAndInformJobTracker(int failures, TaskID mapId,
            boolean readError) {
        if ((reportReadErrorImmediately && readError)
                || ((failures % maxFetchFailuresBeforeReporting) == 0)) {
            LOG.info("Reporting fetch failure for " + mapId + " to jobtracker.");
//            status.addFetchFailedMap(mapId);
        }
    }

    private void checkReducerHealth() {
        final float MAX_ALLOWED_FAILED_FETCH_ATTEMPT_PERCENT = 0.5f;
        final float MIN_REQUIRED_PROGRESS_PERCENT = 0.5f;
        final float MAX_ALLOWED_STALL_TIME_PERCENT = 0.5f;

        long totalFailures = failedShuffleCounter.get();
        int doneMaps = totalMaps - remainingMaps;

        boolean reducerHealthy = (((float) totalFailures / (totalFailures + doneMaps)) < MAX_ALLOWED_FAILED_FETCH_ATTEMPT_PERCENT);

        // check if the reducer has progressed enough
        boolean reducerProgressedEnough = (((float) doneMaps / totalMaps) >= MIN_REQUIRED_PROGRESS_PERCENT);

        // check if the reducer is stalled for a long time
        // duration for which the reducer is stalled
        int stallDuration = (int) (System.currentTimeMillis() - lastProgressTime);

        // duration for which the reducer ran with progress
        int shuffleProgressDuration = (int) (lastProgressTime - startTime);

        // min time the reducer should run without getting killed
        int minShuffleRunDuration = (shuffleProgressDuration > maxMapRuntime) ? shuffleProgressDuration
                : maxMapRuntime;

        boolean reducerStalled = (((float) stallDuration / minShuffleRunDuration) >= MAX_ALLOWED_STALL_TIME_PERCENT);

        // kill if not healthy and has insufficient progress
//        if ((failureCounts.size() >= maxFailedUniqueFetches || failureCounts
//                .size() == (totalMaps - doneMaps))
//                && !reducerHealthy
//                && (!reducerProgressedEnough || reducerStalled)) {
        
//      if (failureCounts.size() >= maxFailedUniqueFetches) {
//            LOG.severe("Shuffle failed with too many fetch failures and insufficient progress! size=" + failureCounts.size());
//            String errorMsg = "Exceeded MAX_FAILED_UNIQUE_FETCHES; bailing-out.";
//            reporter.reportException(new IOException(errorMsg));
//        }

    }
        
    public synchronized void tipLost(String hostName, TaskID taskId) {
        LOG.warning("Task " + taskId + " lost on " + hostName + ", status=" + mapStatus[taskId.getPartIdx()]);        
        if (mapStatus[taskId.getPartIdx()] == MAP_READY) 
            mapStatus[taskId.getPartIdx()] = MAP_UNKNOW;
        
        MapHost host = mapLocations.get(hostName);
        if (host != null) {            
            host.lostMap(taskId);
            if (host.getNumKnownMapOutputs() == 0) {
                mapLocations.remove(hostName);
                if (pendingHosts.contains(host)) {
                    pendingHosts.remove(host);
                }
            }
        }
    }

    public synchronized void addKnownMapOutput(String hostName, String hostUrl,
            TaskID mapId) {
        if (mapStatus[mapId.getPartIdx()] == MAP_COPIED) {
            LOG.info("BUG: Map " + mapId.getPartIdx() + " copied, but added again.");
            return;
        }
        MapHost host = mapLocations.get(hostName);
        if (host == null) {
            host = new MapHost(hostName, hostUrl);
            mapLocations.put(hostName, host);
        }
        mapStatus[mapId.getPartIdx()] = MAP_READY;
        host.addKnownMap(mapId);

        // Mark the host as pending
        if (host.getState() == MapHost.State.PENDING) {
            pendingHosts.add(host);
            notifyAll();
        }
    }

    public synchronized void putBackKnownMapOutput(MapHost host, TaskID mapId) {
        mapStatus[mapId.getPartIdx()] = MAP_READY;
        host.addKnownMap(mapId);
    }

    public synchronized MapHost getHost() throws InterruptedException {
        while (pendingHosts.isEmpty()) {
            wait();
        }

        MapHost host = null;
        Iterator<MapHost> iter = pendingHosts.iterator();
        int numToPick = random.nextInt(pendingHosts.size());
        for (int i = 0; i <= numToPick; ++i) {
            host = iter.next();
        }

        pendingHosts.remove(host);
        host.markBusy();

        LOG.info("Assiging " + host + " with " + host.getNumKnownMapOutputs()
                + " to " + Thread.currentThread().getName());
        shuffleStart.set(System.currentTimeMillis());

        return host;
    }

    public synchronized List<TaskID> getMapsForHost(MapHost host) {
        List<TaskID> list = host.getAndClearKnownMaps();
        Iterator<TaskID> itr = list.iterator();
        List<TaskID> result = new ArrayList<TaskID>();
        int includedMaps = 0;
        int totalSize = list.size();
        // find the maps that we still need, up to the limit
        while (itr.hasNext()) {
            TaskID id = itr.next();
            if (mapStatus[id.getPartIdx()] != MAP_COPIED) {
                mapStatus[id.getPartIdx()] = MAP_FETCHING;
                result.add(id);
                if (++includedMaps >= MAX_MAPS_AT_ONCE) {
                    break;
                }
            } 
        }
        // put back the maps left after the limit
        while (itr.hasNext()) {
            TaskID id = itr.next();
            if (mapStatus[id.getPartIdx()] != MAP_COPIED) {
                host.addKnownMap(id);
            }
        }
        LOG.info("assigned " + includedMaps + " of " + totalSize + " to "
                + host + " to " + Thread.currentThread().getName());
        return result;
    }

    public synchronized void freeHost(MapHost host) {
        MapHost.State preState = host.getState();
        if (host.getState() != MapHost.State.PENALIZED) {
            if (host.markAvailable() == MapHost.State.PENDING) {
                pendingHosts.add(host);
                notifyAll();
            }
        }
        LOG.info(host + " freed by " + Thread.currentThread().getName()
                + " in " + (System.currentTimeMillis() - shuffleStart.get())
                + "ms, preState=" + preState.toString());
    }

    public synchronized void resetKnownMaps() {
        mapLocations.clear();
        pendingHosts.clear();
        Arrays.fill(mapStatus, MAP_UNKNOW);
    }

    /**
     * Wait until the shuffle finishes or until the timeout.
     * 
     * @param millis
     *            maximum wait time
     * @return true if the shuffle is done
     * @throws InterruptedException
     */
    public synchronized boolean waitUntilDone(int millis)
            throws InterruptedException {
        if (remainingMaps > 0) {
            Iterator<MapHost> it = pendingHosts.iterator();
            if (it.hasNext()) {
                MapHost host = it.next();
                LOG.info("Debug: map remaining=" + remainingMaps + ", peek map id: " + peekRemainingMap());                
            }
            wait(millis);
            return remainingMaps == 0;
        }
        return true;
    }
    
    private int peekRemainingMap() {
        for (int i = 0; i < mapStatus.length; ++i) {
            if (mapStatus[i] != MAP_COPIED) return i;
        }
        return -1;
    }
    
    /**
     * A structure that records the penalty for a host.
     */
    private static class Penalty implements Delayed {
        MapHost host;

        private long endTime;

        Penalty(MapHost host, long delay) {
            this.host = host;
            this.endTime = System.currentTimeMillis() + delay;
        }

        public long getDelay(TimeUnit unit) {
            long remainingTime = endTime - System.currentTimeMillis();
            return unit.convert(remainingTime, TimeUnit.MILLISECONDS);
        }
        
        public int compareTo(Delayed o) {
            long other = ((Penalty) o).endTime;
            return endTime == other ? 0 : (endTime < other ? -1 : 1);
        }

    }

    /**
     * A thread that takes hosts off of the penalty list when the timer expires.
     */
    private class Referee extends Thread {
        public Referee() {
            setName("ShufflePenaltyReferee");
            setDaemon(true);
        }

        public void run() {
            try {
                while (true) {
                    // take the first host that has an expired penalty
                    MapHost host = penalties.take().host;
                    synchronized (ShuffleScheduler.this) {
                        if (host.markAvailable() == MapHost.State.PENDING) {
                            pendingHosts.add(host);
                            ShuffleScheduler.this.notifyAll();
                        }
                    }
                }
            } catch (InterruptedException ie) {
                return;
            } catch (Throwable t) {
                reporter.reportException(t);
            }
        }
    }

    public void close() throws InterruptedException {
        referee.interrupt();
        referee.join();
    }

    public synchronized void informMaxMapRunTime(int duration) {
        if (duration > maxMapRuntime) {
            maxMapRuntime = duration;
        }
    }
}
