/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.cowork;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.rpc2.RpcException;
import odis.serialize.IWritable;

/**
 * The RPC interface for a client to submit job.  Use {@link JobClient} to 
 * submit a job to job master.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public interface IJobSubmissionProtocol {
  
  /////////////////////////////////////////////////////////////////////////////
  // RPC Communication: JobClient->JobMaster 
  /////////////////////////////////////////////////////////////////////////////
    /**
     * Returns the update-interal in milli-seconds of the job-master.
     * @param version  the client's version 
     * @throws RpcException  if an error occurs
     */
    public long getUpdateInterval(int version) throws RpcException;
    /**
     * Submits a job to the job-master.
     * @param job  the job-configuration
     * @return  the status as a JobStatus instance
     * @throws RpcException  if an error occurs
     */
    public JobStatus submitJob(JobConfig job) throws RpcException;
    /**
     * Aborts a job from running.
     * @param jobId  the ID of the job to be aborted
     * @throws RpcException  if an error occurs
     */
    public void abortJob(String jobId) throws RpcException;
    /**
     * Removes a job from the job-master.
     * @param jobId  the ID of the job
     * @return  true if success, false otherwise
     * @throws RpcException  if an error occurs
     */
    public boolean removeJob(String jobId) throws RpcException;
    /**
     * Returns the status of a job.
     * @param jobId  the ID of the job
     * @return  the status of the job as a JobStatus instance
     * @throws RpcException
     */
    public JobStatus getJobStatus(String jobId) throws RpcException;
    /**
     * Returns the message of a job
     * @param jobId  the ID of the job
     * @return  the message string
     * @throws RpcException  if an error occurs
     */
    public String getJobMsg(String jobId) throws RpcException;
    /**
     * Returns the tasks' messages (by collector.collectDoneMsg())
     * @param jobId  the ID of the job
     * @return  the messages in a 2-D string array. The first dimention is task
     *          and the second is the index of the task
     * @throws RpcException  if an error occurs
     */
    public String[][] getTaskMsgs(String jobId) throws RpcException;
    /**
     * Returns the counter-maps of a job
     * @param jobId  the ID of the job
     * @return  the counter-map array. The element index is task
     * @throws RpcException  if an error occurs
     */
    public CounterMap[] getJobCounters(String jobId) throws RpcException;    
    
    /**
     * set priority of a job of prefix
     * @param jobPrefix 
     * @param value  1 ~ 5, <= 0 means clean this setting
     * @throws RpcException
     */
    public void setPriorityValue(String jobPrefix, int value) throws RpcException;    
    
    /**
     * 
     * @param flag true is debug level
     * @throws RpcException
     */
    public void setDebug(boolean flag) throws RpcException;
    
    
    public void addBlacklisted(String tmId) throws RpcException;
    
    public void removeBlacklisted(String tmId) throws RpcException;    
    
    /**
     * 
     * @return CUID of the cluster
     * @throws RpcException
     */
    public String getCUID() throws RpcException;
    
  /////////////////////////////////////////////////////////////////////////////
  // Job Status
  /////////////////////////////////////////////////////////////////////////////
  public final static int JOB_STATE_IDLE = 0;
  public final static int JOB_STATE_RUNNING = 1;
  public final static int JOB_STATE_ABORTING = 2;
  public final static int JOB_STATE_CLOSING = 3;
  /**
   * The status of the job.
   * @author david
   *
   */
  public static class JobStatus implements IWritable {
    protected String jobId;
    volatile protected int state;
    volatile protected int stage;
    volatile protected int failed;  // total number of failures
    volatile protected int ignored; // failure in the last stage that are ignored
    protected float[] progress;
    
    public JobStatus() { }
    public JobStatus(String id, int stageNum) {
      this.jobId = id;
      this.state = JOB_STATE_IDLE; 
      this.stage = -1;
      this.failed = 0; this.ignored = 0;
      this.progress = new float[stageNum];
      Arrays.fill(progress, 0f);
    }
    
    public boolean isIdle() { return state==JOB_STATE_IDLE; }
    public boolean isRunning() { return state==JOB_STATE_RUNNING; }
    public boolean isFinished() {
      return state==JOB_STATE_ABORTING || state==JOB_STATE_CLOSING;
    }    
    public String getStateString() {
      switch (state) {
        case JOB_STATE_IDLE: return "IDLE";
        case JOB_STATE_RUNNING: return "RUN";
        case JOB_STATE_ABORTING: return "ABORT";
        case JOB_STATE_CLOSING: return "CLOSE";
        default: return "UNKNOWN";
      }
    }
    public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append(jobId + ":" + getStateString() + "(stage="+stage+")");
      return sb.toString();
    }
    
    public String getJobId() { return jobId; }
    
    public int getState() { return state; }
    public void setRun() { state = JOB_STATE_RUNNING; stage=0; }
    public void setAbort() { state = JOB_STATE_ABORTING; }
    public void setClose() { state = JOB_STATE_CLOSING; }
    
    public int getStage() { return stage; }
    public boolean isEnd(int s) { return s>=progress.length; }
    public boolean isInLastStage() { return (progress.length - stage) == 1; }
    public void incStage() { stage++; }
    
    public void fail() { failed++; }
    public int getFailTimes() { return failed; }
    
    public void ignore() { ignored++; }
    public int getIgnoreTimes() { return ignored; }
    
    public float[] getProgress() { return progress; }
    public float getProgress(int s) { return progress[s]; }
    public void setProgress(int s, float f) { progress[s] = f; }

    public void writeFields(DataOutput out) throws IOException {
      out.writeUTF(jobId);
      out.writeInt(state);
      out.writeInt(stage);
      out.writeInt(failed);
      out.writeInt(ignored);
      out.writeInt(progress.length);
      for (int i=0; i<progress.length; i++)
        out.writeFloat(progress[i]);
    }

    public void readFields(DataInput in) throws IOException {
      jobId = in.readUTF();
      state = in.readInt();
      stage = in.readInt();
      failed = in.readInt();
      ignored = in.readInt();
      int c = in.readInt();
      progress = new float[c];
      for (int i=0; i<c; i++)
        progress[i] = in.readFloat();
    }
    
    public IWritable copyFields(IWritable value) {
      JobStatus that = (JobStatus) value;
      this.jobId = that.jobId;
      this.state = that.state;
      this.stage = that.stage;
      this.failed = that.failed;
      this.ignored = that.ignored;
      this.progress = new float[that.progress.length];
      System.arraycopy(that.progress, 0, this.progress, 0, this.progress.length);
      return this;
    }
  }

}
