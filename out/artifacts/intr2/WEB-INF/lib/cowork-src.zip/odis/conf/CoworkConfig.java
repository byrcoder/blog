/**
 * @(#)CoworkConfig.java, 2012-12-18. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.conf;

import java.io.File;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import toolbox.misc.LogFormatter;

/**
 * config file for cowork 
 *
 * @author chenheng
 * 
 */
public class CoworkConfig {

    protected static final Logger LOG = LogFormatter.getLogger(CoworkConfig.class);
    private static File home;
    private static Configuration conf;
    private static final HashMap<String, Integer> tmInstanceMap = new HashMap<String, Integer>();
    private static CoworkConfig instance = new CoworkConfig();
    
    public static CoworkConfig get() {
        return instance;
    }

    public static Configuration conf() {
        return conf;
    }
    
    static {
        String home = System.getProperty("odis.home");
        if (home == null) {
            home = System.getenv("ODIS_HOME");
        }
        if (home == null) {
            home = ".";
        }
        CoworkConfig.home = new File(home);
        System.setProperty("odis.home", CoworkConfig.home.getAbsolutePath());

        
        File confDir = new File(home, "conf");
        try {
            conf = ConfigUtils.parseXmlConfig(confDir, new String[] {
                "service.xml"
            });
        } catch (ConfigurationException e) {
            LOG.log(Level.SEVERE, "parse odfs configuration failed", e);
            throw new RuntimeException("parse odfs configuration failed", e);
        }

        String local = System.getProperty("odis.local");
        if (local == null) {
            local = System.getenv("ODIS_LOCAL");
        }
        if (local == null) {
            local = ".";
        }
        conf.setProperty("odis.local", local);
        conf.setProperty("user.name", System.getProperty("user.name"));
        
        // load cowork instance map
        String[] tmInstances = conf.getStringArray("cowork.taskmaster.instance.name");
        for (int i = 0; i < tmInstances.length; i++) {
            tmInstanceMap.put(tmInstances[i], i);
            LOG.fine("Loading taskmaster instance " + i + " of \""
                    + tmInstances[i] + "\"");
        }
    }

    
    public static File getHomeDir() {
        return home;
    }

    public static File getConfigDir() {
        return new File(home, "conf");
    }

    public static File getLibraryDir() {
        return new File(home, "lib");
    }

    public static File getWebDir() {
        return new File(home, "web");
    }
    

    public String getOdisServiceLocal() {
        return conf.getString("odis.local");
    }

    public File getOdisTmpDir() {
        return new File(getOdisServiceLocal(), "tmp");
    }

    public File getOdisLogRootDir() {
        return new File(getOdisServiceLocal(), "log");
    }

    public File getCoworkLogDir() {
        return new File(getOdisLogRootDir(), "cowork");
    }

    public File getOdfsLogDir() {
        return new File(getOdisLogRootDir(), "odfs");
    }

    public Properties getServiceLogLevel() {
        return conf.getProperties("log.debug-level");
    }
    
    public int getJobMasterPort() {
        return conf.getInt("cowork.jobmaster.port", 4848);
    }
    
    public String[] getTaskMasterTmpDir(String tmName) {
        String defaultTmp = getOdisServiceLocal();
        if ("local".equals(tmName))
            return new String[] {
                new File(defaultTmp, "cowork").getPath()
            };
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        assert idx != null;
        String[] tmps = conf.getStringArray("cowork.taskmaster.instance("
                + idx + ")" + ".local-dir.tmp");
        if (tmps == null || tmps.length == 0) {
            return new String[] {
                new File(defaultTmp, "cowork").getPath()
            };
        } else
            return tmps;
    }

    public int getTaskMasterTaskLimit(String tmName) {
        if ("local".equals(tmName))
            throw new IllegalArgumentException(
                    "No task limit for \"local\" case");
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null)
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        return conf.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".task-limit", 2);
    }

    public int getTaskMasterFileLimit(String tmName) {
        if ("local".equals(tmName))
            throw new IllegalArgumentException(
                    "No file limit for \"local\" case");
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null)
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        return conf.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".file-limit", 16);
    }

    public int getTaskHeapLimit(String tmName) {
        if ("local".equals(tmName)) {
            throw new IllegalArgumentException(
                    "No heap limit for \"local\" case");
        }
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null) {
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        }
        return conf.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".heap-limit", 800);
    }
    
    public int getTaskMasterMemory(String tmName) {
        if ("local".equals(tmName)) {
            throw new IllegalArgumentException(
                    "No heap limit for \"local\" case");
        }
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null) {
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        }
        return conf.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".memory", 8000); //MB
    }

    ///////////////////////////////////////////////////////////////////////////
    // Deprecated set methods for test case only
    ///////////////////////////////////////////////////////////////////////////

    /**
     * @deprecated for test-case only
     */
    @Deprecated
    public void setInt(String name, int value) {
        conf.setProperty(name, value + "");
    }

    /**
     * @deprecated for test-case only
     */
    @Deprecated
    public void setLong(String name, long value) {
        conf.setProperty(name, value + "");
    }

    /**
     * @deprecated for test-case only
     */
    @Deprecated
    public void setString(String name, String value) {
        conf.setProperty(name, value);
    }
    
    /**
     * Returns the InetSocketAddress from and address string
     */
    public static InetSocketAddress getAddress(String addStr) {
        if ("local".equals(addStr)) {
            return null;
        }
        if (addStr == null) {
            throw new NullPointerException("Null net address");
        }
        String[] jmStr = addStr.split(":");
        if (jmStr.length != 2) {
            throw new RuntimeException("Invalid net address: " + addStr);
        }
        return new InetSocketAddress(jmStr[0], Integer.parseInt(jmStr[1]));
    }

    public int getRMPort() {
        return conf.getInt("cowork.resManager.port", 1986);
    }

    public int getRMWebPort() {
        return conf.getInt("cowork.resManager.web-port", 1987);
    }

    public static InetSocketAddress getResManagerAddress() {
        return getAddress(conf.getString("cowork.resManager.address", ""));
    }

    public String getRMHost() {
        // TODO Auto-generated method stub
        return "";
    }
}
