package odis.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

import odis.util.DF;

import toolbox.misc.LogFormatter;

/**
 * 
 * @author tuqc
 *
 */
public class LocalDirAllocator {
    public static final int SIZE_UNKNOWN = -1;
    protected static final Logger LOG = LogFormatter.getLogger(LocalDirAllocator.class);

    File[] localDirs;
    Random rand = new Random();
    public LocalDirAllocator(File[] dirs) {
        assert dirs.length > 0;
        this.localDirs = dirs;
    }
    
    public LocalDirAllocator(File dir) {
        this(new File[]{dir});
    }
    
    public File getTmpDirForWriter() throws IOException {
        File tmpDir = new File(this.localDirs[0], "tmp");
        tmpDir.mkdirs();
        return tmpDir;
    }
    
    public File getLocalFileForWrite(String partPath) throws IOException {
        return getLocalFileForWrite(partPath, SIZE_UNKNOWN);
    }

    public File getLocalFileForWrite(String partPath, long size) throws IOException {
        File file;
        if (!localDirs[0].exists()) localDirs[0].mkdirs();
        if (localDirs[0].getUsableSpace() > size) {
            file = new File(localDirs[0], partPath);
        }else {
            LOG.warning(localDirs[0].getAbsolutePath() + " space=" + localDirs[0].getUsableSpace() + ", need size=" + size);
            File dir = localDirs[rand.nextInt(localDirs.length)];
            if (!dir.exists()) dir.mkdirs();
            if (dir.getUsableSpace() < size) {
                boolean find = false;
                for (File d : localDirs) {
                    if (!d.exists()) d.mkdirs();
                    if (d.getUsableSpace() > size) {
                        dir = d;
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    for (File d : localDirs) {
                        DF df = new DF(d.getCanonicalPath());
                        LOG.warning(d.getAbsolutePath() + " -> " + df.toString());
                    }
                    throw new IOException("Can't allocate file for size " + size);
                }
            }
            file = new File(dir, partPath);            
        }
//        file.mkdirs();
        return file;
    }    
    
    /**
     * 删除所有构造函数中传入的dir
     * @throws IOException
     */
    public void cleanAllDirs() throws IOException {
        for (File f : localDirs) {
            if (f.exists()) f.delete();
        }
    }
}
