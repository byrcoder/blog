package odis.mapred.lib;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import odis.file.IndexedFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;

public class IndexedFileInputFormat extends SeqFileInputFormat {

  @Override
  public String[] listParts(String svcAddr, String path) throws IOException {
    FileSystem fs = FileSystem.getNamed(svcAddr);
    FileInfo[] files = fs.listFiles(new Path(path));
    if (files == null) {
      throw new IOException("cannot find path " + svcAddr + ":" + path);
    }
    String[] parts = new String[files.length];
    for (int i=0; i<files.length; i++) {
        Path f = new Path(IndexedFile.getDataFile(files[i].getPath().asFile()));
      if (!fs.isFile(f))
        throw new IOException("The part " + f + " is not a file.");
      parts[i] = files[i].getPath().getName() + File.separator 
                      + IndexedFile.DATA_FILE_NAME;
    }
    Arrays.sort(parts); // should list in a consistant same order
    return parts;
  }

}
