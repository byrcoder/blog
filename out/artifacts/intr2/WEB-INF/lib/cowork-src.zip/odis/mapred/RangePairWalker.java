package odis.mapred;

import java.util.Comparator;
import java.util.logging.Logger;

import odis.file.IRecordReader;
import odis.serialize.IWritableComparable;

import org.apache.commons.configuration.Configuration;

import toolbox.misc.LogFormatter;

/**
 * [startKey, startValue)    
 * @author tuqc
 *
 */
public class RangePairWalker implements IWritablePairWalker{
    private static final Logger LOG = LogFormatter.getLogger(RangePairWalker.class);
    IWritableComparable startKey;
    IWritableComparable endKey;
    IWritablePairWalker walker;
    volatile boolean inRange = false;
    /**
     *  [startKey, startValue)    
     * @param startKey
     * @param endKey
     * @param walker
     */
    public RangePairWalker(IWritableComparable startKey, IWritableComparable endKey, IWritablePairWalker walker) {
        this.startKey = startKey;
        this.endKey = endKey;
        this.walker = walker;        
    }
    
    @Override
    public boolean moreValue() {
        return walker.moreValue();
    }

    @Override
    public Object getValue() {
        return walker.getValue();
    }

    @Override
    public void configure(IRecordReader in, Comparator cmp, Configuration conf) {
        walker.configure(in, cmp, conf);
    }

    @Override
    public boolean moreKey() {
        boolean flag = walker.moreKey();
        if (!flag) return flag;
        
        if (!inRange) {
            inRange = true;
            int count = 0;
            if (startKey != null) {
                while(flag) {
                    IWritableComparable k = (IWritableComparable)walker.getKey();
                    if (k.compareTo(startKey) < 0) {
                        ++count;
                    }else {
                        LOG.info("Debug: range begin skipCount=" + count + " for startKey=" + startKey + ", endKey=" + endKey + " ,curKey=" + k + ", tid=" + Thread.currentThread().getId());
                        break;
                    }
                    flag = walker.moreKey();
                }
                if (!flag) return false;
            }else {
                LOG.info("Debug: range begin skipCount=null");
            }
        }

        if (endKey != null) {
            IWritableComparable k = (IWritableComparable)walker.getKey();
            if (k.compareTo(endKey) >= 0) {
                return false;
            }                
        }
        //true
        return flag;        
    }

    @Override
    public Object getKey() {
        return walker.getKey();
    }

    
    
}
