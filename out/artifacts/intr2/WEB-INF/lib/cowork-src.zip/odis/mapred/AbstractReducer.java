package odis.mapred;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;

public abstract class AbstractReducer<K, V> implements IReducer<K, V> {

  public void configure(JobDef job, TaskRunnable task) { }

  public void reduceBegin() { }

  public void reduceEnd(ICollector collector) { }

}
