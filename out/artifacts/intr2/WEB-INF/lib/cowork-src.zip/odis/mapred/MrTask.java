package odis.mapred;

import java.io.IOException;
import java.util.logging.Level;

import odis.cowork.JobDef;
import odis.cowork.TaskWorker;
import odis.file.IRecordReader;
import toolbox.misc.ClassUtils;

public class MrTask extends MrTaskRunnable {
  
  public static final float REDUCE_PROCESS_START = ReduceTask.PROCESS_START;
  
  IReducer reducer;
  IMapper mapper;
  float rProgress, mProgress, rPortion, mPortion;

  @Override
  protected void reducePreProcess() { reducer.reduceBegin(); }

  @SuppressWarnings("unchecked")
  @Override
  protected void reduceProcess(IRecordReader in) throws IOException { 
      // combiner
    int inputMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_INPUT,stage);
    ICollector collector = this;
    // process
    float pTotalSize = in.getSize()/rPortion, 
          pStart = REDUCE_PROCESS_START*rPortion;
    long lastPos = in.getPos();
    walker.configure(in, keyCmp, mrJob.getConfig());
    while (walker.moreKey()) {
      if (toEnd) break;
      if (!isSkip()) {
        reducer.reduce(walker.getKey(), walker, collector);
        if (outputError != null) {
          throw new RuntimeException("Error occur on asynchronous output", outputError);
        }
      }
      else
        LOG.warning("Skip bad record at " + cursor() + ": key=" + walker.getKey());
      // set counters
      getCounter(CT_REDUCE_IN_RECORD).inc();
      getCounter(CT_REDUCE_IN_SIZE).inc(in.getPos()-lastPos);
      lastPos = in.getPos();
      // report process
      long processed = getCounter(CT_REDUCE_IN_SIZE).get();
      rProgress = Math.min(pStart + (1-REDUCE_PROCESS_START)*processed/pTotalSize,rPortion);
      progress = rProgress+mProgress;
      cursor.write(cursor(), time());
    }      
  }

  @Override
  protected void reducePostProcess() {
    rProgress = rPortion;
    reducer.reduceEnd(this);
    progress = rProgress+mProgress;
  } 

  @Override
  protected void mapPreProcess(ITaskInputSplit[] splits) {
    mapper.mapBegin();
  }

  @SuppressWarnings("unchecked")
  @Override
  protected void mapProcess(IRecordReader in) throws IOException {
    // combiner
    int inputMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_INPUT,stage);
    ICollector collector = this;
    // allocate new key & value instances
    Class keyClass = in.getKeyClass(), valClass = in.getValueClass();
    Object key   = ClassUtils.newInstance(keyClass);
    Object value = ClassUtils.newInstance(valClass);
    // process
    float fTotalSplitSize = mInputSize/mPortion;
    long lastPos = in.getPos(), curPos = lastPos;
    while (true) {
      if (toEnd) break;
      if (!isSkip()) {  // not skipping record
        // read next key & value
        if (!in.next(key, value)) break;
        curPos = in.getPos();
        // map pair to output
        mapper.map(key, value, collector);
        if (outputError != null) {
          throw new RuntimeException("Error occur on aynchronous output", outputError);
        }
      } else {          // skipping record
        try {
          if (!in.next(key, value)) break;
          curPos = in.getPos();
          LOG.warning("Skip bad record at cursor " + cursor() + ": key=" 
                  + key + ",value=" + value);
        } catch (Throwable t) {
          LOG.log(Level.WARNING, "Skip bad record at " + cursor(), t);
        }
      }
      // set counters
      getCounter(CT_MAPPED_IN_RECORD).inc();
      getCounter(CT_MAPPED_IN_SIZE).inc(curPos-lastPos);
      lastPos = curPos;
      // report process
      long processed = getCounter(CT_MAPPED_IN_SIZE).get();
      mProgress = Math.min((float)(processed)/ fTotalSplitSize, mPortion);
      progress = rProgress+mProgress;
      cursor.write(cursor(), time());
    }
  }

  @Override
  protected void mapPostProcess() {
    mProgress = mPortion;
    mapper.mapEnd(this); 
    progress=mProgress+rProgress;
  }

  @Override
  public void configure(JobDef job, TaskWorker worker) {
    super.configure(job,worker);
    
    int reducerMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_OUTPUT,stage);
    reducer = this.mrJob.getReducer(reducerMrPhase);
    reducer.configure(job, this);
    
    int mapperMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_INPUT,stage);
    mapper = this.mrJob.getMapper(mapperMrPhase);
    if (mapper!=null) {
      assert this.mrJob.getInputChannelNum(mapperMrPhase)!=0;
      mapper.configure(job, this);
      mPortion = 0.5f;
    } else {
      assert this.mrJob.getInputChannelNum(mapperMrPhase)==0;
      mPortion = 0f;
    }
    mProgress = 0f; rProgress = 0f; rPortion = 1f-mPortion;
  }

}
