package odis.mapred;

/**
 * The walker class for getting values:
 * NOTE: You can get the first value after the first call to moreValue() and
 *       moreValue() returns true.
 * Usage:
 *   while (walker.moreValue()) {
 *       V val = walker.getValue();
 *       // use the value
 *   } // while
 * @author david
 *
 * @param <V>  the type of the value
 */
public interface IValueWalker<V> {
    /**
     * Move cursor to next value in this key
     * @return whether cursor is successfully moved to a new value.
     */
    public boolean moreValue();
    /**
     * Get value at current cursor
     */
    public V getValue();  
}
