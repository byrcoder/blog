package odis.mapred.lib;

import odis.cowork.TaskFatalException;

/**
 * The walker that reuses all key-value objects.
 * 
 * @author david
 *
 * @param <K>  the type of the key
 * @param <V>  the value of the key
 */
public class ReuseWalker<K, V> extends PairWalkerBase<K, V> {
  private K savedKey;
  private V savedValue;
  
  @SuppressWarnings("unchecked")
  @Override
  protected void allocNextKey() {
    try {
      if (savedKey == null)
        nextKey = (K) in.getKeyClass().newInstance();
      else {
        nextKey = savedKey;  savedKey = null;
      } // else
    } catch (Exception e) {
      throw new TaskFatalException("Cannot allocate key for ReusePairWalker",e);
    }
  }

  @SuppressWarnings("unchecked")
  @Override
  protected void allocNextValue() {
    try {
      if (savedValue == null)
        nextValue = (V) in.getValueClass().newInstance();
      else {
        nextValue = savedValue;  savedValue = null; 
      }
    } catch (Exception e) {
      throw new TaskFatalException("Cannot allocate value for ReusePairWalker",
              e);
    }      
  }
  
  protected void freeCurrentKey() {
      if (key != null)
          savedKey = key;
  };
  protected void freeCurrentValue() {
      if (value != null)
          savedValue = value;
  };
}
