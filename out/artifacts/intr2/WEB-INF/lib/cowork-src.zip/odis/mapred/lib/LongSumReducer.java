package odis.mapred.lib;

import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.serialize.lib.LongWritable;

public class LongSumReducer<K> extends AbstractReducer<K,LongWritable> {

  public void reduce(K key, IWritablePairWalker<K,LongWritable> values,
      ICollector collector) {
    // sum all values for this key
    long sum = 0;
    while (values.moreValue())
      sum += values.getValue().get();
    // output sum
    collector.collect(key, new LongWritable(sum));
  }

}
