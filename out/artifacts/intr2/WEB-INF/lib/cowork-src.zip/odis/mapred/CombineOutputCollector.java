package odis.mapred;

import java.io.IOException;
import odis.cowork.CounterMap;
import odis.cowork.TaskFatalException;
import odis.serialize.IWritable;

public class CombineOutputCollector<K extends IWritable, V extends IWritable> implements ICollector{

    private CounterMap.Counter outCounter;
    private IFile.Writer<K,V> writer;
    public CombineOutputCollector(CounterMap.Counter outCounter) {
        this.outCounter = outCounter;
    }
    
    public void setWriter(IFile.Writer<K, V> writer) {
        this.writer = writer;
    }
    
    @Override
    public void collect(Object key, Object value) {
        try {
            writer.append(key, value);
            if (outCounter != null) outCounter.inc();
        }catch(IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void collectDoneMsg(String msg) {
        throw new TaskFatalException("Method not implemented for " 
                + this.getClass().getName());
    }

    @Override
    public void collectToPartition(int part, Object key, Object value) {
        throw new TaskFatalException("Method not implemented for " 
                + this.getClass().getName());
    }

    @Override
    public void collectToChannel(int channel, Object key, Object value) {
        throw new TaskFatalException("Method not implemented for " 
                + this.getClass().getName());
    }

}
