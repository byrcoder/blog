/**
 * 
 */
package odis.mapred.lib;

import java.util.ArrayList;

import odis.mapred.IWritableWalker;
import odis.serialize.IWritable;
import toolbox.misc.ClassUtils;

/**
 * Reuse objects in next map.
 * 
 * @author david
 *
 */
public class PerMapWritableWalker implements IWritableWalker {
    /**
     * 
     * @return return the maximum number of objects in the pool. -1 means not limit.
     */
    protected int getMaxPoolLen() {
        return 10000;
    }
    public IWritable alloc() {
        int maxPoolLen = getMaxPoolLen();
        if (maxPoolLen > 0 && poolPos >= maxPoolLen)
            // pool is full
            return (IWritable) ClassUtils.newInstance(objClass);
        if (poolPos == pool.size())
            // enlarge pool
            pool.add((IWritable) ClassUtils.newInstance(objClass));
        return pool.get(poolPos ++);
    }

    public void reset() {
        poolPos = 0;
    }

    public void clear() {
        poolPos = 0;
        pool.clear();
    }

    protected int poolPos;
    protected ArrayList<IWritable> pool = new ArrayList<IWritable>();
    protected Class objClass;
    public void configure(Class objClass) {
        this.objClass = objClass;
        clear();
    }
}
