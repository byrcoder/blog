package odis.mapred.lib;

import java.io.File;
import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.file.TextRecordFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.ITaskInputSplit;

/**
 * Input format for reading text files. Each line is a record. Both the key and 
 * value are {@link StringBuilder}. And a separator (set with 
 * {@link #setSeparator(BasicInOutJobDef, File, String)} and default to the 
 * space character) separates the key and the value for each line. 
 * 
 * @author zl
 */
public class TextInputFormat extends GenericFileInputFormat {
    private static final String PROP_SEPARATOR = 
        "mapred.text-inputformat.separator";
    private static final String PROP_ENCODING = 
        "mapred.text-inputformat.encoding";

    /**
     * Sets the separator used for breaking up the key and value, for a specific 
     * input dir. For each line the separator is searched in the line. The part 
     * before becomes the key and the part after becomes the value (both 
     * non-inclusive). If the separator is not found. The whole lines becomes 
     * the key and the value is <code>"\n"<code> (the line break), which is an 
     * indicator that the value does not exist.
     * 
     * <p>If no separator is set, the default is the space character.
     * 
     * @param dir input dir (added via 
     * {@link BasicInOutJobDef#addInputDir(File)}) where this separator applies.
     */
    public static void setSeparator(BasicInOutJobDef jobDef, Path dir,
            String separator) {
        String url = BasicInOutJobDef.getServiceUrl(jobDef.getDefaultFsName(),
                dir.toString());
        jobDef.getConfig().setProperty(PROP_SEPARATOR+"."+url, separator);
    }
    /**
     * @deprecated use the one using Path instead of File
     */
    @Deprecated
    public static void setSeparator(BasicInOutJobDef jobDef, File dir, 
            String separator) {
        setSeparator(jobDef, new Path(dir), separator);
    }
    
    /**
     * Sets the encoding for reading files for a particular input dir. By 
     * default, the system locale encoding is used.
     * @param dir  input dir (added via {@link 
     *             BasicInOutJobDef#addInputDir(File)}) where this encoding 
     *             applies.
     */
    public static void setEncoding(BasicInOutJobDef jobDef, Path dir, 
            String encoding) {
        String url = BasicInOutJobDef.getServiceUrl(jobDef.getDefaultFsName(),
                dir.toString());
        jobDef.getConfig().setProperty(PROP_ENCODING+"."+url, encoding);
    }
    /**
     * @deprecated use the one using Path instead of File
     */
    @Deprecated
    public static void setEncoding(BasicInOutJobDef jobDef, File dir, 
            String encoding) {
        String url = BasicInOutJobDef.getServiceUrl(jobDef.getDefaultFsName(),
                dir.toString());
        jobDef.getConfig().setProperty(PROP_ENCODING+"."+url, encoding);
    }

    @Override
    public IRecordReader getRecordReader(ITaskInputSplit split,
            TaskRunnable task, BasicInOutJobDef jobConf) throws IOException {
        assert split instanceof InputFileSplit;    
        InputFileSplit fSplit = (InputFileSplit) split;

        // open the file and seek to the start of the split
        String separator = jobConf.getConfig().getString(
                PROP_SEPARATOR + "." + fSplit.getSource(), " ");
        String encoding = jobConf.getConfig().getString(
                PROP_ENCODING + "." + fSplit.getSource(), null);
        TextRecordFile.Reader in = new TextRecordFile.Reader(
            FileSystem.getNamed(fSplit.getFsName()),
            new Path(fSplit.getFile()), separator,
            fSplit.getStart(), fSplit.getLength(), encoding);
        return in;
    }

}
