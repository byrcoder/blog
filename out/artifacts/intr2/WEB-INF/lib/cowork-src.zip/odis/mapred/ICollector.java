/*
 * Copyright (c) 2006, Outfox Team
 */

package odis.mapred;

/**
 * The collector interface used to collect (key,value) in output channels
 *
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 * Created on Mar 15, 2006
 */

public interface ICollector {
    /**
     * The default collect method for this collector. For example:
     *   - MapTask: will be "collectToPartition";
     *   - MapOnlyTask: will be collect all output channels
     *   - ReduceTask: will be collect all output channels
     * @param key      the key to be written
     * @param value    the value to be written
     */
    public void collect(Object key, Object value);
    /**
     * Collects a task done message. These messages can be achieved in the
     * JobResult by calling JobResult.getMsg().
     *   
     * @param msg      the task done message
     */
    public void collectDoneMsg(String msg);
    /**
     * Collects <key, value> to a certain partition for next stage. E.g. in
     * a map stage, the <key, value> will be collected to a specified partition
     * for the reduce stage.
     * The <key, value> instances can be reused after return.
     * 
     * @param part     the partition number
     * @param key      the key to be written
     * @param value    the value to be written
     */
    public void collectToPartition(int part, Object key, Object value);
    /**
     * Collects <key, value> to output channel. After collecting, the key/value
     * can be reused again.
     *  
     * @param channel  the output channel number. must >=0
     * @param key      the key to be written
     * @param value    the value to be written
     */
    public void collectToChannel(int channel, Object key, Object value);
}
