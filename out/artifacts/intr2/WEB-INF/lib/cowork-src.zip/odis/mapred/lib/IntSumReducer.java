package odis.mapred.lib;

import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.serialize.lib.IntWritable;

public class IntSumReducer<K> extends AbstractReducer<K,IntWritable> {

    IntWritable sValue = new IntWritable();
    
    public void reduce(K key, IWritablePairWalker<K, IntWritable> values, ICollector collector) {
        int sum = 0;
        while(values.moreValue()){
            IntWritable v = values.getValue();
            sum += v.get();
        }
        sValue.set(sum);
        collector.collect(key, sValue);
    }

}
