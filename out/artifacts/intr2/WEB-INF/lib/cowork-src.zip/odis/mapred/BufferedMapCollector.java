package odis.mapred;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.cowork.CounterMap;
import odis.cowork.JobConfig;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.BinaryKeyValComparator;
import odis.file.CompressUtils;
import odis.file.IRecordComparator;
import odis.file.IRecordReader;
import odis.file.ReverseRecordComparator;
import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import odis.file.CompressUtils.CompressedData;
import odis.file.SequenceFile.ObjectCompressWriter;
import odis.io.CDataOutputStream;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.lib.QuickSort;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.lib.IntWritable;
import odis.util.LocalDirAllocator;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;
import odis.mapred.IFileMerger.Segment;
import odis.mapred.SpillRecord.IndexRecord;

/**
 * BufferedMapConllector will fistly collector the output in memory, when the
 * memory increase to threshold, it will sort the records and dump them to the
 * disk. After map done, the collector will merge all segments which dump
 * before. So the map output is sorted.
 * 
 * @author Qichen
 */

public class BufferedMapCollector<K extends IWritable, V extends IWritable>
        implements ICollector, IndexedSortable {
    protected static final Logger LOG = LogFormatter.getLogger(BufferedMapCollector.class);

    protected final static int MERGE_FACTOR = OdisLibConfig.conf().getInt("cowork.map.merge.factor", 50); // m byte

    protected static final String SPILL_IN_DIR_NAME = "spill.in";
    private final static int APPROX_HEADER_LENGTH = 150;
    public static final int MAP_OUTPUT_INDEX_RECORD_LENGTH = 24;

    protected Throwable outputError = null;

    protected BasicPartitioner partitioner;

    TaskRunnable task;
    BasicInOutJobDef job;
    JobConfig jobConfig;

    BinaryComparator keyComparator;
    BinaryComparator valueCompartor;

    Class<K> keyClass;
    Class<V> valClass;

    FileSystem lfs;

    protected String localDir;

    protected int taskPartIdx;

    CompressAlgo compressAlgo;
    boolean useCompress;

    final int partitions;
     
     CombinerRunner combinerRunner = null;
     CombineOutputCollector combineCollector = null;

    // k/v accounting
    final IntBuffer kvmeta; // metadata overlay on backing store

    int kvstart; // marks origin of spill metadata

    int kvend; // marks end of spill metadata

    int kvindex; // marks end of fully serialized records

    int equator; // marks origin of meta/serialization

    int bufstart; // marks beginning of spill

    int bufend; // marks beginning of collectable

    int bufmark; // marks end of record

    int bufindex; // marks end of collected

    int bufvoid; // marks the point where we should stop
                 // reading at the end of the buffer

    byte[] kvbuffer; // main output buffer

    private final byte[] b0 = new byte[0];

    private static final int INDEX = 0; // index offset in acct

    private static final int VALSTART = 1; // val offset in acct

    private static final int KEYSTART = 2; // key offset in acct

    private static final int PARTITION = 3; // partition offset in acct

    private static final int NMETA = 4; // num meta ints

    private static final int METASIZE = NMETA * 4; // size in bytes

    // spill accounting
    final int maxRec;

    final int softLimit;

    boolean spillInProgress;;

    int bufferRemaining;

    volatile Throwable sortSpillException = null;

    int numSpills = 0;

    final int minSpillsForCombine;

    final IndexedSorter sorter;

    final ReentrantLock spillLock = new ReentrantLock();

    final Condition spillDone = spillLock.newCondition();

    final Condition spillReady = spillLock.newCondition();

    final BlockingBuffer bb = new BlockingBuffer();

    volatile boolean spillThreadRunning = false;

    final SpillThread spillThread = new SpillThread();

    final FileSystem rfs;

    // Counters
    final CounterMap.Counter mapOutputByteCounter;
    final CounterMap.Counter mapOutputRecordCounter;    
    final CounterMap.Counter spilledRecordsCounter;
    CounterMap.Counter combineOutputCounter = null;
    CounterMap.Counter combineOutputSizeCounter = null;

    final ArrayList<SpillRecord> indexCacheList = new ArrayList<SpillRecord>(); 
    final ArrayList<Path> spillFileList = new ArrayList<Path>();

    private int totalIndexCacheMemory;

    MapOutputFile mapOutputFile = null;
    LocalDirAllocator localDirAllocator = null;
    
    private static final int INDEX_CACHE_MEMORY_LIMIT = 1024 * 1024;
    private Throwable error = null;

    @SuppressWarnings("unchecked")
    public BufferedMapCollector(BasicInOutJobDef job, TaskRunnable task) 
        throws IOException {
        
        //basic info
        this.job = (BasicInOutJobDef)job;
        this.task = task;
        this.jobConfig = job.getConfig();        
        this.partitioner = ((MapReduceJobDef)job).getPartitioner();
        partitions = job.getTaskNumber(task.getStageIdx() + 1);;
        rfs = FileSystem.getNamed("local");                
        localDirAllocator = task.getWorker().getLocalDirAllocator();

        int ioPhase = MapRedUtil.getMrMergePhase(task.getStageIdx() + 1, job);
        
        //class info
        keyClass = job.getMergeKeyClass(ioPhase);
        valClass = job.getMergeValClass(ioPhase);
        keyComparator = job.getMergeKeyComparator(ioPhase);
        valueCompartor = job.getMergeValComparator(ioPhase);
        
        //compress
        useCompress = partitioner.getCompress(job, ioPhase);
        if (useCompress) {
            compressAlgo = partitioner.getCompressAlgo(job, ioPhase);
            LOG.info("Use compress algo " + compressAlgo.name());
        }else compressAlgo = null;
        
        // sanity checks
        final float spillper = jobConfig.getFloat(MRConfig.MAP_OUT_BUFFEER_SPILL_PERCENT, 0.5f);
        final int sortmb = job.getMapOutBufferSize(ioPhase);
        
        if (spillper > (float) 1.0 || spillper <= (float) 0.0) {
            throw new IOException("Invalid \""
                    + MRConfig.MAP_OUT_BUFFEER_SPILL_PERCENT + "\": " + spillper);
        }
//        if ((sortmb & 0x7FF) != sortmb) {
//            throw new IOException("Invalid map out buffer size" + sortmb);
//        }
        // sorter = ReflectionUtils.newInstance(job.getClass("map.sort.class",
        // QuickSort.class, IndexedSorter.class), job);

        sorter = new QuickSort();
        // buffers and accounting
        int maxMemUsage = sortmb; 
//            sortmb << 20;
        maxMemUsage -= maxMemUsage % METASIZE;
        kvbuffer = new byte[maxMemUsage];
        bufvoid = kvbuffer.length;
        kvmeta = ByteBuffer.wrap(kvbuffer).asIntBuffer();
        setEquator(0);
        bufstart = bufend = bufindex = equator;
        kvstart = kvend = kvindex;

        maxRec = kvmeta.capacity() / NMETA;
        softLimit = (int) (kvbuffer.length * spillper);
        bufferRemaining = softLimit;
        
        LOG.info("Map output buffer size: " + sortmb);
        LOG.info("soft limit at " + softLimit);
        LOG.info("bufstart = " + bufstart + "; bufvoid = " + bufvoid);
        LOG.info("kvstart = " + kvstart + "; length = " + maxRec);

        // k/v serialization
        // output counters
        mapOutputByteCounter = task.getCounter(MapTaskRunnable.CT_MAPPED_OUT_SIZE);
        mapOutputRecordCounter = task.getCounter(MapTaskRunnable.CT_MAPPED_OUT_RECORD);
        spilledRecordsCounter = task.getCounter(MapTaskRunnable.CT_SPILLED_RECORD);

        mapOutputFile = new MapOutputFile(localDirAllocator);
        // compression

        // combiner
        if (job.getCombiner(ioPhase) != null) {
//            final CounterMap.Counter combineInputPairCounter = task.getCounter(MapTaskRunnable.CT_COMBINE_IN_PAIR);
            combinerRunner = CombinerRunner.create(job, task, ioPhase, null);            
            combineOutputCounter = task.getCounter(MapTaskRunnable.CT_COMBINE_OUT_RECORD);
            combineOutputSizeCounter = task.getCounter(MapTaskRunnable.CT_COMBINE_OUT_SIZE);
            combineCollector = new CombineOutputCollector<K, V>(null);
        } else {
            combineCollector = null;
            combinerRunner = null;
        }
        spillInProgress = false;
        minSpillsForCombine = jobConfig.getInt(MRConfig.MAP_COMBINE_MIN_SPILLS, 3);
        spillThread.setDaemon(true);
        spillThread.setName("SpillThread");
        spillLock.lock();
        try {
            spillThread.start();
            while (!spillThreadRunning) {
                spillDone.await();
            }
        } catch (InterruptedException e) {
            throw new IOException("Spill thread failed to initialize", e);
        } finally {
            spillLock.unlock();
        }
        if (sortSpillException != null) {
            throw new IOException("Spill thread failed to initialize",
                    sortSpillException);
        }
    }

    @Override
    public void collect(Object key, Object value) {
        collectToPartition(partitioner.getPartition(key, value, partitions), key, value);
    }

    @Override
    public void collectDoneMsg(String msg) {
        task.setDoneMsg(msg);
    }

    @Override
    public void collectToChannel(int channel, Object key, Object value) {
        throw new TaskFatalException("Method not implemented for " 
                + this.getClass().getName());
    }
    
    /**
     * Serialize the key, value to intermediate storage. When this method
     * returns, kvindex must refer to sufficient unused storage to store one
     * METADATA.
     */
    @Override
    public void collectToPartition(final int partition, Object k, Object v){
        IWritable key = (IWritable)k;
        IWritable value = (IWritable)v;
        try {
    //        reporter.progress();
            if (key.getClass() != keyClass) {
                throw new IOException("Type mismatch in key from map: expected "
                        + keyClass.getName() + ", recieved "
                        + key.getClass().getName());
            }
            if (value.getClass() != valClass) {
                throw new IOException("Type mismatch in value from map: expected "
                        + valClass.getName() + ", recieved "
                        + value.getClass().getName());
            }
            if (partition < 0 || partition >= partitions) {
                throw new IOException("Illegal partition for " + key + " ("
                        + partition + ")");
            }
            checkSpillException();
            bufferRemaining -= METASIZE;
            if (bufferRemaining <= 0) {
                // start spill if the thread is not running and the soft limit has
                // been
                // reached
                spillLock.lock();
                try {
                    do {
                        if (!spillInProgress) {
                            final int kvbidx = 4 * kvindex;
                            final int kvbend = 4 * kvend;
                            // serialized, unspilled bytes always lie between
                            // kvindex and
                            // bufindex, crossing the equator. Note that any void
                            // space
                            // created by a reset must be included in "used" bytes
                            final int bUsed = distanceTo(kvbidx, bufindex);
                            final boolean bufsoftlimit = bUsed >= softLimit;
                            if ((kvbend + METASIZE) % kvbuffer.length != equator
                                    - (equator % METASIZE)) {
                                // spill finished, reclaim space
                                resetSpill();
                                bufferRemaining = Math
                                        .min(distanceTo(bufindex, kvbidx) - 2
                                                * METASIZE, softLimit - bUsed)
                                        - METASIZE;
                                continue;
                            } else if (bufsoftlimit && kvindex != kvend) {
                                // spill records, if any collected; check latter, as
                                // it may
                                // be possible for metadata alignment to hit spill
                                // pcnt
                                startSpill();
                                final int avgRec = (int) (mapOutputByteCounter.get()/ mapOutputRecordCounter.get());
                                // leave at least half the split buffer for
                                // serialization data
                                // ensure that kvindex >= bufindex
                                final int distkvi = distanceTo(bufindex, kvbidx);
                                final int newPos = (bufindex + Math.max(
                                        2 * METASIZE - 1,
                                        Math.min(distkvi / 2, distkvi
                                                / (METASIZE + avgRec) * METASIZE)))
                                        % kvbuffer.length;
                                setEquator(newPos);
                                bufmark = bufindex = newPos;
                                final int serBound = 4 * kvend;
                                // bytes remaining before the lock must be held and
                                // limits
                                // checked is the minimum of three arcs: the
                                // metadata space, the
                                // serialization space, and the soft limit
                                bufferRemaining = Math.min(
                                // metadata max
                                        distanceTo(bufend, newPos), Math.min(
                                        // serialization max
                                                distanceTo(newPos, serBound),
                                                // soft limit
                                                softLimit)) - 2 * METASIZE;
                            }
                        }
                    } while (false);
                } finally {
                    spillLock.unlock();
                }
            }
    
            try {
                // serialize key bytes into buffer
                int keystart = bufindex;
                key.writeFields(bb);
    //            keySerializer.serialize(key);
                if (bufindex < keystart) {
                    // wrapped the key; must make contiguous
                    bb.shiftBufferedKey();
                    keystart = 0;
                }
                // serialize value bytes into buffer
                final int valstart = bufindex;
                value.writeFields(bb);
    //            valSerializer.serialize(value);
                // It's possible for records to have zero length, i.e. the
                // serializer
                // will perform no writes. To ensure that the boundary conditions
                // are
                // checked and that the kvindex invariant is maintained, perform a
                // zero-length write into the buffer. The logic monitoring this
                // could be
                // moved into collect, but this is cleaner and inexpensive. For now,
                // it
                // is acceptable.
                bb.write(b0, 0, 0);
    
                // the record must be marked after the preceding write, as the
                // metadata
                // for this record are not yet written
                int valend = bb.markRecord();
    
                mapOutputRecordCounter.inc(1);
                mapOutputByteCounter.inc(distanceTo(keystart, valend, bufvoid));
    
                // write accounting info
                kvmeta.put(kvindex + INDEX, kvindex);
                kvmeta.put(kvindex + PARTITION, partition);
                kvmeta.put(kvindex + KEYSTART, keystart);
                kvmeta.put(kvindex + VALSTART, valstart);
                // advance kvindex
                kvindex = (kvindex - NMETA + kvmeta.capacity()) % kvmeta.capacity();
            } catch (MapBufferTooSmallException e) {
                LOG.info("Record too large for in-memory buffer: " + e.getMessage());
                spillSingleRecord(partition,key, value);
                mapOutputRecordCounter.inc(1);
                return;
            }
        }catch(Throwable e) {
            LOG.log(Level.SEVERE, "ERROR" ,e);
            error = e;
            throw new RuntimeException(e);
        }
    }
    
    public Throwable getError(){
        return error;
    }

    private void testPrint(int kvoff) {
        InMemValBytes key = new InMemValBytes();
        InMemValBytes value = new InMemValBytes();
        int start = kvmeta.get(kvoff + KEYSTART);
        int len = (kvmeta.get(kvoff + VALSTART) - kvmeta
                .get(kvoff + KEYSTART)); 
        key.reset(kvbuffer, start, len);
        getVBytesForOffset(kvoff, value);
        
        try {
            IntWritable iw = new IntWritable();
            iw.readFields(key);
            System.out.println("***=" + iw.get() + ", pos=" + key.getPosition() + ",len=" + key.getSize());
            iw.readFields(value);
            System.out.println("yyyyyy=" + iw.get() + ", pos=" + value.getPosition() + ",len=" + value.getSize());
        }catch(Exception e) {
            LOG.log(Level.SEVERE, "", e);
        }
    }
    
    /**
     * Set the point from which meta and serialization data expand. The meta
     * indices are aligned with the buffer, so metadata never spans the ends of
     * the circular buffer.
     */
    private void setEquator(int pos) {
        equator = pos;
        // set index prior to first entry, aligned at meta boundary
        final int aligned = pos - (pos % METASIZE);
        kvindex = ((aligned - METASIZE + kvbuffer.length) % kvbuffer.length) / 4;
        LOG.info("(EQUATOR) " + pos + " kvi " + kvindex + "(" + (kvindex * 4)
                + ")");
    }

    /**
     * The spill is complete, so set the buffer and meta indices to be equal to
     * the new equator to free space for continuing collection. Note that when
     * kvindex == kvend == kvstart, the buffer is empty.
     */
    private void resetSpill() {
        final int e = equator;
        bufstart = bufend = e;
        final int aligned = e - (e % METASIZE);
        // set start/end to point to first meta record
        kvstart = kvend = ((aligned - METASIZE + kvbuffer.length) % kvbuffer.length) / 4;
        LOG.info("(RESET) equator " + e + " kv " + kvstart + "("
                + (kvstart * 4) + ")" + " kvi " + kvindex + "(" + (kvindex * 4)
                + ")");
    }

    /**
     * Compute the distance in bytes between two indices in the serialization
     * buffer.
     * 
     * @see #distanceTo(int,int,int)
     */
    final int distanceTo(final int i, final int j) {
        return distanceTo(i, j, kvbuffer.length);
    }

    /**
     * Compute the distance between two indices in the circular buffer given the
     * max distance.
     */
    int distanceTo(final int i, final int j, final int mod) {
        return i <= j ? j - i : mod - i + j;
    }

    /**
     * For the given meta position, return the dereferenced position in the
     * integer array. Each meta block contains several integers describing
     * record data in its serialized form, but the INDEX is not necessarily
     * related to the proximate metadata. The index value at the referenced int
     * position is the start offset of the associated metadata block. So the
     * metadata INDEX at metapos may point to the metadata described by the
     * metadata block at metapos + k, which contains information about that
     * serialized record.
     */
    int offsetFor(int metapos) {
        return kvmeta.get(metapos * NMETA + INDEX);
    }

    /**
     * Compare logical range, st i, j MOD offset capacity. Compare by partition,
     * then by key.
     * 
     * @see IndexedSortable#compare
     */
    private InMemValBytes iValBytes = null;
    private InMemValBytes jValBytes = null;
    
    public int compare(final int mi, final int mj) {
        final int kvi = offsetFor(mi % maxRec);
        final int kvj = offsetFor(mj % maxRec);
        final int kvip = kvmeta.get(kvi + PARTITION);
        final int kvjp = kvmeta.get(kvj + PARTITION);
        // sort by partition
        if (kvip != kvjp) {
            return kvip - kvjp;
        }                      
        // sort by key
        int ret = keyComparator.compare(kvbuffer, kvmeta.get(kvi + KEYSTART),
                kvmeta.get(kvi + VALSTART) - kvmeta.get(kvi + KEYSTART),
                kvbuffer, kvmeta.get(kvj + KEYSTART),
                kvmeta.get(kvj + VALSTART) - kvmeta.get(kvj + KEYSTART));
        if (ret != 0 || valueCompartor == null) return ret;
        else { //compare value
            if(iValBytes == null) {
                iValBytes = new InMemValBytes();            
                jValBytes = new InMemValBytes();
            }
            getVBytesForOffset(kvi, iValBytes);
            getVBytesForOffset(kvj, jValBytes);            
            return valueCompartor.compare(iValBytes.getBuffer(), iValBytes.getPosition(), iValBytes.getSize(), 
                    jValBytes.getBuffer(), jValBytes.getPosition(), jValBytes.getSize());
        }
    }

    /**
     * Swap logical indices st i, j MOD offset capacity.
     * 
     * @see IndexedSortable#swap
     */
    public void swap(final int mi, final int mj) {
        final int kvi = (mi % maxRec) * NMETA + INDEX;
        final int kvj = (mj % maxRec) * NMETA + INDEX;
        int tmp = kvmeta.get(kvi);
        kvmeta.put(kvi, kvmeta.get(kvj));
        kvmeta.put(kvj, tmp);
    }

    /**
     * Inner class managing the spill of serialized records to disk.
     */
    protected class BlockingBuffer extends CDataOutputStream {

        public BlockingBuffer() {
            super(new Buffer());
        }

        /**
         * Mark end of record. Note that this is required if the buffer is to
         * cut the spill in the proper place.
         */
        public int markRecord() {
            bufmark = bufindex;
            return bufindex;
        }

        /**
         * Set position from last mark to end of writable buffer, then rewrite
         * the data between last mark and kvindex. This handles a special case
         * where the key wraps around the buffer. If the key is to be passed to
         * a RawComparator, then it must be contiguous in the buffer. This
         * recopies the data in the buffer back into itself, but starting at the
         * beginning of the buffer. Note that this method should <b>only</b> be
         * called immediately after detecting this condition. To call it at any
         * other time is undefined and would likely result in data loss or
         * corruption.
         * 
         * @see #markRecord()
         */
        protected void shiftBufferedKey() throws IOException {
            // spillLock unnecessary; both kvend and kvindex are current
            int headbytelen = bufvoid - bufmark;
            bufvoid = bufmark;
            final int kvbidx = 4 * kvindex;
            final int kvbend = 4 * kvend;
            final int avail = Math.min(distanceTo(0, kvbidx),
                    distanceTo(0, kvbend));
            if (bufindex + headbytelen < avail) {
                System.arraycopy(kvbuffer, 0, kvbuffer, headbytelen, bufindex);
                System.arraycopy(kvbuffer, bufvoid, kvbuffer, 0, headbytelen);
                bufindex += headbytelen;
                bufferRemaining -= kvbuffer.length - bufvoid;
            } else {
                byte[] keytmp = new byte[bufindex];
                System.arraycopy(kvbuffer, 0, keytmp, 0, bufindex);
                bufindex = 0;
                out.write(kvbuffer, bufmark, headbytelen);
                out.write(keytmp);
            }
        }
    }

    public class Buffer extends OutputStream {
        private final byte[] scratch = new byte[1];

        @Override
        public void write(int v) throws IOException {
            scratch[0] = (byte) v;
            write(scratch, 0, 1);
        }

        /**
         * Attempt to write a sequence of bytes to the collection buffer. This
         * method will block if the spill thread is running and it cannot write.
         * 
         * @throws MapBufferTooSmallException
         *             if record is too large to deserialize into the collection
         *             buffer.
         */
        @Override
        public void write(byte b[], int off, int len) throws IOException {
            // must always verify the invariant that at least METASIZE bytes are
            // available beyond kvindex, even when len == 0
            bufferRemaining -= len;
            if (bufferRemaining <= 0) {
                // writing these bytes could exhaust available buffer space or
                // fill
                // the buffer to soft limit. check if spill or blocking are
                // necessary
                boolean blockwrite = false;
                spillLock.lock();
                try {
                    do {
                        checkSpillException();

                        final int kvbidx = 4 * kvindex;
                        final int kvbend = 4 * kvend;
                        // ser distance to key index
                        final int distkvi = distanceTo(bufindex, kvbidx);
                        // ser distance to spill end index
                        final int distkve = distanceTo(bufindex, kvbend);

                        // if kvindex is closer than kvend, then a spill is
                        // neither in
                        // progress nor complete and reset since the lock was
                        // held. The
                        // write should block only if there is insufficient
                        // space to
                        // complete the current write, write the metadata for
                        // this record,
                        // and write the metadata for the next record. If kvend
                        // is closer,
                        // then the write should block if there is too little
                        // space for
                        // either the metadata or the current write. Note that
                        // collect
                        // ensures its metadata requirement with a zero-length
                        // write
                        blockwrite = distkvi <= distkve ? distkvi <= len + 2
                                * METASIZE : distkve <= len
                                || distanceTo(bufend, kvbidx) < 2 * METASIZE;

                        if (!spillInProgress) {
                            if (blockwrite) {
                                if ((kvbend + METASIZE) % kvbuffer.length != equator
                                        - (equator % METASIZE)) {
                                    // spill finished, reclaim space
                                    // need to use meta exclusively; zero-len
                                    // rec & 100% spill
                                    // pcnt would fail
                                    resetSpill(); // resetSpill doesn't move
                                                  // bufindex, kvindex
                                    bufferRemaining = Math.min(
                                            distkvi - 2 * METASIZE,
                                            softLimit
                                                    - distanceTo(kvbidx,
                                                            bufindex))
                                            - len;
                                    continue;
                                }
                                // we have records we can spill; only spill if
                                // blocked
                                if (kvindex != kvend) {
                                    startSpill();
                                    // Blocked on this write, waiting for the
                                    // spill just
                                    // initiated to finish. Instead of
                                    // repositioning the marker
                                    // and copying the partial record, we set
                                    // the record start
                                    // to be the new equator
                                    setEquator(bufmark);
                                } else {
                                    // We have no buffered records, and this
                                    // record is too large
                                    // to write into kvbuffer. We must spill it
                                    // directly from
                                    // collect
                                    final int size = distanceTo(bufstart,
                                            bufindex) + len;
                                    setEquator(0);
                                    bufstart = bufend = bufindex = equator;
                                    kvstart = kvend = kvindex;
                                    bufvoid = kvbuffer.length;
                                    throw new MapBufferTooSmallException(size
                                            + " bytes");
                                }
                            }
                        }

                        if (blockwrite) {
                            // wait for spill
                            try {
                                while (spillInProgress) {
//                                    reporter.progress();
                                    spillDone.await();
                                }
                            } catch (InterruptedException e) {
                                throw new IOException(
                                        "Buffer interrupted while waiting for the writer",
                                        e);
                            }
                        }
                    } while (blockwrite);
                } finally {
                    spillLock.unlock();
                }
            }
            // here, we know that we have sufficient space to write
            if (bufindex + len > bufvoid) {
                final int gaplen = bufvoid - bufindex;
                System.arraycopy(b, off, kvbuffer, bufindex, gaplen);
                len -= gaplen;
                off += gaplen;
                bufindex = 0;
            }
            System.arraycopy(b, off, kvbuffer, bufindex, len);
            bufindex += len;
        }
    }

    public void flush() throws IOException, ClassNotFoundException,
            InterruptedException {
        LOG.info("Starting flush of map output");
        spillLock.lock();
        try {
            while (spillInProgress) {
//                reporter.progress();
                spillDone.await();
            }
            checkSpillException();

            final int kvbend = 4 * kvend;
            if ((kvbend + METASIZE) % kvbuffer.length != equator
                    - (equator % METASIZE)) {
                // spill finished
                resetSpill();
            }
            if (kvindex != kvend) {
                kvend = (kvindex + NMETA) % kvmeta.capacity();
                bufend = bufmark;
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.info("Spilling map output");
                    LOG.info("bufstart = " + bufstart + "; bufend = " + bufmark
                            + "; bufvoid = " + bufvoid);
                    LOG.info("kvstart = "
                            + kvstart
                            + "("
                            + (kvstart * 4)
                            + "); kvend = "
                            + kvend
                            + "("
                            + (kvend * 4)
                            + "); length = "
                            + (distanceTo(kvend, kvstart, kvmeta.capacity()) + 1)
                            + "/" + maxRec);
                }
                sortAndSpill();
            }
        } catch (InterruptedException e) {
            throw new IOException("Interrupted while waiting for the writer", e);
        } finally {
            spillLock.unlock();
        }
        assert !spillLock.isHeldByCurrentThread();
        // shut down spill thread and wait for it to exit. Since the preceding
        // ensures that it is finished with its work (and sortAndSpill did not
        // throw), we elect to use an interrupt instead of setting a flag.
        // Spilling simultaneously from this thread while the spill thread
        // finishes its work might be both a useful way to extend this and also
        // sufficient motivation for the latter approach.
        try {
            spillThread.interrupt();
            spillThread.join();
        } catch (InterruptedException e) {
            throw new IOException("Spill failed", e);
        }
        // release sort buffer before the merge
        kvbuffer = null;
        mergeParts();
    }

    public void close() throws IOException{
        try {
            flush();
        }catch(Exception e) {
            throw new IOException(e);
        }
    }
    
    public Path getFinalOutputFile() {
        return finalOutputFile;
    }

    protected class SpillThread extends Thread {

        @Override
        public void run() {
            spillThreadRunning = true;
            spillLock.lock();
            try {
                while (true) {
                    spillDone.signal();
                    while (!spillInProgress) {
                        spillReady.await();
                    }
                    try {
                        spillLock.unlock();
                        sortAndSpill();
                    } catch (Throwable t) {
                        sortSpillException = t;
                    } finally {
                        spillLock.lock();
                        if (bufend < bufstart) {
                            bufvoid = kvbuffer.length;
                        }
                        kvstart = kvend;
                        bufstart = bufend;
                        spillInProgress = false;
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                spillLock.unlock();
                spillThreadRunning = false;
            }
        }
    }

    private void checkSpillException() throws IOException {
        final Throwable lspillException = sortSpillException;
        if (lspillException != null) {
            if (lspillException instanceof Error) {
                LOG.log(Level.SEVERE, "Task spill failed. " , lspillException);
//                final String logMsg = "Task " + getTaskID() + " failed : "
//                        + StringUtils.stringifyException(lspillException);
//                reportFatalError(getTaskID(), lspillException, logMsg);
            }
            throw new IOException("Spill failed", lspillException);
        }
    }

    private void startSpill() {
        assert !spillInProgress;
        kvend = (kvindex + NMETA) % kvmeta.capacity();
        bufend = bufmark;
        spillInProgress = true;
        if (LOG.isLoggable(Level.INFO)) {
            LOG.info("Spilling map output");
            LOG.info("bufstart = " + bufstart + "; bufend = " + bufmark
                    + "; bufvoid = " + bufvoid);
            LOG.info("kvstart = " + kvstart + "(" + (kvstart * 4)
                    + "); kvend = " + kvend + "(" + (kvend * 4)
                    + "); length = "
                    + (distanceTo(kvend, kvstart, kvmeta.capacity()) + 1) + "/"
                    + maxRec);
        }
        spillReady.signal();
    }

    private void sortAndSpill() throws IOException, ClassNotFoundException,
            InterruptedException {
        // approximate the length of the output file to be the length of the
        // buffer + header lengths for the partitions
        final long size = (bufend >= bufstart ? bufend - bufstart
                : (bufvoid - bufend) + bufstart)
                + partitions
                * APPROX_HEADER_LENGTH;
        FSDataOutputStream out = null;
        try {
            // create spill file
            final SpillRecord spillRec = new SpillRecord(partitions);
            final Path filename = mapOutputFile.getSpillFileForWrite(numSpills,
                    size + partitions * MAP_OUTPUT_INDEX_RECORD_LENGTH);
            out = rfs.create(filename);

            final int mstart = kvend / NMETA;
            final int mend = 1
                    + // kvend is a valid record
                    (kvstart >= kvend ? kvstart : kvmeta.capacity() + kvstart)
                    / NMETA;
            sorter.sort(BufferedMapCollector.this, mstart, mend);
            int spindex = mstart;
            final IndexRecord rec = new IndexRecord();
            final InMemValBytes value = new InMemValBytes();
            for (int i = 0; i < partitions; ++i) {
                IFile.Writer<K, V> writer = null;
                try {
                    long segmentStart = out.getPos();
                    writer = new IFile.Writer<K, V>(out, keyClass, valClass, compressAlgo, spilledRecordsCounter);
                    if (combinerRunner == null) {
                        // spill directly
                        DataInputBuffer key = new DataInputBuffer();
                        while (spindex < mend
                                && kvmeta.get(offsetFor(spindex % maxRec)
                                        + PARTITION) == i) {
                            final int kvoff = offsetFor(spindex % maxRec);
                            key.reset(kvbuffer, kvmeta.get(kvoff + KEYSTART),
                                    (kvmeta.get(kvoff + VALSTART) - kvmeta
                                            .get(kvoff + KEYSTART)));
                            getVBytesForOffset(kvoff, value);
                                                         
                            writer.append(key, value);
                            ++spindex;
                        }
                    } else {
                        int spstart = spindex;
                        while (spindex < mend
                                && kvmeta.get(offsetFor(spindex % maxRec)
                                        + PARTITION) == i) {
                            ++spindex;
                        }
                        // Note: we would like to avoid the combiner if we've
                        // fewer
                        // than some threshold of records for a partition
                        if (spstart != spindex) {
                            combineCollector.setWriter(writer);
                            RawKeyValueIterator kvIter = new MRResultIterator(
                                    spstart, spindex);
                            combinerRunner
                                    .combine(
                                            new CombinerRunner.RawKeyValueRecordReader(
                                                    kvIter,
                                                    keyClass,
                                                    valClass,
                                                    task.getCounter(MapTaskRunnable.CT_COMBINE_IN_RECORD)),
                                            combineCollector);
                        }
                    }

                    // close the writer
                    writer.close();

                    // record offsets
                    rec.startOffset = segmentStart;
                    rec.rawLength = writer.getRawLength();
                    rec.partLength = writer.getCompressedLength();
                    spillRec.putIndex(rec, i);

                    writer = null;
                } finally {
                    if (null != writer)
                        writer.close();
                }
            }

            if (totalIndexCacheMemory >= INDEX_CACHE_MEMORY_LIMIT) {
                // create spill index file
                Path indexFilename = MapOutputFile.getFileIndex(filename);
//                Path indexFilename = mapOutputFile.getSpillIndexFileForWrite(
//                        numSpills, partitions * MAP_OUTPUT_INDEX_RECORD_LENGTH);
                spillRec.writeToFile(indexFilename);
            } else {
                indexCacheList.add(spillRec);
                totalIndexCacheMemory += spillRec.size()
                        * MAP_OUTPUT_INDEX_RECORD_LENGTH;
            }
            LOG.info("Finished spill " + numSpills);
            ++numSpills;
            spillFileList.add(filename);
        } finally {
            if (out != null)
                out.close();
        }
    }

    /**
     * Handles the degenerate case where serialization fails to fit in the
     * in-memory buffer, so we must spill the record from collect directly to a
     * spill file. Consider this "losing".
     */
    private void spillSingleRecord(int partition, final IWritable key, final IWritable value)
            throws IOException {
        long size = kvbuffer.length + partitions * APPROX_HEADER_LENGTH;
        FSDataOutputStream out = null;
        try {
            // create spill file
            final SpillRecord spillRec = new SpillRecord(partitions);
            final Path filename = mapOutputFile.getSpillFileForWrite(numSpills,
                    size + partitions * MAP_OUTPUT_INDEX_RECORD_LENGTH);
            out = rfs.create(filename);

            // we don't run the combiner for a single record
            IndexRecord rec = new IndexRecord();
            for (int i = 0; i < partitions; ++i) {
                IFile.Writer<K, V> writer = null;
                try {
                    long segmentStart = out.getPos();
                    // Create a new codec, don't care!
                    writer = new IFile.Writer<K, V>(out, keyClass,
                            valClass, compressAlgo, spilledRecordsCounter);

                    if (i == partition) {
                        final long recordStart = out.getPos();
                        writer.append(key, value);
                        // Note that our map byte count will not be accurate
                        // with
                        // compression
                        mapOutputByteCounter.inc(out.getPos() - recordStart);
                    }
                    writer.close();

                    // record offsets
                    rec.startOffset = segmentStart;
                    rec.rawLength = writer.getRawLength();
                    rec.partLength = writer.getCompressedLength();
                    spillRec.putIndex(rec, i);

                    writer = null;
                } catch (IOException e) {
                    if (null != writer)
                        writer.close();
                    throw e;
                }
            }
            if (totalIndexCacheMemory >= INDEX_CACHE_MEMORY_LIMIT) {
                // create spill index file
                Path indexFilename = MapOutputFile.getFileIndex(filename);
//                Path indexFilename = mapOutputFile.getSpillIndexFileForWrite(
//                        numSpills, partitions * MAP_OUTPUT_INDEX_RECORD_LENGTH);
                spillRec.writeToFile(indexFilename);
            } else {
                indexCacheList.add(spillRec);
                totalIndexCacheMemory += spillRec.size()
                        * MAP_OUTPUT_INDEX_RECORD_LENGTH;
            }
            
            ++numSpills;
            spillFileList.add(filename);
        } finally {
            if (out != null)
                out.close();
        }
    }

    /**
     * Given an offset, populate vbytes with the associated set of deserialized
     * value bytes. Should only be called during a spill.
     */
    private void getVBytesForOffset(int kvoff, InMemValBytes vbytes) {
        // get the keystart for the next serialized value to be the end
        // of this value. If this is the last value in the buffer, use bufend
        final int nextindex = kvoff == kvend ? bufend : kvmeta.get((kvoff
                - NMETA + kvmeta.capacity() + KEYSTART)
                % kvmeta.capacity());
        // calculate the length of the value
        int vallen = (nextindex >= kvmeta.get(kvoff + VALSTART)) ? nextindex
                - kvmeta.get(kvoff + VALSTART) : (bufvoid - kvmeta.get(kvoff
                + VALSTART))
                + nextindex;
        vbytes.reset(kvbuffer, kvmeta.get(kvoff + VALSTART), vallen);
    }
    
    private int getValueLen(int kvoff) {
        final int nextindex = kvoff == kvend ? bufend : kvmeta.get((kvoff
                - NMETA + kvmeta.capacity() + KEYSTART)
                % kvmeta.capacity());
        // calculate the length of the value
        int vallen = (nextindex >= kvmeta.get(kvoff + VALSTART)) ? nextindex
                - kvmeta.get(kvoff + VALSTART) : (bufvoid - kvmeta.get(kvoff
                + VALSTART))
                + nextindex;
        return vallen;
    }

    /**
     * Inner class wrapping valuebytes, used for appendRaw.
     */
    protected class InMemValBytes extends DataInputBuffer {
        private byte[] buffer;

        private int start;

        private int length;

        public void reset(byte[] buffer, int start, int length) {
            this.buffer = buffer;
            this.start = start;
            this.length = length;

            if (start + length > bufvoid) {
                this.buffer = new byte[this.length];
                final int taillen = bufvoid - start;
                System.arraycopy(buffer, start, this.buffer, 0, taillen);
                System.arraycopy(buffer, 0, this.buffer, taillen, length
                        - taillen);
                this.start = 0;
            }

            super.reset(this.buffer, this.start, this.length);
        }
    }

    protected class MRResultIterator implements RawKeyValueIterator {
        private final DataInputBuffer keybuf = new DataInputBuffer();

        private final InMemValBytes vbytes = new InMemValBytes();

        private final int end;

        private int current;

        public MRResultIterator(int start, int end) {
            this.end = end;
            current = start - 1;
        }

        public boolean next() throws IOException {
            return ++current < end;
        }

        public DataInputBuffer getKey() throws IOException {
            final int kvoff = offsetFor(current % maxRec);
            keybuf.reset(kvbuffer, kvmeta.get(kvoff + KEYSTART),
                    kvmeta.get(kvoff + VALSTART) - kvmeta.get(kvoff + KEYSTART));
            return keybuf;
        }

        public DataInputBuffer getValue() throws IOException {
            getVBytesForOffset(offsetFor(current % maxRec), vbytes);
            return vbytes;
        }

        public void close() {}

        @Override
        public long getPos() throws IOException {
            throw new UnsupportedOperationException();
        }

        @Override
        public long getSize() throws IOException {
            throw new UnsupportedOperationException();
        }
    }

    Path finalOutputFile = null;
    private void mergeParts() throws IOException, InterruptedException,
            ClassNotFoundException {
        // get the approximate size of the final output/index files
        long finalOutFileSize = 0;
        long finalIndexFileSize = 0;
        final Path[] filename = new Path[numSpills];
        
        for (int i = 0; i < numSpills; i++) {
            filename[i] = spillFileList.get(i);
            finalOutFileSize += rfs.getLength(filename[i]);
        }
        if (numSpills == 1) { // the spill is the final output
            finalOutputFile = new Path(filename[0].getParent(),MapOutputFile.MAP_OUT_FILE_NAME);
            rfs.rename(filename[0], finalOutputFile);
            if (indexCacheList.size() == 0) {
                rfs.rename(MapOutputFile.getFileIndex(spillFileList.get(0)), 
                        MapOutputFile.getFileIndex(finalOutputFile));
            } else {
                indexCacheList.get(0).writeToFile(MapOutputFile.getFileIndex(finalOutputFile));
            }
            
            if (combineOutputCounter != null) {
                combineOutputCounter.inc(spilledRecordsCounter.get());
            }
            
            if (this.combineOutputSizeCounter != null) {
                long len = rfs.getLength(finalOutputFile);
                this.combineOutputSizeCounter.inc(len);
            }            
            return;
        }

        // read in paged indices
        for (int i = indexCacheList.size(); i < numSpills; ++i) {
            Path indexFileName = MapOutputFile.getFileIndex(spillFileList.get(i));
            indexCacheList.add(new SpillRecord(indexFileName));
        }

        // make correction in the length to include the sequence file header
        // lengths for each partition
        finalOutFileSize += partitions * APPROX_HEADER_LENGTH;
        finalIndexFileSize = partitions * MAP_OUTPUT_INDEX_RECORD_LENGTH;
        finalOutputFile = mapOutputFile.getOutputFileForWrite(finalOutFileSize);
        Path finalIndexFile = mapOutputFile.getFileIndex(finalOutputFile);

        // The output stream for the final single output file
        FSDataOutputStream finalOut = rfs.create(finalOutputFile, true, 4096);

        if (numSpills == 0) {
            // create dummy files
            IndexRecord rec = new IndexRecord();
            SpillRecord sr = new SpillRecord(partitions);
            try {
                for (int i = 0; i < partitions; i++) {
                    long segmentStart = finalOut.getPos();
                    IFile.Writer<K, V> writer = new IFile.Writer<K, V>(finalOut,keyClass, valClass, compressAlgo, null);
                    writer.close();
                    rec.startOffset = segmentStart;
                    rec.rawLength = writer.getRawLength();
                    rec.partLength = writer.getCompressedLength();
                    sr.putIndex(rec, i);
                }
                sr.writeToFile(finalIndexFile);
            } finally {
                finalOut.close();
            }
            return;
        }
        {
//            sortPhase.addPhases(partitions); // Divide sort phase into
                                             // sub-phases
            IFileMerger.considerFinalMergeForProgress();

            IndexRecord rec = new IndexRecord();
            final SpillRecord spillRec = new SpillRecord(partitions);
            for (int parts = 0; parts < partitions; parts++) {
                // create the segments to be merged
                List<Segment<K, V>> segmentList = new ArrayList<Segment<K, V>>(
                        numSpills);
                for (int i = 0; i < numSpills; i++) {
                    IndexRecord indexRecord = indexCacheList.get(i).getIndex(
                            parts);

                    Segment<K, V> s = new Segment<K, V>(jobConfig, rfs, filename[i],
                            indexRecord.startOffset, indexRecord.partLength,
                            compressAlgo, true);
                    segmentList.add(i, s);

                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.fine(" Reducer=" + parts
                                + "Spill =" + i + "(" + indexRecord.startOffset
                                + "," + indexRecord.rawLength + ", "
                                + indexRecord.partLength + ")");
                    }
                }

                int mergeFactor = jobConfig.getInt(MRConfig.MAP_SORT_MERGE_FACTOR, 100);
                // sort the segments only if there are intermediate merges
                boolean sortSegments = segmentList.size() > mergeFactor;
                // merge
                @SuppressWarnings("unchecked")
                RawKeyValueIterator kvIter = IFileMerger.merge(jobConfig, localDirAllocator, rfs, keyClass,
                        valClass, compressAlgo, segmentList, mergeFactor, -1,
                        keyComparator, valueCompartor, sortSegments,
                        null, spilledRecordsCounter);

                // write merged output to disk
                long segmentStart = finalOut.getPos();
                IFile.Writer<K, V> writer = new IFile.Writer<K, V>(finalOut, keyClass,
                        valClass, compressAlgo, this.combineOutputCounter);
                if (combinerRunner == null || numSpills < minSpillsForCombine) {
                    IFileMerger.writeFile(kvIter, writer, jobConfig);
                } else {
                    combineCollector.setWriter(writer);
                    combinerRunner.combine(
                            new CombinerRunner.RawKeyValueRecordReader(kvIter,
                                    keyClass, valClass), combineCollector);
                }

                // close
                writer.close();

                // record offsets
                rec.startOffset = segmentStart;
                rec.rawLength = writer.getRawLength();
                rec.partLength = writer.getCompressedLength();
                spillRec.putIndex(rec, parts);
            }
            spillRec.writeToFile(finalIndexFile);
            finalOut.close();
            for (int i = 0; i < numSpills; i++) {
                rfs.delete(filename[i]);
            }
        }
        if (this.combineOutputSizeCounter != null) {
            long len = rfs.getLength(finalOutputFile);
            this.combineOutputSizeCounter.inc(len);
        }
    }
    
    @SuppressWarnings("serial")
    private static class MapBufferTooSmallException extends IOException {
      public MapBufferTooSmallException(String s) {
        super(s);
      }
    }
    
}
