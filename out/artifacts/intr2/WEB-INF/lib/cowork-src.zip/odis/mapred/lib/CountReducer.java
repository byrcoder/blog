package odis.mapred.lib;

import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.serialize.lib.IntWritable;

public class CountReducer extends AbstractReducer<Object, Object> {

  public void reduce(Object key, IWritablePairWalker<Object,Object> values,
      ICollector collector) {
    // count number of values for this key
    int count = 0;
    while (values.moreValue()) count++;
    // output sum
    collector.collect(key, new IntWritable(count));
  }

}
