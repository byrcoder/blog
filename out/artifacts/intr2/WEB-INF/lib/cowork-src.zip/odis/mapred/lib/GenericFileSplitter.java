package odis.mapred.lib;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicSplitter;
import odis.mapred.ITaskInputSplit;
import toolbox.misc.LogFormatter;

/**
 * The general file splliter.
 * 
 * CHANGE:
 *   1) split files in more then one directory vertically.
 *       Old:  dir-1/file-1 dir-1/file-2 | dir-2/file-1 dir-2/file-2
 *       Now:  dir-1/file-1 dir-2/file-1 | dir-1/file-2 dir-2/file-2
 *     Reason:
 *       Different folders could contain different types of files. The average 
 *       size per entry could be different. The latter way makes the mapping 
 *       more balanced.
 * 
 * @author zl, David
 *
 */
public class GenericFileSplitter extends BasicSplitter {
    protected static final Logger LOG =
        LogFormatter.getLogger(GenericFileSplitter.class.getName());
    
    protected boolean allowEmpty(BasicInOutJobDef job) { return false; }
  
    protected Class<? extends BasicSplitter> getTypeClass() {
        return GenericFileSplitter.class;
    }
  
    protected int getUnitNumber(int taskStage, BasicInOutJobDef job) 
            throws IOException {
        if (isPerUnitSplit(taskStage, job))
            return split(taskStage,job).length;
        throw new IOException("Cannot call getUnitNumber() unless you use " 
                + "per-unit-split");
    }
  
    protected ITaskInputSplit[][] split(IFileSystem[] fs, String[] dirs, 
            String [][] parts, Path[][] files, int fileCount, 
            int blkSize, boolean isPerFile, int splitNum) throws IOException {
        InputFileSplit[][] inputSplits;
        // one-task-per-file
        if (isPerFile) {
            inputSplits = new InputFileSplit[fileCount][1];
            int idx = 0;
            for (int i = 0; i < files.length; i ++) {
                for (int j = 0; j < files[i].length; j ++) {
                    inputSplits[idx++][0] = new InputFileSplit(fs[i].getName(), 
                            dirs[i], parts[i][j]);
                  } // for j
            } // for i
            if (idx!=fileCount)
                throw new IOException("File number changed, expect " + fileCount 
                        + " got " + idx);
            //sort tasks from large to small
            //@Todo can't sort here, 
            //  sortSplitByLength(inputSplits);
            return inputSplits;
        }
        // compute total size
        long totalBlock = 0; 
        for (int i = 0; i < files.length; i ++)
            for (int j = 0; j < files[i].length; j ++) {
                totalBlock += (fs[i].getLength(files[i][j]) 
                        + blkSize - 1) / blkSize;
              } // for j, i
        long blocksPerSplit = totalBlock / splitNum;
        // extraBlocks is given to first extraBlocks splits each
        long extraBlocks = totalBlock % splitNum;  
        int curPart = 0;  long curNeed = blocksPerSplit;
        if (curPart < extraBlocks)
            curNeed ++;
        inputSplits = new InputFileSplit[splitNum][];
        ArrayList<InputFileSplit> splits = new ArrayList<InputFileSplit>();
        /*
         * maxParts = the maximum number of parts over all folders
         */
        int maxParts = 0;
        for (int i = 0; i < files.length; i ++)
            if (files[i].length > maxParts)
                maxParts = files[i].length;
        /*
         * Loop first by parts than by folders
         */
        for (int j = 0; j < maxParts; j ++) 
            for (int i = 0; i < files.length; i ++) {
                if (j >= files[i].length)
                    // in case some folder has less parts than maxParts
                    continue;
                long fileLeft = fs[i].getLength(files[i][j]); 
                long filePos = 0;
                long blkLeftInFile = (fileLeft + blkSize - 1) / blkSize;
                while (blkLeftInFile > curNeed) { 
                    /*
                     * current part ends
                     */         
                    long takenBytes = curNeed * blkSize;
                    assert (takenBytes < fileLeft);
                    splits.add(new InputFileSplit(fs[i].getName(), dirs[i], 
                        parts[i][j], filePos,takenBytes));
                    inputSplits[curPart] = splits.toArray(
                            new InputFileSplit[splits.size()]);
                    fileLeft -= takenBytes; filePos += takenBytes;
                    blkLeftInFile = (fileLeft + blkSize - 1) / blkSize;
                    splits = new ArrayList<InputFileSplit>();
                    curPart++; assert curPart<inputSplits.length;
                    curNeed = blocksPerSplit; 
                    if (curPart<extraBlocks) 
                        curNeed++;
                } // while
                if (blkLeftInFile < curNeed) {
                    /*
                     * current file ends
                     */
                    splits.add(new InputFileSplit(fs[i].getName(), dirs[i], 
                            parts[i][j], filePos, fileLeft));
                    curNeed -= blkLeftInFile;  fileLeft = 0;  
                    filePos += fileLeft;
                } else if (blkLeftInFile == curNeed) {
                    /*
                     * both end
                     */
                    splits.add(new InputFileSplit(fs[i].getName(), dirs[i], 
                            parts[i][j], filePos,fileLeft));
                    inputSplits[curPart] = splits.toArray(
                            new InputFileSplit[splits.size()]);
                    curNeed = 0; fileLeft = 0; filePos += fileLeft;
                    splits = new ArrayList<InputFileSplit>();
                    curPart++; 
                    // everyone gets more than claimed
                    assert curPart <= inputSplits.length;  
                    curNeed = blocksPerSplit; 
                    if (curPart < extraBlocks) 
                        curNeed ++;
                } // else if
                assert curPart<=inputSplits.length && fileLeft==0; // FIXME
            } // for i, j
        for (; curPart < inputSplits.length; curPart ++)
            inputSplits[curPart] = new InputFileSplit[0];
        
        //sort tasks from large to small
        sortSplitByLength(inputSplits);
        
        return inputSplits;
    }
  
    @Override
    protected ITaskInputSplit[][] split(int taskStage, BasicInOutJobDef job) 
        throws IOException {
        LOG.info("Doing regular file splitting ...");
        // list files
        int fileCount = 0;
        IFileSystem[] fs = new IFileSystem[getChannelNum(taskStage,job)];
        String[] dirs = new String[getChannelNum(taskStage,job)];
        Path[][] files = new Path[getChannelNum(taskStage,job)][];
        String [][] parts = new String[getChannelNum(taskStage,job)][];
        for (int i = 0; i < dirs.length; i ++) {
            fs[i] = FileSystem.getNamed(getSvcAddr(taskStage,i,job));
            dirs[i] = getPath(taskStage,i,job);
            LOG.info("dir[" + i + "]: " + fs[i].getName()+":"+dirs[i]);
            // the input format decide how to get parts here
            parts[i] = getParts(taskStage, i, job); 
            files[i] = new Path[parts[i].length];
            for (int j = 0; j < parts[i].length; j ++) 
                files[i][j] = new Path(dirs[i], parts[i][j]);
            fileCount += files[i].length;
            LOG.fine("Input channel " + i + ": " + Arrays.toString(files[i]));
        } // for i    
        if (dirs.length != 0 && fileCount == 0 && !allowEmpty(job))
            throw new IOException("No input files in: " 
                    + Arrays.toString(dirs));
        
        if (LOG.isLoggable(Level.FINEST)) {
            LOG.finest("Input file systems: \n" + Arrays.deepToString(fs));
            LOG.finest("Input directories: \n" + Arrays.deepToString(dirs));
            LOG.finest("Spliting files: \n" + Arrays.deepToString(files));
        } // if
        
        return split(fs, dirs, parts, files, fileCount, getBlockSize(taskStage, 
                job), isPerUnitSplit(taskStage, job), job.getTaskNumber(
                        taskStage));
    }
    
    private void sortSplitByLength(ITaskInputSplit[][] splits) {
        LOG.info("Sort input tasks by input length.");
        Arrays.sort(splits, new Comparator<ITaskInputSplit[]>() {
            @Override
            public int compare(ITaskInputSplit[] t1, ITaskInputSplit[] t2) {
                long len1 = 0;
                long len2 = 0;
                for (ITaskInputSplit split: t1) {
                    try {
                        len1 += split.getLength();
                    } catch (IOException e) {
                        LOG.warning("Can't sort split tasks.  "
                                + e.getMessage());
                    }
                }
                for (ITaskInputSplit split: t2) {
                    try {
                        len2 += split.getLength();
                    } catch (IOException e) {
                        LOG.warning("Can't sort split tasks.  "
                                + e.getMessage());
                    }
                }
                return len2 > len1 ? 1 : len2 == len1 ? 0 : -1;
            }

        });
    }
}
