package odis.mapred;

import java.io.IOException;
import java.util.logging.Level;

import odis.cowork.JobDef;
import odis.cowork.TaskWorker;
import odis.file.IRecordReader;
import odis.file.SequenceFile;
import toolbox.misc.ClassUtils;

/**
 * Default map task definition used in map reduce job
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public class MapTask extends MapTaskRunnable {
  
  public static final float REPORT_INTERVAL = 0.05f;

  private IMapper mapper;
  
  @Override
  public void configure(JobDef job, TaskWorker worker) {
    super.configure(job,worker);
    this.mapper = this.mrJob.getMapper();
    this.mapper.configure(job,this);
  }
  
  @Override
  protected void preProcess() {
    mapper.mapBegin();   
  }

  @SuppressWarnings("unchecked")
  @Override
  protected void process(IRecordReader in) throws IOException {
    long lastPos = in.getPos(), curPos=lastPos;
    ICollector collector = this;
    // allocate new key & value instances
    Class keyClass = in.getKeyClass(), valClass = in.getValueClass();
    Object key = ClassUtils.newInstance(keyClass);
    Object value = ClassUtils.newInstance(valClass);
    // process records
    while (true) {
      if (toEnd) break;
      if (!isSkip()) {  // not skipping record
        // read next key & value
        if (!in.next(key, value)) break;
        curPos = in.getPos();
        // map pair to output
        mapper.map(key, value, collector);
        if (outputError != null) {
          throw new RuntimeException("Error occur on async output", outputError);
        }
      } else {          // skipping record
        try {
          if (!in.next(key, value)) break;
          curPos = in.getPos();
          LOG.warning("Skip bad record at cursor " + cursor() + ": key=" 
              + key + ",value=" + value);
        } catch (Throwable t) {
          LOG.log(Level.WARNING, "Failed to skip bad record at " + cursor(), t);
          if(in instanceof SequenceFile.Reader) {
            long pos = ((SequenceFile.Reader)in).getPosition() + 1;
            LOG.info("Will sync from " + pos);
            ((SequenceFile.Reader)in).sync(pos);
          }
        }
      }
      // set counters
      getCounter(CT_MAPPED_IN_RECORD).inc();
      getCounter(CT_MAPPED_IN_SIZE).inc(curPos-lastPos);
      lastPos = curPos;
      // report process
      long processed = getCounter(CT_MAPPED_IN_SIZE).get();
      progress = Math.min( (float)processed / inputSize, 1.0f);
      cursor.write(cursor(), time());
    }
  }
  
  @Override
  protected void postProcess() {    
    mapper.mapEnd(this);
    progress = 1f;
  }

}
