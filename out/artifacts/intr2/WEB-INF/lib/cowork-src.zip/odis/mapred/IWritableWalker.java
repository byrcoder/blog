/**
 * 
 */
package odis.mapred;

import odis.serialize.IWritable;

/**
 * A walker interface. A writable walker provides allocation functions.
 * After calling to several allocation function, one can call reset to 
 * make the buffered (if necessary) object to be reused.
 * 
 * A typical flow of using a writable walker is:
 *   
 *      walker = new XXXWritableWalker();
 *      while (not end) {
 *          for one round {
 *              Object obj = walker.alloc();
 *              ...
 *          } // for
 *          walker.reset();
 *      } // while
 *      walker.clear();
 * 
 * @author david
 *
 */
public interface IWritableWalker {
    /**
     * 
     * Configure the walker.
     * @param objClass
     */
    public void configure(Class objClass);
    /**
     * Allocate a walker object.
     * @return returns an allocated instance.
     */
    public IWritable alloc();
    /**
     * Reset the walker for next round of allocation.
     *
     */
    public void reset();
    /**
     * Reset and clear all buffered object.
     *
     */
    public void clear();
}
