package odis.mapred;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;

/**
 * The input data format to open a reader of a source.  The source could be a
 * file, a data base, or others.  For example, currently, we mostly deal with
 * input files stored in a file system (local or dist). The processing of 
 * an input file may be split across multiple machines.  Each machine will get
 * multiple splits of {@link ITaskInputSplit}.  The input data are processed 
 * as sequences of records, implementing {@link IRecordReader}.  Files must 
 * thus be split on record boundaries.

 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 14, 2006
 * Copyright (c) 2006, Outfox Team
 */
public abstract class BasicInputFormat { 

  /**
   * Gets the input parts under svcAddr:path, use this method to define what are
   * parts to be processed under a path. For example, in indexed file, only the
   * data parts will be used as input.
   * 
   * @param svcAddr service address
   * @param path input path in this service
   * @return the part file names under this path 
   */
  public abstract String[] listParts(String svcAddr, String path) 
      throws IOException;
  
  /** 
   * Constructs an {@link IRecordReader} for an {@link ITaskInputSplit}.
   * Here we also provide information about (stage,part) and jobConf since
   * the customized {@link BasicInputFormat} may want to do some filter-like 
   * operation on the <code>split</code>.
   * 
   * @param split     the {@link ITaskInputSplit}
   * @param task      the task which needs this reader
   * @param jobConf   the job that this split belongs to
   * @return a {@link IRecordReader}
   */
  public abstract IRecordReader getRecordReader(ITaskInputSplit split, 
      TaskRunnable task, BasicInOutJobDef jobConf) throws IOException;

}