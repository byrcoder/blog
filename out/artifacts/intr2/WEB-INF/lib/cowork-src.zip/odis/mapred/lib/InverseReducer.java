package odis.mapred.lib;

import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;

public class InverseReducer extends AbstractReducer {

    public void reduce(Object key, IWritablePairWalker values,
            ICollector collector) {
        while(values.moreValue()){
            collector.collect(values.getValue(), key);
        }
    }

}
