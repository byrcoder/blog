/**
 * 
 */
package odis.mapred.lib;

import odis.mapred.IWritableWalker;
import odis.serialize.IWritable;
import toolbox.misc.ClassUtils;

/**
 * A reuse writable walker.
 * 
 * @author david
 *
 */
public class ReuseWritableWalker implements IWritableWalker {
    IWritable obj;
    public IWritable alloc() {
        return obj;
    }

    public void clear() {
    }

    public void configure(Class objClass) {
        obj = (IWritable) ClassUtils.newInstance(objClass);
    }

    public void reset() {
    }

}
