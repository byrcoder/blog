package odis.mapred.ext;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.cowork.JobDef;
import odis.cowork.TaskWorker;
import odis.file.IRecordReader;
import odis.mapred.IWritablePairWalker;
import odis.mapred.ReduceTaskRunnable;
import odis.serialize.comparator.WritableComparator;
import odis.util.MultiValueTreeMapSorter;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

public class ReduceMergeTask extends ReduceTaskRunnable {
    public static final Logger LOG = LogFormatter.getLogger(ReduceMergeTask.class.getName());

    public static ReduceMergeConf getExtensionConf() { return new ReduceMergeConf(); }

    public static final float REPORT_INTERVAL = 0.05f;
    public static final float PROCESS_START = 0.2f;  

    private ReduceMergeConf extConf;
    private IMergeReducer reducer;
    private IRecordReader[] readers;
    private IWritablePairWalker[] walkers;

    @Override
    public void configure(JobDef job, TaskWorker worker) {
        super.configure(job,worker);
        this.extConf = new ReduceMergeConf(); extConf.loadFrom(this.mrJob);
        this.reducer = extConf.getMergeReducer();
        this.reducer.configure(job,this);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void preProcess() {
        try {
            // prepare readers check consistancy
            String[] dirs = extConf.getMergeDirs();
            LOG.info("Merge dirs : " + Arrays.toString(dirs));
            if (dirs==null || dirs.length==0)
                LOG.warning("Do not merge parts in reduce? " +
                "Please use ReduceTask instead of ReduceMergeTask.");
            readers = new IRecordReader[dirs.length];
            for (int i=0; i<readers.length; i++)
                readers[i] = extConf.getMergeInputReader(i, this, mrJob);
            // prepare walkers
            walkers = new IWritablePairWalker[readers.length];
            for (int i=0; i<walkers.length; i++) {
                walkers[i] = extConf.getMergeWalker(i);
                if (walkers[i] != null)
                    walkers[i].configure(readers[i],keyCmp, mrJob.getConfig());
            }
            // prepare reducer
            reducer.reduceBegin();
        } catch (IOException e) {
            throw new RuntimeException("IOException in " + this.getClass().getName() 
                    + ".preProces()", e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void process(IRecordReader in) throws IOException {
        long totalSize = in.getSize();
        for (int i=0; i<readers.length; i++)
            totalSize += (readers[i]==null? 0:readers[i].getSize());

        walker.configure(in, keyCmp, mrJob.getConfig());

        // initialize priority queue, push value walker and all the merge walkers into it
        MultiValueTreeMapSorter<Object, Pair<IWritablePairWalker, Integer> > keyMerger = 
            new MultiValueTreeMapSorter<Object, Pair<IWritablePairWalker, Integer> >(keyCmp);
        if (walker.moreKey()) {
            keyMerger.put(walker.getKey(), new Pair<IWritablePairWalker, Integer>(walker, -1));
        }
        for (int i=0; i<walkers.length; i++) {
            if (walkers[i] != null && walkers[i].moreKey()) {
                Pair<IWritablePairWalker, Integer> walkerPair = new Pair<IWritablePairWalker, Integer>(walkers[i], i);
                keyMerger.put(walkers[i].getKey(), walkerPair);
            }
        }
        
        // process the merge
        IWritablePairWalker values = null;
        IWritablePairWalker[] mergeValues = new IWritablePairWalker[walkers.length];
        while (!keyMerger.isEmpty()) {
            // check if task is forced to stop
            if (toEnd) break;
            
            MultiValueTreeMapSorter<Object, Pair<IWritablePairWalker, Integer> >.Pair keyValues = 
                keyMerger.remove();
            
            // prepare key and merge values
            Object curKey = keyValues.getKey();
            for (Pair<IWritablePairWalker, Integer> walkerPair : keyValues.getValues()) {
                int idx = walkerPair.getSecond();
                if (idx < 0) {
                    values = walkerPair.getFirst();
                } else {
                    mergeValues[idx] = walkerPair.getFirst();
                }
            }
            
            // reduce
            reducer.reduce(curKey, values, mergeValues, this);
            
            // fill in more keys for walkers who consumed a key in the reduce
            for (Pair<IWritablePairWalker, Integer> walkerPair : keyValues.getValues()) {
                int idx = walkerPair.getSecond();
                if (idx < 0) {
                    values = null;
                    if (walker.moreKey()) keyMerger.put(walker.getKey(), walkerPair);
                } else {
                    mergeValues[idx] = null;
                    IWritablePairWalker tmpWalker = walkerPair.getFirst(); 
                    if (tmpWalker.moreKey()) 
                        keyMerger.put(tmpWalker.getKey(), walkerPair);
                }
            }
            
            // count the doneSize
            long doneSize = in.getPos();
            for (IRecordReader reader : readers) {
                if (reader != null) {
                    doneSize += reader.getPos();
                }
            }
            
            // set counters
            getCounter(CT_REDUCE_IN_RECORD).inc();
            getCounter(CT_REDUCE_IN_SIZE).set(doneSize);          
            // update progress
            progress = PROCESS_START + (1-PROCESS_START)*doneSize/totalSize;
            cursor.write(cursor(), time());
        }      
    }

    @Override
    protected void postProcess() {
        try {
            // close readers
            if (readers!=null)
                for (int i=0; i<readers.length; i++)
                    if (readers[i]!=null) readers[i].close();
            reducer.reduceEnd(this);
            progress = 1f;
        } catch (IOException e) {
            throw new RuntimeException("IOException in " + this.getClass().getName() 
                    + ".postProcess()", e);
        }
    }

    // interface for test case  
    protected void setTaskWorker(TaskWorker runner) {
        this.worker = runner;
    }
    protected void setWalker(IWritablePairWalker walker) {
        this.walker = walker;
    }
    protected void setKeyComparator(WritableComparator kc) {
        this.keyCmp = kc;
    }

}
