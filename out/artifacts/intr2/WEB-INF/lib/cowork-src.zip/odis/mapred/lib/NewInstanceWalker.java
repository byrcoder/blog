package odis.mapred.lib;

import odis.cowork.TaskFatalException;

/**
 * The walker that create new instance for each walk
 * @author david
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the value
 */
public class NewInstanceWalker<K, V> extends PairWalkerBase<K, V> {

  @SuppressWarnings("unchecked")
  protected void allocNextKey() {
    try {
      nextKey = (K) in.getKeyClass().newInstance();
    } catch (Exception e) {
      throw new TaskFatalException("Cannot allocate key for NewInstancePairWalker",e);
    }
  };
  @SuppressWarnings("unchecked")
  protected void allocNextValue() {
    try {
      nextValue = (V) in.getValueClass().newInstance();
    } catch (Exception e) {
      throw new TaskFatalException("Cannot allocate value for NewInstancePairWalker",e);
    }
  };
}
