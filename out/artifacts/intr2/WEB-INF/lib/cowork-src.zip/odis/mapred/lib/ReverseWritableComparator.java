package odis.mapred.lib;

import odis.serialize.IWritable;
import odis.serialize.comparator.WritableComparator;

public class ReverseWritableComparator extends WritableComparator {
    
    private WritableComparator comp;
    public ReverseWritableComparator(WritableComparator comp) {
        super(comp.getComparableClass());
        this.comp = comp;
    }
    
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        return -comp.compare(b1, s1, l1, b2, s2, l2);
    }
    
    public Class<? extends IWritable> getComparableClass() {
        return comp.getComparableClass();
    }

    public int compare(Object o1, Object o2) {
        return -comp.compare(o1, o2);
    }
    
}
