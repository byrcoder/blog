package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;

public class SeqFileOutputFormat extends GenericFileOutputFormat {  

  protected IRecordWriter getRecordWriter(int channel, 
      TaskRunnable task, BasicInOutJobDef job) throws IOException {
    // setup file system, session file and target file
    setup(channel,task,job);
    // get writer
    Class keyClass = getKeyClass(task.getStageIdx(),channel,job);
    Class valClass = getValueClass(task.getStageIdx(),channel,job);
    // use compressed sequence file?
    int compressBlock = getCompressSize(job,getMrPhase(task.getStageIdx(), job),channel);
    boolean objectCompression = getObjectCompression(job, getMrPhase(task.getStageIdx(), job), channel);
    CompressAlgo compressAlgo = getCompressAlgo(job, getMrPhase(task.getStageIdx(), job), channel);
    if (compressBlock>0)
      return new SequenceFile.CompressedWriter(fs, new Path(sessionFile), 
              keyClass, valClass, true, compressBlock, objectCompression, compressAlgo);
    else if (compressBlock==0)
      return new SequenceFile.CompressedWriter(fs, new Path(sessionFile), 
              keyClass, valClass, true, SequenceFile.CompressedWriter.DEFAULT_BLOCK_SIZE, 
              objectCompression, compressAlgo);
    else
      return new SequenceFile.Writer(fs, new Path(sessionFile), keyClass, valClass, true);
  }

}
