package odis.mapred.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;

import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.ITaskInputSplit;
import odis.serialize.IWritable;

/**
 * A section of an input file for a task.  An implementation of 
 * {@link ITaskInputSplit}. A TaskRunnable would take several 
 * {@link ITaskInputSplit}(s) as its input for processing.
 * 
 * Properties (other than those in ITaskInputSplit):
 *   fsName
 *   start
 *   length
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public class InputFileSplit implements ITaskInputSplit { 
  
  private final static long WHOLE_PART_LENGTH = -1;
 
  private String fs;   // filesystem name, e.g "local", or "host:port";
  private String path; // file name
  private String part; // part name, i.e. part-xxxxx
  private long start;  // start position
  private long length; // length of the split  
  
  public InputFileSplit() {}

  /**
   * 
   * @param fs
   * @param path
   * @param part
   * @param start
   * @param length
   */
  public InputFileSplit(String fs, String path, String part, long start, 
          long length) {
    this.fs = fs; this.path = path;    
    this.part = part; this.start = start; this.length = length;
  }

  public InputFileSplit(String fs, String path, String part) {
      // length 0 means the whole file
      this(fs, path, part, 0, WHOLE_PART_LENGTH); 
  }
  
  public String getSource() {
    return BasicInOutJobDef.getServiceUrl(fs, path);
  }

  public String getPart() {
    return part + ":" + start + "+" + length;
  }
  
  public String getFsName() { 
      return fs;
  }
  public File getFile() { 
      return new File(path, part); 
  } 
  public long getStart() { 
      return start; 
  }
  public long getLength() throws IOException {
    if (length == WHOLE_PART_LENGTH) 
      length = FileSystem.getNamed(fs).getLength(new Path(getFile()));
    return length;
  }
  
  public String toString() {
    return getSource() + "# " + getPart();
  }
  
  @Override
  public boolean equals(Object o) {
      if (o == null || o.getClass() != this.getClass()) 
          return false;
      InputFileSplit that = (InputFileSplit) o;
      return this.start == that.start && this.length == that.length &&
          this.fs.equals(that.fs) && this.part.equals(that.part) && 
          this.path.equals(that.path);
  }
  
  @Override
  public int hashCode() {
      return (int)(this.length ^ this.start ^ this.fs.hashCode() 
              ^ this.path.hashCode() ^ this.part.hashCode()); 
  }

  ////////////////////////////////////////////
  // Writable methods
  ////////////////////////////////////////////

  public void writeFields(DataOutput out) throws IOException {
    out.writeUTF(fs);
    out.writeUTF(path);
    out.writeUTF(part);
    out.writeLong(start);
    out.writeLong(length);
  }
  
  public void readFields(DataInput in) throws IOException {
    fs = in.readUTF();
    path = in.readUTF();
    part = in.readUTF();
    start = in.readLong();
    length = in.readLong();
  }
 
  public IWritable copyFields(IWritable value) {
    InputFileSplit that = (InputFileSplit) value;
    this.fs = that.fs; this.path = that.path; this.part = that.part;
    this.start = that.start; this.length = that.length;
    return this;
  }

}
