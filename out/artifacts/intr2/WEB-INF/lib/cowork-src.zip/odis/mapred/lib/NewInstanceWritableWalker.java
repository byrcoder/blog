/**
 * 
 */
package odis.mapred.lib;

import odis.mapred.IWritableWalker;
import odis.serialize.IWritable;
import toolbox.misc.ClassUtils;

/**
 * A walker allocating new instance each time.
 * 
 * @author david
 *
 */
public class NewInstanceWritableWalker implements IWritableWalker {
    protected Class objClass;
    public IWritable alloc() {
        return (IWritable) ClassUtils.newInstance(objClass);
    }

    public void clear() {
    }

    public void configure(Class objClass) {
        this.objClass = objClass;
    }

    public void reset() {
    }
}
