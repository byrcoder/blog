/**
 * @(#)SkipBadRecordSeqFileInputFormat.java, 2009-7-15. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.ITaskInputSplit;

/**
 * 能跳过出错数据块的 input format
 * @author jiangfy
 *
 */
public class SkipBadRecordSeqFileInputFormat extends SeqFileInputFormat {
    
    @Override
    public IRecordReader getRecordReader(ITaskInputSplit split, 
            TaskRunnable task, BasicInOutJobDef job) throws IOException {

        assert split instanceof InputFileSplit;    
        InputFileSplit fSplit = (InputFileSplit) split;

        // open the file and seek to the start of the split
        SequenceFile.Reader in = new SequenceFile.Reader(
                FileSystem.getNamed(fSplit.getFsName()), 
                new Path(fSplit.getFile()), fSplit.getStart(), fSplit.getLength());
        return new SkipBadRecordReader(in);
    }  

}
