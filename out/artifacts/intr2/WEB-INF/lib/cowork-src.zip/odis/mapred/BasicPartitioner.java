package odis.mapred;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import toolbox.misc.UnitUtils;

/**
 * Partitions the key space.  A partition writer is created for each reduce task.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public abstract class BasicPartitioner {

  /**
   * Configurate this partitioner with jobdef.
   * @param job the job configuration
   */
  protected void configurate(BasicInOutJobDef job) {}
  
  /**
   * Returns the paritition number for a given entry given the total number of
   * partitions.  Typically a hash function on all or a subset of the key.
   * 
   * @param key the entry key
   * @param value the entry value
   * @param numPartitions the number of partitions
   * @return the partition number
   */
  public abstract int getPartition(Object key, Object value, int numPartitions);

  /**
   * Return {@link IRecordWriter}s for writing map outputs
   *
   * @param task  task that wants to get partition writers
   * @param job   job configuration
   * @return {@link IRecordWriter}s for writing map outputs
   */
  @Deprecated
  protected abstract IRecordWriter[] getPartitionWriters(TaskRunnable task, 
      BasicInOutJobDef job) throws IOException;
  
  /**
   * Get the partition file name written by <code>mapIdx</code> for 
   * <code>reduceIdx</code>.
   * @param mapIdx      part number of map
   * @param reduceIdx   part number of reduce
   * @return partition  file name
   */
  protected abstract String getPartitionName(int mapIdx, int reduceIdx);
  
  /**
   * Generate input file path for a task (e.g. reduce task) who does 
   * shuffle/merge.  This task (e.g. reduce task) is at the next stage of the
   * task (e.g. map task) where the partitioner is used.  The path is a
   * relative path to the local root of previous stage task (e.g. map task)
   * 
   * @param mergeTask  the task
   * @param job        job configuration
   * @return input splits for next stage
   */
  public abstract String[] getMergeInputPaths(TaskRunnable mergeTask, 
     BasicInOutJobDef job);
  
  /**
   * Return paths for writing map outputs
   * @param task
   * @param job
   * @return
   * @throws IOException
   */
  public abstract String[] getPartitionOutputPaths(TaskRunnable task, 
      BasicInOutJobDef job) throws IOException;
    
  protected static int getMrPhase(int taskStage, BasicInOutJobDef conf) {
    return conf.getIoPhase(BasicInOutJobDef.TYPE_PARTITIONER,taskStage);
  }
  protected static Class getKeyClass(int taskStage, BasicInOutJobDef conf) {
    return conf.getMergeKeyClass(getMrPhase(taskStage,conf));
  }
  protected static Class getValClass(int taskStage, BasicInOutJobDef conf) {
    return conf.getMergeValClass(getMrPhase(taskStage,conf));
  }
  
  private static final String PROP_COMPRESS = "mapred.partitioner.compress";
  private static final String PROP_COMPRESS_ALGO = "mapred.partitioner.compress.algorithm";
  private static final String PROP_OBJECT_COMPRESS = "mapred.partitioner.object_compress";
  
  public static void setCompress(BasicInOutJobDef job) {
    setCompress(job,job.getIoPhaseNum()-1);
  }
  
  @Deprecated
  public static void setCompress(BasicInOutJobDef job, int compressBlockSize, boolean objectCompressed) {
      setCompress(job, job.getIoPhaseNum()-1, compressBlockSize, objectCompressed);
  }
  
  public static void setCompress(BasicInOutJobDef job, int mrPhase) {
      setCompress(job, mrPhase, SequenceFile.DEFAULT_COMPRESS_ALGO);
  }
  private static final int DEFAULT_PARTITION_COMPRESS_BLOCK_SIZE = (int)(64 * UnitUtils.K);
  
  @Deprecated
  public static void setCompress(BasicInOutJobDef job, int mrPhase, 
          int compressBlockSize, boolean objectCompressed) {
      setCompress(job, mrPhase, compressBlockSize, objectCompressed, 
              SequenceFile.DEFAULT_COMPRESS_ALGO);
  }
  
  @Deprecated
  public static void setCompress(BasicInOutJobDef job, int mrPhase, 
          int compressBlockSize, boolean objectCompressed, CompressAlgo compressAlgo) {
      setCompress(job, mrPhase, compressAlgo);
  }
  
  @Deprecated
  protected static boolean isObjectCompress(BasicInOutJobDef job, int mrPhase) {
    return job.getConfig().getBoolean(PROP_OBJECT_COMPRESS+"."+mrPhase, false);
  }
  
  @Deprecated
  protected static int getCompressBlockSize(BasicInOutJobDef job, int mrPhase) {
      return job.getConfig().getInt(PROP_COMPRESS + "." + mrPhase, -1);
  }
  
  public static final String PROP_MAP_OUTPUT_COMPRESS = "map.output.compress";
  public static boolean getCompress(BasicInOutJobDef job, int mrPhase) {
      if (getCompressBlockSize(job, mrPhase) >= 0) return true;
      return job.getConfig().getBoolean(PROP_MAP_OUTPUT_COMPRESS + "." + mrPhase, false);      
  }
  
  public static void setCompress(BasicInOutJobDef job, int mrPhase, CompressAlgo algo) {
      job.getConfig().setBoolean(PROP_MAP_OUTPUT_COMPRESS + "." + mrPhase, true);
      job.getConfig().setProperty(PROP_COMPRESS_ALGO + "." + mrPhase, algo.byteValue());
  }
  
  public static CompressAlgo getCompressAlgo(BasicInOutJobDef job, int mrPhase) {
      byte b = job.getConfig().getByte(PROP_COMPRESS_ALGO + "." + mrPhase, 
              SequenceFile.DEFAULT_COMPRESS_ALGO.byteValue());
      return CompressAlgo.get(b);
  }

}
