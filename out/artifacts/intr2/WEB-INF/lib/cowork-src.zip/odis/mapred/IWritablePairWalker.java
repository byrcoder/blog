package odis.mapred;

import java.util.Comparator;

import odis.file.IRecordReader;

import org.apache.commons.configuration.Configuration;

/**
 * The class for walking through pairs of (key, value).  Each distinct key 
 * corresponds to a set of values like:
 * (k1, v11), ..., (k1, v1n), (k2, v21), ..., (k2, v2n), ...
 * NOTE: 1) You must fetch the first key after a call to moreKey() when if 
 *       moreKey() returns true.
 *       2) You need not walk through all values before calling the next 
 *          moreKey() as the following example shows.
 * 
 * Usage:
 *   IWritablePairWalker walker;
 *   
 *   while (walker.moreKey()) {
 *       K key = walker.getKey();
 *       while (walker.moveValue()) {
 *           V val = walker.getValue();
 *           ...
 *           if (some condition)
 *               break;
 *           ...
 *       } // while
 *   } // while
 * 
 * @author Li Zhuang, David
 */
public interface IWritablePairWalker<K, V> extends IValueWalker<V> {
    /**
     * Configures the walker.
     * @param in  the IRecordReader for reading pairs
     * @param cmp  the comparator that indicates whether a new key appears
     * @param conf  the configuration
     */
    public void configure(IRecordReader in, Comparator<K> cmp, 
            Configuration conf);
    
    /**
     * Moves cursor to next key (!=current key).
     * @return whether cursor is successfully moved to a new key.
     */
    public boolean moreKey();  
    
    /**
     * Gets key at the current cursor
     */
    public K getKey();    
}