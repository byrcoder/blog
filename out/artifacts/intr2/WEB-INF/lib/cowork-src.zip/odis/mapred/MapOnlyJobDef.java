package odis.mapred;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;

import odis.cowork.CoWorkUtils;
import odis.cowork.TaskRunnable;
import odis.io.Path;
import odis.mapred.lib.GenericFileSplitter;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import toolbox.misc.ClassUtils;

/**
 * Job definition for map only job
 * 
 * INPUT -(map)-> PARTITIONER -> [MERGER] -> OUTPUT
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public class MapOnlyJobDef extends BasicInOutJobDef {
  
  @Override
  protected String getTypeName() { return "MapOnly"; }
  protected String getTypeClass() { return MapOnlyJobDef.class.getName(); }

  protected static final int TASK_STAGE_MAP = 0;
  protected static final int IO_PHASE_MAP = 0;
  
  public MapOnlyJobDef() { super(); }
  
  @SuppressWarnings("unchecked") @Override
  protected void staticDefine() {
    // definition
    this.stageNames = new String[]{"map-only"};
    this.stageXfaces = new String[]{MapOnlyTaskRunnable.class.getName()};
    // default parameters
    this.jobName = "job";
    this.taskClasses = new String[]{MapOnlyTask.class.getName()};
    this.taskNumbers = new int[]{1};
    this.workerNum = 1;
    this.taskPerMachine = new int[]{0};
    this.exclusiveOwn = new boolean[]{false};
  }

  @Override
  public int getIoPhase(int type, int stage) { return IO_PHASE_MAP; }
  @Override
  public int getIoPhaseNum() { return 1; }
  @Override
  public int getStage(int type, int ioPhase) { return TASK_STAGE_MAP; }
  
  private ITaskInputSplit[][] inputSplits=null;
  
  private void computeSplits() throws IOException {
    inputSplits = getInputSplitter().split(TASK_STAGE_MAP, this);
    if (inputSplits==null) {
      LOG.info("No input splits got"); return;
    }
    if (LOG.isLoggable(Level.INFO)) {
      int count = 0;
      for (int i = 0; i < inputSplits.length; i ++)
        count += inputSplits[i].length;
      LOG.info("Totally " + count + " splits for this job.");
    } // if
    for (int i=0; i<inputSplits.length; i++)
      LOG.fine("Split " + i + ": " + Arrays.toString(inputSplits[i]));    
  }
  
  protected ITaskInputSplit[] getInputSplits(int part) throws IOException {
    if (inputSplits==null) {
        // load cached splits
        String cachedSplitsString = this.getConfig().getString(
                "mapred.input.cached_splits");
        if (cachedSplitsString != null) {
            inputSplits = CoWorkUtils.stringToSplits(cachedSplitsString);
        } else {
            computeSplits();
        }
    }
    if (inputSplits==null) return new ITaskInputSplit[0];
    return inputSplits[part];
  }  
  
  /**
   * Compute the splits and save it into job def.
   */
  @Override
  protected void prepareBeforeSubmit() throws IOException {
      super.prepareBeforeSubmit();
      computeSplits();
      String s = CoWorkUtils.splitsToString(inputSplits);
      this.getConfig().setProperty("mapred.input.cached_splits", s);
  }
  
  // set & get map class
  public void setMapTaskRunnable(Class<? extends TaskRunnable> c) {
    super.setTaskClass(TASK_STAGE_MAP, c);
    setExtMapper(c.getName());
  }
  public Class<? extends TaskRunnable> getMapTaskRunnable() {
    return super.getTaskClass(TASK_STAGE_MAP);
  }
  
  // set & get map task number
  public void setMapNumber(int num) {
    super.setTaskNumber(TASK_STAGE_MAP, num);
  }
  public int getMapNumber() {
    return super.getTaskNumber(TASK_STAGE_MAP);
  }
  
  // check progress
  public void setCheckMapProgress(boolean b) {
    super.setCheckProgress(TASK_STAGE_MAP, b);
  }
  
  // splitter
  public void setInputSplitter(Class<? extends BasicSplitter> splitter) {
    super.setInputSplitter(IO_PHASE_MAP,splitter);
  }
  protected BasicSplitter getInputSplitter() {
    BasicSplitter splitter=super.getInputSplitter(IO_PHASE_MAP);
    if (splitter==null) splitter = new GenericFileSplitter();
    return splitter;
  }

  // input dirs/files (= input of map)
  // all input dirs/files are from the same file system defined in instance
  @Deprecated
  public int addInputDir(File dir) {
    return addInputDir(dir, SeqFileInputFormat.class);
  }
  public int addInputDir(Path dir) {
      return addInputDir(dir, SeqFileInputFormat.class);
  }
  @Deprecated
  public int addInputDir(File dir, Class<? extends BasicInputFormat> format) {
    String svcAddr = getDefaultFsName();
    return super.addInputChannel(IO_PHASE_MAP,svcAddr,dir.toString(),format);
  }
  public int addInputDir(Path dir, Class<? extends BasicInputFormat> format) {
      String svcAddr = getDefaultFsName();
      return super.addInputChannel(IO_PHASE_MAP,svcAddr,dir.toString(),format);
  }
  @Deprecated
  public int addInputDir(String fsName, File dir) {
      return addInputDir(fsName, dir, SeqFileInputFormat.class);
  }
  public int addInputDir(String fsName, Path dir) {
      return addInputDir(fsName, dir, SeqFileInputFormat.class);
  }
  @Deprecated
  public int addInputDir(String fsName, File dir, 
          Class<? extends BasicInputFormat> format) {
      return super.addInputChannel(IO_PHASE_MAP,fsName,dir.toString(),format);
  }
  public int addInputDir(String fsName, Path dir, 
          Class<? extends BasicInputFormat> format) {
      return super.addInputChannel(IO_PHASE_MAP,fsName,dir.toString(),format);
  }
  protected int getInputChannelNum() {
    return super.getInputChannelNum(IO_PHASE_MAP);
  }
  protected String getInputPath(int channel) {
    return super.getInputPath(IO_PHASE_MAP,channel);
  }  
  protected BasicInputFormat getInputFormat(String svcUrl) {
    BasicInputFormat format = super.getInputFormat(IO_PHASE_MAP,svcUrl);
    if (format==null) format = new SeqFileInputFormat();
    return format;
  }

  // output dirs/files (= output of reduce)
  // all output dirs/files must write to the same file system in instance
  @Deprecated
  public void addOutputDir(int channel, File dir, Class key, Class value) {
    this.addOutputDir(channel, dir, key, value, SeqFileOutputFormat.class);
  }
  public void addOutputDir(int channel, Path dir, Class key, Class value) {
      this.addOutputDir(channel, dir, key, value, SeqFileOutputFormat.class);
  }
  @Deprecated
  public void addOutputDir(int channel, File dir, Class key, 
          Class value, Class<? extends BasicOutputFormat> format) {
      addOutputDir(channel, new Path(dir), key, value, format);
  }
  public void addOutputDir(int channel, Path dir, Class key, 
      Class value, Class<? extends BasicOutputFormat> format) {
    String svcAddr = getDefaultFsName();
    super.addOutputChannel(getIoPhaseNum() - 1, channel, 
        svcAddr, dir.toString(), key, value, format);
  }
  
  /**
   *  add By tuqc
   */
  public void addOutputDir(String fsName, int channel, Path dir, Class key, 
	      Class value, Class<? extends BasicOutputFormat> format) {
	  super.addOutputChannel(getIoPhaseNum() - 1, channel, 
		        fsName, dir.toString(), key, value, format);
  }
  
  protected int getOutputChannelNum() {
    return super.getOutputChannelNum(getIoPhaseNum() - 1);
  }
  protected String getOutputPath(int channel) {
    return super.getOutputPath(getIoPhaseNum() - 1, channel);
  }  
  protected Class getOutputKeyClass(int channel) {
    return super.getOutputKeyClass(getIoPhaseNum() - 1, channel);
  }
  protected Class getOutputValueClass(int channel) {
    return super.getOutputValClass(getIoPhaseNum() - 1, channel);
  }
  protected BasicOutputFormat getOutputFormat(int channel) {
    BasicOutputFormat out = super.getOutputFormat(getIoPhaseNum() - 1, channel);
    if (out==null) out = new SeqFileOutputFormat();
//    if (out==null) out = new BufferedSeqFileOutputFormat();
    return out;
  }
  
  // Backup execution options
  public void setMapBackupNum(int copy) { 
      super.setMaxBackupNum(TASK_STAGE_MAP, copy); 
  }
  public void setMapBackupLag(float lag) { 
      super.setMaxProgressLag(TASK_STAGE_MAP, lag); 
  }
  protected float getMaxProgressLag(int stage) {
      return getConfig().getFloat(PROP_BACKUP_LAG+"."+stage, 0.5f);
  }

  // Other features
  public void setPerUnitSplit(boolean b) {
    setTaskNumber(TASK_STAGE_MAP, PER_UNIT_TASK_NUM);
    super.setPerUnitSplit(IO_PHASE_MAP, b);
  }
  protected boolean isPerUnitSplit() {    
    return super.isPerUnitSplit(IO_PHASE_MAP);
  }
  public void setSplitBlockSize(int n) {
    super.setSplitBlockSize(IO_PHASE_MAP,n);
  }
  protected int getSplitBlockSize() {
    return super.getSplitBlockSize(IO_PHASE_MAP);
  }
  
  protected static final String PR_MAP_MAPPER = "mapred.map.mapper";
  public void setMapper(Class<? extends IMapper> mapper) {
    getConfig().setPropClass(PR_MAP_MAPPER+"."+IO_PHASE_MAP, mapper, IMapper.class);
  }
  public IMapper getMapper() {
    Class cls = getConfig().getPropClass(PR_MAP_MAPPER+"."+IO_PHASE_MAP, 
        IMapper.class, null);
    if (cls!=null)
      return (IMapper) ClassUtils.newInstance(cls);
    else return null;
  }
  
  public void setExtMapper(String mapperName) {
    getConfig().setProperty(PR_MAP_MAPPER+".ext", mapperName);
  }
  public String getExtMapper() {
    return getConfig().getString(PR_MAP_MAPPER+".ext");
  }
  
  protected boolean isValid() {
    if (!super.isValid()) return false;
    if (getMapper()==null && getExtMapper()==null) {
      LOG.warning("Please set mapper class: see setMapper() or set**Maper()");
      return false;
    }
    try {
      if (isPerUnitSplit()) {
        if (inputSplits==null) computeSplits();
        this.setTaskNumber(TASK_STAGE_MAP, inputSplits.length);
      }
    } catch (IOException e) {
      LOG.log(Level.WARNING, "Cannot compute splits for per unit split", e);
      return false;
    }
    // check task number
    for (int i=0; i<taskNumbers.length; i++)
      if (taskNumbers[i]<=0) {
        LOG.warning("Invalid: Task number at stage " + i + ": " 
                + taskNumbers[i]);
        return false; // task number at each stage must > 0
      }
    return true;
  }
}
