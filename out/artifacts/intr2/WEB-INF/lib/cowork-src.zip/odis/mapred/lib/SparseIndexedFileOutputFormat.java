/**
 * @(#)SparseIndexedFileOutputFormat.java, 2007-9-7. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.SparseIndexedFile;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;

/**
 * Output format for {@link odis.file.SparseIndexedFile}.
 * @author river
 */
public class SparseIndexedFileOutputFormat extends GenericFileOutputFormat {

    @Override
    protected IRecordWriter getRecordWriter(int channel, TaskRunnable task,
            BasicInOutJobDef job) throws IOException {
        
        // setup file system, session file and target file
        setup(channel, task, job);
        
        Class keyClass = getKeyClass(task.getStageIdx(), channel, job);
        Class valClass = getValueClass(task.getStageIdx(), channel, job);
        
        int skipSize = getSparseIndexSkipSize(job, getMrPhase(task.getStageIdx(), job), channel);
        if (skipSize <= 0) {
            return new SparseIndexedFile.Writer(fs, new Path(sessionFile), 
                    keyClass, valClass, true);
        } else {
            return new SparseIndexedFile.Writer(fs, new Path(sessionFile), 
                    keyClass, valClass, skipSize, true);
        }
    }

}
