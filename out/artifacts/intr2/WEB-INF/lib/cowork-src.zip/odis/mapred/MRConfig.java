package odis.mapred;

public interface MRConfig {

    public static final String MERGED_OUTPUT_PREFIX = ".merged";
    
    public static final String MAP_OUT_BUFFEER_SPILL_PERCENT = "map.buffer.spill.percent";
    
    public static final String MAP_COMBINE_MIN_SPILLS = "map.combine.min-spills";    
    
    public static final String MAP_SORT_MERGE_FACTOR = "map.sort.merge.factor";
    
    public static final String SHUFFLE_MAX_FETCH_FAILURES = "cowork.shuffle.max-failure";
    
    public static final String SHUFFLE_READ_ERROR_REPORT = "cowork.shuffle.report-failure";
    
    public static final String SHUFFLE_CONNECT_TIMEOUT = "cowork.shuffle.connect-timeout";
    
    public static final String SHUFFLE_READ_TIMEOUT = "cowork.shuffle.read-timeout";
    
    public static final String SHUFFLE_INPUT_BUFFER_PERCENT = "cowork.shuffle.input-buffer-percent";
    
    public static final String IO_SORT_FACTOR = "cowork.io.sort-factor";
    
    public static final String REDUCE_MEMORY_TOTAL_BYTES = "cowork.reduce.total-memory";
    
    public static final String REDUCE_MEMTOMEM_THRESHOLD = "cowork.reduce.memtomem-threshold";
    
    public static final String SHUFFLE_MERGE_EPRCENT = "cowork.shuffle.merge-percent";
    
    public static final String REDUCE_MEMTOMEM_ENABLED = "cowork.reduce.memtomem-enable";
    
    public static final String REDUCE_INPUT_BUFFER_PERCENT = "cowork.reduce.buffer-percent";
    
    public static final String SHUFFLE_PARALLEL_COPIES = "cowork.shuffle.copies";
    
    public static final String MERGER_BINARY_SEARCH_SKIP = "cowork.merger.search.skip";
    
    public static final int MAX_DONE_MSG_LENGTH = 10240;
}
