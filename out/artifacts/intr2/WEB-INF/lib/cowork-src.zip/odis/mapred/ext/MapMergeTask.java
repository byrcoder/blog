package odis.mapred.ext;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.cowork.JobDef;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskWorker;
import odis.file.IRecordReader;
import odis.file.SequenceFile;
import odis.mapred.ITaskInputSplit;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MRConfig;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MapTaskRunnable;
import odis.mapred.RangePairWalker;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;
import odis.tools.SeqFileHelper;
import odis.util.MultiValueTreeMapSorter;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

public class MapMergeTask extends MapTaskRunnable {
    private static final Logger LOG = LogFormatter.getLogger(MapMergeTask.class);

    public static final float REPORT_INTERVAL = 0.05f;

    private MapMergeConf extConf;

    private IMergeMapper mapper;

    private WritableComparator keyCmp;

    private IRecordReader[] readers;

    private IWritablePairWalker[] walkers;

    @Override
    public void configure(JobDef job, TaskWorker worker) {
        super.configure(job, worker);
        extConf = new MapMergeConf();
        extConf.loadFrom(job);
        mapper = extConf.getMergeMapper();
        mapper.configure(job, this);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void preProcess() {
        try {
            // prepare readers check consistancy
            String[] dirs = extConf.getMergeDirs();
            if (dirs == null || dirs.length == 0)
                LOG.warning("No merge parts in map ");

            /* int mapNum = mrJob.getMapNumber(); */
            readers = new IRecordReader[dirs.length];
            Class keyClass = null;
            for (int i = 0; i < dirs.length; i++) {
                if (dirs[i] == null)
                    continue;
                readers[i] = extConf.getMergeInputReader(i, this, mrJob);
                Class cls = readers[i].getKeyClass();
                if (keyClass != null && cls != keyClass) {
                    throw new TaskFatalException(
                            "Merge channels have different key class");
                } else {
                    keyClass = cls;
                }
            }

            BinaryComparator bc = extConf.getKeyComparator();
            if (bc == null)
                bc = WritableRegistry
                        .getBinaryComparator((Class<? extends IWritable>) keyClass);
            keyCmp = new WritableComparator(
                    (Class<? extends IWritableComparable>) keyClass, bc);

            IWritableComparable startKey = null, endKey = null;
            if (extConf.getMergeSpeedUp() > 1) {
                extConf.calculateSpeedup(this, mrJob);
                startKey = getStartKey();
                endKey = getEndKey();
                LOG.info("Debug: partIdx=" + this.getPartIdx() + ", startKey=" + startKey + ", endKey=" + endKey);
            }
            
            // prepare walkers
            walkers = new IWritablePairWalker[readers.length];
            for (int i = 0; i < walkers.length; i++) {
                walkers[i] = extConf.getMergeWalker(i);
                if (walkers[i] != null) {                    
                    if (extConf.getMergeSpeedUp() > 1) {
                        //speed up
                        if (startKey == null && endKey == null && this.getPartIdx() >= extConf.getMergePartNum(mrJob)) {
                            LOG.info("Debug: Empty input for " + getPartIdx());
                            walkers[i] = null;
                        }else {
                            walkers[i] = new RangePairWalker(startKey, endKey, walkers[i]);
                            if (startKey  != null) {
                                SeqFileHelper.moveNearTo((SequenceFile.Reader)readers[i], startKey, 
                                        mrJob.getConfig().getLong(MRConfig.MERGER_BINARY_SEARCH_SKIP, SeqFileHelper.DEFAULT_SKIP));
                                LOG.info("Debug: move reader to " + readers[i].getPos());
                            }
                        }
                    }
                    if (walkers[i] != null)
                        walkers[i].configure(readers[i], keyCmp, this.mrJob.getConfig());
                }
            }
            // prepare reducer
            mapper.mapBegin();
        } catch (IOException e) {
            throw new RuntimeException("IOException in "
                    + this.getClass().getName() + ".preProces()", e);
        }

    }

    @SuppressWarnings("unchecked")
    @Override
    protected void processSplits(MapReduceJobDef mrJob, ITaskInputSplit[] splits)
            throws IOException {

        assert splits == null || splits.length == 0;

        long totalSize = 0;
        for (int i = 0; i < readers.length; i++)
            totalSize += (readers[i] == null ? 0 : readers[i].getSize());

        // initialize priority queue
        MultiValueTreeMapSorter<Object, Pair<IWritablePairWalker, Integer> > keyMerger = 
            new MultiValueTreeMapSorter<Object, Pair<IWritablePairWalker, Integer> >(keyCmp);
        for (int i=0; i<walkers.length; i++) {
            if (walkers[i] != null && walkers[i].moreKey()) {
                Pair<IWritablePairWalker, Integer> walkerPair = new Pair<IWritablePairWalker, Integer>(walkers[i], i);
                keyMerger.put(walkers[i].getKey(), walkerPair);
            }
        }
        
        // process the merge
        IWritablePairWalker[] mergeValues = new IWritablePairWalker[walkers.length];
        Arrays.fill(mergeValues, null);
        
        while (!keyMerger.isEmpty()) {
            
            if (toEnd) break;
            
            MultiValueTreeMapSorter<Object, Pair<IWritablePairWalker, Integer> >.Pair keyValues = 
                keyMerger.remove();
            
            // prepare key and merge values
            Object curKey = keyValues.getKey();
            for (Pair<IWritablePairWalker, Integer> walkerPair : keyValues.getValues()) {
                mergeValues[walkerPair.getSecond()] = walkerPair.getFirst();
            }
            
            // map
            mapper.map(curKey, mergeValues, this);
            
            // fill in more keys for walkers who consumed a key in the reduce
            for (Pair<IWritablePairWalker, Integer> walkerPair : keyValues.getValues()) {
                mergeValues[walkerPair.getSecond()] = null;
                IWritablePairWalker walker = walkerPair.getFirst(); 
                if (walker.moreKey()) 
                    keyMerger.put(walker.getKey(), walkerPair);
            }
            
            // release the key values pair into buffer
            keyMerger.releasePair(keyValues);
            
            // count the done size
            long doneSize = 0;
            for (IRecordReader reader : readers) {
                if (reader != null) {
                    doneSize += reader.getPos();
                }
            }
            
            // set counters
            getCounter(CT_MAPPED_IN_RECORD).inc();
            getCounter(CT_MAPPED_IN_SIZE).set(doneSize);
            
            // update progress
            progress = (float) (doneSize) / totalSize;
            cursor.write(cursor(), time());
        }
    }

    @Override
    protected void process(IRecordReader in) {}

    @Override
    protected void postProcess() {
        try {
            // close readers
            if (readers != null)
                for (int i = 0; i < readers.length; i++)
                    if (readers[i] != null)
                        readers[i].close();
            mapper.mapEnd(this);
            progress = 1f;
        } catch (IOException e) {
            throw new RuntimeException("IOException in "
                    + this.getClass().getName() + ".postProcess()", e);
        }
    }
    
    protected IWritableComparable getStartKey() throws IOException {
      if (extConf.getStartPos() <= 0) return null;
      int mainChannel = extConf.getMainChannel(mrJob);      
      SequenceFile.Reader mainReader = (SequenceFile.Reader)readers[mainChannel];      
      Object k = SeqFileHelper.peekKeyFromNextSync(mainReader, extConf.getStartPos());      
      if (k != null) return (IWritableComparable)k;
      return null;
    }
    
    protected IWritableComparable getEndKey() throws IOException {
        if (extConf.getEndPos() <= 0) return null;
        int mainChannel = extConf.getMainChannel(mrJob);      
        SequenceFile.Reader mainReader = (SequenceFile.Reader)readers[mainChannel];        
        Object k = SeqFileHelper.peekKeyFromNextSync(mainReader, extConf.getEndPos());
        if (k != null) return (IWritableComparable)k;
        return null;
    }
}
