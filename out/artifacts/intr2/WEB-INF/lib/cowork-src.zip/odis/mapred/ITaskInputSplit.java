package odis.mapred;

import java.io.IOException;

import odis.serialize.IWritable;

/**
 * The split interface that a task taking as an input.  This could be a part of
 * a file, part of a database table or others
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 14, 2006
 * Copyright (c) 2006, Outfox Team
 */
public interface ITaskInputSplit extends IWritable {

  /**
   * Get the source "url" of the split.  For example, for a sequence file split 
   * in distributed file system, "host:port#file-dir".
   * @return the source string
   */
  public String getSource();

  /**
   * Get the part string of the split.  For example, for a sequence file split 
   * in distributed file system, it could be "part-xxxxx:start+length".
   * @return the source string
   */
  public String getPart();
  
  /**
   * Returns the length of this split
   * @return the length of this split
   * @throws IOException  if ain I/O error occurs
   */
  public long getLength() throws IOException;  
  
}
