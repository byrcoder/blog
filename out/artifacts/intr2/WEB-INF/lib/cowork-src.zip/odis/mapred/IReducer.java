package odis.mapred;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;

/**
 * Reduces a set of intermediate values which share a key to a smaller set of
 * values.  Input values are the grouped output of a {@link IMapper}.
 * 
 * IReducer is a small step in
 *   - ReduceTaskRunnable.run() = ... ReduceTask.process() ...
 *   - ReduceTask.process() = IReducer.prepare() ... 
 *              while {...IReducer.map()..} ... IReducer.finish()
 *
 * @author zl Li Zhuang 2/20/2006
 * Copyright @ 2006 Kaiwoo Inc. All rights reserved.
 */
public interface IReducer<K, V> {
    /**
     * The default output channel number.
     */
    public static int DEFAULT_OUTPUT_CHANNEL = 0;
    /**
     * Configures the reducer.
     * @param job  the job-definition. This is commonly an instance of the sub-
     *             class of JobDef.
     * @param task  the instance of the runnable task.
     */
    public void configure(JobDef job, TaskRunnable task);
    /**
     * Indicates that the reduce operation is about to start.
     */
    public void reduceBegin();

    /**
     * Combines values for a given key.  Output pairs are collected with calls 
     * to {@link ReduceTaskRunnable#collectToChannel(int, Object, Object)}.  
     * The output pair is not required to have the same type of key/values as 
     * input.  Beaware that the objects for "values" might be reused depends on 
     * which {@link IWritablePairWalker} you used.
     * 
     * @param key the key
     * @param values the values to combine
     * @param collector to collect combined values
     * 
     * NOTE: You should not change this interface to throw exception.  
     * Supposely, all non-fatal exception should be handled inside and if the 
     * exception cannot be handled, it should be a runtime error, throw 
     * {@link odis.cowork.TaskFatalException} instead.
     */
    public void reduce(K key, IWritablePairWalker<K, V> values, 
            ICollector collector);
    /**
     * Indicates that the reduce operation is about to end
     * @param collector  the collector.
     */
    public void reduceEnd(ICollector collector);
}
