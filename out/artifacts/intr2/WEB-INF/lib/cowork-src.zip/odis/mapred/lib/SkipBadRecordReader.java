/**
 * @(#)SkipBadRecordReader.java, 2009-7-15. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.IRecordReader;
import odis.file.SequenceFile;
import odis.io.BadObjectException;
import odis.serialize.toolkit.LazyWritable;
import toolbox.misc.LogFormatter;

/**
 * 跳过坏结果的 reader 
 * @author jiangfy
 *
 */
public class SkipBadRecordReader implements IRecordReader {
    private static final Logger LOG = LogFormatter.getLogger(SkipBadRecordReader.class);
    
    private SequenceFile.Reader reader;
    
    private long searchDistance = 5 * 1024 * 1024L;
    private long badObjectIgnored = 0;
    private long blockSkips = 0;
    
    public SkipBadRecordReader(SequenceFile.Reader reader) {
        this.reader = reader;
    }

    @Override
    public void close() throws IOException {
        reader.close();
    }

    @Override
    public Class getKeyClass() {
        return reader.getKeyClass();
    }

    @Override
    public long getPos() throws IOException {
        return reader.getPos();
    }

    @Override
    public long getSize() throws IOException {
        return reader.getSize();
    }

    @Override
    public Class getValueClass() {
        return reader.getValueClass();
    }

    @Override
    public boolean next(Object key, Object value) throws IOException {
        while (true) {
            long lastPos = reader.getPosition();
            try {
                if (!reader.next(key, value))
                    return false;
                
                try {
                    if (value instanceof LazyWritable) {
                        // make sure the compressed data is ok
                        ((LazyWritable) value).decode();
                    }
                } catch (Throwable e) {
                    throw new BadObjectException("decode object failed", e);
                }
                
                return true;
                
            } catch (BadObjectException e) {
                LOG.log(Level.WARNING, "bad object found at pos "
                        + lastPos + ", skip.", e);
                if (reader.getPosition() > lastPos ) {
                    badObjectIgnored ++;
                    continue;
                } else {
                    if (!skipBadBlock(reader, lastPos, reader.getSize()))
                        return false;
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "read failed at pos " + lastPos
                        + ", try to recover.", e);
                if (reader.getPosition() > lastPos) {
                    try {
                        LOG.log(Level.INFO, "try sync first");
                        reader.sync(reader.getPosition());
                    } catch (Throwable ex) {
                        LOG.log(Level.INFO,
                        "sync failed, try to skip the bad block");
                        if (!skipBadBlock(reader, lastPos, reader.getSize()))
                            return false;
                    }
                } else {
                    if (!skipBadBlock(reader, lastPos, reader.getSize()))
                        return false;
                }
            }
        }
    }
    
    private boolean skipBadBlock(SequenceFile.Reader reader, long fromPos,
            long length) {
        long pos = fromPos;
        if (pos >= length) {
            LOG.log(Level.INFO, "remove the last part of data.");
            return false;
        }

        while (pos < length) {
            try {
                reader.sync(pos);
                LOG.log(Level.INFO, "recovered at pos " + reader.getPosition());
                blockSkips ++;
                return true;
            } catch (Throwable ex) {}
            pos += searchDistance;
        }
        return false;
    }

}
