package odis.mapred;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;

/**
 * IMapper is a small step in
 *   - MapTaskRunnable.run() = ... MapTask.process() ...
 *   - MapTask.process() = IMapper.prepare() ... while {...IMapper.map()..} ...
 *                         IMapper.finish()
 * A mapper transforms a pair of key/value into some other form and write
 * intermediate files in local file system. 
 * 
 * @author zl Li Zhuang 2/20/2006
 * Copyright @ 2006 Kaiwoo Inc. All rights reserved.
 * 
 */

public interface IMapper<K, V> {
  
  /**
   * This configuration will be called at the task configuration time
   * 
   * @param job job configuration
   * @param task the task definition in this job
   */
  public void configure(JobDef job, TaskRunnable task);
  
  /**
   * Executed before iterations of map()
   */
  public void mapBegin();
  
  /**
   * Maps a single input key/value pair into intermediate key/value pairs.
   * Output pairs need not be of the same types as input pairs.  A given input
   * pair may map to zero or many output pairs.  Output pairs are collected
   * with calls to {@link MapTaskRunnable#collect(Object,Object)}.
   * 
   * @param key the key
   * @param value the value
   * 
   * NOTE: 
   * You should not change this interface to throw exception.  Supposely, all 
   * non-fatal exception should be handled inside and if the exception cannot be 
   * handled, it should be a runtime error, throw 
   * {@link odis.cowork.TaskFatalException} instead.
   */
  public void map(K key, V value, ICollector collector);  
  
  /**
   * Executed after iterations of map()
   * @param collector TODO
   */
  public void mapEnd(ICollector collector);
}