package odis.mapred.lib;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import odis.cowork.CoWorkUtils;
import odis.cowork.TaskRunnable;
import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicOutputFormat;
import odis.mapred.MrStarJobDef;
import toolbox.misc.LogFormatter;

public abstract class GenericFileOutputFormat<K,V> extends BasicOutputFormat<K,V> {
    
    protected Logger LOG = LogFormatter.getLogger(GenericFileOutputFormat.class);
    
    protected File sessionFile, targetFile;
    protected IFileSystem fs;
    
    private static final String PROP_COMPRESS = "mapred.output.compress";
    private static final String PROP_OBJECT_COMPRESS = "mapred.output.object_compress";
    private static final String PROP_COMPRESS_ALGO = "mapred.output.compress_algorithm";
    
    private static final String PROP_SPARCE_INDEX_SKIP_SIZE = "mapred.output.sparce_index_skip_size";
    
    /**
     * 设置对 job 的指定输出 channel 进行块压缩
     * @param job 
     * @param channel 输出的 channel
     * @param blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     */
    public static void setCompress(BasicInOutJobDef job, int channel, int blockSize) {
        setCompress(job,job.getIoPhaseNum()-1,channel, blockSize, false);
    }
    
    /**
     * 设置对 job 的指定输出 channel 使用指定压缩算法进行块压缩
     * @param job 
     * @param channel 输出的 channel
     * @param blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     * @param compressAlgo 压缩算法
     */
    public static void setCompress(BasicInOutJobDef job, int channel, 
            int blockSize, CompressAlgo compressAlgo) {
        setCompress(job, job.getIoPhaseNum()-1, channel, blockSize, false, compressAlgo);
    }
    
    /**
     * 设置对 job 的指定输出 channel 进行块压缩
     * @param job
     * @param channel 输出的 channel
     * @param blockSize blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     * @param objectCompress 是否额外按照对象压缩
     */
    public static void setCompress(BasicInOutJobDef job, int channel, int blockSize, boolean objectCompress) {
        setCompress(job,job.getIoPhaseNum()-1,channel, blockSize, objectCompress);
    }
    
    /**
     * 设置对 job 的指定输出 channel 使用指定压缩算法进行块压缩
     * @param job
     * @param channel 输出的 channel
     * @param blockSize blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     * @param objectCompress 否额外按照对象压缩
     * @param compressAlgo 压缩算法
     */
    public static void setCompress(BasicInOutJobDef job, int channel, 
            int blockSize, boolean objectCompress, CompressAlgo compressAlgo) {
        setCompress(job,job.getIoPhaseNum()-1,channel, blockSize, objectCompress, compressAlgo);
    }
    
    /**
     * 设置对 job 的指定输出 channel 进行块压缩
     * @param job
     * @param mrPhase 输出时的 mrPhase，参见 {@link MrStarJobDef} 的 javadoc 中对于 mrPhase 的定义
     * @param channel 输出的 channel
     * @param blockSize blockSize blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     */
    public static void setCompress(BasicInOutJobDef job, int mrPhase, int channel, int blockSize) {
        setCompress(job, mrPhase, channel, blockSize, false);
    }
    
    /**
     * 设置对 job 的指定输出 channel 进行块压缩
     * @param job
     * @param mrPhase 输出时的 mrPhase，参见 {@link MrStarJobDef} 的 javadoc 中对于 mrPhase 的定义
     * @param channel 输出的 channel
     * @param blockSize blockSize blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     * @param objectCompress 是否额外按对象压缩
     */
    public static void setCompress(BasicInOutJobDef job, int mrPhase, int channel, int blockSize, boolean objectCompress) {
        setCompress(job, mrPhase, channel, blockSize, objectCompress, SequenceFile.DEFAULT_COMPRESS_ALGO);
    }
    
    /**
     * 设置对 job 的指定输出 channel 使用指定压缩算法进行块压缩
     * @param job 
     * @param mrPhase 输出时的 mrPhase，参见 {@link MrStarJobDef} 的 javadoc 中对于 mrPhase 的定义
     * @param channel 输出的 channel
     * @param blockSize 压缩块的大小，0 表示使用默认值： {@link SequenceFile.CompressedWriter#DEFAULT_BLOCK_SIZE}
     * @param objectCompress 是否额外按对象压缩
     * @param compressAlgo 压缩算法
     */
    public static void setCompress(BasicInOutJobDef job, int mrPhase, int channel, 
            int blockSize, boolean objectCompress, CompressAlgo compressAlgo) {
        job.getConfig().setInt(PROP_COMPRESS+"."+mrPhase+"."+channel, blockSize);
        job.getConfig().setBoolean(PROP_OBJECT_COMPRESS + "." + mrPhase + "." + channel, objectCompress);
        job.getConfig().setProperty(PROP_COMPRESS_ALGO+"."+mrPhase+"."+channel, compressAlgo.byteValue());
    }
    
    /**
     * 获得设置的压缩块的大小
     * @param job
     * @param mrPhase
     * @param channel
     * @return
     */
    public static int getCompressSize(BasicInOutJobDef job, int mrPhase, int channel) {
        return job.getConfig().getInt(PROP_COMPRESS+"."+mrPhase+"."+channel, -1);
    }
    
    /**
     * 获得是否设置了按照对象进行压缩
     * @param job
     * @param mrPhase
     * @param channel
     * @return
     */
    public static boolean getObjectCompression(BasicInOutJobDef job, int mrPhase, int channel) {
        return job.getConfig().getBoolean(PROP_OBJECT_COMPRESS + "." + mrPhase + "." + channel, false);
    }
    
    /**
     * 获得压缩的算法
     * @param job
     * @param mrPhase
     * @param channel
     * @return
     */
    public static CompressAlgo getCompressAlgo(BasicInOutJobDef job, int mrPhase, int channel) {
        byte b = job.getConfig().getByte(PROP_COMPRESS_ALGO + "." + mrPhase + "." + channel, 
                SequenceFile.DEFAULT_COMPRESS_ALGO.byteValue());
        return CompressAlgo.get(b);
    }

    public static void setSparseIndexSkipSize(BasicInOutJobDef job, int channel, int skipSize) {
        setSparseIndexSkipSize(job, job.getIoPhaseNum()-1, channel, skipSize);
    }
    
    public static void setSparseIndexSkipSize(BasicInOutJobDef job, int mrPhase, int channel, int skipSize) {
        assert skipSize > 0;
        job.getConfig().setInt(PROP_SPARCE_INDEX_SKIP_SIZE + "." + mrPhase + "." + channel, skipSize);
    }
    
    public static int getSparseIndexSkipSize(BasicInOutJobDef job, int mrPhase, int channel) {
        return job.getConfig().getInt(PROP_SPARCE_INDEX_SKIP_SIZE, -1);
    }
    
    /**
     * Get the output file name for a part
     * @param part  The part index
     * @return  the output file name
     */
    protected String getOutputFileName(int part) {
        return CoWorkUtils.getPartID(part);
    }
    
    protected void setup(int channel, TaskRunnable task, 
            BasicInOutJobDef job) throws IOException {
        String svcAddr = getSvcAddr(task.getStageIdx(),channel,job);
        fs = FileSystem.getNamed(svcAddr);
        // target file        
        Path targetPath = new Path(getPath(task.getStageIdx(),channel,job));
        fs.mkdirs(targetPath); // make all parents path
        String partName = getOutputFileName(task.getPartIdx()); 
        targetFile = targetPath.cat(partName).asFile();
        // session file
        Path sessionPath = new Path(job.getFsOvaryDir(task.getJobId()));
        fs.mkdirs(sessionPath);
        sessionFile = getSessionFile(sessionPath.asFile());
    }
    
    @Override
    protected void finish() throws IOException {
        // remove this due to the bug of this getLock (could have deadlock)
        fs.getLock(new Path(targetFile), FileSystem.EXCLUSIVE_LOCK);
        try {
            if (fs.exists(new Path(targetFile))) {
                LOG.warning("Target file " + targetFile + " already exists, " +
                		"ignore session file " + sessionFile);
            } else if (!fs.rename(new Path(sessionFile), new Path(targetFile)))
                throw new IOException("Cannot move " + sessionFile + " to " 
                        + targetFile);
        } finally {
            fs.releaseLock(new Path(targetFile));
        }
    }
    
    protected File getSessionFile(File dir) throws IOException {
        String pid = System.getProperty("pid");
        String name = CoWorkUtils.generate();
        if (pid!=null) name = name+"-"+pid;
        Path file = new Path(dir, name);
        while (fs.exists(file)) {
            LOG.warning("Sesion file " + file + " existing, trying another " +
            		"one ...");
            file = new Path(dir, CoWorkUtils.generate());
        } // while
        return file.asFile();
    }
}
