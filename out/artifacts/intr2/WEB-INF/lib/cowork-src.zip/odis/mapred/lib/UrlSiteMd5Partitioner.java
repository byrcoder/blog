/**
 * @(#)UrlSiteMd5Partitioner.java, 2007-6-7. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import odis.serialize.lib.Url;

/**
 * Url partitioner by siteid.
 * @author river
 */
public class UrlSiteMd5Partitioner extends SeqFileHashPartitioner {

    public static int getPartition(Url url, int numPartitions) {
        return (int) ((url.getSiteID() & Long.MAX_VALUE) % numPartitions);
    }

    public int getPartition(Object key, Object value, int numPartitions) {
        return getPartition((Url) key, numPartitions);
    }
    
}
