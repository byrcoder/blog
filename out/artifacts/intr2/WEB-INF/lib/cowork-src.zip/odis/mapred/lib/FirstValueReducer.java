package odis.mapred.lib;

import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;

/**
 * Collect the first value for each key.
 * @author river
 *
 */
public class FirstValueReducer extends AbstractReducer {

  public void reduce(Object key, IWritablePairWalker values, ICollector collector) {
    if (values.moreValue()) {
      collector.collect(key, values.getValue());
    }
  }

}
