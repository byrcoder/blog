package odis.mapred;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;

import odis.cowork.JobDef;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.cowork.CounterMap.Counter;
import odis.file.IRecordReader;


public abstract class MapTaskRunnable extends TaskRunnable implements ICollector {
    
  public final static String CT_MAPPED_IN_RECORD = "MapInRecord"; 
  public final static String CT_MAPPED_OUT_RECORD = "MapOutRecord";
  public final static String CT_MAPPED_IN_SIZE = "MapInSize";
  public final static String CT_MAPPED_OUT_SIZE = "MapOutSize";
  public final static String CT_COMBINE_IN_PAIR ="MapCombineInPair";
  public final static String CT_COMBINE_IN_RECORD ="MapCombineInRecord";
  public final static String CT_COMBINE_OUT_RECORD="MapCombineOutRecord";
  public final static String CT_COMBINE_OUT_SIZE="MapCombineOutSize";
  public final static String CT_SPILLED_RECORD="MapSpilledRecord";

  protected MapReduceJobDef mrJob;
  //protected IRecordWriter[] out=null;          // outputs of this map task for all reduce task
  protected BasicPartitioner partitioner; // partitioner for map result
  protected Throwable outputError = null; // throwable caught on output
  protected long inputSize;

  protected BufferedMapCollector2 collector;
  protected int nextStageNum;
  
  @Override
  public void configure(JobDef job, TaskWorker worker) {
    assert job instanceof MapReduceJobDef;
    this.mrJob = (MapReduceJobDef) job;
    this.worker = worker;
   
    int nextStage = getStageIdx() + 1; //next stage
    nextStageNum = job.getTaskNumber(nextStage);
    
    resultPartCount = new int[nextStageNum];
    Arrays.fill(resultPartCount, 0);    
  }
  
  @SuppressWarnings("unchecked")
  @Override
  public void run() {
    
    startTime = System.currentTimeMillis();
    
    LOG.info("Starting " + this.getClass().getName() + ".run()");    
    try {
      // input splits
//      assert this.worker.getPrevWorkers()==null;
      ITaskInputSplit[] splits = mrJob.getInputSplits(part);
      StringBuffer sb = new StringBuffer("I will process " + splits.length 
              + " input split(s):");
      for (int i=0; i<splits.length; i++)
        sb.append("\n"+splits[i].toString());
      LOG.info(sb.toString());
      // compute total input size
      inputSize = 0;
      for (int i=0; i<splits.length; i++)
        inputSize += splits[i].getLength();
      // process
//      this.out=null;
      try {
    	collector = new BufferedMapCollector2(this.mrJob, this, this.getCounter(CT_MAPPED_OUT_RECORD), this.getCounter(CT_MAPPED_OUT_SIZE));
        // partitioner
        partitioner = mrJob.getPartitioner();
        // record writers        
//        out = partitioner.getPartitionWriters(this, mrJob);
        // real process from input and write to outputs
        LOG.info("Partitioner and writers are ready. Starting real process ...");
        preProcess(); // set some global states before process
        processSplits(mrJob, splits);
        postProcess(); // get some global states after process
                
        // summarize
        LOG.info("Processed " + getCounter(CT_MAPPED_IN_RECORD).get() 
            + " record (" + getCounter(CT_MAPPED_IN_SIZE).get() + " bytes).");
        LOG.info("Output " + getCounter(CT_MAPPED_OUT_RECORD).get() 
            + " record (" + getCounter(CT_MAPPED_OUT_SIZE).get() + " bytes).");
                        
      } finally {
          if (collector != null) {
              collector.close();
              outputError = collector.getError();
              collector = null;
          }
      }
      //sort map out file
    } catch (IOException e) {        
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + ".run()", e);
    } 
    if (outputError != null) {
      throw new RuntimeException("Error occur on async output", outputError);
    }
    
  }
  
  public long cursor() {
      Counter ct = counters.get(CT_MAPPED_IN_RECORD);
      if (ct==null) return NON_CURSOR;
      else return ct.get();
  }
  
  public void clean(JobDef job) {} // do nothing

  /** work done right before processing all pieces of splits */
  protected abstract void preProcess();
  
  @SuppressWarnings("unchecked")
  protected void processSplits(MapReduceJobDef mrJob, ITaskInputSplit[] splits) 
      throws IOException {
    IRecordReader in = null;
    setProgressFlag(true);
    try {
      for (int i=0; i<splits.length; i++) {
        LOG.info("Processing split=" + splits[i]); 
        in = mrJob.getInputFormat(splits[i].getSource()).getRecordReader(
            splits[i],this,mrJob);
        LOG.info("Record reader class is " + in.getClass().getName());
        process(in);
        in.close(); in = null;
        LOG.info("Return from processing split=" + splits[i] + ", cursor="+cursor());
        if (toEnd) break;
      } // for i
      // log size of each partition
//      if (out!=null && out.length>0) {
//        StringBuffer sb = new StringBuffer("Map output parition size: [" + out[0].getSize()); 
//        for (int i = 1; i < out.length; i ++)
//          sb.append("," + out[i].getSize());
//        sb.append("]");
//        LOG.info(sb.toString());
//      } // if
    } finally {
      setProgressFlag(false);
      if (in!=null) in.close();
    }
    if (outputError != null) {
      throw new RuntimeException("Error occur on asynchronous output", outputError);
    }
  }
  
  /**
   * NOTE: Process one piece of split
   * You should not change this interface to throw exception.  Supposely, all 
   * non-fatal exception should be handled inside and if the exception cannot be 
   * handled, it should be a runtime error, throw TaskFatalException instead.
   */
  protected abstract void process(IRecordReader in) throws IOException;
  
  /** work done right after processing all pieces of splits */
  protected abstract void postProcess();

  /**
   * Default collect() will collect <key,value> to default partition.
   */
  public void collect(Object key, Object value) {
//      collector.collect(key, value);
      collectToPartition(partitioner.getPartition(key, value, nextStageNum),key,value);
  }
  
  @SuppressWarnings("unchecked")
  public void collectToPartition(int part, Object key, Object value) {
      resultPartCount[part]++;
      collector.collectToPartition(part, key, value);
//    try {
//      if (part<0 || part>=out.length)
//        throw new TaskFatalException("BUG: try to collect to partition " 
//          + part + ", partition range accepted: [0," + out.length+")");
//      long prevPos = out[part].getSize();
//      out[part].write(key, value);
//      getCounter(CT_MAPPED_OUT_RECORD).inc();
//      getCounter(CT_MAPPED_OUT_SIZE).inc(out[part].getSize()-prevPos);
//    } catch (IOException e) {
//      outputError = e;
//      throw new RuntimeException("IOException in " + this.getClass().getName() 
//        + ".collectToParition()", e);
//    } catch (Throwable e) {
//      outputError = e;
//      throw new RuntimeException("Unexpected error in " + 
//              this.getClass().getName() + 
//              ".collectToPartition(" + part + ")", e);
//    }
  }
  
  public void collectToChannel(int index, Object key, Object value) {
    throw new TaskFatalException("Method not implemented for " 
        + this.getClass().getName());
  }
  
  public void collectDoneMsg(String msg) {
    this.doneMsg = msg;
  }

}
