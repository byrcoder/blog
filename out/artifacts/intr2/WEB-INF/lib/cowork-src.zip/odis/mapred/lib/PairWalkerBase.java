package odis.mapred.lib;

import java.io.IOException;
import java.util.Comparator;

import odis.file.IRecordReader;
import odis.mapred.IWritablePairWalker;

import org.apache.commons.configuration.Configuration;

public abstract class PairWalkerBase<K, V> implements IWritablePairWalker<K, V> {
  
  protected IRecordReader in;
  protected Comparator<K> comparator;
  
  protected K key, nextKey;
  protected V value, nextValue;
  protected boolean beforeKey, beforeValue;
  protected boolean eof;
  /**
   * Allocate a new (or saved) instance for nextKey
   */
  protected abstract void allocNextKey();
  /**
   * Allocate a new (or saved) instance fore nextValue
   */
  protected abstract void allocNextValue();
  /**
   * the instance in key is no longer used (by the walker), free it (or save it
   * for reusing)
   */
  protected void freeCurrentKey() {};
  /**
   * The instance in value is no longer used (by the walker), free it (or save 
   * it for reusing)
   * 
   */
  protected void freeCurrentValue() {};
  
  private void toClose() {
    freeCurrentKey();  freeCurrentValue();
    key = null; value = null;
  }

  public void configure(IRecordReader in, Comparator<K> cmp,
      Configuration conf) {
    try {
      this.in = in;
      this.comparator = cmp;

      allocNextKey();  allocNextValue();
      eof = !in.next(nextKey, nextValue);
      
      beforeKey = true;
    } catch (IOException e) {
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + ".config()", e);
    }
  }

  public boolean moreKey() {
    try {
      if (eof)
        return false;
      
      if (beforeKey) {
        // new key is ready to read
        beforeKey = false;
        // copy from next
        freeCurrentKey();  
        key = nextKey;  value = nextValue;
        beforeValue = true;
        return true;
      } // if
  
      // find next key
      if (beforeValue)
        allocNextKey();
      allocNextValue();
      
      while (true) {
        eof = !in.next(nextKey, nextValue);
        if (eof) {
          toClose();  return false;
        } // if
        if (comparator.compare(key, nextKey) != 0)
          break;
      } // while
      
      freeCurrentKey();  freeCurrentValue();
      key = nextKey;  value = nextValue;
      
      beforeValue = true;
      return true;
    } catch (IOException e) {
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + "moreKey()", e);
    }
  }

  public boolean moreValue() {
    try {
      if (beforeKey || eof)
        return false;
      
      if (beforeValue) {
        // first value of this key
        beforeValue = false;
        allocNextKey();  return true;
      } // if

      // find next value
      allocNextValue();
      eof = !in.next(nextKey, nextValue);
      if (eof) {
        toClose();  return false;
      } // if
      
      freeCurrentValue();
      if (comparator.compare(key, nextKey) == 0) {
        value = nextValue;
        return true;
      } // if
      
      value = null;
      beforeKey = true;  return false;
    } catch (IOException e) {
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + "moreValue()", e);
    }
  }

  public K getKey() {
    return key;
  }

  public V getValue() {
    return value;
  }

}

