package odis.mapred;

import odis.cowork.TaskRunnable;
import odis.mapred.lib.PerKeyBufferedWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;
import toolbox.misc.ClassUtils;

/**
 * Job definition support map reduce job
 * 
 * INPUT -(map)-> PARTITIONER -(remote)-> MERGER -(reduce)-> OUTPUT
 * 
 * Basic usage:
 *   MapReduceJobDef job = ...;
 *   
 *   job.addInput(...);
 *   ...
 *   
 *   job.setMapper(...);
 *   job.setMapNumber(...);
 *   
 *   job.setPartitionerClass(...);
 *   job.setMergeKeyValClass(...);
 *   
 *   job.setReducer(...);
 *   job.setReduceNumber(...);
 *   
 *   job.addOutputDir(...);
 *   
 *   JobResult res = JobClient.runJob(..., job);
 *   ...
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public class MapReduceJobDef extends MapOnlyJobDef {

  protected String getTypeName() { return "MapReduce"; }
  protected String getTypeClass() { return MapReduceJobDef.class.getName(); }

  public MapReduceJobDef() { super(); }
  
  @SuppressWarnings("unchecked") @Override
  protected void staticDefine() {
    // static definitions
    stageNames = new String[]{"map","reduce"};
    stageXfaces = new String[]{MapTaskRunnable.class.getName(),
                               ReduceTaskRunnable.class.getName()};
    // default parameters
    this.jobName = "job";
    this.taskClasses = new String[]{MapTask.class.getName(),ReduceTask.class.getName()};
    this.taskNumbers = new int[]{1,1};
    this.workerNum = 1;
    this.taskPerMachine = new int[]{0,0};
    this.exclusiveOwn = new boolean[]{false,false};
  }  
  
  //////////////////////////////////////////////////////////////////////////////
  // Reduce is the last stage
  //////////////////////////////////////////////////////////////////////////////
  
  // set & get reduce class
  public void setReduceTaskRunnable(Class<? extends ReduceTaskRunnable> c) {    
    super.setTaskClass(getTotalStage()-1, c);
    setExtReducer(c.getName());
  }
  public Class<? extends TaskRunnable> getReduceTaskRunnable() {
    return super.getTaskClass(getTotalStage()-1);
  }  
  // set & get reduece task number
  public void setReduceNumber(int num) {
    super.setTaskNumber(getTotalStage()-1, num);
  }
  public int getReduceNumber() {
    return super.getTaskNumber(getTotalStage()-1);
  }
  
  public void setCheckReduceProgress(boolean b) {
      super.setCheckProgress(getTotalStage()-1, b);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Partitioner for the MapTask is in the first io stage 
  //////////////////////////////////////////////////////////////////////////////
  
  public void setPartitionerClass(Class<? extends BasicPartitioner> partitioner) {
    super.setPartitionerClass(IO_PHASE_MAP,partitioner);
  }
  public void useDefaultHashPartitioner() {
    super.setPartitionerClass(IO_PHASE_MAP,SeqFileHashPartitioner.class);
  }
  
  protected BasicPartitioner getPartitioner(int ioPhase) {
    BasicPartitioner partitioner = super.getPartitioner(ioPhase);
    return partitioner; 
  }
  protected BasicPartitioner getPartitioner() {
    return this.getPartitioner(IO_PHASE_MAP);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Combiner for the MapTask in the first io stage
  //////////////////////////////////////////////////////////////////////////////
  public void setCombinerClass(Class<? extends IReducer> combiner) {
    super.setCombinerClass(IO_PHASE_MAP, combiner);
  }
  protected IReducer getCombiner() {
    return super.getCombiner(IO_PHASE_MAP);
  }
  public void setCombiningBufferSize(int buff) {
    super.setCombiningBufferSize(IO_PHASE_MAP, buff);
  }
  protected int getCombiningBufferSize() {
    return super.getCombiningBufferSize(IO_PHASE_MAP);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Merger/Walker for the ReduceTask is in the last io stage
  ////////////////////////////////////////////////////////////////////////////// 
  // merge (=output of map =input of reduce)
  public void setMergeKeyValClass(Class key, 
      Class value) {
    super.setMergeKeyValClass(getIoPhaseNum()-1,key,value);
  }
  public void setMergeKeyComparator(Class<? extends BinaryComparator> comparator) {
    super.setMergeKeyComparator(getIoPhaseNum()-1,comparator);
  }  
  public void setMergeValComparator(Class<? extends BinaryComparator> comparator) {
    super.setMergeValComparator(getIoPhaseNum()-1,comparator);   
  }
  protected Class getMergeKeyClass() {
    return super.getMergeKeyClass(getIoPhaseNum()-1);
  }
  protected Class getMergeValClass() {
    return super.getMergeValClass(getIoPhaseNum()-1);
  }
  protected WritableComparator getMergeKeyComparator() {
    return super.getMergeKeyComparator(getIoPhaseNum()-1);
  }
  protected BinaryComparator getMergeValComparator() {
    return super.getMergeValComparator(getIoPhaseNum()-1);
  }
  public void setMergerClass(Class<? extends BasicMerger> merger) {
    super.setMergerClass(getIoPhaseNum() - 1,merger);
  }
  public void setWalkerClass(Class<? extends IWritablePairWalker> walker) {
    super.setWalkerClass(getIoPhaseNum() - 1,walker);
  }
  protected BasicMerger getMerger() {
    BasicMerger merger = super.getMerger(getIoPhaseNum() - 1);
//    if (merger==null) merger = new SeqFileSortMerger();
//    if (merger==null) merger = new SeqFileAsyncSortMerger();
    return merger;
  }
  protected IWritablePairWalker getWalker() {
    IWritablePairWalker walker = super.getWalker(getIoPhaseNum() - 1);
    if (walker==null) walker = new PerKeyBufferedWalker();
    return walker;
  }
  public void setMergeCompressed(boolean v) {
      setMergeTransferCompressed(getIoPhaseNum()-1, v);
  }
  public boolean getMergeCompressed() {
      return getMergeTransferCompressed(getIoPhaseNum()-1);
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // Backup execution options
  /////////////////////////////////////////////////////////////////////////////
  public void setReduceBackupNum(int copy) {
      super.setMaxBackupNum(getTotalStage()-1, copy);
  }
  public void setReduceBackupLag(float lag) {
      super.setMaxProgressLag(getTotalStage()-1, lag);
  }
  protected float getMaxProgressLag(int stage) {
      if (stage==TASK_STAGE_MAP) // no backup for map
          return getConfig().getFloat(PROP_BACKUP_LAG+"."+stage, 1f);
      else
          return getConfig().getFloat(PROP_BACKUP_LAG+"."+stage, 0.5f);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Default ReduceTaskRunnable and its IReducer interface
  //////////////////////////////////////////////////////////////////////////////

  protected static final String PR_REDUCE_REDUCER = "mapred.reduce.reducer_class";  
  public void setReducer(Class<? extends IReducer> reducer) {
    getConfig().setPropClass(PR_REDUCE_REDUCER+"."+(getIoPhaseNum()-1), 
        reducer, IReducer.class);
  }
  public IReducer getReducer() {
    Class cls = getConfig().getPropClass(PR_REDUCE_REDUCER+"."+(getIoPhaseNum()-1), 
        IReducer.class, null);
    if (cls!=null)
      return (IReducer) ClassUtils.newInstance(cls);
    else return null;
  }
  
  public void setExtReducer(String reducerName) {
    getConfig().setProperty(PR_REDUCE_REDUCER+".ext", reducerName);
  }
  public String getExtReducer() {
    return getConfig().getString(PR_REDUCE_REDUCER+".ext");
  }
  
  protected boolean isValid() {
    if (!super.isValid()) return false;
    if (getReducer()==null && getExtReducer()==null) {
      LOG.warning("Please set reducer class: see setReducer() or set**Reducer()");
      return false;
    }
    if (getMergeKeyClass()==null || getMergeValClass()==null) {
      LOG.warning("Please set merge key/value classes: see setMergeKeyValueClass()");
      return false;
    }
    BasicPartitioner partitioner = getPartitioner();
    if (partitioner == null) {
      LOG.warning("Cannot find partitioner setting, job cannot be submitted.");
      return false;
    }
    if (SeqFileHashPartitioner.class.isAssignableFrom(partitioner.getClass())) {
      if (!checkHashCode(getMergeKeyClass())) {
        if (SeqFileHashPartitioner.class==getPartitioner().getClass()) {
          LOG.warning("To use SeqFileHashPartitioner, you must override hashCode() for merge key class.");
          return false;
        } else
          LOG.warning("You're using a subclass of SeqFileHashPartitioner without overriding hashCode() for merge key class.");
      }
    }
    if (BasicPartitioner.isObjectCompress(this, getIoPhaseNum()-1) && 
        getConfig().getProperty(PR_MR_VAL_COMPARATOR+"."+(getIoPhaseNum()-1)) != null) {
      LOG.warning("Cannot use compression for map output with value comparator");
      return false;
    }
    return true;
  }
  
  protected static boolean checkHashCode(Class className) {
      return ClassUtils.newInstance(className).hashCode() == 
          ClassUtils.newInstance(className).hashCode();
  }

}
