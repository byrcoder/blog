package odis.mapred.lib;

import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;

public class IdentityMapper extends AbstractMapper {

  public void map(Object key, Object value, ICollector collector) {
    collector.collect(key,value);
  }

}
