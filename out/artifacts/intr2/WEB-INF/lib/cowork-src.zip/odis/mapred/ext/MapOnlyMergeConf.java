package odis.mapred.ext;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import odis.cowork.CoWorkUtils;
import odis.cowork.JobDef;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInputFormat;
import odis.mapred.IExtConf;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.InputFileSplit;
import odis.mapred.lib.SeqFileInputFormat;
import odis.serialize.IWritableComparable;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.lib.StringsWritable;
import odis.tools.SeqFileHelper;
import toolbox.misc.ClassUtils;
import toolbox.misc.EmptyInstance;
import toolbox.misc.LogFormatter;

public class MapOnlyMergeConf implements IExtConf {
  
  private static final Logger LOG = LogFormatter.getLogger(MapOnlyMergeConf.class.getName());

  private static final String [] EMPTY_DIRS = new String[0];
  private static final Class [] EMPTY_WALKERS = new Class[0];
  private static final Class [] EMPTY_INPUTFORMATS = new Class[0];
  
  private static final String EXT_MMAP_MAPPER = "mapred.ext.merge_map.mapper";
  private static final String EXT_MMAP_KEYCMP = "mapred.ext.merge_map.keycmp";
  private static final String EXT_MMAP_COUNT  = "mapred.ext.merge_map.count";
  private static final String EXT_MMAP_FS     = "mapred.ext.merge_map.fs";
  private static final String EXT_MMAP_DIR    = "mapred.ext.merge_map.dir";
  private static final String EXT_MMAP_WALKER = "mapred.ext.merge_map.walker";  
  private static final String EXT_MMAP_INPUTFORMAT = "mapred.ext.merge_map.input_format";
  private static final String EXT_MMAP_CHANNEL_PART = "mapred.ext.merge_channel_part";
  private static final String EXT_MMAP_MERGE_SPEEDUP = "mapred.ext.merge_speedup";
  private static final String EXT_MMAP_MAIN_CHANNEL = "mapred.ext.merge_main_channel";
  private static final String EXT_MMAP_MERGE_PART = "mapred.ext.merge_part";

  private Class<? extends BinaryComparator> keyCmp;
  private Class<? extends IMergeMapper> mapper;
  
  private String [] mergeFsNames = EmptyInstance.STRINGS;
  private String [] mergeDirs = EMPTY_DIRS;
  private Class [] mergeWalkers = EMPTY_WALKERS; 
  private Class [] mergeInputFormats = EMPTY_INPUTFORMATS;
  
  private int mergeSpeedUp = 1; //default 1
  private int mergeMainChannel = -1;
  
  protected Class<? extends TaskRunnable> taskClass;  
  public MapOnlyMergeConf() { taskClass = MapOnlyMergeTask.class; }
  
  @SuppressWarnings("unchecked")
  public void loadFrom(JobDef job) {
    assert job instanceof MapOnlyJobDef;
    MapOnlyJobDef moJob = (MapOnlyJobDef) job;
    
    // check task class
    if (moJob.getMapTaskRunnable()!=taskClass)
      throw new TaskFatalException("MergeMapper is set only when " +
            "MapOnlyTaskRunnable is " + taskClass.getName());
    
    // mapper
    mapper = (Class<? extends IMergeMapper>) moJob.getConfig().getPropClass(
        EXT_MMAP_MAPPER, IMergeMapper.class, null);
    
    // key comparator
    keyCmp = (Class<? extends BinaryComparator>) moJob.getConfig().
        getPropClass(EXT_MMAP_KEYCMP, BinaryComparator.class, null);
    
    // dirs & walkers
    int count = moJob.getConfig().getInt(EXT_MMAP_COUNT, 0);
    if (count == 0) {
      mergeFsNames = EmptyInstance.STRINGS;  
      mergeDirs = EMPTY_DIRS;
      mergeWalkers = EMPTY_WALKERS;
      mergeInputFormats = EMPTY_INPUTFORMATS;
    } else {
      mergeFsNames = new String[count];
      mergeDirs = new String[count];
      mergeWalkers = new Class[count];
      mergeInputFormats = new Class[count];
      for (int i=0; i<count; i++) {
        String dir = (String)moJob.getConfig().getProperty(
            EXT_MMAP_DIR + "." + i);
        Class cls = moJob.getConfig().getPropClass(
            EXT_MMAP_WALKER+"."+i, IWritablePairWalker.class, null);
        Class in = moJob.getConfig().getPropClass(
            EXT_MMAP_INPUTFORMAT+"."+i, BasicInputFormat.class, null);
        if (dir != null && cls != null) {
          mergeDirs[i] = dir;
          mergeWalkers[i] = cls;
          mergeInputFormats[i] = in;
        }
        mergeFsNames[i] = (String)moJob.getConfig().getProperty(EXT_MMAP_FS + "." + i);
      }
    }
    
    mergeSpeedUp = moJob.getConfig().getInt(EXT_MMAP_MERGE_SPEEDUP, 1);
    mergeMainChannel = job.getConfig().getInt(EXT_MMAP_MAIN_CHANNEL, -1);
    LOG.info("MergeSpeedUp=" + mergeSpeedUp + ", MainChannel=" + mergeSpeedUp);
  }

  @Override
  public void saveTo(JobDef job) {
    assert job instanceof MapOnlyJobDef;
    MapOnlyJobDef moJob = (MapOnlyJobDef) job;
    
    // task runnable
    moJob.setMapTaskRunnable(taskClass);
    // mapper
    moJob.getConfig().setPropClass(EXT_MMAP_MAPPER, mapper, IMergeMapper.class);
    moJob.setExtMapper(mapper.getName());
    // key comparator
    if (keyCmp!=null)
      moJob.getConfig().setPropClass(EXT_MMAP_KEYCMP, keyCmp, BinaryComparator.class);
    
    assert mergeDirs.length == mergeWalkers.length && 
           mergeDirs.length == mergeInputFormats.length;
    
    // dirs & walkers
    for (int i=0; i<mergeDirs.length; i++) {
      if (mergeDirs[i] == null || mergeWalkers[i] == null ||
          mergeInputFormats[i]==null) continue;
      moJob.getConfig().setProperty(EXT_MMAP_DIR + "." + i, mergeDirs[i]);
      moJob.getConfig().setPropClass(EXT_MMAP_WALKER+"."+i, 
          mergeWalkers[i], IWritablePairWalker.class);
      moJob.getConfig().setPropClass(EXT_MMAP_INPUTFORMAT+"."+i,
          mergeInputFormats[i], BasicInputFormat.class);
      if (mergeFsNames[i] != null) {
          moJob.getConfig().setProperty(EXT_MMAP_FS + "." + i, mergeFsNames[i]);
      }
    }
    moJob.getConfig().setInt(EXT_MMAP_COUNT, mergeDirs.length);
    
    // get the file splits and save to config
    for (int channel = 0; channel < mergeInputFormats.length; channel ++) {
        if (mergeInputFormats[channel] == null) continue;
        
        BasicInputFormat input = (BasicInputFormat) ClassUtils
        .newInstance(mergeInputFormats[channel]);
        try {
            String[] fileParts = input.listParts(
                    mergeFsNames[channel]==null ? moJob.getDefaultFsName() : mergeFsNames[channel],
                            mergeDirs[channel]);
            StringsWritable list = new StringsWritable();
            for (String s : fileParts) { list.addString(s); }
            String encodedString = CoWorkUtils.writableToString(list);
            moJob.getConfig().setProperty(EXT_MMAP_CHANNEL_PART + "_" + channel, encodedString);
        } catch(IOException e) {
            throw new RuntimeException("prepare the input splits failed", e);
        }
    }
    
    moJob.getConfig().setInt(EXT_MMAP_MERGE_SPEEDUP, mergeSpeedUp);
    moJob.getConfig().setInt(EXT_MMAP_MAIN_CHANNEL, getMainChannel(moJob));
    LOG.info("MergeSpeedUp=" + mergeSpeedUp + ", MainChannel=" + getMainChannel(moJob));
    
    try {
        int partNum = getMergePartNum(moJob);
        LOG.info("Set mapper number mergeSpeedUp * partNum");
        moJob.setMapNumber(mergeSpeedUp * partNum);
        moJob.getConfig().setInt(EXT_MMAP_MERGE_PART, partNum);
    }catch(IOException e) {
        throw new RuntimeException(e);
    }
  }
  
  public void setKeyComparator(Class<? extends BinaryComparator> keyCmp) {
    this.keyCmp = keyCmp;
  }
  
  public BinaryComparator getKeyComparator() {
    if (keyCmp==null) return null;
    else return (BinaryComparator) ClassUtils.newInstance(keyCmp);
  }
  
  public void setMergeMapper(Class<? extends IMergeMapper> mapper) {
    this.mapper = mapper;
  }
  
  public IMergeMapper getMergeMapper() {
    if (mapper==null)
      throw new TaskFatalException("Merge mapper is not initialized");
    return (IMergeMapper) ClassUtils.newInstance(mapper);
  }
  
  public void setMergeCount(int value) {
    assert value >= mergeDirs.length;
    if (value == mergeDirs.length) return;
    
    String [] dirs = new String[value];
    System.arraycopy(mergeDirs, 0, dirs, 0, mergeDirs.length);
    mergeDirs = dirs;
    
    Class [] clazzes = new Class[value];
    System.arraycopy(mergeWalkers, 0, clazzes, 0, mergeWalkers.length);
    mergeWalkers = clazzes;
    
    Class [] inputs = new Class[value];
    System.arraycopy(mergeInputFormats, 0, inputs, 0, mergeInputFormats.length);
    mergeInputFormats = inputs;
    
    String [] fsNames = new String[value];
    System.arraycopy(mergeFsNames, 0, fsNames, 0, mergeFsNames.length);
    mergeFsNames = fsNames;
  }
  @Deprecated
  public void setMergeDir(int idx, File dir, Class walker) {
      setMergeDir(idx, new Path(dir), walker);
  }
  
  public void setMergeDir(int idx, Path dir, Class walker) {
    setMergeDir(idx,dir,walker,SeqFileInputFormat.class);
  }
  
  @Deprecated
  public void setMergeDir(int idx, File dir, Class walker, Class inputformat) {
      setMergeDir(idx, new Path(dir), walker, inputformat);
  }
  
  public void setMergeDir(int idx, Path dir, Class walker, Class inputformat) {
      setMergeDir(idx, null, dir, walker, inputformat);
  }
  
  @Deprecated
  public void setMergeDir(int idx, String fsName, File dir, Class walker) {
      setMergeDir(idx, fsName, new Path(dir), walker);
  }
  
  public void setMergeDir(int idx, String fsName, Path dir, Class walker) {
      setMergeDir(idx, fsName, dir, walker, SeqFileInputFormat.class);
  }
  
  @Deprecated
  public void setMergeDir(int idx, String fsName, File dir, Class walker, Class inputformat) {
      setMergeDir(idx, fsName, new Path(dir), walker, inputformat);
  }
  
  public void setMergeDir(int idx, String fsName, Path dir, Class walker, Class inputformat) {
    assert mergeDirs.length == mergeWalkers.length;
    if (idx < 0 || idx >= mergeDirs.length) {
      throw new RuntimeException("No slot to save merge dir, call setMergeCount() first");
    }
    mergeFsNames[idx] = fsName;
    mergeDirs[idx] = dir.getPath();
    mergeWalkers[idx] = walker;
    mergeInputFormats[idx] = inputformat;
  }
  
  public String[] getMergeDirs() {
    if (mergeDirs.length == 0)
      LOG.warning("Merge directories are not initialized");
    return mergeDirs;
  }
  
  public IWritablePairWalker getMergeWalker(int index) {
    if (index<0||index>=mergeWalkers.length)
      throw new TaskFatalException("Merge walkers are not initialized or " +
            "try to get walkers exceeds bound");
    if (mergeWalkers[index]==null) return null;
    return (IWritablePairWalker) ClassUtils.newInstance(mergeWalkers[index]);
  }
  
  public IRecordReader getMergeInputReader(int channel, TaskRunnable task,
      MapOnlyJobDef job) throws IOException {
    if (channel < 0 || channel >= mergeInputFormats.length)
      throw new TaskFatalException("Merge reader are not initialized or "
          + "try to get reader exceeds bound");
    if (mergeInputFormats[channel] == null || mergeDirs[channel] == null)
      return null;
    else {
      int mapNum = job.getMapNumber();
      
      BasicInputFormat input = (BasicInputFormat) 
      ClassUtils.newInstance(mergeInputFormats[channel]);
      
      String[] fileParts;
      String cachedParts = job.getConfig().getString(EXT_MMAP_CHANNEL_PART + "_" + channel);
      if (cachedParts != null) {
          StringsWritable cachedFileParts = (StringsWritable)CoWorkUtils.stringToWritable(cachedParts);
          fileParts = cachedFileParts.toStringArray();
      } else {
          fileParts = input.listParts(
              mergeFsNames[channel]==null ? job.getDefaultFsName() : mergeFsNames[channel],
                      mergeDirs[channel]);
      }
      
//      if (mapNum != fileParts.length) {
//        throw new IOException("Merge channel " + channel
//            + ": Map-Number!=Part-Number-To-Merge: " + mapNum + "!="
//            + fileParts.length);
//      }
      return input.getRecordReader(
              new InputFileSplit(
                      mergeFsNames[channel] == null ? job.getDefaultFsName() : mergeFsNames[channel], 
                              mergeDirs[channel], fileParts[task.getPartIdx() % fileParts.length]), task, job);
    }
  }  
  
  /**
   * the job's map task number = factor * partNum 
   * @param factor must >= 1
   * @return
   */
  public void setMergeSpeedUp(int factor) {
      if (factor < 1) throw new RuntimeException("Merge factor must >= 1");
      mergeSpeedUp = factor;
  }
  
  public int getMergeSpeedUp() {
      return mergeSpeedUp;
  }
  
  /**
   * the merge job will split the task by this channel
   * @param channel
   */
  public void setMergeMainChannel(int channel) {
      if (channel >= mergeDirs.length) throw new RuntimeException("channel idx must less than dirs.length");
      mergeMainChannel = channel;
  }
  
  public int getMainChannel(MapOnlyJobDef job) {                  
      if (mergeMainChannel >= 0) return mergeMainChannel;
      try {
          long maxLength = -1;
          for (int i = 0; i < mergeDirs.length; ++i) {
              if (mergeDirs[i] == null) continue;
              String fsName = (mergeFsNames[i] == null ? job.getDefaultFsName() : mergeFsNames[i]);
              FileSystem fs = FileSystem.getNamed(fsName);
              long len = fs.getLengthRecursive(new Path(mergeDirs[i]));
              if (len > maxLength) {
                  maxLength = len;
                  mergeMainChannel = i;
              }
          }
      }catch(IOException e) {
          throw new RuntimeException(e);
      }
      return mergeMainChannel;
  }

  int partsNumber = -1;  
  private Path[] getPartFilesWithSameIdxInAllChannel(int partIdx, MapOnlyJobDef job) throws IOException {
      Path [] channelParts = new Path[mergeDirs.length];
      for (int i = 0; i < mergeDirs.length; ++i) {
          if (mergeDirs[i] == null) continue;
          BasicInputFormat input = (BasicInputFormat) ClassUtils.newInstance(mergeInputFormats[i]);
          String[] innerParts;
          String cachedParts = job.getConfig().getString(EXT_MMAP_CHANNEL_PART + "_" + i);
          if (cachedParts != null) {
              StringsWritable cachedFileParts = (StringsWritable)CoWorkUtils.stringToWritable(cachedParts);
              innerParts = cachedFileParts.toStringArray();
          } else {
              innerParts = input.listParts(
                  mergeFsNames[i]==null ? job.getDefaultFsName() : mergeFsNames[i],
                          mergeDirs[i]);
          }
          if (partsNumber > 0 && partsNumber != innerParts.length) {
              throw new IOException("Part number don't match.");
          }          
          partsNumber = innerParts.length;          
          channelParts[i] = new Path(mergeDirs[i] ,innerParts[partIdx % innerParts.length]);
      }      
      return channelParts;
  }

  public int getMergePartNum(MapOnlyJobDef job) throws IOException{          
      if (partsNumber  > 0) return partsNumber;
      if (job.getConfig().getInt(EXT_MMAP_MERGE_PART, -1) > 0) {
          partsNumber = job.getConfig().getInt(EXT_MMAP_MERGE_PART, -1);
          return partsNumber;
      }
      int index = 0;
      while (mergeInputFormats[index] == null && index < mergeInputFormats.length) 
          ++index;
      if (mergeInputFormats[index] == null)
          throw new IOException("No inputformat set.");
      BasicInputFormat input = (BasicInputFormat) ClassUtils.newInstance(mergeInputFormats[index]);
      String[] innerParts;
      String cachedParts = job.getConfig().getString(EXT_MMAP_CHANNEL_PART + "_" + 0);
      if (cachedParts != null) {
          StringsWritable cachedFileParts = (StringsWritable)CoWorkUtils.stringToWritable(cachedParts);
          innerParts = cachedFileParts.toStringArray();
      } else {
          innerParts = input.listParts(
              mergeFsNames[index]==null ? job.getDefaultFsName() : mergeFsNames[index],
                      mergeDirs[index]);
      }
      partsNumber = innerParts.length;
      return partsNumber;
  }
  
  private FileSystem getChannelFs(int channel, MapOnlyJobDef job) throws IOException {
      String fsName = mergeFsNames[channel]==null ? job.getDefaultFsName() : mergeFsNames[channel];      
      return FileSystem.getNamed(fsName);
  }
  
  long startPos = -1, endPos = -1;
  protected long getStartPos(){
      return startPos;
  }
  
  protected long getEndPos() {
      return endPos;
  }
  
  public void calculateSpeedup(TaskRunnable task,
          MapOnlyJobDef job) throws IOException {
      int partIdx = task.getPartIdx();
      int mapNum = job.getMapNumber();
      int totalPartNum = getMergePartNum(job);
      
      if (mapNum % totalPartNum != 0) {
          throw new IOException("Mapper number equal (n * part number)");
      }
      
      if (mergeSpeedUp != mapNum / totalPartNum) {
          throw new IOException("Speedup must equal mapNum / partNum.");
      }
      
      if (mergeSpeedUp > 1) {
          Path[] partFiles = getPartFilesWithSameIdxInAllChannel(partIdx % totalPartNum, job);
          int segment = partIdx / totalPartNum;
          
          Path mainPartPath = partFiles[mergeMainChannel];
          long mainPartFileLength = getChannelFs(mergeMainChannel, job).getLength(mainPartPath);
          
          if (mainPartFileLength == 0)
              throw new IOException("Main part " + mainPartPath + " len can't be 0.");
          
          long avgLen = mainPartFileLength/mergeSpeedUp;          
          
          if (segment != 0) startPos = segment * avgLen;          
          if (segment != mergeSpeedUp - 1) endPos = (segment + 1) * avgLen;
          
          LOG.info("Debug: mainPart=" + mainPartPath + ", mainPartFileLength=" + mainPartFileLength);
          LOG.info("Debug: partIdx=" + partIdx + ", totalPart=" + totalPartNum + ", segment=" + segment + ", mainChannel=" + mergeMainChannel);
          LOG.info("Debug: startPos=" + startPos + ", endPos=" + endPos + ", avgLen=" + avgLen);
      }
  }  
  
}
