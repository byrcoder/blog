package odis.mapred.lib;

import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.serialize.lib.NullWritable;

public class NullValueMapper extends AbstractMapper {

    public void map(Object key, Object value, ICollector collector) {
        collector.collect(value, NullWritable.get());
    }

}
