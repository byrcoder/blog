package odis.mapred;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import odis.io.Path;
import odis.util.LocalDirAllocator;

public class MapOutputFile {

    public static final String MAP_OUT_FILE_NAME = "map.out";
    public static final String MAP_OUT_INDEX_FILE_NAME = "map.out.index";
    public static final String MAP_OUT_INDEX_SUFFIX = ".index";
    
    private LocalDirAllocator lDirAlloc;
//    List<Path> spillPathList;
    public MapOutputFile(LocalDirAllocator localAllocator) {
        this.lDirAlloc = localAllocator;
    }     
    
    /**
     * Create a local map output file name.
     * 
     * @param size the size of the file
     * @return path
     * @throws IOException
     */
    public Path getOutputFileForWrite(long size)
        throws IOException {
      return new Path(lDirAlloc.getLocalFileForWrite(getOutputFileName(), size));
    }

    /**
     * Create a local map spill file name.
     * 
     * @param spillNumber the number
     * @param size the size of the file
     * @return path
     * @throws IOException
     */
    public Path getSpillFileForWrite(int spillNumber, long size)
        throws IOException {
      return new Path(lDirAlloc.getLocalFileForWrite(getSpillFileName(spillNumber) , size));
    }
        
    public static Path getFileIndex(Path spillFilePath) {
        return spillFilePath.getParentFile().cat(spillFilePath.getName() +  MAP_OUT_INDEX_SUFFIX);
    }
    
    public static String getOutputFileName() {
        return MAP_OUT_FILE_NAME;
    }
    
    public static String getOutputIndexFileName() {
        return getOutputFileName() + MAP_OUT_INDEX_SUFFIX;
    }
    
    public static String getSpillFileName(int spillNumber) {
        return "spill." + spillNumber;
    }
    
    public static String getSpillIndexFileName(int spillNumber) {
        return getSpillFileName(spillNumber) + ".index";
    }
}
