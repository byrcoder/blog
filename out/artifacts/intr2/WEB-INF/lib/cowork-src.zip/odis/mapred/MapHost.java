package odis.mapred;

import java.util.ArrayList;
import java.util.List;

public class MapHost {

    public static enum State {
      IDLE,               // No map outputs available
      BUSY,               // Map outputs are being fetched
      PENDING,            // Known map outputs which need to be fetched
      PENALIZED           // Host penalized due to shuffle failures
    }
    
    private State state = State.IDLE;
    private final String hostName;
    private final String baseUrl;
    private List<TaskID> maps = new ArrayList<TaskID>();
    private long penalizeTime = -1;
    
    public MapHost(String hostName, String baseUrl) {
      this.hostName = hostName;
      this.baseUrl = baseUrl;
    }
    
    public synchronized State getState() {
      return state;
    }

    public String getHostName() {
      return hostName;
    }

    public synchronized TaskID peekMaps() {
        return maps.size() > 0 ? maps.get(0) : null; 
    }
    
    public String getBaseUrl() {
      return baseUrl;
    }

    public synchronized void addKnownMap(TaskID mapId) {
      maps.add(mapId);
      if (state == State.IDLE) {
        state = State.PENDING;
      }
    }
    
    public synchronized void lostMap(TaskID mapId) {
        maps.remove(mapId);
        if (maps.isEmpty()) {
            state = State.IDLE;
        }
    }
    
    public synchronized List<TaskID> getAndClearKnownMaps() {
      List<TaskID> currentKnownMaps = maps;
      maps = new ArrayList<TaskID>();
      return currentKnownMaps;
    }
    
    public synchronized void markBusy() {
      state = State.BUSY;
    }
    
    public synchronized void markPenalized() {
      state = State.PENALIZED;
      penalizeTime = System.currentTimeMillis();
    }
    
    public long getPenalizedTime() {
        return penalizeTime;
    }
    
    public synchronized int getNumKnownMapOutputs() {
      return maps.size();
    }

    /**
     * Called when the node is done with its penalty or done copying.
     * @return the host's new state
     */
    public synchronized State markAvailable() {
      if (maps.isEmpty()) {
        state = State.IDLE;
      } else {
        state = State.PENDING;
      }
      return state;
    }
    
    @Override
    public String toString() {
      return hostName;
    }
    
    public int hashCode() {
        return hostName.hashCode();
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o != null && o instanceof MapHost) {
            MapHost that = (MapHost)o;
            return this.hostName.equals(that.hostName) && this.state.equals(that.state);
        }
        return false;
    }
}
