package odis.mapred;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;

import odis.cowork.CoWorkUtils;
import odis.cowork.JobConfig;
import odis.cowork.TaskRunnable;
import odis.io.Path;
import odis.mapred.lib.GenericFileSplitter;
import odis.mapred.lib.PerKeyBufferedWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.comparator.BinaryComparator;
import toolbox.misc.ClassUtils;

/**
 * Map-reduce start jobs
 * 
 * ioPhase and stage
 * 
 *                  0             1                    N - 1
 *               ioPhase       ioPhase       ...      ioPhase           
 *              /       \     /       \              /       \
 *              
 *    INPUT ==> map-reduce -> map-reduce --> ... --> map-reduce => OUTPUT
 *    
 *         \     /       \     /      \     /   \     /       \     /
 *          stage         stage        stage ... stage         stage
 *            0             1            2       N - 1           N
 *           
 * 
 * @author david
 * 
 * ChangeLog:
 * (zl): 2006/3/21
 *   - add complete support form MR include input/output
 *   - remove the need of IReduceMapper
 */

public class MrStarJobDef extends MapReduceJobDef {

  private static final String MR_NUMBER  = "jobdef.mrstar.mr_number";
  
  @Override
  protected String getTypeName() {  return "MapReduceStar"; }
  protected String getTypeClass() { return MrStarJobDef.class.getName(); }
  
  public MrStarJobDef() { super(); }
  
  public MrStarJobDef(int mrNum) {
    initialize(mrNum);
  }
  
  @SuppressWarnings("unchecked")
  private void initialize(int mrNum) {
    if (mrNum==1)
      throw new RuntimeException("For 1-MR process, please use MapReduceJobDef intead of Mr*");
    // dynamic definitions
    this.stageNames = new String[mrNum+1];
    this.stageXfaces = new String[mrNum+1];
    stageNames[0] = "map"; stageXfaces[0] = MapTaskRunnable.class.getName();
    for (int i=1; i<mrNum; i++) {
      stageNames[i] = "reduce-map";
      stageXfaces[i] = MrTaskRunnable.class.getName();
    }
    stageNames[mrNum] = "reduce"; stageXfaces[mrNum] = ReduceTaskRunnable.class.getName();
    // default parameters
    this.jobName = "job";
    this.workerNum = 1;
    this.taskClasses = new String[mrNum+1];
    this.taskNumbers = new int[mrNum+1];
    this.taskPerMachine = new int[mrNum+1];
    this.exclusiveOwn = new boolean[mrNum+1];
    taskClasses[0] = MapTask.class.getName(); taskClasses[mrNum] = ReduceTask.class.getName();
    taskNumbers[0] = 1; taskNumbers[mrNum] = 1;
    taskPerMachine[0] = 0; taskPerMachine[mrNum] = 0;
    exclusiveOwn[0] = false; exclusiveOwn[mrNum] = false;
    for (int i=1; i<mrNum; i++) {
      taskClasses[i] = MrTask.class.getName();
      taskNumbers[i] = 1; taskPerMachine[i] = 0;  exclusiveOwn[i] = false;
    }
    // special default parameters
    inputSplits = new ITaskInputSplit[mrNum][][];
  }

  /** This is a dynamic class, no static definitions */
  @Override
  protected void staticDefine() { }
  @Override
  protected void loadConfig(JobConfig conf) {
    int mrNum = conf.getInt(MR_NUMBER,1);
    initialize(mrNum);
    super.loadConfig(conf);
  }
  @Override
  protected void saveConfig() {
    JobConfig conf = getConfig();
    conf.setInt(MR_NUMBER,getIoPhaseNum());
    super.saveConfig();
  }
  
  @Override
  public int getIoPhase(int type, int stage) {
    switch (type) {
      case TYPE_INPUT: case TYPE_PARTITIONER:
        if (stage < getIoPhaseNum())
          return stage;
        else
          break;
      case TYPE_MERGER: case TYPE_OUTPUT:
        if (stage > 0)
          return stage - 1;
        else
          break;
    } // switch
    throw new RuntimeException("Invalid type (" + type + ") and stage (" 
      + stage + ") + for this job.");
  }

  public int getIoPhaseNum() { return getTotalStage()-1; }
  
  public int getStage(int type, int ioPhase) {
    if (ioPhase<0 && ioPhase>=getIoPhaseNum())
      throw new RuntimeException("IO Phase # " + ioPhase + " is out of range");
      switch (type) {
        case TYPE_INPUT: case TYPE_PARTITIONER:
          return ioPhase;
        case TYPE_MERGER: case TYPE_OUTPUT:
          return ioPhase+1;
      } // switch
    throw new RuntimeException("Invalid type (" + type + ") and stage (" 
      + ioPhase + ") + for this job.");
  }

  public void setReducer(int mrPhase, Class<? extends IReducer> reducer) {
    assert 0<=mrPhase && mrPhase<getIoPhaseNum();
    getConfig().setPropClass(PR_REDUCE_REDUCER+"."+mrPhase, reducer, IReducer.class);
  }
  
  @SuppressWarnings("unchecked")
  protected IReducer getReducer(int mrPhase) {
    assert 0<=mrPhase && mrPhase<getIoPhaseNum();
    Class<? extends IReducer> cls = (Class<? extends IReducer>) 
      getConfig().getPropClass(PR_REDUCE_REDUCER+"."+mrPhase, IReducer.class, null);
    if (cls != null)
      return (IReducer) ClassUtils.newInstance(cls);
    else
      return null;
  }
  public void setMapper(int mrPhase, Class<? extends IMapper> mapper) {
    assert 0<=mrPhase && mrPhase<getIoPhaseNum();
    getConfig().setPropClass(PR_MAP_MAPPER+"."+mrPhase, mapper, IMapper.class);
  }
  protected IMapper getMapper(int mrPhase) {
    assert 0<=mrPhase && mrPhase<getIoPhaseNum();
    Class cls = getConfig().getPropClass(PR_MAP_MAPPER+"."+mrPhase, 
        IMapper.class, null);
    if (cls!=null)
      return (IMapper) ClassUtils.newInstance(cls);
    else return null;
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Set MrTaskRunnable from stage [1, io_stage_num)
  //////////////////////////////////////////////////////////////////////////////
  public Class<? extends TaskRunnable> getMrTaskRunnable(int stage) {
    assert 0 < stage && stage < getIoPhaseNum();
    return super.getTaskClass(stage);
  }
  public void setMrTaskRunnable(int stage, Class<? extends TaskRunnable> c) {
    assert 0 < stage && stage < getIoPhaseNum();
    super.setTaskClass(stage, c);
  }
  public void setMrNumber(int stage, int num) {
    assert 0 < stage && stage < getIoPhaseNum();
    super.setTaskNumber(stage, num);
  }
  
  public void setCheckMrProgress(int stage, boolean b) {
    assert 0 < stage && stage < getIoPhaseNum();
    super.setCheckProgress(stage, b);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // add input/partitioner/merger/output at each mr phase
  //////////////////////////////////////////////////////////////////////////////
  public void setInputSplitter(int mrPhase, Class<? extends BasicSplitter> splitter) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setInputSplitter(mrPhase,splitter);
  }
  protected BasicSplitter getInputSplitter(int mrPhase) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    BasicSplitter splitter = super.getInputSplitter(mrPhase);
    if (splitter==null) splitter = new GenericFileSplitter();
    return splitter;
  }
  @Deprecated
  public int addInputDir(int mrPhase, File dir) {
      return addInputDir(mrPhase, new Path(dir));
  }
  public int addInputDir(int mrPhase, Path dir) {
    return addInputDir(mrPhase,dir,SeqFileInputFormat.class);
  }
  @Deprecated
  public int addInputDir(int mrPhase, String svcAddr, File dir) {
      return addInputDir(mrPhase, svcAddr, new Path(dir));
  }
  public int addInputDir(int mrPhase, String svcAddr, Path dir) {
      return addInputDir(mrPhase, svcAddr, dir, SeqFileInputFormat.class);
  }
  @Deprecated
  public int addInputDir(int mrPhase, File dir, Class<? extends BasicInputFormat> format) {
      return addInputDir(mrPhase, new Path(dir), format);
  }
  public int addInputDir(int mrPhase, Path dir, Class<? extends BasicInputFormat> format) {
    String svcAddr = getDefaultFsName();
    return addInputDir(mrPhase,svcAddr,dir, format);
  }
  @Deprecated
  public int addInputDir(int mrPhase, String svcAddr, File dir, Class<? extends BasicInputFormat> format) {
    return addInputDir(mrPhase, svcAddr, new Path(dir), format);  
  }
  public int addInputDir(int mrPhase, String svcAddr, Path dir, Class<? extends BasicInputFormat> format) {
      assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
      return super.addInputChannel(mrPhase,svcAddr,dir.toString(),format);
  }
  protected BasicInputFormat getInputFormat(int mrPhase, String svcUrl) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    BasicInputFormat format = super.getInputFormat(mrPhase,svcUrl);
    if (format==null) format = new SeqFileInputFormat();
    return format;
  }
  public void setPartitionerClass(int mrPhase, 
      Class<? extends BasicPartitioner> partitioner) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setPartitionerClass(mrPhase,partitioner);
  }
  public void useDefaultHashPartitioner() {
    for (int i=0; i<getIoPhaseNum(); i++) {
      super.setPartitionerClass(i, SeqFileHashPartitioner.class);
    }
  }
  protected BasicPartitioner getPartitioner(int mrPhase) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    BasicPartitioner partitioner = super.getPartitioner(mrPhase);
    return partitioner;
  }
  public void setMergeKeyValClass(int mrPhase, Class key, Class value) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setMergeKeyValClass(mrPhase,key,value);
  }
  public void setMergeKeyComparator(int mrPhase,
      Class<? extends BinaryComparator> comparator) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setMergeKeyComparator(mrPhase,comparator);
  }  
  public void setMergeValComparator(int mrPhase,
      Class<? extends BinaryComparator> comparator) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setMergeValComparator(mrPhase, comparator);   
  }
  public void setMergerClass(int mrPhase, Class<? extends BasicMerger> merger) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setMergerClass(mrPhase,merger);
  }
  protected BasicMerger getMerger(int mrPhase) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    BasicMerger merger = super.getMerger(mrPhase);
//    if (merger==null)
//        merger = new SeqFileAsyncSortMerger();
//        merger = new SeqFileSortMerger();
    return merger;
  }
  public void setMergeCompressed(int mrPhase, boolean v) {
      assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
      super.setMergeTransferCompressed(mrPhase, v);
  }
  public boolean getMergeCompressed(int mrPhase) {
      assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
      return super.getMergeTransferCompressed(mrPhase);
  }
  public void setWalkerClass(int mrPhase, Class<? extends IWritablePairWalker> walker) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    super.setWalkerClass(mrPhase,walker);
  }
  protected IWritablePairWalker getWalker(int mrPhase) {
    assert 0 <= mrPhase && mrPhase < getIoPhaseNum();
    IWritablePairWalker walker = super.getWalker(mrPhase);
    if (walker==null) walker = new PerKeyBufferedWalker();
    return walker;
  }
  @Deprecated
  public void addOutputDir(int mrPhase, int channel, File dir, 
          Class<? extends IWritableComparable> key, Class<? extends IWritable> value) {
      addOutputDir(mrPhase, channel, new Path(dir), key, value);
  }
  public void addOutputDir(int mrPhase, int channel, Path dir, 
      Class<? extends IWritableComparable> key, Class<? extends IWritable> value) {
    this.addOutputDir(mrPhase,channel,dir,key,value, SeqFileOutputFormat.class);
  }
  @Deprecated
  public void addOutputDir(int mrPhase, int channel, File dir, 
          Class<? extends IWritableComparable> key,
          Class<? extends IWritable> value, Class<? extends BasicOutputFormat> format) {
      addOutputDir(mrPhase, channel, new Path(dir), key, value, format);
  }
  public void addOutputDir(int mrPhase, int channel, Path dir, 
      Class<? extends IWritableComparable> key,
      Class<? extends IWritable> value, Class<? extends BasicOutputFormat> format) {
    assert 0 <= mrPhase && mrPhase <= getIoPhaseNum();
    String svcAddr = getDefaultFsName();
    super.addOutputChannel(mrPhase, channel, svcAddr, dir.toString(), key, value, format);
  }
  protected BasicOutputFormat getOutputFormat(int mrPhase, int channel) {
    BasicOutputFormat out = super.getOutputFormat(mrPhase, channel);
    if (out==null) out = new SeqFileOutputFormat();
    return out;
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Combiner for the MapTask in the first io stage
  //////////////////////////////////////////////////////////////////////////////
  public void setCombinerClass(int mrPhase, Class<? extends IReducer> combiner) {
    super.setCombinerClass(mrPhase, combiner);
  }
  public void setCombiningBufferSize(int mrPhase, int buff) {
    super.setCombiningBufferSize(mrPhase, buff);
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // backup execution parameters
  /////////////////////////////////////////////////////////////////////////////
  public void setMrBackupNum(int stage, int copy) {
      assert 0 < stage && stage < getIoPhaseNum();
      super.setMaxBackupNum(stage, copy);
  }
  public void setMrBackupLag(int stage, float lag) {
      assert 0 < stage && stage < getIoPhaseNum();
      super.setMaxProgressLag(stage, lag);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // get input splits
  //////////////////////////////////////////////////////////////////////////////
  private ITaskInputSplit[][][] inputSplits=null;  
  
  private void computeSplits(int taskStage) throws IOException {
    int mrPhase = getIoPhase(TYPE_INPUT, taskStage);
    inputSplits[mrPhase] = getInputSplitter(mrPhase).split(taskStage, this);
    for (int i=0; i<inputSplits[mrPhase].length; i++)
      LOG.fine("Split " + i + ": " + Arrays.toString(inputSplits[mrPhase][i]));    
  }

  protected ITaskInputSplit[] getInputSplits(int part) throws IOException {
    return this.getInputSplits(0,part);
  }

  protected ITaskInputSplit[] getInputSplits(int taskStage, int part) throws IOException {
    int mrPhase = getIoPhase(TYPE_INPUT, taskStage);
    if (inputSplits[mrPhase]==null) {
        String cached = this.getConfig().getString("mapred.mr.inputs.splits.stage_" + mrPhase);
        if (cached == null) {
            computeSplits(taskStage);
        } else {
            inputSplits[mrPhase] = CoWorkUtils.stringToSplits(cached);
        }
    }
    return inputSplits[mrPhase][part];
  }  
  
  /**
   * Prepare the splits for each stage, and save encoded string into job.
   */
  @Override
  protected void prepareBeforeSubmit() throws IOException {
      for (int i=0; i<inputSplits.length; i++) {
          computeSplits(i);
          String encoded = CoWorkUtils.splitsToString(inputSplits[i]);
          this.getConfig().setProperty("mapred.mr.inputs.splits.stage_" + i, encoded);
      }
  }
  
  protected boolean isValid() {
    if (!super.isValid()) return false;
    for (int i=0; i<getIoPhaseNum(); i++) {
      if (getMergeKeyClass(i)==null || getMergeValClass(i)==null) {
        LOG.warning("Please set merge key/value classes for ioPhase " + i 
          + " : see setMergeKeyValueClass()");
        return false;
      }
      BasicPartitioner partitioner = getPartitioner(i);
      if (partitioner == null) {
        LOG.warning("cannot find partitioner setting for phase " + i);
        return false;
      }
      Class partCls = partitioner.getClass();
      if (SeqFileHashPartitioner.class.isAssignableFrom(partCls)) {
          if (!checkHashCode(getMergeKeyClass(i))) {
            if (SeqFileHashPartitioner.class==partCls) {
              LOG.warning("ioPhase " + i + ": To use SeqFileHashPartitioner, " +
                 "you must override hashCode() for merge key class.");
              return false;
            } else
              LOG.warning("ioPhase " + i + ": You're using a subclass of " +
                 "SeqFileHashPartitioner without overriding hashCode() for merge key class.");
          }
      }
      // set per unit map
      try {
          if (isPerUnitSplit(i)) {
              if (inputSplits[i]==null) computeSplits(getStage(TYPE_INPUT,i));
              this.setTaskNumber(getStage(TYPE_INPUT,i), inputSplits[i].length);
          }
      } catch (IOException e) {
          LOG.log(Level.WARNING, "Cannot compute splits for per unit split in io phase " + i, e);
          return false;
      }
    }
    for (int i=1; i<getIoPhaseNum()-1; i++) {
      if (getMapper(i)==null && getReducer(i)==null) {
        LOG.warning("Please set at lease either mapper or reducer for ioPhase " 
          + i + " : see setMapper()/setReducer()");          
        return false;
      }
    }
    for (int i=0; i<getIoPhaseNum()-1; i++) {
      if (BasicPartitioner.isObjectCompress(this, i) && 
          getConfig().getProperty(PR_MR_VAL_COMPARATOR+"."+ i) != null) {
        LOG.warning("Cannot use map output compression with valcomparator");
        return false;
      }
    }
    return true;
  }

}
