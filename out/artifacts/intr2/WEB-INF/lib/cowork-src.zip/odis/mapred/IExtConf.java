package odis.mapred;

import odis.cowork.JobDef;

/**
 * The configuration of extenal plug-in.
 * 
 * @author zl, David
 *
 */
public interface IExtConf {
    /**
     * Load the content of this extension configuration from job definition
     * @param job job definition
     */
    public void loadFrom(JobDef job);

    /**
     * Save the content of this extension configuration to job definition
     * @param job job definition
     */
    public void saveTo(JobDef job);
}
