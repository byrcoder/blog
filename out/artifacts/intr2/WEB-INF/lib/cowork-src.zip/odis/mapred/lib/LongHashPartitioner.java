/**
 * @(#)LongHashPartitioner.java, 2007-6-6. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import odis.serialize.lib.LongWritable;

/**
 * Partitioner for LongWritable and subclasses of LongWritable(such as DocID and SiteID).
 * @author river
 */
public class LongHashPartitioner extends SeqFileHashPartitioner {

    public static int getPartition(long key, int partitionNumber) {
        return (int) ((key & Long.MAX_VALUE) % partitionNumber);
    }

    public static int getPartition(LongWritable key, int partitionNumber) {
        return (int) ((key.get() & Long.MAX_VALUE) % partitionNumber);
    }

    public int getPartition(Object key, Object value, int numPartitions) {
        return getPartition((LongWritable) key, numPartitions);
    }
    
}
