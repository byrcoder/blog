package odis.mapred;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.cowork.CoWorkUtils;
import odis.cowork.CounterMap;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.IFileMerger.Segment;
import odis.mapred.SpillRecord.IndexRecord;
import odis.mapred.lib.QuickSort;
import odis.serialize.IWritable;
import odis.serialize.comparator.BinaryComparator;
import odis.util.LocalDirAllocator;
import toolbox.misc.LogFormatter;

public class BufferedMapCollector2<K extends IWritable, V extends IWritable> implements ICollector{
    protected static final Logger LOG = LogFormatter.getLogger(BufferedMapCollector2.class);
    protected final static int MERGE_FACTOR = OdisLibConfig.conf().getInt("cowork.map.merge.factor", 50); // m byte

    protected static final String SPILL_IN_DIR_NAME = "spill.in";
    private final static int APPROX_HEADER_LENGTH = 150;
    public static final int MAP_OUTPUT_INDEX_RECORD_LENGTH = 24;
    
    protected Throwable outputError = null;
    
    private int totalBufSize;
    private int bufferNum;
    private int flushGapSize;
    
    protected BasicPartitioner partitioner;
    TaskRunnable task;
    BasicInOutJobDef job;
//    IRecordComparator recordComparator;
    Class keyClass, valClass;
    FileSystem lfs;
    
    protected int totalPartNum;
    protected String localDir;
    protected int taskPartIdx;
        
    SpillThread spillThread = new SpillThread();        
    
    BlockingQueue<IndexedBuffer> emptyBufs = new LinkedBlockingQueue<IndexedBuffer>();
    BlockingQueue<IndexedBuffer> fullBufs = new LinkedBlockingQueue<IndexedBuffer>();
    ArrayList<IndexedBuffer> bufList = new ArrayList<IndexedBuffer>();
    
    final ArrayList<SpillRecord> indexCacheList = new ArrayList<SpillRecord>(); 
    final ArrayList<Path> spillFileList = new ArrayList<Path>();
    
    final BinaryComparator keyComparator;
    final BinaryComparator valueCompartor;
    
    CombinerRunner combinerRunner = null;
    CombineOutputCollector combineCollector = null;
    
    CompressAlgo compressAlgo;
    boolean useCompress;
    
    MapOutputFile mapOutputFile = null;
    LocalDirAllocator localDirAllocator = null;

    final CounterMap.Counter spilledRecordsCounter;
    CounterMap.Counter combineOutputCounter = null;
    CounterMap.Counter combineOutputSizeCounter = null;
    
    CounterMap.Counter recordCounter;
    CounterMap.Counter sizeCounter;
    
//    public BufferedMapCollector2(BasicInOutJobDef job, TaskRunnable task) throws IOException{
//        this(job, task, null, null);
//    }
    
    /**
     * init the buffer
     * @param task
     * @param job
     * @throws IOException
     */
    public BufferedMapCollector2(BasicInOutJobDef job, TaskRunnable task, CounterMap.Counter recordCounter, CounterMap.Counter sizeCounter) throws IOException{    
        this.recordCounter = recordCounter;
        this.sizeCounter = sizeCounter;
        int ioPhase = MapRedUtil.getMrMergePhase(task.getStageIdx() + 1, job);
        
        //main buffer
        totalBufSize = getMapOutBufferSize(task.getStageIdx(), job);
        bufferNum = getMapBufferNumber(task.getStageIdx(),job);
        flushGapSize = getBufferFlushGap(task.getStageIdx(),job);
        
        //part number of next stage
        totalPartNum = job.getTaskNumber(task.getStageIdx() + 1);
        this.partitioner = ((MapReduceJobDef)job).getPartitioner();        
        this.task = task;
        this.job = job;
        this.localDir = task.getWorker().getLocalDir();
        this.taskPartIdx = task.getPartIdx();
        this.lfs = FileSystem.getNamed("local");
                                
        keyClass = job.getMergeKeyClass(ioPhase);
        valClass = job.getMergeValClass(ioPhase);
        keyComparator = job.getMergeKeyComparator(ioPhase);
        valueCompartor = job.getMergeValComparator(ioPhase);
        assert keyClass!=null && valClass!=null : 
            "Must set merge key & value classes using setMergeKeyValClass()";

        
        localDirAllocator = task.getWorker().getLocalDirAllocator();
        mapOutputFile = new MapOutputFile(localDirAllocator);
        
        //compress
        useCompress = partitioner.getCompress(job, ioPhase);
        if (useCompress) {
            compressAlgo = partitioner.getCompressAlgo(job, ioPhase);
            LOG.info("Use compress algo " + compressAlgo.name());
        }else {
            LOG.info("Don't compress map output.");
            compressAlgo = null;
        }
        
        // combiner
        if (job.getCombiner(ioPhase) != null) {
//            final CounterMap.Counter combineInputPairCounter = task.getCounter(MapTaskRunnable.CT_COMBINE_IN_PAIR);
            combinerRunner = CombinerRunner.create(job, task, ioPhase, null);            
            combineOutputCounter = task.getCounter(MapTaskRunnable.CT_COMBINE_OUT_RECORD);
            combineOutputSizeCounter = task.getCounter(MapTaskRunnable.CT_COMBINE_OUT_SIZE);
            combineCollector = new CombineOutputCollector<K, V>(null);
        } else {
            combineCollector = null;
            combinerRunner = null;
        }

        try {
            for (int i = 0; i < bufferNum; ++i) {
                IndexedBuffer buffer = new IndexedBuffer(totalBufSize/bufferNum, MAX_RECORD_NUM);
                emptyBufs.put(buffer);
                bufList.add(buffer);
            }
        }catch(InterruptedException e) { throw new RuntimeException(e); }
        spillThread.start();                
        
        spilledRecordsCounter = task.getCounter(MapTaskRunnable.CT_SPILLED_RECORD);
    }
            
    @Override
    public void collect(Object key, Object value) {
        collectToPartition(partitioner.getPartition(key, value, totalPartNum), key, value);
    }

    @Override
    public void collectDoneMsg(String msg) {
        task.setDoneMsg(msg);
    }

    @Override
    public void collectToChannel(int channel, Object key, Object value) {
        throw new TaskFatalException("Method not implemented for " 
                + this.getClass().getName());
    }

    IndexedBuffer curBuf = null;
    
    @Override
    public synchronized void collectToPartition(int part, Object key, Object value) {
        checkException();
        try {         
            if (curBuf == null) {
                long start = System.currentTimeMillis();
                curBuf = emptyBufs.take();
                LOG.info("Wait buffer use " + (System.currentTimeMillis() - start) + " ms");
            }                
            checkException();
            
            int preSize = curBuf.size();
            ((IWritable)key).writeFields(curBuf);
            int keyLen = curBuf.size() - preSize;
            ((IWritable)value).writeFields(curBuf);
            int valLen = curBuf.size() - preSize - keyLen;
            
            curBuf.addRecord(preSize, keyLen, valLen, part);
            
            if (recordCounter != null) recordCounter.inc();
            if (sizeCounter != null) sizeCounter.inc(curBuf.size() - preSize);
            
            if (curBuf.isNearFull(flushGapSize)) {
                fullBufs.put(curBuf);
                curBuf = null;
            }
            
        }catch (IOException e) {
            outputError = e;
            e.printStackTrace();
            throw new RuntimeException("IOException in " + this.getClass().getName() 
                    + ".collectToParition()", e);
        }catch (Throwable e) {
            outputError = e;
            e.printStackTrace();
            throw new RuntimeException("Unexpected error in " + 
                    this.getClass().getName() + 
                    ".collectToPartition(" + part + ")", e);
        }
    }    
    
    private static final int INDEX_GROW_UNIT = 256 * 1024; 
    class IndexedBuffer extends DataOutputBuffer implements IndexedSortable {
        int [] parts;
        int [] offs;
        int [] keyLens;
        int [] valLens;        
        int cur;
        
        int maxSize;
        int curBufSize;
        int maxRecordNum;

        public IndexedBuffer() {
            maxSize = 0;
            maxRecordNum = 0;
            cur = 0;
        }
        
        public IndexedBuffer(int size, int maxRecordNum) {
            super(4 * 1024 * 1024); // 4M
            curBufSize = getData().length;
            LOG.info("Init indexed buffer with max size " + size + ", max record:" + maxRecordNum);
            maxSize = size;
            parts = new int[INDEX_GROW_UNIT];
            offs = new int[INDEX_GROW_UNIT];
            keyLens = new int[INDEX_GROW_UNIT];
            valLens = new int[INDEX_GROW_UNIT];
            cur = 0;
            this.maxRecordNum = maxRecordNum;
        }
        
        protected void ensureIndexSize() {
            if (cur + 1 >= offs.length) {
                if (offs.length >= maxRecordNum) return;                
                int newlen = offs.length + INDEX_GROW_UNIT;
                if (newlen > maxRecordNum) newlen = maxRecordNum;
                
                LOG.info("Enlarge index size from " + offs.length + " to " + newlen);
                int [] otherOffs = new int[newlen];
                System.arraycopy(offs, 0, otherOffs, 0, offs.length);
                offs = otherOffs;

                int [] otherKeyLens= new int[newlen];
                System.arraycopy(keyLens, 0, otherKeyLens, 0, keyLens.length);
                keyLens = otherKeyLens;

                int [] otherValLens = new int[newlen];
                System.arraycopy(valLens, 0, otherValLens, 0, valLens.length);
                valLens = otherValLens;           
                
                int [] otherParts= new int[newlen];
                System.arraycopy(parts, 0, otherParts, 0, parts.length);
                parts = otherParts;  
            }
        }
        
        protected void grow() {
            int oldLen = super.getData().length;
            if (oldLen >= maxSize) return;            
            int newLen = (oldLen * 2 > maxSize ? maxSize : oldLen * 2 );
            
            super.ensureFreeSpace(newLen - size());
            curBufSize = super.getData().length;
            LOG.info("Enlarge local read buffer from " + oldLen + "  to " + curBufSize + " when used " + super.size());
        }
        
        public int getMaxSize() { return maxSize; }
        
        public boolean isNearFull(int gapSize) {
            if (curBufSize - size() < gapSize) {
                grow();
            }
            return (maxSize - size() < gapSize) || (cur >= maxRecordNum - 2);
        }
        
        @Override
        public DataOutputBuffer reset() {
            super.reset();
            cur = 0;
            return this;
        }
                
        public int size() {
            return super.size();
        }
        
        public int getRecordNum() {
            return cur;
        }
                
        public void addRecord(int startOffset, int keyLength, int valLength, int part) {
            ensureIndexSize();
            offs[cur] = startOffset;
            keyLens[cur] = keyLength;
            valLens[cur] = valLength;
            parts[cur] = part;
            ++cur;
        }
        
        public void setRecord(int index ,int startOffset, int keyLength, int valLength, int part) {
            ensureIndexSize();
            offs[index] = startOffset;
            keyLens[index] = keyLength;
            valLens[index] = valLength;
            parts[index] = part;
        }
        
        @Override
        public int compare(int i, int j) {
            if (parts[i] != parts[j])  return parts[i] - parts[j];
            else {
                int ret = keyComparator.compare(getData(), offs[i], keyLens[i], getData(), offs[j], keyLens[j]);
                if (ret != 0 || valueCompartor == null) return ret;
                else {
                    return valueCompartor.compare(getData(), offs[i] + keyLens[i], valLens[i], getData(), offs[j] + keyLens[j], valLens[j]);
                }                
            }
        }

        @Override
        public void swap(int i, int j) {
            int part = parts[i];
            int soffset = offs[i];
            int keylen = keyLens[i];
            int valen = valLens[i];
            this.setRecord(i, offs[j], keyLens[j], valLens[j], parts[j]);
            this.setRecord(j, soffset, keylen, valen, part);            
        }        
    }

    private int [] partsRecordNum = null; 
    private QuickSort quickSort = new QuickSort(); //use to sort buffer
    int numSpills = 0;
    /**
     * flush buffer data, and add index in memory
     * @throws IOException
     */
    protected void sortAndSpill(IndexedBuffer indexedBuf) throws IOException{
        if (indexedBuf.size() > 0) {
            if (partsRecordNum == null) {
                partsRecordNum = new int[totalPartNum];
                Arrays.fill(partsRecordNum, 0);
             }

            DataOutputBuffer buf = indexedBuf;
            LOG.info("Begin to flush memory, size: " + buf.size() + " to files. ");
            long startTime = System.currentTimeMillis();        
            // sort index
            quickSort.sort(indexedBuf, 0, indexedBuf.getRecordNum());            
            LOG.info("Sort complete, use time: " + (System.currentTimeMillis() - startTime) + " , record num: " + indexedBuf.getRecordNum());

            FSDataOutputStream out = null;            
            try {
                final SpillRecord spillRec = new SpillRecord(totalPartNum);
                final Path filename = mapOutputFile.getSpillFileForWrite(numSpills, indexedBuf.size());
                out = lfs.create(filename);
                
                final IndexRecord rec = new IndexRecord();
                int curRecord = 0;
                for (int i = 0; i < totalPartNum; ++i) {
                    IFile.Writer<K, V> writer = null;
                    try {
                        long segmentStart = out.getPos();
                        writer = new IFile.Writer<K, V>(out, keyClass, valClass, compressAlgo, spilledRecordsCounter);
                        if (combinerRunner == null) {
                            // spill directly                                                        
                            while (curRecord < indexedBuf.getRecordNum()) {
                                if (indexedBuf.parts[curRecord] != i) break;                                    
                                writer.append(buf.getData(), indexedBuf.offs[curRecord], indexedBuf.keyLens[curRecord], indexedBuf.valLens[curRecord]);
                                ++curRecord;
                            }                                                                                                                
                        } else {
                            //run combiner                            
                            combineCollector.setWriter(writer);
                            BufferResultIterator kvIter = new BufferResultIterator(indexedBuf, curRecord,i);
                            combinerRunner.combine(
                                    new CombinerRunner.RawKeyValueRecordReader(
                                            kvIter,
                                            keyClass,
                                            valClass,
                                            task.getCounter(MapTaskRunnable.CT_COMBINE_IN_RECORD)),
                                    combineCollector);
                            
                            curRecord = kvIter.getLastRecordPos();
                        }

                        // close the writer
                        writer.close();

                        // record offsets
                        rec.startOffset = segmentStart;
                        rec.rawLength = writer.getRawLength();
                        rec.partLength = writer.getCompressedLength();
                        spillRec.putIndex(rec, i);

                        writer = null;
                    } finally {
                        if (null != writer)
                            writer.close();
                    }
                    
                } //end for
                
                    // create spill index file
                Path indexFilename = MapOutputFile.getFileIndex(filename);
                spillRec.writeToFile(indexFilename);
//                indexCacheList.add(spillRec);
                LOG.info("Finished spill " + numSpills + ", size=" + lfs.getLength(filename) + ", indexSize=" + lfs.getLength(indexFilename));
                ++numSpills;
                spillFileList.add(filename);
            } finally {
                if (out != null) {
                    out.close();
                }
            }

            LOG.info("End spill the buffer. use time: " + (System.currentTimeMillis() - startTime));
        }else
            LOG.warning("Buffer is empty when spill the buffer!");

    }
    
    public Throwable getError() {
        return outputError;
    }
    
    public void close() throws IOException{
        LOG.info("Finishing " + this.getClass().getName() + " of " + task.getTaskId() );
        
        try {
            if (curBuf != null && curBuf.getRecordNum() > 0)
                fullBufs.put(curBuf);
            spillThread.shutdown();
            spillThread.join();
        } catch (InterruptedException e) {
            LOG.severe("Finish collect error. " + e);
            throw new RuntimeException(e);
        }

        for (IndexedBuffer buf: bufList) {
            buf.reset(0);
        }
        bufList.clear();

        mergeParts();
    }
                   
    public Path getFinalOutputFile() {
        return finalOutputFile;
    }
    
    Path finalOutputFile = null;
    private void mergeParts() throws IOException{
        LOG.info("Start merge " + spillFileList.size() + " spills.");
        // get the approximate size of the final output/index files
        long finalOutFileSize = 0;
        long finalIndexFileSize = 0;
        final Path[] filename = new Path[numSpills];
        
        for (int i = 0; i < numSpills; i++) {
            filename[i] = spillFileList.get(i);
            finalOutFileSize += lfs.getLength(filename[i]);
        }
        if (numSpills == 1) { // the spill is the final output
            finalOutputFile = new Path(filename[0].getParent(),MapOutputFile.MAP_OUT_FILE_NAME);
            lfs.rename(filename[0], finalOutputFile);
            if (indexCacheList.size() == 0) {
                lfs.rename(MapOutputFile.getFileIndex(spillFileList.get(0)), 
                        MapOutputFile.getFileIndex(finalOutputFile));
            } else {
                indexCacheList.get(0).writeToFile(MapOutputFile.getFileIndex(finalOutputFile));
            }
            
            if (combineOutputCounter != null) {
                combineOutputCounter.inc(spilledRecordsCounter.get());
            }
            
            if (this.combineOutputSizeCounter != null) {
                long len = lfs.getLength(finalOutputFile);
                this.combineOutputSizeCounter.inc(len);
            }            
            return;
        }

        // read in paged indices
        for (int i = indexCacheList.size(); i < numSpills; ++i) {
            Path indexFileName = MapOutputFile.getFileIndex(spillFileList.get(i));
            indexCacheList.add(new SpillRecord(indexFileName));
        }

        // make correction in the length to include the sequence file header
        // lengths for each partition
        finalIndexFileSize = totalPartNum * MAP_OUTPUT_INDEX_RECORD_LENGTH;
        finalOutFileSize += totalPartNum * APPROX_HEADER_LENGTH;
        finalOutFileSize += finalOutFileSize;
        finalOutputFile = mapOutputFile.getOutputFileForWrite(finalOutFileSize);
        Path finalIndexFile = mapOutputFile.getFileIndex(finalOutputFile);

        // The output stream for the final single output file
        FSDataOutputStream finalOut = lfs.create(finalOutputFile, true, 4096);

        if (numSpills == 0) {
            // create dummy files
            IndexRecord rec = new IndexRecord();
            SpillRecord sr = new SpillRecord(totalPartNum);
            try {
                for (int i = 0; i < totalPartNum; i++) {
                    long segmentStart = finalOut.getPos();
                    IFile.Writer<K, V> writer = new IFile.Writer<K, V>(finalOut,keyClass, valClass, compressAlgo, null);
                    writer.close();
                    rec.startOffset = segmentStart;
                    rec.rawLength = writer.getRawLength();
                    rec.partLength = writer.getCompressedLength();
                    sr.putIndex(rec, i);
                }
                sr.writeToFile(finalIndexFile);
            } finally {
                finalOut.close();
            }
            return;
        }
        {
//            sortPhase.addPhases(partitions); // Divide sort phase into
                                             // sub-phases
            IFileMerger.considerFinalMergeForProgress();

            IndexRecord rec = new IndexRecord();
            final SpillRecord spillRec = new SpillRecord(totalPartNum);
            for (int parts = 0; parts < totalPartNum; parts++) {
                // create the segments to be merged
                List<Segment<K, V>> segmentList = new ArrayList<Segment<K, V>>(
                        numSpills);
                for (int i = 0; i < numSpills; i++) {
                    IndexRecord indexRecord = indexCacheList.get(i).getIndex(
                            parts);

                    Segment<K, V> s = new Segment<K, V>(job.getConfig(), lfs, filename[i],
                            indexRecord.startOffset, indexRecord.partLength,
                            compressAlgo, true);
                    segmentList.add(i, s);

                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.fine(" Reducer=" + parts
                                + "Spill =" + i + "(" + indexRecord.startOffset
                                + "," + indexRecord.rawLength + ", "
                                + indexRecord.partLength + ")");
                    }
                }

                int mergeFactor = job.getConfig().getInt(MRConfig.MAP_SORT_MERGE_FACTOR, 100);
                // sort the segments only if there are intermediate merges
                boolean sortSegments = segmentList.size() > mergeFactor;
                // merge
                @SuppressWarnings("unchecked")
                RawKeyValueIterator kvIter = IFileMerger.merge(job.getConfig(), localDirAllocator, lfs, keyClass,
                        valClass, compressAlgo, segmentList, mergeFactor, -1,
                        keyComparator, valueCompartor, sortSegments,
                        null, spilledRecordsCounter);

                int minSpillsForCombine = job.getConfig().getInt(MRConfig.MAP_COMBINE_MIN_SPILLS, 3);
                // write merged output to disk
                long segmentStart = finalOut.getPos();
                IFile.Writer<K, V> writer = new IFile.Writer<K, V>(finalOut, keyClass,
                        valClass, compressAlgo, this.combineOutputCounter);
                if (combinerRunner == null || numSpills < minSpillsForCombine) {
                    IFileMerger.writeFile(kvIter, writer, job.getConfig());
                } else {
                    combineCollector.setWriter(writer);
                    combinerRunner.combine(
                            new CombinerRunner.RawKeyValueRecordReader(kvIter,
                                    keyClass, valClass), combineCollector);
                }

                // close
                writer.close();

                // record offsets
                rec.startOffset = segmentStart;
                rec.rawLength = writer.getRawLength();
                rec.partLength = writer.getCompressedLength();
                spillRec.putIndex(rec, parts);
            }
            spillRec.writeToFile(finalIndexFile);
            finalOut.close();
            for (int i = 0; i < numSpills; i++) {
                lfs.delete(filename[i]);
            }
        }
        if (this.combineOutputSizeCounter != null) {
            long len = lfs.getLength(finalOutputFile);
            this.combineOutputSizeCounter.inc(len);
        }
    }
    
    class BufferResultIterator implements RawKeyValueIterator {
        
        DataInputBuffer keyBuf, valueBuf;
        IndexedBuffer indexedBuf;
        int pos;
        int part;
        public BufferResultIterator(IndexedBuffer indexedBuf, int start, int part) {
            this.indexedBuf = indexedBuf;
            this.pos = start;
            this.part = part;
            keyBuf = new DataInputBuffer();
            valueBuf = new DataInputBuffer();
        }

        @Override
        public DataInputBuffer getKey() throws IOException {
            return keyBuf;
        }

        @Override
        public DataInputBuffer getValue() throws IOException {
            return valueBuf;
        }

        @Override
        public boolean next() throws IOException {
            if (pos >= indexedBuf.getRecordNum() || indexedBuf.parts[pos] != this.part) return false;
            
            keyBuf.reset(indexedBuf.getData(), indexedBuf.offs[pos], indexedBuf.keyLens[pos]);
            valueBuf.reset(indexedBuf.getData(), indexedBuf.offs[pos] + indexedBuf.keyLens[pos], indexedBuf.valLens[pos]);
            
            ++pos;
            return true;
        }

        public int getLastRecordPos() { return pos; }
        
        @Override
        public void close() throws IOException {
        }

        @Override
        public long getPos() throws IOException {
            throw new UnsupportedOperationException();
        }

        @Override
        public long getSize() throws IOException {
            throw new UnsupportedOperationException();
        }
        
    }
    
    protected static final int MAX_RECORD_NUM = 2 * 1024 * 1024;    
    class SpillThread extends Thread{
        @Override
        public void run() {
            try {
                while (true) {
                    IndexedBuffer fulledBuf = fullBufs.take();
                    if (fulledBuf.getMaxSize() == 0) { // empty buffer
                        assert fullBufs.size() == 0;
                        break;
                    }
                    try {
                        sortAndSpill(fulledBuf);
                    }finally{
                        fulledBuf.reset();
                        emptyBufs.put(fulledBuf); //must put back buffer                        
                    }                    
                }                
            }catch (InterruptedException e) {
                LOG.severe(CoWorkUtils.getStrackTrace(e));
                outputError = e;
            }catch (Exception e) {
                LOG.severe(CoWorkUtils.getStrackTrace(e));
                outputError = e;
            }finally{
            }                           
        }
        
        public void shutdown() {
            try {
                fullBufs.put(new IndexedBuffer()); // and empty index buffer
            }catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }        
    }
        
    public void checkException() {
        if (outputError != null)
            throw new RuntimeException(outputError);
    }    
    
    protected static int getMapOutBufferSize(int taskStage, BasicInOutJobDef conf) {
        return conf.getMapOutBufferSize(getMrPhase(taskStage, conf));
    }

    protected static int getMapBufferNumber(int taskStage, BasicInOutJobDef conf) {
        return conf.getMapOutBufferNumber(taskStage);
    }
        
    protected static int getBufferFlushGap(int taskStage, BasicInOutJobDef conf) {
        return conf.getMapOutBufferFlushGap(taskStage);
    }
    
    protected static int getMrPhase(int taskStage, BasicInOutJobDef conf) {
        return conf.getIoPhase(BasicInOutJobDef.TYPE_PARTITIONER, taskStage);
    }

    protected static Class getKeyClass(int taskStage, BasicInOutJobDef conf) {
        return conf.getMergeKeyClass(getMrPhase(taskStage, conf));
    }

    protected static Class getValClass(int taskStage, BasicInOutJobDef conf) {
        return conf.getMergeValClass(getMrPhase(taskStage, conf));
    }
    
    protected static BinaryComparator getKeyComparator(int taskStage,
            BasicInOutJobDef conf) {
        return conf.getMergeKeyComparator(getMrPhase(taskStage, conf));
    }    

    protected static BinaryComparator getValComparator(int taskStage,
            BasicInOutJobDef conf) {
        return conf.getMergeValComparator(getMrPhase(taskStage, conf));
    }
    protected static final String PR_MR_REVERSE_SORT = "mapred.reverse.sort";
    protected static boolean getReverseSort(BasicInOutJobDef jobDef, int mrPhase) {
        return jobDef.getConfig().getBoolean(PR_MR_REVERSE_SORT+"."+mrPhase, false);
    }
    

}
