package odis.mapred;

import java.io.IOException;
import java.util.Comparator;
import java.util.logging.Level;

import odis.cowork.JobDef;
import odis.cowork.Shuffle;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.cowork.CounterMap.Counter;
import odis.file.IRecordReader;
import odis.file.IRecordWriter;


public abstract class ReduceTaskRunnable extends TaskRunnable implements ICollector {

  public final static String CT_COPY_IN_SIZE = "CopyInSize";
  public final static String CT_COPY_FILE = "CopyInFile";
  public final static String CT_MERGE_FILE = "MergeFile";
  public final static String CT_MERGE_TIME = "MergeTime";
  public final static String CT_MERGE_IN_SIZE = "MergeInSize";
  public final static String CT_MERGE_IN_RECORD = "MergeInRecord";
  public final static String CT_REDUCE_IN_RECORD = "ReduceInRecord";
  public final static String CT_REDUCE_IN_SIZE = "ReduceInSize";
  public final static String CT_REDUCE_OUT_RECORD = "ReduceOutRecord";
  public final static String CT_REDUCE_OUT_SIZE = "ReduceOutSize";

  protected MapReduceJobDef mrJob;
//  protected BasicMerger merger;         // merger for reduce
  protected IWritablePairWalker walker; // walker for the reduce (key,value*)
  protected Comparator<Object> keyCmp;  // key comparator in reduce (key,value*)
  protected IRecordWriter[] out;        // output writers
  protected Throwable outputError = null;      // throwable caught on output
  
  protected Class mergeKeyClass;
  protected Class mergeValueClass;
  
  @Override
  public void configure(JobDef job, TaskWorker worker) {
    assert job instanceof MapReduceJobDef;
    this.mrJob = (MapReduceJobDef) job;
    this.worker = worker;
  }

  @SuppressWarnings("unchecked")
  @Override
  public void run() {

    startTime = System.currentTimeMillis();

    LOG.info("Starting " + this.getClass().getName() + ".run()");
    boolean isProcessDone = false;
    BasicOutputFormat[] outputFormat=null;
    try {
      // merger merging
      IRecordReader in=null;
      LOG.info("Copy map outputs and merge/sort them to local " 
              + worker.getLocalDir() + " ...");
//      this.merger = mrJob.getMerger();
      // NOTE: do not need to clean local dir in cowork 3 since each restarting
      // of a task will be in a different random local directory. -- Li
      // this.merger.clear(worker.getLocalDir());
//      in = merger.merge(this, mrJob);
      mergeKeyClass = mrJob.getMergeKeyClass();
      mergeValueClass = mrJob.getMergeValClass();
      
      Shuffle shuffle = new Shuffle(mrJob, this.getWorker(), null);
      RawKeyValueIterator kvIter = shuffle.run();
      LOG.info("Finished shuffle phase ...");
      shuffle = null;
      
      in = new CombinerRunner.RawKeyValueRecordReader(kvIter, mergeKeyClass, mergeValueClass);
      
      //check if the task is preparing task      
      try {
        // output writers
        this.out = new IRecordWriter[mrJob.getOutputChannelNum()];
        outputFormat = new BasicOutputFormat[out.length];
        for (int oc=0; oc<out.length; oc++) {
          outputFormat[oc] = mrJob.getOutputFormat(oc);
          out[oc] = outputFormat[oc].getRecordWriter(oc,this,mrJob);
        }
        // walker and key comparator
        walker = mrJob.getWalker();
        keyCmp = mrJob.getMergeKeyComparator();
        // process
        LOG.info("Process key-values in reduce ...");
        preProcess();
        setProgressFlag(true);
        try { process(in); } finally { setProgressFlag(false); }
        postProcess();
        // summarize
        LOG.info("Processed " + getCounter(CT_REDUCE_IN_RECORD).get() 
            + " record (" + getCounter(CT_REDUCE_IN_SIZE).get() + " bytes).");
        LOG.info("Output " + getCounter(CT_REDUCE_OUT_RECORD).get() 
            + " record (" + getCounter(CT_REDUCE_OUT_SIZE).get() + " bytes).");
        // till now the task is normally ended
        isProcessDone = true;
      } finally {
        if (in!=null) in.close();
        if (out!=null) {
          for (int i=0; i<out.length; i++)
            if (out[i]!=null) out[i].close();
        }
        if (isProcessDone)
          for (int oc=0; oc<outputFormat.length; oc++) outputFormat[oc].finish();        
      }
    }catch(InterruptedException e) {
        throw new RuntimeException(e);
    }catch (IOException e) {
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + ".run()", e);
    }
    if (outputError != null) {
      throw new RuntimeException("Error occur on asynchronous output", outputError);
    }
  }  
  
  public long cursor() {
      Counter ct = counters.get(CT_REDUCE_IN_RECORD);
      if (ct==null) return NON_CURSOR;
      else return getCounter(CT_REDUCE_IN_RECORD).get();
  }  
  
  protected abstract void preProcess();
  
  /**
   * NOTE: 
   * You should not change this interface to throw exception.  Supposely, all 
   * non-fatal exception should be handled inside and if the exception cannot be 
   * handled, it should be a runtime error, throw TaskFatalException instead.
   */
  protected abstract void process(IRecordReader in) throws IOException;
  
  protected abstract void postProcess();

  /**
   * Default collect will collect to all output channels
   */
  public void collect(Object key, Object value) {
    for (int i = 0; i < out.length; i ++)
      this.collectToChannel(i, key, value);
  }
  
  public void collectToPartition(int part, Object key, Object value) {
    throw new TaskFatalException("Method not implemented for " 
      + this.getClass().getName());
  }

  @SuppressWarnings("unchecked")
  public void collectToChannel(int channel, Object key, Object value) {
    try {
      if (channel<0 || channel>=out.length)
        throw new TaskFatalException("BUG: try to collect to output channel " 
          + channel + ", channel range accepted: [0," + out.length+")");
      long prevPos = out[channel].getSize();
      out[channel].write(key,value);
      if (channel == 0) {
          getCounter(CT_REDUCE_OUT_RECORD).inc();
          getCounter(CT_REDUCE_OUT_SIZE).inc(out[channel].getSize()-prevPos);          
      } else {
          getCounter(CT_REDUCE_OUT_RECORD + "-" + channel).inc();
          getCounter(CT_REDUCE_OUT_SIZE + "-" + channel).inc(out[channel].getSize()-prevPos);                    
      }
    } catch (IOException e) {
      outputError = e;
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + ".collect()", e);
    } catch (Throwable e) {
      outputError = e;
      throw new RuntimeException("Throwable in " + this.getClass().getName() + 
              ".collectToChannel(" + channel+")", e);
    }
  }
  
  public void collectDoneMsg(String msg) {
    this.doneMsg = msg;
  }

}
