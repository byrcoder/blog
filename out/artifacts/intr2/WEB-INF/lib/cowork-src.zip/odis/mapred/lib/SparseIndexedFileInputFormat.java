/**
 * @(#)SparseIndexedFileInputFormat.java, 2007-9-7. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import odis.file.SparseIndexedFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;

/**
 * Inputformat for {@link odis.file.SparsedIndexedFile}.
 * @author river
 *
 */
public class SparseIndexedFileInputFormat extends SeqFileInputFormat {

    @Override
    public String[] listParts(String svcAddr, String path) throws IOException {
        FileSystem fs = FileSystem.getNamed(svcAddr);
        
        FileInfo[] files = fs.listFiles(new Path(path));
        if (files == null) {
            throw new IOException("cannot find path " + svcAddr + ":" + path);
        }
        String[] parts = new String[files.length];
        for (int i=0; i<files.length; i++) {
            Path f = SparseIndexedFile.getDataPath(files[i].getPath());
            if (!fs.isFile(f))
                throw new IOException("The part " + f + " is not a file.");
            parts[i] = files[i].getPath().getName() + File.separator + SparseIndexedFile.DATA_FILE_NAME;
        }
        Arrays.sort(parts); // should list in a consistant same order
        return parts;
    }
    
}
