package odis.mapred.lib;

import odis.serialize.lib.BytesAccessable;
import odis.serialize.lib.MD5Writable;

/**
 * MD5-mod partitioner for "string(UTF8Writable/UTF16Writable/StringWritable/Url)" key.
 * @author river
 */
public class StringMd5Partitioner extends SeqFileHashPartitioner {

    public static int getPartition(BytesAccessable string, int numPartitions) {
        long v = MD5Writable.halfDigest(string);
        return (int) ((v & Long.MAX_VALUE) % numPartitions);
    }

    public int getPartition(Object key, Object value, int numPartitions) {
        long v = MD5Writable.halfDigest((BytesAccessable)key);
        return (int) ((v & Long.MAX_VALUE) % numPartitions);
    }
    
    
}
