/**
 * @(#)RandomPartitioner.java, 2007-7-16. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.mapred.lib;

import java.util.Random;

import odis.mapred.lib.SeqFileHashPartitioner;

/**
 * 随机将对象均匀分配到每个partition上的partitioner.
 * @author river
 */
public class RandomPartitioner extends SeqFileHashPartitioner {
    private Random rand = new Random();

    @Override
    public int getPartition(Object key, Object value, int numPartitions) {
        return rand.nextInt(numPartitions);
    }
    
}
