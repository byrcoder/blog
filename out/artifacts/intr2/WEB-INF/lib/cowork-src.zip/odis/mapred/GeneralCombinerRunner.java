package odis.mapred;

import java.io.IOException;
import java.util.Comparator;
import java.util.logging.Logger;

import odis.cowork.CounterMap;
import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import toolbox.misc.LogFormatter;

/**
 * 
 * @author tuqc
 *
 */
public class GeneralCombinerRunner<K,V> extends CombinerRunner<K,V>{
    protected static final Logger LOG = LogFormatter.getLogger(GeneralCombinerRunner.class);
    protected Comparator<Object> keyCmp;
    protected IWritablePairWalker walker;
    protected JobDef job;
    protected TaskRunnable task;
    CounterMap.Counter inputCounter;
    IReducer reducer;
    int phase;
    
    public GeneralCombinerRunner(BasicInOutJobDef job, TaskRunnable task, int phase,
            CounterMap.Counter inputCounter) {        
        this.phase = phase;        
        this.job = job;
        this.inputCounter = inputCounter;
        this.task = task;
        this.walker = job.getCombinerWalker(phase);        
        reducer = job.getCombiner(phase);
        
        keyCmp = job.getMergeKeyComparator(phase);
        
        LOG.info("Init combiner=" + this.getClass().getName() + ", walker=" + walker.getClass().getName() + ", keyCmp=" + keyCmp.getClass().getName());
        
        reducer.configure(job, task);        
    }
    
    @Override
    public void combine(IRecordReader recordIn, ICollector collector)
            throws IOException {
        LOG.fine("Start run combiner...");
        walker.configure(recordIn, keyCmp, job.getConfig());
        
        reducer.reduceBegin();
        
        while (walker.moreKey()) {
            reducer.reduce(walker.getKey(), walker, collector);
            if (inputCounter != null) inputCounter.inc();
        }
        
        reducer.reduceEnd(collector);
        if (inputCounter != null)
            LOG.fine("End run combiner, inputCounter=" + inputCounter.get() );
    }
}
