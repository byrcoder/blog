package odis.mapred;

import java.io.IOException;

import odis.cowork.JobDef;
import odis.cowork.TaskWorker;
import odis.file.IRecordReader;


public class ReduceTask extends ReduceTaskRunnable {

  public static final float PROCESS_START = 0.2f;

  private IReducer reducer;

  @Override
  public void configure(JobDef job, TaskWorker worker) {
    super.configure(job,worker);
    this.reducer = this.mrJob.getReducer();
    this.reducer.configure(job,this);
  }
  
  @SuppressWarnings("unchecked")
  protected void preProcess() {
    reducer.reduceBegin();
  }

  @SuppressWarnings("unchecked")
  @Override
  protected void process(IRecordReader in) throws IOException {
    long totalSize = in.getSize(), lastPos = in.getPos();
    walker.configure(in, keyCmp, mrJob.getConfig());
    while (walker.moreKey()) {
      if (toEnd) break;
      if (!isSkip()) {
        reducer.reduce(walker.getKey(), walker, this);
        if (outputError != null) {
          throw new RuntimeException("Error occur on asynchronous output", outputError);
        }
      }
      else
        LOG.warning("Skip bad record at " + cursor() + ": key=" + walker.getKey());
      // set counters
      getCounter(CT_REDUCE_IN_RECORD).inc();
      getCounter(CT_REDUCE_IN_SIZE).inc(in.getPos()-lastPos);
      lastPos = in.getPos();
      // report process
      long processed = getCounter(CT_REDUCE_IN_SIZE).get();
      progress = PROCESS_START + (1-PROCESS_START)*processed/totalSize;
      cursor.write(cursor(), time());
    }
  }
  
  protected void postProcess() {
    reducer.reduceEnd(this);
    progress = 1f;
  }

}
