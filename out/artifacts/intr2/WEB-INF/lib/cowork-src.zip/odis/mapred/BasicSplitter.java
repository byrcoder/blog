package odis.mapred;

import java.io.IOException;

public abstract class BasicSplitter {  
  
  protected abstract ITaskInputSplit[][] split(int taskStage, 
      BasicInOutJobDef job) throws IOException;
  
  /** 
   * @param taskStage task stage
   * @param conf job definition
   * @return mapreduce phase that a splitter of this stage belongs to
   */
  protected int getMrPhase(int taskStage, BasicInOutJobDef conf) {
    return conf.getIoPhase(BasicInOutJobDef.TYPE_INPUT,taskStage);
  }
  
  /** 
   * @param taskStage task stage
   * @param channel channel number
   * @param conf job definition
   * @return input service address at this task stage in this channel, e.g. host:port
   */
  protected String getSvcAddr(int taskStage, int channel, BasicInOutJobDef conf) {
    return conf.getInputSvcAddr(getMrPhase(taskStage,conf),channel);
  }
  
  /** 
   * @param taskStage task stage
   * @param channel channel number
   * @param conf job definition
   * @return input path at this task stage in this channel, e.g. file-path:start+length
   */
  protected String getPath(int taskStage, int channel, BasicInOutJobDef conf) {
    return conf.getInputPath(getMrPhase(taskStage,conf),channel);
  }
  
  /**
   * @param taskStage task stage
   * @param conf job definition
   * @return number of channels in this stage
   */
  protected int getChannelNum(int taskStage, BasicInOutJobDef conf) {
    return conf.getInputChannelNum(getMrPhase(taskStage,conf));
  }
  
  /**
   * The parts from InputFormat.listParts()
   * 
   * @param taskStage task stage
   * @param channel channel number
   * @param conf job definition
   * @return all the input parts assigned to this channel
   * @throws IOException  if an I/O error occurs
   */
  protected String[] getParts(int taskStage, int channel, BasicInOutJobDef conf) 
      throws IOException {
    int mrPhase = getMrPhase(taskStage, conf);
    String svcAddr = conf.getInputSvcAddr(mrPhase, channel);
    String path = conf.getInputPath(mrPhase, channel);
    return conf.getInputFormat(mrPhase, channel).listParts(svcAddr, path);
  }
  
  /**
   * Splitter devides input into blocks and split among blocks.  Get the per block size.
   * @param taskStage  task stage
   * @param job job definition
   * @return per block size
   */
  protected int getBlockSize(int taskStage, BasicInOutJobDef job) {
      return job.getSplitBlockSize(getMrPhase(taskStage,job));
  }
  
  /**
   * Whether to split input based on its basic unit number, e.g. file number
   * @param taskStage task stage
   * @param job job definition
   * @return whether to do per unit split
   */
  protected boolean isPerUnitSplit(int taskStage, BasicInOutJobDef job) {
      return job.isPerUnitSplit(getMrPhase(taskStage,job));
  }

}
