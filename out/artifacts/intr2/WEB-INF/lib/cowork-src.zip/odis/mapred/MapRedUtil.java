package odis.mapred;


public class MapRedUtil {

    public static int getMrMergePhase(int taskStage, BasicInOutJobDef job) {
        return job.getIoPhase(BasicInOutJobDef.TYPE_MERGER, taskStage);
    }
    
}
