package odis.mapred.ext;

import java.io.IOException;

import odis.file.IRecordReader;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.mapred.ReduceTaskRunnable;

/**
 * Allow to exit the "reduce" loop early if the goal is satified before 
 * finishing processing all records.
 * 
 * @author Li Zhuang (zl@cs.berkeley.edu, zl@rd.netease.com)
 *
 * Created on Apr 21, 2006
 * Copyright (c) 2006 Outfox Team
 */
public abstract class EarlyExitReduceTask extends ReduceTaskRunnable {

  public static final float REPORT_INTERVAL = 0.05f;
  public static final float PROCESS_START = 0.2f;

  @Override
  protected void preProcess() {
    reduceBegin();
  }

  @SuppressWarnings("unchecked")
  @Override
  protected void process(IRecordReader in) throws IOException {
      long totalSize = in.getSize(), lastPos=in.getPos();
      int count = 0;
      walker.configure(in, keyCmp, mrJob.getConfig());
      while (walker.moreKey()) {
          reduce(walker.getKey(), walker, this);
          // set counters
          getCounter(CT_REDUCE_IN_RECORD).inc();
          getCounter(CT_REDUCE_IN_SIZE).inc(in.getPos()-lastPos);
          lastPos = in.getPos();
          // report process
          long processed = getCounter(CT_REDUCE_IN_SIZE).get();
          progress = PROCESS_START + (1-PROCESS_START)*processed/totalSize;
          cursor.write(cursor(), time());
          if (isBreak()) {
              LOG.info("Early quit after processed " + count 
                      + " records, position at: " + in.getPos()+"/"+in.getSize());
              break;
          }
      }
  }
  
  protected void reduceBegin() { }
  protected abstract void reduce(Object key, IWritablePairWalker values, ICollector collector);
  protected void reduceEnd(ICollector collector) { }
  
  protected abstract boolean isBreak();

  @Override
  protected void postProcess() {
    reduceEnd(this);
    progress=1f;
  }

}
