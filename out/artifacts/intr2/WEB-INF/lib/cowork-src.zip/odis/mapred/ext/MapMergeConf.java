package odis.mapred.ext;


public class MapMergeConf extends MapOnlyMergeConf {
  
  public MapMergeConf() { taskClass = MapMergeTask.class; }
  
}
