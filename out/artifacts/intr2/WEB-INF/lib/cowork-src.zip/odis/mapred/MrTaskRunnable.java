package odis.mapred;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import odis.cowork.JobDef;
import odis.cowork.Shuffle;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.cowork.CounterMap.Counter;
import odis.file.IRecordReader;
import odis.file.IRecordWriter;

public abstract class MrTaskRunnable extends TaskRunnable implements ICollector {

  protected final static String CT_MAPPED_TIME = "MappedTime";
  protected final static String CT_MAPPED_IN_RECORD = MapTaskRunnable.CT_MAPPED_IN_RECORD; 
  protected final static String CT_MAPPED_IN_SIZE = MapTaskRunnable.CT_MAPPED_IN_SIZE;
  protected final static String CT_MAPPED_OUT_RECORD = MapTaskRunnable.CT_MAPPED_OUT_RECORD;
  protected final static String CT_MAPPED_OUT_SIZE = MapTaskRunnable.CT_MAPPED_OUT_SIZE;

  protected final static String CT_REDUCE_TIME = "ReduceTime";
  protected final static String CT_REDUCE_IN_RECORD = ReduceTaskRunnable.CT_REDUCE_IN_RECORD;
  protected final static String CT_REDUCE_IN_SIZE = ReduceTaskRunnable.CT_REDUCE_IN_SIZE;
  protected final static String CT_REDUCE_OUT_RECORD = ReduceTaskRunnable.CT_REDUCE_OUT_RECORD;
  protected final static String CT_REDUCE_OUT_SIZE = ReduceTaskRunnable.CT_REDUCE_OUT_SIZE;

  protected MrStarJobDef mrJob;
  protected IWritablePairWalker walker;    // walker for the reduce (key,value*)
  protected Comparator<Object> keyCmp;     // key comparator in reduce (key,value*)  
  protected BasicPartitioner partitioner;  // partitioner for map result
  protected BufferedMapCollector2 collector;
  protected IRecordWriter[] externalRedOut;        // outputs of current "reduce"
  protected IRecordReader mergeIn;         // merged input from output of mapper
  protected Throwable outputError = null;  // throwable caught on output

  protected long mStartTime, rStartTime;
  protected long mInputSize;
    
  protected int nextStageNum;
  @Override
  public void configure(JobDef job, TaskWorker worker) {
    assert job instanceof MrStarJobDef;
    this.mrJob = (MrStarJobDef) job;
    this.worker = worker;
    
    int nextStage = getStageIdx() + 1; //next stage
    nextStageNum = job.getTaskNumber(nextStage);
    
    resultPartCount = new int[nextStageNum];
    Arrays.fill(resultPartCount, 0);
  }
  
  @SuppressWarnings("unchecked")
  @Override
  public void run() {
    BasicOutputFormat[] externalOutputFormats = null;
    startTime = System.currentTimeMillis();

    LOG.info("Starting " + this.getClass().getName() + ".run()");
    boolean isProcessDone = false;
    try {
      try {
        // merger & merge key comparator      
        LOG.info("Copy map outputs and merge/sort them to local " + 
            worker.getLocalDir() + " ...");
        int mergerMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_MERGER, worker.getTaskRunnable().getStageIdx());
//        this.merger = mrJob.getMerger(mergerMrPhase);
        // NOTE: do not need to clean local dir in cowork 3 since each 
        // restarting of a task will be in a different random local directory. 
        // -- Li
        //this.merger.clear(worker.getLocalDir());
        this.keyCmp = mrJob.getMergeKeyComparator(mergerMrPhase);
        
        // merge output of mapper for reducer
        LOG.info("Start merging map-outs ...");
//        mergeIn = merger.merge(this, mrJob);
        
        Class mergeKeyClass = mrJob.getMergeKeyClass(mergerMrPhase);
        Class mergeValueClass = mrJob.getMergeValClass(mergerMrPhase);
        Shuffle shuffle = new Shuffle(mrJob, this.getWorker(), null);
        RawKeyValueIterator kvIter = shuffle.run();
        LOG.info("Finished shuffle phase ...");
        shuffle = null;
        
        mergeIn = new CombinerRunner.RawKeyValueRecordReader(kvIter, mergeKeyClass, mergeValueClass);
        
        // partitioner
        int partMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_PARTITIONER, 
                stage);
        partitioner = mrJob.getPartitioner(partMrPhase);
        // partition record writers        
        collector = new BufferedMapCollector2(this.mrJob, this, this.getCounter(CT_MAPPED_OUT_RECORD), this.getCounter(CT_MAPPED_OUT_SIZE));
        
        int outputMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_OUTPUT, stage);
        int channelNum = mrJob.getOutputChannelNum(outputMrPhase); 
        this.externalRedOut = new IRecordWriter[channelNum];
        externalOutputFormats = new BasicOutputFormat[externalRedOut.length];
        for (int oc = 0; oc < externalRedOut.length; oc++) {
            externalOutputFormats[oc] = mrJob.getOutputFormat(outputMrPhase, oc);
            externalRedOut[oc] = externalOutputFormats[oc].getRecordWriter(oc, this, mrJob);
        } // for oc
        // real process from input and write to outputs
        LOG.info("Partitioner and writers are ready. Starting real process ...");
                
        // process map splits
        mStartTime = System.currentTimeMillis();
        int inputMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_INPUT, stage);
        if (mrJob.getMapper(inputMrPhase) != null) {
            LOG.info("Start mr map progress...");
            ITaskInputSplit[] inputSplits = mrJob.getInputSplits(stage, 
                    this.part);
            mInputSize = 0;
            for (int i = 0; i < inputSplits.length; i ++)
                mInputSize += inputSplits[i].getLength();
            mapRun(inputSplits, mrJob);
        } else {  // didn't set mapper, should not set input channel
            assert mrJob.getInputChannelNum(inputMrPhase) == 0;
            assert mrJob.getInputSplits(stage, this.part).length == 0;
        }
        
        try {
            LOG.info("Start mr reduce progress...");
            // process reduce splits
            rStartTime = System.currentTimeMillis();
            // reduce output format & walker        
            this.walker = mrJob.getWalker(outputMrPhase);

            reduceRun(mrJob);
        } finally {
            // close merge in reader
            if (mergeIn != null) {
                mergeIn.close();
                mergeIn = null;
            }
        }
        
        // till now the task is normally ended
        isProcessDone = true;
      } finally {
          if (collector != null) {
              outputError = collector.getError();
              collector.close();
          }
          collector = null;
        if (externalRedOut != null) {
          for (int i=0; i<externalRedOut.length; i++) {
            if (externalRedOut[i]!=null) externalRedOut[i].close();
          }
        }
        if (isProcessDone && externalOutputFormats != null)
          for (int oc=0; oc<externalOutputFormats.length; oc++) externalOutputFormats[oc].finish();
      } // finally
    } catch (IOException e) {
      throw new RuntimeException("IOException in " + this.getClass().getName() 
          + ".run()", e);
    } catch(InterruptedException e) {
        throw new RuntimeException(e);
    }
    if (outputError != null) {
      throw new RuntimeException("Error occur on asynchronous output", 
              outputError);
    }
  }  
  
  public long cursor() {
      Counter mct = counters.get(CT_MAPPED_IN_RECORD);
      Counter rct = counters.get(CT_REDUCE_IN_RECORD);
      if (mct==null||rct==null) return NON_CURSOR;
      else return mct.get() + rct.get();
  }  
  
  @SuppressWarnings("unchecked")
  private void mapRun(ITaskInputSplit[] splits, MrStarJobDef mrJob) throws IOException {
    // begin real processs
    IRecordReader mapIn = null;
    mapPreProcess(splits);
    setProgressFlag(true);
    try {
      int inputMrPhase = mrJob.getIoPhase(MrStarJobDef.TYPE_INPUT,stage);
      // { process splits (start)
      for (int i=0; i<splits.length; i++) {
        LOG.info("Processing input split=" + splits[i]);
        mapIn = mrJob.getInputFormat(inputMrPhase,splits[i].getSource()).
          getRecordReader(splits[i],this,mrJob);
        mapProcess(mapIn);
        mapIn.close(); mapIn = null;
        LOG.info("Return from processing split=" + splits[i] + ", cursor="+cursor());
        if (toEnd) break;
      } // for i
      // summarize
      LOG.info("Processed " + getCounter(CT_MAPPED_IN_RECORD).get() 
          + " record (" + getCounter(CT_MAPPED_IN_SIZE).get() + " bytes).");
      LOG.info("Output " + getCounter(CT_MAPPED_OUT_RECORD).get() 
          + " record (" + getCounter(CT_MAPPED_OUT_SIZE).get() + " bytes).");
    } finally {
      setProgressFlag(false);
      if (mapIn!=null) mapIn.close();
    }
    mapPostProcess();
  }
  
  private void reduceRun(MrStarJobDef mrJob) throws IOException {
      // process
      LOG.info("Process key-values in reduce ...");
      reducePreProcess();
      setProgressFlag(true);
      try { reduceProcess(mergeIn); } finally { setProgressFlag(false); }
      reducePostProcess();
      // summarize
      LOG.info("Processed " + getCounter(CT_REDUCE_IN_RECORD).get() 
              + " record (" + getCounter(CT_REDUCE_IN_SIZE).get() + " bytes).");
      LOG.info("Output " + getCounter(CT_REDUCE_OUT_RECORD).get() 
              + " record (" + getCounter(CT_REDUCE_OUT_SIZE).get() + " bytes).");
  }

  /**
   * NOTE: 
   * You should not change this interface to throw exception.  Supposely, all 
   * non-fatal exception should be handled inside and if the exception cannot be 
   * handled, it should be a runtime error, throw TaskFatalException instead.
   */
  protected abstract void mapPreProcess(ITaskInputSplit[] splits);  
  protected abstract void mapProcess(IRecordReader in) throws IOException;
  protected abstract void mapPostProcess();
  
  /**
   * NOTE: 
   * You should not change this interface to throw exception.  Supposely, all 
   * non-fatal exception should be handled inside and if the exception cannot be 
   * handled, it should be a runtime error, throw TaskFatalException instead.
   */
  protected abstract void reducePreProcess();  
  protected abstract void reduceProcess(IRecordReader in) throws IOException;
  protected abstract void reducePostProcess();

  /**
   * Default collect() will collect <key,value> to default partition.
   */
  public void collect(Object key, Object value) {
    collectToPartition(partitioner.getPartition(key, value, nextStageNum),key,value);
  }
  
  @SuppressWarnings("unchecked")
  public void collectToPartition(int part, Object key, Object value) {
      resultPartCount[part]++;
      collector.collectToPartition(part, key, value);
  }
  
  @SuppressWarnings("unchecked")
  public void collectToChannel(int channel, Object key, Object value) {
      if (channel<0 || channel>=  externalRedOut.length)
          throw new TaskFatalException("BUG: try to collect to output channel " 
                  + channel + ", channel range accepted: [0," + (channel)+")");
      try {
          long prevPos = externalRedOut[channel].getSize();
          externalRedOut[channel].write(key,value);
          getCounter(CT_REDUCE_OUT_RECORD + "-" + channel).inc();
          getCounter(CT_REDUCE_OUT_SIZE + "-" + channel).inc(externalRedOut[channel].getSize()-prevPos);      
      } catch (IOException e) {
          outputError = e;
          throw new RuntimeException("IOException in " + this.getClass().getName() 
                  + ".collect()", e);
      } catch (Throwable e) {
          outputError = e;
          throw new RuntimeException("Unexpected exception in " + 
                  this.getClass().getName() + 
                  ".collectToChannel(" + channel + ")", e);
      }                  
  }
  
  public void collectDoneMsg(String msg) {
    this.doneMsg = msg;
  }

}
