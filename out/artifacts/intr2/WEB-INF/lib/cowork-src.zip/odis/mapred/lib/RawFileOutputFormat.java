package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.RecordFile;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.serialize.IWritable;

/**
 * The output format that stores only the raw binary content of the keys and 
 * values through calling key.writeFields() and value.writeFields().
 *  
 * @author david
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the value
 */
public class RawFileOutputFormat<K extends IWritable, V extends IWritable> 
        extends GenericFileOutputFormat<K, V> {
    @Override
    protected IRecordWriter<K, V> getRecordWriter(int channel, 
            TaskRunnable task, BasicInOutJobDef jobConf) throws IOException {
        setup(channel, task, jobConf);

        return new RecordFile.Writer<K, V>(fs, new Path(sessionFile), true) {
            public void write(K key, V value) throws IOException {
                key.writeFields(out);  value.writeFields(out);
            }
        };
    }
}
