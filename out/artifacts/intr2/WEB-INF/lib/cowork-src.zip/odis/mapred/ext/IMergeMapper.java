package odis.mapred.ext;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;

/**
 * The interface of merge-mapper.
 * @author zl, david
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the values. The values could be of different types,
 *             so specify the shared parent type here.
 */
public interface IMergeMapper<K, V> {
    /**
     * Configures the mapper. This method was called before the output pipes
     * (files) are created.
     * 
     * @param conf  the JobDef instance
     * @param task  the TaskRunnable instance
     */
    public void configure(JobDef conf, TaskRunnable task);
    /**
     * Called before the first map().
     */
    public void mapBegin();
    
    /**
     * Combines values for a given key.  Input keys must not be altered.  Typically 
     * all values
     * are combined into zero or one value.  Output pairs are collected with
     * calls to <code>collector</code>
     * 
     * @param key the key
     * @param mergeValues the channels of merge values, might be null for some channel
     * @param collector to collect combined values
     * 
     * NOTE: 
     * You should not change this interface to throw exception.  Supposely, all 
     * non-fatal exception should be handled inside and if the exception cannot be 
     * handled, it should be a runtime error, throw 
     * {@link odis.cowork.TaskFatalException} instead.
     */
    public void map(K key, IWritablePairWalker<K, V>[] mergeValues, 
            ICollector collector);
    /**
     * Called after the last map(). Some summative data can be collected here.
     * @param collector  the collector same as the one in map().
     */
    public void mapEnd(ICollector collector);
}
