package odis.mapred.lib;

import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;

public class NullMapper<K,V> extends AbstractMapper<K,V> {

    public void map(K key, V value, ICollector collector) { }

}
