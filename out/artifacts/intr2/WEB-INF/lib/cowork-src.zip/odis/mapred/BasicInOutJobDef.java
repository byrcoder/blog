package odis.mapred;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

import odis.cowork.JobDef;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.lib.PerKeyBufferedWalker;
import odis.mapred.lib.ReverseBinaryComparator;
import odis.mapred.lib.ReverseWritableComparator;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;
import toolbox.misc.ClassUtils;

/**
 * An abstract class defines a job which is composed of phases of input/output.
 *   (In,Out) ==> (In,Out) ==> (In,Out) ==> (In,Out) ....
 * The "In" and "Out" are not necessarily in the same task stage.  Every pair of
 * (In,Out) is called an <code>ioPhase</code>.  Subclasses include
 * - MapOnlyJobDef: [In->Out]
 * - MapReduceJobDef: [In]->[Out]
 * - MrStarJobDef: [In]->[Out,In]->[Out,In]->...->[Out]
 * 
 * All methods in this class must be protected.  Since this class is extended
 * by many classes which have different interfaces.  We don't want application
 * programmer use the wrong methods by mistake.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 16, 2006
 * Copyright (c) 2006, Outfox Team
 */
public abstract class BasicInOutJobDef extends JobDef {

  /**
   * Get the service url string for a resource.  In the format of:
   * host:port/<path-till-dir>.  For example:
   *  - ODFS file with name node at tb001:8888: /m5/webdb/site/@tb001:8888
   *  - File in local filesystem: /tmp/outfox/local_tm/job_xxxxx.0.0/@local
   *  - File in remote filesystem: /job_xxxxx.0.3/@tb012:34642
   */
  public static String getServiceUrl(String svcAddr, String path) {
    return path+"@"+svcAddr;
  }
  
  public static final int TYPE_INPUT = 0;
  public static final int TYPE_PARTITIONER = 1;
  public static final int TYPE_MERGER = 2;
  public static final int TYPE_OUTPUT = 3;
  
  /**
   * Get the IO phase index given the task stage index 
   *   INPUT -> PARTITIONER -> MERGER -> OUTPUT
   * @param type one of four the types above 
   * @param stage task stage Index
   * @return i/o phase index number
   */
  public abstract int getIoPhase(int type, int stage);
  public abstract int getIoPhaseNum();
  /**
   * Get the stage index given the io phase index and type
   * @param type  type in the io phase
   * @param ioPhase io phase index
   * @return stage index
   */
  public abstract int getStage(int type, int ioPhase);
  
  protected static final String INOUT_FS_NAME = "inout.fs";
  protected static final String INOUT_OVARY_DIR= "inout.ovary-dir";
  public static final String DEFAULT_OVARY_DIR = "cowork-ovary";
  public void setDefaultFsName(String fsName) {
    getConfig().setProperty(INOUT_FS_NAME,fsName);
  }
  public String getDefaultFsName() {
    return getConfig().getString(INOUT_FS_NAME,"local");
  }
  public void setFsOvaryDir(String dir) {
    getConfig().setProperty(INOUT_OVARY_DIR,dir);    
  }
  public File getFsOvaryDir(String jobId) {
    String defaultTmp = File.separator + DEFAULT_OVARY_DIR; // "/cowork-ovary"
    if (getDefaultFsName().equals("local"))  // "/tmp/cowork-ovary"
      defaultTmp = new File(
          File.separator+"tmp"+File.separator+System.getProperty("user.name"),
          DEFAULT_OVARY_DIR).getPath();
    return new File(getConfig().getString(INOUT_OVARY_DIR, defaultTmp),jobId);
  }  

  //////////////////////////////////////////////////////////////////////////////
  // Input splitter
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_INPUT_SPLITTER   = "mapred.input.splitter";
  protected void setInputSplitter(int ioPhase, Class<? extends BasicSplitter> splitter) {
    String prop = PR_INPUT_SPLITTER+"."+ioPhase;
    getConfig().setPropClass(prop,splitter,BasicSplitter.class);
  }
  protected BasicSplitter getInputSplitter(int ioPhase) {
    String prop = PR_INPUT_SPLITTER+"."+ioPhase;
    Class cls = getConfig().getPropClass(prop, BasicSplitter.class, null);
    if (cls!=null)
      return (BasicSplitter) ClassUtils.newInstance(cls);
    else return null;
  }
  protected final static String PR_INPUT_SPLIT_BLKSIZE = "mapred.input.split_blksize";
  protected final static String PR_INPUT_UNIT_SPLIT = "mapred.input.unit_split";
  protected final static int PER_UNIT_TASK_NUM = -1;
  public void setPerUnitSplit(int ioPhase, boolean b) {
      assert 0<=ioPhase && ioPhase<getIoPhaseNum();
      getConfig().setBoolean(PR_INPUT_UNIT_SPLIT+"."+ioPhase, b);
  }
  protected boolean isPerUnitSplit(int ioPhase) {
      assert 0<=ioPhase && ioPhase<getIoPhaseNum();
      return getConfig().getBoolean(PR_INPUT_UNIT_SPLIT+"."+ioPhase, false);
  }
  public void setSplitBlockSize(int ioPhase, int n) {
      assert 0<=ioPhase && ioPhase<getIoPhaseNum();
      getConfig().setInt(PR_INPUT_SPLIT_BLKSIZE+"."+ioPhase,n);
  }
  protected int getSplitBlockSize(int ioPhase) {
      assert 0<=ioPhase && ioPhase<getIoPhaseNum();
      return getConfig().getInt(PR_INPUT_SPLIT_BLKSIZE+"."+ioPhase, 16384); // FIXME: default
  }  

  //////////////////////////////////////////////////////////////////////////////
  // Input channel and format
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_INPUT_CHANNEL     = "mapred.input.channel";
  protected static final String PR_INPUT_FORMAT      = "mapred.input.format";
  protected int addInputChannel(int ioPhase, String svcAddr, String path,
      Class<? extends BasicInputFormat> format) {
    if (path==null) {
      LOG.warning("Add null name string as an input channel.");
      return -1;
    }
    String cProp = PR_INPUT_CHANNEL+"."+ioPhase;
    String fProp = PR_INPUT_FORMAT+"."+ioPhase;
    int chnIdx = getConfig().getInt(cProp,0);
    String svcUrl = getServiceUrl(svcAddr,path);
    getConfig().setInt(cProp,chnIdx+1);              // number of channels
    getConfig().setProperty(cProp+"."+chnIdx, svcUrl); // service url
    getConfig().setPropClass(fProp+"."+svcUrl, format, BasicInputFormat.class);
                                                         // input format
    return chnIdx;
  }
  protected BasicInputFormat getInputFormat(int ioPhase, String svcUrl) { // input format
    String fProp = PR_INPUT_FORMAT+"."+ioPhase;
    LOG.info("Get input format for svcurl " + svcUrl + " : " + getConfig().getString(fProp+"."+svcUrl));
    Class cls = getConfig().getPropClass(fProp+"."+svcUrl, 
        BasicInputFormat.class, null);
    if (cls!=null)
      return (BasicInputFormat) ClassUtils.newInstance(cls);
    else return null;
  }
  protected BasicInputFormat getInputFormat(int ioPhase, int channel) {
    String cProp = PR_INPUT_CHANNEL+"."+ioPhase;
    String svcUrl = getConfig().getString(cProp+"."+channel,null);
    if (svcUrl==null) return null;
    return getInputFormat(ioPhase,svcUrl);
  }
  protected int getInputChannelNum(int ioPhase) {       // number of channels
    String cProp = PR_INPUT_CHANNEL+"."+ioPhase;
    return getConfig().getInt(cProp,0);
  }
  protected String getInputSvcAddr(int ioPhase, int channel) { // service address
    String cProp = PR_INPUT_CHANNEL+"."+ioPhase;
    String svcUrl = getConfig().getString(cProp+"."+channel,null);
    if (svcUrl==null) return null;
    String[] str = svcUrl.split("@"); assert str.length==2;
    return str[1];
  }
  protected String getInputPath(int ioPhase, int channel) { // "path"
    String cProp = PR_INPUT_CHANNEL+"."+ioPhase;
    String svcUrl = getConfig().getString(cProp+"."+channel,null);
    if (svcUrl==null) return null;
    String[] str = svcUrl.split("@"); assert str.length==2;
    return str[0];
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Partitioner to prepare data for merger
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_MR_PARTITIONER = "mapred.mr.partitioner";
  protected void setPartitionerClass(int ioPhase, 
      Class<? extends BasicPartitioner> partitioner) {
    String pProp = PR_MR_PARTITIONER+"."+ioPhase;
    getConfig().setPropClass(pProp, partitioner, BasicPartitioner.class);
  }
  protected BasicPartitioner getPartitioner(int ioPhase) {
    String pProp = PR_MR_PARTITIONER+"."+ioPhase;
    Class cls = getConfig().getPropClass(pProp, BasicPartitioner.class, null);
    if (cls!=null) {
      BasicPartitioner p = (BasicPartitioner) ClassUtils.newInstance(cls);
      p.configurate(this);
      return p;
    }
    else return null;
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Combiner: cobmine map output
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_MR_COMBINER = "mapred.mr.combiner";
  protected static final String PR_MR_COMBINE_BUFFER = "mapred.mr.combine_buffer";
  protected void setCombinerClass(int ioPhase, Class<? extends IReducer> combiner) {
    String pProp = PR_MR_COMBINER+"."+ioPhase;
    getConfig().setPropClass(pProp, combiner, IReducer.class);    
  }
  public IReducer getCombiner(int ioPhase) {
    String pProp = PR_MR_COMBINER+"."+ioPhase;
    Class cls = getConfig().getPropClass(pProp, IReducer.class, null);
    if (cls!=null)
      return (IReducer) ClassUtils.newInstance(cls);
    else return null;
  }
  public boolean isSetCombiner(int ioPhase) {
      String pProp = PR_MR_COMBINER+"."+ioPhase;
      Class cls = getConfig().getPropClass(pProp, IReducer.class, null);
      return cls != null;      
  }
  protected void setCombiningBufferSize(int ioPhase, int buff) {
    String pProp = PR_MR_COMBINE_BUFFER+"."+ioPhase;
    getConfig().setInt(pProp, buff);        
  }
  protected int getCombiningBufferSize(int ioPhase) {
    String pProp = PR_MR_COMBINE_BUFFER+"."+ioPhase;
    return getConfig().getInt(pProp, 10000); // FIXME
  }
  
  /////////////////////////////
  // Mapper: map out buffer
  ////////////////////////////////
  protected static final String PR_MR_MAPOUT_BUFFER = "mapred.mr.mapout_buffer";
  protected static final String PR_MR_MAPOUT_BUFFER_NUMBER = "mapred.mr.mapout_buffer_number";
  protected static final String PR_MR_MAPOUT_BUFFER_BACKUP_PERCENT = "mapred.mr.mapout_buffer_backup_percent";
  protected static final String PR_MR_MAPOUT_BUFFER_FLUSH_GAP= "mapred.mr.mapout_buffer_flush_gap";
  /**
   * value should between 4*1024*1024 ~ 1024*1024*1024
   * @param ioPhrase
   * @param byte size
   */
  public void setMapOutBufferSize(int ioPhrase, int size) {
      if (size < 4*1024*1024 || size > 1024*1024*1024) {
          throw new RuntimeException("Map Buffer should between 4M~1024M.");
      }
      String pProp = PR_MR_MAPOUT_BUFFER+"."+ioPhrase;
      getConfig().setInt(pProp, size);            
  }
  protected int getMapOutBufferSize(int ioPhrase) {
      String pProp = PR_MR_MAPOUT_BUFFER+"."+ioPhrase;
      return getConfig().getInt(pProp, 200 * 1024 * 1024); //M size            
  }
  protected int getMapOutBufferNumber(int ioPhrase) {
      String pProp = PR_MR_MAPOUT_BUFFER_NUMBER+"."+ioPhrase;
      return getConfig().getInt(pProp, 2);             
  }
  protected float getMapOutBufferBackupPercent(int ioPhrase) {
      String pProp = PR_MR_MAPOUT_BUFFER_BACKUP_PERCENT+"."+ioPhrase;
      return getConfig().getFloat(pProp, 0.2f);      
  }
  //this means when buffer remain 5M, it will flush to disk
  //avoid buffer grow
  protected int getMapOutBufferFlushGap(int ioPhrase) {
      String pProp = PR_MR_MAPOUT_BUFFER_FLUSH_GAP+"."+ioPhrase;
      return getConfig().getInt(pProp, 1*1024*1024 ); //5M      
  }  
  
  
  //////////////////////////////////////////////////////////////////////////////
  // Merger: Merge between "in" and "out"
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_MR_MERGER         = "mapred.mr.merger";
  protected void setMergerClass(int ioPhase, Class<? extends BasicMerger> merger) {
    String mProp = PR_MR_MERGER+"."+ioPhase;
    getConfig().setPropClass(mProp, merger, BasicMerger.class);
  }
  protected BasicMerger getMerger(int ioPhase) {
    String mProp = PR_MR_MERGER+"."+ioPhase;
    Class cls = getConfig().getPropClass(mProp, BasicMerger.class, null);
    if (cls!=null) return (BasicMerger) ClassUtils.newInstance(cls);
    else return null;
  }
  
  protected static final String PR_MR_KEY            = "mapred.mr.key";
  protected static final String PR_MR_VAL            = "mapred.mr.val";
  protected static final String PR_MR_KEY_COMPARATOR = "mapred.mr.key_comparator";
  protected static final String PR_MR_VAL_COMPARATOR = "mapred.mr.val_comparator";  
  protected void setMergeKeyValClass(int ioPhase,
    Class key, Class value) {
    String kProp = PR_MR_KEY+"."+ioPhase;
    String vProp = PR_MR_VAL+"."+ioPhase;
    getConfig().setPropClass(kProp, key, Object.class);
    getConfig().setPropClass(vProp, value, Object.class);
  }
  protected void setMergeKeyComparator(int ioPhase, 
      Class<? extends BinaryComparator> comparator) {
    String kcProp = PR_MR_KEY_COMPARATOR+"."+ioPhase;
    getConfig().setPropClass(kcProp, comparator, BinaryComparator.class);
  }
  protected void setMergeValComparator(int ioPhase,
      Class<? extends BinaryComparator> comparator) {
    String vcProp = PR_MR_VAL_COMPARATOR+"."+ioPhase;
    getConfig().setPropClass(vcProp, comparator, BinaryComparator.class);   
  }
  public Class getMergeKeyClass(int ioPhase) {
    String kProp = PR_MR_KEY+"."+ioPhase;
    return getConfig().getPropClass(kProp, Object.class, null);
  }
  public Class getMergeValClass(int ioPhase) {
    String vProp = PR_MR_VAL+"."+ioPhase;
    return getConfig().getPropClass(vProp, Object.class, null);
  }
  @SuppressWarnings("unchecked")
  public WritableComparator getMergeKeyComparator(int ioPhase) {
    String kcProp = PR_MR_KEY_COMPARATOR+"."+ioPhase;
    Class cls = getConfig().getPropClass(kcProp, BinaryComparator.class, null);
    if (cls==null)  // no setting in job? load from registry
      cls = WritableRegistry.getBinaryComparatorClass(getMergeKeyClass(ioPhase));
    WritableComparator comp;
    if (cls!=null)
      comp = new WritableComparator(getMergeKeyClass(ioPhase), 
          (BinaryComparator) ClassUtils.newInstance(cls));
    else comp = new WritableComparator(getMergeKeyClass(ioPhase));
    if (getReverseSort(ioPhase)) {
        comp = new ReverseWritableComparator(comp);
    }
    return comp;
  }
  @SuppressWarnings("unchecked")
  public BinaryComparator getMergeValComparator(int ioPhase) {
    String vcProp = PR_MR_VAL_COMPARATOR+"."+ioPhase;
    Class cls = getConfig().getPropClass(vcProp,BinaryComparator.class, null);
    if (cls == null) return null;
    else {
        BinaryComparator comp = (BinaryComparator) ClassUtils.newInstance(cls);
        if (getReverseSort(ioPhase)) {
            comp = new ReverseBinaryComparator(comp);
        }
        return comp;
    }
  }

  //////////////////////////////////////////////////////////////////////////////
  // walker for output
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_MR_PAIRWALKER  = "mapred.mr.pair_walker";
  protected void setWalkerClass(int ioPhase, Class<? extends IWritablePairWalker> walker) {
    String pwProp = PR_MR_PAIRWALKER+"."+ioPhase;
    getConfig().setPropClass(pwProp, walker, IWritablePairWalker.class);
  }
  protected IWritablePairWalker getWalker(int ioPhase) {
    String pwProp = PR_MR_PAIRWALKER+"."+ioPhase;
    Class cls = getConfig().getPropClass(pwProp, IWritablePairWalker.class, null);
    if (cls!=null)
      return (IWritablePairWalker) ClassUtils.newInstance(cls);
    return null;
  }

  protected static final String PR_MR_COMBINER_PAIRWALKER  = "mapred.mr.combiner.pair_walker";
  protected void setCombinerWalkerClass(int ioPhase, Class<? extends IWritablePairWalker> walker) {
      String pwProp = PR_MR_COMBINER_PAIRWALKER+"."+ioPhase;
      getConfig().setPropClass(pwProp, walker, IWritablePairWalker.class);
  }
  protected IWritablePairWalker getCombinerWalker(int ioPhase) {
      String pwProp = PR_MR_COMBINER_PAIRWALKER+"."+ioPhase;
      Class cls = getConfig().getPropClass(pwProp, IWritablePairWalker.class, PerKeyBufferedWalker.class);
      return (IWritablePairWalker) ClassUtils.newInstance(cls);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Compression during reduce merge
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_MR_MERGE_TRANSFER_COMPRESSED = "mapred.mr.merge_transfer_compressed";
  protected void setMergeTransferCompressed(int ioPhase, boolean v) {
      String pwProp = PR_MR_MERGE_TRANSFER_COMPRESSED + "." + ioPhase;
      getConfig().setBoolean(pwProp, v);
  }
  protected boolean getMergeTransferCompressed(int ioPhase) {
      String pwProp = PR_MR_MERGE_TRANSFER_COMPRESSED + "." + ioPhase;
      return getConfig().getBoolean(pwProp, false);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Output channel and format
  //////////////////////////////////////////////////////////////////////////////
  protected static final String PR_OUTPUT         = "mapred.output";
  protected static final String PR_OUTPUT_SERVICE = "mapred.output.service";
  protected static final String PR_OUTPUT_PATH    = "mapred.output.path";
  protected static final String PR_OUTPUT_KEY     = "mapred.output.key";
  protected static final String PR_OUTPUT_VAL     = "mapred.output.value";
  protected static final String PR_OUTPUT_FORMAT  = "mapred.output.format";
  protected void addOutputChannel(int ioPhase, int channel, 
      String svcAddr, String path, 
      Class key, Class value, Class<? extends BasicOutputFormat> format) {
    if (path==null)
      LOG.warning("Add null name string as an output channel.");
    String prop  = PR_OUTPUT+"."+ioPhase;
    String sProp = PR_OUTPUT_SERVICE+"."+ioPhase;
    String pProp = PR_OUTPUT_PATH+"."+ioPhase;
    String fProp = PR_OUTPUT_FORMAT+"."+ioPhase;
    String kProp = PR_OUTPUT_KEY+"."+ioPhase;
    String vProp = PR_OUTPUT_VAL+"."+ioPhase;
    int chnIdx = getConfig().getInt(prop,0);
    if (chnIdx!=channel) throw new RuntimeException("Expect channel " + 
        chnIdx + ", but get channel " + channel);
    getConfig().setInt(prop,chnIdx+1);
    getConfig().setProperty(sProp+"."+chnIdx, svcAddr);
    getConfig().setProperty(pProp+"."+chnIdx, path);
    getConfig().setPropClass(fProp+"."+chnIdx, format, BasicOutputFormat.class);
    getConfig().setPropClass(kProp+"."+chnIdx, key == null ? IWritableComparable.class : key , IWritableComparable.class);
    getConfig().setPropClass(vProp+"."+chnIdx, value == null ? IWritable.class : value, IWritable.class);
  }
  protected int getOutputChannelNum(int ioPhase) {
    String prop = PR_OUTPUT+"."+ioPhase;
    return getConfig().getInt(prop,0);
  }
  protected BasicOutputFormat getOutputFormat(int ioPhase, int channel) {
    String fProp = PR_OUTPUT_FORMAT+"."+ioPhase;
    Class cls = getConfig().getPropClass(fProp+"."+channel, 
        BasicOutputFormat.class, null);
    if (cls != null)
      return (BasicOutputFormat) ClassUtils.newInstance(cls);
    else return null;
  }
  protected String getOutputSvcAddr(int ioPhase, int channel) {
    String sProp = PR_OUTPUT_SERVICE+"."+ioPhase;
    return getConfig().getString(sProp+"."+channel,null);
  }
  protected String getOutputPath(int ioPhase, int channel) {
    String pProp = PR_OUTPUT_PATH+"."+ioPhase;
    return getConfig().getString(pProp+"."+channel, null);
  }
  protected Class getOutputKeyClass(int ioPhase, int channel) {
    String kProp = PR_OUTPUT_KEY+"."+ioPhase;
    return getConfig().getPropClass(kProp+"."+channel, IWritableComparable.class, null);
  }
  protected Class getOutputValClass(int ioPhase, int channel) {
    String vProp = PR_OUTPUT_VAL+"."+ioPhase;
    return getConfig().getPropClass(vProp+"."+channel, IWritable.class, null);
  }
  
  // plugin extension
  public void plugin(IExtConf ext) {
    ext.saveTo(this);
  }
  
  protected void cleanup(String jobId) {
    LOG.info(jobId + ": Cleaning up ovary dirs");
    for (int ioPhase=0; ioPhase<getTotalStage(); ioPhase++) {
      Path ovaryDir = new Path(getFsOvaryDir(jobId));
      for (int channel=0; channel<getOutputChannelNum(ioPhase); channel++)
        try {
          FileSystem fs = FileSystem.getNamed(getOutputSvcAddr(ioPhase, channel));
          if (!fs.exists(ovaryDir)) continue;
          if (!depriveDir(fs, ovaryDir))
            LOG.warning(jobId + ": Fail to delete " + fs.getName() +":"+ovaryDir);
          else LOG.info(jobId + ": Cleaned up " + fs.getName() +":"+ovaryDir);
        } catch (IOException e) {
          LOG.log(Level.WARNING, "Cannot clear " + ovaryDir + ": ioPhase=" 
              + ioPhase + ",channel="+channel, e);
        }
    }
  }
  
  private boolean depriveDir(FileSystem fs, Path dir) throws IOException {
    boolean isSuccess = true;
    FileInfo[] files = fs.listFiles(dir);
    if (files!=null) {
      for (int i=0; i>files.length; i++) {
        if (fs.isFile(files[i].getPath()))
          isSuccess = isSuccess && fs.deprive(files[i].getPath());
        else isSuccess = isSuccess && depriveDir(fs, files[i].getPath());
      }
    }
    isSuccess = isSuccess && fs.delete(dir);
    return isSuccess;
  }

  static final String PR_MR_REVERSE_SORT = "mapred.reverse.sort";
  public boolean getReverseSort(int mrPhase) {
      return getConfig().getBoolean(PR_MR_REVERSE_SORT+"."+mrPhase, false);
  }
  
  public void setReverseSort(boolean b) {
      setReverseSort(getIoPhaseNum()-1,b);
  }
  
  public void setReverseSort(int mrPhase, boolean b) {
      assert 0 <= mrPhase && mrPhase < this.getIoPhaseNum();
      getConfig().setProperty(PR_MR_REVERSE_SORT+"."+mrPhase, b);
  }
}
