package odis.mapred;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.zip.CheckedInputStream;
import java.util.zip.CheckedOutputStream;
import java.util.zip.Checksum;

import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.util.IOUtils;
import odis.util.PureJavaCrc32;

import static odis.mapred.BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH;
/**
 * 
 * @author tuqc
 *
 */

public class SpillRecord {

    /** Backing store */
    private final ByteBuffer buf;

    /** View of backing storage as longs */
    private final LongBuffer entries;

    public SpillRecord(int numPartitions) {
        buf = ByteBuffer.allocate(numPartitions
                * BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH);
        entries = buf.asLongBuffer();
    }

    public SpillRecord(Path indexFileName) throws IOException {
        this(indexFileName, new PureJavaCrc32());
    }

    public SpillRecord(Path indexFileName, Checksum crc) throws IOException {

        final FileSystem rfs = FileSystem.getNamed("local");
        final FSDataInputStream in = rfs.open(indexFileName);
        try {
            final long length = rfs.getLength(indexFileName);
            final int partitions = (int) length
                    / BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH;
            final int size = partitions
                    * BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH;

            buf = ByteBuffer.allocate(size);
            if (crc != null) {
                crc.reset();
                CheckedInputStream chk = new CheckedInputStream(in, crc);
                IOUtils.readFully(chk, buf.array(), 0, size);
                if (chk.getChecksum().getValue() != in.readLong()) {
                    throw new IOException(
                            "Checksum error reading spill index: "
                                    + indexFileName);
                }
            } else {
                IOUtils.readFully(in, buf.array(), 0, size);
            }
            entries = buf.asLongBuffer();
        } finally {
            in.close();
        }
    }

    /**
     * Return number of IndexRecord entries in this spill.
     */
    public int size() {
        return entries.capacity()
                / (BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH / 8);
    }

    /**
     * Get spill offsets for given partition.
     */
    public IndexRecord getIndex(int partition) {
        final int pos = partition
                * BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH / 8;
        return new IndexRecord(entries.get(pos), entries.get(pos + 1),
                entries.get(pos + 2));
    }

    /**
     * Set spill offsets for given partition.
     */
    public void putIndex(IndexRecord rec, int partition) {
        final int pos = partition
                * BufferedMapCollector.MAP_OUTPUT_INDEX_RECORD_LENGTH / 8;
        entries.put(pos, rec.startOffset);
        entries.put(pos + 1, rec.rawLength);
        entries.put(pos + 2, rec.partLength);
    }

    /**
     * Write this spill record to the location provided.
     */
    public void writeToFile(Path loc) throws IOException {
        writeToFile(loc, new PureJavaCrc32());
    }

    public void writeToFile(Path loc, Checksum crc) throws IOException {
        final IFileSystem rfs = FileSystem.getNamed("local");
        CheckedOutputStream chk = null;
        final FSDataOutputStream out = rfs.create(loc);
        try {
            if (crc != null) {
                crc.reset();
                chk = new CheckedOutputStream(out, crc);
                chk.write(buf.array());
                out.writeLong(chk.getChecksum().getValue());
            } else {
                out.write(buf.array());
            }
        } finally {
            if (chk != null) {
                chk.close();
            } else {
                out.close();
            }
        }
    }



    public static class IndexRecord {
        public long startOffset;
        public long rawLength;
        public long partLength;
    
        public IndexRecord() {}
    
        public IndexRecord(long startOffset, long rawLength, long partLength) {
            this.startOffset = startOffset;
            this.rawLength = rawLength;
            this.partLength = partLength;
        }
    }
}