package odis.mapred.ext;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;

/**
 * The interface of a merge-reducer.
 * 
 * @author zl, david
 *
 * @param <K>  the type of the key
 * @param <V1>  the type of the values
 * @param <V2>  the type of the merged-values. The values could be of different 
 *              types, so specify the shared parent type here.
 */
public interface IMergeReducer<K, V1, V2> {
    /**
     * The constant for default-output-channel.
     */
    public static int DEFAULT_OUTPUT_CHANNEL = 0;
    /**
     * Configures the reducer. This method was called before the output pipes
     * (files) are created.
     * 
     * @param conf  the JobDef instance
     * @param task  the TaskRunnable instance
     */
    public void configure(JobDef conf, TaskRunnable task);
    /**
     * Called before the first reduce().
     */
    public void reduceBegin();

    /**
     * Combines values for a given key.  Output pairs are collected with calls to 
     * {@link ReduceTaskRunnable#collectToChannel(int, Object, Object)}.  The output pair 
     * is not required to have the same type of key/values as input.  Beaware that
     * the objects for "values" might be reused depends on which 
     * {@link IWritablePairWalker} you used.
     * 
     * @param key the key
     * @param values the values to combine
     * @param collector to collect combined values
     * 
     * NOTE: 
     * You should not change this interface to throw exception.  Supposely, all 
     * non-fatal exception should be handled inside and if the exception cannot be 
     * handled, it should be a runtime error, throw 
     * {@link odis.cowork.TaskFatalException} instead.
     */
    public void reduce(K key, IWritablePairWalker<K, V1> values, 
        IWritablePairWalker<K, V2>[] mergeValues, ICollector collector);

    /**
     * Called after the last reduce(). Some summative data can be collected here.
     * @param collector  the collector same as the one in map().
     */
    public void reduceEnd(ICollector collector);
}
