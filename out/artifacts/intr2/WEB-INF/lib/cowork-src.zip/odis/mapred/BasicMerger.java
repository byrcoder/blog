package odis.mapred;

import java.io.IOException;
import java.util.logging.Logger;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.serialize.comparator.BinaryComparator;
import toolbox.misc.LogFormatter;

/**
 * Merge all outputs from last stage.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public abstract class BasicMerger {
	
    protected static final Logger LOG = LogFormatter.getLogger(BasicMerger.class);

  /**
   * Merge outputs of map tasks in previous stage for this task 
   * 1. Copy mapout from remote to local
   * 2. Merge records with the same key together
   * Note: suggest to overlap copy (IO-intensive) with merge (CPU-intensive)
   * @param task    task that is doing this merge
   * @param job     job configuration
   * @return The record reader of the merge output
   * @throws IOException
   */
  public abstract IRecordReader merge(TaskRunnable task, BasicInOutJobDef job)
    throws IOException;  
  
  public abstract void clean(TaskRunnable task, BasicInOutJobDef job)
    throws IOException;
  
  protected static int getMrPhase(int taskStage, BasicInOutJobDef conf) {
    return conf.getIoPhase(BasicInOutJobDef.TYPE_MERGER,taskStage);
  }
  
  protected static Class getKeyClass(int taskStage, BasicInOutJobDef conf) {
    return conf.getMergeKeyClass(getMrPhase(taskStage,conf));
  }

  protected static Class getValClass(int taskStage, BasicInOutJobDef conf) {
    return conf.getMergeValClass(getMrPhase(taskStage,conf));
  }

  protected static BinaryComparator getKeyComparator(int taskStage, 
      BasicInOutJobDef conf) {
    return conf.getMergeKeyComparator(getMrPhase(taskStage,conf));
  }
    
  protected static BinaryComparator getValComparator(int taskStage, 
      BasicInOutJobDef conf) {
    return conf.getMergeValComparator(getMrPhase(taskStage,conf));
  }
  
  protected static boolean getMergeTransferCompressed(int taskStage, BasicInOutJobDef conf) {
      return conf.getMergeTransferCompressed(getMrPhase(taskStage, conf));
  }
  
  protected static BasicPartitioner getPartitioner(int prevStage, 
      BasicInOutJobDef conf) {
    return conf.getPartitioner(BasicPartitioner.getMrPhase(prevStage,conf));
  }
  
  protected static final String PR_MR_REVERSE_SORT = "mapred.reverse.sort";
  protected static boolean getReverseSort(BasicInOutJobDef jobDef, int mrPhase) {
      return jobDef.getReverseSort(mrPhase);
  }
  public static void setReverseSort(BasicInOutJobDef jobDef, boolean b) {
      setReverseSort(jobDef, jobDef.getIoPhaseNum()-1,b);
  }
  public static void setReverseSort(BasicInOutJobDef jobDef, int mrPhase, boolean b) {
      jobDef.setReverseSort(mrPhase, b);
  }

  public static final String MERGE_MEMORY = "mapred.reduce.merge-memory";
  public static final String MERGE_THREAD_NUM = "mapred.reduce.merge-thread";
  public static void setMergeMemory(BasicInOutJobDef jobDef, int stage, int size) {
      assert 0 <= stage && stage <= jobDef.getIoPhaseNum();
      if (size < 8*1024*1024 || size > 800*1024*1024) {
          throw new RuntimeException("Merge memory should between 8M ~ 800M");
      }
      LOG.info("Set merge memory " + MERGE_MEMORY+"."+stage + "=" + size);
      jobDef.getConfig().setProperty(MERGE_MEMORY+"."+stage, size);
  }
  public static void setMergeMemory(BasicInOutJobDef jobDef, int size) {
      setMergeMemory(jobDef, jobDef.getIoPhaseNum(), size);
  }
  protected static int getMergeMemory(BasicInOutJobDef jobDef, int stage) {
      assert stage >= 1;
      return jobDef.getConfig().getInt(MERGE_MEMORY+"."+stage, 256*1024*1024); //200M
  }
  
  public static void setMergeThreadNum(BasicInOutJobDef jobDef, int stage, int threadNum) {
      assert 0 <= stage && stage <= jobDef.getIoPhaseNum();
      if (threadNum < 1 || threadNum > 10) {
          throw new RuntimeException("Merge thread number should between 1 ~ 10");
      }
      jobDef.getConfig().setProperty(MERGE_THREAD_NUM+"."+stage, threadNum);         
  }
  public static void setMergeThreadNum(BasicInOutJobDef jobDef, int threadNum) {
      setMergeThreadNum(jobDef, jobDef.getIoPhaseNum() ,threadNum);
  }
  protected static int getMergeThreadNum(BasicInOutJobDef jobDef, int stage) {
      return jobDef.getConfig().getInt(MERGE_THREAD_NUM+"."+stage, 2);
  }
    
}
