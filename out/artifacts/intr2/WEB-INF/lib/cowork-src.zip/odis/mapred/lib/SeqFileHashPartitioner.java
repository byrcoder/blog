package odis.mapred.lib;

import java.io.File;
import java.io.IOException;

import odis.cowork.CoWorkUtils;
import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.SequenceFile;
import odis.file.CompressUtils.CompressAlgo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicPartitioner;

public class SeqFileHashPartitioner extends BasicPartitioner {
  
  public int getPartition(Object key, Object value, int numPartitions) {
    return (key.hashCode() & Integer.MAX_VALUE) % numPartitions;
  }

  @Override
  protected String getPartitionName(int mapIdx, int reduceIdx) {
    return "partitioner-"+ CoWorkUtils.formatNumber(mapIdx) + "-" + 
        CoWorkUtils.formatNumber(reduceIdx);
  }

  @Override
  protected IRecordWriter[] getPartitionWriters(TaskRunnable task, 
      BasicInOutJobDef job) throws IOException {
    // get the number of part for next stage
    int partNum = job.getTaskNumber(task.getStageIdx()+1);
    IRecordWriter[] writers = new IRecordWriter[partNum];
    FileSystem lfs = FileSystem.getNamed("local");
    Class keyClass = getKeyClass(task.getStageIdx(), job);
    Class valClass = getValClass(task.getStageIdx(), job);
    assert keyClass!=null && valClass!=null : 
        "Must set merge key & value classes using setMergeKeyValClass()";
    int part = task.getPartIdx();
    for (int reduceIdx=0; reduceIdx<writers.length; reduceIdx++) {      
        Path file = new Path(task.getWorker().getLocalDir(), getPartitionName(part,reduceIdx));
        // use compressed writer here
        int compressBlockSize = getCompressBlockSize(job, getMrPhase(task.getStageIdx(), job));
        boolean objectCompressed = isObjectCompress(job,getMrPhase(task.getStageIdx(),job)); 
        CompressAlgo compressAlgo = getCompressAlgo(job, getMrPhase(task.getStageIdx(), job));
        if (compressBlockSize > 0) {
            writers[reduceIdx] = new SequenceFile.CompressedWriter(lfs, file, keyClass, 
                    valClass, true, compressBlockSize, objectCompressed, compressAlgo);
        } else if (compressBlockSize == 0) {
            writers[reduceIdx] = new SequenceFile.CompressedWriter(lfs, file, keyClass, 
                    valClass, true, SequenceFile.CompressedWriter.DEFAULT_BLOCK_SIZE, 
                    objectCompressed, compressAlgo);
        } else if (objectCompressed) {
            writers[reduceIdx] = new SequenceFile.ObjectCompressWriter(lfs, 
                    file, keyClass, valClass, true, compressAlgo);
        } else {
            writers[reduceIdx] = new SequenceFile.Writer(lfs, file, keyClass, valClass, true);
        }
    } // for reduceIdx
    return writers;
  }

  @Override
  public String[] getMergeInputPaths(TaskRunnable mergeTask,
      BasicInOutJobDef job) {
    String jobId = mergeTask.getJobId();
    int prevStage = mergeTask.getStageIdx()-1;
    int partIdx = mergeTask.getPartIdx();
    int partNum = job.getTaskNumber(prevStage);
    String[] paths = new String[partNum];
    for (int i=0; i<partNum; i++) {
      String dir = TaskRunnable.getTaskId(jobId, prevStage, i);
      paths[i] = new File(dir,getPartitionName(i,partIdx)).getPath();
    }
    return paths;
  }

  /**
   * @author Qichen
   */
    @Override
    public String[] getPartitionOutputPaths(TaskRunnable task,
            BasicInOutJobDef job) throws IOException {
        int partNum = job.getTaskNumber(task.getStageIdx() + 1);
        String[] pathStrs = new String[partNum];
        int part = task.getPartIdx();
        for (int reduceIdx = 0; reduceIdx < partNum; reduceIdx++) {
            Path file = new Path(task.getWorker().getLocalDir(),
                    getPartitionName(part, reduceIdx));
            pathStrs[reduceIdx] = file.getAbsolutePath();
        }
        return pathStrs;
    }

}
