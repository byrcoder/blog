package odis.mapred.lib;

import odis.mapred.AbstractMapper;
import odis.mapred.ICollector;
import odis.serialize.IWritable;
import odis.serialize.toolkit.DynamicWritable;

/**
 * @deprecated Because DynamicWritable is deprecated, do not use this class and 
 * write your own mapper instead.
 */
@Deprecated
public class DynamicMapper<K,V extends IWritable> extends AbstractMapper<K,V> {
    private DynamicWritable wrapper = new DynamicWritable();
    
    public void map(K key, V value, ICollector collector) {
        wrapper.set(value);
        collector.collect(key, wrapper);
    }

}
