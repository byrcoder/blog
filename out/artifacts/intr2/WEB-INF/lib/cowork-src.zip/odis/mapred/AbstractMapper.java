package odis.mapred;

import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;

public abstract class AbstractMapper<K, V> implements IMapper<K, V> {

  public void configure(JobDef job, TaskRunnable task) {}

  public void mapBegin() {}

  public void mapEnd(ICollector collector) {}

}
