package odis.mapred.ext;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import odis.cowork.CoWorkUtils;
import odis.cowork.JobDef;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.io.Path;
import odis.mapred.BasicInputFormat;
import odis.mapred.IExtConf;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.InputFileSplit;
import odis.mapred.lib.SeqFileInputFormat;
import odis.serialize.lib.StringsWritable;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

public class ReduceMergeConf implements IExtConf {
  private static final String [] EMPTY_DIRS = new String[0];
  private static final Class [] EMPTY_WALKERS = new Class[0];
  private static final Class [] EMPTY_INPUTFORMATS = new Class[0];
  
  public static final Logger LOG = LogFormatter.getLogger(ReduceMergeConf.class.getName());
  
  private Class<? extends IMergeReducer> reducer;
  
  private String [] mergeFsNames = EMPTY_DIRS;
  private String [] mergeDirs = EMPTY_DIRS;
  private Class [] mergeWalkers = EMPTY_WALKERS;
  private Class [] mergeInputFormats = EMPTY_INPUTFORMATS;

  private static final String EXT_MREDUCE_MERGE_COUNT = "mapred.ext.merge_reduce.count";
  private static final String EXT_MREDUCE_REDUCER = "mapred.ext.merge_reduce.reducer";  
  private static final String EXT_MREDUCE_FSNAME  = "mapred.ext.merge_reduce.fs";
  private static final String EXT_MREDUCE_DIR     = "mapred.ext.merge_reduce.dir";
  private static final String EXT_MREDUCE_WALKER  = "mapred.ext.merge_reduce.walker";
  private static final String EXT_MREDUCE_INPUTFORMAT = "mapred.ext.merge_reduce.input_format";
  private static final String EXT_MREDUCE_CHANNEL_PART = "mapred.ext.merge_reduce.channel_part";
  
  @SuppressWarnings("unchecked")
  public void loadFrom(JobDef job) {
    assert job instanceof MapReduceJobDef;
    MapReduceJobDef mrJob = (MapReduceJobDef) job;
    // check task class
    if (mrJob.getReduceTaskRunnable()!=ReduceMergeTask.class)
      throw new TaskFatalException("MergeReducer is set only when " +
            "ReduceTaskRunnable is MergeReduceTask.");
    // reducer
    reducer = (Class<? extends IMergeReducer>) mrJob.getConfig().getPropClass(
        EXT_MREDUCE_REDUCER, IMergeReducer.class, null);
    
    // dirs & walkers
    int mergeCount = mrJob.getConfig().getInt(EXT_MREDUCE_MERGE_COUNT, 0);
    if (mergeCount == 0) {
      mergeDirs = EMPTY_DIRS;
      mergeWalkers = EMPTY_WALKERS;
      mergeInputFormats = EMPTY_INPUTFORMATS;
    } else {
      mergeFsNames = new String[mergeCount];
      mergeDirs = new String[mergeCount];
      mergeWalkers = new Class[mergeCount];
      mergeInputFormats = new Class[mergeCount];
      for (int i=0; i<mergeCount; i++) {
        String dir = (String)mrJob.getConfig().getProperty(
            EXT_MREDUCE_DIR + "." + i);
        Class cls = mrJob.getConfig().getPropClass(
            EXT_MREDUCE_WALKER+"."+i, IWritablePairWalker.class, null);
        Class in = mrJob.getConfig().getPropClass(
            EXT_MREDUCE_INPUTFORMAT+"."+i, BasicInputFormat.class, null);
        if (dir != null && cls != null && in != null) {
          mergeDirs[i] = dir;
          mergeWalkers[i] = cls;
          mergeInputFormats[i] = in;
          mergeFsNames[i] = mrJob.getConfig().getString(EXT_MREDUCE_FSNAME + "." + i, null);
        }
      }
    }
  }

  public void saveTo(JobDef job) {
    assert job instanceof MapReduceJobDef;
    MapReduceJobDef mrJob = (MapReduceJobDef) job;
    // task runnable
    mrJob.setReduceTaskRunnable(ReduceMergeTask.class);
    // reducer
    mrJob.getConfig().setPropClass(EXT_MREDUCE_REDUCER, reducer, IMergeReducer.class);
    mrJob.setExtReducer(reducer.getName());
    // dirs & walkers
    assert mergeDirs.length == mergeWalkers.length && 
           mergeDirs.length == mergeInputFormats.length;
    int mergeCount = mergeDirs.length;
    
    for (int i=0; i<mergeCount; i++) {
      if (mergeDirs[i] == null || mergeWalkers[i] == null ||
          mergeInputFormats[i]==null) continue;
      mrJob.getConfig().setProperty(EXT_MREDUCE_DIR + "." + i, mergeDirs[i]);
      mrJob.getConfig().setPropClass(EXT_MREDUCE_WALKER+"."+i, 
          mergeWalkers[i], IWritablePairWalker.class);
      mrJob.getConfig().setPropClass(EXT_MREDUCE_INPUTFORMAT+"."+i,
          mergeInputFormats[i], BasicInputFormat.class);
      if (mergeFsNames[i] != null) {
          mrJob.getConfig().setProperty(EXT_MREDUCE_FSNAME + "." + i, mergeFsNames[i]);
      }
    }
    mrJob.getConfig().setInt(EXT_MREDUCE_MERGE_COUNT, mergeCount);
    
    // get the file splits and save to config
    for (int channel = 0; channel < mergeInputFormats.length; channel ++) {
        if (mergeInputFormats[channel] == null) continue;
        
        BasicInputFormat input = (BasicInputFormat) ClassUtils
        .newInstance(mergeInputFormats[channel]);
        try {
            String[] fileParts = input.listParts(
                    mergeFsNames[channel]==null ? mrJob.getDefaultFsName() : mergeFsNames[channel],
                            mergeDirs[channel]);
            StringsWritable list = new StringsWritable();
            for (String s : fileParts) { list.addString(s); }
            String encodedString = CoWorkUtils.writableToString(list);
            mrJob.getConfig().setProperty(EXT_MREDUCE_CHANNEL_PART + "_" + channel, encodedString);
        } catch(IOException e) {
            throw new RuntimeException("prepare the input splits failed", e);
        }
    }
    
  }

  public void setMergeReducer(Class<? extends IMergeReducer> reducer) {
    this.reducer = reducer;
  }
  public IMergeReducer getMergeReducer() {
    if (reducer==null)
      throw new TaskFatalException("Merge reducer is not initialized");
    return (IMergeReducer) ClassUtils.newInstance(reducer);
  }
  
  public void setMergeCount(int value) {
    assert mergeDirs.length == mergeWalkers.length;
    assert value >= mergeDirs.length;
    if (value == mergeDirs.length) return;
    
    String [] fsNames = new String[value];
    System.arraycopy(mergeFsNames, 0, fsNames, 0, mergeFsNames.length);
    mergeFsNames = fsNames;
    
    String [] dirs = new String[value];
    System.arraycopy(mergeDirs, 0, dirs, 0, mergeDirs.length);
    
    Class [] clazzes = new Class[value];
    System.arraycopy(mergeWalkers, 0, clazzes, 0, mergeWalkers.length);
    
    Class [] inputs = new Class[value];
    System.arraycopy(mergeInputFormats, 0, inputs, 0, mergeInputFormats.length);
    
    mergeDirs = dirs;
    mergeWalkers = clazzes;
    mergeInputFormats = inputs;
  }
  
  @Deprecated
  public void setMergeDir(int idx, File dir, Class walker) {
      setMergeDir(idx, new Path(dir), walker);
  }
  public void setMergeDir(int idx, Path dir, Class walker) {
      setMergeDir(idx, null, dir,walker,SeqFileInputFormat.class);
  }
  @Deprecated
  public void setMergeDir(int idx, File dir, Class walker, Class inputformat) {
      setMergeDir(idx, new Path(dir), walker, inputformat);
  }
  public void setMergeDir(int idx, Path dir, Class walker, Class inputformat) {
      setMergeDir(idx, null, dir, walker, inputformat);
  }
  @Deprecated
  public void setMergeDir(int idx, String fsName, File dir, Class walker) {
      setMergeDir(idx, fsName, new Path(dir), walker);
  }
  public void setMergeDir(int idx, String fsName, Path dir, Class walker) {
      setMergeDir(idx, fsName, dir, walker, SeqFileInputFormat.class);
  }
  @Deprecated
  public void setMergeDir(int idx, String fsName, File dir, Class walker, Class inputformat) {
      setMergeDir(idx, fsName, new Path(dir), walker, inputformat);
  }
  public void setMergeDir(int idx, String fsName, Path dir, Class walker, Class inputformat) {
      if (idx >= mergeDirs.length) {
          throw new RuntimeException("no slot to save merge dir, call setMergeCount() first");
        }
        mergeDirs[idx] = dir.getPath();
        mergeWalkers[idx] = walker;
        mergeInputFormats[idx] = inputformat;
        mergeFsNames[idx] = fsName;
  }
  
  public String[] getMergeDirs() {
    if (mergeDirs.length == 0)
      LOG.warning("Merge directories are not initialized");
    return mergeDirs;
  }
  
  public IWritablePairWalker getMergeWalker(int index) {
    if (index<0||index>=mergeWalkers.length)
      throw new TaskFatalException("Merge walkers are not initialized or " +
            "try to get walkers exceeds bound");
    if (mergeWalkers[index] == null) 
      return null;
    else 
      return (IWritablePairWalker) ClassUtils.newInstance(mergeWalkers[index]);
  }
  
  public IRecordReader getMergeInputReader(int channel, TaskRunnable task, MapReduceJobDef job) 
      throws IOException {
    if (channel<0||channel>=mergeInputFormats.length)
      throw new TaskFatalException("Merge reader are not initialized or " +
            "try to get reader exceeds bound");
    if (mergeInputFormats[channel]==null||mergeDirs[channel]==null) return null;
    else {
      int reduceNum = job.getReduceNumber();
      BasicInputFormat input = (BasicInputFormat) ClassUtils.newInstance(mergeInputFormats[channel]);
      String[] fileParts;
      String cachedParts = job.getConfig().getString(EXT_MREDUCE_CHANNEL_PART + "_" + channel);
      if (cachedParts != null) {
          StringsWritable cachedFileParts = (StringsWritable)CoWorkUtils.stringToWritable(cachedParts);
          fileParts = cachedFileParts.toStringArray();
      } else {
          fileParts = input.listParts(
              mergeFsNames[channel]==null ? job.getDefaultFsName() : mergeFsNames[channel],
                      mergeDirs[channel]);
      }
      
      if ( reduceNum != fileParts.length ) {
        throw new IOException("Merge channel " + channel + 
            ": Reduce-Number!=Part-Number-To-Merge: " + reduceNum + "!=" + fileParts.length);
      }
      return input.getRecordReader(new InputFileSplit(mergeFsNames[channel]==null ? job.getDefaultFsName() : mergeFsNames[channel], 
          mergeDirs[channel], fileParts[task.getPartIdx()]), task, job);
    }
  }  

}
