package odis.mapred;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

public class TaskID implements IWritable{    
    String taskId;
    int idx;
    
    public TaskID() {}
    
    public TaskID(String taskId, int idx) {
        this.taskId = taskId;
        this.idx = idx;
    }

    public String getId() { return taskId; }
    public int getPartIdx() { return idx; }

    @Override
    public IWritable copyFields(IWritable value) {
        TaskID that = (TaskID)value;
        this.taskId = that.taskId;
        this.idx = that.idx;
        return this;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        StringWritable.writeString(out, taskId);
        out.writeInt(idx);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        this.taskId = StringWritable.readString(in);
        this.idx = in.readInt();
    }
    
    public int hashCode() {
        return taskId.hashCode();
    }
    
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o != null && o instanceof TaskID) {
            TaskID that = (TaskID)o;
            return this.taskId.equals(that.taskId) && this.idx == that.idx;
        }
        return false;
    }
    
    public String toString() {
        return taskId;
    }
}
