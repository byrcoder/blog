/**
 * 
 */
package odis.mapred.lib;

import java.util.Comparator;

import odis.cowork.TaskFatalException;
import odis.file.IRecordReader;

import org.apache.commons.configuration.Configuration;

/**
 * A pair walker that ensure with the same key, each value is passed with a separate 
 * instance of the value object. This allows you to do collective operations on these
 * values without need to worrying about the value changing beneath you.
 * 
 * @author david
 */
public class PerKeyBufferedWalker<K, V> extends PairWalkerBase<K, V> {
  public static final String PROP_NUM_OBJECT = "bufferedwalker.num.object";
  private Object[] valPool;
  private int poolStart, poolEnd;
  private boolean lastPooled;
  private K savedKey;

  @SuppressWarnings("unchecked")
  @Override
  protected void allocNextKey() {
    try {
      if (savedKey == null)
        nextKey = (K) in.getKeyClass().newInstance();
      else {
        nextKey = savedKey;  savedKey = null;
      } // else
    } catch (Exception e) {
      throw new TaskFatalException("Cannot allocate key for PerKeyPairWalker",e);
    }
  }

  @SuppressWarnings("unchecked")
  @Override
  protected void allocNextValue() {
    try {
      nextValue = (V) alloc();
    } catch (Exception e) {
      throw new TaskFatalException("Cannot allocate value for PerKeyPairWalker",e);
    }
  }

  @Override
  protected void freeCurrentKey() {
    if (key !=  null) {
      savedKey = key;
      // reset the pool for new key
      if (lastPooled) {
        // the last allocated value object is in the pool, switch it to the front so that it is not used
        Object tmp = valPool[poolStart-1];  valPool[poolStart-1] = valPool[0];  valPool[0] = tmp;
        poolStart = 1;
      } else
        poolStart = 0;
    } // if
  }
  
  @SuppressWarnings("unchecked")
  private Object alloc() throws InstantiationException, IllegalAccessException {
    lastPooled = false;
    if (poolStart >= poolEnd)
      // no available object in the pool
      if (poolEnd < valPool.length) {
        // pool is not full, new an instance into the pool
        valPool[poolEnd] = in.getValueClass().newInstance(); 
        poolEnd ++;
      } else
        // return a new instance without pooling
        return in.getValueClass().newInstance();
    
    lastPooled = true;
    Object o = valPool[poolStart];
    poolStart ++;
    
    return o;
  }
  
  public void configure(IRecordReader in, Comparator<K> cmp,
      Configuration conf) {
    lastPooled = false;
    savedKey = null;
    valPool = new Object[conf.getInt(PROP_NUM_OBJECT, 100)];
    poolStart = 0;  poolEnd = 0;
    
    super.configure(in, cmp, conf);
  }
}
