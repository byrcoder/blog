package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.TextRecordFile;
import odis.mapred.BasicInOutJobDef;

/**
 * Output format for writing text files. Each line is treated as a record.
 * And a separator (set via 
 * {@link #setSeparator(BasicInOutJobDef, int, String)}) separates the key and 
 * value.
 * 
 * @author zl
 */
public class TextOutputFormat extends GenericFileOutputFormat {
    
    private static final String PROP_SEPARATOR = 
        "mapred.text-outputformat.separator";
    
    public static void setSeparator(BasicInOutJobDef jobDef, int channel,
            String separator) {
        setSeparator(jobDef, channel, jobDef.getIoPhaseNum()-1, separator);
    }
    
    public static void setSeparator(BasicInOutJobDef jobDef, int channel,
            int mrPhase, String separator) {
        jobDef.getConfig().setProperty(
                PROP_SEPARATOR+"."+mrPhase+"."+channel, separator);
    }

    @Override
    protected IRecordWriter getRecordWriter(int channel, TaskRunnable task, 
            BasicInOutJobDef jobConf) throws IOException {
        // setup file system, session file and target file
        setup(channel,task,jobConf);
        int mrPhase = getMrPhase(task.getStageIdx(), jobConf);
        String separator = jobConf.getConfig().getString(
                PROP_SEPARATOR+"."+mrPhase+"."+channel, " ");
        return new TextRecordFile.Writer(fs, sessionFile, separator, true);
    }    

}
