package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.mapred.BasicInOutJobDef;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import toolbox.misc.ClassUtils;

/**
 * The sequence-file-output-format that checks whether the outputed keys are sorted.
 * 
 * @author David
 *
 */
public class SortedSeqFileOutputFormat extends SeqFileOutputFormat {
    
    public static class OrderChecker implements IRecordWriter {
        @SuppressWarnings("serial")
        public static class WrongOrderException extends IOException {
            public WrongOrderException(String msg) {
                super(msg);
            }
        }
        IRecordWriter writer;
        IWritableComparable lastKey = null;
        Class keyClass;
        public OrderChecker(IRecordWriter writer, Class keyClass) throws IOException {
            if (!IWritableComparable.class.isAssignableFrom(keyClass))
                throw new IOException(keyClass + " is not a class derived from Comparable.");
            this.writer = writer;
            this.keyClass = keyClass;
        }
        public void close() throws IOException {
            writer.close();
        }

        public long getSize() throws IOException {
            return writer.getSize();    
        }
        
        @SuppressWarnings("unchecked")
        public void write(Object key, Object value) throws IOException {
            if (lastKey != null) {
                if (lastKey.compareTo((IWritable) key) > 0)
                    throw new WrongOrderException("Wrong order: " + lastKey + " is greated than " + key);
            } else {
                lastKey = (IWritableComparable) ClassUtils.newInstance(keyClass);
            } // else
            if (lastKey.copyFields((IWritable) key) == null) {
                throw new RuntimeException("cannot copy key class of " + keyClass);
            }
            writer.write(key, value);
        }
        
    }

    protected IRecordWriter getRecordWriter(int channel, 
      TaskRunnable task, BasicInOutJobDef job) throws IOException {
        IRecordWriter writer = super.getRecordWriter(channel, task, job);
        return new OrderChecker(writer, getKeyClass(task.getStageIdx(),channel,job)); 
   }
}
