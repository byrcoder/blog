package odis.mapred.lib;

import java.io.IOException;
import java.util.Arrays;

import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInputFormat;

public abstract class GenericFileInputFormat extends BasicInputFormat {

    @Override
    public String[] listParts(String svcAddr, String path) throws IOException {
      FileSystem fs = FileSystem.getNamed(svcAddr);
      FileInfo[] files = fs.listFiles(new Path(path));
      if (files == null)
        throw new IOException("Cannot find path " + svcAddr + ":" + path);
      String[] parts = new String[files.length];
      for (int i=0; i<files.length; i++) {
        if (!fs.isFile(files[i].getPath()))
          throw new IOException("The part is not a file but a directory");
        parts[i] = files[i].getPath().getName();
      }
      Arrays.sort(parts); // should list in a consistant same order
      return parts;
    }

}
