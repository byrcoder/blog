package odis.mapred;

import java.io.IOException;

import odis.cowork.CounterMap;
import odis.cowork.JobDef;
import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.io.DataInputBuffer;
import odis.serialize.IWritable;

/**
 * 
 * @author tuqc
 *
 * @param <K>
 * @param <V>
 */

public abstract class CombinerRunner<K,V> {

    /**
     * Run the combiner over a set of inputs.
     * @param recordIn the key/value pairs to use as input
     * @param collector the output collector
     */
    public abstract void combine(IRecordReader recordIn, ICollector collector)
            throws IOException;
    
    @SuppressWarnings("unchecked")
    public static <K,V> 
    CombinerRunner<K,V> create(BasicInOutJobDef job, TaskRunnable task, int phase, 
                               CounterMap.Counter inputCounter)  {                
        return new GeneralCombinerRunner(job, task, phase, inputCounter);
    }
    
    public static class RawKeyValueRecordReader implements IRecordReader {

        private Class keyClass, valClass;
        RawKeyValueIterator kvIter;
        CounterMap.Counter inCounter;
        
        public RawKeyValueRecordReader(RawKeyValueIterator kvIter, Class keyClass, Class valClass) {
            this(kvIter, keyClass, valClass, null);
        }
        
        public RawKeyValueRecordReader(RawKeyValueIterator kvIter, Class keyClass, 
                Class valClass, CounterMap.Counter inCounter) {
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.kvIter = kvIter;
            this.inCounter = inCounter;
        }
        
        @Override
        public Class getKeyClass() {
            return keyClass;
        }

        @Override
        public Class getValueClass() {
            return valClass;
        }

        @Override
        public boolean next(Object key, Object value) throws IOException {
            if (key.getClass() != keyClass)
                throw new IOException("wrong key class: " + key.getClass()
                        + " is not " + keyClass);
            if (value.getClass() != valClass)
                throw new IOException("wrong value class: " + value.getClass()
                        + " is not " + valClass);
            
            boolean b = kvIter.next();
            if (b) {
                DataInputBuffer in = kvIter.getKey();
                ((IWritable)key).readFields(in);
                in = kvIter.getValue();
                ((IWritable)value).readFields(in);
                if (inCounter != null) inCounter.inc();
            }
            return b;
        }

        @Override
        public void close() throws IOException {
            kvIter.close();
        }

        @Override
        public long getPos() throws IOException {
            return kvIter.getPos();
        }

        @Override
        public long getSize() throws IOException {
            return kvIter.getSize();
        }
        
    }
}
