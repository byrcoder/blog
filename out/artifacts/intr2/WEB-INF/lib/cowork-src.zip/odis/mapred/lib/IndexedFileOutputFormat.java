package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;
import odis.file.IndexedFile;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;

public class IndexedFileOutputFormat extends GenericFileOutputFormat {
  
  protected IRecordWriter getRecordWriter(int channel, 
      TaskRunnable task, BasicInOutJobDef job) throws IOException {
    // setup file system, session file and target file
    setup(channel,task,job);
    Class keyClass = getKeyClass(task.getStageIdx(),channel,job);
    Class valClass = getValueClass(task.getStageIdx(),channel,job);
    // use compressed index file?
    int compressBlock = getCompressSize(job,getMrPhase(task.getStageIdx(), job),channel);    
    if (compressBlock>0)
        return new IndexedFile.CompressedWriter(fs, new Path(sessionFile), keyClass, valClass, true, compressBlock);
    else if (compressBlock==0)
        return new IndexedFile.CompressedWriter(fs, new Path(sessionFile), keyClass, valClass, true);
    else 
        return new IndexedFile.Writer(fs, new Path(sessionFile), keyClass, valClass, true);
  }

}
