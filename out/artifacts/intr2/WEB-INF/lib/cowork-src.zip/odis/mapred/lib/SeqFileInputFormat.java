package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.ITaskInputSplit;

/**
 * A implementation of input format that opens readers to 
 * {@link odis.file.SequenceFile}. Also defines minimum split size.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 14, 2006
 * Copyright (c) 2006, Outfox Team
 */
public class SeqFileInputFormat extends GenericFileInputFormat {

  /**
   * Get record reader for a split.  The split is located at stage 0, part 
   * <code>part</code> of <code>job</code>.
   */
  public IRecordReader getRecordReader(ITaskInputSplit split, 
      TaskRunnable task, BasicInOutJobDef job) throws IOException {
    
    assert split instanceof InputFileSplit;    
    InputFileSplit fSplit = (InputFileSplit) split;

    // open the file and seek to the start of the split
    SequenceFile.Reader in = new SequenceFile.Reader(
        FileSystem.getNamed(fSplit.getFsName()), 
        new Path(fSplit.getFile()), fSplit.getStart(), fSplit.getLength());
    return in;
  }  

}
