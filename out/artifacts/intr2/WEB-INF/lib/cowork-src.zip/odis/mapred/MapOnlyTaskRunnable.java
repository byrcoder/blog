package odis.mapred;

import java.io.IOException;
import java.util.logging.Level;

import odis.cowork.JobDef;
import odis.cowork.TaskFatalException;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.cowork.CounterMap.Counter;
import odis.file.IRecordReader;
import odis.file.IRecordWriter;

/**
 * Abstract class that defines a task used in MapOnlyJobDef
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 15, 2006
 * Copyright (c) 2006, Outfox Team
 */
public abstract class MapOnlyTaskRunnable extends TaskRunnable 
        implements ICollector {
  public final static String CT_MAPPED_IN_RECORD = 
      MapTaskRunnable.CT_MAPPED_IN_RECORD; 
  public final static String CT_MAPPED_IN_SIZE = 
      MapTaskRunnable.CT_MAPPED_IN_SIZE;
  public final static String CT_MAPPED_OUT_RECORD = 
      MapTaskRunnable.CT_MAPPED_OUT_RECORD;
  public final static String CT_MAPPED_OUT_SIZE = 
      MapTaskRunnable.CT_MAPPED_OUT_SIZE;

  protected MapOnlyJobDef moJob;
  protected IRecordWriter[] out;  // output writers

  protected long inputSize;
  protected Throwable outputError = null; // throwable caught during output
  
  @Override
  public void configure(JobDef job, TaskWorker worker) {
    assert job instanceof MapOnlyJobDef;
    this.moJob = (MapOnlyJobDef) job;
    this.worker = worker;
  }
  
  @SuppressWarnings("unchecked")
  @Override
  public void run() {
    
    startTime = System.currentTimeMillis();
    
    LOG.info("Starting " + this.getClass().getName() + ".run()");    
    boolean isProcessDone = false;
    BasicOutputFormat[] outputFormat=null;
    try {
//      assert this.worker.getPrevWorkers()==null;
      // get input splits
      ITaskInputSplit[] splits = moJob.getInputSplits(part);
      StringBuffer sb = new StringBuffer("I will process " + splits.length 
              + " input split(s):");
      for (int i=0; i<splits.length; i++)
        sb.append("\n  "+splits[i].toString());
      LOG.info(sb.toString());
      // compute total input size
      inputSize = 0;
      for (int i=0; i<splits.length; i++)
        inputSize += splits[i].getLength();
      // process
      try {
        // set output
        this.out = new IRecordWriter[moJob.getOutputChannelNum()];
        outputFormat = new BasicOutputFormat[out.length]; 
        for (int oc=0; oc<out.length; oc++) {
          outputFormat[oc] = moJob.getOutputFormat(oc);
          out[oc] = outputFormat[oc].getRecordWriter(oc,this,moJob);
        }
        // real process from input and write to outputs
        LOG.info("Partitioner and writers are ready. Starting real process " 
                + "...");        
        preProcess(); // set some global states before process
        processSplits(moJob, splits);
        postProcess(); // get some global states after process
        // summarize
        LOG.info("Processed " + getCounter(CT_MAPPED_IN_RECORD).get() 
            + " record (" + getCounter(CT_MAPPED_IN_SIZE).get() + " bytes).");
        LOG.info("Output " + getCounter(CT_MAPPED_OUT_RECORD).get() 
                + " record (" + getCounter(CT_MAPPED_OUT_SIZE).get() 
                + " bytes).");
        // till now the task is normally ended
        isProcessDone = true;
      } finally {
        if (out!=null) {
          for (int i=0; i<out.length; i++)
            if (out[i]!=null) out[i].close();
        }
        if (isProcessDone)
          for (int oc=0; oc<outputFormat.length; oc++) 
              outputFormat[oc].finish();
      }
    } catch (IOException e) {
      throw new RuntimeException("IOException in " + this.getClass().getName() 
        + ".run()", e);
    }
    if (outputError != null) {
      throw new RuntimeException("Error occurred in asynchronous output", 
              outputError);
    }
  }

  public long cursor() {
      Counter ct = counters.get(CT_MAPPED_IN_RECORD);
      if (ct==null) return NON_CURSOR;
      else return ct.get();
  }  
  
  /** work done right before processing all pieces of splits */
  protected abstract void preProcess();
  
  protected void processSplits(MapOnlyJobDef moJob, ITaskInputSplit[] splits) 
      throws IOException {
    IRecordReader in = null;
    setProgressFlag(true);
    try {
      for (int i=0; i<splits.length; i++) {
        LOG.info("Processing split=" + splits[i]);
        in = moJob.getInputFormat(splits[i].getSource()).getRecordReader(
          splits[i], this, moJob);
        process(in);
        in.close(); in = null;
        LOG.info("Return from processing split=" + splits[i] + ", cursor="
                + cursor());
        if (toEnd) break;
      }
    } finally {
      setProgressFlag(false);
      if (in!=null) in.close();
    }
  }
  /**
   * NOTE: 
   * You should not change this interface to throw exception.  Supposely, all 
   * non-fatal exception should be handled inside and if the exception cannot be 
   * handled, it should be a runtime error, throw TaskFatalException instead.
   */
  protected abstract void process(IRecordReader in) throws IOException;
  
  /** work done right after processing all pieces of splits */
  protected abstract void postProcess();

  /**
   * Default collect will collect to all output channels
   */
  public void collect(Object key, Object value) {
    for (int i = 0; i < out.length; i ++)
      this.collectToChannel(i, key, value);
  }
  
  public void collectToPartition(int part, Object key, Object value) {
      throw new TaskFatalException("Method not implemented for " 
              + this.getClass().getName());
  }

  @SuppressWarnings("unchecked")
  public void collectToChannel(int channel, Object key, Object value) {
    try {
      if (channel<0 || channel>=out.length)
        throw new TaskFatalException("BUG: try to collect to output channel " 
            + channel + ", channel range accepted: [0," + out.length+")");
      long prevPos = out[channel].getSize();
      out[channel].write(key,value);
      getCounter(CT_MAPPED_OUT_RECORD).inc();
      getCounter(CT_MAPPED_OUT_SIZE).inc(out[channel].getSize()-prevPos);
    } catch (IOException e) {
      LOG.log(Level.SEVERE, "output failed", e);
      outputError = e;
      throw new RuntimeException("IOException in " + this.getClass().getName() 
        + ".collect()", e);
    } catch (Throwable e) {
      LOG.log(Level.SEVERE, "output failed", e);
      outputError = e;
      throw new RuntimeException("Unexpected exception in " + 
              this.getClass().getName() + 
              ".collectToChannel(" + channel+",...)", e);
    }
  }
  
  public void collectDoneMsg(String msg) {
    this.doneMsg = msg;
  }

}
