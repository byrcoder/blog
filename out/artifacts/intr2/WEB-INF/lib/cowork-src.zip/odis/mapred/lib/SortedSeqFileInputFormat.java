package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.ITaskInputSplit;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import toolbox.misc.ClassUtils;

/**
 * The sequence-file-input-format that checks whether the input keys are sorted.
 * If the input keys are not sorted, an exception is raised. 
 * 
 * @author David
 *
 */
public class SortedSeqFileInputFormat extends SeqFileInputFormat {

    public static class OrderChecker implements IRecordReader {
        @SuppressWarnings("serial")
        public static class WrongOrderException extends IOException {
            public WrongOrderException(String msg) {
                super(msg);
            }
        }
        private IRecordReader reader;
        private IWritableComparable lastKey = null;
        private Class keyClass;
        public OrderChecker(IRecordReader reader) throws IOException {
            this.reader = reader;
            this.keyClass = reader.getKeyClass();
            if (!IWritableComparable.class.isAssignableFrom(keyClass))
                throw new IOException(keyClass + " is not a class derived from Comparable.");
        }
        public void close() throws IOException {
            reader.close();
        }
        
        @SuppressWarnings("unchecked")
        public boolean next(Object key, Object value) throws IOException {
            boolean b = reader.next(key, value);
            if (lastKey != null) {
                if (lastKey.compareTo((IWritable) key) > 0)
                    throw new WrongOrderException("Wrong order: " + lastKey + " is greated than " + key);
            } else {
                lastKey = (IWritableComparable) ClassUtils.newInstance(keyClass);
            } // else
            if (lastKey.copyFields((IWritable) key) == null) {
                throw new RuntimeException("cannot copy key class of " + keyClass);
            } // if
            return b;
        }
        
        public Class getKeyClass() { return reader.getKeyClass(); }
        public Class getValueClass() { return reader.getValueClass(); }       
        public long getPos() throws IOException { return reader.getPos(); }
        public long getSize() throws IOException { return reader.getSize(); }

    }
    
    public IRecordReader getRecordReader(ITaskInputSplit split, 
            TaskRunnable task, BasicInOutJobDef job) throws IOException {
        IRecordReader reader = super.getRecordReader(split, task, job);
        return new OrderChecker(reader); 
    }

}
