package odis.mapred;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordWriter;

/**
 * The output data format to open a writer of a destination.  The destinate
 * could be a file, a database or others.  For example, currently, we mostly 
 * deal with output files are stored in a file system.  There could
 * be multiple channels of output for each task.  {@link BasicOutputFormat} 
 * opens {@link IRecordWriter} for each output channel.
 *  
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 *
 * Created on Mar 14, 2006
 * Copyright (c) 2006, Outfox Team
 */
public abstract class BasicOutputFormat<K, V> {

  protected static int getMrPhase(int taskStage, BasicInOutJobDef conf) {
    return conf.getIoPhase(BasicInOutJobDef.TYPE_OUTPUT,taskStage);
  }
  
  protected String getSvcAddr(int taskStage, int channel, BasicInOutJobDef conf) {
    return conf.getOutputSvcAddr(getMrPhase(taskStage,conf),channel);
  }
  
  protected String getPath(int taskStage, int channel, BasicInOutJobDef conf) {
    return conf.getOutputPath(getMrPhase(taskStage,conf),channel);
  }
  
  protected Class getKeyClass(int taskStage, int channel, BasicInOutJobDef conf) {
    return conf.getOutputKeyClass(getMrPhase(taskStage,conf),channel);
  }

  protected Class getValueClass(int taskStage, int channel, BasicInOutJobDef conf) {
    return conf.getOutputValClass(getMrPhase(taskStage,conf),channel);
  }  
  
  /**
   * Open an {@link IRecordWriter} for <code>part</code> of an output channel
   * @param channel    index of the channel
   * @param task       the task which needs this writer 
   * @param jobConf    the configuration of a job
   * @return the record writer of this part in this channel
   * @throws IOException
   */
  protected abstract IRecordWriter<K, V> getRecordWriter(int channel, 
      TaskRunnable task, BasicInOutJobDef jobConf) throws IOException;
  
  /**
   * some finalize stuffs, like rename from temp file to target file 
   */
  protected abstract void finish() throws IOException;

}
