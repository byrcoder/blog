package odis.mapred;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import odis.cowork.CounterMap;
import odis.file.CompressUtils;
import odis.file.CompressUtils.CompressAlgo;
import odis.file.IRecordReader;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.FSDataInputStream;
import odis.io.FSDataOutputStream;
import odis.io.IFileSystem;
import odis.io.LzoInputStream;
import odis.io.LzoOutputStream;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.lib.IntWritable;
import odis.util.BoundedByteArrayOutputStream;
import odis.util.WritableUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;


/**
 * <code>IFile</code> is the simple <key-len, value-len, key, value> format
 * for the intermediate map-outputs in CoWork.
 *
 * @author tuqc
 */
public class IFile {
    private static final int EOF_MARKER = -1;
    protected static final Logger LOG = LogFormatter.getLogger(IFile.class);
    public static final int DEFAULT_GZIP_COMPRESS_BUFFER_SIZE = (int)(64 * UnitUtils.K);
    public static class Writer<K extends IWritable, V extends IWritable> {
        DataOutputStream out;

        boolean ownOutputStream = false;

        long start = 0;

        FSDataOutputStream rawOut;

//        boolean compressOutput = false;

        long decompressedBytesWritten = 0;

        long compressedBytesWritten = 0;

        // Count records written to disk
        private long numRecordsWritten = 0;

        private final CounterMap.Counter writtenRecordsCounter;

        Class<K> keyClass;

        Class<V> valueClass;


        public Writer(IFileSystem fs, Path file, Class<K> keyClass,
                Class<V> valueClass, CompressAlgo compressAlgo,
                CounterMap.Counter writesCounter) throws IOException {
            this(fs.create(file), keyClass, valueClass, compressAlgo, writesCounter);
            ownOutputStream = true;
        }

        public Writer(FSDataOutputStream out, Class<K> keyClass,
                Class<V> valueClass, CompressAlgo compressAlgo,
                CounterMap.Counter writesCounter) throws IOException {
            this.writtenRecordsCounter = writesCounter;
            this.rawOut = out;
            this.start = this.rawOut.getPos();

            if (compressAlgo != null) {
                this.out = new DataOutputStream(getCompressOutputStream(compressAlgo,out));
            } else {
                this.out = new DataOutputStream(out);
            }

            this.keyClass = keyClass;
            this.valueClass = valueClass;
        }

        public Writer(IFileSystem fs, Path file) throws IOException {
            this(fs, file, null, null, null, null);
        }

        public Writer(){
            writtenRecordsCounter = null;
        }
        
        public void close() throws IOException {

            // Write EOF_MARKER for key/value length
            WritableUtils.writeVInt(out, EOF_MARKER);
            WritableUtils.writeVInt(out, EOF_MARKER);
            decompressedBytesWritten += 2 * WritableUtils.getVIntSize(EOF_MARKER);

            // Flush the stream
            out.flush();

            // Close the underlying stream iff we own it...
            if (ownOutputStream) {
                out.close();
            }

            // TODO may be have bug here
            compressedBytesWritten = rawOut.getPos() - start;

            out = null;
            if (writtenRecordsCounter != null) {
                writtenRecordsCounter.inc(numRecordsWritten);
            }
        }

        DataOutputBuffer keyOutputBuffer = null;
        DataOutputBuffer valOutputBuffer = null;
        DataInputBuffer keyInputBuffer = null;
        DataInputBuffer valInputBuffer = null;
        public void append(Object key, Object value) throws IOException {
            if (key.getClass() != keyClass)
                throw new IOException("wrong key class: " + key.getClass()
                        + " is not " + keyClass);
            if (value.getClass() != valueClass)
                throw new IOException("wrong value class: " + value.getClass()
                        + " is not " + valueClass);

            if (keyOutputBuffer == null) {
                keyOutputBuffer = new DataOutputBuffer();
                valOutputBuffer = new DataOutputBuffer();       
                keyInputBuffer = new DataInputBuffer();
                valInputBuffer = new DataInputBuffer();
            }
            
            keyOutputBuffer.reset();
            ((IWritable)key).writeFields(keyOutputBuffer);

            valOutputBuffer.reset();
            ((IWritable)value).writeFields(valOutputBuffer);
            
            keyInputBuffer.reset(keyOutputBuffer);
            valInputBuffer.reset(valOutputBuffer);
            append(keyInputBuffer, valInputBuffer);                                               
        }

        public void append(DataInputBuffer key, DataInputBuffer value)
                throws IOException {
//            int keyLength = key.getSize() - key.getPosition();
            int keyLength = key.getSize();
            if (keyLength < 0) {
                throw new IOException("Negative key-length not allowed: "
                        + keyLength + " for " + key);
            }

//            int valueLength = value.getSize() - value.getPosition();
            int valueLength = value.getSize();
            if (valueLength < 0) {
                throw new IOException("Negative value-length not allowed: "
                        + valueLength + " for " + value);
            }

                     
            WritableUtils.writeVInt(out, keyLength);
            WritableUtils.writeVInt(out, valueLength);
            out.write(key.getBuffer(), key.getPosition(), keyLength);
            out.write(value.getBuffer(), value.getPosition(), valueLength);

            // Update bytes written
            decompressedBytesWritten += keyLength + valueLength
                    + WritableUtils.getVIntSize(keyLength)
                    + WritableUtils.getVIntSize(valueLength);
            ++numRecordsWritten;
//            if (writtenRecordsCounter != null) writtenRecordsCounter.inc();
        }
        
        public void append(byte[] data, int start, int keyLength,
                int valueLength) throws IOException {
            if (keyLength < 0 || valueLength < 0) {
                throw new IOException("Negative value-length not allowed. keyLen=" + keyLength + ", valLen=" + valueLength);
            }
            WritableUtils.writeVInt(out, keyLength);
            WritableUtils.writeVInt(out, valueLength);
            out.write(data, start, keyLength);
            out.write(data, start + keyLength, valueLength);

            // Update bytes written
            decompressedBytesWritten += keyLength + valueLength
                    + WritableUtils.getVIntSize(keyLength)
                    + WritableUtils.getVIntSize(valueLength);
            ++numRecordsWritten;            
        }

        // Required for mark/reset
        public DataOutputStream getOutputStream() {
            return out;
        }

        // Required for mark/reset
        public void updateCountersForExternalAppend(long length) {
            ++numRecordsWritten;
            decompressedBytesWritten += length;
        }

        public long getRawLength() {
            return decompressedBytesWritten;
        }

        public long getCompressedLength() {
            return compressedBytesWritten;
        }
    }
    
    public static OutputStream getCompressOutputStream(CompressAlgo algo, OutputStream out) throws IOException{
        if (algo == CompressAlgo.GZIP) {
            return new GZIPOutputStream(out, IFile.DEFAULT_GZIP_COMPRESS_BUFFER_SIZE);
        } else { // defalut lzo
            return new LzoOutputStream(out);
        }
    }
    
    public static InputStream getDecompressInputStream(CompressAlgo algo, InputStream in) throws IOException {
        if (algo == CompressAlgo.GZIP) {
            return new GZIPInputStream(in);
        }else {
            return new LzoInputStream(in);
        }
    }
    
    public static class Reader<K extends IWritable, V extends IWritable>{
        private static final int DEFAULT_BUFFER_SIZE = 128 * 1024;

        private static final int MAX_VINT_SIZE = 9;

        // Count records read from disk
        private long numRecordsRead = 0;

        protected CounterMap.Counter readRecordsCounter;

        final FSDataInputStream rawIn; // Possibly decompressed stream that we read

        public long bytesRead = 0;

        protected final long fileLength;

        protected boolean eof = false;

        protected byte[] buffer = null;

        protected int bufferSize = DEFAULT_BUFFER_SIZE;

        protected DataInputStream dataIn;

        protected int recNo = 1;

        protected int currentKeyLength;

        protected int currentValueLength;

        byte keyBytes[] = new byte[0];

        /**
         * Construct an IFile Reader.
         * 
         * @param fs
         *            FileSystem
         * @param file
         *            Path of the file to be opened. This file should have
         *            checksum bytes for the data at the end of the file.
         * @param compressAlgo
         *            compress algo
         * @param readsCounter
         *            Counter for records read from disk
         * @throws IOException
         */
        public Reader(IFileSystem fs, Path file,
                CompressAlgo compressAlgo, CounterMap.Counter readsCounter)
                throws IOException {
            this(fs, file, 0, fs.getLength(file), compressAlgo, readsCounter);
        }

        public Reader(IFileSystem fs, Path file, long offset, long length,CompressAlgo compressAlgo, CounterMap.Counter readsCounter)
                throws IOException {
            this(fs.open(file), offset, length, compressAlgo, readsCounter);
        }

        public Reader(FSDataInputStream in, long length,
                CompressAlgo compressAlgo, CounterMap.Counter readsCounter)
                throws IOException {
            this(in, 0, length, compressAlgo, readsCounter);
        }
        
        /**
         * Construct an IFile Reader.
         * 
         * @param in
         *            The input stream
         * @param length
         *            Length of the data in the stream, including the checksum
         *            bytes.
         * @param compressAlgo
         *            codec
         * @param readsCounter
         *            Counter for records read from disk
         * @throws IOException
         */
        public Reader(FSDataInputStream in, long offset, long length,
                CompressAlgo compressAlgo, CounterMap.Counter readsCounter)
                throws IOException {
            if (offset > 0 ) in.seek(offset);
            readRecordsCounter = readsCounter;
            if (compressAlgo != null) {
                this.dataIn = new DataInputStream(getDecompressInputStream(compressAlgo, in));
            } else {
                this.dataIn = new DataInputStream(in);
            }
            this.rawIn = in;
            this.fileLength = length;
        }

        public DataInputStream getDataInputStream() {
            return this.dataIn;
        }
        
        public long getLength() throws IOException{
            return fileLength - this.rawIn.getPos();
        }

        public long getPosition() throws IOException {
            return this.rawIn.getPos();
        }
        
        public void setReadCounter(CounterMap.Counter c) {
            this.readRecordsCounter = c;
        }
        
        public CounterMap.Counter getReadCounter() {
            return this.readRecordsCounter;
        }

        /**
         * Read upto len bytes into buf starting at offset off.
         * 
         * @param buf
         *            buffer
         * @param off
         *            offset
         * @param len
         *            length of buffer
         * @return the no. of bytes read
         * @throws IOException
         */
        private int readData(byte[] buf, int off, int len) throws IOException {
            int bytesRead = 0;
            while (bytesRead < len) {
                int n = dataIn.read(buf, off + bytesRead, len - bytesRead);
                if (n < 0) {
                    return bytesRead;
                }
                bytesRead += n;
            }
            return len;
        }

        protected boolean positionToNextRecord(DataInput dIn)
                throws IOException {
            // Sanity check
            if (eof) {
                throw new EOFException("Completed reading " + bytesRead);
            }

            // Read key and value lengths
            currentKeyLength = WritableUtils.readVInt(dIn);
            currentValueLength = WritableUtils.readVInt(dIn);
            bytesRead += WritableUtils.getVIntSize(currentKeyLength)
                    + WritableUtils.getVIntSize(currentValueLength);

            // Check for EOF
            if (currentKeyLength == EOF_MARKER
                    && currentValueLength == EOF_MARKER) {
                eof = true;
                return false;
            }

            // Sanity check
            if (currentKeyLength < 0) {
                throw new IOException("Rec# " + recNo
                        + ": Negative key-length: " + currentKeyLength);
            }
            if (currentValueLength < 0) {
                throw new IOException("Rec# " + recNo
                        + ": Negative value-length: " + currentValueLength);
            }

            return true;
        }

        public boolean nextRawKey(DataInputBuffer key) throws IOException {
            if (!positionToNextRecord(dataIn)) {
                return false;
            }
            if (keyBytes.length < currentKeyLength) {
                keyBytes = new byte[currentKeyLength << 1];
            }
            int i = readData(keyBytes, 0, currentKeyLength);
            if (i != currentKeyLength) {
                throw new IOException("Asked for " + currentKeyLength
                        + " Got: " + i);
            }
            key.reset(keyBytes, currentKeyLength);
            bytesRead += currentKeyLength;            
            return true;
        }

        public void nextRawValue(DataInputBuffer value) throws IOException {
            final byte[] valBytes = (value.getBuffer().length < currentValueLength) ? new byte[currentValueLength << 1]
                    : value.getBuffer();
            int i = readData(valBytes, 0, currentValueLength);
            if (i != currentValueLength) {
                throw new IOException("Asked for " + currentValueLength
                        + " Got: " + i);
            }
            value.reset(valBytes, currentValueLength);

            // Record the bytes read
            bytesRead += currentValueLength;
            ++recNo;
            ++numRecordsRead;
        }

        public void close() throws IOException {
            // Close the underlying stream
            rawIn.close();

            // Release the buffer
            dataIn = null;
            buffer = null; 
            if (readRecordsCounter != null) {
                readRecordsCounter.inc(numRecordsRead);
            }
        }

        public void reset(int offset) {
            return;
        }

        /*
        DataInputBuffer keyBuf = null;
        DataInputBuffer valueBuf = null;
        @Override
        public DataInputBuffer getKey() throws IOException {
            return keyBuf;
        }

        @Override
        public DataInputBuffer getValue() throws IOException {
            if (valueBuf == null) valueBuf = new DataInputBuffer();
            nextRawValue(valueBuf);
            return valueBuf;
        }

        @Override
        public boolean next() throws IOException {
            if (keyBuf == null) keyBuf = new DataInputBuffer();
            if (nextRawKey(keyBuf)) return true;
            else            
                return false;
        }
        */

//        public void disableChecksumValidation() {
//            checksumIn.disableChecksumValidation();
//        }

    }

    public static class RecordReader implements IRecordReader{

        private Class keyClass, valClass;
        IFile.Reader reader;
        boolean ownReader = false;
        
        DataInputBuffer keyBuf, valBuf;        
        
        public RecordReader(Class keyClass, Class valClass, IFileSystem fs,
                Path path, long offset, long length, CompressAlgo algo,
                CounterMap.Counter counter) throws IOException {
            this(keyClass, valClass, new Reader(fs, path, offset, length, algo, counter));
            
        }
        
        public RecordReader(Class keyClass, Class valClass, IFile.Reader reader) {            
            this.keyClass = keyClass;
            this.valClass = valClass;
            this.reader = reader;
            this.keyBuf = new DataInputBuffer();
            this.valBuf = new DataInputBuffer();
        }
        
        @Override
        public Class getKeyClass() {
            return keyClass;
        }

        @Override
        public Class getValueClass() {
            return valClass;
        }

        @Override
        public boolean next(Object key, Object value) throws IOException {
            if (!key.getClass().equals(keyClass) || !value.getClass().equals(valClass)) {
                throw new IOException("key/value class not match.");
            }
            if (reader.nextRawKey(keyBuf)) {
                reader.nextRawValue(valBuf);
                ((IWritable)key).readFields(keyBuf);
                ((IWritable)value).readFields(valBuf);
                return true;
            }else
                return false;
        }

        @Override
        public void close() throws IOException {
            if (ownReader) reader.close();
        }

        @Override
        public long getPos() throws IOException {
            return reader.getPosition();
        }

        @Override
        public long getSize() throws IOException {
            return reader.getLength();
        }
        
    }
    
    public static class InMemoryWriter<K extends IWritable, V extends IWritable>
            extends IFile.Writer<K, V> {
        private DataOutputStream out;

        public InMemoryWriter(BoundedByteArrayOutputStream arrayStream) {
            super();
            this.out = new DataOutputStream(new IFileOutputStream(arrayStream));
        }

        public void append(K key, V value) throws IOException {
            throw new UnsupportedOperationException(
                    "InMemoryWriter.append(K key, V value");
        }

        public void append(DataInputBuffer key, DataInputBuffer value)
                throws IOException {
            int keyLength = key.getSize() - key.getSize();
            if (keyLength < 0) {
                throw new IOException("Negative key-length not allowed: "
                        + keyLength + " for " + key);
            }

            int valueLength = value.getSize() - value.getPosition();
            if (valueLength < 0) {
                throw new IOException("Negative value-length not allowed: "
                        + valueLength + " for " + value);
            }

            WritableUtils.writeVInt(out, keyLength);
            WritableUtils.writeVInt(out, valueLength);
            out.write(key.getBuffer(), key.getPosition(), keyLength);
            out.write(value.getBuffer(), value.getPosition(), valueLength);
        }

        public void close() throws IOException {
            // Write EOF_MARKER for key/value length
            WritableUtils.writeVInt(out, IFile.EOF_MARKER);
            WritableUtils.writeVInt(out, IFile.EOF_MARKER);

            // Close the stream
            out.close();
            out = null;
        }
    }    
    
    public static class IFileOutputStream extends FilterOutputStream {
        /**
         * The output stream to be checksummed. 
         */
//        private final DataChecksum sum;
        private byte[] barray;
        private boolean closed = false;
        private boolean finished = false;

        /**
         * Create a checksum output stream that writes
         * the bytes to the given stream.
         * @param out
         */
        public IFileOutputStream(OutputStream out) {
          super(out);
//          sum = DataChecksum.newDataChecksum(DataChecksum.CHECKSUM_CRC32,
//              Integer.MAX_VALUE);
//          barray = new byte[sum.getChecksumSize()];
          barray = new byte[1];
        }
        
        @Override
        public void close() throws IOException {
          if (closed) {
            return;
          }
          closed = true;
          finish();
          out.close();
        }

        /**
         * Finishes writing data to the output stream, by writing
         * the checksum bytes to the end. The underlying stream is not closed.
         * @throws IOException
         */
        public void finish() throws IOException {
          if (finished) {
            return;
          }
          finished = true;
//          sum.writeValue(barray, 0, false);
//          out.write (barray, 0, sum.getChecksumSize());
          out.flush();
        }

        /**
         * Write bytes to the stream.
         */
        @Override
        public void write(byte[] b, int off, int len) throws IOException {
//          sum.update(b, off,len);
          out.write(b,off,len);
        }
       
        @Override
        public void write(int b) throws IOException {
          barray[0] = (byte) (b & 0xFF);
          write(barray,0,1);
        }
    }
}
