package odis.mapred.lib;

import odis.mapred.AbstractReducer;
import odis.mapred.ICollector;
import odis.mapred.IWritablePairWalker;
import odis.serialize.IWritable;

public class IdentityReducer extends AbstractReducer {
  
  public void reduce(Object key, IWritablePairWalker values, ICollector collector) {
    while (values.moreValue())
      collector.collect(key, (IWritable)values.getValue());    
  }

}
