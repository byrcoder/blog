package odis.mapred.lib;

import odis.serialize.lib.Url;

/**
 * Partition url by md5Hash, for compatible with docid.
 * @see odis.mapred.lib.LongHashPartitioner
 * @author river
 */
public class UrlMd5Partitioner extends SeqFileHashPartitioner {

    public static int getPartition(Url url, int numPartitions) {
        return (int) ((url.md5HashCode() & Long.MAX_VALUE) % numPartitions);
    }

    public int getPartition(Object key, Object value, int numPartitions) {
        return getPartition((Url) key, numPartitions);
    }

}
