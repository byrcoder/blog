package odis.mapred.lib;

import java.io.IOException;

import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.ITaskInputSplit;
import odis.serialize.IWritable;
import odis.serialize.lib.TypedBlobWritable;
import toolbox.misc.ClassUtils;

/**
 * The basic class for typed blob writable from sequence file.
 * When using this input format, the value will be converted into
 * a TypedBlobWritable, and the content is the blob data. The type is
 * set to be an integer number.
 * 
 * Use getBlobSeqFileInputFormat to get a typed class.
 * 
 * This class is useful when input files with indentity types have
 * to be distiguished during processing. 
 * 
 * @author David
 *
 */
public abstract class TypedBlobSeqFileInputFormat extends SeqFileInputFormat {
    /**
     * Returns a TypedBlobSeqFileInputFormat corresponding to the specified 
     * index.
     * @param index  the index as tye type, should be withing [0, 9]
     * @return  a TypedBlobSeqFileInputFormat corresponding to the specified 
     * index
     */
    public static Class<? extends TypedBlobSeqFileInputFormat> get(int index) {
        if (index == 0)
            return Type_0.class;
        if (index == 1)
            return Type_1.class;
        if (index == 2)
            return Type_2.class;
        if (index == 3)
            return Type_3.class;
        if (index == 4)
            return Type_4.class;
        if (index == 5)
            return Type_5.class;
        if (index == 6)
            return Type_6.class;
        if (index == 7)
            return Type_7.class;
        if (index == 8)
            return Type_8.class;
        if (index == 9)
            return Type_9.class;
        return null;
    }
    /**
     * Returns the index
     * @return the index
     */
    public abstract int getIndex();
    public IRecordReader getRecordReader(ITaskInputSplit split, 
            TaskRunnable task, BasicInOutJobDef job) throws IOException {
        final IRecordReader in = super.getRecordReader(split, task, job);
        if (!IWritable.class.isAssignableFrom(in.getValueClass()))
            throw new RuntimeException(in.getValueClass() + " is not a IWritable!");
        
        return new IRecordReader() {
            private IWritable vl = (IWritable) ClassUtils.newInstance(in.getValueClass());
            
            public void close() throws IOException {
                in.close();
            }
            public Class getKeyClass() {
                return in.getKeyClass();
            }
            public long getPos() throws IOException {
                return in.getPos();
            }
            public long getSize() throws IOException {
                return in.getSize();
            }

            public Class getValueClass() {
                return TypedBlobWritable.class;
            }
            
            public boolean next(Object key, Object value) throws IOException {
                if (!in.next(key, vl))
                    return false;
                
                ((TypedBlobWritable) value).setType(getIndex());
                ((TypedBlobWritable) value).setData(vl);
                
                return true;
            }
        };
    }
    /**
     * The type-0 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_0 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 0; }
    }
    /**
     * The type-1 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_1 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 1; }
    }
    /**
     * The type-2 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_2 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 2; }
    }
    /**
     * The type-3 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_3 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 3; }
    }
    /**
     * The type-4 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_4 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 4; }
    }
    /**
     * The type-5 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_5 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 5; }
    }
    /**
     * The type-6 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_6 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 6; }
    }
    /**
     * The type-7 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_7 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 7; }
    }
    /**
     * The type-8 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_8 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 8; }
    }
    /**
     * The type-9 TypedBlobSeqFileInputFormat class
     * @author david
     */
    public static class Type_9 extends TypedBlobSeqFileInputFormat {
        @Override
        public int getIndex() { return 9; }
    }
}
