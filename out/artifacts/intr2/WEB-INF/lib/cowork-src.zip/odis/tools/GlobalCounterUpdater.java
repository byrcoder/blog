package odis.tools;
import java.net.InetSocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import odis.cowork.CounterMap;
import odis.cowork.IJobMasterProtocol;
import odis.cowork.IJobSubmissionProtocol;
import odis.cowork.ITaskMasterProtocol;
import odis.cowork.CounterMap.Counter;
import odis.rpc2.RPC;
import odis.rpc2.RpcException;
import toolbox.misc.LogFormatter;
/**
 * Use GlobalCounter can get the golbal counter info
 * 
 * @author tuqc 2009-9-7
 * 
 */
public class GlobalCounterUpdater {
    private static final Logger LOG = LogFormatter.getLogger(GlobalCounterUpdater.class);
    protected static final int UPDATE_INTERVAL = 10 * 1000; //10s
    protected ConcurrentHashMap<String,GlobalCounter> jobCounters;
    protected ITaskMasterProtocol taskMaster;    
    protected IJobSubmissionProtocol jobMaster;
    public GlobalCounterUpdater(ITaskMasterProtocol tm) {
        this.taskMaster = tm;
        jobMaster = null;
        jobCounters = new ConcurrentHashMap<String,GlobalCounter>();
    }
    public GlobalCounterUpdater(IJobSubmissionProtocol jm) {
        this.taskMaster = null;
        jobMaster = jm;
        jobCounters = new ConcurrentHashMap<String,GlobalCounter>();        
    }
    
    public GlobalCounterUpdater(InetSocketAddress masterAddr) throws RpcException {
        jobMaster = RPC.getProxy(IJobMasterProtocol.class, masterAddr);
        this.taskMaster = null;
        jobCounters = new ConcurrentHashMap<String,GlobalCounter>();        
    }
    
    public GlobalCounterUpdater(String masterIp, int port) throws RpcException {
        this(new InetSocketAddress(masterIp,port));
    }
        
    public synchronized GlobalCounter getGlobalCounter(String jobId) {
        if (!jobCounters.containsKey(jobId)) {
            jobCounters.put(jobId, new GlobalCounter(jobId));
        }
        return jobCounters.get(jobId);
    }
    
    protected CounterMap[] update(String jobId) throws RuntimeException{
        if (taskMaster != null) {
            try{
                return taskMaster.getGlobalCounters(jobId);
            }catch(Exception e) {
                LOG.warning("update global counter from taskmaster error." + e);
                throw new RuntimeException(e);
            }
        }else {
            try {
                return jobMaster.getJobCounters(jobId);
            }catch(Exception e) {
                LOG.warning("update global counter from jobmaster error." + e);
                throw new RuntimeException(e);                
            }
        }            
    }

    public class GlobalCounter{
        protected long lastUpdate;
        protected String jobId;
        protected CounterMap[] counters;
        protected long updateInterval;
        public GlobalCounter(String jobId) {
            this.jobId = jobId;
            lastUpdate = 0;
            counters = null;
            updateInterval = UPDATE_INTERVAL;
        }
        
        public void setUpdateInterval(int milSecond) {
            updateInterval = milSecond;
        }
        
        public long getUpdateInterval() {
            return updateInterval;    
        }

        public long get(String counterName, int stageIdx) {
            CounterMap cm = getCounterMap(stageIdx);
            if (cm != null) {
                Counter c = cm.get(counterName);
                if (c != null)
                    return c.get();
                
            }
            return 0;
        }
        
        public CounterMap getCounterMap(int stageIdx) {
            if (System.currentTimeMillis() - lastUpdate > updateInterval) {
                update();
                lastUpdate = System.currentTimeMillis();
            }
            return counters[stageIdx]; 
        }
        
        protected void update() {
            counters = GlobalCounterUpdater.this.update(jobId);
        }
    }
}
