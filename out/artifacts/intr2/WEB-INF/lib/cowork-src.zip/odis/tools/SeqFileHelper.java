package odis.tools;

import java.io.IOException;

import odis.file.SequenceFile;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.mapred.MRConfig;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import toolbox.misc.ClassUtils;
import toolbox.misc.UnitUtils;

public class SeqFileHelper {
    
    
    public static Object peekKeyFromNextSync(SequenceFile.Reader reader, long pos) throws IOException {
        long oldPos = reader.getPos();
        reader.seek(pos);
        reader.sync(pos);
        try {
            Object curKey, curValue;
            curKey = reader.getKeyClass().newInstance();
            curValue = reader.getValueClass().newInstance();
            
            if (reader.next(curKey, curValue)) {
                return curKey;
            }        
            return null;
        }catch(Exception e) {
            throw new IOException(e);
        }finally {
            reader.seek(oldPos);            
        }
    }
    
    public static final long DEFAULT_SKIP = UnitUtils.M * 8;
    public static long getNearSyncLessThan(IFileSystem fs, Path p, 
            IWritableComparable target) throws IOException {
        SequenceFile.Reader reader = new SequenceFile.Reader(fs, p);
        try {
            return getNearSyncLessThan(reader, target, DEFAULT_SKIP);
        }finally {
            reader.close();
        }
    }
    
    
    /**
     * for the sequence file sorted from low to high
     * @param reader
     * @param target
     * @return
     * @throws IOException
     */
    public static long getNearSyncLessThan(SequenceFile.Reader reader, 
            IWritableComparable target, long skip) throws IOException {      
        IWritableComparable k = (IWritableComparable)ClassUtils.newInstance(reader.getKeyClass());
        IWritable v = (IWritable)ClassUtils.newInstance(reader.getValueClass());
        
        long low = 0;
        long high = reader.getEnd();        
        
        reader.sync(low);
        low = reader.getPosition();
        long from = low;
        while (high - low > skip) {
            long mid = (high + low) / 2;
            reader.seek(mid);
            reader.sync(mid);
            mid = reader.getPosition();
            if (!reader.next(k, v))
                return -1;
            int t = k.compareTo(target);
            if (t < 0) {
                low = mid;
                from = mid;
            } else if (t == 0) {
                // find pre sequencial
                from = mid - skip;
                while (from > 0) {
                    reader.seek(from);
                    reader.sync(from);
                    if (!reader.next(k, v))
                        return -1;

                    if (k.compareTo(target) < 0) // find it
                        break;
                    from = from - skip;
                }

                if (from < 0)
                    from = 0;
                from = reader.getPosition();
                break;
            } else {
                high = mid;
            }
        }

        return from;
    }    
    
    public static void moveNearTo(SequenceFile.Reader reader, IWritableComparable target, long skip) throws IOException {
        long pos = SeqFileHelper.getNearSyncLessThan(reader, target, skip);
        if (pos < 0) throw new IOException("Move near error.");
        reader.seek(pos);
    }
}
