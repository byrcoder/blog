/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.tools.demo;

import odis.cowork.JobResult;
import odis.mapred.AbstractMapper;
import odis.mapred.BasicMerger;
import odis.mapred.BasicPartitioner;
import odis.mapred.ICollector;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.IntWritable;
import odis.tools.MapReduceHelper;


/**
 * A simple demo to show MR: use map-reduce to invert (k,v) to (v,k) and then
 * sort according to v.
 *
 * @author zl
 *
 */
public class InvertDemo extends CountStatDemo {
  
  // args for test
  private int compressBlockSize = -1;
  private boolean objectCompressed = false;
  private String javaConfig = "";
  private int heapSize = 200;
  private boolean isExclusive = false;
  
  public void setCompressBlockSize(int v) { compressBlockSize = v; }
  public void setObjectCompressed(boolean v) { objectCompressed = v; }
  public void setJavaConfig(String s) {javaConfig = s;}
  public void setHeapSize(int heap) {heapSize = heap;}
  public void setExclusive() {isExclusive = true;}
  
  public static class InvertMapper extends AbstractMapper<Object,Object> {
    
    public void map(Object key, Object value, ICollector collector) {
      assert value instanceof IWritableComparable;
      collector.collect((IWritableComparable)value,key);
    }

  }

  public boolean exec(int nWorker) throws Exception {
      if ("generate".equals(cmd))
          return generate(inDir.getPath(), ln,fn, nWorker);
      else if (!"run".equals(cmd)) {
          usage(out);
          throw new IllegalArgumentException("Wrong arguments input.");
      }
      
      MapReduceJobDef job = context.createMapReduceJob("invert", nWorker);
      
      MapReduceHelper helper = new MapReduceHelper(job, context.getFileSystem(), tmpDir, inDir); 
      helper.addReadInputDir(inDir, SeqFileInputFormat.class);
      helper.addDirectOutputDir(IdentityReducer.DEFAULT_OUTPUT_CHANNEL, 
          outDir, IntWritable.class, IntWritable.class, 
          SeqFileOutputFormat.class);
      BasicPartitioner.setCompress(job, compressBlockSize, objectCompressed);
      
      // mapper/merge/reducer
      job.setMapper(InvertMapper.class);
      job.setMergeKeyValClass(IntWritable.class, IntWritable.class);
      job.setMergeCompressed(true);
      job.useDefaultHashPartitioner();
      job.setReducer(IdentityReducer.class);
      job.setTaskHeapSize(heapSize);
      job.addTaskJavaConfig(javaConfig);
      job.setNextStageStartThreshold(nextStageStartThreshold);
      job.setBoostFactor(boostFactor);
      if (isExclusive) {
          job.setTaskPerMachine(0, 1);
      }
      // map/reduce number
      job.setMapNumber(mn); job.setReduceNumber(rn);
                  
      // run job
      JobResult result = helper.runJob(context.getCoWork());
      return result!=null && result.isSuccess();
  }

  public String comment() {
      return "Invert the (key,value) pair as (value,key)";
  }

}
