package odis.tools;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Logger;

import odis.cowork.JobClient;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.file.IRecordReader;
import odis.file.IRecordWriter;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.BasicInputFormat;
import odis.mapred.BasicOutputFormat;
import odis.mapred.BasicSplitter;
import odis.mapred.ITaskInputSplit;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.IdentityMapper;
import odis.mapred.lib.IdentityReducer;
import odis.mapred.lib.ReuseWalker;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IWritable;
import odis.serialize.lib.LongWritable;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.ArgumentProcessor;
import toolbox.text.util.StringUtils;

/**
 * The tool for cowork benchmark.
 * 
 * This job is a normal map-reduce job, but the input and output does not call
 * file-system. So using this tool you can benchmark the pure cowork efficiency
 * without considering the performance of file-system.
 * 
 * Usage:
 *   cowork-bench -nmap 2 -nred 2 -size 1000
 * 
 * @author david
 *
 */
public class CoworkBenchTool extends AbstractCoWorkTool {
	protected static final Logger LOG = LogFormatter.getLogger(CoworkBenchTool.class);
    int nmap = 1;
    int nred = 1;
    int wn = 1;
    boolean pf = false;
    long size = 1024 * 1024 * 1024;
    ArgumentProcessor ap = new ArgumentProcessor(
    		"wn", 1, "COMMENT: the number of worker",
            "nmap", 1, "COMMENT: the number of mappers",
            "nred", 1, "COMMENT: the number of reducers",
            "size", 1, "COMMENT: the size of the input data in MB",
            "pf", false, "COMMENT: generate power law data"
            );
    
    @Override
    protected boolean processArgs(String[] args) throws Exception {
        String res = ap.process(args, 0);
        if (res != null) {
            System.err.println(res);
            usage(out);
            return false;
        } // if
        
        if (!ap.isOptSet("nmap") || !ap.isOptSet("nred") 
                || !ap.isOptSet("size")) {
            usage(out);
            return false;
        } // if
        
        wn = ap.getIntOpt("wn");
        nmap = ap.getIntOpt("nmap");
        nred = ap.getIntOpt("nred");
        size = ap.getIntOpt("size") * 1024L * 1024;
        
        System.out.println("nmap: " + nmap);
        System.out.println("nred: " + nred);
        System.out.println("size: " + StringUtils.byteDesc(size));
        
        return super.processArgs(args);
    }
    
    @Override
    public String comment() {
        return "Benchmark tool for cowork";
    }

    /**
     * A data-structure of ITaskInputSplit for length and nWorker.
     * 
     * @author david
     *
     */
    public static class LengthSplit implements ITaskInputSplit {
        private int nWorker;
        private long length;
        
        
        public LengthSplit() {
        	
        }
        /**
         * The constructor.
         * 
         * @param nWorker  the number of workers
         * @param length  the length of this split in bytes
         */
        public LengthSplit(int nWorker, long length) {
            this.nWorker = nWorker;
            this.length = length;
        }

        public long getLength() throws IOException {
            return length;
        }

        public String getPart() {
            return "";
        }

        public String getSource() {
            return BasicInOutJobDef.getServiceUrl("rand",
                    nWorker + "." + length);
        }

        public void readFields(DataInput in) throws IOException {
            length = in.readLong();
            nWorker = in.readInt();
        }

        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(length);
            out.writeInt(nWorker);
        }

        public IWritable copyFields(IWritable value) {
            this.length = ((LengthSplit) value).length;
            this.nWorker = ((LengthSplit) value).nWorker;
            return this;
        }

        @Override
        public String toString() {
            return "length: " + length;
        }
    }
    
    /**
     * The input format generating random data.
     * 
     * @author david
     *
     */
    public static class RandomDataInputFormat extends BasicInputFormat {
        @Override
        public IRecordReader getRecordReader(ITaskInputSplit split,
                TaskRunnable task, BasicInOutJobDef jobConf) throws IOException {
            LengthSplit spl = (LengthSplit) split;
            final long size = spl.getLength();
            final Random rand = new Random();
            return new IRecordReader() {
                long pos = 0;
                public void close() throws IOException {
                }

                public Class getKeyClass() {
                    return LongWritable.class;
                }

                public long getPos() throws IOException {
                    return pos;
                }

                public long getSize() throws IOException {
                    return size;
                }

                public Class getValueClass() {
                    return LongWritable.class;
                }

                public boolean next(Object key, Object value)
                        throws IOException {
                    if (pos >= size)
                        return false;

                    ((LongWritable) key).set(rand.nextLong());
                    ((LongWritable) value).set(rand.nextLong());

                    pos ++;
                    return true;
                }
            };
        }

        @Override
        public String[] listParts(String svcAddr, String path)
                throws IOException {
            String[] nums = new File(path).getName().split("\\.");
            int count = Integer.parseInt(nums[0]);
            String[] res = new String[count];
            for (int i = 0; i < res.length; i ++)
                res[i] = i + "." + nums[1];
            LOG.info("listParts: " + path);
            LOG.info("Part of input:" + Arrays.deepToString(res));
            return res;
        }
    }
    /**
     * The null-output format.
     * 
     * @author david
     *
     */
    public static class NullOuputFormat extends BasicOutputFormat {
        @Override
        protected void finish() throws IOException {
        }

        @Override
        protected IRecordWriter getRecordWriter(int channel, TaskRunnable task,
                BasicInOutJobDef jobConf) throws IOException {
            return new IRecordWriter() {
                long size = 0;
                public void close() throws IOException {
                }

                public long getSize() throws IOException {
                    return size;
                }

                public void write(Object key, Object value) throws IOException {
                    size ++;
                }
            };
        }
    }
    /**
     * The simple BasicSplitter that splits the input by its file-name.
     * 
     * @author david
     *
     */
    public static class SimpleBasicSplitter extends BasicSplitter {
        @Override
        protected ITaskInputSplit[][] split(int taskStage, BasicInOutJobDef job)
                throws IOException {

            // only support one channel
            assert getChannelNum(taskStage, job) == 1;
            String[] parts = getParts(taskStage, 0, job);
            ITaskInputSplit[][] res = new ITaskInputSplit[parts.length][1];

            for (int i = 0; i < parts.length; i ++) {
                res[i][0] = new LengthSplit(parts.length,
                        Long.parseLong(parts[i].split("\\.")[1]));
            } // for i

            LOG.info("Input splits:" + Arrays.deepToString(res));
            return res;
        }
    }
    
    @Override
    public boolean exec(int nWorker) throws Exception {
        MapReduceJobDef job = context.createMapReduceJob("cowork-bench", 
                wn);
        
        // map
        /*
         * Input file name:
         *   <part-number>.<size>
         * the size of each part = size / 16 / nmap
         * where 16 is the bytes of each entry (2 longs)
         */
        job.addInputDir("rand", new Path(nmap + "." + (size / 16 / nmap)),
                RandomDataInputFormat.class);
        job.setMapper(IdentityMapper.class);
        job.setMapNumber(nmap);
        
        job.setPerUnitSplit(true);
        job.setInputSplitter(SimpleBasicSplitter.class);

        // reduce
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setMergeKeyValClass(LongWritable.class, LongWritable.class);
        job.setReducer(IdentityReducer.class);
        job.setReduceNumber(nred);
        job.setWalkerClass(ReuseWalker.class);
        job.addOutputDir(0, new Path("empty"), LongWritable.class,
                LongWritable.class, NullOuputFormat.class);

        JobResult res = JobClient.runJob(context.getCoWork(), job);
        if (!res.isSuccess())
            return false;
        
        return true;
    }

    @Override
    public void usage(PrintWriter out) {
        ap.printHelpInfo(out, "cowork-bench", 100);
    }
}
