package odis.tools;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import junit.framework.TestCase;
import odis.cowork.JobDef;
import odis.io.FileSystem;
import odis.io.LocalFileSystem;
import odis.io.Path;
import odis.mapred.BasicInOutJobDef;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.ITool;

/**
 * A base class for writing test-cases related to odis. 
 * The class does the following things:
 *   1) homePath/inputPath/outputPath/tempPath definition. homePath points to
 *      a folder name related to the current testing class. Other paths are
 *      sub-folders of homePath
 *   2) All paths are cleared before testing, and try remove after testing. If
 *      some paths are failed to removed, an exception is raised, since this
 *      means some files are not correctly closed.
 * 
 * @author david
 *
 */
public class TestCaseOdis extends TestCase {
    static {
        // set the TEST sysenv, so some settings,
        // such as task heap size should be set to proper value for single
        // machine
        System.setProperty("IS_TEST", "true");
    }

    @Deprecated // use homePath instead
    protected File testDir; // the home directory of all

    @Deprecated // use inputPath instead
    protected File inputDir;
    @Deprecated // use outputPath instead
    protected File outputDir;
    @Deprecated // use tempPath instead
    protected File tempDir;

    protected Path homePath; // the home directory of all
    protected Path inputPath; // input directory
    protected Path outputPath; // the output directory
    protected Path tempPath; // the temporary directory
    
    protected LocalFileSystem lfs;

    protected FileSystem fs;

    protected PrintWriter out;
    
    protected ToolContext context;
    
    protected String testName = null;

    public TestCaseOdis() {}
    
    void setTestName(String name) {
        this.testName = name;
    }
    
    @SuppressWarnings("deprecation")
    protected void setUp() throws Exception {
        LogFormatter.setShowThreadIDs(true);

        super.setUp();

        // lfs & nfs
        lfs = new LocalFileSystem();
        fs = lfs;

        // test dir
        if (testName == null) {
            testName = this.getClass().getName();
        }
        
        /*
         * Initialize homePath/inputPath/outputPath/tempPath 
         */
        homePath = new Path(System.getProperty("test.build.data", "."), 
                testName);
        System.out.println("Using test directory: " + homePath);
        if (lfs.exists(homePath) && !lfs.delete(homePath))
            throw new IOException("Cannot clean test directory: " + homePath);
        lfs.mkdirs(homePath);
        
        inputPath = homePath.cat("input");
        outputPath = homePath.cat("output");
        tempPath = homePath.cat("tmp");
        lfs.mkdirs(tempPath);
        
        /*
         * Initialize testDir/inputDir/outputDir/tempDir 
         */
        testDir = homePath.asFile();

        // other dir
        inputDir = inputPath.asFile();
        outputDir = outputPath.asFile();
        tempDir = tempPath.asFile();

        out = new PrintWriter(System.out, true);
        
        String appName = testName.replace('.', '_') + "_" + System.currentTimeMillis();
        ToolContext.addApp(appName, "local", testDir.getPath());
        context = new ToolContext(appName) {
            public void configJob(JobDef job, String jobName, int nWorker) {
                super.configJob(job, jobName, nWorker);
                if (job instanceof BasicInOutJobDef) {
                    BasicInOutJobDef ioJob = (BasicInOutJobDef) job;
                    ioJob.setFsOvaryDir(tempDir.getPath());
                }
            }
        };
        context.setCoWork("local");
    }

    protected void tearDown() throws Exception {
        if (lfs.exists(homePath))
            if (!lfs.delete(homePath)) {
                System.err.println("error: cannot remove test directory, " 
                        + "some file could be opened without being closed");
            } // if
    }
    
    public ToolContext context() { return context; }
    
    public PrintWriter out() { return out; }
    
    public FileSystem fs() { return fs; }
    
    @Deprecated
    public File root() { return testDir; }
    @Deprecated
    public File input() { return inputDir; }
    @Deprecated
    public File output() { return outputDir; }
    @Deprecated
    public File temp() { return tempDir; }
    
    public Path homePath() { return homePath; }
    public Path inputPath() { return inputPath; }
    public Path outputPath() { return outputPath; }
    public Path tempPath() { return tempPath; }
    
    public void runTool(Class clazz, String s) throws Exception {
        runTool(clazz, s.split("\\s+"), 1);
    }
    
    public void runTool(Class clazz, String [] args) throws Exception {
        runTool(clazz, args, 1);
    }
    
    public void runTool(Class clazz, String [] args, int nWorker
                    ) throws Exception {
        if (AbstractCoWorkTool.class.isAssignableFrom(clazz)) {
            AbstractCoWorkTool tool = 
                (AbstractCoWorkTool) ClassUtils.newInstance(clazz);
            assertTrue("set env failed for tool " + clazz, tool.setEnv(context, 
                    args, out));
            assertTrue("execute tool " + clazz + " failed", tool.exec(nWorker));
        } else if (AbstractLocalTool.class.isAssignableFrom(clazz)) {
            AbstractLocalTool tool = (AbstractLocalTool)ClassUtils.newInstance(
                    clazz);
            assertTrue("set env failed for tool " + clazz, tool.setEnv(context, 
                    out));
            assertTrue("execute tool " + clazz + " failed", tool.exec(args));
        } else if (ITool.class.isAssignableFrom(clazz)) {
            ITool tool = (ITool)ClassUtils.newInstance(clazz);
            assertTrue("execute tool " + clazz + " failed", tool.exec(args));
        } else {
            throw new RuntimeException("bad class : " + clazz);
        }
    }
    
}
