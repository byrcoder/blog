package odis.tools;

import junit.framework.TestCase;

/**
 * Test framework for simple cowork job.
 * The test flow is : (setUp)--createInput--execute--checkOutput--(tearDown), the subclass should 
 * implement createInput(), execute() and checkOutput() methods.
 * Test environment is created at setUp().
 * 
 * @author river
 *
 */
public abstract class ToolTest extends TestCase {
    
    protected TestCaseOdis ctx = null;

    /**
     * Create the test environment.
     */
    public void setUp() throws Exception {
        ctx = new TestCaseOdis();
        ctx.setTestName(this.getClass().getName());
        ctx.setUp();
    }
    
    /**
     * Destroy the test environment, delete the directories.
     */
    public void tearDown() throws Exception {
        ctx.tearDown();
        ctx = null;
    }
    
    public ToolTest withEnv(TestCaseOdis ctx) {
        this.ctx = ctx;
        return this;
    }
    
    /**
     * Pass in the test environment, this method is called when
     * the testcase is used in other testcase.
     * @param ctx
     */
    public void setEnv(TestCaseOdis ctx) {
        this.ctx = ctx;
    }
    
    /**
     * Prepare the input data.
     * @throws Exception
     */
    abstract public void createInput() throws Exception;
    
    protected void runTool(Class clazz, String s) throws Exception {
        ctx.runTool(clazz, s);
    }
    
    protected void runTool(Class clazz, String [] args) throws Exception {
        ctx.runTool(clazz, args);
    }
    
    protected void runTool(Class clazz, String [] args, int nWorker) throws Exception {
        ctx.runTool(clazz, args, nWorker);
    }
    
    /**
     * To be override to initialize something.
     */
    public void init() {
    }
    
    /**
     * Run the task.
     * @throws Exception
     */
    abstract public void execute() throws Exception;
    
    /**
     * Validate the output.
     * @throws Exception
     */
    abstract public void checkOutput() throws Exception;
    
    @SuppressWarnings("deprecation")
    public void runFlow() throws Exception {
        init();
        createInput();
        execute();
        String callCountName = this.getClass().getName() + ".called";
        int callCount = ctx.context.getAppInt(callCountName, 0);
        ctx.context.setAppInt(callCountName, callCount+1);
        checkOutput();
    }
    
    /**
     * 执行整个过程一次并且仅仅一次.
     * @throws Exception
     */
    public void runOnce() throws Exception {
        int callCount = ctx.context.getAppInt(this.getClass().getName() + ".called", 0);
        if (callCount == 0) {
            runFlow();
        }
    }
    
    /**
     * The test flow is here.
     * @throws Exception
     */
    public void test() throws Exception {
        runFlow();
    }
    
}
