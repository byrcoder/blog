/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Jul 28, 2006
 */
package odis.tools.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;

import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.ICollector;
import odis.mapred.IMapper;
import odis.mapred.IReducer;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.lib.BytesWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;
import toolbox.misc.net.InetAddressUtils;

/**
 * Simple demo to generate fake data (modeled after snapshot/summary data), and
 * then use mapreduce to sort. This outputs some performance numbers and thus 
 * can be used as a CoWork/ODFS benchmark.
 *  
 * @author zf
 */
public class SortDemo extends MapReduceDemo implements IMapper<IntWritable, IntWritable>, IReducer<LongWritable, BytesWritable>{
    static final String PER_MAPPER_SIZE_IN_MB = "perMapperSizeInMB";
    static final String INPUT_DIR = "_sort_demo/input";
    static final String OUTPUT_DIR = "_sort_demo/output";
    int mn, rn;
    String localhost, rootDir;
    
    public String comment() {
        return "Sort Benchmark";
    }

    public boolean exec(int nWorker) throws Exception {
        Path rootPath = context.path(rootDir);
        Path inputDir = rootPath.cat(INPUT_DIR);
        Path outputDir = rootPath.cat(OUTPUT_DIR);
        Path tmpDir = rootPath.cat("tmp");
        // 1 - prepare fake input files
        context.getFileSystem().delete(rootPath);       
        for (int i = 0; i < mn; i++) {
            SequenceFile.Writer w = new SequenceFile.Writer(context.getFileSystem(), 
                inputDir.cat(i + ""), IntWritable.class, IntWritable.class);
            w.write(new IntWritable(i), new IntWritable(i));
            w.close();
        }
        
        // 2 - do actual sort        
        long start = System.currentTimeMillis();
        MapReduceJobDef job = context.createMapReduceJob("sort_demo", nWorker);
        
        MapReduceHelper helper = new MapReduceHelper(job, context.getFileSystem(), tmpDir, inputDir);
        helper.addReadInputDir(inputDir, SeqFileInputFormat.class);
        helper.addDirectOutputDir(SortDemo.DEFAULT_OUTPUT_CHANNEL, outputDir, 
                LongWritable.class, BytesWritable.class,
                SeqFileOutputFormat.class);

        job.getConfig().setInt(PER_MAPPER_SIZE_IN_MB, perMapperSizeInMB);        
        
        // mapper & reducer
        job.setMapper(SortDemo.class);
        job.setPerUnitSplit(true);
        job.setMergeKeyValClass(LongWritable.class, BytesWritable.class);
        job.useDefaultHashPartitioner();
        
        job.setReducer(SortDemo.class);
        job.setReduceNumber(rn);
        
        JobResult result = helper.runJob(context.getCoWork());
        
        String[][] msg = (result==null)?null:result.getMsg();
        if (msg!=null) System.out.println(Arrays.deepToString(msg));
        
        long duration = System.currentTimeMillis() - start;
        
        // 3 - generate a gnuplot data file
        // plot with:
        //   plot 'sort_times.txt' index 0 using 1:(($2+$3)/2):2:3 title "Map" with yerrorbars , \
        //        'sort_times.txt' index 1 using ($1+10):(($2+$3)/2):2:3 title "Reduce" with yerrorbars

        long b = Long.MAX_VALUE;
        long totalSize = 0;
        int M = 3;
        long map[][] = new long[mn][M];
        long reduce[][] = new long[rn][M];
        for (int i = 0; i < mn; i++) {
            String[] s = result.getMsg()[0][i].split(" ");
            for (int j = 0; j < M; j++) {
                map[i][j] = Long.parseLong(s[j]);
            }
            if (map[i][0] < b)
                b = map[i][0];
            totalSize += map[i][2];
        }
        for (int i = 0; i < rn; i++) {
            String[] s = result.getMsg()[1][i].split(" ");
            for (int j = 0; j < M; j++)
                reduce[i][j] = Long.parseLong(s[j]);
        }
        PrintWriter pw = new PrintWriter("sort_times.txt");
        pw.println("# Map data: id start(ms) end(ms) bytes host");
        for (int i = 0; i < mn; i++)
            pw.println(i+" "+(map[i][0]-b)+" "+(map[i][1]-b)+" "+map[i][2]+" "
                    +result.getMsg()[0][i].split(" ")[3]);      // last is hostname
        pw.println();
        pw.println();
        pw.println("# Reduce data: id start(ms) end(ms) bytes host");
        for (int i = 0; i < rn; i++)
            pw.println(i+" "+(reduce[i][0]-b)+" "+(reduce[i][1]-b)+" "+reduce[i][2]+" "
                    +result.getMsg()[1][i].split(" ")[3]);      // last is hostname
        pw.close();
        
        System.out.println("Total time: "+duration+"ms");
        System.out.println("Total effective bandwidth "+(totalSize/duration)+"KB/s");
        return result.isSuccess();
    }

    public boolean setEnv(ToolContext env, String[] args, PrintWriter out)
            throws Exception {
        super.setEnv(env, args, out);
        if (args.length != 4) {
            usage(out);
            return false;
        }
        mn = Integer.parseInt(args[0]);
        rn = Integer.parseInt(args[1]);
        perMapperSizeInMB = Integer.parseInt(args[2]);
        rootDir = args[3];
        return true;
    }

    public void usage(PrintWriter out) {
        out.println("sort <map_num> <reduce_num> <per-mapper-data-size-in-MB> <dir>");
        out.println("   each entry is randomly sized 100B - 10K");
    }

    // Mapper
    int perMapperSizeInMB;
    int id;
    public void configure(JobDef conf, TaskRunnable task) {
        perMapperSizeInMB = conf.getConfig().getInt(PER_MAPPER_SIZE_IN_MB);
        id = task.getPartIdx();
    }

    public void map(IntWritable key, IntWritable value, ICollector collector) {
        long start = System.currentTimeMillis();
        long limit = (long)perMapperSizeInMB * 1024 * 1024;
        long size = 0;
        Random r = new Random(id);
        while (size < limit) {
            int c = r.nextInt(10*1024-100)+100;
            BytesWritable bw = new BytesWritable(new byte[c]);
            LongWritable lw = new LongWritable(r.nextLong());
            collector.collect(lw, bw);
            size += c + 8 + 4;
        }
        long end = System.currentTimeMillis();
        long duration = end - start;
        System.out.println("Mapper "+id+" wrote "+size+"B in "+duration+"ms: "
                +(size/duration)+"KB/s");
        try {
            collector.collectDoneMsg(start+" "+end+" "+size+" "+InetAddressUtils.findLocalMachineName());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void reduce(LongWritable key, IWritablePairWalker<LongWritable, BytesWritable> values, ICollector collector) {
        while (values.moreValue()) {
            collector.collectToChannel(DEFAULT_OUTPUT_CHANNEL, key, values.getValue());
            reduceSize += values.getValue().size() + 8 + 4;
        }
    }

    public void mapBegin() {
    }

    public void mapEnd(ICollector collector) {
    }
    long reduceStart;
    long reduceSize;
    public void reduceBegin() {
        reduceStart = System.currentTimeMillis();
        reduceSize = 0;
    }

    public void reduceEnd(ICollector collector) {
        long end = System.currentTimeMillis();
        long duration = end - reduceStart;
        System.out.println("Reducer "+id+" wrote "+reduceSize+"B in "+duration+"ms: "
                +(reduceSize/duration)+" KB/s");
        try {
            collector.collectDoneMsg(reduceStart+" "+end+" "+reduceSize+" "+InetAddressUtils.findLocalMachineName());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // just for misc tests
    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            System.out.println("write      keep writing a big SequenceFile ");
            return;
        }
        if (args[0].equals("write")) {
            FileSystem fs = FileSystem.get();
            SequenceFile.Writer f = new SequenceFile.Writer(fs, new Path("_sort_demo/write_test"), 
                    LongWritable.class, BytesWritable.class);
            Random r = new Random(1);
            while (true) {
                int c = r.nextInt(10*1024-100)+100;
                BytesWritable bw = new BytesWritable(new byte[c]);
                LongWritable lw = new LongWritable(r.nextLong());
                f.write(lw, bw);
            }
        }
    }
}
