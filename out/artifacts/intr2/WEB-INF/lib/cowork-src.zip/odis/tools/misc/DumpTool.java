package odis.tools.misc;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.CoWorkUtils;
import odis.file.SequenceFile;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.Path;
import odis.mapred.BasicPartitioner;
import odis.mapred.lib.LongHashPartitioner;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.serialize.IParsable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.toolkit.LazyWritable;
import odis.tools.AbstractLocalTool;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.GetOpts;

public class DumpTool extends AbstractLocalTool {
    public static final Logger LOG = LogFormatter.getLogger(DumpTool.class);

    public static IWritable[] searchInSortedSequenceFile(FileSystem fs,
            String path, IWritableComparable target) throws IOException {
        SequenceFile.Reader reader = new SequenceFile.Reader(fs,
                new Path(path));
        try {
            return searchInSortedSequenceFile(fs, reader, target);
        } finally {
            reader.close();
        }
    }
    
    public static final long MAX_BINARY_SEARCH_DISTANCE = 30 * 1024 * 1024;

    private static IWritable[] searchSequential(SequenceFile.Reader reader,
            long from, long to, IWritableComparable target) throws IOException {
        IWritableComparable key;
        IWritable value;

        try {
            key = (IWritableComparable) reader.getKeyClass().newInstance();
            value = (IWritable) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new IOException("cannot initialize object");
        }

        List<IWritable> list = new ArrayList<IWritable>();
        reader.seek(from);
        while (reader.getPosition() <= to && reader.next(key, value)) {
            int comp = key.compareTo(target);
            if (comp == 0) {
                list.add(value);
                try {
                    value = (IWritable) reader.getValueClass().newInstance();
                } catch (Exception e) {
                    throw new IOException("cannot initialize object");
                }
            } else if (comp > 0) {
                break;
            }
        }

        return (list.isEmpty() ? null : list.toArray(new IWritable[list.size()]));
    }

    /**
     * 在一个已经按照升序排列的SequenceFile中检索目标，这时可以采用二分查找的办法加速查询.
     * 理论上我们应该尽量保证有序的文件都保存一个索引，不过目前我们还有一部分数据没有索引，所以
     * 这个只是一个权宜的解决方案.
     * 
     * @param nfs
     * @param reader
     * @param target
     * @return the IWritable objects found
     * @throws IOException
     */
    private static IWritable[] searchInSortedSequenceFile(FileSystem nfs,
            SequenceFile.Reader reader, IWritableComparable target)
            throws IOException {

        long lowPos = 0;
        long hiPos = reader.getEnd();
        long midPos;

        IWritableComparable lowKey, hiKey, midKey;
        IWritable lowValue, hiValue, midValue;
        try {
            lowKey = (IWritableComparable) reader.getKeyClass().newInstance();
            midKey = (IWritableComparable) reader.getKeyClass().newInstance();
            hiKey = (IWritableComparable) reader.getKeyClass().newInstance();

            lowValue = (IWritable) reader.getValueClass().newInstance();
            midValue = (IWritable) reader.getValueClass().newInstance();
            hiValue = (IWritable) reader.getValueClass().newInstance();
        } catch (Exception e) {
            throw new IOException("cannot initialize object");
        }

        reader.sync(lowPos);
        lowPos = reader.getPosition();
        reader.next(lowKey, lowValue);

        int comp = lowKey.compareTo(target);
        if (comp == 0) {
            return searchSequential(reader, lowPos, hiPos, target);
        } else if (comp > 0)
            return null;

        while (hiPos - lowPos > MAX_BINARY_SEARCH_DISTANCE) {
            midPos = (lowPos + hiPos) / 2;
            reader.sync(midPos);
            midPos = reader.getPosition();
            reader.next(midKey, midValue);
            comp = midKey.compareTo(target);
            if (comp == 0) {
                long fromPos = midPos - MAX_BINARY_SEARCH_DISTANCE * 10;
                if (fromPos < 0) {
                    fromPos = 0;
                }
                reader.sync(fromPos);
                fromPos = reader.getPos();
                return searchSequential(reader, fromPos, hiPos, target);
            } else if (comp < 0) {
                IWritableComparable tmpKey = lowKey;
                lowKey = midKey;
                midKey = tmpKey;

                IWritable tmpValue = lowValue;
                lowValue = midValue;
                midValue = tmpValue;
                lowPos = midPos;
            } else {
                IWritableComparable tmpKey = hiKey;
                hiKey = midKey;
                midKey = tmpKey;

                IWritable tmpValue = hiValue;
                hiValue = midValue;
                midValue = tmpValue;
                hiPos = midPos;
            }
        }

        return searchSequential(reader, lowPos, hiPos, target);
    }

    private Map<String, String> defaultPartitioners = 
        new HashMap<String, String>();

    private void loadDefaultPartitioners() {
        defaultPartitioners.put("outfox.data.DocID",
                LongHashPartitioner.class.getName());
        defaultPartitioners.put("outfox.data.SiteID",
                LongHashPartitioner.class.getName());
        defaultPartitioners.put("odis.serialize.lib.Url",
                "odis.mapred.lib.UrlMd5Partitioner");
    }

    private void getSequenceFiles(Path file, List<Path> files)
            throws IOException {
        if (!fs.exists(file)) {
            throw new IOException("cannot find file " + file);
        }
        if (fs.isDirectory(file)) {
            if (fs.exists(file.cat("index"))
                    && fs.exists(file.cat("data"))) {
                files.add(file.cat("data"));
            } else {
                FileInfo[] list = fs.listFiles(file);
                for (int i = 0; i < list.length; i++)
                    getSequenceFiles(list[i].getPath(), files);
            }
        } else {
            files.add(file);
        }
    }
    
    private static IWritableComparable parseKey(String keyString,
            Class<?> keyclass) throws IOException {
        try {
            IWritableComparable targetKey = (IWritableComparable) keyclass
                    .newInstance();
            if (targetKey instanceof IParsable) {
                ((IParsable) targetKey).parse(keyString);
            }
            return targetKey;
        } catch (Exception e) {
            throw new IOException("Cannot parse keystring \"" + keyString
                    + "\" as keyclass " + keyclass.getName());
        }
    }

    private void output(Object key, Object val) throws IOException {
        if (outputFile == null)
            return;
        if (writer == null) {
            writer = new SequenceFile.Writer(FileSystem.getNamed("local"),
                    new Path(outputFile), key.getClass(), val.getClass());
        }
        writer.write(key, val);
    }

    private int getPartition(Class<?> keyClass, IWritableComparable key,
            int partitionCount) {
        String classname = partClass;
        if (classname == null) {
            classname = defaultPartitioners.get(keyClass.getName());
            if (classname == null) {
                classname = SeqFileHashPartitioner.class.getName();
            }
        }

        try {
            Class clazz = Class.forName(classname);
            BasicPartitioner partitioner = 
                (BasicPartitioner) clazz.newInstance();
            return partitioner.getPartition(key, null, partitionCount);
        } catch (Exception e) {
            System.err.println("cannot initialize partitioner " + classname);
            throw new RuntimeException(e);
        }
    }
    
    private void saveCorruptData(IWritable key, IWritable value) 
            throws Exception {
        File tmpDir = new File("./corrupt");
        if (!tmpDir.exists()) tmpDir.mkdir();
        File tmpFile = File.createTempFile("corrupt", ".dat", tmpDir);
        SequenceFile.Writer out = new SequenceFile.Writer(
                FileSystem.getNamed("local"), 
                new Path(tmpFile), 
                key.getClass(), 
                value.getClass());
        try {
            out.write(key, value);
        } finally {
            out.close();
        }
        System.err.println("Corrupt object with key " + key + " saved to local " 
                + tmpFile.getAbsolutePath());
    }
    
    // 输入文件的属性
    private FileSystem fs;      // file system
    private String[] paths;     // directories & files
    private String inputSplit;  // split position
    private int from;           // from record
    private int to;             // to record
    private String keyString;   // key to match (in string format)
    private boolean ordered;    // whether the paths are ordered sequence files
    private boolean partitioned;// whether the paths are partitioned directories
    private String partClass;   // partitioner class    
    // 本地输出文件
    private String outputFile;
    // 处理的属性
    private boolean noprint;
    private boolean icheck;

    // 仅仅输出key
    private boolean keyOnly;

    private SequenceFile.Writer writer;

    public void usage(PrintWriter out) {
        out.println("usage: [-fs file_system] [-c] [-out output] [-o] " +
                "[-i] [-e from:count] [-p] [-pc partitioner] " +
                "[-k <key_to_match>] [-sp input_split] path");
        out.println("Dump content in a data directory or file.");
        out.println("Options:");
        out.println(" -fs   Filesystem to be used. Default set in " 
                + "\"app.instance(*).dfs\"");
        out.println(" -k    Match a specific key. Only a couple of key types " 
                + "are supported.");
        out.println("       (The class of the key implements IParsable).");
        out.println(" -out  Local output file. All entries extracted are " 
                + "written to this file.");
        out.println(" -o    Do binary search in sorted sequence file. Effect " 
                + "only when -k used.");
        out.println(" -c    Avoid print found entries to stdout.");
        out.println(" -i    Do data integrity check.");
        out.println(" -e    Extract from a certain record. \"from\" is " 
                + "included.");
        out.println(" -sp   Specific split in input files.");
        out.println(" -p    Regard dir as partitioned dir.");
        out.println("       (Will use partitioner to locate the partition index" 
                + " first)");
        out.println(" -pc   Set the partitioner, used with \"-p\"");
        out.println(" -keyonly Print only the key");
        out.println("The last argument should be the path of file or " 
                + "directory.");
    }

    protected boolean processArgs(String[] args) throws IOException {
        GetOpts opts = new GetOpts("c[out]:oie:k:[sp]:p[pc]:[fs]:[keyonly]", 
                args);
        String fsName = opts.getOpt("fs");
        fs = fsName == null ? context.getFileSystem() : FileSystem.getNamed(
                fsName);

        keyString = opts.getOpt("k");
        outputFile = opts.getOpt("out");
        noprint = opts.hasOption("c");
        icheck = opts.hasOption("i");
        ordered = opts.hasOption("o");
        inputSplit = opts.getOpt("sp");
        partitioned = opts.hasOption("p");
        partClass = opts.getOpt("pc");
        keyOnly = opts.hasOption("keyonly");
        paths = opts.getRemains();

        String temp = opts.getOpt("e");
        from = 0;
        to = Integer.MAX_VALUE;
        if (temp != null) {
            String[] parts = temp.split(":");
            if (parts.length < 1) {
                throw new IOException("bad extract setting " + temp);
            }
            from = Integer.parseInt(parts[0]);
            if (parts.length > 1) {
                to = Integer.parseInt(parts[1]) + from - 1;
            }
        }

        if (icheck)
            noprint = true;
        return true;
    }

    public boolean exec(String args[]) throws Exception {
        loadDefaultPartitioners();
        try {
            processArgs(args);
        } catch (IOException e) {
            LOG.severe("Error in parsing arguments, please check your " 
                    + "filesystem setting and others.");
            usage(out);
            return false;
        }
        if (paths.length == 0) {
            usage(out);
            return false;
        }

        /*
         * Make file-list.
         */
        List<Path> files = new ArrayList<Path>();
        for (int i = 0; i < paths.length; i++) {
            if (partitioned) {
                // add the root path
                files.add(new Path(paths[i]));
            } else {
                // add each individual file
                getSequenceFiles(new Path(paths[i]), files);
            }
        }

        long count = 0;

        for (Path file : files) {

            if (partitioned) {
                // reset file to the correct partition
                int partitionCount = fs.listFiles(file).length;
                if (partitionCount == 0) {
                    LOG.severe("cannot find data in " + file);
                    continue;
                }

                Path partFile = new Path(file, CoWorkUtils.getPartID(0));
                if (fs.isDirectory(partFile)) {
                    partFile = new Path(partFile, "data");
                }
                SequenceFile.Reader probReader = new SequenceFile.Reader(fs,
                        partFile);
                try {
                    Class<?> keyClass = probReader.getKeyClass();
                    IWritableComparable probKey = parseKey(keyString, keyClass);
                    int p = getPartition(keyClass, probKey, partitionCount);
                    file = file.cat(CoWorkUtils.getPartID(p));
                } finally {
                    probReader.close();
                }
            }
            
            if (fs.isDirectory(file)) {
                file = file.cat("data");
            }

            LOG.info("---- Process file " + file + " ----");
            SequenceFile.Reader reader;
            if (inputSplit == null) {
                reader = new SequenceFile.Reader(fs, file);
            } else {
                String[] tmp = inputSplit.split("\\+");
                long startPos = Long.parseLong(tmp[0]);
                long length = Long.parseLong(tmp[1]);
                reader = new SequenceFile.Reader(fs, file, startPos, length);
            }
            Class<?> keyclass = reader.getKeyClass();
            Class<?> valclass = reader.getValueClass();
            LOG.info("(compress_block_size=" + reader.getCompressBlockSize() 
                    + ", -- " + keyclass + " -> " + valclass + "--)");

            IWritableComparable targetKey = null;
            if (keyString != null)
                targetKey = parseKey(keyString, keyclass);

            if (ordered && keyString != null) {
                IWritable[] result = searchInSortedSequenceFile(fs, reader,
                        targetKey);
                if (result != null) {
                    for (IWritable v : result) {
                        output(targetKey, v);
                        if (!noprint)
                            out.println(keyString + " ^ " + v);
                    }
                    break;
                }
            } else {
                IWritable key = (IWritable) keyclass.newInstance();
                IWritable val = (IWritable) valclass.newInstance();

                int index = 0;
                while (true) {
                    try {
                        if (!reader.next(key, val)) break;
                    } catch(Throwable e) {
                        LOG.log(Level.WARNING, "Sequence file reading failed " 
                                + "before " + reader.getPos(), e);
                        LOG.warning("Current state: key = " + key + ", val = " 
                                + val);
                        LOG.warning("NOTE: The above key/val are only helpful " 
                                + "info, they may not be the exact\n" 
                                + "      bad pair because the exception may be" 
                                + " thrown before they were read!");
                        break;
                    }
                    
                    count++; index++;
                    if (index < from) continue;
                    if (index > to) break;
                    if (targetKey != null && !key.equals(targetKey)) continue;

                    if (icheck) {
                        if (val instanceof LazyWritable) {
                            LazyWritable w = (LazyWritable) val;
                            try {
                                w.decode();
                            } catch (Throwable e) {
                                LOG.log(Level.WARNING, "BAD writable entry " 
                                        + "found : key = " + key, e);
                                saveCorruptData(key, val);
                                continue;
                            }
                        }
                    }
                    output(key, val);
                    if (!noprint) {
                        if (keyOnly) {
                            out.println(key);
                        } else {
                            out.println(key + " ^ " + val.toString());
                        }
                    }
                }
            }
        }
        if (writer != null)
            writer.close();
        LOG.info("In total " + count + " entries fetched.");
        return true;
    }
    
    public String comment() {
        return "Dump specified records from a sequence (or index) file";
    }

}
