package odis.tools;

import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * The abstract cowork-tool.
 * 
 * @author xxx
 *
 */
public abstract class AbstractCoWorkTool {

    protected ToolContext context;
    protected PrintWriter out;
    protected int mParallel, rParallel;
    
    /**
     * This method should be override by subclass to process the args.
     * @param args
     * @return
     * @throws Exception
     */
    protected boolean processArgs(String[] args) throws Exception {
        return true;
    }
    
    /**
     * This method should be override by subclass to intialize the tool.
     * @return
     * @throws Exception
     */
    protected boolean initTool() throws Exception {
        return true;
    }
    
    /**
     * Setting the environment.
     * 
     * @param context  the ToolContext instance 
     * @param args  the arguments from the console for this tool
     * @param out  the output PrintWriter
     * @return  true if success, false otherwise
     * @throws Exception  if any error occurs
     */
    public boolean setEnv(ToolContext context, String[] args, PrintWriter out) 
            throws Exception {
        this.context = context;
        this.out = out;
        this.mParallel = 6;
        this.rParallel = 1;
        
        String[] userArgs = processParallel(args);
        
        if (!processArgs(userArgs)) return false;
        if (!initTool()) return false;

        return true;
    }
    
    private String[] processParallel(String[] args) {
        ArrayList<String> userArgs = new ArrayList<String>();
        int i=0;
        while (i<args.length) {
            if ("-mp".equals(args[i])) {
                i++;
                if (i<args.length) mParallel = Integer.parseInt(args[i++]);
            } else if ("-rp".equals(args[i])) {
                i++;
                if (i<args.length) rParallel = Integer.parseInt(args[i++]);
            } else {
                userArgs.add(args[i++]);
            }
        }
        return userArgs.toArray(new String[userArgs.size()]);
    }
    
    /**
     * Executes the tool.
     * @param nWorker  the number of workers
     * @return  true if success, false otherwise.
     * @throws Exception  if any error occurs.
     */
    public abstract boolean exec(int nWorker) throws Exception;
    
    /** explain the usage of this tool and output it to <code>out</code> */
    public abstract void usage(PrintWriter out);
    /** one-lined comments for this tool. */
    public abstract String comment();

}
