/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.tools.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.logging.Logger;

import odis.cowork.CoWorkUtils;
import odis.cowork.GenericJobDef;
import odis.cowork.JobClient;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.file.SequenceFile;
import odis.io.FileSystem;
import odis.io.Path;
import odis.serialize.lib.IntWritable;
import odis.tools.AbstractCoWorkTool;
import odis.tools.ToolContext;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

public abstract class MapReduceDemo extends AbstractCoWorkTool {
    
    private static String LOG_RECORD_NUMBER = "count_stat.log_record_num";
    private static String LOG_DATA_DIR = "count_stat.data_dir";
    private static String LOG_FS = "count_stat.fs";    
    protected static final Logger LOG = LogFormatter.getLogger(MapReduceDemo.class);
    protected boolean generate(String dir, int ln, int fn, int nWorker) throws IOException {
        // clean previous directory
        try {
            context.getFileSystem().delete(new Path(dir));
            context.getFileSystem().mkdirs(new Path(dir));
        } catch (IOException e) {
            out.println("Cannot clean previous directory: " + dir);
            e.printStackTrace(out);
            return false;
        }
        
        GenericJobDef gJobDef = context.createGenericJob("generate", nWorker);
        gJobDef.setTaskClass(GenerateTask.class);
        gJobDef.setTaskNumber(fn);        
        
        gJobDef.getConfig().setInt(LOG_RECORD_NUMBER, ln);
        gJobDef.getConfig().setProperty(LOG_DATA_DIR, dir);
        gJobDef.getConfig().setProperty(LOG_FS, context.getAppFs());        

        JobResult result = JobClient.runJob(context.getCoWork(), gJobDef);
        out.print("Result messages: ");
        out.println(Arrays.deepToString(result.getMsg()));
        
        return result.isSuccess();
    }
    
    public static class GenerateTask extends TaskRunnable {
        
        private static int USER_NUM = 100;
        private static int OP_NUM = 10;
        
        private int ln, count;
        private String dir, fsName;

        @Override
        public void configure(JobDef job, TaskWorker runner) {
            ln = job.getConfig().getInt(LOG_RECORD_NUMBER);
            dir = job.getConfig().getString(LOG_DATA_DIR);
            fsName = job.getConfig().getString(LOG_FS);
            this.worker = runner;
        }

        @Override
        public void run() {
            startTime = System.currentTimeMillis();
            try {
                FileSystem fs = FileSystem.getNamed(fsName);
                fs.mkdirs(new Path(dir));
                Path file = new Path(dir, CoWorkUtils.getPartID(part)); 
                if (fs.exists(file)) fs.delete(file);
                Random rand = new Random(System.currentTimeMillis());
                SequenceFile.Writer out = new SequenceFile.Writer(fs, file,
                        IntWritable.class,IntWritable.class);
                try {
                    IntWritable uid = new IntWritable(), jid = new IntWritable();
                    for (int i=0; i<ln; i++) {
                        uid.set(rand.nextInt(USER_NUM));
                        jid.set(rand.nextInt(OP_NUM));
                        out.write(uid,jid);
                        count = i;
                        progress = i*1f/ln;
                    }
                    progress = 1f;
                    cursor.write(cursor(), time());
                    this.doneMsg = "SUCCESS";
                } finally { out.close(); }
            } catch (IOException e) {                
                throw new RuntimeException(e);
            }
        }
        
        public long cursor() { return count; }        
    }
    
    private static HashMap<String, Class> demos = new HashMap<String, Class>();
    static {
        demos.put("count_stat", CountStatDemo.class);
        demos.put("invert", InvertDemo.class);
        demos.put("sort", SortDemo.class);
        demos.put("maponly", MapOnlyDemo.class);
    }
    
    public static void main(String[] args) throws Exception {
        // arguments
        int nWorker = 1;
        if (args.length<2) { usage(); System.exit(1); }
        if ("-nW".equals(args[0]) && args.length>2)
            nWorker = Integer.parseInt(args[1]);
        else { usage(); System.exit(1); }

        MapReduceDemo demo = 
            (MapReduceDemo) ClassUtils.newInstance(demos.get(args[2]));
        ToolContext env = new ToolContext();;
        String[] newArgs = new String[args.length-3];
        System.arraycopy(args, 3, newArgs, 0, newArgs.length);
        // run
        if (demo.setEnv(env, newArgs, new PrintWriter(System.out,true))) {
            if (!demo.exec(nWorker))
                System.out.println("Demo excution error, exiting.");
        } else System.out.println("Demo environment setting error, exiting.");
    }
    
    private static void usage() {
        System.out.println("Usage: mrdemo -nW <worker-num> ...");
        System.out.println("Available demos:");
        for (String key: demos.keySet()) {
          String comment = key + " tool.";
          comment = ((MapReduceDemo) ClassUtils.newInstance(demos.get(key))).comment();
          System.out.format("     %-" + 4 + "s  %s\n", key, comment);
        }
    }    

}
