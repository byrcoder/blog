package odis.tools;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.rmi.server.UID;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import odis.cowork.CounterMap;
import odis.cowork.JobClient;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskFatalException;
import odis.io.FileInfo;
import odis.io.IFileSystem;
import odis.io.LockStateException;
import odis.io.Path;
import odis.mapred.BasicInputFormat;
import odis.mapred.BasicOutputFormat;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.MD5Writable;
import odis.util.ProcessUtils;
import toolbox.collections.Pair;
import toolbox.misc.LogFormatter;

/**
 * A helper class for map-reduce jobs.
 * 
 * This helper class helps the using cowork job in the following ways:
 *   1) For read only databases, the source directory is first linked to
 *      a temporary directory, and then the job will read the temporary
 *      directroy which will be deleted after execution.
 *   2) For updating databases, which are both the input and output of the job,
 *      the output is firstly redirect to a temporary directory. If the job 
 *      succeeds, the temporary directory replaces the old one. Otherwise the 
 *      original directory remains unchanged. Correct locks are used for these 
 *      directories.
 *   3) Temporary directories will be deleted after running the job.
 *   
 * Usage:
 *   1) Create a helper object.
 *   2) For read-only databases: call *addReadInputDir* to add the path.
 *   3) For output databases: If some of them are also as the input, call 
 *      *addUpdateInputDir* to add it. If this databases contains only one
 *      output directory, call *addUpdateOutputDir* to add it. If some of the
 *      folders under the same parent folder need to be replace as a whole, call
 *      *addUpdateOutputSubDir* to add them. If the directory is neither used
 *      as input, nor need to preserve the integrity, use *addDirectOutputDir*.
 *   4) call *helper.runJob* instead of JobClient.runJob directly to run the 
 *      job. Otherwise the lock requring and replacement wont be performed.
 *     
 *  Sample:
 *     XxxJobDef job = ...;
 *   
 *     MapReduceHelper helper = new MapReduceHelper(job, fs, tmpRoot, insRoot);
 *     
 *     helper.addReadInputDir(new Path("/data/input"), null);
 *     helper.addUpdateOutpuDir(new Path("/data/output"), null);
 *     
 *     JobResult res = helper.runJob(addr);
 *     if (!res.isSuccess())
 *         return false;
 *         
 *     return true;
 *     
 * TODO:
 *   the function check input data
 *     
 * @author David, rivers
 *
 */
public class MapReduceHelper {
    private static Logger LOG = LogFormatter.getLogger(MapReduceHelper.class);
    
    protected JobDef job;
    protected IFileSystem fs;
    protected Path tmpPath;
    protected Path insRoot;
    
    /**
     * Container to hold external filesystem and related temp paths.
     */
    protected HashMap<IFileSystem, Path> externalTempPaths = 
        new HashMap<IFileSystem, Path>();
    
    /**
     * Creates map reduce helper for job.
     * @param context The context to be used to determine temp directory and 
     *        instance root.
     * @param job The job.
     * @throws IOException
     */
    public MapReduceHelper(ToolContext context, JobDef job) throws IOException {
        this(job, context.getFileSystem(), 
                new Path(context.getAppTemp()), 
                new Path(context.getAppRoot()));
    }
    
    /**
     * The constructor.
     * The temp path created by map reduce helper is nearly global unique, 
     * because we include {@link UID} and process id information to generate the 
     * name of temp path. 
     * 
     * @param job  The job-def object.
     * @param fs  The file-system.
     * @param tmpRoot The path to the temporary path.
     * @param insRoot The optional instance path. This parameter is used to 
     *                determine some temporary files' names. If it is specified 
     *                to null, some filenames maybe not debug-friendly.
     * @throws IOException
     */
    public MapReduceHelper(JobDef job, IFileSystem fs, Path tmpRoot, 
            Path insRoot) throws IOException {
        this.job = job;
        this.fs = fs;
        this.insRoot = insRoot;
        this.tmpPath = createTempDir(fs, tmpRoot, job.getJobName());
    }
    
    protected Random rand = new Random();
    
    protected Path genTempDir(IFileSystem fs, Path path) throws IOException {
        String name = path.getName();
        if (insRoot != null && 
                path.toString().length() > insRoot.toString().length()) {
            /*
             * Try make the temprory folder debug-friendly
             */
            if (path.toString().startsWith(insRoot.toString())) {
                Path tmp = path;
                while (tmp != null && 
                        tmp.toString().length() > insRoot.toString().length()) {
                    tmp = tmp.getParentFile();
                } // while
                if (insRoot.equals(tmp)) {
                    name = path.toString().substring(
                            insRoot.toString().length());
                } // if
            } // if
        } // else
        
        String idx; 
        do {
            idx = "." + Integer.toHexString(rand.nextInt());
        } while (fs.exists(tmpPath.cat(name + idx)));
        
        return tmpPath.cat(name + idx);
    }
    protected Path genTempDir(Path path) throws IOException {
        return genTempDir(this.fs, path);
    }    
    
    /**
     * Locks the folder and links it.
     * 
     * Read {@link IFileSystem#link} for more comments.
     * 
     * NOTE: locking before linking is essential since otherwise an empty folder 
     *       could be linked.
     * 
     * @param src  the source path
     * @param dst  the destination to be linked to
     * @return  true if success, false otherwise
     * @throws IOException  if an I/O error occurs
     */
    protected boolean lockLink(IFileSystem fs, Path src, Path dst) 
            throws IOException {
        fs.getLock(src, IFileSystem.SHARED_LOCK);
        try {
            return fs.link(src, dst);
        } finally {
            fs.releaseLock(src);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    // Input Directory for Read Only (will not be touched during the job)    //
    ///////////////////////////////////////////////////////////////////////////
    
    /**
     * Links the specified dir to temporary folder.
     * 
     * @param dir  the folder to be linked to
     * @return  the linked path
     * @throws IOException  if an I/O error occurs
     */
    public Path linkInputPath(Path dir) throws IOException {
        Path linkedPath = genTempDir(dir);
        if (linkedPath.getParentFile() != null)
            fs.mkdirs(linkedPath.getParentFile());
        if (!lockLink(fs, dir, linkedPath)) {
            throw new IOException("Cannot link source directory " + dir + 
                    " to " + linkedPath);
        } // if
        
        return linkedPath;
    }

    /**
     * Add an input directory only for reading. This folder will be linked to a
     * temporary folder and the job will read from the linked folder. If the 
     * input directory does not exist or is empty, it is not added to the job. 
     * Use return value to know whether this folder has been linked and added.
     *
     * NOTE: job must be an instance of MapOnlyJobDef (or its subclass, e.g. 
     *       MapReduceJobDef).
     *
     * @param dir  The input directory.
     * @param format  The input format for the speicified input data. NULL for 
     *                default input-format(see 
     *                {@link MapOnlyJobDef#addInputDir(Path)}).
     * @return  The path to the linked path. Null if the specified directory 
     *          does not exists or contains no files.
     * @throws IOException  if an I/O error occurs
     */
    public Path addReadInputDir(Path dir, 
            Class<? extends BasicInputFormat> format) throws IOException {
        if (!fs.exists(dir) || fs.listFiles(dir).length == 0) {
            return null;
        } // if

        Path linkedPath = linkInputPath(dir);
        if (format ==  null)
            ((MapOnlyJobDef) job).addInputDir(linkedPath);
        else
            ((MapOnlyJobDef) job).addInputDir(linkedPath, format);

        return linkedPath;
    }
    
    /**
     * Add an input directory only for reading. This folder will be linked to a
     * temporary folder and the job will read from the linked folder. If the 
     * input directory does not exist or is empty, it is not added to the job. 
     * Use return value to know whether this folder has been linked and added.
     *
     * NOTE: job must be an instance of MrStarJobDef (or its subclass).
     *
     * @param dir  The input directory.
     * @param format  The input format for the speicified input data. NULL for 
     *                default inputformat.
     * @return  The path to the linked path. Null if the specified directory 
     *          does not exists or contains no files.
     * @throws IOException
     */
    public Path addReadInputDir(int phase, Path dir, 
            Class<? extends BasicInputFormat> format) throws IOException {
        if (!fs.exists(dir) || fs.listFiles(dir).length == 0) {
            return null;
        } // if

        Path linkedPath = linkInputPath(dir);

        if (format ==  null)
            ((MrStarJobDef) job).addInputDir(phase, linkedPath);
        else
            ((MrStarJobDef) job).addInputDir(phase, linkedPath, format);

        return linkedPath;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    // Output Directory for Direct Output (Override if it is existing)       //
    ///////////////////////////////////////////////////////////////////////////

    /**
     * Add a direct output directory. The folder will be cleared before 
     * executing.
     * 
     * NOTE: job must be an instance of MapOnlyJobDef (or its subclass, e.g. 
     *       MapReduceJobDef).
     * 
     * @param channel  The output channel number.
     * @param dir  The output directory.
     * @param key  The class of the key.
     * @param value  The class of the value.
     * @param format The output format. NULL for default outputformat.
     * @throws IOException
     */
    public void addDirectOutputDir(int channel, Path dir, 
            Class<? extends IWritableComparable> key, 
            Class<? extends IWritable> value, 
            Class<? extends BasicOutputFormat> format) throws IOException {
        clearDir(fs, dir);
        if (format == null)
            ((MapOnlyJobDef) job).addOutputDir(channel, dir, key, value);
        else
            ((MapOnlyJobDef) job).addOutputDir(channel, dir, key, value, 
                    format);
    }
    /**
     * Add a direct output directory. The folder will be cleared before 
     * executing.
     * 
     * NOTE: job must be an instance of MrStarJobDef (or its subclass).
     * 
     * @param mrPhase  The phase of the output task. 
     * @param channel  The output channel number.
     * @param dir  The output directory.
     * @param key  The class of the key.
     * @param value  The class of the value.
     * @param format The output format. NULL for default outputformat.
     * @throws IOException
     */
    public void addDirectOutputDir(int mrPhase, int channel, Path dir, 
            Class<? extends IWritableComparable> key, 
            Class<? extends IWritable> value, 
            Class<? extends BasicOutputFormat> format) throws IOException {
        clearDir(fs, dir);
        if (format == null)
            ((MrStarJobDef) job).addOutputDir(mrPhase, channel, dir, key, 
                    value);
        else
            ((MrStarJobDef) job).addOutputDir(mrPhase, channel, dir, key, value, 
                    format);
    }
    
    ///////////////////////////////////////////////////////////////////////////
    // Directory (currently existing) to be updated at the end of job        //
    ///////////////////////////////////////////////////////////////////////////

    // dst <--> tmp
    protected TreeMap<Path, Path> replacePairs = new TreeMap<Path, Path>();
    
    /**
     * Directories to be shared-locked during job execution.
     */
    protected List<Path> readonlyDirs = new LinkedList<Path>();
    
    /**
     * Set for shared-locked directories to avoid duplicate directory
     * in {@link #readonlyDirs}.
     */
    protected HashSet<Path> readonlyDirSet = new HashSet<Path>();
    
    /**
     * The input directories to be validated before job execution.
     */
    protected HashSet<Pair<IFileSystem, Path>> inputDirToValidate = 
        new HashSet<Pair<IFileSystem, Path>>();
    
    /**
     * Creates an empty output directory for updating. It will be replaced
     * if the job is successfully executed.
     * 
     * @param dir the destination path.
     * @return The directory created.
     * @throws IOException
     */
    public Path createUpdateRawOutputDir(Path dir) throws IOException {
        Path tmpUpdateDir = genTempDir(dir);
        replacePairs.put(dir, tmpUpdateDir);
        
        clearDir(fs, tmpUpdateDir);
        return tmpUpdateDir;
    }
    /**
     * Creates an empty output sub-directory for update. It will be replaced
     * if the job is successfully executed.
     * 
     * @param parent  the parent of the destination path
     * @param sub  the sub name of the destination path
     * @return  the created directory
     * @throws IOException  if an I/O error occurs
     */
    public Path createUpdateRawOutputSubDir(Path parent, String sub) 
            throws IOException {
        Path tmp = replacePairs.get(parent);
        if (tmp == null) {
            tmp = genTempDir(parent);
            replacePairs.put(parent, tmp);
            clearDir(fs, tmp);
        } // if
        return tmp.cat(sub);
    }
    /**
     * Adds a directory for updating. Since the updating directory cannot be 
     * changed during the job, it is directly added to the input-dir of the job, 
     * if it exists and is non-empty. 
     * 
     * NOTE: job must be an instance of MapOnlyJobDef (or its subclass, e.g. 
     *       MapReduceJobDef).
     * 
     * @param dir  The input directory.
     * @param format  The input-format for the input data.
     * @return Whether this input directory is added.
     * @throws IOException
     */
    public boolean addUpdateInputDir(Path dir, 
            Class<? extends BasicInputFormat> format) throws IOException {
        if (!fs.exists(dir) || fs.listFiles(dir).length == 0) {
            return false;
        } // if
        
        if (format == null)
            ((MapOnlyJobDef) job).addInputDir(dir);
        else
            ((MapOnlyJobDef) job).addInputDir(dir, format);
        
        return true;
    }
    
    /**
     * Adds a directory for updating. Since the updating directory cannot be 
     * changed during the job, it is directly added to the input-dir of the job, 
     * if it exists and is non-empty. 
     * 
     * NOTE: job must be an instance of MrStarJobDef (or its subclass).
     * 
     * @param mrPhase  The phase of the input task.
     * @param dir  The input directory.
     * @param format  The input-format of the input data. NULL for default 
     *                inputformat.
     * @return Whether this input directory is added.
     * @throws IOException
     */
    public boolean addUpdateInputDir(int mrPhase, Path dir, 
            Class<? extends BasicInputFormat> format) throws IOException {
        if (!fs.exists(dir) || fs.listFiles(dir).length == 0) {
            return false;
        } // if
        
        if (format == null)
            ((MrStarJobDef) job).addInputDir(mrPhase, dir);
        else
            ((MrStarJobDef) job).addInputDir(mrPhase, dir, format);
        
        return true;
    }
    
    /**
     * Adds an updating output directory. For preventing the original data in 
     * case the task is failed, a temporary folder will be added to the job. 
     * After the job is successfuly executed, the temporary folder will replace 
     * the destination folder safely.
     * 
     * NOTE: job must be an instance of MapOnlyJobDef (or its subclass, e.g. 
     *       MapReduceJobDef).
     * 
     * @param channel  The output channel number.
     * @param dir  The output directory.
     * @param key  The class of the key.
     * @param value  The class of the value.
     * @param format The output format. NULL for default outputformat.
     * @return  the path to the temporary folder
     * @throws IOException
     */
    public Path addUpdateOutputDir(int channel, Path dir, 
            Class<? extends IWritableComparable> key, Class<? extends IWritable> value,
            Class<? extends BasicOutputFormat> format) throws IOException {
        Path tmpDir = createUpdateRawOutputDir(dir);
        if (format ==  null)
            ((MapOnlyJobDef) job).addOutputDir(channel, tmpDir, key, value);
        else
            ((MapOnlyJobDef) job).addOutputDir(channel, tmpDir, key, value, 
                    format);
        
        return tmpDir;
    }
    
    /**
     * Adds an updating output directory. For preventing the original data in 
     * case the task is failed, a temporary folder will be added to the job. 
     * After the job is successfuly executed, the temporary folder will replace 
     * the destination folder safely.
     * 
     * NOTE: job must be an instance of MrStarJobDef (or its subclass).
     * 
     * @param mrPhase  The phase of the output directory.
     * @param channel  The output channel number.
     * @param dir  The output directory.
     * @param key  The class of the key.
     * @param value  The class of the value.
     * @param format The output format. NULL for default outputformat.
     * @return  the path to the temporary folder
     * @throws IOException
     */
    public Path addUpdateOutputDir(int mrPhase, int channel, Path dir, 
            Class<? extends IWritableComparable> key, Class<? extends IWritable> value,
            Class<? extends BasicOutputFormat> format) throws IOException {
        Path tmpDir = createUpdateRawOutputDir(dir);
        if (format ==  null)
            ((MrStarJobDef) job).addOutputDir(mrPhase, channel, tmpDir, key, 
                    value);
        else
            ((MrStarJobDef) job).addOutputDir(mrPhase, channel, tmpDir, key, 
                    value, format);
        
        return tmpDir;
    }
    
    /**
     * Adds a sub-directory of an updating directory. The whole parent directory
     * will be generated at a temporary folder, and be replaced with that 
     * temoporary folder as a WHOLE if the job is sucessfuly executed.
     * 
     * NOTE: job must be an instance of MapOnlyJobDef (or its subclass).
     * 
     * @param mrPhase  The phase of the output directory.
     * @param channel  The output channel number.
     * @param parent  The parent directory (or the root of the updating 
     *                directory).
     * @param sub  The sub directory name.
     * @param key  The class of the key.
     * @param value  The class of the value.
     * @param format The output format. NULL for default outputformat.
     * @return  the path to the temporary sub-folder
     * @throws IOException
     */
    public Path addUpdateOutputSubDir(int channel, Path parent, String sub, 
            Class<? extends IWritableComparable> key, 
            Class<? extends IWritable> value, 
            Class<? extends BasicOutputFormat> format) throws IOException {
    
        Path replaceTmp = replacePairs.get(parent);
        if (replaceTmp == null) {
            replaceTmp = genTempDir(parent);
            replacePairs.put(parent, replaceTmp);
            clearDir(fs, replaceTmp);
        }
        Path tmpSubir = replaceTmp.cat(sub);

        if (format == null)
            ((MapOnlyJobDef) job).addOutputDir(channel, tmpSubir, key, value);
        else
            ((MapOnlyJobDef) job).addOutputDir(channel, tmpSubir, key, value, 
                    format);
        
        return tmpSubir;
    }
    
    /**
     * Adds a sub-directory of an updating directory. The whole parent directory
     * will be generated at a temporary folder, and be replaced with that 
     * temoporary folder as a whole if the job is sucessfuly executed.
     * 
     * NOTE: job must be an instance of MrStarJobDef (or its subclass).
     * 
     * @param mrPhase  The phase of the output directory.
     * @param channel  The output channel number.
     * @param parent  The parent directory (or the root of the updating 
     *                directory).
     * @param sub  The sub directory name.
     * @param key  The class of the key.
     * @param value  The class of the value.
     * @param format The output format. NULL for default outputformat.
     * @return  the path to the temporary sub-folder
     * @throws IOException
     */
    public Path addUpdateOutputSubDir(int mrPhase, int channel, Path parent, 
            String sub, Class<? extends IWritableComparable> key, 
            Class<? extends IWritable> value, 
            Class<? extends BasicOutputFormat> format) throws IOException {
    
        Path replaceTmp = replacePairs.get(parent);
        if (replaceTmp==null) {
            replaceTmp = genTempDir(parent);
            replacePairs.put(parent, replaceTmp);
            clearDir(fs, replaceTmp);
        }
        Path tmpSub = replaceTmp.cat(sub);

        if (format == null)
            ((MrStarJobDef) job).addOutputDir(mrPhase, channel, tmpSub, key, 
                    value);
        else
            ((MrStarJobDef) job).addOutputDir(mrPhase, channel, tmpSub, key, 
                    value, format);
        
        return tmpSub;
    }

    /**
     * Run the job and return the result. All updating directory will be locked 
     * and replaced if the job is successfuly executed.
     * 
     * @param jmAddr The address to the jobmaster.
     * @param afterRunJob The functions to be invoked after job execution and 
     *                    before directory replacement
     * @return The job-result returned from JobClient.runJob().
     * @throws IOException
     * @throws LockStateException
     */
    public JobResult runJob(InetSocketAddress jmAddr) throws IOException, 
            LockStateException {
        try {
            return runJob(jmAddr, new Function[0]);
        } catch(FuncExecutionException e) {
            // This exception should not be thown here
            throw new RuntimeException(e);
        }
    }
    
    /**
     * Run the job and return the result. All updating directory will be locked 
     * and replaced if the job is successfuly executed.
     * 
     * @param jmAddr The address to the jobmaster.
     * @param afterRunJob The functions to be invoked after job execution and 
     *                    before directory replacement
     * @return The job-result returned from JobClient.runJob().
     * @throws IOException
     * @throws LockStateException
     */
    public JobResult runJob(InetSocketAddress jmAddr, Function ... afterRunJob) 
    throws IOException, LockStateException, FuncExecutionException {
        return runJob(jmAddr, true, afterRunJob);
    }
    
    /**
     * Run the job and return the result. All updating directory will be locked 
     * and replaced if the job is successfuly executed.
     * 
     * @param jmAddr
     * @param checkOutput whether check output is continuous
     * @param afterRunJob
     * @return
     * @throws IOException
     * @throws LockStateException
     * @throws FuncExecutionException
     */
    public JobResult runJob(InetSocketAddress jmAddr, boolean checkOutput,
            Function... afterRunJob) throws IOException, LockStateException,
            FuncExecutionException {
        try {
            for (Path path : readonlyDirs) {
                fs.getLock(path, IFileSystem.SHARED_LOCK);
            }
            for (Path path: replacePairs.keySet()) {
                fs.getLock(path, IFileSystem.UPDATE_LOCK);
            }
            for (Pair<IFileSystem, Path> entry : inputDirToValidate) {
                validateInput(entry.getFirst(), entry.getSecond());
            }
            
            try {
                JobResult res = JobClient.runJob(jmAddr, job);
                if (res!=null && res.isSuccess()) {
                    
                    // invoke functions
                    for (Function func : afterRunJob) {
                        try {
                            func.jobResult = res;
                            func.fs = fs;
                            func.execute();
                        } catch(Exception e) {
                            throw new FuncExecutionException("function failed : ", e);
                        }
                    }
                    
                    // Replace updating dirs.
                    for (Map.Entry<Path, Path> entry: replacePairs.entrySet()) {
                        if (entry.getValue() == null) continue;
                        
                        fs.promoteLock(entry.getKey());
                        if (checkOutput) {
                            validateOutput(fs, entry.getValue(), job);
                        }
                        replace(fs, entry.getKey(), entry.getValue());
                    }
                } // if
                return res;
            } finally {
                for (Path path: replacePairs.keySet()) {
                    fs.releaseLock(path);
                }
                for (Path path : readonlyDirs) {
                    fs.releaseLock(path);
                }
            }
        } finally {
            ToDelete.delete(fs, this.tmpPath);
            for (Map.Entry<IFileSystem, Path> entry : externalTempPaths.entrySet()) {
                ToDelete.delete(entry.getKey(), entry.getValue());
            }
        }
    }
    
    /**
     * Return the part number in directory dir.
     * @param dir
     * @return
     * @throws IOException
     */
    public int getPartNumber(Path dir) throws IOException {
        return getContinuousPartCount(fs, dir);
    }
    
    /**
     * Validate if the given dir is valid db directory for read. 
     * One valid input directory should be : 
     * <ul>
     * <li>directory must exists
     * <li>directory should contains sub directory
     * <li>part number in sub directory should be continuous
     * </ul>
     * @param dir
     * @throws IOException
     */
    protected void validateInput(IFileSystem fs, Path dir) throws IOException {
        if (!fs.exists(dir)) throw new IOException("input directory " + dir 
                + " does not exist");
        if (getContinuousPartCount(fs, dir) == 0) {
            throw new IOException("input directory " + dir + " is empty");
        }
    }
    
    /**
     * check output is continuous. only do check when job is MapOnlyJob or MapReduceJob
     * @param fs
     * @param dir
     * @param job
     * @throws IOException
     */
    protected void validateOutput(IFileSystem fs, Path dir, JobDef job) 
        throws IOException {
        if (job instanceof MapReduceJobDef || job instanceof MapOnlyJobDef) {
            if (!fs.exists(dir)) {
                throw new IOException(dir + " not exists");
            }
            
            FileInfo [] infos = fs.listFiles(dir);
            if (infos.length > 0 && infos[0].getPath().getName().matches("part\\-(\\d+)")) {
                if (getContinuousPartCount(fs, dir) == 0)
                    throw new IOException(dir + " is empty");
            }
        }
    }
    
    /**
     * Link the dir to temp directory and return the linked path. 
     * This job do care if the original input data could be changed by others 
     * when executing.
     *  
     * @param path
     * @return
     */
    public Path getReadInput(Path dir) throws IOException {
        Path input = linkInputPath(dir);
        inputDirToValidate.add(new Pair<IFileSystem, Path>(fs, input));
        return input;
    }
    
    /**
     * Link the dir on specified filesystem to temp directory which is created
     * on the same filesystem as the input dir, and return the linked path.
     *  
     * @param fs
     * @param dir
     * @return
     * @throws IOException
     */
    public Path getReadInput(IFileSystem fs, Path dir) throws IOException {
        if (fs == this.fs) {
            return getReadInput(dir);
        }
        
        Path tempRoot = externalTempPaths.get(fs);
        if (tempRoot == null) {
            tempRoot = createTempDir(fs, new Path("/external-temp"), 
                    job.getJobName());
            externalTempPaths.put(fs, tempRoot);
        }
        fs.mkdirs(tempRoot);
        
        String name = dir.getName();
        Path tempDir = tempRoot.cat(name + "." + createUniqueMd5());
        
        if (!lockLink(fs, dir, tempDir)) {
            throw new IOException("Cannot link source directory " + dir + 
                    " to " + tempDir);
        }
        
        inputDirToValidate.add(new Pair<IFileSystem, Path>(fs, tempDir));
        return tempDir;
    }
    
    /**
     * Return the original dir, and save the input dir in shared-lock-dir list
     * which should be shared-locked before job execution.
     *  
     * @param dir
     * @return
     * @throws IOException
     */
    public Path getSharedInput(Path dir) throws IOException {
        if (replacePairs.containsKey(dir)) {
            throw new IOException("dir " + dir + " is update input previously");
        }
        if (!readonlyDirSet.contains(dir)) {
            readonlyDirs.add(dir);
            readonlyDirSet.add(dir);
        }
        inputDirToValidate.add(new Pair<IFileSystem, Path>(fs, dir));
        
        return dir;
    }
    
    /**
     * Return the dir directory, and save the input dir in list which should be
     * update locked before job execution.
     * 
     * @param dir
     * @return
     * @throws IOException
     */
    public Path getUpdateInput(Path dir) throws IOException {
        if (readonlyDirs.contains(dir)) {
            throw new IOException("dir " + dir + " is read input previously");
        }
        
        if (!replacePairs.containsKey(dir)) {
            replacePairs.put(dir, null);
        }
        inputDirToValidate.add(new Pair<IFileSystem, Path>(fs, dir));
        
        return dir;
    }

    /**
     * Clear the output directory and return it directly.
     * @param dir
     * @return
     * @throws IOException
     */
    public Path getDirectOutput(Path dir) throws IOException {
        clearDir(fs, dir);
        return dir;
    }
    
    /**
     * Return one new created output directory under temp root, 
     * which is named as "output.$UID". The directory should be 
     * deleted automatically after {@link #runJob(InetSocketAddress)}
     * called.
     * 
     * This method is the same to call {@link #getTempOutput(String)}
     * with "output" as param.
     * 
     * @see #getTempOutput(String)
     * 
     * @return The new created and cleaned directory
     * @throws IOException
     */
    public Path getTempOutput() throws IOException {
        return getTempOutput("output");
    }
    
    /**
     * Return one new created output directory under temp root,
     * which is named as "$prefix.$UID". The directory should be
     * deleted automatically after {@link #runJob(InetSocketAddress)}
     * called.
     * 
     * @param prefix Prefix of new created directory
     * @return The new created and cleaned directory
     * @throws IOException
     */
    public Path getTempOutput(String prefix) throws IOException {
        String uid = new UID().toString() + "_" + ProcessUtils.getPid();
        Path tmpPath = this.tmpPath.cat(prefix + "." 
                + MD5Writable.digest(uid).toString());
        clearDir(fs, tmpPath);
        return tmpPath;
    }
    
    /**
     * Return temp directory created under temp root. The original dir should be 
     * saved in replace pairs which should be update-locked before job execution
     * and replaced by temp directory if job succeeded. 
     * 
     * @param dir
     * @return
     * @throws IOException
     */
    public Path getUpdateOutput(Path dir) throws IOException {
        if (readonlyDirs.contains(dir)) {
            throw new IOException("dir " + dir + " is read input previously");
        }
        if (replacePairs.containsKey(dir) && replacePairs.get(dir) != null) {
            throw new IOException("dir " + dir + " is updated twice");
        }
        
        Path tmpUpdateDir = genTempDir(dir);
        replacePairs.put(dir, tmpUpdateDir);
        clearDir(fs, tmpUpdateDir);
        
        return tmpUpdateDir;
    }

    /**
     * Print the counter map with title of job name.
     * @see #printCounters(PrintWriter, String, CounterMap[])
     * @param writer
     * @param counterMap
     * @throws IOException
     */
    public void printCounters(PrintWriter writer, CounterMap [] counterMap) 
            throws IOException {
        printCounters(writer, job.getJobName() + " counters", counterMap);
    }
    
    /**
     * Print the messages with title of job name.
     * @see #printCounters(PrintWriter, String, CounterMap[])
     * @param writer
     * @param messages
     * @throws IOException
     */
    public void printMessages(PrintWriter writer, String [][] messages) 
            throws IOException {
        printMessages(writer, job.getJobName() + " messages", messages);
    }
    
    /**
     * Clear speicified dir under specified file-system. After calling to this 
     * method, the destination folder is created without any contents.
     * 
     * @param fs  the file-system instance
     * @param dir  the directory to be cleared
     * @throws IOException  if an I/O error occurs
     */
    public static void clearDir(IFileSystem fs, Path dir) throws IOException {
        try {
            FileInfo[] files = fs.listFiles(dir);
            if (files != null) {
                for (FileInfo file: files)
                    if (!fs.delete(file.getPath()))
                        throw new IOException("Can't delete " + file.getPath() + "!");
            } // if
        } catch (IOException e) {
            // ignored
        }
        
        if (!fs.exists(dir)) fs.mkdirs(dir);
    }
    
    /**
     * Create a directory as temp directory, which should be cleaned before 
     * used and deleted after used.
     * @param fs
     * @param path
     * @return the file passed in
     * @throws IOException
     */
    protected static Path internalCreateTempDir(IFileSystem fs, Path path) throws IOException {
        if (fs.exists(path) && !fs.delete(path)) {
            throw new IOException("cannot clean temp directory " + path);
        }
        fs.mkdirs(path);
        ToDelete.toDelete(fs, path);
        return path;
    }

    /**
     * Create one unique md5 string.
     * @return
     */
    private static String createUniqueMd5() {
        String uid = new UID().toString() + "_" + ProcessUtils.getPid() 
                    + "_" + Thread.currentThread().getId();
        return MD5Writable.digest(uid).toString();
    }
    
    /**
     * Creates a temperary directory with given prefix and one unique suffix. 
     * The new created directory should be cleaned before returned, and it 
     * should be deleted when the tool complete. Refer to 
     * {@link ToDelete#toDelete(IFileSystem, Path)} for more information on 
     * auto-delete directories.
     * 
     * @param fs
     * @param prefix
     * @return
     * @throws IOException
     */
    public static Path createTempDir(IFileSystem fs, Path tempRoot, String prefix) throws IOException {
        Path tmpPath = tempRoot.cat(prefix + "." + createUniqueMd5());
        internalCreateTempDir(fs, tmpPath);
        return tmpPath;
    }
    
    /**
     * Create a directory as temp directory, which should be cleaned before 
     * used and deleted after used.
     * @deprecated Use {@link MapReduceHelper} instance instead of static methods or
     * use {@link #createTempDir(IFileSystem, String)} to create unique temp directory.
     * 
     * @param fs
     * @param path
     * @return the file passed in
     * @throws IOException
     */
    public static Path createTempDir(IFileSystem fs, Path path) throws IOException {
        if (fs.exists(path) && !fs.delete(path)) {
            throw new IOException("cannot clean temp directory " + path);
        }
        fs.mkdirs(path);
        ToDelete.toDelete(fs, path);
        return path;
    }
    
    /**
     * Make sure the input dir exists.
     * @deprecated Use {@link MapReduceHelper#getInput(Path)} instead.
     * 
     * @param fs
     * @param input
     * @return
     * @throws IOException
     */
    public static Path getInputDir(IFileSystem fs, Path input) throws IOException {
        if (!fs.exists(input)) {
            throw new IOException("cannot find input directory " + input);
        }
        return input;
    }
    
    /**
     * If the output directory exists, remove it before returned.
     * @deprecated Use {@link MapReduceHelper#getDirectOutput(Path)} instead.
     * @param fs
     * @param output
     * @return
     * @throws IOException
     */
    public static Path getOutputDir(IFileSystem fs, Path output) throws IOException {
        if (fs.exists(output) && !fs.delete(output)) {
            throw new IOException("cannot clean output directory " + output);
        }
        return output;
    }

    /**
     * NOTE: add an EXCLUSIVE_LOCK on target before calling this method
     * 
     * @param fs
     * @param target
     * @param newPath
     * @throws IOException
     */
    public static void replace(IFileSystem fs, Path target, Path newPath) 
            throws IOException {
        replace(fs, target, newPath, new Path(newPath.getPath()+".replaced_old"), false);
    }
    
    /**
     * Replaces the contents of path with newFile in an atomic action. 
     * The action is taken in the following order: 
     *   1) delete newfile.replaced_old 
     *   2) ren path newfile.replaced_old 
     *   3) ren newfile path 
     *   4) delete newfile.replaced_old
     * 
     * @param fs  the file-system
     * @param target  the folder for data storing
     * @param newpath  the folder containing the new contents
     * @throws IOException
     */
    public static void replace(IFileSystem fs, Path target, Path newPath, 
            Path tmpPath, boolean keepTmp) throws IOException {
        if (!fs.exists(newPath))
            throw new IOException("cannot find new file " + newPath);

        if (fs.exists(tmpPath) && !fs.delete(tmpPath))
            throw new IOException("cannot remove tmp file " + tmpPath
                    + " during replace");

        // create the parent directory for target
        if (target.getParentFile() != null && !fs.exists(
                target.getParentFile())) {
            fs.mkdirs(target.getParentFile());
        }
        
        boolean restore = fs.exists(target);

        if (fs.exists(target) && !fs.rename(target, tmpPath))
            throw new IOException("cannot rename old file " + target
                    + " to tmp file " + tmpPath);

        if (!fs.rename(newPath, target))
            if (restore) {
                LOG.warning("Cannot rename new file " + newPath  + " to file " 
                        + target +", restoring the old one from " + tmpPath);
                if (!fs.rename(tmpPath, target))
                    throw new IOException("Cannot restore " + target + " from " 
                            + tmpPath);
            } else throw new IOException("Cannot rename new file " + newPath
                    + " to file " + target);

        if (!keepTmp)
            if (fs.exists(tmpPath) && !fs.delete(tmpPath))
                throw new IOException("cannot clean tmp file after replace " 
                        + "finished");
    }
    /**
     * Returns the number of parts in a directory 
     * @param fs  the file-system
     * @param dir  the directory
     * @return the number of parts in a directory
     * @throws IOException  if an I/O error occurs
     */
    public static int getContinuousPartCount(IFileSystem fs, Path dir)
            throws IOException {
        return getPartCount(fs, dir, "part\\-(\\d+)", true);
    }
    /**
     * Returns the number of parts in a directory 
     * @param fs  the file-system
     * @param dir  the directory
     * @param pattern  the pattern
     * @return the number of parts in a directory
     * @throws IOException  if an I/O error occurs
     */
    public static int getContinuousPartCount(IFileSystem fs, Path dir, 
            String pattern) throws IOException {
        return getPartCount(fs, dir, pattern, true);
    }
    /**
     * Returns the number of parts in a directory 
     * @param fs  the file-system
     * @param dir  the directory
     * @return the number of parts in a directory
     * @throws IOException  if an I/O error occurs
     */
    public static int getPartCount(IFileSystem fs, Path dir) 
            throws IOException {
        return getPartCount(fs, dir, "part\\-(\\d+)", false);
    }
    /**
     * Returns the number of parts in a directory 
     * @param fs  the file-system
     * @param dir  the directory
     * @param pattern  the pattern
     * @return the number of parts in a directory
     * @throws IOException  if an I/O error occurs
     */
    public static int getPartCount(IFileSystem fs, Path dir, String pattern) 
            throws IOException {
        return getPartCount(fs, dir, pattern, false);
    }
    
    /**
     * Link a directory that contains continuous parts 
     * @param fs  The file system
     * @param src  The src directory to be linked
     * @param link  The directory that links to the source directory
     * @return  number of continuous parts linked in the directory
     * @throws IOException
     */
    public static int linkContinuousParts(IFileSystem fs, Path src, Path link) 
            throws IOException {
        if (!fs.exists(src)) {
            throw new IOException("cannot find source directory " + src);
        }
        int partitionNumber = getContinuousPartCount(fs, src);
        if (partitionNumber <= 0) {
            throw new IOException("cannot find data in source directory " 
                    + src);
        }
        Path linkParent = new Path(link.getParent());
        if (!fs.exists(linkParent)) {
            fs.mkdirs(linkParent);
        }
        if (!fs.link(src, link)) {
            throw new IOException("cannot link source directory " + src + " to " 
                    + "directory " + link);
        }
        int newPartitionNumber = getContinuousPartCount(fs, link);
        if (newPartitionNumber != partitionNumber) {
            throw new IOException("link failed : data mismatch");
        }
        return partitionNumber;
    }
    
    public static Path linkInput(IFileSystem fs, Path src, Path link) 
            throws IOException {
        linkContinuousParts(fs, src, link);
        return link;
    }

    /**
     * Get number of parts (matches a pattern) number in a directory 
     * @param fs  The file system
     * @param dir  The directory to be checked
     * @param pattern  The pattern to be matched
     * @param checkContinuous  Whether to check the part numbers are continuous
     * @throws IOException
     */
    protected static int getPartCount(IFileSystem fs, Path dir,
            String pattern, boolean checkContinuous) throws IOException {
        if (!fs.exists(dir)) return 0;

        FileInfo[] files = fs.listFiles(dir);
        if (files == null || files.length == 0) return 0;
        
        HashMap<Integer, Path> partMap = new HashMap<Integer, Path>();
        
        int max = -1;
        Pattern pat = Pattern.compile(pattern);
        for (int i = 0; i < files.length; i++) {
            String name = files[i].getPath().getName();
            if (fs.isDirectory(files[i].getPath()) && 
                    fs.listFiles(files[i].getPath()).length == 0)
                continue;  // empty directory

            Matcher matcher = pat.matcher(name);
            if (matcher.matches()) {
                String seqString = matcher.group(1);
                int seq = Integer.parseInt(seqString);
                partMap.put(seq, files[i].getPath());
                if (seq > max) max = seq;
            }
        }
        if (max < 0) return 0;

        if (!checkContinuous) return partMap.size();
        for (int i = 0; i <= max; i++) {
            if (!partMap.containsKey(i))
                throw new IOException("non-continuous: cannot find part " + i);
        }
        return max + 1;
    }
    
    /**
     * 返回第一个大于当前目录中所有数字文件名都大的数字. 
     * @param fs  The file system
     * @param dir  The directory to be checked
     * @return  The next number larger than all dir numbers in the directory
     * @throws IOException
     * @deprecated Use Segments class in odis-app to handle segment dir
     */
    public static int getNextDirNumber(IFileSystem fs, Path dir) 
            throws IOException {
        FileInfo[] files = fs.listFiles(dir);
        if (files == null || files.length == 0) return 0; // empty file
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < files.length; i++) {
            String name = files[i].getPath().getName();
            if (name.matches("\\d+")) {
                int value = Integer.parseInt(name);
                if (value > max) max = value;
            }
        }
        if (max == Integer.MIN_VALUE) return 0;
        else return max + 1;
    }
    
    /**
     * No comment, so DO NOT use it.
     * @deprecated Use Segments class in odis-app to handle segment dir
     */
    public static Path getNextOrderedDir(IFileSystem fs, Path dir) 
            throws IOException {
        int next = getNextDirNumber(fs, dir);
        return new Path(dir, next+"");
    }
    
    /**
     * No comment, so DO NOT use it.
     * @deprecated Use Segments class in odis-app to handle segment dir
     */
    public static Path[] getNextOrderedDirs(IFileSystem fs, Path dir, int num) 
            throws IOException {
        int next = getNextDirNumber(fs,dir);
        Path[] dirs = new Path[num];
        for (int i = next; i < next+num; i++)
            dirs[i] = new Path(dir, i+"");
        return dirs;
    }
    
    /**
     * No comment, so DO NOT use it.
     * @deprecated Use Segments class in odis-app to handle segment dir
     */
    public static Path createNextOrderedDir(IFileSystem fs, Path dir) 
            throws IOException {
        Path next = getNextOrderedDir(fs, dir);
        fs.mkdirs(next);
        return next;
    }
    
    /**
     * No comment, so DO NOT use it.
     * @deprecated Use Segments class in odis-app to handle segment dir.
     */
    public static Path[] createNextOrderedDirs(IFileSystem fs, Path dir, int num)
            throws IOException {
        Path[] next = getNextOrderedDirs(fs, dir, num);
        for (int i=0; i<next.length; i++)
            fs.mkdirs(next[i]);
        return next;
    }
    
    /**
     * Print the messages returned in job result.
     * @param out
     * @param title the title of message, which to be printed in first line
     * @param msgs msg list
     */
    public static void printMessages(PrintWriter out, String title, String [] msgs) {
        out.println(title);
        for (int index = 0; index < msgs.length; index++) {
            if (msgs[index] != null && msgs[index].length() > 0) {
                out.println(String.format("[%4d] %s", index, msgs[index]));
            }
        }
    }
    /**
     * Print the messages returned in job result.
     * @param out
     * @param title The title of message, which to be printed in first line
     * @param msgs msg list
     */
    public static void printMessages(PrintWriter out, String title, String [][] msgs) {
        out.println(title);
        for (int stage = 0; stage < msgs.length; stage ++) {
            boolean stageTitlePrinted = false;
            for (int index = 0; index < msgs[stage].length; index++) {
                if (msgs[stage][index] != null && msgs[stage][index].length() > 0) {
                    if (!stageTitlePrinted) {
                        out.println("-== Stage " + stage + " ==-");
                        stageTitlePrinted = true;
                    }
                    out.println(String.format("[%4d] %s", index, msgs[stage][index]));
                }
            }
        }
    }
    /**
     * Print the counters returned in job result.
     * @param out
     * @param title The title of message, which to be printed in first line
     * @param map The counter map of one stage.
     */
    public static void printCounters(PrintWriter out, String title, CounterMap map) {
        out.println(title);
        for (Map.Entry<String, CounterMap.Counter> entry : map.entrySet()) {
            out.println("\t" + entry.getKey() + " = " + entry.getValue());
        }
    }
    /**
     * Print the counters returned in job result.
     * @param out
     * @param title The title of message, which to be printed in first line
     * @param maps The counter maps of all the stages.
     */
    public static void printCounters(PrintWriter out, String title, CounterMap[] maps) {
        out.println(title);
        int index = 0;
        for (CounterMap map : maps) {
            out.println("Stage " + (index++) + ":");
            for (Map.Entry<String, CounterMap.Counter> entry : map.entrySet()) {
                out.println("\t" + entry.getKey() + " = " + entry.getValue());
            }
        }
    }
    
    /**
     * Safely copies local folder to remote. Use this method when you are going 
     * to make some local data and copy it to destination remote file-system. 
     * This method can avoid the problem caused by backup tasks.
     * 
     * This method does the following things:
     *   1) lock the destination folder
     *   
     *   2) if destination existed, throw an exception to fail the current task.
     *      (some other backup task had copy their result to the destination
     *      folder)
     *      
     *   3) otherwise copy from local to destination. If any error occurs during
     *      copying, try delete the destination folder (fail the job if deletion
     *      is failed), and fail the current task
     * 
     * @param src  the source path at local
     * @param dstFs  the file-system of the destination
     * @param dst  the path to the destination at <dstFs>
     * @throws IOException  if an I/O exception occurs 
     */
    public static void syncCopyFromLocal(File src, IFileSystem dstFs, 
            Path dst) throws IOException {
        System.out.println("Copying from " + src + "@local to " + dst + "@" 
                + dstFs + " ...");
        dstFs.getLock(dst, IFileSystem.EXCLUSIVE_LOCK);
        try {
            if (!dstFs.exists(dst)) {
                try {
                    dstFs.copyFromLocalFile(src, dst);
                } catch (Throwable e) {
                    if (!dstFs.delete(dst))
                        throw new TaskFatalException("Can't delete " + dst + "@" 
                                + dstFs, e);
                    if (e instanceof IOException)
                        throw (IOException) e;
                    throw new RuntimeException("Exception when copy from " + src 
                            + "@local to " + dst + "@" + dstFs, e);
                }
            } else {
                /*
                 * If indexDir exists, fail this task, let another task to 
                 * succeed.
                 */
                throw new IOException(dst + "@" + dstFs + " already " +
                		"exists!");
            }
        } finally {
            dstFs.releaseLock(dst);
        }
        System.out.println("Copied from " + src + "@local to " + dst + "@" 
                + dstFs+ " successfuly!");
    }
    
    /**
     * Function to be invoked by {@link MapReduceHelper#runJob(InetSocketAddress)}.
     * To Create one function :
     * <code>
     *     Function func = new Function(param1, param2) {
     *         public void execute() {
     *             ...
     *         }
     *     };
     * </code>
     * The file system instance and job result shoule also be able to be accessed in function.
     * 
     * @author river
     *
     */
    public static abstract class Function {
        protected Object [] params;
        protected JobResult jobResult;
        protected IFileSystem fs;
        
        /**
         * Create one function without params.
         */
        public Function() {
            params = new Object[0];
        }
        /**
         * Create one function with given params. The params
         * passed in can be accessed in {@link #execute()}.
         * @param objs
         */
        public Function(Object ... objs) {
            params = objs;
        }
        
        /**
         * The actural execution to be invoked later.
         */
        public abstract void execute() throws Exception;
        
    }
    
    /**
     * Exception to be thrown when function execution failed.
     *
     * @author river
     *
     */
    public static class FuncExecutionException extends Exception {

        private static final long serialVersionUID = -5583807607844563900L;

        public FuncExecutionException() {}
        
        public FuncExecutionException(String message, Throwable cause) {
            super(message, cause);
        }
        
        public FuncExecutionException(Throwable cause) {
            super(cause);
        }
        
    }
    
}
