/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.tools.demo;

import java.io.PrintWriter;
import java.util.Arrays;

import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.io.Path;
import odis.mapred.ICollector;
import odis.mapred.IMapper;
import odis.mapred.MRConfig;
import odis.mapred.MapReduceJobDef;
import odis.mapred.lib.CountReducer;
import odis.mapred.lib.IdentityMapper;
import odis.mapred.lib.IntSumReducer;
import odis.mapred.lib.SeqFileHashPartitioner;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.lib.IntWritable;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;

/**
 * This class demonstrates how to use MapReduce programming model
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu)
 *
 */

public class CountStatDemo extends MapReduceDemo {
        
    protected String cmd;
    protected Path inDir, outDir, tmpDir;
    protected int ln, fn;
    protected int mn, rn;    
    
    protected float nextStageStartThreshold = 0.2f;
    protected float boostFactor = 4.0f;
    
    protected long maxReduceMem = -1;
    
    Class combinerClass;
    
    public CountStatDemo() {

    }
    public String comment() {        
        return "Use MapReduce to count number of entries for each key";
    }

    public void setCombinerClass(Class cl) {
        this.combinerClass = cl;
    }
    
    public void setMaxReduceMem(long m) {
        this.maxReduceMem = m;
    }
    
    public boolean exec(int nWorker) throws Exception {

        if ("generate".equals(cmd))
            return generate(inDir.getPath(), ln,fn, nWorker);
        else if (!"run".equals(cmd)) {
            usage(out);
            throw new IllegalArgumentException("Wrong arguments input.");
        }
        MapReduceJobDef job = context.createMapReduceJob("count_stat", nWorker);
        if (maxReduceMem > 0) job.getConfig().setProperty(MRConfig.REDUCE_MEMORY_TOTAL_BYTES, maxReduceMem);
        
        MapReduceHelper helper = new MapReduceHelper(job, context.getFileSystem(), tmpDir, inDir); 
        helper.addReadInputDir(inDir, SeqFileInputFormat.class);
        helper.addDirectOutputDir(CountReducer.DEFAULT_OUTPUT_CHANNEL, 
            outDir, IntWritable.class, IntWritable.class,
            SeqFileOutputFormat.class);        
        
        // mapper/merge/reducer
        job.setMapper(CountMap.class);
        job.setPartitionerClass(SeqFileHashPartitioner.class);
        job.setMergeKeyValClass(IntWritable.class, IntWritable.class);        
        job.setReducer(IntSumReducer.class);
        job.setTaskHeapSize(200);
        job.setMapOutBufferSize(0, 4 * 1024 *1024);
        if (combinerClass != null) {
            job.setCombinerClass(combinerClass);
        }
        
        // map/reduce number
        job.setMapNumber(mn); job.setReduceNumber(rn);
        
        // run job
        JobResult result = helper.runJob(context.getCoWork());
        
        LOG.info("Counter Stats:");
        if (result.isSuccess()) {
            LOG.info(Arrays.toString(result.getCounters()));
        }
        return result.isSuccess();

    }

    public boolean setEnv(ToolContext env, String[] args, PrintWriter out) throws Exception {
        super.setEnv(env, args, out);
        if (args.length<=0) { usage(out); return false; }
        if ("generate".equals(args[0]) && args.length==6 ) {
            if (!args[1].equals("-ln") || !args[3].equals("-fn")) {
                usage(out);
                throw new IllegalArgumentException("Wrong arguments input.");                
            }
            cmd = args[0];
            ln = Integer.parseInt(args[2]);
            fn = Integer.parseInt(args[4]);
            inDir = new Path(args[5]);
        } else if ("run".equals(args[0]) && args.length>=7) {
            if (!args[1].equals("-mn") || !args[3].equals("-rn")) {
                usage(out);
                throw new IllegalArgumentException("Wrong arguments input.");                
            }
            cmd = args[0];
            mn = Integer.parseInt(args[2]);
            rn = Integer.parseInt(args[4]);
            inDir = new Path(args[5]);            
            outDir = new Path(args[6]).cat("db");
            tmpDir = new Path(args[6]).cat("tmp");
            if(args.length > 7)
                nextStageStartThreshold = Float.parseFloat(args[7]);
            if(args.length > 8)
                boostFactor = Float.parseFloat(args[8]);
        } else { usage(out); return false; }
        this.out = out;
        return true;
    }

    public void usage(PrintWriter out) {
        out.println("Usage: count_stat <cmd-and-parameters>");
        out.println("  1. generate -ln <log-record-num> -fn <file-num> <data-dir>");
        out.println("     generate experimental data at <data-dir>");
        out.println("  2. run -mn <map-num> -rn <reduce-num> <data-dir> <out-dir>");
        out.println("     run the demo using data at <data-dir>");
    }
    
    
    public static class CountMap implements  IMapper {

        @Override
        public void configure(JobDef job, TaskRunnable task) {
        }

        @Override
        public void mapBegin() {
        }

        private IntWritable count = new IntWritable(1);
        
        @Override
        public void map(Object key, Object value, ICollector collector) {
            collector.collect(key, count);
        }

        @Override
        public void mapEnd(ICollector collector) {
        }
        
    }
}
