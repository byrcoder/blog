/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.tools.demo;

import java.io.PrintWriter;

import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.io.Path;
import odis.mapred.ICollector;
import odis.mapred.IMapper;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.lib.SeqFileInputFormat;
import odis.mapred.lib.SeqFileOutputFormat;
import odis.serialize.lib.FloatWritable;
import odis.serialize.lib.IntWritable;
import odis.tools.MapReduceHelper;
import odis.tools.ToolContext;


/**
 * This demo shows how to use a MapOnlyJobDef and MapOnlyTasks
 * 
 * The demo mapper will do two things:
 *  1). compute 1/value and output (key,1/value) to directory DIR_INV;
 *  2). compute value^2 and output (key,value^2) to directory DIR_SQR.
 * 
 * @author zl
 *
 */

public class MapOnlyDemo extends MapReduceDemo {

  private static int INDEX_DIR_INV = 0;
  private static int INDEX_DIR_SQR = 1;
  
  public static class DemoMapper implements IMapper {

    public void configure(JobDef conf, TaskRunnable task) { }
    
    public void mapBegin() {}

    public void map(Object key, Object value, ICollector collector) {
      IntWritable iKey = (IntWritable) key;
      IntWritable iVal = (IntWritable) value;
      assert iKey.get()==iVal.get();  // just for demo
      collector.collectToChannel(INDEX_DIR_INV, iKey, new FloatWritable(1f/iVal.get()));
      collector.collectToChannel(INDEX_DIR_SQR, iKey, new IntWritable(iVal.get()*iVal.get()));
    }

    public void mapEnd(ICollector collector) { }
    
  }

  private int partNum;
  private Path inDir, outDir, tmpDir;

  public void usage(PrintWriter out) {
    out.println("Usage: maponly [...] <part-num> <input-dir> <output-dir>");
  }

  public boolean setEnv(ToolContext env, String[] args, PrintWriter out) throws Exception {    
    if (args.length!=3) {
      usage(out); return false;
    }
    super.setEnv(env, args, out);
    this.partNum = Integer.parseInt(args[0]);
    this.inDir = new Path(args[1]);
    this.outDir = new Path(args[2]).cat("db");    
    this.tmpDir = new Path(args[2]).cat("tmp");
    return true;
  }

  public boolean exec(int nWorker) throws Exception {
    MapOnlyJobDef job = context.createMapOnlyJob("maponly-demo", nWorker);
        
    MapReduceHelper helper = new MapReduceHelper(job, context.getFileSystem(), tmpDir, inDir);
    helper.addReadInputDir(inDir, SeqFileInputFormat.class);
    helper.addDirectOutputDir(INDEX_DIR_INV, outDir.cat("inv"), 
        IntWritable.class, FloatWritable.class,
        SeqFileOutputFormat.class);
    helper.addDirectOutputDir(INDEX_DIR_SQR, outDir.cat("sqr"),
        IntWritable.class, IntWritable.class,
        SeqFileOutputFormat.class);    
    
    // splitter, mapper
    job.setMapper(DemoMapper.class);
    job.setMapNumber(partNum);
    job.setTaskHeapSize(200);
    // run job
    JobResult result = helper.runJob(context.getCoWork());
    if (result==null) return false;        
    return result.isSuccess();
  }

  public String comment() {
    return "A demo to use a MapOnlyJobDef and MapOnlyTasks";
  }

}
