/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.tools.demo;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.cowork.GenericJobDef;
import odis.cowork.JobClient;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.cowork.TaskWorker;
import odis.tools.AbstractCoWorkTool;
import odis.tools.ToolContext;
import toolbox.misc.LogFormatter;


/**
 * This is the demo to show how to run GenericTask
 * 
 * <p>CounterDemo: Create a job which count N times
 *  1). Devide the job into t tasks each count N/t times;
 *  2). Assign w workers and m machines to this job.
 * 
 * <p>CounterDemo.UnreliableCounterTask: tasks in the job
 *  - Each count N/t times
 * 
 * @author zl
 *
 */
public class CounterDemo extends AbstractCoWorkTool {
  
  private static final Logger LOG = LogFormatter.getLogger(CounterDemo.class);
  
  public CounterDemo() {
      this.isExclusive = false;
  }
  
  private boolean isExclusive;
  public CounterDemo(boolean b) {
      this.isExclusive = b;
  }
  
  public static class UnreliableCounterTask extends TaskRunnable {

    private static final Random r = new Random();

    private int count;  
    private double failProb;  
    private int countMax;
    private long waitInterval;    
    
    @Override
    public void run() {
      startTime = System.currentTimeMillis();
      while (count<countMax) { 
        try {
          Thread.sleep(waitInterval);
        } catch (InterruptedException e) {
          LOG.finest("Thread.sleep() expection in CountTaskDemo.run()");
        }
        if (r.nextDouble()<failProb)
          throw new RuntimeException("Intended exception for testing.");
          //throw new odis.cowork.TaskFatalException("Intended exception for testing.");
        count++;
        progress = (float)count/(float)countMax;
        cursor.write(cursor(), time());
        getCounter("Haha").inc();
      }
      progress = 1f;
      this.doneMsg = "counter-demo-message" + this.stage +"." + this.part;
    }
    
    public long cursor() { return count; }
  
    @Override
    public void configure(JobDef job, TaskWorker worker) {
      this.worker = worker;
      countMax = job.getConfig().getInt("counterdemo.count_num",100);
      waitInterval = job.getConfig().getLong("counterdemo.wait_interval",100);
      failProb = job.getConfig().getDouble("counterdemo.fail_prop",0.0);
      LOG.info("Count every " + waitInterval + "ms (failProp=" + failProb 
          + ") for " + countMax + " times.");
      count = 0;
    }

  }
  
  int nCount; double fail; long wait; int nTask;
  
  public boolean setEnv(ToolContext env, String[] args, PrintWriter out) 
      throws Exception {
    if (args.length!=4) { usage(out); System.exit(1); }
    super.setEnv(env, args, out);
    nCount = Integer.parseInt(args[0]);
    fail = Double.parseDouble(args[1]);
    wait = Long.parseLong(args[2]);
    nTask = Integer.parseInt(args[3]);
    
    return true;
  }

  public boolean exec(int nWorker) {
    try {
      GenericJobDef gJobDef = context.createGenericJob("counter", nWorker);
      gJobDef.setTaskClass(UnreliableCounterTask.class);
      gJobDef.setTaskHeapSize(200);
      gJobDef.setTaskNumber(nTask);
      if (isExclusive)
         gJobDef.setTaskPerMachine(0, 1);
      
      gJobDef.getConfig().setInt("counterdemo.count_num", nCount/nTask);
      gJobDef.getConfig().setLong("counterdemo.wait_interval", wait);
      gJobDef.getConfig().setDouble("counterdemo.fail_prop", fail);

      JobResult result = JobClient.runJob(context.getCoWork(), gJobDef);
      LOG.info("Result messages:");
      LOG.info(Arrays.deepToString(result.getMsg()));
      return result.isSuccess();
    } catch (Exception e) {
      LOG.log(Level.WARNING, "Caught exception in JobClient.runJob()", e);
      return false;
    }
  }

  public void usage(PrintWriter out) {
    out.println("CounterDemo count# fail-prob wait-interval task#");
  }

  public String comment() {
    return "the demo to show how to run GenericTask";
  }

}
