package odis.tools;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.logging.Logger;

import odis.conf.OdisLibConfig;
import odis.cowork.TaskRunnable;
import odis.dfs.client.DistributedFileSystem;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import toolbox.misc.LogFormatter;

/**
 * Usage:
 * if your local dir is /disk2/outback/black-url, and it have a subfile url-0001 
 * Sync Files: 
 *      DistributedFileCache cache = getFileCache("outback-your-namespace");
 *      cache.syncFromLocal(new File(/disk2/outback/black-url));
 *      
 * After your file sync to cache, your file only identity is file.getName(),
 *  
 * Download Files: 
 *      cache.copyToLocal(black-url, task); //recommend 
 * or: 
 *      cache.copyToLocal(black-url, new File(/diskx/your-local-dir));
 * 
 * Access Files:
 *      File myfile = cache.getCacheFile("black-url/url-001", task);
 *      or
 *      File myfile = cache.getCacheFile("black-url/url-001", new File(/diskx/your-local-dir));
 * 
 * 
 * @author tuqc
 *
 */
public class DistributedFileCache {
    protected static final Logger LOG = LogFormatter.getLogger(DistributedFileCache.class);
    public static final String CONF_FILECACHE_ROOT= "odis.file-cache.root";
    private static final String CONF_FILECACHE_FS = "odis.file-cache.fs";
    public static final String CONF_FILECACHE_REPLICA = "odis.file-cache.replica-num";
    
    private static final String DEFAULT_CACHE_ROOT = "/infra/file-cache";
    public static final String DEFAULT_CACHE_FS = "tiger:6080";
    
     
   public static DistributedFileCache getFileCache(String namespace) throws IOException{
       return getFileCache(OdisLibConfig.conf().getString(CONF_FILECACHE_FS, DEFAULT_CACHE_FS), namespace);
   }
   
   public static DistributedFileCache getFileCache(String fsName, String namespace) throws IOException{
       return new DistributedFileCache(FileSystem.getNamed(fsName), namespace);       
   }
   
   final FileSystem fs;
   final Path pathSpace;
   int cacheReplica; //default
   
   protected DistributedFileCache(FileSystem fs, String namespace) {
       pathSpace = new Path(OdisLibConfig.conf().getString(CONF_FILECACHE_ROOT, DEFAULT_CACHE_ROOT), namespace);
       this.fs = fs;
       cacheReplica = OdisLibConfig.conf().getInt(CONF_FILECACHE_REPLICA, 8);
   }
   
   public void setCacheReplica(int replica) {
       if (replica < 1 || replica > 32) {
           throw new RuntimeException("replica should >= 1 and <=32");
       }
       this.cacheReplica = replica;
   }
   
   /**
    * it will call syncFromLocal(localFile, true, null)
    * @param localFile
    * @throws IOException
    */
   public void syncFromLocal(File localFile) throws IOException {
       syncFromLocal(localFile, true, null);
   }
   
   public void syncFromLocal(File localFile, boolean recursive) throws IOException {
       syncFromLocal(localFile, recursive, null);
   }
   
   /**
    * the function will sync the localFile with the cache file
    * 
    * After your file sync to cache, your file identity is file.getName(), 
    * and the subfile identity is file.getName()/sub-file-name
    * 
    * if the cachefile.lastModifiedTime > localFile.lastModified(), nothing will do
    * 
    * if localFile is directory and recursive=false, it will not sync the sub-directory  
    * 
    * use {@link #copyToLocal(String, TaskRunnable)} and {@link #copyToLocal(String, File)} to download file
    *  
    * After download, use {@link #getCacheFile(String, TaskRunnable)}
    * 
    * example: 
    * if your local dir is /disk2/outback/black-url, and it have a subfile url-0001
    * 
    * syncFromLocal(new File(/disk2/outback/black-url));
    * 
    * download: 
    * copyToLocal(black-url, task); //recommend 
    * or: 
    * copyToLocal(black-url, new File(/diskx/your-local-dir));
    * 
    * Access:
    * getCacheFile("black-url/url-001", task);
    * getCacheFile("black-url/url-001", new File(/diskx/your-local-dir));
    * 
    * @param cacheId
    * @param localFile  file can be directory
    * @param recursive
    * @param filter
    * @throws IOException
    */
   public void syncFromLocal(File localFile, boolean recursive, FilenameFilter filter) throws IOException{
       if (!localFile.exists()) {
           throw new IOException("File " + localFile + " not exisit.");
       }
       Path destFile = getCacheFileFullPath(localFile.getName());       
       
       if (!localFile.isDirectory()) { // file
           copyFromLocalFile(destFile, localFile);
           return;
       } else {
           //dir
           if (fs.exists(destFile)) {
               if (!fs.isDirectory(destFile)) {
                   LOG.info("Delete " + fs.getName() + ":"+ destFile);
                   fs.delete(destFile);
               }
           }
           fs.mkdirs(destFile);           
           copyFromLocalDir(destFile, localFile, recursive, filter);           
       }
       
       if (fs instanceof DistributedFileSystem) {
           LOG.info("Set replication num " + cacheReplica);
           ((DistributedFileSystem)fs).setReplicationNumber(destFile.getAbsolutePath(), (byte)cacheReplica, true);
       }
   }
   
   protected void copyFromLocalDir(Path destDir, File localDir, boolean recursive, FilenameFilter filter) throws IOException {
       File[] subFiles = localDir.listFiles(filter);
       for (File subFile : subFiles) {
           Path destFile = new Path(destDir, subFile.getName());
           if (subFile.isDirectory()) {
               if (!recursive) continue;
               
               if (!fs.exists(destFile)) {
                   fs.mkdirs(destFile);
               }else {
                   if (!fs.isDirectory(destFile)) {
                       fs.delete(destFile);
                       fs.mkdirs(destFile);
                   }
               }
               assert fs.isDirectory(destFile);
               copyFromLocalDir(destFile, subFile, recursive, filter);                   
           } else { // not derectory
               copyFromLocalFile(destFile, subFile);
           }
           
       }//end of for       
   }
   
   protected void copyFromLocalFile(Path destFile, File localFile) throws IOException {       
       if (fs.exists(destFile)) {
           if (fs.isDirectory(destFile)) throw new IOException("Dest file " + destFile + " is exist and is a directory.");                      
           if (fs.lastModified(destFile) < localFile.lastModified()) {
               LOG.info("Delete " + destFile + " because of out of date.");                   
               fs.delete(destFile);
               LOG.info("Copy " + localFile + " to " + destFile);
               fs.copyFromLocalFile(localFile, destFile);
           } else {
               LOG.fine("Ignore " + localFile);
           }
       }else {
           LOG.info("Copy " + localFile + " to " + destFile);
           fs.copyFromLocalFile(localFile, destFile);
       }       
   }
   
   protected static final String CACHE_LOCAL_DIR = "file-cache";
   
   /**
    * it will download the file use task's local dir
    * the file will be deleted after the task finished
    * @param filename
    * @param task
    * @throws IOException
    */
   public void copyToLocal(String filename, TaskRunnable task) throws IOException {
       copyToLocal(filename, new File(task.getWorker().getLocalDir(), CACHE_LOCAL_DIR));
   }
         
   public void copyToLocal(String filename, File localDir) throws IOException {
       if (!localDir.exists()) localDir.mkdirs();
       Path srcPath = getCacheFileFullPath(filename);
       File destFile = new File(localDir, filename);
       LOG.info("Get " + srcPath + " to " + destFile);
       fs.copyToLocalFile(srcPath, destFile);
   }

   /**
    * for example, if to add /disk2/dir/subdir to file cache,
    * you want to read a file in subdir, you should use getCacheFile("subdir/a", task); 
    * 
    * @param fileRelativePath  
    * @param task
    * @return
    */
   public File getCacheFile(String fileRelativePath, TaskRunnable task) {
       File localCache = new File(task.getWorker().getLocalDir(), CACHE_LOCAL_DIR);
       localCache.mkdirs();
       return new File(localCache, fileRelativePath);
   }
   
   public File getCacheFile(String fileRelativePath, File localDir) {
       localDir.mkdirs();
       return new File(localDir, fileRelativePath);
   }
   
   /**
    * it will delete all file in namespace
    * @throws IOException
    */
   public void deleteAllFile() throws IOException {
       
   }
   
   public boolean existFileCache(String cacheId) throws IOException{      
       return fs.exists(getCacheFileFullPath(cacheId));
   }
   
   public boolean removeFileCache(String cacheId) throws IOException{
       Path cacheFile = getCacheFileFullPath(cacheId);
       LOG.info("Delete cache file " + fs.getName() + ":" + cacheFile);
       return fs.delete(cacheFile);
   }   
   
   protected Path getCacheFileFullPath(String filename) {
       return new Path(pathSpace, filename);
   }
}
