/*
 * Copyright (c) 2005-2006, Outfox Team.
 *
 * Created on Mar 15, 2006
 */
package odis.tools.demo;

import java.io.PrintWriter;

import odis.cowork.JobClient;
import odis.cowork.JobDef;
import odis.cowork.JobResult;
import odis.cowork.TaskRunnable;
import odis.io.Path;
import odis.mapred.BasicMerger;
import odis.mapred.ICollector;
import odis.mapred.IMapper;
import odis.mapred.IReducer;
import odis.mapred.IWritablePairWalker;
import odis.mapred.MrStarJobDef;
import odis.mapred.lib.IdentityMapper;
import odis.mapred.lib.IdentityReducer;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.lib.LongWritable;
import odis.serialize.lib.MD5Writable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.toolkit.GenericWritable;
import odis.tools.AbstractCoWorkTool;
import odis.tools.ToolContext;

public class MrStarDemo extends AbstractCoWorkTool {
  
  private static int OUTPUT_DIR_SITE = 0;
  private static int OUTPUT_DIR_URL = 0;
  
  public static class Container extends GenericWritable {
    protected Class[] getTypes() {
      return new Class[] {UTF8Writable.class, LongWritable.class};
    }
  }
  
  public static class SiteMR implements IMapper, IReducer {

    // notice that the following three methods are shared by mapper and reducer
    public void configure(JobDef conf, TaskRunnable task) { }
    public void mapBegin() { }
    public void mapEnd(ICollector collector) { }
    public void reduceBegin() { }
    public void reduceEnd(ICollector collector) { }

    Container box = new Container();
    LongWritable siteId = new LongWritable();
    
    public void map(Object key, Object value, ICollector collector) {
      LongWritable urlId = (LongWritable) key;
      UTF8Writable url = (UTF8Writable) value;
      siteId.set(MD5Writable.digest(url).halfDigest());
      box.set(url,0); collector.collect(siteId, box);
      box.set(urlId,1); collector.collect(siteId,box);
    }

    public void reduce(Object key, IWritablePairWalker values, ICollector collector) {
      IWritable url=null; IWritableComparable urlId=null;
      while (values.moreValue()) {
        Container c = (Container) values.getValue();
        if (c.get() instanceof UTF8Writable) {
          url = c.get();
          collector.collectToChannel(OUTPUT_DIR_SITE,key,url);  // collect to output
        } else if (c.get() instanceof LongWritable) {
          urlId = (IWritableComparable)c.get();
        }
      }
      collector.collect(urlId,url);  // collect to next map
    }

  }  

  private int nMap, nMr, nReduce;
  private Path[] input, output;

  public void usage(PrintWriter out) {
    out.println("MrStarDemo <map-num> <mr-num> <reduce-num>" +
            " <input-dir1> <input-dir2> <output-dir1> <output-dir2>");
  }

  public String comment() {
    return "This demo shows how to use MrStarJobDef using an example similar to update tool";
  }

  public boolean setEnv(ToolContext env, String[] args, PrintWriter out)
      throws Exception {    
    if (args.length!=7) { usage(out); return false; }
    
    super.setEnv(env, args, out);
    nMap = Integer.parseInt(args[0]);
    nMr = Integer.parseInt(args[1]);
    nReduce = Integer.parseInt(args[2]);
    input = new Path[2]; output = new Path[2];
    input[0] = new Path(args[3]);  input[1] = new Path(args[4]);
    output[0] = new Path(args[5]); output[1] = new Path(args[6]);    
    
    return true;
  }

  /**
   *            .                 MR1   (url-id, url)
   *             .                            |
   *              .                           V
   *  MR2          .                (site-id, url/url-id)
   *  (url-id,url)  .                      /  |
   *        |     ,--.----(url-id,url)----'   |
   *        |     |   .                       `----> (site-id, url) SITEDB
   *        V     V    .
   *     (url-id,url)   .
   *           |
   *           V
   *    (url-id,url) URLDB
   */
  public boolean exec(int nWorker) throws Exception {
    
    MrStarJobDef mrJob = new MrStarJobDef(2);
    
    // where to find the task classes and how to load them 
    //job.setTaskClassPath(env.get...);
    //job.setJavaConfig(env.get...);
    //job.setTaskWorkerHeapSize(env.get...);
    
    // job name & file system
    mrJob.setJobName("mr*");    
    mrJob.setDefaultFsName(context.getAppFs());
    
    // phase 0
    int mrPhase = 0;
    mrJob.addInputDir(mrPhase, input[mrPhase]);
    mrJob.setMapper(mrPhase, SiteMR.class);
    mrJob.setMergeKeyValClass(mrPhase, LongWritable.class, Container.class);
    mrJob.setReducer(mrPhase, SiteMR.class);
    mrJob.setMergeCompressed(mrPhase, true);
    mrJob.addOutputDir(mrPhase, OUTPUT_DIR_SITE, output[mrPhase], 
        LongWritable.class, UTF8Writable.class);
    
    mrJob.setMapOutBufferSize(mrPhase, 10 * 1024 * 1024);
    mrJob.setTaskHeapSize(200);
    // phase 1
    mrPhase = 1;
    mrJob.addInputDir(mrPhase, input[mrPhase]);
    mrJob.setMapper(mrPhase, IdentityMapper.class);
    mrJob.setMergeKeyValClass(mrPhase, LongWritable.class, UTF8Writable.class);
    mrJob.setReducer(mrPhase, IdentityReducer.class);
    mrJob.setMergeCompressed(mrPhase, true);
    mrJob.addOutputDir(mrPhase, OUTPUT_DIR_URL, output[mrPhase], 
        LongWritable.class, UTF8Writable.class);
    
    mrJob.setMapNumber(nMap);       // stage 0
    mrJob.setMrNumber(1,nMr);       // stage 1
    mrJob.setReduceNumber(nReduce); // stage 2
    mrJob.setWorkerNumber(nWorker);
    
    mrJob.setMapOutBufferSize(mrPhase, 10 * 1024 * 1024);
    
    mrJob.useDefaultHashPartitioner();    
    JobResult result = JobClient.runJob(context.getCoWork(),mrJob);
    
    return result.isSuccess();
  }

}
