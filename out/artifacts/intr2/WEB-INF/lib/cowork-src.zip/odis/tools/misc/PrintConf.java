package odis.tools.misc;

import java.io.PrintWriter;

import odis.tools.AbstractLocalTool;
import odis.tools.ToolContext;

/**
 * Tool to print the value for key in configuration on stdout.
 * This tool is used in scripts to acquire the application settings.
 * 
 * @author river
 *
 */
public class PrintConf extends AbstractLocalTool {

    public String comment() {
        return "Print the configruation";
    }

    public boolean exec(String[] args) throws Exception {
        if (args.length == 0) {
            usage(out);
            return false;
        }
        processArgs(args);
        return true;
    }

    public void usage(PrintWriter out) {
        out.println("usage: config-name");
    }

    protected boolean processArgs(String[] args) throws Exception {
        for (String s : args) {
            String value = ToolContext.getConfig().getString(s, null);
            if (value == null) {
                out.println("<null>");
            } else {
                out.println(value);
            }
        }
        return true;
    }

}
