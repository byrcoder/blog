package odis.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.sun.management.OperatingSystemMXBean;

import odis.util.SysInfo;
import toolbox.misc.LogFormatter;

public class ResourceInfo extends SysInfo{

    private static final Logger LOG = LogFormatter.getLogger(ResourceInfo.class);
    private static OperatingSystemMXBean osMXBean = (OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean();
    
    public static double getSystemLoadAverage() {
        return osMXBean.getSystemLoadAverage();
    }
    
    public static int getAvailableProcessors() {
        return osMXBean.getAvailableProcessors();
    }
    
    public static int getAvailableMemory(){
        String bashCmd = "free -m";
        try {
            Process proc = Runtime.getRuntime().exec(new String[]{"/bin/bash", "-c", bashCmd});
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new InputStreamReader(proc
                        .getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("Mem:")) {
                        String[] str = line.split("\\s+");
                        if (str.length == 7) {
                            int availMem = Integer.valueOf(str[3]) + Integer.valueOf(str[6]);
                            return availMem;
                        }
                    }
                }
            } finally {
                if (reader != null)
                    reader.close();
            }
            
        } catch (Exception e) {
            LOG.log(Level.WARNING, "", e);
            return -1;
        }
        return -1;
        
    }
    
    public static String byteToMegabit(long value) {
        double metabits = (double) value / 1048576;
        java.text.DecimalFormat df = new java.text.DecimalFormat("###,###.00");
        return df.format(metabits);
    }
    
    public static void main(String[] args) {
        System.out.println((int)(ResourceInfo.getAvailableMemory() >> 20));
    }
}
