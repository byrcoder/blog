package odis.tools;


import odis.cowork.GenericJobDef;
import odis.cowork.JobDef;
import odis.mapred.BasicInOutJobDef;
import odis.mapred.MapOnlyJobDef;
import odis.mapred.MapReduceJobDef;
import odis.mapred.MrStarJobDef;



/**
 * Environment for cowork tools.
 * 
 * @author river, David
 *
 */
public class ToolContext extends LocalToolContext {
    
    public ToolContext() {
        this(getConfig().getString("app.default"));
    }    
    
    /**
     * Create a context given instance name
     * @param instance  instance must exist and not be null
     */
    public ToolContext(String instance) {
        setApp(instance);
    }
    
    private void setApp(String instance) {
        if (instance == null || instance.equals("null")) {
            this.instanceName = null;
            this.instanceIdx = -1;
        } else {
            this.instanceName = instance;
            Integer idx = instanceMap.get(instance);
            if (idx!=null) 
                this.instanceIdx = idx;
            else 
                throw new RuntimeException("Cannot find instance " + instance);
        }
    }

    /**
     * This method should be override in subclass if application specified
     * configuration (e.g. other class than "CoWorkAppConf") should be used.
     * @param job  job definition
     * @param jobName  name of job
     * @param nWorker  number of worker to be used
     */
    public void configJob(JobDef job, String jobName, int nWorker) {
        job.setJobName(jobName);
        job.setWorkerNumber(nWorker);

        // set for task workers
        job.setTaskClassPath(System.getProperty("java.class.path"));
        job.setTaskOdisHome(getAppHome());
        job.addTaskDebugConfig(getAppProperties(APP_TASK_LOGLEVEL));
        job.setTaskHeapSize(getAppInt(APP_TASK_HEAPSIZE, 800));

        // set for BasicInOutJobDef
        if (job instanceof BasicInOutJobDef) {
            BasicInOutJobDef ioJob = (BasicInOutJobDef) job;
            ioJob.setDefaultFsName(getAppFs());
        }
    }

    public GenericJobDef createGenericJob(String jobName, int nWorker) {
        GenericJobDef job = new GenericJobDef();
        configJob(job, jobName, nWorker);
        return job;
    }

    public MapOnlyJobDef createMapOnlyJob(String jobName, int nWorker) {
        MapOnlyJobDef job = new MapOnlyJobDef();
        configJob(job, jobName, nWorker);
        return job;
    }

    public MapReduceJobDef createMapReduceJob(String jobName, int nWorker) {
        MapReduceJobDef job = new MapReduceJobDef();
        configJob(job, jobName, nWorker);
        return job;
    }

    public MrStarJobDef createMrStarJob(int mrNum, String jobName, int nWorker) {
        MrStarJobDef job = new MrStarJobDef(mrNum);
        configJob(job, jobName, nWorker);
        return job;
    }
}
