package odis.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.cli.ArgumentProcessor;
import toolbox.misc.cli.ITool;
import toolbox.text.util.StringComparison;
import toolbox.text.util.StringUtils;

/**
 * 
 * This is the entry class for to start all outfox tools (ICoWorkTool)
 * 
 * @author zl,river
 * 
 * 11/29/2006: incooperate the idear of CoWorkNameUtils and CoWorkNameDir which
 * was credited to Phoenix Wang. Thanks!
 * 
 */
public class ToolExecMain {

    private static final Logger LOG = LogFormatter.getLogger(ToolExecMain.class);

    // distributed tools
    private static Map<String, Class<? extends AbstractCoWorkTool>> distTools = 
        new TreeMap<String, Class<? extends AbstractCoWorkTool>>();

    // local tools
    private static Map<String, Class<? extends ITool>> localTools = 
        new TreeMap<String, Class<? extends ITool>>();

    static {
        init();
        // David: the following codes assure that initialization info lines
        // printed will not break help info
        for (String name: distTools.keySet()) {
            try {
                distTools.get(name).newInstance();
            } catch (InstantiationException e) {} catch (IllegalAccessException e) {}
        }
        for (String name: localTools.keySet()) {
            try {
                localTools.get(name).newInstance();
            } catch (InstantiationException e) {} catch (IllegalAccessException e) {}
        }
    }
    
    protected static void registerDistTool(String name, 
            Class<? extends AbstractCoWorkTool> tool) {
        distTools.put(name, tool);
    }

    protected static void registerLocalTool(String name, 
            Class<? extends ITool> cmd) {
        localTools.put(name, cmd);
    }

    public static final String PROP_NAME = "tools.list";

    @SuppressWarnings("unchecked")
    private static void init() {
        List<URL> resources = new ArrayList<URL>();
        try {
            Enumeration<URL> enume = ToolExecMain.class.getClassLoader()
                .getResources(PROP_NAME);
            for (; enume.hasMoreElements();) {
                resources.add(enume.nextElement());
            }
            enume = ToolExecMain.class.getClassLoader().getResources(
                    "META-INF/" + PROP_NAME);
            for (; enume.hasMoreElements();) {
                resources.add(enume.nextElement());
            }
        } catch (IOException e) {
            LOG.severe("cannot find " + PROP_NAME + " in classpath");
            throw new RuntimeException("cannot find " + PROP_NAME
                    + " in classpath ");
        }

        // find all tool class names
        HashMap<String, String> tool = new HashMap<String, String>();
        for (URL url : resources) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
                try{
                    String s;
                    while ((s = reader.readLine()) != null) {
                        s = s.trim();
                        if (s.length() == 0 || s.startsWith("#")) continue;
                        int pos = s.indexOf(':');
                        if (pos < 0) {
                            LOG.severe("bad tool def : " + s);
                        } else {
                            String toolName = s.substring(0, pos).trim();
                            String clazzName = s.substring(pos+1).trim();
                            if (tool.containsKey(toolName) && !clazzName.equals(tool.get(toolName))) {
                                String errorMsg = 
                                    "duplicate tool definition found for command \"" + toolName 
                                    + "\", previous class is \"" + tool.get(toolName) 
                                    + "\" and current is \"" + clazzName + "\"";
                                LOG.log(Level.SEVERE, errorMsg);
                                continue;
                            }
                            tool.put(toolName, clazzName);
                        }
                    }
                } finally {
                    reader.close();
                }
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "load tool configuration from " + url
                        + " failed.", e);
                throw new RuntimeException(e);
            }
        }
        
        // load classes
        for (Map.Entry<String, String> entry : tool.entrySet()) {
            String toolName = entry.getKey();
            String clazzName = entry.getValue();
            try {
                Class<?> clazz = Class.forName(clazzName);
                if (AbstractCoWorkTool.class.isAssignableFrom(clazz)) {
                    registerDistTool(toolName, (Class<? extends AbstractCoWorkTool>)clazz);
                } else if (ITool.class.isAssignableFrom(clazz)) {
                    registerLocalTool(toolName, (Class<? extends ITool>) clazz);
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING, "Error registering tool \"" + toolName 
                    + "\" with class \"" + clazzName + "\", ignoring: " + e.toString());
            }
        }
    }
    
    protected String nearestCommands(String cmd, int dis_max, int dis_show) {
        StringBuilder res = new StringBuilder();
        // find dis_best
        int dis_best = dis_max + 1;
        for (String name : distTools.keySet()) {
            int dis = StringComparison.editDistance(cmd, name);
            if (dis < dis_best)
                dis_best = dis;
        } // for name
        for (String name : localTools.keySet()) {
            int dis = StringComparison.editDistance(cmd, name);
            if (dis < dis_best)
                dis_best = dis;
        } // for name
        // find name to shown
        for (String name : distTools.keySet()) {
            int dis = StringComparison.editDistance(cmd, name);
            if (dis <= dis_show || dis == dis_best) {
                if (res.length() > 0) {
                    res.append(' ');
                }
                res.append(name);
            }
        } // for name
        for (String name : localTools.keySet()) {
            int dis = StringComparison.editDistance(cmd, name);
            if (dis <= dis_show || dis == dis_best) {
                if (res.length() > 0) {
                    res.append(' ');
                }
                res.append(name);
            }
        } // for name
        // return result
        return res.toString();
    }

    protected Class getToolClass(String name) {
        Class cls = distTools.get(name);
        if (cls == null)
            cls = localTools.get(name);
        if (cls == null) {
            try {
                cls = Class.forName(name);
            } catch(Exception e) {
                cls = null;
            }
        }
        
        if (cls == null) {
            String pattern = name;
            List<String> includeList = new ArrayList<String>(1);
            includeList.add(pattern);
            try {
                String [] classnames = ClassUtils.findClassesInPackage(
                        ".*", includeList, new ArrayList<String>(0));
                HashSet<String> set = new HashSet<String>();
                for (String s : classnames) {
                    set.add(s);
                }
                if (set.size() == 1) {
                    cls = Class.forName(set.iterator().next());
                } else if (set.size() > 1) {
                    LOG.info("Multiply candidate classes found : " + 
                            Arrays.toString(set.toArray(new String[set.size()])));
                }
            } catch(Exception e) {
            }
        }
        
        return cls;
    }

    protected int processPrependArgs(String[] args, int idx) {
        while (idx < args.length) {
            if ("-d".equals(args[idx])) {
                LogFormatter.setDebugLevel(Level.FINE, "_all");
                idx++;
            } else if ("-dd".equals(args[idx])) {
                LogFormatter.setDebugLevel(Level.FINER, "_all");
                idx++;
            } else if ("-ddd".equals(args[idx])) {
                LogFormatter.setDebugLevel(Level.ALL, "_all");
                idx++;
            } else {
                break;
            }
        } // while
        return idx;
    }
    
    /**
     * Can be overrided
     */
    protected ToolContext getToolContext(String instance) {
        if (instance==null) return new ToolContext();
        else return new ToolContext(instance);
    }

    /**
     * Executes the job.
     * @param args  the arguments from the console
     * @param out the output PrintWriter
     * @return  the return value for the application
     */
    public int exec(String[] args, PrintWriter out) {
        long timeStart = System.currentTimeMillis();

        int rvalue = 0;

        try {
            // process prepend arguements
            int i = processPrependArgs(args, 0);
            if (i >= args.length) { usage(out); rvalue = 1; return rvalue; }
            
            // process result of the options
            ToolContext env = getToolContext(null);        
            ArgumentProcessor p = new ArgumentProcessor("wn", 1, "DEF:1");
            
            env.setToArguments(p);
            
            String res = p.process(args, i);
            if (res != null) throw new RuntimeException(res);
            if (p.size() < 1) { usage(out); rvalue = 1; return rvalue; }

            String cmd = p.get(0);
            if ("help".equals(cmd)) {   // help
                if (p.size() < 2) usage(out);
                else { cmd = p.get(1); help(cmd, out); }
            } else {                    // tools
                // get tool
                Class cls = getToolClass(cmd);
                if (cls == null) unknown(cmd, out);
                
                // configurate env settings according to the command line
                int nWorker = p.getIntOpt("wn");
                env.getFromArguments(p);
                
                // left over args
                String[] newArgs = new String[p.size() - 1];
                for (int j = 0; j < newArgs.length; j++)
                    newArgs[j] = p.get(j + 1);
                //cat will be used to simulate read for non-java
                //and its output can not have other message
                if (!"cat".equals(cmd)) {
                    out.println("Running tool " + cmd + " using " + nWorker
                            + " workers, with " + env.toString());
                }
                
                // exec tool
                if (AbstractCoWorkTool.class.isAssignableFrom(cls)) { // dist tool
                    AbstractCoWorkTool tool = (AbstractCoWorkTool) cls.newInstance();
                    if (!tool.setEnv(env, newArgs, out)) {
                        out.println("Error in setting environment.");
                        rvalue = 2;
                    } else if (!tool.exec(nWorker)) {
                        rvalue = 2;
                        LOG.warning("CoWorkTool is not correctly executed.");
                    }
                } else if (ITool.class.isAssignableFrom(cls)) { // local tool
                    ITool tool = (ITool) cls.newInstance();
                    if (tool instanceof AbstractLocalTool)
                        if (!((AbstractLocalTool)tool).setEnv(env, out)) {
                            out.println("Error in setting environment.");
                            rvalue = 2;                        	
                        }
                    if (rvalue==0 && !tool.exec(newArgs)) {
                        rvalue = 2;
                        LOG.warning("LocalTool is not correctly executed.");
                    }
                } else {
                    LOG.warning(cls.getName() + "This is not a tool.");
                }
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Error during starting service or run demo", e);
            rvalue = 3;
        }

        long timeEnd = System.currentTimeMillis();
        LOG.info("Total elapsed time: " + (timeEnd - timeStart) + " ms ("
                + ((int) (timeEnd - timeStart) / 1000 / 60) + " minutes "
                + (((timeEnd - timeStart) / 1000) % 60) + " seconds)");
        return rvalue;        
    }
    
    /**
     * Display help message for a command
     * @param cmd   The command with help message
     */
    private void help(String cmd, PrintWriter out) throws Exception{
        Class cls = getToolClass(cmd);
        if (cls == null) {
            unknown(cmd, out);
        } else if (AbstractCoWorkTool.class.isAssignableFrom(cls)) {
            ((AbstractCoWorkTool) cls.newInstance()).usage(out);
        } else if (ITool.class.isAssignableFrom(cls))
            ((ITool) cls.newInstance()).usage(out);
    }
    
    private void unknown(String cmd, PrintWriter out) {
        out.print("  Unkown commands " + cmd);
        String[] simCmds = nearestCommands(cmd, 5, 3).split(" ");
        if (simCmds.length >= 1)
            out.println(" (similar commands: "
                    + Arrays.deepToString(simCmds) + ")");
        else out.println();
        // throw exception for scripts' detecting failure.
        throw new RuntimeException("Unknown command/class: " + cmd);
    }    

    private void usage(PrintWriter out) throws Exception {
        String[] options = getToolContext(null).displayArguments();        
        out.println("Usage:");
        out.println("1. help [tool-name]");
        out.println("2. [global-options] <tool-name> [tool-options]");
        out.println("   global-option:");
        out.println("     -wn worker-num - number of workers to be reserved. DEFAULT: 1.");
        for (String op:options) out.println("     " + op);
        
        // dist tools
        out.println("   cowork-tool-names:");
        printTools(distTools, out);
        
        // local tools
        out.println("   local-tool-names:");
        printTools(localTools, out);

        // tool options
        out.println("   tool-options: ");
        out.println("     find out of each tool using \"help [tool-name]\"");
    }
    
    private void printTools(Map<String, ?> tools, PrintWriter out) {
        Set<String> keys = tools.keySet();
        int len = 0;
        for (String key : keys)
            if (key.length() > len) len = key.length();
        if (len > 15) len = 15;
        for (String key : keys) {
            String comment = key + " tool.";
            try {
                Class cls = (Class) tools.get(key);
                if (AbstractCoWorkTool.class.isAssignableFrom(cls))
                    comment = ((AbstractCoWorkTool) cls.newInstance()).comment();
                else if (ITool.class.isAssignableFrom(cls))
                    comment = ((ITool) cls.newInstance()).comment();
                else continue;
            } catch (Exception e) { continue; }
            int len_comment = 80 - Math.max(len, key.length()) - 7; // 7 is the spaces we used
            ArrayList<String> lines = StringUtils.layout(comment, len_comment,
                    "ends");
            out.format("     %-" + len + "s  %s\n", key,
                    (lines.size() > 0 ? lines.get(0) : ""));
            for (int i = 1; i < lines.size(); i++)
                out.format("     %-" + Math.max(len, key.length()) + "s  %s\n",
                        "", lines.get(i));
        } // for key
    }

    public static void main(String[] args) {
        ToolExecMain os = new ToolExecMain();
        PrintWriter out = new PrintWriter(System.out, true);
        System.exit(os.exec(args, out));
    }

}
