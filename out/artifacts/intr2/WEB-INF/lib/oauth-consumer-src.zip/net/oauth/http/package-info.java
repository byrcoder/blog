/**
 * Classes that integrate OAuth with HTTP.
 */
package net.oauth.http;
