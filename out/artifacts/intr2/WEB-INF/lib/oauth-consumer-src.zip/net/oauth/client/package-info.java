/**
 * Classes for implementing an OAuth Consumer; that is a client that requests
 * access to protected resources.
 */
package net.oauth.client;

